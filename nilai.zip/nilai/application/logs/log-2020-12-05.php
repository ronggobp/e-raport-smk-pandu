<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-05 00:52:47 --> Config Class Initialized
INFO - 2020-12-05 00:52:47 --> Hooks Class Initialized
DEBUG - 2020-12-05 00:52:47 --> UTF-8 Support Enabled
INFO - 2020-12-05 00:52:47 --> Utf8 Class Initialized
INFO - 2020-12-05 00:52:47 --> URI Class Initialized
DEBUG - 2020-12-05 00:52:47 --> No URI present. Default controller set.
INFO - 2020-12-05 00:52:47 --> Router Class Initialized
INFO - 2020-12-05 00:52:47 --> Output Class Initialized
INFO - 2020-12-05 00:52:47 --> Security Class Initialized
DEBUG - 2020-12-05 00:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 00:52:47 --> Input Class Initialized
INFO - 2020-12-05 00:52:47 --> Language Class Initialized
INFO - 2020-12-05 00:52:47 --> Language Class Initialized
INFO - 2020-12-05 00:52:47 --> Config Class Initialized
INFO - 2020-12-05 00:52:47 --> Loader Class Initialized
INFO - 2020-12-05 00:52:47 --> Helper loaded: url_helper
INFO - 2020-12-05 00:52:47 --> Helper loaded: file_helper
INFO - 2020-12-05 00:52:47 --> Helper loaded: form_helper
INFO - 2020-12-05 00:52:47 --> Helper loaded: my_helper
INFO - 2020-12-05 00:52:47 --> Database Driver Class Initialized
DEBUG - 2020-12-05 00:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 00:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 00:52:48 --> Controller Class Initialized
INFO - 2020-12-05 00:52:48 --> Config Class Initialized
INFO - 2020-12-05 00:52:48 --> Hooks Class Initialized
DEBUG - 2020-12-05 00:52:48 --> UTF-8 Support Enabled
INFO - 2020-12-05 00:52:48 --> Utf8 Class Initialized
INFO - 2020-12-05 00:52:48 --> URI Class Initialized
INFO - 2020-12-05 00:52:48 --> Router Class Initialized
INFO - 2020-12-05 00:52:48 --> Output Class Initialized
INFO - 2020-12-05 00:52:48 --> Security Class Initialized
DEBUG - 2020-12-05 00:52:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 00:52:48 --> Input Class Initialized
INFO - 2020-12-05 00:52:48 --> Language Class Initialized
INFO - 2020-12-05 00:52:48 --> Language Class Initialized
INFO - 2020-12-05 00:52:48 --> Config Class Initialized
INFO - 2020-12-05 00:52:48 --> Loader Class Initialized
INFO - 2020-12-05 00:52:48 --> Helper loaded: url_helper
INFO - 2020-12-05 00:52:48 --> Helper loaded: file_helper
INFO - 2020-12-05 00:52:48 --> Helper loaded: form_helper
INFO - 2020-12-05 00:52:48 --> Helper loaded: my_helper
INFO - 2020-12-05 00:52:48 --> Database Driver Class Initialized
DEBUG - 2020-12-05 00:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 00:52:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 00:52:48 --> Controller Class Initialized
DEBUG - 2020-12-05 00:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-05 00:52:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 00:52:48 --> Final output sent to browser
DEBUG - 2020-12-05 00:52:48 --> Total execution time: 0.2076
INFO - 2020-12-05 00:53:02 --> Config Class Initialized
INFO - 2020-12-05 00:53:02 --> Hooks Class Initialized
DEBUG - 2020-12-05 00:53:02 --> UTF-8 Support Enabled
INFO - 2020-12-05 00:53:02 --> Utf8 Class Initialized
INFO - 2020-12-05 00:53:02 --> URI Class Initialized
INFO - 2020-12-05 00:53:02 --> Router Class Initialized
INFO - 2020-12-05 00:53:02 --> Output Class Initialized
INFO - 2020-12-05 00:53:02 --> Security Class Initialized
DEBUG - 2020-12-05 00:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 00:53:02 --> Input Class Initialized
INFO - 2020-12-05 00:53:02 --> Language Class Initialized
INFO - 2020-12-05 00:53:02 --> Language Class Initialized
INFO - 2020-12-05 00:53:02 --> Config Class Initialized
INFO - 2020-12-05 00:53:02 --> Loader Class Initialized
INFO - 2020-12-05 00:53:02 --> Helper loaded: url_helper
INFO - 2020-12-05 00:53:02 --> Helper loaded: file_helper
INFO - 2020-12-05 00:53:02 --> Helper loaded: form_helper
INFO - 2020-12-05 00:53:02 --> Helper loaded: my_helper
INFO - 2020-12-05 00:53:02 --> Database Driver Class Initialized
DEBUG - 2020-12-05 00:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 00:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 00:53:02 --> Controller Class Initialized
INFO - 2020-12-05 00:53:02 --> Helper loaded: cookie_helper
INFO - 2020-12-05 00:53:02 --> Final output sent to browser
DEBUG - 2020-12-05 00:53:02 --> Total execution time: 0.3692
INFO - 2020-12-05 00:53:04 --> Config Class Initialized
INFO - 2020-12-05 00:53:04 --> Hooks Class Initialized
DEBUG - 2020-12-05 00:53:04 --> UTF-8 Support Enabled
INFO - 2020-12-05 00:53:04 --> Utf8 Class Initialized
INFO - 2020-12-05 00:53:04 --> URI Class Initialized
INFO - 2020-12-05 00:53:04 --> Router Class Initialized
INFO - 2020-12-05 00:53:04 --> Output Class Initialized
INFO - 2020-12-05 00:53:04 --> Security Class Initialized
DEBUG - 2020-12-05 00:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 00:53:04 --> Input Class Initialized
INFO - 2020-12-05 00:53:04 --> Language Class Initialized
INFO - 2020-12-05 00:53:04 --> Language Class Initialized
INFO - 2020-12-05 00:53:04 --> Config Class Initialized
INFO - 2020-12-05 00:53:04 --> Loader Class Initialized
INFO - 2020-12-05 00:53:04 --> Helper loaded: url_helper
INFO - 2020-12-05 00:53:04 --> Helper loaded: file_helper
INFO - 2020-12-05 00:53:04 --> Helper loaded: form_helper
INFO - 2020-12-05 00:53:04 --> Helper loaded: my_helper
INFO - 2020-12-05 00:53:04 --> Database Driver Class Initialized
DEBUG - 2020-12-05 00:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 00:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 00:53:04 --> Controller Class Initialized
DEBUG - 2020-12-05 00:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-05 00:53:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 00:53:04 --> Final output sent to browser
DEBUG - 2020-12-05 00:53:04 --> Total execution time: 0.2770
INFO - 2020-12-05 00:53:08 --> Config Class Initialized
INFO - 2020-12-05 00:53:08 --> Hooks Class Initialized
DEBUG - 2020-12-05 00:53:08 --> UTF-8 Support Enabled
INFO - 2020-12-05 00:53:08 --> Utf8 Class Initialized
INFO - 2020-12-05 00:53:08 --> URI Class Initialized
INFO - 2020-12-05 00:53:08 --> Router Class Initialized
INFO - 2020-12-05 00:53:08 --> Output Class Initialized
INFO - 2020-12-05 00:53:08 --> Security Class Initialized
DEBUG - 2020-12-05 00:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 00:53:08 --> Input Class Initialized
INFO - 2020-12-05 00:53:08 --> Language Class Initialized
INFO - 2020-12-05 00:53:08 --> Language Class Initialized
INFO - 2020-12-05 00:53:08 --> Config Class Initialized
INFO - 2020-12-05 00:53:08 --> Loader Class Initialized
INFO - 2020-12-05 00:53:08 --> Helper loaded: url_helper
INFO - 2020-12-05 00:53:08 --> Helper loaded: file_helper
INFO - 2020-12-05 00:53:08 --> Helper loaded: form_helper
INFO - 2020-12-05 00:53:08 --> Helper loaded: my_helper
INFO - 2020-12-05 00:53:08 --> Database Driver Class Initialized
DEBUG - 2020-12-05 00:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 00:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 00:53:08 --> Controller Class Initialized
DEBUG - 2020-12-05 00:53:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 00:53:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 00:53:09 --> Final output sent to browser
DEBUG - 2020-12-05 00:53:09 --> Total execution time: 0.3740
INFO - 2020-12-05 02:32:03 --> Config Class Initialized
INFO - 2020-12-05 02:32:03 --> Hooks Class Initialized
DEBUG - 2020-12-05 02:32:03 --> UTF-8 Support Enabled
INFO - 2020-12-05 02:32:03 --> Utf8 Class Initialized
INFO - 2020-12-05 02:32:03 --> URI Class Initialized
INFO - 2020-12-05 02:32:03 --> Router Class Initialized
INFO - 2020-12-05 02:32:03 --> Output Class Initialized
INFO - 2020-12-05 02:32:03 --> Security Class Initialized
DEBUG - 2020-12-05 02:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 02:32:03 --> Input Class Initialized
INFO - 2020-12-05 02:32:03 --> Language Class Initialized
INFO - 2020-12-05 02:32:03 --> Language Class Initialized
INFO - 2020-12-05 02:32:03 --> Config Class Initialized
INFO - 2020-12-05 02:32:03 --> Loader Class Initialized
INFO - 2020-12-05 02:32:03 --> Helper loaded: url_helper
INFO - 2020-12-05 02:32:03 --> Helper loaded: file_helper
INFO - 2020-12-05 02:32:03 --> Helper loaded: form_helper
INFO - 2020-12-05 02:32:03 --> Helper loaded: my_helper
INFO - 2020-12-05 02:32:03 --> Database Driver Class Initialized
DEBUG - 2020-12-05 02:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 02:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 02:32:03 --> Controller Class Initialized
DEBUG - 2020-12-05 02:32:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 02:32:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 02:32:03 --> Final output sent to browser
DEBUG - 2020-12-05 02:32:03 --> Total execution time: 0.2101
INFO - 2020-12-05 02:32:13 --> Config Class Initialized
INFO - 2020-12-05 02:32:13 --> Hooks Class Initialized
DEBUG - 2020-12-05 02:32:13 --> UTF-8 Support Enabled
INFO - 2020-12-05 02:32:13 --> Utf8 Class Initialized
INFO - 2020-12-05 02:32:13 --> URI Class Initialized
INFO - 2020-12-05 02:32:13 --> Router Class Initialized
INFO - 2020-12-05 02:32:13 --> Output Class Initialized
INFO - 2020-12-05 02:32:13 --> Security Class Initialized
DEBUG - 2020-12-05 02:32:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 02:32:13 --> Input Class Initialized
INFO - 2020-12-05 02:32:13 --> Language Class Initialized
INFO - 2020-12-05 02:32:13 --> Language Class Initialized
INFO - 2020-12-05 02:32:13 --> Config Class Initialized
INFO - 2020-12-05 02:32:13 --> Loader Class Initialized
INFO - 2020-12-05 02:32:13 --> Helper loaded: url_helper
INFO - 2020-12-05 02:32:13 --> Helper loaded: file_helper
INFO - 2020-12-05 02:32:13 --> Helper loaded: form_helper
INFO - 2020-12-05 02:32:13 --> Helper loaded: my_helper
INFO - 2020-12-05 02:32:13 --> Database Driver Class Initialized
DEBUG - 2020-12-05 02:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 02:32:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 02:32:13 --> Controller Class Initialized
DEBUG - 2020-12-05 02:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-05 02:32:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 02:32:13 --> Final output sent to browser
DEBUG - 2020-12-05 02:32:13 --> Total execution time: 0.2130
INFO - 2020-12-05 02:32:14 --> Config Class Initialized
INFO - 2020-12-05 02:32:14 --> Hooks Class Initialized
DEBUG - 2020-12-05 02:32:14 --> UTF-8 Support Enabled
INFO - 2020-12-05 02:32:14 --> Utf8 Class Initialized
INFO - 2020-12-05 02:32:14 --> URI Class Initialized
INFO - 2020-12-05 02:32:14 --> Router Class Initialized
INFO - 2020-12-05 02:32:14 --> Output Class Initialized
INFO - 2020-12-05 02:32:14 --> Security Class Initialized
DEBUG - 2020-12-05 02:32:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 02:32:14 --> Input Class Initialized
INFO - 2020-12-05 02:32:14 --> Language Class Initialized
INFO - 2020-12-05 02:32:14 --> Language Class Initialized
INFO - 2020-12-05 02:32:14 --> Config Class Initialized
INFO - 2020-12-05 02:32:14 --> Loader Class Initialized
INFO - 2020-12-05 02:32:14 --> Helper loaded: url_helper
INFO - 2020-12-05 02:32:14 --> Helper loaded: file_helper
INFO - 2020-12-05 02:32:14 --> Helper loaded: form_helper
INFO - 2020-12-05 02:32:14 --> Helper loaded: my_helper
INFO - 2020-12-05 02:32:14 --> Database Driver Class Initialized
DEBUG - 2020-12-05 02:32:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 02:32:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 02:32:14 --> Controller Class Initialized
DEBUG - 2020-12-05 02:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 02:32:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 02:32:14 --> Final output sent to browser
DEBUG - 2020-12-05 02:32:14 --> Total execution time: 0.1745
INFO - 2020-12-05 02:32:15 --> Config Class Initialized
INFO - 2020-12-05 02:32:15 --> Hooks Class Initialized
DEBUG - 2020-12-05 02:32:15 --> UTF-8 Support Enabled
INFO - 2020-12-05 02:32:15 --> Utf8 Class Initialized
INFO - 2020-12-05 02:32:15 --> URI Class Initialized
INFO - 2020-12-05 02:32:15 --> Router Class Initialized
INFO - 2020-12-05 02:32:15 --> Output Class Initialized
INFO - 2020-12-05 02:32:15 --> Security Class Initialized
DEBUG - 2020-12-05 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 02:32:15 --> Input Class Initialized
INFO - 2020-12-05 02:32:15 --> Language Class Initialized
INFO - 2020-12-05 02:32:15 --> Language Class Initialized
INFO - 2020-12-05 02:32:15 --> Config Class Initialized
INFO - 2020-12-05 02:32:15 --> Loader Class Initialized
INFO - 2020-12-05 02:32:15 --> Helper loaded: url_helper
INFO - 2020-12-05 02:32:15 --> Helper loaded: file_helper
INFO - 2020-12-05 02:32:15 --> Helper loaded: form_helper
INFO - 2020-12-05 02:32:15 --> Helper loaded: my_helper
INFO - 2020-12-05 02:32:15 --> Database Driver Class Initialized
DEBUG - 2020-12-05 02:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 02:32:15 --> Controller Class Initialized
DEBUG - 2020-12-05 02:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-05 02:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 02:32:15 --> Final output sent to browser
DEBUG - 2020-12-05 02:32:15 --> Total execution time: 0.1786
INFO - 2020-12-05 02:32:19 --> Config Class Initialized
INFO - 2020-12-05 02:32:19 --> Hooks Class Initialized
DEBUG - 2020-12-05 02:32:19 --> UTF-8 Support Enabled
INFO - 2020-12-05 02:32:19 --> Utf8 Class Initialized
INFO - 2020-12-05 02:32:19 --> URI Class Initialized
INFO - 2020-12-05 02:32:19 --> Router Class Initialized
INFO - 2020-12-05 02:32:19 --> Output Class Initialized
INFO - 2020-12-05 02:32:19 --> Security Class Initialized
DEBUG - 2020-12-05 02:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 02:32:19 --> Input Class Initialized
INFO - 2020-12-05 02:32:19 --> Language Class Initialized
INFO - 2020-12-05 02:32:19 --> Language Class Initialized
INFO - 2020-12-05 02:32:19 --> Config Class Initialized
INFO - 2020-12-05 02:32:19 --> Loader Class Initialized
INFO - 2020-12-05 02:32:19 --> Helper loaded: url_helper
INFO - 2020-12-05 02:32:19 --> Helper loaded: file_helper
INFO - 2020-12-05 02:32:19 --> Helper loaded: form_helper
INFO - 2020-12-05 02:32:19 --> Helper loaded: my_helper
INFO - 2020-12-05 02:32:19 --> Database Driver Class Initialized
DEBUG - 2020-12-05 02:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 02:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 02:32:19 --> Controller Class Initialized
DEBUG - 2020-12-05 02:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 02:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 02:32:19 --> Final output sent to browser
DEBUG - 2020-12-05 02:32:19 --> Total execution time: 0.1773
INFO - 2020-12-05 04:43:44 --> Config Class Initialized
INFO - 2020-12-05 04:43:44 --> Hooks Class Initialized
DEBUG - 2020-12-05 04:43:44 --> UTF-8 Support Enabled
INFO - 2020-12-05 04:43:44 --> Utf8 Class Initialized
INFO - 2020-12-05 04:43:44 --> URI Class Initialized
INFO - 2020-12-05 04:43:44 --> Router Class Initialized
INFO - 2020-12-05 04:43:44 --> Output Class Initialized
INFO - 2020-12-05 04:43:44 --> Security Class Initialized
DEBUG - 2020-12-05 04:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 04:43:44 --> Input Class Initialized
INFO - 2020-12-05 04:43:44 --> Language Class Initialized
INFO - 2020-12-05 04:43:44 --> Language Class Initialized
INFO - 2020-12-05 04:43:44 --> Config Class Initialized
INFO - 2020-12-05 04:43:44 --> Loader Class Initialized
INFO - 2020-12-05 04:43:44 --> Helper loaded: url_helper
INFO - 2020-12-05 04:43:44 --> Helper loaded: file_helper
INFO - 2020-12-05 04:43:44 --> Helper loaded: form_helper
INFO - 2020-12-05 04:43:44 --> Helper loaded: my_helper
INFO - 2020-12-05 04:43:44 --> Database Driver Class Initialized
DEBUG - 2020-12-05 04:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 04:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 04:43:44 --> Controller Class Initialized
DEBUG - 2020-12-05 04:43:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 04:43:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 04:43:44 --> Final output sent to browser
DEBUG - 2020-12-05 04:43:44 --> Total execution time: 0.1842
INFO - 2020-12-05 04:44:59 --> Config Class Initialized
INFO - 2020-12-05 04:44:59 --> Hooks Class Initialized
DEBUG - 2020-12-05 04:44:59 --> UTF-8 Support Enabled
INFO - 2020-12-05 04:44:59 --> Utf8 Class Initialized
INFO - 2020-12-05 04:44:59 --> URI Class Initialized
INFO - 2020-12-05 04:44:59 --> Router Class Initialized
INFO - 2020-12-05 04:44:59 --> Output Class Initialized
INFO - 2020-12-05 04:44:59 --> Security Class Initialized
DEBUG - 2020-12-05 04:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 04:44:59 --> Input Class Initialized
INFO - 2020-12-05 04:44:59 --> Language Class Initialized
INFO - 2020-12-05 04:44:59 --> Language Class Initialized
INFO - 2020-12-05 04:44:59 --> Config Class Initialized
INFO - 2020-12-05 04:44:59 --> Loader Class Initialized
INFO - 2020-12-05 04:44:59 --> Helper loaded: url_helper
INFO - 2020-12-05 04:44:59 --> Helper loaded: file_helper
INFO - 2020-12-05 04:44:59 --> Helper loaded: form_helper
INFO - 2020-12-05 04:44:59 --> Helper loaded: my_helper
INFO - 2020-12-05 04:44:59 --> Database Driver Class Initialized
DEBUG - 2020-12-05 04:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 04:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 04:44:59 --> Controller Class Initialized
DEBUG - 2020-12-05 04:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 04:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 04:44:59 --> Final output sent to browser
DEBUG - 2020-12-05 04:44:59 --> Total execution time: 0.2376
INFO - 2020-12-05 04:45:00 --> Config Class Initialized
INFO - 2020-12-05 04:45:00 --> Hooks Class Initialized
DEBUG - 2020-12-05 04:45:00 --> UTF-8 Support Enabled
INFO - 2020-12-05 04:45:00 --> Utf8 Class Initialized
INFO - 2020-12-05 04:45:00 --> URI Class Initialized
INFO - 2020-12-05 04:45:00 --> Router Class Initialized
INFO - 2020-12-05 04:45:00 --> Output Class Initialized
INFO - 2020-12-05 04:45:00 --> Security Class Initialized
DEBUG - 2020-12-05 04:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 04:45:00 --> Input Class Initialized
INFO - 2020-12-05 04:45:00 --> Language Class Initialized
INFO - 2020-12-05 04:45:00 --> Language Class Initialized
INFO - 2020-12-05 04:45:00 --> Config Class Initialized
INFO - 2020-12-05 04:45:00 --> Loader Class Initialized
INFO - 2020-12-05 04:45:00 --> Helper loaded: url_helper
INFO - 2020-12-05 04:45:00 --> Helper loaded: file_helper
INFO - 2020-12-05 04:45:00 --> Helper loaded: form_helper
INFO - 2020-12-05 04:45:00 --> Helper loaded: my_helper
INFO - 2020-12-05 04:45:00 --> Database Driver Class Initialized
DEBUG - 2020-12-05 04:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 04:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 04:45:00 --> Controller Class Initialized
DEBUG - 2020-12-05 04:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 04:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 04:45:00 --> Final output sent to browser
DEBUG - 2020-12-05 04:45:00 --> Total execution time: 0.1808
INFO - 2020-12-05 04:45:09 --> Config Class Initialized
INFO - 2020-12-05 04:45:09 --> Hooks Class Initialized
DEBUG - 2020-12-05 04:45:09 --> UTF-8 Support Enabled
INFO - 2020-12-05 04:45:09 --> Utf8 Class Initialized
INFO - 2020-12-05 04:45:09 --> URI Class Initialized
INFO - 2020-12-05 04:45:09 --> Router Class Initialized
INFO - 2020-12-05 04:45:09 --> Output Class Initialized
INFO - 2020-12-05 04:45:09 --> Security Class Initialized
DEBUG - 2020-12-05 04:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 04:45:09 --> Input Class Initialized
INFO - 2020-12-05 04:45:09 --> Language Class Initialized
INFO - 2020-12-05 04:45:09 --> Language Class Initialized
INFO - 2020-12-05 04:45:09 --> Config Class Initialized
INFO - 2020-12-05 04:45:09 --> Loader Class Initialized
INFO - 2020-12-05 04:45:09 --> Helper loaded: url_helper
INFO - 2020-12-05 04:45:09 --> Helper loaded: file_helper
INFO - 2020-12-05 04:45:09 --> Helper loaded: form_helper
INFO - 2020-12-05 04:45:09 --> Helper loaded: my_helper
INFO - 2020-12-05 04:45:09 --> Database Driver Class Initialized
DEBUG - 2020-12-05 04:45:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 04:45:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 04:45:09 --> Controller Class Initialized
DEBUG - 2020-12-05 04:45:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-12-05 04:45:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 04:45:09 --> Final output sent to browser
DEBUG - 2020-12-05 04:45:09 --> Total execution time: 0.2226
INFO - 2020-12-05 04:45:09 --> Config Class Initialized
INFO - 2020-12-05 04:45:09 --> Hooks Class Initialized
DEBUG - 2020-12-05 04:45:09 --> UTF-8 Support Enabled
INFO - 2020-12-05 04:45:10 --> Utf8 Class Initialized
INFO - 2020-12-05 04:45:10 --> URI Class Initialized
INFO - 2020-12-05 04:45:10 --> Router Class Initialized
INFO - 2020-12-05 04:45:10 --> Output Class Initialized
INFO - 2020-12-05 04:45:10 --> Security Class Initialized
DEBUG - 2020-12-05 04:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 04:45:10 --> Input Class Initialized
INFO - 2020-12-05 04:45:10 --> Language Class Initialized
INFO - 2020-12-05 04:45:10 --> Language Class Initialized
INFO - 2020-12-05 04:45:10 --> Config Class Initialized
INFO - 2020-12-05 04:45:10 --> Loader Class Initialized
INFO - 2020-12-05 04:45:10 --> Helper loaded: url_helper
INFO - 2020-12-05 04:45:10 --> Helper loaded: file_helper
INFO - 2020-12-05 04:45:10 --> Helper loaded: form_helper
INFO - 2020-12-05 04:45:10 --> Helper loaded: my_helper
INFO - 2020-12-05 04:45:10 --> Database Driver Class Initialized
DEBUG - 2020-12-05 04:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 04:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 04:45:10 --> Controller Class Initialized
INFO - 2020-12-05 04:45:10 --> Config Class Initialized
INFO - 2020-12-05 04:45:10 --> Hooks Class Initialized
DEBUG - 2020-12-05 04:45:10 --> UTF-8 Support Enabled
INFO - 2020-12-05 04:45:10 --> Utf8 Class Initialized
INFO - 2020-12-05 04:45:10 --> URI Class Initialized
INFO - 2020-12-05 04:45:10 --> Router Class Initialized
INFO - 2020-12-05 04:45:10 --> Output Class Initialized
INFO - 2020-12-05 04:45:10 --> Security Class Initialized
DEBUG - 2020-12-05 04:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 04:45:10 --> Input Class Initialized
INFO - 2020-12-05 04:45:10 --> Language Class Initialized
INFO - 2020-12-05 04:45:10 --> Language Class Initialized
INFO - 2020-12-05 04:45:10 --> Config Class Initialized
INFO - 2020-12-05 04:45:10 --> Loader Class Initialized
INFO - 2020-12-05 04:45:10 --> Helper loaded: url_helper
INFO - 2020-12-05 04:45:10 --> Helper loaded: file_helper
INFO - 2020-12-05 04:45:10 --> Helper loaded: form_helper
INFO - 2020-12-05 04:45:10 --> Helper loaded: my_helper
INFO - 2020-12-05 04:45:10 --> Database Driver Class Initialized
DEBUG - 2020-12-05 04:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 04:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 04:45:10 --> Controller Class Initialized
DEBUG - 2020-12-05 04:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 04:45:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 04:45:10 --> Final output sent to browser
DEBUG - 2020-12-05 04:45:10 --> Total execution time: 0.1883
INFO - 2020-12-05 04:45:33 --> Config Class Initialized
INFO - 2020-12-05 04:45:33 --> Hooks Class Initialized
DEBUG - 2020-12-05 04:45:33 --> UTF-8 Support Enabled
INFO - 2020-12-05 04:45:33 --> Utf8 Class Initialized
INFO - 2020-12-05 04:45:33 --> URI Class Initialized
INFO - 2020-12-05 04:45:33 --> Router Class Initialized
INFO - 2020-12-05 04:45:33 --> Output Class Initialized
INFO - 2020-12-05 04:45:33 --> Security Class Initialized
DEBUG - 2020-12-05 04:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 04:45:33 --> Input Class Initialized
INFO - 2020-12-05 04:45:33 --> Language Class Initialized
INFO - 2020-12-05 04:45:33 --> Language Class Initialized
INFO - 2020-12-05 04:45:33 --> Config Class Initialized
INFO - 2020-12-05 04:45:33 --> Loader Class Initialized
INFO - 2020-12-05 04:45:33 --> Helper loaded: url_helper
INFO - 2020-12-05 04:45:33 --> Helper loaded: file_helper
INFO - 2020-12-05 04:45:33 --> Helper loaded: form_helper
INFO - 2020-12-05 04:45:33 --> Helper loaded: my_helper
INFO - 2020-12-05 04:45:34 --> Database Driver Class Initialized
DEBUG - 2020-12-05 04:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 04:45:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 04:45:34 --> Controller Class Initialized
DEBUG - 2020-12-05 04:45:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 04:45:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 04:45:34 --> Final output sent to browser
DEBUG - 2020-12-05 04:45:34 --> Total execution time: 0.2547
INFO - 2020-12-05 08:35:56 --> Config Class Initialized
INFO - 2020-12-05 08:35:56 --> Hooks Class Initialized
DEBUG - 2020-12-05 08:35:56 --> UTF-8 Support Enabled
INFO - 2020-12-05 08:35:56 --> Utf8 Class Initialized
INFO - 2020-12-05 08:35:56 --> URI Class Initialized
INFO - 2020-12-05 08:35:57 --> Router Class Initialized
INFO - 2020-12-05 08:35:57 --> Output Class Initialized
INFO - 2020-12-05 08:35:57 --> Security Class Initialized
DEBUG - 2020-12-05 08:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 08:35:57 --> Input Class Initialized
INFO - 2020-12-05 08:35:57 --> Language Class Initialized
INFO - 2020-12-05 08:35:57 --> Language Class Initialized
INFO - 2020-12-05 08:35:57 --> Config Class Initialized
INFO - 2020-12-05 08:35:57 --> Loader Class Initialized
INFO - 2020-12-05 08:35:57 --> Helper loaded: url_helper
INFO - 2020-12-05 08:35:57 --> Helper loaded: file_helper
INFO - 2020-12-05 08:35:57 --> Helper loaded: form_helper
INFO - 2020-12-05 08:35:57 --> Helper loaded: my_helper
INFO - 2020-12-05 08:35:57 --> Database Driver Class Initialized
DEBUG - 2020-12-05 08:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 08:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 08:35:57 --> Controller Class Initialized
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:57 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:35:58 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
DEBUG - 2020-12-05 08:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 08:35:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 08:35:58 --> Final output sent to browser
DEBUG - 2020-12-05 08:35:58 --> Total execution time: 1.5096
INFO - 2020-12-05 08:36:39 --> Config Class Initialized
INFO - 2020-12-05 08:36:39 --> Hooks Class Initialized
DEBUG - 2020-12-05 08:36:39 --> UTF-8 Support Enabled
INFO - 2020-12-05 08:36:39 --> Utf8 Class Initialized
INFO - 2020-12-05 08:36:39 --> URI Class Initialized
INFO - 2020-12-05 08:36:39 --> Router Class Initialized
INFO - 2020-12-05 08:36:39 --> Output Class Initialized
INFO - 2020-12-05 08:36:39 --> Security Class Initialized
DEBUG - 2020-12-05 08:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 08:36:39 --> Input Class Initialized
INFO - 2020-12-05 08:36:39 --> Language Class Initialized
INFO - 2020-12-05 08:36:39 --> Language Class Initialized
INFO - 2020-12-05 08:36:39 --> Config Class Initialized
INFO - 2020-12-05 08:36:39 --> Loader Class Initialized
INFO - 2020-12-05 08:36:39 --> Helper loaded: url_helper
INFO - 2020-12-05 08:36:39 --> Helper loaded: file_helper
INFO - 2020-12-05 08:36:39 --> Helper loaded: form_helper
INFO - 2020-12-05 08:36:39 --> Helper loaded: my_helper
INFO - 2020-12-05 08:36:39 --> Database Driver Class Initialized
DEBUG - 2020-12-05 08:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 08:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 08:36:39 --> Controller Class Initialized
ERROR - 2020-12-05 08:36:39 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:36:39 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:36:39 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:36:39 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:36:39 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
DEBUG - 2020-12-05 08:36:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 08:36:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 08:36:39 --> Final output sent to browser
DEBUG - 2020-12-05 08:36:40 --> Total execution time: 0.2749
INFO - 2020-12-05 08:37:00 --> Config Class Initialized
INFO - 2020-12-05 08:37:00 --> Hooks Class Initialized
DEBUG - 2020-12-05 08:37:00 --> UTF-8 Support Enabled
INFO - 2020-12-05 08:37:00 --> Utf8 Class Initialized
INFO - 2020-12-05 08:37:00 --> URI Class Initialized
INFO - 2020-12-05 08:37:00 --> Router Class Initialized
INFO - 2020-12-05 08:37:00 --> Output Class Initialized
INFO - 2020-12-05 08:37:00 --> Security Class Initialized
DEBUG - 2020-12-05 08:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 08:37:00 --> Input Class Initialized
INFO - 2020-12-05 08:37:00 --> Language Class Initialized
INFO - 2020-12-05 08:37:00 --> Language Class Initialized
INFO - 2020-12-05 08:37:00 --> Config Class Initialized
INFO - 2020-12-05 08:37:00 --> Loader Class Initialized
INFO - 2020-12-05 08:37:00 --> Helper loaded: url_helper
INFO - 2020-12-05 08:37:00 --> Helper loaded: file_helper
INFO - 2020-12-05 08:37:00 --> Helper loaded: form_helper
INFO - 2020-12-05 08:37:00 --> Helper loaded: my_helper
INFO - 2020-12-05 08:37:00 --> Database Driver Class Initialized
DEBUG - 2020-12-05 08:37:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 08:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 08:37:00 --> Controller Class Initialized
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:00 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:01 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 51
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 52
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 53
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 54
ERROR - 2020-12-05 08:37:02 --> Severity: Notice --> Undefined variable: gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 55
DEBUG - 2020-12-05 08:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 08:37:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 08:37:02 --> Final output sent to browser
DEBUG - 2020-12-05 08:37:02 --> Total execution time: 1.8593
INFO - 2020-12-05 08:37:22 --> Config Class Initialized
INFO - 2020-12-05 08:37:22 --> Hooks Class Initialized
DEBUG - 2020-12-05 08:37:22 --> UTF-8 Support Enabled
INFO - 2020-12-05 08:37:22 --> Utf8 Class Initialized
INFO - 2020-12-05 08:37:22 --> URI Class Initialized
INFO - 2020-12-05 08:37:22 --> Router Class Initialized
INFO - 2020-12-05 08:37:22 --> Output Class Initialized
INFO - 2020-12-05 08:37:22 --> Security Class Initialized
DEBUG - 2020-12-05 08:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 08:37:22 --> Input Class Initialized
INFO - 2020-12-05 08:37:22 --> Language Class Initialized
INFO - 2020-12-05 08:37:22 --> Language Class Initialized
INFO - 2020-12-05 08:37:22 --> Config Class Initialized
INFO - 2020-12-05 08:37:22 --> Loader Class Initialized
INFO - 2020-12-05 08:37:22 --> Helper loaded: url_helper
INFO - 2020-12-05 08:37:22 --> Helper loaded: file_helper
INFO - 2020-12-05 08:37:22 --> Helper loaded: form_helper
INFO - 2020-12-05 08:37:22 --> Helper loaded: my_helper
INFO - 2020-12-05 08:37:22 --> Database Driver Class Initialized
DEBUG - 2020-12-05 08:37:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 08:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 08:37:22 --> Controller Class Initialized
DEBUG - 2020-12-05 08:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 08:37:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 08:37:22 --> Final output sent to browser
DEBUG - 2020-12-05 08:37:22 --> Total execution time: 0.0411
INFO - 2020-12-05 08:38:56 --> Config Class Initialized
INFO - 2020-12-05 08:38:56 --> Hooks Class Initialized
DEBUG - 2020-12-05 08:38:56 --> UTF-8 Support Enabled
INFO - 2020-12-05 08:38:56 --> Utf8 Class Initialized
INFO - 2020-12-05 08:38:56 --> URI Class Initialized
INFO - 2020-12-05 08:38:56 --> Router Class Initialized
INFO - 2020-12-05 08:38:56 --> Output Class Initialized
INFO - 2020-12-05 08:38:56 --> Security Class Initialized
DEBUG - 2020-12-05 08:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 08:38:56 --> Input Class Initialized
INFO - 2020-12-05 08:38:56 --> Language Class Initialized
INFO - 2020-12-05 08:38:56 --> Language Class Initialized
INFO - 2020-12-05 08:38:56 --> Config Class Initialized
INFO - 2020-12-05 08:38:56 --> Loader Class Initialized
INFO - 2020-12-05 08:38:56 --> Helper loaded: url_helper
INFO - 2020-12-05 08:38:56 --> Helper loaded: file_helper
INFO - 2020-12-05 08:38:56 --> Helper loaded: form_helper
INFO - 2020-12-05 08:38:56 --> Helper loaded: my_helper
INFO - 2020-12-05 08:38:56 --> Database Driver Class Initialized
DEBUG - 2020-12-05 08:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 08:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 08:38:56 --> Controller Class Initialized
DEBUG - 2020-12-05 08:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 08:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 08:38:57 --> Final output sent to browser
DEBUG - 2020-12-05 08:38:57 --> Total execution time: 0.6643
INFO - 2020-12-05 08:39:33 --> Config Class Initialized
INFO - 2020-12-05 08:39:33 --> Hooks Class Initialized
DEBUG - 2020-12-05 08:39:33 --> UTF-8 Support Enabled
INFO - 2020-12-05 08:39:33 --> Utf8 Class Initialized
INFO - 2020-12-05 08:39:33 --> URI Class Initialized
INFO - 2020-12-05 08:39:33 --> Router Class Initialized
INFO - 2020-12-05 08:39:33 --> Output Class Initialized
INFO - 2020-12-05 08:39:33 --> Security Class Initialized
DEBUG - 2020-12-05 08:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-05 08:39:33 --> Input Class Initialized
INFO - 2020-12-05 08:39:33 --> Language Class Initialized
INFO - 2020-12-05 08:39:33 --> Language Class Initialized
INFO - 2020-12-05 08:39:33 --> Config Class Initialized
INFO - 2020-12-05 08:39:33 --> Loader Class Initialized
INFO - 2020-12-05 08:39:33 --> Helper loaded: url_helper
INFO - 2020-12-05 08:39:33 --> Helper loaded: file_helper
INFO - 2020-12-05 08:39:33 --> Helper loaded: form_helper
INFO - 2020-12-05 08:39:33 --> Helper loaded: my_helper
INFO - 2020-12-05 08:39:33 --> Database Driver Class Initialized
DEBUG - 2020-12-05 08:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-05 08:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-05 08:39:33 --> Controller Class Initialized
DEBUG - 2020-12-05 08:39:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-05 08:39:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-05 08:39:33 --> Final output sent to browser
DEBUG - 2020-12-05 08:39:33 --> Total execution time: 0.2725
