<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-15 02:24:23 --> Config Class Initialized
INFO - 2020-10-15 02:24:23 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:24:24 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:24:24 --> Utf8 Class Initialized
INFO - 2020-10-15 02:24:24 --> URI Class Initialized
DEBUG - 2020-10-15 02:24:24 --> No URI present. Default controller set.
INFO - 2020-10-15 02:24:24 --> Router Class Initialized
INFO - 2020-10-15 02:24:24 --> Output Class Initialized
INFO - 2020-10-15 02:24:24 --> Security Class Initialized
DEBUG - 2020-10-15 02:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:24:24 --> Input Class Initialized
INFO - 2020-10-15 02:24:24 --> Language Class Initialized
INFO - 2020-10-15 02:24:25 --> Language Class Initialized
INFO - 2020-10-15 02:24:25 --> Config Class Initialized
INFO - 2020-10-15 02:24:25 --> Loader Class Initialized
INFO - 2020-10-15 02:24:25 --> Helper loaded: url_helper
INFO - 2020-10-15 02:24:25 --> Helper loaded: file_helper
INFO - 2020-10-15 02:24:25 --> Helper loaded: form_helper
INFO - 2020-10-15 02:24:25 --> Helper loaded: my_helper
INFO - 2020-10-15 02:24:25 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:24:26 --> Controller Class Initialized
INFO - 2020-10-15 02:24:26 --> Config Class Initialized
INFO - 2020-10-15 02:24:26 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:24:26 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:24:26 --> Utf8 Class Initialized
INFO - 2020-10-15 02:24:26 --> URI Class Initialized
INFO - 2020-10-15 02:24:26 --> Router Class Initialized
INFO - 2020-10-15 02:24:26 --> Output Class Initialized
INFO - 2020-10-15 02:24:26 --> Security Class Initialized
DEBUG - 2020-10-15 02:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:24:26 --> Input Class Initialized
INFO - 2020-10-15 02:24:26 --> Language Class Initialized
INFO - 2020-10-15 02:24:26 --> Language Class Initialized
INFO - 2020-10-15 02:24:26 --> Config Class Initialized
INFO - 2020-10-15 02:24:26 --> Loader Class Initialized
INFO - 2020-10-15 02:24:26 --> Helper loaded: url_helper
INFO - 2020-10-15 02:24:26 --> Helper loaded: file_helper
INFO - 2020-10-15 02:24:26 --> Helper loaded: form_helper
INFO - 2020-10-15 02:24:26 --> Helper loaded: my_helper
INFO - 2020-10-15 02:24:26 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:24:26 --> Controller Class Initialized
DEBUG - 2020-10-15 02:24:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 02:24:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 02:24:27 --> Final output sent to browser
DEBUG - 2020-10-15 02:24:27 --> Total execution time: 0.7797
INFO - 2020-10-15 02:24:38 --> Config Class Initialized
INFO - 2020-10-15 02:24:38 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:24:38 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:24:38 --> Utf8 Class Initialized
INFO - 2020-10-15 02:24:38 --> URI Class Initialized
INFO - 2020-10-15 02:24:38 --> Router Class Initialized
INFO - 2020-10-15 02:24:39 --> Output Class Initialized
INFO - 2020-10-15 02:24:39 --> Security Class Initialized
DEBUG - 2020-10-15 02:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:24:39 --> Input Class Initialized
INFO - 2020-10-15 02:24:39 --> Language Class Initialized
INFO - 2020-10-15 02:24:39 --> Language Class Initialized
INFO - 2020-10-15 02:24:39 --> Config Class Initialized
INFO - 2020-10-15 02:24:39 --> Loader Class Initialized
INFO - 2020-10-15 02:24:39 --> Helper loaded: url_helper
INFO - 2020-10-15 02:24:39 --> Helper loaded: file_helper
INFO - 2020-10-15 02:24:39 --> Helper loaded: form_helper
INFO - 2020-10-15 02:24:39 --> Helper loaded: my_helper
INFO - 2020-10-15 02:24:39 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:24:39 --> Controller Class Initialized
INFO - 2020-10-15 02:24:39 --> Helper loaded: cookie_helper
INFO - 2020-10-15 02:24:39 --> Final output sent to browser
DEBUG - 2020-10-15 02:24:39 --> Total execution time: 0.8029
INFO - 2020-10-15 02:24:41 --> Config Class Initialized
INFO - 2020-10-15 02:24:41 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:24:41 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:24:41 --> Utf8 Class Initialized
INFO - 2020-10-15 02:24:41 --> URI Class Initialized
INFO - 2020-10-15 02:24:41 --> Router Class Initialized
INFO - 2020-10-15 02:24:41 --> Output Class Initialized
INFO - 2020-10-15 02:24:41 --> Security Class Initialized
DEBUG - 2020-10-15 02:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:24:41 --> Input Class Initialized
INFO - 2020-10-15 02:24:41 --> Language Class Initialized
INFO - 2020-10-15 02:24:41 --> Language Class Initialized
INFO - 2020-10-15 02:24:41 --> Config Class Initialized
INFO - 2020-10-15 02:24:41 --> Loader Class Initialized
INFO - 2020-10-15 02:24:41 --> Helper loaded: url_helper
INFO - 2020-10-15 02:24:41 --> Helper loaded: file_helper
INFO - 2020-10-15 02:24:41 --> Helper loaded: form_helper
INFO - 2020-10-15 02:24:41 --> Helper loaded: my_helper
INFO - 2020-10-15 02:24:41 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:24:41 --> Controller Class Initialized
DEBUG - 2020-10-15 02:24:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 02:24:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 02:24:41 --> Final output sent to browser
DEBUG - 2020-10-15 02:24:41 --> Total execution time: 0.6776
INFO - 2020-10-15 02:39:01 --> Config Class Initialized
INFO - 2020-10-15 02:39:01 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:39:01 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:39:01 --> Utf8 Class Initialized
INFO - 2020-10-15 02:39:01 --> URI Class Initialized
INFO - 2020-10-15 02:39:01 --> Router Class Initialized
INFO - 2020-10-15 02:39:01 --> Output Class Initialized
INFO - 2020-10-15 02:39:01 --> Security Class Initialized
DEBUG - 2020-10-15 02:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:39:02 --> Input Class Initialized
INFO - 2020-10-15 02:39:02 --> Language Class Initialized
INFO - 2020-10-15 02:39:02 --> Language Class Initialized
INFO - 2020-10-15 02:39:02 --> Config Class Initialized
INFO - 2020-10-15 02:39:02 --> Loader Class Initialized
INFO - 2020-10-15 02:39:02 --> Helper loaded: url_helper
INFO - 2020-10-15 02:39:02 --> Helper loaded: file_helper
INFO - 2020-10-15 02:39:02 --> Helper loaded: form_helper
INFO - 2020-10-15 02:39:02 --> Helper loaded: my_helper
INFO - 2020-10-15 02:39:02 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:39:02 --> Controller Class Initialized
DEBUG - 2020-10-15 02:39:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-15 02:39:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 02:39:02 --> Final output sent to browser
DEBUG - 2020-10-15 02:39:02 --> Total execution time: 0.8870
INFO - 2020-10-15 02:39:05 --> Config Class Initialized
INFO - 2020-10-15 02:39:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:39:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:39:05 --> Utf8 Class Initialized
INFO - 2020-10-15 02:39:05 --> URI Class Initialized
INFO - 2020-10-15 02:39:05 --> Router Class Initialized
INFO - 2020-10-15 02:39:05 --> Output Class Initialized
INFO - 2020-10-15 02:39:05 --> Security Class Initialized
DEBUG - 2020-10-15 02:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:39:05 --> Input Class Initialized
INFO - 2020-10-15 02:39:05 --> Language Class Initialized
INFO - 2020-10-15 02:39:05 --> Language Class Initialized
INFO - 2020-10-15 02:39:05 --> Config Class Initialized
INFO - 2020-10-15 02:39:05 --> Loader Class Initialized
INFO - 2020-10-15 02:39:05 --> Helper loaded: url_helper
INFO - 2020-10-15 02:39:05 --> Helper loaded: file_helper
INFO - 2020-10-15 02:39:05 --> Helper loaded: form_helper
INFO - 2020-10-15 02:39:05 --> Helper loaded: my_helper
INFO - 2020-10-15 02:39:05 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:39:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:39:05 --> Controller Class Initialized
DEBUG - 2020-10-15 02:39:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-15 02:39:06 --> Final output sent to browser
DEBUG - 2020-10-15 02:39:06 --> Total execution time: 0.8481
INFO - 2020-10-15 02:39:18 --> Config Class Initialized
INFO - 2020-10-15 02:39:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:39:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:39:18 --> Utf8 Class Initialized
INFO - 2020-10-15 02:39:18 --> URI Class Initialized
INFO - 2020-10-15 02:39:18 --> Router Class Initialized
INFO - 2020-10-15 02:39:18 --> Output Class Initialized
INFO - 2020-10-15 02:39:18 --> Security Class Initialized
DEBUG - 2020-10-15 02:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:39:18 --> Input Class Initialized
INFO - 2020-10-15 02:39:18 --> Language Class Initialized
INFO - 2020-10-15 02:39:18 --> Language Class Initialized
INFO - 2020-10-15 02:39:18 --> Config Class Initialized
INFO - 2020-10-15 02:39:18 --> Loader Class Initialized
INFO - 2020-10-15 02:39:18 --> Helper loaded: url_helper
INFO - 2020-10-15 02:39:18 --> Helper loaded: file_helper
INFO - 2020-10-15 02:39:18 --> Helper loaded: form_helper
INFO - 2020-10-15 02:39:18 --> Helper loaded: my_helper
INFO - 2020-10-15 02:39:18 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:39:18 --> Controller Class Initialized
DEBUG - 2020-10-15 02:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-10-15 02:39:18 --> Final output sent to browser
DEBUG - 2020-10-15 02:39:18 --> Total execution time: 0.7105
INFO - 2020-10-15 02:45:05 --> Config Class Initialized
INFO - 2020-10-15 02:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:45:06 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:45:06 --> Utf8 Class Initialized
INFO - 2020-10-15 02:45:06 --> URI Class Initialized
INFO - 2020-10-15 02:45:06 --> Router Class Initialized
INFO - 2020-10-15 02:45:06 --> Output Class Initialized
INFO - 2020-10-15 02:45:06 --> Security Class Initialized
DEBUG - 2020-10-15 02:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:45:06 --> Input Class Initialized
INFO - 2020-10-15 02:45:06 --> Language Class Initialized
INFO - 2020-10-15 02:45:06 --> Language Class Initialized
INFO - 2020-10-15 02:45:06 --> Config Class Initialized
INFO - 2020-10-15 02:45:06 --> Loader Class Initialized
INFO - 2020-10-15 02:45:06 --> Helper loaded: url_helper
INFO - 2020-10-15 02:45:06 --> Helper loaded: file_helper
INFO - 2020-10-15 02:45:06 --> Helper loaded: form_helper
INFO - 2020-10-15 02:45:06 --> Helper loaded: my_helper
INFO - 2020-10-15 02:45:06 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:45:06 --> Controller Class Initialized
DEBUG - 2020-10-15 02:45:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-15 02:45:06 --> Final output sent to browser
DEBUG - 2020-10-15 02:45:06 --> Total execution time: 0.8982
INFO - 2020-10-15 02:45:50 --> Config Class Initialized
INFO - 2020-10-15 02:45:50 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:45:50 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:45:50 --> Utf8 Class Initialized
INFO - 2020-10-15 02:45:50 --> URI Class Initialized
INFO - 2020-10-15 02:45:50 --> Router Class Initialized
INFO - 2020-10-15 02:45:51 --> Output Class Initialized
INFO - 2020-10-15 02:45:51 --> Security Class Initialized
DEBUG - 2020-10-15 02:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:45:51 --> Input Class Initialized
INFO - 2020-10-15 02:45:51 --> Language Class Initialized
INFO - 2020-10-15 02:45:51 --> Language Class Initialized
INFO - 2020-10-15 02:45:51 --> Config Class Initialized
INFO - 2020-10-15 02:45:51 --> Loader Class Initialized
INFO - 2020-10-15 02:45:51 --> Helper loaded: url_helper
INFO - 2020-10-15 02:45:51 --> Helper loaded: file_helper
INFO - 2020-10-15 02:45:51 --> Helper loaded: form_helper
INFO - 2020-10-15 02:45:51 --> Helper loaded: my_helper
INFO - 2020-10-15 02:45:51 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:45:51 --> Controller Class Initialized
DEBUG - 2020-10-15 02:45:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-15 02:45:51 --> Final output sent to browser
DEBUG - 2020-10-15 02:45:51 --> Total execution time: 0.8809
INFO - 2020-10-15 02:47:53 --> Config Class Initialized
INFO - 2020-10-15 02:47:53 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:47:53 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:47:53 --> Utf8 Class Initialized
INFO - 2020-10-15 02:47:53 --> URI Class Initialized
INFO - 2020-10-15 02:47:53 --> Router Class Initialized
INFO - 2020-10-15 02:47:53 --> Output Class Initialized
INFO - 2020-10-15 02:47:53 --> Security Class Initialized
DEBUG - 2020-10-15 02:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:47:54 --> Input Class Initialized
INFO - 2020-10-15 02:47:54 --> Language Class Initialized
INFO - 2020-10-15 02:47:54 --> Language Class Initialized
INFO - 2020-10-15 02:47:54 --> Config Class Initialized
INFO - 2020-10-15 02:47:54 --> Loader Class Initialized
INFO - 2020-10-15 02:47:54 --> Helper loaded: url_helper
INFO - 2020-10-15 02:47:54 --> Helper loaded: file_helper
INFO - 2020-10-15 02:47:54 --> Helper loaded: form_helper
INFO - 2020-10-15 02:47:54 --> Helper loaded: my_helper
INFO - 2020-10-15 02:47:54 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:47:54 --> Controller Class Initialized
DEBUG - 2020-10-15 02:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-15 02:47:54 --> Final output sent to browser
DEBUG - 2020-10-15 02:47:54 --> Total execution time: 0.9192
INFO - 2020-10-15 02:49:52 --> Config Class Initialized
INFO - 2020-10-15 02:49:52 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:49:52 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:49:52 --> Utf8 Class Initialized
INFO - 2020-10-15 02:49:52 --> URI Class Initialized
INFO - 2020-10-15 02:49:52 --> Router Class Initialized
INFO - 2020-10-15 02:49:52 --> Output Class Initialized
INFO - 2020-10-15 02:49:52 --> Security Class Initialized
DEBUG - 2020-10-15 02:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:49:52 --> Input Class Initialized
INFO - 2020-10-15 02:49:52 --> Language Class Initialized
INFO - 2020-10-15 02:49:52 --> Language Class Initialized
INFO - 2020-10-15 02:49:52 --> Config Class Initialized
INFO - 2020-10-15 02:49:52 --> Loader Class Initialized
INFO - 2020-10-15 02:49:53 --> Helper loaded: url_helper
INFO - 2020-10-15 02:49:53 --> Helper loaded: file_helper
INFO - 2020-10-15 02:49:53 --> Helper loaded: form_helper
INFO - 2020-10-15 02:49:53 --> Helper loaded: my_helper
INFO - 2020-10-15 02:49:53 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:49:53 --> Controller Class Initialized
DEBUG - 2020-10-15 02:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-15 02:49:53 --> Final output sent to browser
DEBUG - 2020-10-15 02:49:53 --> Total execution time: 0.6786
INFO - 2020-10-15 02:50:00 --> Config Class Initialized
INFO - 2020-10-15 02:50:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:50:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:50:00 --> Utf8 Class Initialized
INFO - 2020-10-15 02:50:00 --> URI Class Initialized
INFO - 2020-10-15 02:50:00 --> Router Class Initialized
INFO - 2020-10-15 02:50:00 --> Output Class Initialized
INFO - 2020-10-15 02:50:00 --> Security Class Initialized
DEBUG - 2020-10-15 02:50:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:50:00 --> Input Class Initialized
INFO - 2020-10-15 02:50:00 --> Language Class Initialized
INFO - 2020-10-15 02:50:00 --> Language Class Initialized
INFO - 2020-10-15 02:50:00 --> Config Class Initialized
INFO - 2020-10-15 02:50:00 --> Loader Class Initialized
INFO - 2020-10-15 02:50:00 --> Helper loaded: url_helper
INFO - 2020-10-15 02:50:00 --> Helper loaded: file_helper
INFO - 2020-10-15 02:50:00 --> Helper loaded: form_helper
INFO - 2020-10-15 02:50:00 --> Helper loaded: my_helper
INFO - 2020-10-15 02:50:00 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:50:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:50:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:50:00 --> Controller Class Initialized
DEBUG - 2020-10-15 02:50:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-10-15 02:50:00 --> Final output sent to browser
DEBUG - 2020-10-15 02:50:00 --> Total execution time: 0.7085
INFO - 2020-10-15 02:50:11 --> Config Class Initialized
INFO - 2020-10-15 02:50:11 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:50:11 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:50:11 --> Utf8 Class Initialized
INFO - 2020-10-15 02:50:11 --> URI Class Initialized
INFO - 2020-10-15 02:50:11 --> Router Class Initialized
INFO - 2020-10-15 02:50:11 --> Output Class Initialized
INFO - 2020-10-15 02:50:11 --> Security Class Initialized
DEBUG - 2020-10-15 02:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:50:11 --> Input Class Initialized
INFO - 2020-10-15 02:50:11 --> Language Class Initialized
INFO - 2020-10-15 02:50:11 --> Language Class Initialized
INFO - 2020-10-15 02:50:11 --> Config Class Initialized
INFO - 2020-10-15 02:50:11 --> Loader Class Initialized
INFO - 2020-10-15 02:50:11 --> Helper loaded: url_helper
INFO - 2020-10-15 02:50:11 --> Helper loaded: file_helper
INFO - 2020-10-15 02:50:11 --> Helper loaded: form_helper
INFO - 2020-10-15 02:50:11 --> Helper loaded: my_helper
INFO - 2020-10-15 02:50:11 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:50:12 --> Controller Class Initialized
DEBUG - 2020-10-15 02:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-10-15 02:50:12 --> Final output sent to browser
DEBUG - 2020-10-15 02:50:12 --> Total execution time: 0.5492
INFO - 2020-10-15 02:50:12 --> Config Class Initialized
INFO - 2020-10-15 02:50:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:50:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:50:12 --> Utf8 Class Initialized
INFO - 2020-10-15 02:50:12 --> URI Class Initialized
INFO - 2020-10-15 02:50:12 --> Router Class Initialized
INFO - 2020-10-15 02:50:12 --> Output Class Initialized
INFO - 2020-10-15 02:50:12 --> Security Class Initialized
DEBUG - 2020-10-15 02:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:50:12 --> Input Class Initialized
INFO - 2020-10-15 02:50:12 --> Language Class Initialized
INFO - 2020-10-15 02:50:12 --> Language Class Initialized
INFO - 2020-10-15 02:50:12 --> Config Class Initialized
INFO - 2020-10-15 02:50:12 --> Loader Class Initialized
INFO - 2020-10-15 02:50:12 --> Helper loaded: url_helper
INFO - 2020-10-15 02:50:12 --> Helper loaded: file_helper
INFO - 2020-10-15 02:50:12 --> Helper loaded: form_helper
INFO - 2020-10-15 02:50:12 --> Helper loaded: my_helper
INFO - 2020-10-15 02:50:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:50:12 --> Controller Class Initialized
DEBUG - 2020-10-15 02:50:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-10-15 02:50:12 --> Final output sent to browser
DEBUG - 2020-10-15 02:50:12 --> Total execution time: 0.8163
INFO - 2020-10-15 02:50:29 --> Config Class Initialized
INFO - 2020-10-15 02:50:29 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:50:29 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:50:29 --> Utf8 Class Initialized
INFO - 2020-10-15 02:50:29 --> URI Class Initialized
INFO - 2020-10-15 02:50:29 --> Router Class Initialized
INFO - 2020-10-15 02:50:29 --> Output Class Initialized
INFO - 2020-10-15 02:50:29 --> Security Class Initialized
DEBUG - 2020-10-15 02:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:50:29 --> Input Class Initialized
INFO - 2020-10-15 02:50:29 --> Language Class Initialized
INFO - 2020-10-15 02:50:29 --> Language Class Initialized
INFO - 2020-10-15 02:50:29 --> Config Class Initialized
INFO - 2020-10-15 02:50:29 --> Loader Class Initialized
INFO - 2020-10-15 02:50:29 --> Helper loaded: url_helper
INFO - 2020-10-15 02:50:29 --> Helper loaded: file_helper
INFO - 2020-10-15 02:50:29 --> Helper loaded: form_helper
INFO - 2020-10-15 02:50:30 --> Helper loaded: my_helper
INFO - 2020-10-15 02:50:30 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:50:30 --> Controller Class Initialized
DEBUG - 2020-10-15 02:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-10-15 02:50:30 --> Final output sent to browser
DEBUG - 2020-10-15 02:50:30 --> Total execution time: 0.7203
INFO - 2020-10-15 02:56:19 --> Config Class Initialized
INFO - 2020-10-15 02:56:19 --> Hooks Class Initialized
DEBUG - 2020-10-15 02:56:19 --> UTF-8 Support Enabled
INFO - 2020-10-15 02:56:19 --> Utf8 Class Initialized
INFO - 2020-10-15 02:56:19 --> URI Class Initialized
DEBUG - 2020-10-15 02:56:19 --> No URI present. Default controller set.
INFO - 2020-10-15 02:56:19 --> Router Class Initialized
INFO - 2020-10-15 02:56:19 --> Output Class Initialized
INFO - 2020-10-15 02:56:19 --> Security Class Initialized
DEBUG - 2020-10-15 02:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 02:56:19 --> Input Class Initialized
INFO - 2020-10-15 02:56:19 --> Language Class Initialized
INFO - 2020-10-15 02:56:19 --> Language Class Initialized
INFO - 2020-10-15 02:56:19 --> Config Class Initialized
INFO - 2020-10-15 02:56:19 --> Loader Class Initialized
INFO - 2020-10-15 02:56:19 --> Helper loaded: url_helper
INFO - 2020-10-15 02:56:19 --> Helper loaded: file_helper
INFO - 2020-10-15 02:56:19 --> Helper loaded: form_helper
INFO - 2020-10-15 02:56:19 --> Helper loaded: my_helper
INFO - 2020-10-15 02:56:19 --> Database Driver Class Initialized
DEBUG - 2020-10-15 02:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 02:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 02:56:20 --> Controller Class Initialized
DEBUG - 2020-10-15 02:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 02:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 02:56:20 --> Final output sent to browser
DEBUG - 2020-10-15 02:56:20 --> Total execution time: 0.6183
INFO - 2020-10-15 03:17:36 --> Config Class Initialized
INFO - 2020-10-15 03:17:37 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:17:37 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:17:37 --> Utf8 Class Initialized
INFO - 2020-10-15 03:17:37 --> URI Class Initialized
INFO - 2020-10-15 03:17:37 --> Router Class Initialized
INFO - 2020-10-15 03:17:37 --> Output Class Initialized
INFO - 2020-10-15 03:17:37 --> Security Class Initialized
DEBUG - 2020-10-15 03:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:17:37 --> Input Class Initialized
INFO - 2020-10-15 03:17:37 --> Language Class Initialized
INFO - 2020-10-15 03:17:37 --> Language Class Initialized
INFO - 2020-10-15 03:17:37 --> Config Class Initialized
INFO - 2020-10-15 03:17:37 --> Loader Class Initialized
INFO - 2020-10-15 03:17:37 --> Helper loaded: url_helper
INFO - 2020-10-15 03:17:37 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:17:37 --> Controller Class Initialized
INFO - 2020-10-15 03:17:37 --> Final output sent to browser
DEBUG - 2020-10-15 03:17:37 --> Total execution time: 0.1860
INFO - 2020-10-15 03:17:42 --> Config Class Initialized
INFO - 2020-10-15 03:17:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:17:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:17:42 --> Utf8 Class Initialized
INFO - 2020-10-15 03:17:42 --> URI Class Initialized
INFO - 2020-10-15 03:17:42 --> Router Class Initialized
INFO - 2020-10-15 03:17:42 --> Output Class Initialized
INFO - 2020-10-15 03:17:42 --> Security Class Initialized
DEBUG - 2020-10-15 03:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:17:42 --> Input Class Initialized
INFO - 2020-10-15 03:17:42 --> Language Class Initialized
INFO - 2020-10-15 03:17:42 --> Language Class Initialized
INFO - 2020-10-15 03:17:42 --> Config Class Initialized
INFO - 2020-10-15 03:17:42 --> Loader Class Initialized
INFO - 2020-10-15 03:17:42 --> Helper loaded: url_helper
INFO - 2020-10-15 03:17:42 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:17:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:17:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:17:42 --> Controller Class Initialized
INFO - 2020-10-15 03:17:42 --> Final output sent to browser
DEBUG - 2020-10-15 03:17:42 --> Total execution time: 0.1823
INFO - 2020-10-15 03:17:47 --> Config Class Initialized
INFO - 2020-10-15 03:17:47 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:17:47 --> Utf8 Class Initialized
INFO - 2020-10-15 03:17:47 --> URI Class Initialized
DEBUG - 2020-10-15 03:17:47 --> No URI present. Default controller set.
INFO - 2020-10-15 03:17:47 --> Router Class Initialized
INFO - 2020-10-15 03:17:47 --> Output Class Initialized
INFO - 2020-10-15 03:17:47 --> Security Class Initialized
DEBUG - 2020-10-15 03:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:17:47 --> Input Class Initialized
INFO - 2020-10-15 03:17:47 --> Language Class Initialized
INFO - 2020-10-15 03:17:47 --> Language Class Initialized
INFO - 2020-10-15 03:17:47 --> Config Class Initialized
INFO - 2020-10-15 03:17:47 --> Loader Class Initialized
INFO - 2020-10-15 03:17:47 --> Helper loaded: url_helper
INFO - 2020-10-15 03:17:47 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:17:47 --> Controller Class Initialized
ERROR - 2020-10-15 03:17:47 --> Severity: Error --> Call to undefined function cek_aktif() C:\xampp\htdocs\nilai\application\modules\home\controllers\Home.php 15
INFO - 2020-10-15 03:18:06 --> Config Class Initialized
INFO - 2020-10-15 03:18:06 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:18:06 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:18:06 --> Utf8 Class Initialized
INFO - 2020-10-15 03:18:06 --> URI Class Initialized
DEBUG - 2020-10-15 03:18:06 --> No URI present. Default controller set.
INFO - 2020-10-15 03:18:06 --> Router Class Initialized
INFO - 2020-10-15 03:18:06 --> Output Class Initialized
INFO - 2020-10-15 03:18:06 --> Security Class Initialized
DEBUG - 2020-10-15 03:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:18:06 --> Input Class Initialized
INFO - 2020-10-15 03:18:06 --> Language Class Initialized
INFO - 2020-10-15 03:18:06 --> Language Class Initialized
INFO - 2020-10-15 03:18:06 --> Config Class Initialized
INFO - 2020-10-15 03:18:06 --> Loader Class Initialized
INFO - 2020-10-15 03:18:06 --> Helper loaded: url_helper
INFO - 2020-10-15 03:18:06 --> Helper loaded: file_helper
INFO - 2020-10-15 03:18:06 --> Helper loaded: form_helper
INFO - 2020-10-15 03:18:06 --> Helper loaded: my_helper
INFO - 2020-10-15 03:18:06 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:18:06 --> Controller Class Initialized
DEBUG - 2020-10-15 03:18:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:18:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:18:06 --> Final output sent to browser
DEBUG - 2020-10-15 03:18:06 --> Total execution time: 0.2546
INFO - 2020-10-15 03:19:11 --> Config Class Initialized
INFO - 2020-10-15 03:19:11 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:11 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:11 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:11 --> URI Class Initialized
INFO - 2020-10-15 03:19:11 --> Router Class Initialized
INFO - 2020-10-15 03:19:11 --> Output Class Initialized
INFO - 2020-10-15 03:19:11 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:11 --> Input Class Initialized
INFO - 2020-10-15 03:19:11 --> Language Class Initialized
INFO - 2020-10-15 03:19:11 --> Language Class Initialized
INFO - 2020-10-15 03:19:11 --> Config Class Initialized
INFO - 2020-10-15 03:19:11 --> Loader Class Initialized
INFO - 2020-10-15 03:19:11 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:11 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:11 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:12 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:12 --> Controller Class Initialized
INFO - 2020-10-15 03:19:12 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:19:12 --> Config Class Initialized
INFO - 2020-10-15 03:19:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:12 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:12 --> URI Class Initialized
INFO - 2020-10-15 03:19:12 --> Router Class Initialized
INFO - 2020-10-15 03:19:12 --> Output Class Initialized
INFO - 2020-10-15 03:19:12 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:12 --> Input Class Initialized
INFO - 2020-10-15 03:19:12 --> Language Class Initialized
INFO - 2020-10-15 03:19:12 --> Language Class Initialized
INFO - 2020-10-15 03:19:12 --> Config Class Initialized
INFO - 2020-10-15 03:19:12 --> Loader Class Initialized
INFO - 2020-10-15 03:19:12 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:12 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:12 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:12 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:12 --> Controller Class Initialized
DEBUG - 2020-10-15 03:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:19:12 --> Final output sent to browser
DEBUG - 2020-10-15 03:19:12 --> Total execution time: 0.2222
INFO - 2020-10-15 03:19:14 --> Config Class Initialized
INFO - 2020-10-15 03:19:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:14 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:14 --> URI Class Initialized
INFO - 2020-10-15 03:19:14 --> Router Class Initialized
INFO - 2020-10-15 03:19:14 --> Output Class Initialized
INFO - 2020-10-15 03:19:14 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:14 --> Input Class Initialized
INFO - 2020-10-15 03:19:14 --> Language Class Initialized
INFO - 2020-10-15 03:19:14 --> Language Class Initialized
INFO - 2020-10-15 03:19:14 --> Config Class Initialized
INFO - 2020-10-15 03:19:14 --> Loader Class Initialized
INFO - 2020-10-15 03:19:14 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:14 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:14 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:14 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:14 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:14 --> Controller Class Initialized
INFO - 2020-10-15 03:19:14 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:19:14 --> Config Class Initialized
INFO - 2020-10-15 03:19:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:14 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:14 --> URI Class Initialized
INFO - 2020-10-15 03:19:14 --> Router Class Initialized
INFO - 2020-10-15 03:19:14 --> Output Class Initialized
INFO - 2020-10-15 03:19:14 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:14 --> Input Class Initialized
INFO - 2020-10-15 03:19:14 --> Language Class Initialized
INFO - 2020-10-15 03:19:14 --> Language Class Initialized
INFO - 2020-10-15 03:19:14 --> Config Class Initialized
INFO - 2020-10-15 03:19:14 --> Loader Class Initialized
INFO - 2020-10-15 03:19:14 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:14 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:14 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:14 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:14 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:15 --> Controller Class Initialized
DEBUG - 2020-10-15 03:19:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:19:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:19:15 --> Final output sent to browser
DEBUG - 2020-10-15 03:19:15 --> Total execution time: 0.2400
INFO - 2020-10-15 03:19:36 --> Config Class Initialized
INFO - 2020-10-15 03:19:36 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:36 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:36 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:36 --> URI Class Initialized
INFO - 2020-10-15 03:19:36 --> Router Class Initialized
INFO - 2020-10-15 03:19:36 --> Output Class Initialized
INFO - 2020-10-15 03:19:36 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:36 --> Input Class Initialized
INFO - 2020-10-15 03:19:36 --> Language Class Initialized
INFO - 2020-10-15 03:19:36 --> Language Class Initialized
INFO - 2020-10-15 03:19:36 --> Config Class Initialized
INFO - 2020-10-15 03:19:36 --> Loader Class Initialized
INFO - 2020-10-15 03:19:36 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:36 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:36 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:36 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:36 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:36 --> Controller Class Initialized
INFO - 2020-10-15 03:19:36 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:19:36 --> Config Class Initialized
INFO - 2020-10-15 03:19:36 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:36 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:36 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:36 --> URI Class Initialized
INFO - 2020-10-15 03:19:36 --> Router Class Initialized
INFO - 2020-10-15 03:19:36 --> Output Class Initialized
INFO - 2020-10-15 03:19:36 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:36 --> Input Class Initialized
INFO - 2020-10-15 03:19:36 --> Language Class Initialized
INFO - 2020-10-15 03:19:36 --> Language Class Initialized
INFO - 2020-10-15 03:19:36 --> Config Class Initialized
INFO - 2020-10-15 03:19:36 --> Loader Class Initialized
INFO - 2020-10-15 03:19:36 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:36 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:36 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:36 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:36 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:36 --> Controller Class Initialized
DEBUG - 2020-10-15 03:19:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:19:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:19:36 --> Final output sent to browser
DEBUG - 2020-10-15 03:19:36 --> Total execution time: 0.2406
INFO - 2020-10-15 03:19:39 --> Config Class Initialized
INFO - 2020-10-15 03:19:39 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:39 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:39 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:39 --> URI Class Initialized
INFO - 2020-10-15 03:19:39 --> Router Class Initialized
INFO - 2020-10-15 03:19:39 --> Output Class Initialized
INFO - 2020-10-15 03:19:39 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:39 --> Input Class Initialized
INFO - 2020-10-15 03:19:39 --> Language Class Initialized
INFO - 2020-10-15 03:19:39 --> Language Class Initialized
INFO - 2020-10-15 03:19:39 --> Config Class Initialized
INFO - 2020-10-15 03:19:39 --> Loader Class Initialized
INFO - 2020-10-15 03:19:39 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:39 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:39 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:39 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:39 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:39 --> Controller Class Initialized
INFO - 2020-10-15 03:19:39 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:19:39 --> Config Class Initialized
INFO - 2020-10-15 03:19:39 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:19:39 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:19:39 --> Utf8 Class Initialized
INFO - 2020-10-15 03:19:39 --> URI Class Initialized
INFO - 2020-10-15 03:19:39 --> Router Class Initialized
INFO - 2020-10-15 03:19:39 --> Output Class Initialized
INFO - 2020-10-15 03:19:39 --> Security Class Initialized
DEBUG - 2020-10-15 03:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:19:39 --> Input Class Initialized
INFO - 2020-10-15 03:19:39 --> Language Class Initialized
INFO - 2020-10-15 03:19:39 --> Language Class Initialized
INFO - 2020-10-15 03:19:39 --> Config Class Initialized
INFO - 2020-10-15 03:19:39 --> Loader Class Initialized
INFO - 2020-10-15 03:19:40 --> Helper loaded: url_helper
INFO - 2020-10-15 03:19:40 --> Helper loaded: file_helper
INFO - 2020-10-15 03:19:40 --> Helper loaded: form_helper
INFO - 2020-10-15 03:19:40 --> Helper loaded: my_helper
INFO - 2020-10-15 03:19:40 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:19:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:19:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:19:40 --> Controller Class Initialized
DEBUG - 2020-10-15 03:19:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:19:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:19:40 --> Final output sent to browser
DEBUG - 2020-10-15 03:19:40 --> Total execution time: 0.2254
INFO - 2020-10-15 03:20:02 --> Config Class Initialized
INFO - 2020-10-15 03:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:20:02 --> Utf8 Class Initialized
INFO - 2020-10-15 03:20:02 --> URI Class Initialized
INFO - 2020-10-15 03:20:02 --> Router Class Initialized
INFO - 2020-10-15 03:20:03 --> Output Class Initialized
INFO - 2020-10-15 03:20:03 --> Security Class Initialized
DEBUG - 2020-10-15 03:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:20:03 --> Input Class Initialized
INFO - 2020-10-15 03:20:03 --> Language Class Initialized
INFO - 2020-10-15 03:20:03 --> Language Class Initialized
INFO - 2020-10-15 03:20:03 --> Config Class Initialized
INFO - 2020-10-15 03:20:03 --> Loader Class Initialized
INFO - 2020-10-15 03:20:03 --> Helper loaded: url_helper
INFO - 2020-10-15 03:20:03 --> Helper loaded: file_helper
INFO - 2020-10-15 03:20:03 --> Helper loaded: form_helper
INFO - 2020-10-15 03:20:03 --> Helper loaded: my_helper
INFO - 2020-10-15 03:20:03 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:20:03 --> Controller Class Initialized
DEBUG - 2020-10-15 03:20:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:20:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:20:03 --> Final output sent to browser
DEBUG - 2020-10-15 03:20:03 --> Total execution time: 0.2491
INFO - 2020-10-15 03:20:04 --> Config Class Initialized
INFO - 2020-10-15 03:20:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:20:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:20:04 --> Utf8 Class Initialized
INFO - 2020-10-15 03:20:04 --> URI Class Initialized
INFO - 2020-10-15 03:20:04 --> Router Class Initialized
INFO - 2020-10-15 03:20:04 --> Output Class Initialized
INFO - 2020-10-15 03:20:04 --> Security Class Initialized
DEBUG - 2020-10-15 03:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:20:04 --> Input Class Initialized
INFO - 2020-10-15 03:20:04 --> Language Class Initialized
INFO - 2020-10-15 03:20:04 --> Language Class Initialized
INFO - 2020-10-15 03:20:04 --> Config Class Initialized
INFO - 2020-10-15 03:20:04 --> Loader Class Initialized
INFO - 2020-10-15 03:20:04 --> Helper loaded: url_helper
INFO - 2020-10-15 03:20:04 --> Helper loaded: file_helper
INFO - 2020-10-15 03:20:04 --> Helper loaded: form_helper
INFO - 2020-10-15 03:20:04 --> Helper loaded: my_helper
INFO - 2020-10-15 03:20:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:20:04 --> Controller Class Initialized
INFO - 2020-10-15 03:20:04 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:20:04 --> Config Class Initialized
INFO - 2020-10-15 03:20:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:20:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:20:04 --> Utf8 Class Initialized
INFO - 2020-10-15 03:20:04 --> URI Class Initialized
INFO - 2020-10-15 03:20:04 --> Router Class Initialized
INFO - 2020-10-15 03:20:04 --> Output Class Initialized
INFO - 2020-10-15 03:20:04 --> Security Class Initialized
DEBUG - 2020-10-15 03:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:20:04 --> Input Class Initialized
INFO - 2020-10-15 03:20:04 --> Language Class Initialized
INFO - 2020-10-15 03:20:04 --> Language Class Initialized
INFO - 2020-10-15 03:20:04 --> Config Class Initialized
INFO - 2020-10-15 03:20:04 --> Loader Class Initialized
INFO - 2020-10-15 03:20:04 --> Helper loaded: url_helper
INFO - 2020-10-15 03:20:04 --> Helper loaded: file_helper
INFO - 2020-10-15 03:20:04 --> Helper loaded: form_helper
INFO - 2020-10-15 03:20:04 --> Helper loaded: my_helper
INFO - 2020-10-15 03:20:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:20:04 --> Controller Class Initialized
DEBUG - 2020-10-15 03:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:20:04 --> Final output sent to browser
DEBUG - 2020-10-15 03:20:04 --> Total execution time: 0.2265
INFO - 2020-10-15 03:20:06 --> Config Class Initialized
INFO - 2020-10-15 03:20:06 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:20:06 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:20:06 --> Utf8 Class Initialized
INFO - 2020-10-15 03:20:06 --> URI Class Initialized
INFO - 2020-10-15 03:20:06 --> Router Class Initialized
INFO - 2020-10-15 03:20:06 --> Output Class Initialized
INFO - 2020-10-15 03:20:06 --> Security Class Initialized
DEBUG - 2020-10-15 03:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:20:06 --> Input Class Initialized
INFO - 2020-10-15 03:20:06 --> Language Class Initialized
INFO - 2020-10-15 03:20:06 --> Language Class Initialized
INFO - 2020-10-15 03:20:06 --> Config Class Initialized
INFO - 2020-10-15 03:20:06 --> Loader Class Initialized
INFO - 2020-10-15 03:20:06 --> Helper loaded: url_helper
INFO - 2020-10-15 03:20:06 --> Helper loaded: file_helper
INFO - 2020-10-15 03:20:06 --> Helper loaded: form_helper
INFO - 2020-10-15 03:20:06 --> Helper loaded: my_helper
INFO - 2020-10-15 03:20:06 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:20:06 --> Controller Class Initialized
INFO - 2020-10-15 03:20:06 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:20:06 --> Config Class Initialized
INFO - 2020-10-15 03:20:06 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:20:06 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:20:06 --> Utf8 Class Initialized
INFO - 2020-10-15 03:20:06 --> URI Class Initialized
INFO - 2020-10-15 03:20:06 --> Router Class Initialized
INFO - 2020-10-15 03:20:06 --> Output Class Initialized
INFO - 2020-10-15 03:20:06 --> Security Class Initialized
DEBUG - 2020-10-15 03:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:20:06 --> Input Class Initialized
INFO - 2020-10-15 03:20:06 --> Language Class Initialized
INFO - 2020-10-15 03:20:06 --> Language Class Initialized
INFO - 2020-10-15 03:20:06 --> Config Class Initialized
INFO - 2020-10-15 03:20:06 --> Loader Class Initialized
INFO - 2020-10-15 03:20:06 --> Helper loaded: url_helper
INFO - 2020-10-15 03:20:06 --> Helper loaded: file_helper
INFO - 2020-10-15 03:20:06 --> Helper loaded: form_helper
INFO - 2020-10-15 03:20:06 --> Helper loaded: my_helper
INFO - 2020-10-15 03:20:06 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:20:06 --> Controller Class Initialized
DEBUG - 2020-10-15 03:20:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:20:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:20:06 --> Final output sent to browser
DEBUG - 2020-10-15 03:20:06 --> Total execution time: 0.2454
INFO - 2020-10-15 03:22:09 --> Config Class Initialized
INFO - 2020-10-15 03:22:09 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:09 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:09 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:09 --> URI Class Initialized
INFO - 2020-10-15 03:22:09 --> Router Class Initialized
INFO - 2020-10-15 03:22:09 --> Output Class Initialized
INFO - 2020-10-15 03:22:09 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:09 --> Input Class Initialized
INFO - 2020-10-15 03:22:09 --> Language Class Initialized
INFO - 2020-10-15 03:22:09 --> Language Class Initialized
INFO - 2020-10-15 03:22:09 --> Config Class Initialized
INFO - 2020-10-15 03:22:09 --> Loader Class Initialized
INFO - 2020-10-15 03:22:09 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:09 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:09 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:09 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:09 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:09 --> Controller Class Initialized
INFO - 2020-10-15 03:22:43 --> Config Class Initialized
INFO - 2020-10-15 03:22:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:43 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:43 --> URI Class Initialized
INFO - 2020-10-15 03:22:43 --> Router Class Initialized
INFO - 2020-10-15 03:22:43 --> Output Class Initialized
INFO - 2020-10-15 03:22:43 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:43 --> Input Class Initialized
INFO - 2020-10-15 03:22:43 --> Language Class Initialized
INFO - 2020-10-15 03:22:43 --> Language Class Initialized
INFO - 2020-10-15 03:22:43 --> Config Class Initialized
INFO - 2020-10-15 03:22:43 --> Loader Class Initialized
INFO - 2020-10-15 03:22:43 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:43 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:43 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:43 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:43 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:43 --> Controller Class Initialized
INFO - 2020-10-15 03:22:45 --> Config Class Initialized
INFO - 2020-10-15 03:22:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:45 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:45 --> URI Class Initialized
INFO - 2020-10-15 03:22:45 --> Router Class Initialized
INFO - 2020-10-15 03:22:45 --> Output Class Initialized
INFO - 2020-10-15 03:22:45 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:45 --> Input Class Initialized
INFO - 2020-10-15 03:22:45 --> Language Class Initialized
INFO - 2020-10-15 03:22:45 --> Language Class Initialized
INFO - 2020-10-15 03:22:45 --> Config Class Initialized
INFO - 2020-10-15 03:22:45 --> Loader Class Initialized
INFO - 2020-10-15 03:22:45 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:45 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:45 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:45 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:45 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:45 --> Controller Class Initialized
DEBUG - 2020-10-15 03:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:22:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:22:45 --> Final output sent to browser
DEBUG - 2020-10-15 03:22:45 --> Total execution time: 0.2346
INFO - 2020-10-15 03:22:46 --> Config Class Initialized
INFO - 2020-10-15 03:22:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:46 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:46 --> URI Class Initialized
INFO - 2020-10-15 03:22:46 --> Router Class Initialized
INFO - 2020-10-15 03:22:46 --> Output Class Initialized
INFO - 2020-10-15 03:22:46 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:46 --> Input Class Initialized
INFO - 2020-10-15 03:22:46 --> Language Class Initialized
INFO - 2020-10-15 03:22:46 --> Language Class Initialized
INFO - 2020-10-15 03:22:46 --> Config Class Initialized
INFO - 2020-10-15 03:22:46 --> Loader Class Initialized
INFO - 2020-10-15 03:22:46 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:46 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:46 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:46 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:46 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:46 --> Controller Class Initialized
DEBUG - 2020-10-15 03:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:22:46 --> Final output sent to browser
DEBUG - 2020-10-15 03:22:46 --> Total execution time: 0.2311
INFO - 2020-10-15 03:22:47 --> Config Class Initialized
INFO - 2020-10-15 03:22:47 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:47 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:47 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:47 --> URI Class Initialized
INFO - 2020-10-15 03:22:47 --> Router Class Initialized
INFO - 2020-10-15 03:22:47 --> Output Class Initialized
INFO - 2020-10-15 03:22:47 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:47 --> Input Class Initialized
INFO - 2020-10-15 03:22:47 --> Language Class Initialized
INFO - 2020-10-15 03:22:47 --> Language Class Initialized
INFO - 2020-10-15 03:22:47 --> Config Class Initialized
INFO - 2020-10-15 03:22:47 --> Loader Class Initialized
INFO - 2020-10-15 03:22:47 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:47 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:48 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:48 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:48 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:48 --> Controller Class Initialized
INFO - 2020-10-15 03:22:57 --> Config Class Initialized
INFO - 2020-10-15 03:22:57 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:57 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:57 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:57 --> URI Class Initialized
INFO - 2020-10-15 03:22:57 --> Router Class Initialized
INFO - 2020-10-15 03:22:57 --> Output Class Initialized
INFO - 2020-10-15 03:22:57 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:57 --> Input Class Initialized
INFO - 2020-10-15 03:22:57 --> Language Class Initialized
INFO - 2020-10-15 03:22:57 --> Language Class Initialized
INFO - 2020-10-15 03:22:57 --> Config Class Initialized
INFO - 2020-10-15 03:22:57 --> Loader Class Initialized
INFO - 2020-10-15 03:22:57 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:57 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:57 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:57 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:57 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:57 --> Controller Class Initialized
INFO - 2020-10-15 03:22:58 --> Config Class Initialized
INFO - 2020-10-15 03:22:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:58 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:58 --> URI Class Initialized
INFO - 2020-10-15 03:22:58 --> Router Class Initialized
INFO - 2020-10-15 03:22:58 --> Output Class Initialized
INFO - 2020-10-15 03:22:58 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:58 --> Input Class Initialized
INFO - 2020-10-15 03:22:58 --> Language Class Initialized
INFO - 2020-10-15 03:22:58 --> Language Class Initialized
INFO - 2020-10-15 03:22:58 --> Config Class Initialized
INFO - 2020-10-15 03:22:58 --> Loader Class Initialized
INFO - 2020-10-15 03:22:58 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:58 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:58 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:58 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:58 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:58 --> Controller Class Initialized
INFO - 2020-10-15 03:22:58 --> Config Class Initialized
INFO - 2020-10-15 03:22:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:58 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:58 --> URI Class Initialized
INFO - 2020-10-15 03:22:58 --> Router Class Initialized
INFO - 2020-10-15 03:22:58 --> Output Class Initialized
INFO - 2020-10-15 03:22:58 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:58 --> Input Class Initialized
INFO - 2020-10-15 03:22:58 --> Language Class Initialized
INFO - 2020-10-15 03:22:58 --> Language Class Initialized
INFO - 2020-10-15 03:22:58 --> Config Class Initialized
INFO - 2020-10-15 03:22:58 --> Loader Class Initialized
INFO - 2020-10-15 03:22:58 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:58 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:58 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:58 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:58 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:58 --> Controller Class Initialized
DEBUG - 2020-10-15 03:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:22:58 --> Final output sent to browser
DEBUG - 2020-10-15 03:22:58 --> Total execution time: 0.2769
INFO - 2020-10-15 03:22:59 --> Config Class Initialized
INFO - 2020-10-15 03:22:59 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:22:59 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:22:59 --> Utf8 Class Initialized
INFO - 2020-10-15 03:22:59 --> URI Class Initialized
INFO - 2020-10-15 03:22:59 --> Router Class Initialized
INFO - 2020-10-15 03:22:59 --> Output Class Initialized
INFO - 2020-10-15 03:22:59 --> Security Class Initialized
DEBUG - 2020-10-15 03:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:22:59 --> Input Class Initialized
INFO - 2020-10-15 03:22:59 --> Language Class Initialized
INFO - 2020-10-15 03:22:59 --> Language Class Initialized
INFO - 2020-10-15 03:22:59 --> Config Class Initialized
INFO - 2020-10-15 03:22:59 --> Loader Class Initialized
INFO - 2020-10-15 03:22:59 --> Helper loaded: url_helper
INFO - 2020-10-15 03:22:59 --> Helper loaded: file_helper
INFO - 2020-10-15 03:22:59 --> Helper loaded: form_helper
INFO - 2020-10-15 03:22:59 --> Helper loaded: my_helper
INFO - 2020-10-15 03:22:59 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:22:59 --> Controller Class Initialized
DEBUG - 2020-10-15 03:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:22:59 --> Final output sent to browser
DEBUG - 2020-10-15 03:22:59 --> Total execution time: 0.2479
INFO - 2020-10-15 03:23:00 --> Config Class Initialized
INFO - 2020-10-15 03:23:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:23:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:23:00 --> Utf8 Class Initialized
INFO - 2020-10-15 03:23:00 --> URI Class Initialized
INFO - 2020-10-15 03:23:00 --> Router Class Initialized
INFO - 2020-10-15 03:23:01 --> Output Class Initialized
INFO - 2020-10-15 03:23:01 --> Security Class Initialized
DEBUG - 2020-10-15 03:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:23:01 --> Input Class Initialized
INFO - 2020-10-15 03:23:01 --> Language Class Initialized
INFO - 2020-10-15 03:23:01 --> Language Class Initialized
INFO - 2020-10-15 03:23:01 --> Config Class Initialized
INFO - 2020-10-15 03:23:01 --> Loader Class Initialized
INFO - 2020-10-15 03:23:01 --> Helper loaded: url_helper
INFO - 2020-10-15 03:23:01 --> Helper loaded: file_helper
INFO - 2020-10-15 03:23:01 --> Helper loaded: form_helper
INFO - 2020-10-15 03:23:01 --> Helper loaded: my_helper
INFO - 2020-10-15 03:23:01 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:23:01 --> Controller Class Initialized
INFO - 2020-10-15 03:23:13 --> Config Class Initialized
INFO - 2020-10-15 03:23:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:23:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:23:13 --> Utf8 Class Initialized
INFO - 2020-10-15 03:23:13 --> URI Class Initialized
DEBUG - 2020-10-15 03:23:13 --> No URI present. Default controller set.
INFO - 2020-10-15 03:23:13 --> Router Class Initialized
INFO - 2020-10-15 03:23:13 --> Output Class Initialized
INFO - 2020-10-15 03:23:13 --> Security Class Initialized
DEBUG - 2020-10-15 03:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:23:13 --> Input Class Initialized
INFO - 2020-10-15 03:23:13 --> Language Class Initialized
INFO - 2020-10-15 03:23:13 --> Language Class Initialized
INFO - 2020-10-15 03:23:13 --> Config Class Initialized
INFO - 2020-10-15 03:23:13 --> Loader Class Initialized
INFO - 2020-10-15 03:23:13 --> Helper loaded: url_helper
INFO - 2020-10-15 03:23:13 --> Helper loaded: file_helper
INFO - 2020-10-15 03:23:13 --> Helper loaded: form_helper
INFO - 2020-10-15 03:23:13 --> Helper loaded: my_helper
INFO - 2020-10-15 03:23:13 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:23:13 --> Controller Class Initialized
DEBUG - 2020-10-15 03:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:23:13 --> Final output sent to browser
DEBUG - 2020-10-15 03:23:13 --> Total execution time: 0.2808
INFO - 2020-10-15 03:23:15 --> Config Class Initialized
INFO - 2020-10-15 03:23:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:23:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:23:15 --> Utf8 Class Initialized
INFO - 2020-10-15 03:23:15 --> URI Class Initialized
INFO - 2020-10-15 03:23:15 --> Router Class Initialized
INFO - 2020-10-15 03:23:15 --> Output Class Initialized
INFO - 2020-10-15 03:23:15 --> Security Class Initialized
DEBUG - 2020-10-15 03:23:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:23:15 --> Input Class Initialized
INFO - 2020-10-15 03:23:15 --> Language Class Initialized
INFO - 2020-10-15 03:23:15 --> Language Class Initialized
INFO - 2020-10-15 03:23:15 --> Config Class Initialized
INFO - 2020-10-15 03:23:15 --> Loader Class Initialized
INFO - 2020-10-15 03:23:15 --> Helper loaded: url_helper
INFO - 2020-10-15 03:23:15 --> Helper loaded: file_helper
INFO - 2020-10-15 03:23:15 --> Helper loaded: form_helper
INFO - 2020-10-15 03:23:15 --> Helper loaded: my_helper
INFO - 2020-10-15 03:23:15 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:23:15 --> Controller Class Initialized
INFO - 2020-10-15 03:23:41 --> Config Class Initialized
INFO - 2020-10-15 03:23:41 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:23:41 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:23:41 --> Utf8 Class Initialized
INFO - 2020-10-15 03:23:41 --> URI Class Initialized
INFO - 2020-10-15 03:23:41 --> Router Class Initialized
INFO - 2020-10-15 03:23:41 --> Output Class Initialized
INFO - 2020-10-15 03:23:41 --> Security Class Initialized
DEBUG - 2020-10-15 03:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:23:41 --> Input Class Initialized
INFO - 2020-10-15 03:23:41 --> Language Class Initialized
INFO - 2020-10-15 03:23:41 --> Language Class Initialized
INFO - 2020-10-15 03:23:41 --> Config Class Initialized
INFO - 2020-10-15 03:23:41 --> Loader Class Initialized
INFO - 2020-10-15 03:23:41 --> Helper loaded: url_helper
INFO - 2020-10-15 03:23:41 --> Helper loaded: file_helper
INFO - 2020-10-15 03:23:42 --> Helper loaded: form_helper
INFO - 2020-10-15 03:23:42 --> Helper loaded: my_helper
INFO - 2020-10-15 03:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:23:42 --> Controller Class Initialized
INFO - 2020-10-15 03:23:42 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:23:42 --> Config Class Initialized
INFO - 2020-10-15 03:23:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:23:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:23:42 --> Utf8 Class Initialized
INFO - 2020-10-15 03:23:42 --> URI Class Initialized
INFO - 2020-10-15 03:23:42 --> Router Class Initialized
INFO - 2020-10-15 03:23:42 --> Output Class Initialized
INFO - 2020-10-15 03:23:42 --> Security Class Initialized
DEBUG - 2020-10-15 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:23:42 --> Input Class Initialized
INFO - 2020-10-15 03:23:42 --> Language Class Initialized
INFO - 2020-10-15 03:23:42 --> Language Class Initialized
INFO - 2020-10-15 03:23:42 --> Config Class Initialized
INFO - 2020-10-15 03:23:42 --> Loader Class Initialized
INFO - 2020-10-15 03:23:42 --> Helper loaded: url_helper
INFO - 2020-10-15 03:23:42 --> Helper loaded: file_helper
INFO - 2020-10-15 03:23:42 --> Helper loaded: form_helper
INFO - 2020-10-15 03:23:42 --> Helper loaded: my_helper
INFO - 2020-10-15 03:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:23:42 --> Controller Class Initialized
DEBUG - 2020-10-15 03:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:23:42 --> Final output sent to browser
DEBUG - 2020-10-15 03:23:42 --> Total execution time: 0.2424
INFO - 2020-10-15 03:23:43 --> Config Class Initialized
INFO - 2020-10-15 03:23:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:23:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:23:43 --> Utf8 Class Initialized
INFO - 2020-10-15 03:23:43 --> URI Class Initialized
INFO - 2020-10-15 03:23:43 --> Router Class Initialized
INFO - 2020-10-15 03:23:43 --> Output Class Initialized
INFO - 2020-10-15 03:23:43 --> Security Class Initialized
DEBUG - 2020-10-15 03:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:23:43 --> Input Class Initialized
INFO - 2020-10-15 03:23:43 --> Language Class Initialized
INFO - 2020-10-15 03:23:43 --> Language Class Initialized
INFO - 2020-10-15 03:23:44 --> Config Class Initialized
INFO - 2020-10-15 03:23:44 --> Loader Class Initialized
INFO - 2020-10-15 03:23:44 --> Helper loaded: url_helper
INFO - 2020-10-15 03:23:44 --> Helper loaded: file_helper
INFO - 2020-10-15 03:23:44 --> Helper loaded: form_helper
INFO - 2020-10-15 03:23:44 --> Helper loaded: my_helper
INFO - 2020-10-15 03:23:44 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:23:44 --> Controller Class Initialized
INFO - 2020-10-15 03:23:44 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:23:44 --> Config Class Initialized
INFO - 2020-10-15 03:23:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:23:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:23:44 --> Utf8 Class Initialized
INFO - 2020-10-15 03:23:44 --> URI Class Initialized
INFO - 2020-10-15 03:23:44 --> Router Class Initialized
INFO - 2020-10-15 03:23:44 --> Output Class Initialized
INFO - 2020-10-15 03:23:44 --> Security Class Initialized
DEBUG - 2020-10-15 03:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:23:44 --> Input Class Initialized
INFO - 2020-10-15 03:23:44 --> Language Class Initialized
INFO - 2020-10-15 03:23:44 --> Language Class Initialized
INFO - 2020-10-15 03:23:44 --> Config Class Initialized
INFO - 2020-10-15 03:23:44 --> Loader Class Initialized
INFO - 2020-10-15 03:23:44 --> Helper loaded: url_helper
INFO - 2020-10-15 03:23:44 --> Helper loaded: file_helper
INFO - 2020-10-15 03:23:44 --> Helper loaded: form_helper
INFO - 2020-10-15 03:23:44 --> Helper loaded: my_helper
INFO - 2020-10-15 03:23:44 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:23:44 --> Controller Class Initialized
DEBUG - 2020-10-15 03:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:23:44 --> Final output sent to browser
DEBUG - 2020-10-15 03:23:44 --> Total execution time: 0.2503
INFO - 2020-10-15 03:24:42 --> Config Class Initialized
INFO - 2020-10-15 03:24:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:24:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:24:42 --> Utf8 Class Initialized
INFO - 2020-10-15 03:24:42 --> URI Class Initialized
INFO - 2020-10-15 03:24:42 --> Router Class Initialized
INFO - 2020-10-15 03:24:42 --> Output Class Initialized
INFO - 2020-10-15 03:24:42 --> Security Class Initialized
DEBUG - 2020-10-15 03:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:24:42 --> Input Class Initialized
INFO - 2020-10-15 03:24:42 --> Language Class Initialized
INFO - 2020-10-15 03:24:42 --> Language Class Initialized
INFO - 2020-10-15 03:24:42 --> Config Class Initialized
INFO - 2020-10-15 03:24:42 --> Loader Class Initialized
INFO - 2020-10-15 03:24:42 --> Helper loaded: url_helper
INFO - 2020-10-15 03:24:42 --> Helper loaded: file_helper
INFO - 2020-10-15 03:24:42 --> Helper loaded: form_helper
INFO - 2020-10-15 03:24:42 --> Helper loaded: my_helper
INFO - 2020-10-15 03:24:42 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:24:42 --> Controller Class Initialized
DEBUG - 2020-10-15 03:24:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:24:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:24:42 --> Final output sent to browser
DEBUG - 2020-10-15 03:24:42 --> Total execution time: 0.2562
INFO - 2020-10-15 03:24:44 --> Config Class Initialized
INFO - 2020-10-15 03:24:44 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:24:44 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:24:44 --> Utf8 Class Initialized
INFO - 2020-10-15 03:24:44 --> URI Class Initialized
INFO - 2020-10-15 03:24:44 --> Router Class Initialized
INFO - 2020-10-15 03:24:44 --> Output Class Initialized
INFO - 2020-10-15 03:24:44 --> Security Class Initialized
DEBUG - 2020-10-15 03:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:24:44 --> Input Class Initialized
INFO - 2020-10-15 03:24:44 --> Language Class Initialized
INFO - 2020-10-15 03:24:44 --> Language Class Initialized
INFO - 2020-10-15 03:24:44 --> Config Class Initialized
INFO - 2020-10-15 03:24:44 --> Loader Class Initialized
INFO - 2020-10-15 03:24:44 --> Helper loaded: url_helper
INFO - 2020-10-15 03:24:44 --> Helper loaded: file_helper
INFO - 2020-10-15 03:24:44 --> Helper loaded: form_helper
INFO - 2020-10-15 03:24:44 --> Helper loaded: my_helper
INFO - 2020-10-15 03:24:44 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:24:44 --> Controller Class Initialized
INFO - 2020-10-15 03:24:44 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:25:15 --> Config Class Initialized
INFO - 2020-10-15 03:25:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:25:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:25:15 --> Utf8 Class Initialized
INFO - 2020-10-15 03:25:15 --> URI Class Initialized
INFO - 2020-10-15 03:25:15 --> Router Class Initialized
INFO - 2020-10-15 03:25:15 --> Output Class Initialized
INFO - 2020-10-15 03:25:15 --> Security Class Initialized
DEBUG - 2020-10-15 03:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:25:15 --> Input Class Initialized
INFO - 2020-10-15 03:25:15 --> Language Class Initialized
INFO - 2020-10-15 03:25:15 --> Language Class Initialized
INFO - 2020-10-15 03:25:15 --> Config Class Initialized
INFO - 2020-10-15 03:25:15 --> Loader Class Initialized
INFO - 2020-10-15 03:25:15 --> Helper loaded: url_helper
INFO - 2020-10-15 03:25:15 --> Helper loaded: file_helper
INFO - 2020-10-15 03:25:15 --> Helper loaded: form_helper
INFO - 2020-10-15 03:25:15 --> Helper loaded: my_helper
INFO - 2020-10-15 03:25:15 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:25:15 --> Controller Class Initialized
INFO - 2020-10-15 03:25:15 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:26:37 --> Config Class Initialized
INFO - 2020-10-15 03:26:37 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:26:37 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:26:37 --> Utf8 Class Initialized
INFO - 2020-10-15 03:26:37 --> URI Class Initialized
INFO - 2020-10-15 03:26:37 --> Router Class Initialized
INFO - 2020-10-15 03:26:37 --> Output Class Initialized
INFO - 2020-10-15 03:26:37 --> Security Class Initialized
DEBUG - 2020-10-15 03:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:26:37 --> Input Class Initialized
INFO - 2020-10-15 03:26:37 --> Language Class Initialized
INFO - 2020-10-15 03:26:37 --> Language Class Initialized
INFO - 2020-10-15 03:26:37 --> Config Class Initialized
INFO - 2020-10-15 03:26:37 --> Loader Class Initialized
INFO - 2020-10-15 03:26:37 --> Helper loaded: url_helper
INFO - 2020-10-15 03:26:37 --> Helper loaded: file_helper
INFO - 2020-10-15 03:26:37 --> Helper loaded: form_helper
INFO - 2020-10-15 03:26:37 --> Helper loaded: my_helper
INFO - 2020-10-15 03:26:37 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:26:37 --> Controller Class Initialized
INFO - 2020-10-15 03:26:37 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:27:17 --> Config Class Initialized
INFO - 2020-10-15 03:27:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:27:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:27:17 --> Utf8 Class Initialized
INFO - 2020-10-15 03:27:17 --> URI Class Initialized
INFO - 2020-10-15 03:27:17 --> Router Class Initialized
INFO - 2020-10-15 03:27:17 --> Output Class Initialized
INFO - 2020-10-15 03:27:17 --> Security Class Initialized
DEBUG - 2020-10-15 03:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:27:17 --> Input Class Initialized
INFO - 2020-10-15 03:27:17 --> Language Class Initialized
INFO - 2020-10-15 03:27:17 --> Language Class Initialized
INFO - 2020-10-15 03:27:17 --> Config Class Initialized
INFO - 2020-10-15 03:27:17 --> Loader Class Initialized
INFO - 2020-10-15 03:27:17 --> Helper loaded: url_helper
INFO - 2020-10-15 03:27:17 --> Helper loaded: file_helper
INFO - 2020-10-15 03:27:17 --> Helper loaded: form_helper
INFO - 2020-10-15 03:27:17 --> Helper loaded: my_helper
INFO - 2020-10-15 03:27:17 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:27:17 --> Controller Class Initialized
INFO - 2020-10-15 03:27:17 --> Helper loaded: cookie_helper
ERROR - 2020-10-15 03:27:17 --> Severity: Error --> Call to undefined method CI_Session::logout() C:\xampp\htdocs\nilai\application\modules\login\controllers\Login.php 108
INFO - 2020-10-15 03:27:58 --> Config Class Initialized
INFO - 2020-10-15 03:27:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:27:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:27:58 --> Utf8 Class Initialized
INFO - 2020-10-15 03:27:58 --> URI Class Initialized
INFO - 2020-10-15 03:27:58 --> Router Class Initialized
INFO - 2020-10-15 03:27:58 --> Output Class Initialized
INFO - 2020-10-15 03:27:58 --> Security Class Initialized
DEBUG - 2020-10-15 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:27:58 --> Input Class Initialized
INFO - 2020-10-15 03:27:58 --> Language Class Initialized
INFO - 2020-10-15 03:27:58 --> Language Class Initialized
INFO - 2020-10-15 03:27:58 --> Config Class Initialized
INFO - 2020-10-15 03:27:58 --> Loader Class Initialized
INFO - 2020-10-15 03:27:58 --> Helper loaded: url_helper
INFO - 2020-10-15 03:27:58 --> Helper loaded: file_helper
INFO - 2020-10-15 03:27:58 --> Helper loaded: form_helper
INFO - 2020-10-15 03:27:58 --> Helper loaded: my_helper
INFO - 2020-10-15 03:27:58 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:27:58 --> Controller Class Initialized
INFO - 2020-10-15 03:27:58 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:27:58 --> Config Class Initialized
INFO - 2020-10-15 03:27:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:27:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:27:58 --> Utf8 Class Initialized
INFO - 2020-10-15 03:27:58 --> URI Class Initialized
INFO - 2020-10-15 03:27:58 --> Router Class Initialized
INFO - 2020-10-15 03:27:58 --> Output Class Initialized
INFO - 2020-10-15 03:27:58 --> Security Class Initialized
DEBUG - 2020-10-15 03:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:27:58 --> Input Class Initialized
INFO - 2020-10-15 03:27:58 --> Language Class Initialized
INFO - 2020-10-15 03:27:58 --> Language Class Initialized
INFO - 2020-10-15 03:27:58 --> Config Class Initialized
INFO - 2020-10-15 03:27:58 --> Loader Class Initialized
INFO - 2020-10-15 03:27:58 --> Helper loaded: url_helper
INFO - 2020-10-15 03:27:58 --> Helper loaded: file_helper
INFO - 2020-10-15 03:27:58 --> Helper loaded: form_helper
INFO - 2020-10-15 03:27:58 --> Helper loaded: my_helper
INFO - 2020-10-15 03:27:58 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:27:58 --> Controller Class Initialized
DEBUG - 2020-10-15 03:27:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:27:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:27:58 --> Final output sent to browser
DEBUG - 2020-10-15 03:27:58 --> Total execution time: 0.2387
INFO - 2020-10-15 03:28:00 --> Config Class Initialized
INFO - 2020-10-15 03:28:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:00 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:00 --> URI Class Initialized
INFO - 2020-10-15 03:28:00 --> Router Class Initialized
INFO - 2020-10-15 03:28:00 --> Output Class Initialized
INFO - 2020-10-15 03:28:00 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:00 --> Input Class Initialized
INFO - 2020-10-15 03:28:00 --> Language Class Initialized
INFO - 2020-10-15 03:28:00 --> Language Class Initialized
INFO - 2020-10-15 03:28:00 --> Config Class Initialized
INFO - 2020-10-15 03:28:00 --> Loader Class Initialized
INFO - 2020-10-15 03:28:00 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:00 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:00 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:00 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:00 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:01 --> Controller Class Initialized
INFO - 2020-10-15 03:28:01 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:28:01 --> Config Class Initialized
INFO - 2020-10-15 03:28:01 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:01 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:01 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:01 --> URI Class Initialized
INFO - 2020-10-15 03:28:01 --> Router Class Initialized
INFO - 2020-10-15 03:28:01 --> Output Class Initialized
INFO - 2020-10-15 03:28:01 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:01 --> Input Class Initialized
INFO - 2020-10-15 03:28:01 --> Language Class Initialized
INFO - 2020-10-15 03:28:01 --> Language Class Initialized
INFO - 2020-10-15 03:28:01 --> Config Class Initialized
INFO - 2020-10-15 03:28:01 --> Loader Class Initialized
INFO - 2020-10-15 03:28:01 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:01 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:01 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:01 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:01 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:01 --> Controller Class Initialized
DEBUG - 2020-10-15 03:28:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:28:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:28:01 --> Final output sent to browser
DEBUG - 2020-10-15 03:28:01 --> Total execution time: 0.2438
INFO - 2020-10-15 03:28:03 --> Config Class Initialized
INFO - 2020-10-15 03:28:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:03 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:03 --> URI Class Initialized
INFO - 2020-10-15 03:28:03 --> Router Class Initialized
INFO - 2020-10-15 03:28:03 --> Output Class Initialized
INFO - 2020-10-15 03:28:03 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:04 --> Input Class Initialized
INFO - 2020-10-15 03:28:04 --> Language Class Initialized
INFO - 2020-10-15 03:28:04 --> Language Class Initialized
INFO - 2020-10-15 03:28:04 --> Config Class Initialized
INFO - 2020-10-15 03:28:04 --> Loader Class Initialized
INFO - 2020-10-15 03:28:04 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:04 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:04 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:04 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:04 --> Controller Class Initialized
INFO - 2020-10-15 03:28:04 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:28:04 --> Config Class Initialized
INFO - 2020-10-15 03:28:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:04 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:04 --> URI Class Initialized
INFO - 2020-10-15 03:28:04 --> Router Class Initialized
INFO - 2020-10-15 03:28:04 --> Output Class Initialized
INFO - 2020-10-15 03:28:04 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:04 --> Input Class Initialized
INFO - 2020-10-15 03:28:04 --> Language Class Initialized
INFO - 2020-10-15 03:28:04 --> Language Class Initialized
INFO - 2020-10-15 03:28:04 --> Config Class Initialized
INFO - 2020-10-15 03:28:04 --> Loader Class Initialized
INFO - 2020-10-15 03:28:04 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:04 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:04 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:04 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:04 --> Controller Class Initialized
DEBUG - 2020-10-15 03:28:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:28:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:28:04 --> Final output sent to browser
DEBUG - 2020-10-15 03:28:04 --> Total execution time: 0.2720
INFO - 2020-10-15 03:28:52 --> Config Class Initialized
INFO - 2020-10-15 03:28:52 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:52 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:52 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:52 --> URI Class Initialized
INFO - 2020-10-15 03:28:52 --> Router Class Initialized
INFO - 2020-10-15 03:28:52 --> Output Class Initialized
INFO - 2020-10-15 03:28:52 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:52 --> Input Class Initialized
INFO - 2020-10-15 03:28:52 --> Language Class Initialized
INFO - 2020-10-15 03:28:52 --> Language Class Initialized
INFO - 2020-10-15 03:28:52 --> Config Class Initialized
INFO - 2020-10-15 03:28:52 --> Loader Class Initialized
INFO - 2020-10-15 03:28:52 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:52 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:52 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:52 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:52 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:52 --> Controller Class Initialized
INFO - 2020-10-15 03:28:52 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:28:52 --> Config Class Initialized
INFO - 2020-10-15 03:28:52 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:52 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:52 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:52 --> URI Class Initialized
INFO - 2020-10-15 03:28:52 --> Router Class Initialized
INFO - 2020-10-15 03:28:52 --> Output Class Initialized
INFO - 2020-10-15 03:28:52 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:52 --> Input Class Initialized
INFO - 2020-10-15 03:28:52 --> Language Class Initialized
INFO - 2020-10-15 03:28:52 --> Language Class Initialized
INFO - 2020-10-15 03:28:52 --> Config Class Initialized
INFO - 2020-10-15 03:28:53 --> Loader Class Initialized
INFO - 2020-10-15 03:28:53 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:53 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:53 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:53 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:53 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:53 --> Controller Class Initialized
DEBUG - 2020-10-15 03:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:28:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:28:53 --> Final output sent to browser
DEBUG - 2020-10-15 03:28:53 --> Total execution time: 0.2358
INFO - 2020-10-15 03:28:54 --> Config Class Initialized
INFO - 2020-10-15 03:28:54 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:54 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:54 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:54 --> URI Class Initialized
INFO - 2020-10-15 03:28:54 --> Router Class Initialized
INFO - 2020-10-15 03:28:54 --> Output Class Initialized
INFO - 2020-10-15 03:28:54 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:54 --> Input Class Initialized
INFO - 2020-10-15 03:28:54 --> Language Class Initialized
INFO - 2020-10-15 03:28:54 --> Language Class Initialized
INFO - 2020-10-15 03:28:54 --> Config Class Initialized
INFO - 2020-10-15 03:28:54 --> Loader Class Initialized
INFO - 2020-10-15 03:28:54 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:54 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:54 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:54 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:54 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:54 --> Controller Class Initialized
DEBUG - 2020-10-15 03:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:28:54 --> Final output sent to browser
DEBUG - 2020-10-15 03:28:54 --> Total execution time: 0.3039
INFO - 2020-10-15 03:28:55 --> Config Class Initialized
INFO - 2020-10-15 03:28:55 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:55 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:55 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:55 --> URI Class Initialized
INFO - 2020-10-15 03:28:55 --> Router Class Initialized
INFO - 2020-10-15 03:28:55 --> Output Class Initialized
INFO - 2020-10-15 03:28:55 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:55 --> Input Class Initialized
INFO - 2020-10-15 03:28:55 --> Language Class Initialized
INFO - 2020-10-15 03:28:55 --> Language Class Initialized
INFO - 2020-10-15 03:28:55 --> Config Class Initialized
INFO - 2020-10-15 03:28:55 --> Loader Class Initialized
INFO - 2020-10-15 03:28:55 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:55 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:55 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:55 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:55 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:55 --> Controller Class Initialized
INFO - 2020-10-15 03:28:55 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:28:55 --> Config Class Initialized
INFO - 2020-10-15 03:28:55 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:28:55 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:28:55 --> Utf8 Class Initialized
INFO - 2020-10-15 03:28:55 --> URI Class Initialized
INFO - 2020-10-15 03:28:55 --> Router Class Initialized
INFO - 2020-10-15 03:28:55 --> Output Class Initialized
INFO - 2020-10-15 03:28:55 --> Security Class Initialized
DEBUG - 2020-10-15 03:28:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:28:55 --> Input Class Initialized
INFO - 2020-10-15 03:28:55 --> Language Class Initialized
INFO - 2020-10-15 03:28:55 --> Language Class Initialized
INFO - 2020-10-15 03:28:55 --> Config Class Initialized
INFO - 2020-10-15 03:28:55 --> Loader Class Initialized
INFO - 2020-10-15 03:28:55 --> Helper loaded: url_helper
INFO - 2020-10-15 03:28:55 --> Helper loaded: file_helper
INFO - 2020-10-15 03:28:55 --> Helper loaded: form_helper
INFO - 2020-10-15 03:28:55 --> Helper loaded: my_helper
INFO - 2020-10-15 03:28:55 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:28:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:28:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:28:55 --> Controller Class Initialized
DEBUG - 2020-10-15 03:28:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:28:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:28:56 --> Final output sent to browser
DEBUG - 2020-10-15 03:28:56 --> Total execution time: 0.2645
INFO - 2020-10-15 03:29:07 --> Config Class Initialized
INFO - 2020-10-15 03:29:07 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:07 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:07 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:07 --> URI Class Initialized
INFO - 2020-10-15 03:29:08 --> Router Class Initialized
INFO - 2020-10-15 03:29:08 --> Output Class Initialized
INFO - 2020-10-15 03:29:08 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:08 --> Input Class Initialized
INFO - 2020-10-15 03:29:08 --> Language Class Initialized
INFO - 2020-10-15 03:29:08 --> Language Class Initialized
INFO - 2020-10-15 03:29:08 --> Config Class Initialized
INFO - 2020-10-15 03:29:08 --> Loader Class Initialized
INFO - 2020-10-15 03:29:08 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:08 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:08 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:08 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:08 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:08 --> Controller Class Initialized
DEBUG - 2020-10-15 03:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:29:08 --> Final output sent to browser
DEBUG - 2020-10-15 03:29:08 --> Total execution time: 0.3391
INFO - 2020-10-15 03:29:09 --> Config Class Initialized
INFO - 2020-10-15 03:29:09 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:09 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:09 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:09 --> URI Class Initialized
INFO - 2020-10-15 03:29:09 --> Router Class Initialized
INFO - 2020-10-15 03:29:09 --> Output Class Initialized
INFO - 2020-10-15 03:29:09 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:09 --> Input Class Initialized
INFO - 2020-10-15 03:29:09 --> Language Class Initialized
INFO - 2020-10-15 03:29:09 --> Language Class Initialized
INFO - 2020-10-15 03:29:09 --> Config Class Initialized
INFO - 2020-10-15 03:29:09 --> Loader Class Initialized
INFO - 2020-10-15 03:29:09 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:09 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:09 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:09 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:09 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:09 --> Controller Class Initialized
INFO - 2020-10-15 03:29:09 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:29:09 --> Config Class Initialized
INFO - 2020-10-15 03:29:09 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:09 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:09 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:09 --> URI Class Initialized
INFO - 2020-10-15 03:29:09 --> Router Class Initialized
INFO - 2020-10-15 03:29:09 --> Output Class Initialized
INFO - 2020-10-15 03:29:09 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:09 --> Input Class Initialized
INFO - 2020-10-15 03:29:09 --> Language Class Initialized
INFO - 2020-10-15 03:29:09 --> Language Class Initialized
INFO - 2020-10-15 03:29:09 --> Config Class Initialized
INFO - 2020-10-15 03:29:09 --> Loader Class Initialized
INFO - 2020-10-15 03:29:09 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:09 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:09 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:09 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:09 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:09 --> Controller Class Initialized
DEBUG - 2020-10-15 03:29:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:29:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:29:09 --> Final output sent to browser
DEBUG - 2020-10-15 03:29:09 --> Total execution time: 0.2584
INFO - 2020-10-15 03:29:11 --> Config Class Initialized
INFO - 2020-10-15 03:29:11 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:11 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:11 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:11 --> URI Class Initialized
INFO - 2020-10-15 03:29:11 --> Router Class Initialized
INFO - 2020-10-15 03:29:11 --> Output Class Initialized
INFO - 2020-10-15 03:29:11 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:11 --> Input Class Initialized
INFO - 2020-10-15 03:29:11 --> Language Class Initialized
INFO - 2020-10-15 03:29:11 --> Language Class Initialized
INFO - 2020-10-15 03:29:11 --> Config Class Initialized
INFO - 2020-10-15 03:29:11 --> Loader Class Initialized
INFO - 2020-10-15 03:29:11 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:11 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:11 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:11 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:11 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:11 --> Controller Class Initialized
INFO - 2020-10-15 03:29:11 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:29:11 --> Config Class Initialized
INFO - 2020-10-15 03:29:11 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:11 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:11 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:11 --> URI Class Initialized
INFO - 2020-10-15 03:29:11 --> Router Class Initialized
INFO - 2020-10-15 03:29:11 --> Output Class Initialized
INFO - 2020-10-15 03:29:11 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:11 --> Input Class Initialized
INFO - 2020-10-15 03:29:11 --> Language Class Initialized
INFO - 2020-10-15 03:29:11 --> Language Class Initialized
INFO - 2020-10-15 03:29:11 --> Config Class Initialized
INFO - 2020-10-15 03:29:11 --> Loader Class Initialized
INFO - 2020-10-15 03:29:11 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:11 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:11 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:11 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:11 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:11 --> Controller Class Initialized
INFO - 2020-10-15 03:29:11 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:29:11 --> Config Class Initialized
INFO - 2020-10-15 03:29:11 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:11 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:11 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:11 --> URI Class Initialized
INFO - 2020-10-15 03:29:11 --> Router Class Initialized
INFO - 2020-10-15 03:29:12 --> Output Class Initialized
INFO - 2020-10-15 03:29:12 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:12 --> Input Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Config Class Initialized
INFO - 2020-10-15 03:29:12 --> Loader Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:12 --> Controller Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:29:12 --> Config Class Initialized
INFO - 2020-10-15 03:29:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:12 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:12 --> URI Class Initialized
INFO - 2020-10-15 03:29:12 --> Router Class Initialized
INFO - 2020-10-15 03:29:12 --> Output Class Initialized
INFO - 2020-10-15 03:29:12 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:12 --> Input Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Config Class Initialized
INFO - 2020-10-15 03:29:12 --> Loader Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:12 --> Controller Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:29:12 --> Config Class Initialized
INFO - 2020-10-15 03:29:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:12 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:12 --> URI Class Initialized
INFO - 2020-10-15 03:29:12 --> Router Class Initialized
INFO - 2020-10-15 03:29:12 --> Output Class Initialized
INFO - 2020-10-15 03:29:12 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:12 --> Input Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Config Class Initialized
INFO - 2020-10-15 03:29:12 --> Loader Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:12 --> Controller Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:29:12 --> Config Class Initialized
INFO - 2020-10-15 03:29:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:12 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:12 --> URI Class Initialized
INFO - 2020-10-15 03:29:12 --> Router Class Initialized
INFO - 2020-10-15 03:29:12 --> Output Class Initialized
INFO - 2020-10-15 03:29:12 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:12 --> Input Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Language Class Initialized
INFO - 2020-10-15 03:29:12 --> Config Class Initialized
INFO - 2020-10-15 03:29:12 --> Loader Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:12 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:12 --> Controller Class Initialized
INFO - 2020-10-15 03:29:12 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:29:13 --> Config Class Initialized
INFO - 2020-10-15 03:29:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:13 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:13 --> URI Class Initialized
INFO - 2020-10-15 03:29:13 --> Router Class Initialized
INFO - 2020-10-15 03:29:13 --> Output Class Initialized
INFO - 2020-10-15 03:29:13 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:13 --> Input Class Initialized
INFO - 2020-10-15 03:29:13 --> Language Class Initialized
INFO - 2020-10-15 03:29:13 --> Language Class Initialized
INFO - 2020-10-15 03:29:13 --> Config Class Initialized
INFO - 2020-10-15 03:29:13 --> Loader Class Initialized
INFO - 2020-10-15 03:29:13 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:13 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:13 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:13 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:13 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:13 --> Controller Class Initialized
DEBUG - 2020-10-15 03:29:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:29:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:29:13 --> Final output sent to browser
DEBUG - 2020-10-15 03:29:13 --> Total execution time: 0.3098
INFO - 2020-10-15 03:29:14 --> Config Class Initialized
INFO - 2020-10-15 03:29:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:14 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:14 --> URI Class Initialized
INFO - 2020-10-15 03:29:14 --> Router Class Initialized
INFO - 2020-10-15 03:29:14 --> Output Class Initialized
INFO - 2020-10-15 03:29:14 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:14 --> Input Class Initialized
INFO - 2020-10-15 03:29:14 --> Language Class Initialized
INFO - 2020-10-15 03:29:14 --> Language Class Initialized
INFO - 2020-10-15 03:29:14 --> Config Class Initialized
INFO - 2020-10-15 03:29:14 --> Loader Class Initialized
INFO - 2020-10-15 03:29:14 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:14 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:14 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:14 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:14 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:14 --> Controller Class Initialized
DEBUG - 2020-10-15 03:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-10-15 03:29:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:29:14 --> Final output sent to browser
DEBUG - 2020-10-15 03:29:14 --> Total execution time: 0.3015
INFO - 2020-10-15 03:29:16 --> Config Class Initialized
INFO - 2020-10-15 03:29:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:16 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:16 --> URI Class Initialized
INFO - 2020-10-15 03:29:16 --> Router Class Initialized
INFO - 2020-10-15 03:29:16 --> Output Class Initialized
INFO - 2020-10-15 03:29:16 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:16 --> Input Class Initialized
INFO - 2020-10-15 03:29:16 --> Language Class Initialized
INFO - 2020-10-15 03:29:16 --> Language Class Initialized
INFO - 2020-10-15 03:29:16 --> Config Class Initialized
INFO - 2020-10-15 03:29:16 --> Loader Class Initialized
INFO - 2020-10-15 03:29:16 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:16 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:16 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:16 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:16 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:16 --> Controller Class Initialized
DEBUG - 2020-10-15 03:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-10-15 03:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:29:16 --> Final output sent to browser
DEBUG - 2020-10-15 03:29:16 --> Total execution time: 0.2813
INFO - 2020-10-15 03:29:16 --> Config Class Initialized
INFO - 2020-10-15 03:29:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:17 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:17 --> URI Class Initialized
INFO - 2020-10-15 03:29:17 --> Router Class Initialized
INFO - 2020-10-15 03:29:17 --> Output Class Initialized
INFO - 2020-10-15 03:29:17 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:17 --> Input Class Initialized
INFO - 2020-10-15 03:29:17 --> Language Class Initialized
INFO - 2020-10-15 03:29:17 --> Language Class Initialized
INFO - 2020-10-15 03:29:17 --> Config Class Initialized
INFO - 2020-10-15 03:29:17 --> Loader Class Initialized
INFO - 2020-10-15 03:29:17 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:17 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:17 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:17 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:17 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:17 --> Controller Class Initialized
INFO - 2020-10-15 03:29:18 --> Config Class Initialized
INFO - 2020-10-15 03:29:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:29:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:29:18 --> Utf8 Class Initialized
INFO - 2020-10-15 03:29:18 --> URI Class Initialized
INFO - 2020-10-15 03:29:18 --> Router Class Initialized
INFO - 2020-10-15 03:29:18 --> Output Class Initialized
INFO - 2020-10-15 03:29:18 --> Security Class Initialized
DEBUG - 2020-10-15 03:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:29:18 --> Input Class Initialized
INFO - 2020-10-15 03:29:18 --> Language Class Initialized
INFO - 2020-10-15 03:29:18 --> Language Class Initialized
INFO - 2020-10-15 03:29:18 --> Config Class Initialized
INFO - 2020-10-15 03:29:18 --> Loader Class Initialized
INFO - 2020-10-15 03:29:19 --> Helper loaded: url_helper
INFO - 2020-10-15 03:29:19 --> Helper loaded: file_helper
INFO - 2020-10-15 03:29:19 --> Helper loaded: form_helper
INFO - 2020-10-15 03:29:19 --> Helper loaded: my_helper
INFO - 2020-10-15 03:29:19 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:29:19 --> Controller Class Initialized
DEBUG - 2020-10-15 03:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-15 03:29:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:29:19 --> Final output sent to browser
DEBUG - 2020-10-15 03:29:19 --> Total execution time: 0.3018
INFO - 2020-10-15 03:30:01 --> Config Class Initialized
INFO - 2020-10-15 03:30:01 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:01 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:01 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:01 --> URI Class Initialized
INFO - 2020-10-15 03:30:01 --> Router Class Initialized
INFO - 2020-10-15 03:30:01 --> Output Class Initialized
INFO - 2020-10-15 03:30:01 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:01 --> Input Class Initialized
INFO - 2020-10-15 03:30:01 --> Language Class Initialized
INFO - 2020-10-15 03:30:01 --> Language Class Initialized
INFO - 2020-10-15 03:30:01 --> Config Class Initialized
INFO - 2020-10-15 03:30:01 --> Loader Class Initialized
INFO - 2020-10-15 03:30:01 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:01 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:01 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:01 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:01 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:01 --> Controller Class Initialized
INFO - 2020-10-15 03:30:01 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:30:01 --> Config Class Initialized
INFO - 2020-10-15 03:30:01 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:01 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:01 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:01 --> URI Class Initialized
INFO - 2020-10-15 03:30:01 --> Router Class Initialized
INFO - 2020-10-15 03:30:01 --> Output Class Initialized
INFO - 2020-10-15 03:30:01 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:01 --> Input Class Initialized
INFO - 2020-10-15 03:30:01 --> Language Class Initialized
INFO - 2020-10-15 03:30:01 --> Language Class Initialized
INFO - 2020-10-15 03:30:01 --> Config Class Initialized
INFO - 2020-10-15 03:30:01 --> Loader Class Initialized
INFO - 2020-10-15 03:30:01 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:01 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:01 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:01 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:01 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:01 --> Controller Class Initialized
DEBUG - 2020-10-15 03:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:30:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:30:02 --> Final output sent to browser
DEBUG - 2020-10-15 03:30:02 --> Total execution time: 0.2688
INFO - 2020-10-15 03:30:03 --> Config Class Initialized
INFO - 2020-10-15 03:30:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:03 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:03 --> URI Class Initialized
INFO - 2020-10-15 03:30:03 --> Router Class Initialized
INFO - 2020-10-15 03:30:03 --> Output Class Initialized
INFO - 2020-10-15 03:30:03 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:03 --> Input Class Initialized
INFO - 2020-10-15 03:30:03 --> Language Class Initialized
INFO - 2020-10-15 03:30:03 --> Language Class Initialized
INFO - 2020-10-15 03:30:03 --> Config Class Initialized
INFO - 2020-10-15 03:30:03 --> Loader Class Initialized
INFO - 2020-10-15 03:30:03 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:03 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:03 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:03 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:03 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:03 --> Controller Class Initialized
INFO - 2020-10-15 03:30:03 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:30:03 --> Config Class Initialized
INFO - 2020-10-15 03:30:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:03 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:03 --> URI Class Initialized
INFO - 2020-10-15 03:30:03 --> Router Class Initialized
INFO - 2020-10-15 03:30:03 --> Output Class Initialized
INFO - 2020-10-15 03:30:03 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:03 --> Input Class Initialized
INFO - 2020-10-15 03:30:03 --> Language Class Initialized
INFO - 2020-10-15 03:30:04 --> Language Class Initialized
INFO - 2020-10-15 03:30:04 --> Config Class Initialized
INFO - 2020-10-15 03:30:04 --> Loader Class Initialized
INFO - 2020-10-15 03:30:04 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:04 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:04 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:04 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:04 --> Controller Class Initialized
DEBUG - 2020-10-15 03:30:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:30:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:30:04 --> Final output sent to browser
DEBUG - 2020-10-15 03:30:04 --> Total execution time: 0.2687
INFO - 2020-10-15 03:30:30 --> Config Class Initialized
INFO - 2020-10-15 03:30:30 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:30 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:30 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:30 --> URI Class Initialized
INFO - 2020-10-15 03:30:30 --> Router Class Initialized
INFO - 2020-10-15 03:30:30 --> Output Class Initialized
INFO - 2020-10-15 03:30:30 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:30 --> Input Class Initialized
INFO - 2020-10-15 03:30:30 --> Language Class Initialized
INFO - 2020-10-15 03:30:30 --> Language Class Initialized
INFO - 2020-10-15 03:30:30 --> Config Class Initialized
INFO - 2020-10-15 03:30:30 --> Loader Class Initialized
INFO - 2020-10-15 03:30:30 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:30 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:30 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:30 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:30 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:30 --> Controller Class Initialized
INFO - 2020-10-15 03:30:30 --> Config Class Initialized
INFO - 2020-10-15 03:30:30 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:30 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:30 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:30 --> URI Class Initialized
INFO - 2020-10-15 03:30:30 --> Router Class Initialized
INFO - 2020-10-15 03:30:30 --> Output Class Initialized
INFO - 2020-10-15 03:30:30 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:30 --> Input Class Initialized
INFO - 2020-10-15 03:30:30 --> Language Class Initialized
INFO - 2020-10-15 03:30:30 --> Language Class Initialized
INFO - 2020-10-15 03:30:30 --> Config Class Initialized
INFO - 2020-10-15 03:30:30 --> Loader Class Initialized
INFO - 2020-10-15 03:30:30 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:30 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:30 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:30 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:30 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:30 --> Controller Class Initialized
DEBUG - 2020-10-15 03:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:30:30 --> Final output sent to browser
DEBUG - 2020-10-15 03:30:30 --> Total execution time: 0.2541
INFO - 2020-10-15 03:30:32 --> Config Class Initialized
INFO - 2020-10-15 03:30:32 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:32 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:32 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:32 --> URI Class Initialized
INFO - 2020-10-15 03:30:32 --> Router Class Initialized
INFO - 2020-10-15 03:30:32 --> Output Class Initialized
INFO - 2020-10-15 03:30:32 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:32 --> Input Class Initialized
INFO - 2020-10-15 03:30:32 --> Language Class Initialized
INFO - 2020-10-15 03:30:32 --> Language Class Initialized
INFO - 2020-10-15 03:30:32 --> Config Class Initialized
INFO - 2020-10-15 03:30:32 --> Loader Class Initialized
INFO - 2020-10-15 03:30:32 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:32 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:32 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:32 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:32 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:32 --> Controller Class Initialized
INFO - 2020-10-15 03:30:32 --> Config Class Initialized
INFO - 2020-10-15 03:30:32 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:30:32 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:30:32 --> Utf8 Class Initialized
INFO - 2020-10-15 03:30:32 --> URI Class Initialized
INFO - 2020-10-15 03:30:32 --> Router Class Initialized
INFO - 2020-10-15 03:30:32 --> Output Class Initialized
INFO - 2020-10-15 03:30:32 --> Security Class Initialized
DEBUG - 2020-10-15 03:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:30:32 --> Input Class Initialized
INFO - 2020-10-15 03:30:32 --> Language Class Initialized
INFO - 2020-10-15 03:30:32 --> Language Class Initialized
INFO - 2020-10-15 03:30:32 --> Config Class Initialized
INFO - 2020-10-15 03:30:32 --> Loader Class Initialized
INFO - 2020-10-15 03:30:32 --> Helper loaded: url_helper
INFO - 2020-10-15 03:30:32 --> Helper loaded: file_helper
INFO - 2020-10-15 03:30:32 --> Helper loaded: form_helper
INFO - 2020-10-15 03:30:32 --> Helper loaded: my_helper
INFO - 2020-10-15 03:30:32 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:30:32 --> Controller Class Initialized
DEBUG - 2020-10-15 03:30:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:30:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:30:32 --> Final output sent to browser
DEBUG - 2020-10-15 03:30:32 --> Total execution time: 0.2565
INFO - 2020-10-15 03:31:00 --> Config Class Initialized
INFO - 2020-10-15 03:31:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:31:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:31:00 --> Utf8 Class Initialized
INFO - 2020-10-15 03:31:00 --> URI Class Initialized
INFO - 2020-10-15 03:31:00 --> Router Class Initialized
INFO - 2020-10-15 03:31:00 --> Output Class Initialized
INFO - 2020-10-15 03:31:00 --> Security Class Initialized
DEBUG - 2020-10-15 03:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:31:00 --> Input Class Initialized
INFO - 2020-10-15 03:31:00 --> Language Class Initialized
INFO - 2020-10-15 03:31:00 --> Language Class Initialized
INFO - 2020-10-15 03:31:00 --> Config Class Initialized
INFO - 2020-10-15 03:31:00 --> Loader Class Initialized
INFO - 2020-10-15 03:31:00 --> Helper loaded: url_helper
INFO - 2020-10-15 03:31:00 --> Helper loaded: file_helper
INFO - 2020-10-15 03:31:00 --> Helper loaded: form_helper
INFO - 2020-10-15 03:31:00 --> Helper loaded: my_helper
INFO - 2020-10-15 03:31:00 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:31:00 --> Controller Class Initialized
DEBUG - 2020-10-15 03:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:31:00 --> Final output sent to browser
DEBUG - 2020-10-15 03:31:00 --> Total execution time: 0.3097
INFO - 2020-10-15 03:31:01 --> Config Class Initialized
INFO - 2020-10-15 03:31:01 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:31:01 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:31:01 --> Utf8 Class Initialized
INFO - 2020-10-15 03:31:01 --> URI Class Initialized
INFO - 2020-10-15 03:31:01 --> Router Class Initialized
INFO - 2020-10-15 03:31:01 --> Output Class Initialized
INFO - 2020-10-15 03:31:01 --> Security Class Initialized
DEBUG - 2020-10-15 03:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:31:01 --> Input Class Initialized
INFO - 2020-10-15 03:31:01 --> Language Class Initialized
INFO - 2020-10-15 03:31:01 --> Language Class Initialized
INFO - 2020-10-15 03:31:01 --> Config Class Initialized
INFO - 2020-10-15 03:31:01 --> Loader Class Initialized
INFO - 2020-10-15 03:31:01 --> Helper loaded: url_helper
INFO - 2020-10-15 03:31:01 --> Helper loaded: file_helper
INFO - 2020-10-15 03:31:01 --> Helper loaded: form_helper
INFO - 2020-10-15 03:31:01 --> Helper loaded: my_helper
INFO - 2020-10-15 03:31:01 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:31:01 --> Controller Class Initialized
INFO - 2020-10-15 03:31:01 --> Helper loaded: cookie_helper
ERROR - 2020-10-15 03:31:02 --> Severity: Warning --> session_destroy(): Trying to destroy uninitialized session C:\xampp\htdocs\nilai\system\libraries\Session\Session.php 628
INFO - 2020-10-15 03:31:02 --> Config Class Initialized
INFO - 2020-10-15 03:31:02 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:31:02 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:31:02 --> Utf8 Class Initialized
INFO - 2020-10-15 03:31:02 --> URI Class Initialized
INFO - 2020-10-15 03:31:02 --> Router Class Initialized
INFO - 2020-10-15 03:31:02 --> Output Class Initialized
INFO - 2020-10-15 03:31:02 --> Security Class Initialized
DEBUG - 2020-10-15 03:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:31:02 --> Input Class Initialized
INFO - 2020-10-15 03:31:02 --> Language Class Initialized
INFO - 2020-10-15 03:31:02 --> Language Class Initialized
INFO - 2020-10-15 03:31:02 --> Config Class Initialized
INFO - 2020-10-15 03:31:02 --> Loader Class Initialized
INFO - 2020-10-15 03:31:02 --> Helper loaded: url_helper
INFO - 2020-10-15 03:31:02 --> Helper loaded: file_helper
INFO - 2020-10-15 03:31:02 --> Helper loaded: form_helper
INFO - 2020-10-15 03:31:02 --> Helper loaded: my_helper
INFO - 2020-10-15 03:31:02 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:31:02 --> Controller Class Initialized
DEBUG - 2020-10-15 03:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:31:02 --> Final output sent to browser
DEBUG - 2020-10-15 03:31:02 --> Total execution time: 0.2631
INFO - 2020-10-15 03:32:36 --> Config Class Initialized
INFO - 2020-10-15 03:32:36 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:32:36 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:32:36 --> Utf8 Class Initialized
INFO - 2020-10-15 03:32:36 --> URI Class Initialized
INFO - 2020-10-15 03:32:36 --> Router Class Initialized
INFO - 2020-10-15 03:32:36 --> Output Class Initialized
INFO - 2020-10-15 03:32:36 --> Security Class Initialized
DEBUG - 2020-10-15 03:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:32:36 --> Input Class Initialized
INFO - 2020-10-15 03:32:36 --> Language Class Initialized
INFO - 2020-10-15 03:32:36 --> Language Class Initialized
INFO - 2020-10-15 03:32:36 --> Config Class Initialized
INFO - 2020-10-15 03:32:36 --> Loader Class Initialized
INFO - 2020-10-15 03:32:36 --> Helper loaded: url_helper
INFO - 2020-10-15 03:32:36 --> Helper loaded: file_helper
INFO - 2020-10-15 03:32:36 --> Helper loaded: form_helper
INFO - 2020-10-15 03:32:36 --> Helper loaded: my_helper
INFO - 2020-10-15 03:32:36 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:32:36 --> Controller Class Initialized
DEBUG - 2020-10-15 03:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:32:36 --> Final output sent to browser
DEBUG - 2020-10-15 03:32:36 --> Total execution time: 0.3115
INFO - 2020-10-15 03:32:37 --> Config Class Initialized
INFO - 2020-10-15 03:32:37 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:32:37 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:32:37 --> Utf8 Class Initialized
INFO - 2020-10-15 03:32:37 --> URI Class Initialized
INFO - 2020-10-15 03:32:37 --> Router Class Initialized
INFO - 2020-10-15 03:32:37 --> Output Class Initialized
INFO - 2020-10-15 03:32:37 --> Security Class Initialized
DEBUG - 2020-10-15 03:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:32:37 --> Input Class Initialized
INFO - 2020-10-15 03:32:37 --> Language Class Initialized
INFO - 2020-10-15 03:32:37 --> Language Class Initialized
INFO - 2020-10-15 03:32:37 --> Config Class Initialized
INFO - 2020-10-15 03:32:37 --> Loader Class Initialized
INFO - 2020-10-15 03:32:37 --> Helper loaded: url_helper
INFO - 2020-10-15 03:32:37 --> Helper loaded: file_helper
INFO - 2020-10-15 03:32:37 --> Helper loaded: form_helper
INFO - 2020-10-15 03:32:37 --> Helper loaded: my_helper
INFO - 2020-10-15 03:32:37 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:32:37 --> Controller Class Initialized
INFO - 2020-10-15 03:32:37 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:32:37 --> Config Class Initialized
INFO - 2020-10-15 03:32:37 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:32:37 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:32:37 --> Utf8 Class Initialized
INFO - 2020-10-15 03:32:37 --> URI Class Initialized
INFO - 2020-10-15 03:32:37 --> Router Class Initialized
INFO - 2020-10-15 03:32:37 --> Output Class Initialized
INFO - 2020-10-15 03:32:37 --> Security Class Initialized
DEBUG - 2020-10-15 03:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:32:38 --> Input Class Initialized
INFO - 2020-10-15 03:32:38 --> Language Class Initialized
INFO - 2020-10-15 03:32:38 --> Language Class Initialized
INFO - 2020-10-15 03:32:38 --> Config Class Initialized
INFO - 2020-10-15 03:32:38 --> Loader Class Initialized
INFO - 2020-10-15 03:32:38 --> Helper loaded: url_helper
INFO - 2020-10-15 03:32:38 --> Helper loaded: file_helper
INFO - 2020-10-15 03:32:38 --> Helper loaded: form_helper
INFO - 2020-10-15 03:32:38 --> Helper loaded: my_helper
INFO - 2020-10-15 03:32:38 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:32:38 --> Controller Class Initialized
DEBUG - 2020-10-15 03:32:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:32:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:32:38 --> Final output sent to browser
DEBUG - 2020-10-15 03:32:38 --> Total execution time: 0.2586
INFO - 2020-10-15 03:32:51 --> Config Class Initialized
INFO - 2020-10-15 03:32:51 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:32:51 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:32:51 --> Utf8 Class Initialized
INFO - 2020-10-15 03:32:51 --> URI Class Initialized
INFO - 2020-10-15 03:32:51 --> Router Class Initialized
INFO - 2020-10-15 03:32:51 --> Output Class Initialized
INFO - 2020-10-15 03:32:51 --> Security Class Initialized
DEBUG - 2020-10-15 03:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:32:51 --> Input Class Initialized
INFO - 2020-10-15 03:32:51 --> Language Class Initialized
INFO - 2020-10-15 03:32:51 --> Language Class Initialized
INFO - 2020-10-15 03:32:51 --> Config Class Initialized
INFO - 2020-10-15 03:32:51 --> Loader Class Initialized
INFO - 2020-10-15 03:32:51 --> Helper loaded: url_helper
INFO - 2020-10-15 03:32:51 --> Helper loaded: file_helper
INFO - 2020-10-15 03:32:51 --> Helper loaded: form_helper
INFO - 2020-10-15 03:32:51 --> Helper loaded: my_helper
INFO - 2020-10-15 03:32:51 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:32:51 --> Controller Class Initialized
DEBUG - 2020-10-15 03:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:32:51 --> Final output sent to browser
DEBUG - 2020-10-15 03:32:51 --> Total execution time: 0.3972
INFO - 2020-10-15 03:32:52 --> Config Class Initialized
INFO - 2020-10-15 03:32:53 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:32:53 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:32:53 --> Utf8 Class Initialized
INFO - 2020-10-15 03:32:53 --> URI Class Initialized
INFO - 2020-10-15 03:32:53 --> Router Class Initialized
INFO - 2020-10-15 03:32:53 --> Output Class Initialized
INFO - 2020-10-15 03:32:53 --> Security Class Initialized
DEBUG - 2020-10-15 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:32:53 --> Input Class Initialized
INFO - 2020-10-15 03:32:53 --> Language Class Initialized
INFO - 2020-10-15 03:32:53 --> Language Class Initialized
INFO - 2020-10-15 03:32:53 --> Config Class Initialized
INFO - 2020-10-15 03:32:53 --> Loader Class Initialized
INFO - 2020-10-15 03:32:53 --> Helper loaded: url_helper
INFO - 2020-10-15 03:32:53 --> Helper loaded: file_helper
INFO - 2020-10-15 03:32:53 --> Helper loaded: form_helper
INFO - 2020-10-15 03:32:53 --> Helper loaded: my_helper
INFO - 2020-10-15 03:32:53 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:32:53 --> Controller Class Initialized
INFO - 2020-10-15 03:32:53 --> Config Class Initialized
INFO - 2020-10-15 03:32:53 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:32:53 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:32:53 --> Utf8 Class Initialized
INFO - 2020-10-15 03:32:53 --> URI Class Initialized
INFO - 2020-10-15 03:32:53 --> Router Class Initialized
INFO - 2020-10-15 03:32:53 --> Output Class Initialized
INFO - 2020-10-15 03:32:53 --> Security Class Initialized
DEBUG - 2020-10-15 03:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:32:53 --> Input Class Initialized
INFO - 2020-10-15 03:32:53 --> Language Class Initialized
INFO - 2020-10-15 03:32:53 --> Language Class Initialized
INFO - 2020-10-15 03:32:53 --> Config Class Initialized
INFO - 2020-10-15 03:32:53 --> Loader Class Initialized
INFO - 2020-10-15 03:32:53 --> Helper loaded: url_helper
INFO - 2020-10-15 03:32:53 --> Helper loaded: file_helper
INFO - 2020-10-15 03:32:53 --> Helper loaded: form_helper
INFO - 2020-10-15 03:32:53 --> Helper loaded: my_helper
INFO - 2020-10-15 03:32:53 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:32:53 --> Controller Class Initialized
DEBUG - 2020-10-15 03:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:32:53 --> Final output sent to browser
DEBUG - 2020-10-15 03:32:53 --> Total execution time: 0.3292
INFO - 2020-10-15 03:34:40 --> Config Class Initialized
INFO - 2020-10-15 03:34:40 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:34:40 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:34:40 --> Utf8 Class Initialized
INFO - 2020-10-15 03:34:41 --> URI Class Initialized
INFO - 2020-10-15 03:34:41 --> Router Class Initialized
INFO - 2020-10-15 03:34:41 --> Output Class Initialized
INFO - 2020-10-15 03:34:41 --> Security Class Initialized
DEBUG - 2020-10-15 03:34:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:34:41 --> Input Class Initialized
INFO - 2020-10-15 03:34:41 --> Language Class Initialized
INFO - 2020-10-15 03:34:41 --> Language Class Initialized
INFO - 2020-10-15 03:34:41 --> Config Class Initialized
INFO - 2020-10-15 03:34:41 --> Loader Class Initialized
INFO - 2020-10-15 03:34:41 --> Helper loaded: url_helper
INFO - 2020-10-15 03:34:41 --> Helper loaded: file_helper
INFO - 2020-10-15 03:34:41 --> Helper loaded: form_helper
INFO - 2020-10-15 03:34:41 --> Helper loaded: my_helper
INFO - 2020-10-15 03:34:41 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:34:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:34:41 --> Controller Class Initialized
DEBUG - 2020-10-15 03:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:34:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:34:41 --> Final output sent to browser
DEBUG - 2020-10-15 03:34:41 --> Total execution time: 0.3391
INFO - 2020-10-15 03:34:42 --> Config Class Initialized
INFO - 2020-10-15 03:34:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:34:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:34:42 --> Utf8 Class Initialized
INFO - 2020-10-15 03:34:42 --> URI Class Initialized
INFO - 2020-10-15 03:34:42 --> Router Class Initialized
INFO - 2020-10-15 03:34:42 --> Output Class Initialized
INFO - 2020-10-15 03:34:42 --> Security Class Initialized
DEBUG - 2020-10-15 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:34:42 --> Input Class Initialized
INFO - 2020-10-15 03:34:42 --> Language Class Initialized
INFO - 2020-10-15 03:34:42 --> Language Class Initialized
INFO - 2020-10-15 03:34:42 --> Config Class Initialized
INFO - 2020-10-15 03:34:42 --> Loader Class Initialized
INFO - 2020-10-15 03:34:42 --> Helper loaded: url_helper
INFO - 2020-10-15 03:34:42 --> Helper loaded: file_helper
INFO - 2020-10-15 03:34:42 --> Helper loaded: form_helper
INFO - 2020-10-15 03:34:42 --> Helper loaded: my_helper
INFO - 2020-10-15 03:34:42 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:34:42 --> Controller Class Initialized
INFO - 2020-10-15 03:34:42 --> Config Class Initialized
INFO - 2020-10-15 03:34:42 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:34:42 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:34:42 --> Utf8 Class Initialized
INFO - 2020-10-15 03:34:42 --> URI Class Initialized
DEBUG - 2020-10-15 03:34:42 --> No URI present. Default controller set.
INFO - 2020-10-15 03:34:42 --> Router Class Initialized
INFO - 2020-10-15 03:34:42 --> Output Class Initialized
INFO - 2020-10-15 03:34:42 --> Security Class Initialized
DEBUG - 2020-10-15 03:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:34:42 --> Input Class Initialized
INFO - 2020-10-15 03:34:42 --> Language Class Initialized
INFO - 2020-10-15 03:34:42 --> Language Class Initialized
INFO - 2020-10-15 03:34:42 --> Config Class Initialized
INFO - 2020-10-15 03:34:42 --> Loader Class Initialized
INFO - 2020-10-15 03:34:42 --> Helper loaded: url_helper
INFO - 2020-10-15 03:34:42 --> Helper loaded: file_helper
INFO - 2020-10-15 03:34:42 --> Helper loaded: form_helper
INFO - 2020-10-15 03:34:42 --> Helper loaded: my_helper
INFO - 2020-10-15 03:34:42 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:34:42 --> Controller Class Initialized
DEBUG - 2020-10-15 03:34:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:34:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:34:42 --> Final output sent to browser
DEBUG - 2020-10-15 03:34:42 --> Total execution time: 0.2794
INFO - 2020-10-15 03:45:05 --> Config Class Initialized
INFO - 2020-10-15 03:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:45:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:45:05 --> Utf8 Class Initialized
INFO - 2020-10-15 03:45:05 --> URI Class Initialized
DEBUG - 2020-10-15 03:45:05 --> No URI present. Default controller set.
INFO - 2020-10-15 03:45:05 --> Router Class Initialized
INFO - 2020-10-15 03:45:05 --> Output Class Initialized
INFO - 2020-10-15 03:45:05 --> Security Class Initialized
DEBUG - 2020-10-15 03:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:45:05 --> Input Class Initialized
INFO - 2020-10-15 03:45:05 --> Language Class Initialized
INFO - 2020-10-15 03:45:05 --> Language Class Initialized
INFO - 2020-10-15 03:45:05 --> Config Class Initialized
INFO - 2020-10-15 03:45:05 --> Loader Class Initialized
INFO - 2020-10-15 03:45:05 --> Helper loaded: url_helper
INFO - 2020-10-15 03:45:05 --> Helper loaded: file_helper
INFO - 2020-10-15 03:45:05 --> Helper loaded: form_helper
INFO - 2020-10-15 03:45:05 --> Helper loaded: my_helper
INFO - 2020-10-15 03:45:05 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:45:05 --> Controller Class Initialized
DEBUG - 2020-10-15 03:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:45:05 --> Final output sent to browser
DEBUG - 2020-10-15 03:45:05 --> Total execution time: 0.2958
INFO - 2020-10-15 03:45:08 --> Config Class Initialized
INFO - 2020-10-15 03:45:08 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:45:08 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:45:08 --> Utf8 Class Initialized
INFO - 2020-10-15 03:45:08 --> URI Class Initialized
INFO - 2020-10-15 03:45:08 --> Router Class Initialized
INFO - 2020-10-15 03:45:08 --> Output Class Initialized
INFO - 2020-10-15 03:45:08 --> Security Class Initialized
DEBUG - 2020-10-15 03:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:45:08 --> Input Class Initialized
INFO - 2020-10-15 03:45:08 --> Language Class Initialized
INFO - 2020-10-15 03:45:08 --> Language Class Initialized
INFO - 2020-10-15 03:45:08 --> Config Class Initialized
INFO - 2020-10-15 03:45:08 --> Loader Class Initialized
INFO - 2020-10-15 03:45:08 --> Helper loaded: url_helper
INFO - 2020-10-15 03:45:08 --> Helper loaded: file_helper
INFO - 2020-10-15 03:45:08 --> Helper loaded: form_helper
INFO - 2020-10-15 03:45:08 --> Helper loaded: my_helper
INFO - 2020-10-15 03:45:08 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:45:08 --> Controller Class Initialized
INFO - 2020-10-15 03:45:08 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:45:08 --> Config Class Initialized
INFO - 2020-10-15 03:45:08 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:45:08 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:45:08 --> Utf8 Class Initialized
INFO - 2020-10-15 03:45:08 --> URI Class Initialized
INFO - 2020-10-15 03:45:08 --> Router Class Initialized
INFO - 2020-10-15 03:45:08 --> Output Class Initialized
INFO - 2020-10-15 03:45:08 --> Security Class Initialized
DEBUG - 2020-10-15 03:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:45:08 --> Input Class Initialized
INFO - 2020-10-15 03:45:08 --> Language Class Initialized
INFO - 2020-10-15 03:45:08 --> Language Class Initialized
INFO - 2020-10-15 03:45:08 --> Config Class Initialized
INFO - 2020-10-15 03:45:08 --> Loader Class Initialized
INFO - 2020-10-15 03:45:08 --> Helper loaded: url_helper
INFO - 2020-10-15 03:45:08 --> Helper loaded: file_helper
INFO - 2020-10-15 03:45:08 --> Helper loaded: form_helper
INFO - 2020-10-15 03:45:08 --> Helper loaded: my_helper
INFO - 2020-10-15 03:45:08 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:45:08 --> Controller Class Initialized
DEBUG - 2020-10-15 03:45:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:45:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:45:08 --> Final output sent to browser
DEBUG - 2020-10-15 03:45:08 --> Total execution time: 0.3117
INFO - 2020-10-15 03:56:27 --> Config Class Initialized
INFO - 2020-10-15 03:56:27 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:27 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:27 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:27 --> URI Class Initialized
INFO - 2020-10-15 03:56:27 --> Router Class Initialized
INFO - 2020-10-15 03:56:27 --> Output Class Initialized
INFO - 2020-10-15 03:56:27 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:27 --> Input Class Initialized
INFO - 2020-10-15 03:56:27 --> Language Class Initialized
INFO - 2020-10-15 03:56:27 --> Language Class Initialized
INFO - 2020-10-15 03:56:27 --> Config Class Initialized
INFO - 2020-10-15 03:56:27 --> Loader Class Initialized
INFO - 2020-10-15 03:56:27 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:27 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:27 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:27 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:27 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:27 --> Controller Class Initialized
DEBUG - 2020-10-15 03:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:56:27 --> Final output sent to browser
DEBUG - 2020-10-15 03:56:27 --> Total execution time: 0.3935
INFO - 2020-10-15 03:56:28 --> Config Class Initialized
INFO - 2020-10-15 03:56:28 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:28 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:28 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:29 --> URI Class Initialized
INFO - 2020-10-15 03:56:29 --> Router Class Initialized
INFO - 2020-10-15 03:56:29 --> Output Class Initialized
INFO - 2020-10-15 03:56:29 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:29 --> Input Class Initialized
INFO - 2020-10-15 03:56:29 --> Language Class Initialized
INFO - 2020-10-15 03:56:29 --> Language Class Initialized
INFO - 2020-10-15 03:56:29 --> Config Class Initialized
INFO - 2020-10-15 03:56:29 --> Loader Class Initialized
INFO - 2020-10-15 03:56:29 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:29 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:29 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:29 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:29 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:29 --> Controller Class Initialized
INFO - 2020-10-15 03:56:29 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:56:29 --> Config Class Initialized
INFO - 2020-10-15 03:56:29 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:29 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:29 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:29 --> URI Class Initialized
DEBUG - 2020-10-15 03:56:29 --> No URI present. Default controller set.
INFO - 2020-10-15 03:56:29 --> Router Class Initialized
INFO - 2020-10-15 03:56:29 --> Output Class Initialized
INFO - 2020-10-15 03:56:29 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:29 --> Input Class Initialized
INFO - 2020-10-15 03:56:29 --> Language Class Initialized
INFO - 2020-10-15 03:56:29 --> Language Class Initialized
INFO - 2020-10-15 03:56:29 --> Config Class Initialized
INFO - 2020-10-15 03:56:29 --> Loader Class Initialized
INFO - 2020-10-15 03:56:29 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:29 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:29 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:29 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:29 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:29 --> Controller Class Initialized
DEBUG - 2020-10-15 03:56:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:56:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:56:29 --> Final output sent to browser
DEBUG - 2020-10-15 03:56:29 --> Total execution time: 0.3127
INFO - 2020-10-15 03:56:30 --> Config Class Initialized
INFO - 2020-10-15 03:56:30 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:30 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:30 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:30 --> URI Class Initialized
INFO - 2020-10-15 03:56:30 --> Router Class Initialized
INFO - 2020-10-15 03:56:30 --> Output Class Initialized
INFO - 2020-10-15 03:56:30 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:30 --> Input Class Initialized
INFO - 2020-10-15 03:56:30 --> Language Class Initialized
INFO - 2020-10-15 03:56:30 --> Language Class Initialized
INFO - 2020-10-15 03:56:30 --> Config Class Initialized
INFO - 2020-10-15 03:56:30 --> Loader Class Initialized
INFO - 2020-10-15 03:56:30 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:30 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:30 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:30 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:30 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:30 --> Controller Class Initialized
INFO - 2020-10-15 03:56:30 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:56:30 --> Config Class Initialized
INFO - 2020-10-15 03:56:30 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:30 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:30 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:30 --> URI Class Initialized
DEBUG - 2020-10-15 03:56:30 --> No URI present. Default controller set.
INFO - 2020-10-15 03:56:31 --> Router Class Initialized
INFO - 2020-10-15 03:56:31 --> Output Class Initialized
INFO - 2020-10-15 03:56:31 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:31 --> Input Class Initialized
INFO - 2020-10-15 03:56:31 --> Language Class Initialized
INFO - 2020-10-15 03:56:31 --> Language Class Initialized
INFO - 2020-10-15 03:56:31 --> Config Class Initialized
INFO - 2020-10-15 03:56:31 --> Loader Class Initialized
INFO - 2020-10-15 03:56:31 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:31 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:31 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:31 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:31 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:31 --> Controller Class Initialized
DEBUG - 2020-10-15 03:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:56:31 --> Final output sent to browser
DEBUG - 2020-10-15 03:56:31 --> Total execution time: 0.3413
INFO - 2020-10-15 03:56:33 --> Config Class Initialized
INFO - 2020-10-15 03:56:33 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:33 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:33 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:33 --> URI Class Initialized
DEBUG - 2020-10-15 03:56:33 --> No URI present. Default controller set.
INFO - 2020-10-15 03:56:33 --> Router Class Initialized
INFO - 2020-10-15 03:56:33 --> Output Class Initialized
INFO - 2020-10-15 03:56:33 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:33 --> Input Class Initialized
INFO - 2020-10-15 03:56:33 --> Language Class Initialized
INFO - 2020-10-15 03:56:33 --> Language Class Initialized
INFO - 2020-10-15 03:56:33 --> Config Class Initialized
INFO - 2020-10-15 03:56:33 --> Loader Class Initialized
INFO - 2020-10-15 03:56:33 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:33 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:33 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:33 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:33 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:33 --> Controller Class Initialized
DEBUG - 2020-10-15 03:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:56:33 --> Final output sent to browser
DEBUG - 2020-10-15 03:56:33 --> Total execution time: 0.3283
INFO - 2020-10-15 03:56:38 --> Config Class Initialized
INFO - 2020-10-15 03:56:38 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:38 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:38 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:38 --> URI Class Initialized
INFO - 2020-10-15 03:56:38 --> Router Class Initialized
INFO - 2020-10-15 03:56:38 --> Output Class Initialized
INFO - 2020-10-15 03:56:38 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:38 --> Input Class Initialized
INFO - 2020-10-15 03:56:38 --> Language Class Initialized
INFO - 2020-10-15 03:56:38 --> Language Class Initialized
INFO - 2020-10-15 03:56:38 --> Config Class Initialized
INFO - 2020-10-15 03:56:39 --> Loader Class Initialized
INFO - 2020-10-15 03:56:39 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:39 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:39 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:39 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:39 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:39 --> Controller Class Initialized
INFO - 2020-10-15 03:56:39 --> Helper loaded: cookie_helper
INFO - 2020-10-15 03:56:39 --> Config Class Initialized
INFO - 2020-10-15 03:56:39 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:56:39 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:56:39 --> Utf8 Class Initialized
INFO - 2020-10-15 03:56:39 --> URI Class Initialized
DEBUG - 2020-10-15 03:56:39 --> No URI present. Default controller set.
INFO - 2020-10-15 03:56:39 --> Router Class Initialized
INFO - 2020-10-15 03:56:39 --> Output Class Initialized
INFO - 2020-10-15 03:56:39 --> Security Class Initialized
DEBUG - 2020-10-15 03:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:56:39 --> Input Class Initialized
INFO - 2020-10-15 03:56:39 --> Language Class Initialized
INFO - 2020-10-15 03:56:39 --> Language Class Initialized
INFO - 2020-10-15 03:56:39 --> Config Class Initialized
INFO - 2020-10-15 03:56:39 --> Loader Class Initialized
INFO - 2020-10-15 03:56:39 --> Helper loaded: url_helper
INFO - 2020-10-15 03:56:39 --> Helper loaded: file_helper
INFO - 2020-10-15 03:56:39 --> Helper loaded: form_helper
INFO - 2020-10-15 03:56:39 --> Helper loaded: my_helper
INFO - 2020-10-15 03:56:39 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:56:39 --> Controller Class Initialized
DEBUG - 2020-10-15 03:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:56:39 --> Final output sent to browser
DEBUG - 2020-10-15 03:56:39 --> Total execution time: 0.3047
INFO - 2020-10-15 03:57:00 --> Config Class Initialized
INFO - 2020-10-15 03:57:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:57:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:57:00 --> Utf8 Class Initialized
INFO - 2020-10-15 03:57:00 --> URI Class Initialized
DEBUG - 2020-10-15 03:57:00 --> No URI present. Default controller set.
INFO - 2020-10-15 03:57:00 --> Router Class Initialized
INFO - 2020-10-15 03:57:00 --> Output Class Initialized
INFO - 2020-10-15 03:57:01 --> Security Class Initialized
DEBUG - 2020-10-15 03:57:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:57:01 --> Input Class Initialized
INFO - 2020-10-15 03:57:01 --> Language Class Initialized
INFO - 2020-10-15 03:57:01 --> Language Class Initialized
INFO - 2020-10-15 03:57:01 --> Config Class Initialized
INFO - 2020-10-15 03:57:01 --> Loader Class Initialized
INFO - 2020-10-15 03:57:01 --> Helper loaded: url_helper
INFO - 2020-10-15 03:57:01 --> Helper loaded: file_helper
INFO - 2020-10-15 03:57:01 --> Helper loaded: form_helper
INFO - 2020-10-15 03:57:01 --> Helper loaded: my_helper
INFO - 2020-10-15 03:57:01 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:57:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:57:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:57:01 --> Controller Class Initialized
DEBUG - 2020-10-15 03:57:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:57:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:57:01 --> Final output sent to browser
DEBUG - 2020-10-15 03:57:01 --> Total execution time: 0.4112
INFO - 2020-10-15 03:57:02 --> Config Class Initialized
INFO - 2020-10-15 03:57:02 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:57:02 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:57:02 --> Utf8 Class Initialized
INFO - 2020-10-15 03:57:02 --> URI Class Initialized
INFO - 2020-10-15 03:57:02 --> Router Class Initialized
INFO - 2020-10-15 03:57:02 --> Output Class Initialized
INFO - 2020-10-15 03:57:02 --> Security Class Initialized
DEBUG - 2020-10-15 03:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:57:02 --> Input Class Initialized
INFO - 2020-10-15 03:57:02 --> Language Class Initialized
INFO - 2020-10-15 03:57:02 --> Language Class Initialized
INFO - 2020-10-15 03:57:02 --> Config Class Initialized
INFO - 2020-10-15 03:57:02 --> Loader Class Initialized
INFO - 2020-10-15 03:57:02 --> Helper loaded: url_helper
INFO - 2020-10-15 03:57:02 --> Helper loaded: file_helper
INFO - 2020-10-15 03:57:02 --> Helper loaded: form_helper
INFO - 2020-10-15 03:57:02 --> Helper loaded: my_helper
INFO - 2020-10-15 03:57:02 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:57:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:57:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:57:02 --> Controller Class Initialized
INFO - 2020-10-15 03:57:02 --> Config Class Initialized
INFO - 2020-10-15 03:57:02 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:57:02 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:57:02 --> Utf8 Class Initialized
INFO - 2020-10-15 03:57:02 --> URI Class Initialized
DEBUG - 2020-10-15 03:57:02 --> No URI present. Default controller set.
INFO - 2020-10-15 03:57:02 --> Router Class Initialized
INFO - 2020-10-15 03:57:02 --> Output Class Initialized
INFO - 2020-10-15 03:57:02 --> Security Class Initialized
DEBUG - 2020-10-15 03:57:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:57:02 --> Input Class Initialized
INFO - 2020-10-15 03:57:02 --> Language Class Initialized
INFO - 2020-10-15 03:57:02 --> Language Class Initialized
INFO - 2020-10-15 03:57:02 --> Config Class Initialized
INFO - 2020-10-15 03:57:02 --> Loader Class Initialized
INFO - 2020-10-15 03:57:02 --> Helper loaded: url_helper
INFO - 2020-10-15 03:57:02 --> Helper loaded: file_helper
INFO - 2020-10-15 03:57:02 --> Helper loaded: form_helper
INFO - 2020-10-15 03:57:02 --> Helper loaded: my_helper
INFO - 2020-10-15 03:57:02 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:57:03 --> Controller Class Initialized
DEBUG - 2020-10-15 03:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:57:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:57:03 --> Final output sent to browser
DEBUG - 2020-10-15 03:57:03 --> Total execution time: 0.3125
INFO - 2020-10-15 03:57:04 --> Config Class Initialized
INFO - 2020-10-15 03:57:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:57:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:57:04 --> Utf8 Class Initialized
INFO - 2020-10-15 03:57:04 --> URI Class Initialized
INFO - 2020-10-15 03:57:04 --> Router Class Initialized
INFO - 2020-10-15 03:57:04 --> Output Class Initialized
INFO - 2020-10-15 03:57:04 --> Security Class Initialized
DEBUG - 2020-10-15 03:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:57:04 --> Input Class Initialized
INFO - 2020-10-15 03:57:04 --> Language Class Initialized
INFO - 2020-10-15 03:57:04 --> Language Class Initialized
INFO - 2020-10-15 03:57:04 --> Config Class Initialized
INFO - 2020-10-15 03:57:04 --> Loader Class Initialized
INFO - 2020-10-15 03:57:04 --> Helper loaded: url_helper
INFO - 2020-10-15 03:57:04 --> Helper loaded: file_helper
INFO - 2020-10-15 03:57:04 --> Helper loaded: form_helper
INFO - 2020-10-15 03:57:04 --> Helper loaded: my_helper
INFO - 2020-10-15 03:57:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:57:04 --> Controller Class Initialized
INFO - 2020-10-15 03:57:04 --> Config Class Initialized
INFO - 2020-10-15 03:57:04 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:57:04 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:57:04 --> Utf8 Class Initialized
INFO - 2020-10-15 03:57:04 --> URI Class Initialized
DEBUG - 2020-10-15 03:57:04 --> No URI present. Default controller set.
INFO - 2020-10-15 03:57:04 --> Router Class Initialized
INFO - 2020-10-15 03:57:04 --> Output Class Initialized
INFO - 2020-10-15 03:57:04 --> Security Class Initialized
DEBUG - 2020-10-15 03:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:57:04 --> Input Class Initialized
INFO - 2020-10-15 03:57:04 --> Language Class Initialized
INFO - 2020-10-15 03:57:04 --> Language Class Initialized
INFO - 2020-10-15 03:57:04 --> Config Class Initialized
INFO - 2020-10-15 03:57:04 --> Loader Class Initialized
INFO - 2020-10-15 03:57:04 --> Helper loaded: url_helper
INFO - 2020-10-15 03:57:04 --> Helper loaded: file_helper
INFO - 2020-10-15 03:57:04 --> Helper loaded: form_helper
INFO - 2020-10-15 03:57:04 --> Helper loaded: my_helper
INFO - 2020-10-15 03:57:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:57:04 --> Controller Class Initialized
DEBUG - 2020-10-15 03:57:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:57:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:57:04 --> Final output sent to browser
DEBUG - 2020-10-15 03:57:04 --> Total execution time: 0.3151
INFO - 2020-10-15 03:57:24 --> Config Class Initialized
INFO - 2020-10-15 03:57:24 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:57:24 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:57:24 --> Utf8 Class Initialized
INFO - 2020-10-15 03:57:24 --> URI Class Initialized
INFO - 2020-10-15 03:57:24 --> Router Class Initialized
INFO - 2020-10-15 03:57:24 --> Output Class Initialized
INFO - 2020-10-15 03:57:24 --> Security Class Initialized
DEBUG - 2020-10-15 03:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:57:24 --> Input Class Initialized
INFO - 2020-10-15 03:57:24 --> Language Class Initialized
INFO - 2020-10-15 03:57:24 --> Language Class Initialized
INFO - 2020-10-15 03:57:24 --> Config Class Initialized
INFO - 2020-10-15 03:57:24 --> Loader Class Initialized
INFO - 2020-10-15 03:57:24 --> Helper loaded: url_helper
INFO - 2020-10-15 03:57:24 --> Helper loaded: file_helper
INFO - 2020-10-15 03:57:24 --> Helper loaded: form_helper
INFO - 2020-10-15 03:57:24 --> Helper loaded: my_helper
INFO - 2020-10-15 03:57:24 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:57:24 --> Controller Class Initialized
INFO - 2020-10-15 03:57:24 --> Config Class Initialized
INFO - 2020-10-15 03:57:24 --> Hooks Class Initialized
DEBUG - 2020-10-15 03:57:24 --> UTF-8 Support Enabled
INFO - 2020-10-15 03:57:24 --> Utf8 Class Initialized
INFO - 2020-10-15 03:57:24 --> URI Class Initialized
DEBUG - 2020-10-15 03:57:24 --> No URI present. Default controller set.
INFO - 2020-10-15 03:57:24 --> Router Class Initialized
INFO - 2020-10-15 03:57:24 --> Output Class Initialized
INFO - 2020-10-15 03:57:24 --> Security Class Initialized
DEBUG - 2020-10-15 03:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 03:57:24 --> Input Class Initialized
INFO - 2020-10-15 03:57:24 --> Language Class Initialized
INFO - 2020-10-15 03:57:24 --> Language Class Initialized
INFO - 2020-10-15 03:57:24 --> Config Class Initialized
INFO - 2020-10-15 03:57:24 --> Loader Class Initialized
INFO - 2020-10-15 03:57:24 --> Helper loaded: url_helper
INFO - 2020-10-15 03:57:24 --> Helper loaded: file_helper
INFO - 2020-10-15 03:57:24 --> Helper loaded: form_helper
INFO - 2020-10-15 03:57:24 --> Helper loaded: my_helper
INFO - 2020-10-15 03:57:24 --> Database Driver Class Initialized
DEBUG - 2020-10-15 03:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 03:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 03:57:24 --> Controller Class Initialized
DEBUG - 2020-10-15 03:57:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 03:57:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 03:57:24 --> Final output sent to browser
DEBUG - 2020-10-15 03:57:24 --> Total execution time: 0.3488
INFO - 2020-10-15 05:47:16 --> Config Class Initialized
INFO - 2020-10-15 05:47:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:47:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:47:16 --> Utf8 Class Initialized
INFO - 2020-10-15 05:47:16 --> URI Class Initialized
DEBUG - 2020-10-15 05:47:16 --> No URI present. Default controller set.
INFO - 2020-10-15 05:47:16 --> Router Class Initialized
INFO - 2020-10-15 05:47:16 --> Output Class Initialized
INFO - 2020-10-15 05:47:16 --> Security Class Initialized
DEBUG - 2020-10-15 05:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:47:16 --> Input Class Initialized
INFO - 2020-10-15 05:47:16 --> Language Class Initialized
INFO - 2020-10-15 05:47:16 --> Language Class Initialized
INFO - 2020-10-15 05:47:16 --> Config Class Initialized
INFO - 2020-10-15 05:47:16 --> Loader Class Initialized
INFO - 2020-10-15 05:47:16 --> Helper loaded: url_helper
INFO - 2020-10-15 05:47:16 --> Helper loaded: file_helper
INFO - 2020-10-15 05:47:16 --> Helper loaded: form_helper
INFO - 2020-10-15 05:47:16 --> Helper loaded: my_helper
INFO - 2020-10-15 05:47:16 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:47:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:47:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:47:16 --> Controller Class Initialized
DEBUG - 2020-10-15 05:47:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:47:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:47:16 --> Final output sent to browser
DEBUG - 2020-10-15 05:47:16 --> Total execution time: 0.3832
INFO - 2020-10-15 05:49:43 --> Config Class Initialized
INFO - 2020-10-15 05:49:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:49:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:49:43 --> Utf8 Class Initialized
INFO - 2020-10-15 05:49:43 --> URI Class Initialized
DEBUG - 2020-10-15 05:49:43 --> No URI present. Default controller set.
INFO - 2020-10-15 05:49:43 --> Router Class Initialized
INFO - 2020-10-15 05:49:43 --> Output Class Initialized
INFO - 2020-10-15 05:49:43 --> Security Class Initialized
DEBUG - 2020-10-15 05:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:49:44 --> Input Class Initialized
INFO - 2020-10-15 05:49:44 --> Language Class Initialized
INFO - 2020-10-15 05:49:44 --> Language Class Initialized
INFO - 2020-10-15 05:49:44 --> Config Class Initialized
INFO - 2020-10-15 05:49:44 --> Loader Class Initialized
INFO - 2020-10-15 05:49:44 --> Helper loaded: url_helper
INFO - 2020-10-15 05:49:44 --> Helper loaded: file_helper
INFO - 2020-10-15 05:49:44 --> Helper loaded: form_helper
INFO - 2020-10-15 05:49:44 --> Helper loaded: my_helper
INFO - 2020-10-15 05:49:44 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:49:44 --> Controller Class Initialized
DEBUG - 2020-10-15 05:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:49:44 --> Final output sent to browser
DEBUG - 2020-10-15 05:49:44 --> Total execution time: 0.2944
INFO - 2020-10-15 05:49:45 --> Config Class Initialized
INFO - 2020-10-15 05:49:45 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:49:45 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:49:45 --> Utf8 Class Initialized
INFO - 2020-10-15 05:49:45 --> URI Class Initialized
INFO - 2020-10-15 05:49:45 --> Router Class Initialized
INFO - 2020-10-15 05:49:45 --> Output Class Initialized
INFO - 2020-10-15 05:49:45 --> Security Class Initialized
DEBUG - 2020-10-15 05:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:49:45 --> Input Class Initialized
INFO - 2020-10-15 05:49:45 --> Language Class Initialized
INFO - 2020-10-15 05:49:45 --> Language Class Initialized
INFO - 2020-10-15 05:49:45 --> Config Class Initialized
INFO - 2020-10-15 05:49:45 --> Loader Class Initialized
INFO - 2020-10-15 05:49:45 --> Helper loaded: url_helper
INFO - 2020-10-15 05:49:46 --> Helper loaded: file_helper
INFO - 2020-10-15 05:49:46 --> Helper loaded: form_helper
INFO - 2020-10-15 05:49:46 --> Helper loaded: my_helper
INFO - 2020-10-15 05:49:46 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:49:46 --> Controller Class Initialized
INFO - 2020-10-15 05:49:46 --> Helper loaded: cookie_helper
INFO - 2020-10-15 05:49:46 --> Config Class Initialized
INFO - 2020-10-15 05:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:49:46 --> Utf8 Class Initialized
INFO - 2020-10-15 05:49:46 --> URI Class Initialized
INFO - 2020-10-15 05:49:46 --> Router Class Initialized
INFO - 2020-10-15 05:49:46 --> Output Class Initialized
INFO - 2020-10-15 05:49:46 --> Security Class Initialized
DEBUG - 2020-10-15 05:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:49:46 --> Input Class Initialized
INFO - 2020-10-15 05:49:46 --> Language Class Initialized
INFO - 2020-10-15 05:49:46 --> Language Class Initialized
INFO - 2020-10-15 05:49:46 --> Config Class Initialized
INFO - 2020-10-15 05:49:46 --> Loader Class Initialized
INFO - 2020-10-15 05:49:46 --> Helper loaded: url_helper
INFO - 2020-10-15 05:49:46 --> Helper loaded: file_helper
INFO - 2020-10-15 05:49:46 --> Helper loaded: form_helper
INFO - 2020-10-15 05:49:46 --> Helper loaded: my_helper
INFO - 2020-10-15 05:49:46 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:49:46 --> Controller Class Initialized
DEBUG - 2020-10-15 05:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:49:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:49:46 --> Final output sent to browser
DEBUG - 2020-10-15 05:49:46 --> Total execution time: 0.2926
INFO - 2020-10-15 05:50:24 --> Config Class Initialized
INFO - 2020-10-15 05:50:24 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:24 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:24 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:24 --> URI Class Initialized
INFO - 2020-10-15 05:50:24 --> Router Class Initialized
INFO - 2020-10-15 05:50:24 --> Output Class Initialized
INFO - 2020-10-15 05:50:24 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:24 --> Input Class Initialized
INFO - 2020-10-15 05:50:24 --> Language Class Initialized
INFO - 2020-10-15 05:50:24 --> Language Class Initialized
INFO - 2020-10-15 05:50:24 --> Config Class Initialized
INFO - 2020-10-15 05:50:24 --> Loader Class Initialized
INFO - 2020-10-15 05:50:24 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:24 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:24 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:24 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:24 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:24 --> Controller Class Initialized
DEBUG - 2020-10-15 05:50:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:50:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:50:24 --> Final output sent to browser
DEBUG - 2020-10-15 05:50:24 --> Total execution time: 0.3112
INFO - 2020-10-15 05:50:25 --> Config Class Initialized
INFO - 2020-10-15 05:50:25 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:25 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:25 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:25 --> URI Class Initialized
INFO - 2020-10-15 05:50:25 --> Router Class Initialized
INFO - 2020-10-15 05:50:25 --> Output Class Initialized
INFO - 2020-10-15 05:50:25 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:25 --> Input Class Initialized
INFO - 2020-10-15 05:50:25 --> Language Class Initialized
ERROR - 2020-10-15 05:50:25 --> 404 Page Not Found: ../modules/login/controllers/Login/logout
INFO - 2020-10-15 05:50:47 --> Config Class Initialized
INFO - 2020-10-15 05:50:47 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:47 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:47 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:47 --> URI Class Initialized
INFO - 2020-10-15 05:50:47 --> Router Class Initialized
INFO - 2020-10-15 05:50:47 --> Output Class Initialized
INFO - 2020-10-15 05:50:47 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:47 --> Input Class Initialized
INFO - 2020-10-15 05:50:47 --> Language Class Initialized
INFO - 2020-10-15 05:50:47 --> Language Class Initialized
INFO - 2020-10-15 05:50:47 --> Config Class Initialized
INFO - 2020-10-15 05:50:47 --> Loader Class Initialized
INFO - 2020-10-15 05:50:47 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:47 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:47 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:47 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:47 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:47 --> Controller Class Initialized
INFO - 2020-10-15 05:50:47 --> Config Class Initialized
INFO - 2020-10-15 05:50:47 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:47 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:47 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:47 --> URI Class Initialized
INFO - 2020-10-15 05:50:47 --> Router Class Initialized
INFO - 2020-10-15 05:50:47 --> Output Class Initialized
INFO - 2020-10-15 05:50:47 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:47 --> Input Class Initialized
INFO - 2020-10-15 05:50:47 --> Language Class Initialized
INFO - 2020-10-15 05:50:47 --> Language Class Initialized
INFO - 2020-10-15 05:50:47 --> Config Class Initialized
INFO - 2020-10-15 05:50:47 --> Loader Class Initialized
INFO - 2020-10-15 05:50:47 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:47 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:47 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:47 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:47 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:47 --> Controller Class Initialized
DEBUG - 2020-10-15 05:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:50:47 --> Final output sent to browser
DEBUG - 2020-10-15 05:50:47 --> Total execution time: 0.3411
INFO - 2020-10-15 05:50:49 --> Config Class Initialized
INFO - 2020-10-15 05:50:49 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:49 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:49 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:49 --> URI Class Initialized
INFO - 2020-10-15 05:50:49 --> Router Class Initialized
INFO - 2020-10-15 05:50:49 --> Output Class Initialized
INFO - 2020-10-15 05:50:49 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:49 --> Input Class Initialized
INFO - 2020-10-15 05:50:49 --> Language Class Initialized
INFO - 2020-10-15 05:50:49 --> Language Class Initialized
INFO - 2020-10-15 05:50:49 --> Config Class Initialized
INFO - 2020-10-15 05:50:49 --> Loader Class Initialized
INFO - 2020-10-15 05:50:49 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:49 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:49 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:49 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:49 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:49 --> Controller Class Initialized
INFO - 2020-10-15 05:50:49 --> Config Class Initialized
INFO - 2020-10-15 05:50:49 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:49 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:49 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:49 --> URI Class Initialized
INFO - 2020-10-15 05:50:49 --> Router Class Initialized
INFO - 2020-10-15 05:50:49 --> Output Class Initialized
INFO - 2020-10-15 05:50:49 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:49 --> Input Class Initialized
INFO - 2020-10-15 05:50:49 --> Language Class Initialized
INFO - 2020-10-15 05:50:49 --> Language Class Initialized
INFO - 2020-10-15 05:50:49 --> Config Class Initialized
INFO - 2020-10-15 05:50:49 --> Loader Class Initialized
INFO - 2020-10-15 05:50:49 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:49 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:49 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:49 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:49 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:49 --> Controller Class Initialized
DEBUG - 2020-10-15 05:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:50:49 --> Final output sent to browser
DEBUG - 2020-10-15 05:50:49 --> Total execution time: 0.2798
INFO - 2020-10-15 05:50:50 --> Config Class Initialized
INFO - 2020-10-15 05:50:50 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:50 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:50 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:50 --> URI Class Initialized
INFO - 2020-10-15 05:50:50 --> Router Class Initialized
INFO - 2020-10-15 05:50:50 --> Output Class Initialized
INFO - 2020-10-15 05:50:50 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:50 --> Input Class Initialized
INFO - 2020-10-15 05:50:50 --> Language Class Initialized
INFO - 2020-10-15 05:50:50 --> Language Class Initialized
INFO - 2020-10-15 05:50:50 --> Config Class Initialized
INFO - 2020-10-15 05:50:50 --> Loader Class Initialized
INFO - 2020-10-15 05:50:50 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:50 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:50 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:50 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:50 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:50 --> Controller Class Initialized
INFO - 2020-10-15 05:50:50 --> Config Class Initialized
INFO - 2020-10-15 05:50:50 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:50 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:50 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:50 --> URI Class Initialized
INFO - 2020-10-15 05:50:50 --> Router Class Initialized
INFO - 2020-10-15 05:50:50 --> Output Class Initialized
INFO - 2020-10-15 05:50:50 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:50 --> Input Class Initialized
INFO - 2020-10-15 05:50:50 --> Language Class Initialized
INFO - 2020-10-15 05:50:50 --> Language Class Initialized
INFO - 2020-10-15 05:50:50 --> Config Class Initialized
INFO - 2020-10-15 05:50:50 --> Loader Class Initialized
INFO - 2020-10-15 05:50:50 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:50 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:50 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:50 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:50 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:50 --> Controller Class Initialized
DEBUG - 2020-10-15 05:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:50:50 --> Final output sent to browser
DEBUG - 2020-10-15 05:50:50 --> Total execution time: 0.3043
INFO - 2020-10-15 05:50:54 --> Config Class Initialized
INFO - 2020-10-15 05:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:54 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:54 --> URI Class Initialized
INFO - 2020-10-15 05:50:54 --> Router Class Initialized
INFO - 2020-10-15 05:50:54 --> Output Class Initialized
INFO - 2020-10-15 05:50:54 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:54 --> Input Class Initialized
INFO - 2020-10-15 05:50:54 --> Language Class Initialized
INFO - 2020-10-15 05:50:54 --> Language Class Initialized
INFO - 2020-10-15 05:50:54 --> Config Class Initialized
INFO - 2020-10-15 05:50:54 --> Loader Class Initialized
INFO - 2020-10-15 05:50:54 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:54 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:54 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:54 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:54 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:54 --> Controller Class Initialized
INFO - 2020-10-15 05:50:54 --> Config Class Initialized
INFO - 2020-10-15 05:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:50:54 --> Utf8 Class Initialized
INFO - 2020-10-15 05:50:54 --> URI Class Initialized
INFO - 2020-10-15 05:50:54 --> Router Class Initialized
INFO - 2020-10-15 05:50:54 --> Output Class Initialized
INFO - 2020-10-15 05:50:54 --> Security Class Initialized
DEBUG - 2020-10-15 05:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:50:54 --> Input Class Initialized
INFO - 2020-10-15 05:50:54 --> Language Class Initialized
INFO - 2020-10-15 05:50:54 --> Language Class Initialized
INFO - 2020-10-15 05:50:54 --> Config Class Initialized
INFO - 2020-10-15 05:50:54 --> Loader Class Initialized
INFO - 2020-10-15 05:50:54 --> Helper loaded: url_helper
INFO - 2020-10-15 05:50:54 --> Helper loaded: file_helper
INFO - 2020-10-15 05:50:54 --> Helper loaded: form_helper
INFO - 2020-10-15 05:50:54 --> Helper loaded: my_helper
INFO - 2020-10-15 05:50:54 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:50:54 --> Controller Class Initialized
DEBUG - 2020-10-15 05:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:50:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:50:54 --> Final output sent to browser
DEBUG - 2020-10-15 05:50:54 --> Total execution time: 0.2832
INFO - 2020-10-15 05:51:22 --> Config Class Initialized
INFO - 2020-10-15 05:51:22 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:51:22 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:51:22 --> Utf8 Class Initialized
INFO - 2020-10-15 05:51:22 --> URI Class Initialized
INFO - 2020-10-15 05:51:22 --> Router Class Initialized
INFO - 2020-10-15 05:51:22 --> Output Class Initialized
INFO - 2020-10-15 05:51:22 --> Security Class Initialized
DEBUG - 2020-10-15 05:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:51:22 --> Input Class Initialized
INFO - 2020-10-15 05:51:22 --> Language Class Initialized
INFO - 2020-10-15 05:51:22 --> Language Class Initialized
INFO - 2020-10-15 05:51:22 --> Config Class Initialized
INFO - 2020-10-15 05:51:22 --> Loader Class Initialized
INFO - 2020-10-15 05:51:22 --> Helper loaded: url_helper
INFO - 2020-10-15 05:51:22 --> Helper loaded: file_helper
INFO - 2020-10-15 05:51:22 --> Helper loaded: form_helper
INFO - 2020-10-15 05:51:22 --> Helper loaded: my_helper
INFO - 2020-10-15 05:51:22 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:51:22 --> Controller Class Initialized
DEBUG - 2020-10-15 05:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:51:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:51:22 --> Final output sent to browser
DEBUG - 2020-10-15 05:51:22 --> Total execution time: 0.3422
INFO - 2020-10-15 05:51:24 --> Config Class Initialized
INFO - 2020-10-15 05:51:24 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:51:24 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:51:24 --> Utf8 Class Initialized
INFO - 2020-10-15 05:51:24 --> URI Class Initialized
INFO - 2020-10-15 05:51:24 --> Router Class Initialized
INFO - 2020-10-15 05:51:24 --> Output Class Initialized
INFO - 2020-10-15 05:51:24 --> Security Class Initialized
DEBUG - 2020-10-15 05:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:51:24 --> Input Class Initialized
INFO - 2020-10-15 05:51:24 --> Language Class Initialized
INFO - 2020-10-15 05:51:24 --> Language Class Initialized
INFO - 2020-10-15 05:51:24 --> Config Class Initialized
INFO - 2020-10-15 05:51:24 --> Loader Class Initialized
INFO - 2020-10-15 05:51:24 --> Helper loaded: url_helper
INFO - 2020-10-15 05:51:24 --> Helper loaded: file_helper
INFO - 2020-10-15 05:51:24 --> Helper loaded: form_helper
INFO - 2020-10-15 05:51:24 --> Helper loaded: my_helper
INFO - 2020-10-15 05:51:24 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:51:24 --> Controller Class Initialized
ERROR - 2020-10-15 05:51:24 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\login\controllers\Login.php 96
INFO - 2020-10-15 05:51:24 --> Config Class Initialized
INFO - 2020-10-15 05:51:24 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:51:24 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:51:24 --> Utf8 Class Initialized
INFO - 2020-10-15 05:51:24 --> URI Class Initialized
INFO - 2020-10-15 05:51:24 --> Router Class Initialized
INFO - 2020-10-15 05:51:24 --> Output Class Initialized
INFO - 2020-10-15 05:51:24 --> Security Class Initialized
DEBUG - 2020-10-15 05:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:51:24 --> Input Class Initialized
INFO - 2020-10-15 05:51:24 --> Language Class Initialized
INFO - 2020-10-15 05:51:24 --> Language Class Initialized
INFO - 2020-10-15 05:51:24 --> Config Class Initialized
INFO - 2020-10-15 05:51:24 --> Loader Class Initialized
INFO - 2020-10-15 05:51:24 --> Helper loaded: url_helper
INFO - 2020-10-15 05:51:24 --> Helper loaded: file_helper
INFO - 2020-10-15 05:51:24 --> Helper loaded: form_helper
INFO - 2020-10-15 05:51:24 --> Helper loaded: my_helper
INFO - 2020-10-15 05:51:24 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:51:24 --> Controller Class Initialized
DEBUG - 2020-10-15 05:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:51:24 --> Final output sent to browser
DEBUG - 2020-10-15 05:51:24 --> Total execution time: 0.3099
INFO - 2020-10-15 05:51:47 --> Config Class Initialized
INFO - 2020-10-15 05:51:47 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:51:47 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:51:47 --> Utf8 Class Initialized
INFO - 2020-10-15 05:51:47 --> URI Class Initialized
INFO - 2020-10-15 05:51:47 --> Router Class Initialized
INFO - 2020-10-15 05:51:47 --> Output Class Initialized
INFO - 2020-10-15 05:51:47 --> Security Class Initialized
DEBUG - 2020-10-15 05:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:51:47 --> Input Class Initialized
INFO - 2020-10-15 05:51:47 --> Language Class Initialized
INFO - 2020-10-15 05:51:47 --> Language Class Initialized
INFO - 2020-10-15 05:51:47 --> Config Class Initialized
INFO - 2020-10-15 05:51:47 --> Loader Class Initialized
INFO - 2020-10-15 05:51:47 --> Helper loaded: url_helper
INFO - 2020-10-15 05:51:47 --> Helper loaded: file_helper
INFO - 2020-10-15 05:51:47 --> Helper loaded: form_helper
INFO - 2020-10-15 05:51:47 --> Helper loaded: my_helper
INFO - 2020-10-15 05:51:47 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:51:47 --> Controller Class Initialized
DEBUG - 2020-10-15 05:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:51:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:51:47 --> Final output sent to browser
DEBUG - 2020-10-15 05:51:47 --> Total execution time: 0.3569
INFO - 2020-10-15 05:51:49 --> Config Class Initialized
INFO - 2020-10-15 05:51:49 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:51:49 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:51:49 --> Utf8 Class Initialized
INFO - 2020-10-15 05:51:49 --> URI Class Initialized
INFO - 2020-10-15 05:51:49 --> Router Class Initialized
INFO - 2020-10-15 05:51:49 --> Output Class Initialized
INFO - 2020-10-15 05:51:49 --> Security Class Initialized
DEBUG - 2020-10-15 05:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:51:49 --> Input Class Initialized
INFO - 2020-10-15 05:51:49 --> Language Class Initialized
INFO - 2020-10-15 05:51:49 --> Language Class Initialized
INFO - 2020-10-15 05:51:49 --> Config Class Initialized
INFO - 2020-10-15 05:51:49 --> Loader Class Initialized
INFO - 2020-10-15 05:51:49 --> Helper loaded: url_helper
INFO - 2020-10-15 05:51:49 --> Helper loaded: file_helper
INFO - 2020-10-15 05:51:49 --> Helper loaded: form_helper
INFO - 2020-10-15 05:51:49 --> Helper loaded: my_helper
INFO - 2020-10-15 05:51:49 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:51:49 --> Controller Class Initialized
ERROR - 2020-10-15 05:51:49 --> Severity: Notice --> Undefined variable: data C:\xampp\htdocs\nilai\application\modules\login\controllers\Login.php 96
INFO - 2020-10-15 05:51:49 --> Config Class Initialized
INFO - 2020-10-15 05:51:49 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:51:49 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:51:49 --> Utf8 Class Initialized
INFO - 2020-10-15 05:51:49 --> URI Class Initialized
INFO - 2020-10-15 05:51:49 --> Router Class Initialized
INFO - 2020-10-15 05:51:49 --> Output Class Initialized
INFO - 2020-10-15 05:51:49 --> Security Class Initialized
DEBUG - 2020-10-15 05:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:51:49 --> Input Class Initialized
INFO - 2020-10-15 05:51:49 --> Language Class Initialized
INFO - 2020-10-15 05:51:49 --> Language Class Initialized
INFO - 2020-10-15 05:51:49 --> Config Class Initialized
INFO - 2020-10-15 05:51:49 --> Loader Class Initialized
INFO - 2020-10-15 05:51:49 --> Helper loaded: url_helper
INFO - 2020-10-15 05:51:49 --> Helper loaded: file_helper
INFO - 2020-10-15 05:51:49 --> Helper loaded: form_helper
INFO - 2020-10-15 05:51:49 --> Helper loaded: my_helper
INFO - 2020-10-15 05:51:49 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:51:49 --> Controller Class Initialized
DEBUG - 2020-10-15 05:51:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:51:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:51:49 --> Final output sent to browser
DEBUG - 2020-10-15 05:51:49 --> Total execution time: 0.2883
INFO - 2020-10-15 05:52:03 --> Config Class Initialized
INFO - 2020-10-15 05:52:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:52:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:52:03 --> Utf8 Class Initialized
INFO - 2020-10-15 05:52:03 --> URI Class Initialized
INFO - 2020-10-15 05:52:03 --> Router Class Initialized
INFO - 2020-10-15 05:52:03 --> Output Class Initialized
INFO - 2020-10-15 05:52:03 --> Security Class Initialized
DEBUG - 2020-10-15 05:52:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:52:03 --> Input Class Initialized
INFO - 2020-10-15 05:52:04 --> Language Class Initialized
INFO - 2020-10-15 05:52:04 --> Language Class Initialized
INFO - 2020-10-15 05:52:04 --> Config Class Initialized
INFO - 2020-10-15 05:52:04 --> Loader Class Initialized
INFO - 2020-10-15 05:52:04 --> Helper loaded: url_helper
INFO - 2020-10-15 05:52:04 --> Helper loaded: file_helper
INFO - 2020-10-15 05:52:04 --> Helper loaded: form_helper
INFO - 2020-10-15 05:52:04 --> Helper loaded: my_helper
INFO - 2020-10-15 05:52:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:52:04 --> Controller Class Initialized
DEBUG - 2020-10-15 05:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:52:04 --> Final output sent to browser
DEBUG - 2020-10-15 05:52:04 --> Total execution time: 0.3455
INFO - 2020-10-15 05:52:05 --> Config Class Initialized
INFO - 2020-10-15 05:52:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:52:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:52:05 --> Utf8 Class Initialized
INFO - 2020-10-15 05:52:05 --> URI Class Initialized
INFO - 2020-10-15 05:52:05 --> Router Class Initialized
INFO - 2020-10-15 05:52:05 --> Output Class Initialized
INFO - 2020-10-15 05:52:05 --> Security Class Initialized
DEBUG - 2020-10-15 05:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:52:05 --> Input Class Initialized
INFO - 2020-10-15 05:52:05 --> Language Class Initialized
INFO - 2020-10-15 05:52:05 --> Language Class Initialized
INFO - 2020-10-15 05:52:05 --> Config Class Initialized
INFO - 2020-10-15 05:52:05 --> Loader Class Initialized
INFO - 2020-10-15 05:52:05 --> Helper loaded: url_helper
INFO - 2020-10-15 05:52:05 --> Helper loaded: file_helper
INFO - 2020-10-15 05:52:05 --> Helper loaded: form_helper
INFO - 2020-10-15 05:52:05 --> Helper loaded: my_helper
INFO - 2020-10-15 05:52:05 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:52:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:52:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:52:05 --> Controller Class Initialized
INFO - 2020-10-15 05:52:05 --> Config Class Initialized
INFO - 2020-10-15 05:52:05 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:52:05 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:52:05 --> Utf8 Class Initialized
INFO - 2020-10-15 05:52:05 --> URI Class Initialized
INFO - 2020-10-15 05:52:05 --> Router Class Initialized
INFO - 2020-10-15 05:52:05 --> Output Class Initialized
INFO - 2020-10-15 05:52:05 --> Security Class Initialized
DEBUG - 2020-10-15 05:52:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:52:05 --> Input Class Initialized
INFO - 2020-10-15 05:52:05 --> Language Class Initialized
INFO - 2020-10-15 05:52:05 --> Language Class Initialized
INFO - 2020-10-15 05:52:05 --> Config Class Initialized
INFO - 2020-10-15 05:52:05 --> Loader Class Initialized
INFO - 2020-10-15 05:52:05 --> Helper loaded: url_helper
INFO - 2020-10-15 05:52:06 --> Helper loaded: file_helper
INFO - 2020-10-15 05:52:06 --> Helper loaded: form_helper
INFO - 2020-10-15 05:52:06 --> Helper loaded: my_helper
INFO - 2020-10-15 05:52:06 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:52:06 --> Controller Class Initialized
DEBUG - 2020-10-15 05:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:52:06 --> Final output sent to browser
DEBUG - 2020-10-15 05:52:06 --> Total execution time: 0.3116
INFO - 2020-10-15 05:52:51 --> Config Class Initialized
INFO - 2020-10-15 05:52:51 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:52:51 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:52:51 --> Utf8 Class Initialized
INFO - 2020-10-15 05:52:51 --> URI Class Initialized
INFO - 2020-10-15 05:52:51 --> Router Class Initialized
INFO - 2020-10-15 05:52:51 --> Output Class Initialized
INFO - 2020-10-15 05:52:51 --> Security Class Initialized
DEBUG - 2020-10-15 05:52:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:52:51 --> Input Class Initialized
INFO - 2020-10-15 05:52:51 --> Language Class Initialized
INFO - 2020-10-15 05:52:51 --> Language Class Initialized
INFO - 2020-10-15 05:52:51 --> Config Class Initialized
INFO - 2020-10-15 05:52:51 --> Loader Class Initialized
INFO - 2020-10-15 05:52:51 --> Helper loaded: url_helper
INFO - 2020-10-15 05:52:51 --> Helper loaded: file_helper
INFO - 2020-10-15 05:52:51 --> Helper loaded: form_helper
INFO - 2020-10-15 05:52:51 --> Helper loaded: my_helper
INFO - 2020-10-15 05:52:51 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:52:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:52:51 --> Controller Class Initialized
DEBUG - 2020-10-15 05:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:52:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:52:51 --> Final output sent to browser
DEBUG - 2020-10-15 05:52:51 --> Total execution time: 0.3200
INFO - 2020-10-15 05:52:52 --> Config Class Initialized
INFO - 2020-10-15 05:52:52 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:52:52 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:52:52 --> Utf8 Class Initialized
INFO - 2020-10-15 05:52:52 --> URI Class Initialized
INFO - 2020-10-15 05:52:52 --> Router Class Initialized
INFO - 2020-10-15 05:52:52 --> Output Class Initialized
INFO - 2020-10-15 05:52:52 --> Security Class Initialized
DEBUG - 2020-10-15 05:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:52:52 --> Input Class Initialized
INFO - 2020-10-15 05:52:52 --> Language Class Initialized
INFO - 2020-10-15 05:52:52 --> Language Class Initialized
INFO - 2020-10-15 05:52:52 --> Config Class Initialized
INFO - 2020-10-15 05:52:52 --> Loader Class Initialized
INFO - 2020-10-15 05:52:52 --> Helper loaded: url_helper
INFO - 2020-10-15 05:52:52 --> Helper loaded: file_helper
INFO - 2020-10-15 05:52:52 --> Helper loaded: form_helper
INFO - 2020-10-15 05:52:52 --> Helper loaded: my_helper
INFO - 2020-10-15 05:52:53 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:52:53 --> Controller Class Initialized
INFO - 2020-10-15 05:52:53 --> Config Class Initialized
INFO - 2020-10-15 05:52:53 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:52:53 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:52:53 --> Utf8 Class Initialized
INFO - 2020-10-15 05:52:53 --> URI Class Initialized
INFO - 2020-10-15 05:52:53 --> Router Class Initialized
INFO - 2020-10-15 05:52:53 --> Output Class Initialized
INFO - 2020-10-15 05:52:53 --> Security Class Initialized
DEBUG - 2020-10-15 05:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:52:53 --> Input Class Initialized
INFO - 2020-10-15 05:52:53 --> Language Class Initialized
ERROR - 2020-10-15 05:52:53 --> 404 Page Not Found: /index
INFO - 2020-10-15 05:53:05 --> Config Class Initialized
INFO - 2020-10-15 05:53:06 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:53:06 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:53:06 --> Utf8 Class Initialized
INFO - 2020-10-15 05:53:06 --> URI Class Initialized
INFO - 2020-10-15 05:53:06 --> Router Class Initialized
INFO - 2020-10-15 05:53:06 --> Output Class Initialized
INFO - 2020-10-15 05:53:06 --> Security Class Initialized
DEBUG - 2020-10-15 05:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:53:06 --> Input Class Initialized
INFO - 2020-10-15 05:53:06 --> Language Class Initialized
ERROR - 2020-10-15 05:53:06 --> 404 Page Not Found: /index
INFO - 2020-10-15 05:53:09 --> Config Class Initialized
INFO - 2020-10-15 05:53:09 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:53:09 --> Utf8 Class Initialized
INFO - 2020-10-15 05:53:09 --> URI Class Initialized
DEBUG - 2020-10-15 05:53:09 --> No URI present. Default controller set.
INFO - 2020-10-15 05:53:09 --> Router Class Initialized
INFO - 2020-10-15 05:53:09 --> Output Class Initialized
INFO - 2020-10-15 05:53:09 --> Security Class Initialized
DEBUG - 2020-10-15 05:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:53:09 --> Input Class Initialized
INFO - 2020-10-15 05:53:09 --> Language Class Initialized
INFO - 2020-10-15 05:53:09 --> Language Class Initialized
INFO - 2020-10-15 05:53:09 --> Config Class Initialized
INFO - 2020-10-15 05:53:09 --> Loader Class Initialized
INFO - 2020-10-15 05:53:09 --> Helper loaded: url_helper
INFO - 2020-10-15 05:53:09 --> Helper loaded: file_helper
INFO - 2020-10-15 05:53:09 --> Helper loaded: form_helper
INFO - 2020-10-15 05:53:09 --> Helper loaded: my_helper
INFO - 2020-10-15 05:53:09 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:53:09 --> Controller Class Initialized
DEBUG - 2020-10-15 05:53:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:53:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:53:09 --> Final output sent to browser
DEBUG - 2020-10-15 05:53:09 --> Total execution time: 0.3321
INFO - 2020-10-15 05:53:10 --> Config Class Initialized
INFO - 2020-10-15 05:53:10 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:53:10 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:53:10 --> Utf8 Class Initialized
INFO - 2020-10-15 05:53:11 --> URI Class Initialized
INFO - 2020-10-15 05:53:11 --> Router Class Initialized
INFO - 2020-10-15 05:53:11 --> Output Class Initialized
INFO - 2020-10-15 05:53:11 --> Security Class Initialized
DEBUG - 2020-10-15 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:53:11 --> Input Class Initialized
INFO - 2020-10-15 05:53:11 --> Language Class Initialized
INFO - 2020-10-15 05:53:11 --> Language Class Initialized
INFO - 2020-10-15 05:53:11 --> Config Class Initialized
INFO - 2020-10-15 05:53:11 --> Loader Class Initialized
INFO - 2020-10-15 05:53:11 --> Helper loaded: url_helper
INFO - 2020-10-15 05:53:11 --> Helper loaded: file_helper
INFO - 2020-10-15 05:53:11 --> Helper loaded: form_helper
INFO - 2020-10-15 05:53:11 --> Helper loaded: my_helper
INFO - 2020-10-15 05:53:11 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:53:11 --> Controller Class Initialized
INFO - 2020-10-15 05:53:11 --> Config Class Initialized
INFO - 2020-10-15 05:53:11 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:53:11 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:53:11 --> Utf8 Class Initialized
INFO - 2020-10-15 05:53:11 --> URI Class Initialized
DEBUG - 2020-10-15 05:53:11 --> No URI present. Default controller set.
INFO - 2020-10-15 05:53:11 --> Router Class Initialized
INFO - 2020-10-15 05:53:11 --> Output Class Initialized
INFO - 2020-10-15 05:53:11 --> Security Class Initialized
DEBUG - 2020-10-15 05:53:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:53:11 --> Input Class Initialized
INFO - 2020-10-15 05:53:11 --> Language Class Initialized
INFO - 2020-10-15 05:53:11 --> Language Class Initialized
INFO - 2020-10-15 05:53:11 --> Config Class Initialized
INFO - 2020-10-15 05:53:11 --> Loader Class Initialized
INFO - 2020-10-15 05:53:11 --> Helper loaded: url_helper
INFO - 2020-10-15 05:53:11 --> Helper loaded: file_helper
INFO - 2020-10-15 05:53:11 --> Helper loaded: form_helper
INFO - 2020-10-15 05:53:11 --> Helper loaded: my_helper
INFO - 2020-10-15 05:53:11 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:53:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:53:11 --> Controller Class Initialized
DEBUG - 2020-10-15 05:53:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:53:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:53:11 --> Final output sent to browser
DEBUG - 2020-10-15 05:53:11 --> Total execution time: 0.3230
INFO - 2020-10-15 05:53:48 --> Config Class Initialized
INFO - 2020-10-15 05:53:48 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:53:48 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:53:48 --> Utf8 Class Initialized
INFO - 2020-10-15 05:53:48 --> URI Class Initialized
DEBUG - 2020-10-15 05:53:48 --> No URI present. Default controller set.
INFO - 2020-10-15 05:53:48 --> Router Class Initialized
INFO - 2020-10-15 05:53:48 --> Output Class Initialized
INFO - 2020-10-15 05:53:48 --> Security Class Initialized
DEBUG - 2020-10-15 05:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:53:48 --> Input Class Initialized
INFO - 2020-10-15 05:53:48 --> Language Class Initialized
INFO - 2020-10-15 05:53:48 --> Language Class Initialized
INFO - 2020-10-15 05:53:48 --> Config Class Initialized
INFO - 2020-10-15 05:53:48 --> Loader Class Initialized
INFO - 2020-10-15 05:53:48 --> Helper loaded: url_helper
INFO - 2020-10-15 05:53:48 --> Helper loaded: file_helper
INFO - 2020-10-15 05:53:48 --> Helper loaded: form_helper
INFO - 2020-10-15 05:53:48 --> Helper loaded: my_helper
INFO - 2020-10-15 05:53:48 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:53:48 --> Controller Class Initialized
DEBUG - 2020-10-15 05:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:53:48 --> Final output sent to browser
DEBUG - 2020-10-15 05:53:48 --> Total execution time: 0.3125
INFO - 2020-10-15 05:53:49 --> Config Class Initialized
INFO - 2020-10-15 05:53:49 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:53:49 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:53:49 --> Utf8 Class Initialized
INFO - 2020-10-15 05:53:49 --> URI Class Initialized
INFO - 2020-10-15 05:53:49 --> Router Class Initialized
INFO - 2020-10-15 05:53:49 --> Output Class Initialized
INFO - 2020-10-15 05:53:49 --> Security Class Initialized
DEBUG - 2020-10-15 05:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:53:49 --> Input Class Initialized
INFO - 2020-10-15 05:53:49 --> Language Class Initialized
INFO - 2020-10-15 05:53:49 --> Language Class Initialized
INFO - 2020-10-15 05:53:49 --> Config Class Initialized
INFO - 2020-10-15 05:53:49 --> Loader Class Initialized
INFO - 2020-10-15 05:53:49 --> Helper loaded: url_helper
INFO - 2020-10-15 05:53:49 --> Helper loaded: file_helper
INFO - 2020-10-15 05:53:49 --> Helper loaded: form_helper
INFO - 2020-10-15 05:53:49 --> Helper loaded: my_helper
INFO - 2020-10-15 05:53:49 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:53:49 --> Controller Class Initialized
INFO - 2020-10-15 05:53:49 --> Helper loaded: cookie_helper
INFO - 2020-10-15 05:53:49 --> Config Class Initialized
INFO - 2020-10-15 05:53:49 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:53:49 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:53:49 --> Utf8 Class Initialized
INFO - 2020-10-15 05:53:49 --> URI Class Initialized
INFO - 2020-10-15 05:53:49 --> Router Class Initialized
INFO - 2020-10-15 05:53:49 --> Output Class Initialized
INFO - 2020-10-15 05:53:49 --> Security Class Initialized
DEBUG - 2020-10-15 05:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:53:49 --> Input Class Initialized
INFO - 2020-10-15 05:53:49 --> Language Class Initialized
INFO - 2020-10-15 05:53:50 --> Language Class Initialized
INFO - 2020-10-15 05:53:50 --> Config Class Initialized
INFO - 2020-10-15 05:53:50 --> Loader Class Initialized
INFO - 2020-10-15 05:53:50 --> Helper loaded: url_helper
INFO - 2020-10-15 05:53:50 --> Helper loaded: file_helper
INFO - 2020-10-15 05:53:50 --> Helper loaded: form_helper
INFO - 2020-10-15 05:53:50 --> Helper loaded: my_helper
INFO - 2020-10-15 05:53:50 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:53:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:53:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:53:50 --> Controller Class Initialized
DEBUG - 2020-10-15 05:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:53:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:53:50 --> Final output sent to browser
DEBUG - 2020-10-15 05:53:50 --> Total execution time: 0.3265
INFO - 2020-10-15 05:54:01 --> Config Class Initialized
INFO - 2020-10-15 05:54:01 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:54:01 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:54:01 --> Utf8 Class Initialized
INFO - 2020-10-15 05:54:01 --> URI Class Initialized
INFO - 2020-10-15 05:54:01 --> Router Class Initialized
INFO - 2020-10-15 05:54:02 --> Output Class Initialized
INFO - 2020-10-15 05:54:02 --> Security Class Initialized
DEBUG - 2020-10-15 05:54:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:54:02 --> Input Class Initialized
INFO - 2020-10-15 05:54:02 --> Language Class Initialized
INFO - 2020-10-15 05:54:02 --> Language Class Initialized
INFO - 2020-10-15 05:54:02 --> Config Class Initialized
INFO - 2020-10-15 05:54:02 --> Loader Class Initialized
INFO - 2020-10-15 05:54:02 --> Helper loaded: url_helper
INFO - 2020-10-15 05:54:02 --> Helper loaded: file_helper
INFO - 2020-10-15 05:54:02 --> Helper loaded: form_helper
INFO - 2020-10-15 05:54:02 --> Helper loaded: my_helper
INFO - 2020-10-15 05:54:02 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:54:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:54:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:54:02 --> Controller Class Initialized
DEBUG - 2020-10-15 05:54:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:54:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:54:02 --> Final output sent to browser
DEBUG - 2020-10-15 05:54:02 --> Total execution time: 0.3179
INFO - 2020-10-15 05:54:03 --> Config Class Initialized
INFO - 2020-10-15 05:54:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:54:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:54:03 --> Utf8 Class Initialized
INFO - 2020-10-15 05:54:03 --> URI Class Initialized
INFO - 2020-10-15 05:54:03 --> Router Class Initialized
INFO - 2020-10-15 05:54:03 --> Output Class Initialized
INFO - 2020-10-15 05:54:03 --> Security Class Initialized
DEBUG - 2020-10-15 05:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:54:03 --> Input Class Initialized
INFO - 2020-10-15 05:54:03 --> Language Class Initialized
INFO - 2020-10-15 05:54:03 --> Language Class Initialized
INFO - 2020-10-15 05:54:03 --> Config Class Initialized
INFO - 2020-10-15 05:54:03 --> Loader Class Initialized
INFO - 2020-10-15 05:54:03 --> Helper loaded: url_helper
INFO - 2020-10-15 05:54:03 --> Helper loaded: file_helper
INFO - 2020-10-15 05:54:03 --> Helper loaded: form_helper
INFO - 2020-10-15 05:54:03 --> Helper loaded: my_helper
INFO - 2020-10-15 05:54:03 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:54:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:54:03 --> Controller Class Initialized
INFO - 2020-10-15 05:54:03 --> Helper loaded: cookie_helper
INFO - 2020-10-15 05:54:03 --> Config Class Initialized
INFO - 2020-10-15 05:54:03 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:54:03 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:54:03 --> Utf8 Class Initialized
INFO - 2020-10-15 05:54:03 --> URI Class Initialized
INFO - 2020-10-15 05:54:03 --> Router Class Initialized
INFO - 2020-10-15 05:54:03 --> Output Class Initialized
INFO - 2020-10-15 05:54:04 --> Security Class Initialized
DEBUG - 2020-10-15 05:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:54:04 --> Input Class Initialized
INFO - 2020-10-15 05:54:04 --> Language Class Initialized
INFO - 2020-10-15 05:54:04 --> Language Class Initialized
INFO - 2020-10-15 05:54:04 --> Config Class Initialized
INFO - 2020-10-15 05:54:04 --> Loader Class Initialized
INFO - 2020-10-15 05:54:04 --> Helper loaded: url_helper
INFO - 2020-10-15 05:54:04 --> Helper loaded: file_helper
INFO - 2020-10-15 05:54:04 --> Helper loaded: form_helper
INFO - 2020-10-15 05:54:04 --> Helper loaded: my_helper
INFO - 2020-10-15 05:54:04 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:54:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:54:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:54:04 --> Controller Class Initialized
DEBUG - 2020-10-15 05:54:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:54:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:54:04 --> Final output sent to browser
DEBUG - 2020-10-15 05:54:04 --> Total execution time: 0.2939
INFO - 2020-10-15 05:55:50 --> Config Class Initialized
INFO - 2020-10-15 05:55:50 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:55:50 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:55:50 --> Utf8 Class Initialized
INFO - 2020-10-15 05:55:50 --> URI Class Initialized
INFO - 2020-10-15 05:55:50 --> Router Class Initialized
INFO - 2020-10-15 05:55:50 --> Output Class Initialized
INFO - 2020-10-15 05:55:50 --> Security Class Initialized
DEBUG - 2020-10-15 05:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:55:50 --> Input Class Initialized
INFO - 2020-10-15 05:55:50 --> Language Class Initialized
INFO - 2020-10-15 05:55:50 --> Language Class Initialized
INFO - 2020-10-15 05:55:50 --> Config Class Initialized
INFO - 2020-10-15 05:55:50 --> Loader Class Initialized
INFO - 2020-10-15 05:55:51 --> Helper loaded: url_helper
INFO - 2020-10-15 05:55:51 --> Helper loaded: file_helper
INFO - 2020-10-15 05:55:51 --> Helper loaded: form_helper
INFO - 2020-10-15 05:55:51 --> Helper loaded: my_helper
INFO - 2020-10-15 05:55:51 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:55:51 --> Controller Class Initialized
DEBUG - 2020-10-15 05:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:55:51 --> Final output sent to browser
DEBUG - 2020-10-15 05:55:51 --> Total execution time: 0.3783
INFO - 2020-10-15 05:55:52 --> Config Class Initialized
INFO - 2020-10-15 05:55:52 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:55:52 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:55:52 --> Utf8 Class Initialized
INFO - 2020-10-15 05:55:52 --> URI Class Initialized
INFO - 2020-10-15 05:55:52 --> Router Class Initialized
INFO - 2020-10-15 05:55:52 --> Output Class Initialized
INFO - 2020-10-15 05:55:52 --> Security Class Initialized
DEBUG - 2020-10-15 05:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:55:52 --> Input Class Initialized
INFO - 2020-10-15 05:55:52 --> Language Class Initialized
INFO - 2020-10-15 05:55:52 --> Language Class Initialized
INFO - 2020-10-15 05:55:52 --> Config Class Initialized
INFO - 2020-10-15 05:55:52 --> Loader Class Initialized
INFO - 2020-10-15 05:55:52 --> Helper loaded: url_helper
INFO - 2020-10-15 05:55:52 --> Helper loaded: file_helper
INFO - 2020-10-15 05:55:52 --> Helper loaded: form_helper
INFO - 2020-10-15 05:55:52 --> Helper loaded: my_helper
INFO - 2020-10-15 05:55:52 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:55:52 --> Controller Class Initialized
INFO - 2020-10-15 05:55:52 --> Config Class Initialized
INFO - 2020-10-15 05:55:52 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:55:52 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:55:52 --> Utf8 Class Initialized
INFO - 2020-10-15 05:55:52 --> URI Class Initialized
INFO - 2020-10-15 05:55:52 --> Router Class Initialized
INFO - 2020-10-15 05:55:52 --> Output Class Initialized
INFO - 2020-10-15 05:55:52 --> Security Class Initialized
DEBUG - 2020-10-15 05:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:55:52 --> Input Class Initialized
INFO - 2020-10-15 05:55:52 --> Language Class Initialized
INFO - 2020-10-15 05:55:52 --> Language Class Initialized
INFO - 2020-10-15 05:55:52 --> Config Class Initialized
INFO - 2020-10-15 05:55:52 --> Loader Class Initialized
INFO - 2020-10-15 05:55:52 --> Helper loaded: url_helper
INFO - 2020-10-15 05:55:52 --> Helper loaded: file_helper
INFO - 2020-10-15 05:55:52 --> Helper loaded: form_helper
INFO - 2020-10-15 05:55:52 --> Helper loaded: my_helper
INFO - 2020-10-15 05:55:52 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:55:52 --> Controller Class Initialized
DEBUG - 2020-10-15 05:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:55:52 --> Final output sent to browser
DEBUG - 2020-10-15 05:55:52 --> Total execution time: 0.2999
INFO - 2020-10-15 05:55:54 --> Config Class Initialized
INFO - 2020-10-15 05:55:54 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:55:54 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:55:54 --> Utf8 Class Initialized
INFO - 2020-10-15 05:55:54 --> URI Class Initialized
INFO - 2020-10-15 05:55:54 --> Router Class Initialized
INFO - 2020-10-15 05:55:54 --> Output Class Initialized
INFO - 2020-10-15 05:55:54 --> Security Class Initialized
DEBUG - 2020-10-15 05:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:55:54 --> Input Class Initialized
INFO - 2020-10-15 05:55:55 --> Language Class Initialized
INFO - 2020-10-15 05:55:55 --> Language Class Initialized
INFO - 2020-10-15 05:55:55 --> Config Class Initialized
INFO - 2020-10-15 05:55:55 --> Loader Class Initialized
INFO - 2020-10-15 05:55:55 --> Helper loaded: url_helper
INFO - 2020-10-15 05:55:55 --> Helper loaded: file_helper
INFO - 2020-10-15 05:55:55 --> Helper loaded: form_helper
INFO - 2020-10-15 05:55:55 --> Helper loaded: my_helper
INFO - 2020-10-15 05:55:55 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:55:55 --> Controller Class Initialized
DEBUG - 2020-10-15 05:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-15 05:55:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:55:55 --> Final output sent to browser
DEBUG - 2020-10-15 05:55:55 --> Total execution time: 0.2954
INFO - 2020-10-15 05:55:56 --> Config Class Initialized
INFO - 2020-10-15 05:55:56 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:55:56 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:55:56 --> Utf8 Class Initialized
INFO - 2020-10-15 05:55:56 --> URI Class Initialized
INFO - 2020-10-15 05:55:56 --> Router Class Initialized
INFO - 2020-10-15 05:55:56 --> Output Class Initialized
INFO - 2020-10-15 05:55:56 --> Security Class Initialized
DEBUG - 2020-10-15 05:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:55:57 --> Input Class Initialized
INFO - 2020-10-15 05:55:57 --> Language Class Initialized
INFO - 2020-10-15 05:55:57 --> Language Class Initialized
INFO - 2020-10-15 05:55:57 --> Config Class Initialized
INFO - 2020-10-15 05:55:57 --> Loader Class Initialized
INFO - 2020-10-15 05:55:57 --> Helper loaded: url_helper
INFO - 2020-10-15 05:55:57 --> Helper loaded: file_helper
INFO - 2020-10-15 05:55:57 --> Helper loaded: form_helper
INFO - 2020-10-15 05:55:57 --> Helper loaded: my_helper
INFO - 2020-10-15 05:55:57 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:55:57 --> Controller Class Initialized
INFO - 2020-10-15 05:55:57 --> Config Class Initialized
INFO - 2020-10-15 05:55:57 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:55:57 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:55:57 --> Utf8 Class Initialized
INFO - 2020-10-15 05:55:57 --> URI Class Initialized
INFO - 2020-10-15 05:55:57 --> Router Class Initialized
INFO - 2020-10-15 05:55:57 --> Output Class Initialized
INFO - 2020-10-15 05:55:57 --> Security Class Initialized
DEBUG - 2020-10-15 05:55:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:55:57 --> Input Class Initialized
INFO - 2020-10-15 05:55:57 --> Language Class Initialized
INFO - 2020-10-15 05:55:57 --> Language Class Initialized
INFO - 2020-10-15 05:55:57 --> Config Class Initialized
INFO - 2020-10-15 05:55:57 --> Loader Class Initialized
INFO - 2020-10-15 05:55:57 --> Helper loaded: url_helper
INFO - 2020-10-15 05:55:57 --> Helper loaded: file_helper
INFO - 2020-10-15 05:55:57 --> Helper loaded: form_helper
INFO - 2020-10-15 05:55:57 --> Helper loaded: my_helper
INFO - 2020-10-15 05:55:57 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:55:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:55:57 --> Controller Class Initialized
DEBUG - 2020-10-15 05:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:55:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:55:57 --> Final output sent to browser
DEBUG - 2020-10-15 05:55:57 --> Total execution time: 0.3174
INFO - 2020-10-15 05:56:14 --> Config Class Initialized
INFO - 2020-10-15 05:56:14 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:56:14 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:56:14 --> Utf8 Class Initialized
INFO - 2020-10-15 05:56:14 --> URI Class Initialized
INFO - 2020-10-15 05:56:14 --> Router Class Initialized
INFO - 2020-10-15 05:56:14 --> Output Class Initialized
INFO - 2020-10-15 05:56:14 --> Security Class Initialized
DEBUG - 2020-10-15 05:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:56:14 --> Input Class Initialized
INFO - 2020-10-15 05:56:14 --> Language Class Initialized
INFO - 2020-10-15 05:56:14 --> Language Class Initialized
INFO - 2020-10-15 05:56:14 --> Config Class Initialized
INFO - 2020-10-15 05:56:14 --> Loader Class Initialized
INFO - 2020-10-15 05:56:14 --> Helper loaded: url_helper
INFO - 2020-10-15 05:56:14 --> Helper loaded: file_helper
INFO - 2020-10-15 05:56:14 --> Helper loaded: form_helper
INFO - 2020-10-15 05:56:14 --> Helper loaded: my_helper
INFO - 2020-10-15 05:56:14 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:56:14 --> Controller Class Initialized
DEBUG - 2020-10-15 05:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:56:14 --> Final output sent to browser
DEBUG - 2020-10-15 05:56:14 --> Total execution time: 0.3611
INFO - 2020-10-15 05:56:15 --> Config Class Initialized
INFO - 2020-10-15 05:56:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:56:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:56:15 --> Utf8 Class Initialized
INFO - 2020-10-15 05:56:15 --> URI Class Initialized
INFO - 2020-10-15 05:56:15 --> Router Class Initialized
INFO - 2020-10-15 05:56:15 --> Output Class Initialized
INFO - 2020-10-15 05:56:15 --> Security Class Initialized
DEBUG - 2020-10-15 05:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:56:15 --> Input Class Initialized
INFO - 2020-10-15 05:56:15 --> Language Class Initialized
INFO - 2020-10-15 05:56:15 --> Language Class Initialized
INFO - 2020-10-15 05:56:15 --> Config Class Initialized
INFO - 2020-10-15 05:56:15 --> Loader Class Initialized
INFO - 2020-10-15 05:56:15 --> Helper loaded: url_helper
INFO - 2020-10-15 05:56:15 --> Helper loaded: file_helper
INFO - 2020-10-15 05:56:15 --> Helper loaded: form_helper
INFO - 2020-10-15 05:56:16 --> Helper loaded: my_helper
INFO - 2020-10-15 05:56:16 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:56:16 --> Controller Class Initialized
INFO - 2020-10-15 05:56:16 --> Helper loaded: cookie_helper
INFO - 2020-10-15 05:56:16 --> Config Class Initialized
INFO - 2020-10-15 05:56:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:56:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:56:16 --> Utf8 Class Initialized
INFO - 2020-10-15 05:56:16 --> URI Class Initialized
INFO - 2020-10-15 05:56:16 --> Router Class Initialized
INFO - 2020-10-15 05:56:16 --> Output Class Initialized
INFO - 2020-10-15 05:56:16 --> Security Class Initialized
DEBUG - 2020-10-15 05:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:56:16 --> Input Class Initialized
INFO - 2020-10-15 05:56:16 --> Language Class Initialized
INFO - 2020-10-15 05:56:16 --> Language Class Initialized
INFO - 2020-10-15 05:56:16 --> Config Class Initialized
INFO - 2020-10-15 05:56:16 --> Loader Class Initialized
INFO - 2020-10-15 05:56:16 --> Helper loaded: url_helper
INFO - 2020-10-15 05:56:16 --> Helper loaded: file_helper
INFO - 2020-10-15 05:56:16 --> Helper loaded: form_helper
INFO - 2020-10-15 05:56:16 --> Helper loaded: my_helper
INFO - 2020-10-15 05:56:16 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:56:16 --> Controller Class Initialized
DEBUG - 2020-10-15 05:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 05:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:56:16 --> Final output sent to browser
DEBUG - 2020-10-15 05:56:16 --> Total execution time: 0.3266
INFO - 2020-10-15 05:56:58 --> Config Class Initialized
INFO - 2020-10-15 05:56:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:56:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:56:58 --> Utf8 Class Initialized
INFO - 2020-10-15 05:56:58 --> URI Class Initialized
INFO - 2020-10-15 05:56:58 --> Router Class Initialized
INFO - 2020-10-15 05:56:58 --> Output Class Initialized
INFO - 2020-10-15 05:56:58 --> Security Class Initialized
DEBUG - 2020-10-15 05:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:56:58 --> Input Class Initialized
INFO - 2020-10-15 05:56:58 --> Language Class Initialized
INFO - 2020-10-15 05:56:58 --> Language Class Initialized
INFO - 2020-10-15 05:56:58 --> Config Class Initialized
INFO - 2020-10-15 05:56:58 --> Loader Class Initialized
INFO - 2020-10-15 05:56:58 --> Helper loaded: url_helper
INFO - 2020-10-15 05:56:58 --> Helper loaded: file_helper
INFO - 2020-10-15 05:56:58 --> Helper loaded: form_helper
INFO - 2020-10-15 05:56:58 --> Helper loaded: my_helper
INFO - 2020-10-15 05:56:58 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:56:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:56:58 --> Controller Class Initialized
DEBUG - 2020-10-15 05:56:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 05:56:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:56:58 --> Final output sent to browser
DEBUG - 2020-10-15 05:56:58 --> Total execution time: 0.2926
INFO - 2020-10-15 05:57:00 --> Config Class Initialized
INFO - 2020-10-15 05:57:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:57:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:57:00 --> Utf8 Class Initialized
INFO - 2020-10-15 05:57:00 --> URI Class Initialized
INFO - 2020-10-15 05:57:00 --> Router Class Initialized
INFO - 2020-10-15 05:57:00 --> Output Class Initialized
INFO - 2020-10-15 05:57:00 --> Security Class Initialized
DEBUG - 2020-10-15 05:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:57:00 --> Input Class Initialized
INFO - 2020-10-15 05:57:00 --> Language Class Initialized
INFO - 2020-10-15 05:57:00 --> Language Class Initialized
INFO - 2020-10-15 05:57:00 --> Config Class Initialized
INFO - 2020-10-15 05:57:00 --> Loader Class Initialized
INFO - 2020-10-15 05:57:00 --> Helper loaded: url_helper
INFO - 2020-10-15 05:57:00 --> Helper loaded: file_helper
INFO - 2020-10-15 05:57:00 --> Helper loaded: form_helper
INFO - 2020-10-15 05:57:00 --> Helper loaded: my_helper
INFO - 2020-10-15 05:57:00 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:57:00 --> Controller Class Initialized
INFO - 2020-10-15 05:57:00 --> Config Class Initialized
INFO - 2020-10-15 05:57:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:57:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:57:00 --> Utf8 Class Initialized
INFO - 2020-10-15 05:57:00 --> URI Class Initialized
INFO - 2020-10-15 05:57:00 --> Router Class Initialized
INFO - 2020-10-15 05:57:00 --> Output Class Initialized
INFO - 2020-10-15 05:57:00 --> Security Class Initialized
DEBUG - 2020-10-15 05:57:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:57:00 --> Input Class Initialized
INFO - 2020-10-15 05:57:00 --> Language Class Initialized
INFO - 2020-10-15 05:57:00 --> Language Class Initialized
INFO - 2020-10-15 05:57:00 --> Config Class Initialized
INFO - 2020-10-15 05:57:00 --> Loader Class Initialized
INFO - 2020-10-15 05:57:00 --> Helper loaded: url_helper
INFO - 2020-10-15 05:57:00 --> Helper loaded: file_helper
INFO - 2020-10-15 05:57:00 --> Helper loaded: form_helper
INFO - 2020-10-15 05:57:00 --> Helper loaded: my_helper
INFO - 2020-10-15 05:57:00 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:57:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:57:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:57:00 --> Controller Class Initialized
DEBUG - 2020-10-15 05:57:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 05:57:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:57:00 --> Final output sent to browser
DEBUG - 2020-10-15 05:57:00 --> Total execution time: 0.3181
INFO - 2020-10-15 05:57:37 --> Config Class Initialized
INFO - 2020-10-15 05:57:37 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:57:37 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:57:37 --> Utf8 Class Initialized
INFO - 2020-10-15 05:57:37 --> URI Class Initialized
INFO - 2020-10-15 05:57:37 --> Router Class Initialized
INFO - 2020-10-15 05:57:37 --> Output Class Initialized
INFO - 2020-10-15 05:57:37 --> Security Class Initialized
DEBUG - 2020-10-15 05:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:57:37 --> Input Class Initialized
INFO - 2020-10-15 05:57:37 --> Language Class Initialized
INFO - 2020-10-15 05:57:37 --> Language Class Initialized
INFO - 2020-10-15 05:57:37 --> Config Class Initialized
INFO - 2020-10-15 05:57:37 --> Loader Class Initialized
INFO - 2020-10-15 05:57:37 --> Helper loaded: url_helper
INFO - 2020-10-15 05:57:37 --> Helper loaded: file_helper
INFO - 2020-10-15 05:57:37 --> Helper loaded: form_helper
INFO - 2020-10-15 05:57:37 --> Helper loaded: my_helper
INFO - 2020-10-15 05:57:37 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:57:37 --> Controller Class Initialized
DEBUG - 2020-10-15 05:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 05:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:57:37 --> Final output sent to browser
DEBUG - 2020-10-15 05:57:37 --> Total execution time: 0.3025
INFO - 2020-10-15 05:57:38 --> Config Class Initialized
INFO - 2020-10-15 05:57:38 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:57:38 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:57:38 --> Utf8 Class Initialized
INFO - 2020-10-15 05:57:38 --> URI Class Initialized
INFO - 2020-10-15 05:57:38 --> Router Class Initialized
INFO - 2020-10-15 05:57:38 --> Output Class Initialized
INFO - 2020-10-15 05:57:38 --> Security Class Initialized
DEBUG - 2020-10-15 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:57:38 --> Input Class Initialized
INFO - 2020-10-15 05:57:38 --> Language Class Initialized
INFO - 2020-10-15 05:57:38 --> Language Class Initialized
INFO - 2020-10-15 05:57:38 --> Config Class Initialized
INFO - 2020-10-15 05:57:38 --> Loader Class Initialized
INFO - 2020-10-15 05:57:38 --> Helper loaded: url_helper
INFO - 2020-10-15 05:57:38 --> Helper loaded: file_helper
INFO - 2020-10-15 05:57:38 --> Helper loaded: form_helper
INFO - 2020-10-15 05:57:38 --> Helper loaded: my_helper
INFO - 2020-10-15 05:57:38 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:57:38 --> Controller Class Initialized
INFO - 2020-10-15 05:57:38 --> Config Class Initialized
INFO - 2020-10-15 05:57:38 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:57:38 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:57:38 --> Utf8 Class Initialized
INFO - 2020-10-15 05:57:38 --> URI Class Initialized
INFO - 2020-10-15 05:57:38 --> Router Class Initialized
INFO - 2020-10-15 05:57:38 --> Output Class Initialized
INFO - 2020-10-15 05:57:38 --> Security Class Initialized
DEBUG - 2020-10-15 05:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:57:38 --> Input Class Initialized
INFO - 2020-10-15 05:57:39 --> Language Class Initialized
ERROR - 2020-10-15 05:57:39 --> 404 Page Not Found: /index
INFO - 2020-10-15 05:57:54 --> Config Class Initialized
INFO - 2020-10-15 05:57:54 --> Hooks Class Initialized
DEBUG - 2020-10-15 05:57:54 --> UTF-8 Support Enabled
INFO - 2020-10-15 05:57:54 --> Utf8 Class Initialized
INFO - 2020-10-15 05:57:55 --> URI Class Initialized
DEBUG - 2020-10-15 05:57:55 --> No URI present. Default controller set.
INFO - 2020-10-15 05:57:55 --> Router Class Initialized
INFO - 2020-10-15 05:57:55 --> Output Class Initialized
INFO - 2020-10-15 05:57:55 --> Security Class Initialized
DEBUG - 2020-10-15 05:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 05:57:55 --> Input Class Initialized
INFO - 2020-10-15 05:57:55 --> Language Class Initialized
INFO - 2020-10-15 05:57:55 --> Language Class Initialized
INFO - 2020-10-15 05:57:55 --> Config Class Initialized
INFO - 2020-10-15 05:57:55 --> Loader Class Initialized
INFO - 2020-10-15 05:57:55 --> Helper loaded: url_helper
INFO - 2020-10-15 05:57:55 --> Helper loaded: file_helper
INFO - 2020-10-15 05:57:55 --> Helper loaded: form_helper
INFO - 2020-10-15 05:57:55 --> Helper loaded: my_helper
INFO - 2020-10-15 05:57:55 --> Database Driver Class Initialized
DEBUG - 2020-10-15 05:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 05:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 05:57:55 --> Controller Class Initialized
DEBUG - 2020-10-15 05:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 05:57:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 05:57:55 --> Final output sent to browser
DEBUG - 2020-10-15 05:57:55 --> Total execution time: 0.3577
INFO - 2020-10-15 06:16:13 --> Config Class Initialized
INFO - 2020-10-15 06:16:13 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:16:13 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:16:13 --> Utf8 Class Initialized
INFO - 2020-10-15 06:16:13 --> URI Class Initialized
DEBUG - 2020-10-15 06:16:13 --> No URI present. Default controller set.
INFO - 2020-10-15 06:16:13 --> Router Class Initialized
INFO - 2020-10-15 06:16:13 --> Output Class Initialized
INFO - 2020-10-15 06:16:13 --> Security Class Initialized
DEBUG - 2020-10-15 06:16:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:16:13 --> Input Class Initialized
INFO - 2020-10-15 06:16:13 --> Language Class Initialized
INFO - 2020-10-15 06:16:13 --> Language Class Initialized
INFO - 2020-10-15 06:16:13 --> Config Class Initialized
INFO - 2020-10-15 06:16:13 --> Loader Class Initialized
INFO - 2020-10-15 06:16:13 --> Helper loaded: url_helper
INFO - 2020-10-15 06:16:13 --> Helper loaded: file_helper
INFO - 2020-10-15 06:16:13 --> Helper loaded: form_helper
INFO - 2020-10-15 06:16:13 --> Helper loaded: my_helper
INFO - 2020-10-15 06:16:13 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:16:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:16:13 --> Controller Class Initialized
DEBUG - 2020-10-15 06:16:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:16:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:16:14 --> Final output sent to browser
DEBUG - 2020-10-15 06:16:14 --> Total execution time: 0.4388
INFO - 2020-10-15 06:16:15 --> Config Class Initialized
INFO - 2020-10-15 06:16:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:16:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:16:15 --> Utf8 Class Initialized
INFO - 2020-10-15 06:16:15 --> URI Class Initialized
INFO - 2020-10-15 06:16:15 --> Router Class Initialized
INFO - 2020-10-15 06:16:15 --> Output Class Initialized
INFO - 2020-10-15 06:16:15 --> Security Class Initialized
DEBUG - 2020-10-15 06:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:16:15 --> Input Class Initialized
INFO - 2020-10-15 06:16:15 --> Language Class Initialized
INFO - 2020-10-15 06:16:15 --> Language Class Initialized
INFO - 2020-10-15 06:16:15 --> Config Class Initialized
INFO - 2020-10-15 06:16:15 --> Loader Class Initialized
INFO - 2020-10-15 06:16:15 --> Helper loaded: url_helper
INFO - 2020-10-15 06:16:15 --> Helper loaded: file_helper
INFO - 2020-10-15 06:16:15 --> Helper loaded: form_helper
INFO - 2020-10-15 06:16:15 --> Helper loaded: my_helper
INFO - 2020-10-15 06:16:15 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:16:15 --> Controller Class Initialized
INFO - 2020-10-15 06:16:15 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:16:15 --> Config Class Initialized
INFO - 2020-10-15 06:16:15 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:16:15 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:16:15 --> Utf8 Class Initialized
INFO - 2020-10-15 06:16:15 --> URI Class Initialized
INFO - 2020-10-15 06:16:15 --> Router Class Initialized
INFO - 2020-10-15 06:16:15 --> Output Class Initialized
INFO - 2020-10-15 06:16:15 --> Security Class Initialized
DEBUG - 2020-10-15 06:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:16:15 --> Input Class Initialized
INFO - 2020-10-15 06:16:15 --> Language Class Initialized
INFO - 2020-10-15 06:16:15 --> Language Class Initialized
INFO - 2020-10-15 06:16:15 --> Config Class Initialized
INFO - 2020-10-15 06:16:15 --> Loader Class Initialized
INFO - 2020-10-15 06:16:15 --> Helper loaded: url_helper
INFO - 2020-10-15 06:16:15 --> Helper loaded: file_helper
INFO - 2020-10-15 06:16:15 --> Helper loaded: form_helper
INFO - 2020-10-15 06:16:15 --> Helper loaded: my_helper
INFO - 2020-10-15 06:16:15 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:16:15 --> Controller Class Initialized
DEBUG - 2020-10-15 06:16:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:16:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:16:15 --> Final output sent to browser
DEBUG - 2020-10-15 06:16:15 --> Total execution time: 0.3409
INFO - 2020-10-15 06:16:54 --> Config Class Initialized
INFO - 2020-10-15 06:16:54 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:16:54 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:16:54 --> Utf8 Class Initialized
INFO - 2020-10-15 06:16:54 --> URI Class Initialized
INFO - 2020-10-15 06:16:54 --> Router Class Initialized
INFO - 2020-10-15 06:16:54 --> Output Class Initialized
INFO - 2020-10-15 06:16:54 --> Security Class Initialized
DEBUG - 2020-10-15 06:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:16:54 --> Input Class Initialized
INFO - 2020-10-15 06:16:54 --> Language Class Initialized
INFO - 2020-10-15 06:16:54 --> Language Class Initialized
INFO - 2020-10-15 06:16:54 --> Config Class Initialized
INFO - 2020-10-15 06:16:54 --> Loader Class Initialized
INFO - 2020-10-15 06:16:54 --> Helper loaded: url_helper
INFO - 2020-10-15 06:16:54 --> Helper loaded: file_helper
INFO - 2020-10-15 06:16:55 --> Helper loaded: form_helper
INFO - 2020-10-15 06:16:55 --> Helper loaded: my_helper
INFO - 2020-10-15 06:16:55 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:16:55 --> Controller Class Initialized
DEBUG - 2020-10-15 06:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:16:55 --> Final output sent to browser
DEBUG - 2020-10-15 06:16:55 --> Total execution time: 0.4300
INFO - 2020-10-15 06:16:56 --> Config Class Initialized
INFO - 2020-10-15 06:16:56 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:16:56 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:16:56 --> Utf8 Class Initialized
INFO - 2020-10-15 06:16:56 --> URI Class Initialized
INFO - 2020-10-15 06:16:56 --> Router Class Initialized
INFO - 2020-10-15 06:16:56 --> Output Class Initialized
INFO - 2020-10-15 06:16:56 --> Security Class Initialized
DEBUG - 2020-10-15 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:16:56 --> Input Class Initialized
INFO - 2020-10-15 06:16:56 --> Language Class Initialized
INFO - 2020-10-15 06:16:56 --> Language Class Initialized
INFO - 2020-10-15 06:16:56 --> Config Class Initialized
INFO - 2020-10-15 06:16:56 --> Loader Class Initialized
INFO - 2020-10-15 06:16:56 --> Helper loaded: url_helper
INFO - 2020-10-15 06:16:56 --> Helper loaded: file_helper
INFO - 2020-10-15 06:16:56 --> Helper loaded: form_helper
INFO - 2020-10-15 06:16:56 --> Helper loaded: my_helper
INFO - 2020-10-15 06:16:56 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:16:56 --> Controller Class Initialized
INFO - 2020-10-15 06:16:56 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:16:56 --> Config Class Initialized
INFO - 2020-10-15 06:16:56 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:16:56 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:16:56 --> Utf8 Class Initialized
INFO - 2020-10-15 06:16:56 --> URI Class Initialized
INFO - 2020-10-15 06:16:56 --> Router Class Initialized
INFO - 2020-10-15 06:16:56 --> Output Class Initialized
INFO - 2020-10-15 06:16:56 --> Security Class Initialized
DEBUG - 2020-10-15 06:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:16:57 --> Input Class Initialized
INFO - 2020-10-15 06:16:57 --> Language Class Initialized
INFO - 2020-10-15 06:16:57 --> Language Class Initialized
INFO - 2020-10-15 06:16:57 --> Config Class Initialized
INFO - 2020-10-15 06:16:57 --> Loader Class Initialized
INFO - 2020-10-15 06:16:57 --> Helper loaded: url_helper
INFO - 2020-10-15 06:16:57 --> Helper loaded: file_helper
INFO - 2020-10-15 06:16:57 --> Helper loaded: form_helper
INFO - 2020-10-15 06:16:57 --> Helper loaded: my_helper
INFO - 2020-10-15 06:16:57 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:16:57 --> Controller Class Initialized
DEBUG - 2020-10-15 06:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:16:57 --> Final output sent to browser
DEBUG - 2020-10-15 06:16:57 --> Total execution time: 0.3357
INFO - 2020-10-15 06:17:07 --> Config Class Initialized
INFO - 2020-10-15 06:17:07 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:07 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:07 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:07 --> URI Class Initialized
INFO - 2020-10-15 06:17:07 --> Router Class Initialized
INFO - 2020-10-15 06:17:07 --> Output Class Initialized
INFO - 2020-10-15 06:17:07 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:07 --> Input Class Initialized
INFO - 2020-10-15 06:17:07 --> Language Class Initialized
INFO - 2020-10-15 06:17:07 --> Language Class Initialized
INFO - 2020-10-15 06:17:07 --> Config Class Initialized
INFO - 2020-10-15 06:17:07 --> Loader Class Initialized
INFO - 2020-10-15 06:17:07 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:07 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:07 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:07 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:07 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:07 --> Controller Class Initialized
DEBUG - 2020-10-15 06:17:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:17:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:17:07 --> Final output sent to browser
DEBUG - 2020-10-15 06:17:07 --> Total execution time: 0.4401
INFO - 2020-10-15 06:17:08 --> Config Class Initialized
INFO - 2020-10-15 06:17:08 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:08 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:08 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:08 --> URI Class Initialized
INFO - 2020-10-15 06:17:08 --> Router Class Initialized
INFO - 2020-10-15 06:17:08 --> Output Class Initialized
INFO - 2020-10-15 06:17:08 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:08 --> Input Class Initialized
INFO - 2020-10-15 06:17:08 --> Language Class Initialized
INFO - 2020-10-15 06:17:08 --> Language Class Initialized
INFO - 2020-10-15 06:17:08 --> Config Class Initialized
INFO - 2020-10-15 06:17:08 --> Loader Class Initialized
INFO - 2020-10-15 06:17:08 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:08 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:08 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:08 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:08 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:08 --> Controller Class Initialized
INFO - 2020-10-15 06:17:08 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:17:08 --> Config Class Initialized
INFO - 2020-10-15 06:17:08 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:09 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:09 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:09 --> URI Class Initialized
INFO - 2020-10-15 06:17:09 --> Router Class Initialized
INFO - 2020-10-15 06:17:09 --> Output Class Initialized
INFO - 2020-10-15 06:17:09 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:09 --> Input Class Initialized
INFO - 2020-10-15 06:17:09 --> Language Class Initialized
INFO - 2020-10-15 06:17:09 --> Language Class Initialized
INFO - 2020-10-15 06:17:09 --> Config Class Initialized
INFO - 2020-10-15 06:17:09 --> Loader Class Initialized
INFO - 2020-10-15 06:17:09 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:09 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:09 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:09 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:09 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:09 --> Controller Class Initialized
DEBUG - 2020-10-15 06:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:17:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:17:09 --> Final output sent to browser
DEBUG - 2020-10-15 06:17:09 --> Total execution time: 0.3306
INFO - 2020-10-15 06:17:32 --> Config Class Initialized
INFO - 2020-10-15 06:17:32 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:32 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:32 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:32 --> URI Class Initialized
INFO - 2020-10-15 06:17:32 --> Router Class Initialized
INFO - 2020-10-15 06:17:32 --> Output Class Initialized
INFO - 2020-10-15 06:17:32 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:32 --> Input Class Initialized
INFO - 2020-10-15 06:17:32 --> Language Class Initialized
INFO - 2020-10-15 06:17:32 --> Language Class Initialized
INFO - 2020-10-15 06:17:32 --> Config Class Initialized
INFO - 2020-10-15 06:17:32 --> Loader Class Initialized
INFO - 2020-10-15 06:17:32 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:32 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:32 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:32 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:32 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:32 --> Controller Class Initialized
INFO - 2020-10-15 06:17:32 --> Config Class Initialized
INFO - 2020-10-15 06:17:32 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:32 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:32 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:32 --> URI Class Initialized
INFO - 2020-10-15 06:17:32 --> Router Class Initialized
INFO - 2020-10-15 06:17:32 --> Output Class Initialized
INFO - 2020-10-15 06:17:32 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:32 --> Input Class Initialized
INFO - 2020-10-15 06:17:32 --> Language Class Initialized
INFO - 2020-10-15 06:17:32 --> Language Class Initialized
INFO - 2020-10-15 06:17:33 --> Config Class Initialized
INFO - 2020-10-15 06:17:33 --> Loader Class Initialized
INFO - 2020-10-15 06:17:33 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:33 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:33 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:33 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:33 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:33 --> Controller Class Initialized
DEBUG - 2020-10-15 06:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:17:33 --> Final output sent to browser
DEBUG - 2020-10-15 06:17:33 --> Total execution time: 0.3891
INFO - 2020-10-15 06:17:34 --> Config Class Initialized
INFO - 2020-10-15 06:17:34 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:34 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:34 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:34 --> URI Class Initialized
INFO - 2020-10-15 06:17:34 --> Router Class Initialized
INFO - 2020-10-15 06:17:34 --> Output Class Initialized
INFO - 2020-10-15 06:17:34 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:34 --> Input Class Initialized
INFO - 2020-10-15 06:17:34 --> Language Class Initialized
INFO - 2020-10-15 06:17:34 --> Language Class Initialized
INFO - 2020-10-15 06:17:34 --> Config Class Initialized
INFO - 2020-10-15 06:17:34 --> Loader Class Initialized
INFO - 2020-10-15 06:17:34 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:34 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:34 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:34 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:34 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:34 --> Controller Class Initialized
DEBUG - 2020-10-15 06:17:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:17:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:17:34 --> Final output sent to browser
DEBUG - 2020-10-15 06:17:34 --> Total execution time: 0.4410
INFO - 2020-10-15 06:17:35 --> Config Class Initialized
INFO - 2020-10-15 06:17:35 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:35 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:35 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:35 --> URI Class Initialized
INFO - 2020-10-15 06:17:35 --> Router Class Initialized
INFO - 2020-10-15 06:17:35 --> Output Class Initialized
INFO - 2020-10-15 06:17:35 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:35 --> Input Class Initialized
INFO - 2020-10-15 06:17:35 --> Language Class Initialized
INFO - 2020-10-15 06:17:35 --> Language Class Initialized
INFO - 2020-10-15 06:17:35 --> Config Class Initialized
INFO - 2020-10-15 06:17:35 --> Loader Class Initialized
INFO - 2020-10-15 06:17:35 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:35 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:35 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:35 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:35 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:35 --> Controller Class Initialized
INFO - 2020-10-15 06:17:35 --> Config Class Initialized
INFO - 2020-10-15 06:17:35 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:35 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:35 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:36 --> URI Class Initialized
INFO - 2020-10-15 06:17:36 --> Router Class Initialized
INFO - 2020-10-15 06:17:36 --> Output Class Initialized
INFO - 2020-10-15 06:17:36 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:36 --> Input Class Initialized
INFO - 2020-10-15 06:17:36 --> Language Class Initialized
INFO - 2020-10-15 06:17:36 --> Language Class Initialized
INFO - 2020-10-15 06:17:36 --> Config Class Initialized
INFO - 2020-10-15 06:17:36 --> Loader Class Initialized
INFO - 2020-10-15 06:17:36 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:36 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:36 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:36 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:36 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:36 --> Controller Class Initialized
DEBUG - 2020-10-15 06:17:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:17:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:17:36 --> Final output sent to browser
DEBUG - 2020-10-15 06:17:36 --> Total execution time: 0.3930
INFO - 2020-10-15 06:17:57 --> Config Class Initialized
INFO - 2020-10-15 06:17:57 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:57 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:57 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:57 --> URI Class Initialized
INFO - 2020-10-15 06:17:57 --> Router Class Initialized
INFO - 2020-10-15 06:17:57 --> Output Class Initialized
INFO - 2020-10-15 06:17:57 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:57 --> Input Class Initialized
INFO - 2020-10-15 06:17:57 --> Language Class Initialized
INFO - 2020-10-15 06:17:57 --> Language Class Initialized
INFO - 2020-10-15 06:17:57 --> Config Class Initialized
INFO - 2020-10-15 06:17:57 --> Loader Class Initialized
INFO - 2020-10-15 06:17:57 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:57 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:57 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:57 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:57 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:57 --> Controller Class Initialized
DEBUG - 2020-10-15 06:17:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:17:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:17:57 --> Final output sent to browser
DEBUG - 2020-10-15 06:17:57 --> Total execution time: 0.4401
INFO - 2020-10-15 06:17:58 --> Config Class Initialized
INFO - 2020-10-15 06:17:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:58 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:58 --> URI Class Initialized
INFO - 2020-10-15 06:17:58 --> Router Class Initialized
INFO - 2020-10-15 06:17:58 --> Output Class Initialized
INFO - 2020-10-15 06:17:58 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:58 --> Input Class Initialized
INFO - 2020-10-15 06:17:58 --> Language Class Initialized
INFO - 2020-10-15 06:17:58 --> Language Class Initialized
INFO - 2020-10-15 06:17:58 --> Config Class Initialized
INFO - 2020-10-15 06:17:58 --> Loader Class Initialized
INFO - 2020-10-15 06:17:58 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:58 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:58 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:58 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:58 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:58 --> Controller Class Initialized
INFO - 2020-10-15 06:17:58 --> Config Class Initialized
INFO - 2020-10-15 06:17:58 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:17:58 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:17:59 --> Utf8 Class Initialized
INFO - 2020-10-15 06:17:59 --> URI Class Initialized
INFO - 2020-10-15 06:17:59 --> Router Class Initialized
INFO - 2020-10-15 06:17:59 --> Output Class Initialized
INFO - 2020-10-15 06:17:59 --> Security Class Initialized
DEBUG - 2020-10-15 06:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:17:59 --> Input Class Initialized
INFO - 2020-10-15 06:17:59 --> Language Class Initialized
INFO - 2020-10-15 06:17:59 --> Language Class Initialized
INFO - 2020-10-15 06:17:59 --> Config Class Initialized
INFO - 2020-10-15 06:17:59 --> Loader Class Initialized
INFO - 2020-10-15 06:17:59 --> Helper loaded: url_helper
INFO - 2020-10-15 06:17:59 --> Helper loaded: file_helper
INFO - 2020-10-15 06:17:59 --> Helper loaded: form_helper
INFO - 2020-10-15 06:17:59 --> Helper loaded: my_helper
INFO - 2020-10-15 06:17:59 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:17:59 --> Controller Class Initialized
DEBUG - 2020-10-15 06:17:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:17:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:17:59 --> Final output sent to browser
DEBUG - 2020-10-15 06:17:59 --> Total execution time: 0.3496
INFO - 2020-10-15 06:18:00 --> Config Class Initialized
INFO - 2020-10-15 06:18:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:18:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:18:00 --> Utf8 Class Initialized
INFO - 2020-10-15 06:18:00 --> URI Class Initialized
INFO - 2020-10-15 06:18:00 --> Router Class Initialized
INFO - 2020-10-15 06:18:00 --> Output Class Initialized
INFO - 2020-10-15 06:18:00 --> Security Class Initialized
DEBUG - 2020-10-15 06:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:18:00 --> Input Class Initialized
INFO - 2020-10-15 06:18:00 --> Language Class Initialized
INFO - 2020-10-15 06:18:00 --> Language Class Initialized
INFO - 2020-10-15 06:18:00 --> Config Class Initialized
INFO - 2020-10-15 06:18:00 --> Loader Class Initialized
INFO - 2020-10-15 06:18:00 --> Helper loaded: url_helper
INFO - 2020-10-15 06:18:00 --> Helper loaded: file_helper
INFO - 2020-10-15 06:18:00 --> Helper loaded: form_helper
INFO - 2020-10-15 06:18:00 --> Helper loaded: my_helper
INFO - 2020-10-15 06:18:00 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:18:00 --> Controller Class Initialized
INFO - 2020-10-15 06:18:00 --> Config Class Initialized
INFO - 2020-10-15 06:18:00 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:18:00 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:18:00 --> Utf8 Class Initialized
INFO - 2020-10-15 06:18:00 --> URI Class Initialized
INFO - 2020-10-15 06:18:00 --> Router Class Initialized
INFO - 2020-10-15 06:18:00 --> Output Class Initialized
INFO - 2020-10-15 06:18:01 --> Security Class Initialized
DEBUG - 2020-10-15 06:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:18:01 --> Input Class Initialized
INFO - 2020-10-15 06:18:01 --> Language Class Initialized
INFO - 2020-10-15 06:18:01 --> Language Class Initialized
INFO - 2020-10-15 06:18:01 --> Config Class Initialized
INFO - 2020-10-15 06:18:01 --> Loader Class Initialized
INFO - 2020-10-15 06:18:01 --> Helper loaded: url_helper
INFO - 2020-10-15 06:18:01 --> Helper loaded: file_helper
INFO - 2020-10-15 06:18:01 --> Helper loaded: form_helper
INFO - 2020-10-15 06:18:01 --> Helper loaded: my_helper
INFO - 2020-10-15 06:18:01 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:18:01 --> Controller Class Initialized
DEBUG - 2020-10-15 06:18:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:18:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:18:01 --> Final output sent to browser
DEBUG - 2020-10-15 06:18:01 --> Total execution time: 0.3619
INFO - 2020-10-15 06:18:10 --> Config Class Initialized
INFO - 2020-10-15 06:18:10 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:18:10 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:18:10 --> Utf8 Class Initialized
INFO - 2020-10-15 06:18:10 --> URI Class Initialized
INFO - 2020-10-15 06:18:10 --> Router Class Initialized
INFO - 2020-10-15 06:18:10 --> Output Class Initialized
INFO - 2020-10-15 06:18:10 --> Security Class Initialized
DEBUG - 2020-10-15 06:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:18:11 --> Input Class Initialized
INFO - 2020-10-15 06:18:11 --> Language Class Initialized
INFO - 2020-10-15 06:18:11 --> Language Class Initialized
INFO - 2020-10-15 06:18:11 --> Config Class Initialized
INFO - 2020-10-15 06:18:11 --> Loader Class Initialized
INFO - 2020-10-15 06:18:11 --> Helper loaded: url_helper
INFO - 2020-10-15 06:18:11 --> Helper loaded: file_helper
INFO - 2020-10-15 06:18:11 --> Helper loaded: form_helper
INFO - 2020-10-15 06:18:11 --> Helper loaded: my_helper
INFO - 2020-10-15 06:18:11 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:18:11 --> Controller Class Initialized
INFO - 2020-10-15 06:18:11 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:18:11 --> Final output sent to browser
DEBUG - 2020-10-15 06:18:11 --> Total execution time: 0.5056
INFO - 2020-10-15 06:18:12 --> Config Class Initialized
INFO - 2020-10-15 06:18:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:18:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:18:12 --> Utf8 Class Initialized
INFO - 2020-10-15 06:18:12 --> URI Class Initialized
INFO - 2020-10-15 06:18:12 --> Router Class Initialized
INFO - 2020-10-15 06:18:12 --> Output Class Initialized
INFO - 2020-10-15 06:18:12 --> Security Class Initialized
DEBUG - 2020-10-15 06:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:18:12 --> Input Class Initialized
INFO - 2020-10-15 06:18:12 --> Language Class Initialized
INFO - 2020-10-15 06:18:12 --> Language Class Initialized
INFO - 2020-10-15 06:18:12 --> Config Class Initialized
INFO - 2020-10-15 06:18:12 --> Loader Class Initialized
INFO - 2020-10-15 06:18:12 --> Helper loaded: url_helper
INFO - 2020-10-15 06:18:13 --> Helper loaded: file_helper
INFO - 2020-10-15 06:18:13 --> Helper loaded: form_helper
INFO - 2020-10-15 06:18:13 --> Helper loaded: my_helper
INFO - 2020-10-15 06:18:13 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:18:13 --> Controller Class Initialized
DEBUG - 2020-10-15 06:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:18:13 --> Final output sent to browser
DEBUG - 2020-10-15 06:18:13 --> Total execution time: 0.5091
INFO - 2020-10-15 06:18:16 --> Config Class Initialized
INFO - 2020-10-15 06:18:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:18:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:18:16 --> Utf8 Class Initialized
INFO - 2020-10-15 06:18:16 --> URI Class Initialized
INFO - 2020-10-15 06:18:16 --> Router Class Initialized
INFO - 2020-10-15 06:18:16 --> Output Class Initialized
INFO - 2020-10-15 06:18:16 --> Security Class Initialized
DEBUG - 2020-10-15 06:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:18:16 --> Input Class Initialized
INFO - 2020-10-15 06:18:16 --> Language Class Initialized
INFO - 2020-10-15 06:18:16 --> Language Class Initialized
INFO - 2020-10-15 06:18:16 --> Config Class Initialized
INFO - 2020-10-15 06:18:16 --> Loader Class Initialized
INFO - 2020-10-15 06:18:16 --> Helper loaded: url_helper
INFO - 2020-10-15 06:18:16 --> Helper loaded: file_helper
INFO - 2020-10-15 06:18:16 --> Helper loaded: form_helper
INFO - 2020-10-15 06:18:16 --> Helper loaded: my_helper
INFO - 2020-10-15 06:18:16 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:18:16 --> Controller Class Initialized
INFO - 2020-10-15 06:18:16 --> Config Class Initialized
INFO - 2020-10-15 06:18:16 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:18:16 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:18:16 --> Utf8 Class Initialized
INFO - 2020-10-15 06:18:16 --> URI Class Initialized
INFO - 2020-10-15 06:18:16 --> Router Class Initialized
INFO - 2020-10-15 06:18:16 --> Output Class Initialized
INFO - 2020-10-15 06:18:16 --> Security Class Initialized
DEBUG - 2020-10-15 06:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:18:16 --> Input Class Initialized
INFO - 2020-10-15 06:18:16 --> Language Class Initialized
INFO - 2020-10-15 06:18:16 --> Language Class Initialized
INFO - 2020-10-15 06:18:16 --> Config Class Initialized
INFO - 2020-10-15 06:18:16 --> Loader Class Initialized
INFO - 2020-10-15 06:18:16 --> Helper loaded: url_helper
INFO - 2020-10-15 06:18:16 --> Helper loaded: file_helper
INFO - 2020-10-15 06:18:16 --> Helper loaded: form_helper
INFO - 2020-10-15 06:18:16 --> Helper loaded: my_helper
INFO - 2020-10-15 06:18:16 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:18:16 --> Controller Class Initialized
DEBUG - 2020-10-15 06:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:18:16 --> Final output sent to browser
DEBUG - 2020-10-15 06:18:16 --> Total execution time: 0.3847
INFO - 2020-10-15 06:24:41 --> Config Class Initialized
INFO - 2020-10-15 06:24:41 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:24:41 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:24:41 --> Utf8 Class Initialized
INFO - 2020-10-15 06:24:41 --> URI Class Initialized
INFO - 2020-10-15 06:24:41 --> Router Class Initialized
INFO - 2020-10-15 06:24:41 --> Output Class Initialized
INFO - 2020-10-15 06:24:41 --> Security Class Initialized
DEBUG - 2020-10-15 06:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:24:41 --> Input Class Initialized
INFO - 2020-10-15 06:24:41 --> Language Class Initialized
INFO - 2020-10-15 06:24:41 --> Language Class Initialized
INFO - 2020-10-15 06:24:41 --> Config Class Initialized
INFO - 2020-10-15 06:24:41 --> Loader Class Initialized
INFO - 2020-10-15 06:24:41 --> Helper loaded: url_helper
INFO - 2020-10-15 06:24:41 --> Helper loaded: file_helper
INFO - 2020-10-15 06:24:41 --> Helper loaded: form_helper
INFO - 2020-10-15 06:24:41 --> Helper loaded: my_helper
INFO - 2020-10-15 06:24:41 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:24:41 --> Controller Class Initialized
DEBUG - 2020-10-15 06:24:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:24:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:24:41 --> Final output sent to browser
DEBUG - 2020-10-15 06:24:41 --> Total execution time: 0.4299
INFO - 2020-10-15 06:24:43 --> Config Class Initialized
INFO - 2020-10-15 06:24:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:24:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:24:43 --> Utf8 Class Initialized
INFO - 2020-10-15 06:24:43 --> URI Class Initialized
INFO - 2020-10-15 06:24:43 --> Router Class Initialized
INFO - 2020-10-15 06:24:43 --> Output Class Initialized
INFO - 2020-10-15 06:24:43 --> Security Class Initialized
DEBUG - 2020-10-15 06:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:24:43 --> Input Class Initialized
INFO - 2020-10-15 06:24:43 --> Language Class Initialized
INFO - 2020-10-15 06:24:43 --> Language Class Initialized
INFO - 2020-10-15 06:24:43 --> Config Class Initialized
INFO - 2020-10-15 06:24:43 --> Loader Class Initialized
INFO - 2020-10-15 06:24:43 --> Helper loaded: url_helper
INFO - 2020-10-15 06:24:43 --> Helper loaded: file_helper
INFO - 2020-10-15 06:24:43 --> Helper loaded: form_helper
INFO - 2020-10-15 06:24:43 --> Helper loaded: my_helper
INFO - 2020-10-15 06:24:43 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:24:43 --> Controller Class Initialized
INFO - 2020-10-15 06:24:43 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:24:43 --> Config Class Initialized
INFO - 2020-10-15 06:24:43 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:24:43 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:24:43 --> Utf8 Class Initialized
INFO - 2020-10-15 06:24:43 --> URI Class Initialized
INFO - 2020-10-15 06:24:43 --> Router Class Initialized
INFO - 2020-10-15 06:24:43 --> Output Class Initialized
INFO - 2020-10-15 06:24:43 --> Security Class Initialized
DEBUG - 2020-10-15 06:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:24:43 --> Input Class Initialized
INFO - 2020-10-15 06:24:43 --> Language Class Initialized
INFO - 2020-10-15 06:24:43 --> Language Class Initialized
INFO - 2020-10-15 06:24:43 --> Config Class Initialized
INFO - 2020-10-15 06:24:43 --> Loader Class Initialized
INFO - 2020-10-15 06:24:43 --> Helper loaded: url_helper
INFO - 2020-10-15 06:24:43 --> Helper loaded: file_helper
INFO - 2020-10-15 06:24:43 --> Helper loaded: form_helper
INFO - 2020-10-15 06:24:43 --> Helper loaded: my_helper
INFO - 2020-10-15 06:24:43 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:24:43 --> Controller Class Initialized
DEBUG - 2020-10-15 06:24:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:24:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:24:43 --> Final output sent to browser
DEBUG - 2020-10-15 06:24:43 --> Total execution time: 0.3360
INFO - 2020-10-15 06:47:55 --> Config Class Initialized
INFO - 2020-10-15 06:47:55 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:47:55 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:47:55 --> Utf8 Class Initialized
INFO - 2020-10-15 06:47:55 --> URI Class Initialized
INFO - 2020-10-15 06:47:55 --> Router Class Initialized
INFO - 2020-10-15 06:47:55 --> Output Class Initialized
INFO - 2020-10-15 06:47:55 --> Security Class Initialized
DEBUG - 2020-10-15 06:47:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:47:55 --> Input Class Initialized
INFO - 2020-10-15 06:47:55 --> Language Class Initialized
INFO - 2020-10-15 06:47:55 --> Language Class Initialized
INFO - 2020-10-15 06:47:55 --> Config Class Initialized
INFO - 2020-10-15 06:47:55 --> Loader Class Initialized
INFO - 2020-10-15 06:47:55 --> Helper loaded: url_helper
INFO - 2020-10-15 06:47:55 --> Helper loaded: file_helper
INFO - 2020-10-15 06:47:55 --> Helper loaded: form_helper
INFO - 2020-10-15 06:47:55 --> Helper loaded: my_helper
INFO - 2020-10-15 06:47:55 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:47:55 --> Controller Class Initialized
DEBUG - 2020-10-15 06:47:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:47:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:47:55 --> Final output sent to browser
DEBUG - 2020-10-15 06:47:55 --> Total execution time: 0.4297
INFO - 2020-10-15 06:47:56 --> Config Class Initialized
INFO - 2020-10-15 06:47:56 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:47:56 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:47:56 --> Utf8 Class Initialized
INFO - 2020-10-15 06:47:56 --> URI Class Initialized
INFO - 2020-10-15 06:47:56 --> Router Class Initialized
INFO - 2020-10-15 06:47:56 --> Output Class Initialized
INFO - 2020-10-15 06:47:56 --> Security Class Initialized
DEBUG - 2020-10-15 06:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:47:56 --> Input Class Initialized
INFO - 2020-10-15 06:47:56 --> Language Class Initialized
INFO - 2020-10-15 06:47:56 --> Language Class Initialized
INFO - 2020-10-15 06:47:56 --> Config Class Initialized
INFO - 2020-10-15 06:47:56 --> Loader Class Initialized
INFO - 2020-10-15 06:47:56 --> Helper loaded: url_helper
INFO - 2020-10-15 06:47:56 --> Helper loaded: file_helper
INFO - 2020-10-15 06:47:56 --> Helper loaded: form_helper
INFO - 2020-10-15 06:47:56 --> Helper loaded: my_helper
INFO - 2020-10-15 06:47:56 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:47:56 --> Controller Class Initialized
INFO - 2020-10-15 06:47:56 --> Helper loaded: cookie_helper
ERROR - 2020-10-15 06:47:56 --> Severity: Error --> Call to undefined method CI_Session::session_destroy() C:\xampp\htdocs\nilai\application\modules\login\controllers\Login.php 108
INFO - 2020-10-15 06:49:12 --> Config Class Initialized
INFO - 2020-10-15 06:49:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:49:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:49:12 --> Utf8 Class Initialized
INFO - 2020-10-15 06:49:12 --> URI Class Initialized
INFO - 2020-10-15 06:49:12 --> Router Class Initialized
INFO - 2020-10-15 06:49:12 --> Output Class Initialized
INFO - 2020-10-15 06:49:12 --> Security Class Initialized
DEBUG - 2020-10-15 06:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:49:12 --> Input Class Initialized
INFO - 2020-10-15 06:49:12 --> Language Class Initialized
INFO - 2020-10-15 06:49:12 --> Language Class Initialized
INFO - 2020-10-15 06:49:12 --> Config Class Initialized
INFO - 2020-10-15 06:49:12 --> Loader Class Initialized
INFO - 2020-10-15 06:49:12 --> Helper loaded: url_helper
INFO - 2020-10-15 06:49:12 --> Helper loaded: file_helper
INFO - 2020-10-15 06:49:12 --> Helper loaded: form_helper
INFO - 2020-10-15 06:49:12 --> Helper loaded: my_helper
INFO - 2020-10-15 06:49:12 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:49:12 --> Controller Class Initialized
INFO - 2020-10-15 06:49:12 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:49:12 --> Config Class Initialized
INFO - 2020-10-15 06:49:12 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:49:12 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:49:12 --> Utf8 Class Initialized
INFO - 2020-10-15 06:49:12 --> URI Class Initialized
INFO - 2020-10-15 06:49:12 --> Router Class Initialized
INFO - 2020-10-15 06:49:12 --> Output Class Initialized
INFO - 2020-10-15 06:49:12 --> Security Class Initialized
DEBUG - 2020-10-15 06:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:49:13 --> Input Class Initialized
INFO - 2020-10-15 06:49:13 --> Language Class Initialized
ERROR - 2020-10-15 06:49:13 --> 404 Page Not Found: /index
INFO - 2020-10-15 06:49:26 --> Config Class Initialized
INFO - 2020-10-15 06:49:26 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:49:26 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:49:26 --> Utf8 Class Initialized
INFO - 2020-10-15 06:49:26 --> URI Class Initialized
INFO - 2020-10-15 06:49:26 --> Router Class Initialized
INFO - 2020-10-15 06:49:26 --> Output Class Initialized
INFO - 2020-10-15 06:49:26 --> Security Class Initialized
DEBUG - 2020-10-15 06:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:49:26 --> Input Class Initialized
INFO - 2020-10-15 06:49:26 --> Language Class Initialized
ERROR - 2020-10-15 06:49:26 --> 404 Page Not Found: /index
INFO - 2020-10-15 06:49:29 --> Config Class Initialized
INFO - 2020-10-15 06:49:29 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:49:29 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:49:29 --> Utf8 Class Initialized
INFO - 2020-10-15 06:49:29 --> URI Class Initialized
DEBUG - 2020-10-15 06:49:29 --> No URI present. Default controller set.
INFO - 2020-10-15 06:49:29 --> Router Class Initialized
INFO - 2020-10-15 06:49:29 --> Output Class Initialized
INFO - 2020-10-15 06:49:29 --> Security Class Initialized
DEBUG - 2020-10-15 06:49:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:49:29 --> Input Class Initialized
INFO - 2020-10-15 06:49:29 --> Language Class Initialized
INFO - 2020-10-15 06:49:29 --> Language Class Initialized
INFO - 2020-10-15 06:49:29 --> Config Class Initialized
INFO - 2020-10-15 06:49:29 --> Loader Class Initialized
INFO - 2020-10-15 06:49:29 --> Helper loaded: url_helper
INFO - 2020-10-15 06:49:29 --> Helper loaded: file_helper
INFO - 2020-10-15 06:49:29 --> Helper loaded: form_helper
INFO - 2020-10-15 06:49:29 --> Helper loaded: my_helper
INFO - 2020-10-15 06:49:29 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:49:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:49:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:49:30 --> Controller Class Initialized
DEBUG - 2020-10-15 06:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:49:30 --> Final output sent to browser
DEBUG - 2020-10-15 06:49:30 --> Total execution time: 0.3911
INFO - 2020-10-15 06:49:31 --> Config Class Initialized
INFO - 2020-10-15 06:49:31 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:49:31 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:49:31 --> Utf8 Class Initialized
INFO - 2020-10-15 06:49:31 --> URI Class Initialized
INFO - 2020-10-15 06:49:31 --> Router Class Initialized
INFO - 2020-10-15 06:49:31 --> Output Class Initialized
INFO - 2020-10-15 06:49:31 --> Security Class Initialized
DEBUG - 2020-10-15 06:49:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:49:31 --> Input Class Initialized
INFO - 2020-10-15 06:49:31 --> Language Class Initialized
INFO - 2020-10-15 06:49:31 --> Language Class Initialized
INFO - 2020-10-15 06:49:31 --> Config Class Initialized
INFO - 2020-10-15 06:49:31 --> Loader Class Initialized
INFO - 2020-10-15 06:49:31 --> Helper loaded: url_helper
INFO - 2020-10-15 06:49:31 --> Helper loaded: file_helper
INFO - 2020-10-15 06:49:31 --> Helper loaded: form_helper
INFO - 2020-10-15 06:49:31 --> Helper loaded: my_helper
INFO - 2020-10-15 06:49:31 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:49:31 --> Controller Class Initialized
INFO - 2020-10-15 06:49:31 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:49:31 --> Config Class Initialized
INFO - 2020-10-15 06:49:31 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:49:31 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:49:31 --> Utf8 Class Initialized
INFO - 2020-10-15 06:49:31 --> URI Class Initialized
DEBUG - 2020-10-15 06:49:31 --> No URI present. Default controller set.
INFO - 2020-10-15 06:49:31 --> Router Class Initialized
INFO - 2020-10-15 06:49:32 --> Output Class Initialized
INFO - 2020-10-15 06:49:32 --> Security Class Initialized
DEBUG - 2020-10-15 06:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:49:32 --> Input Class Initialized
INFO - 2020-10-15 06:49:32 --> Language Class Initialized
INFO - 2020-10-15 06:49:32 --> Language Class Initialized
INFO - 2020-10-15 06:49:32 --> Config Class Initialized
INFO - 2020-10-15 06:49:32 --> Loader Class Initialized
INFO - 2020-10-15 06:49:32 --> Helper loaded: url_helper
INFO - 2020-10-15 06:49:32 --> Helper loaded: file_helper
INFO - 2020-10-15 06:49:32 --> Helper loaded: form_helper
INFO - 2020-10-15 06:49:32 --> Helper loaded: my_helper
INFO - 2020-10-15 06:49:32 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:49:32 --> Controller Class Initialized
DEBUG - 2020-10-15 06:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:49:32 --> Final output sent to browser
DEBUG - 2020-10-15 06:49:32 --> Total execution time: 0.3505
INFO - 2020-10-15 06:50:17 --> Config Class Initialized
INFO - 2020-10-15 06:50:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:50:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:50:17 --> Utf8 Class Initialized
INFO - 2020-10-15 06:50:17 --> URI Class Initialized
DEBUG - 2020-10-15 06:50:17 --> No URI present. Default controller set.
INFO - 2020-10-15 06:50:17 --> Router Class Initialized
INFO - 2020-10-15 06:50:17 --> Output Class Initialized
INFO - 2020-10-15 06:50:17 --> Security Class Initialized
DEBUG - 2020-10-15 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:50:17 --> Input Class Initialized
INFO - 2020-10-15 06:50:17 --> Language Class Initialized
INFO - 2020-10-15 06:50:17 --> Language Class Initialized
INFO - 2020-10-15 06:50:17 --> Config Class Initialized
INFO - 2020-10-15 06:50:17 --> Loader Class Initialized
INFO - 2020-10-15 06:50:17 --> Helper loaded: url_helper
INFO - 2020-10-15 06:50:17 --> Helper loaded: file_helper
INFO - 2020-10-15 06:50:17 --> Helper loaded: form_helper
INFO - 2020-10-15 06:50:17 --> Helper loaded: my_helper
INFO - 2020-10-15 06:50:17 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:50:17 --> Controller Class Initialized
DEBUG - 2020-10-15 06:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:50:17 --> Final output sent to browser
DEBUG - 2020-10-15 06:50:17 --> Total execution time: 0.3555
INFO - 2020-10-15 06:50:18 --> Config Class Initialized
INFO - 2020-10-15 06:50:18 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:50:18 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:50:18 --> Utf8 Class Initialized
INFO - 2020-10-15 06:50:18 --> URI Class Initialized
INFO - 2020-10-15 06:50:18 --> Router Class Initialized
INFO - 2020-10-15 06:50:18 --> Output Class Initialized
INFO - 2020-10-15 06:50:18 --> Security Class Initialized
DEBUG - 2020-10-15 06:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:50:18 --> Input Class Initialized
INFO - 2020-10-15 06:50:19 --> Language Class Initialized
INFO - 2020-10-15 06:50:19 --> Language Class Initialized
INFO - 2020-10-15 06:50:19 --> Config Class Initialized
INFO - 2020-10-15 06:50:19 --> Loader Class Initialized
INFO - 2020-10-15 06:50:19 --> Helper loaded: url_helper
INFO - 2020-10-15 06:50:19 --> Helper loaded: file_helper
INFO - 2020-10-15 06:50:19 --> Helper loaded: form_helper
INFO - 2020-10-15 06:50:19 --> Helper loaded: my_helper
INFO - 2020-10-15 06:50:19 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:50:19 --> Controller Class Initialized
INFO - 2020-10-15 06:50:19 --> Config Class Initialized
INFO - 2020-10-15 06:50:19 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:50:19 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:50:19 --> Utf8 Class Initialized
INFO - 2020-10-15 06:50:19 --> URI Class Initialized
INFO - 2020-10-15 06:50:19 --> Router Class Initialized
INFO - 2020-10-15 06:50:19 --> Output Class Initialized
INFO - 2020-10-15 06:50:19 --> Security Class Initialized
DEBUG - 2020-10-15 06:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:50:19 --> Input Class Initialized
INFO - 2020-10-15 06:50:19 --> Language Class Initialized
INFO - 2020-10-15 06:50:19 --> Language Class Initialized
INFO - 2020-10-15 06:50:19 --> Config Class Initialized
INFO - 2020-10-15 06:50:19 --> Loader Class Initialized
INFO - 2020-10-15 06:50:19 --> Helper loaded: url_helper
INFO - 2020-10-15 06:50:19 --> Helper loaded: file_helper
INFO - 2020-10-15 06:50:19 --> Helper loaded: form_helper
INFO - 2020-10-15 06:50:19 --> Helper loaded: my_helper
INFO - 2020-10-15 06:50:19 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:50:19 --> Controller Class Initialized
DEBUG - 2020-10-15 06:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:50:19 --> Final output sent to browser
DEBUG - 2020-10-15 06:50:19 --> Total execution time: 0.3671
INFO - 2020-10-15 06:57:17 --> Config Class Initialized
INFO - 2020-10-15 06:57:17 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:17 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:17 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:17 --> URI Class Initialized
INFO - 2020-10-15 06:57:17 --> Router Class Initialized
INFO - 2020-10-15 06:57:17 --> Output Class Initialized
INFO - 2020-10-15 06:57:17 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:17 --> Input Class Initialized
INFO - 2020-10-15 06:57:17 --> Language Class Initialized
INFO - 2020-10-15 06:57:17 --> Language Class Initialized
INFO - 2020-10-15 06:57:17 --> Config Class Initialized
INFO - 2020-10-15 06:57:17 --> Loader Class Initialized
INFO - 2020-10-15 06:57:17 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:17 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:17 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:17 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:17 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:17 --> Controller Class Initialized
DEBUG - 2020-10-15 06:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-15 06:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:57:17 --> Final output sent to browser
DEBUG - 2020-10-15 06:57:17 --> Total execution time: 0.4886
INFO - 2020-10-15 06:57:19 --> Config Class Initialized
INFO - 2020-10-15 06:57:19 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:19 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:19 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:19 --> URI Class Initialized
INFO - 2020-10-15 06:57:19 --> Router Class Initialized
INFO - 2020-10-15 06:57:19 --> Output Class Initialized
INFO - 2020-10-15 06:57:19 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:19 --> Input Class Initialized
INFO - 2020-10-15 06:57:19 --> Language Class Initialized
INFO - 2020-10-15 06:57:19 --> Language Class Initialized
INFO - 2020-10-15 06:57:19 --> Config Class Initialized
INFO - 2020-10-15 06:57:19 --> Loader Class Initialized
INFO - 2020-10-15 06:57:19 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:19 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:19 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:19 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:19 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:19 --> Controller Class Initialized
INFO - 2020-10-15 06:57:19 --> Helper loaded: cookie_helper
ERROR - 2020-10-15 06:57:19 --> Severity: Error --> Call to undefined method CI_Session::session_destroy() C:\xampp\htdocs\nilai\application\modules\login\controllers\Login.php 108
INFO - 2020-10-15 06:57:34 --> Config Class Initialized
INFO - 2020-10-15 06:57:34 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:34 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:34 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:34 --> URI Class Initialized
INFO - 2020-10-15 06:57:34 --> Router Class Initialized
INFO - 2020-10-15 06:57:34 --> Output Class Initialized
INFO - 2020-10-15 06:57:34 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:34 --> Input Class Initialized
INFO - 2020-10-15 06:57:34 --> Language Class Initialized
INFO - 2020-10-15 06:57:34 --> Language Class Initialized
INFO - 2020-10-15 06:57:34 --> Config Class Initialized
INFO - 2020-10-15 06:57:34 --> Loader Class Initialized
INFO - 2020-10-15 06:57:34 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:34 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:34 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:34 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:34 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:34 --> Controller Class Initialized
INFO - 2020-10-15 06:57:34 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:57:34 --> Config Class Initialized
INFO - 2020-10-15 06:57:34 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:34 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:34 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:34 --> URI Class Initialized
INFO - 2020-10-15 06:57:34 --> Router Class Initialized
INFO - 2020-10-15 06:57:34 --> Output Class Initialized
INFO - 2020-10-15 06:57:34 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:34 --> Input Class Initialized
INFO - 2020-10-15 06:57:34 --> Language Class Initialized
INFO - 2020-10-15 06:57:34 --> Language Class Initialized
INFO - 2020-10-15 06:57:34 --> Config Class Initialized
INFO - 2020-10-15 06:57:34 --> Loader Class Initialized
INFO - 2020-10-15 06:57:34 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:34 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:34 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:35 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:35 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:35 --> Controller Class Initialized
DEBUG - 2020-10-15 06:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:57:35 --> Final output sent to browser
DEBUG - 2020-10-15 06:57:35 --> Total execution time: 0.3524
INFO - 2020-10-15 06:57:37 --> Config Class Initialized
INFO - 2020-10-15 06:57:37 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:37 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:37 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:37 --> URI Class Initialized
INFO - 2020-10-15 06:57:37 --> Router Class Initialized
INFO - 2020-10-15 06:57:37 --> Output Class Initialized
INFO - 2020-10-15 06:57:37 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:37 --> Input Class Initialized
INFO - 2020-10-15 06:57:37 --> Language Class Initialized
INFO - 2020-10-15 06:57:37 --> Language Class Initialized
INFO - 2020-10-15 06:57:37 --> Config Class Initialized
INFO - 2020-10-15 06:57:37 --> Loader Class Initialized
INFO - 2020-10-15 06:57:37 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:37 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:37 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:37 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:37 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:37 --> Controller Class Initialized
INFO - 2020-10-15 06:57:37 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:57:37 --> Config Class Initialized
INFO - 2020-10-15 06:57:37 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:37 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:37 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:37 --> URI Class Initialized
INFO - 2020-10-15 06:57:37 --> Router Class Initialized
INFO - 2020-10-15 06:57:37 --> Output Class Initialized
INFO - 2020-10-15 06:57:37 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:37 --> Input Class Initialized
INFO - 2020-10-15 06:57:37 --> Language Class Initialized
INFO - 2020-10-15 06:57:37 --> Language Class Initialized
INFO - 2020-10-15 06:57:37 --> Config Class Initialized
INFO - 2020-10-15 06:57:37 --> Loader Class Initialized
INFO - 2020-10-15 06:57:37 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:37 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:37 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:37 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:37 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:37 --> Controller Class Initialized
DEBUG - 2020-10-15 06:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:57:37 --> Final output sent to browser
DEBUG - 2020-10-15 06:57:37 --> Total execution time: 0.3568
INFO - 2020-10-15 06:57:53 --> Config Class Initialized
INFO - 2020-10-15 06:57:53 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:53 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:53 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:53 --> URI Class Initialized
DEBUG - 2020-10-15 06:57:53 --> No URI present. Default controller set.
INFO - 2020-10-15 06:57:53 --> Router Class Initialized
INFO - 2020-10-15 06:57:53 --> Output Class Initialized
INFO - 2020-10-15 06:57:53 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:53 --> Input Class Initialized
INFO - 2020-10-15 06:57:53 --> Language Class Initialized
INFO - 2020-10-15 06:57:53 --> Language Class Initialized
INFO - 2020-10-15 06:57:53 --> Config Class Initialized
INFO - 2020-10-15 06:57:53 --> Loader Class Initialized
INFO - 2020-10-15 06:57:53 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:53 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:53 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:53 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:53 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:53 --> Controller Class Initialized
DEBUG - 2020-10-15 06:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:57:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:57:53 --> Final output sent to browser
DEBUG - 2020-10-15 06:57:53 --> Total execution time: 0.4283
INFO - 2020-10-15 06:57:55 --> Config Class Initialized
INFO - 2020-10-15 06:57:55 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:55 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:55 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:55 --> URI Class Initialized
INFO - 2020-10-15 06:57:55 --> Router Class Initialized
INFO - 2020-10-15 06:57:55 --> Output Class Initialized
INFO - 2020-10-15 06:57:55 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:55 --> Input Class Initialized
INFO - 2020-10-15 06:57:55 --> Language Class Initialized
INFO - 2020-10-15 06:57:55 --> Language Class Initialized
INFO - 2020-10-15 06:57:55 --> Config Class Initialized
INFO - 2020-10-15 06:57:55 --> Loader Class Initialized
INFO - 2020-10-15 06:57:55 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:55 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:55 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:55 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:55 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:55 --> Controller Class Initialized
INFO - 2020-10-15 06:57:55 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:57:55 --> Config Class Initialized
INFO - 2020-10-15 06:57:55 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:57:55 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:57:55 --> Utf8 Class Initialized
INFO - 2020-10-15 06:57:55 --> URI Class Initialized
INFO - 2020-10-15 06:57:55 --> Router Class Initialized
INFO - 2020-10-15 06:57:55 --> Output Class Initialized
INFO - 2020-10-15 06:57:55 --> Security Class Initialized
DEBUG - 2020-10-15 06:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:57:55 --> Input Class Initialized
INFO - 2020-10-15 06:57:56 --> Language Class Initialized
INFO - 2020-10-15 06:57:56 --> Language Class Initialized
INFO - 2020-10-15 06:57:56 --> Config Class Initialized
INFO - 2020-10-15 06:57:56 --> Loader Class Initialized
INFO - 2020-10-15 06:57:56 --> Helper loaded: url_helper
INFO - 2020-10-15 06:57:56 --> Helper loaded: file_helper
INFO - 2020-10-15 06:57:56 --> Helper loaded: form_helper
INFO - 2020-10-15 06:57:56 --> Helper loaded: my_helper
INFO - 2020-10-15 06:57:56 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:57:56 --> Controller Class Initialized
DEBUG - 2020-10-15 06:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:57:56 --> Final output sent to browser
DEBUG - 2020-10-15 06:57:56 --> Total execution time: 0.3960
INFO - 2020-10-15 06:58:06 --> Config Class Initialized
INFO - 2020-10-15 06:58:06 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:58:06 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:58:06 --> Utf8 Class Initialized
INFO - 2020-10-15 06:58:06 --> URI Class Initialized
DEBUG - 2020-10-15 06:58:06 --> No URI present. Default controller set.
INFO - 2020-10-15 06:58:06 --> Router Class Initialized
INFO - 2020-10-15 06:58:06 --> Output Class Initialized
INFO - 2020-10-15 06:58:06 --> Security Class Initialized
DEBUG - 2020-10-15 06:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:58:06 --> Input Class Initialized
INFO - 2020-10-15 06:58:06 --> Language Class Initialized
INFO - 2020-10-15 06:58:06 --> Language Class Initialized
INFO - 2020-10-15 06:58:06 --> Config Class Initialized
INFO - 2020-10-15 06:58:06 --> Loader Class Initialized
INFO - 2020-10-15 06:58:06 --> Helper loaded: url_helper
INFO - 2020-10-15 06:58:06 --> Helper loaded: file_helper
INFO - 2020-10-15 06:58:06 --> Helper loaded: form_helper
INFO - 2020-10-15 06:58:06 --> Helper loaded: my_helper
INFO - 2020-10-15 06:58:06 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:58:06 --> Controller Class Initialized
DEBUG - 2020-10-15 06:58:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:58:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:58:06 --> Final output sent to browser
DEBUG - 2020-10-15 06:58:06 --> Total execution time: 0.4225
INFO - 2020-10-15 06:58:08 --> Config Class Initialized
INFO - 2020-10-15 06:58:08 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:58:08 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:58:08 --> Utf8 Class Initialized
INFO - 2020-10-15 06:58:08 --> URI Class Initialized
INFO - 2020-10-15 06:58:08 --> Router Class Initialized
INFO - 2020-10-15 06:58:08 --> Output Class Initialized
INFO - 2020-10-15 06:58:08 --> Security Class Initialized
DEBUG - 2020-10-15 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:58:08 --> Input Class Initialized
INFO - 2020-10-15 06:58:08 --> Language Class Initialized
INFO - 2020-10-15 06:58:08 --> Language Class Initialized
INFO - 2020-10-15 06:58:08 --> Config Class Initialized
INFO - 2020-10-15 06:58:08 --> Loader Class Initialized
INFO - 2020-10-15 06:58:08 --> Helper loaded: url_helper
INFO - 2020-10-15 06:58:08 --> Helper loaded: file_helper
INFO - 2020-10-15 06:58:08 --> Helper loaded: form_helper
INFO - 2020-10-15 06:58:08 --> Helper loaded: my_helper
INFO - 2020-10-15 06:58:08 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:58:08 --> Controller Class Initialized
INFO - 2020-10-15 06:58:08 --> Helper loaded: cookie_helper
INFO - 2020-10-15 06:58:08 --> Config Class Initialized
INFO - 2020-10-15 06:58:08 --> Hooks Class Initialized
DEBUG - 2020-10-15 06:58:08 --> UTF-8 Support Enabled
INFO - 2020-10-15 06:58:08 --> Utf8 Class Initialized
INFO - 2020-10-15 06:58:08 --> URI Class Initialized
INFO - 2020-10-15 06:58:08 --> Router Class Initialized
INFO - 2020-10-15 06:58:08 --> Output Class Initialized
INFO - 2020-10-15 06:58:08 --> Security Class Initialized
DEBUG - 2020-10-15 06:58:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-15 06:58:08 --> Input Class Initialized
INFO - 2020-10-15 06:58:08 --> Language Class Initialized
INFO - 2020-10-15 06:58:08 --> Language Class Initialized
INFO - 2020-10-15 06:58:08 --> Config Class Initialized
INFO - 2020-10-15 06:58:08 --> Loader Class Initialized
INFO - 2020-10-15 06:58:08 --> Helper loaded: url_helper
INFO - 2020-10-15 06:58:08 --> Helper loaded: file_helper
INFO - 2020-10-15 06:58:08 --> Helper loaded: form_helper
INFO - 2020-10-15 06:58:08 --> Helper loaded: my_helper
INFO - 2020-10-15 06:58:08 --> Database Driver Class Initialized
DEBUG - 2020-10-15 06:58:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-15 06:58:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-15 06:58:09 --> Controller Class Initialized
DEBUG - 2020-10-15 06:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-15 06:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-15 06:58:09 --> Final output sent to browser
DEBUG - 2020-10-15 06:58:09 --> Total execution time: 0.3770
