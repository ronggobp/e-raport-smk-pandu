<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-12 04:27:08 --> Config Class Initialized
INFO - 2021-06-12 04:27:08 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:08 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:08 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:08 --> URI Class Initialized
DEBUG - 2021-06-12 04:27:09 --> No URI present. Default controller set.
INFO - 2021-06-12 04:27:09 --> Router Class Initialized
INFO - 2021-06-12 04:27:09 --> Output Class Initialized
INFO - 2021-06-12 04:27:09 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:09 --> Input Class Initialized
INFO - 2021-06-12 04:27:09 --> Language Class Initialized
INFO - 2021-06-12 04:27:09 --> Language Class Initialized
INFO - 2021-06-12 04:27:09 --> Config Class Initialized
INFO - 2021-06-12 04:27:09 --> Loader Class Initialized
INFO - 2021-06-12 04:27:09 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:09 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:09 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:09 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:09 --> Controller Class Initialized
INFO - 2021-06-12 04:27:09 --> Config Class Initialized
INFO - 2021-06-12 04:27:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:09 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:09 --> URI Class Initialized
INFO - 2021-06-12 04:27:09 --> Router Class Initialized
INFO - 2021-06-12 04:27:09 --> Output Class Initialized
INFO - 2021-06-12 04:27:09 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:09 --> Input Class Initialized
INFO - 2021-06-12 04:27:09 --> Language Class Initialized
INFO - 2021-06-12 04:27:09 --> Language Class Initialized
INFO - 2021-06-12 04:27:09 --> Config Class Initialized
INFO - 2021-06-12 04:27:09 --> Loader Class Initialized
INFO - 2021-06-12 04:27:09 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:09 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:09 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:09 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:09 --> Controller Class Initialized
DEBUG - 2021-06-12 04:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 04:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:27:09 --> Final output sent to browser
DEBUG - 2021-06-12 04:27:09 --> Total execution time: 0.1041
INFO - 2021-06-12 04:27:16 --> Config Class Initialized
INFO - 2021-06-12 04:27:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:16 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:16 --> URI Class Initialized
INFO - 2021-06-12 04:27:16 --> Router Class Initialized
INFO - 2021-06-12 04:27:16 --> Output Class Initialized
INFO - 2021-06-12 04:27:16 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:16 --> Input Class Initialized
INFO - 2021-06-12 04:27:16 --> Language Class Initialized
INFO - 2021-06-12 04:27:16 --> Language Class Initialized
INFO - 2021-06-12 04:27:16 --> Config Class Initialized
INFO - 2021-06-12 04:27:16 --> Loader Class Initialized
INFO - 2021-06-12 04:27:16 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:16 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:16 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:16 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:16 --> Controller Class Initialized
INFO - 2021-06-12 04:27:16 --> Final output sent to browser
DEBUG - 2021-06-12 04:27:16 --> Total execution time: 0.0586
INFO - 2021-06-12 04:27:27 --> Config Class Initialized
INFO - 2021-06-12 04:27:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:27 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:27 --> URI Class Initialized
INFO - 2021-06-12 04:27:27 --> Router Class Initialized
INFO - 2021-06-12 04:27:27 --> Output Class Initialized
INFO - 2021-06-12 04:27:27 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:27 --> Input Class Initialized
INFO - 2021-06-12 04:27:27 --> Language Class Initialized
INFO - 2021-06-12 04:27:27 --> Language Class Initialized
INFO - 2021-06-12 04:27:27 --> Config Class Initialized
INFO - 2021-06-12 04:27:27 --> Loader Class Initialized
INFO - 2021-06-12 04:27:27 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:27 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:27 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:27 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:27 --> Controller Class Initialized
INFO - 2021-06-12 04:27:27 --> Helper loaded: cookie_helper
INFO - 2021-06-12 04:27:27 --> Final output sent to browser
DEBUG - 2021-06-12 04:27:27 --> Total execution time: 0.0958
INFO - 2021-06-12 04:27:28 --> Config Class Initialized
INFO - 2021-06-12 04:27:28 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:28 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:28 --> URI Class Initialized
INFO - 2021-06-12 04:27:28 --> Router Class Initialized
INFO - 2021-06-12 04:27:28 --> Output Class Initialized
INFO - 2021-06-12 04:27:28 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:28 --> Input Class Initialized
INFO - 2021-06-12 04:27:28 --> Language Class Initialized
INFO - 2021-06-12 04:27:28 --> Language Class Initialized
INFO - 2021-06-12 04:27:28 --> Config Class Initialized
INFO - 2021-06-12 04:27:28 --> Loader Class Initialized
INFO - 2021-06-12 04:27:28 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:28 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:28 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:28 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:28 --> Controller Class Initialized
DEBUG - 2021-06-12 04:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 04:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:27:28 --> Final output sent to browser
DEBUG - 2021-06-12 04:27:28 --> Total execution time: 0.1479
INFO - 2021-06-12 04:27:30 --> Config Class Initialized
INFO - 2021-06-12 04:27:30 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:30 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:30 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:30 --> URI Class Initialized
INFO - 2021-06-12 04:27:30 --> Router Class Initialized
INFO - 2021-06-12 04:27:30 --> Output Class Initialized
INFO - 2021-06-12 04:27:30 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:30 --> Input Class Initialized
INFO - 2021-06-12 04:27:30 --> Language Class Initialized
INFO - 2021-06-12 04:27:30 --> Language Class Initialized
INFO - 2021-06-12 04:27:30 --> Config Class Initialized
INFO - 2021-06-12 04:27:30 --> Loader Class Initialized
INFO - 2021-06-12 04:27:30 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:30 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:30 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:30 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:30 --> Controller Class Initialized
DEBUG - 2021-06-12 04:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:27:30 --> Final output sent to browser
DEBUG - 2021-06-12 04:27:30 --> Total execution time: 0.0966
INFO - 2021-06-12 04:27:44 --> Config Class Initialized
INFO - 2021-06-12 04:27:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:44 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:44 --> URI Class Initialized
INFO - 2021-06-12 04:27:44 --> Router Class Initialized
INFO - 2021-06-12 04:27:44 --> Output Class Initialized
INFO - 2021-06-12 04:27:44 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:44 --> Input Class Initialized
INFO - 2021-06-12 04:27:44 --> Language Class Initialized
INFO - 2021-06-12 04:27:44 --> Language Class Initialized
INFO - 2021-06-12 04:27:44 --> Config Class Initialized
INFO - 2021-06-12 04:27:44 --> Loader Class Initialized
INFO - 2021-06-12 04:27:44 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:44 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:44 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:44 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:44 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:44 --> Controller Class Initialized
DEBUG - 2021-06-12 04:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 04:27:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:27:44 --> Final output sent to browser
DEBUG - 2021-06-12 04:27:44 --> Total execution time: 0.0972
INFO - 2021-06-12 04:27:44 --> Config Class Initialized
INFO - 2021-06-12 04:27:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:27:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:27:44 --> Utf8 Class Initialized
INFO - 2021-06-12 04:27:44 --> URI Class Initialized
INFO - 2021-06-12 04:27:44 --> Router Class Initialized
INFO - 2021-06-12 04:27:44 --> Output Class Initialized
INFO - 2021-06-12 04:27:44 --> Security Class Initialized
DEBUG - 2021-06-12 04:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:27:44 --> Input Class Initialized
INFO - 2021-06-12 04:27:44 --> Language Class Initialized
INFO - 2021-06-12 04:27:44 --> Language Class Initialized
INFO - 2021-06-12 04:27:44 --> Config Class Initialized
INFO - 2021-06-12 04:27:44 --> Loader Class Initialized
INFO - 2021-06-12 04:27:44 --> Helper loaded: url_helper
INFO - 2021-06-12 04:27:44 --> Helper loaded: file_helper
INFO - 2021-06-12 04:27:44 --> Helper loaded: form_helper
INFO - 2021-06-12 04:27:44 --> Helper loaded: my_helper
INFO - 2021-06-12 04:27:44 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:27:44 --> Controller Class Initialized
INFO - 2021-06-12 04:32:11 --> Config Class Initialized
INFO - 2021-06-12 04:32:11 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:32:11 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:32:11 --> Utf8 Class Initialized
INFO - 2021-06-12 04:32:11 --> URI Class Initialized
INFO - 2021-06-12 04:32:11 --> Router Class Initialized
INFO - 2021-06-12 04:32:11 --> Output Class Initialized
INFO - 2021-06-12 04:32:11 --> Security Class Initialized
DEBUG - 2021-06-12 04:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:32:11 --> Input Class Initialized
INFO - 2021-06-12 04:32:11 --> Language Class Initialized
INFO - 2021-06-12 04:32:11 --> Language Class Initialized
INFO - 2021-06-12 04:32:11 --> Config Class Initialized
INFO - 2021-06-12 04:32:11 --> Loader Class Initialized
INFO - 2021-06-12 04:32:11 --> Helper loaded: url_helper
INFO - 2021-06-12 04:32:11 --> Helper loaded: file_helper
INFO - 2021-06-12 04:32:11 --> Helper loaded: form_helper
INFO - 2021-06-12 04:32:11 --> Helper loaded: my_helper
INFO - 2021-06-12 04:32:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:32:11 --> Controller Class Initialized
INFO - 2021-06-12 04:32:11 --> Final output sent to browser
DEBUG - 2021-06-12 04:32:11 --> Total execution time: 0.0639
INFO - 2021-06-12 04:32:31 --> Config Class Initialized
INFO - 2021-06-12 04:32:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:32:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:32:31 --> Utf8 Class Initialized
INFO - 2021-06-12 04:32:31 --> URI Class Initialized
INFO - 2021-06-12 04:32:31 --> Router Class Initialized
INFO - 2021-06-12 04:32:31 --> Output Class Initialized
INFO - 2021-06-12 04:32:31 --> Security Class Initialized
DEBUG - 2021-06-12 04:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:32:31 --> Input Class Initialized
INFO - 2021-06-12 04:32:31 --> Language Class Initialized
INFO - 2021-06-12 04:32:31 --> Language Class Initialized
INFO - 2021-06-12 04:32:31 --> Config Class Initialized
INFO - 2021-06-12 04:32:31 --> Loader Class Initialized
INFO - 2021-06-12 04:32:31 --> Helper loaded: url_helper
INFO - 2021-06-12 04:32:31 --> Helper loaded: file_helper
INFO - 2021-06-12 04:32:31 --> Helper loaded: form_helper
INFO - 2021-06-12 04:32:31 --> Helper loaded: my_helper
INFO - 2021-06-12 04:32:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:32:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:32:31 --> Controller Class Initialized
INFO - 2021-06-12 04:32:31 --> Final output sent to browser
DEBUG - 2021-06-12 04:32:31 --> Total execution time: 0.0494
INFO - 2021-06-12 04:32:46 --> Config Class Initialized
INFO - 2021-06-12 04:32:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:32:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:32:46 --> Utf8 Class Initialized
INFO - 2021-06-12 04:32:46 --> URI Class Initialized
INFO - 2021-06-12 04:32:46 --> Router Class Initialized
INFO - 2021-06-12 04:32:46 --> Output Class Initialized
INFO - 2021-06-12 04:32:46 --> Security Class Initialized
DEBUG - 2021-06-12 04:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:32:46 --> Input Class Initialized
INFO - 2021-06-12 04:32:46 --> Language Class Initialized
INFO - 2021-06-12 04:32:46 --> Language Class Initialized
INFO - 2021-06-12 04:32:46 --> Config Class Initialized
INFO - 2021-06-12 04:32:46 --> Loader Class Initialized
INFO - 2021-06-12 04:32:46 --> Helper loaded: url_helper
INFO - 2021-06-12 04:32:46 --> Helper loaded: file_helper
INFO - 2021-06-12 04:32:46 --> Helper loaded: form_helper
INFO - 2021-06-12 04:32:46 --> Helper loaded: my_helper
INFO - 2021-06-12 04:32:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:32:46 --> Controller Class Initialized
INFO - 2021-06-12 04:32:46 --> Final output sent to browser
DEBUG - 2021-06-12 04:32:46 --> Total execution time: 0.0514
INFO - 2021-06-12 04:32:46 --> Config Class Initialized
INFO - 2021-06-12 04:32:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:32:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:32:46 --> Utf8 Class Initialized
INFO - 2021-06-12 04:32:46 --> URI Class Initialized
INFO - 2021-06-12 04:32:46 --> Router Class Initialized
INFO - 2021-06-12 04:32:46 --> Output Class Initialized
INFO - 2021-06-12 04:32:46 --> Security Class Initialized
DEBUG - 2021-06-12 04:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:32:46 --> Input Class Initialized
INFO - 2021-06-12 04:32:46 --> Language Class Initialized
INFO - 2021-06-12 04:32:46 --> Language Class Initialized
INFO - 2021-06-12 04:32:46 --> Config Class Initialized
INFO - 2021-06-12 04:32:46 --> Loader Class Initialized
INFO - 2021-06-12 04:32:46 --> Helper loaded: url_helper
INFO - 2021-06-12 04:32:46 --> Helper loaded: file_helper
INFO - 2021-06-12 04:32:46 --> Helper loaded: form_helper
INFO - 2021-06-12 04:32:46 --> Helper loaded: my_helper
INFO - 2021-06-12 04:32:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:32:46 --> Controller Class Initialized
INFO - 2021-06-12 04:33:12 --> Config Class Initialized
INFO - 2021-06-12 04:33:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:12 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:12 --> URI Class Initialized
INFO - 2021-06-12 04:33:12 --> Router Class Initialized
INFO - 2021-06-12 04:33:12 --> Output Class Initialized
INFO - 2021-06-12 04:33:12 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:12 --> Input Class Initialized
INFO - 2021-06-12 04:33:12 --> Language Class Initialized
INFO - 2021-06-12 04:33:12 --> Language Class Initialized
INFO - 2021-06-12 04:33:12 --> Config Class Initialized
INFO - 2021-06-12 04:33:12 --> Loader Class Initialized
INFO - 2021-06-12 04:33:12 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:12 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:12 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:12 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:12 --> Controller Class Initialized
INFO - 2021-06-12 04:33:12 --> Final output sent to browser
DEBUG - 2021-06-12 04:33:12 --> Total execution time: 0.0494
INFO - 2021-06-12 04:33:18 --> Config Class Initialized
INFO - 2021-06-12 04:33:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:18 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:18 --> URI Class Initialized
INFO - 2021-06-12 04:33:18 --> Router Class Initialized
INFO - 2021-06-12 04:33:18 --> Output Class Initialized
INFO - 2021-06-12 04:33:18 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:18 --> Input Class Initialized
INFO - 2021-06-12 04:33:18 --> Language Class Initialized
INFO - 2021-06-12 04:33:18 --> Language Class Initialized
INFO - 2021-06-12 04:33:18 --> Config Class Initialized
INFO - 2021-06-12 04:33:18 --> Loader Class Initialized
INFO - 2021-06-12 04:33:18 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:18 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:18 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:18 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:18 --> Controller Class Initialized
INFO - 2021-06-12 04:33:18 --> Final output sent to browser
DEBUG - 2021-06-12 04:33:18 --> Total execution time: 0.0503
INFO - 2021-06-12 04:33:18 --> Config Class Initialized
INFO - 2021-06-12 04:33:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:18 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:18 --> URI Class Initialized
INFO - 2021-06-12 04:33:18 --> Router Class Initialized
INFO - 2021-06-12 04:33:18 --> Output Class Initialized
INFO - 2021-06-12 04:33:18 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:18 --> Input Class Initialized
INFO - 2021-06-12 04:33:18 --> Language Class Initialized
INFO - 2021-06-12 04:33:18 --> Language Class Initialized
INFO - 2021-06-12 04:33:18 --> Config Class Initialized
INFO - 2021-06-12 04:33:18 --> Loader Class Initialized
INFO - 2021-06-12 04:33:18 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:18 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:18 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:18 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:18 --> Controller Class Initialized
INFO - 2021-06-12 04:33:31 --> Config Class Initialized
INFO - 2021-06-12 04:33:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:31 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:31 --> URI Class Initialized
INFO - 2021-06-12 04:33:31 --> Router Class Initialized
INFO - 2021-06-12 04:33:31 --> Output Class Initialized
INFO - 2021-06-12 04:33:31 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:31 --> Input Class Initialized
INFO - 2021-06-12 04:33:31 --> Language Class Initialized
INFO - 2021-06-12 04:33:31 --> Language Class Initialized
INFO - 2021-06-12 04:33:31 --> Config Class Initialized
INFO - 2021-06-12 04:33:31 --> Loader Class Initialized
INFO - 2021-06-12 04:33:31 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:31 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:31 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:31 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:31 --> Controller Class Initialized
INFO - 2021-06-12 04:33:31 --> Final output sent to browser
DEBUG - 2021-06-12 04:33:31 --> Total execution time: 0.0501
INFO - 2021-06-12 04:33:37 --> Config Class Initialized
INFO - 2021-06-12 04:33:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:37 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:37 --> URI Class Initialized
INFO - 2021-06-12 04:33:37 --> Router Class Initialized
INFO - 2021-06-12 04:33:37 --> Output Class Initialized
INFO - 2021-06-12 04:33:37 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:37 --> Input Class Initialized
INFO - 2021-06-12 04:33:37 --> Language Class Initialized
INFO - 2021-06-12 04:33:37 --> Language Class Initialized
INFO - 2021-06-12 04:33:37 --> Config Class Initialized
INFO - 2021-06-12 04:33:37 --> Loader Class Initialized
INFO - 2021-06-12 04:33:37 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:37 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:37 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:37 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:37 --> Controller Class Initialized
INFO - 2021-06-12 04:33:37 --> Final output sent to browser
DEBUG - 2021-06-12 04:33:37 --> Total execution time: 0.0506
INFO - 2021-06-12 04:33:37 --> Config Class Initialized
INFO - 2021-06-12 04:33:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:37 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:37 --> URI Class Initialized
INFO - 2021-06-12 04:33:37 --> Router Class Initialized
INFO - 2021-06-12 04:33:37 --> Output Class Initialized
INFO - 2021-06-12 04:33:37 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:37 --> Input Class Initialized
INFO - 2021-06-12 04:33:37 --> Language Class Initialized
INFO - 2021-06-12 04:33:37 --> Language Class Initialized
INFO - 2021-06-12 04:33:37 --> Config Class Initialized
INFO - 2021-06-12 04:33:37 --> Loader Class Initialized
INFO - 2021-06-12 04:33:37 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:37 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:37 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:37 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:37 --> Controller Class Initialized
INFO - 2021-06-12 04:33:41 --> Config Class Initialized
INFO - 2021-06-12 04:33:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:41 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:41 --> URI Class Initialized
INFO - 2021-06-12 04:33:41 --> Router Class Initialized
INFO - 2021-06-12 04:33:41 --> Output Class Initialized
INFO - 2021-06-12 04:33:41 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:41 --> Input Class Initialized
INFO - 2021-06-12 04:33:41 --> Language Class Initialized
INFO - 2021-06-12 04:33:41 --> Language Class Initialized
INFO - 2021-06-12 04:33:41 --> Config Class Initialized
INFO - 2021-06-12 04:33:41 --> Loader Class Initialized
INFO - 2021-06-12 04:33:41 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:41 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:41 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:41 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:41 --> Controller Class Initialized
DEBUG - 2021-06-12 04:33:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:33:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:33:41 --> Final output sent to browser
DEBUG - 2021-06-12 04:33:41 --> Total execution time: 0.0507
INFO - 2021-06-12 04:33:43 --> Config Class Initialized
INFO - 2021-06-12 04:33:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:43 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:43 --> URI Class Initialized
INFO - 2021-06-12 04:33:43 --> Router Class Initialized
INFO - 2021-06-12 04:33:43 --> Output Class Initialized
INFO - 2021-06-12 04:33:43 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:43 --> Input Class Initialized
INFO - 2021-06-12 04:33:43 --> Language Class Initialized
INFO - 2021-06-12 04:33:43 --> Language Class Initialized
INFO - 2021-06-12 04:33:43 --> Config Class Initialized
INFO - 2021-06-12 04:33:43 --> Loader Class Initialized
INFO - 2021-06-12 04:33:43 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:43 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:43 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:43 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:43 --> Controller Class Initialized
DEBUG - 2021-06-12 04:33:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 04:33:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:33:43 --> Final output sent to browser
DEBUG - 2021-06-12 04:33:43 --> Total execution time: 0.1122
INFO - 2021-06-12 04:33:46 --> Config Class Initialized
INFO - 2021-06-12 04:33:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:33:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:33:46 --> Utf8 Class Initialized
INFO - 2021-06-12 04:33:46 --> URI Class Initialized
INFO - 2021-06-12 04:33:46 --> Router Class Initialized
INFO - 2021-06-12 04:33:46 --> Output Class Initialized
INFO - 2021-06-12 04:33:46 --> Security Class Initialized
DEBUG - 2021-06-12 04:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:33:46 --> Input Class Initialized
INFO - 2021-06-12 04:33:46 --> Language Class Initialized
INFO - 2021-06-12 04:33:46 --> Language Class Initialized
INFO - 2021-06-12 04:33:46 --> Config Class Initialized
INFO - 2021-06-12 04:33:46 --> Loader Class Initialized
INFO - 2021-06-12 04:33:46 --> Helper loaded: url_helper
INFO - 2021-06-12 04:33:46 --> Helper loaded: file_helper
INFO - 2021-06-12 04:33:46 --> Helper loaded: form_helper
INFO - 2021-06-12 04:33:46 --> Helper loaded: my_helper
INFO - 2021-06-12 04:33:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:33:46 --> Controller Class Initialized
INFO - 2021-06-12 04:33:46 --> Final output sent to browser
DEBUG - 2021-06-12 04:33:46 --> Total execution time: 0.0489
INFO - 2021-06-12 04:34:01 --> Config Class Initialized
INFO - 2021-06-12 04:34:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:01 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:01 --> URI Class Initialized
INFO - 2021-06-12 04:34:01 --> Router Class Initialized
INFO - 2021-06-12 04:34:01 --> Output Class Initialized
INFO - 2021-06-12 04:34:01 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:01 --> Input Class Initialized
INFO - 2021-06-12 04:34:01 --> Language Class Initialized
INFO - 2021-06-12 04:34:01 --> Language Class Initialized
INFO - 2021-06-12 04:34:01 --> Config Class Initialized
INFO - 2021-06-12 04:34:01 --> Loader Class Initialized
INFO - 2021-06-12 04:34:01 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:01 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:01 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:01 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:01 --> Controller Class Initialized
INFO - 2021-06-12 04:34:01 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:01 --> Total execution time: 0.0390
INFO - 2021-06-12 04:34:06 --> Config Class Initialized
INFO - 2021-06-12 04:34:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:06 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:06 --> URI Class Initialized
INFO - 2021-06-12 04:34:06 --> Router Class Initialized
INFO - 2021-06-12 04:34:06 --> Output Class Initialized
INFO - 2021-06-12 04:34:06 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:06 --> Input Class Initialized
INFO - 2021-06-12 04:34:06 --> Language Class Initialized
INFO - 2021-06-12 04:34:06 --> Language Class Initialized
INFO - 2021-06-12 04:34:06 --> Config Class Initialized
INFO - 2021-06-12 04:34:06 --> Loader Class Initialized
INFO - 2021-06-12 04:34:06 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:06 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:06 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:06 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:07 --> Controller Class Initialized
INFO - 2021-06-12 04:34:07 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:07 --> Total execution time: 0.0500
INFO - 2021-06-12 04:34:07 --> Config Class Initialized
INFO - 2021-06-12 04:34:07 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:07 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:07 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:07 --> URI Class Initialized
INFO - 2021-06-12 04:34:07 --> Router Class Initialized
INFO - 2021-06-12 04:34:07 --> Output Class Initialized
INFO - 2021-06-12 04:34:07 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:07 --> Input Class Initialized
INFO - 2021-06-12 04:34:07 --> Language Class Initialized
INFO - 2021-06-12 04:34:07 --> Language Class Initialized
INFO - 2021-06-12 04:34:07 --> Config Class Initialized
INFO - 2021-06-12 04:34:07 --> Loader Class Initialized
INFO - 2021-06-12 04:34:07 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:07 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:07 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:07 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:07 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:07 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 04:34:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:07 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:07 --> Total execution time: 0.0527
INFO - 2021-06-12 04:34:21 --> Config Class Initialized
INFO - 2021-06-12 04:34:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:21 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:21 --> URI Class Initialized
INFO - 2021-06-12 04:34:21 --> Router Class Initialized
INFO - 2021-06-12 04:34:21 --> Output Class Initialized
INFO - 2021-06-12 04:34:21 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:21 --> Input Class Initialized
INFO - 2021-06-12 04:34:21 --> Language Class Initialized
INFO - 2021-06-12 04:34:21 --> Language Class Initialized
INFO - 2021-06-12 04:34:21 --> Config Class Initialized
INFO - 2021-06-12 04:34:21 --> Loader Class Initialized
INFO - 2021-06-12 04:34:21 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:21 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:21 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:21 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:21 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:34:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:21 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:21 --> Total execution time: 0.0409
INFO - 2021-06-12 04:34:23 --> Config Class Initialized
INFO - 2021-06-12 04:34:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:23 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:23 --> URI Class Initialized
INFO - 2021-06-12 04:34:23 --> Router Class Initialized
INFO - 2021-06-12 04:34:23 --> Output Class Initialized
INFO - 2021-06-12 04:34:23 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:23 --> Input Class Initialized
INFO - 2021-06-12 04:34:23 --> Language Class Initialized
INFO - 2021-06-12 04:34:23 --> Language Class Initialized
INFO - 2021-06-12 04:34:23 --> Config Class Initialized
INFO - 2021-06-12 04:34:23 --> Loader Class Initialized
INFO - 2021-06-12 04:34:23 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:23 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:23 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:23 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:23 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 04:34:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:23 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:23 --> Total execution time: 0.0508
INFO - 2021-06-12 04:34:24 --> Config Class Initialized
INFO - 2021-06-12 04:34:24 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:24 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:24 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:24 --> URI Class Initialized
INFO - 2021-06-12 04:34:24 --> Router Class Initialized
INFO - 2021-06-12 04:34:24 --> Output Class Initialized
INFO - 2021-06-12 04:34:24 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:24 --> Input Class Initialized
INFO - 2021-06-12 04:34:24 --> Language Class Initialized
INFO - 2021-06-12 04:34:24 --> Language Class Initialized
INFO - 2021-06-12 04:34:24 --> Config Class Initialized
INFO - 2021-06-12 04:34:24 --> Loader Class Initialized
INFO - 2021-06-12 04:34:24 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:24 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:24 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:24 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:24 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:24 --> Controller Class Initialized
INFO - 2021-06-12 04:34:24 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:24 --> Total execution time: 0.0499
INFO - 2021-06-12 04:34:29 --> Config Class Initialized
INFO - 2021-06-12 04:34:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:29 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:29 --> URI Class Initialized
INFO - 2021-06-12 04:34:29 --> Router Class Initialized
INFO - 2021-06-12 04:34:29 --> Output Class Initialized
INFO - 2021-06-12 04:34:29 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:29 --> Input Class Initialized
INFO - 2021-06-12 04:34:29 --> Language Class Initialized
INFO - 2021-06-12 04:34:29 --> Language Class Initialized
INFO - 2021-06-12 04:34:29 --> Config Class Initialized
INFO - 2021-06-12 04:34:29 --> Loader Class Initialized
INFO - 2021-06-12 04:34:29 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:29 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:29 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:29 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:29 --> Controller Class Initialized
INFO - 2021-06-12 04:34:29 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:29 --> Total execution time: 0.0510
INFO - 2021-06-12 04:34:29 --> Config Class Initialized
INFO - 2021-06-12 04:34:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:29 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:29 --> URI Class Initialized
INFO - 2021-06-12 04:34:29 --> Router Class Initialized
INFO - 2021-06-12 04:34:29 --> Output Class Initialized
INFO - 2021-06-12 04:34:29 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:29 --> Input Class Initialized
INFO - 2021-06-12 04:34:29 --> Language Class Initialized
INFO - 2021-06-12 04:34:29 --> Language Class Initialized
INFO - 2021-06-12 04:34:29 --> Config Class Initialized
INFO - 2021-06-12 04:34:29 --> Loader Class Initialized
INFO - 2021-06-12 04:34:29 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:29 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:29 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:29 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:29 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 04:34:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:29 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:29 --> Total execution time: 0.0436
INFO - 2021-06-12 04:34:43 --> Config Class Initialized
INFO - 2021-06-12 04:34:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:43 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:43 --> URI Class Initialized
INFO - 2021-06-12 04:34:43 --> Router Class Initialized
INFO - 2021-06-12 04:34:43 --> Output Class Initialized
INFO - 2021-06-12 04:34:43 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:43 --> Input Class Initialized
INFO - 2021-06-12 04:34:43 --> Language Class Initialized
INFO - 2021-06-12 04:34:43 --> Language Class Initialized
INFO - 2021-06-12 04:34:43 --> Config Class Initialized
INFO - 2021-06-12 04:34:43 --> Loader Class Initialized
INFO - 2021-06-12 04:34:43 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:43 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:43 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:43 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:43 --> Controller Class Initialized
INFO - 2021-06-12 04:34:43 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:43 --> Total execution time: 0.0491
INFO - 2021-06-12 04:34:49 --> Config Class Initialized
INFO - 2021-06-12 04:34:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:49 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:49 --> URI Class Initialized
INFO - 2021-06-12 04:34:49 --> Router Class Initialized
INFO - 2021-06-12 04:34:49 --> Output Class Initialized
INFO - 2021-06-12 04:34:49 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:49 --> Input Class Initialized
INFO - 2021-06-12 04:34:49 --> Language Class Initialized
INFO - 2021-06-12 04:34:49 --> Language Class Initialized
INFO - 2021-06-12 04:34:49 --> Config Class Initialized
INFO - 2021-06-12 04:34:49 --> Loader Class Initialized
INFO - 2021-06-12 04:34:49 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:49 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:49 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:49 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:49 --> Controller Class Initialized
INFO - 2021-06-12 04:34:49 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:49 --> Total execution time: 0.0491
INFO - 2021-06-12 04:34:49 --> Config Class Initialized
INFO - 2021-06-12 04:34:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:49 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:49 --> URI Class Initialized
INFO - 2021-06-12 04:34:49 --> Router Class Initialized
INFO - 2021-06-12 04:34:49 --> Output Class Initialized
INFO - 2021-06-12 04:34:49 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:49 --> Input Class Initialized
INFO - 2021-06-12 04:34:49 --> Language Class Initialized
INFO - 2021-06-12 04:34:49 --> Language Class Initialized
INFO - 2021-06-12 04:34:49 --> Config Class Initialized
INFO - 2021-06-12 04:34:49 --> Loader Class Initialized
INFO - 2021-06-12 04:34:49 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:49 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:49 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:49 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:49 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 04:34:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:49 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:49 --> Total execution time: 0.0419
INFO - 2021-06-12 04:34:50 --> Config Class Initialized
INFO - 2021-06-12 04:34:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:50 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:50 --> URI Class Initialized
INFO - 2021-06-12 04:34:50 --> Router Class Initialized
INFO - 2021-06-12 04:34:50 --> Output Class Initialized
INFO - 2021-06-12 04:34:50 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:50 --> Input Class Initialized
INFO - 2021-06-12 04:34:50 --> Language Class Initialized
INFO - 2021-06-12 04:34:50 --> Language Class Initialized
INFO - 2021-06-12 04:34:50 --> Config Class Initialized
INFO - 2021-06-12 04:34:50 --> Loader Class Initialized
INFO - 2021-06-12 04:34:50 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:50 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:50 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:50 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:50 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:50 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:50 --> Total execution time: 0.0418
INFO - 2021-06-12 04:34:51 --> Config Class Initialized
INFO - 2021-06-12 04:34:51 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:51 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:51 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:51 --> URI Class Initialized
INFO - 2021-06-12 04:34:52 --> Router Class Initialized
INFO - 2021-06-12 04:34:52 --> Output Class Initialized
INFO - 2021-06-12 04:34:52 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:52 --> Input Class Initialized
INFO - 2021-06-12 04:34:52 --> Language Class Initialized
INFO - 2021-06-12 04:34:52 --> Language Class Initialized
INFO - 2021-06-12 04:34:52 --> Config Class Initialized
INFO - 2021-06-12 04:34:52 --> Loader Class Initialized
INFO - 2021-06-12 04:34:52 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:52 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:52 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:52 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:52 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:52 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 04:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:52 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:52 --> Total execution time: 0.0504
INFO - 2021-06-12 04:34:52 --> Config Class Initialized
INFO - 2021-06-12 04:34:52 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:52 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:52 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:52 --> URI Class Initialized
INFO - 2021-06-12 04:34:52 --> Router Class Initialized
INFO - 2021-06-12 04:34:52 --> Output Class Initialized
INFO - 2021-06-12 04:34:52 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:52 --> Input Class Initialized
INFO - 2021-06-12 04:34:52 --> Language Class Initialized
INFO - 2021-06-12 04:34:52 --> Language Class Initialized
INFO - 2021-06-12 04:34:52 --> Config Class Initialized
INFO - 2021-06-12 04:34:52 --> Loader Class Initialized
INFO - 2021-06-12 04:34:52 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:52 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:52 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:52 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:52 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:52 --> Controller Class Initialized
INFO - 2021-06-12 04:34:54 --> Config Class Initialized
INFO - 2021-06-12 04:34:54 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:54 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:54 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:54 --> URI Class Initialized
INFO - 2021-06-12 04:34:54 --> Router Class Initialized
INFO - 2021-06-12 04:34:54 --> Output Class Initialized
INFO - 2021-06-12 04:34:54 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:54 --> Input Class Initialized
INFO - 2021-06-12 04:34:54 --> Language Class Initialized
INFO - 2021-06-12 04:34:54 --> Language Class Initialized
INFO - 2021-06-12 04:34:54 --> Config Class Initialized
INFO - 2021-06-12 04:34:54 --> Loader Class Initialized
INFO - 2021-06-12 04:34:54 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:54 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:54 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:54 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:54 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:54 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:34:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:54 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:54 --> Total execution time: 0.0492
INFO - 2021-06-12 04:34:57 --> Config Class Initialized
INFO - 2021-06-12 04:34:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:57 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:57 --> URI Class Initialized
INFO - 2021-06-12 04:34:57 --> Router Class Initialized
INFO - 2021-06-12 04:34:57 --> Output Class Initialized
INFO - 2021-06-12 04:34:57 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:57 --> Input Class Initialized
INFO - 2021-06-12 04:34:57 --> Language Class Initialized
INFO - 2021-06-12 04:34:57 --> Language Class Initialized
INFO - 2021-06-12 04:34:57 --> Config Class Initialized
INFO - 2021-06-12 04:34:57 --> Loader Class Initialized
INFO - 2021-06-12 04:34:57 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:57 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:57 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:57 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:57 --> Controller Class Initialized
DEBUG - 2021-06-12 04:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 04:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:34:57 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:57 --> Total execution time: 0.0504
INFO - 2021-06-12 04:34:57 --> Config Class Initialized
INFO - 2021-06-12 04:34:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:57 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:57 --> URI Class Initialized
INFO - 2021-06-12 04:34:57 --> Router Class Initialized
INFO - 2021-06-12 04:34:57 --> Output Class Initialized
INFO - 2021-06-12 04:34:57 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:57 --> Input Class Initialized
INFO - 2021-06-12 04:34:57 --> Language Class Initialized
INFO - 2021-06-12 04:34:57 --> Language Class Initialized
INFO - 2021-06-12 04:34:57 --> Config Class Initialized
INFO - 2021-06-12 04:34:57 --> Loader Class Initialized
INFO - 2021-06-12 04:34:57 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:57 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:57 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:57 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:57 --> Controller Class Initialized
INFO - 2021-06-12 04:34:59 --> Config Class Initialized
INFO - 2021-06-12 04:34:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:34:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:34:59 --> Utf8 Class Initialized
INFO - 2021-06-12 04:34:59 --> URI Class Initialized
INFO - 2021-06-12 04:34:59 --> Router Class Initialized
INFO - 2021-06-12 04:34:59 --> Output Class Initialized
INFO - 2021-06-12 04:34:59 --> Security Class Initialized
DEBUG - 2021-06-12 04:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:34:59 --> Input Class Initialized
INFO - 2021-06-12 04:34:59 --> Language Class Initialized
INFO - 2021-06-12 04:34:59 --> Language Class Initialized
INFO - 2021-06-12 04:34:59 --> Config Class Initialized
INFO - 2021-06-12 04:34:59 --> Loader Class Initialized
INFO - 2021-06-12 04:34:59 --> Helper loaded: url_helper
INFO - 2021-06-12 04:34:59 --> Helper loaded: file_helper
INFO - 2021-06-12 04:34:59 --> Helper loaded: form_helper
INFO - 2021-06-12 04:34:59 --> Helper loaded: my_helper
INFO - 2021-06-12 04:34:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:34:59 --> Controller Class Initialized
INFO - 2021-06-12 04:34:59 --> Final output sent to browser
DEBUG - 2021-06-12 04:34:59 --> Total execution time: 0.0742
INFO - 2021-06-12 04:35:04 --> Config Class Initialized
INFO - 2021-06-12 04:35:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:35:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:35:04 --> Utf8 Class Initialized
INFO - 2021-06-12 04:35:04 --> URI Class Initialized
INFO - 2021-06-12 04:35:04 --> Router Class Initialized
INFO - 2021-06-12 04:35:04 --> Output Class Initialized
INFO - 2021-06-12 04:35:04 --> Security Class Initialized
DEBUG - 2021-06-12 04:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:35:04 --> Input Class Initialized
INFO - 2021-06-12 04:35:04 --> Language Class Initialized
INFO - 2021-06-12 04:35:04 --> Language Class Initialized
INFO - 2021-06-12 04:35:04 --> Config Class Initialized
INFO - 2021-06-12 04:35:04 --> Loader Class Initialized
INFO - 2021-06-12 04:35:04 --> Helper loaded: url_helper
INFO - 2021-06-12 04:35:04 --> Helper loaded: file_helper
INFO - 2021-06-12 04:35:04 --> Helper loaded: form_helper
INFO - 2021-06-12 04:35:04 --> Helper loaded: my_helper
INFO - 2021-06-12 04:35:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:35:04 --> Controller Class Initialized
INFO - 2021-06-12 04:35:46 --> Config Class Initialized
INFO - 2021-06-12 04:35:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:35:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:35:46 --> Utf8 Class Initialized
INFO - 2021-06-12 04:35:46 --> URI Class Initialized
INFO - 2021-06-12 04:35:46 --> Router Class Initialized
INFO - 2021-06-12 04:35:46 --> Output Class Initialized
INFO - 2021-06-12 04:35:46 --> Security Class Initialized
DEBUG - 2021-06-12 04:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:35:46 --> Input Class Initialized
INFO - 2021-06-12 04:35:46 --> Language Class Initialized
INFO - 2021-06-12 04:35:46 --> Language Class Initialized
INFO - 2021-06-12 04:35:46 --> Config Class Initialized
INFO - 2021-06-12 04:35:46 --> Loader Class Initialized
INFO - 2021-06-12 04:35:46 --> Helper loaded: url_helper
INFO - 2021-06-12 04:35:46 --> Helper loaded: file_helper
INFO - 2021-06-12 04:35:46 --> Helper loaded: form_helper
INFO - 2021-06-12 04:35:46 --> Helper loaded: my_helper
INFO - 2021-06-12 04:35:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:35:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:35:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:35:46 --> Controller Class Initialized
DEBUG - 2021-06-12 04:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:35:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:35:46 --> Final output sent to browser
DEBUG - 2021-06-12 04:35:46 --> Total execution time: 0.0505
INFO - 2021-06-12 04:35:47 --> Config Class Initialized
INFO - 2021-06-12 04:35:47 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:35:47 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:35:47 --> Utf8 Class Initialized
INFO - 2021-06-12 04:35:47 --> URI Class Initialized
INFO - 2021-06-12 04:35:47 --> Router Class Initialized
INFO - 2021-06-12 04:35:47 --> Output Class Initialized
INFO - 2021-06-12 04:35:47 --> Security Class Initialized
DEBUG - 2021-06-12 04:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:35:47 --> Input Class Initialized
INFO - 2021-06-12 04:35:47 --> Language Class Initialized
INFO - 2021-06-12 04:35:47 --> Language Class Initialized
INFO - 2021-06-12 04:35:47 --> Config Class Initialized
INFO - 2021-06-12 04:35:47 --> Loader Class Initialized
INFO - 2021-06-12 04:35:47 --> Helper loaded: url_helper
INFO - 2021-06-12 04:35:47 --> Helper loaded: file_helper
INFO - 2021-06-12 04:35:47 --> Helper loaded: form_helper
INFO - 2021-06-12 04:35:47 --> Helper loaded: my_helper
INFO - 2021-06-12 04:35:47 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:35:47 --> Controller Class Initialized
DEBUG - 2021-06-12 04:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 04:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:35:47 --> Final output sent to browser
DEBUG - 2021-06-12 04:35:47 --> Total execution time: 0.0510
INFO - 2021-06-12 04:35:50 --> Config Class Initialized
INFO - 2021-06-12 04:35:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:35:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:35:50 --> Utf8 Class Initialized
INFO - 2021-06-12 04:35:50 --> URI Class Initialized
INFO - 2021-06-12 04:35:50 --> Router Class Initialized
INFO - 2021-06-12 04:35:50 --> Output Class Initialized
INFO - 2021-06-12 04:35:50 --> Security Class Initialized
DEBUG - 2021-06-12 04:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:35:50 --> Input Class Initialized
INFO - 2021-06-12 04:35:50 --> Language Class Initialized
INFO - 2021-06-12 04:35:50 --> Language Class Initialized
INFO - 2021-06-12 04:35:50 --> Config Class Initialized
INFO - 2021-06-12 04:35:50 --> Loader Class Initialized
INFO - 2021-06-12 04:35:50 --> Helper loaded: url_helper
INFO - 2021-06-12 04:35:50 --> Helper loaded: file_helper
INFO - 2021-06-12 04:35:50 --> Helper loaded: form_helper
INFO - 2021-06-12 04:35:50 --> Helper loaded: my_helper
INFO - 2021-06-12 04:35:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:35:50 --> Controller Class Initialized
INFO - 2021-06-12 04:36:17 --> Config Class Initialized
INFO - 2021-06-12 04:36:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:36:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:36:17 --> Utf8 Class Initialized
INFO - 2021-06-12 04:36:17 --> URI Class Initialized
INFO - 2021-06-12 04:36:17 --> Router Class Initialized
INFO - 2021-06-12 04:36:17 --> Output Class Initialized
INFO - 2021-06-12 04:36:17 --> Security Class Initialized
DEBUG - 2021-06-12 04:36:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:36:17 --> Input Class Initialized
INFO - 2021-06-12 04:36:17 --> Language Class Initialized
INFO - 2021-06-12 04:36:17 --> Language Class Initialized
INFO - 2021-06-12 04:36:17 --> Config Class Initialized
INFO - 2021-06-12 04:36:17 --> Loader Class Initialized
INFO - 2021-06-12 04:36:17 --> Helper loaded: url_helper
INFO - 2021-06-12 04:36:17 --> Helper loaded: file_helper
INFO - 2021-06-12 04:36:17 --> Helper loaded: form_helper
INFO - 2021-06-12 04:36:17 --> Helper loaded: my_helper
INFO - 2021-06-12 04:36:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:36:17 --> Controller Class Initialized
DEBUG - 2021-06-12 04:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:36:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:36:17 --> Final output sent to browser
DEBUG - 2021-06-12 04:36:17 --> Total execution time: 0.0522
INFO - 2021-06-12 04:36:19 --> Config Class Initialized
INFO - 2021-06-12 04:36:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:36:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:36:19 --> Utf8 Class Initialized
INFO - 2021-06-12 04:36:19 --> URI Class Initialized
INFO - 2021-06-12 04:36:19 --> Router Class Initialized
INFO - 2021-06-12 04:36:19 --> Output Class Initialized
INFO - 2021-06-12 04:36:19 --> Security Class Initialized
DEBUG - 2021-06-12 04:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:36:19 --> Input Class Initialized
INFO - 2021-06-12 04:36:19 --> Language Class Initialized
INFO - 2021-06-12 04:36:19 --> Language Class Initialized
INFO - 2021-06-12 04:36:19 --> Config Class Initialized
INFO - 2021-06-12 04:36:19 --> Loader Class Initialized
INFO - 2021-06-12 04:36:19 --> Helper loaded: url_helper
INFO - 2021-06-12 04:36:19 --> Helper loaded: file_helper
INFO - 2021-06-12 04:36:19 --> Helper loaded: form_helper
INFO - 2021-06-12 04:36:19 --> Helper loaded: my_helper
INFO - 2021-06-12 04:36:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:36:19 --> Controller Class Initialized
DEBUG - 2021-06-12 04:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 04:36:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:36:19 --> Final output sent to browser
DEBUG - 2021-06-12 04:36:19 --> Total execution time: 0.0511
INFO - 2021-06-12 04:36:19 --> Config Class Initialized
INFO - 2021-06-12 04:36:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:36:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:36:19 --> Utf8 Class Initialized
INFO - 2021-06-12 04:36:19 --> URI Class Initialized
INFO - 2021-06-12 04:36:19 --> Router Class Initialized
INFO - 2021-06-12 04:36:19 --> Output Class Initialized
INFO - 2021-06-12 04:36:19 --> Security Class Initialized
DEBUG - 2021-06-12 04:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:36:19 --> Input Class Initialized
INFO - 2021-06-12 04:36:19 --> Language Class Initialized
INFO - 2021-06-12 04:36:19 --> Language Class Initialized
INFO - 2021-06-12 04:36:19 --> Config Class Initialized
INFO - 2021-06-12 04:36:19 --> Loader Class Initialized
INFO - 2021-06-12 04:36:19 --> Helper loaded: url_helper
INFO - 2021-06-12 04:36:19 --> Helper loaded: file_helper
INFO - 2021-06-12 04:36:19 --> Helper loaded: form_helper
INFO - 2021-06-12 04:36:19 --> Helper loaded: my_helper
INFO - 2021-06-12 04:36:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:36:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:36:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:36:19 --> Controller Class Initialized
INFO - 2021-06-12 04:36:21 --> Config Class Initialized
INFO - 2021-06-12 04:36:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:36:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:36:21 --> Utf8 Class Initialized
INFO - 2021-06-12 04:36:21 --> URI Class Initialized
INFO - 2021-06-12 04:36:21 --> Router Class Initialized
INFO - 2021-06-12 04:36:21 --> Output Class Initialized
INFO - 2021-06-12 04:36:21 --> Security Class Initialized
DEBUG - 2021-06-12 04:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:36:21 --> Input Class Initialized
INFO - 2021-06-12 04:36:21 --> Language Class Initialized
INFO - 2021-06-12 04:36:21 --> Language Class Initialized
INFO - 2021-06-12 04:36:21 --> Config Class Initialized
INFO - 2021-06-12 04:36:21 --> Loader Class Initialized
INFO - 2021-06-12 04:36:21 --> Helper loaded: url_helper
INFO - 2021-06-12 04:36:21 --> Helper loaded: file_helper
INFO - 2021-06-12 04:36:21 --> Helper loaded: form_helper
INFO - 2021-06-12 04:36:21 --> Helper loaded: my_helper
INFO - 2021-06-12 04:36:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:36:21 --> Controller Class Initialized
INFO - 2021-06-12 04:36:39 --> Config Class Initialized
INFO - 2021-06-12 04:36:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:36:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:36:39 --> Utf8 Class Initialized
INFO - 2021-06-12 04:36:39 --> URI Class Initialized
INFO - 2021-06-12 04:36:39 --> Router Class Initialized
INFO - 2021-06-12 04:36:39 --> Output Class Initialized
INFO - 2021-06-12 04:36:39 --> Security Class Initialized
DEBUG - 2021-06-12 04:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:36:39 --> Input Class Initialized
INFO - 2021-06-12 04:36:39 --> Language Class Initialized
INFO - 2021-06-12 04:36:39 --> Language Class Initialized
INFO - 2021-06-12 04:36:39 --> Config Class Initialized
INFO - 2021-06-12 04:36:39 --> Loader Class Initialized
INFO - 2021-06-12 04:36:39 --> Helper loaded: url_helper
INFO - 2021-06-12 04:36:39 --> Helper loaded: file_helper
INFO - 2021-06-12 04:36:39 --> Helper loaded: form_helper
INFO - 2021-06-12 04:36:39 --> Helper loaded: my_helper
INFO - 2021-06-12 04:36:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:36:39 --> Controller Class Initialized
DEBUG - 2021-06-12 04:36:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 04:36:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:36:39 --> Final output sent to browser
DEBUG - 2021-06-12 04:36:39 --> Total execution time: 0.0413
INFO - 2021-06-12 04:36:40 --> Config Class Initialized
INFO - 2021-06-12 04:36:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:36:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:36:40 --> Utf8 Class Initialized
INFO - 2021-06-12 04:36:40 --> URI Class Initialized
INFO - 2021-06-12 04:36:40 --> Router Class Initialized
INFO - 2021-06-12 04:36:40 --> Output Class Initialized
INFO - 2021-06-12 04:36:40 --> Security Class Initialized
DEBUG - 2021-06-12 04:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:36:40 --> Input Class Initialized
INFO - 2021-06-12 04:36:40 --> Language Class Initialized
INFO - 2021-06-12 04:36:40 --> Language Class Initialized
INFO - 2021-06-12 04:36:40 --> Config Class Initialized
INFO - 2021-06-12 04:36:40 --> Loader Class Initialized
INFO - 2021-06-12 04:36:40 --> Helper loaded: url_helper
INFO - 2021-06-12 04:36:40 --> Helper loaded: file_helper
INFO - 2021-06-12 04:36:40 --> Helper loaded: form_helper
INFO - 2021-06-12 04:36:40 --> Helper loaded: my_helper
INFO - 2021-06-12 04:36:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:36:40 --> Controller Class Initialized
DEBUG - 2021-06-12 04:36:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 04:36:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:36:40 --> Final output sent to browser
DEBUG - 2021-06-12 04:36:40 --> Total execution time: 0.0509
INFO - 2021-06-12 04:36:42 --> Config Class Initialized
INFO - 2021-06-12 04:36:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:36:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:36:42 --> Utf8 Class Initialized
INFO - 2021-06-12 04:36:42 --> URI Class Initialized
INFO - 2021-06-12 04:36:42 --> Router Class Initialized
INFO - 2021-06-12 04:36:42 --> Output Class Initialized
INFO - 2021-06-12 04:36:42 --> Security Class Initialized
DEBUG - 2021-06-12 04:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:36:42 --> Input Class Initialized
INFO - 2021-06-12 04:36:42 --> Language Class Initialized
INFO - 2021-06-12 04:36:42 --> Language Class Initialized
INFO - 2021-06-12 04:36:42 --> Config Class Initialized
INFO - 2021-06-12 04:36:42 --> Loader Class Initialized
INFO - 2021-06-12 04:36:42 --> Helper loaded: url_helper
INFO - 2021-06-12 04:36:42 --> Helper loaded: file_helper
INFO - 2021-06-12 04:36:42 --> Helper loaded: form_helper
INFO - 2021-06-12 04:36:42 --> Helper loaded: my_helper
INFO - 2021-06-12 04:36:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:36:42 --> Controller Class Initialized
INFO - 2021-06-12 04:37:27 --> Config Class Initialized
INFO - 2021-06-12 04:37:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:37:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:37:27 --> Utf8 Class Initialized
INFO - 2021-06-12 04:37:27 --> URI Class Initialized
INFO - 2021-06-12 04:37:27 --> Router Class Initialized
INFO - 2021-06-12 04:37:27 --> Output Class Initialized
INFO - 2021-06-12 04:37:27 --> Security Class Initialized
DEBUG - 2021-06-12 04:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:37:27 --> Input Class Initialized
INFO - 2021-06-12 04:37:27 --> Language Class Initialized
INFO - 2021-06-12 04:37:27 --> Language Class Initialized
INFO - 2021-06-12 04:37:27 --> Config Class Initialized
INFO - 2021-06-12 04:37:27 --> Loader Class Initialized
INFO - 2021-06-12 04:37:27 --> Helper loaded: url_helper
INFO - 2021-06-12 04:37:27 --> Helper loaded: file_helper
INFO - 2021-06-12 04:37:27 --> Helper loaded: form_helper
INFO - 2021-06-12 04:37:27 --> Helper loaded: my_helper
INFO - 2021-06-12 04:37:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:37:27 --> Controller Class Initialized
INFO - 2021-06-12 04:37:27 --> Helper loaded: cookie_helper
INFO - 2021-06-12 04:37:27 --> Config Class Initialized
INFO - 2021-06-12 04:37:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 04:37:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 04:37:27 --> Utf8 Class Initialized
INFO - 2021-06-12 04:37:27 --> URI Class Initialized
INFO - 2021-06-12 04:37:27 --> Router Class Initialized
INFO - 2021-06-12 04:37:27 --> Output Class Initialized
INFO - 2021-06-12 04:37:27 --> Security Class Initialized
DEBUG - 2021-06-12 04:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 04:37:27 --> Input Class Initialized
INFO - 2021-06-12 04:37:27 --> Language Class Initialized
INFO - 2021-06-12 04:37:27 --> Language Class Initialized
INFO - 2021-06-12 04:37:27 --> Config Class Initialized
INFO - 2021-06-12 04:37:27 --> Loader Class Initialized
INFO - 2021-06-12 04:37:27 --> Helper loaded: url_helper
INFO - 2021-06-12 04:37:27 --> Helper loaded: file_helper
INFO - 2021-06-12 04:37:27 --> Helper loaded: form_helper
INFO - 2021-06-12 04:37:27 --> Helper loaded: my_helper
INFO - 2021-06-12 04:37:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 04:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 04:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 04:37:27 --> Controller Class Initialized
DEBUG - 2021-06-12 04:37:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 04:37:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 04:37:27 --> Final output sent to browser
DEBUG - 2021-06-12 04:37:27 --> Total execution time: 0.0483
INFO - 2021-06-12 05:40:22 --> Config Class Initialized
INFO - 2021-06-12 05:40:22 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:40:22 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:40:22 --> Utf8 Class Initialized
INFO - 2021-06-12 05:40:22 --> URI Class Initialized
INFO - 2021-06-12 05:40:22 --> Router Class Initialized
INFO - 2021-06-12 05:40:22 --> Output Class Initialized
INFO - 2021-06-12 05:40:22 --> Security Class Initialized
DEBUG - 2021-06-12 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:40:22 --> Input Class Initialized
INFO - 2021-06-12 05:40:22 --> Language Class Initialized
INFO - 2021-06-12 05:40:22 --> Language Class Initialized
INFO - 2021-06-12 05:40:22 --> Config Class Initialized
INFO - 2021-06-12 05:40:22 --> Loader Class Initialized
INFO - 2021-06-12 05:40:22 --> Helper loaded: url_helper
INFO - 2021-06-12 05:40:22 --> Helper loaded: file_helper
INFO - 2021-06-12 05:40:22 --> Helper loaded: form_helper
INFO - 2021-06-12 05:40:22 --> Helper loaded: my_helper
INFO - 2021-06-12 05:40:22 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:40:22 --> Controller Class Initialized
DEBUG - 2021-06-12 05:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 05:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:40:22 --> Final output sent to browser
DEBUG - 2021-06-12 05:40:22 --> Total execution time: 0.0653
INFO - 2021-06-12 05:40:41 --> Config Class Initialized
INFO - 2021-06-12 05:40:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:40:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:40:41 --> Utf8 Class Initialized
INFO - 2021-06-12 05:40:41 --> URI Class Initialized
INFO - 2021-06-12 05:40:41 --> Router Class Initialized
INFO - 2021-06-12 05:40:41 --> Output Class Initialized
INFO - 2021-06-12 05:40:41 --> Security Class Initialized
DEBUG - 2021-06-12 05:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:40:41 --> Input Class Initialized
INFO - 2021-06-12 05:40:41 --> Language Class Initialized
INFO - 2021-06-12 05:40:41 --> Language Class Initialized
INFO - 2021-06-12 05:40:41 --> Config Class Initialized
INFO - 2021-06-12 05:40:41 --> Loader Class Initialized
INFO - 2021-06-12 05:40:41 --> Helper loaded: url_helper
INFO - 2021-06-12 05:40:41 --> Helper loaded: file_helper
INFO - 2021-06-12 05:40:41 --> Helper loaded: form_helper
INFO - 2021-06-12 05:40:41 --> Helper loaded: my_helper
INFO - 2021-06-12 05:40:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:40:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:40:41 --> Controller Class Initialized
INFO - 2021-06-12 05:40:41 --> Final output sent to browser
DEBUG - 2021-06-12 05:40:41 --> Total execution time: 0.0521
INFO - 2021-06-12 05:40:47 --> Config Class Initialized
INFO - 2021-06-12 05:40:47 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:40:47 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:40:47 --> Utf8 Class Initialized
INFO - 2021-06-12 05:40:47 --> URI Class Initialized
INFO - 2021-06-12 05:40:47 --> Router Class Initialized
INFO - 2021-06-12 05:40:47 --> Output Class Initialized
INFO - 2021-06-12 05:40:47 --> Security Class Initialized
DEBUG - 2021-06-12 05:40:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:40:47 --> Input Class Initialized
INFO - 2021-06-12 05:40:47 --> Language Class Initialized
INFO - 2021-06-12 05:40:47 --> Language Class Initialized
INFO - 2021-06-12 05:40:47 --> Config Class Initialized
INFO - 2021-06-12 05:40:47 --> Loader Class Initialized
INFO - 2021-06-12 05:40:47 --> Helper loaded: url_helper
INFO - 2021-06-12 05:40:47 --> Helper loaded: file_helper
INFO - 2021-06-12 05:40:47 --> Helper loaded: form_helper
INFO - 2021-06-12 05:40:47 --> Helper loaded: my_helper
INFO - 2021-06-12 05:40:47 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:40:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:40:47 --> Controller Class Initialized
INFO - 2021-06-12 05:40:47 --> Helper loaded: cookie_helper
INFO - 2021-06-12 05:40:47 --> Final output sent to browser
DEBUG - 2021-06-12 05:40:47 --> Total execution time: 0.0472
INFO - 2021-06-12 05:40:48 --> Config Class Initialized
INFO - 2021-06-12 05:40:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:40:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:40:48 --> Utf8 Class Initialized
INFO - 2021-06-12 05:40:48 --> URI Class Initialized
INFO - 2021-06-12 05:40:48 --> Router Class Initialized
INFO - 2021-06-12 05:40:48 --> Output Class Initialized
INFO - 2021-06-12 05:40:48 --> Security Class Initialized
DEBUG - 2021-06-12 05:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:40:48 --> Input Class Initialized
INFO - 2021-06-12 05:40:48 --> Language Class Initialized
INFO - 2021-06-12 05:40:48 --> Language Class Initialized
INFO - 2021-06-12 05:40:48 --> Config Class Initialized
INFO - 2021-06-12 05:40:48 --> Loader Class Initialized
INFO - 2021-06-12 05:40:48 --> Helper loaded: url_helper
INFO - 2021-06-12 05:40:48 --> Helper loaded: file_helper
INFO - 2021-06-12 05:40:48 --> Helper loaded: form_helper
INFO - 2021-06-12 05:40:48 --> Helper loaded: my_helper
INFO - 2021-06-12 05:40:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:40:48 --> Controller Class Initialized
DEBUG - 2021-06-12 05:40:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 05:40:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:40:48 --> Final output sent to browser
DEBUG - 2021-06-12 05:40:48 --> Total execution time: 0.0844
INFO - 2021-06-12 05:41:37 --> Config Class Initialized
INFO - 2021-06-12 05:41:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:41:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:41:37 --> Utf8 Class Initialized
INFO - 2021-06-12 05:41:37 --> URI Class Initialized
INFO - 2021-06-12 05:41:37 --> Router Class Initialized
INFO - 2021-06-12 05:41:37 --> Output Class Initialized
INFO - 2021-06-12 05:41:37 --> Security Class Initialized
DEBUG - 2021-06-12 05:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:41:37 --> Input Class Initialized
INFO - 2021-06-12 05:41:37 --> Language Class Initialized
INFO - 2021-06-12 05:41:37 --> Language Class Initialized
INFO - 2021-06-12 05:41:37 --> Config Class Initialized
INFO - 2021-06-12 05:41:37 --> Loader Class Initialized
INFO - 2021-06-12 05:41:37 --> Helper loaded: url_helper
INFO - 2021-06-12 05:41:37 --> Helper loaded: file_helper
INFO - 2021-06-12 05:41:37 --> Helper loaded: form_helper
INFO - 2021-06-12 05:41:37 --> Helper loaded: my_helper
INFO - 2021-06-12 05:41:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:41:37 --> Controller Class Initialized
DEBUG - 2021-06-12 05:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2021-06-12 05:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:41:37 --> Final output sent to browser
DEBUG - 2021-06-12 05:41:37 --> Total execution time: 0.0803
INFO - 2021-06-12 05:41:49 --> Config Class Initialized
INFO - 2021-06-12 05:41:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:41:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:41:49 --> Utf8 Class Initialized
INFO - 2021-06-12 05:41:49 --> URI Class Initialized
INFO - 2021-06-12 05:41:49 --> Router Class Initialized
INFO - 2021-06-12 05:41:49 --> Output Class Initialized
INFO - 2021-06-12 05:41:49 --> Security Class Initialized
DEBUG - 2021-06-12 05:41:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:41:49 --> Input Class Initialized
INFO - 2021-06-12 05:41:49 --> Language Class Initialized
INFO - 2021-06-12 05:41:49 --> Language Class Initialized
INFO - 2021-06-12 05:41:49 --> Config Class Initialized
INFO - 2021-06-12 05:41:49 --> Loader Class Initialized
INFO - 2021-06-12 05:41:49 --> Helper loaded: url_helper
INFO - 2021-06-12 05:41:49 --> Helper loaded: file_helper
INFO - 2021-06-12 05:41:49 --> Helper loaded: form_helper
INFO - 2021-06-12 05:41:49 --> Helper loaded: my_helper
INFO - 2021-06-12 05:41:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:41:49 --> Controller Class Initialized
INFO - 2021-06-12 05:41:53 --> Config Class Initialized
INFO - 2021-06-12 05:41:53 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:41:53 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:41:53 --> Utf8 Class Initialized
INFO - 2021-06-12 05:41:53 --> URI Class Initialized
INFO - 2021-06-12 05:41:53 --> Router Class Initialized
INFO - 2021-06-12 05:41:53 --> Output Class Initialized
INFO - 2021-06-12 05:41:53 --> Security Class Initialized
DEBUG - 2021-06-12 05:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:41:53 --> Input Class Initialized
INFO - 2021-06-12 05:41:53 --> Language Class Initialized
INFO - 2021-06-12 05:41:53 --> Language Class Initialized
INFO - 2021-06-12 05:41:53 --> Config Class Initialized
INFO - 2021-06-12 05:41:53 --> Loader Class Initialized
INFO - 2021-06-12 05:41:53 --> Helper loaded: url_helper
INFO - 2021-06-12 05:41:53 --> Helper loaded: file_helper
INFO - 2021-06-12 05:41:53 --> Helper loaded: form_helper
INFO - 2021-06-12 05:41:53 --> Helper loaded: my_helper
INFO - 2021-06-12 05:41:53 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:41:53 --> Controller Class Initialized
DEBUG - 2021-06-12 05:41:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-06-12 05:41:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:41:53 --> Final output sent to browser
DEBUG - 2021-06-12 05:41:53 --> Total execution time: 0.0670
INFO - 2021-06-12 05:42:05 --> Config Class Initialized
INFO - 2021-06-12 05:42:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:42:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:42:05 --> Utf8 Class Initialized
INFO - 2021-06-12 05:42:05 --> URI Class Initialized
INFO - 2021-06-12 05:42:05 --> Router Class Initialized
INFO - 2021-06-12 05:42:05 --> Output Class Initialized
INFO - 2021-06-12 05:42:05 --> Security Class Initialized
DEBUG - 2021-06-12 05:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:42:05 --> Input Class Initialized
INFO - 2021-06-12 05:42:05 --> Language Class Initialized
INFO - 2021-06-12 05:42:05 --> Language Class Initialized
INFO - 2021-06-12 05:42:05 --> Config Class Initialized
INFO - 2021-06-12 05:42:05 --> Loader Class Initialized
INFO - 2021-06-12 05:42:05 --> Helper loaded: url_helper
INFO - 2021-06-12 05:42:05 --> Helper loaded: file_helper
INFO - 2021-06-12 05:42:05 --> Helper loaded: form_helper
INFO - 2021-06-12 05:42:05 --> Helper loaded: my_helper
INFO - 2021-06-12 05:42:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:42:05 --> Controller Class Initialized
INFO - 2021-06-12 05:42:40 --> Config Class Initialized
INFO - 2021-06-12 05:42:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:42:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:42:40 --> Utf8 Class Initialized
INFO - 2021-06-12 05:42:40 --> URI Class Initialized
INFO - 2021-06-12 05:42:40 --> Router Class Initialized
INFO - 2021-06-12 05:42:40 --> Output Class Initialized
INFO - 2021-06-12 05:42:40 --> Security Class Initialized
DEBUG - 2021-06-12 05:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:42:40 --> Input Class Initialized
INFO - 2021-06-12 05:42:40 --> Language Class Initialized
INFO - 2021-06-12 05:42:40 --> Language Class Initialized
INFO - 2021-06-12 05:42:40 --> Config Class Initialized
INFO - 2021-06-12 05:42:40 --> Loader Class Initialized
INFO - 2021-06-12 05:42:40 --> Helper loaded: url_helper
INFO - 2021-06-12 05:42:40 --> Helper loaded: file_helper
INFO - 2021-06-12 05:42:40 --> Helper loaded: form_helper
INFO - 2021-06-12 05:42:40 --> Helper loaded: my_helper
INFO - 2021-06-12 05:42:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:42:40 --> Controller Class Initialized
INFO - 2021-06-12 05:43:00 --> Config Class Initialized
INFO - 2021-06-12 05:43:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:43:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:43:00 --> Utf8 Class Initialized
INFO - 2021-06-12 05:43:00 --> URI Class Initialized
INFO - 2021-06-12 05:43:00 --> Router Class Initialized
INFO - 2021-06-12 05:43:00 --> Output Class Initialized
INFO - 2021-06-12 05:43:01 --> Security Class Initialized
DEBUG - 2021-06-12 05:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:43:01 --> Input Class Initialized
INFO - 2021-06-12 05:43:01 --> Language Class Initialized
INFO - 2021-06-12 05:43:01 --> Language Class Initialized
INFO - 2021-06-12 05:43:01 --> Config Class Initialized
INFO - 2021-06-12 05:43:01 --> Loader Class Initialized
INFO - 2021-06-12 05:43:01 --> Helper loaded: url_helper
INFO - 2021-06-12 05:43:01 --> Helper loaded: file_helper
INFO - 2021-06-12 05:43:01 --> Helper loaded: form_helper
INFO - 2021-06-12 05:43:01 --> Helper loaded: my_helper
INFO - 2021-06-12 05:43:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:43:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:43:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:43:01 --> Controller Class Initialized
INFO - 2021-06-12 05:43:17 --> Config Class Initialized
INFO - 2021-06-12 05:43:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:43:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:43:17 --> Utf8 Class Initialized
INFO - 2021-06-12 05:43:17 --> URI Class Initialized
INFO - 2021-06-12 05:43:17 --> Router Class Initialized
INFO - 2021-06-12 05:43:17 --> Output Class Initialized
INFO - 2021-06-12 05:43:17 --> Security Class Initialized
DEBUG - 2021-06-12 05:43:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:43:17 --> Input Class Initialized
INFO - 2021-06-12 05:43:17 --> Language Class Initialized
INFO - 2021-06-12 05:43:17 --> Language Class Initialized
INFO - 2021-06-12 05:43:17 --> Config Class Initialized
INFO - 2021-06-12 05:43:17 --> Loader Class Initialized
INFO - 2021-06-12 05:43:17 --> Helper loaded: url_helper
INFO - 2021-06-12 05:43:17 --> Helper loaded: file_helper
INFO - 2021-06-12 05:43:17 --> Helper loaded: form_helper
INFO - 2021-06-12 05:43:17 --> Helper loaded: my_helper
INFO - 2021-06-12 05:43:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:43:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:43:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:43:17 --> Controller Class Initialized
INFO - 2021-06-12 05:43:28 --> Config Class Initialized
INFO - 2021-06-12 05:43:28 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:43:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:43:28 --> Utf8 Class Initialized
INFO - 2021-06-12 05:43:28 --> URI Class Initialized
INFO - 2021-06-12 05:43:28 --> Router Class Initialized
INFO - 2021-06-12 05:43:28 --> Output Class Initialized
INFO - 2021-06-12 05:43:28 --> Security Class Initialized
DEBUG - 2021-06-12 05:43:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:43:28 --> Input Class Initialized
INFO - 2021-06-12 05:43:28 --> Language Class Initialized
INFO - 2021-06-12 05:43:28 --> Language Class Initialized
INFO - 2021-06-12 05:43:28 --> Config Class Initialized
INFO - 2021-06-12 05:43:28 --> Loader Class Initialized
INFO - 2021-06-12 05:43:28 --> Helper loaded: url_helper
INFO - 2021-06-12 05:43:28 --> Helper loaded: file_helper
INFO - 2021-06-12 05:43:28 --> Helper loaded: form_helper
INFO - 2021-06-12 05:43:28 --> Helper loaded: my_helper
INFO - 2021-06-12 05:43:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:43:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:43:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:43:28 --> Controller Class Initialized
INFO - 2021-06-12 05:43:39 --> Config Class Initialized
INFO - 2021-06-12 05:43:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:43:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:43:39 --> Utf8 Class Initialized
INFO - 2021-06-12 05:43:39 --> URI Class Initialized
INFO - 2021-06-12 05:43:39 --> Router Class Initialized
INFO - 2021-06-12 05:43:39 --> Output Class Initialized
INFO - 2021-06-12 05:43:39 --> Security Class Initialized
DEBUG - 2021-06-12 05:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:43:39 --> Input Class Initialized
INFO - 2021-06-12 05:43:39 --> Language Class Initialized
INFO - 2021-06-12 05:43:39 --> Language Class Initialized
INFO - 2021-06-12 05:43:39 --> Config Class Initialized
INFO - 2021-06-12 05:43:39 --> Loader Class Initialized
INFO - 2021-06-12 05:43:39 --> Helper loaded: url_helper
INFO - 2021-06-12 05:43:39 --> Helper loaded: file_helper
INFO - 2021-06-12 05:43:39 --> Helper loaded: form_helper
INFO - 2021-06-12 05:43:39 --> Helper loaded: my_helper
INFO - 2021-06-12 05:43:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:43:39 --> Controller Class Initialized
INFO - 2021-06-12 05:44:10 --> Config Class Initialized
INFO - 2021-06-12 05:44:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:44:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:44:10 --> Utf8 Class Initialized
INFO - 2021-06-12 05:44:10 --> URI Class Initialized
INFO - 2021-06-12 05:44:10 --> Router Class Initialized
INFO - 2021-06-12 05:44:10 --> Output Class Initialized
INFO - 2021-06-12 05:44:10 --> Security Class Initialized
DEBUG - 2021-06-12 05:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:44:10 --> Input Class Initialized
INFO - 2021-06-12 05:44:10 --> Language Class Initialized
INFO - 2021-06-12 05:44:10 --> Language Class Initialized
INFO - 2021-06-12 05:44:10 --> Config Class Initialized
INFO - 2021-06-12 05:44:10 --> Loader Class Initialized
INFO - 2021-06-12 05:44:10 --> Helper loaded: url_helper
INFO - 2021-06-12 05:44:10 --> Helper loaded: file_helper
INFO - 2021-06-12 05:44:10 --> Helper loaded: form_helper
INFO - 2021-06-12 05:44:10 --> Helper loaded: my_helper
INFO - 2021-06-12 05:44:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:44:10 --> Controller Class Initialized
INFO - 2021-06-12 05:44:10 --> Config Class Initialized
INFO - 2021-06-12 05:44:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:44:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:44:10 --> Utf8 Class Initialized
INFO - 2021-06-12 05:44:10 --> URI Class Initialized
INFO - 2021-06-12 05:44:10 --> Router Class Initialized
INFO - 2021-06-12 05:44:10 --> Output Class Initialized
INFO - 2021-06-12 05:44:10 --> Security Class Initialized
DEBUG - 2021-06-12 05:44:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:44:10 --> Input Class Initialized
INFO - 2021-06-12 05:44:10 --> Language Class Initialized
INFO - 2021-06-12 05:44:10 --> Language Class Initialized
INFO - 2021-06-12 05:44:10 --> Config Class Initialized
INFO - 2021-06-12 05:44:10 --> Loader Class Initialized
INFO - 2021-06-12 05:44:10 --> Helper loaded: url_helper
INFO - 2021-06-12 05:44:10 --> Helper loaded: file_helper
INFO - 2021-06-12 05:44:10 --> Helper loaded: form_helper
INFO - 2021-06-12 05:44:10 --> Helper loaded: my_helper
INFO - 2021-06-12 05:44:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:44:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:44:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:44:10 --> Controller Class Initialized
INFO - 2021-06-12 05:44:23 --> Config Class Initialized
INFO - 2021-06-12 05:44:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:44:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:44:23 --> Utf8 Class Initialized
INFO - 2021-06-12 05:44:23 --> URI Class Initialized
INFO - 2021-06-12 05:44:23 --> Router Class Initialized
INFO - 2021-06-12 05:44:23 --> Output Class Initialized
INFO - 2021-06-12 05:44:23 --> Security Class Initialized
DEBUG - 2021-06-12 05:44:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:44:23 --> Input Class Initialized
INFO - 2021-06-12 05:44:23 --> Language Class Initialized
INFO - 2021-06-12 05:44:23 --> Language Class Initialized
INFO - 2021-06-12 05:44:23 --> Config Class Initialized
INFO - 2021-06-12 05:44:23 --> Loader Class Initialized
INFO - 2021-06-12 05:44:23 --> Helper loaded: url_helper
INFO - 2021-06-12 05:44:23 --> Helper loaded: file_helper
INFO - 2021-06-12 05:44:23 --> Helper loaded: form_helper
INFO - 2021-06-12 05:44:23 --> Helper loaded: my_helper
INFO - 2021-06-12 05:44:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:44:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:44:23 --> Controller Class Initialized
INFO - 2021-06-12 05:44:26 --> Config Class Initialized
INFO - 2021-06-12 05:44:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:44:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:44:26 --> Utf8 Class Initialized
INFO - 2021-06-12 05:44:26 --> URI Class Initialized
INFO - 2021-06-12 05:44:26 --> Router Class Initialized
INFO - 2021-06-12 05:44:26 --> Output Class Initialized
INFO - 2021-06-12 05:44:26 --> Security Class Initialized
DEBUG - 2021-06-12 05:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:44:26 --> Input Class Initialized
INFO - 2021-06-12 05:44:26 --> Language Class Initialized
INFO - 2021-06-12 05:44:26 --> Language Class Initialized
INFO - 2021-06-12 05:44:26 --> Config Class Initialized
INFO - 2021-06-12 05:44:26 --> Loader Class Initialized
INFO - 2021-06-12 05:44:26 --> Helper loaded: url_helper
INFO - 2021-06-12 05:44:26 --> Helper loaded: file_helper
INFO - 2021-06-12 05:44:26 --> Helper loaded: form_helper
INFO - 2021-06-12 05:44:26 --> Helper loaded: my_helper
INFO - 2021-06-12 05:44:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:44:26 --> Controller Class Initialized
INFO - 2021-06-12 05:44:27 --> Config Class Initialized
INFO - 2021-06-12 05:44:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:44:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:44:27 --> Utf8 Class Initialized
INFO - 2021-06-12 05:44:27 --> URI Class Initialized
INFO - 2021-06-12 05:44:27 --> Router Class Initialized
INFO - 2021-06-12 05:44:27 --> Output Class Initialized
INFO - 2021-06-12 05:44:27 --> Security Class Initialized
DEBUG - 2021-06-12 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:44:27 --> Input Class Initialized
INFO - 2021-06-12 05:44:27 --> Language Class Initialized
INFO - 2021-06-12 05:44:27 --> Language Class Initialized
INFO - 2021-06-12 05:44:27 --> Config Class Initialized
INFO - 2021-06-12 05:44:27 --> Loader Class Initialized
INFO - 2021-06-12 05:44:27 --> Helper loaded: url_helper
INFO - 2021-06-12 05:44:27 --> Helper loaded: file_helper
INFO - 2021-06-12 05:44:27 --> Helper loaded: form_helper
INFO - 2021-06-12 05:44:27 --> Helper loaded: my_helper
INFO - 2021-06-12 05:44:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:44:27 --> Controller Class Initialized
INFO - 2021-06-12 05:44:27 --> Config Class Initialized
INFO - 2021-06-12 05:44:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:44:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:44:27 --> Utf8 Class Initialized
INFO - 2021-06-12 05:44:27 --> URI Class Initialized
INFO - 2021-06-12 05:44:27 --> Router Class Initialized
INFO - 2021-06-12 05:44:27 --> Output Class Initialized
INFO - 2021-06-12 05:44:27 --> Security Class Initialized
DEBUG - 2021-06-12 05:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:44:27 --> Input Class Initialized
INFO - 2021-06-12 05:44:27 --> Language Class Initialized
INFO - 2021-06-12 05:44:27 --> Language Class Initialized
INFO - 2021-06-12 05:44:27 --> Config Class Initialized
INFO - 2021-06-12 05:44:27 --> Loader Class Initialized
INFO - 2021-06-12 05:44:27 --> Helper loaded: url_helper
INFO - 2021-06-12 05:44:27 --> Helper loaded: file_helper
INFO - 2021-06-12 05:44:27 --> Helper loaded: form_helper
INFO - 2021-06-12 05:44:27 --> Helper loaded: my_helper
INFO - 2021-06-12 05:44:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:44:27 --> Controller Class Initialized
INFO - 2021-06-12 05:44:32 --> Config Class Initialized
INFO - 2021-06-12 05:44:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:44:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:44:32 --> Utf8 Class Initialized
INFO - 2021-06-12 05:44:32 --> URI Class Initialized
INFO - 2021-06-12 05:44:32 --> Router Class Initialized
INFO - 2021-06-12 05:44:32 --> Output Class Initialized
INFO - 2021-06-12 05:44:32 --> Security Class Initialized
DEBUG - 2021-06-12 05:44:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:44:32 --> Input Class Initialized
INFO - 2021-06-12 05:44:32 --> Language Class Initialized
INFO - 2021-06-12 05:44:32 --> Language Class Initialized
INFO - 2021-06-12 05:44:32 --> Config Class Initialized
INFO - 2021-06-12 05:44:32 --> Loader Class Initialized
INFO - 2021-06-12 05:44:32 --> Helper loaded: url_helper
INFO - 2021-06-12 05:44:32 --> Helper loaded: file_helper
INFO - 2021-06-12 05:44:32 --> Helper loaded: form_helper
INFO - 2021-06-12 05:44:32 --> Helper loaded: my_helper
INFO - 2021-06-12 05:44:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:44:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:44:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:44:32 --> Controller Class Initialized
INFO - 2021-06-12 05:45:02 --> Config Class Initialized
INFO - 2021-06-12 05:45:02 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:45:02 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:45:02 --> Utf8 Class Initialized
INFO - 2021-06-12 05:45:02 --> URI Class Initialized
INFO - 2021-06-12 05:45:02 --> Router Class Initialized
INFO - 2021-06-12 05:45:02 --> Output Class Initialized
INFO - 2021-06-12 05:45:02 --> Security Class Initialized
DEBUG - 2021-06-12 05:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:45:02 --> Input Class Initialized
INFO - 2021-06-12 05:45:02 --> Language Class Initialized
INFO - 2021-06-12 05:45:02 --> Language Class Initialized
INFO - 2021-06-12 05:45:02 --> Config Class Initialized
INFO - 2021-06-12 05:45:02 --> Loader Class Initialized
INFO - 2021-06-12 05:45:02 --> Helper loaded: url_helper
INFO - 2021-06-12 05:45:02 --> Helper loaded: file_helper
INFO - 2021-06-12 05:45:02 --> Helper loaded: form_helper
INFO - 2021-06-12 05:45:02 --> Helper loaded: my_helper
INFO - 2021-06-12 05:45:02 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:45:02 --> Controller Class Initialized
INFO - 2021-06-12 05:45:05 --> Config Class Initialized
INFO - 2021-06-12 05:45:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:45:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:45:05 --> Utf8 Class Initialized
INFO - 2021-06-12 05:45:05 --> URI Class Initialized
INFO - 2021-06-12 05:45:05 --> Router Class Initialized
INFO - 2021-06-12 05:45:05 --> Output Class Initialized
INFO - 2021-06-12 05:45:05 --> Security Class Initialized
DEBUG - 2021-06-12 05:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:45:05 --> Input Class Initialized
INFO - 2021-06-12 05:45:05 --> Language Class Initialized
INFO - 2021-06-12 05:45:05 --> Language Class Initialized
INFO - 2021-06-12 05:45:05 --> Config Class Initialized
INFO - 2021-06-12 05:45:05 --> Loader Class Initialized
INFO - 2021-06-12 05:45:05 --> Helper loaded: url_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: file_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: form_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: my_helper
INFO - 2021-06-12 05:45:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:45:05 --> Controller Class Initialized
INFO - 2021-06-12 05:45:05 --> Helper loaded: cookie_helper
INFO - 2021-06-12 05:45:05 --> Config Class Initialized
INFO - 2021-06-12 05:45:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:45:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:45:05 --> Utf8 Class Initialized
INFO - 2021-06-12 05:45:05 --> URI Class Initialized
INFO - 2021-06-12 05:45:05 --> Router Class Initialized
INFO - 2021-06-12 05:45:05 --> Output Class Initialized
INFO - 2021-06-12 05:45:05 --> Security Class Initialized
DEBUG - 2021-06-12 05:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:45:05 --> Input Class Initialized
INFO - 2021-06-12 05:45:05 --> Language Class Initialized
INFO - 2021-06-12 05:45:05 --> Language Class Initialized
INFO - 2021-06-12 05:45:05 --> Config Class Initialized
INFO - 2021-06-12 05:45:05 --> Loader Class Initialized
INFO - 2021-06-12 05:45:05 --> Helper loaded: url_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: file_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: form_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: my_helper
INFO - 2021-06-12 05:45:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:45:05 --> Controller Class Initialized
INFO - 2021-06-12 05:45:05 --> Helper loaded: cookie_helper
INFO - 2021-06-12 05:45:05 --> Config Class Initialized
INFO - 2021-06-12 05:45:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:45:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:45:05 --> Utf8 Class Initialized
INFO - 2021-06-12 05:45:05 --> URI Class Initialized
INFO - 2021-06-12 05:45:05 --> Router Class Initialized
INFO - 2021-06-12 05:45:05 --> Output Class Initialized
INFO - 2021-06-12 05:45:05 --> Security Class Initialized
DEBUG - 2021-06-12 05:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:45:05 --> Input Class Initialized
INFO - 2021-06-12 05:45:05 --> Language Class Initialized
INFO - 2021-06-12 05:45:05 --> Language Class Initialized
INFO - 2021-06-12 05:45:05 --> Config Class Initialized
INFO - 2021-06-12 05:45:05 --> Loader Class Initialized
INFO - 2021-06-12 05:45:05 --> Helper loaded: url_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: file_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: form_helper
INFO - 2021-06-12 05:45:05 --> Helper loaded: my_helper
INFO - 2021-06-12 05:45:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:45:05 --> Controller Class Initialized
DEBUG - 2021-06-12 05:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 05:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:45:05 --> Final output sent to browser
DEBUG - 2021-06-12 05:45:05 --> Total execution time: 0.0490
INFO - 2021-06-12 05:45:27 --> Config Class Initialized
INFO - 2021-06-12 05:45:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:45:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:45:27 --> Utf8 Class Initialized
INFO - 2021-06-12 05:45:27 --> URI Class Initialized
INFO - 2021-06-12 05:45:27 --> Router Class Initialized
INFO - 2021-06-12 05:45:27 --> Output Class Initialized
INFO - 2021-06-12 05:45:27 --> Security Class Initialized
DEBUG - 2021-06-12 05:45:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:45:27 --> Input Class Initialized
INFO - 2021-06-12 05:45:27 --> Language Class Initialized
INFO - 2021-06-12 05:45:27 --> Language Class Initialized
INFO - 2021-06-12 05:45:27 --> Config Class Initialized
INFO - 2021-06-12 05:45:27 --> Loader Class Initialized
INFO - 2021-06-12 05:45:27 --> Helper loaded: url_helper
INFO - 2021-06-12 05:45:27 --> Helper loaded: file_helper
INFO - 2021-06-12 05:45:27 --> Helper loaded: form_helper
INFO - 2021-06-12 05:45:27 --> Helper loaded: my_helper
INFO - 2021-06-12 05:45:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:45:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:45:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:45:27 --> Controller Class Initialized
INFO - 2021-06-12 05:45:27 --> Helper loaded: cookie_helper
INFO - 2021-06-12 05:45:27 --> Final output sent to browser
DEBUG - 2021-06-12 05:45:27 --> Total execution time: 0.0428
INFO - 2021-06-12 05:45:27 --> Config Class Initialized
INFO - 2021-06-12 05:45:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:45:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:45:28 --> Utf8 Class Initialized
INFO - 2021-06-12 05:45:28 --> URI Class Initialized
INFO - 2021-06-12 05:45:28 --> Router Class Initialized
INFO - 2021-06-12 05:45:28 --> Output Class Initialized
INFO - 2021-06-12 05:45:28 --> Security Class Initialized
DEBUG - 2021-06-12 05:45:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:45:28 --> Input Class Initialized
INFO - 2021-06-12 05:45:28 --> Language Class Initialized
INFO - 2021-06-12 05:45:28 --> Language Class Initialized
INFO - 2021-06-12 05:45:28 --> Config Class Initialized
INFO - 2021-06-12 05:45:28 --> Loader Class Initialized
INFO - 2021-06-12 05:45:28 --> Helper loaded: url_helper
INFO - 2021-06-12 05:45:28 --> Helper loaded: file_helper
INFO - 2021-06-12 05:45:28 --> Helper loaded: form_helper
INFO - 2021-06-12 05:45:28 --> Helper loaded: my_helper
INFO - 2021-06-12 05:45:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:45:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:45:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:45:28 --> Controller Class Initialized
DEBUG - 2021-06-12 05:45:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 05:45:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:45:28 --> Final output sent to browser
DEBUG - 2021-06-12 05:45:28 --> Total execution time: 0.0673
INFO - 2021-06-12 05:45:49 --> Config Class Initialized
INFO - 2021-06-12 05:45:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:45:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:45:49 --> Utf8 Class Initialized
INFO - 2021-06-12 05:45:49 --> URI Class Initialized
INFO - 2021-06-12 05:45:49 --> Router Class Initialized
INFO - 2021-06-12 05:45:49 --> Output Class Initialized
INFO - 2021-06-12 05:45:49 --> Security Class Initialized
DEBUG - 2021-06-12 05:45:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:45:49 --> Input Class Initialized
INFO - 2021-06-12 05:45:49 --> Language Class Initialized
INFO - 2021-06-12 05:45:49 --> Language Class Initialized
INFO - 2021-06-12 05:45:49 --> Config Class Initialized
INFO - 2021-06-12 05:45:49 --> Loader Class Initialized
INFO - 2021-06-12 05:45:49 --> Helper loaded: url_helper
INFO - 2021-06-12 05:45:49 --> Helper loaded: file_helper
INFO - 2021-06-12 05:45:49 --> Helper loaded: form_helper
INFO - 2021-06-12 05:45:49 --> Helper loaded: my_helper
INFO - 2021-06-12 05:45:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:45:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:45:49 --> Controller Class Initialized
DEBUG - 2021-06-12 05:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 05:45:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:45:49 --> Final output sent to browser
DEBUG - 2021-06-12 05:45:49 --> Total execution time: 0.0404
INFO - 2021-06-12 05:48:19 --> Config Class Initialized
INFO - 2021-06-12 05:48:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:48:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:48:19 --> Utf8 Class Initialized
INFO - 2021-06-12 05:48:19 --> URI Class Initialized
INFO - 2021-06-12 05:48:19 --> Router Class Initialized
INFO - 2021-06-12 05:48:19 --> Output Class Initialized
INFO - 2021-06-12 05:48:19 --> Security Class Initialized
DEBUG - 2021-06-12 05:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:48:19 --> Input Class Initialized
INFO - 2021-06-12 05:48:19 --> Language Class Initialized
INFO - 2021-06-12 05:48:19 --> Language Class Initialized
INFO - 2021-06-12 05:48:19 --> Config Class Initialized
INFO - 2021-06-12 05:48:19 --> Loader Class Initialized
INFO - 2021-06-12 05:48:19 --> Helper loaded: url_helper
INFO - 2021-06-12 05:48:19 --> Helper loaded: file_helper
INFO - 2021-06-12 05:48:19 --> Helper loaded: form_helper
INFO - 2021-06-12 05:48:19 --> Helper loaded: my_helper
INFO - 2021-06-12 05:48:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:48:19 --> Controller Class Initialized
DEBUG - 2021-06-12 05:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 05:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:48:19 --> Final output sent to browser
DEBUG - 2021-06-12 05:48:19 --> Total execution time: 0.0606
INFO - 2021-06-12 05:48:31 --> Config Class Initialized
INFO - 2021-06-12 05:48:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:48:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:48:31 --> Utf8 Class Initialized
INFO - 2021-06-12 05:48:31 --> URI Class Initialized
INFO - 2021-06-12 05:48:31 --> Router Class Initialized
INFO - 2021-06-12 05:48:31 --> Output Class Initialized
INFO - 2021-06-12 05:48:31 --> Security Class Initialized
DEBUG - 2021-06-12 05:48:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:48:31 --> Input Class Initialized
INFO - 2021-06-12 05:48:31 --> Language Class Initialized
INFO - 2021-06-12 05:48:31 --> Language Class Initialized
INFO - 2021-06-12 05:48:31 --> Config Class Initialized
INFO - 2021-06-12 05:48:31 --> Loader Class Initialized
INFO - 2021-06-12 05:48:31 --> Helper loaded: url_helper
INFO - 2021-06-12 05:48:31 --> Helper loaded: file_helper
INFO - 2021-06-12 05:48:31 --> Helper loaded: form_helper
INFO - 2021-06-12 05:48:31 --> Helper loaded: my_helper
INFO - 2021-06-12 05:48:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:48:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:48:31 --> Controller Class Initialized
INFO - 2021-06-12 05:49:28 --> Config Class Initialized
INFO - 2021-06-12 05:49:28 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:49:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:49:28 --> Utf8 Class Initialized
INFO - 2021-06-12 05:49:28 --> URI Class Initialized
INFO - 2021-06-12 05:49:28 --> Router Class Initialized
INFO - 2021-06-12 05:49:28 --> Output Class Initialized
INFO - 2021-06-12 05:49:28 --> Security Class Initialized
DEBUG - 2021-06-12 05:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:49:28 --> Input Class Initialized
INFO - 2021-06-12 05:49:28 --> Language Class Initialized
INFO - 2021-06-12 05:49:28 --> Language Class Initialized
INFO - 2021-06-12 05:49:28 --> Config Class Initialized
INFO - 2021-06-12 05:49:28 --> Loader Class Initialized
INFO - 2021-06-12 05:49:28 --> Helper loaded: url_helper
INFO - 2021-06-12 05:49:28 --> Helper loaded: file_helper
INFO - 2021-06-12 05:49:28 --> Helper loaded: form_helper
INFO - 2021-06-12 05:49:28 --> Helper loaded: my_helper
INFO - 2021-06-12 05:49:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:49:28 --> Controller Class Initialized
INFO - 2021-06-12 05:49:28 --> Config Class Initialized
INFO - 2021-06-12 05:49:28 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:49:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:49:28 --> Utf8 Class Initialized
INFO - 2021-06-12 05:49:28 --> URI Class Initialized
INFO - 2021-06-12 05:49:28 --> Router Class Initialized
INFO - 2021-06-12 05:49:28 --> Output Class Initialized
INFO - 2021-06-12 05:49:28 --> Security Class Initialized
DEBUG - 2021-06-12 05:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:49:28 --> Input Class Initialized
INFO - 2021-06-12 05:49:28 --> Language Class Initialized
INFO - 2021-06-12 05:49:28 --> Language Class Initialized
INFO - 2021-06-12 05:49:28 --> Config Class Initialized
INFO - 2021-06-12 05:49:28 --> Loader Class Initialized
INFO - 2021-06-12 05:49:28 --> Helper loaded: url_helper
INFO - 2021-06-12 05:49:28 --> Helper loaded: file_helper
INFO - 2021-06-12 05:49:28 --> Helper loaded: form_helper
INFO - 2021-06-12 05:49:28 --> Helper loaded: my_helper
INFO - 2021-06-12 05:49:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:49:28 --> Controller Class Initialized
INFO - 2021-06-12 05:49:36 --> Config Class Initialized
INFO - 2021-06-12 05:49:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:49:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:49:36 --> Utf8 Class Initialized
INFO - 2021-06-12 05:49:36 --> URI Class Initialized
INFO - 2021-06-12 05:49:36 --> Router Class Initialized
INFO - 2021-06-12 05:49:36 --> Output Class Initialized
INFO - 2021-06-12 05:49:36 --> Security Class Initialized
DEBUG - 2021-06-12 05:49:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:49:36 --> Input Class Initialized
INFO - 2021-06-12 05:49:36 --> Language Class Initialized
INFO - 2021-06-12 05:49:36 --> Language Class Initialized
INFO - 2021-06-12 05:49:36 --> Config Class Initialized
INFO - 2021-06-12 05:49:36 --> Loader Class Initialized
INFO - 2021-06-12 05:49:36 --> Helper loaded: url_helper
INFO - 2021-06-12 05:49:36 --> Helper loaded: file_helper
INFO - 2021-06-12 05:49:36 --> Helper loaded: form_helper
INFO - 2021-06-12 05:49:36 --> Helper loaded: my_helper
INFO - 2021-06-12 05:49:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:49:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:49:36 --> Controller Class Initialized
DEBUG - 2021-06-12 05:49:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 05:49:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:49:36 --> Final output sent to browser
DEBUG - 2021-06-12 05:49:36 --> Total execution time: 0.0508
INFO - 2021-06-12 05:51:23 --> Config Class Initialized
INFO - 2021-06-12 05:51:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:51:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:51:23 --> Utf8 Class Initialized
INFO - 2021-06-12 05:51:23 --> URI Class Initialized
INFO - 2021-06-12 05:51:23 --> Router Class Initialized
INFO - 2021-06-12 05:51:23 --> Output Class Initialized
INFO - 2021-06-12 05:51:23 --> Security Class Initialized
DEBUG - 2021-06-12 05:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:51:23 --> Input Class Initialized
INFO - 2021-06-12 05:51:23 --> Language Class Initialized
INFO - 2021-06-12 05:51:23 --> Language Class Initialized
INFO - 2021-06-12 05:51:23 --> Config Class Initialized
INFO - 2021-06-12 05:51:23 --> Loader Class Initialized
INFO - 2021-06-12 05:51:23 --> Helper loaded: url_helper
INFO - 2021-06-12 05:51:23 --> Helper loaded: file_helper
INFO - 2021-06-12 05:51:23 --> Helper loaded: form_helper
INFO - 2021-06-12 05:51:23 --> Helper loaded: my_helper
INFO - 2021-06-12 05:51:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:51:23 --> Controller Class Initialized
DEBUG - 2021-06-12 05:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 05:51:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:51:23 --> Final output sent to browser
DEBUG - 2021-06-12 05:51:23 --> Total execution time: 0.0546
INFO - 2021-06-12 05:51:36 --> Config Class Initialized
INFO - 2021-06-12 05:51:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:51:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:51:36 --> Utf8 Class Initialized
INFO - 2021-06-12 05:51:36 --> URI Class Initialized
INFO - 2021-06-12 05:51:36 --> Router Class Initialized
INFO - 2021-06-12 05:51:36 --> Output Class Initialized
INFO - 2021-06-12 05:51:36 --> Security Class Initialized
DEBUG - 2021-06-12 05:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:51:36 --> Input Class Initialized
INFO - 2021-06-12 05:51:36 --> Language Class Initialized
INFO - 2021-06-12 05:51:36 --> Language Class Initialized
INFO - 2021-06-12 05:51:36 --> Config Class Initialized
INFO - 2021-06-12 05:51:36 --> Loader Class Initialized
INFO - 2021-06-12 05:51:36 --> Helper loaded: url_helper
INFO - 2021-06-12 05:51:36 --> Helper loaded: file_helper
INFO - 2021-06-12 05:51:36 --> Helper loaded: form_helper
INFO - 2021-06-12 05:51:36 --> Helper loaded: my_helper
INFO - 2021-06-12 05:51:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:51:36 --> Controller Class Initialized
INFO - 2021-06-12 05:52:12 --> Config Class Initialized
INFO - 2021-06-12 05:52:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:52:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:52:12 --> Utf8 Class Initialized
INFO - 2021-06-12 05:52:12 --> URI Class Initialized
INFO - 2021-06-12 05:52:12 --> Router Class Initialized
INFO - 2021-06-12 05:52:12 --> Output Class Initialized
INFO - 2021-06-12 05:52:12 --> Security Class Initialized
DEBUG - 2021-06-12 05:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:52:12 --> Input Class Initialized
INFO - 2021-06-12 05:52:12 --> Language Class Initialized
INFO - 2021-06-12 05:52:12 --> Language Class Initialized
INFO - 2021-06-12 05:52:12 --> Config Class Initialized
INFO - 2021-06-12 05:52:12 --> Loader Class Initialized
INFO - 2021-06-12 05:52:12 --> Helper loaded: url_helper
INFO - 2021-06-12 05:52:12 --> Helper loaded: file_helper
INFO - 2021-06-12 05:52:12 --> Helper loaded: form_helper
INFO - 2021-06-12 05:52:12 --> Helper loaded: my_helper
INFO - 2021-06-12 05:52:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:52:12 --> Controller Class Initialized
DEBUG - 2021-06-12 05:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 05:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:52:12 --> Final output sent to browser
DEBUG - 2021-06-12 05:52:12 --> Total execution time: 0.0484
INFO - 2021-06-12 05:52:26 --> Config Class Initialized
INFO - 2021-06-12 05:52:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:52:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:52:26 --> Utf8 Class Initialized
INFO - 2021-06-12 05:52:26 --> URI Class Initialized
INFO - 2021-06-12 05:52:26 --> Router Class Initialized
INFO - 2021-06-12 05:52:26 --> Output Class Initialized
INFO - 2021-06-12 05:52:26 --> Security Class Initialized
DEBUG - 2021-06-12 05:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:52:26 --> Input Class Initialized
INFO - 2021-06-12 05:52:26 --> Language Class Initialized
INFO - 2021-06-12 05:52:26 --> Language Class Initialized
INFO - 2021-06-12 05:52:26 --> Config Class Initialized
INFO - 2021-06-12 05:52:26 --> Loader Class Initialized
INFO - 2021-06-12 05:52:26 --> Helper loaded: url_helper
INFO - 2021-06-12 05:52:26 --> Helper loaded: file_helper
INFO - 2021-06-12 05:52:26 --> Helper loaded: form_helper
INFO - 2021-06-12 05:52:26 --> Helper loaded: my_helper
INFO - 2021-06-12 05:52:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:52:26 --> Controller Class Initialized
DEBUG - 2021-06-12 05:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 05:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:52:26 --> Final output sent to browser
DEBUG - 2021-06-12 05:52:26 --> Total execution time: 0.0477
INFO - 2021-06-12 05:52:26 --> Config Class Initialized
INFO - 2021-06-12 05:52:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:52:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:52:26 --> Utf8 Class Initialized
INFO - 2021-06-12 05:52:26 --> URI Class Initialized
INFO - 2021-06-12 05:52:26 --> Router Class Initialized
INFO - 2021-06-12 05:52:26 --> Output Class Initialized
INFO - 2021-06-12 05:52:26 --> Security Class Initialized
DEBUG - 2021-06-12 05:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:52:26 --> Input Class Initialized
INFO - 2021-06-12 05:52:26 --> Language Class Initialized
INFO - 2021-06-12 05:52:26 --> Language Class Initialized
INFO - 2021-06-12 05:52:26 --> Config Class Initialized
INFO - 2021-06-12 05:52:26 --> Loader Class Initialized
INFO - 2021-06-12 05:52:26 --> Helper loaded: url_helper
INFO - 2021-06-12 05:52:26 --> Helper loaded: file_helper
INFO - 2021-06-12 05:52:26 --> Helper loaded: form_helper
INFO - 2021-06-12 05:52:26 --> Helper loaded: my_helper
INFO - 2021-06-12 05:52:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:52:26 --> Controller Class Initialized
DEBUG - 2021-06-12 05:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 05:52:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:52:26 --> Final output sent to browser
DEBUG - 2021-06-12 05:52:26 --> Total execution time: 0.0536
INFO - 2021-06-12 05:52:38 --> Config Class Initialized
INFO - 2021-06-12 05:52:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:52:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:52:38 --> Utf8 Class Initialized
INFO - 2021-06-12 05:52:38 --> URI Class Initialized
INFO - 2021-06-12 05:52:38 --> Router Class Initialized
INFO - 2021-06-12 05:52:38 --> Output Class Initialized
INFO - 2021-06-12 05:52:38 --> Security Class Initialized
DEBUG - 2021-06-12 05:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:52:38 --> Input Class Initialized
INFO - 2021-06-12 05:52:38 --> Language Class Initialized
INFO - 2021-06-12 05:52:38 --> Language Class Initialized
INFO - 2021-06-12 05:52:38 --> Config Class Initialized
INFO - 2021-06-12 05:52:38 --> Loader Class Initialized
INFO - 2021-06-12 05:52:38 --> Helper loaded: url_helper
INFO - 2021-06-12 05:52:38 --> Helper loaded: file_helper
INFO - 2021-06-12 05:52:38 --> Helper loaded: form_helper
INFO - 2021-06-12 05:52:38 --> Helper loaded: my_helper
INFO - 2021-06-12 05:52:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:52:38 --> Controller Class Initialized
INFO - 2021-06-12 05:52:44 --> Config Class Initialized
INFO - 2021-06-12 05:52:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:52:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:52:44 --> Utf8 Class Initialized
INFO - 2021-06-12 05:52:44 --> URI Class Initialized
INFO - 2021-06-12 05:52:44 --> Router Class Initialized
INFO - 2021-06-12 05:52:44 --> Output Class Initialized
INFO - 2021-06-12 05:52:44 --> Security Class Initialized
DEBUG - 2021-06-12 05:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:52:44 --> Input Class Initialized
INFO - 2021-06-12 05:52:44 --> Language Class Initialized
INFO - 2021-06-12 05:52:44 --> Language Class Initialized
INFO - 2021-06-12 05:52:44 --> Config Class Initialized
INFO - 2021-06-12 05:52:44 --> Loader Class Initialized
INFO - 2021-06-12 05:52:44 --> Helper loaded: url_helper
INFO - 2021-06-12 05:52:44 --> Helper loaded: file_helper
INFO - 2021-06-12 05:52:44 --> Helper loaded: form_helper
INFO - 2021-06-12 05:52:44 --> Helper loaded: my_helper
INFO - 2021-06-12 05:52:44 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:52:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:52:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:52:44 --> Controller Class Initialized
INFO - 2021-06-12 05:53:14 --> Config Class Initialized
INFO - 2021-06-12 05:53:14 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:53:14 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:53:14 --> Utf8 Class Initialized
INFO - 2021-06-12 05:53:14 --> URI Class Initialized
INFO - 2021-06-12 05:53:14 --> Router Class Initialized
INFO - 2021-06-12 05:53:14 --> Output Class Initialized
INFO - 2021-06-12 05:53:14 --> Security Class Initialized
DEBUG - 2021-06-12 05:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:53:14 --> Input Class Initialized
INFO - 2021-06-12 05:53:14 --> Language Class Initialized
INFO - 2021-06-12 05:53:15 --> Language Class Initialized
INFO - 2021-06-12 05:53:15 --> Config Class Initialized
INFO - 2021-06-12 05:53:15 --> Loader Class Initialized
INFO - 2021-06-12 05:53:15 --> Helper loaded: url_helper
INFO - 2021-06-12 05:53:15 --> Helper loaded: file_helper
INFO - 2021-06-12 05:53:15 --> Helper loaded: form_helper
INFO - 2021-06-12 05:53:15 --> Helper loaded: my_helper
INFO - 2021-06-12 05:53:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:53:15 --> Controller Class Initialized
DEBUG - 2021-06-12 05:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 05:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:53:15 --> Final output sent to browser
DEBUG - 2021-06-12 05:53:15 --> Total execution time: 0.0512
INFO - 2021-06-12 05:53:28 --> Config Class Initialized
INFO - 2021-06-12 05:53:28 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:53:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:53:28 --> Utf8 Class Initialized
INFO - 2021-06-12 05:53:28 --> URI Class Initialized
INFO - 2021-06-12 05:53:28 --> Router Class Initialized
INFO - 2021-06-12 05:53:28 --> Output Class Initialized
INFO - 2021-06-12 05:53:28 --> Security Class Initialized
DEBUG - 2021-06-12 05:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:53:28 --> Input Class Initialized
INFO - 2021-06-12 05:53:28 --> Language Class Initialized
INFO - 2021-06-12 05:53:28 --> Language Class Initialized
INFO - 2021-06-12 05:53:28 --> Config Class Initialized
INFO - 2021-06-12 05:53:28 --> Loader Class Initialized
INFO - 2021-06-12 05:53:28 --> Helper loaded: url_helper
INFO - 2021-06-12 05:53:28 --> Helper loaded: file_helper
INFO - 2021-06-12 05:53:28 --> Helper loaded: form_helper
INFO - 2021-06-12 05:53:28 --> Helper loaded: my_helper
INFO - 2021-06-12 05:53:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:53:28 --> Controller Class Initialized
DEBUG - 2021-06-12 05:53:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 05:53:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:53:28 --> Final output sent to browser
DEBUG - 2021-06-12 05:53:28 --> Total execution time: 0.0432
INFO - 2021-06-12 05:53:43 --> Config Class Initialized
INFO - 2021-06-12 05:53:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:53:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:53:43 --> Utf8 Class Initialized
INFO - 2021-06-12 05:53:43 --> URI Class Initialized
INFO - 2021-06-12 05:53:43 --> Router Class Initialized
INFO - 2021-06-12 05:53:43 --> Output Class Initialized
INFO - 2021-06-12 05:53:43 --> Security Class Initialized
DEBUG - 2021-06-12 05:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:53:43 --> Input Class Initialized
INFO - 2021-06-12 05:53:43 --> Language Class Initialized
INFO - 2021-06-12 05:53:43 --> Language Class Initialized
INFO - 2021-06-12 05:53:43 --> Config Class Initialized
INFO - 2021-06-12 05:53:43 --> Loader Class Initialized
INFO - 2021-06-12 05:53:43 --> Helper loaded: url_helper
INFO - 2021-06-12 05:53:43 --> Helper loaded: file_helper
INFO - 2021-06-12 05:53:43 --> Helper loaded: form_helper
INFO - 2021-06-12 05:53:43 --> Helper loaded: my_helper
INFO - 2021-06-12 05:53:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:53:43 --> Controller Class Initialized
INFO - 2021-06-12 05:54:09 --> Config Class Initialized
INFO - 2021-06-12 05:54:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:54:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:54:09 --> Utf8 Class Initialized
INFO - 2021-06-12 05:54:09 --> URI Class Initialized
INFO - 2021-06-12 05:54:09 --> Router Class Initialized
INFO - 2021-06-12 05:54:09 --> Output Class Initialized
INFO - 2021-06-12 05:54:09 --> Security Class Initialized
DEBUG - 2021-06-12 05:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:54:09 --> Input Class Initialized
INFO - 2021-06-12 05:54:09 --> Language Class Initialized
INFO - 2021-06-12 05:54:09 --> Language Class Initialized
INFO - 2021-06-12 05:54:09 --> Config Class Initialized
INFO - 2021-06-12 05:54:09 --> Loader Class Initialized
INFO - 2021-06-12 05:54:09 --> Helper loaded: url_helper
INFO - 2021-06-12 05:54:09 --> Helper loaded: file_helper
INFO - 2021-06-12 05:54:09 --> Helper loaded: form_helper
INFO - 2021-06-12 05:54:09 --> Helper loaded: my_helper
INFO - 2021-06-12 05:54:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:54:09 --> Controller Class Initialized
DEBUG - 2021-06-12 05:54:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 05:54:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:54:09 --> Final output sent to browser
DEBUG - 2021-06-12 05:54:09 --> Total execution time: 0.0480
INFO - 2021-06-12 05:54:26 --> Config Class Initialized
INFO - 2021-06-12 05:54:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:54:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:54:26 --> Utf8 Class Initialized
INFO - 2021-06-12 05:54:26 --> URI Class Initialized
INFO - 2021-06-12 05:54:26 --> Router Class Initialized
INFO - 2021-06-12 05:54:26 --> Output Class Initialized
INFO - 2021-06-12 05:54:26 --> Security Class Initialized
DEBUG - 2021-06-12 05:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:54:26 --> Input Class Initialized
INFO - 2021-06-12 05:54:26 --> Language Class Initialized
INFO - 2021-06-12 05:54:26 --> Language Class Initialized
INFO - 2021-06-12 05:54:26 --> Config Class Initialized
INFO - 2021-06-12 05:54:26 --> Loader Class Initialized
INFO - 2021-06-12 05:54:26 --> Helper loaded: url_helper
INFO - 2021-06-12 05:54:26 --> Helper loaded: file_helper
INFO - 2021-06-12 05:54:26 --> Helper loaded: form_helper
INFO - 2021-06-12 05:54:26 --> Helper loaded: my_helper
INFO - 2021-06-12 05:54:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:54:26 --> Controller Class Initialized
DEBUG - 2021-06-12 05:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 05:54:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:54:26 --> Final output sent to browser
DEBUG - 2021-06-12 05:54:26 --> Total execution time: 0.0700
INFO - 2021-06-12 05:54:38 --> Config Class Initialized
INFO - 2021-06-12 05:54:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:54:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:54:38 --> Utf8 Class Initialized
INFO - 2021-06-12 05:54:38 --> URI Class Initialized
INFO - 2021-06-12 05:54:38 --> Router Class Initialized
INFO - 2021-06-12 05:54:38 --> Output Class Initialized
INFO - 2021-06-12 05:54:38 --> Security Class Initialized
DEBUG - 2021-06-12 05:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:54:38 --> Input Class Initialized
INFO - 2021-06-12 05:54:38 --> Language Class Initialized
INFO - 2021-06-12 05:54:38 --> Language Class Initialized
INFO - 2021-06-12 05:54:38 --> Config Class Initialized
INFO - 2021-06-12 05:54:38 --> Loader Class Initialized
INFO - 2021-06-12 05:54:38 --> Helper loaded: url_helper
INFO - 2021-06-12 05:54:38 --> Helper loaded: file_helper
INFO - 2021-06-12 05:54:38 --> Helper loaded: form_helper
INFO - 2021-06-12 05:54:38 --> Helper loaded: my_helper
INFO - 2021-06-12 05:54:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:54:38 --> Controller Class Initialized
INFO - 2021-06-12 05:54:43 --> Config Class Initialized
INFO - 2021-06-12 05:54:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:54:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:54:43 --> Utf8 Class Initialized
INFO - 2021-06-12 05:54:43 --> URI Class Initialized
INFO - 2021-06-12 05:54:43 --> Router Class Initialized
INFO - 2021-06-12 05:54:43 --> Output Class Initialized
INFO - 2021-06-12 05:54:43 --> Security Class Initialized
DEBUG - 2021-06-12 05:54:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:54:43 --> Input Class Initialized
INFO - 2021-06-12 05:54:43 --> Language Class Initialized
INFO - 2021-06-12 05:54:43 --> Language Class Initialized
INFO - 2021-06-12 05:54:43 --> Config Class Initialized
INFO - 2021-06-12 05:54:43 --> Loader Class Initialized
INFO - 2021-06-12 05:54:43 --> Helper loaded: url_helper
INFO - 2021-06-12 05:54:43 --> Helper loaded: file_helper
INFO - 2021-06-12 05:54:43 --> Helper loaded: form_helper
INFO - 2021-06-12 05:54:43 --> Helper loaded: my_helper
INFO - 2021-06-12 05:54:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:54:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:54:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:54:43 --> Controller Class Initialized
INFO - 2021-06-12 05:55:51 --> Config Class Initialized
INFO - 2021-06-12 05:55:51 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:55:51 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:55:51 --> Utf8 Class Initialized
INFO - 2021-06-12 05:55:51 --> URI Class Initialized
INFO - 2021-06-12 05:55:51 --> Router Class Initialized
INFO - 2021-06-12 05:55:51 --> Output Class Initialized
INFO - 2021-06-12 05:55:51 --> Security Class Initialized
DEBUG - 2021-06-12 05:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:55:51 --> Input Class Initialized
INFO - 2021-06-12 05:55:51 --> Language Class Initialized
INFO - 2021-06-12 05:55:51 --> Language Class Initialized
INFO - 2021-06-12 05:55:51 --> Config Class Initialized
INFO - 2021-06-12 05:55:51 --> Loader Class Initialized
INFO - 2021-06-12 05:55:51 --> Helper loaded: url_helper
INFO - 2021-06-12 05:55:51 --> Helper loaded: file_helper
INFO - 2021-06-12 05:55:51 --> Helper loaded: form_helper
INFO - 2021-06-12 05:55:51 --> Helper loaded: my_helper
INFO - 2021-06-12 05:55:51 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:55:51 --> Controller Class Initialized
DEBUG - 2021-06-12 05:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 05:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:55:51 --> Final output sent to browser
DEBUG - 2021-06-12 05:55:51 --> Total execution time: 0.0633
INFO - 2021-06-12 05:56:05 --> Config Class Initialized
INFO - 2021-06-12 05:56:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:56:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:56:05 --> Utf8 Class Initialized
INFO - 2021-06-12 05:56:05 --> URI Class Initialized
INFO - 2021-06-12 05:56:05 --> Router Class Initialized
INFO - 2021-06-12 05:56:05 --> Output Class Initialized
INFO - 2021-06-12 05:56:05 --> Security Class Initialized
DEBUG - 2021-06-12 05:56:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:56:05 --> Input Class Initialized
INFO - 2021-06-12 05:56:05 --> Language Class Initialized
INFO - 2021-06-12 05:56:05 --> Language Class Initialized
INFO - 2021-06-12 05:56:05 --> Config Class Initialized
INFO - 2021-06-12 05:56:05 --> Loader Class Initialized
INFO - 2021-06-12 05:56:05 --> Helper loaded: url_helper
INFO - 2021-06-12 05:56:05 --> Helper loaded: file_helper
INFO - 2021-06-12 05:56:05 --> Helper loaded: form_helper
INFO - 2021-06-12 05:56:05 --> Helper loaded: my_helper
INFO - 2021-06-12 05:56:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:56:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:56:05 --> Controller Class Initialized
DEBUG - 2021-06-12 05:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 05:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 05:56:06 --> Final output sent to browser
DEBUG - 2021-06-12 05:56:06 --> Total execution time: 0.2273
INFO - 2021-06-12 05:56:21 --> Config Class Initialized
INFO - 2021-06-12 05:56:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 05:56:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 05:56:21 --> Utf8 Class Initialized
INFO - 2021-06-12 05:56:21 --> URI Class Initialized
INFO - 2021-06-12 05:56:21 --> Router Class Initialized
INFO - 2021-06-12 05:56:21 --> Output Class Initialized
INFO - 2021-06-12 05:56:21 --> Security Class Initialized
DEBUG - 2021-06-12 05:56:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 05:56:21 --> Input Class Initialized
INFO - 2021-06-12 05:56:21 --> Language Class Initialized
INFO - 2021-06-12 05:56:21 --> Language Class Initialized
INFO - 2021-06-12 05:56:21 --> Config Class Initialized
INFO - 2021-06-12 05:56:21 --> Loader Class Initialized
INFO - 2021-06-12 05:56:21 --> Helper loaded: url_helper
INFO - 2021-06-12 05:56:21 --> Helper loaded: file_helper
INFO - 2021-06-12 05:56:21 --> Helper loaded: form_helper
INFO - 2021-06-12 05:56:21 --> Helper loaded: my_helper
INFO - 2021-06-12 05:56:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 05:56:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 05:56:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 05:56:21 --> Controller Class Initialized
INFO - 2021-06-12 06:06:07 --> Config Class Initialized
INFO - 2021-06-12 06:06:07 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:07 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:07 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:07 --> URI Class Initialized
DEBUG - 2021-06-12 06:06:07 --> No URI present. Default controller set.
INFO - 2021-06-12 06:06:07 --> Router Class Initialized
INFO - 2021-06-12 06:06:07 --> Output Class Initialized
INFO - 2021-06-12 06:06:07 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:07 --> Input Class Initialized
INFO - 2021-06-12 06:06:07 --> Language Class Initialized
INFO - 2021-06-12 06:06:07 --> Language Class Initialized
INFO - 2021-06-12 06:06:07 --> Config Class Initialized
INFO - 2021-06-12 06:06:07 --> Loader Class Initialized
INFO - 2021-06-12 06:06:07 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:07 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:07 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:07 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:07 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:07 --> Controller Class Initialized
INFO - 2021-06-12 06:06:07 --> Config Class Initialized
INFO - 2021-06-12 06:06:07 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:07 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:07 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:07 --> URI Class Initialized
INFO - 2021-06-12 06:06:07 --> Router Class Initialized
INFO - 2021-06-12 06:06:07 --> Output Class Initialized
INFO - 2021-06-12 06:06:07 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:07 --> Input Class Initialized
INFO - 2021-06-12 06:06:07 --> Language Class Initialized
INFO - 2021-06-12 06:06:07 --> Language Class Initialized
INFO - 2021-06-12 06:06:07 --> Config Class Initialized
INFO - 2021-06-12 06:06:07 --> Loader Class Initialized
INFO - 2021-06-12 06:06:07 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:07 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:07 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:07 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:07 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:07 --> Controller Class Initialized
DEBUG - 2021-06-12 06:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:06:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:06:07 --> Final output sent to browser
DEBUG - 2021-06-12 06:06:07 --> Total execution time: 0.0408
INFO - 2021-06-12 06:06:17 --> Config Class Initialized
INFO - 2021-06-12 06:06:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:17 --> URI Class Initialized
INFO - 2021-06-12 06:06:17 --> Router Class Initialized
INFO - 2021-06-12 06:06:17 --> Output Class Initialized
INFO - 2021-06-12 06:06:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:17 --> Input Class Initialized
INFO - 2021-06-12 06:06:17 --> Language Class Initialized
INFO - 2021-06-12 06:06:17 --> Language Class Initialized
INFO - 2021-06-12 06:06:17 --> Config Class Initialized
INFO - 2021-06-12 06:06:17 --> Loader Class Initialized
INFO - 2021-06-12 06:06:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:17 --> Controller Class Initialized
INFO - 2021-06-12 06:06:17 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:06:17 --> Final output sent to browser
DEBUG - 2021-06-12 06:06:17 --> Total execution time: 0.0544
INFO - 2021-06-12 06:06:17 --> Config Class Initialized
INFO - 2021-06-12 06:06:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:17 --> URI Class Initialized
INFO - 2021-06-12 06:06:17 --> Router Class Initialized
INFO - 2021-06-12 06:06:17 --> Output Class Initialized
INFO - 2021-06-12 06:06:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:17 --> Input Class Initialized
INFO - 2021-06-12 06:06:17 --> Language Class Initialized
INFO - 2021-06-12 06:06:17 --> Language Class Initialized
INFO - 2021-06-12 06:06:17 --> Config Class Initialized
INFO - 2021-06-12 06:06:17 --> Loader Class Initialized
INFO - 2021-06-12 06:06:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:17 --> Controller Class Initialized
DEBUG - 2021-06-12 06:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:06:17 --> Final output sent to browser
DEBUG - 2021-06-12 06:06:17 --> Total execution time: 0.0882
INFO - 2021-06-12 06:06:19 --> Config Class Initialized
INFO - 2021-06-12 06:06:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:19 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:19 --> URI Class Initialized
INFO - 2021-06-12 06:06:19 --> Router Class Initialized
INFO - 2021-06-12 06:06:19 --> Output Class Initialized
INFO - 2021-06-12 06:06:19 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:19 --> Input Class Initialized
INFO - 2021-06-12 06:06:19 --> Language Class Initialized
INFO - 2021-06-12 06:06:19 --> Language Class Initialized
INFO - 2021-06-12 06:06:19 --> Config Class Initialized
INFO - 2021-06-12 06:06:19 --> Loader Class Initialized
INFO - 2021-06-12 06:06:19 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:19 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:19 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:19 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:19 --> Controller Class Initialized
DEBUG - 2021-06-12 06:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:06:19 --> Final output sent to browser
DEBUG - 2021-06-12 06:06:19 --> Total execution time: 0.0523
INFO - 2021-06-12 06:06:23 --> Config Class Initialized
INFO - 2021-06-12 06:06:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:23 --> URI Class Initialized
INFO - 2021-06-12 06:06:23 --> Router Class Initialized
INFO - 2021-06-12 06:06:23 --> Output Class Initialized
INFO - 2021-06-12 06:06:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:23 --> Input Class Initialized
INFO - 2021-06-12 06:06:23 --> Language Class Initialized
INFO - 2021-06-12 06:06:23 --> Language Class Initialized
INFO - 2021-06-12 06:06:23 --> Config Class Initialized
INFO - 2021-06-12 06:06:23 --> Loader Class Initialized
INFO - 2021-06-12 06:06:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:23 --> Controller Class Initialized
DEBUG - 2021-06-12 06:06:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:06:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:06:23 --> Final output sent to browser
DEBUG - 2021-06-12 06:06:23 --> Total execution time: 0.0560
INFO - 2021-06-12 06:06:23 --> Config Class Initialized
INFO - 2021-06-12 06:06:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:23 --> URI Class Initialized
INFO - 2021-06-12 06:06:23 --> Router Class Initialized
INFO - 2021-06-12 06:06:23 --> Output Class Initialized
INFO - 2021-06-12 06:06:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:23 --> Input Class Initialized
INFO - 2021-06-12 06:06:23 --> Language Class Initialized
INFO - 2021-06-12 06:06:23 --> Language Class Initialized
INFO - 2021-06-12 06:06:23 --> Config Class Initialized
INFO - 2021-06-12 06:06:23 --> Loader Class Initialized
INFO - 2021-06-12 06:06:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:23 --> Controller Class Initialized
INFO - 2021-06-12 06:06:30 --> Config Class Initialized
INFO - 2021-06-12 06:06:30 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:30 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:30 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:30 --> URI Class Initialized
INFO - 2021-06-12 06:06:30 --> Router Class Initialized
INFO - 2021-06-12 06:06:30 --> Output Class Initialized
INFO - 2021-06-12 06:06:30 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:30 --> Input Class Initialized
INFO - 2021-06-12 06:06:30 --> Language Class Initialized
INFO - 2021-06-12 06:06:30 --> Language Class Initialized
INFO - 2021-06-12 06:06:30 --> Config Class Initialized
INFO - 2021-06-12 06:06:30 --> Loader Class Initialized
INFO - 2021-06-12 06:06:30 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:30 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:30 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:30 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:30 --> Controller Class Initialized
DEBUG - 2021-06-12 06:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-12 06:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:06:30 --> Final output sent to browser
DEBUG - 2021-06-12 06:06:30 --> Total execution time: 0.0654
INFO - 2021-06-12 06:06:58 --> Config Class Initialized
INFO - 2021-06-12 06:06:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:58 --> URI Class Initialized
INFO - 2021-06-12 06:06:58 --> Router Class Initialized
INFO - 2021-06-12 06:06:58 --> Output Class Initialized
INFO - 2021-06-12 06:06:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:58 --> Input Class Initialized
INFO - 2021-06-12 06:06:58 --> Language Class Initialized
INFO - 2021-06-12 06:06:58 --> Language Class Initialized
INFO - 2021-06-12 06:06:58 --> Config Class Initialized
INFO - 2021-06-12 06:06:58 --> Loader Class Initialized
INFO - 2021-06-12 06:06:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:58 --> Controller Class Initialized
INFO - 2021-06-12 06:06:58 --> Config Class Initialized
INFO - 2021-06-12 06:06:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:58 --> URI Class Initialized
INFO - 2021-06-12 06:06:58 --> Router Class Initialized
INFO - 2021-06-12 06:06:58 --> Output Class Initialized
INFO - 2021-06-12 06:06:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:58 --> Input Class Initialized
INFO - 2021-06-12 06:06:58 --> Language Class Initialized
INFO - 2021-06-12 06:06:58 --> Language Class Initialized
INFO - 2021-06-12 06:06:58 --> Config Class Initialized
INFO - 2021-06-12 06:06:58 --> Loader Class Initialized
INFO - 2021-06-12 06:06:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:58 --> Controller Class Initialized
DEBUG - 2021-06-12 06:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:06:58 --> Final output sent to browser
DEBUG - 2021-06-12 06:06:58 --> Total execution time: 0.0437
INFO - 2021-06-12 06:06:58 --> Config Class Initialized
INFO - 2021-06-12 06:06:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:06:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:06:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:06:58 --> URI Class Initialized
INFO - 2021-06-12 06:06:58 --> Router Class Initialized
INFO - 2021-06-12 06:06:58 --> Output Class Initialized
INFO - 2021-06-12 06:06:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:06:58 --> Input Class Initialized
INFO - 2021-06-12 06:06:58 --> Language Class Initialized
INFO - 2021-06-12 06:06:58 --> Language Class Initialized
INFO - 2021-06-12 06:06:58 --> Config Class Initialized
INFO - 2021-06-12 06:06:58 --> Loader Class Initialized
INFO - 2021-06-12 06:06:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:06:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:06:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:06:58 --> Controller Class Initialized
INFO - 2021-06-12 06:07:00 --> Config Class Initialized
INFO - 2021-06-12 06:07:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:00 --> URI Class Initialized
INFO - 2021-06-12 06:07:00 --> Router Class Initialized
INFO - 2021-06-12 06:07:00 --> Output Class Initialized
INFO - 2021-06-12 06:07:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:00 --> Input Class Initialized
INFO - 2021-06-12 06:07:00 --> Language Class Initialized
INFO - 2021-06-12 06:07:00 --> Language Class Initialized
INFO - 2021-06-12 06:07:00 --> Config Class Initialized
INFO - 2021-06-12 06:07:00 --> Loader Class Initialized
INFO - 2021-06-12 06:07:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:00 --> Controller Class Initialized
INFO - 2021-06-12 06:07:00 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:00 --> Total execution time: 0.0484
INFO - 2021-06-12 06:07:05 --> Config Class Initialized
INFO - 2021-06-12 06:07:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:05 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:05 --> URI Class Initialized
INFO - 2021-06-12 06:07:05 --> Router Class Initialized
INFO - 2021-06-12 06:07:05 --> Output Class Initialized
INFO - 2021-06-12 06:07:05 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:05 --> Input Class Initialized
INFO - 2021-06-12 06:07:05 --> Language Class Initialized
INFO - 2021-06-12 06:07:05 --> Language Class Initialized
INFO - 2021-06-12 06:07:05 --> Config Class Initialized
INFO - 2021-06-12 06:07:05 --> Loader Class Initialized
INFO - 2021-06-12 06:07:05 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:05 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:05 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:05 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:05 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:07:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:05 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:05 --> Total execution time: 0.0518
INFO - 2021-06-12 06:07:06 --> Config Class Initialized
INFO - 2021-06-12 06:07:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:06 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:06 --> URI Class Initialized
INFO - 2021-06-12 06:07:06 --> Router Class Initialized
INFO - 2021-06-12 06:07:06 --> Output Class Initialized
INFO - 2021-06-12 06:07:06 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:06 --> Input Class Initialized
INFO - 2021-06-12 06:07:06 --> Language Class Initialized
INFO - 2021-06-12 06:07:06 --> Language Class Initialized
INFO - 2021-06-12 06:07:06 --> Config Class Initialized
INFO - 2021-06-12 06:07:06 --> Loader Class Initialized
INFO - 2021-06-12 06:07:06 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:06 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:06 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:06 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:06 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:07:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:06 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:06 --> Total execution time: 0.0531
INFO - 2021-06-12 06:07:08 --> Config Class Initialized
INFO - 2021-06-12 06:07:08 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:08 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:08 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:08 --> URI Class Initialized
INFO - 2021-06-12 06:07:08 --> Router Class Initialized
INFO - 2021-06-12 06:07:08 --> Output Class Initialized
INFO - 2021-06-12 06:07:08 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:08 --> Input Class Initialized
INFO - 2021-06-12 06:07:08 --> Language Class Initialized
INFO - 2021-06-12 06:07:08 --> Language Class Initialized
INFO - 2021-06-12 06:07:08 --> Config Class Initialized
INFO - 2021-06-12 06:07:08 --> Loader Class Initialized
INFO - 2021-06-12 06:07:08 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:08 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:08 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:08 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:08 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:08 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-12 06:07:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:08 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:08 --> Total execution time: 0.0672
INFO - 2021-06-12 06:07:15 --> Config Class Initialized
INFO - 2021-06-12 06:07:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:15 --> URI Class Initialized
INFO - 2021-06-12 06:07:15 --> Router Class Initialized
INFO - 2021-06-12 06:07:15 --> Output Class Initialized
INFO - 2021-06-12 06:07:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:15 --> Input Class Initialized
INFO - 2021-06-12 06:07:15 --> Language Class Initialized
INFO - 2021-06-12 06:07:15 --> Language Class Initialized
INFO - 2021-06-12 06:07:15 --> Config Class Initialized
INFO - 2021-06-12 06:07:15 --> Loader Class Initialized
INFO - 2021-06-12 06:07:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:15 --> Controller Class Initialized
INFO - 2021-06-12 06:07:15 --> Config Class Initialized
INFO - 2021-06-12 06:07:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:15 --> URI Class Initialized
INFO - 2021-06-12 06:07:15 --> Router Class Initialized
INFO - 2021-06-12 06:07:15 --> Output Class Initialized
INFO - 2021-06-12 06:07:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:15 --> Input Class Initialized
INFO - 2021-06-12 06:07:15 --> Language Class Initialized
INFO - 2021-06-12 06:07:15 --> Language Class Initialized
INFO - 2021-06-12 06:07:15 --> Config Class Initialized
INFO - 2021-06-12 06:07:15 --> Loader Class Initialized
INFO - 2021-06-12 06:07:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:16 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:07:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:16 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:16 --> Total execution time: 0.0537
INFO - 2021-06-12 06:07:17 --> Config Class Initialized
INFO - 2021-06-12 06:07:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:17 --> URI Class Initialized
INFO - 2021-06-12 06:07:17 --> Router Class Initialized
INFO - 2021-06-12 06:07:17 --> Output Class Initialized
INFO - 2021-06-12 06:07:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:17 --> Input Class Initialized
INFO - 2021-06-12 06:07:17 --> Language Class Initialized
INFO - 2021-06-12 06:07:17 --> Language Class Initialized
INFO - 2021-06-12 06:07:17 --> Config Class Initialized
INFO - 2021-06-12 06:07:17 --> Loader Class Initialized
INFO - 2021-06-12 06:07:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:17 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:07:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:17 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:17 --> Total execution time: 0.0523
INFO - 2021-06-12 06:07:18 --> Config Class Initialized
INFO - 2021-06-12 06:07:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:18 --> URI Class Initialized
INFO - 2021-06-12 06:07:18 --> Router Class Initialized
INFO - 2021-06-12 06:07:18 --> Output Class Initialized
INFO - 2021-06-12 06:07:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:18 --> Input Class Initialized
INFO - 2021-06-12 06:07:18 --> Language Class Initialized
INFO - 2021-06-12 06:07:18 --> Language Class Initialized
INFO - 2021-06-12 06:07:18 --> Config Class Initialized
INFO - 2021-06-12 06:07:18 --> Loader Class Initialized
INFO - 2021-06-12 06:07:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:18 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:07:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:18 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:18 --> Total execution time: 0.0426
INFO - 2021-06-12 06:07:18 --> Config Class Initialized
INFO - 2021-06-12 06:07:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:18 --> URI Class Initialized
INFO - 2021-06-12 06:07:18 --> Router Class Initialized
INFO - 2021-06-12 06:07:18 --> Output Class Initialized
INFO - 2021-06-12 06:07:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:18 --> Input Class Initialized
INFO - 2021-06-12 06:07:18 --> Language Class Initialized
INFO - 2021-06-12 06:07:18 --> Language Class Initialized
INFO - 2021-06-12 06:07:18 --> Config Class Initialized
INFO - 2021-06-12 06:07:18 --> Loader Class Initialized
INFO - 2021-06-12 06:07:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:18 --> Controller Class Initialized
INFO - 2021-06-12 06:07:20 --> Config Class Initialized
INFO - 2021-06-12 06:07:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:20 --> URI Class Initialized
INFO - 2021-06-12 06:07:20 --> Router Class Initialized
INFO - 2021-06-12 06:07:20 --> Output Class Initialized
INFO - 2021-06-12 06:07:20 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:20 --> Input Class Initialized
INFO - 2021-06-12 06:07:20 --> Language Class Initialized
INFO - 2021-06-12 06:07:20 --> Language Class Initialized
INFO - 2021-06-12 06:07:20 --> Config Class Initialized
INFO - 2021-06-12 06:07:20 --> Loader Class Initialized
INFO - 2021-06-12 06:07:20 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:20 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:20 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:20 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:21 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-06-12 06:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:21 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:21 --> Total execution time: 0.0518
INFO - 2021-06-12 06:07:27 --> Config Class Initialized
INFO - 2021-06-12 06:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:27 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:27 --> URI Class Initialized
INFO - 2021-06-12 06:07:27 --> Router Class Initialized
INFO - 2021-06-12 06:07:27 --> Output Class Initialized
INFO - 2021-06-12 06:07:27 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:27 --> Input Class Initialized
INFO - 2021-06-12 06:07:27 --> Language Class Initialized
INFO - 2021-06-12 06:07:27 --> Language Class Initialized
INFO - 2021-06-12 06:07:27 --> Config Class Initialized
INFO - 2021-06-12 06:07:27 --> Loader Class Initialized
INFO - 2021-06-12 06:07:27 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:27 --> Controller Class Initialized
INFO - 2021-06-12 06:07:27 --> Config Class Initialized
INFO - 2021-06-12 06:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:27 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:27 --> URI Class Initialized
INFO - 2021-06-12 06:07:27 --> Router Class Initialized
INFO - 2021-06-12 06:07:27 --> Output Class Initialized
INFO - 2021-06-12 06:07:27 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:27 --> Input Class Initialized
INFO - 2021-06-12 06:07:27 --> Language Class Initialized
INFO - 2021-06-12 06:07:27 --> Language Class Initialized
INFO - 2021-06-12 06:07:27 --> Config Class Initialized
INFO - 2021-06-12 06:07:27 --> Loader Class Initialized
INFO - 2021-06-12 06:07:27 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:27 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:07:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:27 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:27 --> Total execution time: 0.0513
INFO - 2021-06-12 06:07:27 --> Config Class Initialized
INFO - 2021-06-12 06:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:27 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:27 --> URI Class Initialized
INFO - 2021-06-12 06:07:27 --> Router Class Initialized
INFO - 2021-06-12 06:07:27 --> Output Class Initialized
INFO - 2021-06-12 06:07:27 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:27 --> Input Class Initialized
INFO - 2021-06-12 06:07:27 --> Language Class Initialized
INFO - 2021-06-12 06:07:27 --> Language Class Initialized
INFO - 2021-06-12 06:07:27 --> Config Class Initialized
INFO - 2021-06-12 06:07:27 --> Loader Class Initialized
INFO - 2021-06-12 06:07:27 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:27 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:27 --> Controller Class Initialized
INFO - 2021-06-12 06:07:28 --> Config Class Initialized
INFO - 2021-06-12 06:07:28 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:28 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:28 --> URI Class Initialized
INFO - 2021-06-12 06:07:28 --> Router Class Initialized
INFO - 2021-06-12 06:07:28 --> Output Class Initialized
INFO - 2021-06-12 06:07:28 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:28 --> Input Class Initialized
INFO - 2021-06-12 06:07:28 --> Language Class Initialized
INFO - 2021-06-12 06:07:28 --> Language Class Initialized
INFO - 2021-06-12 06:07:28 --> Config Class Initialized
INFO - 2021-06-12 06:07:28 --> Loader Class Initialized
INFO - 2021-06-12 06:07:28 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:28 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:28 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:28 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:28 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:28 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:28 --> Total execution time: 0.0526
INFO - 2021-06-12 06:07:29 --> Config Class Initialized
INFO - 2021-06-12 06:07:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:29 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:29 --> URI Class Initialized
INFO - 2021-06-12 06:07:29 --> Router Class Initialized
INFO - 2021-06-12 06:07:29 --> Output Class Initialized
INFO - 2021-06-12 06:07:29 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:29 --> Input Class Initialized
INFO - 2021-06-12 06:07:29 --> Language Class Initialized
INFO - 2021-06-12 06:07:29 --> Language Class Initialized
INFO - 2021-06-12 06:07:29 --> Config Class Initialized
INFO - 2021-06-12 06:07:29 --> Loader Class Initialized
INFO - 2021-06-12 06:07:29 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:29 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:29 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:29 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:30 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:30 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:30 --> Total execution time: 0.0522
INFO - 2021-06-12 06:07:31 --> Config Class Initialized
INFO - 2021-06-12 06:07:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:31 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:31 --> URI Class Initialized
INFO - 2021-06-12 06:07:31 --> Router Class Initialized
INFO - 2021-06-12 06:07:31 --> Output Class Initialized
INFO - 2021-06-12 06:07:31 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:31 --> Input Class Initialized
INFO - 2021-06-12 06:07:31 --> Language Class Initialized
INFO - 2021-06-12 06:07:31 --> Language Class Initialized
INFO - 2021-06-12 06:07:31 --> Config Class Initialized
INFO - 2021-06-12 06:07:31 --> Loader Class Initialized
INFO - 2021-06-12 06:07:31 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:31 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:31 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:31 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:31 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-06-12 06:07:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:31 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:31 --> Total execution time: 0.0428
INFO - 2021-06-12 06:07:35 --> Config Class Initialized
INFO - 2021-06-12 06:07:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:35 --> URI Class Initialized
INFO - 2021-06-12 06:07:35 --> Router Class Initialized
INFO - 2021-06-12 06:07:35 --> Output Class Initialized
INFO - 2021-06-12 06:07:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:35 --> Input Class Initialized
INFO - 2021-06-12 06:07:35 --> Language Class Initialized
INFO - 2021-06-12 06:07:35 --> Language Class Initialized
INFO - 2021-06-12 06:07:35 --> Config Class Initialized
INFO - 2021-06-12 06:07:35 --> Loader Class Initialized
INFO - 2021-06-12 06:07:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:35 --> Controller Class Initialized
INFO - 2021-06-12 06:07:35 --> Config Class Initialized
INFO - 2021-06-12 06:07:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:35 --> URI Class Initialized
INFO - 2021-06-12 06:07:35 --> Router Class Initialized
INFO - 2021-06-12 06:07:35 --> Output Class Initialized
INFO - 2021-06-12 06:07:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:35 --> Input Class Initialized
INFO - 2021-06-12 06:07:35 --> Language Class Initialized
INFO - 2021-06-12 06:07:36 --> Language Class Initialized
INFO - 2021-06-12 06:07:36 --> Config Class Initialized
INFO - 2021-06-12 06:07:36 --> Loader Class Initialized
INFO - 2021-06-12 06:07:36 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:36 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:36 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:36 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:36 --> Controller Class Initialized
DEBUG - 2021-06-12 06:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:07:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:07:36 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:36 --> Total execution time: 0.0415
INFO - 2021-06-12 06:07:37 --> Config Class Initialized
INFO - 2021-06-12 06:07:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:07:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:07:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:07:37 --> URI Class Initialized
INFO - 2021-06-12 06:07:37 --> Router Class Initialized
INFO - 2021-06-12 06:07:37 --> Output Class Initialized
INFO - 2021-06-12 06:07:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:07:37 --> Input Class Initialized
INFO - 2021-06-12 06:07:37 --> Language Class Initialized
INFO - 2021-06-12 06:07:37 --> Language Class Initialized
INFO - 2021-06-12 06:07:37 --> Config Class Initialized
INFO - 2021-06-12 06:07:37 --> Loader Class Initialized
INFO - 2021-06-12 06:07:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:07:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:07:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:07:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:07:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:07:37 --> Controller Class Initialized
INFO - 2021-06-12 06:07:37 --> Final output sent to browser
DEBUG - 2021-06-12 06:07:37 --> Total execution time: 0.0508
INFO - 2021-06-12 06:08:48 --> Config Class Initialized
INFO - 2021-06-12 06:08:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:08:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:08:48 --> Utf8 Class Initialized
INFO - 2021-06-12 06:08:48 --> URI Class Initialized
INFO - 2021-06-12 06:08:48 --> Router Class Initialized
INFO - 2021-06-12 06:08:48 --> Output Class Initialized
INFO - 2021-06-12 06:08:48 --> Security Class Initialized
DEBUG - 2021-06-12 06:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:08:48 --> Input Class Initialized
INFO - 2021-06-12 06:08:48 --> Language Class Initialized
INFO - 2021-06-12 06:08:48 --> Language Class Initialized
INFO - 2021-06-12 06:08:48 --> Config Class Initialized
INFO - 2021-06-12 06:08:48 --> Loader Class Initialized
INFO - 2021-06-12 06:08:48 --> Helper loaded: url_helper
INFO - 2021-06-12 06:08:48 --> Helper loaded: file_helper
INFO - 2021-06-12 06:08:48 --> Helper loaded: form_helper
INFO - 2021-06-12 06:08:48 --> Helper loaded: my_helper
INFO - 2021-06-12 06:08:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:08:48 --> Controller Class Initialized
INFO - 2021-06-12 06:08:48 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:08:48 --> Config Class Initialized
INFO - 2021-06-12 06:08:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:08:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:08:48 --> Utf8 Class Initialized
INFO - 2021-06-12 06:08:48 --> URI Class Initialized
INFO - 2021-06-12 06:08:48 --> Router Class Initialized
INFO - 2021-06-12 06:08:48 --> Output Class Initialized
INFO - 2021-06-12 06:08:48 --> Security Class Initialized
DEBUG - 2021-06-12 06:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:08:48 --> Input Class Initialized
INFO - 2021-06-12 06:08:48 --> Language Class Initialized
INFO - 2021-06-12 06:08:48 --> Language Class Initialized
INFO - 2021-06-12 06:08:48 --> Config Class Initialized
INFO - 2021-06-12 06:08:48 --> Loader Class Initialized
INFO - 2021-06-12 06:08:48 --> Helper loaded: url_helper
INFO - 2021-06-12 06:08:48 --> Helper loaded: file_helper
INFO - 2021-06-12 06:08:48 --> Helper loaded: form_helper
INFO - 2021-06-12 06:08:48 --> Helper loaded: my_helper
INFO - 2021-06-12 06:08:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:08:48 --> Controller Class Initialized
DEBUG - 2021-06-12 06:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:08:48 --> Final output sent to browser
DEBUG - 2021-06-12 06:08:48 --> Total execution time: 0.0499
INFO - 2021-06-12 06:09:02 --> Config Class Initialized
INFO - 2021-06-12 06:09:02 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:02 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:02 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:02 --> URI Class Initialized
INFO - 2021-06-12 06:09:02 --> Router Class Initialized
INFO - 2021-06-12 06:09:02 --> Output Class Initialized
INFO - 2021-06-12 06:09:02 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:02 --> Input Class Initialized
INFO - 2021-06-12 06:09:02 --> Language Class Initialized
INFO - 2021-06-12 06:09:02 --> Language Class Initialized
INFO - 2021-06-12 06:09:02 --> Config Class Initialized
INFO - 2021-06-12 06:09:02 --> Loader Class Initialized
INFO - 2021-06-12 06:09:02 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:02 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:02 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:02 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:02 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:02 --> Controller Class Initialized
INFO - 2021-06-12 06:09:02 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:09:02 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:02 --> Total execution time: 0.0520
INFO - 2021-06-12 06:09:02 --> Config Class Initialized
INFO - 2021-06-12 06:09:02 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:02 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:02 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:02 --> URI Class Initialized
INFO - 2021-06-12 06:09:02 --> Router Class Initialized
INFO - 2021-06-12 06:09:02 --> Output Class Initialized
INFO - 2021-06-12 06:09:02 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:02 --> Input Class Initialized
INFO - 2021-06-12 06:09:02 --> Language Class Initialized
INFO - 2021-06-12 06:09:02 --> Language Class Initialized
INFO - 2021-06-12 06:09:02 --> Config Class Initialized
INFO - 2021-06-12 06:09:02 --> Loader Class Initialized
INFO - 2021-06-12 06:09:02 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:02 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:02 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:02 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:02 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:02 --> Controller Class Initialized
DEBUG - 2021-06-12 06:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:09:02 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:02 --> Total execution time: 0.0851
INFO - 2021-06-12 06:09:16 --> Config Class Initialized
INFO - 2021-06-12 06:09:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:16 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:16 --> URI Class Initialized
INFO - 2021-06-12 06:09:16 --> Router Class Initialized
INFO - 2021-06-12 06:09:16 --> Output Class Initialized
INFO - 2021-06-12 06:09:16 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:16 --> Input Class Initialized
INFO - 2021-06-12 06:09:16 --> Language Class Initialized
INFO - 2021-06-12 06:09:16 --> Language Class Initialized
INFO - 2021-06-12 06:09:16 --> Config Class Initialized
INFO - 2021-06-12 06:09:16 --> Loader Class Initialized
INFO - 2021-06-12 06:09:16 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:16 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:16 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:16 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:16 --> Controller Class Initialized
DEBUG - 2021-06-12 06:09:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:09:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:09:16 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:16 --> Total execution time: 0.0412
INFO - 2021-06-12 06:09:38 --> Config Class Initialized
INFO - 2021-06-12 06:09:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:38 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:38 --> URI Class Initialized
INFO - 2021-06-12 06:09:38 --> Router Class Initialized
INFO - 2021-06-12 06:09:38 --> Output Class Initialized
INFO - 2021-06-12 06:09:38 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:38 --> Input Class Initialized
INFO - 2021-06-12 06:09:38 --> Language Class Initialized
INFO - 2021-06-12 06:09:38 --> Language Class Initialized
INFO - 2021-06-12 06:09:38 --> Config Class Initialized
INFO - 2021-06-12 06:09:38 --> Loader Class Initialized
INFO - 2021-06-12 06:09:38 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:38 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:38 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:38 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:38 --> Controller Class Initialized
DEBUG - 2021-06-12 06:09:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:09:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:09:38 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:38 --> Total execution time: 0.0467
INFO - 2021-06-12 06:09:38 --> Config Class Initialized
INFO - 2021-06-12 06:09:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:38 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:38 --> URI Class Initialized
INFO - 2021-06-12 06:09:38 --> Router Class Initialized
INFO - 2021-06-12 06:09:38 --> Output Class Initialized
INFO - 2021-06-12 06:09:38 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:38 --> Input Class Initialized
INFO - 2021-06-12 06:09:38 --> Language Class Initialized
INFO - 2021-06-12 06:09:38 --> Language Class Initialized
INFO - 2021-06-12 06:09:38 --> Config Class Initialized
INFO - 2021-06-12 06:09:38 --> Loader Class Initialized
INFO - 2021-06-12 06:09:38 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:38 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:38 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:38 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:38 --> Controller Class Initialized
INFO - 2021-06-12 06:09:39 --> Config Class Initialized
INFO - 2021-06-12 06:09:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:39 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:39 --> URI Class Initialized
INFO - 2021-06-12 06:09:39 --> Router Class Initialized
INFO - 2021-06-12 06:09:39 --> Output Class Initialized
INFO - 2021-06-12 06:09:39 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:39 --> Input Class Initialized
INFO - 2021-06-12 06:09:39 --> Language Class Initialized
INFO - 2021-06-12 06:09:39 --> Language Class Initialized
INFO - 2021-06-12 06:09:39 --> Config Class Initialized
INFO - 2021-06-12 06:09:39 --> Loader Class Initialized
INFO - 2021-06-12 06:09:39 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:39 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:39 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:39 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:39 --> Controller Class Initialized
DEBUG - 2021-06-12 06:09:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:09:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:09:39 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:39 --> Total execution time: 0.0452
INFO - 2021-06-12 06:09:42 --> Config Class Initialized
INFO - 2021-06-12 06:09:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:42 --> URI Class Initialized
INFO - 2021-06-12 06:09:42 --> Router Class Initialized
INFO - 2021-06-12 06:09:42 --> Output Class Initialized
INFO - 2021-06-12 06:09:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:42 --> Input Class Initialized
INFO - 2021-06-12 06:09:42 --> Language Class Initialized
INFO - 2021-06-12 06:09:42 --> Language Class Initialized
INFO - 2021-06-12 06:09:42 --> Config Class Initialized
INFO - 2021-06-12 06:09:42 --> Loader Class Initialized
INFO - 2021-06-12 06:09:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:42 --> Controller Class Initialized
INFO - 2021-06-12 06:09:42 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:42 --> Total execution time: 0.0538
INFO - 2021-06-12 06:09:44 --> Config Class Initialized
INFO - 2021-06-12 06:09:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:44 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:44 --> URI Class Initialized
INFO - 2021-06-12 06:09:44 --> Router Class Initialized
INFO - 2021-06-12 06:09:44 --> Output Class Initialized
INFO - 2021-06-12 06:09:44 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:44 --> Input Class Initialized
INFO - 2021-06-12 06:09:44 --> Language Class Initialized
INFO - 2021-06-12 06:09:44 --> Language Class Initialized
INFO - 2021-06-12 06:09:44 --> Config Class Initialized
INFO - 2021-06-12 06:09:44 --> Loader Class Initialized
INFO - 2021-06-12 06:09:44 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:44 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:44 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:44 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:44 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:44 --> Controller Class Initialized
INFO - 2021-06-12 06:09:44 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:44 --> Total execution time: 0.0419
INFO - 2021-06-12 06:09:46 --> Config Class Initialized
INFO - 2021-06-12 06:09:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:46 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:46 --> URI Class Initialized
INFO - 2021-06-12 06:09:46 --> Router Class Initialized
INFO - 2021-06-12 06:09:46 --> Output Class Initialized
INFO - 2021-06-12 06:09:46 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:46 --> Input Class Initialized
INFO - 2021-06-12 06:09:46 --> Language Class Initialized
INFO - 2021-06-12 06:09:46 --> Language Class Initialized
INFO - 2021-06-12 06:09:46 --> Config Class Initialized
INFO - 2021-06-12 06:09:46 --> Loader Class Initialized
INFO - 2021-06-12 06:09:46 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:46 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:46 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:46 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:46 --> Controller Class Initialized
INFO - 2021-06-12 06:09:46 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:46 --> Total execution time: 0.0401
INFO - 2021-06-12 06:09:49 --> Config Class Initialized
INFO - 2021-06-12 06:09:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:09:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:09:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:09:49 --> URI Class Initialized
INFO - 2021-06-12 06:09:49 --> Router Class Initialized
INFO - 2021-06-12 06:09:49 --> Output Class Initialized
INFO - 2021-06-12 06:09:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:09:49 --> Input Class Initialized
INFO - 2021-06-12 06:09:49 --> Language Class Initialized
INFO - 2021-06-12 06:09:49 --> Language Class Initialized
INFO - 2021-06-12 06:09:49 --> Config Class Initialized
INFO - 2021-06-12 06:09:49 --> Loader Class Initialized
INFO - 2021-06-12 06:09:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:09:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:09:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:09:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:09:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:09:49 --> Controller Class Initialized
INFO - 2021-06-12 06:09:49 --> Final output sent to browser
DEBUG - 2021-06-12 06:09:49 --> Total execution time: 0.0519
INFO - 2021-06-12 06:10:00 --> Config Class Initialized
INFO - 2021-06-12 06:10:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:10:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:10:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:10:00 --> URI Class Initialized
INFO - 2021-06-12 06:10:00 --> Router Class Initialized
INFO - 2021-06-12 06:10:00 --> Output Class Initialized
INFO - 2021-06-12 06:10:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:10:00 --> Input Class Initialized
INFO - 2021-06-12 06:10:00 --> Language Class Initialized
INFO - 2021-06-12 06:10:00 --> Language Class Initialized
INFO - 2021-06-12 06:10:00 --> Config Class Initialized
INFO - 2021-06-12 06:10:00 --> Loader Class Initialized
INFO - 2021-06-12 06:10:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:10:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:10:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:10:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:10:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:10:00 --> Controller Class Initialized
INFO - 2021-06-12 06:11:35 --> Config Class Initialized
INFO - 2021-06-12 06:11:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:11:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:11:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:11:35 --> URI Class Initialized
INFO - 2021-06-12 06:11:35 --> Router Class Initialized
INFO - 2021-06-12 06:11:35 --> Output Class Initialized
INFO - 2021-06-12 06:11:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:11:35 --> Input Class Initialized
INFO - 2021-06-12 06:11:35 --> Language Class Initialized
INFO - 2021-06-12 06:11:35 --> Language Class Initialized
INFO - 2021-06-12 06:11:35 --> Config Class Initialized
INFO - 2021-06-12 06:11:35 --> Loader Class Initialized
INFO - 2021-06-12 06:11:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:11:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:11:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:11:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:11:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:11:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:11:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:11:35 --> Controller Class Initialized
INFO - 2021-06-12 06:12:13 --> Config Class Initialized
INFO - 2021-06-12 06:12:13 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:12:13 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:12:13 --> Utf8 Class Initialized
INFO - 2021-06-12 06:12:13 --> URI Class Initialized
INFO - 2021-06-12 06:12:13 --> Router Class Initialized
INFO - 2021-06-12 06:12:13 --> Output Class Initialized
INFO - 2021-06-12 06:12:13 --> Security Class Initialized
DEBUG - 2021-06-12 06:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:12:13 --> Input Class Initialized
INFO - 2021-06-12 06:12:13 --> Language Class Initialized
INFO - 2021-06-12 06:12:13 --> Language Class Initialized
INFO - 2021-06-12 06:12:13 --> Config Class Initialized
INFO - 2021-06-12 06:12:13 --> Loader Class Initialized
INFO - 2021-06-12 06:12:13 --> Helper loaded: url_helper
INFO - 2021-06-12 06:12:13 --> Helper loaded: file_helper
INFO - 2021-06-12 06:12:13 --> Helper loaded: form_helper
INFO - 2021-06-12 06:12:13 --> Helper loaded: my_helper
INFO - 2021-06-12 06:12:13 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:12:13 --> Controller Class Initialized
DEBUG - 2021-06-12 06:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:12:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:12:13 --> Final output sent to browser
DEBUG - 2021-06-12 06:12:13 --> Total execution time: 0.0461
INFO - 2021-06-12 06:12:15 --> Config Class Initialized
INFO - 2021-06-12 06:12:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:12:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:12:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:12:15 --> URI Class Initialized
INFO - 2021-06-12 06:12:15 --> Router Class Initialized
INFO - 2021-06-12 06:12:15 --> Output Class Initialized
INFO - 2021-06-12 06:12:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:12:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:12:15 --> Input Class Initialized
INFO - 2021-06-12 06:12:15 --> Language Class Initialized
INFO - 2021-06-12 06:12:15 --> Language Class Initialized
INFO - 2021-06-12 06:12:15 --> Config Class Initialized
INFO - 2021-06-12 06:12:15 --> Loader Class Initialized
INFO - 2021-06-12 06:12:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:12:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:12:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:12:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:12:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:12:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:12:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:12:15 --> Controller Class Initialized
INFO - 2021-06-12 06:12:16 --> Config Class Initialized
INFO - 2021-06-12 06:12:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:12:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:12:16 --> Utf8 Class Initialized
INFO - 2021-06-12 06:12:16 --> URI Class Initialized
INFO - 2021-06-12 06:12:16 --> Router Class Initialized
INFO - 2021-06-12 06:12:16 --> Output Class Initialized
INFO - 2021-06-12 06:12:16 --> Security Class Initialized
DEBUG - 2021-06-12 06:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:12:16 --> Input Class Initialized
INFO - 2021-06-12 06:12:16 --> Language Class Initialized
INFO - 2021-06-12 06:12:16 --> Language Class Initialized
INFO - 2021-06-12 06:12:16 --> Config Class Initialized
INFO - 2021-06-12 06:12:16 --> Loader Class Initialized
INFO - 2021-06-12 06:12:16 --> Helper loaded: url_helper
INFO - 2021-06-12 06:12:16 --> Helper loaded: file_helper
INFO - 2021-06-12 06:12:16 --> Helper loaded: form_helper
INFO - 2021-06-12 06:12:16 --> Helper loaded: my_helper
INFO - 2021-06-12 06:12:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:12:16 --> Controller Class Initialized
DEBUG - 2021-06-12 06:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:12:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:12:16 --> Final output sent to browser
DEBUG - 2021-06-12 06:12:16 --> Total execution time: 0.0648
INFO - 2021-06-12 06:12:18 --> Config Class Initialized
INFO - 2021-06-12 06:12:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:12:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:12:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:12:18 --> URI Class Initialized
INFO - 2021-06-12 06:12:18 --> Router Class Initialized
INFO - 2021-06-12 06:12:18 --> Output Class Initialized
INFO - 2021-06-12 06:12:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:12:18 --> Input Class Initialized
INFO - 2021-06-12 06:12:18 --> Language Class Initialized
INFO - 2021-06-12 06:12:18 --> Language Class Initialized
INFO - 2021-06-12 06:12:18 --> Config Class Initialized
INFO - 2021-06-12 06:12:18 --> Loader Class Initialized
INFO - 2021-06-12 06:12:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:12:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:12:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:12:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:12:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:12:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:12:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:12:18 --> Controller Class Initialized
INFO - 2021-06-12 06:12:49 --> Config Class Initialized
INFO - 2021-06-12 06:12:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:12:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:12:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:12:49 --> URI Class Initialized
INFO - 2021-06-12 06:12:49 --> Router Class Initialized
INFO - 2021-06-12 06:12:49 --> Output Class Initialized
INFO - 2021-06-12 06:12:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:12:49 --> Input Class Initialized
INFO - 2021-06-12 06:12:49 --> Language Class Initialized
INFO - 2021-06-12 06:12:49 --> Language Class Initialized
INFO - 2021-06-12 06:12:49 --> Config Class Initialized
INFO - 2021-06-12 06:12:49 --> Loader Class Initialized
INFO - 2021-06-12 06:12:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:12:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:12:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:12:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:12:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:12:49 --> Controller Class Initialized
INFO - 2021-06-12 06:13:30 --> Config Class Initialized
INFO - 2021-06-12 06:13:30 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:13:30 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:13:30 --> Utf8 Class Initialized
INFO - 2021-06-12 06:13:30 --> URI Class Initialized
INFO - 2021-06-12 06:13:30 --> Router Class Initialized
INFO - 2021-06-12 06:13:30 --> Output Class Initialized
INFO - 2021-06-12 06:13:30 --> Security Class Initialized
DEBUG - 2021-06-12 06:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:13:30 --> Input Class Initialized
INFO - 2021-06-12 06:13:30 --> Language Class Initialized
INFO - 2021-06-12 06:13:30 --> Language Class Initialized
INFO - 2021-06-12 06:13:30 --> Config Class Initialized
INFO - 2021-06-12 06:13:30 --> Loader Class Initialized
INFO - 2021-06-12 06:13:30 --> Helper loaded: url_helper
INFO - 2021-06-12 06:13:30 --> Helper loaded: file_helper
INFO - 2021-06-12 06:13:30 --> Helper loaded: form_helper
INFO - 2021-06-12 06:13:30 --> Helper loaded: my_helper
INFO - 2021-06-12 06:13:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:13:30 --> Controller Class Initialized
DEBUG - 2021-06-12 06:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:13:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:13:30 --> Final output sent to browser
DEBUG - 2021-06-12 06:13:30 --> Total execution time: 0.0572
INFO - 2021-06-12 06:13:30 --> Config Class Initialized
INFO - 2021-06-12 06:13:30 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:13:30 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:13:30 --> Utf8 Class Initialized
INFO - 2021-06-12 06:13:30 --> URI Class Initialized
INFO - 2021-06-12 06:13:30 --> Router Class Initialized
INFO - 2021-06-12 06:13:30 --> Output Class Initialized
INFO - 2021-06-12 06:13:30 --> Security Class Initialized
DEBUG - 2021-06-12 06:13:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:13:30 --> Input Class Initialized
INFO - 2021-06-12 06:13:30 --> Language Class Initialized
INFO - 2021-06-12 06:13:30 --> Language Class Initialized
INFO - 2021-06-12 06:13:30 --> Config Class Initialized
INFO - 2021-06-12 06:13:30 --> Loader Class Initialized
INFO - 2021-06-12 06:13:30 --> Helper loaded: url_helper
INFO - 2021-06-12 06:13:30 --> Helper loaded: file_helper
INFO - 2021-06-12 06:13:30 --> Helper loaded: form_helper
INFO - 2021-06-12 06:13:30 --> Helper loaded: my_helper
INFO - 2021-06-12 06:13:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:13:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:13:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:13:30 --> Controller Class Initialized
INFO - 2021-06-12 06:13:31 --> Config Class Initialized
INFO - 2021-06-12 06:13:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:13:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:13:31 --> Utf8 Class Initialized
INFO - 2021-06-12 06:13:31 --> URI Class Initialized
INFO - 2021-06-12 06:13:31 --> Router Class Initialized
INFO - 2021-06-12 06:13:31 --> Output Class Initialized
INFO - 2021-06-12 06:13:31 --> Security Class Initialized
DEBUG - 2021-06-12 06:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:13:31 --> Input Class Initialized
INFO - 2021-06-12 06:13:31 --> Language Class Initialized
INFO - 2021-06-12 06:13:31 --> Language Class Initialized
INFO - 2021-06-12 06:13:31 --> Config Class Initialized
INFO - 2021-06-12 06:13:31 --> Loader Class Initialized
INFO - 2021-06-12 06:13:31 --> Helper loaded: url_helper
INFO - 2021-06-12 06:13:31 --> Helper loaded: file_helper
INFO - 2021-06-12 06:13:31 --> Helper loaded: form_helper
INFO - 2021-06-12 06:13:31 --> Helper loaded: my_helper
INFO - 2021-06-12 06:13:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:13:31 --> Controller Class Initialized
DEBUG - 2021-06-12 06:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:13:31 --> Final output sent to browser
DEBUG - 2021-06-12 06:13:31 --> Total execution time: 0.0483
INFO - 2021-06-12 06:13:34 --> Config Class Initialized
INFO - 2021-06-12 06:13:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:13:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:13:34 --> Utf8 Class Initialized
INFO - 2021-06-12 06:13:34 --> URI Class Initialized
INFO - 2021-06-12 06:13:34 --> Router Class Initialized
INFO - 2021-06-12 06:13:34 --> Output Class Initialized
INFO - 2021-06-12 06:13:34 --> Security Class Initialized
DEBUG - 2021-06-12 06:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:13:34 --> Input Class Initialized
INFO - 2021-06-12 06:13:34 --> Language Class Initialized
INFO - 2021-06-12 06:13:34 --> Language Class Initialized
INFO - 2021-06-12 06:13:34 --> Config Class Initialized
INFO - 2021-06-12 06:13:34 --> Loader Class Initialized
INFO - 2021-06-12 06:13:34 --> Helper loaded: url_helper
INFO - 2021-06-12 06:13:34 --> Helper loaded: file_helper
INFO - 2021-06-12 06:13:34 --> Helper loaded: form_helper
INFO - 2021-06-12 06:13:34 --> Helper loaded: my_helper
INFO - 2021-06-12 06:13:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:13:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:13:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:13:34 --> Controller Class Initialized
INFO - 2021-06-12 06:13:34 --> Final output sent to browser
DEBUG - 2021-06-12 06:13:34 --> Total execution time: 0.0516
INFO - 2021-06-12 06:13:37 --> Config Class Initialized
INFO - 2021-06-12 06:13:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:13:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:13:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:13:37 --> URI Class Initialized
INFO - 2021-06-12 06:13:37 --> Router Class Initialized
INFO - 2021-06-12 06:13:37 --> Output Class Initialized
INFO - 2021-06-12 06:13:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:13:37 --> Input Class Initialized
INFO - 2021-06-12 06:13:37 --> Language Class Initialized
INFO - 2021-06-12 06:13:37 --> Language Class Initialized
INFO - 2021-06-12 06:13:37 --> Config Class Initialized
INFO - 2021-06-12 06:13:37 --> Loader Class Initialized
INFO - 2021-06-12 06:13:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:13:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:13:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:13:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:13:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:13:37 --> Controller Class Initialized
INFO - 2021-06-12 06:14:08 --> Config Class Initialized
INFO - 2021-06-12 06:14:08 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:14:08 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:14:08 --> Utf8 Class Initialized
INFO - 2021-06-12 06:14:08 --> URI Class Initialized
INFO - 2021-06-12 06:14:08 --> Router Class Initialized
INFO - 2021-06-12 06:14:08 --> Output Class Initialized
INFO - 2021-06-12 06:14:08 --> Security Class Initialized
DEBUG - 2021-06-12 06:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:14:08 --> Input Class Initialized
INFO - 2021-06-12 06:14:08 --> Language Class Initialized
INFO - 2021-06-12 06:14:08 --> Language Class Initialized
INFO - 2021-06-12 06:14:08 --> Config Class Initialized
INFO - 2021-06-12 06:14:08 --> Loader Class Initialized
INFO - 2021-06-12 06:14:08 --> Helper loaded: url_helper
INFO - 2021-06-12 06:14:08 --> Helper loaded: file_helper
INFO - 2021-06-12 06:14:08 --> Helper loaded: form_helper
INFO - 2021-06-12 06:14:08 --> Helper loaded: my_helper
INFO - 2021-06-12 06:14:08 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:14:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:14:08 --> Controller Class Initialized
INFO - 2021-06-12 06:15:53 --> Config Class Initialized
INFO - 2021-06-12 06:15:53 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:15:53 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:15:53 --> Utf8 Class Initialized
INFO - 2021-06-12 06:15:53 --> URI Class Initialized
INFO - 2021-06-12 06:15:53 --> Router Class Initialized
INFO - 2021-06-12 06:15:53 --> Output Class Initialized
INFO - 2021-06-12 06:15:53 --> Security Class Initialized
DEBUG - 2021-06-12 06:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:15:53 --> Input Class Initialized
INFO - 2021-06-12 06:15:53 --> Language Class Initialized
INFO - 2021-06-12 06:15:53 --> Language Class Initialized
INFO - 2021-06-12 06:15:53 --> Config Class Initialized
INFO - 2021-06-12 06:15:53 --> Loader Class Initialized
INFO - 2021-06-12 06:15:53 --> Helper loaded: url_helper
INFO - 2021-06-12 06:15:53 --> Helper loaded: file_helper
INFO - 2021-06-12 06:15:53 --> Helper loaded: form_helper
INFO - 2021-06-12 06:15:53 --> Helper loaded: my_helper
INFO - 2021-06-12 06:15:53 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:15:53 --> Controller Class Initialized
DEBUG - 2021-06-12 06:15:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:15:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:15:53 --> Final output sent to browser
DEBUG - 2021-06-12 06:15:53 --> Total execution time: 0.3393
INFO - 2021-06-12 06:15:54 --> Config Class Initialized
INFO - 2021-06-12 06:15:54 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:15:54 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:15:54 --> Utf8 Class Initialized
INFO - 2021-06-12 06:15:54 --> URI Class Initialized
INFO - 2021-06-12 06:15:54 --> Router Class Initialized
INFO - 2021-06-12 06:15:54 --> Output Class Initialized
INFO - 2021-06-12 06:15:54 --> Security Class Initialized
DEBUG - 2021-06-12 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:15:54 --> Input Class Initialized
INFO - 2021-06-12 06:15:54 --> Language Class Initialized
INFO - 2021-06-12 06:15:54 --> Language Class Initialized
INFO - 2021-06-12 06:15:54 --> Config Class Initialized
INFO - 2021-06-12 06:15:54 --> Loader Class Initialized
INFO - 2021-06-12 06:15:54 --> Helper loaded: url_helper
INFO - 2021-06-12 06:15:54 --> Helper loaded: file_helper
INFO - 2021-06-12 06:15:54 --> Helper loaded: form_helper
INFO - 2021-06-12 06:15:54 --> Helper loaded: my_helper
INFO - 2021-06-12 06:15:54 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:15:54 --> Controller Class Initialized
INFO - 2021-06-12 06:15:55 --> Config Class Initialized
INFO - 2021-06-12 06:15:55 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:15:55 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:15:55 --> Utf8 Class Initialized
INFO - 2021-06-12 06:15:55 --> URI Class Initialized
INFO - 2021-06-12 06:15:55 --> Router Class Initialized
INFO - 2021-06-12 06:15:55 --> Output Class Initialized
INFO - 2021-06-12 06:15:55 --> Security Class Initialized
DEBUG - 2021-06-12 06:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:15:55 --> Input Class Initialized
INFO - 2021-06-12 06:15:55 --> Language Class Initialized
INFO - 2021-06-12 06:15:55 --> Language Class Initialized
INFO - 2021-06-12 06:15:55 --> Config Class Initialized
INFO - 2021-06-12 06:15:55 --> Loader Class Initialized
INFO - 2021-06-12 06:15:55 --> Helper loaded: url_helper
INFO - 2021-06-12 06:15:55 --> Helper loaded: file_helper
INFO - 2021-06-12 06:15:55 --> Helper loaded: form_helper
INFO - 2021-06-12 06:15:55 --> Helper loaded: my_helper
INFO - 2021-06-12 06:15:55 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:15:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:15:55 --> Controller Class Initialized
DEBUG - 2021-06-12 06:15:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:15:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:15:55 --> Final output sent to browser
DEBUG - 2021-06-12 06:15:55 --> Total execution time: 0.6319
INFO - 2021-06-12 06:16:23 --> Config Class Initialized
INFO - 2021-06-12 06:16:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:23 --> URI Class Initialized
INFO - 2021-06-12 06:16:23 --> Router Class Initialized
INFO - 2021-06-12 06:16:23 --> Output Class Initialized
INFO - 2021-06-12 06:16:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:23 --> Input Class Initialized
INFO - 2021-06-12 06:16:23 --> Language Class Initialized
INFO - 2021-06-12 06:16:23 --> Language Class Initialized
INFO - 2021-06-12 06:16:23 --> Config Class Initialized
INFO - 2021-06-12 06:16:23 --> Loader Class Initialized
INFO - 2021-06-12 06:16:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:23 --> Controller Class Initialized
INFO - 2021-06-12 06:16:25 --> Config Class Initialized
INFO - 2021-06-12 06:16:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:25 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:25 --> URI Class Initialized
INFO - 2021-06-12 06:16:25 --> Router Class Initialized
INFO - 2021-06-12 06:16:25 --> Output Class Initialized
INFO - 2021-06-12 06:16:25 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:25 --> Input Class Initialized
INFO - 2021-06-12 06:16:25 --> Language Class Initialized
INFO - 2021-06-12 06:16:25 --> Language Class Initialized
INFO - 2021-06-12 06:16:25 --> Config Class Initialized
INFO - 2021-06-12 06:16:25 --> Loader Class Initialized
INFO - 2021-06-12 06:16:25 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:25 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:25 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:25 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:25 --> Controller Class Initialized
DEBUG - 2021-06-12 06:16:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:16:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:16:25 --> Final output sent to browser
DEBUG - 2021-06-12 06:16:25 --> Total execution time: 0.0666
INFO - 2021-06-12 06:16:26 --> Config Class Initialized
INFO - 2021-06-12 06:16:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:26 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:26 --> URI Class Initialized
INFO - 2021-06-12 06:16:26 --> Router Class Initialized
INFO - 2021-06-12 06:16:26 --> Output Class Initialized
INFO - 2021-06-12 06:16:26 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:26 --> Input Class Initialized
INFO - 2021-06-12 06:16:26 --> Language Class Initialized
INFO - 2021-06-12 06:16:26 --> Language Class Initialized
INFO - 2021-06-12 06:16:26 --> Config Class Initialized
INFO - 2021-06-12 06:16:26 --> Loader Class Initialized
INFO - 2021-06-12 06:16:26 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:26 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:26 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:26 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:26 --> Controller Class Initialized
INFO - 2021-06-12 06:16:46 --> Config Class Initialized
INFO - 2021-06-12 06:16:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:46 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:46 --> URI Class Initialized
INFO - 2021-06-12 06:16:46 --> Router Class Initialized
INFO - 2021-06-12 06:16:46 --> Output Class Initialized
INFO - 2021-06-12 06:16:46 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:46 --> Input Class Initialized
INFO - 2021-06-12 06:16:46 --> Language Class Initialized
INFO - 2021-06-12 06:16:47 --> Language Class Initialized
INFO - 2021-06-12 06:16:47 --> Config Class Initialized
INFO - 2021-06-12 06:16:47 --> Loader Class Initialized
INFO - 2021-06-12 06:16:47 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:47 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:47 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:47 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:47 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:47 --> Controller Class Initialized
INFO - 2021-06-12 06:16:47 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:16:47 --> Config Class Initialized
INFO - 2021-06-12 06:16:47 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:47 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:47 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:47 --> URI Class Initialized
INFO - 2021-06-12 06:16:47 --> Router Class Initialized
INFO - 2021-06-12 06:16:47 --> Output Class Initialized
INFO - 2021-06-12 06:16:47 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:47 --> Input Class Initialized
INFO - 2021-06-12 06:16:47 --> Language Class Initialized
INFO - 2021-06-12 06:16:47 --> Language Class Initialized
INFO - 2021-06-12 06:16:47 --> Config Class Initialized
INFO - 2021-06-12 06:16:47 --> Loader Class Initialized
INFO - 2021-06-12 06:16:47 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:47 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:47 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:47 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:47 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:47 --> Controller Class Initialized
DEBUG - 2021-06-12 06:16:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:16:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:16:47 --> Final output sent to browser
DEBUG - 2021-06-12 06:16:47 --> Total execution time: 0.0415
INFO - 2021-06-12 06:16:55 --> Config Class Initialized
INFO - 2021-06-12 06:16:55 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:55 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:55 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:55 --> URI Class Initialized
INFO - 2021-06-12 06:16:55 --> Router Class Initialized
INFO - 2021-06-12 06:16:55 --> Output Class Initialized
INFO - 2021-06-12 06:16:55 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:55 --> Input Class Initialized
INFO - 2021-06-12 06:16:55 --> Language Class Initialized
INFO - 2021-06-12 06:16:55 --> Language Class Initialized
INFO - 2021-06-12 06:16:55 --> Config Class Initialized
INFO - 2021-06-12 06:16:55 --> Loader Class Initialized
INFO - 2021-06-12 06:16:55 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:55 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:55 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:55 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:55 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:55 --> Controller Class Initialized
INFO - 2021-06-12 06:16:55 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:16:55 --> Final output sent to browser
DEBUG - 2021-06-12 06:16:55 --> Total execution time: 0.0439
INFO - 2021-06-12 06:16:56 --> Config Class Initialized
INFO - 2021-06-12 06:16:56 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:56 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:56 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:56 --> URI Class Initialized
INFO - 2021-06-12 06:16:56 --> Router Class Initialized
INFO - 2021-06-12 06:16:56 --> Output Class Initialized
INFO - 2021-06-12 06:16:56 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:56 --> Input Class Initialized
INFO - 2021-06-12 06:16:56 --> Language Class Initialized
INFO - 2021-06-12 06:16:56 --> Language Class Initialized
INFO - 2021-06-12 06:16:56 --> Config Class Initialized
INFO - 2021-06-12 06:16:56 --> Loader Class Initialized
INFO - 2021-06-12 06:16:56 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:56 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:56 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:56 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:56 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:56 --> Controller Class Initialized
DEBUG - 2021-06-12 06:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:16:56 --> Final output sent to browser
DEBUG - 2021-06-12 06:16:56 --> Total execution time: 0.0864
INFO - 2021-06-12 06:16:58 --> Config Class Initialized
INFO - 2021-06-12 06:16:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:16:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:16:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:16:58 --> URI Class Initialized
INFO - 2021-06-12 06:16:58 --> Router Class Initialized
INFO - 2021-06-12 06:16:58 --> Output Class Initialized
INFO - 2021-06-12 06:16:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:16:58 --> Input Class Initialized
INFO - 2021-06-12 06:16:58 --> Language Class Initialized
INFO - 2021-06-12 06:16:58 --> Language Class Initialized
INFO - 2021-06-12 06:16:58 --> Config Class Initialized
INFO - 2021-06-12 06:16:58 --> Loader Class Initialized
INFO - 2021-06-12 06:16:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:16:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:16:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:16:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:16:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:16:58 --> Controller Class Initialized
DEBUG - 2021-06-12 06:16:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:16:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:16:58 --> Final output sent to browser
DEBUG - 2021-06-12 06:16:58 --> Total execution time: 0.0428
INFO - 2021-06-12 06:17:11 --> Config Class Initialized
INFO - 2021-06-12 06:17:11 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:17:11 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:17:11 --> Utf8 Class Initialized
INFO - 2021-06-12 06:17:11 --> URI Class Initialized
INFO - 2021-06-12 06:17:11 --> Router Class Initialized
INFO - 2021-06-12 06:17:11 --> Output Class Initialized
INFO - 2021-06-12 06:17:11 --> Security Class Initialized
DEBUG - 2021-06-12 06:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:17:11 --> Input Class Initialized
INFO - 2021-06-12 06:17:11 --> Language Class Initialized
INFO - 2021-06-12 06:17:11 --> Language Class Initialized
INFO - 2021-06-12 06:17:11 --> Config Class Initialized
INFO - 2021-06-12 06:17:11 --> Loader Class Initialized
INFO - 2021-06-12 06:17:11 --> Helper loaded: url_helper
INFO - 2021-06-12 06:17:11 --> Helper loaded: file_helper
INFO - 2021-06-12 06:17:11 --> Helper loaded: form_helper
INFO - 2021-06-12 06:17:11 --> Helper loaded: my_helper
INFO - 2021-06-12 06:17:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:17:12 --> Controller Class Initialized
DEBUG - 2021-06-12 06:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:17:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:17:12 --> Final output sent to browser
DEBUG - 2021-06-12 06:17:12 --> Total execution time: 1.0084
INFO - 2021-06-12 06:17:12 --> Config Class Initialized
INFO - 2021-06-12 06:17:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:17:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:17:12 --> Utf8 Class Initialized
INFO - 2021-06-12 06:17:12 --> URI Class Initialized
INFO - 2021-06-12 06:17:12 --> Router Class Initialized
INFO - 2021-06-12 06:17:12 --> Output Class Initialized
INFO - 2021-06-12 06:17:12 --> Security Class Initialized
DEBUG - 2021-06-12 06:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:17:12 --> Input Class Initialized
INFO - 2021-06-12 06:17:12 --> Language Class Initialized
INFO - 2021-06-12 06:17:12 --> Language Class Initialized
INFO - 2021-06-12 06:17:12 --> Config Class Initialized
INFO - 2021-06-12 06:17:12 --> Loader Class Initialized
INFO - 2021-06-12 06:17:12 --> Helper loaded: url_helper
INFO - 2021-06-12 06:17:12 --> Helper loaded: file_helper
INFO - 2021-06-12 06:17:12 --> Helper loaded: form_helper
INFO - 2021-06-12 06:17:12 --> Helper loaded: my_helper
INFO - 2021-06-12 06:17:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:17:12 --> Controller Class Initialized
INFO - 2021-06-12 06:17:21 --> Config Class Initialized
INFO - 2021-06-12 06:17:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:17:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:17:21 --> Utf8 Class Initialized
INFO - 2021-06-12 06:17:21 --> URI Class Initialized
INFO - 2021-06-12 06:17:21 --> Router Class Initialized
INFO - 2021-06-12 06:17:21 --> Output Class Initialized
INFO - 2021-06-12 06:17:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:17:21 --> Input Class Initialized
INFO - 2021-06-12 06:17:21 --> Language Class Initialized
INFO - 2021-06-12 06:17:21 --> Language Class Initialized
INFO - 2021-06-12 06:17:21 --> Config Class Initialized
INFO - 2021-06-12 06:17:21 --> Loader Class Initialized
INFO - 2021-06-12 06:17:21 --> Helper loaded: url_helper
INFO - 2021-06-12 06:17:21 --> Helper loaded: file_helper
INFO - 2021-06-12 06:17:21 --> Helper loaded: form_helper
INFO - 2021-06-12 06:17:21 --> Helper loaded: my_helper
INFO - 2021-06-12 06:17:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:17:21 --> Controller Class Initialized
DEBUG - 2021-06-12 06:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:17:21 --> Final output sent to browser
DEBUG - 2021-06-12 06:17:21 --> Total execution time: 0.0459
INFO - 2021-06-12 06:17:27 --> Config Class Initialized
INFO - 2021-06-12 06:17:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:17:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:17:27 --> Utf8 Class Initialized
INFO - 2021-06-12 06:17:27 --> URI Class Initialized
INFO - 2021-06-12 06:17:27 --> Router Class Initialized
INFO - 2021-06-12 06:17:27 --> Output Class Initialized
INFO - 2021-06-12 06:17:27 --> Security Class Initialized
DEBUG - 2021-06-12 06:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:17:27 --> Input Class Initialized
INFO - 2021-06-12 06:17:27 --> Language Class Initialized
INFO - 2021-06-12 06:17:27 --> Language Class Initialized
INFO - 2021-06-12 06:17:27 --> Config Class Initialized
INFO - 2021-06-12 06:17:27 --> Loader Class Initialized
INFO - 2021-06-12 06:17:27 --> Helper loaded: url_helper
INFO - 2021-06-12 06:17:27 --> Helper loaded: file_helper
INFO - 2021-06-12 06:17:27 --> Helper loaded: form_helper
INFO - 2021-06-12 06:17:27 --> Helper loaded: my_helper
INFO - 2021-06-12 06:17:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:17:27 --> Controller Class Initialized
DEBUG - 2021-06-12 06:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:17:27 --> Final output sent to browser
DEBUG - 2021-06-12 06:17:27 --> Total execution time: 0.0459
INFO - 2021-06-12 06:17:27 --> Config Class Initialized
INFO - 2021-06-12 06:17:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:17:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:17:27 --> Utf8 Class Initialized
INFO - 2021-06-12 06:17:27 --> URI Class Initialized
INFO - 2021-06-12 06:17:27 --> Router Class Initialized
INFO - 2021-06-12 06:17:27 --> Output Class Initialized
INFO - 2021-06-12 06:17:27 --> Security Class Initialized
DEBUG - 2021-06-12 06:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:17:27 --> Input Class Initialized
INFO - 2021-06-12 06:17:27 --> Language Class Initialized
INFO - 2021-06-12 06:17:27 --> Language Class Initialized
INFO - 2021-06-12 06:17:27 --> Config Class Initialized
INFO - 2021-06-12 06:17:27 --> Loader Class Initialized
INFO - 2021-06-12 06:17:27 --> Helper loaded: url_helper
INFO - 2021-06-12 06:17:27 --> Helper loaded: file_helper
INFO - 2021-06-12 06:17:27 --> Helper loaded: form_helper
INFO - 2021-06-12 06:17:27 --> Helper loaded: my_helper
INFO - 2021-06-12 06:17:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:17:27 --> Controller Class Initialized
INFO - 2021-06-12 06:17:28 --> Config Class Initialized
INFO - 2021-06-12 06:17:28 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:17:28 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:17:28 --> Utf8 Class Initialized
INFO - 2021-06-12 06:17:28 --> URI Class Initialized
INFO - 2021-06-12 06:17:28 --> Router Class Initialized
INFO - 2021-06-12 06:17:28 --> Output Class Initialized
INFO - 2021-06-12 06:17:28 --> Security Class Initialized
DEBUG - 2021-06-12 06:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:17:28 --> Input Class Initialized
INFO - 2021-06-12 06:17:28 --> Language Class Initialized
INFO - 2021-06-12 06:17:28 --> Language Class Initialized
INFO - 2021-06-12 06:17:28 --> Config Class Initialized
INFO - 2021-06-12 06:17:28 --> Loader Class Initialized
INFO - 2021-06-12 06:17:28 --> Helper loaded: url_helper
INFO - 2021-06-12 06:17:28 --> Helper loaded: file_helper
INFO - 2021-06-12 06:17:28 --> Helper loaded: form_helper
INFO - 2021-06-12 06:17:28 --> Helper loaded: my_helper
INFO - 2021-06-12 06:17:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:17:28 --> Controller Class Initialized
DEBUG - 2021-06-12 06:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:17:28 --> Final output sent to browser
DEBUG - 2021-06-12 06:17:28 --> Total execution time: 0.0453
INFO - 2021-06-12 06:17:33 --> Config Class Initialized
INFO - 2021-06-12 06:17:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:17:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:17:33 --> Utf8 Class Initialized
INFO - 2021-06-12 06:17:33 --> URI Class Initialized
INFO - 2021-06-12 06:17:33 --> Router Class Initialized
INFO - 2021-06-12 06:17:33 --> Output Class Initialized
INFO - 2021-06-12 06:17:33 --> Security Class Initialized
DEBUG - 2021-06-12 06:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:17:33 --> Input Class Initialized
INFO - 2021-06-12 06:17:33 --> Language Class Initialized
INFO - 2021-06-12 06:17:33 --> Language Class Initialized
INFO - 2021-06-12 06:17:33 --> Config Class Initialized
INFO - 2021-06-12 06:17:33 --> Loader Class Initialized
INFO - 2021-06-12 06:17:33 --> Helper loaded: url_helper
INFO - 2021-06-12 06:17:33 --> Helper loaded: file_helper
INFO - 2021-06-12 06:17:33 --> Helper loaded: form_helper
INFO - 2021-06-12 06:17:33 --> Helper loaded: my_helper
INFO - 2021-06-12 06:17:33 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:17:33 --> Controller Class Initialized
INFO - 2021-06-12 06:18:18 --> Config Class Initialized
INFO - 2021-06-12 06:18:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:18 --> URI Class Initialized
INFO - 2021-06-12 06:18:18 --> Router Class Initialized
INFO - 2021-06-12 06:18:18 --> Output Class Initialized
INFO - 2021-06-12 06:18:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:18 --> Input Class Initialized
INFO - 2021-06-12 06:18:18 --> Language Class Initialized
INFO - 2021-06-12 06:18:18 --> Language Class Initialized
INFO - 2021-06-12 06:18:18 --> Config Class Initialized
INFO - 2021-06-12 06:18:18 --> Loader Class Initialized
INFO - 2021-06-12 06:18:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:18 --> Controller Class Initialized
INFO - 2021-06-12 06:18:37 --> Config Class Initialized
INFO - 2021-06-12 06:18:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:37 --> URI Class Initialized
INFO - 2021-06-12 06:18:37 --> Router Class Initialized
INFO - 2021-06-12 06:18:37 --> Output Class Initialized
INFO - 2021-06-12 06:18:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:37 --> Input Class Initialized
INFO - 2021-06-12 06:18:37 --> Language Class Initialized
INFO - 2021-06-12 06:18:37 --> Language Class Initialized
INFO - 2021-06-12 06:18:37 --> Config Class Initialized
INFO - 2021-06-12 06:18:37 --> Loader Class Initialized
INFO - 2021-06-12 06:18:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:37 --> Controller Class Initialized
DEBUG - 2021-06-12 06:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:18:37 --> Final output sent to browser
DEBUG - 2021-06-12 06:18:37 --> Total execution time: 0.0532
INFO - 2021-06-12 06:18:37 --> Config Class Initialized
INFO - 2021-06-12 06:18:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:38 --> URI Class Initialized
INFO - 2021-06-12 06:18:38 --> Router Class Initialized
INFO - 2021-06-12 06:18:38 --> Output Class Initialized
INFO - 2021-06-12 06:18:38 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:38 --> Input Class Initialized
INFO - 2021-06-12 06:18:38 --> Language Class Initialized
INFO - 2021-06-12 06:18:38 --> Language Class Initialized
INFO - 2021-06-12 06:18:38 --> Config Class Initialized
INFO - 2021-06-12 06:18:38 --> Loader Class Initialized
INFO - 2021-06-12 06:18:38 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:38 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:38 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:38 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:38 --> Controller Class Initialized
INFO - 2021-06-12 06:18:39 --> Config Class Initialized
INFO - 2021-06-12 06:18:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:39 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:39 --> URI Class Initialized
INFO - 2021-06-12 06:18:39 --> Router Class Initialized
INFO - 2021-06-12 06:18:39 --> Output Class Initialized
INFO - 2021-06-12 06:18:39 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:39 --> Input Class Initialized
INFO - 2021-06-12 06:18:39 --> Language Class Initialized
INFO - 2021-06-12 06:18:39 --> Language Class Initialized
INFO - 2021-06-12 06:18:39 --> Config Class Initialized
INFO - 2021-06-12 06:18:39 --> Loader Class Initialized
INFO - 2021-06-12 06:18:39 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:39 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:39 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:39 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:39 --> Controller Class Initialized
DEBUG - 2021-06-12 06:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:18:39 --> Final output sent to browser
DEBUG - 2021-06-12 06:18:39 --> Total execution time: 0.0416
INFO - 2021-06-12 06:18:41 --> Config Class Initialized
INFO - 2021-06-12 06:18:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:41 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:41 --> URI Class Initialized
INFO - 2021-06-12 06:18:41 --> Router Class Initialized
INFO - 2021-06-12 06:18:41 --> Output Class Initialized
INFO - 2021-06-12 06:18:41 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:41 --> Input Class Initialized
INFO - 2021-06-12 06:18:41 --> Language Class Initialized
INFO - 2021-06-12 06:18:42 --> Language Class Initialized
INFO - 2021-06-12 06:18:42 --> Config Class Initialized
INFO - 2021-06-12 06:18:42 --> Loader Class Initialized
INFO - 2021-06-12 06:18:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:42 --> Controller Class Initialized
DEBUG - 2021-06-12 06:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:18:42 --> Final output sent to browser
DEBUG - 2021-06-12 06:18:42 --> Total execution time: 0.0452
INFO - 2021-06-12 06:18:42 --> Config Class Initialized
INFO - 2021-06-12 06:18:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:42 --> URI Class Initialized
INFO - 2021-06-12 06:18:42 --> Router Class Initialized
INFO - 2021-06-12 06:18:42 --> Output Class Initialized
INFO - 2021-06-12 06:18:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:42 --> Input Class Initialized
INFO - 2021-06-12 06:18:42 --> Language Class Initialized
INFO - 2021-06-12 06:18:42 --> Language Class Initialized
INFO - 2021-06-12 06:18:42 --> Config Class Initialized
INFO - 2021-06-12 06:18:42 --> Loader Class Initialized
INFO - 2021-06-12 06:18:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:42 --> Controller Class Initialized
INFO - 2021-06-12 06:18:43 --> Config Class Initialized
INFO - 2021-06-12 06:18:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:43 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:43 --> URI Class Initialized
INFO - 2021-06-12 06:18:43 --> Router Class Initialized
INFO - 2021-06-12 06:18:43 --> Output Class Initialized
INFO - 2021-06-12 06:18:43 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:43 --> Input Class Initialized
INFO - 2021-06-12 06:18:43 --> Language Class Initialized
INFO - 2021-06-12 06:18:43 --> Language Class Initialized
INFO - 2021-06-12 06:18:43 --> Config Class Initialized
INFO - 2021-06-12 06:18:43 --> Loader Class Initialized
INFO - 2021-06-12 06:18:43 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:43 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:43 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:43 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:43 --> Controller Class Initialized
DEBUG - 2021-06-12 06:18:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:18:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:18:43 --> Final output sent to browser
DEBUG - 2021-06-12 06:18:43 --> Total execution time: 0.0566
INFO - 2021-06-12 06:18:55 --> Config Class Initialized
INFO - 2021-06-12 06:18:55 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:18:55 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:18:55 --> Utf8 Class Initialized
INFO - 2021-06-12 06:18:55 --> URI Class Initialized
INFO - 2021-06-12 06:18:55 --> Router Class Initialized
INFO - 2021-06-12 06:18:55 --> Output Class Initialized
INFO - 2021-06-12 06:18:55 --> Security Class Initialized
DEBUG - 2021-06-12 06:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:18:55 --> Input Class Initialized
INFO - 2021-06-12 06:18:55 --> Language Class Initialized
INFO - 2021-06-12 06:18:55 --> Language Class Initialized
INFO - 2021-06-12 06:18:55 --> Config Class Initialized
INFO - 2021-06-12 06:18:55 --> Loader Class Initialized
INFO - 2021-06-12 06:18:55 --> Helper loaded: url_helper
INFO - 2021-06-12 06:18:55 --> Helper loaded: file_helper
INFO - 2021-06-12 06:18:55 --> Helper loaded: form_helper
INFO - 2021-06-12 06:18:55 --> Helper loaded: my_helper
INFO - 2021-06-12 06:18:55 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:18:55 --> Controller Class Initialized
INFO - 2021-06-12 06:19:27 --> Config Class Initialized
INFO - 2021-06-12 06:19:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:19:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:19:27 --> Utf8 Class Initialized
INFO - 2021-06-12 06:19:27 --> URI Class Initialized
INFO - 2021-06-12 06:19:27 --> Router Class Initialized
INFO - 2021-06-12 06:19:27 --> Output Class Initialized
INFO - 2021-06-12 06:19:27 --> Security Class Initialized
DEBUG - 2021-06-12 06:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:19:27 --> Input Class Initialized
INFO - 2021-06-12 06:19:27 --> Language Class Initialized
INFO - 2021-06-12 06:19:27 --> Language Class Initialized
INFO - 2021-06-12 06:19:27 --> Config Class Initialized
INFO - 2021-06-12 06:19:27 --> Loader Class Initialized
INFO - 2021-06-12 06:19:27 --> Helper loaded: url_helper
INFO - 2021-06-12 06:19:27 --> Helper loaded: file_helper
INFO - 2021-06-12 06:19:27 --> Helper loaded: form_helper
INFO - 2021-06-12 06:19:27 --> Helper loaded: my_helper
INFO - 2021-06-12 06:19:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:19:27 --> Controller Class Initialized
INFO - 2021-06-12 06:19:58 --> Config Class Initialized
INFO - 2021-06-12 06:19:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:19:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:19:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:19:58 --> URI Class Initialized
INFO - 2021-06-12 06:19:58 --> Router Class Initialized
INFO - 2021-06-12 06:19:58 --> Output Class Initialized
INFO - 2021-06-12 06:19:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:19:58 --> Input Class Initialized
INFO - 2021-06-12 06:19:58 --> Language Class Initialized
INFO - 2021-06-12 06:19:58 --> Language Class Initialized
INFO - 2021-06-12 06:19:58 --> Config Class Initialized
INFO - 2021-06-12 06:19:58 --> Loader Class Initialized
INFO - 2021-06-12 06:19:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:19:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:19:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:19:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:19:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:19:58 --> Controller Class Initialized
DEBUG - 2021-06-12 06:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:19:58 --> Final output sent to browser
DEBUG - 2021-06-12 06:19:58 --> Total execution time: 0.0451
INFO - 2021-06-12 06:19:58 --> Config Class Initialized
INFO - 2021-06-12 06:19:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:19:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:19:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:19:58 --> URI Class Initialized
INFO - 2021-06-12 06:19:58 --> Router Class Initialized
INFO - 2021-06-12 06:19:58 --> Output Class Initialized
INFO - 2021-06-12 06:19:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:19:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:19:58 --> Input Class Initialized
INFO - 2021-06-12 06:19:58 --> Language Class Initialized
INFO - 2021-06-12 06:19:58 --> Language Class Initialized
INFO - 2021-06-12 06:19:58 --> Config Class Initialized
INFO - 2021-06-12 06:19:58 --> Loader Class Initialized
INFO - 2021-06-12 06:19:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:19:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:19:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:19:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:19:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:19:58 --> Controller Class Initialized
INFO - 2021-06-12 06:20:00 --> Config Class Initialized
INFO - 2021-06-12 06:20:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:20:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:20:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:20:00 --> URI Class Initialized
INFO - 2021-06-12 06:20:00 --> Router Class Initialized
INFO - 2021-06-12 06:20:00 --> Output Class Initialized
INFO - 2021-06-12 06:20:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:20:00 --> Input Class Initialized
INFO - 2021-06-12 06:20:00 --> Language Class Initialized
INFO - 2021-06-12 06:20:00 --> Language Class Initialized
INFO - 2021-06-12 06:20:00 --> Config Class Initialized
INFO - 2021-06-12 06:20:00 --> Loader Class Initialized
INFO - 2021-06-12 06:20:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:20:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:20:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:20:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:20:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:20:00 --> Controller Class Initialized
DEBUG - 2021-06-12 06:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:20:00 --> Final output sent to browser
DEBUG - 2021-06-12 06:20:00 --> Total execution time: 0.0459
INFO - 2021-06-12 06:20:09 --> Config Class Initialized
INFO - 2021-06-12 06:20:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:20:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:20:09 --> Utf8 Class Initialized
INFO - 2021-06-12 06:20:09 --> URI Class Initialized
INFO - 2021-06-12 06:20:09 --> Router Class Initialized
INFO - 2021-06-12 06:20:09 --> Output Class Initialized
INFO - 2021-06-12 06:20:09 --> Security Class Initialized
DEBUG - 2021-06-12 06:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:20:09 --> Input Class Initialized
INFO - 2021-06-12 06:20:09 --> Language Class Initialized
INFO - 2021-06-12 06:20:09 --> Language Class Initialized
INFO - 2021-06-12 06:20:09 --> Config Class Initialized
INFO - 2021-06-12 06:20:09 --> Loader Class Initialized
INFO - 2021-06-12 06:20:09 --> Helper loaded: url_helper
INFO - 2021-06-12 06:20:09 --> Helper loaded: file_helper
INFO - 2021-06-12 06:20:09 --> Helper loaded: form_helper
INFO - 2021-06-12 06:20:09 --> Helper loaded: my_helper
INFO - 2021-06-12 06:20:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:20:09 --> Controller Class Initialized
INFO - 2021-06-12 06:20:11 --> Config Class Initialized
INFO - 2021-06-12 06:20:11 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:20:11 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:20:11 --> Utf8 Class Initialized
INFO - 2021-06-12 06:20:11 --> URI Class Initialized
INFO - 2021-06-12 06:20:11 --> Router Class Initialized
INFO - 2021-06-12 06:20:11 --> Output Class Initialized
INFO - 2021-06-12 06:20:11 --> Security Class Initialized
DEBUG - 2021-06-12 06:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:20:11 --> Input Class Initialized
INFO - 2021-06-12 06:20:11 --> Language Class Initialized
INFO - 2021-06-12 06:20:11 --> Language Class Initialized
INFO - 2021-06-12 06:20:11 --> Config Class Initialized
INFO - 2021-06-12 06:20:11 --> Loader Class Initialized
INFO - 2021-06-12 06:20:11 --> Helper loaded: url_helper
INFO - 2021-06-12 06:20:11 --> Helper loaded: file_helper
INFO - 2021-06-12 06:20:11 --> Helper loaded: form_helper
INFO - 2021-06-12 06:20:11 --> Helper loaded: my_helper
INFO - 2021-06-12 06:20:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:20:11 --> Controller Class Initialized
DEBUG - 2021-06-12 06:20:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:20:12 --> Final output sent to browser
DEBUG - 2021-06-12 06:20:12 --> Total execution time: 0.9352
INFO - 2021-06-12 06:20:49 --> Config Class Initialized
INFO - 2021-06-12 06:20:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:20:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:20:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:20:49 --> URI Class Initialized
INFO - 2021-06-12 06:20:49 --> Router Class Initialized
INFO - 2021-06-12 06:20:49 --> Output Class Initialized
INFO - 2021-06-12 06:20:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:20:49 --> Input Class Initialized
INFO - 2021-06-12 06:20:49 --> Language Class Initialized
INFO - 2021-06-12 06:20:49 --> Language Class Initialized
INFO - 2021-06-12 06:20:49 --> Config Class Initialized
INFO - 2021-06-12 06:20:49 --> Loader Class Initialized
INFO - 2021-06-12 06:20:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:20:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:20:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:20:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:20:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:20:49 --> Controller Class Initialized
INFO - 2021-06-12 06:20:49 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:20:49 --> Config Class Initialized
INFO - 2021-06-12 06:20:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:20:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:20:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:20:49 --> URI Class Initialized
INFO - 2021-06-12 06:20:49 --> Router Class Initialized
INFO - 2021-06-12 06:20:49 --> Output Class Initialized
INFO - 2021-06-12 06:20:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:20:49 --> Input Class Initialized
INFO - 2021-06-12 06:20:49 --> Language Class Initialized
INFO - 2021-06-12 06:20:49 --> Language Class Initialized
INFO - 2021-06-12 06:20:49 --> Config Class Initialized
INFO - 2021-06-12 06:20:49 --> Loader Class Initialized
INFO - 2021-06-12 06:20:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:20:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:20:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:20:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:20:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:20:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:20:49 --> Controller Class Initialized
DEBUG - 2021-06-12 06:20:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:20:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:20:49 --> Final output sent to browser
DEBUG - 2021-06-12 06:20:49 --> Total execution time: 0.0530
INFO - 2021-06-12 06:20:57 --> Config Class Initialized
INFO - 2021-06-12 06:20:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:20:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:20:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:20:57 --> URI Class Initialized
INFO - 2021-06-12 06:20:57 --> Router Class Initialized
INFO - 2021-06-12 06:20:57 --> Output Class Initialized
INFO - 2021-06-12 06:20:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:20:57 --> Input Class Initialized
INFO - 2021-06-12 06:20:57 --> Language Class Initialized
INFO - 2021-06-12 06:20:57 --> Language Class Initialized
INFO - 2021-06-12 06:20:57 --> Config Class Initialized
INFO - 2021-06-12 06:20:57 --> Loader Class Initialized
INFO - 2021-06-12 06:20:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:20:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:20:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:20:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:20:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:20:57 --> Controller Class Initialized
INFO - 2021-06-12 06:20:57 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:20:57 --> Final output sent to browser
DEBUG - 2021-06-12 06:20:57 --> Total execution time: 0.0439
INFO - 2021-06-12 06:20:57 --> Config Class Initialized
INFO - 2021-06-12 06:20:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:20:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:20:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:20:57 --> URI Class Initialized
INFO - 2021-06-12 06:20:57 --> Router Class Initialized
INFO - 2021-06-12 06:20:57 --> Output Class Initialized
INFO - 2021-06-12 06:20:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:20:57 --> Input Class Initialized
INFO - 2021-06-12 06:20:57 --> Language Class Initialized
INFO - 2021-06-12 06:20:57 --> Language Class Initialized
INFO - 2021-06-12 06:20:57 --> Config Class Initialized
INFO - 2021-06-12 06:20:57 --> Loader Class Initialized
INFO - 2021-06-12 06:20:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:20:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:20:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:20:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:20:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:20:57 --> Controller Class Initialized
DEBUG - 2021-06-12 06:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:20:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:20:57 --> Final output sent to browser
DEBUG - 2021-06-12 06:20:57 --> Total execution time: 0.0777
INFO - 2021-06-12 06:21:04 --> Config Class Initialized
INFO - 2021-06-12 06:21:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:21:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:21:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:21:04 --> URI Class Initialized
INFO - 2021-06-12 06:21:04 --> Router Class Initialized
INFO - 2021-06-12 06:21:04 --> Output Class Initialized
INFO - 2021-06-12 06:21:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:21:04 --> Input Class Initialized
INFO - 2021-06-12 06:21:04 --> Language Class Initialized
INFO - 2021-06-12 06:21:04 --> Language Class Initialized
INFO - 2021-06-12 06:21:04 --> Config Class Initialized
INFO - 2021-06-12 06:21:04 --> Loader Class Initialized
INFO - 2021-06-12 06:21:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:21:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:21:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:21:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:21:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:21:04 --> Controller Class Initialized
DEBUG - 2021-06-12 06:21:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:21:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:21:04 --> Final output sent to browser
DEBUG - 2021-06-12 06:21:04 --> Total execution time: 0.0429
INFO - 2021-06-12 06:21:15 --> Config Class Initialized
INFO - 2021-06-12 06:21:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:21:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:21:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:21:15 --> URI Class Initialized
INFO - 2021-06-12 06:21:15 --> Router Class Initialized
INFO - 2021-06-12 06:21:15 --> Output Class Initialized
INFO - 2021-06-12 06:21:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:21:15 --> Input Class Initialized
INFO - 2021-06-12 06:21:15 --> Language Class Initialized
INFO - 2021-06-12 06:21:15 --> Language Class Initialized
INFO - 2021-06-12 06:21:15 --> Config Class Initialized
INFO - 2021-06-12 06:21:15 --> Loader Class Initialized
INFO - 2021-06-12 06:21:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:21:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:21:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:21:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:21:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:21:15 --> Controller Class Initialized
DEBUG - 2021-06-12 06:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:21:15 --> Final output sent to browser
DEBUG - 2021-06-12 06:21:15 --> Total execution time: 0.0465
INFO - 2021-06-12 06:21:15 --> Config Class Initialized
INFO - 2021-06-12 06:21:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:21:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:21:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:21:15 --> URI Class Initialized
INFO - 2021-06-12 06:21:15 --> Router Class Initialized
INFO - 2021-06-12 06:21:16 --> Output Class Initialized
INFO - 2021-06-12 06:21:16 --> Security Class Initialized
DEBUG - 2021-06-12 06:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:21:16 --> Input Class Initialized
INFO - 2021-06-12 06:21:16 --> Language Class Initialized
INFO - 2021-06-12 06:21:16 --> Language Class Initialized
INFO - 2021-06-12 06:21:16 --> Config Class Initialized
INFO - 2021-06-12 06:21:16 --> Loader Class Initialized
INFO - 2021-06-12 06:21:16 --> Helper loaded: url_helper
INFO - 2021-06-12 06:21:16 --> Helper loaded: file_helper
INFO - 2021-06-12 06:21:16 --> Helper loaded: form_helper
INFO - 2021-06-12 06:21:16 --> Helper loaded: my_helper
INFO - 2021-06-12 06:21:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:21:16 --> Controller Class Initialized
INFO - 2021-06-12 06:21:17 --> Config Class Initialized
INFO - 2021-06-12 06:21:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:21:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:21:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:21:17 --> URI Class Initialized
INFO - 2021-06-12 06:21:17 --> Router Class Initialized
INFO - 2021-06-12 06:21:17 --> Output Class Initialized
INFO - 2021-06-12 06:21:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:21:17 --> Input Class Initialized
INFO - 2021-06-12 06:21:17 --> Language Class Initialized
INFO - 2021-06-12 06:21:17 --> Language Class Initialized
INFO - 2021-06-12 06:21:17 --> Config Class Initialized
INFO - 2021-06-12 06:21:17 --> Loader Class Initialized
INFO - 2021-06-12 06:21:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:21:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:21:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:21:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:21:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:21:17 --> Controller Class Initialized
DEBUG - 2021-06-12 06:21:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:21:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:21:17 --> Final output sent to browser
DEBUG - 2021-06-12 06:21:17 --> Total execution time: 0.0759
INFO - 2021-06-12 06:21:36 --> Config Class Initialized
INFO - 2021-06-12 06:21:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:21:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:21:36 --> Utf8 Class Initialized
INFO - 2021-06-12 06:21:36 --> URI Class Initialized
INFO - 2021-06-12 06:21:36 --> Router Class Initialized
INFO - 2021-06-12 06:21:36 --> Output Class Initialized
INFO - 2021-06-12 06:21:36 --> Security Class Initialized
DEBUG - 2021-06-12 06:21:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:21:36 --> Input Class Initialized
INFO - 2021-06-12 06:21:36 --> Language Class Initialized
INFO - 2021-06-12 06:21:36 --> Language Class Initialized
INFO - 2021-06-12 06:21:36 --> Config Class Initialized
INFO - 2021-06-12 06:21:36 --> Loader Class Initialized
INFO - 2021-06-12 06:21:36 --> Helper loaded: url_helper
INFO - 2021-06-12 06:21:36 --> Helper loaded: file_helper
INFO - 2021-06-12 06:21:36 --> Helper loaded: form_helper
INFO - 2021-06-12 06:21:36 --> Helper loaded: my_helper
INFO - 2021-06-12 06:21:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:21:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:21:36 --> Controller Class Initialized
INFO - 2021-06-12 06:21:36 --> Final output sent to browser
DEBUG - 2021-06-12 06:21:36 --> Total execution time: 0.0446
INFO - 2021-06-12 06:21:38 --> Config Class Initialized
INFO - 2021-06-12 06:21:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:21:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:21:38 --> Utf8 Class Initialized
INFO - 2021-06-12 06:21:38 --> URI Class Initialized
INFO - 2021-06-12 06:21:38 --> Router Class Initialized
INFO - 2021-06-12 06:21:38 --> Output Class Initialized
INFO - 2021-06-12 06:21:38 --> Security Class Initialized
DEBUG - 2021-06-12 06:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:21:38 --> Input Class Initialized
INFO - 2021-06-12 06:21:38 --> Language Class Initialized
INFO - 2021-06-12 06:21:38 --> Language Class Initialized
INFO - 2021-06-12 06:21:38 --> Config Class Initialized
INFO - 2021-06-12 06:21:38 --> Loader Class Initialized
INFO - 2021-06-12 06:21:38 --> Helper loaded: url_helper
INFO - 2021-06-12 06:21:38 --> Helper loaded: file_helper
INFO - 2021-06-12 06:21:38 --> Helper loaded: form_helper
INFO - 2021-06-12 06:21:38 --> Helper loaded: my_helper
INFO - 2021-06-12 06:21:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:21:38 --> Controller Class Initialized
INFO - 2021-06-12 06:21:38 --> Final output sent to browser
DEBUG - 2021-06-12 06:21:38 --> Total execution time: 0.0383
INFO - 2021-06-12 06:21:39 --> Config Class Initialized
INFO - 2021-06-12 06:21:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:21:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:21:39 --> Utf8 Class Initialized
INFO - 2021-06-12 06:21:39 --> URI Class Initialized
INFO - 2021-06-12 06:21:39 --> Router Class Initialized
INFO - 2021-06-12 06:21:39 --> Output Class Initialized
INFO - 2021-06-12 06:21:39 --> Security Class Initialized
DEBUG - 2021-06-12 06:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:21:39 --> Input Class Initialized
INFO - 2021-06-12 06:21:39 --> Language Class Initialized
INFO - 2021-06-12 06:21:39 --> Language Class Initialized
INFO - 2021-06-12 06:21:39 --> Config Class Initialized
INFO - 2021-06-12 06:21:39 --> Loader Class Initialized
INFO - 2021-06-12 06:21:39 --> Helper loaded: url_helper
INFO - 2021-06-12 06:21:39 --> Helper loaded: file_helper
INFO - 2021-06-12 06:21:39 --> Helper loaded: form_helper
INFO - 2021-06-12 06:21:39 --> Helper loaded: my_helper
INFO - 2021-06-12 06:21:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:21:39 --> Controller Class Initialized
INFO - 2021-06-12 06:22:16 --> Config Class Initialized
INFO - 2021-06-12 06:22:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:22:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:22:16 --> Utf8 Class Initialized
INFO - 2021-06-12 06:22:16 --> URI Class Initialized
INFO - 2021-06-12 06:22:16 --> Router Class Initialized
INFO - 2021-06-12 06:22:16 --> Output Class Initialized
INFO - 2021-06-12 06:22:16 --> Security Class Initialized
DEBUG - 2021-06-12 06:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:22:16 --> Input Class Initialized
INFO - 2021-06-12 06:22:16 --> Language Class Initialized
INFO - 2021-06-12 06:22:16 --> Language Class Initialized
INFO - 2021-06-12 06:22:16 --> Config Class Initialized
INFO - 2021-06-12 06:22:16 --> Loader Class Initialized
INFO - 2021-06-12 06:22:16 --> Helper loaded: url_helper
INFO - 2021-06-12 06:22:16 --> Helper loaded: file_helper
INFO - 2021-06-12 06:22:16 --> Helper loaded: form_helper
INFO - 2021-06-12 06:22:16 --> Helper loaded: my_helper
INFO - 2021-06-12 06:22:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:22:16 --> Controller Class Initialized
INFO - 2021-06-12 06:22:16 --> Final output sent to browser
DEBUG - 2021-06-12 06:22:16 --> Total execution time: 0.0458
INFO - 2021-06-12 06:22:17 --> Config Class Initialized
INFO - 2021-06-12 06:22:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:22:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:22:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:22:17 --> URI Class Initialized
INFO - 2021-06-12 06:22:17 --> Router Class Initialized
INFO - 2021-06-12 06:22:17 --> Output Class Initialized
INFO - 2021-06-12 06:22:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:22:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:22:17 --> Input Class Initialized
INFO - 2021-06-12 06:22:17 --> Language Class Initialized
INFO - 2021-06-12 06:22:17 --> Language Class Initialized
INFO - 2021-06-12 06:22:17 --> Config Class Initialized
INFO - 2021-06-12 06:22:17 --> Loader Class Initialized
INFO - 2021-06-12 06:22:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:22:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:22:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:22:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:22:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:22:17 --> Controller Class Initialized
INFO - 2021-06-12 06:22:58 --> Config Class Initialized
INFO - 2021-06-12 06:22:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:22:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:22:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:22:58 --> URI Class Initialized
INFO - 2021-06-12 06:22:58 --> Router Class Initialized
INFO - 2021-06-12 06:22:58 --> Output Class Initialized
INFO - 2021-06-12 06:22:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:22:58 --> Input Class Initialized
INFO - 2021-06-12 06:22:58 --> Language Class Initialized
INFO - 2021-06-12 06:22:58 --> Language Class Initialized
INFO - 2021-06-12 06:22:58 --> Config Class Initialized
INFO - 2021-06-12 06:22:58 --> Loader Class Initialized
INFO - 2021-06-12 06:22:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:22:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:22:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:22:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:22:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:22:58 --> Controller Class Initialized
DEBUG - 2021-06-12 06:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:22:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:22:58 --> Final output sent to browser
DEBUG - 2021-06-12 06:22:58 --> Total execution time: 0.0464
INFO - 2021-06-12 06:22:58 --> Config Class Initialized
INFO - 2021-06-12 06:22:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:22:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:22:58 --> Utf8 Class Initialized
INFO - 2021-06-12 06:22:58 --> URI Class Initialized
INFO - 2021-06-12 06:22:58 --> Router Class Initialized
INFO - 2021-06-12 06:22:58 --> Output Class Initialized
INFO - 2021-06-12 06:22:58 --> Security Class Initialized
DEBUG - 2021-06-12 06:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:22:58 --> Input Class Initialized
INFO - 2021-06-12 06:22:58 --> Language Class Initialized
INFO - 2021-06-12 06:22:58 --> Language Class Initialized
INFO - 2021-06-12 06:22:58 --> Config Class Initialized
INFO - 2021-06-12 06:22:58 --> Loader Class Initialized
INFO - 2021-06-12 06:22:58 --> Helper loaded: url_helper
INFO - 2021-06-12 06:22:58 --> Helper loaded: file_helper
INFO - 2021-06-12 06:22:58 --> Helper loaded: form_helper
INFO - 2021-06-12 06:22:58 --> Helper loaded: my_helper
INFO - 2021-06-12 06:22:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:22:58 --> Controller Class Initialized
INFO - 2021-06-12 06:22:59 --> Config Class Initialized
INFO - 2021-06-12 06:22:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:22:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:22:59 --> Utf8 Class Initialized
INFO - 2021-06-12 06:22:59 --> URI Class Initialized
INFO - 2021-06-12 06:22:59 --> Router Class Initialized
INFO - 2021-06-12 06:22:59 --> Output Class Initialized
INFO - 2021-06-12 06:22:59 --> Security Class Initialized
DEBUG - 2021-06-12 06:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:22:59 --> Input Class Initialized
INFO - 2021-06-12 06:22:59 --> Language Class Initialized
INFO - 2021-06-12 06:22:59 --> Language Class Initialized
INFO - 2021-06-12 06:22:59 --> Config Class Initialized
INFO - 2021-06-12 06:22:59 --> Loader Class Initialized
INFO - 2021-06-12 06:22:59 --> Helper loaded: url_helper
INFO - 2021-06-12 06:22:59 --> Helper loaded: file_helper
INFO - 2021-06-12 06:22:59 --> Helper loaded: form_helper
INFO - 2021-06-12 06:22:59 --> Helper loaded: my_helper
INFO - 2021-06-12 06:22:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:22:59 --> Controller Class Initialized
DEBUG - 2021-06-12 06:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:22:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:22:59 --> Final output sent to browser
DEBUG - 2021-06-12 06:22:59 --> Total execution time: 0.1221
INFO - 2021-06-12 06:23:01 --> Config Class Initialized
INFO - 2021-06-12 06:23:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:01 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:01 --> URI Class Initialized
INFO - 2021-06-12 06:23:01 --> Router Class Initialized
INFO - 2021-06-12 06:23:01 --> Output Class Initialized
INFO - 2021-06-12 06:23:01 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:01 --> Input Class Initialized
INFO - 2021-06-12 06:23:01 --> Language Class Initialized
INFO - 2021-06-12 06:23:01 --> Language Class Initialized
INFO - 2021-06-12 06:23:01 --> Config Class Initialized
INFO - 2021-06-12 06:23:01 --> Loader Class Initialized
INFO - 2021-06-12 06:23:01 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:01 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:01 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:01 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:01 --> Controller Class Initialized
INFO - 2021-06-12 06:23:01 --> Final output sent to browser
DEBUG - 2021-06-12 06:23:01 --> Total execution time: 0.0459
INFO - 2021-06-12 06:23:03 --> Config Class Initialized
INFO - 2021-06-12 06:23:03 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:03 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:03 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:03 --> URI Class Initialized
INFO - 2021-06-12 06:23:03 --> Router Class Initialized
INFO - 2021-06-12 06:23:03 --> Output Class Initialized
INFO - 2021-06-12 06:23:03 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:03 --> Input Class Initialized
INFO - 2021-06-12 06:23:03 --> Language Class Initialized
INFO - 2021-06-12 06:23:03 --> Language Class Initialized
INFO - 2021-06-12 06:23:03 --> Config Class Initialized
INFO - 2021-06-12 06:23:03 --> Loader Class Initialized
INFO - 2021-06-12 06:23:03 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:03 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:03 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:03 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:03 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:03 --> Controller Class Initialized
INFO - 2021-06-12 06:23:03 --> Final output sent to browser
DEBUG - 2021-06-12 06:23:03 --> Total execution time: 0.0551
INFO - 2021-06-12 06:23:06 --> Config Class Initialized
INFO - 2021-06-12 06:23:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:06 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:06 --> URI Class Initialized
INFO - 2021-06-12 06:23:06 --> Router Class Initialized
INFO - 2021-06-12 06:23:06 --> Output Class Initialized
INFO - 2021-06-12 06:23:06 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:06 --> Input Class Initialized
INFO - 2021-06-12 06:23:06 --> Language Class Initialized
INFO - 2021-06-12 06:23:06 --> Language Class Initialized
INFO - 2021-06-12 06:23:06 --> Config Class Initialized
INFO - 2021-06-12 06:23:06 --> Loader Class Initialized
INFO - 2021-06-12 06:23:06 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:06 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:06 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:06 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:06 --> Controller Class Initialized
INFO - 2021-06-12 06:23:06 --> Final output sent to browser
DEBUG - 2021-06-12 06:23:06 --> Total execution time: 0.6592
INFO - 2021-06-12 06:23:29 --> Config Class Initialized
INFO - 2021-06-12 06:23:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:29 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:29 --> URI Class Initialized
INFO - 2021-06-12 06:23:29 --> Router Class Initialized
INFO - 2021-06-12 06:23:29 --> Output Class Initialized
INFO - 2021-06-12 06:23:29 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:29 --> Input Class Initialized
INFO - 2021-06-12 06:23:29 --> Language Class Initialized
INFO - 2021-06-12 06:23:29 --> Language Class Initialized
INFO - 2021-06-12 06:23:29 --> Config Class Initialized
INFO - 2021-06-12 06:23:29 --> Loader Class Initialized
INFO - 2021-06-12 06:23:29 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:29 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:29 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:29 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:29 --> Controller Class Initialized
DEBUG - 2021-06-12 06:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:23:29 --> Final output sent to browser
DEBUG - 2021-06-12 06:23:29 --> Total execution time: 0.0512
INFO - 2021-06-12 06:23:29 --> Config Class Initialized
INFO - 2021-06-12 06:23:30 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:30 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:30 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:30 --> URI Class Initialized
INFO - 2021-06-12 06:23:30 --> Router Class Initialized
INFO - 2021-06-12 06:23:30 --> Output Class Initialized
INFO - 2021-06-12 06:23:30 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:30 --> Input Class Initialized
INFO - 2021-06-12 06:23:30 --> Language Class Initialized
INFO - 2021-06-12 06:23:30 --> Language Class Initialized
INFO - 2021-06-12 06:23:30 --> Config Class Initialized
INFO - 2021-06-12 06:23:30 --> Loader Class Initialized
INFO - 2021-06-12 06:23:30 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:30 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:30 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:30 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:30 --> Controller Class Initialized
INFO - 2021-06-12 06:23:31 --> Config Class Initialized
INFO - 2021-06-12 06:23:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:31 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:31 --> URI Class Initialized
INFO - 2021-06-12 06:23:31 --> Router Class Initialized
INFO - 2021-06-12 06:23:31 --> Output Class Initialized
INFO - 2021-06-12 06:23:31 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:31 --> Input Class Initialized
INFO - 2021-06-12 06:23:31 --> Language Class Initialized
INFO - 2021-06-12 06:23:31 --> Language Class Initialized
INFO - 2021-06-12 06:23:31 --> Config Class Initialized
INFO - 2021-06-12 06:23:31 --> Loader Class Initialized
INFO - 2021-06-12 06:23:31 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:31 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:31 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:31 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:31 --> Controller Class Initialized
INFO - 2021-06-12 06:23:31 --> Final output sent to browser
DEBUG - 2021-06-12 06:23:31 --> Total execution time: 0.0515
INFO - 2021-06-12 06:23:41 --> Config Class Initialized
INFO - 2021-06-12 06:23:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:41 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:41 --> URI Class Initialized
INFO - 2021-06-12 06:23:41 --> Router Class Initialized
INFO - 2021-06-12 06:23:41 --> Output Class Initialized
INFO - 2021-06-12 06:23:41 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:41 --> Input Class Initialized
INFO - 2021-06-12 06:23:41 --> Language Class Initialized
INFO - 2021-06-12 06:23:41 --> Language Class Initialized
INFO - 2021-06-12 06:23:41 --> Config Class Initialized
INFO - 2021-06-12 06:23:41 --> Loader Class Initialized
INFO - 2021-06-12 06:23:41 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:41 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:41 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:41 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:41 --> Controller Class Initialized
DEBUG - 2021-06-12 06:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:23:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:23:41 --> Final output sent to browser
DEBUG - 2021-06-12 06:23:41 --> Total execution time: 0.1661
INFO - 2021-06-12 06:23:41 --> Config Class Initialized
INFO - 2021-06-12 06:23:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:41 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:41 --> URI Class Initialized
INFO - 2021-06-12 06:23:41 --> Router Class Initialized
INFO - 2021-06-12 06:23:41 --> Output Class Initialized
INFO - 2021-06-12 06:23:41 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:41 --> Input Class Initialized
INFO - 2021-06-12 06:23:41 --> Language Class Initialized
INFO - 2021-06-12 06:23:41 --> Language Class Initialized
INFO - 2021-06-12 06:23:41 --> Config Class Initialized
INFO - 2021-06-12 06:23:41 --> Loader Class Initialized
INFO - 2021-06-12 06:23:41 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:41 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:41 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:41 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:41 --> Controller Class Initialized
INFO - 2021-06-12 06:23:42 --> Config Class Initialized
INFO - 2021-06-12 06:23:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:42 --> URI Class Initialized
INFO - 2021-06-12 06:23:42 --> Router Class Initialized
INFO - 2021-06-12 06:23:42 --> Output Class Initialized
INFO - 2021-06-12 06:23:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:42 --> Input Class Initialized
INFO - 2021-06-12 06:23:42 --> Language Class Initialized
INFO - 2021-06-12 06:23:42 --> Language Class Initialized
INFO - 2021-06-12 06:23:42 --> Config Class Initialized
INFO - 2021-06-12 06:23:42 --> Loader Class Initialized
INFO - 2021-06-12 06:23:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:42 --> Controller Class Initialized
DEBUG - 2021-06-12 06:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:23:42 --> Final output sent to browser
DEBUG - 2021-06-12 06:23:42 --> Total execution time: 0.0442
INFO - 2021-06-12 06:23:46 --> Config Class Initialized
INFO - 2021-06-12 06:23:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:23:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:23:46 --> Utf8 Class Initialized
INFO - 2021-06-12 06:23:46 --> URI Class Initialized
INFO - 2021-06-12 06:23:46 --> Router Class Initialized
INFO - 2021-06-12 06:23:46 --> Output Class Initialized
INFO - 2021-06-12 06:23:46 --> Security Class Initialized
DEBUG - 2021-06-12 06:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:23:46 --> Input Class Initialized
INFO - 2021-06-12 06:23:46 --> Language Class Initialized
INFO - 2021-06-12 06:23:46 --> Language Class Initialized
INFO - 2021-06-12 06:23:46 --> Config Class Initialized
INFO - 2021-06-12 06:23:46 --> Loader Class Initialized
INFO - 2021-06-12 06:23:46 --> Helper loaded: url_helper
INFO - 2021-06-12 06:23:46 --> Helper loaded: file_helper
INFO - 2021-06-12 06:23:46 --> Helper loaded: form_helper
INFO - 2021-06-12 06:23:46 --> Helper loaded: my_helper
INFO - 2021-06-12 06:23:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:23:46 --> Controller Class Initialized
INFO - 2021-06-12 06:24:21 --> Config Class Initialized
INFO - 2021-06-12 06:24:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:24:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:24:21 --> Utf8 Class Initialized
INFO - 2021-06-12 06:24:21 --> URI Class Initialized
INFO - 2021-06-12 06:24:21 --> Router Class Initialized
INFO - 2021-06-12 06:24:21 --> Output Class Initialized
INFO - 2021-06-12 06:24:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:24:21 --> Input Class Initialized
INFO - 2021-06-12 06:24:21 --> Language Class Initialized
INFO - 2021-06-12 06:24:22 --> Language Class Initialized
INFO - 2021-06-12 06:24:22 --> Config Class Initialized
INFO - 2021-06-12 06:24:22 --> Loader Class Initialized
INFO - 2021-06-12 06:24:22 --> Helper loaded: url_helper
INFO - 2021-06-12 06:24:22 --> Helper loaded: file_helper
INFO - 2021-06-12 06:24:22 --> Helper loaded: form_helper
INFO - 2021-06-12 06:24:22 --> Helper loaded: my_helper
INFO - 2021-06-12 06:24:22 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:24:22 --> Controller Class Initialized
INFO - 2021-06-12 06:25:55 --> Config Class Initialized
INFO - 2021-06-12 06:25:55 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:25:55 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:25:55 --> Utf8 Class Initialized
INFO - 2021-06-12 06:25:55 --> URI Class Initialized
INFO - 2021-06-12 06:25:55 --> Router Class Initialized
INFO - 2021-06-12 06:25:55 --> Output Class Initialized
INFO - 2021-06-12 06:25:55 --> Security Class Initialized
DEBUG - 2021-06-12 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:25:55 --> Input Class Initialized
INFO - 2021-06-12 06:25:55 --> Language Class Initialized
INFO - 2021-06-12 06:25:55 --> Language Class Initialized
INFO - 2021-06-12 06:25:55 --> Config Class Initialized
INFO - 2021-06-12 06:25:55 --> Loader Class Initialized
INFO - 2021-06-12 06:25:55 --> Helper loaded: url_helper
INFO - 2021-06-12 06:25:55 --> Helper loaded: file_helper
INFO - 2021-06-12 06:25:55 --> Helper loaded: form_helper
INFO - 2021-06-12 06:25:55 --> Helper loaded: my_helper
INFO - 2021-06-12 06:25:55 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:25:55 --> Controller Class Initialized
DEBUG - 2021-06-12 06:25:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:25:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:25:55 --> Final output sent to browser
DEBUG - 2021-06-12 06:25:55 --> Total execution time: 0.1185
INFO - 2021-06-12 06:25:55 --> Config Class Initialized
INFO - 2021-06-12 06:25:55 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:25:55 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:25:55 --> Utf8 Class Initialized
INFO - 2021-06-12 06:25:55 --> URI Class Initialized
INFO - 2021-06-12 06:25:55 --> Router Class Initialized
INFO - 2021-06-12 06:25:55 --> Output Class Initialized
INFO - 2021-06-12 06:25:55 --> Security Class Initialized
DEBUG - 2021-06-12 06:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:25:55 --> Input Class Initialized
INFO - 2021-06-12 06:25:55 --> Language Class Initialized
INFO - 2021-06-12 06:25:55 --> Language Class Initialized
INFO - 2021-06-12 06:25:55 --> Config Class Initialized
INFO - 2021-06-12 06:25:55 --> Loader Class Initialized
INFO - 2021-06-12 06:25:55 --> Helper loaded: url_helper
INFO - 2021-06-12 06:25:55 --> Helper loaded: file_helper
INFO - 2021-06-12 06:25:55 --> Helper loaded: form_helper
INFO - 2021-06-12 06:25:55 --> Helper loaded: my_helper
INFO - 2021-06-12 06:25:55 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:25:55 --> Controller Class Initialized
INFO - 2021-06-12 06:25:57 --> Config Class Initialized
INFO - 2021-06-12 06:25:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:25:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:25:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:25:57 --> URI Class Initialized
INFO - 2021-06-12 06:25:57 --> Router Class Initialized
INFO - 2021-06-12 06:25:57 --> Output Class Initialized
INFO - 2021-06-12 06:25:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:25:57 --> Input Class Initialized
INFO - 2021-06-12 06:25:57 --> Language Class Initialized
INFO - 2021-06-12 06:25:57 --> Language Class Initialized
INFO - 2021-06-12 06:25:57 --> Config Class Initialized
INFO - 2021-06-12 06:25:57 --> Loader Class Initialized
INFO - 2021-06-12 06:25:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:25:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:25:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:25:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:25:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:25:57 --> Controller Class Initialized
DEBUG - 2021-06-12 06:25:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:25:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:25:57 --> Final output sent to browser
DEBUG - 2021-06-12 06:25:57 --> Total execution time: 0.0874
INFO - 2021-06-12 06:26:03 --> Config Class Initialized
INFO - 2021-06-12 06:26:03 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:26:03 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:26:03 --> Utf8 Class Initialized
INFO - 2021-06-12 06:26:03 --> URI Class Initialized
INFO - 2021-06-12 06:26:03 --> Router Class Initialized
INFO - 2021-06-12 06:26:03 --> Output Class Initialized
INFO - 2021-06-12 06:26:03 --> Security Class Initialized
DEBUG - 2021-06-12 06:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:26:03 --> Input Class Initialized
INFO - 2021-06-12 06:26:03 --> Language Class Initialized
INFO - 2021-06-12 06:26:03 --> Language Class Initialized
INFO - 2021-06-12 06:26:03 --> Config Class Initialized
INFO - 2021-06-12 06:26:03 --> Loader Class Initialized
INFO - 2021-06-12 06:26:03 --> Helper loaded: url_helper
INFO - 2021-06-12 06:26:03 --> Helper loaded: file_helper
INFO - 2021-06-12 06:26:03 --> Helper loaded: form_helper
INFO - 2021-06-12 06:26:03 --> Helper loaded: my_helper
INFO - 2021-06-12 06:26:03 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:26:03 --> Controller Class Initialized
INFO - 2021-06-12 06:27:09 --> Config Class Initialized
INFO - 2021-06-12 06:27:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:27:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:27:09 --> Utf8 Class Initialized
INFO - 2021-06-12 06:27:09 --> URI Class Initialized
INFO - 2021-06-12 06:27:09 --> Router Class Initialized
INFO - 2021-06-12 06:27:09 --> Output Class Initialized
INFO - 2021-06-12 06:27:09 --> Security Class Initialized
DEBUG - 2021-06-12 06:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:27:09 --> Input Class Initialized
INFO - 2021-06-12 06:27:09 --> Language Class Initialized
INFO - 2021-06-12 06:27:09 --> Language Class Initialized
INFO - 2021-06-12 06:27:09 --> Config Class Initialized
INFO - 2021-06-12 06:27:09 --> Loader Class Initialized
INFO - 2021-06-12 06:27:09 --> Helper loaded: url_helper
INFO - 2021-06-12 06:27:09 --> Helper loaded: file_helper
INFO - 2021-06-12 06:27:09 --> Helper loaded: form_helper
INFO - 2021-06-12 06:27:09 --> Helper loaded: my_helper
INFO - 2021-06-12 06:27:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:27:09 --> Controller Class Initialized
INFO - 2021-06-12 06:27:35 --> Config Class Initialized
INFO - 2021-06-12 06:27:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:27:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:27:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:27:35 --> URI Class Initialized
INFO - 2021-06-12 06:27:35 --> Router Class Initialized
INFO - 2021-06-12 06:27:35 --> Output Class Initialized
INFO - 2021-06-12 06:27:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:27:35 --> Input Class Initialized
INFO - 2021-06-12 06:27:35 --> Language Class Initialized
INFO - 2021-06-12 06:27:35 --> Language Class Initialized
INFO - 2021-06-12 06:27:35 --> Config Class Initialized
INFO - 2021-06-12 06:27:35 --> Loader Class Initialized
INFO - 2021-06-12 06:27:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:27:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:27:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:27:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:27:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:27:35 --> Controller Class Initialized
DEBUG - 2021-06-12 06:27:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:27:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:27:35 --> Final output sent to browser
DEBUG - 2021-06-12 06:27:35 --> Total execution time: 0.0455
INFO - 2021-06-12 06:27:35 --> Config Class Initialized
INFO - 2021-06-12 06:27:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:27:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:27:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:27:35 --> URI Class Initialized
INFO - 2021-06-12 06:27:35 --> Router Class Initialized
INFO - 2021-06-12 06:27:35 --> Output Class Initialized
INFO - 2021-06-12 06:27:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:27:35 --> Input Class Initialized
INFO - 2021-06-12 06:27:35 --> Language Class Initialized
INFO - 2021-06-12 06:27:35 --> Language Class Initialized
INFO - 2021-06-12 06:27:35 --> Config Class Initialized
INFO - 2021-06-12 06:27:35 --> Loader Class Initialized
INFO - 2021-06-12 06:27:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:27:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:27:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:27:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:27:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:27:35 --> Controller Class Initialized
INFO - 2021-06-12 06:27:37 --> Config Class Initialized
INFO - 2021-06-12 06:27:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:27:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:27:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:27:37 --> URI Class Initialized
INFO - 2021-06-12 06:27:37 --> Router Class Initialized
INFO - 2021-06-12 06:27:37 --> Output Class Initialized
INFO - 2021-06-12 06:27:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:27:37 --> Input Class Initialized
INFO - 2021-06-12 06:27:37 --> Language Class Initialized
INFO - 2021-06-12 06:27:37 --> Language Class Initialized
INFO - 2021-06-12 06:27:37 --> Config Class Initialized
INFO - 2021-06-12 06:27:37 --> Loader Class Initialized
INFO - 2021-06-12 06:27:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:27:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:27:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:27:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:27:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:27:37 --> Controller Class Initialized
DEBUG - 2021-06-12 06:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:27:37 --> Final output sent to browser
DEBUG - 2021-06-12 06:27:37 --> Total execution time: 0.0450
INFO - 2021-06-12 06:27:39 --> Config Class Initialized
INFO - 2021-06-12 06:27:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:27:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:27:39 --> Utf8 Class Initialized
INFO - 2021-06-12 06:27:39 --> URI Class Initialized
INFO - 2021-06-12 06:27:39 --> Router Class Initialized
INFO - 2021-06-12 06:27:39 --> Output Class Initialized
INFO - 2021-06-12 06:27:39 --> Security Class Initialized
DEBUG - 2021-06-12 06:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:27:39 --> Input Class Initialized
INFO - 2021-06-12 06:27:39 --> Language Class Initialized
INFO - 2021-06-12 06:27:39 --> Language Class Initialized
INFO - 2021-06-12 06:27:39 --> Config Class Initialized
INFO - 2021-06-12 06:27:39 --> Loader Class Initialized
INFO - 2021-06-12 06:27:39 --> Helper loaded: url_helper
INFO - 2021-06-12 06:27:39 --> Helper loaded: file_helper
INFO - 2021-06-12 06:27:39 --> Helper loaded: form_helper
INFO - 2021-06-12 06:27:39 --> Helper loaded: my_helper
INFO - 2021-06-12 06:27:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:27:39 --> Controller Class Initialized
INFO - 2021-06-12 06:28:04 --> Config Class Initialized
INFO - 2021-06-12 06:28:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:28:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:28:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:28:04 --> URI Class Initialized
INFO - 2021-06-12 06:28:04 --> Router Class Initialized
INFO - 2021-06-12 06:28:04 --> Output Class Initialized
INFO - 2021-06-12 06:28:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:28:04 --> Input Class Initialized
INFO - 2021-06-12 06:28:04 --> Language Class Initialized
INFO - 2021-06-12 06:28:04 --> Language Class Initialized
INFO - 2021-06-12 06:28:04 --> Config Class Initialized
INFO - 2021-06-12 06:28:04 --> Loader Class Initialized
INFO - 2021-06-12 06:28:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:28:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:28:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:28:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:28:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:28:04 --> Controller Class Initialized
INFO - 2021-06-12 06:28:26 --> Config Class Initialized
INFO - 2021-06-12 06:28:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:28:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:28:26 --> Utf8 Class Initialized
INFO - 2021-06-12 06:28:26 --> URI Class Initialized
INFO - 2021-06-12 06:28:26 --> Router Class Initialized
INFO - 2021-06-12 06:28:26 --> Output Class Initialized
INFO - 2021-06-12 06:28:26 --> Security Class Initialized
DEBUG - 2021-06-12 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:28:26 --> Input Class Initialized
INFO - 2021-06-12 06:28:26 --> Language Class Initialized
INFO - 2021-06-12 06:28:26 --> Language Class Initialized
INFO - 2021-06-12 06:28:26 --> Config Class Initialized
INFO - 2021-06-12 06:28:26 --> Loader Class Initialized
INFO - 2021-06-12 06:28:26 --> Helper loaded: url_helper
INFO - 2021-06-12 06:28:26 --> Helper loaded: file_helper
INFO - 2021-06-12 06:28:26 --> Helper loaded: form_helper
INFO - 2021-06-12 06:28:26 --> Helper loaded: my_helper
INFO - 2021-06-12 06:28:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:28:26 --> Controller Class Initialized
DEBUG - 2021-06-12 06:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:28:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:28:26 --> Final output sent to browser
DEBUG - 2021-06-12 06:28:26 --> Total execution time: 0.0451
INFO - 2021-06-12 06:28:26 --> Config Class Initialized
INFO - 2021-06-12 06:28:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:28:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:28:26 --> Utf8 Class Initialized
INFO - 2021-06-12 06:28:26 --> URI Class Initialized
INFO - 2021-06-12 06:28:26 --> Router Class Initialized
INFO - 2021-06-12 06:28:26 --> Output Class Initialized
INFO - 2021-06-12 06:28:26 --> Security Class Initialized
DEBUG - 2021-06-12 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:28:26 --> Input Class Initialized
INFO - 2021-06-12 06:28:26 --> Language Class Initialized
INFO - 2021-06-12 06:28:26 --> Language Class Initialized
INFO - 2021-06-12 06:28:26 --> Config Class Initialized
INFO - 2021-06-12 06:28:26 --> Loader Class Initialized
INFO - 2021-06-12 06:28:26 --> Helper loaded: url_helper
INFO - 2021-06-12 06:28:26 --> Helper loaded: file_helper
INFO - 2021-06-12 06:28:26 --> Helper loaded: form_helper
INFO - 2021-06-12 06:28:26 --> Helper loaded: my_helper
INFO - 2021-06-12 06:28:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:28:26 --> Controller Class Initialized
INFO - 2021-06-12 06:28:27 --> Config Class Initialized
INFO - 2021-06-12 06:28:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:28:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:28:27 --> Utf8 Class Initialized
INFO - 2021-06-12 06:28:27 --> URI Class Initialized
INFO - 2021-06-12 06:28:27 --> Router Class Initialized
INFO - 2021-06-12 06:28:27 --> Output Class Initialized
INFO - 2021-06-12 06:28:27 --> Security Class Initialized
DEBUG - 2021-06-12 06:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:28:27 --> Input Class Initialized
INFO - 2021-06-12 06:28:27 --> Language Class Initialized
INFO - 2021-06-12 06:28:27 --> Language Class Initialized
INFO - 2021-06-12 06:28:27 --> Config Class Initialized
INFO - 2021-06-12 06:28:27 --> Loader Class Initialized
INFO - 2021-06-12 06:28:27 --> Helper loaded: url_helper
INFO - 2021-06-12 06:28:27 --> Helper loaded: file_helper
INFO - 2021-06-12 06:28:27 --> Helper loaded: form_helper
INFO - 2021-06-12 06:28:27 --> Helper loaded: my_helper
INFO - 2021-06-12 06:28:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:28:27 --> Controller Class Initialized
DEBUG - 2021-06-12 06:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:28:27 --> Final output sent to browser
DEBUG - 2021-06-12 06:28:27 --> Total execution time: 0.0445
INFO - 2021-06-12 06:28:45 --> Config Class Initialized
INFO - 2021-06-12 06:28:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:28:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:28:45 --> Utf8 Class Initialized
INFO - 2021-06-12 06:28:45 --> URI Class Initialized
INFO - 2021-06-12 06:28:45 --> Router Class Initialized
INFO - 2021-06-12 06:28:45 --> Output Class Initialized
INFO - 2021-06-12 06:28:45 --> Security Class Initialized
DEBUG - 2021-06-12 06:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:28:45 --> Input Class Initialized
INFO - 2021-06-12 06:28:45 --> Language Class Initialized
INFO - 2021-06-12 06:28:45 --> Language Class Initialized
INFO - 2021-06-12 06:28:45 --> Config Class Initialized
INFO - 2021-06-12 06:28:45 --> Loader Class Initialized
INFO - 2021-06-12 06:28:45 --> Helper loaded: url_helper
INFO - 2021-06-12 06:28:45 --> Helper loaded: file_helper
INFO - 2021-06-12 06:28:45 --> Helper loaded: form_helper
INFO - 2021-06-12 06:28:45 --> Helper loaded: my_helper
INFO - 2021-06-12 06:28:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:28:45 --> Controller Class Initialized
INFO - 2021-06-12 06:29:34 --> Config Class Initialized
INFO - 2021-06-12 06:29:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:29:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:29:34 --> Utf8 Class Initialized
INFO - 2021-06-12 06:29:34 --> URI Class Initialized
INFO - 2021-06-12 06:29:34 --> Router Class Initialized
INFO - 2021-06-12 06:29:34 --> Output Class Initialized
INFO - 2021-06-12 06:29:34 --> Security Class Initialized
DEBUG - 2021-06-12 06:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:29:34 --> Input Class Initialized
INFO - 2021-06-12 06:29:34 --> Language Class Initialized
INFO - 2021-06-12 06:29:34 --> Language Class Initialized
INFO - 2021-06-12 06:29:34 --> Config Class Initialized
INFO - 2021-06-12 06:29:34 --> Loader Class Initialized
INFO - 2021-06-12 06:29:34 --> Helper loaded: url_helper
INFO - 2021-06-12 06:29:34 --> Helper loaded: file_helper
INFO - 2021-06-12 06:29:34 --> Helper loaded: form_helper
INFO - 2021-06-12 06:29:34 --> Helper loaded: my_helper
INFO - 2021-06-12 06:29:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:29:34 --> Controller Class Initialized
INFO - 2021-06-12 06:30:04 --> Config Class Initialized
INFO - 2021-06-12 06:30:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:30:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:30:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:30:04 --> URI Class Initialized
INFO - 2021-06-12 06:30:04 --> Router Class Initialized
INFO - 2021-06-12 06:30:04 --> Output Class Initialized
INFO - 2021-06-12 06:30:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:30:04 --> Input Class Initialized
INFO - 2021-06-12 06:30:04 --> Language Class Initialized
INFO - 2021-06-12 06:30:04 --> Language Class Initialized
INFO - 2021-06-12 06:30:04 --> Config Class Initialized
INFO - 2021-06-12 06:30:04 --> Loader Class Initialized
INFO - 2021-06-12 06:30:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:30:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:30:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:30:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:30:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:30:04 --> Controller Class Initialized
DEBUG - 2021-06-12 06:30:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:30:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:30:04 --> Final output sent to browser
DEBUG - 2021-06-12 06:30:04 --> Total execution time: 0.0448
INFO - 2021-06-12 06:30:04 --> Config Class Initialized
INFO - 2021-06-12 06:30:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:30:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:30:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:30:04 --> URI Class Initialized
INFO - 2021-06-12 06:30:04 --> Router Class Initialized
INFO - 2021-06-12 06:30:04 --> Output Class Initialized
INFO - 2021-06-12 06:30:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:30:04 --> Input Class Initialized
INFO - 2021-06-12 06:30:04 --> Language Class Initialized
INFO - 2021-06-12 06:30:04 --> Language Class Initialized
INFO - 2021-06-12 06:30:04 --> Config Class Initialized
INFO - 2021-06-12 06:30:04 --> Loader Class Initialized
INFO - 2021-06-12 06:30:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:30:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:30:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:30:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:30:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:30:04 --> Controller Class Initialized
INFO - 2021-06-12 06:30:06 --> Config Class Initialized
INFO - 2021-06-12 06:30:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:30:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:30:06 --> Utf8 Class Initialized
INFO - 2021-06-12 06:30:06 --> URI Class Initialized
INFO - 2021-06-12 06:30:06 --> Router Class Initialized
INFO - 2021-06-12 06:30:06 --> Output Class Initialized
INFO - 2021-06-12 06:30:06 --> Security Class Initialized
DEBUG - 2021-06-12 06:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:30:06 --> Input Class Initialized
INFO - 2021-06-12 06:30:06 --> Language Class Initialized
INFO - 2021-06-12 06:30:06 --> Language Class Initialized
INFO - 2021-06-12 06:30:06 --> Config Class Initialized
INFO - 2021-06-12 06:30:06 --> Loader Class Initialized
INFO - 2021-06-12 06:30:06 --> Helper loaded: url_helper
INFO - 2021-06-12 06:30:06 --> Helper loaded: file_helper
INFO - 2021-06-12 06:30:06 --> Helper loaded: form_helper
INFO - 2021-06-12 06:30:06 --> Helper loaded: my_helper
INFO - 2021-06-12 06:30:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:30:06 --> Controller Class Initialized
DEBUG - 2021-06-12 06:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:30:06 --> Final output sent to browser
DEBUG - 2021-06-12 06:30:06 --> Total execution time: 0.0448
INFO - 2021-06-12 06:30:10 --> Config Class Initialized
INFO - 2021-06-12 06:30:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:30:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:30:10 --> Utf8 Class Initialized
INFO - 2021-06-12 06:30:10 --> URI Class Initialized
INFO - 2021-06-12 06:30:10 --> Router Class Initialized
INFO - 2021-06-12 06:30:10 --> Output Class Initialized
INFO - 2021-06-12 06:30:10 --> Security Class Initialized
DEBUG - 2021-06-12 06:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:30:10 --> Input Class Initialized
INFO - 2021-06-12 06:30:10 --> Language Class Initialized
INFO - 2021-06-12 06:30:10 --> Language Class Initialized
INFO - 2021-06-12 06:30:10 --> Config Class Initialized
INFO - 2021-06-12 06:30:10 --> Loader Class Initialized
INFO - 2021-06-12 06:30:10 --> Helper loaded: url_helper
INFO - 2021-06-12 06:30:10 --> Helper loaded: file_helper
INFO - 2021-06-12 06:30:10 --> Helper loaded: form_helper
INFO - 2021-06-12 06:30:10 --> Helper loaded: my_helper
INFO - 2021-06-12 06:30:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:30:10 --> Controller Class Initialized
INFO - 2021-06-12 06:30:45 --> Config Class Initialized
INFO - 2021-06-12 06:30:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:30:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:30:45 --> Utf8 Class Initialized
INFO - 2021-06-12 06:30:45 --> URI Class Initialized
INFO - 2021-06-12 06:30:45 --> Router Class Initialized
INFO - 2021-06-12 06:30:45 --> Output Class Initialized
INFO - 2021-06-12 06:30:45 --> Security Class Initialized
DEBUG - 2021-06-12 06:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:30:45 --> Input Class Initialized
INFO - 2021-06-12 06:30:45 --> Language Class Initialized
INFO - 2021-06-12 06:30:45 --> Language Class Initialized
INFO - 2021-06-12 06:30:45 --> Config Class Initialized
INFO - 2021-06-12 06:30:45 --> Loader Class Initialized
INFO - 2021-06-12 06:30:45 --> Helper loaded: url_helper
INFO - 2021-06-12 06:30:45 --> Helper loaded: file_helper
INFO - 2021-06-12 06:30:45 --> Helper loaded: form_helper
INFO - 2021-06-12 06:30:45 --> Helper loaded: my_helper
INFO - 2021-06-12 06:30:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:30:45 --> Controller Class Initialized
INFO - 2021-06-12 06:31:31 --> Config Class Initialized
INFO - 2021-06-12 06:31:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:31:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:31:31 --> Utf8 Class Initialized
INFO - 2021-06-12 06:31:31 --> URI Class Initialized
INFO - 2021-06-12 06:31:31 --> Router Class Initialized
INFO - 2021-06-12 06:31:31 --> Output Class Initialized
INFO - 2021-06-12 06:31:31 --> Security Class Initialized
DEBUG - 2021-06-12 06:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:31:31 --> Input Class Initialized
INFO - 2021-06-12 06:31:31 --> Language Class Initialized
INFO - 2021-06-12 06:31:31 --> Language Class Initialized
INFO - 2021-06-12 06:31:31 --> Config Class Initialized
INFO - 2021-06-12 06:31:31 --> Loader Class Initialized
INFO - 2021-06-12 06:31:31 --> Helper loaded: url_helper
INFO - 2021-06-12 06:31:31 --> Helper loaded: file_helper
INFO - 2021-06-12 06:31:31 --> Helper loaded: form_helper
INFO - 2021-06-12 06:31:31 --> Helper loaded: my_helper
INFO - 2021-06-12 06:31:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:31:31 --> Controller Class Initialized
DEBUG - 2021-06-12 06:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:31:31 --> Final output sent to browser
DEBUG - 2021-06-12 06:31:31 --> Total execution time: 0.0478
INFO - 2021-06-12 06:31:31 --> Config Class Initialized
INFO - 2021-06-12 06:31:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:31:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:31:31 --> Utf8 Class Initialized
INFO - 2021-06-12 06:31:31 --> URI Class Initialized
INFO - 2021-06-12 06:31:31 --> Router Class Initialized
INFO - 2021-06-12 06:31:31 --> Output Class Initialized
INFO - 2021-06-12 06:31:31 --> Security Class Initialized
DEBUG - 2021-06-12 06:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:31:31 --> Input Class Initialized
INFO - 2021-06-12 06:31:31 --> Language Class Initialized
INFO - 2021-06-12 06:31:31 --> Language Class Initialized
INFO - 2021-06-12 06:31:31 --> Config Class Initialized
INFO - 2021-06-12 06:31:31 --> Loader Class Initialized
INFO - 2021-06-12 06:31:31 --> Helper loaded: url_helper
INFO - 2021-06-12 06:31:31 --> Helper loaded: file_helper
INFO - 2021-06-12 06:31:31 --> Helper loaded: form_helper
INFO - 2021-06-12 06:31:31 --> Helper loaded: my_helper
INFO - 2021-06-12 06:31:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:31:31 --> Controller Class Initialized
INFO - 2021-06-12 06:31:32 --> Config Class Initialized
INFO - 2021-06-12 06:31:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:31:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:31:32 --> Utf8 Class Initialized
INFO - 2021-06-12 06:31:32 --> URI Class Initialized
INFO - 2021-06-12 06:31:32 --> Router Class Initialized
INFO - 2021-06-12 06:31:32 --> Output Class Initialized
INFO - 2021-06-12 06:31:32 --> Security Class Initialized
DEBUG - 2021-06-12 06:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:31:32 --> Input Class Initialized
INFO - 2021-06-12 06:31:32 --> Language Class Initialized
INFO - 2021-06-12 06:31:32 --> Language Class Initialized
INFO - 2021-06-12 06:31:32 --> Config Class Initialized
INFO - 2021-06-12 06:31:32 --> Loader Class Initialized
INFO - 2021-06-12 06:31:32 --> Helper loaded: url_helper
INFO - 2021-06-12 06:31:32 --> Helper loaded: file_helper
INFO - 2021-06-12 06:31:32 --> Helper loaded: form_helper
INFO - 2021-06-12 06:31:32 --> Helper loaded: my_helper
INFO - 2021-06-12 06:31:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:31:32 --> Controller Class Initialized
DEBUG - 2021-06-12 06:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:31:32 --> Final output sent to browser
DEBUG - 2021-06-12 06:31:32 --> Total execution time: 0.0452
INFO - 2021-06-12 06:31:48 --> Config Class Initialized
INFO - 2021-06-12 06:31:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:31:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:31:48 --> Utf8 Class Initialized
INFO - 2021-06-12 06:31:48 --> URI Class Initialized
INFO - 2021-06-12 06:31:48 --> Router Class Initialized
INFO - 2021-06-12 06:31:48 --> Output Class Initialized
INFO - 2021-06-12 06:31:48 --> Security Class Initialized
DEBUG - 2021-06-12 06:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:31:48 --> Input Class Initialized
INFO - 2021-06-12 06:31:48 --> Language Class Initialized
INFO - 2021-06-12 06:31:48 --> Language Class Initialized
INFO - 2021-06-12 06:31:48 --> Config Class Initialized
INFO - 2021-06-12 06:31:48 --> Loader Class Initialized
INFO - 2021-06-12 06:31:48 --> Helper loaded: url_helper
INFO - 2021-06-12 06:31:48 --> Helper loaded: file_helper
INFO - 2021-06-12 06:31:48 --> Helper loaded: form_helper
INFO - 2021-06-12 06:31:48 --> Helper loaded: my_helper
INFO - 2021-06-12 06:31:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:31:48 --> Controller Class Initialized
INFO - 2021-06-12 06:32:15 --> Config Class Initialized
INFO - 2021-06-12 06:32:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:32:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:32:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:32:15 --> URI Class Initialized
INFO - 2021-06-12 06:32:15 --> Router Class Initialized
INFO - 2021-06-12 06:32:15 --> Output Class Initialized
INFO - 2021-06-12 06:32:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:32:15 --> Input Class Initialized
INFO - 2021-06-12 06:32:15 --> Language Class Initialized
INFO - 2021-06-12 06:32:15 --> Language Class Initialized
INFO - 2021-06-12 06:32:15 --> Config Class Initialized
INFO - 2021-06-12 06:32:15 --> Loader Class Initialized
INFO - 2021-06-12 06:32:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:32:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:32:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:32:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:32:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:32:15 --> Controller Class Initialized
INFO - 2021-06-12 06:33:16 --> Config Class Initialized
INFO - 2021-06-12 06:33:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:33:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:33:16 --> Utf8 Class Initialized
INFO - 2021-06-12 06:33:16 --> URI Class Initialized
INFO - 2021-06-12 06:33:16 --> Router Class Initialized
INFO - 2021-06-12 06:33:16 --> Output Class Initialized
INFO - 2021-06-12 06:33:16 --> Security Class Initialized
DEBUG - 2021-06-12 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:33:16 --> Input Class Initialized
INFO - 2021-06-12 06:33:16 --> Language Class Initialized
INFO - 2021-06-12 06:33:16 --> Language Class Initialized
INFO - 2021-06-12 06:33:16 --> Config Class Initialized
INFO - 2021-06-12 06:33:16 --> Loader Class Initialized
INFO - 2021-06-12 06:33:16 --> Helper loaded: url_helper
INFO - 2021-06-12 06:33:16 --> Helper loaded: file_helper
INFO - 2021-06-12 06:33:16 --> Helper loaded: form_helper
INFO - 2021-06-12 06:33:16 --> Helper loaded: my_helper
INFO - 2021-06-12 06:33:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:33:16 --> Controller Class Initialized
DEBUG - 2021-06-12 06:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:33:16 --> Final output sent to browser
DEBUG - 2021-06-12 06:33:16 --> Total execution time: 0.0555
INFO - 2021-06-12 06:33:16 --> Config Class Initialized
INFO - 2021-06-12 06:33:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:33:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:33:16 --> Utf8 Class Initialized
INFO - 2021-06-12 06:33:16 --> URI Class Initialized
INFO - 2021-06-12 06:33:16 --> Router Class Initialized
INFO - 2021-06-12 06:33:16 --> Output Class Initialized
INFO - 2021-06-12 06:33:16 --> Security Class Initialized
DEBUG - 2021-06-12 06:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:33:16 --> Input Class Initialized
INFO - 2021-06-12 06:33:16 --> Language Class Initialized
INFO - 2021-06-12 06:33:16 --> Language Class Initialized
INFO - 2021-06-12 06:33:16 --> Config Class Initialized
INFO - 2021-06-12 06:33:16 --> Loader Class Initialized
INFO - 2021-06-12 06:33:16 --> Helper loaded: url_helper
INFO - 2021-06-12 06:33:16 --> Helper loaded: file_helper
INFO - 2021-06-12 06:33:16 --> Helper loaded: form_helper
INFO - 2021-06-12 06:33:16 --> Helper loaded: my_helper
INFO - 2021-06-12 06:33:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:33:16 --> Controller Class Initialized
INFO - 2021-06-12 06:33:18 --> Config Class Initialized
INFO - 2021-06-12 06:33:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:33:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:33:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:33:18 --> URI Class Initialized
INFO - 2021-06-12 06:33:18 --> Router Class Initialized
INFO - 2021-06-12 06:33:18 --> Output Class Initialized
INFO - 2021-06-12 06:33:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:33:18 --> Input Class Initialized
INFO - 2021-06-12 06:33:18 --> Language Class Initialized
INFO - 2021-06-12 06:33:18 --> Language Class Initialized
INFO - 2021-06-12 06:33:18 --> Config Class Initialized
INFO - 2021-06-12 06:33:18 --> Loader Class Initialized
INFO - 2021-06-12 06:33:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:33:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:33:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:33:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:33:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:33:18 --> Controller Class Initialized
DEBUG - 2021-06-12 06:33:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:33:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:33:18 --> Final output sent to browser
DEBUG - 2021-06-12 06:33:18 --> Total execution time: 0.0441
INFO - 2021-06-12 06:33:20 --> Config Class Initialized
INFO - 2021-06-12 06:33:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:33:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:33:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:33:20 --> URI Class Initialized
INFO - 2021-06-12 06:33:20 --> Router Class Initialized
INFO - 2021-06-12 06:33:20 --> Output Class Initialized
INFO - 2021-06-12 06:33:20 --> Security Class Initialized
DEBUG - 2021-06-12 06:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:33:20 --> Input Class Initialized
INFO - 2021-06-12 06:33:20 --> Language Class Initialized
INFO - 2021-06-12 06:33:20 --> Language Class Initialized
INFO - 2021-06-12 06:33:20 --> Config Class Initialized
INFO - 2021-06-12 06:33:20 --> Loader Class Initialized
INFO - 2021-06-12 06:33:20 --> Helper loaded: url_helper
INFO - 2021-06-12 06:33:20 --> Helper loaded: file_helper
INFO - 2021-06-12 06:33:20 --> Helper loaded: form_helper
INFO - 2021-06-12 06:33:20 --> Helper loaded: my_helper
INFO - 2021-06-12 06:33:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:33:20 --> Controller Class Initialized
INFO - 2021-06-12 06:33:57 --> Config Class Initialized
INFO - 2021-06-12 06:33:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:33:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:33:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:33:57 --> URI Class Initialized
INFO - 2021-06-12 06:33:57 --> Router Class Initialized
INFO - 2021-06-12 06:33:57 --> Output Class Initialized
INFO - 2021-06-12 06:33:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:33:57 --> Input Class Initialized
INFO - 2021-06-12 06:33:57 --> Language Class Initialized
INFO - 2021-06-12 06:33:57 --> Language Class Initialized
INFO - 2021-06-12 06:33:57 --> Config Class Initialized
INFO - 2021-06-12 06:33:57 --> Loader Class Initialized
INFO - 2021-06-12 06:33:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:33:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:33:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:33:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:33:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:33:57 --> Controller Class Initialized
INFO - 2021-06-12 06:34:17 --> Config Class Initialized
INFO - 2021-06-12 06:34:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:34:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:34:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:34:17 --> URI Class Initialized
INFO - 2021-06-12 06:34:17 --> Router Class Initialized
INFO - 2021-06-12 06:34:17 --> Output Class Initialized
INFO - 2021-06-12 06:34:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:34:17 --> Input Class Initialized
INFO - 2021-06-12 06:34:17 --> Language Class Initialized
INFO - 2021-06-12 06:34:17 --> Language Class Initialized
INFO - 2021-06-12 06:34:17 --> Config Class Initialized
INFO - 2021-06-12 06:34:17 --> Loader Class Initialized
INFO - 2021-06-12 06:34:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:34:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:34:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:34:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:34:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:34:17 --> Controller Class Initialized
DEBUG - 2021-06-12 06:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:34:17 --> Final output sent to browser
DEBUG - 2021-06-12 06:34:17 --> Total execution time: 0.0442
INFO - 2021-06-12 06:34:17 --> Config Class Initialized
INFO - 2021-06-12 06:34:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:34:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:34:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:34:17 --> URI Class Initialized
INFO - 2021-06-12 06:34:17 --> Router Class Initialized
INFO - 2021-06-12 06:34:17 --> Output Class Initialized
INFO - 2021-06-12 06:34:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:34:17 --> Input Class Initialized
INFO - 2021-06-12 06:34:17 --> Language Class Initialized
INFO - 2021-06-12 06:34:17 --> Language Class Initialized
INFO - 2021-06-12 06:34:17 --> Config Class Initialized
INFO - 2021-06-12 06:34:17 --> Loader Class Initialized
INFO - 2021-06-12 06:34:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:34:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:34:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:34:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:34:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:34:17 --> Controller Class Initialized
INFO - 2021-06-12 06:34:19 --> Config Class Initialized
INFO - 2021-06-12 06:34:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:34:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:34:19 --> Utf8 Class Initialized
INFO - 2021-06-12 06:34:19 --> URI Class Initialized
INFO - 2021-06-12 06:34:19 --> Router Class Initialized
INFO - 2021-06-12 06:34:19 --> Output Class Initialized
INFO - 2021-06-12 06:34:19 --> Security Class Initialized
DEBUG - 2021-06-12 06:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:34:19 --> Input Class Initialized
INFO - 2021-06-12 06:34:19 --> Language Class Initialized
INFO - 2021-06-12 06:34:19 --> Language Class Initialized
INFO - 2021-06-12 06:34:19 --> Config Class Initialized
INFO - 2021-06-12 06:34:19 --> Loader Class Initialized
INFO - 2021-06-12 06:34:19 --> Helper loaded: url_helper
INFO - 2021-06-12 06:34:19 --> Helper loaded: file_helper
INFO - 2021-06-12 06:34:19 --> Helper loaded: form_helper
INFO - 2021-06-12 06:34:19 --> Helper loaded: my_helper
INFO - 2021-06-12 06:34:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:34:19 --> Controller Class Initialized
DEBUG - 2021-06-12 06:34:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:34:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:34:19 --> Final output sent to browser
DEBUG - 2021-06-12 06:34:19 --> Total execution time: 0.0450
INFO - 2021-06-12 06:34:21 --> Config Class Initialized
INFO - 2021-06-12 06:34:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:34:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:34:21 --> Utf8 Class Initialized
INFO - 2021-06-12 06:34:21 --> URI Class Initialized
INFO - 2021-06-12 06:34:21 --> Router Class Initialized
INFO - 2021-06-12 06:34:21 --> Output Class Initialized
INFO - 2021-06-12 06:34:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:34:21 --> Input Class Initialized
INFO - 2021-06-12 06:34:21 --> Language Class Initialized
INFO - 2021-06-12 06:34:21 --> Language Class Initialized
INFO - 2021-06-12 06:34:21 --> Config Class Initialized
INFO - 2021-06-12 06:34:21 --> Loader Class Initialized
INFO - 2021-06-12 06:34:21 --> Helper loaded: url_helper
INFO - 2021-06-12 06:34:21 --> Helper loaded: file_helper
INFO - 2021-06-12 06:34:21 --> Helper loaded: form_helper
INFO - 2021-06-12 06:34:21 --> Helper loaded: my_helper
INFO - 2021-06-12 06:34:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:34:21 --> Controller Class Initialized
INFO - 2021-06-12 06:34:44 --> Config Class Initialized
INFO - 2021-06-12 06:34:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:34:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:34:44 --> Utf8 Class Initialized
INFO - 2021-06-12 06:34:44 --> URI Class Initialized
INFO - 2021-06-12 06:34:44 --> Router Class Initialized
INFO - 2021-06-12 06:34:44 --> Output Class Initialized
INFO - 2021-06-12 06:34:44 --> Security Class Initialized
DEBUG - 2021-06-12 06:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:34:44 --> Input Class Initialized
INFO - 2021-06-12 06:34:44 --> Language Class Initialized
INFO - 2021-06-12 06:34:44 --> Language Class Initialized
INFO - 2021-06-12 06:34:44 --> Config Class Initialized
INFO - 2021-06-12 06:34:44 --> Loader Class Initialized
INFO - 2021-06-12 06:34:44 --> Helper loaded: url_helper
INFO - 2021-06-12 06:34:44 --> Helper loaded: file_helper
INFO - 2021-06-12 06:34:44 --> Helper loaded: form_helper
INFO - 2021-06-12 06:34:44 --> Helper loaded: my_helper
INFO - 2021-06-12 06:34:44 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:34:44 --> Controller Class Initialized
INFO - 2021-06-12 06:35:32 --> Config Class Initialized
INFO - 2021-06-12 06:35:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:35:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:35:32 --> Utf8 Class Initialized
INFO - 2021-06-12 06:35:32 --> URI Class Initialized
INFO - 2021-06-12 06:35:32 --> Router Class Initialized
INFO - 2021-06-12 06:35:32 --> Output Class Initialized
INFO - 2021-06-12 06:35:32 --> Security Class Initialized
DEBUG - 2021-06-12 06:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:35:32 --> Input Class Initialized
INFO - 2021-06-12 06:35:32 --> Language Class Initialized
INFO - 2021-06-12 06:35:32 --> Language Class Initialized
INFO - 2021-06-12 06:35:32 --> Config Class Initialized
INFO - 2021-06-12 06:35:32 --> Loader Class Initialized
INFO - 2021-06-12 06:35:32 --> Helper loaded: url_helper
INFO - 2021-06-12 06:35:32 --> Helper loaded: file_helper
INFO - 2021-06-12 06:35:32 --> Helper loaded: form_helper
INFO - 2021-06-12 06:35:32 --> Helper loaded: my_helper
INFO - 2021-06-12 06:35:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:35:32 --> Controller Class Initialized
INFO - 2021-06-12 06:35:32 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:35:32 --> Config Class Initialized
INFO - 2021-06-12 06:35:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:35:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:35:32 --> Utf8 Class Initialized
INFO - 2021-06-12 06:35:32 --> URI Class Initialized
INFO - 2021-06-12 06:35:32 --> Router Class Initialized
INFO - 2021-06-12 06:35:32 --> Output Class Initialized
INFO - 2021-06-12 06:35:32 --> Security Class Initialized
DEBUG - 2021-06-12 06:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:35:32 --> Input Class Initialized
INFO - 2021-06-12 06:35:32 --> Language Class Initialized
INFO - 2021-06-12 06:35:32 --> Language Class Initialized
INFO - 2021-06-12 06:35:32 --> Config Class Initialized
INFO - 2021-06-12 06:35:32 --> Loader Class Initialized
INFO - 2021-06-12 06:35:32 --> Helper loaded: url_helper
INFO - 2021-06-12 06:35:32 --> Helper loaded: file_helper
INFO - 2021-06-12 06:35:32 --> Helper loaded: form_helper
INFO - 2021-06-12 06:35:32 --> Helper loaded: my_helper
INFO - 2021-06-12 06:35:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:35:32 --> Controller Class Initialized
DEBUG - 2021-06-12 06:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:35:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:35:32 --> Final output sent to browser
DEBUG - 2021-06-12 06:35:32 --> Total execution time: 0.0547
INFO - 2021-06-12 06:35:41 --> Config Class Initialized
INFO - 2021-06-12 06:35:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:35:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:35:41 --> Utf8 Class Initialized
INFO - 2021-06-12 06:35:41 --> URI Class Initialized
INFO - 2021-06-12 06:35:41 --> Router Class Initialized
INFO - 2021-06-12 06:35:41 --> Output Class Initialized
INFO - 2021-06-12 06:35:41 --> Security Class Initialized
DEBUG - 2021-06-12 06:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:35:41 --> Input Class Initialized
INFO - 2021-06-12 06:35:41 --> Language Class Initialized
INFO - 2021-06-12 06:35:41 --> Language Class Initialized
INFO - 2021-06-12 06:35:41 --> Config Class Initialized
INFO - 2021-06-12 06:35:41 --> Loader Class Initialized
INFO - 2021-06-12 06:35:41 --> Helper loaded: url_helper
INFO - 2021-06-12 06:35:41 --> Helper loaded: file_helper
INFO - 2021-06-12 06:35:41 --> Helper loaded: form_helper
INFO - 2021-06-12 06:35:41 --> Helper loaded: my_helper
INFO - 2021-06-12 06:35:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:35:41 --> Controller Class Initialized
INFO - 2021-06-12 06:35:41 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:35:41 --> Final output sent to browser
DEBUG - 2021-06-12 06:35:41 --> Total execution time: 0.0520
INFO - 2021-06-12 06:35:42 --> Config Class Initialized
INFO - 2021-06-12 06:35:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:35:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:35:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:35:42 --> URI Class Initialized
INFO - 2021-06-12 06:35:42 --> Router Class Initialized
INFO - 2021-06-12 06:35:42 --> Output Class Initialized
INFO - 2021-06-12 06:35:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:35:42 --> Input Class Initialized
INFO - 2021-06-12 06:35:42 --> Language Class Initialized
INFO - 2021-06-12 06:35:42 --> Language Class Initialized
INFO - 2021-06-12 06:35:42 --> Config Class Initialized
INFO - 2021-06-12 06:35:42 --> Loader Class Initialized
INFO - 2021-06-12 06:35:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:35:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:35:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:35:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:35:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:35:42 --> Controller Class Initialized
DEBUG - 2021-06-12 06:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:35:42 --> Final output sent to browser
DEBUG - 2021-06-12 06:35:42 --> Total execution time: 0.1424
INFO - 2021-06-12 06:35:47 --> Config Class Initialized
INFO - 2021-06-12 06:35:47 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:35:47 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:35:47 --> Utf8 Class Initialized
INFO - 2021-06-12 06:35:47 --> URI Class Initialized
INFO - 2021-06-12 06:35:47 --> Router Class Initialized
INFO - 2021-06-12 06:35:47 --> Output Class Initialized
INFO - 2021-06-12 06:35:47 --> Security Class Initialized
DEBUG - 2021-06-12 06:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:35:47 --> Input Class Initialized
INFO - 2021-06-12 06:35:47 --> Language Class Initialized
INFO - 2021-06-12 06:35:47 --> Language Class Initialized
INFO - 2021-06-12 06:35:47 --> Config Class Initialized
INFO - 2021-06-12 06:35:47 --> Loader Class Initialized
INFO - 2021-06-12 06:35:47 --> Helper loaded: url_helper
INFO - 2021-06-12 06:35:47 --> Helper loaded: file_helper
INFO - 2021-06-12 06:35:47 --> Helper loaded: form_helper
INFO - 2021-06-12 06:35:47 --> Helper loaded: my_helper
INFO - 2021-06-12 06:35:47 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:35:47 --> Controller Class Initialized
DEBUG - 2021-06-12 06:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:35:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:35:47 --> Final output sent to browser
DEBUG - 2021-06-12 06:35:47 --> Total execution time: 0.0792
INFO - 2021-06-12 06:36:04 --> Config Class Initialized
INFO - 2021-06-12 06:36:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:36:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:36:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:36:04 --> URI Class Initialized
INFO - 2021-06-12 06:36:04 --> Router Class Initialized
INFO - 2021-06-12 06:36:04 --> Output Class Initialized
INFO - 2021-06-12 06:36:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:36:04 --> Input Class Initialized
INFO - 2021-06-12 06:36:04 --> Language Class Initialized
INFO - 2021-06-12 06:36:04 --> Language Class Initialized
INFO - 2021-06-12 06:36:04 --> Config Class Initialized
INFO - 2021-06-12 06:36:04 --> Loader Class Initialized
INFO - 2021-06-12 06:36:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:36:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:36:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:36:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:36:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:36:04 --> Controller Class Initialized
DEBUG - 2021-06-12 06:36:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:36:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:36:04 --> Final output sent to browser
DEBUG - 2021-06-12 06:36:04 --> Total execution time: 0.0448
INFO - 2021-06-12 06:36:04 --> Config Class Initialized
INFO - 2021-06-12 06:36:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:36:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:36:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:36:04 --> URI Class Initialized
INFO - 2021-06-12 06:36:04 --> Router Class Initialized
INFO - 2021-06-12 06:36:04 --> Output Class Initialized
INFO - 2021-06-12 06:36:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:36:04 --> Input Class Initialized
INFO - 2021-06-12 06:36:04 --> Language Class Initialized
INFO - 2021-06-12 06:36:04 --> Language Class Initialized
INFO - 2021-06-12 06:36:04 --> Config Class Initialized
INFO - 2021-06-12 06:36:04 --> Loader Class Initialized
INFO - 2021-06-12 06:36:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:36:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:36:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:36:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:36:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:36:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:36:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:36:04 --> Controller Class Initialized
INFO - 2021-06-12 06:36:05 --> Config Class Initialized
INFO - 2021-06-12 06:36:05 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:36:05 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:36:05 --> Utf8 Class Initialized
INFO - 2021-06-12 06:36:05 --> URI Class Initialized
INFO - 2021-06-12 06:36:05 --> Router Class Initialized
INFO - 2021-06-12 06:36:05 --> Output Class Initialized
INFO - 2021-06-12 06:36:05 --> Security Class Initialized
DEBUG - 2021-06-12 06:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:36:05 --> Input Class Initialized
INFO - 2021-06-12 06:36:05 --> Language Class Initialized
INFO - 2021-06-12 06:36:05 --> Language Class Initialized
INFO - 2021-06-12 06:36:05 --> Config Class Initialized
INFO - 2021-06-12 06:36:05 --> Loader Class Initialized
INFO - 2021-06-12 06:36:05 --> Helper loaded: url_helper
INFO - 2021-06-12 06:36:05 --> Helper loaded: file_helper
INFO - 2021-06-12 06:36:05 --> Helper loaded: form_helper
INFO - 2021-06-12 06:36:05 --> Helper loaded: my_helper
INFO - 2021-06-12 06:36:05 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:36:05 --> Controller Class Initialized
DEBUG - 2021-06-12 06:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:36:05 --> Final output sent to browser
DEBUG - 2021-06-12 06:36:05 --> Total execution time: 0.0449
INFO - 2021-06-12 06:36:18 --> Config Class Initialized
INFO - 2021-06-12 06:36:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:36:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:36:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:36:18 --> URI Class Initialized
INFO - 2021-06-12 06:36:18 --> Router Class Initialized
INFO - 2021-06-12 06:36:18 --> Output Class Initialized
INFO - 2021-06-12 06:36:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:36:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:36:18 --> Input Class Initialized
INFO - 2021-06-12 06:36:18 --> Language Class Initialized
INFO - 2021-06-12 06:36:18 --> Language Class Initialized
INFO - 2021-06-12 06:36:18 --> Config Class Initialized
INFO - 2021-06-12 06:36:18 --> Loader Class Initialized
INFO - 2021-06-12 06:36:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:36:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:36:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:36:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:36:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:36:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:36:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:36:18 --> Controller Class Initialized
INFO - 2021-06-12 06:37:02 --> Config Class Initialized
INFO - 2021-06-12 06:37:02 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:37:02 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:37:02 --> Utf8 Class Initialized
INFO - 2021-06-12 06:37:02 --> URI Class Initialized
INFO - 2021-06-12 06:37:02 --> Router Class Initialized
INFO - 2021-06-12 06:37:02 --> Output Class Initialized
INFO - 2021-06-12 06:37:02 --> Security Class Initialized
DEBUG - 2021-06-12 06:37:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:37:02 --> Input Class Initialized
INFO - 2021-06-12 06:37:02 --> Language Class Initialized
INFO - 2021-06-12 06:37:02 --> Language Class Initialized
INFO - 2021-06-12 06:37:02 --> Config Class Initialized
INFO - 2021-06-12 06:37:02 --> Loader Class Initialized
INFO - 2021-06-12 06:37:02 --> Helper loaded: url_helper
INFO - 2021-06-12 06:37:02 --> Helper loaded: file_helper
INFO - 2021-06-12 06:37:02 --> Helper loaded: form_helper
INFO - 2021-06-12 06:37:02 --> Helper loaded: my_helper
INFO - 2021-06-12 06:37:02 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:37:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:37:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:37:02 --> Controller Class Initialized
INFO - 2021-06-12 06:37:19 --> Config Class Initialized
INFO - 2021-06-12 06:37:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:37:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:37:19 --> Utf8 Class Initialized
INFO - 2021-06-12 06:37:19 --> URI Class Initialized
INFO - 2021-06-12 06:37:19 --> Router Class Initialized
INFO - 2021-06-12 06:37:19 --> Output Class Initialized
INFO - 2021-06-12 06:37:19 --> Security Class Initialized
DEBUG - 2021-06-12 06:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:37:19 --> Input Class Initialized
INFO - 2021-06-12 06:37:19 --> Language Class Initialized
INFO - 2021-06-12 06:37:19 --> Language Class Initialized
INFO - 2021-06-12 06:37:19 --> Config Class Initialized
INFO - 2021-06-12 06:37:19 --> Loader Class Initialized
INFO - 2021-06-12 06:37:19 --> Helper loaded: url_helper
INFO - 2021-06-12 06:37:19 --> Helper loaded: file_helper
INFO - 2021-06-12 06:37:19 --> Helper loaded: form_helper
INFO - 2021-06-12 06:37:19 --> Helper loaded: my_helper
INFO - 2021-06-12 06:37:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:37:19 --> Controller Class Initialized
DEBUG - 2021-06-12 06:37:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:37:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:37:19 --> Final output sent to browser
DEBUG - 2021-06-12 06:37:19 --> Total execution time: 0.0457
INFO - 2021-06-12 06:37:20 --> Config Class Initialized
INFO - 2021-06-12 06:37:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:37:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:37:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:37:20 --> URI Class Initialized
INFO - 2021-06-12 06:37:20 --> Router Class Initialized
INFO - 2021-06-12 06:37:20 --> Output Class Initialized
INFO - 2021-06-12 06:37:20 --> Security Class Initialized
DEBUG - 2021-06-12 06:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:37:20 --> Input Class Initialized
INFO - 2021-06-12 06:37:20 --> Language Class Initialized
INFO - 2021-06-12 06:37:20 --> Language Class Initialized
INFO - 2021-06-12 06:37:20 --> Config Class Initialized
INFO - 2021-06-12 06:37:20 --> Loader Class Initialized
INFO - 2021-06-12 06:37:20 --> Helper loaded: url_helper
INFO - 2021-06-12 06:37:20 --> Helper loaded: file_helper
INFO - 2021-06-12 06:37:20 --> Helper loaded: form_helper
INFO - 2021-06-12 06:37:20 --> Helper loaded: my_helper
INFO - 2021-06-12 06:37:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:37:20 --> Controller Class Initialized
INFO - 2021-06-12 06:37:21 --> Config Class Initialized
INFO - 2021-06-12 06:37:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:37:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:37:21 --> Utf8 Class Initialized
INFO - 2021-06-12 06:37:21 --> URI Class Initialized
INFO - 2021-06-12 06:37:21 --> Router Class Initialized
INFO - 2021-06-12 06:37:21 --> Output Class Initialized
INFO - 2021-06-12 06:37:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:37:21 --> Input Class Initialized
INFO - 2021-06-12 06:37:21 --> Language Class Initialized
INFO - 2021-06-12 06:37:21 --> Language Class Initialized
INFO - 2021-06-12 06:37:21 --> Config Class Initialized
INFO - 2021-06-12 06:37:21 --> Loader Class Initialized
INFO - 2021-06-12 06:37:21 --> Helper loaded: url_helper
INFO - 2021-06-12 06:37:21 --> Helper loaded: file_helper
INFO - 2021-06-12 06:37:21 --> Helper loaded: form_helper
INFO - 2021-06-12 06:37:21 --> Helper loaded: my_helper
INFO - 2021-06-12 06:37:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:37:21 --> Controller Class Initialized
DEBUG - 2021-06-12 06:37:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:37:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:37:21 --> Final output sent to browser
DEBUG - 2021-06-12 06:37:21 --> Total execution time: 0.0447
INFO - 2021-06-12 06:37:23 --> Config Class Initialized
INFO - 2021-06-12 06:37:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:37:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:37:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:37:23 --> URI Class Initialized
INFO - 2021-06-12 06:37:23 --> Router Class Initialized
INFO - 2021-06-12 06:37:23 --> Output Class Initialized
INFO - 2021-06-12 06:37:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:37:23 --> Input Class Initialized
INFO - 2021-06-12 06:37:23 --> Language Class Initialized
INFO - 2021-06-12 06:37:23 --> Language Class Initialized
INFO - 2021-06-12 06:37:23 --> Config Class Initialized
INFO - 2021-06-12 06:37:23 --> Loader Class Initialized
INFO - 2021-06-12 06:37:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:37:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:37:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:37:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:37:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:37:24 --> Controller Class Initialized
INFO - 2021-06-12 06:37:45 --> Config Class Initialized
INFO - 2021-06-12 06:37:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:37:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:37:45 --> Utf8 Class Initialized
INFO - 2021-06-12 06:37:45 --> URI Class Initialized
INFO - 2021-06-12 06:37:45 --> Router Class Initialized
INFO - 2021-06-12 06:37:45 --> Output Class Initialized
INFO - 2021-06-12 06:37:45 --> Security Class Initialized
DEBUG - 2021-06-12 06:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:37:45 --> Input Class Initialized
INFO - 2021-06-12 06:37:45 --> Language Class Initialized
INFO - 2021-06-12 06:37:45 --> Language Class Initialized
INFO - 2021-06-12 06:37:45 --> Config Class Initialized
INFO - 2021-06-12 06:37:45 --> Loader Class Initialized
INFO - 2021-06-12 06:37:45 --> Helper loaded: url_helper
INFO - 2021-06-12 06:37:45 --> Helper loaded: file_helper
INFO - 2021-06-12 06:37:45 --> Helper loaded: form_helper
INFO - 2021-06-12 06:37:45 --> Helper loaded: my_helper
INFO - 2021-06-12 06:37:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:37:45 --> Controller Class Initialized
INFO - 2021-06-12 06:38:06 --> Config Class Initialized
INFO - 2021-06-12 06:38:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:06 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:06 --> URI Class Initialized
INFO - 2021-06-12 06:38:06 --> Router Class Initialized
INFO - 2021-06-12 06:38:06 --> Output Class Initialized
INFO - 2021-06-12 06:38:06 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:06 --> Input Class Initialized
INFO - 2021-06-12 06:38:06 --> Language Class Initialized
INFO - 2021-06-12 06:38:06 --> Language Class Initialized
INFO - 2021-06-12 06:38:06 --> Config Class Initialized
INFO - 2021-06-12 06:38:06 --> Loader Class Initialized
INFO - 2021-06-12 06:38:06 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:06 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:06 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:06 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:06 --> Controller Class Initialized
DEBUG - 2021-06-12 06:38:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:38:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:38:06 --> Final output sent to browser
DEBUG - 2021-06-12 06:38:06 --> Total execution time: 0.0453
INFO - 2021-06-12 06:38:06 --> Config Class Initialized
INFO - 2021-06-12 06:38:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:06 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:06 --> URI Class Initialized
INFO - 2021-06-12 06:38:06 --> Router Class Initialized
INFO - 2021-06-12 06:38:06 --> Output Class Initialized
INFO - 2021-06-12 06:38:06 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:06 --> Input Class Initialized
INFO - 2021-06-12 06:38:06 --> Language Class Initialized
INFO - 2021-06-12 06:38:06 --> Language Class Initialized
INFO - 2021-06-12 06:38:06 --> Config Class Initialized
INFO - 2021-06-12 06:38:06 --> Loader Class Initialized
INFO - 2021-06-12 06:38:06 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:06 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:06 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:06 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:06 --> Controller Class Initialized
INFO - 2021-06-12 06:38:07 --> Config Class Initialized
INFO - 2021-06-12 06:38:07 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:07 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:07 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:07 --> URI Class Initialized
INFO - 2021-06-12 06:38:07 --> Router Class Initialized
INFO - 2021-06-12 06:38:07 --> Output Class Initialized
INFO - 2021-06-12 06:38:07 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:07 --> Input Class Initialized
INFO - 2021-06-12 06:38:07 --> Language Class Initialized
INFO - 2021-06-12 06:38:07 --> Language Class Initialized
INFO - 2021-06-12 06:38:07 --> Config Class Initialized
INFO - 2021-06-12 06:38:07 --> Loader Class Initialized
INFO - 2021-06-12 06:38:07 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:07 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:07 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:07 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:07 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:07 --> Controller Class Initialized
DEBUG - 2021-06-12 06:38:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:38:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:38:07 --> Final output sent to browser
DEBUG - 2021-06-12 06:38:07 --> Total execution time: 0.0459
INFO - 2021-06-12 06:38:09 --> Config Class Initialized
INFO - 2021-06-12 06:38:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:09 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:09 --> URI Class Initialized
INFO - 2021-06-12 06:38:09 --> Router Class Initialized
INFO - 2021-06-12 06:38:09 --> Output Class Initialized
INFO - 2021-06-12 06:38:09 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:09 --> Input Class Initialized
INFO - 2021-06-12 06:38:09 --> Language Class Initialized
INFO - 2021-06-12 06:38:09 --> Language Class Initialized
INFO - 2021-06-12 06:38:09 --> Config Class Initialized
INFO - 2021-06-12 06:38:09 --> Loader Class Initialized
INFO - 2021-06-12 06:38:09 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:09 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:09 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:09 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:09 --> Controller Class Initialized
INFO - 2021-06-12 06:38:35 --> Config Class Initialized
INFO - 2021-06-12 06:38:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:35 --> URI Class Initialized
INFO - 2021-06-12 06:38:35 --> Router Class Initialized
INFO - 2021-06-12 06:38:35 --> Output Class Initialized
INFO - 2021-06-12 06:38:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:35 --> Input Class Initialized
INFO - 2021-06-12 06:38:35 --> Language Class Initialized
INFO - 2021-06-12 06:38:35 --> Language Class Initialized
INFO - 2021-06-12 06:38:35 --> Config Class Initialized
INFO - 2021-06-12 06:38:35 --> Loader Class Initialized
INFO - 2021-06-12 06:38:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:35 --> Controller Class Initialized
INFO - 2021-06-12 06:38:56 --> Config Class Initialized
INFO - 2021-06-12 06:38:56 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:56 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:56 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:56 --> URI Class Initialized
INFO - 2021-06-12 06:38:56 --> Router Class Initialized
INFO - 2021-06-12 06:38:56 --> Output Class Initialized
INFO - 2021-06-12 06:38:56 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:56 --> Input Class Initialized
INFO - 2021-06-12 06:38:56 --> Language Class Initialized
INFO - 2021-06-12 06:38:56 --> Language Class Initialized
INFO - 2021-06-12 06:38:56 --> Config Class Initialized
INFO - 2021-06-12 06:38:56 --> Loader Class Initialized
INFO - 2021-06-12 06:38:56 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:56 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:56 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:56 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:56 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:56 --> Controller Class Initialized
DEBUG - 2021-06-12 06:38:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:38:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:38:56 --> Final output sent to browser
DEBUG - 2021-06-12 06:38:56 --> Total execution time: 0.0448
INFO - 2021-06-12 06:38:56 --> Config Class Initialized
INFO - 2021-06-12 06:38:56 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:56 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:56 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:56 --> URI Class Initialized
INFO - 2021-06-12 06:38:56 --> Router Class Initialized
INFO - 2021-06-12 06:38:56 --> Output Class Initialized
INFO - 2021-06-12 06:38:56 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:56 --> Input Class Initialized
INFO - 2021-06-12 06:38:56 --> Language Class Initialized
INFO - 2021-06-12 06:38:56 --> Language Class Initialized
INFO - 2021-06-12 06:38:56 --> Config Class Initialized
INFO - 2021-06-12 06:38:56 --> Loader Class Initialized
INFO - 2021-06-12 06:38:56 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:56 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:56 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:56 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:56 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:56 --> Controller Class Initialized
INFO - 2021-06-12 06:38:57 --> Config Class Initialized
INFO - 2021-06-12 06:38:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:57 --> URI Class Initialized
INFO - 2021-06-12 06:38:57 --> Router Class Initialized
INFO - 2021-06-12 06:38:57 --> Output Class Initialized
INFO - 2021-06-12 06:38:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:57 --> Input Class Initialized
INFO - 2021-06-12 06:38:57 --> Language Class Initialized
INFO - 2021-06-12 06:38:57 --> Language Class Initialized
INFO - 2021-06-12 06:38:57 --> Config Class Initialized
INFO - 2021-06-12 06:38:57 --> Loader Class Initialized
INFO - 2021-06-12 06:38:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:57 --> Controller Class Initialized
DEBUG - 2021-06-12 06:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:38:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:38:57 --> Final output sent to browser
DEBUG - 2021-06-12 06:38:57 --> Total execution time: 0.0444
INFO - 2021-06-12 06:38:59 --> Config Class Initialized
INFO - 2021-06-12 06:38:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:38:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:38:59 --> Utf8 Class Initialized
INFO - 2021-06-12 06:38:59 --> URI Class Initialized
INFO - 2021-06-12 06:38:59 --> Router Class Initialized
INFO - 2021-06-12 06:38:59 --> Output Class Initialized
INFO - 2021-06-12 06:38:59 --> Security Class Initialized
DEBUG - 2021-06-12 06:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:38:59 --> Input Class Initialized
INFO - 2021-06-12 06:38:59 --> Language Class Initialized
INFO - 2021-06-12 06:38:59 --> Language Class Initialized
INFO - 2021-06-12 06:38:59 --> Config Class Initialized
INFO - 2021-06-12 06:38:59 --> Loader Class Initialized
INFO - 2021-06-12 06:38:59 --> Helper loaded: url_helper
INFO - 2021-06-12 06:38:59 --> Helper loaded: file_helper
INFO - 2021-06-12 06:38:59 --> Helper loaded: form_helper
INFO - 2021-06-12 06:38:59 --> Helper loaded: my_helper
INFO - 2021-06-12 06:38:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:38:59 --> Controller Class Initialized
INFO - 2021-06-12 06:39:25 --> Config Class Initialized
INFO - 2021-06-12 06:39:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:39:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:39:25 --> Utf8 Class Initialized
INFO - 2021-06-12 06:39:25 --> URI Class Initialized
INFO - 2021-06-12 06:39:25 --> Router Class Initialized
INFO - 2021-06-12 06:39:25 --> Output Class Initialized
INFO - 2021-06-12 06:39:25 --> Security Class Initialized
DEBUG - 2021-06-12 06:39:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:39:25 --> Input Class Initialized
INFO - 2021-06-12 06:39:25 --> Language Class Initialized
INFO - 2021-06-12 06:39:25 --> Language Class Initialized
INFO - 2021-06-12 06:39:25 --> Config Class Initialized
INFO - 2021-06-12 06:39:25 --> Loader Class Initialized
INFO - 2021-06-12 06:39:25 --> Helper loaded: url_helper
INFO - 2021-06-12 06:39:25 --> Helper loaded: file_helper
INFO - 2021-06-12 06:39:25 --> Helper loaded: form_helper
INFO - 2021-06-12 06:39:25 --> Helper loaded: my_helper
INFO - 2021-06-12 06:39:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:39:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:39:25 --> Controller Class Initialized
INFO - 2021-06-12 06:39:42 --> Config Class Initialized
INFO - 2021-06-12 06:39:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:39:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:39:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:39:42 --> URI Class Initialized
INFO - 2021-06-12 06:39:42 --> Router Class Initialized
INFO - 2021-06-12 06:39:42 --> Output Class Initialized
INFO - 2021-06-12 06:39:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:39:42 --> Input Class Initialized
INFO - 2021-06-12 06:39:42 --> Language Class Initialized
INFO - 2021-06-12 06:39:42 --> Language Class Initialized
INFO - 2021-06-12 06:39:42 --> Config Class Initialized
INFO - 2021-06-12 06:39:42 --> Loader Class Initialized
INFO - 2021-06-12 06:39:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:39:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:39:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:39:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:39:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:39:42 --> Controller Class Initialized
DEBUG - 2021-06-12 06:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:39:42 --> Final output sent to browser
DEBUG - 2021-06-12 06:39:42 --> Total execution time: 0.0454
INFO - 2021-06-12 06:39:42 --> Config Class Initialized
INFO - 2021-06-12 06:39:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:39:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:39:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:39:42 --> URI Class Initialized
INFO - 2021-06-12 06:39:42 --> Router Class Initialized
INFO - 2021-06-12 06:39:42 --> Output Class Initialized
INFO - 2021-06-12 06:39:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:39:42 --> Input Class Initialized
INFO - 2021-06-12 06:39:42 --> Language Class Initialized
INFO - 2021-06-12 06:39:42 --> Language Class Initialized
INFO - 2021-06-12 06:39:42 --> Config Class Initialized
INFO - 2021-06-12 06:39:42 --> Loader Class Initialized
INFO - 2021-06-12 06:39:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:39:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:39:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:39:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:39:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:39:42 --> Controller Class Initialized
INFO - 2021-06-12 06:39:44 --> Config Class Initialized
INFO - 2021-06-12 06:39:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:39:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:39:44 --> Utf8 Class Initialized
INFO - 2021-06-12 06:39:44 --> URI Class Initialized
INFO - 2021-06-12 06:39:44 --> Router Class Initialized
INFO - 2021-06-12 06:39:44 --> Output Class Initialized
INFO - 2021-06-12 06:39:44 --> Security Class Initialized
DEBUG - 2021-06-12 06:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:39:44 --> Input Class Initialized
INFO - 2021-06-12 06:39:44 --> Language Class Initialized
INFO - 2021-06-12 06:39:44 --> Language Class Initialized
INFO - 2021-06-12 06:39:44 --> Config Class Initialized
INFO - 2021-06-12 06:39:44 --> Loader Class Initialized
INFO - 2021-06-12 06:39:44 --> Helper loaded: url_helper
INFO - 2021-06-12 06:39:44 --> Helper loaded: file_helper
INFO - 2021-06-12 06:39:44 --> Helper loaded: form_helper
INFO - 2021-06-12 06:39:44 --> Helper loaded: my_helper
INFO - 2021-06-12 06:39:44 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:39:45 --> Controller Class Initialized
DEBUG - 2021-06-12 06:39:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:39:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:39:45 --> Final output sent to browser
DEBUG - 2021-06-12 06:39:45 --> Total execution time: 0.0458
INFO - 2021-06-12 06:39:48 --> Config Class Initialized
INFO - 2021-06-12 06:39:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:39:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:39:48 --> Utf8 Class Initialized
INFO - 2021-06-12 06:39:48 --> URI Class Initialized
INFO - 2021-06-12 06:39:48 --> Router Class Initialized
INFO - 2021-06-12 06:39:48 --> Output Class Initialized
INFO - 2021-06-12 06:39:48 --> Security Class Initialized
DEBUG - 2021-06-12 06:39:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:39:48 --> Input Class Initialized
INFO - 2021-06-12 06:39:48 --> Language Class Initialized
INFO - 2021-06-12 06:39:48 --> Language Class Initialized
INFO - 2021-06-12 06:39:48 --> Config Class Initialized
INFO - 2021-06-12 06:39:48 --> Loader Class Initialized
INFO - 2021-06-12 06:39:48 --> Helper loaded: url_helper
INFO - 2021-06-12 06:39:48 --> Helper loaded: file_helper
INFO - 2021-06-12 06:39:48 --> Helper loaded: form_helper
INFO - 2021-06-12 06:39:48 --> Helper loaded: my_helper
INFO - 2021-06-12 06:39:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:39:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:39:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:39:48 --> Controller Class Initialized
INFO - 2021-06-12 06:40:10 --> Config Class Initialized
INFO - 2021-06-12 06:40:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:40:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:40:10 --> Utf8 Class Initialized
INFO - 2021-06-12 06:40:10 --> URI Class Initialized
INFO - 2021-06-12 06:40:10 --> Router Class Initialized
INFO - 2021-06-12 06:40:10 --> Output Class Initialized
INFO - 2021-06-12 06:40:10 --> Security Class Initialized
DEBUG - 2021-06-12 06:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:40:10 --> Input Class Initialized
INFO - 2021-06-12 06:40:10 --> Language Class Initialized
INFO - 2021-06-12 06:40:11 --> Language Class Initialized
INFO - 2021-06-12 06:40:11 --> Config Class Initialized
INFO - 2021-06-12 06:40:11 --> Loader Class Initialized
INFO - 2021-06-12 06:40:11 --> Helper loaded: url_helper
INFO - 2021-06-12 06:40:11 --> Helper loaded: file_helper
INFO - 2021-06-12 06:40:11 --> Helper loaded: form_helper
INFO - 2021-06-12 06:40:11 --> Helper loaded: my_helper
INFO - 2021-06-12 06:40:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:40:11 --> Controller Class Initialized
INFO - 2021-06-12 06:40:29 --> Config Class Initialized
INFO - 2021-06-12 06:40:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:40:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:40:29 --> Utf8 Class Initialized
INFO - 2021-06-12 06:40:29 --> URI Class Initialized
INFO - 2021-06-12 06:40:29 --> Router Class Initialized
INFO - 2021-06-12 06:40:29 --> Output Class Initialized
INFO - 2021-06-12 06:40:29 --> Security Class Initialized
DEBUG - 2021-06-12 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:40:29 --> Input Class Initialized
INFO - 2021-06-12 06:40:29 --> Language Class Initialized
INFO - 2021-06-12 06:40:29 --> Language Class Initialized
INFO - 2021-06-12 06:40:29 --> Config Class Initialized
INFO - 2021-06-12 06:40:29 --> Loader Class Initialized
INFO - 2021-06-12 06:40:29 --> Helper loaded: url_helper
INFO - 2021-06-12 06:40:29 --> Helper loaded: file_helper
INFO - 2021-06-12 06:40:29 --> Helper loaded: form_helper
INFO - 2021-06-12 06:40:29 --> Helper loaded: my_helper
INFO - 2021-06-12 06:40:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:40:29 --> Controller Class Initialized
DEBUG - 2021-06-12 06:40:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:40:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:40:29 --> Final output sent to browser
DEBUG - 2021-06-12 06:40:29 --> Total execution time: 0.0468
INFO - 2021-06-12 06:40:29 --> Config Class Initialized
INFO - 2021-06-12 06:40:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:40:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:40:29 --> Utf8 Class Initialized
INFO - 2021-06-12 06:40:29 --> URI Class Initialized
INFO - 2021-06-12 06:40:29 --> Router Class Initialized
INFO - 2021-06-12 06:40:29 --> Output Class Initialized
INFO - 2021-06-12 06:40:29 --> Security Class Initialized
DEBUG - 2021-06-12 06:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:40:29 --> Input Class Initialized
INFO - 2021-06-12 06:40:29 --> Language Class Initialized
INFO - 2021-06-12 06:40:29 --> Language Class Initialized
INFO - 2021-06-12 06:40:29 --> Config Class Initialized
INFO - 2021-06-12 06:40:29 --> Loader Class Initialized
INFO - 2021-06-12 06:40:29 --> Helper loaded: url_helper
INFO - 2021-06-12 06:40:29 --> Helper loaded: file_helper
INFO - 2021-06-12 06:40:29 --> Helper loaded: form_helper
INFO - 2021-06-12 06:40:29 --> Helper loaded: my_helper
INFO - 2021-06-12 06:40:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:40:29 --> Controller Class Initialized
INFO - 2021-06-12 06:40:33 --> Config Class Initialized
INFO - 2021-06-12 06:40:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:40:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:40:33 --> Utf8 Class Initialized
INFO - 2021-06-12 06:40:33 --> URI Class Initialized
INFO - 2021-06-12 06:40:33 --> Router Class Initialized
INFO - 2021-06-12 06:40:33 --> Output Class Initialized
INFO - 2021-06-12 06:40:33 --> Security Class Initialized
DEBUG - 2021-06-12 06:40:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:40:33 --> Input Class Initialized
INFO - 2021-06-12 06:40:33 --> Language Class Initialized
INFO - 2021-06-12 06:40:33 --> Language Class Initialized
INFO - 2021-06-12 06:40:33 --> Config Class Initialized
INFO - 2021-06-12 06:40:33 --> Loader Class Initialized
INFO - 2021-06-12 06:40:33 --> Helper loaded: url_helper
INFO - 2021-06-12 06:40:33 --> Helper loaded: file_helper
INFO - 2021-06-12 06:40:33 --> Helper loaded: form_helper
INFO - 2021-06-12 06:40:33 --> Helper loaded: my_helper
INFO - 2021-06-12 06:40:33 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:40:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:40:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:40:34 --> Controller Class Initialized
INFO - 2021-06-12 06:41:10 --> Config Class Initialized
INFO - 2021-06-12 06:41:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:41:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:41:10 --> Utf8 Class Initialized
INFO - 2021-06-12 06:41:10 --> URI Class Initialized
INFO - 2021-06-12 06:41:10 --> Router Class Initialized
INFO - 2021-06-12 06:41:10 --> Output Class Initialized
INFO - 2021-06-12 06:41:10 --> Security Class Initialized
DEBUG - 2021-06-12 06:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:41:10 --> Input Class Initialized
INFO - 2021-06-12 06:41:10 --> Language Class Initialized
INFO - 2021-06-12 06:41:10 --> Language Class Initialized
INFO - 2021-06-12 06:41:10 --> Config Class Initialized
INFO - 2021-06-12 06:41:10 --> Loader Class Initialized
INFO - 2021-06-12 06:41:10 --> Helper loaded: url_helper
INFO - 2021-06-12 06:41:10 --> Helper loaded: file_helper
INFO - 2021-06-12 06:41:10 --> Helper loaded: form_helper
INFO - 2021-06-12 06:41:10 --> Helper loaded: my_helper
INFO - 2021-06-12 06:41:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:41:10 --> Controller Class Initialized
DEBUG - 2021-06-12 06:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:41:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:41:10 --> Final output sent to browser
DEBUG - 2021-06-12 06:41:10 --> Total execution time: 0.0448
INFO - 2021-06-12 06:41:13 --> Config Class Initialized
INFO - 2021-06-12 06:41:13 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:41:13 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:41:13 --> Utf8 Class Initialized
INFO - 2021-06-12 06:41:13 --> URI Class Initialized
INFO - 2021-06-12 06:41:13 --> Router Class Initialized
INFO - 2021-06-12 06:41:13 --> Output Class Initialized
INFO - 2021-06-12 06:41:13 --> Security Class Initialized
DEBUG - 2021-06-12 06:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:41:13 --> Input Class Initialized
INFO - 2021-06-12 06:41:13 --> Language Class Initialized
INFO - 2021-06-12 06:41:13 --> Language Class Initialized
INFO - 2021-06-12 06:41:13 --> Config Class Initialized
INFO - 2021-06-12 06:41:13 --> Loader Class Initialized
INFO - 2021-06-12 06:41:13 --> Helper loaded: url_helper
INFO - 2021-06-12 06:41:13 --> Helper loaded: file_helper
INFO - 2021-06-12 06:41:13 --> Helper loaded: form_helper
INFO - 2021-06-12 06:41:13 --> Helper loaded: my_helper
INFO - 2021-06-12 06:41:13 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:41:13 --> Controller Class Initialized
INFO - 2021-06-12 06:41:36 --> Config Class Initialized
INFO - 2021-06-12 06:41:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:41:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:41:36 --> Utf8 Class Initialized
INFO - 2021-06-12 06:41:36 --> URI Class Initialized
INFO - 2021-06-12 06:41:36 --> Router Class Initialized
INFO - 2021-06-12 06:41:36 --> Output Class Initialized
INFO - 2021-06-12 06:41:36 --> Security Class Initialized
DEBUG - 2021-06-12 06:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:41:36 --> Input Class Initialized
INFO - 2021-06-12 06:41:36 --> Language Class Initialized
INFO - 2021-06-12 06:41:36 --> Language Class Initialized
INFO - 2021-06-12 06:41:36 --> Config Class Initialized
INFO - 2021-06-12 06:41:36 --> Loader Class Initialized
INFO - 2021-06-12 06:41:36 --> Helper loaded: url_helper
INFO - 2021-06-12 06:41:36 --> Helper loaded: file_helper
INFO - 2021-06-12 06:41:36 --> Helper loaded: form_helper
INFO - 2021-06-12 06:41:36 --> Helper loaded: my_helper
INFO - 2021-06-12 06:41:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:41:36 --> Controller Class Initialized
INFO - 2021-06-12 06:42:16 --> Config Class Initialized
INFO - 2021-06-12 06:42:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:42:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:42:16 --> Utf8 Class Initialized
INFO - 2021-06-12 06:42:16 --> URI Class Initialized
INFO - 2021-06-12 06:42:16 --> Router Class Initialized
INFO - 2021-06-12 06:42:16 --> Output Class Initialized
INFO - 2021-06-12 06:42:16 --> Security Class Initialized
DEBUG - 2021-06-12 06:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:42:16 --> Input Class Initialized
INFO - 2021-06-12 06:42:16 --> Language Class Initialized
INFO - 2021-06-12 06:42:16 --> Language Class Initialized
INFO - 2021-06-12 06:42:16 --> Config Class Initialized
INFO - 2021-06-12 06:42:16 --> Loader Class Initialized
INFO - 2021-06-12 06:42:16 --> Helper loaded: url_helper
INFO - 2021-06-12 06:42:16 --> Helper loaded: file_helper
INFO - 2021-06-12 06:42:16 --> Helper loaded: form_helper
INFO - 2021-06-12 06:42:16 --> Helper loaded: my_helper
INFO - 2021-06-12 06:42:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:42:16 --> Controller Class Initialized
DEBUG - 2021-06-12 06:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:42:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:42:16 --> Final output sent to browser
DEBUG - 2021-06-12 06:42:16 --> Total execution time: 0.0454
INFO - 2021-06-12 06:42:17 --> Config Class Initialized
INFO - 2021-06-12 06:42:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:42:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:42:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:42:17 --> URI Class Initialized
INFO - 2021-06-12 06:42:17 --> Router Class Initialized
INFO - 2021-06-12 06:42:17 --> Output Class Initialized
INFO - 2021-06-12 06:42:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:42:17 --> Input Class Initialized
INFO - 2021-06-12 06:42:17 --> Language Class Initialized
INFO - 2021-06-12 06:42:17 --> Language Class Initialized
INFO - 2021-06-12 06:42:17 --> Config Class Initialized
INFO - 2021-06-12 06:42:17 --> Loader Class Initialized
INFO - 2021-06-12 06:42:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:42:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:42:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:42:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:42:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:42:17 --> Controller Class Initialized
INFO - 2021-06-12 06:42:18 --> Config Class Initialized
INFO - 2021-06-12 06:42:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:42:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:42:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:42:18 --> URI Class Initialized
INFO - 2021-06-12 06:42:18 --> Router Class Initialized
INFO - 2021-06-12 06:42:18 --> Output Class Initialized
INFO - 2021-06-12 06:42:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:42:18 --> Input Class Initialized
INFO - 2021-06-12 06:42:18 --> Language Class Initialized
INFO - 2021-06-12 06:42:18 --> Language Class Initialized
INFO - 2021-06-12 06:42:18 --> Config Class Initialized
INFO - 2021-06-12 06:42:18 --> Loader Class Initialized
INFO - 2021-06-12 06:42:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:42:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:42:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:42:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:42:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:42:18 --> Controller Class Initialized
DEBUG - 2021-06-12 06:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:42:18 --> Final output sent to browser
DEBUG - 2021-06-12 06:42:18 --> Total execution time: 0.0440
INFO - 2021-06-12 06:42:20 --> Config Class Initialized
INFO - 2021-06-12 06:42:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:42:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:42:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:42:20 --> URI Class Initialized
INFO - 2021-06-12 06:42:20 --> Router Class Initialized
INFO - 2021-06-12 06:42:20 --> Output Class Initialized
INFO - 2021-06-12 06:42:20 --> Security Class Initialized
DEBUG - 2021-06-12 06:42:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:42:20 --> Input Class Initialized
INFO - 2021-06-12 06:42:20 --> Language Class Initialized
INFO - 2021-06-12 06:42:20 --> Language Class Initialized
INFO - 2021-06-12 06:42:20 --> Config Class Initialized
INFO - 2021-06-12 06:42:20 --> Loader Class Initialized
INFO - 2021-06-12 06:42:20 --> Helper loaded: url_helper
INFO - 2021-06-12 06:42:20 --> Helper loaded: file_helper
INFO - 2021-06-12 06:42:20 --> Helper loaded: form_helper
INFO - 2021-06-12 06:42:20 --> Helper loaded: my_helper
INFO - 2021-06-12 06:42:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:42:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:42:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:42:20 --> Controller Class Initialized
INFO - 2021-06-12 06:42:40 --> Config Class Initialized
INFO - 2021-06-12 06:42:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:42:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:42:40 --> Utf8 Class Initialized
INFO - 2021-06-12 06:42:40 --> URI Class Initialized
INFO - 2021-06-12 06:42:40 --> Router Class Initialized
INFO - 2021-06-12 06:42:40 --> Output Class Initialized
INFO - 2021-06-12 06:42:40 --> Security Class Initialized
DEBUG - 2021-06-12 06:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:42:40 --> Input Class Initialized
INFO - 2021-06-12 06:42:40 --> Language Class Initialized
INFO - 2021-06-12 06:42:40 --> Language Class Initialized
INFO - 2021-06-12 06:42:40 --> Config Class Initialized
INFO - 2021-06-12 06:42:40 --> Loader Class Initialized
INFO - 2021-06-12 06:42:40 --> Helper loaded: url_helper
INFO - 2021-06-12 06:42:40 --> Helper loaded: file_helper
INFO - 2021-06-12 06:42:40 --> Helper loaded: form_helper
INFO - 2021-06-12 06:42:40 --> Helper loaded: my_helper
INFO - 2021-06-12 06:42:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:42:40 --> Controller Class Initialized
INFO - 2021-06-12 06:43:01 --> Config Class Initialized
INFO - 2021-06-12 06:43:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:01 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:01 --> URI Class Initialized
INFO - 2021-06-12 06:43:01 --> Router Class Initialized
INFO - 2021-06-12 06:43:01 --> Output Class Initialized
INFO - 2021-06-12 06:43:01 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:01 --> Input Class Initialized
INFO - 2021-06-12 06:43:01 --> Language Class Initialized
INFO - 2021-06-12 06:43:01 --> Language Class Initialized
INFO - 2021-06-12 06:43:01 --> Config Class Initialized
INFO - 2021-06-12 06:43:01 --> Loader Class Initialized
INFO - 2021-06-12 06:43:02 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:02 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:02 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:02 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:02 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:02 --> Controller Class Initialized
DEBUG - 2021-06-12 06:43:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:43:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:43:02 --> Final output sent to browser
DEBUG - 2021-06-12 06:43:02 --> Total execution time: 0.0460
INFO - 2021-06-12 06:43:02 --> Config Class Initialized
INFO - 2021-06-12 06:43:02 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:02 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:02 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:02 --> URI Class Initialized
INFO - 2021-06-12 06:43:02 --> Router Class Initialized
INFO - 2021-06-12 06:43:02 --> Output Class Initialized
INFO - 2021-06-12 06:43:02 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:02 --> Input Class Initialized
INFO - 2021-06-12 06:43:02 --> Language Class Initialized
INFO - 2021-06-12 06:43:02 --> Language Class Initialized
INFO - 2021-06-12 06:43:02 --> Config Class Initialized
INFO - 2021-06-12 06:43:02 --> Loader Class Initialized
INFO - 2021-06-12 06:43:02 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:02 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:02 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:02 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:02 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:02 --> Controller Class Initialized
INFO - 2021-06-12 06:43:03 --> Config Class Initialized
INFO - 2021-06-12 06:43:03 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:03 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:03 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:03 --> URI Class Initialized
INFO - 2021-06-12 06:43:03 --> Router Class Initialized
INFO - 2021-06-12 06:43:03 --> Output Class Initialized
INFO - 2021-06-12 06:43:03 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:03 --> Input Class Initialized
INFO - 2021-06-12 06:43:03 --> Language Class Initialized
INFO - 2021-06-12 06:43:03 --> Language Class Initialized
INFO - 2021-06-12 06:43:03 --> Config Class Initialized
INFO - 2021-06-12 06:43:03 --> Loader Class Initialized
INFO - 2021-06-12 06:43:03 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:03 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:03 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:03 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:03 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:03 --> Controller Class Initialized
DEBUG - 2021-06-12 06:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:43:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:43:03 --> Final output sent to browser
DEBUG - 2021-06-12 06:43:03 --> Total execution time: 0.0457
INFO - 2021-06-12 06:43:07 --> Config Class Initialized
INFO - 2021-06-12 06:43:07 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:07 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:07 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:07 --> URI Class Initialized
INFO - 2021-06-12 06:43:07 --> Router Class Initialized
INFO - 2021-06-12 06:43:07 --> Output Class Initialized
INFO - 2021-06-12 06:43:07 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:07 --> Input Class Initialized
INFO - 2021-06-12 06:43:07 --> Language Class Initialized
INFO - 2021-06-12 06:43:07 --> Language Class Initialized
INFO - 2021-06-12 06:43:07 --> Config Class Initialized
INFO - 2021-06-12 06:43:07 --> Loader Class Initialized
INFO - 2021-06-12 06:43:07 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:07 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:07 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:07 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:07 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:07 --> Controller Class Initialized
INFO - 2021-06-12 06:43:31 --> Config Class Initialized
INFO - 2021-06-12 06:43:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:31 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:31 --> URI Class Initialized
INFO - 2021-06-12 06:43:31 --> Router Class Initialized
INFO - 2021-06-12 06:43:31 --> Output Class Initialized
INFO - 2021-06-12 06:43:31 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:31 --> Input Class Initialized
INFO - 2021-06-12 06:43:31 --> Language Class Initialized
INFO - 2021-06-12 06:43:31 --> Language Class Initialized
INFO - 2021-06-12 06:43:31 --> Config Class Initialized
INFO - 2021-06-12 06:43:31 --> Loader Class Initialized
INFO - 2021-06-12 06:43:31 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:31 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:31 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:31 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:31 --> Controller Class Initialized
INFO - 2021-06-12 06:43:49 --> Config Class Initialized
INFO - 2021-06-12 06:43:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:49 --> URI Class Initialized
INFO - 2021-06-12 06:43:49 --> Router Class Initialized
INFO - 2021-06-12 06:43:49 --> Output Class Initialized
INFO - 2021-06-12 06:43:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:49 --> Input Class Initialized
INFO - 2021-06-12 06:43:49 --> Language Class Initialized
INFO - 2021-06-12 06:43:49 --> Language Class Initialized
INFO - 2021-06-12 06:43:49 --> Config Class Initialized
INFO - 2021-06-12 06:43:49 --> Loader Class Initialized
INFO - 2021-06-12 06:43:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:49 --> Controller Class Initialized
DEBUG - 2021-06-12 06:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:43:49 --> Final output sent to browser
DEBUG - 2021-06-12 06:43:49 --> Total execution time: 0.0462
INFO - 2021-06-12 06:43:49 --> Config Class Initialized
INFO - 2021-06-12 06:43:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:49 --> URI Class Initialized
INFO - 2021-06-12 06:43:49 --> Router Class Initialized
INFO - 2021-06-12 06:43:49 --> Output Class Initialized
INFO - 2021-06-12 06:43:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:49 --> Input Class Initialized
INFO - 2021-06-12 06:43:49 --> Language Class Initialized
INFO - 2021-06-12 06:43:49 --> Language Class Initialized
INFO - 2021-06-12 06:43:49 --> Config Class Initialized
INFO - 2021-06-12 06:43:49 --> Loader Class Initialized
INFO - 2021-06-12 06:43:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:49 --> Controller Class Initialized
INFO - 2021-06-12 06:43:51 --> Config Class Initialized
INFO - 2021-06-12 06:43:51 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:51 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:51 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:51 --> URI Class Initialized
INFO - 2021-06-12 06:43:51 --> Router Class Initialized
INFO - 2021-06-12 06:43:51 --> Output Class Initialized
INFO - 2021-06-12 06:43:51 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:51 --> Input Class Initialized
INFO - 2021-06-12 06:43:51 --> Language Class Initialized
INFO - 2021-06-12 06:43:51 --> Language Class Initialized
INFO - 2021-06-12 06:43:51 --> Config Class Initialized
INFO - 2021-06-12 06:43:51 --> Loader Class Initialized
INFO - 2021-06-12 06:43:51 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:51 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:51 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:51 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:51 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:51 --> Controller Class Initialized
DEBUG - 2021-06-12 06:43:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:43:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:43:51 --> Final output sent to browser
DEBUG - 2021-06-12 06:43:51 --> Total execution time: 0.0471
INFO - 2021-06-12 06:43:52 --> Config Class Initialized
INFO - 2021-06-12 06:43:52 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:43:52 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:43:52 --> Utf8 Class Initialized
INFO - 2021-06-12 06:43:52 --> URI Class Initialized
INFO - 2021-06-12 06:43:52 --> Router Class Initialized
INFO - 2021-06-12 06:43:52 --> Output Class Initialized
INFO - 2021-06-12 06:43:52 --> Security Class Initialized
DEBUG - 2021-06-12 06:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:43:52 --> Input Class Initialized
INFO - 2021-06-12 06:43:52 --> Language Class Initialized
INFO - 2021-06-12 06:43:52 --> Language Class Initialized
INFO - 2021-06-12 06:43:52 --> Config Class Initialized
INFO - 2021-06-12 06:43:52 --> Loader Class Initialized
INFO - 2021-06-12 06:43:52 --> Helper loaded: url_helper
INFO - 2021-06-12 06:43:52 --> Helper loaded: file_helper
INFO - 2021-06-12 06:43:52 --> Helper loaded: form_helper
INFO - 2021-06-12 06:43:52 --> Helper loaded: my_helper
INFO - 2021-06-12 06:43:52 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:43:52 --> Controller Class Initialized
INFO - 2021-06-12 06:44:12 --> Config Class Initialized
INFO - 2021-06-12 06:44:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:44:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:44:12 --> Utf8 Class Initialized
INFO - 2021-06-12 06:44:12 --> URI Class Initialized
INFO - 2021-06-12 06:44:12 --> Router Class Initialized
INFO - 2021-06-12 06:44:12 --> Output Class Initialized
INFO - 2021-06-12 06:44:12 --> Security Class Initialized
DEBUG - 2021-06-12 06:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:44:12 --> Input Class Initialized
INFO - 2021-06-12 06:44:12 --> Language Class Initialized
INFO - 2021-06-12 06:44:12 --> Language Class Initialized
INFO - 2021-06-12 06:44:12 --> Config Class Initialized
INFO - 2021-06-12 06:44:12 --> Loader Class Initialized
INFO - 2021-06-12 06:44:12 --> Helper loaded: url_helper
INFO - 2021-06-12 06:44:12 --> Helper loaded: file_helper
INFO - 2021-06-12 06:44:12 --> Helper loaded: form_helper
INFO - 2021-06-12 06:44:12 --> Helper loaded: my_helper
INFO - 2021-06-12 06:44:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:44:12 --> Controller Class Initialized
INFO - 2021-06-12 06:44:42 --> Config Class Initialized
INFO - 2021-06-12 06:44:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:44:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:44:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:44:42 --> URI Class Initialized
INFO - 2021-06-12 06:44:42 --> Router Class Initialized
INFO - 2021-06-12 06:44:42 --> Output Class Initialized
INFO - 2021-06-12 06:44:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:44:42 --> Input Class Initialized
INFO - 2021-06-12 06:44:42 --> Language Class Initialized
INFO - 2021-06-12 06:44:42 --> Language Class Initialized
INFO - 2021-06-12 06:44:42 --> Config Class Initialized
INFO - 2021-06-12 06:44:42 --> Loader Class Initialized
INFO - 2021-06-12 06:44:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:44:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:44:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:44:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:44:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:44:42 --> Controller Class Initialized
INFO - 2021-06-12 06:44:42 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:44:42 --> Config Class Initialized
INFO - 2021-06-12 06:44:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:44:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:44:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:44:42 --> URI Class Initialized
INFO - 2021-06-12 06:44:42 --> Router Class Initialized
INFO - 2021-06-12 06:44:42 --> Output Class Initialized
INFO - 2021-06-12 06:44:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:44:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:44:42 --> Input Class Initialized
INFO - 2021-06-12 06:44:42 --> Language Class Initialized
INFO - 2021-06-12 06:44:42 --> Language Class Initialized
INFO - 2021-06-12 06:44:42 --> Config Class Initialized
INFO - 2021-06-12 06:44:42 --> Loader Class Initialized
INFO - 2021-06-12 06:44:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:44:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:44:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:44:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:44:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:44:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:44:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:44:42 --> Controller Class Initialized
DEBUG - 2021-06-12 06:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:44:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:44:42 --> Final output sent to browser
DEBUG - 2021-06-12 06:44:42 --> Total execution time: 0.0503
INFO - 2021-06-12 06:44:57 --> Config Class Initialized
INFO - 2021-06-12 06:44:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:44:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:44:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:44:57 --> URI Class Initialized
INFO - 2021-06-12 06:44:57 --> Router Class Initialized
INFO - 2021-06-12 06:44:57 --> Output Class Initialized
INFO - 2021-06-12 06:44:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:44:57 --> Input Class Initialized
INFO - 2021-06-12 06:44:57 --> Language Class Initialized
INFO - 2021-06-12 06:44:57 --> Language Class Initialized
INFO - 2021-06-12 06:44:57 --> Config Class Initialized
INFO - 2021-06-12 06:44:57 --> Loader Class Initialized
INFO - 2021-06-12 06:44:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:44:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:44:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:44:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:44:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:44:57 --> Controller Class Initialized
INFO - 2021-06-12 06:44:57 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:44:57 --> Final output sent to browser
DEBUG - 2021-06-12 06:44:57 --> Total execution time: 0.0509
INFO - 2021-06-12 06:44:57 --> Config Class Initialized
INFO - 2021-06-12 06:44:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:44:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:44:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:44:57 --> URI Class Initialized
INFO - 2021-06-12 06:44:57 --> Router Class Initialized
INFO - 2021-06-12 06:44:57 --> Output Class Initialized
INFO - 2021-06-12 06:44:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:44:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:44:57 --> Input Class Initialized
INFO - 2021-06-12 06:44:57 --> Language Class Initialized
INFO - 2021-06-12 06:44:57 --> Language Class Initialized
INFO - 2021-06-12 06:44:57 --> Config Class Initialized
INFO - 2021-06-12 06:44:57 --> Loader Class Initialized
INFO - 2021-06-12 06:44:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:44:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:44:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:44:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:44:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:44:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:44:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:44:57 --> Controller Class Initialized
DEBUG - 2021-06-12 06:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:44:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:44:57 --> Final output sent to browser
DEBUG - 2021-06-12 06:44:57 --> Total execution time: 0.0825
INFO - 2021-06-12 06:44:59 --> Config Class Initialized
INFO - 2021-06-12 06:44:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:44:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:44:59 --> Utf8 Class Initialized
INFO - 2021-06-12 06:44:59 --> URI Class Initialized
INFO - 2021-06-12 06:44:59 --> Router Class Initialized
INFO - 2021-06-12 06:44:59 --> Output Class Initialized
INFO - 2021-06-12 06:44:59 --> Security Class Initialized
DEBUG - 2021-06-12 06:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:44:59 --> Input Class Initialized
INFO - 2021-06-12 06:44:59 --> Language Class Initialized
INFO - 2021-06-12 06:44:59 --> Language Class Initialized
INFO - 2021-06-12 06:44:59 --> Config Class Initialized
INFO - 2021-06-12 06:44:59 --> Loader Class Initialized
INFO - 2021-06-12 06:44:59 --> Helper loaded: url_helper
INFO - 2021-06-12 06:44:59 --> Helper loaded: file_helper
INFO - 2021-06-12 06:44:59 --> Helper loaded: form_helper
INFO - 2021-06-12 06:44:59 --> Helper loaded: my_helper
INFO - 2021-06-12 06:44:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:44:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:44:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:44:59 --> Controller Class Initialized
DEBUG - 2021-06-12 06:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:44:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:44:59 --> Final output sent to browser
DEBUG - 2021-06-12 06:44:59 --> Total execution time: 0.0415
INFO - 2021-06-12 06:45:00 --> Config Class Initialized
INFO - 2021-06-12 06:45:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:00 --> URI Class Initialized
INFO - 2021-06-12 06:45:00 --> Router Class Initialized
INFO - 2021-06-12 06:45:00 --> Output Class Initialized
INFO - 2021-06-12 06:45:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:00 --> Input Class Initialized
INFO - 2021-06-12 06:45:00 --> Language Class Initialized
INFO - 2021-06-12 06:45:00 --> Language Class Initialized
INFO - 2021-06-12 06:45:00 --> Config Class Initialized
INFO - 2021-06-12 06:45:00 --> Loader Class Initialized
INFO - 2021-06-12 06:45:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:00 --> Controller Class Initialized
DEBUG - 2021-06-12 06:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:45:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:45:00 --> Final output sent to browser
DEBUG - 2021-06-12 06:45:00 --> Total execution time: 0.0429
INFO - 2021-06-12 06:45:01 --> Config Class Initialized
INFO - 2021-06-12 06:45:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:01 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:01 --> URI Class Initialized
INFO - 2021-06-12 06:45:01 --> Router Class Initialized
INFO - 2021-06-12 06:45:01 --> Output Class Initialized
INFO - 2021-06-12 06:45:01 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:01 --> Input Class Initialized
INFO - 2021-06-12 06:45:01 --> Language Class Initialized
INFO - 2021-06-12 06:45:01 --> Language Class Initialized
INFO - 2021-06-12 06:45:01 --> Config Class Initialized
INFO - 2021-06-12 06:45:01 --> Loader Class Initialized
INFO - 2021-06-12 06:45:01 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:01 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:01 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:01 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:01 --> Controller Class Initialized
INFO - 2021-06-12 06:45:04 --> Config Class Initialized
INFO - 2021-06-12 06:45:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:04 --> URI Class Initialized
INFO - 2021-06-12 06:45:04 --> Router Class Initialized
INFO - 2021-06-12 06:45:04 --> Output Class Initialized
INFO - 2021-06-12 06:45:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:04 --> Input Class Initialized
INFO - 2021-06-12 06:45:04 --> Language Class Initialized
INFO - 2021-06-12 06:45:04 --> Language Class Initialized
INFO - 2021-06-12 06:45:04 --> Config Class Initialized
INFO - 2021-06-12 06:45:04 --> Loader Class Initialized
INFO - 2021-06-12 06:45:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:04 --> Controller Class Initialized
INFO - 2021-06-12 06:45:04 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:45:04 --> Config Class Initialized
INFO - 2021-06-12 06:45:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:04 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:04 --> URI Class Initialized
INFO - 2021-06-12 06:45:04 --> Router Class Initialized
INFO - 2021-06-12 06:45:04 --> Output Class Initialized
INFO - 2021-06-12 06:45:04 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:04 --> Input Class Initialized
INFO - 2021-06-12 06:45:04 --> Language Class Initialized
INFO - 2021-06-12 06:45:04 --> Language Class Initialized
INFO - 2021-06-12 06:45:04 --> Config Class Initialized
INFO - 2021-06-12 06:45:04 --> Loader Class Initialized
INFO - 2021-06-12 06:45:04 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:04 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:04 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:04 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:04 --> Controller Class Initialized
DEBUG - 2021-06-12 06:45:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:45:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:45:04 --> Final output sent to browser
DEBUG - 2021-06-12 06:45:04 --> Total execution time: 0.0494
INFO - 2021-06-12 06:45:12 --> Config Class Initialized
INFO - 2021-06-12 06:45:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:12 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:12 --> URI Class Initialized
INFO - 2021-06-12 06:45:12 --> Router Class Initialized
INFO - 2021-06-12 06:45:12 --> Output Class Initialized
INFO - 2021-06-12 06:45:12 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:12 --> Input Class Initialized
INFO - 2021-06-12 06:45:12 --> Language Class Initialized
INFO - 2021-06-12 06:45:12 --> Language Class Initialized
INFO - 2021-06-12 06:45:12 --> Config Class Initialized
INFO - 2021-06-12 06:45:12 --> Loader Class Initialized
INFO - 2021-06-12 06:45:12 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:12 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:12 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:12 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:12 --> Controller Class Initialized
INFO - 2021-06-12 06:45:12 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:45:12 --> Final output sent to browser
DEBUG - 2021-06-12 06:45:12 --> Total execution time: 0.0508
INFO - 2021-06-12 06:45:13 --> Config Class Initialized
INFO - 2021-06-12 06:45:13 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:13 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:13 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:13 --> URI Class Initialized
INFO - 2021-06-12 06:45:13 --> Router Class Initialized
INFO - 2021-06-12 06:45:13 --> Output Class Initialized
INFO - 2021-06-12 06:45:13 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:13 --> Input Class Initialized
INFO - 2021-06-12 06:45:13 --> Language Class Initialized
INFO - 2021-06-12 06:45:13 --> Language Class Initialized
INFO - 2021-06-12 06:45:13 --> Config Class Initialized
INFO - 2021-06-12 06:45:13 --> Loader Class Initialized
INFO - 2021-06-12 06:45:13 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:13 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:13 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:13 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:13 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:13 --> Controller Class Initialized
DEBUG - 2021-06-12 06:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:45:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:45:13 --> Final output sent to browser
DEBUG - 2021-06-12 06:45:13 --> Total execution time: 0.0741
INFO - 2021-06-12 06:45:15 --> Config Class Initialized
INFO - 2021-06-12 06:45:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:15 --> URI Class Initialized
INFO - 2021-06-12 06:45:15 --> Router Class Initialized
INFO - 2021-06-12 06:45:15 --> Output Class Initialized
INFO - 2021-06-12 06:45:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:15 --> Input Class Initialized
INFO - 2021-06-12 06:45:15 --> Language Class Initialized
INFO - 2021-06-12 06:45:15 --> Language Class Initialized
INFO - 2021-06-12 06:45:15 --> Config Class Initialized
INFO - 2021-06-12 06:45:15 --> Loader Class Initialized
INFO - 2021-06-12 06:45:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:15 --> Controller Class Initialized
DEBUG - 2021-06-12 06:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:45:15 --> Final output sent to browser
DEBUG - 2021-06-12 06:45:15 --> Total execution time: 0.0509
INFO - 2021-06-12 06:45:38 --> Config Class Initialized
INFO - 2021-06-12 06:45:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:38 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:38 --> URI Class Initialized
INFO - 2021-06-12 06:45:38 --> Router Class Initialized
INFO - 2021-06-12 06:45:38 --> Output Class Initialized
INFO - 2021-06-12 06:45:38 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:38 --> Input Class Initialized
INFO - 2021-06-12 06:45:38 --> Language Class Initialized
INFO - 2021-06-12 06:45:38 --> Language Class Initialized
INFO - 2021-06-12 06:45:38 --> Config Class Initialized
INFO - 2021-06-12 06:45:38 --> Loader Class Initialized
INFO - 2021-06-12 06:45:38 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:38 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:38 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:38 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:38 --> Controller Class Initialized
DEBUG - 2021-06-12 06:45:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:45:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:45:38 --> Final output sent to browser
DEBUG - 2021-06-12 06:45:38 --> Total execution time: 0.0468
INFO - 2021-06-12 06:45:38 --> Config Class Initialized
INFO - 2021-06-12 06:45:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:38 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:38 --> URI Class Initialized
INFO - 2021-06-12 06:45:38 --> Router Class Initialized
INFO - 2021-06-12 06:45:38 --> Output Class Initialized
INFO - 2021-06-12 06:45:38 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:38 --> Input Class Initialized
INFO - 2021-06-12 06:45:38 --> Language Class Initialized
INFO - 2021-06-12 06:45:38 --> Language Class Initialized
INFO - 2021-06-12 06:45:38 --> Config Class Initialized
INFO - 2021-06-12 06:45:38 --> Loader Class Initialized
INFO - 2021-06-12 06:45:38 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:38 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:38 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:38 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:38 --> Controller Class Initialized
INFO - 2021-06-12 06:45:39 --> Config Class Initialized
INFO - 2021-06-12 06:45:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:39 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:39 --> URI Class Initialized
INFO - 2021-06-12 06:45:39 --> Router Class Initialized
INFO - 2021-06-12 06:45:39 --> Output Class Initialized
INFO - 2021-06-12 06:45:39 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:39 --> Input Class Initialized
INFO - 2021-06-12 06:45:39 --> Language Class Initialized
INFO - 2021-06-12 06:45:39 --> Language Class Initialized
INFO - 2021-06-12 06:45:39 --> Config Class Initialized
INFO - 2021-06-12 06:45:39 --> Loader Class Initialized
INFO - 2021-06-12 06:45:39 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:39 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:39 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:39 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:39 --> Controller Class Initialized
DEBUG - 2021-06-12 06:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:45:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:45:39 --> Final output sent to browser
DEBUG - 2021-06-12 06:45:39 --> Total execution time: 0.0446
INFO - 2021-06-12 06:45:46 --> Config Class Initialized
INFO - 2021-06-12 06:45:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:45:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:45:46 --> Utf8 Class Initialized
INFO - 2021-06-12 06:45:46 --> URI Class Initialized
INFO - 2021-06-12 06:45:46 --> Router Class Initialized
INFO - 2021-06-12 06:45:46 --> Output Class Initialized
INFO - 2021-06-12 06:45:46 --> Security Class Initialized
DEBUG - 2021-06-12 06:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:45:46 --> Input Class Initialized
INFO - 2021-06-12 06:45:46 --> Language Class Initialized
INFO - 2021-06-12 06:45:46 --> Language Class Initialized
INFO - 2021-06-12 06:45:46 --> Config Class Initialized
INFO - 2021-06-12 06:45:46 --> Loader Class Initialized
INFO - 2021-06-12 06:45:46 --> Helper loaded: url_helper
INFO - 2021-06-12 06:45:46 --> Helper loaded: file_helper
INFO - 2021-06-12 06:45:46 --> Helper loaded: form_helper
INFO - 2021-06-12 06:45:46 --> Helper loaded: my_helper
INFO - 2021-06-12 06:45:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:45:46 --> Controller Class Initialized
INFO - 2021-06-12 06:46:11 --> Config Class Initialized
INFO - 2021-06-12 06:46:11 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:46:11 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:46:11 --> Utf8 Class Initialized
INFO - 2021-06-12 06:46:11 --> URI Class Initialized
INFO - 2021-06-12 06:46:11 --> Router Class Initialized
INFO - 2021-06-12 06:46:11 --> Output Class Initialized
INFO - 2021-06-12 06:46:11 --> Security Class Initialized
DEBUG - 2021-06-12 06:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:46:11 --> Input Class Initialized
INFO - 2021-06-12 06:46:11 --> Language Class Initialized
INFO - 2021-06-12 06:46:11 --> Language Class Initialized
INFO - 2021-06-12 06:46:11 --> Config Class Initialized
INFO - 2021-06-12 06:46:11 --> Loader Class Initialized
INFO - 2021-06-12 06:46:11 --> Helper loaded: url_helper
INFO - 2021-06-12 06:46:11 --> Helper loaded: file_helper
INFO - 2021-06-12 06:46:11 --> Helper loaded: form_helper
INFO - 2021-06-12 06:46:11 --> Helper loaded: my_helper
INFO - 2021-06-12 06:46:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:46:11 --> Controller Class Initialized
INFO - 2021-06-12 06:46:23 --> Config Class Initialized
INFO - 2021-06-12 06:46:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:46:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:46:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:46:23 --> URI Class Initialized
INFO - 2021-06-12 06:46:23 --> Router Class Initialized
INFO - 2021-06-12 06:46:23 --> Output Class Initialized
INFO - 2021-06-12 06:46:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:46:23 --> Input Class Initialized
INFO - 2021-06-12 06:46:23 --> Language Class Initialized
INFO - 2021-06-12 06:46:23 --> Language Class Initialized
INFO - 2021-06-12 06:46:23 --> Config Class Initialized
INFO - 2021-06-12 06:46:23 --> Loader Class Initialized
INFO - 2021-06-12 06:46:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:46:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:46:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:46:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:46:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:46:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:46:23 --> Controller Class Initialized
DEBUG - 2021-06-12 06:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:46:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:46:23 --> Final output sent to browser
DEBUG - 2021-06-12 06:46:23 --> Total execution time: 0.0441
INFO - 2021-06-12 06:46:23 --> Config Class Initialized
INFO - 2021-06-12 06:46:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:46:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:46:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:46:23 --> URI Class Initialized
INFO - 2021-06-12 06:46:23 --> Router Class Initialized
INFO - 2021-06-12 06:46:23 --> Output Class Initialized
INFO - 2021-06-12 06:46:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:46:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:46:23 --> Input Class Initialized
INFO - 2021-06-12 06:46:23 --> Language Class Initialized
INFO - 2021-06-12 06:46:23 --> Language Class Initialized
INFO - 2021-06-12 06:46:23 --> Config Class Initialized
INFO - 2021-06-12 06:46:23 --> Loader Class Initialized
INFO - 2021-06-12 06:46:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:46:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:46:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:46:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:46:24 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:46:24 --> Controller Class Initialized
INFO - 2021-06-12 06:46:25 --> Config Class Initialized
INFO - 2021-06-12 06:46:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:46:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:46:25 --> Utf8 Class Initialized
INFO - 2021-06-12 06:46:25 --> URI Class Initialized
INFO - 2021-06-12 06:46:25 --> Router Class Initialized
INFO - 2021-06-12 06:46:25 --> Output Class Initialized
INFO - 2021-06-12 06:46:25 --> Security Class Initialized
DEBUG - 2021-06-12 06:46:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:46:25 --> Input Class Initialized
INFO - 2021-06-12 06:46:25 --> Language Class Initialized
INFO - 2021-06-12 06:46:25 --> Language Class Initialized
INFO - 2021-06-12 06:46:25 --> Config Class Initialized
INFO - 2021-06-12 06:46:25 --> Loader Class Initialized
INFO - 2021-06-12 06:46:25 --> Helper loaded: url_helper
INFO - 2021-06-12 06:46:25 --> Helper loaded: file_helper
INFO - 2021-06-12 06:46:25 --> Helper loaded: form_helper
INFO - 2021-06-12 06:46:25 --> Helper loaded: my_helper
INFO - 2021-06-12 06:46:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:46:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:46:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:46:25 --> Controller Class Initialized
DEBUG - 2021-06-12 06:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:46:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:46:25 --> Final output sent to browser
DEBUG - 2021-06-12 06:46:25 --> Total execution time: 0.0447
INFO - 2021-06-12 06:46:26 --> Config Class Initialized
INFO - 2021-06-12 06:46:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:46:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:46:26 --> Utf8 Class Initialized
INFO - 2021-06-12 06:46:26 --> URI Class Initialized
INFO - 2021-06-12 06:46:26 --> Router Class Initialized
INFO - 2021-06-12 06:46:26 --> Output Class Initialized
INFO - 2021-06-12 06:46:26 --> Security Class Initialized
DEBUG - 2021-06-12 06:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:46:26 --> Input Class Initialized
INFO - 2021-06-12 06:46:26 --> Language Class Initialized
INFO - 2021-06-12 06:46:26 --> Language Class Initialized
INFO - 2021-06-12 06:46:26 --> Config Class Initialized
INFO - 2021-06-12 06:46:26 --> Loader Class Initialized
INFO - 2021-06-12 06:46:26 --> Helper loaded: url_helper
INFO - 2021-06-12 06:46:26 --> Helper loaded: file_helper
INFO - 2021-06-12 06:46:26 --> Helper loaded: form_helper
INFO - 2021-06-12 06:46:26 --> Helper loaded: my_helper
INFO - 2021-06-12 06:46:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:46:26 --> Controller Class Initialized
INFO - 2021-06-12 06:46:45 --> Config Class Initialized
INFO - 2021-06-12 06:46:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:46:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:46:45 --> Utf8 Class Initialized
INFO - 2021-06-12 06:46:45 --> URI Class Initialized
INFO - 2021-06-12 06:46:45 --> Router Class Initialized
INFO - 2021-06-12 06:46:45 --> Output Class Initialized
INFO - 2021-06-12 06:46:45 --> Security Class Initialized
DEBUG - 2021-06-12 06:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:46:45 --> Input Class Initialized
INFO - 2021-06-12 06:46:45 --> Language Class Initialized
INFO - 2021-06-12 06:46:45 --> Language Class Initialized
INFO - 2021-06-12 06:46:45 --> Config Class Initialized
INFO - 2021-06-12 06:46:45 --> Loader Class Initialized
INFO - 2021-06-12 06:46:45 --> Helper loaded: url_helper
INFO - 2021-06-12 06:46:45 --> Helper loaded: file_helper
INFO - 2021-06-12 06:46:45 --> Helper loaded: form_helper
INFO - 2021-06-12 06:46:45 --> Helper loaded: my_helper
INFO - 2021-06-12 06:46:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:46:45 --> Controller Class Initialized
INFO - 2021-06-12 06:47:00 --> Config Class Initialized
INFO - 2021-06-12 06:47:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:00 --> URI Class Initialized
INFO - 2021-06-12 06:47:00 --> Router Class Initialized
INFO - 2021-06-12 06:47:00 --> Output Class Initialized
INFO - 2021-06-12 06:47:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:00 --> Input Class Initialized
INFO - 2021-06-12 06:47:00 --> Language Class Initialized
INFO - 2021-06-12 06:47:00 --> Language Class Initialized
INFO - 2021-06-12 06:47:00 --> Config Class Initialized
INFO - 2021-06-12 06:47:00 --> Loader Class Initialized
INFO - 2021-06-12 06:47:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:00 --> Controller Class Initialized
DEBUG - 2021-06-12 06:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:47:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:47:00 --> Final output sent to browser
DEBUG - 2021-06-12 06:47:00 --> Total execution time: 0.0482
INFO - 2021-06-12 06:47:00 --> Config Class Initialized
INFO - 2021-06-12 06:47:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:00 --> URI Class Initialized
INFO - 2021-06-12 06:47:00 --> Router Class Initialized
INFO - 2021-06-12 06:47:00 --> Output Class Initialized
INFO - 2021-06-12 06:47:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:00 --> Input Class Initialized
INFO - 2021-06-12 06:47:00 --> Language Class Initialized
INFO - 2021-06-12 06:47:00 --> Language Class Initialized
INFO - 2021-06-12 06:47:00 --> Config Class Initialized
INFO - 2021-06-12 06:47:00 --> Loader Class Initialized
INFO - 2021-06-12 06:47:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:00 --> Controller Class Initialized
INFO - 2021-06-12 06:47:01 --> Config Class Initialized
INFO - 2021-06-12 06:47:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:01 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:01 --> URI Class Initialized
INFO - 2021-06-12 06:47:01 --> Router Class Initialized
INFO - 2021-06-12 06:47:01 --> Output Class Initialized
INFO - 2021-06-12 06:47:01 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:01 --> Input Class Initialized
INFO - 2021-06-12 06:47:01 --> Language Class Initialized
INFO - 2021-06-12 06:47:01 --> Language Class Initialized
INFO - 2021-06-12 06:47:01 --> Config Class Initialized
INFO - 2021-06-12 06:47:01 --> Loader Class Initialized
INFO - 2021-06-12 06:47:01 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:01 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:01 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:01 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:01 --> Controller Class Initialized
DEBUG - 2021-06-12 06:47:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:47:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:47:01 --> Final output sent to browser
DEBUG - 2021-06-12 06:47:01 --> Total execution time: 0.0433
INFO - 2021-06-12 06:47:12 --> Config Class Initialized
INFO - 2021-06-12 06:47:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:12 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:12 --> URI Class Initialized
INFO - 2021-06-12 06:47:12 --> Router Class Initialized
INFO - 2021-06-12 06:47:12 --> Output Class Initialized
INFO - 2021-06-12 06:47:12 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:12 --> Input Class Initialized
INFO - 2021-06-12 06:47:12 --> Language Class Initialized
INFO - 2021-06-12 06:47:12 --> Language Class Initialized
INFO - 2021-06-12 06:47:12 --> Config Class Initialized
INFO - 2021-06-12 06:47:12 --> Loader Class Initialized
INFO - 2021-06-12 06:47:12 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:12 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:12 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:12 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:12 --> Controller Class Initialized
INFO - 2021-06-12 06:47:35 --> Config Class Initialized
INFO - 2021-06-12 06:47:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:35 --> URI Class Initialized
INFO - 2021-06-12 06:47:35 --> Router Class Initialized
INFO - 2021-06-12 06:47:35 --> Output Class Initialized
INFO - 2021-06-12 06:47:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:35 --> Input Class Initialized
INFO - 2021-06-12 06:47:35 --> Language Class Initialized
INFO - 2021-06-12 06:47:35 --> Language Class Initialized
INFO - 2021-06-12 06:47:35 --> Config Class Initialized
INFO - 2021-06-12 06:47:35 --> Loader Class Initialized
INFO - 2021-06-12 06:47:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:35 --> Controller Class Initialized
INFO - 2021-06-12 06:47:50 --> Config Class Initialized
INFO - 2021-06-12 06:47:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:50 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:50 --> URI Class Initialized
INFO - 2021-06-12 06:47:50 --> Router Class Initialized
INFO - 2021-06-12 06:47:50 --> Output Class Initialized
INFO - 2021-06-12 06:47:50 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:50 --> Input Class Initialized
INFO - 2021-06-12 06:47:50 --> Language Class Initialized
INFO - 2021-06-12 06:47:50 --> Language Class Initialized
INFO - 2021-06-12 06:47:50 --> Config Class Initialized
INFO - 2021-06-12 06:47:50 --> Loader Class Initialized
INFO - 2021-06-12 06:47:50 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:50 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:50 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:50 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:50 --> Controller Class Initialized
DEBUG - 2021-06-12 06:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:47:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:47:50 --> Final output sent to browser
DEBUG - 2021-06-12 06:47:50 --> Total execution time: 0.0447
INFO - 2021-06-12 06:47:50 --> Config Class Initialized
INFO - 2021-06-12 06:47:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:50 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:50 --> URI Class Initialized
INFO - 2021-06-12 06:47:50 --> Router Class Initialized
INFO - 2021-06-12 06:47:50 --> Output Class Initialized
INFO - 2021-06-12 06:47:50 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:50 --> Input Class Initialized
INFO - 2021-06-12 06:47:50 --> Language Class Initialized
INFO - 2021-06-12 06:47:50 --> Language Class Initialized
INFO - 2021-06-12 06:47:50 --> Config Class Initialized
INFO - 2021-06-12 06:47:50 --> Loader Class Initialized
INFO - 2021-06-12 06:47:50 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:50 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:50 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:50 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:50 --> Controller Class Initialized
INFO - 2021-06-12 06:47:51 --> Config Class Initialized
INFO - 2021-06-12 06:47:51 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:51 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:51 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:51 --> URI Class Initialized
INFO - 2021-06-12 06:47:51 --> Router Class Initialized
INFO - 2021-06-12 06:47:52 --> Output Class Initialized
INFO - 2021-06-12 06:47:52 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:52 --> Input Class Initialized
INFO - 2021-06-12 06:47:52 --> Language Class Initialized
INFO - 2021-06-12 06:47:52 --> Language Class Initialized
INFO - 2021-06-12 06:47:52 --> Config Class Initialized
INFO - 2021-06-12 06:47:52 --> Loader Class Initialized
INFO - 2021-06-12 06:47:52 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:52 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:52 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:52 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:52 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:52 --> Controller Class Initialized
DEBUG - 2021-06-12 06:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:47:52 --> Final output sent to browser
DEBUG - 2021-06-12 06:47:52 --> Total execution time: 0.0441
INFO - 2021-06-12 06:47:56 --> Config Class Initialized
INFO - 2021-06-12 06:47:56 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:47:56 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:47:56 --> Utf8 Class Initialized
INFO - 2021-06-12 06:47:56 --> URI Class Initialized
INFO - 2021-06-12 06:47:56 --> Router Class Initialized
INFO - 2021-06-12 06:47:56 --> Output Class Initialized
INFO - 2021-06-12 06:47:56 --> Security Class Initialized
DEBUG - 2021-06-12 06:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:47:56 --> Input Class Initialized
INFO - 2021-06-12 06:47:56 --> Language Class Initialized
INFO - 2021-06-12 06:47:56 --> Language Class Initialized
INFO - 2021-06-12 06:47:56 --> Config Class Initialized
INFO - 2021-06-12 06:47:56 --> Loader Class Initialized
INFO - 2021-06-12 06:47:56 --> Helper loaded: url_helper
INFO - 2021-06-12 06:47:56 --> Helper loaded: file_helper
INFO - 2021-06-12 06:47:56 --> Helper loaded: form_helper
INFO - 2021-06-12 06:47:56 --> Helper loaded: my_helper
INFO - 2021-06-12 06:47:56 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:47:56 --> Controller Class Initialized
INFO - 2021-06-12 06:48:20 --> Config Class Initialized
INFO - 2021-06-12 06:48:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:48:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:48:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:48:20 --> URI Class Initialized
INFO - 2021-06-12 06:48:20 --> Router Class Initialized
INFO - 2021-06-12 06:48:20 --> Output Class Initialized
INFO - 2021-06-12 06:48:20 --> Security Class Initialized
DEBUG - 2021-06-12 06:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:48:20 --> Input Class Initialized
INFO - 2021-06-12 06:48:20 --> Language Class Initialized
INFO - 2021-06-12 06:48:20 --> Language Class Initialized
INFO - 2021-06-12 06:48:20 --> Config Class Initialized
INFO - 2021-06-12 06:48:20 --> Loader Class Initialized
INFO - 2021-06-12 06:48:20 --> Helper loaded: url_helper
INFO - 2021-06-12 06:48:20 --> Helper loaded: file_helper
INFO - 2021-06-12 06:48:20 --> Helper loaded: form_helper
INFO - 2021-06-12 06:48:20 --> Helper loaded: my_helper
INFO - 2021-06-12 06:48:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:48:20 --> Controller Class Initialized
INFO - 2021-06-12 06:49:00 --> Config Class Initialized
INFO - 2021-06-12 06:49:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:00 --> URI Class Initialized
INFO - 2021-06-12 06:49:00 --> Router Class Initialized
INFO - 2021-06-12 06:49:00 --> Output Class Initialized
INFO - 2021-06-12 06:49:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:00 --> Input Class Initialized
INFO - 2021-06-12 06:49:00 --> Language Class Initialized
INFO - 2021-06-12 06:49:00 --> Language Class Initialized
INFO - 2021-06-12 06:49:00 --> Config Class Initialized
INFO - 2021-06-12 06:49:00 --> Loader Class Initialized
INFO - 2021-06-12 06:49:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:00 --> Controller Class Initialized
DEBUG - 2021-06-12 06:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:49:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:49:00 --> Final output sent to browser
DEBUG - 2021-06-12 06:49:00 --> Total execution time: 0.0450
INFO - 2021-06-12 06:49:00 --> Config Class Initialized
INFO - 2021-06-12 06:49:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:00 --> URI Class Initialized
INFO - 2021-06-12 06:49:00 --> Router Class Initialized
INFO - 2021-06-12 06:49:00 --> Output Class Initialized
INFO - 2021-06-12 06:49:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:00 --> Input Class Initialized
INFO - 2021-06-12 06:49:00 --> Language Class Initialized
INFO - 2021-06-12 06:49:00 --> Language Class Initialized
INFO - 2021-06-12 06:49:00 --> Config Class Initialized
INFO - 2021-06-12 06:49:00 --> Loader Class Initialized
INFO - 2021-06-12 06:49:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:00 --> Controller Class Initialized
INFO - 2021-06-12 06:49:01 --> Config Class Initialized
INFO - 2021-06-12 06:49:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:01 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:01 --> URI Class Initialized
INFO - 2021-06-12 06:49:01 --> Router Class Initialized
INFO - 2021-06-12 06:49:01 --> Output Class Initialized
INFO - 2021-06-12 06:49:01 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:01 --> Input Class Initialized
INFO - 2021-06-12 06:49:01 --> Language Class Initialized
INFO - 2021-06-12 06:49:01 --> Language Class Initialized
INFO - 2021-06-12 06:49:01 --> Config Class Initialized
INFO - 2021-06-12 06:49:01 --> Loader Class Initialized
INFO - 2021-06-12 06:49:01 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:01 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:01 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:01 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:01 --> Controller Class Initialized
DEBUG - 2021-06-12 06:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:49:01 --> Final output sent to browser
DEBUG - 2021-06-12 06:49:01 --> Total execution time: 0.0442
INFO - 2021-06-12 06:49:03 --> Config Class Initialized
INFO - 2021-06-12 06:49:03 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:03 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:03 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:03 --> URI Class Initialized
INFO - 2021-06-12 06:49:03 --> Router Class Initialized
INFO - 2021-06-12 06:49:03 --> Output Class Initialized
INFO - 2021-06-12 06:49:03 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:03 --> Input Class Initialized
INFO - 2021-06-12 06:49:03 --> Language Class Initialized
INFO - 2021-06-12 06:49:03 --> Language Class Initialized
INFO - 2021-06-12 06:49:03 --> Config Class Initialized
INFO - 2021-06-12 06:49:03 --> Loader Class Initialized
INFO - 2021-06-12 06:49:03 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:03 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:03 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:03 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:03 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:03 --> Controller Class Initialized
INFO - 2021-06-12 06:49:21 --> Config Class Initialized
INFO - 2021-06-12 06:49:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:21 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:21 --> URI Class Initialized
INFO - 2021-06-12 06:49:21 --> Router Class Initialized
INFO - 2021-06-12 06:49:21 --> Output Class Initialized
INFO - 2021-06-12 06:49:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:21 --> Input Class Initialized
INFO - 2021-06-12 06:49:21 --> Language Class Initialized
INFO - 2021-06-12 06:49:21 --> Language Class Initialized
INFO - 2021-06-12 06:49:21 --> Config Class Initialized
INFO - 2021-06-12 06:49:21 --> Loader Class Initialized
INFO - 2021-06-12 06:49:21 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:21 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:21 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:21 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:21 --> Controller Class Initialized
INFO - 2021-06-12 06:49:37 --> Config Class Initialized
INFO - 2021-06-12 06:49:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:37 --> URI Class Initialized
INFO - 2021-06-12 06:49:37 --> Router Class Initialized
INFO - 2021-06-12 06:49:37 --> Output Class Initialized
INFO - 2021-06-12 06:49:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:37 --> Input Class Initialized
INFO - 2021-06-12 06:49:37 --> Language Class Initialized
INFO - 2021-06-12 06:49:37 --> Language Class Initialized
INFO - 2021-06-12 06:49:37 --> Config Class Initialized
INFO - 2021-06-12 06:49:37 --> Loader Class Initialized
INFO - 2021-06-12 06:49:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:37 --> Controller Class Initialized
DEBUG - 2021-06-12 06:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:49:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:49:37 --> Final output sent to browser
DEBUG - 2021-06-12 06:49:37 --> Total execution time: 0.0449
INFO - 2021-06-12 06:49:37 --> Config Class Initialized
INFO - 2021-06-12 06:49:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:37 --> URI Class Initialized
INFO - 2021-06-12 06:49:37 --> Router Class Initialized
INFO - 2021-06-12 06:49:37 --> Output Class Initialized
INFO - 2021-06-12 06:49:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:37 --> Input Class Initialized
INFO - 2021-06-12 06:49:37 --> Language Class Initialized
INFO - 2021-06-12 06:49:37 --> Language Class Initialized
INFO - 2021-06-12 06:49:37 --> Config Class Initialized
INFO - 2021-06-12 06:49:37 --> Loader Class Initialized
INFO - 2021-06-12 06:49:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:37 --> Controller Class Initialized
INFO - 2021-06-12 06:49:38 --> Config Class Initialized
INFO - 2021-06-12 06:49:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:38 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:38 --> URI Class Initialized
INFO - 2021-06-12 06:49:38 --> Router Class Initialized
INFO - 2021-06-12 06:49:38 --> Output Class Initialized
INFO - 2021-06-12 06:49:38 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:38 --> Input Class Initialized
INFO - 2021-06-12 06:49:38 --> Language Class Initialized
INFO - 2021-06-12 06:49:38 --> Language Class Initialized
INFO - 2021-06-12 06:49:38 --> Config Class Initialized
INFO - 2021-06-12 06:49:38 --> Loader Class Initialized
INFO - 2021-06-12 06:49:38 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:38 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:38 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:38 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:38 --> Controller Class Initialized
DEBUG - 2021-06-12 06:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:49:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:49:38 --> Final output sent to browser
DEBUG - 2021-06-12 06:49:38 --> Total execution time: 0.0439
INFO - 2021-06-12 06:49:40 --> Config Class Initialized
INFO - 2021-06-12 06:49:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:49:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:49:40 --> Utf8 Class Initialized
INFO - 2021-06-12 06:49:40 --> URI Class Initialized
INFO - 2021-06-12 06:49:40 --> Router Class Initialized
INFO - 2021-06-12 06:49:40 --> Output Class Initialized
INFO - 2021-06-12 06:49:40 --> Security Class Initialized
DEBUG - 2021-06-12 06:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:49:40 --> Input Class Initialized
INFO - 2021-06-12 06:49:40 --> Language Class Initialized
INFO - 2021-06-12 06:49:40 --> Language Class Initialized
INFO - 2021-06-12 06:49:40 --> Config Class Initialized
INFO - 2021-06-12 06:49:40 --> Loader Class Initialized
INFO - 2021-06-12 06:49:40 --> Helper loaded: url_helper
INFO - 2021-06-12 06:49:40 --> Helper loaded: file_helper
INFO - 2021-06-12 06:49:40 --> Helper loaded: form_helper
INFO - 2021-06-12 06:49:40 --> Helper loaded: my_helper
INFO - 2021-06-12 06:49:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:49:40 --> Controller Class Initialized
INFO - 2021-06-12 06:50:01 --> Config Class Initialized
INFO - 2021-06-12 06:50:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:01 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:01 --> URI Class Initialized
INFO - 2021-06-12 06:50:01 --> Router Class Initialized
INFO - 2021-06-12 06:50:01 --> Output Class Initialized
INFO - 2021-06-12 06:50:01 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:01 --> Input Class Initialized
INFO - 2021-06-12 06:50:01 --> Language Class Initialized
INFO - 2021-06-12 06:50:01 --> Language Class Initialized
INFO - 2021-06-12 06:50:01 --> Config Class Initialized
INFO - 2021-06-12 06:50:01 --> Loader Class Initialized
INFO - 2021-06-12 06:50:01 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:01 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:01 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:01 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:01 --> Controller Class Initialized
INFO - 2021-06-12 06:50:14 --> Config Class Initialized
INFO - 2021-06-12 06:50:14 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:14 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:14 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:14 --> URI Class Initialized
INFO - 2021-06-12 06:50:14 --> Router Class Initialized
INFO - 2021-06-12 06:50:14 --> Output Class Initialized
INFO - 2021-06-12 06:50:14 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:14 --> Input Class Initialized
INFO - 2021-06-12 06:50:14 --> Language Class Initialized
INFO - 2021-06-12 06:50:14 --> Language Class Initialized
INFO - 2021-06-12 06:50:14 --> Config Class Initialized
INFO - 2021-06-12 06:50:14 --> Loader Class Initialized
INFO - 2021-06-12 06:50:14 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:14 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:14 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:14 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:14 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:14 --> Controller Class Initialized
DEBUG - 2021-06-12 06:50:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:50:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:50:14 --> Final output sent to browser
DEBUG - 2021-06-12 06:50:14 --> Total execution time: 0.0450
INFO - 2021-06-12 06:50:15 --> Config Class Initialized
INFO - 2021-06-12 06:50:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:15 --> URI Class Initialized
INFO - 2021-06-12 06:50:15 --> Router Class Initialized
INFO - 2021-06-12 06:50:15 --> Output Class Initialized
INFO - 2021-06-12 06:50:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:15 --> Input Class Initialized
INFO - 2021-06-12 06:50:15 --> Language Class Initialized
INFO - 2021-06-12 06:50:15 --> Language Class Initialized
INFO - 2021-06-12 06:50:15 --> Config Class Initialized
INFO - 2021-06-12 06:50:15 --> Loader Class Initialized
INFO - 2021-06-12 06:50:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:15 --> Controller Class Initialized
INFO - 2021-06-12 06:50:17 --> Config Class Initialized
INFO - 2021-06-12 06:50:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:17 --> URI Class Initialized
INFO - 2021-06-12 06:50:17 --> Router Class Initialized
INFO - 2021-06-12 06:50:17 --> Output Class Initialized
INFO - 2021-06-12 06:50:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:17 --> Input Class Initialized
INFO - 2021-06-12 06:50:17 --> Language Class Initialized
INFO - 2021-06-12 06:50:17 --> Language Class Initialized
INFO - 2021-06-12 06:50:17 --> Config Class Initialized
INFO - 2021-06-12 06:50:17 --> Loader Class Initialized
INFO - 2021-06-12 06:50:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:17 --> Controller Class Initialized
DEBUG - 2021-06-12 06:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:50:17 --> Final output sent to browser
DEBUG - 2021-06-12 06:50:17 --> Total execution time: 0.0446
INFO - 2021-06-12 06:50:19 --> Config Class Initialized
INFO - 2021-06-12 06:50:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:19 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:19 --> URI Class Initialized
INFO - 2021-06-12 06:50:19 --> Router Class Initialized
INFO - 2021-06-12 06:50:19 --> Output Class Initialized
INFO - 2021-06-12 06:50:19 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:19 --> Input Class Initialized
INFO - 2021-06-12 06:50:19 --> Language Class Initialized
INFO - 2021-06-12 06:50:19 --> Language Class Initialized
INFO - 2021-06-12 06:50:19 --> Config Class Initialized
INFO - 2021-06-12 06:50:19 --> Loader Class Initialized
INFO - 2021-06-12 06:50:19 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:19 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:19 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:19 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:19 --> Controller Class Initialized
INFO - 2021-06-12 06:50:36 --> Config Class Initialized
INFO - 2021-06-12 06:50:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:36 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:36 --> URI Class Initialized
INFO - 2021-06-12 06:50:36 --> Router Class Initialized
INFO - 2021-06-12 06:50:36 --> Output Class Initialized
INFO - 2021-06-12 06:50:36 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:36 --> Input Class Initialized
INFO - 2021-06-12 06:50:36 --> Language Class Initialized
INFO - 2021-06-12 06:50:36 --> Language Class Initialized
INFO - 2021-06-12 06:50:36 --> Config Class Initialized
INFO - 2021-06-12 06:50:36 --> Loader Class Initialized
INFO - 2021-06-12 06:50:36 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:36 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:36 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:36 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:36 --> Controller Class Initialized
INFO - 2021-06-12 06:50:51 --> Config Class Initialized
INFO - 2021-06-12 06:50:51 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:51 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:51 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:51 --> URI Class Initialized
INFO - 2021-06-12 06:50:51 --> Router Class Initialized
INFO - 2021-06-12 06:50:51 --> Output Class Initialized
INFO - 2021-06-12 06:50:51 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:51 --> Input Class Initialized
INFO - 2021-06-12 06:50:51 --> Language Class Initialized
INFO - 2021-06-12 06:50:51 --> Language Class Initialized
INFO - 2021-06-12 06:50:51 --> Config Class Initialized
INFO - 2021-06-12 06:50:51 --> Loader Class Initialized
INFO - 2021-06-12 06:50:51 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:51 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:51 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:51 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:51 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:51 --> Controller Class Initialized
DEBUG - 2021-06-12 06:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:50:51 --> Final output sent to browser
DEBUG - 2021-06-12 06:50:51 --> Total execution time: 0.0444
INFO - 2021-06-12 06:50:51 --> Config Class Initialized
INFO - 2021-06-12 06:50:51 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:51 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:51 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:51 --> URI Class Initialized
INFO - 2021-06-12 06:50:51 --> Router Class Initialized
INFO - 2021-06-12 06:50:51 --> Output Class Initialized
INFO - 2021-06-12 06:50:51 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:51 --> Input Class Initialized
INFO - 2021-06-12 06:50:51 --> Language Class Initialized
INFO - 2021-06-12 06:50:51 --> Language Class Initialized
INFO - 2021-06-12 06:50:51 --> Config Class Initialized
INFO - 2021-06-12 06:50:51 --> Loader Class Initialized
INFO - 2021-06-12 06:50:51 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:51 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:51 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:51 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:51 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:51 --> Controller Class Initialized
INFO - 2021-06-12 06:50:55 --> Config Class Initialized
INFO - 2021-06-12 06:50:55 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:50:55 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:50:55 --> Utf8 Class Initialized
INFO - 2021-06-12 06:50:55 --> URI Class Initialized
INFO - 2021-06-12 06:50:55 --> Router Class Initialized
INFO - 2021-06-12 06:50:55 --> Output Class Initialized
INFO - 2021-06-12 06:50:55 --> Security Class Initialized
DEBUG - 2021-06-12 06:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:50:55 --> Input Class Initialized
INFO - 2021-06-12 06:50:55 --> Language Class Initialized
INFO - 2021-06-12 06:50:55 --> Language Class Initialized
INFO - 2021-06-12 06:50:55 --> Config Class Initialized
INFO - 2021-06-12 06:50:55 --> Loader Class Initialized
INFO - 2021-06-12 06:50:55 --> Helper loaded: url_helper
INFO - 2021-06-12 06:50:55 --> Helper loaded: file_helper
INFO - 2021-06-12 06:50:55 --> Helper loaded: form_helper
INFO - 2021-06-12 06:50:55 --> Helper loaded: my_helper
INFO - 2021-06-12 06:50:55 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:50:55 --> Controller Class Initialized
DEBUG - 2021-06-12 06:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:50:55 --> Final output sent to browser
DEBUG - 2021-06-12 06:50:55 --> Total execution time: 0.0432
INFO - 2021-06-12 06:51:00 --> Config Class Initialized
INFO - 2021-06-12 06:51:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:51:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:51:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:51:00 --> URI Class Initialized
INFO - 2021-06-12 06:51:00 --> Router Class Initialized
INFO - 2021-06-12 06:51:00 --> Output Class Initialized
INFO - 2021-06-12 06:51:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:51:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:51:00 --> Input Class Initialized
INFO - 2021-06-12 06:51:00 --> Language Class Initialized
INFO - 2021-06-12 06:51:00 --> Language Class Initialized
INFO - 2021-06-12 06:51:00 --> Config Class Initialized
INFO - 2021-06-12 06:51:00 --> Loader Class Initialized
INFO - 2021-06-12 06:51:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:51:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:51:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:51:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:51:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:51:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:51:00 --> Controller Class Initialized
INFO - 2021-06-12 06:51:20 --> Config Class Initialized
INFO - 2021-06-12 06:51:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:51:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:51:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:51:20 --> URI Class Initialized
INFO - 2021-06-12 06:51:20 --> Router Class Initialized
INFO - 2021-06-12 06:51:20 --> Output Class Initialized
INFO - 2021-06-12 06:51:20 --> Security Class Initialized
DEBUG - 2021-06-12 06:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:51:20 --> Input Class Initialized
INFO - 2021-06-12 06:51:20 --> Language Class Initialized
INFO - 2021-06-12 06:51:20 --> Language Class Initialized
INFO - 2021-06-12 06:51:20 --> Config Class Initialized
INFO - 2021-06-12 06:51:20 --> Loader Class Initialized
INFO - 2021-06-12 06:51:20 --> Helper loaded: url_helper
INFO - 2021-06-12 06:51:20 --> Helper loaded: file_helper
INFO - 2021-06-12 06:51:20 --> Helper loaded: form_helper
INFO - 2021-06-12 06:51:20 --> Helper loaded: my_helper
INFO - 2021-06-12 06:51:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:51:20 --> Controller Class Initialized
INFO - 2021-06-12 06:51:36 --> Config Class Initialized
INFO - 2021-06-12 06:51:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:51:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:51:36 --> Utf8 Class Initialized
INFO - 2021-06-12 06:51:36 --> URI Class Initialized
INFO - 2021-06-12 06:51:36 --> Router Class Initialized
INFO - 2021-06-12 06:51:36 --> Output Class Initialized
INFO - 2021-06-12 06:51:36 --> Security Class Initialized
DEBUG - 2021-06-12 06:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:51:36 --> Input Class Initialized
INFO - 2021-06-12 06:51:36 --> Language Class Initialized
INFO - 2021-06-12 06:51:36 --> Language Class Initialized
INFO - 2021-06-12 06:51:36 --> Config Class Initialized
INFO - 2021-06-12 06:51:36 --> Loader Class Initialized
INFO - 2021-06-12 06:51:36 --> Helper loaded: url_helper
INFO - 2021-06-12 06:51:36 --> Helper loaded: file_helper
INFO - 2021-06-12 06:51:36 --> Helper loaded: form_helper
INFO - 2021-06-12 06:51:36 --> Helper loaded: my_helper
INFO - 2021-06-12 06:51:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:51:36 --> Controller Class Initialized
DEBUG - 2021-06-12 06:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:51:36 --> Final output sent to browser
DEBUG - 2021-06-12 06:51:36 --> Total execution time: 0.0444
INFO - 2021-06-12 06:51:36 --> Config Class Initialized
INFO - 2021-06-12 06:51:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:51:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:51:36 --> Utf8 Class Initialized
INFO - 2021-06-12 06:51:36 --> URI Class Initialized
INFO - 2021-06-12 06:51:36 --> Router Class Initialized
INFO - 2021-06-12 06:51:36 --> Output Class Initialized
INFO - 2021-06-12 06:51:36 --> Security Class Initialized
DEBUG - 2021-06-12 06:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:51:36 --> Input Class Initialized
INFO - 2021-06-12 06:51:36 --> Language Class Initialized
INFO - 2021-06-12 06:51:36 --> Language Class Initialized
INFO - 2021-06-12 06:51:36 --> Config Class Initialized
INFO - 2021-06-12 06:51:36 --> Loader Class Initialized
INFO - 2021-06-12 06:51:36 --> Helper loaded: url_helper
INFO - 2021-06-12 06:51:36 --> Helper loaded: file_helper
INFO - 2021-06-12 06:51:36 --> Helper loaded: form_helper
INFO - 2021-06-12 06:51:36 --> Helper loaded: my_helper
INFO - 2021-06-12 06:51:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:51:36 --> Controller Class Initialized
INFO - 2021-06-12 06:51:37 --> Config Class Initialized
INFO - 2021-06-12 06:51:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:51:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:51:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:51:37 --> URI Class Initialized
INFO - 2021-06-12 06:51:37 --> Router Class Initialized
INFO - 2021-06-12 06:51:37 --> Output Class Initialized
INFO - 2021-06-12 06:51:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:51:37 --> Input Class Initialized
INFO - 2021-06-12 06:51:37 --> Language Class Initialized
INFO - 2021-06-12 06:51:37 --> Language Class Initialized
INFO - 2021-06-12 06:51:37 --> Config Class Initialized
INFO - 2021-06-12 06:51:37 --> Loader Class Initialized
INFO - 2021-06-12 06:51:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:51:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:51:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:51:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:51:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:51:37 --> Controller Class Initialized
DEBUG - 2021-06-12 06:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:51:37 --> Final output sent to browser
DEBUG - 2021-06-12 06:51:37 --> Total execution time: 0.0450
INFO - 2021-06-12 06:51:39 --> Config Class Initialized
INFO - 2021-06-12 06:51:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:51:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:51:39 --> Utf8 Class Initialized
INFO - 2021-06-12 06:51:39 --> URI Class Initialized
INFO - 2021-06-12 06:51:39 --> Router Class Initialized
INFO - 2021-06-12 06:51:39 --> Output Class Initialized
INFO - 2021-06-12 06:51:39 --> Security Class Initialized
DEBUG - 2021-06-12 06:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:51:39 --> Input Class Initialized
INFO - 2021-06-12 06:51:39 --> Language Class Initialized
INFO - 2021-06-12 06:51:39 --> Language Class Initialized
INFO - 2021-06-12 06:51:39 --> Config Class Initialized
INFO - 2021-06-12 06:51:39 --> Loader Class Initialized
INFO - 2021-06-12 06:51:39 --> Helper loaded: url_helper
INFO - 2021-06-12 06:51:39 --> Helper loaded: file_helper
INFO - 2021-06-12 06:51:39 --> Helper loaded: form_helper
INFO - 2021-06-12 06:51:39 --> Helper loaded: my_helper
INFO - 2021-06-12 06:51:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:51:39 --> Controller Class Initialized
INFO - 2021-06-12 06:51:59 --> Config Class Initialized
INFO - 2021-06-12 06:51:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:51:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:51:59 --> Utf8 Class Initialized
INFO - 2021-06-12 06:51:59 --> URI Class Initialized
INFO - 2021-06-12 06:51:59 --> Router Class Initialized
INFO - 2021-06-12 06:51:59 --> Output Class Initialized
INFO - 2021-06-12 06:51:59 --> Security Class Initialized
DEBUG - 2021-06-12 06:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:51:59 --> Input Class Initialized
INFO - 2021-06-12 06:51:59 --> Language Class Initialized
INFO - 2021-06-12 06:51:59 --> Language Class Initialized
INFO - 2021-06-12 06:51:59 --> Config Class Initialized
INFO - 2021-06-12 06:51:59 --> Loader Class Initialized
INFO - 2021-06-12 06:51:59 --> Helper loaded: url_helper
INFO - 2021-06-12 06:51:59 --> Helper loaded: file_helper
INFO - 2021-06-12 06:51:59 --> Helper loaded: form_helper
INFO - 2021-06-12 06:51:59 --> Helper loaded: my_helper
INFO - 2021-06-12 06:51:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:51:59 --> Controller Class Initialized
INFO - 2021-06-12 06:52:34 --> Config Class Initialized
INFO - 2021-06-12 06:52:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:34 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:34 --> URI Class Initialized
INFO - 2021-06-12 06:52:34 --> Router Class Initialized
INFO - 2021-06-12 06:52:34 --> Output Class Initialized
INFO - 2021-06-12 06:52:34 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:34 --> Input Class Initialized
INFO - 2021-06-12 06:52:34 --> Language Class Initialized
INFO - 2021-06-12 06:52:34 --> Language Class Initialized
INFO - 2021-06-12 06:52:34 --> Config Class Initialized
INFO - 2021-06-12 06:52:34 --> Loader Class Initialized
INFO - 2021-06-12 06:52:34 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:34 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:34 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:34 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:34 --> Controller Class Initialized
INFO - 2021-06-12 06:52:34 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:52:34 --> Config Class Initialized
INFO - 2021-06-12 06:52:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:34 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:34 --> URI Class Initialized
INFO - 2021-06-12 06:52:34 --> Router Class Initialized
INFO - 2021-06-12 06:52:34 --> Output Class Initialized
INFO - 2021-06-12 06:52:34 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:34 --> Input Class Initialized
INFO - 2021-06-12 06:52:34 --> Language Class Initialized
INFO - 2021-06-12 06:52:34 --> Language Class Initialized
INFO - 2021-06-12 06:52:34 --> Config Class Initialized
INFO - 2021-06-12 06:52:34 --> Loader Class Initialized
INFO - 2021-06-12 06:52:34 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:34 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:34 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:34 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:34 --> Controller Class Initialized
DEBUG - 2021-06-12 06:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:52:34 --> Final output sent to browser
DEBUG - 2021-06-12 06:52:34 --> Total execution time: 0.0495
INFO - 2021-06-12 06:52:37 --> Config Class Initialized
INFO - 2021-06-12 06:52:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:37 --> URI Class Initialized
INFO - 2021-06-12 06:52:37 --> Router Class Initialized
INFO - 2021-06-12 06:52:37 --> Output Class Initialized
INFO - 2021-06-12 06:52:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:37 --> Input Class Initialized
INFO - 2021-06-12 06:52:37 --> Language Class Initialized
INFO - 2021-06-12 06:52:37 --> Language Class Initialized
INFO - 2021-06-12 06:52:37 --> Config Class Initialized
INFO - 2021-06-12 06:52:37 --> Loader Class Initialized
INFO - 2021-06-12 06:52:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:37 --> Controller Class Initialized
INFO - 2021-06-12 06:52:37 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:52:37 --> Config Class Initialized
INFO - 2021-06-12 06:52:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:37 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:37 --> URI Class Initialized
INFO - 2021-06-12 06:52:37 --> Router Class Initialized
INFO - 2021-06-12 06:52:37 --> Output Class Initialized
INFO - 2021-06-12 06:52:37 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:37 --> Input Class Initialized
INFO - 2021-06-12 06:52:37 --> Language Class Initialized
INFO - 2021-06-12 06:52:37 --> Language Class Initialized
INFO - 2021-06-12 06:52:37 --> Config Class Initialized
INFO - 2021-06-12 06:52:37 --> Loader Class Initialized
INFO - 2021-06-12 06:52:37 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:37 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:37 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:37 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:38 --> Controller Class Initialized
DEBUG - 2021-06-12 06:52:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:52:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:52:38 --> Final output sent to browser
DEBUG - 2021-06-12 06:52:38 --> Total execution time: 0.0505
INFO - 2021-06-12 06:52:47 --> Config Class Initialized
INFO - 2021-06-12 06:52:47 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:47 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:47 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:47 --> URI Class Initialized
INFO - 2021-06-12 06:52:47 --> Router Class Initialized
INFO - 2021-06-12 06:52:47 --> Output Class Initialized
INFO - 2021-06-12 06:52:47 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:47 --> Input Class Initialized
INFO - 2021-06-12 06:52:47 --> Language Class Initialized
INFO - 2021-06-12 06:52:47 --> Language Class Initialized
INFO - 2021-06-12 06:52:47 --> Config Class Initialized
INFO - 2021-06-12 06:52:47 --> Loader Class Initialized
INFO - 2021-06-12 06:52:47 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:47 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:47 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:47 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:47 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:47 --> Controller Class Initialized
INFO - 2021-06-12 06:52:47 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:52:47 --> Final output sent to browser
DEBUG - 2021-06-12 06:52:47 --> Total execution time: 0.0509
INFO - 2021-06-12 06:52:47 --> Config Class Initialized
INFO - 2021-06-12 06:52:47 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:47 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:47 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:47 --> URI Class Initialized
INFO - 2021-06-12 06:52:47 --> Router Class Initialized
INFO - 2021-06-12 06:52:47 --> Output Class Initialized
INFO - 2021-06-12 06:52:47 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:47 --> Input Class Initialized
INFO - 2021-06-12 06:52:47 --> Language Class Initialized
INFO - 2021-06-12 06:52:47 --> Language Class Initialized
INFO - 2021-06-12 06:52:47 --> Config Class Initialized
INFO - 2021-06-12 06:52:47 --> Loader Class Initialized
INFO - 2021-06-12 06:52:47 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:47 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:47 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:47 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:47 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:47 --> Controller Class Initialized
DEBUG - 2021-06-12 06:52:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:52:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:52:47 --> Final output sent to browser
DEBUG - 2021-06-12 06:52:47 --> Total execution time: 0.0742
INFO - 2021-06-12 06:52:49 --> Config Class Initialized
INFO - 2021-06-12 06:52:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:49 --> URI Class Initialized
INFO - 2021-06-12 06:52:49 --> Router Class Initialized
INFO - 2021-06-12 06:52:49 --> Output Class Initialized
INFO - 2021-06-12 06:52:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:49 --> Input Class Initialized
INFO - 2021-06-12 06:52:49 --> Language Class Initialized
INFO - 2021-06-12 06:52:49 --> Language Class Initialized
INFO - 2021-06-12 06:52:49 --> Config Class Initialized
INFO - 2021-06-12 06:52:49 --> Loader Class Initialized
INFO - 2021-06-12 06:52:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:49 --> Controller Class Initialized
DEBUG - 2021-06-12 06:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:52:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:52:49 --> Final output sent to browser
DEBUG - 2021-06-12 06:52:49 --> Total execution time: 0.0508
INFO - 2021-06-12 06:52:52 --> Config Class Initialized
INFO - 2021-06-12 06:52:52 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:52 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:52 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:52 --> URI Class Initialized
INFO - 2021-06-12 06:52:52 --> Router Class Initialized
INFO - 2021-06-12 06:52:52 --> Output Class Initialized
INFO - 2021-06-12 06:52:52 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:52 --> Input Class Initialized
INFO - 2021-06-12 06:52:52 --> Language Class Initialized
INFO - 2021-06-12 06:52:52 --> Language Class Initialized
INFO - 2021-06-12 06:52:52 --> Config Class Initialized
INFO - 2021-06-12 06:52:52 --> Loader Class Initialized
INFO - 2021-06-12 06:52:52 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:52 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:52 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:52 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:52 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:52 --> Controller Class Initialized
DEBUG - 2021-06-12 06:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:52:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:52:52 --> Final output sent to browser
DEBUG - 2021-06-12 06:52:52 --> Total execution time: 0.0443
INFO - 2021-06-12 06:52:53 --> Config Class Initialized
INFO - 2021-06-12 06:52:53 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:53 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:53 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:53 --> URI Class Initialized
INFO - 2021-06-12 06:52:53 --> Router Class Initialized
INFO - 2021-06-12 06:52:53 --> Output Class Initialized
INFO - 2021-06-12 06:52:53 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:53 --> Input Class Initialized
INFO - 2021-06-12 06:52:53 --> Language Class Initialized
INFO - 2021-06-12 06:52:53 --> Language Class Initialized
INFO - 2021-06-12 06:52:53 --> Config Class Initialized
INFO - 2021-06-12 06:52:53 --> Loader Class Initialized
INFO - 2021-06-12 06:52:53 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:53 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:53 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:53 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:53 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:53 --> Controller Class Initialized
INFO - 2021-06-12 06:52:54 --> Config Class Initialized
INFO - 2021-06-12 06:52:54 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:54 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:54 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:54 --> URI Class Initialized
INFO - 2021-06-12 06:52:54 --> Router Class Initialized
INFO - 2021-06-12 06:52:54 --> Output Class Initialized
INFO - 2021-06-12 06:52:54 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:54 --> Input Class Initialized
INFO - 2021-06-12 06:52:54 --> Language Class Initialized
INFO - 2021-06-12 06:52:54 --> Language Class Initialized
INFO - 2021-06-12 06:52:54 --> Config Class Initialized
INFO - 2021-06-12 06:52:54 --> Loader Class Initialized
INFO - 2021-06-12 06:52:54 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:54 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:54 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:54 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:54 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:54 --> Controller Class Initialized
DEBUG - 2021-06-12 06:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:52:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:52:54 --> Final output sent to browser
DEBUG - 2021-06-12 06:52:54 --> Total execution time: 0.0456
INFO - 2021-06-12 06:52:57 --> Config Class Initialized
INFO - 2021-06-12 06:52:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:52:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:52:57 --> Utf8 Class Initialized
INFO - 2021-06-12 06:52:57 --> URI Class Initialized
INFO - 2021-06-12 06:52:57 --> Router Class Initialized
INFO - 2021-06-12 06:52:57 --> Output Class Initialized
INFO - 2021-06-12 06:52:57 --> Security Class Initialized
DEBUG - 2021-06-12 06:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:52:57 --> Input Class Initialized
INFO - 2021-06-12 06:52:57 --> Language Class Initialized
INFO - 2021-06-12 06:52:57 --> Language Class Initialized
INFO - 2021-06-12 06:52:57 --> Config Class Initialized
INFO - 2021-06-12 06:52:57 --> Loader Class Initialized
INFO - 2021-06-12 06:52:57 --> Helper loaded: url_helper
INFO - 2021-06-12 06:52:57 --> Helper loaded: file_helper
INFO - 2021-06-12 06:52:57 --> Helper loaded: form_helper
INFO - 2021-06-12 06:52:57 --> Helper loaded: my_helper
INFO - 2021-06-12 06:52:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:52:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:52:57 --> Controller Class Initialized
INFO - 2021-06-12 06:53:33 --> Config Class Initialized
INFO - 2021-06-12 06:53:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:53:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:53:33 --> Utf8 Class Initialized
INFO - 2021-06-12 06:53:33 --> URI Class Initialized
INFO - 2021-06-12 06:53:33 --> Router Class Initialized
INFO - 2021-06-12 06:53:33 --> Output Class Initialized
INFO - 2021-06-12 06:53:33 --> Security Class Initialized
DEBUG - 2021-06-12 06:53:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:53:33 --> Input Class Initialized
INFO - 2021-06-12 06:53:33 --> Language Class Initialized
INFO - 2021-06-12 06:53:33 --> Language Class Initialized
INFO - 2021-06-12 06:53:33 --> Config Class Initialized
INFO - 2021-06-12 06:53:33 --> Loader Class Initialized
INFO - 2021-06-12 06:53:33 --> Helper loaded: url_helper
INFO - 2021-06-12 06:53:33 --> Helper loaded: file_helper
INFO - 2021-06-12 06:53:33 --> Helper loaded: form_helper
INFO - 2021-06-12 06:53:33 --> Helper loaded: my_helper
INFO - 2021-06-12 06:53:33 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:53:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:53:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:53:33 --> Controller Class Initialized
INFO - 2021-06-12 06:53:48 --> Config Class Initialized
INFO - 2021-06-12 06:53:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:53:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:53:48 --> Utf8 Class Initialized
INFO - 2021-06-12 06:53:48 --> URI Class Initialized
INFO - 2021-06-12 06:53:48 --> Router Class Initialized
INFO - 2021-06-12 06:53:48 --> Output Class Initialized
INFO - 2021-06-12 06:53:48 --> Security Class Initialized
DEBUG - 2021-06-12 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:53:48 --> Input Class Initialized
INFO - 2021-06-12 06:53:48 --> Language Class Initialized
INFO - 2021-06-12 06:53:48 --> Language Class Initialized
INFO - 2021-06-12 06:53:48 --> Config Class Initialized
INFO - 2021-06-12 06:53:48 --> Loader Class Initialized
INFO - 2021-06-12 06:53:48 --> Helper loaded: url_helper
INFO - 2021-06-12 06:53:48 --> Helper loaded: file_helper
INFO - 2021-06-12 06:53:48 --> Helper loaded: form_helper
INFO - 2021-06-12 06:53:48 --> Helper loaded: my_helper
INFO - 2021-06-12 06:53:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:53:48 --> Controller Class Initialized
DEBUG - 2021-06-12 06:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:53:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:53:48 --> Final output sent to browser
DEBUG - 2021-06-12 06:53:48 --> Total execution time: 0.0456
INFO - 2021-06-12 06:53:48 --> Config Class Initialized
INFO - 2021-06-12 06:53:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:53:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:53:48 --> Utf8 Class Initialized
INFO - 2021-06-12 06:53:48 --> URI Class Initialized
INFO - 2021-06-12 06:53:48 --> Router Class Initialized
INFO - 2021-06-12 06:53:48 --> Output Class Initialized
INFO - 2021-06-12 06:53:48 --> Security Class Initialized
DEBUG - 2021-06-12 06:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:53:48 --> Input Class Initialized
INFO - 2021-06-12 06:53:48 --> Language Class Initialized
INFO - 2021-06-12 06:53:48 --> Language Class Initialized
INFO - 2021-06-12 06:53:48 --> Config Class Initialized
INFO - 2021-06-12 06:53:48 --> Loader Class Initialized
INFO - 2021-06-12 06:53:48 --> Helper loaded: url_helper
INFO - 2021-06-12 06:53:48 --> Helper loaded: file_helper
INFO - 2021-06-12 06:53:48 --> Helper loaded: form_helper
INFO - 2021-06-12 06:53:48 --> Helper loaded: my_helper
INFO - 2021-06-12 06:53:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:53:48 --> Controller Class Initialized
INFO - 2021-06-12 06:53:49 --> Config Class Initialized
INFO - 2021-06-12 06:53:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:53:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:53:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:53:49 --> URI Class Initialized
INFO - 2021-06-12 06:53:49 --> Router Class Initialized
INFO - 2021-06-12 06:53:49 --> Output Class Initialized
INFO - 2021-06-12 06:53:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:53:49 --> Input Class Initialized
INFO - 2021-06-12 06:53:49 --> Language Class Initialized
INFO - 2021-06-12 06:53:49 --> Language Class Initialized
INFO - 2021-06-12 06:53:49 --> Config Class Initialized
INFO - 2021-06-12 06:53:49 --> Loader Class Initialized
INFO - 2021-06-12 06:53:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:53:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:53:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:53:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:53:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:53:49 --> Controller Class Initialized
DEBUG - 2021-06-12 06:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:53:49 --> Final output sent to browser
DEBUG - 2021-06-12 06:53:49 --> Total execution time: 0.0447
INFO - 2021-06-12 06:53:51 --> Config Class Initialized
INFO - 2021-06-12 06:53:51 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:53:51 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:53:51 --> Utf8 Class Initialized
INFO - 2021-06-12 06:53:51 --> URI Class Initialized
INFO - 2021-06-12 06:53:51 --> Router Class Initialized
INFO - 2021-06-12 06:53:51 --> Output Class Initialized
INFO - 2021-06-12 06:53:51 --> Security Class Initialized
DEBUG - 2021-06-12 06:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:53:51 --> Input Class Initialized
INFO - 2021-06-12 06:53:51 --> Language Class Initialized
INFO - 2021-06-12 06:53:51 --> Language Class Initialized
INFO - 2021-06-12 06:53:51 --> Config Class Initialized
INFO - 2021-06-12 06:53:51 --> Loader Class Initialized
INFO - 2021-06-12 06:53:51 --> Helper loaded: url_helper
INFO - 2021-06-12 06:53:51 --> Helper loaded: file_helper
INFO - 2021-06-12 06:53:51 --> Helper loaded: form_helper
INFO - 2021-06-12 06:53:51 --> Helper loaded: my_helper
INFO - 2021-06-12 06:53:51 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:53:51 --> Controller Class Initialized
INFO - 2021-06-12 06:54:06 --> Config Class Initialized
INFO - 2021-06-12 06:54:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:54:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:54:06 --> Utf8 Class Initialized
INFO - 2021-06-12 06:54:06 --> URI Class Initialized
INFO - 2021-06-12 06:54:06 --> Router Class Initialized
INFO - 2021-06-12 06:54:06 --> Output Class Initialized
INFO - 2021-06-12 06:54:06 --> Security Class Initialized
DEBUG - 2021-06-12 06:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:54:06 --> Input Class Initialized
INFO - 2021-06-12 06:54:06 --> Language Class Initialized
INFO - 2021-06-12 06:54:06 --> Language Class Initialized
INFO - 2021-06-12 06:54:06 --> Config Class Initialized
INFO - 2021-06-12 06:54:06 --> Loader Class Initialized
INFO - 2021-06-12 06:54:06 --> Helper loaded: url_helper
INFO - 2021-06-12 06:54:06 --> Helper loaded: file_helper
INFO - 2021-06-12 06:54:06 --> Helper loaded: form_helper
INFO - 2021-06-12 06:54:06 --> Helper loaded: my_helper
INFO - 2021-06-12 06:54:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:54:06 --> Controller Class Initialized
INFO - 2021-06-12 06:54:21 --> Config Class Initialized
INFO - 2021-06-12 06:54:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:54:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:54:21 --> Utf8 Class Initialized
INFO - 2021-06-12 06:54:21 --> URI Class Initialized
INFO - 2021-06-12 06:54:21 --> Router Class Initialized
INFO - 2021-06-12 06:54:21 --> Output Class Initialized
INFO - 2021-06-12 06:54:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:54:21 --> Input Class Initialized
INFO - 2021-06-12 06:54:21 --> Language Class Initialized
INFO - 2021-06-12 06:54:21 --> Language Class Initialized
INFO - 2021-06-12 06:54:21 --> Config Class Initialized
INFO - 2021-06-12 06:54:21 --> Loader Class Initialized
INFO - 2021-06-12 06:54:21 --> Helper loaded: url_helper
INFO - 2021-06-12 06:54:21 --> Helper loaded: file_helper
INFO - 2021-06-12 06:54:21 --> Helper loaded: form_helper
INFO - 2021-06-12 06:54:21 --> Helper loaded: my_helper
INFO - 2021-06-12 06:54:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:54:21 --> Controller Class Initialized
DEBUG - 2021-06-12 06:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:54:21 --> Final output sent to browser
DEBUG - 2021-06-12 06:54:21 --> Total execution time: 0.0454
INFO - 2021-06-12 06:54:22 --> Config Class Initialized
INFO - 2021-06-12 06:54:22 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:54:22 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:54:22 --> Utf8 Class Initialized
INFO - 2021-06-12 06:54:22 --> URI Class Initialized
INFO - 2021-06-12 06:54:22 --> Router Class Initialized
INFO - 2021-06-12 06:54:22 --> Output Class Initialized
INFO - 2021-06-12 06:54:22 --> Security Class Initialized
DEBUG - 2021-06-12 06:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:54:22 --> Input Class Initialized
INFO - 2021-06-12 06:54:22 --> Language Class Initialized
INFO - 2021-06-12 06:54:22 --> Language Class Initialized
INFO - 2021-06-12 06:54:22 --> Config Class Initialized
INFO - 2021-06-12 06:54:22 --> Loader Class Initialized
INFO - 2021-06-12 06:54:22 --> Helper loaded: url_helper
INFO - 2021-06-12 06:54:22 --> Helper loaded: file_helper
INFO - 2021-06-12 06:54:22 --> Helper loaded: form_helper
INFO - 2021-06-12 06:54:22 --> Helper loaded: my_helper
INFO - 2021-06-12 06:54:22 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:54:22 --> Controller Class Initialized
INFO - 2021-06-12 06:54:23 --> Config Class Initialized
INFO - 2021-06-12 06:54:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:54:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:54:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:54:23 --> URI Class Initialized
INFO - 2021-06-12 06:54:23 --> Router Class Initialized
INFO - 2021-06-12 06:54:23 --> Output Class Initialized
INFO - 2021-06-12 06:54:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:54:23 --> Input Class Initialized
INFO - 2021-06-12 06:54:23 --> Language Class Initialized
INFO - 2021-06-12 06:54:23 --> Language Class Initialized
INFO - 2021-06-12 06:54:23 --> Config Class Initialized
INFO - 2021-06-12 06:54:23 --> Loader Class Initialized
INFO - 2021-06-12 06:54:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:54:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:54:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:54:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:54:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:54:23 --> Controller Class Initialized
DEBUG - 2021-06-12 06:54:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:54:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:54:23 --> Final output sent to browser
DEBUG - 2021-06-12 06:54:23 --> Total execution time: 0.0451
INFO - 2021-06-12 06:54:25 --> Config Class Initialized
INFO - 2021-06-12 06:54:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:54:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:54:25 --> Utf8 Class Initialized
INFO - 2021-06-12 06:54:25 --> URI Class Initialized
INFO - 2021-06-12 06:54:25 --> Router Class Initialized
INFO - 2021-06-12 06:54:25 --> Output Class Initialized
INFO - 2021-06-12 06:54:25 --> Security Class Initialized
DEBUG - 2021-06-12 06:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:54:25 --> Input Class Initialized
INFO - 2021-06-12 06:54:25 --> Language Class Initialized
INFO - 2021-06-12 06:54:25 --> Language Class Initialized
INFO - 2021-06-12 06:54:25 --> Config Class Initialized
INFO - 2021-06-12 06:54:25 --> Loader Class Initialized
INFO - 2021-06-12 06:54:25 --> Helper loaded: url_helper
INFO - 2021-06-12 06:54:25 --> Helper loaded: file_helper
INFO - 2021-06-12 06:54:25 --> Helper loaded: form_helper
INFO - 2021-06-12 06:54:25 --> Helper loaded: my_helper
INFO - 2021-06-12 06:54:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:54:25 --> Controller Class Initialized
INFO - 2021-06-12 06:55:00 --> Config Class Initialized
INFO - 2021-06-12 06:55:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:00 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:00 --> URI Class Initialized
INFO - 2021-06-12 06:55:00 --> Router Class Initialized
INFO - 2021-06-12 06:55:00 --> Output Class Initialized
INFO - 2021-06-12 06:55:00 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:00 --> Input Class Initialized
INFO - 2021-06-12 06:55:00 --> Language Class Initialized
INFO - 2021-06-12 06:55:00 --> Language Class Initialized
INFO - 2021-06-12 06:55:00 --> Config Class Initialized
INFO - 2021-06-12 06:55:00 --> Loader Class Initialized
INFO - 2021-06-12 06:55:00 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:00 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:00 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:00 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:00 --> Controller Class Initialized
INFO - 2021-06-12 06:55:35 --> Config Class Initialized
INFO - 2021-06-12 06:55:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:35 --> URI Class Initialized
INFO - 2021-06-12 06:55:35 --> Router Class Initialized
INFO - 2021-06-12 06:55:35 --> Output Class Initialized
INFO - 2021-06-12 06:55:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:35 --> Input Class Initialized
INFO - 2021-06-12 06:55:35 --> Language Class Initialized
INFO - 2021-06-12 06:55:35 --> Language Class Initialized
INFO - 2021-06-12 06:55:35 --> Config Class Initialized
INFO - 2021-06-12 06:55:35 --> Loader Class Initialized
INFO - 2021-06-12 06:55:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:35 --> Controller Class Initialized
INFO - 2021-06-12 06:55:35 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:55:35 --> Config Class Initialized
INFO - 2021-06-12 06:55:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:35 --> URI Class Initialized
INFO - 2021-06-12 06:55:35 --> Router Class Initialized
INFO - 2021-06-12 06:55:35 --> Output Class Initialized
INFO - 2021-06-12 06:55:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:35 --> Input Class Initialized
INFO - 2021-06-12 06:55:35 --> Language Class Initialized
INFO - 2021-06-12 06:55:35 --> Language Class Initialized
INFO - 2021-06-12 06:55:35 --> Config Class Initialized
INFO - 2021-06-12 06:55:35 --> Loader Class Initialized
INFO - 2021-06-12 06:55:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:35 --> Controller Class Initialized
DEBUG - 2021-06-12 06:55:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:55:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:55:35 --> Final output sent to browser
DEBUG - 2021-06-12 06:55:35 --> Total execution time: 0.0411
INFO - 2021-06-12 06:55:42 --> Config Class Initialized
INFO - 2021-06-12 06:55:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:42 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:42 --> URI Class Initialized
INFO - 2021-06-12 06:55:42 --> Router Class Initialized
INFO - 2021-06-12 06:55:42 --> Output Class Initialized
INFO - 2021-06-12 06:55:42 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:42 --> Input Class Initialized
INFO - 2021-06-12 06:55:42 --> Language Class Initialized
INFO - 2021-06-12 06:55:42 --> Language Class Initialized
INFO - 2021-06-12 06:55:42 --> Config Class Initialized
INFO - 2021-06-12 06:55:42 --> Loader Class Initialized
INFO - 2021-06-12 06:55:42 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:42 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:42 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:42 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:42 --> Controller Class Initialized
INFO - 2021-06-12 06:55:42 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:55:42 --> Final output sent to browser
DEBUG - 2021-06-12 06:55:42 --> Total execution time: 0.0500
INFO - 2021-06-12 06:55:43 --> Config Class Initialized
INFO - 2021-06-12 06:55:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:43 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:43 --> URI Class Initialized
INFO - 2021-06-12 06:55:43 --> Router Class Initialized
INFO - 2021-06-12 06:55:43 --> Output Class Initialized
INFO - 2021-06-12 06:55:43 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:43 --> Input Class Initialized
INFO - 2021-06-12 06:55:43 --> Language Class Initialized
INFO - 2021-06-12 06:55:43 --> Language Class Initialized
INFO - 2021-06-12 06:55:43 --> Config Class Initialized
INFO - 2021-06-12 06:55:43 --> Loader Class Initialized
INFO - 2021-06-12 06:55:43 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:43 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:43 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:43 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:43 --> Controller Class Initialized
DEBUG - 2021-06-12 06:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:55:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:55:43 --> Final output sent to browser
DEBUG - 2021-06-12 06:55:43 --> Total execution time: 0.0734
INFO - 2021-06-12 06:55:45 --> Config Class Initialized
INFO - 2021-06-12 06:55:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:45 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:45 --> URI Class Initialized
INFO - 2021-06-12 06:55:45 --> Router Class Initialized
INFO - 2021-06-12 06:55:45 --> Output Class Initialized
INFO - 2021-06-12 06:55:45 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:45 --> Input Class Initialized
INFO - 2021-06-12 06:55:45 --> Language Class Initialized
INFO - 2021-06-12 06:55:45 --> Language Class Initialized
INFO - 2021-06-12 06:55:45 --> Config Class Initialized
INFO - 2021-06-12 06:55:45 --> Loader Class Initialized
INFO - 2021-06-12 06:55:45 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:45 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:45 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:45 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:45 --> Controller Class Initialized
DEBUG - 2021-06-12 06:55:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:55:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:55:45 --> Final output sent to browser
DEBUG - 2021-06-12 06:55:45 --> Total execution time: 0.0502
INFO - 2021-06-12 06:55:49 --> Config Class Initialized
INFO - 2021-06-12 06:55:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:49 --> URI Class Initialized
INFO - 2021-06-12 06:55:49 --> Router Class Initialized
INFO - 2021-06-12 06:55:49 --> Output Class Initialized
INFO - 2021-06-12 06:55:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:49 --> Input Class Initialized
INFO - 2021-06-12 06:55:49 --> Language Class Initialized
INFO - 2021-06-12 06:55:49 --> Language Class Initialized
INFO - 2021-06-12 06:55:49 --> Config Class Initialized
INFO - 2021-06-12 06:55:49 --> Loader Class Initialized
INFO - 2021-06-12 06:55:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:49 --> Controller Class Initialized
DEBUG - 2021-06-12 06:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:55:49 --> Final output sent to browser
DEBUG - 2021-06-12 06:55:49 --> Total execution time: 0.0450
INFO - 2021-06-12 06:55:49 --> Config Class Initialized
INFO - 2021-06-12 06:55:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:49 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:49 --> URI Class Initialized
INFO - 2021-06-12 06:55:49 --> Router Class Initialized
INFO - 2021-06-12 06:55:49 --> Output Class Initialized
INFO - 2021-06-12 06:55:49 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:49 --> Input Class Initialized
INFO - 2021-06-12 06:55:49 --> Language Class Initialized
INFO - 2021-06-12 06:55:49 --> Language Class Initialized
INFO - 2021-06-12 06:55:49 --> Config Class Initialized
INFO - 2021-06-12 06:55:49 --> Loader Class Initialized
INFO - 2021-06-12 06:55:49 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:49 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:49 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:49 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:49 --> Controller Class Initialized
INFO - 2021-06-12 06:55:50 --> Config Class Initialized
INFO - 2021-06-12 06:55:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:50 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:50 --> URI Class Initialized
INFO - 2021-06-12 06:55:50 --> Router Class Initialized
INFO - 2021-06-12 06:55:50 --> Output Class Initialized
INFO - 2021-06-12 06:55:50 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:50 --> Input Class Initialized
INFO - 2021-06-12 06:55:50 --> Language Class Initialized
INFO - 2021-06-12 06:55:50 --> Language Class Initialized
INFO - 2021-06-12 06:55:50 --> Config Class Initialized
INFO - 2021-06-12 06:55:50 --> Loader Class Initialized
INFO - 2021-06-12 06:55:50 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:50 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:50 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:50 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:50 --> Controller Class Initialized
DEBUG - 2021-06-12 06:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:55:50 --> Final output sent to browser
DEBUG - 2021-06-12 06:55:50 --> Total execution time: 0.0459
INFO - 2021-06-12 06:55:54 --> Config Class Initialized
INFO - 2021-06-12 06:55:54 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:54 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:54 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:54 --> URI Class Initialized
INFO - 2021-06-12 06:55:54 --> Router Class Initialized
INFO - 2021-06-12 06:55:54 --> Output Class Initialized
INFO - 2021-06-12 06:55:54 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:54 --> Input Class Initialized
INFO - 2021-06-12 06:55:54 --> Language Class Initialized
INFO - 2021-06-12 06:55:54 --> Language Class Initialized
INFO - 2021-06-12 06:55:54 --> Config Class Initialized
INFO - 2021-06-12 06:55:54 --> Loader Class Initialized
INFO - 2021-06-12 06:55:54 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:54 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:54 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:54 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:54 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:54 --> Controller Class Initialized
INFO - 2021-06-12 06:55:56 --> Config Class Initialized
INFO - 2021-06-12 06:55:56 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:55:56 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:55:56 --> Utf8 Class Initialized
INFO - 2021-06-12 06:55:56 --> URI Class Initialized
INFO - 2021-06-12 06:55:56 --> Router Class Initialized
INFO - 2021-06-12 06:55:56 --> Output Class Initialized
INFO - 2021-06-12 06:55:56 --> Security Class Initialized
DEBUG - 2021-06-12 06:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:55:56 --> Input Class Initialized
INFO - 2021-06-12 06:55:56 --> Language Class Initialized
INFO - 2021-06-12 06:55:56 --> Language Class Initialized
INFO - 2021-06-12 06:55:56 --> Config Class Initialized
INFO - 2021-06-12 06:55:56 --> Loader Class Initialized
INFO - 2021-06-12 06:55:56 --> Helper loaded: url_helper
INFO - 2021-06-12 06:55:56 --> Helper loaded: file_helper
INFO - 2021-06-12 06:55:56 --> Helper loaded: form_helper
INFO - 2021-06-12 06:55:56 --> Helper loaded: my_helper
INFO - 2021-06-12 06:55:56 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:55:56 --> Controller Class Initialized
INFO - 2021-06-12 06:55:56 --> Final output sent to browser
DEBUG - 2021-06-12 06:55:56 --> Total execution time: 0.0515
INFO - 2021-06-12 06:56:30 --> Config Class Initialized
INFO - 2021-06-12 06:56:30 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:56:30 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:56:30 --> Utf8 Class Initialized
INFO - 2021-06-12 06:56:30 --> URI Class Initialized
INFO - 2021-06-12 06:56:30 --> Router Class Initialized
INFO - 2021-06-12 06:56:30 --> Output Class Initialized
INFO - 2021-06-12 06:56:30 --> Security Class Initialized
DEBUG - 2021-06-12 06:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:56:30 --> Input Class Initialized
INFO - 2021-06-12 06:56:30 --> Language Class Initialized
INFO - 2021-06-12 06:56:30 --> Language Class Initialized
INFO - 2021-06-12 06:56:30 --> Config Class Initialized
INFO - 2021-06-12 06:56:30 --> Loader Class Initialized
INFO - 2021-06-12 06:56:30 --> Helper loaded: url_helper
INFO - 2021-06-12 06:56:30 --> Helper loaded: file_helper
INFO - 2021-06-12 06:56:30 --> Helper loaded: form_helper
INFO - 2021-06-12 06:56:30 --> Helper loaded: my_helper
INFO - 2021-06-12 06:56:30 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:56:30 --> Controller Class Initialized
INFO - 2021-06-12 06:57:08 --> Config Class Initialized
INFO - 2021-06-12 06:57:08 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:08 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:08 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:08 --> URI Class Initialized
INFO - 2021-06-12 06:57:08 --> Router Class Initialized
INFO - 2021-06-12 06:57:08 --> Output Class Initialized
INFO - 2021-06-12 06:57:08 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:08 --> Input Class Initialized
INFO - 2021-06-12 06:57:08 --> Language Class Initialized
INFO - 2021-06-12 06:57:08 --> Language Class Initialized
INFO - 2021-06-12 06:57:08 --> Config Class Initialized
INFO - 2021-06-12 06:57:08 --> Loader Class Initialized
INFO - 2021-06-12 06:57:08 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:08 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:08 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:08 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:08 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:08 --> Controller Class Initialized
INFO - 2021-06-12 06:57:08 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:57:08 --> Config Class Initialized
INFO - 2021-06-12 06:57:08 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:08 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:08 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:08 --> URI Class Initialized
INFO - 2021-06-12 06:57:08 --> Router Class Initialized
INFO - 2021-06-12 06:57:08 --> Output Class Initialized
INFO - 2021-06-12 06:57:08 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:08 --> Input Class Initialized
INFO - 2021-06-12 06:57:08 --> Language Class Initialized
INFO - 2021-06-12 06:57:08 --> Language Class Initialized
INFO - 2021-06-12 06:57:08 --> Config Class Initialized
INFO - 2021-06-12 06:57:08 --> Loader Class Initialized
INFO - 2021-06-12 06:57:08 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:08 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:08 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:08 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:08 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:08 --> Controller Class Initialized
DEBUG - 2021-06-12 06:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:57:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:57:08 --> Final output sent to browser
DEBUG - 2021-06-12 06:57:08 --> Total execution time: 0.0510
INFO - 2021-06-12 06:57:15 --> Config Class Initialized
INFO - 2021-06-12 06:57:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:15 --> URI Class Initialized
INFO - 2021-06-12 06:57:15 --> Router Class Initialized
INFO - 2021-06-12 06:57:15 --> Output Class Initialized
INFO - 2021-06-12 06:57:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:15 --> Input Class Initialized
INFO - 2021-06-12 06:57:15 --> Language Class Initialized
INFO - 2021-06-12 06:57:15 --> Language Class Initialized
INFO - 2021-06-12 06:57:15 --> Config Class Initialized
INFO - 2021-06-12 06:57:15 --> Loader Class Initialized
INFO - 2021-06-12 06:57:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:15 --> Controller Class Initialized
INFO - 2021-06-12 06:57:15 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:57:15 --> Final output sent to browser
DEBUG - 2021-06-12 06:57:15 --> Total execution time: 0.0508
INFO - 2021-06-12 06:57:15 --> Config Class Initialized
INFO - 2021-06-12 06:57:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:15 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:15 --> URI Class Initialized
INFO - 2021-06-12 06:57:15 --> Router Class Initialized
INFO - 2021-06-12 06:57:15 --> Output Class Initialized
INFO - 2021-06-12 06:57:15 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:15 --> Input Class Initialized
INFO - 2021-06-12 06:57:15 --> Language Class Initialized
INFO - 2021-06-12 06:57:15 --> Language Class Initialized
INFO - 2021-06-12 06:57:15 --> Config Class Initialized
INFO - 2021-06-12 06:57:15 --> Loader Class Initialized
INFO - 2021-06-12 06:57:15 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:15 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:15 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:15 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:15 --> Controller Class Initialized
DEBUG - 2021-06-12 06:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:57:15 --> Final output sent to browser
DEBUG - 2021-06-12 06:57:15 --> Total execution time: 0.0845
INFO - 2021-06-12 06:57:17 --> Config Class Initialized
INFO - 2021-06-12 06:57:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:17 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:17 --> URI Class Initialized
INFO - 2021-06-12 06:57:17 --> Router Class Initialized
INFO - 2021-06-12 06:57:17 --> Output Class Initialized
INFO - 2021-06-12 06:57:17 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:17 --> Input Class Initialized
INFO - 2021-06-12 06:57:17 --> Language Class Initialized
INFO - 2021-06-12 06:57:17 --> Language Class Initialized
INFO - 2021-06-12 06:57:17 --> Config Class Initialized
INFO - 2021-06-12 06:57:17 --> Loader Class Initialized
INFO - 2021-06-12 06:57:17 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:17 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:17 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:17 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:17 --> Controller Class Initialized
DEBUG - 2021-06-12 06:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:57:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:57:17 --> Final output sent to browser
DEBUG - 2021-06-12 06:57:17 --> Total execution time: 0.0438
INFO - 2021-06-12 06:57:19 --> Config Class Initialized
INFO - 2021-06-12 06:57:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:19 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:19 --> URI Class Initialized
INFO - 2021-06-12 06:57:19 --> Router Class Initialized
INFO - 2021-06-12 06:57:19 --> Output Class Initialized
INFO - 2021-06-12 06:57:19 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:19 --> Input Class Initialized
INFO - 2021-06-12 06:57:19 --> Language Class Initialized
INFO - 2021-06-12 06:57:19 --> Language Class Initialized
INFO - 2021-06-12 06:57:19 --> Config Class Initialized
INFO - 2021-06-12 06:57:19 --> Loader Class Initialized
INFO - 2021-06-12 06:57:19 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:19 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:19 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:19 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:19 --> Controller Class Initialized
DEBUG - 2021-06-12 06:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:57:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:57:19 --> Final output sent to browser
DEBUG - 2021-06-12 06:57:19 --> Total execution time: 0.0441
INFO - 2021-06-12 06:57:19 --> Config Class Initialized
INFO - 2021-06-12 06:57:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:19 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:19 --> URI Class Initialized
INFO - 2021-06-12 06:57:19 --> Router Class Initialized
INFO - 2021-06-12 06:57:19 --> Output Class Initialized
INFO - 2021-06-12 06:57:19 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:19 --> Input Class Initialized
INFO - 2021-06-12 06:57:19 --> Language Class Initialized
INFO - 2021-06-12 06:57:19 --> Language Class Initialized
INFO - 2021-06-12 06:57:19 --> Config Class Initialized
INFO - 2021-06-12 06:57:19 --> Loader Class Initialized
INFO - 2021-06-12 06:57:19 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:19 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:19 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:19 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:19 --> Controller Class Initialized
INFO - 2021-06-12 06:57:20 --> Config Class Initialized
INFO - 2021-06-12 06:57:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:20 --> URI Class Initialized
INFO - 2021-06-12 06:57:21 --> Router Class Initialized
INFO - 2021-06-12 06:57:21 --> Output Class Initialized
INFO - 2021-06-12 06:57:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:21 --> Input Class Initialized
INFO - 2021-06-12 06:57:21 --> Language Class Initialized
INFO - 2021-06-12 06:57:21 --> Language Class Initialized
INFO - 2021-06-12 06:57:21 --> Config Class Initialized
INFO - 2021-06-12 06:57:21 --> Loader Class Initialized
INFO - 2021-06-12 06:57:21 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:21 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:21 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:21 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:21 --> Controller Class Initialized
DEBUG - 2021-06-12 06:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:57:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:57:21 --> Final output sent to browser
DEBUG - 2021-06-12 06:57:21 --> Total execution time: 0.0437
INFO - 2021-06-12 06:57:23 --> Config Class Initialized
INFO - 2021-06-12 06:57:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:23 --> URI Class Initialized
INFO - 2021-06-12 06:57:23 --> Router Class Initialized
INFO - 2021-06-12 06:57:23 --> Output Class Initialized
INFO - 2021-06-12 06:57:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:23 --> Input Class Initialized
INFO - 2021-06-12 06:57:23 --> Language Class Initialized
INFO - 2021-06-12 06:57:23 --> Language Class Initialized
INFO - 2021-06-12 06:57:23 --> Config Class Initialized
INFO - 2021-06-12 06:57:23 --> Loader Class Initialized
INFO - 2021-06-12 06:57:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:23 --> Controller Class Initialized
INFO - 2021-06-12 06:57:23 --> Final output sent to browser
DEBUG - 2021-06-12 06:57:23 --> Total execution time: 0.0498
INFO - 2021-06-12 06:57:26 --> Config Class Initialized
INFO - 2021-06-12 06:57:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:57:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:57:26 --> Utf8 Class Initialized
INFO - 2021-06-12 06:57:26 --> URI Class Initialized
INFO - 2021-06-12 06:57:26 --> Router Class Initialized
INFO - 2021-06-12 06:57:26 --> Output Class Initialized
INFO - 2021-06-12 06:57:26 --> Security Class Initialized
DEBUG - 2021-06-12 06:57:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:57:26 --> Input Class Initialized
INFO - 2021-06-12 06:57:26 --> Language Class Initialized
INFO - 2021-06-12 06:57:26 --> Language Class Initialized
INFO - 2021-06-12 06:57:26 --> Config Class Initialized
INFO - 2021-06-12 06:57:26 --> Loader Class Initialized
INFO - 2021-06-12 06:57:26 --> Helper loaded: url_helper
INFO - 2021-06-12 06:57:26 --> Helper loaded: file_helper
INFO - 2021-06-12 06:57:26 --> Helper loaded: form_helper
INFO - 2021-06-12 06:57:26 --> Helper loaded: my_helper
INFO - 2021-06-12 06:57:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:57:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:57:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:57:26 --> Controller Class Initialized
INFO - 2021-06-12 06:58:09 --> Config Class Initialized
INFO - 2021-06-12 06:58:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:09 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:09 --> URI Class Initialized
INFO - 2021-06-12 06:58:09 --> Router Class Initialized
INFO - 2021-06-12 06:58:09 --> Output Class Initialized
INFO - 2021-06-12 06:58:09 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:09 --> Input Class Initialized
INFO - 2021-06-12 06:58:09 --> Language Class Initialized
INFO - 2021-06-12 06:58:09 --> Language Class Initialized
INFO - 2021-06-12 06:58:09 --> Config Class Initialized
INFO - 2021-06-12 06:58:09 --> Loader Class Initialized
INFO - 2021-06-12 06:58:09 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:09 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:09 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:09 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:09 --> Controller Class Initialized
INFO - 2021-06-12 06:58:09 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:58:09 --> Config Class Initialized
INFO - 2021-06-12 06:58:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:09 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:09 --> URI Class Initialized
INFO - 2021-06-12 06:58:09 --> Router Class Initialized
INFO - 2021-06-12 06:58:09 --> Output Class Initialized
INFO - 2021-06-12 06:58:09 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:09 --> Input Class Initialized
INFO - 2021-06-12 06:58:09 --> Language Class Initialized
INFO - 2021-06-12 06:58:09 --> Language Class Initialized
INFO - 2021-06-12 06:58:09 --> Config Class Initialized
INFO - 2021-06-12 06:58:09 --> Loader Class Initialized
INFO - 2021-06-12 06:58:09 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:09 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:09 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:09 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:09 --> Controller Class Initialized
DEBUG - 2021-06-12 06:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:58:09 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:09 --> Total execution time: 0.0509
INFO - 2021-06-12 06:58:14 --> Config Class Initialized
INFO - 2021-06-12 06:58:14 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:14 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:14 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:14 --> URI Class Initialized
INFO - 2021-06-12 06:58:14 --> Router Class Initialized
INFO - 2021-06-12 06:58:14 --> Output Class Initialized
INFO - 2021-06-12 06:58:14 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:14 --> Input Class Initialized
INFO - 2021-06-12 06:58:14 --> Language Class Initialized
INFO - 2021-06-12 06:58:14 --> Language Class Initialized
INFO - 2021-06-12 06:58:14 --> Config Class Initialized
INFO - 2021-06-12 06:58:14 --> Loader Class Initialized
INFO - 2021-06-12 06:58:14 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:14 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:14 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:14 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:14 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:14 --> Controller Class Initialized
INFO - 2021-06-12 06:58:14 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:14 --> Total execution time: 0.0494
INFO - 2021-06-12 06:58:18 --> Config Class Initialized
INFO - 2021-06-12 06:58:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:18 --> URI Class Initialized
INFO - 2021-06-12 06:58:18 --> Router Class Initialized
INFO - 2021-06-12 06:58:18 --> Output Class Initialized
INFO - 2021-06-12 06:58:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:18 --> Input Class Initialized
INFO - 2021-06-12 06:58:18 --> Language Class Initialized
INFO - 2021-06-12 06:58:18 --> Language Class Initialized
INFO - 2021-06-12 06:58:18 --> Config Class Initialized
INFO - 2021-06-12 06:58:18 --> Loader Class Initialized
INFO - 2021-06-12 06:58:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:18 --> Controller Class Initialized
INFO - 2021-06-12 06:58:18 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:58:18 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:18 --> Total execution time: 0.0503
INFO - 2021-06-12 06:58:18 --> Config Class Initialized
INFO - 2021-06-12 06:58:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:18 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:18 --> URI Class Initialized
INFO - 2021-06-12 06:58:18 --> Router Class Initialized
INFO - 2021-06-12 06:58:18 --> Output Class Initialized
INFO - 2021-06-12 06:58:18 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:18 --> Input Class Initialized
INFO - 2021-06-12 06:58:18 --> Language Class Initialized
INFO - 2021-06-12 06:58:18 --> Language Class Initialized
INFO - 2021-06-12 06:58:18 --> Config Class Initialized
INFO - 2021-06-12 06:58:18 --> Loader Class Initialized
INFO - 2021-06-12 06:58:18 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:18 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:18 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:18 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:18 --> Controller Class Initialized
DEBUG - 2021-06-12 06:58:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:58:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:58:18 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:18 --> Total execution time: 0.0738
INFO - 2021-06-12 06:58:20 --> Config Class Initialized
INFO - 2021-06-12 06:58:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:20 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:20 --> URI Class Initialized
INFO - 2021-06-12 06:58:20 --> Router Class Initialized
INFO - 2021-06-12 06:58:20 --> Output Class Initialized
INFO - 2021-06-12 06:58:20 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:20 --> Input Class Initialized
INFO - 2021-06-12 06:58:20 --> Language Class Initialized
INFO - 2021-06-12 06:58:20 --> Language Class Initialized
INFO - 2021-06-12 06:58:20 --> Config Class Initialized
INFO - 2021-06-12 06:58:20 --> Loader Class Initialized
INFO - 2021-06-12 06:58:20 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:20 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:20 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:20 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:20 --> Controller Class Initialized
DEBUG - 2021-06-12 06:58:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-06-12 06:58:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:58:20 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:20 --> Total execution time: 0.0792
INFO - 2021-06-12 06:58:21 --> Config Class Initialized
INFO - 2021-06-12 06:58:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:21 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:21 --> URI Class Initialized
INFO - 2021-06-12 06:58:21 --> Router Class Initialized
INFO - 2021-06-12 06:58:21 --> Output Class Initialized
INFO - 2021-06-12 06:58:21 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:21 --> Input Class Initialized
INFO - 2021-06-12 06:58:21 --> Language Class Initialized
INFO - 2021-06-12 06:58:21 --> Language Class Initialized
INFO - 2021-06-12 06:58:21 --> Config Class Initialized
INFO - 2021-06-12 06:58:21 --> Loader Class Initialized
INFO - 2021-06-12 06:58:21 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:21 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:21 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:21 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:21 --> Controller Class Initialized
INFO - 2021-06-12 06:58:23 --> Config Class Initialized
INFO - 2021-06-12 06:58:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:23 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:23 --> URI Class Initialized
INFO - 2021-06-12 06:58:23 --> Router Class Initialized
INFO - 2021-06-12 06:58:23 --> Output Class Initialized
INFO - 2021-06-12 06:58:23 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:23 --> Input Class Initialized
INFO - 2021-06-12 06:58:23 --> Language Class Initialized
INFO - 2021-06-12 06:58:23 --> Language Class Initialized
INFO - 2021-06-12 06:58:23 --> Config Class Initialized
INFO - 2021-06-12 06:58:23 --> Loader Class Initialized
INFO - 2021-06-12 06:58:23 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:23 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:23 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:23 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:23 --> Controller Class Initialized
INFO - 2021-06-12 06:58:24 --> Config Class Initialized
INFO - 2021-06-12 06:58:24 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:24 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:24 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:24 --> URI Class Initialized
INFO - 2021-06-12 06:58:24 --> Router Class Initialized
INFO - 2021-06-12 06:58:24 --> Output Class Initialized
INFO - 2021-06-12 06:58:24 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:24 --> Input Class Initialized
INFO - 2021-06-12 06:58:24 --> Language Class Initialized
INFO - 2021-06-12 06:58:24 --> Language Class Initialized
INFO - 2021-06-12 06:58:24 --> Config Class Initialized
INFO - 2021-06-12 06:58:24 --> Loader Class Initialized
INFO - 2021-06-12 06:58:24 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:24 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:24 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:24 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:24 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:24 --> Controller Class Initialized
INFO - 2021-06-12 06:58:25 --> Config Class Initialized
INFO - 2021-06-12 06:58:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:25 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:25 --> URI Class Initialized
INFO - 2021-06-12 06:58:25 --> Router Class Initialized
INFO - 2021-06-12 06:58:25 --> Output Class Initialized
INFO - 2021-06-12 06:58:25 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:25 --> Input Class Initialized
INFO - 2021-06-12 06:58:25 --> Language Class Initialized
INFO - 2021-06-12 06:58:25 --> Language Class Initialized
INFO - 2021-06-12 06:58:25 --> Config Class Initialized
INFO - 2021-06-12 06:58:25 --> Loader Class Initialized
INFO - 2021-06-12 06:58:25 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:25 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:25 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:25 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:25 --> Controller Class Initialized
INFO - 2021-06-12 06:58:34 --> Config Class Initialized
INFO - 2021-06-12 06:58:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:34 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:34 --> URI Class Initialized
INFO - 2021-06-12 06:58:34 --> Router Class Initialized
INFO - 2021-06-12 06:58:34 --> Output Class Initialized
INFO - 2021-06-12 06:58:34 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:34 --> Input Class Initialized
INFO - 2021-06-12 06:58:34 --> Language Class Initialized
INFO - 2021-06-12 06:58:34 --> Language Class Initialized
INFO - 2021-06-12 06:58:34 --> Config Class Initialized
INFO - 2021-06-12 06:58:34 --> Loader Class Initialized
INFO - 2021-06-12 06:58:34 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:34 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:34 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:34 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:34 --> Controller Class Initialized
INFO - 2021-06-12 06:58:34 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:58:34 --> Config Class Initialized
INFO - 2021-06-12 06:58:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:34 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:34 --> URI Class Initialized
INFO - 2021-06-12 06:58:34 --> Router Class Initialized
INFO - 2021-06-12 06:58:34 --> Output Class Initialized
INFO - 2021-06-12 06:58:34 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:34 --> Input Class Initialized
INFO - 2021-06-12 06:58:34 --> Language Class Initialized
INFO - 2021-06-12 06:58:34 --> Language Class Initialized
INFO - 2021-06-12 06:58:34 --> Config Class Initialized
INFO - 2021-06-12 06:58:34 --> Loader Class Initialized
INFO - 2021-06-12 06:58:34 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:34 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:34 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:34 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:34 --> Controller Class Initialized
DEBUG - 2021-06-12 06:58:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 06:58:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:58:34 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:34 --> Total execution time: 0.0394
INFO - 2021-06-12 06:58:39 --> Config Class Initialized
INFO - 2021-06-12 06:58:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:39 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:39 --> URI Class Initialized
INFO - 2021-06-12 06:58:39 --> Router Class Initialized
INFO - 2021-06-12 06:58:39 --> Output Class Initialized
INFO - 2021-06-12 06:58:39 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:39 --> Input Class Initialized
INFO - 2021-06-12 06:58:39 --> Language Class Initialized
INFO - 2021-06-12 06:58:39 --> Language Class Initialized
INFO - 2021-06-12 06:58:39 --> Config Class Initialized
INFO - 2021-06-12 06:58:39 --> Loader Class Initialized
INFO - 2021-06-12 06:58:39 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:39 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:39 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:39 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:39 --> Controller Class Initialized
INFO - 2021-06-12 06:58:39 --> Helper loaded: cookie_helper
INFO - 2021-06-12 06:58:39 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:39 --> Total execution time: 0.0516
INFO - 2021-06-12 06:58:40 --> Config Class Initialized
INFO - 2021-06-12 06:58:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:40 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:40 --> URI Class Initialized
INFO - 2021-06-12 06:58:40 --> Router Class Initialized
INFO - 2021-06-12 06:58:40 --> Output Class Initialized
INFO - 2021-06-12 06:58:40 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:40 --> Input Class Initialized
INFO - 2021-06-12 06:58:40 --> Language Class Initialized
INFO - 2021-06-12 06:58:40 --> Language Class Initialized
INFO - 2021-06-12 06:58:40 --> Config Class Initialized
INFO - 2021-06-12 06:58:40 --> Loader Class Initialized
INFO - 2021-06-12 06:58:40 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:40 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:40 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:40 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:40 --> Controller Class Initialized
DEBUG - 2021-06-12 06:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 06:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:58:40 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:40 --> Total execution time: 0.0817
INFO - 2021-06-12 06:58:41 --> Config Class Initialized
INFO - 2021-06-12 06:58:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:58:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:58:41 --> Utf8 Class Initialized
INFO - 2021-06-12 06:58:41 --> URI Class Initialized
INFO - 2021-06-12 06:58:41 --> Router Class Initialized
INFO - 2021-06-12 06:58:41 --> Output Class Initialized
INFO - 2021-06-12 06:58:41 --> Security Class Initialized
DEBUG - 2021-06-12 06:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:58:41 --> Input Class Initialized
INFO - 2021-06-12 06:58:41 --> Language Class Initialized
INFO - 2021-06-12 06:58:41 --> Language Class Initialized
INFO - 2021-06-12 06:58:41 --> Config Class Initialized
INFO - 2021-06-12 06:58:41 --> Loader Class Initialized
INFO - 2021-06-12 06:58:41 --> Helper loaded: url_helper
INFO - 2021-06-12 06:58:41 --> Helper loaded: file_helper
INFO - 2021-06-12 06:58:41 --> Helper loaded: form_helper
INFO - 2021-06-12 06:58:41 --> Helper loaded: my_helper
INFO - 2021-06-12 06:58:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:58:41 --> Controller Class Initialized
DEBUG - 2021-06-12 06:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 06:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:58:41 --> Final output sent to browser
DEBUG - 2021-06-12 06:58:41 --> Total execution time: 0.0501
INFO - 2021-06-12 06:59:06 --> Config Class Initialized
INFO - 2021-06-12 06:59:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:06 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:06 --> URI Class Initialized
INFO - 2021-06-12 06:59:06 --> Router Class Initialized
INFO - 2021-06-12 06:59:06 --> Output Class Initialized
INFO - 2021-06-12 06:59:06 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:06 --> Input Class Initialized
INFO - 2021-06-12 06:59:06 --> Language Class Initialized
INFO - 2021-06-12 06:59:06 --> Language Class Initialized
INFO - 2021-06-12 06:59:06 --> Config Class Initialized
INFO - 2021-06-12 06:59:06 --> Loader Class Initialized
INFO - 2021-06-12 06:59:06 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:06 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:06 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:06 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:06 --> Controller Class Initialized
DEBUG - 2021-06-12 06:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:59:06 --> Final output sent to browser
DEBUG - 2021-06-12 06:59:06 --> Total execution time: 0.0453
INFO - 2021-06-12 06:59:08 --> Config Class Initialized
INFO - 2021-06-12 06:59:08 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:08 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:08 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:08 --> URI Class Initialized
INFO - 2021-06-12 06:59:08 --> Router Class Initialized
INFO - 2021-06-12 06:59:08 --> Output Class Initialized
INFO - 2021-06-12 06:59:08 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:08 --> Input Class Initialized
INFO - 2021-06-12 06:59:08 --> Language Class Initialized
INFO - 2021-06-12 06:59:08 --> Language Class Initialized
INFO - 2021-06-12 06:59:08 --> Config Class Initialized
INFO - 2021-06-12 06:59:08 --> Loader Class Initialized
INFO - 2021-06-12 06:59:08 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:08 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:08 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:08 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:08 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:08 --> Controller Class Initialized
INFO - 2021-06-12 06:59:09 --> Config Class Initialized
INFO - 2021-06-12 06:59:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:09 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:09 --> URI Class Initialized
INFO - 2021-06-12 06:59:09 --> Router Class Initialized
INFO - 2021-06-12 06:59:09 --> Output Class Initialized
INFO - 2021-06-12 06:59:09 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:09 --> Input Class Initialized
INFO - 2021-06-12 06:59:09 --> Language Class Initialized
INFO - 2021-06-12 06:59:09 --> Language Class Initialized
INFO - 2021-06-12 06:59:09 --> Config Class Initialized
INFO - 2021-06-12 06:59:09 --> Loader Class Initialized
INFO - 2021-06-12 06:59:09 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:09 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:09 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:09 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:09 --> Controller Class Initialized
INFO - 2021-06-12 06:59:09 --> Final output sent to browser
DEBUG - 2021-06-12 06:59:09 --> Total execution time: 0.0524
INFO - 2021-06-12 06:59:32 --> Config Class Initialized
INFO - 2021-06-12 06:59:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:32 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:32 --> URI Class Initialized
INFO - 2021-06-12 06:59:32 --> Router Class Initialized
INFO - 2021-06-12 06:59:32 --> Output Class Initialized
INFO - 2021-06-12 06:59:32 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:32 --> Input Class Initialized
INFO - 2021-06-12 06:59:32 --> Language Class Initialized
INFO - 2021-06-12 06:59:32 --> Language Class Initialized
INFO - 2021-06-12 06:59:32 --> Config Class Initialized
INFO - 2021-06-12 06:59:32 --> Loader Class Initialized
INFO - 2021-06-12 06:59:32 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:32 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:32 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:32 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:32 --> Controller Class Initialized
DEBUG - 2021-06-12 06:59:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 06:59:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:59:32 --> Final output sent to browser
DEBUG - 2021-06-12 06:59:32 --> Total execution time: 0.0491
INFO - 2021-06-12 06:59:32 --> Config Class Initialized
INFO - 2021-06-12 06:59:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:32 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:32 --> URI Class Initialized
INFO - 2021-06-12 06:59:32 --> Router Class Initialized
INFO - 2021-06-12 06:59:32 --> Output Class Initialized
INFO - 2021-06-12 06:59:32 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:32 --> Input Class Initialized
INFO - 2021-06-12 06:59:32 --> Language Class Initialized
INFO - 2021-06-12 06:59:32 --> Language Class Initialized
INFO - 2021-06-12 06:59:32 --> Config Class Initialized
INFO - 2021-06-12 06:59:32 --> Loader Class Initialized
INFO - 2021-06-12 06:59:32 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:32 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:32 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:32 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:32 --> Controller Class Initialized
INFO - 2021-06-12 06:59:33 --> Config Class Initialized
INFO - 2021-06-12 06:59:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:33 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:33 --> URI Class Initialized
INFO - 2021-06-12 06:59:33 --> Router Class Initialized
INFO - 2021-06-12 06:59:33 --> Output Class Initialized
INFO - 2021-06-12 06:59:33 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:33 --> Input Class Initialized
INFO - 2021-06-12 06:59:33 --> Language Class Initialized
INFO - 2021-06-12 06:59:33 --> Language Class Initialized
INFO - 2021-06-12 06:59:33 --> Config Class Initialized
INFO - 2021-06-12 06:59:33 --> Loader Class Initialized
INFO - 2021-06-12 06:59:33 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:33 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:33 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:33 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:33 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:33 --> Controller Class Initialized
DEBUG - 2021-06-12 06:59:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 06:59:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 06:59:33 --> Final output sent to browser
DEBUG - 2021-06-12 06:59:33 --> Total execution time: 0.0442
INFO - 2021-06-12 06:59:35 --> Config Class Initialized
INFO - 2021-06-12 06:59:35 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:35 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:35 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:35 --> URI Class Initialized
INFO - 2021-06-12 06:59:35 --> Router Class Initialized
INFO - 2021-06-12 06:59:35 --> Output Class Initialized
INFO - 2021-06-12 06:59:35 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:35 --> Input Class Initialized
INFO - 2021-06-12 06:59:35 --> Language Class Initialized
INFO - 2021-06-12 06:59:35 --> Language Class Initialized
INFO - 2021-06-12 06:59:35 --> Config Class Initialized
INFO - 2021-06-12 06:59:35 --> Loader Class Initialized
INFO - 2021-06-12 06:59:35 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:35 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:35 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:35 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:35 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:35 --> Controller Class Initialized
INFO - 2021-06-12 06:59:54 --> Config Class Initialized
INFO - 2021-06-12 06:59:54 --> Hooks Class Initialized
DEBUG - 2021-06-12 06:59:54 --> UTF-8 Support Enabled
INFO - 2021-06-12 06:59:54 --> Utf8 Class Initialized
INFO - 2021-06-12 06:59:54 --> URI Class Initialized
INFO - 2021-06-12 06:59:54 --> Router Class Initialized
INFO - 2021-06-12 06:59:54 --> Output Class Initialized
INFO - 2021-06-12 06:59:54 --> Security Class Initialized
DEBUG - 2021-06-12 06:59:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 06:59:54 --> Input Class Initialized
INFO - 2021-06-12 06:59:54 --> Language Class Initialized
INFO - 2021-06-12 06:59:54 --> Language Class Initialized
INFO - 2021-06-12 06:59:54 --> Config Class Initialized
INFO - 2021-06-12 06:59:54 --> Loader Class Initialized
INFO - 2021-06-12 06:59:54 --> Helper loaded: url_helper
INFO - 2021-06-12 06:59:54 --> Helper loaded: file_helper
INFO - 2021-06-12 06:59:54 --> Helper loaded: form_helper
INFO - 2021-06-12 06:59:54 --> Helper loaded: my_helper
INFO - 2021-06-12 06:59:54 --> Database Driver Class Initialized
DEBUG - 2021-06-12 06:59:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 06:59:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 06:59:54 --> Controller Class Initialized
INFO - 2021-06-12 07:00:32 --> Config Class Initialized
INFO - 2021-06-12 07:00:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:00:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:00:32 --> Utf8 Class Initialized
INFO - 2021-06-12 07:00:32 --> URI Class Initialized
INFO - 2021-06-12 07:00:32 --> Router Class Initialized
INFO - 2021-06-12 07:00:32 --> Output Class Initialized
INFO - 2021-06-12 07:00:32 --> Security Class Initialized
DEBUG - 2021-06-12 07:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:00:32 --> Input Class Initialized
INFO - 2021-06-12 07:00:32 --> Language Class Initialized
INFO - 2021-06-12 07:00:32 --> Language Class Initialized
INFO - 2021-06-12 07:00:32 --> Config Class Initialized
INFO - 2021-06-12 07:00:32 --> Loader Class Initialized
INFO - 2021-06-12 07:00:32 --> Helper loaded: url_helper
INFO - 2021-06-12 07:00:32 --> Helper loaded: file_helper
INFO - 2021-06-12 07:00:32 --> Helper loaded: form_helper
INFO - 2021-06-12 07:00:32 --> Helper loaded: my_helper
INFO - 2021-06-12 07:00:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:00:32 --> Controller Class Initialized
INFO - 2021-06-12 07:00:32 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:00:32 --> Config Class Initialized
INFO - 2021-06-12 07:00:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:00:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:00:32 --> Utf8 Class Initialized
INFO - 2021-06-12 07:00:32 --> URI Class Initialized
INFO - 2021-06-12 07:00:32 --> Router Class Initialized
INFO - 2021-06-12 07:00:32 --> Output Class Initialized
INFO - 2021-06-12 07:00:32 --> Security Class Initialized
DEBUG - 2021-06-12 07:00:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:00:32 --> Input Class Initialized
INFO - 2021-06-12 07:00:32 --> Language Class Initialized
INFO - 2021-06-12 07:00:32 --> Language Class Initialized
INFO - 2021-06-12 07:00:32 --> Config Class Initialized
INFO - 2021-06-12 07:00:32 --> Loader Class Initialized
INFO - 2021-06-12 07:00:32 --> Helper loaded: url_helper
INFO - 2021-06-12 07:00:32 --> Helper loaded: file_helper
INFO - 2021-06-12 07:00:32 --> Helper loaded: form_helper
INFO - 2021-06-12 07:00:32 --> Helper loaded: my_helper
INFO - 2021-06-12 07:00:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:00:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:00:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:00:32 --> Controller Class Initialized
DEBUG - 2021-06-12 07:00:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 07:00:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:00:32 --> Final output sent to browser
DEBUG - 2021-06-12 07:00:32 --> Total execution time: 0.0489
INFO - 2021-06-12 07:00:38 --> Config Class Initialized
INFO - 2021-06-12 07:00:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:00:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:00:38 --> Utf8 Class Initialized
INFO - 2021-06-12 07:00:38 --> URI Class Initialized
INFO - 2021-06-12 07:00:38 --> Router Class Initialized
INFO - 2021-06-12 07:00:38 --> Output Class Initialized
INFO - 2021-06-12 07:00:38 --> Security Class Initialized
DEBUG - 2021-06-12 07:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:00:38 --> Input Class Initialized
INFO - 2021-06-12 07:00:38 --> Language Class Initialized
INFO - 2021-06-12 07:00:38 --> Language Class Initialized
INFO - 2021-06-12 07:00:38 --> Config Class Initialized
INFO - 2021-06-12 07:00:38 --> Loader Class Initialized
INFO - 2021-06-12 07:00:38 --> Helper loaded: url_helper
INFO - 2021-06-12 07:00:38 --> Helper loaded: file_helper
INFO - 2021-06-12 07:00:38 --> Helper loaded: form_helper
INFO - 2021-06-12 07:00:38 --> Helper loaded: my_helper
INFO - 2021-06-12 07:00:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:00:38 --> Controller Class Initialized
INFO - 2021-06-12 07:00:38 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:00:38 --> Final output sent to browser
DEBUG - 2021-06-12 07:00:38 --> Total execution time: 0.0517
INFO - 2021-06-12 07:00:39 --> Config Class Initialized
INFO - 2021-06-12 07:00:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:00:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:00:39 --> Utf8 Class Initialized
INFO - 2021-06-12 07:00:39 --> URI Class Initialized
INFO - 2021-06-12 07:00:39 --> Router Class Initialized
INFO - 2021-06-12 07:00:39 --> Output Class Initialized
INFO - 2021-06-12 07:00:39 --> Security Class Initialized
DEBUG - 2021-06-12 07:00:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:00:39 --> Input Class Initialized
INFO - 2021-06-12 07:00:39 --> Language Class Initialized
INFO - 2021-06-12 07:00:39 --> Language Class Initialized
INFO - 2021-06-12 07:00:39 --> Config Class Initialized
INFO - 2021-06-12 07:00:39 --> Loader Class Initialized
INFO - 2021-06-12 07:00:39 --> Helper loaded: url_helper
INFO - 2021-06-12 07:00:39 --> Helper loaded: file_helper
INFO - 2021-06-12 07:00:39 --> Helper loaded: form_helper
INFO - 2021-06-12 07:00:39 --> Helper loaded: my_helper
INFO - 2021-06-12 07:00:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:00:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:00:39 --> Controller Class Initialized
DEBUG - 2021-06-12 07:00:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 07:00:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:00:39 --> Final output sent to browser
DEBUG - 2021-06-12 07:00:39 --> Total execution time: 0.0846
INFO - 2021-06-12 07:00:42 --> Config Class Initialized
INFO - 2021-06-12 07:00:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:00:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:00:42 --> Utf8 Class Initialized
INFO - 2021-06-12 07:00:42 --> URI Class Initialized
INFO - 2021-06-12 07:00:42 --> Router Class Initialized
INFO - 2021-06-12 07:00:42 --> Output Class Initialized
INFO - 2021-06-12 07:00:42 --> Security Class Initialized
DEBUG - 2021-06-12 07:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:00:42 --> Input Class Initialized
INFO - 2021-06-12 07:00:42 --> Language Class Initialized
INFO - 2021-06-12 07:00:42 --> Language Class Initialized
INFO - 2021-06-12 07:00:42 --> Config Class Initialized
INFO - 2021-06-12 07:00:42 --> Loader Class Initialized
INFO - 2021-06-12 07:00:42 --> Helper loaded: url_helper
INFO - 2021-06-12 07:00:42 --> Helper loaded: file_helper
INFO - 2021-06-12 07:00:42 --> Helper loaded: form_helper
INFO - 2021-06-12 07:00:42 --> Helper loaded: my_helper
INFO - 2021-06-12 07:00:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:00:42 --> Controller Class Initialized
DEBUG - 2021-06-12 07:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 07:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:00:42 --> Final output sent to browser
DEBUG - 2021-06-12 07:00:42 --> Total execution time: 0.0520
INFO - 2021-06-12 07:01:01 --> Config Class Initialized
INFO - 2021-06-12 07:01:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:01 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:01 --> URI Class Initialized
INFO - 2021-06-12 07:01:01 --> Router Class Initialized
INFO - 2021-06-12 07:01:01 --> Output Class Initialized
INFO - 2021-06-12 07:01:01 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:01 --> Input Class Initialized
INFO - 2021-06-12 07:01:01 --> Language Class Initialized
INFO - 2021-06-12 07:01:01 --> Language Class Initialized
INFO - 2021-06-12 07:01:01 --> Config Class Initialized
INFO - 2021-06-12 07:01:01 --> Loader Class Initialized
INFO - 2021-06-12 07:01:01 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:01 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:01 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:01 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:01 --> Controller Class Initialized
DEBUG - 2021-06-12 07:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:01:01 --> Final output sent to browser
DEBUG - 2021-06-12 07:01:01 --> Total execution time: 0.0448
INFO - 2021-06-12 07:01:02 --> Config Class Initialized
INFO - 2021-06-12 07:01:02 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:02 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:02 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:02 --> URI Class Initialized
INFO - 2021-06-12 07:01:02 --> Router Class Initialized
INFO - 2021-06-12 07:01:02 --> Output Class Initialized
INFO - 2021-06-12 07:01:02 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:02 --> Input Class Initialized
INFO - 2021-06-12 07:01:02 --> Language Class Initialized
INFO - 2021-06-12 07:01:02 --> Language Class Initialized
INFO - 2021-06-12 07:01:02 --> Config Class Initialized
INFO - 2021-06-12 07:01:02 --> Loader Class Initialized
INFO - 2021-06-12 07:01:02 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:02 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:02 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:02 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:02 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:02 --> Controller Class Initialized
INFO - 2021-06-12 07:01:03 --> Config Class Initialized
INFO - 2021-06-12 07:01:03 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:03 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:03 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:03 --> URI Class Initialized
INFO - 2021-06-12 07:01:03 --> Router Class Initialized
INFO - 2021-06-12 07:01:03 --> Output Class Initialized
INFO - 2021-06-12 07:01:03 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:03 --> Input Class Initialized
INFO - 2021-06-12 07:01:03 --> Language Class Initialized
INFO - 2021-06-12 07:01:03 --> Language Class Initialized
INFO - 2021-06-12 07:01:03 --> Config Class Initialized
INFO - 2021-06-12 07:01:03 --> Loader Class Initialized
INFO - 2021-06-12 07:01:03 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:03 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:03 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:03 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:03 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:03 --> Controller Class Initialized
DEBUG - 2021-06-12 07:01:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:01:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:01:03 --> Final output sent to browser
DEBUG - 2021-06-12 07:01:03 --> Total execution time: 0.0445
INFO - 2021-06-12 07:01:07 --> Config Class Initialized
INFO - 2021-06-12 07:01:07 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:07 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:07 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:07 --> URI Class Initialized
INFO - 2021-06-12 07:01:07 --> Router Class Initialized
INFO - 2021-06-12 07:01:07 --> Output Class Initialized
INFO - 2021-06-12 07:01:07 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:07 --> Input Class Initialized
INFO - 2021-06-12 07:01:07 --> Language Class Initialized
INFO - 2021-06-12 07:01:07 --> Language Class Initialized
INFO - 2021-06-12 07:01:07 --> Config Class Initialized
INFO - 2021-06-12 07:01:07 --> Loader Class Initialized
INFO - 2021-06-12 07:01:07 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:07 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:07 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:07 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:07 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:07 --> Controller Class Initialized
INFO - 2021-06-12 07:01:33 --> Config Class Initialized
INFO - 2021-06-12 07:01:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:33 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:33 --> URI Class Initialized
INFO - 2021-06-12 07:01:33 --> Router Class Initialized
INFO - 2021-06-12 07:01:33 --> Output Class Initialized
INFO - 2021-06-12 07:01:33 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:33 --> Input Class Initialized
INFO - 2021-06-12 07:01:33 --> Language Class Initialized
INFO - 2021-06-12 07:01:33 --> Language Class Initialized
INFO - 2021-06-12 07:01:33 --> Config Class Initialized
INFO - 2021-06-12 07:01:33 --> Loader Class Initialized
INFO - 2021-06-12 07:01:33 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:33 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:33 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:33 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:33 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:33 --> Controller Class Initialized
INFO - 2021-06-12 07:01:48 --> Config Class Initialized
INFO - 2021-06-12 07:01:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:48 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:48 --> URI Class Initialized
INFO - 2021-06-12 07:01:48 --> Router Class Initialized
INFO - 2021-06-12 07:01:48 --> Output Class Initialized
INFO - 2021-06-12 07:01:48 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:48 --> Input Class Initialized
INFO - 2021-06-12 07:01:48 --> Language Class Initialized
INFO - 2021-06-12 07:01:48 --> Language Class Initialized
INFO - 2021-06-12 07:01:48 --> Config Class Initialized
INFO - 2021-06-12 07:01:48 --> Loader Class Initialized
INFO - 2021-06-12 07:01:48 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:48 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:48 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:48 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:48 --> Controller Class Initialized
DEBUG - 2021-06-12 07:01:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:01:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:01:48 --> Final output sent to browser
DEBUG - 2021-06-12 07:01:48 --> Total execution time: 0.0456
INFO - 2021-06-12 07:01:48 --> Config Class Initialized
INFO - 2021-06-12 07:01:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:48 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:48 --> URI Class Initialized
INFO - 2021-06-12 07:01:48 --> Router Class Initialized
INFO - 2021-06-12 07:01:48 --> Output Class Initialized
INFO - 2021-06-12 07:01:48 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:48 --> Input Class Initialized
INFO - 2021-06-12 07:01:48 --> Language Class Initialized
INFO - 2021-06-12 07:01:48 --> Language Class Initialized
INFO - 2021-06-12 07:01:48 --> Config Class Initialized
INFO - 2021-06-12 07:01:48 --> Loader Class Initialized
INFO - 2021-06-12 07:01:48 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:48 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:48 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:48 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:48 --> Controller Class Initialized
INFO - 2021-06-12 07:01:49 --> Config Class Initialized
INFO - 2021-06-12 07:01:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:49 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:49 --> URI Class Initialized
INFO - 2021-06-12 07:01:49 --> Router Class Initialized
INFO - 2021-06-12 07:01:49 --> Output Class Initialized
INFO - 2021-06-12 07:01:49 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:49 --> Input Class Initialized
INFO - 2021-06-12 07:01:49 --> Language Class Initialized
INFO - 2021-06-12 07:01:49 --> Language Class Initialized
INFO - 2021-06-12 07:01:49 --> Config Class Initialized
INFO - 2021-06-12 07:01:49 --> Loader Class Initialized
INFO - 2021-06-12 07:01:49 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:49 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:49 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:49 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:49 --> Controller Class Initialized
DEBUG - 2021-06-12 07:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:01:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:01:49 --> Final output sent to browser
DEBUG - 2021-06-12 07:01:49 --> Total execution time: 0.0446
INFO - 2021-06-12 07:01:59 --> Config Class Initialized
INFO - 2021-06-12 07:01:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:01:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:01:59 --> Utf8 Class Initialized
INFO - 2021-06-12 07:01:59 --> URI Class Initialized
INFO - 2021-06-12 07:01:59 --> Router Class Initialized
INFO - 2021-06-12 07:01:59 --> Output Class Initialized
INFO - 2021-06-12 07:01:59 --> Security Class Initialized
DEBUG - 2021-06-12 07:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:01:59 --> Input Class Initialized
INFO - 2021-06-12 07:01:59 --> Language Class Initialized
INFO - 2021-06-12 07:01:59 --> Language Class Initialized
INFO - 2021-06-12 07:01:59 --> Config Class Initialized
INFO - 2021-06-12 07:01:59 --> Loader Class Initialized
INFO - 2021-06-12 07:01:59 --> Helper loaded: url_helper
INFO - 2021-06-12 07:01:59 --> Helper loaded: file_helper
INFO - 2021-06-12 07:01:59 --> Helper loaded: form_helper
INFO - 2021-06-12 07:01:59 --> Helper loaded: my_helper
INFO - 2021-06-12 07:01:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:01:59 --> Controller Class Initialized
INFO - 2021-06-12 07:02:19 --> Config Class Initialized
INFO - 2021-06-12 07:02:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:02:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:02:19 --> Utf8 Class Initialized
INFO - 2021-06-12 07:02:19 --> URI Class Initialized
INFO - 2021-06-12 07:02:19 --> Router Class Initialized
INFO - 2021-06-12 07:02:19 --> Output Class Initialized
INFO - 2021-06-12 07:02:19 --> Security Class Initialized
DEBUG - 2021-06-12 07:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:02:19 --> Input Class Initialized
INFO - 2021-06-12 07:02:19 --> Language Class Initialized
INFO - 2021-06-12 07:02:19 --> Language Class Initialized
INFO - 2021-06-12 07:02:19 --> Config Class Initialized
INFO - 2021-06-12 07:02:19 --> Loader Class Initialized
INFO - 2021-06-12 07:02:19 --> Helper loaded: url_helper
INFO - 2021-06-12 07:02:19 --> Helper loaded: file_helper
INFO - 2021-06-12 07:02:19 --> Helper loaded: form_helper
INFO - 2021-06-12 07:02:19 --> Helper loaded: my_helper
INFO - 2021-06-12 07:02:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:02:19 --> Controller Class Initialized
INFO - 2021-06-12 07:02:38 --> Config Class Initialized
INFO - 2021-06-12 07:02:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:02:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:02:38 --> Utf8 Class Initialized
INFO - 2021-06-12 07:02:38 --> URI Class Initialized
INFO - 2021-06-12 07:02:38 --> Router Class Initialized
INFO - 2021-06-12 07:02:38 --> Output Class Initialized
INFO - 2021-06-12 07:02:38 --> Security Class Initialized
DEBUG - 2021-06-12 07:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:02:38 --> Input Class Initialized
INFO - 2021-06-12 07:02:38 --> Language Class Initialized
INFO - 2021-06-12 07:02:38 --> Language Class Initialized
INFO - 2021-06-12 07:02:38 --> Config Class Initialized
INFO - 2021-06-12 07:02:38 --> Loader Class Initialized
INFO - 2021-06-12 07:02:38 --> Helper loaded: url_helper
INFO - 2021-06-12 07:02:38 --> Helper loaded: file_helper
INFO - 2021-06-12 07:02:38 --> Helper loaded: form_helper
INFO - 2021-06-12 07:02:38 --> Helper loaded: my_helper
INFO - 2021-06-12 07:02:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:02:38 --> Controller Class Initialized
DEBUG - 2021-06-12 07:02:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:02:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:02:38 --> Final output sent to browser
DEBUG - 2021-06-12 07:02:38 --> Total execution time: 0.0462
INFO - 2021-06-12 07:02:38 --> Config Class Initialized
INFO - 2021-06-12 07:02:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:02:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:02:38 --> Utf8 Class Initialized
INFO - 2021-06-12 07:02:38 --> URI Class Initialized
INFO - 2021-06-12 07:02:38 --> Router Class Initialized
INFO - 2021-06-12 07:02:38 --> Output Class Initialized
INFO - 2021-06-12 07:02:38 --> Security Class Initialized
DEBUG - 2021-06-12 07:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:02:38 --> Input Class Initialized
INFO - 2021-06-12 07:02:38 --> Language Class Initialized
INFO - 2021-06-12 07:02:38 --> Language Class Initialized
INFO - 2021-06-12 07:02:38 --> Config Class Initialized
INFO - 2021-06-12 07:02:38 --> Loader Class Initialized
INFO - 2021-06-12 07:02:38 --> Helper loaded: url_helper
INFO - 2021-06-12 07:02:38 --> Helper loaded: file_helper
INFO - 2021-06-12 07:02:38 --> Helper loaded: form_helper
INFO - 2021-06-12 07:02:38 --> Helper loaded: my_helper
INFO - 2021-06-12 07:02:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:02:38 --> Controller Class Initialized
INFO - 2021-06-12 07:02:39 --> Config Class Initialized
INFO - 2021-06-12 07:02:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:02:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:02:39 --> Utf8 Class Initialized
INFO - 2021-06-12 07:02:39 --> URI Class Initialized
INFO - 2021-06-12 07:02:39 --> Router Class Initialized
INFO - 2021-06-12 07:02:39 --> Output Class Initialized
INFO - 2021-06-12 07:02:39 --> Security Class Initialized
DEBUG - 2021-06-12 07:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:02:39 --> Input Class Initialized
INFO - 2021-06-12 07:02:39 --> Language Class Initialized
INFO - 2021-06-12 07:02:39 --> Language Class Initialized
INFO - 2021-06-12 07:02:39 --> Config Class Initialized
INFO - 2021-06-12 07:02:39 --> Loader Class Initialized
INFO - 2021-06-12 07:02:39 --> Helper loaded: url_helper
INFO - 2021-06-12 07:02:39 --> Helper loaded: file_helper
INFO - 2021-06-12 07:02:39 --> Helper loaded: form_helper
INFO - 2021-06-12 07:02:39 --> Helper loaded: my_helper
INFO - 2021-06-12 07:02:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:02:39 --> Controller Class Initialized
DEBUG - 2021-06-12 07:02:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:02:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:02:39 --> Final output sent to browser
DEBUG - 2021-06-12 07:02:39 --> Total execution time: 0.0441
INFO - 2021-06-12 07:02:40 --> Config Class Initialized
INFO - 2021-06-12 07:02:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:02:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:02:40 --> Utf8 Class Initialized
INFO - 2021-06-12 07:02:40 --> URI Class Initialized
INFO - 2021-06-12 07:02:40 --> Router Class Initialized
INFO - 2021-06-12 07:02:40 --> Output Class Initialized
INFO - 2021-06-12 07:02:40 --> Security Class Initialized
DEBUG - 2021-06-12 07:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:02:40 --> Input Class Initialized
INFO - 2021-06-12 07:02:40 --> Language Class Initialized
INFO - 2021-06-12 07:02:40 --> Language Class Initialized
INFO - 2021-06-12 07:02:40 --> Config Class Initialized
INFO - 2021-06-12 07:02:40 --> Loader Class Initialized
INFO - 2021-06-12 07:02:40 --> Helper loaded: url_helper
INFO - 2021-06-12 07:02:40 --> Helper loaded: file_helper
INFO - 2021-06-12 07:02:40 --> Helper loaded: form_helper
INFO - 2021-06-12 07:02:40 --> Helper loaded: my_helper
INFO - 2021-06-12 07:02:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:02:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:02:41 --> Controller Class Initialized
INFO - 2021-06-12 07:03:11 --> Config Class Initialized
INFO - 2021-06-12 07:03:11 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:03:11 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:03:11 --> Utf8 Class Initialized
INFO - 2021-06-12 07:03:11 --> URI Class Initialized
INFO - 2021-06-12 07:03:11 --> Router Class Initialized
INFO - 2021-06-12 07:03:11 --> Output Class Initialized
INFO - 2021-06-12 07:03:11 --> Security Class Initialized
DEBUG - 2021-06-12 07:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:03:11 --> Input Class Initialized
INFO - 2021-06-12 07:03:11 --> Language Class Initialized
INFO - 2021-06-12 07:03:11 --> Language Class Initialized
INFO - 2021-06-12 07:03:11 --> Config Class Initialized
INFO - 2021-06-12 07:03:11 --> Loader Class Initialized
INFO - 2021-06-12 07:03:11 --> Helper loaded: url_helper
INFO - 2021-06-12 07:03:11 --> Helper loaded: file_helper
INFO - 2021-06-12 07:03:11 --> Helper loaded: form_helper
INFO - 2021-06-12 07:03:11 --> Helper loaded: my_helper
INFO - 2021-06-12 07:03:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:03:11 --> Controller Class Initialized
INFO - 2021-06-12 07:03:25 --> Config Class Initialized
INFO - 2021-06-12 07:03:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:03:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:03:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:03:25 --> URI Class Initialized
INFO - 2021-06-12 07:03:25 --> Router Class Initialized
INFO - 2021-06-12 07:03:25 --> Output Class Initialized
INFO - 2021-06-12 07:03:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:03:25 --> Input Class Initialized
INFO - 2021-06-12 07:03:25 --> Language Class Initialized
INFO - 2021-06-12 07:03:25 --> Language Class Initialized
INFO - 2021-06-12 07:03:25 --> Config Class Initialized
INFO - 2021-06-12 07:03:25 --> Loader Class Initialized
INFO - 2021-06-12 07:03:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:03:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:03:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:03:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:03:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:03:25 --> Controller Class Initialized
DEBUG - 2021-06-12 07:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:03:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:03:25 --> Final output sent to browser
DEBUG - 2021-06-12 07:03:25 --> Total execution time: 0.0437
INFO - 2021-06-12 07:03:25 --> Config Class Initialized
INFO - 2021-06-12 07:03:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:03:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:03:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:03:25 --> URI Class Initialized
INFO - 2021-06-12 07:03:25 --> Router Class Initialized
INFO - 2021-06-12 07:03:25 --> Output Class Initialized
INFO - 2021-06-12 07:03:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:03:25 --> Input Class Initialized
INFO - 2021-06-12 07:03:25 --> Language Class Initialized
INFO - 2021-06-12 07:03:25 --> Language Class Initialized
INFO - 2021-06-12 07:03:25 --> Config Class Initialized
INFO - 2021-06-12 07:03:25 --> Loader Class Initialized
INFO - 2021-06-12 07:03:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:03:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:03:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:03:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:03:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:03:25 --> Controller Class Initialized
INFO - 2021-06-12 07:03:26 --> Config Class Initialized
INFO - 2021-06-12 07:03:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:03:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:03:26 --> Utf8 Class Initialized
INFO - 2021-06-12 07:03:26 --> URI Class Initialized
INFO - 2021-06-12 07:03:26 --> Router Class Initialized
INFO - 2021-06-12 07:03:26 --> Output Class Initialized
INFO - 2021-06-12 07:03:26 --> Security Class Initialized
DEBUG - 2021-06-12 07:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:03:26 --> Input Class Initialized
INFO - 2021-06-12 07:03:26 --> Language Class Initialized
INFO - 2021-06-12 07:03:26 --> Language Class Initialized
INFO - 2021-06-12 07:03:26 --> Config Class Initialized
INFO - 2021-06-12 07:03:26 --> Loader Class Initialized
INFO - 2021-06-12 07:03:26 --> Helper loaded: url_helper
INFO - 2021-06-12 07:03:26 --> Helper loaded: file_helper
INFO - 2021-06-12 07:03:26 --> Helper loaded: form_helper
INFO - 2021-06-12 07:03:26 --> Helper loaded: my_helper
INFO - 2021-06-12 07:03:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:03:26 --> Controller Class Initialized
DEBUG - 2021-06-12 07:03:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:03:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:03:26 --> Final output sent to browser
DEBUG - 2021-06-12 07:03:26 --> Total execution time: 0.0446
INFO - 2021-06-12 07:03:29 --> Config Class Initialized
INFO - 2021-06-12 07:03:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:03:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:03:29 --> Utf8 Class Initialized
INFO - 2021-06-12 07:03:29 --> URI Class Initialized
INFO - 2021-06-12 07:03:29 --> Router Class Initialized
INFO - 2021-06-12 07:03:29 --> Output Class Initialized
INFO - 2021-06-12 07:03:29 --> Security Class Initialized
DEBUG - 2021-06-12 07:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:03:29 --> Input Class Initialized
INFO - 2021-06-12 07:03:29 --> Language Class Initialized
INFO - 2021-06-12 07:03:29 --> Language Class Initialized
INFO - 2021-06-12 07:03:29 --> Config Class Initialized
INFO - 2021-06-12 07:03:29 --> Loader Class Initialized
INFO - 2021-06-12 07:03:29 --> Helper loaded: url_helper
INFO - 2021-06-12 07:03:29 --> Helper loaded: file_helper
INFO - 2021-06-12 07:03:29 --> Helper loaded: form_helper
INFO - 2021-06-12 07:03:29 --> Helper loaded: my_helper
INFO - 2021-06-12 07:03:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:03:29 --> Controller Class Initialized
INFO - 2021-06-12 07:03:46 --> Config Class Initialized
INFO - 2021-06-12 07:03:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:03:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:03:46 --> Utf8 Class Initialized
INFO - 2021-06-12 07:03:46 --> URI Class Initialized
INFO - 2021-06-12 07:03:46 --> Router Class Initialized
INFO - 2021-06-12 07:03:46 --> Output Class Initialized
INFO - 2021-06-12 07:03:46 --> Security Class Initialized
DEBUG - 2021-06-12 07:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:03:46 --> Input Class Initialized
INFO - 2021-06-12 07:03:46 --> Language Class Initialized
INFO - 2021-06-12 07:03:46 --> Language Class Initialized
INFO - 2021-06-12 07:03:46 --> Config Class Initialized
INFO - 2021-06-12 07:03:46 --> Loader Class Initialized
INFO - 2021-06-12 07:03:46 --> Helper loaded: url_helper
INFO - 2021-06-12 07:03:46 --> Helper loaded: file_helper
INFO - 2021-06-12 07:03:46 --> Helper loaded: form_helper
INFO - 2021-06-12 07:03:46 --> Helper loaded: my_helper
INFO - 2021-06-12 07:03:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:03:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:03:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:03:46 --> Controller Class Initialized
INFO - 2021-06-12 07:04:14 --> Config Class Initialized
INFO - 2021-06-12 07:04:14 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:14 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:14 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:14 --> URI Class Initialized
INFO - 2021-06-12 07:04:14 --> Router Class Initialized
INFO - 2021-06-12 07:04:14 --> Output Class Initialized
INFO - 2021-06-12 07:04:14 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:14 --> Input Class Initialized
INFO - 2021-06-12 07:04:14 --> Language Class Initialized
INFO - 2021-06-12 07:04:14 --> Language Class Initialized
INFO - 2021-06-12 07:04:14 --> Config Class Initialized
INFO - 2021-06-12 07:04:14 --> Loader Class Initialized
INFO - 2021-06-12 07:04:14 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:14 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:14 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:14 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:14 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:14 --> Controller Class Initialized
DEBUG - 2021-06-12 07:04:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:04:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:04:14 --> Final output sent to browser
DEBUG - 2021-06-12 07:04:14 --> Total execution time: 0.0451
INFO - 2021-06-12 07:04:14 --> Config Class Initialized
INFO - 2021-06-12 07:04:14 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:14 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:14 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:14 --> URI Class Initialized
INFO - 2021-06-12 07:04:14 --> Router Class Initialized
INFO - 2021-06-12 07:04:14 --> Output Class Initialized
INFO - 2021-06-12 07:04:14 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:14 --> Input Class Initialized
INFO - 2021-06-12 07:04:14 --> Language Class Initialized
INFO - 2021-06-12 07:04:14 --> Language Class Initialized
INFO - 2021-06-12 07:04:14 --> Config Class Initialized
INFO - 2021-06-12 07:04:14 --> Loader Class Initialized
INFO - 2021-06-12 07:04:14 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:14 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:14 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:14 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:14 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:14 --> Controller Class Initialized
INFO - 2021-06-12 07:04:16 --> Config Class Initialized
INFO - 2021-06-12 07:04:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:16 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:16 --> URI Class Initialized
INFO - 2021-06-12 07:04:16 --> Router Class Initialized
INFO - 2021-06-12 07:04:16 --> Output Class Initialized
INFO - 2021-06-12 07:04:16 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:16 --> Input Class Initialized
INFO - 2021-06-12 07:04:16 --> Language Class Initialized
INFO - 2021-06-12 07:04:16 --> Language Class Initialized
INFO - 2021-06-12 07:04:16 --> Config Class Initialized
INFO - 2021-06-12 07:04:16 --> Loader Class Initialized
INFO - 2021-06-12 07:04:16 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:16 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:16 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:16 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:16 --> Controller Class Initialized
DEBUG - 2021-06-12 07:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:04:16 --> Final output sent to browser
DEBUG - 2021-06-12 07:04:16 --> Total execution time: 0.0446
INFO - 2021-06-12 07:04:17 --> Config Class Initialized
INFO - 2021-06-12 07:04:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:17 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:17 --> URI Class Initialized
INFO - 2021-06-12 07:04:17 --> Router Class Initialized
INFO - 2021-06-12 07:04:17 --> Output Class Initialized
INFO - 2021-06-12 07:04:17 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:17 --> Input Class Initialized
INFO - 2021-06-12 07:04:17 --> Language Class Initialized
INFO - 2021-06-12 07:04:17 --> Language Class Initialized
INFO - 2021-06-12 07:04:17 --> Config Class Initialized
INFO - 2021-06-12 07:04:17 --> Loader Class Initialized
INFO - 2021-06-12 07:04:17 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:17 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:17 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:17 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:17 --> Controller Class Initialized
INFO - 2021-06-12 07:04:33 --> Config Class Initialized
INFO - 2021-06-12 07:04:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:33 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:33 --> URI Class Initialized
INFO - 2021-06-12 07:04:33 --> Router Class Initialized
INFO - 2021-06-12 07:04:33 --> Output Class Initialized
INFO - 2021-06-12 07:04:33 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:33 --> Input Class Initialized
INFO - 2021-06-12 07:04:33 --> Language Class Initialized
INFO - 2021-06-12 07:04:33 --> Language Class Initialized
INFO - 2021-06-12 07:04:34 --> Config Class Initialized
INFO - 2021-06-12 07:04:34 --> Loader Class Initialized
INFO - 2021-06-12 07:04:34 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:34 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:34 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:34 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:34 --> Controller Class Initialized
INFO - 2021-06-12 07:04:52 --> Config Class Initialized
INFO - 2021-06-12 07:04:52 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:52 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:52 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:52 --> URI Class Initialized
INFO - 2021-06-12 07:04:52 --> Router Class Initialized
INFO - 2021-06-12 07:04:52 --> Output Class Initialized
INFO - 2021-06-12 07:04:52 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:52 --> Input Class Initialized
INFO - 2021-06-12 07:04:52 --> Language Class Initialized
INFO - 2021-06-12 07:04:52 --> Language Class Initialized
INFO - 2021-06-12 07:04:52 --> Config Class Initialized
INFO - 2021-06-12 07:04:52 --> Loader Class Initialized
INFO - 2021-06-12 07:04:52 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:52 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:52 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:52 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:52 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:52 --> Controller Class Initialized
DEBUG - 2021-06-12 07:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:04:52 --> Final output sent to browser
DEBUG - 2021-06-12 07:04:52 --> Total execution time: 0.0451
INFO - 2021-06-12 07:04:52 --> Config Class Initialized
INFO - 2021-06-12 07:04:52 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:52 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:52 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:52 --> URI Class Initialized
INFO - 2021-06-12 07:04:52 --> Router Class Initialized
INFO - 2021-06-12 07:04:52 --> Output Class Initialized
INFO - 2021-06-12 07:04:52 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:52 --> Input Class Initialized
INFO - 2021-06-12 07:04:52 --> Language Class Initialized
INFO - 2021-06-12 07:04:52 --> Language Class Initialized
INFO - 2021-06-12 07:04:52 --> Config Class Initialized
INFO - 2021-06-12 07:04:52 --> Loader Class Initialized
INFO - 2021-06-12 07:04:52 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:52 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:52 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:52 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:52 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:52 --> Controller Class Initialized
INFO - 2021-06-12 07:04:53 --> Config Class Initialized
INFO - 2021-06-12 07:04:53 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:53 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:53 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:53 --> URI Class Initialized
INFO - 2021-06-12 07:04:53 --> Router Class Initialized
INFO - 2021-06-12 07:04:53 --> Output Class Initialized
INFO - 2021-06-12 07:04:53 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:53 --> Input Class Initialized
INFO - 2021-06-12 07:04:53 --> Language Class Initialized
INFO - 2021-06-12 07:04:53 --> Language Class Initialized
INFO - 2021-06-12 07:04:53 --> Config Class Initialized
INFO - 2021-06-12 07:04:53 --> Loader Class Initialized
INFO - 2021-06-12 07:04:53 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:53 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:53 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:53 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:53 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:53 --> Controller Class Initialized
DEBUG - 2021-06-12 07:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:04:53 --> Final output sent to browser
DEBUG - 2021-06-12 07:04:53 --> Total execution time: 0.0446
INFO - 2021-06-12 07:04:58 --> Config Class Initialized
INFO - 2021-06-12 07:04:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:04:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:04:58 --> Utf8 Class Initialized
INFO - 2021-06-12 07:04:58 --> URI Class Initialized
INFO - 2021-06-12 07:04:58 --> Router Class Initialized
INFO - 2021-06-12 07:04:58 --> Output Class Initialized
INFO - 2021-06-12 07:04:58 --> Security Class Initialized
DEBUG - 2021-06-12 07:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:04:58 --> Input Class Initialized
INFO - 2021-06-12 07:04:58 --> Language Class Initialized
INFO - 2021-06-12 07:04:58 --> Language Class Initialized
INFO - 2021-06-12 07:04:58 --> Config Class Initialized
INFO - 2021-06-12 07:04:58 --> Loader Class Initialized
INFO - 2021-06-12 07:04:58 --> Helper loaded: url_helper
INFO - 2021-06-12 07:04:58 --> Helper loaded: file_helper
INFO - 2021-06-12 07:04:58 --> Helper loaded: form_helper
INFO - 2021-06-12 07:04:58 --> Helper loaded: my_helper
INFO - 2021-06-12 07:04:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:04:58 --> Controller Class Initialized
INFO - 2021-06-12 07:05:22 --> Config Class Initialized
INFO - 2021-06-12 07:05:22 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:05:22 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:05:22 --> Utf8 Class Initialized
INFO - 2021-06-12 07:05:22 --> URI Class Initialized
INFO - 2021-06-12 07:05:22 --> Router Class Initialized
INFO - 2021-06-12 07:05:22 --> Output Class Initialized
INFO - 2021-06-12 07:05:22 --> Security Class Initialized
DEBUG - 2021-06-12 07:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:05:22 --> Input Class Initialized
INFO - 2021-06-12 07:05:22 --> Language Class Initialized
INFO - 2021-06-12 07:05:22 --> Language Class Initialized
INFO - 2021-06-12 07:05:22 --> Config Class Initialized
INFO - 2021-06-12 07:05:22 --> Loader Class Initialized
INFO - 2021-06-12 07:05:22 --> Helper loaded: url_helper
INFO - 2021-06-12 07:05:22 --> Helper loaded: file_helper
INFO - 2021-06-12 07:05:22 --> Helper loaded: form_helper
INFO - 2021-06-12 07:05:22 --> Helper loaded: my_helper
INFO - 2021-06-12 07:05:22 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:05:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:05:22 --> Controller Class Initialized
INFO - 2021-06-12 07:05:42 --> Config Class Initialized
INFO - 2021-06-12 07:05:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:05:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:05:42 --> Utf8 Class Initialized
INFO - 2021-06-12 07:05:42 --> URI Class Initialized
INFO - 2021-06-12 07:05:42 --> Router Class Initialized
INFO - 2021-06-12 07:05:42 --> Output Class Initialized
INFO - 2021-06-12 07:05:42 --> Security Class Initialized
DEBUG - 2021-06-12 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:05:42 --> Input Class Initialized
INFO - 2021-06-12 07:05:42 --> Language Class Initialized
INFO - 2021-06-12 07:05:42 --> Language Class Initialized
INFO - 2021-06-12 07:05:42 --> Config Class Initialized
INFO - 2021-06-12 07:05:42 --> Loader Class Initialized
INFO - 2021-06-12 07:05:42 --> Helper loaded: url_helper
INFO - 2021-06-12 07:05:42 --> Helper loaded: file_helper
INFO - 2021-06-12 07:05:42 --> Helper loaded: form_helper
INFO - 2021-06-12 07:05:42 --> Helper loaded: my_helper
INFO - 2021-06-12 07:05:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:05:42 --> Controller Class Initialized
DEBUG - 2021-06-12 07:05:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:05:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:05:42 --> Final output sent to browser
DEBUG - 2021-06-12 07:05:42 --> Total execution time: 0.0445
INFO - 2021-06-12 07:05:42 --> Config Class Initialized
INFO - 2021-06-12 07:05:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:05:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:05:42 --> Utf8 Class Initialized
INFO - 2021-06-12 07:05:42 --> URI Class Initialized
INFO - 2021-06-12 07:05:42 --> Router Class Initialized
INFO - 2021-06-12 07:05:42 --> Output Class Initialized
INFO - 2021-06-12 07:05:42 --> Security Class Initialized
DEBUG - 2021-06-12 07:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:05:42 --> Input Class Initialized
INFO - 2021-06-12 07:05:42 --> Language Class Initialized
INFO - 2021-06-12 07:05:42 --> Language Class Initialized
INFO - 2021-06-12 07:05:42 --> Config Class Initialized
INFO - 2021-06-12 07:05:42 --> Loader Class Initialized
INFO - 2021-06-12 07:05:42 --> Helper loaded: url_helper
INFO - 2021-06-12 07:05:42 --> Helper loaded: file_helper
INFO - 2021-06-12 07:05:42 --> Helper loaded: form_helper
INFO - 2021-06-12 07:05:42 --> Helper loaded: my_helper
INFO - 2021-06-12 07:05:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:05:42 --> Controller Class Initialized
INFO - 2021-06-12 07:05:43 --> Config Class Initialized
INFO - 2021-06-12 07:05:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:05:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:05:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:05:43 --> URI Class Initialized
INFO - 2021-06-12 07:05:43 --> Router Class Initialized
INFO - 2021-06-12 07:05:43 --> Output Class Initialized
INFO - 2021-06-12 07:05:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:05:43 --> Input Class Initialized
INFO - 2021-06-12 07:05:43 --> Language Class Initialized
INFO - 2021-06-12 07:05:43 --> Language Class Initialized
INFO - 2021-06-12 07:05:43 --> Config Class Initialized
INFO - 2021-06-12 07:05:43 --> Loader Class Initialized
INFO - 2021-06-12 07:05:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:05:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:05:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:05:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:05:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:05:43 --> Controller Class Initialized
DEBUG - 2021-06-12 07:05:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:05:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:05:43 --> Final output sent to browser
DEBUG - 2021-06-12 07:05:43 --> Total execution time: 0.0447
INFO - 2021-06-12 07:05:45 --> Config Class Initialized
INFO - 2021-06-12 07:05:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:05:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:05:45 --> Utf8 Class Initialized
INFO - 2021-06-12 07:05:45 --> URI Class Initialized
INFO - 2021-06-12 07:05:45 --> Router Class Initialized
INFO - 2021-06-12 07:05:45 --> Output Class Initialized
INFO - 2021-06-12 07:05:45 --> Security Class Initialized
DEBUG - 2021-06-12 07:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:05:45 --> Input Class Initialized
INFO - 2021-06-12 07:05:45 --> Language Class Initialized
INFO - 2021-06-12 07:05:45 --> Language Class Initialized
INFO - 2021-06-12 07:05:45 --> Config Class Initialized
INFO - 2021-06-12 07:05:45 --> Loader Class Initialized
INFO - 2021-06-12 07:05:45 --> Helper loaded: url_helper
INFO - 2021-06-12 07:05:45 --> Helper loaded: file_helper
INFO - 2021-06-12 07:05:45 --> Helper loaded: form_helper
INFO - 2021-06-12 07:05:45 --> Helper loaded: my_helper
INFO - 2021-06-12 07:05:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:05:46 --> Controller Class Initialized
INFO - 2021-06-12 07:05:46 --> Final output sent to browser
DEBUG - 2021-06-12 07:05:46 --> Total execution time: 0.0522
INFO - 2021-06-12 07:05:58 --> Config Class Initialized
INFO - 2021-06-12 07:05:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:05:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:05:58 --> Utf8 Class Initialized
INFO - 2021-06-12 07:05:58 --> URI Class Initialized
INFO - 2021-06-12 07:05:58 --> Router Class Initialized
INFO - 2021-06-12 07:05:58 --> Output Class Initialized
INFO - 2021-06-12 07:05:58 --> Security Class Initialized
DEBUG - 2021-06-12 07:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:05:58 --> Input Class Initialized
INFO - 2021-06-12 07:05:58 --> Language Class Initialized
INFO - 2021-06-12 07:05:58 --> Language Class Initialized
INFO - 2021-06-12 07:05:58 --> Config Class Initialized
INFO - 2021-06-12 07:05:58 --> Loader Class Initialized
INFO - 2021-06-12 07:05:58 --> Helper loaded: url_helper
INFO - 2021-06-12 07:05:58 --> Helper loaded: file_helper
INFO - 2021-06-12 07:05:58 --> Helper loaded: form_helper
INFO - 2021-06-12 07:05:58 --> Helper loaded: my_helper
INFO - 2021-06-12 07:05:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:05:58 --> Controller Class Initialized
INFO - 2021-06-12 07:06:16 --> Config Class Initialized
INFO - 2021-06-12 07:06:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:06:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:06:16 --> Utf8 Class Initialized
INFO - 2021-06-12 07:06:16 --> URI Class Initialized
INFO - 2021-06-12 07:06:16 --> Router Class Initialized
INFO - 2021-06-12 07:06:16 --> Output Class Initialized
INFO - 2021-06-12 07:06:16 --> Security Class Initialized
DEBUG - 2021-06-12 07:06:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:06:16 --> Input Class Initialized
INFO - 2021-06-12 07:06:16 --> Language Class Initialized
INFO - 2021-06-12 07:06:16 --> Language Class Initialized
INFO - 2021-06-12 07:06:16 --> Config Class Initialized
INFO - 2021-06-12 07:06:16 --> Loader Class Initialized
INFO - 2021-06-12 07:06:16 --> Helper loaded: url_helper
INFO - 2021-06-12 07:06:16 --> Helper loaded: file_helper
INFO - 2021-06-12 07:06:16 --> Helper loaded: form_helper
INFO - 2021-06-12 07:06:16 --> Helper loaded: my_helper
INFO - 2021-06-12 07:06:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:06:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:06:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:06:16 --> Controller Class Initialized
INFO - 2021-06-12 07:06:39 --> Config Class Initialized
INFO - 2021-06-12 07:06:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:06:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:06:39 --> Utf8 Class Initialized
INFO - 2021-06-12 07:06:39 --> URI Class Initialized
INFO - 2021-06-12 07:06:39 --> Router Class Initialized
INFO - 2021-06-12 07:06:39 --> Output Class Initialized
INFO - 2021-06-12 07:06:39 --> Security Class Initialized
DEBUG - 2021-06-12 07:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:06:39 --> Input Class Initialized
INFO - 2021-06-12 07:06:39 --> Language Class Initialized
INFO - 2021-06-12 07:06:39 --> Language Class Initialized
INFO - 2021-06-12 07:06:39 --> Config Class Initialized
INFO - 2021-06-12 07:06:39 --> Loader Class Initialized
INFO - 2021-06-12 07:06:39 --> Helper loaded: url_helper
INFO - 2021-06-12 07:06:39 --> Helper loaded: file_helper
INFO - 2021-06-12 07:06:39 --> Helper loaded: form_helper
INFO - 2021-06-12 07:06:39 --> Helper loaded: my_helper
INFO - 2021-06-12 07:06:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:06:39 --> Controller Class Initialized
DEBUG - 2021-06-12 07:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:06:39 --> Final output sent to browser
DEBUG - 2021-06-12 07:06:39 --> Total execution time: 0.0443
INFO - 2021-06-12 07:06:39 --> Config Class Initialized
INFO - 2021-06-12 07:06:39 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:06:39 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:06:39 --> Utf8 Class Initialized
INFO - 2021-06-12 07:06:39 --> URI Class Initialized
INFO - 2021-06-12 07:06:39 --> Router Class Initialized
INFO - 2021-06-12 07:06:39 --> Output Class Initialized
INFO - 2021-06-12 07:06:39 --> Security Class Initialized
DEBUG - 2021-06-12 07:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:06:39 --> Input Class Initialized
INFO - 2021-06-12 07:06:39 --> Language Class Initialized
INFO - 2021-06-12 07:06:39 --> Language Class Initialized
INFO - 2021-06-12 07:06:39 --> Config Class Initialized
INFO - 2021-06-12 07:06:39 --> Loader Class Initialized
INFO - 2021-06-12 07:06:39 --> Helper loaded: url_helper
INFO - 2021-06-12 07:06:39 --> Helper loaded: file_helper
INFO - 2021-06-12 07:06:39 --> Helper loaded: form_helper
INFO - 2021-06-12 07:06:39 --> Helper loaded: my_helper
INFO - 2021-06-12 07:06:39 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:06:39 --> Controller Class Initialized
INFO - 2021-06-12 07:06:40 --> Config Class Initialized
INFO - 2021-06-12 07:06:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:06:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:06:40 --> Utf8 Class Initialized
INFO - 2021-06-12 07:06:40 --> URI Class Initialized
INFO - 2021-06-12 07:06:40 --> Router Class Initialized
INFO - 2021-06-12 07:06:40 --> Output Class Initialized
INFO - 2021-06-12 07:06:40 --> Security Class Initialized
DEBUG - 2021-06-12 07:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:06:40 --> Input Class Initialized
INFO - 2021-06-12 07:06:40 --> Language Class Initialized
INFO - 2021-06-12 07:06:41 --> Language Class Initialized
INFO - 2021-06-12 07:06:41 --> Config Class Initialized
INFO - 2021-06-12 07:06:41 --> Loader Class Initialized
INFO - 2021-06-12 07:06:41 --> Helper loaded: url_helper
INFO - 2021-06-12 07:06:41 --> Helper loaded: file_helper
INFO - 2021-06-12 07:06:41 --> Helper loaded: form_helper
INFO - 2021-06-12 07:06:41 --> Helper loaded: my_helper
INFO - 2021-06-12 07:06:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:06:41 --> Controller Class Initialized
DEBUG - 2021-06-12 07:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:06:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:06:41 --> Final output sent to browser
DEBUG - 2021-06-12 07:06:41 --> Total execution time: 0.0447
INFO - 2021-06-12 07:06:46 --> Config Class Initialized
INFO - 2021-06-12 07:06:46 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:06:46 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:06:46 --> Utf8 Class Initialized
INFO - 2021-06-12 07:06:46 --> URI Class Initialized
INFO - 2021-06-12 07:06:46 --> Router Class Initialized
INFO - 2021-06-12 07:06:46 --> Output Class Initialized
INFO - 2021-06-12 07:06:46 --> Security Class Initialized
DEBUG - 2021-06-12 07:06:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:06:46 --> Input Class Initialized
INFO - 2021-06-12 07:06:46 --> Language Class Initialized
INFO - 2021-06-12 07:06:46 --> Language Class Initialized
INFO - 2021-06-12 07:06:46 --> Config Class Initialized
INFO - 2021-06-12 07:06:46 --> Loader Class Initialized
INFO - 2021-06-12 07:06:46 --> Helper loaded: url_helper
INFO - 2021-06-12 07:06:46 --> Helper loaded: file_helper
INFO - 2021-06-12 07:06:46 --> Helper loaded: form_helper
INFO - 2021-06-12 07:06:46 --> Helper loaded: my_helper
INFO - 2021-06-12 07:06:46 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:06:46 --> Controller Class Initialized
INFO - 2021-06-12 07:07:09 --> Config Class Initialized
INFO - 2021-06-12 07:07:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:07:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:07:09 --> Utf8 Class Initialized
INFO - 2021-06-12 07:07:09 --> URI Class Initialized
INFO - 2021-06-12 07:07:09 --> Router Class Initialized
INFO - 2021-06-12 07:07:09 --> Output Class Initialized
INFO - 2021-06-12 07:07:09 --> Security Class Initialized
DEBUG - 2021-06-12 07:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:07:09 --> Input Class Initialized
INFO - 2021-06-12 07:07:09 --> Language Class Initialized
INFO - 2021-06-12 07:07:09 --> Language Class Initialized
INFO - 2021-06-12 07:07:09 --> Config Class Initialized
INFO - 2021-06-12 07:07:09 --> Loader Class Initialized
INFO - 2021-06-12 07:07:09 --> Helper loaded: url_helper
INFO - 2021-06-12 07:07:09 --> Helper loaded: file_helper
INFO - 2021-06-12 07:07:09 --> Helper loaded: form_helper
INFO - 2021-06-12 07:07:09 --> Helper loaded: my_helper
INFO - 2021-06-12 07:07:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:07:09 --> Controller Class Initialized
INFO - 2021-06-12 07:07:24 --> Config Class Initialized
INFO - 2021-06-12 07:07:24 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:07:24 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:07:24 --> Utf8 Class Initialized
INFO - 2021-06-12 07:07:24 --> URI Class Initialized
INFO - 2021-06-12 07:07:24 --> Router Class Initialized
INFO - 2021-06-12 07:07:24 --> Output Class Initialized
INFO - 2021-06-12 07:07:24 --> Security Class Initialized
DEBUG - 2021-06-12 07:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:07:24 --> Input Class Initialized
INFO - 2021-06-12 07:07:24 --> Language Class Initialized
INFO - 2021-06-12 07:07:24 --> Language Class Initialized
INFO - 2021-06-12 07:07:24 --> Config Class Initialized
INFO - 2021-06-12 07:07:24 --> Loader Class Initialized
INFO - 2021-06-12 07:07:24 --> Helper loaded: url_helper
INFO - 2021-06-12 07:07:24 --> Helper loaded: file_helper
INFO - 2021-06-12 07:07:24 --> Helper loaded: form_helper
INFO - 2021-06-12 07:07:24 --> Helper loaded: my_helper
INFO - 2021-06-12 07:07:24 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:07:24 --> Controller Class Initialized
DEBUG - 2021-06-12 07:07:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:07:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:07:24 --> Final output sent to browser
DEBUG - 2021-06-12 07:07:24 --> Total execution time: 0.0451
INFO - 2021-06-12 07:07:24 --> Config Class Initialized
INFO - 2021-06-12 07:07:24 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:07:24 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:07:24 --> Utf8 Class Initialized
INFO - 2021-06-12 07:07:24 --> URI Class Initialized
INFO - 2021-06-12 07:07:24 --> Router Class Initialized
INFO - 2021-06-12 07:07:24 --> Output Class Initialized
INFO - 2021-06-12 07:07:24 --> Security Class Initialized
DEBUG - 2021-06-12 07:07:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:07:24 --> Input Class Initialized
INFO - 2021-06-12 07:07:24 --> Language Class Initialized
INFO - 2021-06-12 07:07:24 --> Language Class Initialized
INFO - 2021-06-12 07:07:24 --> Config Class Initialized
INFO - 2021-06-12 07:07:24 --> Loader Class Initialized
INFO - 2021-06-12 07:07:24 --> Helper loaded: url_helper
INFO - 2021-06-12 07:07:24 --> Helper loaded: file_helper
INFO - 2021-06-12 07:07:24 --> Helper loaded: form_helper
INFO - 2021-06-12 07:07:24 --> Helper loaded: my_helper
INFO - 2021-06-12 07:07:24 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:07:24 --> Controller Class Initialized
INFO - 2021-06-12 07:07:26 --> Config Class Initialized
INFO - 2021-06-12 07:07:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:07:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:07:26 --> Utf8 Class Initialized
INFO - 2021-06-12 07:07:26 --> URI Class Initialized
INFO - 2021-06-12 07:07:26 --> Router Class Initialized
INFO - 2021-06-12 07:07:26 --> Output Class Initialized
INFO - 2021-06-12 07:07:26 --> Security Class Initialized
DEBUG - 2021-06-12 07:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:07:26 --> Input Class Initialized
INFO - 2021-06-12 07:07:26 --> Language Class Initialized
INFO - 2021-06-12 07:07:26 --> Language Class Initialized
INFO - 2021-06-12 07:07:26 --> Config Class Initialized
INFO - 2021-06-12 07:07:26 --> Loader Class Initialized
INFO - 2021-06-12 07:07:26 --> Helper loaded: url_helper
INFO - 2021-06-12 07:07:26 --> Helper loaded: file_helper
INFO - 2021-06-12 07:07:26 --> Helper loaded: form_helper
INFO - 2021-06-12 07:07:26 --> Helper loaded: my_helper
INFO - 2021-06-12 07:07:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:07:26 --> Controller Class Initialized
DEBUG - 2021-06-12 07:07:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:07:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:07:26 --> Final output sent to browser
DEBUG - 2021-06-12 07:07:26 --> Total execution time: 0.0433
INFO - 2021-06-12 07:07:27 --> Config Class Initialized
INFO - 2021-06-12 07:07:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:07:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:07:27 --> Utf8 Class Initialized
INFO - 2021-06-12 07:07:27 --> URI Class Initialized
INFO - 2021-06-12 07:07:27 --> Router Class Initialized
INFO - 2021-06-12 07:07:27 --> Output Class Initialized
INFO - 2021-06-12 07:07:27 --> Security Class Initialized
DEBUG - 2021-06-12 07:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:07:27 --> Input Class Initialized
INFO - 2021-06-12 07:07:27 --> Language Class Initialized
INFO - 2021-06-12 07:07:27 --> Language Class Initialized
INFO - 2021-06-12 07:07:27 --> Config Class Initialized
INFO - 2021-06-12 07:07:27 --> Loader Class Initialized
INFO - 2021-06-12 07:07:28 --> Helper loaded: url_helper
INFO - 2021-06-12 07:07:28 --> Helper loaded: file_helper
INFO - 2021-06-12 07:07:28 --> Helper loaded: form_helper
INFO - 2021-06-12 07:07:28 --> Helper loaded: my_helper
INFO - 2021-06-12 07:07:28 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:07:28 --> Controller Class Initialized
INFO - 2021-06-12 07:07:48 --> Config Class Initialized
INFO - 2021-06-12 07:07:48 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:07:48 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:07:48 --> Utf8 Class Initialized
INFO - 2021-06-12 07:07:48 --> URI Class Initialized
INFO - 2021-06-12 07:07:48 --> Router Class Initialized
INFO - 2021-06-12 07:07:48 --> Output Class Initialized
INFO - 2021-06-12 07:07:48 --> Security Class Initialized
DEBUG - 2021-06-12 07:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:07:48 --> Input Class Initialized
INFO - 2021-06-12 07:07:48 --> Language Class Initialized
INFO - 2021-06-12 07:07:48 --> Language Class Initialized
INFO - 2021-06-12 07:07:48 --> Config Class Initialized
INFO - 2021-06-12 07:07:48 --> Loader Class Initialized
INFO - 2021-06-12 07:07:48 --> Helper loaded: url_helper
INFO - 2021-06-12 07:07:48 --> Helper loaded: file_helper
INFO - 2021-06-12 07:07:48 --> Helper loaded: form_helper
INFO - 2021-06-12 07:07:48 --> Helper loaded: my_helper
INFO - 2021-06-12 07:07:48 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:07:48 --> Controller Class Initialized
INFO - 2021-06-12 07:08:20 --> Config Class Initialized
INFO - 2021-06-12 07:08:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:20 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:20 --> URI Class Initialized
INFO - 2021-06-12 07:08:20 --> Router Class Initialized
INFO - 2021-06-12 07:08:20 --> Output Class Initialized
INFO - 2021-06-12 07:08:20 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:20 --> Input Class Initialized
INFO - 2021-06-12 07:08:20 --> Language Class Initialized
INFO - 2021-06-12 07:08:20 --> Language Class Initialized
INFO - 2021-06-12 07:08:20 --> Config Class Initialized
INFO - 2021-06-12 07:08:20 --> Loader Class Initialized
INFO - 2021-06-12 07:08:20 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:20 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:20 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:20 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:20 --> Controller Class Initialized
INFO - 2021-06-12 07:08:20 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:08:20 --> Config Class Initialized
INFO - 2021-06-12 07:08:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:20 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:20 --> URI Class Initialized
INFO - 2021-06-12 07:08:20 --> Router Class Initialized
INFO - 2021-06-12 07:08:20 --> Output Class Initialized
INFO - 2021-06-12 07:08:20 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:20 --> Input Class Initialized
INFO - 2021-06-12 07:08:20 --> Language Class Initialized
INFO - 2021-06-12 07:08:20 --> Language Class Initialized
INFO - 2021-06-12 07:08:20 --> Config Class Initialized
INFO - 2021-06-12 07:08:20 --> Loader Class Initialized
INFO - 2021-06-12 07:08:20 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:20 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:20 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:20 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:20 --> Controller Class Initialized
DEBUG - 2021-06-12 07:08:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 07:08:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:08:20 --> Final output sent to browser
DEBUG - 2021-06-12 07:08:20 --> Total execution time: 0.0513
INFO - 2021-06-12 07:08:32 --> Config Class Initialized
INFO - 2021-06-12 07:08:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:32 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:32 --> URI Class Initialized
INFO - 2021-06-12 07:08:32 --> Router Class Initialized
INFO - 2021-06-12 07:08:32 --> Output Class Initialized
INFO - 2021-06-12 07:08:32 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:32 --> Input Class Initialized
INFO - 2021-06-12 07:08:32 --> Language Class Initialized
INFO - 2021-06-12 07:08:32 --> Language Class Initialized
INFO - 2021-06-12 07:08:32 --> Config Class Initialized
INFO - 2021-06-12 07:08:32 --> Loader Class Initialized
INFO - 2021-06-12 07:08:32 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:32 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:32 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:32 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:32 --> Controller Class Initialized
INFO - 2021-06-12 07:08:32 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:08:32 --> Final output sent to browser
DEBUG - 2021-06-12 07:08:32 --> Total execution time: 0.0520
INFO - 2021-06-12 07:08:33 --> Config Class Initialized
INFO - 2021-06-12 07:08:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:33 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:33 --> URI Class Initialized
INFO - 2021-06-12 07:08:33 --> Router Class Initialized
INFO - 2021-06-12 07:08:33 --> Output Class Initialized
INFO - 2021-06-12 07:08:33 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:33 --> Input Class Initialized
INFO - 2021-06-12 07:08:33 --> Language Class Initialized
INFO - 2021-06-12 07:08:33 --> Language Class Initialized
INFO - 2021-06-12 07:08:33 --> Config Class Initialized
INFO - 2021-06-12 07:08:33 --> Loader Class Initialized
INFO - 2021-06-12 07:08:33 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:33 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:33 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:33 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:33 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:33 --> Controller Class Initialized
DEBUG - 2021-06-12 07:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 07:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:08:33 --> Final output sent to browser
DEBUG - 2021-06-12 07:08:33 --> Total execution time: 0.0720
INFO - 2021-06-12 07:08:34 --> Config Class Initialized
INFO - 2021-06-12 07:08:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:34 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:34 --> URI Class Initialized
INFO - 2021-06-12 07:08:34 --> Router Class Initialized
INFO - 2021-06-12 07:08:34 --> Output Class Initialized
INFO - 2021-06-12 07:08:34 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:34 --> Input Class Initialized
INFO - 2021-06-12 07:08:34 --> Language Class Initialized
INFO - 2021-06-12 07:08:34 --> Language Class Initialized
INFO - 2021-06-12 07:08:34 --> Config Class Initialized
INFO - 2021-06-12 07:08:34 --> Loader Class Initialized
INFO - 2021-06-12 07:08:34 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:34 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:34 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:34 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:34 --> Controller Class Initialized
DEBUG - 2021-06-12 07:08:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 07:08:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:08:34 --> Final output sent to browser
DEBUG - 2021-06-12 07:08:34 --> Total execution time: 0.0519
INFO - 2021-06-12 07:08:36 --> Config Class Initialized
INFO - 2021-06-12 07:08:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:36 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:36 --> URI Class Initialized
INFO - 2021-06-12 07:08:36 --> Router Class Initialized
INFO - 2021-06-12 07:08:36 --> Output Class Initialized
INFO - 2021-06-12 07:08:36 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:36 --> Input Class Initialized
INFO - 2021-06-12 07:08:36 --> Language Class Initialized
INFO - 2021-06-12 07:08:36 --> Language Class Initialized
INFO - 2021-06-12 07:08:36 --> Config Class Initialized
INFO - 2021-06-12 07:08:36 --> Loader Class Initialized
INFO - 2021-06-12 07:08:36 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:36 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:36 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:36 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:36 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:36 --> Controller Class Initialized
DEBUG - 2021-06-12 07:08:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:08:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:08:36 --> Final output sent to browser
DEBUG - 2021-06-12 07:08:36 --> Total execution time: 0.0436
INFO - 2021-06-12 07:08:36 --> Config Class Initialized
INFO - 2021-06-12 07:08:36 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:36 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:36 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:36 --> URI Class Initialized
INFO - 2021-06-12 07:08:36 --> Router Class Initialized
INFO - 2021-06-12 07:08:36 --> Output Class Initialized
INFO - 2021-06-12 07:08:37 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:37 --> Input Class Initialized
INFO - 2021-06-12 07:08:37 --> Language Class Initialized
INFO - 2021-06-12 07:08:37 --> Language Class Initialized
INFO - 2021-06-12 07:08:37 --> Config Class Initialized
INFO - 2021-06-12 07:08:37 --> Loader Class Initialized
INFO - 2021-06-12 07:08:37 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:37 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:37 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:37 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:37 --> Controller Class Initialized
INFO - 2021-06-12 07:08:37 --> Config Class Initialized
INFO - 2021-06-12 07:08:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:37 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:37 --> URI Class Initialized
INFO - 2021-06-12 07:08:37 --> Router Class Initialized
INFO - 2021-06-12 07:08:37 --> Output Class Initialized
INFO - 2021-06-12 07:08:37 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:37 --> Input Class Initialized
INFO - 2021-06-12 07:08:37 --> Language Class Initialized
INFO - 2021-06-12 07:08:37 --> Language Class Initialized
INFO - 2021-06-12 07:08:37 --> Config Class Initialized
INFO - 2021-06-12 07:08:37 --> Loader Class Initialized
INFO - 2021-06-12 07:08:37 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:37 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:37 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:37 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:37 --> Controller Class Initialized
DEBUG - 2021-06-12 07:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:08:37 --> Final output sent to browser
DEBUG - 2021-06-12 07:08:37 --> Total execution time: 0.0450
INFO - 2021-06-12 07:08:42 --> Config Class Initialized
INFO - 2021-06-12 07:08:42 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:42 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:42 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:42 --> URI Class Initialized
INFO - 2021-06-12 07:08:42 --> Router Class Initialized
INFO - 2021-06-12 07:08:42 --> Output Class Initialized
INFO - 2021-06-12 07:08:42 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:42 --> Input Class Initialized
INFO - 2021-06-12 07:08:42 --> Language Class Initialized
INFO - 2021-06-12 07:08:42 --> Language Class Initialized
INFO - 2021-06-12 07:08:42 --> Config Class Initialized
INFO - 2021-06-12 07:08:42 --> Loader Class Initialized
INFO - 2021-06-12 07:08:42 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:42 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:42 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:42 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:42 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:42 --> Controller Class Initialized
INFO - 2021-06-12 07:08:42 --> Final output sent to browser
DEBUG - 2021-06-12 07:08:42 --> Total execution time: 0.0410
INFO - 2021-06-12 07:08:43 --> Config Class Initialized
INFO - 2021-06-12 07:08:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:08:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:08:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:08:43 --> URI Class Initialized
INFO - 2021-06-12 07:08:43 --> Router Class Initialized
INFO - 2021-06-12 07:08:43 --> Output Class Initialized
INFO - 2021-06-12 07:08:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:08:43 --> Input Class Initialized
INFO - 2021-06-12 07:08:43 --> Language Class Initialized
INFO - 2021-06-12 07:08:43 --> Language Class Initialized
INFO - 2021-06-12 07:08:43 --> Config Class Initialized
INFO - 2021-06-12 07:08:43 --> Loader Class Initialized
INFO - 2021-06-12 07:08:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:08:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:08:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:08:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:08:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:08:43 --> Controller Class Initialized
INFO - 2021-06-12 07:09:13 --> Config Class Initialized
INFO - 2021-06-12 07:09:13 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:09:13 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:09:13 --> Utf8 Class Initialized
INFO - 2021-06-12 07:09:13 --> URI Class Initialized
INFO - 2021-06-12 07:09:13 --> Router Class Initialized
INFO - 2021-06-12 07:09:13 --> Output Class Initialized
INFO - 2021-06-12 07:09:13 --> Security Class Initialized
DEBUG - 2021-06-12 07:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:09:13 --> Input Class Initialized
INFO - 2021-06-12 07:09:13 --> Language Class Initialized
INFO - 2021-06-12 07:09:13 --> Language Class Initialized
INFO - 2021-06-12 07:09:13 --> Config Class Initialized
INFO - 2021-06-12 07:09:13 --> Loader Class Initialized
INFO - 2021-06-12 07:09:13 --> Helper loaded: url_helper
INFO - 2021-06-12 07:09:13 --> Helper loaded: file_helper
INFO - 2021-06-12 07:09:13 --> Helper loaded: form_helper
INFO - 2021-06-12 07:09:13 --> Helper loaded: my_helper
INFO - 2021-06-12 07:09:13 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:09:13 --> Controller Class Initialized
INFO - 2021-06-12 07:09:24 --> Config Class Initialized
INFO - 2021-06-12 07:09:24 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:09:24 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:09:24 --> Utf8 Class Initialized
INFO - 2021-06-12 07:09:24 --> URI Class Initialized
INFO - 2021-06-12 07:09:24 --> Router Class Initialized
INFO - 2021-06-12 07:09:24 --> Output Class Initialized
INFO - 2021-06-12 07:09:24 --> Security Class Initialized
DEBUG - 2021-06-12 07:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:09:24 --> Input Class Initialized
INFO - 2021-06-12 07:09:24 --> Language Class Initialized
INFO - 2021-06-12 07:09:24 --> Language Class Initialized
INFO - 2021-06-12 07:09:24 --> Config Class Initialized
INFO - 2021-06-12 07:09:24 --> Loader Class Initialized
INFO - 2021-06-12 07:09:24 --> Helper loaded: url_helper
INFO - 2021-06-12 07:09:24 --> Helper loaded: file_helper
INFO - 2021-06-12 07:09:24 --> Helper loaded: form_helper
INFO - 2021-06-12 07:09:24 --> Helper loaded: my_helper
INFO - 2021-06-12 07:09:24 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:09:24 --> Controller Class Initialized
DEBUG - 2021-06-12 07:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:09:24 --> Final output sent to browser
DEBUG - 2021-06-12 07:09:24 --> Total execution time: 0.0465
INFO - 2021-06-12 07:09:24 --> Config Class Initialized
INFO - 2021-06-12 07:09:24 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:09:24 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:09:24 --> Utf8 Class Initialized
INFO - 2021-06-12 07:09:24 --> URI Class Initialized
INFO - 2021-06-12 07:09:24 --> Router Class Initialized
INFO - 2021-06-12 07:09:24 --> Output Class Initialized
INFO - 2021-06-12 07:09:24 --> Security Class Initialized
DEBUG - 2021-06-12 07:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:09:24 --> Input Class Initialized
INFO - 2021-06-12 07:09:24 --> Language Class Initialized
INFO - 2021-06-12 07:09:24 --> Language Class Initialized
INFO - 2021-06-12 07:09:24 --> Config Class Initialized
INFO - 2021-06-12 07:09:24 --> Loader Class Initialized
INFO - 2021-06-12 07:09:24 --> Helper loaded: url_helper
INFO - 2021-06-12 07:09:24 --> Helper loaded: file_helper
INFO - 2021-06-12 07:09:24 --> Helper loaded: form_helper
INFO - 2021-06-12 07:09:24 --> Helper loaded: my_helper
INFO - 2021-06-12 07:09:24 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:09:24 --> Controller Class Initialized
INFO - 2021-06-12 07:09:25 --> Config Class Initialized
INFO - 2021-06-12 07:09:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:09:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:09:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:09:25 --> URI Class Initialized
INFO - 2021-06-12 07:09:25 --> Router Class Initialized
INFO - 2021-06-12 07:09:25 --> Output Class Initialized
INFO - 2021-06-12 07:09:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:09:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:09:25 --> Input Class Initialized
INFO - 2021-06-12 07:09:25 --> Language Class Initialized
INFO - 2021-06-12 07:09:25 --> Language Class Initialized
INFO - 2021-06-12 07:09:25 --> Config Class Initialized
INFO - 2021-06-12 07:09:25 --> Loader Class Initialized
INFO - 2021-06-12 07:09:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:09:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:09:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:09:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:09:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:09:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:09:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:09:25 --> Controller Class Initialized
DEBUG - 2021-06-12 07:09:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:09:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:09:25 --> Final output sent to browser
DEBUG - 2021-06-12 07:09:25 --> Total execution time: 0.0437
INFO - 2021-06-12 07:09:29 --> Config Class Initialized
INFO - 2021-06-12 07:09:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:09:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:09:29 --> Utf8 Class Initialized
INFO - 2021-06-12 07:09:29 --> URI Class Initialized
INFO - 2021-06-12 07:09:29 --> Router Class Initialized
INFO - 2021-06-12 07:09:29 --> Output Class Initialized
INFO - 2021-06-12 07:09:29 --> Security Class Initialized
DEBUG - 2021-06-12 07:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:09:29 --> Input Class Initialized
INFO - 2021-06-12 07:09:29 --> Language Class Initialized
INFO - 2021-06-12 07:09:29 --> Language Class Initialized
INFO - 2021-06-12 07:09:29 --> Config Class Initialized
INFO - 2021-06-12 07:09:29 --> Loader Class Initialized
INFO - 2021-06-12 07:09:29 --> Helper loaded: url_helper
INFO - 2021-06-12 07:09:29 --> Helper loaded: file_helper
INFO - 2021-06-12 07:09:29 --> Helper loaded: form_helper
INFO - 2021-06-12 07:09:29 --> Helper loaded: my_helper
INFO - 2021-06-12 07:09:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:09:29 --> Controller Class Initialized
INFO - 2021-06-12 07:09:43 --> Config Class Initialized
INFO - 2021-06-12 07:09:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:09:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:09:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:09:43 --> URI Class Initialized
INFO - 2021-06-12 07:09:43 --> Router Class Initialized
INFO - 2021-06-12 07:09:43 --> Output Class Initialized
INFO - 2021-06-12 07:09:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:09:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:09:43 --> Input Class Initialized
INFO - 2021-06-12 07:09:43 --> Language Class Initialized
INFO - 2021-06-12 07:09:43 --> Language Class Initialized
INFO - 2021-06-12 07:09:43 --> Config Class Initialized
INFO - 2021-06-12 07:09:43 --> Loader Class Initialized
INFO - 2021-06-12 07:09:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:09:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:09:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:09:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:09:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:09:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:09:43 --> Controller Class Initialized
INFO - 2021-06-12 07:10:25 --> Config Class Initialized
INFO - 2021-06-12 07:10:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:25 --> URI Class Initialized
INFO - 2021-06-12 07:10:25 --> Router Class Initialized
INFO - 2021-06-12 07:10:25 --> Output Class Initialized
INFO - 2021-06-12 07:10:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:25 --> Input Class Initialized
INFO - 2021-06-12 07:10:25 --> Language Class Initialized
INFO - 2021-06-12 07:10:25 --> Language Class Initialized
INFO - 2021-06-12 07:10:25 --> Config Class Initialized
INFO - 2021-06-12 07:10:25 --> Loader Class Initialized
INFO - 2021-06-12 07:10:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:25 --> Controller Class Initialized
INFO - 2021-06-12 07:10:25 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:10:25 --> Config Class Initialized
INFO - 2021-06-12 07:10:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:25 --> URI Class Initialized
INFO - 2021-06-12 07:10:25 --> Router Class Initialized
INFO - 2021-06-12 07:10:25 --> Output Class Initialized
INFO - 2021-06-12 07:10:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:25 --> Input Class Initialized
INFO - 2021-06-12 07:10:25 --> Language Class Initialized
INFO - 2021-06-12 07:10:25 --> Language Class Initialized
INFO - 2021-06-12 07:10:25 --> Config Class Initialized
INFO - 2021-06-12 07:10:25 --> Loader Class Initialized
INFO - 2021-06-12 07:10:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:25 --> Controller Class Initialized
DEBUG - 2021-06-12 07:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 07:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:10:25 --> Final output sent to browser
DEBUG - 2021-06-12 07:10:25 --> Total execution time: 0.0398
INFO - 2021-06-12 07:10:32 --> Config Class Initialized
INFO - 2021-06-12 07:10:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:32 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:32 --> URI Class Initialized
INFO - 2021-06-12 07:10:32 --> Router Class Initialized
INFO - 2021-06-12 07:10:32 --> Output Class Initialized
INFO - 2021-06-12 07:10:32 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:32 --> Input Class Initialized
INFO - 2021-06-12 07:10:32 --> Language Class Initialized
INFO - 2021-06-12 07:10:32 --> Language Class Initialized
INFO - 2021-06-12 07:10:32 --> Config Class Initialized
INFO - 2021-06-12 07:10:32 --> Loader Class Initialized
INFO - 2021-06-12 07:10:32 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:32 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:32 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:32 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:32 --> Controller Class Initialized
INFO - 2021-06-12 07:10:32 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:10:32 --> Final output sent to browser
DEBUG - 2021-06-12 07:10:32 --> Total execution time: 0.0403
INFO - 2021-06-12 07:10:33 --> Config Class Initialized
INFO - 2021-06-12 07:10:33 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:33 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:33 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:33 --> URI Class Initialized
INFO - 2021-06-12 07:10:33 --> Router Class Initialized
INFO - 2021-06-12 07:10:33 --> Output Class Initialized
INFO - 2021-06-12 07:10:33 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:33 --> Input Class Initialized
INFO - 2021-06-12 07:10:33 --> Language Class Initialized
INFO - 2021-06-12 07:10:33 --> Language Class Initialized
INFO - 2021-06-12 07:10:33 --> Config Class Initialized
INFO - 2021-06-12 07:10:33 --> Loader Class Initialized
INFO - 2021-06-12 07:10:33 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:33 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:33 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:33 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:33 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:33 --> Controller Class Initialized
DEBUG - 2021-06-12 07:10:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 07:10:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:10:33 --> Final output sent to browser
DEBUG - 2021-06-12 07:10:33 --> Total execution time: 0.0827
INFO - 2021-06-12 07:10:34 --> Config Class Initialized
INFO - 2021-06-12 07:10:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:34 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:34 --> URI Class Initialized
INFO - 2021-06-12 07:10:34 --> Router Class Initialized
INFO - 2021-06-12 07:10:34 --> Output Class Initialized
INFO - 2021-06-12 07:10:34 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:34 --> Input Class Initialized
INFO - 2021-06-12 07:10:34 --> Language Class Initialized
INFO - 2021-06-12 07:10:34 --> Language Class Initialized
INFO - 2021-06-12 07:10:34 --> Config Class Initialized
INFO - 2021-06-12 07:10:34 --> Loader Class Initialized
INFO - 2021-06-12 07:10:34 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:34 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:34 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:34 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:34 --> Controller Class Initialized
DEBUG - 2021-06-12 07:10:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 07:10:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:10:34 --> Final output sent to browser
DEBUG - 2021-06-12 07:10:34 --> Total execution time: 0.0409
INFO - 2021-06-12 07:10:40 --> Config Class Initialized
INFO - 2021-06-12 07:10:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:40 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:40 --> URI Class Initialized
INFO - 2021-06-12 07:10:40 --> Router Class Initialized
INFO - 2021-06-12 07:10:40 --> Output Class Initialized
INFO - 2021-06-12 07:10:40 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:40 --> Input Class Initialized
INFO - 2021-06-12 07:10:40 --> Language Class Initialized
INFO - 2021-06-12 07:10:40 --> Language Class Initialized
INFO - 2021-06-12 07:10:40 --> Config Class Initialized
INFO - 2021-06-12 07:10:40 --> Loader Class Initialized
INFO - 2021-06-12 07:10:40 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:40 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:40 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:40 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:40 --> Controller Class Initialized
DEBUG - 2021-06-12 07:10:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:10:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:10:40 --> Final output sent to browser
DEBUG - 2021-06-12 07:10:40 --> Total execution time: 0.0444
INFO - 2021-06-12 07:10:40 --> Config Class Initialized
INFO - 2021-06-12 07:10:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:40 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:40 --> URI Class Initialized
INFO - 2021-06-12 07:10:40 --> Router Class Initialized
INFO - 2021-06-12 07:10:40 --> Output Class Initialized
INFO - 2021-06-12 07:10:40 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:40 --> Input Class Initialized
INFO - 2021-06-12 07:10:40 --> Language Class Initialized
INFO - 2021-06-12 07:10:40 --> Language Class Initialized
INFO - 2021-06-12 07:10:40 --> Config Class Initialized
INFO - 2021-06-12 07:10:40 --> Loader Class Initialized
INFO - 2021-06-12 07:10:40 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:40 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:40 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:40 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:40 --> Controller Class Initialized
INFO - 2021-06-12 07:10:41 --> Config Class Initialized
INFO - 2021-06-12 07:10:41 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:41 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:41 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:41 --> URI Class Initialized
INFO - 2021-06-12 07:10:41 --> Router Class Initialized
INFO - 2021-06-12 07:10:41 --> Output Class Initialized
INFO - 2021-06-12 07:10:41 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:41 --> Input Class Initialized
INFO - 2021-06-12 07:10:41 --> Language Class Initialized
INFO - 2021-06-12 07:10:41 --> Language Class Initialized
INFO - 2021-06-12 07:10:41 --> Config Class Initialized
INFO - 2021-06-12 07:10:41 --> Loader Class Initialized
INFO - 2021-06-12 07:10:41 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:41 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:41 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:41 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:41 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:41 --> Controller Class Initialized
DEBUG - 2021-06-12 07:10:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:10:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:10:41 --> Final output sent to browser
DEBUG - 2021-06-12 07:10:41 --> Total execution time: 0.0439
INFO - 2021-06-12 07:10:43 --> Config Class Initialized
INFO - 2021-06-12 07:10:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:10:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:10:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:10:43 --> URI Class Initialized
INFO - 2021-06-12 07:10:43 --> Router Class Initialized
INFO - 2021-06-12 07:10:43 --> Output Class Initialized
INFO - 2021-06-12 07:10:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:10:43 --> Input Class Initialized
INFO - 2021-06-12 07:10:43 --> Language Class Initialized
INFO - 2021-06-12 07:10:43 --> Language Class Initialized
INFO - 2021-06-12 07:10:43 --> Config Class Initialized
INFO - 2021-06-12 07:10:43 --> Loader Class Initialized
INFO - 2021-06-12 07:10:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:10:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:10:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:10:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:10:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:10:43 --> Controller Class Initialized
INFO - 2021-06-12 07:11:44 --> Config Class Initialized
INFO - 2021-06-12 07:11:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:11:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:11:44 --> Utf8 Class Initialized
INFO - 2021-06-12 07:11:44 --> URI Class Initialized
INFO - 2021-06-12 07:11:44 --> Router Class Initialized
INFO - 2021-06-12 07:11:44 --> Output Class Initialized
INFO - 2021-06-12 07:11:44 --> Security Class Initialized
DEBUG - 2021-06-12 07:11:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:11:44 --> Input Class Initialized
INFO - 2021-06-12 07:11:44 --> Language Class Initialized
INFO - 2021-06-12 07:11:44 --> Language Class Initialized
INFO - 2021-06-12 07:11:44 --> Config Class Initialized
INFO - 2021-06-12 07:11:44 --> Loader Class Initialized
INFO - 2021-06-12 07:11:45 --> Helper loaded: url_helper
INFO - 2021-06-12 07:11:45 --> Helper loaded: file_helper
INFO - 2021-06-12 07:11:45 --> Helper loaded: form_helper
INFO - 2021-06-12 07:11:45 --> Helper loaded: my_helper
INFO - 2021-06-12 07:11:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:11:45 --> Controller Class Initialized
INFO - 2021-06-12 07:12:10 --> Config Class Initialized
INFO - 2021-06-12 07:12:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:10 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:10 --> URI Class Initialized
INFO - 2021-06-12 07:12:10 --> Router Class Initialized
INFO - 2021-06-12 07:12:10 --> Output Class Initialized
INFO - 2021-06-12 07:12:10 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:10 --> Input Class Initialized
INFO - 2021-06-12 07:12:10 --> Language Class Initialized
INFO - 2021-06-12 07:12:10 --> Language Class Initialized
INFO - 2021-06-12 07:12:10 --> Config Class Initialized
INFO - 2021-06-12 07:12:10 --> Loader Class Initialized
INFO - 2021-06-12 07:12:10 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:10 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:10 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:10 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:10 --> Controller Class Initialized
INFO - 2021-06-12 07:12:10 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:12:10 --> Config Class Initialized
INFO - 2021-06-12 07:12:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:10 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:10 --> URI Class Initialized
INFO - 2021-06-12 07:12:10 --> Router Class Initialized
INFO - 2021-06-12 07:12:10 --> Output Class Initialized
INFO - 2021-06-12 07:12:10 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:10 --> Input Class Initialized
INFO - 2021-06-12 07:12:10 --> Language Class Initialized
INFO - 2021-06-12 07:12:10 --> Language Class Initialized
INFO - 2021-06-12 07:12:10 --> Config Class Initialized
INFO - 2021-06-12 07:12:10 --> Loader Class Initialized
INFO - 2021-06-12 07:12:10 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:10 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:10 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:10 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:10 --> Controller Class Initialized
DEBUG - 2021-06-12 07:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 07:12:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:12:11 --> Final output sent to browser
DEBUG - 2021-06-12 07:12:11 --> Total execution time: 0.0530
INFO - 2021-06-12 07:12:16 --> Config Class Initialized
INFO - 2021-06-12 07:12:16 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:16 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:16 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:16 --> URI Class Initialized
INFO - 2021-06-12 07:12:16 --> Router Class Initialized
INFO - 2021-06-12 07:12:16 --> Output Class Initialized
INFO - 2021-06-12 07:12:16 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:16 --> Input Class Initialized
INFO - 2021-06-12 07:12:16 --> Language Class Initialized
INFO - 2021-06-12 07:12:16 --> Language Class Initialized
INFO - 2021-06-12 07:12:16 --> Config Class Initialized
INFO - 2021-06-12 07:12:16 --> Loader Class Initialized
INFO - 2021-06-12 07:12:16 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:16 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:16 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:16 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:16 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:16 --> Controller Class Initialized
INFO - 2021-06-12 07:12:16 --> Final output sent to browser
DEBUG - 2021-06-12 07:12:16 --> Total execution time: 0.0504
INFO - 2021-06-12 07:12:19 --> Config Class Initialized
INFO - 2021-06-12 07:12:19 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:19 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:19 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:19 --> URI Class Initialized
INFO - 2021-06-12 07:12:19 --> Router Class Initialized
INFO - 2021-06-12 07:12:19 --> Output Class Initialized
INFO - 2021-06-12 07:12:19 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:19 --> Input Class Initialized
INFO - 2021-06-12 07:12:19 --> Language Class Initialized
INFO - 2021-06-12 07:12:19 --> Language Class Initialized
INFO - 2021-06-12 07:12:19 --> Config Class Initialized
INFO - 2021-06-12 07:12:19 --> Loader Class Initialized
INFO - 2021-06-12 07:12:19 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:19 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:19 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:19 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:19 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:19 --> Controller Class Initialized
INFO - 2021-06-12 07:12:19 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:12:19 --> Final output sent to browser
DEBUG - 2021-06-12 07:12:19 --> Total execution time: 0.0512
INFO - 2021-06-12 07:12:20 --> Config Class Initialized
INFO - 2021-06-12 07:12:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:20 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:20 --> URI Class Initialized
INFO - 2021-06-12 07:12:20 --> Router Class Initialized
INFO - 2021-06-12 07:12:20 --> Output Class Initialized
INFO - 2021-06-12 07:12:20 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:20 --> Input Class Initialized
INFO - 2021-06-12 07:12:20 --> Language Class Initialized
INFO - 2021-06-12 07:12:20 --> Language Class Initialized
INFO - 2021-06-12 07:12:20 --> Config Class Initialized
INFO - 2021-06-12 07:12:20 --> Loader Class Initialized
INFO - 2021-06-12 07:12:20 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:20 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:20 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:20 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:20 --> Controller Class Initialized
DEBUG - 2021-06-12 07:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 07:12:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:12:20 --> Final output sent to browser
DEBUG - 2021-06-12 07:12:20 --> Total execution time: 0.0722
INFO - 2021-06-12 07:12:21 --> Config Class Initialized
INFO - 2021-06-12 07:12:21 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:21 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:21 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:21 --> URI Class Initialized
INFO - 2021-06-12 07:12:21 --> Router Class Initialized
INFO - 2021-06-12 07:12:21 --> Output Class Initialized
INFO - 2021-06-12 07:12:21 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:21 --> Input Class Initialized
INFO - 2021-06-12 07:12:21 --> Language Class Initialized
INFO - 2021-06-12 07:12:21 --> Language Class Initialized
INFO - 2021-06-12 07:12:21 --> Config Class Initialized
INFO - 2021-06-12 07:12:21 --> Loader Class Initialized
INFO - 2021-06-12 07:12:21 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:21 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:21 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:21 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:21 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:21 --> Controller Class Initialized
DEBUG - 2021-06-12 07:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 07:12:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:12:21 --> Final output sent to browser
DEBUG - 2021-06-12 07:12:21 --> Total execution time: 0.0417
INFO - 2021-06-12 07:12:23 --> Config Class Initialized
INFO - 2021-06-12 07:12:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:23 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:23 --> URI Class Initialized
INFO - 2021-06-12 07:12:23 --> Router Class Initialized
INFO - 2021-06-12 07:12:23 --> Output Class Initialized
INFO - 2021-06-12 07:12:23 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:23 --> Input Class Initialized
INFO - 2021-06-12 07:12:23 --> Language Class Initialized
INFO - 2021-06-12 07:12:23 --> Language Class Initialized
INFO - 2021-06-12 07:12:23 --> Config Class Initialized
INFO - 2021-06-12 07:12:23 --> Loader Class Initialized
INFO - 2021-06-12 07:12:23 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:23 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:23 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:23 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:23 --> Controller Class Initialized
DEBUG - 2021-06-12 07:12:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:12:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:12:23 --> Final output sent to browser
DEBUG - 2021-06-12 07:12:23 --> Total execution time: 0.0448
INFO - 2021-06-12 07:12:23 --> Config Class Initialized
INFO - 2021-06-12 07:12:23 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:23 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:23 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:23 --> URI Class Initialized
INFO - 2021-06-12 07:12:23 --> Router Class Initialized
INFO - 2021-06-12 07:12:23 --> Output Class Initialized
INFO - 2021-06-12 07:12:23 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:23 --> Input Class Initialized
INFO - 2021-06-12 07:12:23 --> Language Class Initialized
INFO - 2021-06-12 07:12:23 --> Language Class Initialized
INFO - 2021-06-12 07:12:23 --> Config Class Initialized
INFO - 2021-06-12 07:12:23 --> Loader Class Initialized
INFO - 2021-06-12 07:12:23 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:23 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:23 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:23 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:23 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:23 --> Controller Class Initialized
INFO - 2021-06-12 07:12:25 --> Config Class Initialized
INFO - 2021-06-12 07:12:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:25 --> URI Class Initialized
INFO - 2021-06-12 07:12:25 --> Router Class Initialized
INFO - 2021-06-12 07:12:25 --> Output Class Initialized
INFO - 2021-06-12 07:12:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:25 --> Input Class Initialized
INFO - 2021-06-12 07:12:25 --> Language Class Initialized
INFO - 2021-06-12 07:12:25 --> Language Class Initialized
INFO - 2021-06-12 07:12:25 --> Config Class Initialized
INFO - 2021-06-12 07:12:25 --> Loader Class Initialized
INFO - 2021-06-12 07:12:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:25 --> Controller Class Initialized
DEBUG - 2021-06-12 07:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:12:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:12:25 --> Final output sent to browser
DEBUG - 2021-06-12 07:12:25 --> Total execution time: 0.0449
INFO - 2021-06-12 07:12:27 --> Config Class Initialized
INFO - 2021-06-12 07:12:27 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:27 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:27 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:27 --> URI Class Initialized
INFO - 2021-06-12 07:12:27 --> Router Class Initialized
INFO - 2021-06-12 07:12:27 --> Output Class Initialized
INFO - 2021-06-12 07:12:27 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:27 --> Input Class Initialized
INFO - 2021-06-12 07:12:27 --> Language Class Initialized
INFO - 2021-06-12 07:12:27 --> Language Class Initialized
INFO - 2021-06-12 07:12:27 --> Config Class Initialized
INFO - 2021-06-12 07:12:27 --> Loader Class Initialized
INFO - 2021-06-12 07:12:27 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:27 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:27 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:27 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:27 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:27 --> Controller Class Initialized
INFO - 2021-06-12 07:12:43 --> Config Class Initialized
INFO - 2021-06-12 07:12:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:12:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:12:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:12:43 --> URI Class Initialized
INFO - 2021-06-12 07:12:43 --> Router Class Initialized
INFO - 2021-06-12 07:12:43 --> Output Class Initialized
INFO - 2021-06-12 07:12:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:12:43 --> Input Class Initialized
INFO - 2021-06-12 07:12:43 --> Language Class Initialized
INFO - 2021-06-12 07:12:43 --> Language Class Initialized
INFO - 2021-06-12 07:12:43 --> Config Class Initialized
INFO - 2021-06-12 07:12:43 --> Loader Class Initialized
INFO - 2021-06-12 07:12:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:12:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:12:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:12:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:12:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:12:43 --> Controller Class Initialized
INFO - 2021-06-12 07:13:01 --> Config Class Initialized
INFO - 2021-06-12 07:13:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:13:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:13:01 --> Utf8 Class Initialized
INFO - 2021-06-12 07:13:01 --> URI Class Initialized
INFO - 2021-06-12 07:13:01 --> Router Class Initialized
INFO - 2021-06-12 07:13:01 --> Output Class Initialized
INFO - 2021-06-12 07:13:01 --> Security Class Initialized
DEBUG - 2021-06-12 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:13:01 --> Input Class Initialized
INFO - 2021-06-12 07:13:01 --> Language Class Initialized
INFO - 2021-06-12 07:13:01 --> Language Class Initialized
INFO - 2021-06-12 07:13:01 --> Config Class Initialized
INFO - 2021-06-12 07:13:01 --> Loader Class Initialized
INFO - 2021-06-12 07:13:01 --> Helper loaded: url_helper
INFO - 2021-06-12 07:13:01 --> Helper loaded: file_helper
INFO - 2021-06-12 07:13:01 --> Helper loaded: form_helper
INFO - 2021-06-12 07:13:01 --> Helper loaded: my_helper
INFO - 2021-06-12 07:13:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:13:01 --> Controller Class Initialized
DEBUG - 2021-06-12 07:13:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:13:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:13:01 --> Final output sent to browser
DEBUG - 2021-06-12 07:13:01 --> Total execution time: 0.0545
INFO - 2021-06-12 07:13:01 --> Config Class Initialized
INFO - 2021-06-12 07:13:01 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:13:01 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:13:01 --> Utf8 Class Initialized
INFO - 2021-06-12 07:13:01 --> URI Class Initialized
INFO - 2021-06-12 07:13:01 --> Router Class Initialized
INFO - 2021-06-12 07:13:01 --> Output Class Initialized
INFO - 2021-06-12 07:13:01 --> Security Class Initialized
DEBUG - 2021-06-12 07:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:13:01 --> Input Class Initialized
INFO - 2021-06-12 07:13:01 --> Language Class Initialized
INFO - 2021-06-12 07:13:01 --> Language Class Initialized
INFO - 2021-06-12 07:13:01 --> Config Class Initialized
INFO - 2021-06-12 07:13:01 --> Loader Class Initialized
INFO - 2021-06-12 07:13:01 --> Helper loaded: url_helper
INFO - 2021-06-12 07:13:01 --> Helper loaded: file_helper
INFO - 2021-06-12 07:13:01 --> Helper loaded: form_helper
INFO - 2021-06-12 07:13:01 --> Helper loaded: my_helper
INFO - 2021-06-12 07:13:01 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:13:01 --> Controller Class Initialized
INFO - 2021-06-12 07:13:10 --> Config Class Initialized
INFO - 2021-06-12 07:13:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:13:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:13:10 --> Utf8 Class Initialized
INFO - 2021-06-12 07:13:10 --> URI Class Initialized
INFO - 2021-06-12 07:13:10 --> Router Class Initialized
INFO - 2021-06-12 07:13:10 --> Output Class Initialized
INFO - 2021-06-12 07:13:10 --> Security Class Initialized
DEBUG - 2021-06-12 07:13:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:13:10 --> Input Class Initialized
INFO - 2021-06-12 07:13:10 --> Language Class Initialized
INFO - 2021-06-12 07:13:10 --> Language Class Initialized
INFO - 2021-06-12 07:13:10 --> Config Class Initialized
INFO - 2021-06-12 07:13:10 --> Loader Class Initialized
INFO - 2021-06-12 07:13:10 --> Helper loaded: url_helper
INFO - 2021-06-12 07:13:10 --> Helper loaded: file_helper
INFO - 2021-06-12 07:13:10 --> Helper loaded: form_helper
INFO - 2021-06-12 07:13:10 --> Helper loaded: my_helper
INFO - 2021-06-12 07:13:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:13:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:13:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:13:10 --> Controller Class Initialized
DEBUG - 2021-06-12 07:13:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:13:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:13:10 --> Final output sent to browser
DEBUG - 2021-06-12 07:13:10 --> Total execution time: 0.0446
INFO - 2021-06-12 07:13:15 --> Config Class Initialized
INFO - 2021-06-12 07:13:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:13:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:13:15 --> Utf8 Class Initialized
INFO - 2021-06-12 07:13:15 --> URI Class Initialized
INFO - 2021-06-12 07:13:15 --> Router Class Initialized
INFO - 2021-06-12 07:13:15 --> Output Class Initialized
INFO - 2021-06-12 07:13:15 --> Security Class Initialized
DEBUG - 2021-06-12 07:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:13:15 --> Input Class Initialized
INFO - 2021-06-12 07:13:15 --> Language Class Initialized
INFO - 2021-06-12 07:13:15 --> Language Class Initialized
INFO - 2021-06-12 07:13:15 --> Config Class Initialized
INFO - 2021-06-12 07:13:15 --> Loader Class Initialized
INFO - 2021-06-12 07:13:15 --> Helper loaded: url_helper
INFO - 2021-06-12 07:13:15 --> Helper loaded: file_helper
INFO - 2021-06-12 07:13:15 --> Helper loaded: form_helper
INFO - 2021-06-12 07:13:15 --> Helper loaded: my_helper
INFO - 2021-06-12 07:13:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:13:15 --> Controller Class Initialized
INFO - 2021-06-12 07:13:43 --> Config Class Initialized
INFO - 2021-06-12 07:13:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:13:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:13:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:13:43 --> URI Class Initialized
INFO - 2021-06-12 07:13:43 --> Router Class Initialized
INFO - 2021-06-12 07:13:43 --> Output Class Initialized
INFO - 2021-06-12 07:13:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:13:43 --> Input Class Initialized
INFO - 2021-06-12 07:13:43 --> Language Class Initialized
INFO - 2021-06-12 07:13:43 --> Language Class Initialized
INFO - 2021-06-12 07:13:43 --> Config Class Initialized
INFO - 2021-06-12 07:13:43 --> Loader Class Initialized
INFO - 2021-06-12 07:13:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:13:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:13:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:13:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:13:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:13:43 --> Controller Class Initialized
INFO - 2021-06-12 07:14:03 --> Config Class Initialized
INFO - 2021-06-12 07:14:03 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:14:03 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:14:03 --> Utf8 Class Initialized
INFO - 2021-06-12 07:14:03 --> URI Class Initialized
INFO - 2021-06-12 07:14:03 --> Router Class Initialized
INFO - 2021-06-12 07:14:03 --> Output Class Initialized
INFO - 2021-06-12 07:14:03 --> Security Class Initialized
DEBUG - 2021-06-12 07:14:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:14:03 --> Input Class Initialized
INFO - 2021-06-12 07:14:03 --> Language Class Initialized
INFO - 2021-06-12 07:14:03 --> Language Class Initialized
INFO - 2021-06-12 07:14:03 --> Config Class Initialized
INFO - 2021-06-12 07:14:03 --> Loader Class Initialized
INFO - 2021-06-12 07:14:03 --> Helper loaded: url_helper
INFO - 2021-06-12 07:14:03 --> Helper loaded: file_helper
INFO - 2021-06-12 07:14:03 --> Helper loaded: form_helper
INFO - 2021-06-12 07:14:03 --> Helper loaded: my_helper
INFO - 2021-06-12 07:14:03 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:14:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:14:03 --> Controller Class Initialized
DEBUG - 2021-06-12 07:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:14:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:14:03 --> Final output sent to browser
DEBUG - 2021-06-12 07:14:03 --> Total execution time: 0.0457
INFO - 2021-06-12 07:14:04 --> Config Class Initialized
INFO - 2021-06-12 07:14:04 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:14:04 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:14:04 --> Utf8 Class Initialized
INFO - 2021-06-12 07:14:04 --> URI Class Initialized
INFO - 2021-06-12 07:14:04 --> Router Class Initialized
INFO - 2021-06-12 07:14:04 --> Output Class Initialized
INFO - 2021-06-12 07:14:04 --> Security Class Initialized
DEBUG - 2021-06-12 07:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:14:04 --> Input Class Initialized
INFO - 2021-06-12 07:14:04 --> Language Class Initialized
INFO - 2021-06-12 07:14:04 --> Language Class Initialized
INFO - 2021-06-12 07:14:04 --> Config Class Initialized
INFO - 2021-06-12 07:14:04 --> Loader Class Initialized
INFO - 2021-06-12 07:14:04 --> Helper loaded: url_helper
INFO - 2021-06-12 07:14:04 --> Helper loaded: file_helper
INFO - 2021-06-12 07:14:04 --> Helper loaded: form_helper
INFO - 2021-06-12 07:14:04 --> Helper loaded: my_helper
INFO - 2021-06-12 07:14:04 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:14:04 --> Controller Class Initialized
INFO - 2021-06-12 07:14:06 --> Config Class Initialized
INFO - 2021-06-12 07:14:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:14:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:14:06 --> Utf8 Class Initialized
INFO - 2021-06-12 07:14:06 --> URI Class Initialized
INFO - 2021-06-12 07:14:06 --> Router Class Initialized
INFO - 2021-06-12 07:14:06 --> Output Class Initialized
INFO - 2021-06-12 07:14:06 --> Security Class Initialized
DEBUG - 2021-06-12 07:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:14:06 --> Input Class Initialized
INFO - 2021-06-12 07:14:06 --> Language Class Initialized
INFO - 2021-06-12 07:14:06 --> Language Class Initialized
INFO - 2021-06-12 07:14:06 --> Config Class Initialized
INFO - 2021-06-12 07:14:06 --> Loader Class Initialized
INFO - 2021-06-12 07:14:06 --> Helper loaded: url_helper
INFO - 2021-06-12 07:14:06 --> Helper loaded: file_helper
INFO - 2021-06-12 07:14:06 --> Helper loaded: form_helper
INFO - 2021-06-12 07:14:06 --> Helper loaded: my_helper
INFO - 2021-06-12 07:14:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:14:06 --> Controller Class Initialized
DEBUG - 2021-06-12 07:14:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:14:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:14:06 --> Final output sent to browser
DEBUG - 2021-06-12 07:14:06 --> Total execution time: 0.0457
INFO - 2021-06-12 07:14:09 --> Config Class Initialized
INFO - 2021-06-12 07:14:09 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:14:09 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:14:09 --> Utf8 Class Initialized
INFO - 2021-06-12 07:14:09 --> URI Class Initialized
INFO - 2021-06-12 07:14:09 --> Router Class Initialized
INFO - 2021-06-12 07:14:09 --> Output Class Initialized
INFO - 2021-06-12 07:14:09 --> Security Class Initialized
DEBUG - 2021-06-12 07:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:14:09 --> Input Class Initialized
INFO - 2021-06-12 07:14:09 --> Language Class Initialized
INFO - 2021-06-12 07:14:09 --> Language Class Initialized
INFO - 2021-06-12 07:14:09 --> Config Class Initialized
INFO - 2021-06-12 07:14:09 --> Loader Class Initialized
INFO - 2021-06-12 07:14:09 --> Helper loaded: url_helper
INFO - 2021-06-12 07:14:09 --> Helper loaded: file_helper
INFO - 2021-06-12 07:14:09 --> Helper loaded: form_helper
INFO - 2021-06-12 07:14:09 --> Helper loaded: my_helper
INFO - 2021-06-12 07:14:09 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:14:09 --> Controller Class Initialized
INFO - 2021-06-12 07:14:25 --> Config Class Initialized
INFO - 2021-06-12 07:14:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:14:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:14:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:14:25 --> URI Class Initialized
INFO - 2021-06-12 07:14:25 --> Router Class Initialized
INFO - 2021-06-12 07:14:25 --> Output Class Initialized
INFO - 2021-06-12 07:14:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:14:25 --> Input Class Initialized
INFO - 2021-06-12 07:14:25 --> Language Class Initialized
INFO - 2021-06-12 07:14:25 --> Language Class Initialized
INFO - 2021-06-12 07:14:25 --> Config Class Initialized
INFO - 2021-06-12 07:14:25 --> Loader Class Initialized
INFO - 2021-06-12 07:14:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:14:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:14:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:14:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:14:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:14:25 --> Controller Class Initialized
DEBUG - 2021-06-12 07:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 07:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:14:25 --> Final output sent to browser
DEBUG - 2021-06-12 07:14:25 --> Total execution time: 0.0525
INFO - 2021-06-12 07:14:43 --> Config Class Initialized
INFO - 2021-06-12 07:14:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:14:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:14:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:14:43 --> URI Class Initialized
INFO - 2021-06-12 07:14:43 --> Router Class Initialized
INFO - 2021-06-12 07:14:43 --> Output Class Initialized
INFO - 2021-06-12 07:14:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:14:43 --> Input Class Initialized
INFO - 2021-06-12 07:14:43 --> Language Class Initialized
INFO - 2021-06-12 07:14:43 --> Language Class Initialized
INFO - 2021-06-12 07:14:43 --> Config Class Initialized
INFO - 2021-06-12 07:14:43 --> Loader Class Initialized
INFO - 2021-06-12 07:14:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:14:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:14:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:14:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:14:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:14:43 --> Controller Class Initialized
INFO - 2021-06-12 07:15:44 --> Config Class Initialized
INFO - 2021-06-12 07:15:44 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:44 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:44 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:44 --> URI Class Initialized
INFO - 2021-06-12 07:15:44 --> Router Class Initialized
INFO - 2021-06-12 07:15:44 --> Output Class Initialized
INFO - 2021-06-12 07:15:44 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:44 --> Input Class Initialized
INFO - 2021-06-12 07:15:44 --> Language Class Initialized
INFO - 2021-06-12 07:15:44 --> Language Class Initialized
INFO - 2021-06-12 07:15:44 --> Config Class Initialized
INFO - 2021-06-12 07:15:44 --> Loader Class Initialized
INFO - 2021-06-12 07:15:44 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:44 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:44 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:44 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:44 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:45 --> Controller Class Initialized
INFO - 2021-06-12 07:15:45 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:15:45 --> Config Class Initialized
INFO - 2021-06-12 07:15:45 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:45 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:45 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:45 --> URI Class Initialized
INFO - 2021-06-12 07:15:45 --> Router Class Initialized
INFO - 2021-06-12 07:15:45 --> Output Class Initialized
INFO - 2021-06-12 07:15:45 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:45 --> Input Class Initialized
INFO - 2021-06-12 07:15:45 --> Language Class Initialized
INFO - 2021-06-12 07:15:45 --> Language Class Initialized
INFO - 2021-06-12 07:15:45 --> Config Class Initialized
INFO - 2021-06-12 07:15:45 --> Loader Class Initialized
INFO - 2021-06-12 07:15:45 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:45 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:45 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:45 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:45 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:45 --> Controller Class Initialized
DEBUG - 2021-06-12 07:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 07:15:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:15:45 --> Final output sent to browser
DEBUG - 2021-06-12 07:15:45 --> Total execution time: 0.0528
INFO - 2021-06-12 07:15:50 --> Config Class Initialized
INFO - 2021-06-12 07:15:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:50 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:50 --> URI Class Initialized
INFO - 2021-06-12 07:15:50 --> Router Class Initialized
INFO - 2021-06-12 07:15:50 --> Output Class Initialized
INFO - 2021-06-12 07:15:50 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:50 --> Input Class Initialized
INFO - 2021-06-12 07:15:50 --> Language Class Initialized
INFO - 2021-06-12 07:15:50 --> Language Class Initialized
INFO - 2021-06-12 07:15:50 --> Config Class Initialized
INFO - 2021-06-12 07:15:50 --> Loader Class Initialized
INFO - 2021-06-12 07:15:50 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:50 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:50 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:50 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:50 --> Controller Class Initialized
INFO - 2021-06-12 07:15:50 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:15:50 --> Final output sent to browser
DEBUG - 2021-06-12 07:15:50 --> Total execution time: 0.0525
INFO - 2021-06-12 07:15:50 --> Config Class Initialized
INFO - 2021-06-12 07:15:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:50 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:50 --> URI Class Initialized
INFO - 2021-06-12 07:15:50 --> Router Class Initialized
INFO - 2021-06-12 07:15:50 --> Output Class Initialized
INFO - 2021-06-12 07:15:50 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:50 --> Input Class Initialized
INFO - 2021-06-12 07:15:50 --> Language Class Initialized
INFO - 2021-06-12 07:15:50 --> Language Class Initialized
INFO - 2021-06-12 07:15:50 --> Config Class Initialized
INFO - 2021-06-12 07:15:50 --> Loader Class Initialized
INFO - 2021-06-12 07:15:50 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:50 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:50 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:50 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:50 --> Controller Class Initialized
DEBUG - 2021-06-12 07:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-06-12 07:15:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:15:50 --> Final output sent to browser
DEBUG - 2021-06-12 07:15:50 --> Total execution time: 0.0838
INFO - 2021-06-12 07:15:53 --> Config Class Initialized
INFO - 2021-06-12 07:15:53 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:53 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:53 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:53 --> URI Class Initialized
INFO - 2021-06-12 07:15:53 --> Router Class Initialized
INFO - 2021-06-12 07:15:53 --> Output Class Initialized
INFO - 2021-06-12 07:15:53 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:53 --> Input Class Initialized
INFO - 2021-06-12 07:15:53 --> Language Class Initialized
INFO - 2021-06-12 07:15:53 --> Language Class Initialized
INFO - 2021-06-12 07:15:53 --> Config Class Initialized
INFO - 2021-06-12 07:15:53 --> Loader Class Initialized
INFO - 2021-06-12 07:15:53 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:53 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:53 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:53 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:53 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:53 --> Controller Class Initialized
DEBUG - 2021-06-12 07:15:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-06-12 07:15:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:15:53 --> Final output sent to browser
DEBUG - 2021-06-12 07:15:53 --> Total execution time: 0.0435
INFO - 2021-06-12 07:15:57 --> Config Class Initialized
INFO - 2021-06-12 07:15:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:57 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:57 --> URI Class Initialized
INFO - 2021-06-12 07:15:57 --> Router Class Initialized
INFO - 2021-06-12 07:15:57 --> Output Class Initialized
INFO - 2021-06-12 07:15:57 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:57 --> Input Class Initialized
INFO - 2021-06-12 07:15:57 --> Language Class Initialized
INFO - 2021-06-12 07:15:57 --> Language Class Initialized
INFO - 2021-06-12 07:15:57 --> Config Class Initialized
INFO - 2021-06-12 07:15:57 --> Loader Class Initialized
INFO - 2021-06-12 07:15:57 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:57 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:57 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:57 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:57 --> Controller Class Initialized
DEBUG - 2021-06-12 07:15:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:15:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:15:57 --> Final output sent to browser
DEBUG - 2021-06-12 07:15:57 --> Total execution time: 0.0446
INFO - 2021-06-12 07:15:57 --> Config Class Initialized
INFO - 2021-06-12 07:15:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:57 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:57 --> URI Class Initialized
INFO - 2021-06-12 07:15:57 --> Router Class Initialized
INFO - 2021-06-12 07:15:57 --> Output Class Initialized
INFO - 2021-06-12 07:15:57 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:57 --> Input Class Initialized
INFO - 2021-06-12 07:15:57 --> Language Class Initialized
INFO - 2021-06-12 07:15:57 --> Language Class Initialized
INFO - 2021-06-12 07:15:57 --> Config Class Initialized
INFO - 2021-06-12 07:15:57 --> Loader Class Initialized
INFO - 2021-06-12 07:15:57 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:57 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:57 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:57 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:57 --> Controller Class Initialized
INFO - 2021-06-12 07:15:59 --> Config Class Initialized
INFO - 2021-06-12 07:15:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:15:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:15:59 --> Utf8 Class Initialized
INFO - 2021-06-12 07:15:59 --> URI Class Initialized
INFO - 2021-06-12 07:15:59 --> Router Class Initialized
INFO - 2021-06-12 07:15:59 --> Output Class Initialized
INFO - 2021-06-12 07:15:59 --> Security Class Initialized
DEBUG - 2021-06-12 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:15:59 --> Input Class Initialized
INFO - 2021-06-12 07:15:59 --> Language Class Initialized
INFO - 2021-06-12 07:15:59 --> Language Class Initialized
INFO - 2021-06-12 07:15:59 --> Config Class Initialized
INFO - 2021-06-12 07:15:59 --> Loader Class Initialized
INFO - 2021-06-12 07:15:59 --> Helper loaded: url_helper
INFO - 2021-06-12 07:15:59 --> Helper loaded: file_helper
INFO - 2021-06-12 07:15:59 --> Helper loaded: form_helper
INFO - 2021-06-12 07:15:59 --> Helper loaded: my_helper
INFO - 2021-06-12 07:15:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:15:59 --> Controller Class Initialized
DEBUG - 2021-06-12 07:15:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:15:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:15:59 --> Final output sent to browser
DEBUG - 2021-06-12 07:15:59 --> Total execution time: 0.0449
INFO - 2021-06-12 07:16:00 --> Config Class Initialized
INFO - 2021-06-12 07:16:00 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:16:00 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:16:00 --> Utf8 Class Initialized
INFO - 2021-06-12 07:16:00 --> URI Class Initialized
INFO - 2021-06-12 07:16:00 --> Router Class Initialized
INFO - 2021-06-12 07:16:00 --> Output Class Initialized
INFO - 2021-06-12 07:16:00 --> Security Class Initialized
DEBUG - 2021-06-12 07:16:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:16:00 --> Input Class Initialized
INFO - 2021-06-12 07:16:00 --> Language Class Initialized
INFO - 2021-06-12 07:16:00 --> Language Class Initialized
INFO - 2021-06-12 07:16:00 --> Config Class Initialized
INFO - 2021-06-12 07:16:00 --> Loader Class Initialized
INFO - 2021-06-12 07:16:00 --> Helper loaded: url_helper
INFO - 2021-06-12 07:16:00 --> Helper loaded: file_helper
INFO - 2021-06-12 07:16:00 --> Helper loaded: form_helper
INFO - 2021-06-12 07:16:00 --> Helper loaded: my_helper
INFO - 2021-06-12 07:16:00 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:16:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:16:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:16:00 --> Controller Class Initialized
INFO - 2021-06-12 07:16:25 --> Config Class Initialized
INFO - 2021-06-12 07:16:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:16:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:16:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:16:25 --> URI Class Initialized
INFO - 2021-06-12 07:16:25 --> Router Class Initialized
INFO - 2021-06-12 07:16:25 --> Output Class Initialized
INFO - 2021-06-12 07:16:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:16:25 --> Input Class Initialized
INFO - 2021-06-12 07:16:25 --> Language Class Initialized
INFO - 2021-06-12 07:16:25 --> Language Class Initialized
INFO - 2021-06-12 07:16:25 --> Config Class Initialized
INFO - 2021-06-12 07:16:25 --> Loader Class Initialized
INFO - 2021-06-12 07:16:25 --> Helper loaded: url_helper
INFO - 2021-06-12 07:16:25 --> Helper loaded: file_helper
INFO - 2021-06-12 07:16:25 --> Helper loaded: form_helper
INFO - 2021-06-12 07:16:25 --> Helper loaded: my_helper
INFO - 2021-06-12 07:16:25 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:16:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:16:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:16:25 --> Controller Class Initialized
INFO - 2021-06-12 07:16:37 --> Config Class Initialized
INFO - 2021-06-12 07:16:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:16:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:16:37 --> Utf8 Class Initialized
INFO - 2021-06-12 07:16:37 --> URI Class Initialized
INFO - 2021-06-12 07:16:37 --> Router Class Initialized
INFO - 2021-06-12 07:16:37 --> Output Class Initialized
INFO - 2021-06-12 07:16:37 --> Security Class Initialized
DEBUG - 2021-06-12 07:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:16:37 --> Input Class Initialized
INFO - 2021-06-12 07:16:37 --> Language Class Initialized
INFO - 2021-06-12 07:16:37 --> Language Class Initialized
INFO - 2021-06-12 07:16:37 --> Config Class Initialized
INFO - 2021-06-12 07:16:37 --> Loader Class Initialized
INFO - 2021-06-12 07:16:37 --> Helper loaded: url_helper
INFO - 2021-06-12 07:16:37 --> Helper loaded: file_helper
INFO - 2021-06-12 07:16:37 --> Helper loaded: form_helper
INFO - 2021-06-12 07:16:37 --> Helper loaded: my_helper
INFO - 2021-06-12 07:16:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:16:37 --> Controller Class Initialized
DEBUG - 2021-06-12 07:16:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:16:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:16:37 --> Final output sent to browser
DEBUG - 2021-06-12 07:16:37 --> Total execution time: 0.0453
INFO - 2021-06-12 07:16:37 --> Config Class Initialized
INFO - 2021-06-12 07:16:37 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:16:37 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:16:37 --> Utf8 Class Initialized
INFO - 2021-06-12 07:16:37 --> URI Class Initialized
INFO - 2021-06-12 07:16:37 --> Router Class Initialized
INFO - 2021-06-12 07:16:37 --> Output Class Initialized
INFO - 2021-06-12 07:16:37 --> Security Class Initialized
DEBUG - 2021-06-12 07:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:16:37 --> Input Class Initialized
INFO - 2021-06-12 07:16:37 --> Language Class Initialized
INFO - 2021-06-12 07:16:37 --> Language Class Initialized
INFO - 2021-06-12 07:16:37 --> Config Class Initialized
INFO - 2021-06-12 07:16:37 --> Loader Class Initialized
INFO - 2021-06-12 07:16:37 --> Helper loaded: url_helper
INFO - 2021-06-12 07:16:37 --> Helper loaded: file_helper
INFO - 2021-06-12 07:16:37 --> Helper loaded: form_helper
INFO - 2021-06-12 07:16:37 --> Helper loaded: my_helper
INFO - 2021-06-12 07:16:37 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:16:37 --> Controller Class Initialized
INFO - 2021-06-12 07:16:38 --> Config Class Initialized
INFO - 2021-06-12 07:16:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:16:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:16:38 --> Utf8 Class Initialized
INFO - 2021-06-12 07:16:38 --> URI Class Initialized
INFO - 2021-06-12 07:16:38 --> Router Class Initialized
INFO - 2021-06-12 07:16:38 --> Output Class Initialized
INFO - 2021-06-12 07:16:38 --> Security Class Initialized
DEBUG - 2021-06-12 07:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:16:38 --> Input Class Initialized
INFO - 2021-06-12 07:16:38 --> Language Class Initialized
INFO - 2021-06-12 07:16:38 --> Language Class Initialized
INFO - 2021-06-12 07:16:38 --> Config Class Initialized
INFO - 2021-06-12 07:16:38 --> Loader Class Initialized
INFO - 2021-06-12 07:16:38 --> Helper loaded: url_helper
INFO - 2021-06-12 07:16:38 --> Helper loaded: file_helper
INFO - 2021-06-12 07:16:38 --> Helper loaded: form_helper
INFO - 2021-06-12 07:16:38 --> Helper loaded: my_helper
INFO - 2021-06-12 07:16:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:16:38 --> Controller Class Initialized
DEBUG - 2021-06-12 07:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:16:38 --> Final output sent to browser
DEBUG - 2021-06-12 07:16:38 --> Total execution time: 0.0441
INFO - 2021-06-12 07:16:40 --> Config Class Initialized
INFO - 2021-06-12 07:16:40 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:16:40 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:16:40 --> Utf8 Class Initialized
INFO - 2021-06-12 07:16:40 --> URI Class Initialized
INFO - 2021-06-12 07:16:40 --> Router Class Initialized
INFO - 2021-06-12 07:16:40 --> Output Class Initialized
INFO - 2021-06-12 07:16:40 --> Security Class Initialized
DEBUG - 2021-06-12 07:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:16:40 --> Input Class Initialized
INFO - 2021-06-12 07:16:40 --> Language Class Initialized
INFO - 2021-06-12 07:16:40 --> Language Class Initialized
INFO - 2021-06-12 07:16:40 --> Config Class Initialized
INFO - 2021-06-12 07:16:40 --> Loader Class Initialized
INFO - 2021-06-12 07:16:40 --> Helper loaded: url_helper
INFO - 2021-06-12 07:16:40 --> Helper loaded: file_helper
INFO - 2021-06-12 07:16:40 --> Helper loaded: form_helper
INFO - 2021-06-12 07:16:40 --> Helper loaded: my_helper
INFO - 2021-06-12 07:16:40 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:16:40 --> Controller Class Initialized
INFO - 2021-06-12 07:16:58 --> Config Class Initialized
INFO - 2021-06-12 07:16:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:16:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:16:58 --> Utf8 Class Initialized
INFO - 2021-06-12 07:16:58 --> URI Class Initialized
INFO - 2021-06-12 07:16:58 --> Router Class Initialized
INFO - 2021-06-12 07:16:58 --> Output Class Initialized
INFO - 2021-06-12 07:16:58 --> Security Class Initialized
DEBUG - 2021-06-12 07:16:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:16:58 --> Input Class Initialized
INFO - 2021-06-12 07:16:58 --> Language Class Initialized
INFO - 2021-06-12 07:16:58 --> Language Class Initialized
INFO - 2021-06-12 07:16:58 --> Config Class Initialized
INFO - 2021-06-12 07:16:58 --> Loader Class Initialized
INFO - 2021-06-12 07:16:58 --> Helper loaded: url_helper
INFO - 2021-06-12 07:16:58 --> Helper loaded: file_helper
INFO - 2021-06-12 07:16:58 --> Helper loaded: form_helper
INFO - 2021-06-12 07:16:58 --> Helper loaded: my_helper
INFO - 2021-06-12 07:16:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:16:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:16:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:16:58 --> Controller Class Initialized
INFO - 2021-06-12 07:17:17 --> Config Class Initialized
INFO - 2021-06-12 07:17:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:17 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:17 --> URI Class Initialized
INFO - 2021-06-12 07:17:17 --> Router Class Initialized
INFO - 2021-06-12 07:17:17 --> Output Class Initialized
INFO - 2021-06-12 07:17:17 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:17 --> Input Class Initialized
INFO - 2021-06-12 07:17:17 --> Language Class Initialized
INFO - 2021-06-12 07:17:17 --> Language Class Initialized
INFO - 2021-06-12 07:17:17 --> Config Class Initialized
INFO - 2021-06-12 07:17:17 --> Loader Class Initialized
INFO - 2021-06-12 07:17:17 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:17 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:17 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:17 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:17 --> Controller Class Initialized
DEBUG - 2021-06-12 07:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:17:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:17:17 --> Final output sent to browser
DEBUG - 2021-06-12 07:17:17 --> Total execution time: 0.0444
INFO - 2021-06-12 07:17:17 --> Config Class Initialized
INFO - 2021-06-12 07:17:17 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:17 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:17 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:17 --> URI Class Initialized
INFO - 2021-06-12 07:17:17 --> Router Class Initialized
INFO - 2021-06-12 07:17:17 --> Output Class Initialized
INFO - 2021-06-12 07:17:17 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:17 --> Input Class Initialized
INFO - 2021-06-12 07:17:17 --> Language Class Initialized
INFO - 2021-06-12 07:17:17 --> Language Class Initialized
INFO - 2021-06-12 07:17:17 --> Config Class Initialized
INFO - 2021-06-12 07:17:17 --> Loader Class Initialized
INFO - 2021-06-12 07:17:17 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:17 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:17 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:17 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:17 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:17 --> Controller Class Initialized
INFO - 2021-06-12 07:17:18 --> Config Class Initialized
INFO - 2021-06-12 07:17:18 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:18 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:18 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:18 --> URI Class Initialized
INFO - 2021-06-12 07:17:18 --> Router Class Initialized
INFO - 2021-06-12 07:17:18 --> Output Class Initialized
INFO - 2021-06-12 07:17:18 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:18 --> Input Class Initialized
INFO - 2021-06-12 07:17:18 --> Language Class Initialized
INFO - 2021-06-12 07:17:18 --> Language Class Initialized
INFO - 2021-06-12 07:17:18 --> Config Class Initialized
INFO - 2021-06-12 07:17:18 --> Loader Class Initialized
INFO - 2021-06-12 07:17:18 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:18 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:18 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:18 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:18 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:18 --> Controller Class Initialized
DEBUG - 2021-06-12 07:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:17:18 --> Final output sent to browser
DEBUG - 2021-06-12 07:17:18 --> Total execution time: 0.0443
INFO - 2021-06-12 07:17:20 --> Config Class Initialized
INFO - 2021-06-12 07:17:20 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:20 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:20 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:20 --> URI Class Initialized
INFO - 2021-06-12 07:17:20 --> Router Class Initialized
INFO - 2021-06-12 07:17:20 --> Output Class Initialized
INFO - 2021-06-12 07:17:20 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:20 --> Input Class Initialized
INFO - 2021-06-12 07:17:20 --> Language Class Initialized
INFO - 2021-06-12 07:17:20 --> Language Class Initialized
INFO - 2021-06-12 07:17:20 --> Config Class Initialized
INFO - 2021-06-12 07:17:20 --> Loader Class Initialized
INFO - 2021-06-12 07:17:20 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:20 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:20 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:20 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:20 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:20 --> Controller Class Initialized
INFO - 2021-06-12 07:17:43 --> Config Class Initialized
INFO - 2021-06-12 07:17:43 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:43 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:43 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:43 --> URI Class Initialized
INFO - 2021-06-12 07:17:43 --> Router Class Initialized
INFO - 2021-06-12 07:17:43 --> Output Class Initialized
INFO - 2021-06-12 07:17:43 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:43 --> Input Class Initialized
INFO - 2021-06-12 07:17:43 --> Language Class Initialized
INFO - 2021-06-12 07:17:43 --> Language Class Initialized
INFO - 2021-06-12 07:17:43 --> Config Class Initialized
INFO - 2021-06-12 07:17:43 --> Loader Class Initialized
INFO - 2021-06-12 07:17:43 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:43 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:43 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:43 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:43 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:43 --> Controller Class Initialized
INFO - 2021-06-12 07:17:57 --> Config Class Initialized
INFO - 2021-06-12 07:17:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:57 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:57 --> URI Class Initialized
INFO - 2021-06-12 07:17:57 --> Router Class Initialized
INFO - 2021-06-12 07:17:57 --> Output Class Initialized
INFO - 2021-06-12 07:17:57 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:57 --> Input Class Initialized
INFO - 2021-06-12 07:17:57 --> Language Class Initialized
INFO - 2021-06-12 07:17:57 --> Language Class Initialized
INFO - 2021-06-12 07:17:57 --> Config Class Initialized
INFO - 2021-06-12 07:17:57 --> Loader Class Initialized
INFO - 2021-06-12 07:17:57 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:57 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:57 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:57 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:57 --> Controller Class Initialized
DEBUG - 2021-06-12 07:17:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:17:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:17:57 --> Final output sent to browser
DEBUG - 2021-06-12 07:17:57 --> Total execution time: 0.0469
INFO - 2021-06-12 07:17:57 --> Config Class Initialized
INFO - 2021-06-12 07:17:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:57 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:57 --> URI Class Initialized
INFO - 2021-06-12 07:17:57 --> Router Class Initialized
INFO - 2021-06-12 07:17:57 --> Output Class Initialized
INFO - 2021-06-12 07:17:57 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:57 --> Input Class Initialized
INFO - 2021-06-12 07:17:57 --> Language Class Initialized
INFO - 2021-06-12 07:17:57 --> Language Class Initialized
INFO - 2021-06-12 07:17:57 --> Config Class Initialized
INFO - 2021-06-12 07:17:57 --> Loader Class Initialized
INFO - 2021-06-12 07:17:57 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:57 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:57 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:57 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:57 --> Controller Class Initialized
INFO - 2021-06-12 07:17:58 --> Config Class Initialized
INFO - 2021-06-12 07:17:58 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:58 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:58 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:58 --> URI Class Initialized
INFO - 2021-06-12 07:17:58 --> Router Class Initialized
INFO - 2021-06-12 07:17:58 --> Output Class Initialized
INFO - 2021-06-12 07:17:58 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:58 --> Input Class Initialized
INFO - 2021-06-12 07:17:58 --> Language Class Initialized
INFO - 2021-06-12 07:17:58 --> Language Class Initialized
INFO - 2021-06-12 07:17:58 --> Config Class Initialized
INFO - 2021-06-12 07:17:58 --> Loader Class Initialized
INFO - 2021-06-12 07:17:58 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:58 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:58 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:58 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:58 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:58 --> Controller Class Initialized
DEBUG - 2021-06-12 07:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:17:58 --> Final output sent to browser
DEBUG - 2021-06-12 07:17:58 --> Total execution time: 0.0448
INFO - 2021-06-12 07:17:59 --> Config Class Initialized
INFO - 2021-06-12 07:17:59 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:17:59 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:17:59 --> Utf8 Class Initialized
INFO - 2021-06-12 07:17:59 --> URI Class Initialized
INFO - 2021-06-12 07:17:59 --> Router Class Initialized
INFO - 2021-06-12 07:17:59 --> Output Class Initialized
INFO - 2021-06-12 07:17:59 --> Security Class Initialized
DEBUG - 2021-06-12 07:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:17:59 --> Input Class Initialized
INFO - 2021-06-12 07:17:59 --> Language Class Initialized
INFO - 2021-06-12 07:17:59 --> Language Class Initialized
INFO - 2021-06-12 07:17:59 --> Config Class Initialized
INFO - 2021-06-12 07:17:59 --> Loader Class Initialized
INFO - 2021-06-12 07:17:59 --> Helper loaded: url_helper
INFO - 2021-06-12 07:17:59 --> Helper loaded: file_helper
INFO - 2021-06-12 07:17:59 --> Helper loaded: form_helper
INFO - 2021-06-12 07:17:59 --> Helper loaded: my_helper
INFO - 2021-06-12 07:17:59 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:17:59 --> Controller Class Initialized
INFO - 2021-06-12 07:18:13 --> Config Class Initialized
INFO - 2021-06-12 07:18:13 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:18:13 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:18:13 --> Utf8 Class Initialized
INFO - 2021-06-12 07:18:13 --> URI Class Initialized
INFO - 2021-06-12 07:18:13 --> Router Class Initialized
INFO - 2021-06-12 07:18:13 --> Output Class Initialized
INFO - 2021-06-12 07:18:13 --> Security Class Initialized
DEBUG - 2021-06-12 07:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:18:13 --> Input Class Initialized
INFO - 2021-06-12 07:18:13 --> Language Class Initialized
INFO - 2021-06-12 07:18:13 --> Language Class Initialized
INFO - 2021-06-12 07:18:13 --> Config Class Initialized
INFO - 2021-06-12 07:18:13 --> Loader Class Initialized
INFO - 2021-06-12 07:18:13 --> Helper loaded: url_helper
INFO - 2021-06-12 07:18:13 --> Helper loaded: file_helper
INFO - 2021-06-12 07:18:13 --> Helper loaded: form_helper
INFO - 2021-06-12 07:18:13 --> Helper loaded: my_helper
INFO - 2021-06-12 07:18:13 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:18:13 --> Controller Class Initialized
INFO - 2021-06-12 07:18:31 --> Config Class Initialized
INFO - 2021-06-12 07:18:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:18:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:18:31 --> Utf8 Class Initialized
INFO - 2021-06-12 07:18:31 --> URI Class Initialized
INFO - 2021-06-12 07:18:31 --> Router Class Initialized
INFO - 2021-06-12 07:18:31 --> Output Class Initialized
INFO - 2021-06-12 07:18:31 --> Security Class Initialized
DEBUG - 2021-06-12 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:18:31 --> Input Class Initialized
INFO - 2021-06-12 07:18:31 --> Language Class Initialized
INFO - 2021-06-12 07:18:31 --> Language Class Initialized
INFO - 2021-06-12 07:18:31 --> Config Class Initialized
INFO - 2021-06-12 07:18:31 --> Loader Class Initialized
INFO - 2021-06-12 07:18:31 --> Helper loaded: url_helper
INFO - 2021-06-12 07:18:31 --> Helper loaded: file_helper
INFO - 2021-06-12 07:18:31 --> Helper loaded: form_helper
INFO - 2021-06-12 07:18:31 --> Helper loaded: my_helper
INFO - 2021-06-12 07:18:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:18:31 --> Controller Class Initialized
DEBUG - 2021-06-12 07:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:18:31 --> Final output sent to browser
DEBUG - 2021-06-12 07:18:31 --> Total execution time: 0.0446
INFO - 2021-06-12 07:18:31 --> Config Class Initialized
INFO - 2021-06-12 07:18:31 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:18:31 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:18:31 --> Utf8 Class Initialized
INFO - 2021-06-12 07:18:31 --> URI Class Initialized
INFO - 2021-06-12 07:18:31 --> Router Class Initialized
INFO - 2021-06-12 07:18:31 --> Output Class Initialized
INFO - 2021-06-12 07:18:31 --> Security Class Initialized
DEBUG - 2021-06-12 07:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:18:31 --> Input Class Initialized
INFO - 2021-06-12 07:18:31 --> Language Class Initialized
INFO - 2021-06-12 07:18:31 --> Language Class Initialized
INFO - 2021-06-12 07:18:31 --> Config Class Initialized
INFO - 2021-06-12 07:18:31 --> Loader Class Initialized
INFO - 2021-06-12 07:18:31 --> Helper loaded: url_helper
INFO - 2021-06-12 07:18:31 --> Helper loaded: file_helper
INFO - 2021-06-12 07:18:31 --> Helper loaded: form_helper
INFO - 2021-06-12 07:18:31 --> Helper loaded: my_helper
INFO - 2021-06-12 07:18:31 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:18:31 --> Controller Class Initialized
INFO - 2021-06-12 07:18:32 --> Config Class Initialized
INFO - 2021-06-12 07:18:32 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:18:32 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:18:32 --> Utf8 Class Initialized
INFO - 2021-06-12 07:18:32 --> URI Class Initialized
INFO - 2021-06-12 07:18:32 --> Router Class Initialized
INFO - 2021-06-12 07:18:32 --> Output Class Initialized
INFO - 2021-06-12 07:18:32 --> Security Class Initialized
DEBUG - 2021-06-12 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:18:32 --> Input Class Initialized
INFO - 2021-06-12 07:18:32 --> Language Class Initialized
INFO - 2021-06-12 07:18:32 --> Language Class Initialized
INFO - 2021-06-12 07:18:32 --> Config Class Initialized
INFO - 2021-06-12 07:18:32 --> Loader Class Initialized
INFO - 2021-06-12 07:18:32 --> Helper loaded: url_helper
INFO - 2021-06-12 07:18:32 --> Helper loaded: file_helper
INFO - 2021-06-12 07:18:32 --> Helper loaded: form_helper
INFO - 2021-06-12 07:18:32 --> Helper loaded: my_helper
INFO - 2021-06-12 07:18:32 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:18:32 --> Controller Class Initialized
DEBUG - 2021-06-12 07:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:18:32 --> Final output sent to browser
DEBUG - 2021-06-12 07:18:32 --> Total execution time: 0.0457
INFO - 2021-06-12 07:18:34 --> Config Class Initialized
INFO - 2021-06-12 07:18:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:18:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:18:34 --> Utf8 Class Initialized
INFO - 2021-06-12 07:18:34 --> URI Class Initialized
INFO - 2021-06-12 07:18:34 --> Router Class Initialized
INFO - 2021-06-12 07:18:34 --> Output Class Initialized
INFO - 2021-06-12 07:18:34 --> Security Class Initialized
DEBUG - 2021-06-12 07:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:18:34 --> Input Class Initialized
INFO - 2021-06-12 07:18:34 --> Language Class Initialized
INFO - 2021-06-12 07:18:34 --> Language Class Initialized
INFO - 2021-06-12 07:18:34 --> Config Class Initialized
INFO - 2021-06-12 07:18:34 --> Loader Class Initialized
INFO - 2021-06-12 07:18:34 --> Helper loaded: url_helper
INFO - 2021-06-12 07:18:34 --> Helper loaded: file_helper
INFO - 2021-06-12 07:18:34 --> Helper loaded: form_helper
INFO - 2021-06-12 07:18:34 --> Helper loaded: my_helper
INFO - 2021-06-12 07:18:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:18:34 --> Controller Class Initialized
INFO - 2021-06-12 07:18:49 --> Config Class Initialized
INFO - 2021-06-12 07:18:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:18:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:18:49 --> Utf8 Class Initialized
INFO - 2021-06-12 07:18:49 --> URI Class Initialized
INFO - 2021-06-12 07:18:49 --> Router Class Initialized
INFO - 2021-06-12 07:18:49 --> Output Class Initialized
INFO - 2021-06-12 07:18:49 --> Security Class Initialized
DEBUG - 2021-06-12 07:18:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:18:49 --> Input Class Initialized
INFO - 2021-06-12 07:18:49 --> Language Class Initialized
INFO - 2021-06-12 07:18:49 --> Language Class Initialized
INFO - 2021-06-12 07:18:49 --> Config Class Initialized
INFO - 2021-06-12 07:18:49 --> Loader Class Initialized
INFO - 2021-06-12 07:18:49 --> Helper loaded: url_helper
INFO - 2021-06-12 07:18:49 --> Helper loaded: file_helper
INFO - 2021-06-12 07:18:49 --> Helper loaded: form_helper
INFO - 2021-06-12 07:18:49 --> Helper loaded: my_helper
INFO - 2021-06-12 07:18:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:18:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:18:49 --> Controller Class Initialized
INFO - 2021-06-12 07:19:10 --> Config Class Initialized
INFO - 2021-06-12 07:19:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:10 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:10 --> URI Class Initialized
INFO - 2021-06-12 07:19:10 --> Router Class Initialized
INFO - 2021-06-12 07:19:10 --> Output Class Initialized
INFO - 2021-06-12 07:19:10 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:10 --> Input Class Initialized
INFO - 2021-06-12 07:19:10 --> Language Class Initialized
INFO - 2021-06-12 07:19:10 --> Language Class Initialized
INFO - 2021-06-12 07:19:10 --> Config Class Initialized
INFO - 2021-06-12 07:19:10 --> Loader Class Initialized
INFO - 2021-06-12 07:19:10 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:10 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:10 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:10 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:10 --> Controller Class Initialized
DEBUG - 2021-06-12 07:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:19:10 --> Final output sent to browser
DEBUG - 2021-06-12 07:19:10 --> Total execution time: 0.0453
INFO - 2021-06-12 07:19:10 --> Config Class Initialized
INFO - 2021-06-12 07:19:10 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:10 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:10 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:10 --> URI Class Initialized
INFO - 2021-06-12 07:19:10 --> Router Class Initialized
INFO - 2021-06-12 07:19:10 --> Output Class Initialized
INFO - 2021-06-12 07:19:10 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:10 --> Input Class Initialized
INFO - 2021-06-12 07:19:10 --> Language Class Initialized
INFO - 2021-06-12 07:19:10 --> Language Class Initialized
INFO - 2021-06-12 07:19:10 --> Config Class Initialized
INFO - 2021-06-12 07:19:10 --> Loader Class Initialized
INFO - 2021-06-12 07:19:10 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:10 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:10 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:10 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:10 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:10 --> Controller Class Initialized
INFO - 2021-06-12 07:19:12 --> Config Class Initialized
INFO - 2021-06-12 07:19:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:12 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:12 --> URI Class Initialized
INFO - 2021-06-12 07:19:12 --> Router Class Initialized
INFO - 2021-06-12 07:19:12 --> Output Class Initialized
INFO - 2021-06-12 07:19:12 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:12 --> Input Class Initialized
INFO - 2021-06-12 07:19:12 --> Language Class Initialized
INFO - 2021-06-12 07:19:12 --> Language Class Initialized
INFO - 2021-06-12 07:19:12 --> Config Class Initialized
INFO - 2021-06-12 07:19:12 --> Loader Class Initialized
INFO - 2021-06-12 07:19:12 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:12 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:12 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:12 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:12 --> Controller Class Initialized
DEBUG - 2021-06-12 07:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:19:12 --> Final output sent to browser
DEBUG - 2021-06-12 07:19:12 --> Total execution time: 0.0448
INFO - 2021-06-12 07:19:14 --> Config Class Initialized
INFO - 2021-06-12 07:19:14 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:14 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:14 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:14 --> URI Class Initialized
INFO - 2021-06-12 07:19:14 --> Router Class Initialized
INFO - 2021-06-12 07:19:14 --> Output Class Initialized
INFO - 2021-06-12 07:19:14 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:14 --> Input Class Initialized
INFO - 2021-06-12 07:19:14 --> Language Class Initialized
INFO - 2021-06-12 07:19:14 --> Language Class Initialized
INFO - 2021-06-12 07:19:14 --> Config Class Initialized
INFO - 2021-06-12 07:19:14 --> Loader Class Initialized
INFO - 2021-06-12 07:19:14 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:14 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:14 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:14 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:14 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:14 --> Controller Class Initialized
INFO - 2021-06-12 07:19:34 --> Config Class Initialized
INFO - 2021-06-12 07:19:34 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:34 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:34 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:34 --> URI Class Initialized
INFO - 2021-06-12 07:19:34 --> Router Class Initialized
INFO - 2021-06-12 07:19:34 --> Output Class Initialized
INFO - 2021-06-12 07:19:34 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:34 --> Input Class Initialized
INFO - 2021-06-12 07:19:34 --> Language Class Initialized
INFO - 2021-06-12 07:19:34 --> Language Class Initialized
INFO - 2021-06-12 07:19:34 --> Config Class Initialized
INFO - 2021-06-12 07:19:34 --> Loader Class Initialized
INFO - 2021-06-12 07:19:34 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:34 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:34 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:34 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:34 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:34 --> Controller Class Initialized
INFO - 2021-06-12 07:19:49 --> Config Class Initialized
INFO - 2021-06-12 07:19:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:49 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:49 --> URI Class Initialized
INFO - 2021-06-12 07:19:49 --> Router Class Initialized
INFO - 2021-06-12 07:19:49 --> Output Class Initialized
INFO - 2021-06-12 07:19:49 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:49 --> Input Class Initialized
INFO - 2021-06-12 07:19:49 --> Language Class Initialized
INFO - 2021-06-12 07:19:49 --> Language Class Initialized
INFO - 2021-06-12 07:19:49 --> Config Class Initialized
INFO - 2021-06-12 07:19:49 --> Loader Class Initialized
INFO - 2021-06-12 07:19:49 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:49 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:49 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:49 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:49 --> Controller Class Initialized
DEBUG - 2021-06-12 07:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:19:49 --> Final output sent to browser
DEBUG - 2021-06-12 07:19:49 --> Total execution time: 0.0450
INFO - 2021-06-12 07:19:49 --> Config Class Initialized
INFO - 2021-06-12 07:19:49 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:49 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:49 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:49 --> URI Class Initialized
INFO - 2021-06-12 07:19:49 --> Router Class Initialized
INFO - 2021-06-12 07:19:49 --> Output Class Initialized
INFO - 2021-06-12 07:19:49 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:49 --> Input Class Initialized
INFO - 2021-06-12 07:19:49 --> Language Class Initialized
INFO - 2021-06-12 07:19:49 --> Language Class Initialized
INFO - 2021-06-12 07:19:49 --> Config Class Initialized
INFO - 2021-06-12 07:19:49 --> Loader Class Initialized
INFO - 2021-06-12 07:19:49 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:49 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:49 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:49 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:49 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:49 --> Controller Class Initialized
INFO - 2021-06-12 07:19:50 --> Config Class Initialized
INFO - 2021-06-12 07:19:50 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:50 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:50 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:50 --> URI Class Initialized
INFO - 2021-06-12 07:19:50 --> Router Class Initialized
INFO - 2021-06-12 07:19:50 --> Output Class Initialized
INFO - 2021-06-12 07:19:50 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:50 --> Input Class Initialized
INFO - 2021-06-12 07:19:50 --> Language Class Initialized
INFO - 2021-06-12 07:19:50 --> Language Class Initialized
INFO - 2021-06-12 07:19:50 --> Config Class Initialized
INFO - 2021-06-12 07:19:50 --> Loader Class Initialized
INFO - 2021-06-12 07:19:50 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:50 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:50 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:50 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:50 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:50 --> Controller Class Initialized
DEBUG - 2021-06-12 07:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:19:50 --> Final output sent to browser
DEBUG - 2021-06-12 07:19:50 --> Total execution time: 0.0453
INFO - 2021-06-12 07:19:53 --> Config Class Initialized
INFO - 2021-06-12 07:19:53 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:19:53 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:19:53 --> Utf8 Class Initialized
INFO - 2021-06-12 07:19:53 --> URI Class Initialized
INFO - 2021-06-12 07:19:53 --> Router Class Initialized
INFO - 2021-06-12 07:19:53 --> Output Class Initialized
INFO - 2021-06-12 07:19:53 --> Security Class Initialized
DEBUG - 2021-06-12 07:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:19:53 --> Input Class Initialized
INFO - 2021-06-12 07:19:53 --> Language Class Initialized
INFO - 2021-06-12 07:19:53 --> Language Class Initialized
INFO - 2021-06-12 07:19:53 --> Config Class Initialized
INFO - 2021-06-12 07:19:53 --> Loader Class Initialized
INFO - 2021-06-12 07:19:53 --> Helper loaded: url_helper
INFO - 2021-06-12 07:19:53 --> Helper loaded: file_helper
INFO - 2021-06-12 07:19:53 --> Helper loaded: form_helper
INFO - 2021-06-12 07:19:53 --> Helper loaded: my_helper
INFO - 2021-06-12 07:19:53 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:19:53 --> Controller Class Initialized
INFO - 2021-06-12 07:20:06 --> Config Class Initialized
INFO - 2021-06-12 07:20:06 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:20:06 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:20:06 --> Utf8 Class Initialized
INFO - 2021-06-12 07:20:06 --> URI Class Initialized
INFO - 2021-06-12 07:20:06 --> Router Class Initialized
INFO - 2021-06-12 07:20:06 --> Output Class Initialized
INFO - 2021-06-12 07:20:06 --> Security Class Initialized
DEBUG - 2021-06-12 07:20:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:20:06 --> Input Class Initialized
INFO - 2021-06-12 07:20:06 --> Language Class Initialized
INFO - 2021-06-12 07:20:06 --> Language Class Initialized
INFO - 2021-06-12 07:20:06 --> Config Class Initialized
INFO - 2021-06-12 07:20:06 --> Loader Class Initialized
INFO - 2021-06-12 07:20:06 --> Helper loaded: url_helper
INFO - 2021-06-12 07:20:06 --> Helper loaded: file_helper
INFO - 2021-06-12 07:20:06 --> Helper loaded: form_helper
INFO - 2021-06-12 07:20:06 --> Helper loaded: my_helper
INFO - 2021-06-12 07:20:06 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:20:06 --> Controller Class Initialized
INFO - 2021-06-12 07:20:25 --> Config Class Initialized
INFO - 2021-06-12 07:20:25 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:20:25 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:20:25 --> Utf8 Class Initialized
INFO - 2021-06-12 07:20:25 --> URI Class Initialized
INFO - 2021-06-12 07:20:25 --> Router Class Initialized
INFO - 2021-06-12 07:20:25 --> Output Class Initialized
INFO - 2021-06-12 07:20:25 --> Security Class Initialized
DEBUG - 2021-06-12 07:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:20:26 --> Input Class Initialized
INFO - 2021-06-12 07:20:26 --> Language Class Initialized
INFO - 2021-06-12 07:20:26 --> Language Class Initialized
INFO - 2021-06-12 07:20:26 --> Config Class Initialized
INFO - 2021-06-12 07:20:26 --> Loader Class Initialized
INFO - 2021-06-12 07:20:26 --> Helper loaded: url_helper
INFO - 2021-06-12 07:20:26 --> Helper loaded: file_helper
INFO - 2021-06-12 07:20:26 --> Helper loaded: form_helper
INFO - 2021-06-12 07:20:26 --> Helper loaded: my_helper
INFO - 2021-06-12 07:20:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:20:26 --> Controller Class Initialized
DEBUG - 2021-06-12 07:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:20:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:20:26 --> Final output sent to browser
DEBUG - 2021-06-12 07:20:26 --> Total execution time: 0.0452
INFO - 2021-06-12 07:20:26 --> Config Class Initialized
INFO - 2021-06-12 07:20:26 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:20:26 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:20:26 --> Utf8 Class Initialized
INFO - 2021-06-12 07:20:26 --> URI Class Initialized
INFO - 2021-06-12 07:20:26 --> Router Class Initialized
INFO - 2021-06-12 07:20:26 --> Output Class Initialized
INFO - 2021-06-12 07:20:26 --> Security Class Initialized
DEBUG - 2021-06-12 07:20:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:20:26 --> Input Class Initialized
INFO - 2021-06-12 07:20:26 --> Language Class Initialized
INFO - 2021-06-12 07:20:26 --> Language Class Initialized
INFO - 2021-06-12 07:20:26 --> Config Class Initialized
INFO - 2021-06-12 07:20:26 --> Loader Class Initialized
INFO - 2021-06-12 07:20:26 --> Helper loaded: url_helper
INFO - 2021-06-12 07:20:26 --> Helper loaded: file_helper
INFO - 2021-06-12 07:20:26 --> Helper loaded: form_helper
INFO - 2021-06-12 07:20:26 --> Helper loaded: my_helper
INFO - 2021-06-12 07:20:26 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:20:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:20:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:20:26 --> Controller Class Initialized
INFO - 2021-06-12 07:20:29 --> Config Class Initialized
INFO - 2021-06-12 07:20:29 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:20:29 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:20:29 --> Utf8 Class Initialized
INFO - 2021-06-12 07:20:29 --> URI Class Initialized
INFO - 2021-06-12 07:20:29 --> Router Class Initialized
INFO - 2021-06-12 07:20:29 --> Output Class Initialized
INFO - 2021-06-12 07:20:29 --> Security Class Initialized
DEBUG - 2021-06-12 07:20:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:20:29 --> Input Class Initialized
INFO - 2021-06-12 07:20:29 --> Language Class Initialized
INFO - 2021-06-12 07:20:29 --> Language Class Initialized
INFO - 2021-06-12 07:20:29 --> Config Class Initialized
INFO - 2021-06-12 07:20:29 --> Loader Class Initialized
INFO - 2021-06-12 07:20:29 --> Helper loaded: url_helper
INFO - 2021-06-12 07:20:29 --> Helper loaded: file_helper
INFO - 2021-06-12 07:20:29 --> Helper loaded: form_helper
INFO - 2021-06-12 07:20:29 --> Helper loaded: my_helper
INFO - 2021-06-12 07:20:29 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:20:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:20:29 --> Controller Class Initialized
DEBUG - 2021-06-12 07:20:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:20:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:20:29 --> Final output sent to browser
DEBUG - 2021-06-12 07:20:29 --> Total execution time: 0.0442
INFO - 2021-06-12 07:20:38 --> Config Class Initialized
INFO - 2021-06-12 07:20:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:20:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:20:38 --> Utf8 Class Initialized
INFO - 2021-06-12 07:20:38 --> URI Class Initialized
INFO - 2021-06-12 07:20:38 --> Router Class Initialized
INFO - 2021-06-12 07:20:38 --> Output Class Initialized
INFO - 2021-06-12 07:20:38 --> Security Class Initialized
DEBUG - 2021-06-12 07:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:20:38 --> Input Class Initialized
INFO - 2021-06-12 07:20:38 --> Language Class Initialized
INFO - 2021-06-12 07:20:38 --> Language Class Initialized
INFO - 2021-06-12 07:20:38 --> Config Class Initialized
INFO - 2021-06-12 07:20:38 --> Loader Class Initialized
INFO - 2021-06-12 07:20:38 --> Helper loaded: url_helper
INFO - 2021-06-12 07:20:38 --> Helper loaded: file_helper
INFO - 2021-06-12 07:20:38 --> Helper loaded: form_helper
INFO - 2021-06-12 07:20:38 --> Helper loaded: my_helper
INFO - 2021-06-12 07:20:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:20:38 --> Controller Class Initialized
INFO - 2021-06-12 07:20:57 --> Config Class Initialized
INFO - 2021-06-12 07:20:57 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:20:57 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:20:57 --> Utf8 Class Initialized
INFO - 2021-06-12 07:20:57 --> URI Class Initialized
INFO - 2021-06-12 07:20:57 --> Router Class Initialized
INFO - 2021-06-12 07:20:57 --> Output Class Initialized
INFO - 2021-06-12 07:20:57 --> Security Class Initialized
DEBUG - 2021-06-12 07:20:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:20:57 --> Input Class Initialized
INFO - 2021-06-12 07:20:57 --> Language Class Initialized
INFO - 2021-06-12 07:20:57 --> Language Class Initialized
INFO - 2021-06-12 07:20:57 --> Config Class Initialized
INFO - 2021-06-12 07:20:57 --> Loader Class Initialized
INFO - 2021-06-12 07:20:57 --> Helper loaded: url_helper
INFO - 2021-06-12 07:20:57 --> Helper loaded: file_helper
INFO - 2021-06-12 07:20:57 --> Helper loaded: form_helper
INFO - 2021-06-12 07:20:57 --> Helper loaded: my_helper
INFO - 2021-06-12 07:20:57 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:20:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:20:57 --> Controller Class Initialized
INFO - 2021-06-12 07:21:11 --> Config Class Initialized
INFO - 2021-06-12 07:21:11 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:21:11 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:21:11 --> Utf8 Class Initialized
INFO - 2021-06-12 07:21:11 --> URI Class Initialized
INFO - 2021-06-12 07:21:11 --> Router Class Initialized
INFO - 2021-06-12 07:21:11 --> Output Class Initialized
INFO - 2021-06-12 07:21:11 --> Security Class Initialized
DEBUG - 2021-06-12 07:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:21:11 --> Input Class Initialized
INFO - 2021-06-12 07:21:11 --> Language Class Initialized
INFO - 2021-06-12 07:21:11 --> Language Class Initialized
INFO - 2021-06-12 07:21:11 --> Config Class Initialized
INFO - 2021-06-12 07:21:11 --> Loader Class Initialized
INFO - 2021-06-12 07:21:11 --> Helper loaded: url_helper
INFO - 2021-06-12 07:21:11 --> Helper loaded: file_helper
INFO - 2021-06-12 07:21:11 --> Helper loaded: form_helper
INFO - 2021-06-12 07:21:11 --> Helper loaded: my_helper
INFO - 2021-06-12 07:21:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:21:11 --> Controller Class Initialized
DEBUG - 2021-06-12 07:21:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-06-12 07:21:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:21:11 --> Final output sent to browser
DEBUG - 2021-06-12 07:21:11 --> Total execution time: 0.0456
INFO - 2021-06-12 07:21:11 --> Config Class Initialized
INFO - 2021-06-12 07:21:11 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:21:11 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:21:11 --> Utf8 Class Initialized
INFO - 2021-06-12 07:21:11 --> URI Class Initialized
INFO - 2021-06-12 07:21:11 --> Router Class Initialized
INFO - 2021-06-12 07:21:11 --> Output Class Initialized
INFO - 2021-06-12 07:21:11 --> Security Class Initialized
DEBUG - 2021-06-12 07:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:21:11 --> Input Class Initialized
INFO - 2021-06-12 07:21:11 --> Language Class Initialized
INFO - 2021-06-12 07:21:11 --> Language Class Initialized
INFO - 2021-06-12 07:21:11 --> Config Class Initialized
INFO - 2021-06-12 07:21:11 --> Loader Class Initialized
INFO - 2021-06-12 07:21:11 --> Helper loaded: url_helper
INFO - 2021-06-12 07:21:11 --> Helper loaded: file_helper
INFO - 2021-06-12 07:21:11 --> Helper loaded: form_helper
INFO - 2021-06-12 07:21:11 --> Helper loaded: my_helper
INFO - 2021-06-12 07:21:11 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:21:11 --> Controller Class Initialized
INFO - 2021-06-12 07:21:12 --> Config Class Initialized
INFO - 2021-06-12 07:21:12 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:21:12 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:21:12 --> Utf8 Class Initialized
INFO - 2021-06-12 07:21:12 --> URI Class Initialized
INFO - 2021-06-12 07:21:12 --> Router Class Initialized
INFO - 2021-06-12 07:21:12 --> Output Class Initialized
INFO - 2021-06-12 07:21:12 --> Security Class Initialized
DEBUG - 2021-06-12 07:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:21:12 --> Input Class Initialized
INFO - 2021-06-12 07:21:12 --> Language Class Initialized
INFO - 2021-06-12 07:21:12 --> Language Class Initialized
INFO - 2021-06-12 07:21:12 --> Config Class Initialized
INFO - 2021-06-12 07:21:12 --> Loader Class Initialized
INFO - 2021-06-12 07:21:12 --> Helper loaded: url_helper
INFO - 2021-06-12 07:21:12 --> Helper loaded: file_helper
INFO - 2021-06-12 07:21:12 --> Helper loaded: form_helper
INFO - 2021-06-12 07:21:12 --> Helper loaded: my_helper
INFO - 2021-06-12 07:21:12 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:21:12 --> Controller Class Initialized
DEBUG - 2021-06-12 07:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-06-12 07:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:21:12 --> Final output sent to browser
DEBUG - 2021-06-12 07:21:12 --> Total execution time: 0.0433
INFO - 2021-06-12 07:21:15 --> Config Class Initialized
INFO - 2021-06-12 07:21:15 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:21:15 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:21:15 --> Utf8 Class Initialized
INFO - 2021-06-12 07:21:15 --> URI Class Initialized
INFO - 2021-06-12 07:21:15 --> Router Class Initialized
INFO - 2021-06-12 07:21:15 --> Output Class Initialized
INFO - 2021-06-12 07:21:15 --> Security Class Initialized
DEBUG - 2021-06-12 07:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:21:15 --> Input Class Initialized
INFO - 2021-06-12 07:21:15 --> Language Class Initialized
INFO - 2021-06-12 07:21:15 --> Language Class Initialized
INFO - 2021-06-12 07:21:15 --> Config Class Initialized
INFO - 2021-06-12 07:21:15 --> Loader Class Initialized
INFO - 2021-06-12 07:21:15 --> Helper loaded: url_helper
INFO - 2021-06-12 07:21:15 --> Helper loaded: file_helper
INFO - 2021-06-12 07:21:15 --> Helper loaded: form_helper
INFO - 2021-06-12 07:21:15 --> Helper loaded: my_helper
INFO - 2021-06-12 07:21:15 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:21:15 --> Controller Class Initialized
INFO - 2021-06-12 07:21:38 --> Config Class Initialized
INFO - 2021-06-12 07:21:38 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:21:38 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:21:38 --> Utf8 Class Initialized
INFO - 2021-06-12 07:21:38 --> URI Class Initialized
INFO - 2021-06-12 07:21:38 --> Router Class Initialized
INFO - 2021-06-12 07:21:38 --> Output Class Initialized
INFO - 2021-06-12 07:21:38 --> Security Class Initialized
DEBUG - 2021-06-12 07:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:21:38 --> Input Class Initialized
INFO - 2021-06-12 07:21:38 --> Language Class Initialized
INFO - 2021-06-12 07:21:38 --> Language Class Initialized
INFO - 2021-06-12 07:21:38 --> Config Class Initialized
INFO - 2021-06-12 07:21:38 --> Loader Class Initialized
INFO - 2021-06-12 07:21:38 --> Helper loaded: url_helper
INFO - 2021-06-12 07:21:38 --> Helper loaded: file_helper
INFO - 2021-06-12 07:21:38 --> Helper loaded: form_helper
INFO - 2021-06-12 07:21:38 --> Helper loaded: my_helper
INFO - 2021-06-12 07:21:38 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:21:38 --> Controller Class Initialized
INFO - 2021-06-12 07:21:54 --> Config Class Initialized
INFO - 2021-06-12 07:21:54 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:21:54 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:21:54 --> Utf8 Class Initialized
INFO - 2021-06-12 07:21:54 --> URI Class Initialized
INFO - 2021-06-12 07:21:54 --> Router Class Initialized
INFO - 2021-06-12 07:21:54 --> Output Class Initialized
INFO - 2021-06-12 07:21:54 --> Security Class Initialized
DEBUG - 2021-06-12 07:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:21:54 --> Input Class Initialized
INFO - 2021-06-12 07:21:54 --> Language Class Initialized
INFO - 2021-06-12 07:21:54 --> Language Class Initialized
INFO - 2021-06-12 07:21:54 --> Config Class Initialized
INFO - 2021-06-12 07:21:54 --> Loader Class Initialized
INFO - 2021-06-12 07:21:54 --> Helper loaded: url_helper
INFO - 2021-06-12 07:21:54 --> Helper loaded: file_helper
INFO - 2021-06-12 07:21:54 --> Helper loaded: form_helper
INFO - 2021-06-12 07:21:54 --> Helper loaded: my_helper
INFO - 2021-06-12 07:21:54 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:21:54 --> Controller Class Initialized
INFO - 2021-06-12 07:21:54 --> Helper loaded: cookie_helper
INFO - 2021-06-12 07:21:54 --> Config Class Initialized
INFO - 2021-06-12 07:21:54 --> Hooks Class Initialized
DEBUG - 2021-06-12 07:21:54 --> UTF-8 Support Enabled
INFO - 2021-06-12 07:21:54 --> Utf8 Class Initialized
INFO - 2021-06-12 07:21:54 --> URI Class Initialized
INFO - 2021-06-12 07:21:54 --> Router Class Initialized
INFO - 2021-06-12 07:21:54 --> Output Class Initialized
INFO - 2021-06-12 07:21:54 --> Security Class Initialized
DEBUG - 2021-06-12 07:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-12 07:21:54 --> Input Class Initialized
INFO - 2021-06-12 07:21:54 --> Language Class Initialized
INFO - 2021-06-12 07:21:54 --> Language Class Initialized
INFO - 2021-06-12 07:21:54 --> Config Class Initialized
INFO - 2021-06-12 07:21:54 --> Loader Class Initialized
INFO - 2021-06-12 07:21:54 --> Helper loaded: url_helper
INFO - 2021-06-12 07:21:54 --> Helper loaded: file_helper
INFO - 2021-06-12 07:21:54 --> Helper loaded: form_helper
INFO - 2021-06-12 07:21:54 --> Helper loaded: my_helper
INFO - 2021-06-12 07:21:54 --> Database Driver Class Initialized
DEBUG - 2021-06-12 07:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-12 07:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-12 07:21:54 --> Controller Class Initialized
DEBUG - 2021-06-12 07:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-12 07:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-12 07:21:54 --> Final output sent to browser
DEBUG - 2021-06-12 07:21:54 --> Total execution time: 0.0506
