<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-12 03:18:11 --> Config Class Initialized
INFO - 2020-10-12 03:18:11 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:18:12 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:18:12 --> Utf8 Class Initialized
INFO - 2020-10-12 03:18:12 --> URI Class Initialized
DEBUG - 2020-10-12 03:18:12 --> No URI present. Default controller set.
INFO - 2020-10-12 03:18:12 --> Router Class Initialized
INFO - 2020-10-12 03:18:12 --> Output Class Initialized
INFO - 2020-10-12 03:18:12 --> Security Class Initialized
DEBUG - 2020-10-12 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:18:12 --> Input Class Initialized
INFO - 2020-10-12 03:18:12 --> Language Class Initialized
INFO - 2020-10-12 03:18:12 --> Language Class Initialized
INFO - 2020-10-12 03:18:12 --> Config Class Initialized
INFO - 2020-10-12 03:18:12 --> Loader Class Initialized
INFO - 2020-10-12 03:18:12 --> Helper loaded: url_helper
INFO - 2020-10-12 03:18:12 --> Helper loaded: file_helper
INFO - 2020-10-12 03:18:12 --> Helper loaded: form_helper
INFO - 2020-10-12 03:18:12 --> Helper loaded: my_helper
INFO - 2020-10-12 03:18:12 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:18:12 --> Controller Class Initialized
INFO - 2020-10-12 03:18:12 --> Config Class Initialized
INFO - 2020-10-12 03:18:12 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:18:12 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:18:12 --> Utf8 Class Initialized
INFO - 2020-10-12 03:18:12 --> URI Class Initialized
INFO - 2020-10-12 03:18:12 --> Router Class Initialized
INFO - 2020-10-12 03:18:12 --> Output Class Initialized
INFO - 2020-10-12 03:18:12 --> Security Class Initialized
DEBUG - 2020-10-12 03:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:18:12 --> Input Class Initialized
INFO - 2020-10-12 03:18:12 --> Language Class Initialized
INFO - 2020-10-12 03:18:12 --> Language Class Initialized
INFO - 2020-10-12 03:18:12 --> Config Class Initialized
INFO - 2020-10-12 03:18:12 --> Loader Class Initialized
INFO - 2020-10-12 03:18:12 --> Helper loaded: url_helper
INFO - 2020-10-12 03:18:12 --> Helper loaded: file_helper
INFO - 2020-10-12 03:18:12 --> Helper loaded: form_helper
INFO - 2020-10-12 03:18:12 --> Helper loaded: my_helper
INFO - 2020-10-12 03:18:12 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:18:12 --> Controller Class Initialized
DEBUG - 2020-10-12 03:18:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-12 03:18:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-12 03:18:12 --> Final output sent to browser
DEBUG - 2020-10-12 03:18:12 --> Total execution time: 0.2417
INFO - 2020-10-12 03:31:16 --> Config Class Initialized
INFO - 2020-10-12 03:31:16 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:31:16 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:31:16 --> Utf8 Class Initialized
INFO - 2020-10-12 03:31:16 --> URI Class Initialized
INFO - 2020-10-12 03:31:16 --> Router Class Initialized
INFO - 2020-10-12 03:31:16 --> Output Class Initialized
INFO - 2020-10-12 03:31:16 --> Security Class Initialized
DEBUG - 2020-10-12 03:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:31:16 --> Input Class Initialized
INFO - 2020-10-12 03:31:16 --> Language Class Initialized
INFO - 2020-10-12 03:31:16 --> Language Class Initialized
INFO - 2020-10-12 03:31:16 --> Config Class Initialized
INFO - 2020-10-12 03:31:16 --> Loader Class Initialized
INFO - 2020-10-12 03:31:16 --> Helper loaded: url_helper
INFO - 2020-10-12 03:31:16 --> Helper loaded: file_helper
INFO - 2020-10-12 03:31:16 --> Helper loaded: form_helper
INFO - 2020-10-12 03:31:16 --> Helper loaded: my_helper
INFO - 2020-10-12 03:31:16 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:31:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:31:17 --> Controller Class Initialized
INFO - 2020-10-12 03:31:17 --> Helper loaded: cookie_helper
INFO - 2020-10-12 03:31:17 --> Final output sent to browser
DEBUG - 2020-10-12 03:31:17 --> Total execution time: 0.3634
INFO - 2020-10-12 03:31:20 --> Config Class Initialized
INFO - 2020-10-12 03:31:20 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:31:20 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:31:20 --> Utf8 Class Initialized
INFO - 2020-10-12 03:31:20 --> URI Class Initialized
INFO - 2020-10-12 03:31:20 --> Router Class Initialized
INFO - 2020-10-12 03:31:20 --> Output Class Initialized
INFO - 2020-10-12 03:31:20 --> Security Class Initialized
DEBUG - 2020-10-12 03:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:31:20 --> Input Class Initialized
INFO - 2020-10-12 03:31:21 --> Language Class Initialized
INFO - 2020-10-12 03:31:21 --> Language Class Initialized
INFO - 2020-10-12 03:31:21 --> Config Class Initialized
INFO - 2020-10-12 03:31:21 --> Loader Class Initialized
INFO - 2020-10-12 03:31:21 --> Helper loaded: url_helper
INFO - 2020-10-12 03:31:21 --> Helper loaded: file_helper
INFO - 2020-10-12 03:31:21 --> Helper loaded: form_helper
INFO - 2020-10-12 03:31:21 --> Helper loaded: my_helper
INFO - 2020-10-12 03:31:21 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:31:21 --> Controller Class Initialized
DEBUG - 2020-10-12 03:31:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-12 03:31:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-12 03:31:21 --> Final output sent to browser
DEBUG - 2020-10-12 03:31:21 --> Total execution time: 0.4653
INFO - 2020-10-12 03:31:38 --> Config Class Initialized
INFO - 2020-10-12 03:31:38 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:31:38 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:31:38 --> Utf8 Class Initialized
INFO - 2020-10-12 03:31:38 --> URI Class Initialized
INFO - 2020-10-12 03:31:38 --> Router Class Initialized
INFO - 2020-10-12 03:31:38 --> Output Class Initialized
INFO - 2020-10-12 03:31:38 --> Security Class Initialized
DEBUG - 2020-10-12 03:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:31:38 --> Input Class Initialized
INFO - 2020-10-12 03:31:38 --> Language Class Initialized
INFO - 2020-10-12 03:31:38 --> Language Class Initialized
INFO - 2020-10-12 03:31:38 --> Config Class Initialized
INFO - 2020-10-12 03:31:38 --> Loader Class Initialized
INFO - 2020-10-12 03:31:38 --> Helper loaded: url_helper
INFO - 2020-10-12 03:31:38 --> Helper loaded: file_helper
INFO - 2020-10-12 03:31:38 --> Helper loaded: form_helper
INFO - 2020-10-12 03:31:38 --> Helper loaded: my_helper
INFO - 2020-10-12 03:31:38 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:31:38 --> Controller Class Initialized
DEBUG - 2020-10-12 03:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-12 03:31:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-12 03:31:39 --> Final output sent to browser
DEBUG - 2020-10-12 03:31:39 --> Total execution time: 0.2962
INFO - 2020-10-12 03:31:41 --> Config Class Initialized
INFO - 2020-10-12 03:31:41 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:31:41 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:31:41 --> Utf8 Class Initialized
INFO - 2020-10-12 03:31:41 --> URI Class Initialized
INFO - 2020-10-12 03:31:41 --> Router Class Initialized
INFO - 2020-10-12 03:31:41 --> Output Class Initialized
INFO - 2020-10-12 03:31:41 --> Security Class Initialized
DEBUG - 2020-10-12 03:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:31:41 --> Input Class Initialized
INFO - 2020-10-12 03:31:41 --> Language Class Initialized
INFO - 2020-10-12 03:31:41 --> Language Class Initialized
INFO - 2020-10-12 03:31:41 --> Config Class Initialized
INFO - 2020-10-12 03:31:41 --> Loader Class Initialized
INFO - 2020-10-12 03:31:42 --> Helper loaded: url_helper
INFO - 2020-10-12 03:31:42 --> Helper loaded: file_helper
INFO - 2020-10-12 03:31:42 --> Helper loaded: form_helper
INFO - 2020-10-12 03:31:42 --> Helper loaded: my_helper
INFO - 2020-10-12 03:31:42 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:31:42 --> Controller Class Initialized
DEBUG - 2020-10-12 03:31:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-10-12 03:31:42 --> Final output sent to browser
DEBUG - 2020-10-12 03:31:42 --> Total execution time: 0.3198
INFO - 2020-10-12 03:36:00 --> Config Class Initialized
INFO - 2020-10-12 03:36:00 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:36:00 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:36:00 --> Utf8 Class Initialized
INFO - 2020-10-12 03:36:00 --> URI Class Initialized
INFO - 2020-10-12 03:36:00 --> Router Class Initialized
INFO - 2020-10-12 03:36:00 --> Output Class Initialized
INFO - 2020-10-12 03:36:00 --> Security Class Initialized
DEBUG - 2020-10-12 03:36:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:36:00 --> Input Class Initialized
INFO - 2020-10-12 03:36:00 --> Language Class Initialized
INFO - 2020-10-12 03:36:00 --> Language Class Initialized
INFO - 2020-10-12 03:36:00 --> Config Class Initialized
INFO - 2020-10-12 03:36:00 --> Loader Class Initialized
INFO - 2020-10-12 03:36:00 --> Helper loaded: url_helper
INFO - 2020-10-12 03:36:00 --> Helper loaded: file_helper
INFO - 2020-10-12 03:36:00 --> Helper loaded: form_helper
INFO - 2020-10-12 03:36:00 --> Helper loaded: my_helper
INFO - 2020-10-12 03:36:00 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:36:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:36:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:36:00 --> Controller Class Initialized
DEBUG - 2020-10-12 03:36:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-10-12 03:36:00 --> Final output sent to browser
DEBUG - 2020-10-12 03:36:00 --> Total execution time: 0.3494
INFO - 2020-10-12 03:36:08 --> Config Class Initialized
INFO - 2020-10-12 03:36:08 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:36:08 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:36:08 --> Utf8 Class Initialized
INFO - 2020-10-12 03:36:08 --> URI Class Initialized
INFO - 2020-10-12 03:36:08 --> Router Class Initialized
INFO - 2020-10-12 03:36:08 --> Output Class Initialized
INFO - 2020-10-12 03:36:08 --> Security Class Initialized
DEBUG - 2020-10-12 03:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:36:08 --> Input Class Initialized
INFO - 2020-10-12 03:36:08 --> Language Class Initialized
INFO - 2020-10-12 03:36:08 --> Language Class Initialized
INFO - 2020-10-12 03:36:08 --> Config Class Initialized
INFO - 2020-10-12 03:36:08 --> Loader Class Initialized
INFO - 2020-10-12 03:36:08 --> Helper loaded: url_helper
INFO - 2020-10-12 03:36:08 --> Helper loaded: file_helper
INFO - 2020-10-12 03:36:08 --> Helper loaded: form_helper
INFO - 2020-10-12 03:36:08 --> Helper loaded: my_helper
INFO - 2020-10-12 03:36:08 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:36:08 --> Controller Class Initialized
DEBUG - 2020-10-12 03:36:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-10-12 03:36:08 --> Final output sent to browser
DEBUG - 2020-10-12 03:36:08 --> Total execution time: 0.3131
INFO - 2020-10-12 03:42:38 --> Config Class Initialized
INFO - 2020-10-12 03:42:38 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:42:38 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:42:38 --> Utf8 Class Initialized
INFO - 2020-10-12 03:42:38 --> URI Class Initialized
INFO - 2020-10-12 03:42:38 --> Router Class Initialized
INFO - 2020-10-12 03:42:38 --> Output Class Initialized
INFO - 2020-10-12 03:42:38 --> Security Class Initialized
DEBUG - 2020-10-12 03:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:42:38 --> Input Class Initialized
INFO - 2020-10-12 03:42:38 --> Language Class Initialized
INFO - 2020-10-12 03:42:38 --> Language Class Initialized
INFO - 2020-10-12 03:42:38 --> Config Class Initialized
INFO - 2020-10-12 03:42:38 --> Loader Class Initialized
INFO - 2020-10-12 03:42:39 --> Helper loaded: url_helper
INFO - 2020-10-12 03:42:39 --> Helper loaded: file_helper
INFO - 2020-10-12 03:42:39 --> Helper loaded: form_helper
INFO - 2020-10-12 03:42:39 --> Helper loaded: my_helper
INFO - 2020-10-12 03:42:39 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:42:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:42:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:42:39 --> Controller Class Initialized
DEBUG - 2020-10-12 03:42:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-10-12 03:42:39 --> Final output sent to browser
DEBUG - 2020-10-12 03:42:39 --> Total execution time: 0.4090
INFO - 2020-10-12 03:42:49 --> Config Class Initialized
INFO - 2020-10-12 03:42:49 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:42:49 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:42:49 --> Utf8 Class Initialized
INFO - 2020-10-12 03:42:49 --> URI Class Initialized
INFO - 2020-10-12 03:42:49 --> Router Class Initialized
INFO - 2020-10-12 03:42:49 --> Output Class Initialized
INFO - 2020-10-12 03:42:49 --> Security Class Initialized
DEBUG - 2020-10-12 03:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:42:49 --> Input Class Initialized
INFO - 2020-10-12 03:42:49 --> Language Class Initialized
INFO - 2020-10-12 03:42:49 --> Language Class Initialized
INFO - 2020-10-12 03:42:49 --> Config Class Initialized
INFO - 2020-10-12 03:42:49 --> Loader Class Initialized
INFO - 2020-10-12 03:42:49 --> Helper loaded: url_helper
INFO - 2020-10-12 03:42:49 --> Helper loaded: file_helper
INFO - 2020-10-12 03:42:49 --> Helper loaded: form_helper
INFO - 2020-10-12 03:42:49 --> Helper loaded: my_helper
INFO - 2020-10-12 03:42:49 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:42:49 --> Controller Class Initialized
DEBUG - 2020-10-12 03:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_prestasi.php
INFO - 2020-10-12 03:42:49 --> Final output sent to browser
DEBUG - 2020-10-12 03:42:49 --> Total execution time: 0.3825
INFO - 2020-10-12 03:59:51 --> Config Class Initialized
INFO - 2020-10-12 03:59:51 --> Hooks Class Initialized
DEBUG - 2020-10-12 03:59:51 --> UTF-8 Support Enabled
INFO - 2020-10-12 03:59:51 --> Utf8 Class Initialized
INFO - 2020-10-12 03:59:51 --> URI Class Initialized
INFO - 2020-10-12 03:59:51 --> Router Class Initialized
INFO - 2020-10-12 03:59:51 --> Output Class Initialized
INFO - 2020-10-12 03:59:51 --> Security Class Initialized
DEBUG - 2020-10-12 03:59:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 03:59:51 --> Input Class Initialized
INFO - 2020-10-12 03:59:51 --> Language Class Initialized
INFO - 2020-10-12 03:59:51 --> Language Class Initialized
INFO - 2020-10-12 03:59:51 --> Config Class Initialized
INFO - 2020-10-12 03:59:51 --> Loader Class Initialized
INFO - 2020-10-12 03:59:51 --> Helper loaded: url_helper
INFO - 2020-10-12 03:59:51 --> Helper loaded: file_helper
INFO - 2020-10-12 03:59:51 --> Helper loaded: form_helper
INFO - 2020-10-12 03:59:51 --> Helper loaded: my_helper
INFO - 2020-10-12 03:59:51 --> Database Driver Class Initialized
DEBUG - 2020-10-12 03:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 03:59:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 03:59:51 --> Controller Class Initialized
DEBUG - 2020-10-12 03:59:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-10-12 03:59:51 --> Final output sent to browser
DEBUG - 2020-10-12 03:59:51 --> Total execution time: 0.2147
INFO - 2020-10-12 04:00:05 --> Config Class Initialized
INFO - 2020-10-12 04:00:05 --> Hooks Class Initialized
DEBUG - 2020-10-12 04:00:05 --> UTF-8 Support Enabled
INFO - 2020-10-12 04:00:05 --> Utf8 Class Initialized
INFO - 2020-10-12 04:00:05 --> URI Class Initialized
INFO - 2020-10-12 04:00:05 --> Router Class Initialized
INFO - 2020-10-12 04:00:05 --> Output Class Initialized
INFO - 2020-10-12 04:00:05 --> Security Class Initialized
DEBUG - 2020-10-12 04:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 04:00:05 --> Input Class Initialized
INFO - 2020-10-12 04:00:05 --> Language Class Initialized
INFO - 2020-10-12 04:00:05 --> Language Class Initialized
INFO - 2020-10-12 04:00:05 --> Config Class Initialized
INFO - 2020-10-12 04:00:05 --> Loader Class Initialized
INFO - 2020-10-12 04:00:05 --> Helper loaded: url_helper
INFO - 2020-10-12 04:00:05 --> Helper loaded: file_helper
INFO - 2020-10-12 04:00:05 --> Helper loaded: form_helper
INFO - 2020-10-12 04:00:05 --> Helper loaded: my_helper
INFO - 2020-10-12 04:00:05 --> Database Driver Class Initialized
DEBUG - 2020-10-12 04:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 04:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 04:00:05 --> Controller Class Initialized
DEBUG - 2020-10-12 04:00:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-10-12 04:00:05 --> Final output sent to browser
DEBUG - 2020-10-12 04:00:05 --> Total execution time: 0.2471
INFO - 2020-10-12 04:01:11 --> Config Class Initialized
INFO - 2020-10-12 04:01:11 --> Hooks Class Initialized
DEBUG - 2020-10-12 04:01:11 --> UTF-8 Support Enabled
INFO - 2020-10-12 04:01:11 --> Utf8 Class Initialized
INFO - 2020-10-12 04:01:11 --> URI Class Initialized
INFO - 2020-10-12 04:01:11 --> Router Class Initialized
INFO - 2020-10-12 04:01:11 --> Output Class Initialized
INFO - 2020-10-12 04:01:11 --> Security Class Initialized
DEBUG - 2020-10-12 04:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 04:01:11 --> Input Class Initialized
INFO - 2020-10-12 04:01:11 --> Language Class Initialized
INFO - 2020-10-12 04:01:11 --> Language Class Initialized
INFO - 2020-10-12 04:01:11 --> Config Class Initialized
INFO - 2020-10-12 04:01:11 --> Loader Class Initialized
INFO - 2020-10-12 04:01:11 --> Helper loaded: url_helper
INFO - 2020-10-12 04:01:11 --> Helper loaded: file_helper
INFO - 2020-10-12 04:01:11 --> Helper loaded: form_helper
INFO - 2020-10-12 04:01:11 --> Helper loaded: my_helper
INFO - 2020-10-12 04:01:11 --> Database Driver Class Initialized
DEBUG - 2020-10-12 04:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 04:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 04:01:11 --> Controller Class Initialized
DEBUG - 2020-10-12 04:01:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-10-12 04:01:11 --> Final output sent to browser
DEBUG - 2020-10-12 04:01:11 --> Total execution time: 0.2254
INFO - 2020-10-12 04:29:54 --> Config Class Initialized
INFO - 2020-10-12 04:29:54 --> Hooks Class Initialized
DEBUG - 2020-10-12 04:29:54 --> UTF-8 Support Enabled
INFO - 2020-10-12 04:29:54 --> Utf8 Class Initialized
INFO - 2020-10-12 04:29:54 --> URI Class Initialized
INFO - 2020-10-12 04:29:54 --> Router Class Initialized
INFO - 2020-10-12 04:29:54 --> Output Class Initialized
INFO - 2020-10-12 04:29:54 --> Security Class Initialized
DEBUG - 2020-10-12 04:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 04:29:54 --> Input Class Initialized
INFO - 2020-10-12 04:29:54 --> Language Class Initialized
INFO - 2020-10-12 04:29:54 --> Language Class Initialized
INFO - 2020-10-12 04:29:54 --> Config Class Initialized
INFO - 2020-10-12 04:29:54 --> Loader Class Initialized
INFO - 2020-10-12 04:29:54 --> Helper loaded: url_helper
INFO - 2020-10-12 04:29:54 --> Helper loaded: file_helper
INFO - 2020-10-12 04:29:54 --> Helper loaded: form_helper
INFO - 2020-10-12 04:29:54 --> Helper loaded: my_helper
INFO - 2020-10-12 04:29:54 --> Database Driver Class Initialized
DEBUG - 2020-10-12 04:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 04:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 04:29:54 --> Controller Class Initialized
DEBUG - 2020-10-12 04:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul2.php
INFO - 2020-10-12 04:29:54 --> Final output sent to browser
DEBUG - 2020-10-12 04:29:54 --> Total execution time: 0.2351
INFO - 2020-10-12 04:32:05 --> Config Class Initialized
INFO - 2020-10-12 04:32:05 --> Hooks Class Initialized
DEBUG - 2020-10-12 04:32:05 --> UTF-8 Support Enabled
INFO - 2020-10-12 04:32:05 --> Utf8 Class Initialized
INFO - 2020-10-12 04:32:05 --> URI Class Initialized
INFO - 2020-10-12 04:32:05 --> Router Class Initialized
INFO - 2020-10-12 04:32:05 --> Output Class Initialized
INFO - 2020-10-12 04:32:05 --> Security Class Initialized
DEBUG - 2020-10-12 04:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 04:32:05 --> Input Class Initialized
INFO - 2020-10-12 04:32:05 --> Language Class Initialized
INFO - 2020-10-12 04:32:05 --> Language Class Initialized
INFO - 2020-10-12 04:32:05 --> Config Class Initialized
INFO - 2020-10-12 04:32:05 --> Loader Class Initialized
INFO - 2020-10-12 04:32:05 --> Helper loaded: url_helper
INFO - 2020-10-12 04:32:05 --> Helper loaded: file_helper
INFO - 2020-10-12 04:32:05 --> Helper loaded: form_helper
INFO - 2020-10-12 04:32:05 --> Helper loaded: my_helper
INFO - 2020-10-12 04:32:05 --> Database Driver Class Initialized
DEBUG - 2020-10-12 04:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 04:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 04:32:05 --> Controller Class Initialized
DEBUG - 2020-10-12 04:32:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-10-12 04:32:05 --> Final output sent to browser
DEBUG - 2020-10-12 04:32:05 --> Total execution time: 0.2264
INFO - 2020-10-12 04:55:09 --> Config Class Initialized
INFO - 2020-10-12 04:55:09 --> Hooks Class Initialized
DEBUG - 2020-10-12 04:55:09 --> UTF-8 Support Enabled
INFO - 2020-10-12 04:55:09 --> Utf8 Class Initialized
INFO - 2020-10-12 04:55:09 --> URI Class Initialized
INFO - 2020-10-12 04:55:09 --> Router Class Initialized
INFO - 2020-10-12 04:55:09 --> Output Class Initialized
INFO - 2020-10-12 04:55:09 --> Security Class Initialized
DEBUG - 2020-10-12 04:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-12 04:55:09 --> Input Class Initialized
INFO - 2020-10-12 04:55:09 --> Language Class Initialized
INFO - 2020-10-12 04:55:09 --> Language Class Initialized
INFO - 2020-10-12 04:55:09 --> Config Class Initialized
INFO - 2020-10-12 04:55:09 --> Loader Class Initialized
INFO - 2020-10-12 04:55:09 --> Helper loaded: url_helper
INFO - 2020-10-12 04:55:09 --> Helper loaded: file_helper
INFO - 2020-10-12 04:55:09 --> Helper loaded: form_helper
INFO - 2020-10-12 04:55:09 --> Helper loaded: my_helper
INFO - 2020-10-12 04:55:09 --> Database Driver Class Initialized
DEBUG - 2020-10-12 04:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-12 04:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-12 04:55:09 --> Controller Class Initialized
DEBUG - 2020-10-12 04:55:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul4.php
INFO - 2020-10-12 04:55:09 --> Final output sent to browser
DEBUG - 2020-10-12 04:55:09 --> Total execution time: 0.2391
