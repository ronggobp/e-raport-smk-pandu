<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-24 08:58:29 --> Config Class Initialized
INFO - 2020-10-24 08:58:29 --> Hooks Class Initialized
DEBUG - 2020-10-24 08:58:30 --> UTF-8 Support Enabled
INFO - 2020-10-24 08:58:30 --> Utf8 Class Initialized
INFO - 2020-10-24 08:58:30 --> URI Class Initialized
DEBUG - 2020-10-24 08:58:30 --> No URI present. Default controller set.
INFO - 2020-10-24 08:58:30 --> Router Class Initialized
INFO - 2020-10-24 08:58:30 --> Output Class Initialized
INFO - 2020-10-24 08:58:30 --> Security Class Initialized
DEBUG - 2020-10-24 08:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 08:58:30 --> Input Class Initialized
INFO - 2020-10-24 08:58:30 --> Language Class Initialized
INFO - 2020-10-24 08:58:30 --> Language Class Initialized
INFO - 2020-10-24 08:58:30 --> Config Class Initialized
INFO - 2020-10-24 08:58:30 --> Loader Class Initialized
INFO - 2020-10-24 08:58:30 --> Helper loaded: url_helper
INFO - 2020-10-24 08:58:30 --> Helper loaded: file_helper
INFO - 2020-10-24 08:58:30 --> Helper loaded: form_helper
INFO - 2020-10-24 08:58:30 --> Helper loaded: my_helper
INFO - 2020-10-24 08:58:30 --> Database Driver Class Initialized
DEBUG - 2020-10-24 08:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-24 08:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 08:58:30 --> Controller Class Initialized
INFO - 2020-10-24 08:58:30 --> Config Class Initialized
INFO - 2020-10-24 08:58:30 --> Hooks Class Initialized
DEBUG - 2020-10-24 08:58:30 --> UTF-8 Support Enabled
INFO - 2020-10-24 08:58:30 --> Utf8 Class Initialized
INFO - 2020-10-24 08:58:30 --> URI Class Initialized
INFO - 2020-10-24 08:58:30 --> Router Class Initialized
INFO - 2020-10-24 08:58:30 --> Output Class Initialized
INFO - 2020-10-24 08:58:30 --> Security Class Initialized
DEBUG - 2020-10-24 08:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-24 08:58:30 --> Input Class Initialized
INFO - 2020-10-24 08:58:30 --> Language Class Initialized
INFO - 2020-10-24 08:58:30 --> Language Class Initialized
INFO - 2020-10-24 08:58:30 --> Config Class Initialized
INFO - 2020-10-24 08:58:30 --> Loader Class Initialized
INFO - 2020-10-24 08:58:30 --> Helper loaded: url_helper
INFO - 2020-10-24 08:58:30 --> Helper loaded: file_helper
INFO - 2020-10-24 08:58:30 --> Helper loaded: form_helper
INFO - 2020-10-24 08:58:30 --> Helper loaded: my_helper
INFO - 2020-10-24 08:58:30 --> Database Driver Class Initialized
DEBUG - 2020-10-24 08:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-24 08:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-24 08:58:30 --> Controller Class Initialized
DEBUG - 2020-10-24 08:58:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-24 08:58:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-24 08:58:30 --> Final output sent to browser
DEBUG - 2020-10-24 08:58:30 --> Total execution time: 0.2460
