<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-28 04:49:58 --> Config Class Initialized
INFO - 2021-07-28 04:49:58 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:49:58 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:49:58 --> Utf8 Class Initialized
INFO - 2021-07-28 04:49:58 --> URI Class Initialized
INFO - 2021-07-28 04:49:59 --> Router Class Initialized
INFO - 2021-07-28 04:49:59 --> Output Class Initialized
INFO - 2021-07-28 04:49:59 --> Security Class Initialized
DEBUG - 2021-07-28 04:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:49:59 --> Input Class Initialized
INFO - 2021-07-28 04:49:59 --> Language Class Initialized
INFO - 2021-07-28 04:49:59 --> Language Class Initialized
INFO - 2021-07-28 04:49:59 --> Config Class Initialized
INFO - 2021-07-28 04:49:59 --> Loader Class Initialized
INFO - 2021-07-28 04:49:59 --> Helper loaded: url_helper
INFO - 2021-07-28 04:49:59 --> Helper loaded: file_helper
INFO - 2021-07-28 04:49:59 --> Helper loaded: form_helper
INFO - 2021-07-28 04:49:59 --> Helper loaded: my_helper
INFO - 2021-07-28 04:49:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:49:59 --> Controller Class Initialized
DEBUG - 2021-07-28 04:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 04:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:49:59 --> Final output sent to browser
DEBUG - 2021-07-28 04:49:59 --> Total execution time: 0.7334
INFO - 2021-07-28 04:50:13 --> Config Class Initialized
INFO - 2021-07-28 04:50:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:50:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:50:13 --> Utf8 Class Initialized
INFO - 2021-07-28 04:50:13 --> URI Class Initialized
INFO - 2021-07-28 04:50:13 --> Router Class Initialized
INFO - 2021-07-28 04:50:13 --> Output Class Initialized
INFO - 2021-07-28 04:50:13 --> Security Class Initialized
DEBUG - 2021-07-28 04:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:50:13 --> Input Class Initialized
INFO - 2021-07-28 04:50:13 --> Language Class Initialized
INFO - 2021-07-28 04:50:13 --> Language Class Initialized
INFO - 2021-07-28 04:50:13 --> Config Class Initialized
INFO - 2021-07-28 04:50:13 --> Loader Class Initialized
INFO - 2021-07-28 04:50:13 --> Helper loaded: url_helper
INFO - 2021-07-28 04:50:13 --> Helper loaded: file_helper
INFO - 2021-07-28 04:50:13 --> Helper loaded: form_helper
INFO - 2021-07-28 04:50:13 --> Helper loaded: my_helper
INFO - 2021-07-28 04:50:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:50:13 --> Controller Class Initialized
INFO - 2021-07-28 04:50:13 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:50:13 --> Final output sent to browser
DEBUG - 2021-07-28 04:50:13 --> Total execution time: 0.0916
INFO - 2021-07-28 04:50:14 --> Config Class Initialized
INFO - 2021-07-28 04:50:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:50:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:50:14 --> Utf8 Class Initialized
INFO - 2021-07-28 04:50:14 --> URI Class Initialized
INFO - 2021-07-28 04:50:14 --> Router Class Initialized
INFO - 2021-07-28 04:50:14 --> Output Class Initialized
INFO - 2021-07-28 04:50:14 --> Security Class Initialized
DEBUG - 2021-07-28 04:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:50:14 --> Input Class Initialized
INFO - 2021-07-28 04:50:14 --> Language Class Initialized
INFO - 2021-07-28 04:50:14 --> Language Class Initialized
INFO - 2021-07-28 04:50:14 --> Config Class Initialized
INFO - 2021-07-28 04:50:14 --> Loader Class Initialized
INFO - 2021-07-28 04:50:14 --> Helper loaded: url_helper
INFO - 2021-07-28 04:50:14 --> Helper loaded: file_helper
INFO - 2021-07-28 04:50:14 --> Helper loaded: form_helper
INFO - 2021-07-28 04:50:14 --> Helper loaded: my_helper
INFO - 2021-07-28 04:50:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:50:14 --> Controller Class Initialized
DEBUG - 2021-07-28 04:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 04:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:50:15 --> Final output sent to browser
DEBUG - 2021-07-28 04:50:15 --> Total execution time: 0.7820
INFO - 2021-07-28 04:51:38 --> Config Class Initialized
INFO - 2021-07-28 04:51:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:51:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:51:38 --> Utf8 Class Initialized
INFO - 2021-07-28 04:51:38 --> URI Class Initialized
INFO - 2021-07-28 04:51:38 --> Router Class Initialized
INFO - 2021-07-28 04:51:38 --> Output Class Initialized
INFO - 2021-07-28 04:51:38 --> Security Class Initialized
DEBUG - 2021-07-28 04:51:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:51:38 --> Input Class Initialized
INFO - 2021-07-28 04:51:38 --> Language Class Initialized
INFO - 2021-07-28 04:51:38 --> Language Class Initialized
INFO - 2021-07-28 04:51:38 --> Config Class Initialized
INFO - 2021-07-28 04:51:38 --> Loader Class Initialized
INFO - 2021-07-28 04:51:38 --> Helper loaded: url_helper
INFO - 2021-07-28 04:51:38 --> Helper loaded: file_helper
INFO - 2021-07-28 04:51:38 --> Helper loaded: form_helper
INFO - 2021-07-28 04:51:38 --> Helper loaded: my_helper
INFO - 2021-07-28 04:51:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:51:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:51:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:51:38 --> Controller Class Initialized
DEBUG - 2021-07-28 04:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-28 04:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:51:38 --> Final output sent to browser
DEBUG - 2021-07-28 04:51:38 --> Total execution time: 0.1448
INFO - 2021-07-28 04:51:56 --> Config Class Initialized
INFO - 2021-07-28 04:51:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:51:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:51:56 --> Utf8 Class Initialized
INFO - 2021-07-28 04:51:56 --> URI Class Initialized
INFO - 2021-07-28 04:51:56 --> Router Class Initialized
INFO - 2021-07-28 04:51:56 --> Output Class Initialized
INFO - 2021-07-28 04:51:56 --> Security Class Initialized
DEBUG - 2021-07-28 04:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:51:56 --> Input Class Initialized
INFO - 2021-07-28 04:51:56 --> Language Class Initialized
INFO - 2021-07-28 04:51:56 --> Language Class Initialized
INFO - 2021-07-28 04:51:56 --> Config Class Initialized
INFO - 2021-07-28 04:51:56 --> Loader Class Initialized
INFO - 2021-07-28 04:51:56 --> Helper loaded: url_helper
INFO - 2021-07-28 04:51:56 --> Helper loaded: file_helper
INFO - 2021-07-28 04:51:56 --> Helper loaded: form_helper
INFO - 2021-07-28 04:51:56 --> Helper loaded: my_helper
INFO - 2021-07-28 04:51:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:51:56 --> Controller Class Initialized
INFO - 2021-07-28 04:51:56 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:51:56 --> Config Class Initialized
INFO - 2021-07-28 04:51:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:51:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:51:56 --> Utf8 Class Initialized
INFO - 2021-07-28 04:51:56 --> URI Class Initialized
INFO - 2021-07-28 04:51:56 --> Router Class Initialized
INFO - 2021-07-28 04:51:56 --> Output Class Initialized
INFO - 2021-07-28 04:51:56 --> Security Class Initialized
DEBUG - 2021-07-28 04:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:51:56 --> Input Class Initialized
INFO - 2021-07-28 04:51:56 --> Language Class Initialized
INFO - 2021-07-28 04:51:56 --> Language Class Initialized
INFO - 2021-07-28 04:51:56 --> Config Class Initialized
INFO - 2021-07-28 04:51:56 --> Loader Class Initialized
INFO - 2021-07-28 04:51:56 --> Helper loaded: url_helper
INFO - 2021-07-28 04:51:56 --> Helper loaded: file_helper
INFO - 2021-07-28 04:51:56 --> Helper loaded: form_helper
INFO - 2021-07-28 04:51:56 --> Helper loaded: my_helper
INFO - 2021-07-28 04:51:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:51:56 --> Controller Class Initialized
DEBUG - 2021-07-28 04:51:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 04:51:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:51:56 --> Final output sent to browser
DEBUG - 2021-07-28 04:51:56 --> Total execution time: 0.0544
INFO - 2021-07-28 04:52:06 --> Config Class Initialized
INFO - 2021-07-28 04:52:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:52:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:52:06 --> Utf8 Class Initialized
INFO - 2021-07-28 04:52:06 --> URI Class Initialized
INFO - 2021-07-28 04:52:06 --> Router Class Initialized
INFO - 2021-07-28 04:52:06 --> Output Class Initialized
INFO - 2021-07-28 04:52:06 --> Security Class Initialized
DEBUG - 2021-07-28 04:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:52:06 --> Input Class Initialized
INFO - 2021-07-28 04:52:06 --> Language Class Initialized
INFO - 2021-07-28 04:52:06 --> Language Class Initialized
INFO - 2021-07-28 04:52:06 --> Config Class Initialized
INFO - 2021-07-28 04:52:06 --> Loader Class Initialized
INFO - 2021-07-28 04:52:06 --> Helper loaded: url_helper
INFO - 2021-07-28 04:52:06 --> Helper loaded: file_helper
INFO - 2021-07-28 04:52:06 --> Helper loaded: form_helper
INFO - 2021-07-28 04:52:06 --> Helper loaded: my_helper
INFO - 2021-07-28 04:52:06 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:52:06 --> Controller Class Initialized
INFO - 2021-07-28 04:52:06 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:52:06 --> Final output sent to browser
DEBUG - 2021-07-28 04:52:06 --> Total execution time: 0.0565
INFO - 2021-07-28 04:52:06 --> Config Class Initialized
INFO - 2021-07-28 04:52:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:52:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:52:06 --> Utf8 Class Initialized
INFO - 2021-07-28 04:52:06 --> URI Class Initialized
INFO - 2021-07-28 04:52:06 --> Router Class Initialized
INFO - 2021-07-28 04:52:06 --> Output Class Initialized
INFO - 2021-07-28 04:52:06 --> Security Class Initialized
DEBUG - 2021-07-28 04:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:52:06 --> Input Class Initialized
INFO - 2021-07-28 04:52:06 --> Language Class Initialized
INFO - 2021-07-28 04:52:06 --> Language Class Initialized
INFO - 2021-07-28 04:52:06 --> Config Class Initialized
INFO - 2021-07-28 04:52:06 --> Loader Class Initialized
INFO - 2021-07-28 04:52:06 --> Helper loaded: url_helper
INFO - 2021-07-28 04:52:06 --> Helper loaded: file_helper
INFO - 2021-07-28 04:52:06 --> Helper loaded: form_helper
INFO - 2021-07-28 04:52:06 --> Helper loaded: my_helper
INFO - 2021-07-28 04:52:06 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:52:06 --> Controller Class Initialized
DEBUG - 2021-07-28 04:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 04:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:52:06 --> Final output sent to browser
DEBUG - 2021-07-28 04:52:06 --> Total execution time: 0.6143
INFO - 2021-07-28 04:52:09 --> Config Class Initialized
INFO - 2021-07-28 04:52:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:52:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:52:09 --> Utf8 Class Initialized
INFO - 2021-07-28 04:52:09 --> URI Class Initialized
INFO - 2021-07-28 04:52:09 --> Router Class Initialized
INFO - 2021-07-28 04:52:09 --> Output Class Initialized
INFO - 2021-07-28 04:52:09 --> Security Class Initialized
DEBUG - 2021-07-28 04:52:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:52:09 --> Input Class Initialized
INFO - 2021-07-28 04:52:09 --> Language Class Initialized
INFO - 2021-07-28 04:52:09 --> Language Class Initialized
INFO - 2021-07-28 04:52:09 --> Config Class Initialized
INFO - 2021-07-28 04:52:09 --> Loader Class Initialized
INFO - 2021-07-28 04:52:09 --> Helper loaded: url_helper
INFO - 2021-07-28 04:52:09 --> Helper loaded: file_helper
INFO - 2021-07-28 04:52:09 --> Helper loaded: form_helper
INFO - 2021-07-28 04:52:09 --> Helper loaded: my_helper
INFO - 2021-07-28 04:52:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:52:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:52:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:52:09 --> Controller Class Initialized
DEBUG - 2021-07-28 04:52:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-28 04:52:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:52:09 --> Final output sent to browser
DEBUG - 2021-07-28 04:52:09 --> Total execution time: 0.0716
INFO - 2021-07-28 04:52:15 --> Config Class Initialized
INFO - 2021-07-28 04:52:15 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:52:15 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:52:15 --> Utf8 Class Initialized
INFO - 2021-07-28 04:52:15 --> URI Class Initialized
INFO - 2021-07-28 04:52:16 --> Router Class Initialized
INFO - 2021-07-28 04:52:16 --> Output Class Initialized
INFO - 2021-07-28 04:52:16 --> Security Class Initialized
DEBUG - 2021-07-28 04:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:52:16 --> Input Class Initialized
INFO - 2021-07-28 04:52:16 --> Language Class Initialized
INFO - 2021-07-28 04:52:16 --> Language Class Initialized
INFO - 2021-07-28 04:52:16 --> Config Class Initialized
INFO - 2021-07-28 04:52:16 --> Loader Class Initialized
INFO - 2021-07-28 04:52:16 --> Helper loaded: url_helper
INFO - 2021-07-28 04:52:16 --> Helper loaded: file_helper
INFO - 2021-07-28 04:52:16 --> Helper loaded: form_helper
INFO - 2021-07-28 04:52:16 --> Helper loaded: my_helper
INFO - 2021-07-28 04:52:16 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:52:16 --> Controller Class Initialized
DEBUG - 2021-07-28 04:52:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-28 04:52:16 --> Final output sent to browser
DEBUG - 2021-07-28 04:52:16 --> Total execution time: 0.2887
INFO - 2021-07-28 04:54:36 --> Config Class Initialized
INFO - 2021-07-28 04:54:36 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:54:36 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:54:36 --> Utf8 Class Initialized
INFO - 2021-07-28 04:54:36 --> URI Class Initialized
INFO - 2021-07-28 04:54:36 --> Router Class Initialized
INFO - 2021-07-28 04:54:36 --> Output Class Initialized
INFO - 2021-07-28 04:54:36 --> Security Class Initialized
DEBUG - 2021-07-28 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:54:36 --> Input Class Initialized
INFO - 2021-07-28 04:54:36 --> Language Class Initialized
INFO - 2021-07-28 04:54:36 --> Language Class Initialized
INFO - 2021-07-28 04:54:36 --> Config Class Initialized
INFO - 2021-07-28 04:54:36 --> Loader Class Initialized
INFO - 2021-07-28 04:54:36 --> Helper loaded: url_helper
INFO - 2021-07-28 04:54:36 --> Helper loaded: file_helper
INFO - 2021-07-28 04:54:36 --> Helper loaded: form_helper
INFO - 2021-07-28 04:54:36 --> Helper loaded: my_helper
INFO - 2021-07-28 04:54:36 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:54:36 --> Controller Class Initialized
INFO - 2021-07-28 04:54:36 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:54:36 --> Config Class Initialized
INFO - 2021-07-28 04:54:36 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:54:36 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:54:36 --> Utf8 Class Initialized
INFO - 2021-07-28 04:54:36 --> URI Class Initialized
INFO - 2021-07-28 04:54:36 --> Router Class Initialized
INFO - 2021-07-28 04:54:36 --> Output Class Initialized
INFO - 2021-07-28 04:54:36 --> Security Class Initialized
DEBUG - 2021-07-28 04:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:54:36 --> Input Class Initialized
INFO - 2021-07-28 04:54:36 --> Language Class Initialized
INFO - 2021-07-28 04:54:36 --> Language Class Initialized
INFO - 2021-07-28 04:54:36 --> Config Class Initialized
INFO - 2021-07-28 04:54:36 --> Loader Class Initialized
INFO - 2021-07-28 04:54:36 --> Helper loaded: url_helper
INFO - 2021-07-28 04:54:36 --> Helper loaded: file_helper
INFO - 2021-07-28 04:54:36 --> Helper loaded: form_helper
INFO - 2021-07-28 04:54:36 --> Helper loaded: my_helper
INFO - 2021-07-28 04:54:36 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:54:36 --> Controller Class Initialized
DEBUG - 2021-07-28 04:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 04:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:54:36 --> Final output sent to browser
DEBUG - 2021-07-28 04:54:36 --> Total execution time: 0.0403
INFO - 2021-07-28 04:54:46 --> Config Class Initialized
INFO - 2021-07-28 04:54:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:54:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:54:46 --> Utf8 Class Initialized
INFO - 2021-07-28 04:54:46 --> URI Class Initialized
INFO - 2021-07-28 04:54:46 --> Router Class Initialized
INFO - 2021-07-28 04:54:46 --> Output Class Initialized
INFO - 2021-07-28 04:54:46 --> Security Class Initialized
DEBUG - 2021-07-28 04:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:54:46 --> Input Class Initialized
INFO - 2021-07-28 04:54:46 --> Language Class Initialized
INFO - 2021-07-28 04:54:46 --> Language Class Initialized
INFO - 2021-07-28 04:54:46 --> Config Class Initialized
INFO - 2021-07-28 04:54:46 --> Loader Class Initialized
INFO - 2021-07-28 04:54:46 --> Helper loaded: url_helper
INFO - 2021-07-28 04:54:46 --> Helper loaded: file_helper
INFO - 2021-07-28 04:54:46 --> Helper loaded: form_helper
INFO - 2021-07-28 04:54:46 --> Helper loaded: my_helper
INFO - 2021-07-28 04:54:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:54:46 --> Controller Class Initialized
INFO - 2021-07-28 04:54:46 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:54:46 --> Final output sent to browser
DEBUG - 2021-07-28 04:54:46 --> Total execution time: 0.0617
INFO - 2021-07-28 04:54:46 --> Config Class Initialized
INFO - 2021-07-28 04:54:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:54:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:54:46 --> Utf8 Class Initialized
INFO - 2021-07-28 04:54:46 --> URI Class Initialized
INFO - 2021-07-28 04:54:46 --> Router Class Initialized
INFO - 2021-07-28 04:54:46 --> Output Class Initialized
INFO - 2021-07-28 04:54:46 --> Security Class Initialized
DEBUG - 2021-07-28 04:54:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:54:46 --> Input Class Initialized
INFO - 2021-07-28 04:54:46 --> Language Class Initialized
INFO - 2021-07-28 04:54:46 --> Language Class Initialized
INFO - 2021-07-28 04:54:46 --> Config Class Initialized
INFO - 2021-07-28 04:54:46 --> Loader Class Initialized
INFO - 2021-07-28 04:54:46 --> Helper loaded: url_helper
INFO - 2021-07-28 04:54:46 --> Helper loaded: file_helper
INFO - 2021-07-28 04:54:46 --> Helper loaded: form_helper
INFO - 2021-07-28 04:54:46 --> Helper loaded: my_helper
INFO - 2021-07-28 04:54:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:54:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:54:46 --> Controller Class Initialized
DEBUG - 2021-07-28 04:54:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 04:54:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:54:47 --> Final output sent to browser
DEBUG - 2021-07-28 04:54:47 --> Total execution time: 0.7033
INFO - 2021-07-28 04:54:48 --> Config Class Initialized
INFO - 2021-07-28 04:54:48 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:54:48 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:54:48 --> Utf8 Class Initialized
INFO - 2021-07-28 04:54:48 --> URI Class Initialized
INFO - 2021-07-28 04:54:48 --> Router Class Initialized
INFO - 2021-07-28 04:54:48 --> Output Class Initialized
INFO - 2021-07-28 04:54:48 --> Security Class Initialized
DEBUG - 2021-07-28 04:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:54:48 --> Input Class Initialized
INFO - 2021-07-28 04:54:48 --> Language Class Initialized
INFO - 2021-07-28 04:54:48 --> Language Class Initialized
INFO - 2021-07-28 04:54:48 --> Config Class Initialized
INFO - 2021-07-28 04:54:48 --> Loader Class Initialized
INFO - 2021-07-28 04:54:48 --> Helper loaded: url_helper
INFO - 2021-07-28 04:54:48 --> Helper loaded: file_helper
INFO - 2021-07-28 04:54:48 --> Helper loaded: form_helper
INFO - 2021-07-28 04:54:48 --> Helper loaded: my_helper
INFO - 2021-07-28 04:54:48 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:54:48 --> Controller Class Initialized
DEBUG - 2021-07-28 04:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-28 04:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:54:48 --> Final output sent to browser
DEBUG - 2021-07-28 04:54:48 --> Total execution time: 0.0671
INFO - 2021-07-28 04:54:52 --> Config Class Initialized
INFO - 2021-07-28 04:54:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:54:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:54:52 --> Utf8 Class Initialized
INFO - 2021-07-28 04:54:52 --> URI Class Initialized
INFO - 2021-07-28 04:54:52 --> Router Class Initialized
INFO - 2021-07-28 04:54:52 --> Output Class Initialized
INFO - 2021-07-28 04:54:52 --> Security Class Initialized
DEBUG - 2021-07-28 04:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:54:52 --> Input Class Initialized
INFO - 2021-07-28 04:54:52 --> Language Class Initialized
INFO - 2021-07-28 04:54:52 --> Language Class Initialized
INFO - 2021-07-28 04:54:52 --> Config Class Initialized
INFO - 2021-07-28 04:54:52 --> Loader Class Initialized
INFO - 2021-07-28 04:54:52 --> Helper loaded: url_helper
INFO - 2021-07-28 04:54:52 --> Helper loaded: file_helper
INFO - 2021-07-28 04:54:52 --> Helper loaded: form_helper
INFO - 2021-07-28 04:54:52 --> Helper loaded: my_helper
INFO - 2021-07-28 04:54:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:54:52 --> Controller Class Initialized
DEBUG - 2021-07-28 04:54:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-28 04:54:52 --> Final output sent to browser
DEBUG - 2021-07-28 04:54:52 --> Total execution time: 0.1791
INFO - 2021-07-28 04:56:26 --> Config Class Initialized
INFO - 2021-07-28 04:56:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:26 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:26 --> URI Class Initialized
INFO - 2021-07-28 04:56:26 --> Router Class Initialized
INFO - 2021-07-28 04:56:26 --> Output Class Initialized
INFO - 2021-07-28 04:56:26 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:26 --> Input Class Initialized
INFO - 2021-07-28 04:56:26 --> Language Class Initialized
INFO - 2021-07-28 04:56:26 --> Language Class Initialized
INFO - 2021-07-28 04:56:26 --> Config Class Initialized
INFO - 2021-07-28 04:56:26 --> Loader Class Initialized
INFO - 2021-07-28 04:56:26 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:26 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:26 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:26 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:27 --> Controller Class Initialized
INFO - 2021-07-28 04:56:27 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:56:27 --> Config Class Initialized
INFO - 2021-07-28 04:56:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:27 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:27 --> URI Class Initialized
INFO - 2021-07-28 04:56:27 --> Router Class Initialized
INFO - 2021-07-28 04:56:27 --> Output Class Initialized
INFO - 2021-07-28 04:56:27 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:27 --> Input Class Initialized
INFO - 2021-07-28 04:56:27 --> Language Class Initialized
INFO - 2021-07-28 04:56:27 --> Language Class Initialized
INFO - 2021-07-28 04:56:27 --> Config Class Initialized
INFO - 2021-07-28 04:56:27 --> Loader Class Initialized
INFO - 2021-07-28 04:56:27 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:27 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:27 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:27 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:27 --> Controller Class Initialized
DEBUG - 2021-07-28 04:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 04:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:56:27 --> Final output sent to browser
DEBUG - 2021-07-28 04:56:27 --> Total execution time: 0.0557
INFO - 2021-07-28 04:56:40 --> Config Class Initialized
INFO - 2021-07-28 04:56:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:40 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:40 --> URI Class Initialized
INFO - 2021-07-28 04:56:40 --> Router Class Initialized
INFO - 2021-07-28 04:56:40 --> Output Class Initialized
INFO - 2021-07-28 04:56:40 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:40 --> Input Class Initialized
INFO - 2021-07-28 04:56:40 --> Language Class Initialized
INFO - 2021-07-28 04:56:40 --> Language Class Initialized
INFO - 2021-07-28 04:56:40 --> Config Class Initialized
INFO - 2021-07-28 04:56:40 --> Loader Class Initialized
INFO - 2021-07-28 04:56:40 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:40 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:40 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:40 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:40 --> Controller Class Initialized
INFO - 2021-07-28 04:56:40 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:56:40 --> Final output sent to browser
DEBUG - 2021-07-28 04:56:40 --> Total execution time: 0.0497
INFO - 2021-07-28 04:56:43 --> Config Class Initialized
INFO - 2021-07-28 04:56:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:43 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:43 --> URI Class Initialized
INFO - 2021-07-28 04:56:43 --> Router Class Initialized
INFO - 2021-07-28 04:56:43 --> Output Class Initialized
INFO - 2021-07-28 04:56:43 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:43 --> Input Class Initialized
INFO - 2021-07-28 04:56:43 --> Language Class Initialized
INFO - 2021-07-28 04:56:43 --> Language Class Initialized
INFO - 2021-07-28 04:56:43 --> Config Class Initialized
INFO - 2021-07-28 04:56:43 --> Loader Class Initialized
INFO - 2021-07-28 04:56:43 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:43 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:43 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:43 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:43 --> Controller Class Initialized
DEBUG - 2021-07-28 04:56:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 04:56:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:56:43 --> Final output sent to browser
DEBUG - 2021-07-28 04:56:43 --> Total execution time: 0.7242
INFO - 2021-07-28 04:56:48 --> Config Class Initialized
INFO - 2021-07-28 04:56:48 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:48 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:48 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:48 --> URI Class Initialized
INFO - 2021-07-28 04:56:48 --> Router Class Initialized
INFO - 2021-07-28 04:56:48 --> Output Class Initialized
INFO - 2021-07-28 04:56:48 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:48 --> Input Class Initialized
INFO - 2021-07-28 04:56:48 --> Language Class Initialized
INFO - 2021-07-28 04:56:48 --> Language Class Initialized
INFO - 2021-07-28 04:56:48 --> Config Class Initialized
INFO - 2021-07-28 04:56:48 --> Loader Class Initialized
INFO - 2021-07-28 04:56:48 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:48 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:48 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:48 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:48 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:48 --> Controller Class Initialized
DEBUG - 2021-07-28 04:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 04:56:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:56:48 --> Final output sent to browser
DEBUG - 2021-07-28 04:56:48 --> Total execution time: 0.1010
INFO - 2021-07-28 04:56:55 --> Config Class Initialized
INFO - 2021-07-28 04:56:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:55 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:55 --> URI Class Initialized
INFO - 2021-07-28 04:56:55 --> Router Class Initialized
INFO - 2021-07-28 04:56:55 --> Output Class Initialized
INFO - 2021-07-28 04:56:55 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:55 --> Input Class Initialized
INFO - 2021-07-28 04:56:55 --> Language Class Initialized
INFO - 2021-07-28 04:56:55 --> Language Class Initialized
INFO - 2021-07-28 04:56:55 --> Config Class Initialized
INFO - 2021-07-28 04:56:55 --> Loader Class Initialized
INFO - 2021-07-28 04:56:55 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:55 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:55 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:55 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:55 --> Controller Class Initialized
DEBUG - 2021-07-28 04:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 04:56:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:56:55 --> Final output sent to browser
DEBUG - 2021-07-28 04:56:55 --> Total execution time: 0.1221
INFO - 2021-07-28 04:56:55 --> Config Class Initialized
INFO - 2021-07-28 04:56:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:55 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:55 --> URI Class Initialized
INFO - 2021-07-28 04:56:55 --> Router Class Initialized
INFO - 2021-07-28 04:56:55 --> Output Class Initialized
INFO - 2021-07-28 04:56:55 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:55 --> Input Class Initialized
INFO - 2021-07-28 04:56:55 --> Language Class Initialized
INFO - 2021-07-28 04:56:55 --> Language Class Initialized
INFO - 2021-07-28 04:56:55 --> Config Class Initialized
INFO - 2021-07-28 04:56:55 --> Loader Class Initialized
INFO - 2021-07-28 04:56:55 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:55 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:55 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:55 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:55 --> Controller Class Initialized
INFO - 2021-07-28 04:56:57 --> Config Class Initialized
INFO - 2021-07-28 04:56:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:56:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:56:57 --> Utf8 Class Initialized
INFO - 2021-07-28 04:56:57 --> URI Class Initialized
INFO - 2021-07-28 04:56:57 --> Router Class Initialized
INFO - 2021-07-28 04:56:57 --> Output Class Initialized
INFO - 2021-07-28 04:56:57 --> Security Class Initialized
DEBUG - 2021-07-28 04:56:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:56:57 --> Input Class Initialized
INFO - 2021-07-28 04:56:57 --> Language Class Initialized
INFO - 2021-07-28 04:56:57 --> Language Class Initialized
INFO - 2021-07-28 04:56:57 --> Config Class Initialized
INFO - 2021-07-28 04:56:57 --> Loader Class Initialized
INFO - 2021-07-28 04:56:57 --> Helper loaded: url_helper
INFO - 2021-07-28 04:56:57 --> Helper loaded: file_helper
INFO - 2021-07-28 04:56:57 --> Helper loaded: form_helper
INFO - 2021-07-28 04:56:57 --> Helper loaded: my_helper
INFO - 2021-07-28 04:56:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:56:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:56:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:56:57 --> Controller Class Initialized
INFO - 2021-07-28 04:56:57 --> Final output sent to browser
DEBUG - 2021-07-28 04:56:57 --> Total execution time: 0.1095
INFO - 2021-07-28 04:57:06 --> Config Class Initialized
INFO - 2021-07-28 04:57:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:06 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:06 --> URI Class Initialized
INFO - 2021-07-28 04:57:06 --> Router Class Initialized
INFO - 2021-07-28 04:57:07 --> Output Class Initialized
INFO - 2021-07-28 04:57:07 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:07 --> Input Class Initialized
INFO - 2021-07-28 04:57:07 --> Language Class Initialized
INFO - 2021-07-28 04:57:07 --> Language Class Initialized
INFO - 2021-07-28 04:57:07 --> Config Class Initialized
INFO - 2021-07-28 04:57:07 --> Loader Class Initialized
INFO - 2021-07-28 04:57:07 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:07 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:07 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:07 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:07 --> Controller Class Initialized
INFO - 2021-07-28 04:57:07 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:07 --> Total execution time: 0.0671
INFO - 2021-07-28 04:57:15 --> Config Class Initialized
INFO - 2021-07-28 04:57:15 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:15 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:15 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:15 --> URI Class Initialized
INFO - 2021-07-28 04:57:15 --> Router Class Initialized
INFO - 2021-07-28 04:57:15 --> Output Class Initialized
INFO - 2021-07-28 04:57:15 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:15 --> Input Class Initialized
INFO - 2021-07-28 04:57:15 --> Language Class Initialized
INFO - 2021-07-28 04:57:15 --> Language Class Initialized
INFO - 2021-07-28 04:57:15 --> Config Class Initialized
INFO - 2021-07-28 04:57:15 --> Loader Class Initialized
INFO - 2021-07-28 04:57:15 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:15 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:15 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:15 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:15 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:15 --> Controller Class Initialized
INFO - 2021-07-28 04:57:16 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:16 --> Total execution time: 0.8676
INFO - 2021-07-28 04:57:16 --> Config Class Initialized
INFO - 2021-07-28 04:57:16 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:16 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:16 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:16 --> URI Class Initialized
INFO - 2021-07-28 04:57:17 --> Router Class Initialized
INFO - 2021-07-28 04:57:17 --> Output Class Initialized
INFO - 2021-07-28 04:57:17 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:17 --> Input Class Initialized
INFO - 2021-07-28 04:57:17 --> Language Class Initialized
INFO - 2021-07-28 04:57:17 --> Language Class Initialized
INFO - 2021-07-28 04:57:17 --> Config Class Initialized
INFO - 2021-07-28 04:57:17 --> Loader Class Initialized
INFO - 2021-07-28 04:57:17 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:17 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:17 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:17 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:17 --> Controller Class Initialized
INFO - 2021-07-28 04:57:17 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:17 --> Total execution time: 0.0556
INFO - 2021-07-28 04:57:23 --> Config Class Initialized
INFO - 2021-07-28 04:57:23 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:23 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:23 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:23 --> URI Class Initialized
INFO - 2021-07-28 04:57:23 --> Router Class Initialized
INFO - 2021-07-28 04:57:23 --> Output Class Initialized
INFO - 2021-07-28 04:57:23 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:23 --> Input Class Initialized
INFO - 2021-07-28 04:57:23 --> Language Class Initialized
INFO - 2021-07-28 04:57:23 --> Language Class Initialized
INFO - 2021-07-28 04:57:23 --> Config Class Initialized
INFO - 2021-07-28 04:57:23 --> Loader Class Initialized
INFO - 2021-07-28 04:57:23 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:23 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:23 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:23 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:23 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:23 --> Controller Class Initialized
INFO - 2021-07-28 04:57:24 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:24 --> Total execution time: 0.8918
INFO - 2021-07-28 04:57:28 --> Config Class Initialized
INFO - 2021-07-28 04:57:28 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:28 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:28 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:28 --> URI Class Initialized
INFO - 2021-07-28 04:57:28 --> Router Class Initialized
INFO - 2021-07-28 04:57:28 --> Output Class Initialized
INFO - 2021-07-28 04:57:28 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:28 --> Input Class Initialized
INFO - 2021-07-28 04:57:28 --> Language Class Initialized
INFO - 2021-07-28 04:57:28 --> Language Class Initialized
INFO - 2021-07-28 04:57:28 --> Config Class Initialized
INFO - 2021-07-28 04:57:28 --> Loader Class Initialized
INFO - 2021-07-28 04:57:28 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:28 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:28 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:28 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:28 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:28 --> Controller Class Initialized
INFO - 2021-07-28 04:57:28 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:28 --> Total execution time: 0.0761
INFO - 2021-07-28 04:57:35 --> Config Class Initialized
INFO - 2021-07-28 04:57:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:35 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:35 --> URI Class Initialized
INFO - 2021-07-28 04:57:35 --> Router Class Initialized
INFO - 2021-07-28 04:57:35 --> Output Class Initialized
INFO - 2021-07-28 04:57:35 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:35 --> Input Class Initialized
INFO - 2021-07-28 04:57:35 --> Language Class Initialized
INFO - 2021-07-28 04:57:35 --> Language Class Initialized
INFO - 2021-07-28 04:57:35 --> Config Class Initialized
INFO - 2021-07-28 04:57:35 --> Loader Class Initialized
INFO - 2021-07-28 04:57:35 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:35 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:35 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:35 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:35 --> Controller Class Initialized
INFO - 2021-07-28 04:57:35 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:35 --> Total execution time: 0.8744
INFO - 2021-07-28 04:57:38 --> Config Class Initialized
INFO - 2021-07-28 04:57:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:38 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:38 --> URI Class Initialized
INFO - 2021-07-28 04:57:38 --> Router Class Initialized
INFO - 2021-07-28 04:57:38 --> Output Class Initialized
INFO - 2021-07-28 04:57:38 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:38 --> Input Class Initialized
INFO - 2021-07-28 04:57:38 --> Language Class Initialized
INFO - 2021-07-28 04:57:38 --> Language Class Initialized
INFO - 2021-07-28 04:57:38 --> Config Class Initialized
INFO - 2021-07-28 04:57:38 --> Loader Class Initialized
INFO - 2021-07-28 04:57:38 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:38 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:38 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:38 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:38 --> Controller Class Initialized
INFO - 2021-07-28 04:57:38 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:38 --> Total execution time: 0.0581
INFO - 2021-07-28 04:57:46 --> Config Class Initialized
INFO - 2021-07-28 04:57:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:46 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:46 --> URI Class Initialized
INFO - 2021-07-28 04:57:46 --> Router Class Initialized
INFO - 2021-07-28 04:57:46 --> Output Class Initialized
INFO - 2021-07-28 04:57:46 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:46 --> Input Class Initialized
INFO - 2021-07-28 04:57:46 --> Language Class Initialized
INFO - 2021-07-28 04:57:46 --> Language Class Initialized
INFO - 2021-07-28 04:57:46 --> Config Class Initialized
INFO - 2021-07-28 04:57:46 --> Loader Class Initialized
INFO - 2021-07-28 04:57:46 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:46 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:46 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:46 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:46 --> Controller Class Initialized
INFO - 2021-07-28 04:57:47 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:47 --> Total execution time: 0.8857
INFO - 2021-07-28 04:57:51 --> Config Class Initialized
INFO - 2021-07-28 04:57:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:51 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:51 --> URI Class Initialized
INFO - 2021-07-28 04:57:51 --> Router Class Initialized
INFO - 2021-07-28 04:57:51 --> Output Class Initialized
INFO - 2021-07-28 04:57:51 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:51 --> Input Class Initialized
INFO - 2021-07-28 04:57:51 --> Language Class Initialized
INFO - 2021-07-28 04:57:51 --> Language Class Initialized
INFO - 2021-07-28 04:57:51 --> Config Class Initialized
INFO - 2021-07-28 04:57:51 --> Loader Class Initialized
INFO - 2021-07-28 04:57:51 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:51 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:51 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:51 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:51 --> Controller Class Initialized
INFO - 2021-07-28 04:57:52 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:52 --> Total execution time: 0.9044
INFO - 2021-07-28 04:57:54 --> Config Class Initialized
INFO - 2021-07-28 04:57:54 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:57:54 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:57:54 --> Utf8 Class Initialized
INFO - 2021-07-28 04:57:54 --> URI Class Initialized
INFO - 2021-07-28 04:57:54 --> Router Class Initialized
INFO - 2021-07-28 04:57:54 --> Output Class Initialized
INFO - 2021-07-28 04:57:54 --> Security Class Initialized
DEBUG - 2021-07-28 04:57:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:57:54 --> Input Class Initialized
INFO - 2021-07-28 04:57:54 --> Language Class Initialized
INFO - 2021-07-28 04:57:54 --> Language Class Initialized
INFO - 2021-07-28 04:57:54 --> Config Class Initialized
INFO - 2021-07-28 04:57:54 --> Loader Class Initialized
INFO - 2021-07-28 04:57:54 --> Helper loaded: url_helper
INFO - 2021-07-28 04:57:54 --> Helper loaded: file_helper
INFO - 2021-07-28 04:57:54 --> Helper loaded: form_helper
INFO - 2021-07-28 04:57:54 --> Helper loaded: my_helper
INFO - 2021-07-28 04:57:54 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:57:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:57:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:57:54 --> Controller Class Initialized
INFO - 2021-07-28 04:57:54 --> Final output sent to browser
DEBUG - 2021-07-28 04:57:54 --> Total execution time: 0.0441
INFO - 2021-07-28 04:58:25 --> Config Class Initialized
INFO - 2021-07-28 04:58:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:25 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:25 --> URI Class Initialized
INFO - 2021-07-28 04:58:25 --> Router Class Initialized
INFO - 2021-07-28 04:58:25 --> Output Class Initialized
INFO - 2021-07-28 04:58:25 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:25 --> Input Class Initialized
INFO - 2021-07-28 04:58:25 --> Language Class Initialized
INFO - 2021-07-28 04:58:25 --> Language Class Initialized
INFO - 2021-07-28 04:58:25 --> Config Class Initialized
INFO - 2021-07-28 04:58:25 --> Loader Class Initialized
INFO - 2021-07-28 04:58:25 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:25 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:25 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:25 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:25 --> Controller Class Initialized
INFO - 2021-07-28 04:58:25 --> Final output sent to browser
DEBUG - 2021-07-28 04:58:25 --> Total execution time: 0.8578
INFO - 2021-07-28 04:58:29 --> Config Class Initialized
INFO - 2021-07-28 04:58:29 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:29 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:29 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:29 --> URI Class Initialized
INFO - 2021-07-28 04:58:29 --> Router Class Initialized
INFO - 2021-07-28 04:58:29 --> Output Class Initialized
INFO - 2021-07-28 04:58:29 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:29 --> Input Class Initialized
INFO - 2021-07-28 04:58:29 --> Language Class Initialized
INFO - 2021-07-28 04:58:29 --> Language Class Initialized
INFO - 2021-07-28 04:58:29 --> Config Class Initialized
INFO - 2021-07-28 04:58:29 --> Loader Class Initialized
INFO - 2021-07-28 04:58:29 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:29 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:29 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:29 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:29 --> Controller Class Initialized
DEBUG - 2021-07-28 04:58:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 04:58:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:58:29 --> Final output sent to browser
DEBUG - 2021-07-28 04:58:29 --> Total execution time: 0.0471
INFO - 2021-07-28 04:58:34 --> Config Class Initialized
INFO - 2021-07-28 04:58:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:34 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:34 --> URI Class Initialized
INFO - 2021-07-28 04:58:34 --> Router Class Initialized
INFO - 2021-07-28 04:58:34 --> Output Class Initialized
INFO - 2021-07-28 04:58:34 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:34 --> Input Class Initialized
INFO - 2021-07-28 04:58:34 --> Language Class Initialized
INFO - 2021-07-28 04:58:34 --> Language Class Initialized
INFO - 2021-07-28 04:58:34 --> Config Class Initialized
INFO - 2021-07-28 04:58:34 --> Loader Class Initialized
INFO - 2021-07-28 04:58:34 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:34 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:34 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:34 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:35 --> Controller Class Initialized
DEBUG - 2021-07-28 04:58:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 04:58:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:58:35 --> Final output sent to browser
DEBUG - 2021-07-28 04:58:35 --> Total execution time: 0.0615
INFO - 2021-07-28 04:58:35 --> Config Class Initialized
INFO - 2021-07-28 04:58:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:35 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:35 --> URI Class Initialized
INFO - 2021-07-28 04:58:35 --> Router Class Initialized
INFO - 2021-07-28 04:58:35 --> Output Class Initialized
INFO - 2021-07-28 04:58:35 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:35 --> Input Class Initialized
INFO - 2021-07-28 04:58:35 --> Language Class Initialized
INFO - 2021-07-28 04:58:35 --> Language Class Initialized
INFO - 2021-07-28 04:58:35 --> Config Class Initialized
INFO - 2021-07-28 04:58:35 --> Loader Class Initialized
INFO - 2021-07-28 04:58:35 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:35 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:35 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:35 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:35 --> Controller Class Initialized
INFO - 2021-07-28 04:58:36 --> Config Class Initialized
INFO - 2021-07-28 04:58:36 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:36 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:36 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:36 --> URI Class Initialized
INFO - 2021-07-28 04:58:36 --> Router Class Initialized
INFO - 2021-07-28 04:58:36 --> Output Class Initialized
INFO - 2021-07-28 04:58:36 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:36 --> Input Class Initialized
INFO - 2021-07-28 04:58:36 --> Language Class Initialized
INFO - 2021-07-28 04:58:36 --> Language Class Initialized
INFO - 2021-07-28 04:58:36 --> Config Class Initialized
INFO - 2021-07-28 04:58:36 --> Loader Class Initialized
INFO - 2021-07-28 04:58:36 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:36 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:36 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:36 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:36 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:36 --> Controller Class Initialized
INFO - 2021-07-28 04:58:36 --> Final output sent to browser
DEBUG - 2021-07-28 04:58:36 --> Total execution time: 0.0996
INFO - 2021-07-28 04:58:47 --> Config Class Initialized
INFO - 2021-07-28 04:58:47 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:47 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:47 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:47 --> URI Class Initialized
INFO - 2021-07-28 04:58:47 --> Router Class Initialized
INFO - 2021-07-28 04:58:47 --> Output Class Initialized
INFO - 2021-07-28 04:58:47 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:47 --> Input Class Initialized
INFO - 2021-07-28 04:58:47 --> Language Class Initialized
INFO - 2021-07-28 04:58:47 --> Language Class Initialized
INFO - 2021-07-28 04:58:47 --> Config Class Initialized
INFO - 2021-07-28 04:58:47 --> Loader Class Initialized
INFO - 2021-07-28 04:58:47 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:47 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:47 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:47 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:47 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:47 --> Controller Class Initialized
DEBUG - 2021-07-28 04:58:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 04:58:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:58:47 --> Final output sent to browser
DEBUG - 2021-07-28 04:58:47 --> Total execution time: 0.0586
INFO - 2021-07-28 04:58:55 --> Config Class Initialized
INFO - 2021-07-28 04:58:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:55 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:55 --> URI Class Initialized
INFO - 2021-07-28 04:58:55 --> Router Class Initialized
INFO - 2021-07-28 04:58:55 --> Output Class Initialized
INFO - 2021-07-28 04:58:55 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:55 --> Input Class Initialized
INFO - 2021-07-28 04:58:55 --> Language Class Initialized
INFO - 2021-07-28 04:58:55 --> Language Class Initialized
INFO - 2021-07-28 04:58:55 --> Config Class Initialized
INFO - 2021-07-28 04:58:55 --> Loader Class Initialized
INFO - 2021-07-28 04:58:55 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:55 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:55 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:55 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:55 --> Controller Class Initialized
INFO - 2021-07-28 04:58:55 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:58:55 --> Config Class Initialized
INFO - 2021-07-28 04:58:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:58:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:58:55 --> Utf8 Class Initialized
INFO - 2021-07-28 04:58:55 --> URI Class Initialized
INFO - 2021-07-28 04:58:55 --> Router Class Initialized
INFO - 2021-07-28 04:58:55 --> Output Class Initialized
INFO - 2021-07-28 04:58:55 --> Security Class Initialized
DEBUG - 2021-07-28 04:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:58:55 --> Input Class Initialized
INFO - 2021-07-28 04:58:55 --> Language Class Initialized
INFO - 2021-07-28 04:58:55 --> Language Class Initialized
INFO - 2021-07-28 04:58:55 --> Config Class Initialized
INFO - 2021-07-28 04:58:55 --> Loader Class Initialized
INFO - 2021-07-28 04:58:55 --> Helper loaded: url_helper
INFO - 2021-07-28 04:58:55 --> Helper loaded: file_helper
INFO - 2021-07-28 04:58:55 --> Helper loaded: form_helper
INFO - 2021-07-28 04:58:55 --> Helper loaded: my_helper
INFO - 2021-07-28 04:58:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:58:55 --> Controller Class Initialized
DEBUG - 2021-07-28 04:58:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 04:58:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:58:55 --> Final output sent to browser
DEBUG - 2021-07-28 04:58:55 --> Total execution time: 0.0416
INFO - 2021-07-28 04:59:04 --> Config Class Initialized
INFO - 2021-07-28 04:59:04 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:04 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:04 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:04 --> URI Class Initialized
INFO - 2021-07-28 04:59:04 --> Router Class Initialized
INFO - 2021-07-28 04:59:04 --> Output Class Initialized
INFO - 2021-07-28 04:59:04 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:04 --> Input Class Initialized
INFO - 2021-07-28 04:59:04 --> Language Class Initialized
INFO - 2021-07-28 04:59:04 --> Language Class Initialized
INFO - 2021-07-28 04:59:04 --> Config Class Initialized
INFO - 2021-07-28 04:59:04 --> Loader Class Initialized
INFO - 2021-07-28 04:59:04 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:04 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:04 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:04 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:04 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:04 --> Controller Class Initialized
INFO - 2021-07-28 04:59:04 --> Helper loaded: cookie_helper
INFO - 2021-07-28 04:59:04 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:04 --> Total execution time: 0.0580
INFO - 2021-07-28 04:59:05 --> Config Class Initialized
INFO - 2021-07-28 04:59:05 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:05 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:05 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:05 --> URI Class Initialized
INFO - 2021-07-28 04:59:05 --> Router Class Initialized
INFO - 2021-07-28 04:59:05 --> Output Class Initialized
INFO - 2021-07-28 04:59:05 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:05 --> Input Class Initialized
INFO - 2021-07-28 04:59:05 --> Language Class Initialized
INFO - 2021-07-28 04:59:05 --> Language Class Initialized
INFO - 2021-07-28 04:59:05 --> Config Class Initialized
INFO - 2021-07-28 04:59:05 --> Loader Class Initialized
INFO - 2021-07-28 04:59:05 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:05 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:05 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:05 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:05 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:05 --> Controller Class Initialized
DEBUG - 2021-07-28 04:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 04:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:59:06 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:06 --> Total execution time: 0.7304
INFO - 2021-07-28 04:59:08 --> Config Class Initialized
INFO - 2021-07-28 04:59:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:08 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:08 --> URI Class Initialized
INFO - 2021-07-28 04:59:08 --> Router Class Initialized
INFO - 2021-07-28 04:59:08 --> Output Class Initialized
INFO - 2021-07-28 04:59:08 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:08 --> Input Class Initialized
INFO - 2021-07-28 04:59:08 --> Language Class Initialized
INFO - 2021-07-28 04:59:08 --> Language Class Initialized
INFO - 2021-07-28 04:59:08 --> Config Class Initialized
INFO - 2021-07-28 04:59:08 --> Loader Class Initialized
INFO - 2021-07-28 04:59:08 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:08 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:08 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:08 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:08 --> Controller Class Initialized
DEBUG - 2021-07-28 04:59:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 04:59:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:59:08 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:08 --> Total execution time: 0.0695
INFO - 2021-07-28 04:59:10 --> Config Class Initialized
INFO - 2021-07-28 04:59:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:10 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:10 --> URI Class Initialized
INFO - 2021-07-28 04:59:10 --> Router Class Initialized
INFO - 2021-07-28 04:59:10 --> Output Class Initialized
INFO - 2021-07-28 04:59:10 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:10 --> Input Class Initialized
INFO - 2021-07-28 04:59:10 --> Language Class Initialized
INFO - 2021-07-28 04:59:10 --> Language Class Initialized
INFO - 2021-07-28 04:59:10 --> Config Class Initialized
INFO - 2021-07-28 04:59:10 --> Loader Class Initialized
INFO - 2021-07-28 04:59:10 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:10 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:10 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:10 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:10 --> Controller Class Initialized
DEBUG - 2021-07-28 04:59:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 04:59:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:59:10 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:10 --> Total execution time: 0.0598
INFO - 2021-07-28 04:59:10 --> Config Class Initialized
INFO - 2021-07-28 04:59:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:10 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:10 --> URI Class Initialized
INFO - 2021-07-28 04:59:10 --> Router Class Initialized
INFO - 2021-07-28 04:59:10 --> Output Class Initialized
INFO - 2021-07-28 04:59:10 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:10 --> Input Class Initialized
INFO - 2021-07-28 04:59:10 --> Language Class Initialized
INFO - 2021-07-28 04:59:10 --> Language Class Initialized
INFO - 2021-07-28 04:59:10 --> Config Class Initialized
INFO - 2021-07-28 04:59:10 --> Loader Class Initialized
INFO - 2021-07-28 04:59:10 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:10 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:10 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:10 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:10 --> Controller Class Initialized
INFO - 2021-07-28 04:59:11 --> Config Class Initialized
INFO - 2021-07-28 04:59:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:11 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:11 --> URI Class Initialized
INFO - 2021-07-28 04:59:11 --> Router Class Initialized
INFO - 2021-07-28 04:59:11 --> Output Class Initialized
INFO - 2021-07-28 04:59:11 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:11 --> Input Class Initialized
INFO - 2021-07-28 04:59:11 --> Language Class Initialized
INFO - 2021-07-28 04:59:11 --> Language Class Initialized
INFO - 2021-07-28 04:59:11 --> Config Class Initialized
INFO - 2021-07-28 04:59:11 --> Loader Class Initialized
INFO - 2021-07-28 04:59:11 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:11 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:11 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:11 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:11 --> Controller Class Initialized
INFO - 2021-07-28 04:59:11 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:11 --> Total execution time: 0.0892
INFO - 2021-07-28 04:59:18 --> Config Class Initialized
INFO - 2021-07-28 04:59:18 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:18 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:18 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:18 --> URI Class Initialized
INFO - 2021-07-28 04:59:18 --> Router Class Initialized
INFO - 2021-07-28 04:59:18 --> Output Class Initialized
INFO - 2021-07-28 04:59:18 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:18 --> Input Class Initialized
INFO - 2021-07-28 04:59:18 --> Language Class Initialized
INFO - 2021-07-28 04:59:18 --> Language Class Initialized
INFO - 2021-07-28 04:59:18 --> Config Class Initialized
INFO - 2021-07-28 04:59:18 --> Loader Class Initialized
INFO - 2021-07-28 04:59:18 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:18 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:18 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:18 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:18 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:18 --> Controller Class Initialized
INFO - 2021-07-28 04:59:19 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:19 --> Total execution time: 0.8981
INFO - 2021-07-28 04:59:21 --> Config Class Initialized
INFO - 2021-07-28 04:59:21 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:21 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:21 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:21 --> URI Class Initialized
INFO - 2021-07-28 04:59:21 --> Router Class Initialized
INFO - 2021-07-28 04:59:21 --> Output Class Initialized
INFO - 2021-07-28 04:59:21 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:21 --> Input Class Initialized
INFO - 2021-07-28 04:59:21 --> Language Class Initialized
INFO - 2021-07-28 04:59:21 --> Language Class Initialized
INFO - 2021-07-28 04:59:21 --> Config Class Initialized
INFO - 2021-07-28 04:59:21 --> Loader Class Initialized
INFO - 2021-07-28 04:59:21 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:21 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:21 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:21 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:21 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:21 --> Controller Class Initialized
INFO - 2021-07-28 04:59:21 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:21 --> Total execution time: 0.0858
INFO - 2021-07-28 04:59:29 --> Config Class Initialized
INFO - 2021-07-28 04:59:29 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:29 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:29 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:29 --> URI Class Initialized
INFO - 2021-07-28 04:59:29 --> Router Class Initialized
INFO - 2021-07-28 04:59:29 --> Output Class Initialized
INFO - 2021-07-28 04:59:29 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:29 --> Input Class Initialized
INFO - 2021-07-28 04:59:29 --> Language Class Initialized
INFO - 2021-07-28 04:59:29 --> Language Class Initialized
INFO - 2021-07-28 04:59:29 --> Config Class Initialized
INFO - 2021-07-28 04:59:29 --> Loader Class Initialized
INFO - 2021-07-28 04:59:29 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:29 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:29 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:29 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:29 --> Controller Class Initialized
INFO - 2021-07-28 04:59:30 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:30 --> Total execution time: 0.9007
INFO - 2021-07-28 04:59:33 --> Config Class Initialized
INFO - 2021-07-28 04:59:33 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:33 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:33 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:33 --> URI Class Initialized
INFO - 2021-07-28 04:59:33 --> Router Class Initialized
INFO - 2021-07-28 04:59:33 --> Output Class Initialized
INFO - 2021-07-28 04:59:33 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:33 --> Input Class Initialized
INFO - 2021-07-28 04:59:33 --> Language Class Initialized
INFO - 2021-07-28 04:59:33 --> Language Class Initialized
INFO - 2021-07-28 04:59:33 --> Config Class Initialized
INFO - 2021-07-28 04:59:33 --> Loader Class Initialized
INFO - 2021-07-28 04:59:33 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:33 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:33 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:33 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:33 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:33 --> Controller Class Initialized
INFO - 2021-07-28 04:59:33 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:33 --> Total execution time: 0.0553
INFO - 2021-07-28 04:59:38 --> Config Class Initialized
INFO - 2021-07-28 04:59:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:38 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:38 --> URI Class Initialized
INFO - 2021-07-28 04:59:38 --> Router Class Initialized
INFO - 2021-07-28 04:59:38 --> Output Class Initialized
INFO - 2021-07-28 04:59:38 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:38 --> Input Class Initialized
INFO - 2021-07-28 04:59:38 --> Language Class Initialized
INFO - 2021-07-28 04:59:38 --> Language Class Initialized
INFO - 2021-07-28 04:59:38 --> Config Class Initialized
INFO - 2021-07-28 04:59:38 --> Loader Class Initialized
INFO - 2021-07-28 04:59:38 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:38 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:38 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:38 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:38 --> Controller Class Initialized
INFO - 2021-07-28 04:59:39 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:39 --> Total execution time: 0.9142
INFO - 2021-07-28 04:59:41 --> Config Class Initialized
INFO - 2021-07-28 04:59:41 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:41 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:41 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:41 --> URI Class Initialized
INFO - 2021-07-28 04:59:41 --> Router Class Initialized
INFO - 2021-07-28 04:59:41 --> Output Class Initialized
INFO - 2021-07-28 04:59:41 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:41 --> Input Class Initialized
INFO - 2021-07-28 04:59:41 --> Language Class Initialized
INFO - 2021-07-28 04:59:41 --> Language Class Initialized
INFO - 2021-07-28 04:59:41 --> Config Class Initialized
INFO - 2021-07-28 04:59:41 --> Loader Class Initialized
INFO - 2021-07-28 04:59:41 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:41 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:41 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:41 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:41 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:41 --> Controller Class Initialized
INFO - 2021-07-28 04:59:41 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:41 --> Total execution time: 0.0596
INFO - 2021-07-28 04:59:46 --> Config Class Initialized
INFO - 2021-07-28 04:59:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:46 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:46 --> URI Class Initialized
INFO - 2021-07-28 04:59:46 --> Router Class Initialized
INFO - 2021-07-28 04:59:46 --> Output Class Initialized
INFO - 2021-07-28 04:59:46 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:46 --> Input Class Initialized
INFO - 2021-07-28 04:59:46 --> Language Class Initialized
INFO - 2021-07-28 04:59:46 --> Language Class Initialized
INFO - 2021-07-28 04:59:46 --> Config Class Initialized
INFO - 2021-07-28 04:59:46 --> Loader Class Initialized
INFO - 2021-07-28 04:59:46 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:46 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:46 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:46 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:46 --> Controller Class Initialized
INFO - 2021-07-28 04:59:47 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:47 --> Total execution time: 1.0220
INFO - 2021-07-28 04:59:49 --> Config Class Initialized
INFO - 2021-07-28 04:59:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:49 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:49 --> URI Class Initialized
INFO - 2021-07-28 04:59:49 --> Router Class Initialized
INFO - 2021-07-28 04:59:49 --> Output Class Initialized
INFO - 2021-07-28 04:59:49 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:49 --> Input Class Initialized
INFO - 2021-07-28 04:59:49 --> Language Class Initialized
INFO - 2021-07-28 04:59:49 --> Language Class Initialized
INFO - 2021-07-28 04:59:49 --> Config Class Initialized
INFO - 2021-07-28 04:59:49 --> Loader Class Initialized
INFO - 2021-07-28 04:59:49 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:49 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:50 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:50 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:50 --> Controller Class Initialized
DEBUG - 2021-07-28 04:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 04:59:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:59:50 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:50 --> Total execution time: 0.0577
INFO - 2021-07-28 04:59:56 --> Config Class Initialized
INFO - 2021-07-28 04:59:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:56 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:56 --> URI Class Initialized
INFO - 2021-07-28 04:59:56 --> Router Class Initialized
INFO - 2021-07-28 04:59:56 --> Output Class Initialized
INFO - 2021-07-28 04:59:56 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:56 --> Input Class Initialized
INFO - 2021-07-28 04:59:56 --> Language Class Initialized
INFO - 2021-07-28 04:59:56 --> Language Class Initialized
INFO - 2021-07-28 04:59:56 --> Config Class Initialized
INFO - 2021-07-28 04:59:56 --> Loader Class Initialized
INFO - 2021-07-28 04:59:56 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:56 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:56 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:56 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:56 --> Controller Class Initialized
DEBUG - 2021-07-28 04:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 04:59:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 04:59:56 --> Final output sent to browser
DEBUG - 2021-07-28 04:59:56 --> Total execution time: 0.0704
INFO - 2021-07-28 04:59:56 --> Config Class Initialized
INFO - 2021-07-28 04:59:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 04:59:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 04:59:56 --> Utf8 Class Initialized
INFO - 2021-07-28 04:59:56 --> URI Class Initialized
INFO - 2021-07-28 04:59:56 --> Router Class Initialized
INFO - 2021-07-28 04:59:56 --> Output Class Initialized
INFO - 2021-07-28 04:59:56 --> Security Class Initialized
DEBUG - 2021-07-28 04:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 04:59:56 --> Input Class Initialized
INFO - 2021-07-28 04:59:56 --> Language Class Initialized
INFO - 2021-07-28 04:59:56 --> Language Class Initialized
INFO - 2021-07-28 04:59:56 --> Config Class Initialized
INFO - 2021-07-28 04:59:56 --> Loader Class Initialized
INFO - 2021-07-28 04:59:56 --> Helper loaded: url_helper
INFO - 2021-07-28 04:59:56 --> Helper loaded: file_helper
INFO - 2021-07-28 04:59:56 --> Helper loaded: form_helper
INFO - 2021-07-28 04:59:56 --> Helper loaded: my_helper
INFO - 2021-07-28 04:59:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 04:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 04:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 04:59:56 --> Controller Class Initialized
INFO - 2021-07-28 05:00:03 --> Config Class Initialized
INFO - 2021-07-28 05:00:03 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:03 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:03 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:03 --> URI Class Initialized
INFO - 2021-07-28 05:00:03 --> Router Class Initialized
INFO - 2021-07-28 05:00:03 --> Output Class Initialized
INFO - 2021-07-28 05:00:03 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:03 --> Input Class Initialized
INFO - 2021-07-28 05:00:03 --> Language Class Initialized
INFO - 2021-07-28 05:00:03 --> Language Class Initialized
INFO - 2021-07-28 05:00:03 --> Config Class Initialized
INFO - 2021-07-28 05:00:03 --> Loader Class Initialized
INFO - 2021-07-28 05:00:03 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:03 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:03 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:03 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:03 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:03 --> Controller Class Initialized
INFO - 2021-07-28 05:00:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:03 --> Total execution time: 0.0662
INFO - 2021-07-28 05:00:09 --> Config Class Initialized
INFO - 2021-07-28 05:00:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:09 --> URI Class Initialized
INFO - 2021-07-28 05:00:09 --> Router Class Initialized
INFO - 2021-07-28 05:00:09 --> Output Class Initialized
INFO - 2021-07-28 05:00:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:09 --> Input Class Initialized
INFO - 2021-07-28 05:00:09 --> Language Class Initialized
INFO - 2021-07-28 05:00:09 --> Language Class Initialized
INFO - 2021-07-28 05:00:09 --> Config Class Initialized
INFO - 2021-07-28 05:00:09 --> Loader Class Initialized
INFO - 2021-07-28 05:00:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:09 --> Controller Class Initialized
INFO - 2021-07-28 05:00:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:09 --> Total execution time: 0.0600
INFO - 2021-07-28 05:00:14 --> Config Class Initialized
INFO - 2021-07-28 05:00:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:14 --> URI Class Initialized
INFO - 2021-07-28 05:00:14 --> Router Class Initialized
INFO - 2021-07-28 05:00:14 --> Output Class Initialized
INFO - 2021-07-28 05:00:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:14 --> Input Class Initialized
INFO - 2021-07-28 05:00:14 --> Language Class Initialized
INFO - 2021-07-28 05:00:14 --> Language Class Initialized
INFO - 2021-07-28 05:00:14 --> Config Class Initialized
INFO - 2021-07-28 05:00:14 --> Loader Class Initialized
INFO - 2021-07-28 05:00:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:14 --> Controller Class Initialized
INFO - 2021-07-28 05:00:16 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:16 --> Total execution time: 2.1206
INFO - 2021-07-28 05:00:18 --> Config Class Initialized
INFO - 2021-07-28 05:00:18 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:18 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:18 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:18 --> URI Class Initialized
INFO - 2021-07-28 05:00:18 --> Router Class Initialized
INFO - 2021-07-28 05:00:18 --> Output Class Initialized
INFO - 2021-07-28 05:00:18 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:18 --> Input Class Initialized
INFO - 2021-07-28 05:00:18 --> Language Class Initialized
INFO - 2021-07-28 05:00:18 --> Language Class Initialized
INFO - 2021-07-28 05:00:18 --> Config Class Initialized
INFO - 2021-07-28 05:00:18 --> Loader Class Initialized
INFO - 2021-07-28 05:00:18 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:18 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:18 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:18 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:18 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:18 --> Controller Class Initialized
INFO - 2021-07-28 05:00:18 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:18 --> Total execution time: 0.0662
INFO - 2021-07-28 05:00:24 --> Config Class Initialized
INFO - 2021-07-28 05:00:24 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:24 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:24 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:24 --> URI Class Initialized
INFO - 2021-07-28 05:00:24 --> Router Class Initialized
INFO - 2021-07-28 05:00:24 --> Output Class Initialized
INFO - 2021-07-28 05:00:24 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:24 --> Input Class Initialized
INFO - 2021-07-28 05:00:24 --> Language Class Initialized
INFO - 2021-07-28 05:00:24 --> Language Class Initialized
INFO - 2021-07-28 05:00:24 --> Config Class Initialized
INFO - 2021-07-28 05:00:24 --> Loader Class Initialized
INFO - 2021-07-28 05:00:24 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:24 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:24 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:24 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:24 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:25 --> Controller Class Initialized
INFO - 2021-07-28 05:00:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:27 --> Total execution time: 2.2055
INFO - 2021-07-28 05:00:27 --> Config Class Initialized
INFO - 2021-07-28 05:00:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:27 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:27 --> URI Class Initialized
INFO - 2021-07-28 05:00:27 --> Router Class Initialized
INFO - 2021-07-28 05:00:27 --> Output Class Initialized
INFO - 2021-07-28 05:00:27 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:27 --> Input Class Initialized
INFO - 2021-07-28 05:00:27 --> Language Class Initialized
INFO - 2021-07-28 05:00:27 --> Language Class Initialized
INFO - 2021-07-28 05:00:27 --> Config Class Initialized
INFO - 2021-07-28 05:00:27 --> Loader Class Initialized
INFO - 2021-07-28 05:00:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:27 --> Controller Class Initialized
INFO - 2021-07-28 05:00:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:27 --> Total execution time: 0.0571
INFO - 2021-07-28 05:00:34 --> Config Class Initialized
INFO - 2021-07-28 05:00:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:34 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:34 --> URI Class Initialized
INFO - 2021-07-28 05:00:34 --> Router Class Initialized
INFO - 2021-07-28 05:00:34 --> Output Class Initialized
INFO - 2021-07-28 05:00:34 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:34 --> Input Class Initialized
INFO - 2021-07-28 05:00:34 --> Language Class Initialized
INFO - 2021-07-28 05:00:34 --> Language Class Initialized
INFO - 2021-07-28 05:00:34 --> Config Class Initialized
INFO - 2021-07-28 05:00:34 --> Loader Class Initialized
INFO - 2021-07-28 05:00:34 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:34 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:34 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:34 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:34 --> Controller Class Initialized
INFO - 2021-07-28 05:00:36 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:36 --> Total execution time: 2.1845
INFO - 2021-07-28 05:00:38 --> Config Class Initialized
INFO - 2021-07-28 05:00:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:38 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:38 --> URI Class Initialized
INFO - 2021-07-28 05:00:38 --> Router Class Initialized
INFO - 2021-07-28 05:00:38 --> Output Class Initialized
INFO - 2021-07-28 05:00:38 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:38 --> Input Class Initialized
INFO - 2021-07-28 05:00:38 --> Language Class Initialized
INFO - 2021-07-28 05:00:38 --> Language Class Initialized
INFO - 2021-07-28 05:00:38 --> Config Class Initialized
INFO - 2021-07-28 05:00:38 --> Loader Class Initialized
INFO - 2021-07-28 05:00:38 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:38 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:38 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:38 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:38 --> Controller Class Initialized
DEBUG - 2021-07-28 05:00:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:00:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:00:38 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:38 --> Total execution time: 0.0456
INFO - 2021-07-28 05:00:42 --> Config Class Initialized
INFO - 2021-07-28 05:00:42 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:42 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:42 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:42 --> URI Class Initialized
INFO - 2021-07-28 05:00:42 --> Router Class Initialized
INFO - 2021-07-28 05:00:42 --> Output Class Initialized
INFO - 2021-07-28 05:00:42 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:42 --> Input Class Initialized
INFO - 2021-07-28 05:00:42 --> Language Class Initialized
INFO - 2021-07-28 05:00:42 --> Language Class Initialized
INFO - 2021-07-28 05:00:42 --> Config Class Initialized
INFO - 2021-07-28 05:00:42 --> Loader Class Initialized
INFO - 2021-07-28 05:00:42 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:42 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:42 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:42 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:42 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:42 --> Controller Class Initialized
INFO - 2021-07-28 05:00:42 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:00:42 --> Config Class Initialized
INFO - 2021-07-28 05:00:42 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:42 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:42 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:42 --> URI Class Initialized
INFO - 2021-07-28 05:00:42 --> Router Class Initialized
INFO - 2021-07-28 05:00:42 --> Output Class Initialized
INFO - 2021-07-28 05:00:42 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:42 --> Input Class Initialized
INFO - 2021-07-28 05:00:42 --> Language Class Initialized
INFO - 2021-07-28 05:00:42 --> Language Class Initialized
INFO - 2021-07-28 05:00:42 --> Config Class Initialized
INFO - 2021-07-28 05:00:42 --> Loader Class Initialized
INFO - 2021-07-28 05:00:42 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:42 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:42 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:42 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:42 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:42 --> Controller Class Initialized
DEBUG - 2021-07-28 05:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:00:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:00:42 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:42 --> Total execution time: 0.0523
INFO - 2021-07-28 05:00:49 --> Config Class Initialized
INFO - 2021-07-28 05:00:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:49 --> URI Class Initialized
INFO - 2021-07-28 05:00:49 --> Router Class Initialized
INFO - 2021-07-28 05:00:49 --> Output Class Initialized
INFO - 2021-07-28 05:00:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:49 --> Input Class Initialized
INFO - 2021-07-28 05:00:49 --> Language Class Initialized
INFO - 2021-07-28 05:00:49 --> Language Class Initialized
INFO - 2021-07-28 05:00:49 --> Config Class Initialized
INFO - 2021-07-28 05:00:49 --> Loader Class Initialized
INFO - 2021-07-28 05:00:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:49 --> Controller Class Initialized
INFO - 2021-07-28 05:00:49 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:00:49 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:49 --> Total execution time: 0.0536
INFO - 2021-07-28 05:00:50 --> Config Class Initialized
INFO - 2021-07-28 05:00:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:50 --> URI Class Initialized
INFO - 2021-07-28 05:00:50 --> Router Class Initialized
INFO - 2021-07-28 05:00:50 --> Output Class Initialized
INFO - 2021-07-28 05:00:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:50 --> Input Class Initialized
INFO - 2021-07-28 05:00:50 --> Language Class Initialized
INFO - 2021-07-28 05:00:50 --> Language Class Initialized
INFO - 2021-07-28 05:00:50 --> Config Class Initialized
INFO - 2021-07-28 05:00:50 --> Loader Class Initialized
INFO - 2021-07-28 05:00:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:50 --> Controller Class Initialized
DEBUG - 2021-07-28 05:00:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:00:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:00:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:51 --> Total execution time: 0.7293
INFO - 2021-07-28 05:00:53 --> Config Class Initialized
INFO - 2021-07-28 05:00:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:53 --> URI Class Initialized
INFO - 2021-07-28 05:00:53 --> Router Class Initialized
INFO - 2021-07-28 05:00:53 --> Output Class Initialized
INFO - 2021-07-28 05:00:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:53 --> Input Class Initialized
INFO - 2021-07-28 05:00:53 --> Language Class Initialized
INFO - 2021-07-28 05:00:53 --> Language Class Initialized
INFO - 2021-07-28 05:00:53 --> Config Class Initialized
INFO - 2021-07-28 05:00:53 --> Loader Class Initialized
INFO - 2021-07-28 05:00:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:53 --> Controller Class Initialized
DEBUG - 2021-07-28 05:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:00:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:00:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:53 --> Total execution time: 0.0618
INFO - 2021-07-28 05:00:54 --> Config Class Initialized
INFO - 2021-07-28 05:00:54 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:54 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:54 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:54 --> URI Class Initialized
INFO - 2021-07-28 05:00:54 --> Router Class Initialized
INFO - 2021-07-28 05:00:54 --> Output Class Initialized
INFO - 2021-07-28 05:00:54 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:54 --> Input Class Initialized
INFO - 2021-07-28 05:00:54 --> Language Class Initialized
INFO - 2021-07-28 05:00:55 --> Language Class Initialized
INFO - 2021-07-28 05:00:55 --> Config Class Initialized
INFO - 2021-07-28 05:00:55 --> Loader Class Initialized
INFO - 2021-07-28 05:00:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:55 --> Controller Class Initialized
DEBUG - 2021-07-28 05:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:00:55 --> Final output sent to browser
DEBUG - 2021-07-28 05:00:55 --> Total execution time: 0.0658
INFO - 2021-07-28 05:00:55 --> Config Class Initialized
INFO - 2021-07-28 05:00:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:00:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:00:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:00:55 --> URI Class Initialized
INFO - 2021-07-28 05:00:55 --> Router Class Initialized
INFO - 2021-07-28 05:00:55 --> Output Class Initialized
INFO - 2021-07-28 05:00:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:00:55 --> Input Class Initialized
INFO - 2021-07-28 05:00:55 --> Language Class Initialized
INFO - 2021-07-28 05:00:55 --> Language Class Initialized
INFO - 2021-07-28 05:00:55 --> Config Class Initialized
INFO - 2021-07-28 05:00:55 --> Loader Class Initialized
INFO - 2021-07-28 05:00:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:00:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:00:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:00:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:00:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:00:55 --> Controller Class Initialized
INFO - 2021-07-28 05:01:02 --> Config Class Initialized
INFO - 2021-07-28 05:01:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:02 --> URI Class Initialized
INFO - 2021-07-28 05:01:02 --> Router Class Initialized
INFO - 2021-07-28 05:01:02 --> Output Class Initialized
INFO - 2021-07-28 05:01:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:02 --> Input Class Initialized
INFO - 2021-07-28 05:01:02 --> Language Class Initialized
INFO - 2021-07-28 05:01:02 --> Language Class Initialized
INFO - 2021-07-28 05:01:02 --> Config Class Initialized
INFO - 2021-07-28 05:01:02 --> Loader Class Initialized
INFO - 2021-07-28 05:01:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:02 --> Controller Class Initialized
INFO - 2021-07-28 05:01:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:02 --> Total execution time: 0.1076
INFO - 2021-07-28 05:01:09 --> Config Class Initialized
INFO - 2021-07-28 05:01:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:09 --> URI Class Initialized
INFO - 2021-07-28 05:01:09 --> Router Class Initialized
INFO - 2021-07-28 05:01:09 --> Output Class Initialized
INFO - 2021-07-28 05:01:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:09 --> Input Class Initialized
INFO - 2021-07-28 05:01:09 --> Language Class Initialized
INFO - 2021-07-28 05:01:09 --> Language Class Initialized
INFO - 2021-07-28 05:01:09 --> Config Class Initialized
INFO - 2021-07-28 05:01:09 --> Loader Class Initialized
INFO - 2021-07-28 05:01:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:09 --> Controller Class Initialized
DEBUG - 2021-07-28 05:01:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:01:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:01:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:09 --> Total execution time: 0.0662
INFO - 2021-07-28 05:01:13 --> Config Class Initialized
INFO - 2021-07-28 05:01:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:13 --> URI Class Initialized
INFO - 2021-07-28 05:01:13 --> Router Class Initialized
INFO - 2021-07-28 05:01:13 --> Output Class Initialized
INFO - 2021-07-28 05:01:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:13 --> Input Class Initialized
INFO - 2021-07-28 05:01:13 --> Language Class Initialized
INFO - 2021-07-28 05:01:13 --> Language Class Initialized
INFO - 2021-07-28 05:01:13 --> Config Class Initialized
INFO - 2021-07-28 05:01:13 --> Loader Class Initialized
INFO - 2021-07-28 05:01:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:13 --> Controller Class Initialized
DEBUG - 2021-07-28 05:01:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:01:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:01:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:13 --> Total execution time: 0.0460
INFO - 2021-07-28 05:01:13 --> Config Class Initialized
INFO - 2021-07-28 05:01:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:13 --> URI Class Initialized
INFO - 2021-07-28 05:01:13 --> Router Class Initialized
INFO - 2021-07-28 05:01:13 --> Output Class Initialized
INFO - 2021-07-28 05:01:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:13 --> Input Class Initialized
INFO - 2021-07-28 05:01:13 --> Language Class Initialized
INFO - 2021-07-28 05:01:13 --> Language Class Initialized
INFO - 2021-07-28 05:01:13 --> Config Class Initialized
INFO - 2021-07-28 05:01:13 --> Loader Class Initialized
INFO - 2021-07-28 05:01:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:13 --> Controller Class Initialized
INFO - 2021-07-28 05:01:14 --> Config Class Initialized
INFO - 2021-07-28 05:01:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:14 --> URI Class Initialized
INFO - 2021-07-28 05:01:14 --> Router Class Initialized
INFO - 2021-07-28 05:01:14 --> Output Class Initialized
INFO - 2021-07-28 05:01:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:14 --> Input Class Initialized
INFO - 2021-07-28 05:01:14 --> Language Class Initialized
INFO - 2021-07-28 05:01:14 --> Language Class Initialized
INFO - 2021-07-28 05:01:14 --> Config Class Initialized
INFO - 2021-07-28 05:01:14 --> Loader Class Initialized
INFO - 2021-07-28 05:01:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:14 --> Controller Class Initialized
INFO - 2021-07-28 05:01:14 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:14 --> Total execution time: 0.0627
INFO - 2021-07-28 05:01:20 --> Config Class Initialized
INFO - 2021-07-28 05:01:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:20 --> URI Class Initialized
INFO - 2021-07-28 05:01:20 --> Router Class Initialized
INFO - 2021-07-28 05:01:20 --> Output Class Initialized
INFO - 2021-07-28 05:01:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:20 --> Input Class Initialized
INFO - 2021-07-28 05:01:20 --> Language Class Initialized
INFO - 2021-07-28 05:01:20 --> Language Class Initialized
INFO - 2021-07-28 05:01:20 --> Config Class Initialized
INFO - 2021-07-28 05:01:20 --> Loader Class Initialized
INFO - 2021-07-28 05:01:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:20 --> Controller Class Initialized
INFO - 2021-07-28 05:01:21 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:21 --> Total execution time: 0.8929
INFO - 2021-07-28 05:01:25 --> Config Class Initialized
INFO - 2021-07-28 05:01:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:25 --> URI Class Initialized
INFO - 2021-07-28 05:01:25 --> Router Class Initialized
INFO - 2021-07-28 05:01:25 --> Output Class Initialized
INFO - 2021-07-28 05:01:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:25 --> Input Class Initialized
INFO - 2021-07-28 05:01:25 --> Language Class Initialized
INFO - 2021-07-28 05:01:25 --> Language Class Initialized
INFO - 2021-07-28 05:01:25 --> Config Class Initialized
INFO - 2021-07-28 05:01:25 --> Loader Class Initialized
INFO - 2021-07-28 05:01:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:25 --> Controller Class Initialized
INFO - 2021-07-28 05:01:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:25 --> Total execution time: 0.0595
INFO - 2021-07-28 05:01:30 --> Config Class Initialized
INFO - 2021-07-28 05:01:30 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:30 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:30 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:30 --> URI Class Initialized
INFO - 2021-07-28 05:01:30 --> Router Class Initialized
INFO - 2021-07-28 05:01:30 --> Output Class Initialized
INFO - 2021-07-28 05:01:30 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:30 --> Input Class Initialized
INFO - 2021-07-28 05:01:30 --> Language Class Initialized
INFO - 2021-07-28 05:01:30 --> Language Class Initialized
INFO - 2021-07-28 05:01:30 --> Config Class Initialized
INFO - 2021-07-28 05:01:30 --> Loader Class Initialized
INFO - 2021-07-28 05:01:30 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:30 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:30 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:30 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:30 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:30 --> Controller Class Initialized
INFO - 2021-07-28 05:01:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:31 --> Total execution time: 0.9567
INFO - 2021-07-28 05:01:32 --> Config Class Initialized
INFO - 2021-07-28 05:01:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:32 --> URI Class Initialized
INFO - 2021-07-28 05:01:32 --> Router Class Initialized
INFO - 2021-07-28 05:01:32 --> Output Class Initialized
INFO - 2021-07-28 05:01:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:32 --> Input Class Initialized
INFO - 2021-07-28 05:01:32 --> Language Class Initialized
INFO - 2021-07-28 05:01:32 --> Language Class Initialized
INFO - 2021-07-28 05:01:32 --> Config Class Initialized
INFO - 2021-07-28 05:01:32 --> Loader Class Initialized
INFO - 2021-07-28 05:01:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:32 --> Controller Class Initialized
INFO - 2021-07-28 05:01:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:32 --> Total execution time: 0.0795
INFO - 2021-07-28 05:01:37 --> Config Class Initialized
INFO - 2021-07-28 05:01:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:37 --> URI Class Initialized
INFO - 2021-07-28 05:01:37 --> Router Class Initialized
INFO - 2021-07-28 05:01:37 --> Output Class Initialized
INFO - 2021-07-28 05:01:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:37 --> Input Class Initialized
INFO - 2021-07-28 05:01:37 --> Language Class Initialized
INFO - 2021-07-28 05:01:37 --> Language Class Initialized
INFO - 2021-07-28 05:01:37 --> Config Class Initialized
INFO - 2021-07-28 05:01:37 --> Loader Class Initialized
INFO - 2021-07-28 05:01:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:37 --> Controller Class Initialized
INFO - 2021-07-28 05:01:38 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:38 --> Total execution time: 0.9013
INFO - 2021-07-28 05:01:39 --> Config Class Initialized
INFO - 2021-07-28 05:01:39 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:39 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:39 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:39 --> URI Class Initialized
INFO - 2021-07-28 05:01:39 --> Router Class Initialized
INFO - 2021-07-28 05:01:39 --> Output Class Initialized
INFO - 2021-07-28 05:01:39 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:39 --> Input Class Initialized
INFO - 2021-07-28 05:01:39 --> Language Class Initialized
INFO - 2021-07-28 05:01:39 --> Language Class Initialized
INFO - 2021-07-28 05:01:39 --> Config Class Initialized
INFO - 2021-07-28 05:01:39 --> Loader Class Initialized
INFO - 2021-07-28 05:01:39 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:39 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:39 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:39 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:39 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:39 --> Controller Class Initialized
INFO - 2021-07-28 05:01:39 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:39 --> Total execution time: 0.0560
INFO - 2021-07-28 05:01:45 --> Config Class Initialized
INFO - 2021-07-28 05:01:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:45 --> URI Class Initialized
INFO - 2021-07-28 05:01:45 --> Router Class Initialized
INFO - 2021-07-28 05:01:45 --> Output Class Initialized
INFO - 2021-07-28 05:01:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:45 --> Input Class Initialized
INFO - 2021-07-28 05:01:45 --> Language Class Initialized
INFO - 2021-07-28 05:01:45 --> Language Class Initialized
INFO - 2021-07-28 05:01:45 --> Config Class Initialized
INFO - 2021-07-28 05:01:45 --> Loader Class Initialized
INFO - 2021-07-28 05:01:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:45 --> Controller Class Initialized
INFO - 2021-07-28 05:01:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:46 --> Total execution time: 0.8636
INFO - 2021-07-28 05:01:47 --> Config Class Initialized
INFO - 2021-07-28 05:01:47 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:47 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:47 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:47 --> URI Class Initialized
INFO - 2021-07-28 05:01:47 --> Router Class Initialized
INFO - 2021-07-28 05:01:47 --> Output Class Initialized
INFO - 2021-07-28 05:01:47 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:47 --> Input Class Initialized
INFO - 2021-07-28 05:01:47 --> Language Class Initialized
INFO - 2021-07-28 05:01:47 --> Language Class Initialized
INFO - 2021-07-28 05:01:47 --> Config Class Initialized
INFO - 2021-07-28 05:01:47 --> Loader Class Initialized
INFO - 2021-07-28 05:01:47 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:47 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:47 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:47 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:47 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:47 --> Controller Class Initialized
INFO - 2021-07-28 05:01:47 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:47 --> Total execution time: 0.0575
INFO - 2021-07-28 05:01:52 --> Config Class Initialized
INFO - 2021-07-28 05:01:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:52 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:52 --> URI Class Initialized
INFO - 2021-07-28 05:01:52 --> Router Class Initialized
INFO - 2021-07-28 05:01:52 --> Output Class Initialized
INFO - 2021-07-28 05:01:52 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:52 --> Input Class Initialized
INFO - 2021-07-28 05:01:52 --> Language Class Initialized
INFO - 2021-07-28 05:01:52 --> Language Class Initialized
INFO - 2021-07-28 05:01:52 --> Config Class Initialized
INFO - 2021-07-28 05:01:52 --> Loader Class Initialized
INFO - 2021-07-28 05:01:52 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:52 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:52 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:52 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:52 --> Controller Class Initialized
INFO - 2021-07-28 05:01:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:53 --> Total execution time: 0.9195
INFO - 2021-07-28 05:01:59 --> Config Class Initialized
INFO - 2021-07-28 05:01:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:01:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:01:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:01:59 --> URI Class Initialized
INFO - 2021-07-28 05:01:59 --> Router Class Initialized
INFO - 2021-07-28 05:01:59 --> Output Class Initialized
INFO - 2021-07-28 05:01:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:01:59 --> Input Class Initialized
INFO - 2021-07-28 05:01:59 --> Language Class Initialized
INFO - 2021-07-28 05:01:59 --> Language Class Initialized
INFO - 2021-07-28 05:01:59 --> Config Class Initialized
INFO - 2021-07-28 05:01:59 --> Loader Class Initialized
INFO - 2021-07-28 05:01:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:01:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:01:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:01:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:01:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:01:59 --> Controller Class Initialized
INFO - 2021-07-28 05:01:59 --> Final output sent to browser
DEBUG - 2021-07-28 05:01:59 --> Total execution time: 0.0951
INFO - 2021-07-28 05:02:06 --> Config Class Initialized
INFO - 2021-07-28 05:02:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:06 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:06 --> URI Class Initialized
INFO - 2021-07-28 05:02:06 --> Router Class Initialized
INFO - 2021-07-28 05:02:06 --> Output Class Initialized
INFO - 2021-07-28 05:02:06 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:06 --> Input Class Initialized
INFO - 2021-07-28 05:02:06 --> Language Class Initialized
INFO - 2021-07-28 05:02:06 --> Language Class Initialized
INFO - 2021-07-28 05:02:06 --> Config Class Initialized
INFO - 2021-07-28 05:02:06 --> Loader Class Initialized
INFO - 2021-07-28 05:02:06 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:06 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:06 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:06 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:06 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:06 --> Controller Class Initialized
DEBUG - 2021-07-28 05:02:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:02:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:02:06 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:06 --> Total execution time: 0.0644
INFO - 2021-07-28 05:02:07 --> Config Class Initialized
INFO - 2021-07-28 05:02:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:07 --> URI Class Initialized
INFO - 2021-07-28 05:02:07 --> Router Class Initialized
INFO - 2021-07-28 05:02:07 --> Output Class Initialized
INFO - 2021-07-28 05:02:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:07 --> Input Class Initialized
INFO - 2021-07-28 05:02:07 --> Language Class Initialized
INFO - 2021-07-28 05:02:07 --> Language Class Initialized
INFO - 2021-07-28 05:02:07 --> Config Class Initialized
INFO - 2021-07-28 05:02:07 --> Loader Class Initialized
INFO - 2021-07-28 05:02:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:07 --> Controller Class Initialized
DEBUG - 2021-07-28 05:02:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:02:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:02:07 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:07 --> Total execution time: 0.1147
INFO - 2021-07-28 05:02:09 --> Config Class Initialized
INFO - 2021-07-28 05:02:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:09 --> URI Class Initialized
INFO - 2021-07-28 05:02:09 --> Router Class Initialized
INFO - 2021-07-28 05:02:09 --> Output Class Initialized
INFO - 2021-07-28 05:02:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:09 --> Input Class Initialized
INFO - 2021-07-28 05:02:09 --> Language Class Initialized
INFO - 2021-07-28 05:02:09 --> Language Class Initialized
INFO - 2021-07-28 05:02:09 --> Config Class Initialized
INFO - 2021-07-28 05:02:09 --> Loader Class Initialized
INFO - 2021-07-28 05:02:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:09 --> Controller Class Initialized
INFO - 2021-07-28 05:02:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:09 --> Total execution time: 0.1078
INFO - 2021-07-28 05:02:14 --> Config Class Initialized
INFO - 2021-07-28 05:02:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:14 --> URI Class Initialized
INFO - 2021-07-28 05:02:14 --> Router Class Initialized
INFO - 2021-07-28 05:02:14 --> Output Class Initialized
INFO - 2021-07-28 05:02:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:14 --> Input Class Initialized
INFO - 2021-07-28 05:02:14 --> Language Class Initialized
INFO - 2021-07-28 05:02:14 --> Language Class Initialized
INFO - 2021-07-28 05:02:14 --> Config Class Initialized
INFO - 2021-07-28 05:02:14 --> Loader Class Initialized
INFO - 2021-07-28 05:02:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:14 --> Controller Class Initialized
INFO - 2021-07-28 05:02:15 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:15 --> Total execution time: 0.8087
INFO - 2021-07-28 05:02:17 --> Config Class Initialized
INFO - 2021-07-28 05:02:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:17 --> URI Class Initialized
INFO - 2021-07-28 05:02:17 --> Router Class Initialized
INFO - 2021-07-28 05:02:17 --> Output Class Initialized
INFO - 2021-07-28 05:02:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:17 --> Input Class Initialized
INFO - 2021-07-28 05:02:17 --> Language Class Initialized
INFO - 2021-07-28 05:02:17 --> Language Class Initialized
INFO - 2021-07-28 05:02:17 --> Config Class Initialized
INFO - 2021-07-28 05:02:17 --> Loader Class Initialized
INFO - 2021-07-28 05:02:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:17 --> Controller Class Initialized
INFO - 2021-07-28 05:02:17 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:17 --> Total execution time: 0.0694
INFO - 2021-07-28 05:02:22 --> Config Class Initialized
INFO - 2021-07-28 05:02:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:22 --> URI Class Initialized
INFO - 2021-07-28 05:02:22 --> Router Class Initialized
INFO - 2021-07-28 05:02:22 --> Output Class Initialized
INFO - 2021-07-28 05:02:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:22 --> Input Class Initialized
INFO - 2021-07-28 05:02:22 --> Language Class Initialized
INFO - 2021-07-28 05:02:22 --> Language Class Initialized
INFO - 2021-07-28 05:02:22 --> Config Class Initialized
INFO - 2021-07-28 05:02:22 --> Loader Class Initialized
INFO - 2021-07-28 05:02:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:22 --> Controller Class Initialized
INFO - 2021-07-28 05:02:23 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:23 --> Total execution time: 0.7524
INFO - 2021-07-28 05:02:24 --> Config Class Initialized
INFO - 2021-07-28 05:02:24 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:24 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:24 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:24 --> URI Class Initialized
INFO - 2021-07-28 05:02:24 --> Router Class Initialized
INFO - 2021-07-28 05:02:24 --> Output Class Initialized
INFO - 2021-07-28 05:02:24 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:24 --> Input Class Initialized
INFO - 2021-07-28 05:02:24 --> Language Class Initialized
INFO - 2021-07-28 05:02:24 --> Language Class Initialized
INFO - 2021-07-28 05:02:24 --> Config Class Initialized
INFO - 2021-07-28 05:02:24 --> Loader Class Initialized
INFO - 2021-07-28 05:02:24 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:24 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:24 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:24 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:24 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:24 --> Controller Class Initialized
INFO - 2021-07-28 05:02:24 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:24 --> Total execution time: 0.1042
INFO - 2021-07-28 05:02:32 --> Config Class Initialized
INFO - 2021-07-28 05:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:32 --> URI Class Initialized
INFO - 2021-07-28 05:02:32 --> Router Class Initialized
INFO - 2021-07-28 05:02:32 --> Output Class Initialized
INFO - 2021-07-28 05:02:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:32 --> Input Class Initialized
INFO - 2021-07-28 05:02:32 --> Language Class Initialized
INFO - 2021-07-28 05:02:32 --> Language Class Initialized
INFO - 2021-07-28 05:02:32 --> Config Class Initialized
INFO - 2021-07-28 05:02:32 --> Loader Class Initialized
INFO - 2021-07-28 05:02:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:32 --> Controller Class Initialized
INFO - 2021-07-28 05:02:33 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:33 --> Total execution time: 0.7963
INFO - 2021-07-28 05:02:35 --> Config Class Initialized
INFO - 2021-07-28 05:02:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:35 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:35 --> URI Class Initialized
INFO - 2021-07-28 05:02:35 --> Router Class Initialized
INFO - 2021-07-28 05:02:35 --> Output Class Initialized
INFO - 2021-07-28 05:02:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:35 --> Input Class Initialized
INFO - 2021-07-28 05:02:35 --> Language Class Initialized
INFO - 2021-07-28 05:02:35 --> Language Class Initialized
INFO - 2021-07-28 05:02:35 --> Config Class Initialized
INFO - 2021-07-28 05:02:35 --> Loader Class Initialized
INFO - 2021-07-28 05:02:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:35 --> Controller Class Initialized
DEBUG - 2021-07-28 05:02:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:02:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:02:35 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:35 --> Total execution time: 0.0595
INFO - 2021-07-28 05:02:40 --> Config Class Initialized
INFO - 2021-07-28 05:02:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:40 --> URI Class Initialized
INFO - 2021-07-28 05:02:40 --> Router Class Initialized
INFO - 2021-07-28 05:02:40 --> Output Class Initialized
INFO - 2021-07-28 05:02:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:40 --> Input Class Initialized
INFO - 2021-07-28 05:02:40 --> Language Class Initialized
INFO - 2021-07-28 05:02:40 --> Language Class Initialized
INFO - 2021-07-28 05:02:40 --> Config Class Initialized
INFO - 2021-07-28 05:02:40 --> Loader Class Initialized
INFO - 2021-07-28 05:02:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:40 --> Controller Class Initialized
DEBUG - 2021-07-28 05:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:02:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:40 --> Total execution time: 0.0595
INFO - 2021-07-28 05:02:40 --> Config Class Initialized
INFO - 2021-07-28 05:02:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:40 --> URI Class Initialized
INFO - 2021-07-28 05:02:40 --> Router Class Initialized
INFO - 2021-07-28 05:02:40 --> Output Class Initialized
INFO - 2021-07-28 05:02:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:40 --> Input Class Initialized
INFO - 2021-07-28 05:02:40 --> Language Class Initialized
INFO - 2021-07-28 05:02:40 --> Language Class Initialized
INFO - 2021-07-28 05:02:40 --> Config Class Initialized
INFO - 2021-07-28 05:02:40 --> Loader Class Initialized
INFO - 2021-07-28 05:02:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:40 --> Controller Class Initialized
INFO - 2021-07-28 05:02:43 --> Config Class Initialized
INFO - 2021-07-28 05:02:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:43 --> URI Class Initialized
INFO - 2021-07-28 05:02:43 --> Router Class Initialized
INFO - 2021-07-28 05:02:43 --> Output Class Initialized
INFO - 2021-07-28 05:02:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:43 --> Input Class Initialized
INFO - 2021-07-28 05:02:43 --> Language Class Initialized
INFO - 2021-07-28 05:02:43 --> Language Class Initialized
INFO - 2021-07-28 05:02:43 --> Config Class Initialized
INFO - 2021-07-28 05:02:43 --> Loader Class Initialized
INFO - 2021-07-28 05:02:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:43 --> Controller Class Initialized
INFO - 2021-07-28 05:02:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:43 --> Total execution time: 0.1078
INFO - 2021-07-28 05:02:47 --> Config Class Initialized
INFO - 2021-07-28 05:02:47 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:47 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:47 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:47 --> URI Class Initialized
INFO - 2021-07-28 05:02:47 --> Router Class Initialized
INFO - 2021-07-28 05:02:47 --> Output Class Initialized
INFO - 2021-07-28 05:02:47 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:47 --> Input Class Initialized
INFO - 2021-07-28 05:02:47 --> Language Class Initialized
INFO - 2021-07-28 05:02:47 --> Language Class Initialized
INFO - 2021-07-28 05:02:47 --> Config Class Initialized
INFO - 2021-07-28 05:02:47 --> Loader Class Initialized
INFO - 2021-07-28 05:02:47 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:47 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:47 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:47 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:47 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:47 --> Controller Class Initialized
INFO - 2021-07-28 05:02:48 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:48 --> Total execution time: 0.0462
INFO - 2021-07-28 05:02:52 --> Config Class Initialized
INFO - 2021-07-28 05:02:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:52 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:52 --> URI Class Initialized
INFO - 2021-07-28 05:02:52 --> Router Class Initialized
INFO - 2021-07-28 05:02:52 --> Output Class Initialized
INFO - 2021-07-28 05:02:52 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:52 --> Input Class Initialized
INFO - 2021-07-28 05:02:52 --> Language Class Initialized
INFO - 2021-07-28 05:02:52 --> Language Class Initialized
INFO - 2021-07-28 05:02:52 --> Config Class Initialized
INFO - 2021-07-28 05:02:52 --> Loader Class Initialized
INFO - 2021-07-28 05:02:52 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:52 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:52 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:52 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:52 --> Controller Class Initialized
INFO - 2021-07-28 05:02:52 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:52 --> Total execution time: 0.0583
INFO - 2021-07-28 05:02:55 --> Config Class Initialized
INFO - 2021-07-28 05:02:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:55 --> URI Class Initialized
INFO - 2021-07-28 05:02:55 --> Router Class Initialized
INFO - 2021-07-28 05:02:55 --> Output Class Initialized
INFO - 2021-07-28 05:02:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:55 --> Input Class Initialized
INFO - 2021-07-28 05:02:55 --> Language Class Initialized
INFO - 2021-07-28 05:02:55 --> Language Class Initialized
INFO - 2021-07-28 05:02:55 --> Config Class Initialized
INFO - 2021-07-28 05:02:55 --> Loader Class Initialized
INFO - 2021-07-28 05:02:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:55 --> Controller Class Initialized
INFO - 2021-07-28 05:02:55 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:55 --> Total execution time: 0.0601
INFO - 2021-07-28 05:02:59 --> Config Class Initialized
INFO - 2021-07-28 05:02:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:02:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:02:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:02:59 --> URI Class Initialized
INFO - 2021-07-28 05:02:59 --> Router Class Initialized
INFO - 2021-07-28 05:02:59 --> Output Class Initialized
INFO - 2021-07-28 05:02:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:02:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:02:59 --> Input Class Initialized
INFO - 2021-07-28 05:02:59 --> Language Class Initialized
INFO - 2021-07-28 05:02:59 --> Language Class Initialized
INFO - 2021-07-28 05:02:59 --> Config Class Initialized
INFO - 2021-07-28 05:02:59 --> Loader Class Initialized
INFO - 2021-07-28 05:02:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:02:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:02:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:02:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:02:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:02:59 --> Controller Class Initialized
INFO - 2021-07-28 05:02:59 --> Final output sent to browser
DEBUG - 2021-07-28 05:02:59 --> Total execution time: 0.0533
INFO - 2021-07-28 05:03:03 --> Config Class Initialized
INFO - 2021-07-28 05:03:03 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:03 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:03 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:03 --> URI Class Initialized
INFO - 2021-07-28 05:03:03 --> Router Class Initialized
INFO - 2021-07-28 05:03:03 --> Output Class Initialized
INFO - 2021-07-28 05:03:03 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:03 --> Input Class Initialized
INFO - 2021-07-28 05:03:03 --> Language Class Initialized
INFO - 2021-07-28 05:03:03 --> Language Class Initialized
INFO - 2021-07-28 05:03:03 --> Config Class Initialized
INFO - 2021-07-28 05:03:03 --> Loader Class Initialized
INFO - 2021-07-28 05:03:03 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:03 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:03 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:03 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:03 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:03 --> Controller Class Initialized
INFO - 2021-07-28 05:03:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:03 --> Total execution time: 0.0427
INFO - 2021-07-28 05:03:08 --> Config Class Initialized
INFO - 2021-07-28 05:03:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:08 --> URI Class Initialized
INFO - 2021-07-28 05:03:08 --> Router Class Initialized
INFO - 2021-07-28 05:03:08 --> Output Class Initialized
INFO - 2021-07-28 05:03:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:08 --> Input Class Initialized
INFO - 2021-07-28 05:03:08 --> Language Class Initialized
INFO - 2021-07-28 05:03:08 --> Language Class Initialized
INFO - 2021-07-28 05:03:08 --> Config Class Initialized
INFO - 2021-07-28 05:03:08 --> Loader Class Initialized
INFO - 2021-07-28 05:03:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:08 --> Controller Class Initialized
INFO - 2021-07-28 05:03:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:10 --> Total execution time: 2.1714
INFO - 2021-07-28 05:03:11 --> Config Class Initialized
INFO - 2021-07-28 05:03:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:11 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:11 --> URI Class Initialized
INFO - 2021-07-28 05:03:11 --> Router Class Initialized
INFO - 2021-07-28 05:03:11 --> Output Class Initialized
INFO - 2021-07-28 05:03:11 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:11 --> Input Class Initialized
INFO - 2021-07-28 05:03:11 --> Language Class Initialized
INFO - 2021-07-28 05:03:11 --> Language Class Initialized
INFO - 2021-07-28 05:03:11 --> Config Class Initialized
INFO - 2021-07-28 05:03:11 --> Loader Class Initialized
INFO - 2021-07-28 05:03:11 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:11 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:11 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:11 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:11 --> Controller Class Initialized
DEBUG - 2021-07-28 05:03:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:03:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:03:11 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:11 --> Total execution time: 0.0684
INFO - 2021-07-28 05:03:13 --> Config Class Initialized
INFO - 2021-07-28 05:03:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:13 --> URI Class Initialized
INFO - 2021-07-28 05:03:13 --> Router Class Initialized
INFO - 2021-07-28 05:03:13 --> Output Class Initialized
INFO - 2021-07-28 05:03:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:13 --> Input Class Initialized
INFO - 2021-07-28 05:03:13 --> Language Class Initialized
INFO - 2021-07-28 05:03:13 --> Language Class Initialized
INFO - 2021-07-28 05:03:13 --> Config Class Initialized
INFO - 2021-07-28 05:03:13 --> Loader Class Initialized
INFO - 2021-07-28 05:03:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:13 --> Controller Class Initialized
DEBUG - 2021-07-28 05:03:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:03:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:03:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:13 --> Total execution time: 0.0581
INFO - 2021-07-28 05:03:16 --> Config Class Initialized
INFO - 2021-07-28 05:03:16 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:16 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:16 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:16 --> URI Class Initialized
INFO - 2021-07-28 05:03:16 --> Router Class Initialized
INFO - 2021-07-28 05:03:16 --> Output Class Initialized
INFO - 2021-07-28 05:03:16 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:16 --> Input Class Initialized
INFO - 2021-07-28 05:03:16 --> Language Class Initialized
INFO - 2021-07-28 05:03:16 --> Language Class Initialized
INFO - 2021-07-28 05:03:16 --> Config Class Initialized
INFO - 2021-07-28 05:03:16 --> Loader Class Initialized
INFO - 2021-07-28 05:03:16 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:16 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:16 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:16 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:16 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:16 --> Controller Class Initialized
INFO - 2021-07-28 05:03:16 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:16 --> Total execution time: 0.1032
INFO - 2021-07-28 05:03:20 --> Config Class Initialized
INFO - 2021-07-28 05:03:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:20 --> URI Class Initialized
INFO - 2021-07-28 05:03:20 --> Router Class Initialized
INFO - 2021-07-28 05:03:20 --> Output Class Initialized
INFO - 2021-07-28 05:03:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:20 --> Input Class Initialized
INFO - 2021-07-28 05:03:20 --> Language Class Initialized
INFO - 2021-07-28 05:03:20 --> Language Class Initialized
INFO - 2021-07-28 05:03:20 --> Config Class Initialized
INFO - 2021-07-28 05:03:20 --> Loader Class Initialized
INFO - 2021-07-28 05:03:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:20 --> Controller Class Initialized
INFO - 2021-07-28 05:03:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:20 --> Total execution time: 0.0652
INFO - 2021-07-28 05:03:22 --> Config Class Initialized
INFO - 2021-07-28 05:03:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:22 --> URI Class Initialized
INFO - 2021-07-28 05:03:22 --> Router Class Initialized
INFO - 2021-07-28 05:03:22 --> Output Class Initialized
INFO - 2021-07-28 05:03:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:22 --> Input Class Initialized
INFO - 2021-07-28 05:03:22 --> Language Class Initialized
INFO - 2021-07-28 05:03:22 --> Language Class Initialized
INFO - 2021-07-28 05:03:22 --> Config Class Initialized
INFO - 2021-07-28 05:03:22 --> Loader Class Initialized
INFO - 2021-07-28 05:03:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:22 --> Controller Class Initialized
INFO - 2021-07-28 05:03:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:22 --> Total execution time: 0.0609
INFO - 2021-07-28 05:03:25 --> Config Class Initialized
INFO - 2021-07-28 05:03:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:25 --> URI Class Initialized
INFO - 2021-07-28 05:03:25 --> Router Class Initialized
INFO - 2021-07-28 05:03:25 --> Output Class Initialized
INFO - 2021-07-28 05:03:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:25 --> Input Class Initialized
INFO - 2021-07-28 05:03:25 --> Language Class Initialized
INFO - 2021-07-28 05:03:25 --> Language Class Initialized
INFO - 2021-07-28 05:03:25 --> Config Class Initialized
INFO - 2021-07-28 05:03:25 --> Loader Class Initialized
INFO - 2021-07-28 05:03:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:25 --> Controller Class Initialized
INFO - 2021-07-28 05:03:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:25 --> Total execution time: 0.0622
INFO - 2021-07-28 05:03:29 --> Config Class Initialized
INFO - 2021-07-28 05:03:29 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:29 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:29 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:29 --> URI Class Initialized
INFO - 2021-07-28 05:03:29 --> Router Class Initialized
INFO - 2021-07-28 05:03:29 --> Output Class Initialized
INFO - 2021-07-28 05:03:29 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:29 --> Input Class Initialized
INFO - 2021-07-28 05:03:29 --> Language Class Initialized
INFO - 2021-07-28 05:03:29 --> Language Class Initialized
INFO - 2021-07-28 05:03:29 --> Config Class Initialized
INFO - 2021-07-28 05:03:29 --> Loader Class Initialized
INFO - 2021-07-28 05:03:29 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:29 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:29 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:29 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:29 --> Controller Class Initialized
DEBUG - 2021-07-28 05:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:03:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:03:29 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:29 --> Total execution time: 0.0642
INFO - 2021-07-28 05:03:33 --> Config Class Initialized
INFO - 2021-07-28 05:03:33 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:33 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:33 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:33 --> URI Class Initialized
INFO - 2021-07-28 05:03:33 --> Router Class Initialized
INFO - 2021-07-28 05:03:33 --> Output Class Initialized
INFO - 2021-07-28 05:03:33 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:33 --> Input Class Initialized
INFO - 2021-07-28 05:03:33 --> Language Class Initialized
INFO - 2021-07-28 05:03:33 --> Language Class Initialized
INFO - 2021-07-28 05:03:33 --> Config Class Initialized
INFO - 2021-07-28 05:03:33 --> Loader Class Initialized
INFO - 2021-07-28 05:03:33 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:33 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:33 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:33 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:33 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:33 --> Controller Class Initialized
INFO - 2021-07-28 05:03:33 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:03:33 --> Config Class Initialized
INFO - 2021-07-28 05:03:33 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:33 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:33 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:33 --> URI Class Initialized
INFO - 2021-07-28 05:03:33 --> Router Class Initialized
INFO - 2021-07-28 05:03:33 --> Output Class Initialized
INFO - 2021-07-28 05:03:33 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:33 --> Input Class Initialized
INFO - 2021-07-28 05:03:33 --> Language Class Initialized
INFO - 2021-07-28 05:03:33 --> Language Class Initialized
INFO - 2021-07-28 05:03:33 --> Config Class Initialized
INFO - 2021-07-28 05:03:33 --> Loader Class Initialized
INFO - 2021-07-28 05:03:33 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:33 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:33 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:33 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:33 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:33 --> Controller Class Initialized
DEBUG - 2021-07-28 05:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:03:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:03:33 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:33 --> Total execution time: 0.0558
INFO - 2021-07-28 05:03:45 --> Config Class Initialized
INFO - 2021-07-28 05:03:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:45 --> URI Class Initialized
INFO - 2021-07-28 05:03:45 --> Router Class Initialized
INFO - 2021-07-28 05:03:45 --> Output Class Initialized
INFO - 2021-07-28 05:03:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:45 --> Input Class Initialized
INFO - 2021-07-28 05:03:45 --> Language Class Initialized
INFO - 2021-07-28 05:03:45 --> Language Class Initialized
INFO - 2021-07-28 05:03:45 --> Config Class Initialized
INFO - 2021-07-28 05:03:45 --> Loader Class Initialized
INFO - 2021-07-28 05:03:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:45 --> Controller Class Initialized
INFO - 2021-07-28 05:03:45 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:03:45 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:45 --> Total execution time: 0.0458
INFO - 2021-07-28 05:03:49 --> Config Class Initialized
INFO - 2021-07-28 05:03:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:49 --> URI Class Initialized
INFO - 2021-07-28 05:03:49 --> Router Class Initialized
INFO - 2021-07-28 05:03:49 --> Output Class Initialized
INFO - 2021-07-28 05:03:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:49 --> Input Class Initialized
INFO - 2021-07-28 05:03:49 --> Language Class Initialized
INFO - 2021-07-28 05:03:49 --> Language Class Initialized
INFO - 2021-07-28 05:03:49 --> Config Class Initialized
INFO - 2021-07-28 05:03:49 --> Loader Class Initialized
INFO - 2021-07-28 05:03:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:49 --> Controller Class Initialized
DEBUG - 2021-07-28 05:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:03:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:50 --> Total execution time: 0.7273
INFO - 2021-07-28 05:03:50 --> Config Class Initialized
INFO - 2021-07-28 05:03:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:50 --> URI Class Initialized
INFO - 2021-07-28 05:03:50 --> Router Class Initialized
INFO - 2021-07-28 05:03:50 --> Output Class Initialized
INFO - 2021-07-28 05:03:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:50 --> Input Class Initialized
INFO - 2021-07-28 05:03:50 --> Language Class Initialized
INFO - 2021-07-28 05:03:50 --> Language Class Initialized
INFO - 2021-07-28 05:03:50 --> Config Class Initialized
INFO - 2021-07-28 05:03:50 --> Loader Class Initialized
INFO - 2021-07-28 05:03:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:50 --> Controller Class Initialized
DEBUG - 2021-07-28 05:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:03:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:50 --> Total execution time: 0.0671
INFO - 2021-07-28 05:03:51 --> Config Class Initialized
INFO - 2021-07-28 05:03:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:51 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:51 --> URI Class Initialized
INFO - 2021-07-28 05:03:51 --> Router Class Initialized
INFO - 2021-07-28 05:03:51 --> Output Class Initialized
INFO - 2021-07-28 05:03:51 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:51 --> Input Class Initialized
INFO - 2021-07-28 05:03:51 --> Language Class Initialized
INFO - 2021-07-28 05:03:51 --> Language Class Initialized
INFO - 2021-07-28 05:03:51 --> Config Class Initialized
INFO - 2021-07-28 05:03:51 --> Loader Class Initialized
INFO - 2021-07-28 05:03:51 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:51 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:51 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:51 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:51 --> Controller Class Initialized
DEBUG - 2021-07-28 05:03:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:03:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:03:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:51 --> Total execution time: 0.0679
INFO - 2021-07-28 05:03:53 --> Config Class Initialized
INFO - 2021-07-28 05:03:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:53 --> URI Class Initialized
INFO - 2021-07-28 05:03:53 --> Router Class Initialized
INFO - 2021-07-28 05:03:53 --> Output Class Initialized
INFO - 2021-07-28 05:03:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:53 --> Input Class Initialized
INFO - 2021-07-28 05:03:53 --> Language Class Initialized
INFO - 2021-07-28 05:03:53 --> Language Class Initialized
INFO - 2021-07-28 05:03:53 --> Config Class Initialized
INFO - 2021-07-28 05:03:53 --> Loader Class Initialized
INFO - 2021-07-28 05:03:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:53 --> Controller Class Initialized
INFO - 2021-07-28 05:03:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:53 --> Total execution time: 0.1043
INFO - 2021-07-28 05:03:57 --> Config Class Initialized
INFO - 2021-07-28 05:03:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:57 --> URI Class Initialized
INFO - 2021-07-28 05:03:57 --> Router Class Initialized
INFO - 2021-07-28 05:03:57 --> Output Class Initialized
INFO - 2021-07-28 05:03:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:57 --> Input Class Initialized
INFO - 2021-07-28 05:03:57 --> Language Class Initialized
INFO - 2021-07-28 05:03:57 --> Language Class Initialized
INFO - 2021-07-28 05:03:57 --> Config Class Initialized
INFO - 2021-07-28 05:03:57 --> Loader Class Initialized
INFO - 2021-07-28 05:03:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:57 --> Controller Class Initialized
INFO - 2021-07-28 05:03:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:58 --> Total execution time: 0.7940
INFO - 2021-07-28 05:03:59 --> Config Class Initialized
INFO - 2021-07-28 05:03:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:03:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:03:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:03:59 --> URI Class Initialized
INFO - 2021-07-28 05:03:59 --> Router Class Initialized
INFO - 2021-07-28 05:03:59 --> Output Class Initialized
INFO - 2021-07-28 05:03:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:03:59 --> Input Class Initialized
INFO - 2021-07-28 05:03:59 --> Language Class Initialized
INFO - 2021-07-28 05:03:59 --> Language Class Initialized
INFO - 2021-07-28 05:03:59 --> Config Class Initialized
INFO - 2021-07-28 05:03:59 --> Loader Class Initialized
INFO - 2021-07-28 05:03:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:03:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:03:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:03:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:03:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:03:59 --> Controller Class Initialized
INFO - 2021-07-28 05:03:59 --> Final output sent to browser
DEBUG - 2021-07-28 05:03:59 --> Total execution time: 0.0565
INFO - 2021-07-28 05:04:04 --> Config Class Initialized
INFO - 2021-07-28 05:04:04 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:04 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:04 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:04 --> URI Class Initialized
INFO - 2021-07-28 05:04:04 --> Router Class Initialized
INFO - 2021-07-28 05:04:04 --> Output Class Initialized
INFO - 2021-07-28 05:04:04 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:04 --> Input Class Initialized
INFO - 2021-07-28 05:04:04 --> Language Class Initialized
INFO - 2021-07-28 05:04:04 --> Language Class Initialized
INFO - 2021-07-28 05:04:04 --> Config Class Initialized
INFO - 2021-07-28 05:04:04 --> Loader Class Initialized
INFO - 2021-07-28 05:04:04 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:04 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:04 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:04 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:04 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:04 --> Controller Class Initialized
INFO - 2021-07-28 05:04:04 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:04 --> Total execution time: 0.8012
INFO - 2021-07-28 05:04:07 --> Config Class Initialized
INFO - 2021-07-28 05:04:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:07 --> URI Class Initialized
INFO - 2021-07-28 05:04:07 --> Router Class Initialized
INFO - 2021-07-28 05:04:07 --> Output Class Initialized
INFO - 2021-07-28 05:04:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:07 --> Input Class Initialized
INFO - 2021-07-28 05:04:07 --> Language Class Initialized
INFO - 2021-07-28 05:04:07 --> Language Class Initialized
INFO - 2021-07-28 05:04:07 --> Config Class Initialized
INFO - 2021-07-28 05:04:07 --> Loader Class Initialized
INFO - 2021-07-28 05:04:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:07 --> Controller Class Initialized
DEBUG - 2021-07-28 05:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:04:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:04:07 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:07 --> Total execution time: 0.0599
INFO - 2021-07-28 05:04:10 --> Config Class Initialized
INFO - 2021-07-28 05:04:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:10 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:10 --> URI Class Initialized
INFO - 2021-07-28 05:04:10 --> Router Class Initialized
INFO - 2021-07-28 05:04:10 --> Output Class Initialized
INFO - 2021-07-28 05:04:10 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:10 --> Input Class Initialized
INFO - 2021-07-28 05:04:10 --> Language Class Initialized
INFO - 2021-07-28 05:04:10 --> Language Class Initialized
INFO - 2021-07-28 05:04:10 --> Config Class Initialized
INFO - 2021-07-28 05:04:10 --> Loader Class Initialized
INFO - 2021-07-28 05:04:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:10 --> Controller Class Initialized
DEBUG - 2021-07-28 05:04:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:04:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:04:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:10 --> Total execution time: 0.0588
INFO - 2021-07-28 05:04:11 --> Config Class Initialized
INFO - 2021-07-28 05:04:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:11 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:11 --> URI Class Initialized
INFO - 2021-07-28 05:04:11 --> Router Class Initialized
INFO - 2021-07-28 05:04:11 --> Output Class Initialized
INFO - 2021-07-28 05:04:11 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:11 --> Input Class Initialized
INFO - 2021-07-28 05:04:11 --> Language Class Initialized
INFO - 2021-07-28 05:04:11 --> Language Class Initialized
INFO - 2021-07-28 05:04:11 --> Config Class Initialized
INFO - 2021-07-28 05:04:11 --> Loader Class Initialized
INFO - 2021-07-28 05:04:11 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:11 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:11 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:11 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:11 --> Controller Class Initialized
INFO - 2021-07-28 05:04:12 --> Config Class Initialized
INFO - 2021-07-28 05:04:12 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:12 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:12 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:12 --> URI Class Initialized
INFO - 2021-07-28 05:04:12 --> Router Class Initialized
INFO - 2021-07-28 05:04:12 --> Output Class Initialized
INFO - 2021-07-28 05:04:12 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:12 --> Input Class Initialized
INFO - 2021-07-28 05:04:12 --> Language Class Initialized
INFO - 2021-07-28 05:04:12 --> Language Class Initialized
INFO - 2021-07-28 05:04:12 --> Config Class Initialized
INFO - 2021-07-28 05:04:12 --> Loader Class Initialized
INFO - 2021-07-28 05:04:12 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:12 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:12 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:12 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:12 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:12 --> Controller Class Initialized
INFO - 2021-07-28 05:04:12 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:12 --> Total execution time: 0.1067
INFO - 2021-07-28 05:04:17 --> Config Class Initialized
INFO - 2021-07-28 05:04:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:17 --> URI Class Initialized
INFO - 2021-07-28 05:04:17 --> Router Class Initialized
INFO - 2021-07-28 05:04:17 --> Output Class Initialized
INFO - 2021-07-28 05:04:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:17 --> Input Class Initialized
INFO - 2021-07-28 05:04:17 --> Language Class Initialized
INFO - 2021-07-28 05:04:17 --> Language Class Initialized
INFO - 2021-07-28 05:04:17 --> Config Class Initialized
INFO - 2021-07-28 05:04:17 --> Loader Class Initialized
INFO - 2021-07-28 05:04:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:17 --> Controller Class Initialized
INFO - 2021-07-28 05:04:17 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:17 --> Total execution time: 0.0601
INFO - 2021-07-28 05:04:20 --> Config Class Initialized
INFO - 2021-07-28 05:04:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:20 --> URI Class Initialized
INFO - 2021-07-28 05:04:20 --> Router Class Initialized
INFO - 2021-07-28 05:04:20 --> Output Class Initialized
INFO - 2021-07-28 05:04:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:20 --> Input Class Initialized
INFO - 2021-07-28 05:04:20 --> Language Class Initialized
INFO - 2021-07-28 05:04:20 --> Language Class Initialized
INFO - 2021-07-28 05:04:20 --> Config Class Initialized
INFO - 2021-07-28 05:04:20 --> Loader Class Initialized
INFO - 2021-07-28 05:04:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:20 --> Controller Class Initialized
INFO - 2021-07-28 05:04:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:20 --> Total execution time: 0.0597
INFO - 2021-07-28 05:04:22 --> Config Class Initialized
INFO - 2021-07-28 05:04:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:22 --> URI Class Initialized
INFO - 2021-07-28 05:04:22 --> Router Class Initialized
INFO - 2021-07-28 05:04:22 --> Output Class Initialized
INFO - 2021-07-28 05:04:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:22 --> Input Class Initialized
INFO - 2021-07-28 05:04:22 --> Language Class Initialized
INFO - 2021-07-28 05:04:22 --> Language Class Initialized
INFO - 2021-07-28 05:04:22 --> Config Class Initialized
INFO - 2021-07-28 05:04:22 --> Loader Class Initialized
INFO - 2021-07-28 05:04:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:22 --> Controller Class Initialized
INFO - 2021-07-28 05:04:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:22 --> Total execution time: 0.0577
INFO - 2021-07-28 05:04:25 --> Config Class Initialized
INFO - 2021-07-28 05:04:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:25 --> URI Class Initialized
INFO - 2021-07-28 05:04:25 --> Router Class Initialized
INFO - 2021-07-28 05:04:25 --> Output Class Initialized
INFO - 2021-07-28 05:04:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:25 --> Input Class Initialized
INFO - 2021-07-28 05:04:25 --> Language Class Initialized
INFO - 2021-07-28 05:04:25 --> Language Class Initialized
INFO - 2021-07-28 05:04:25 --> Config Class Initialized
INFO - 2021-07-28 05:04:25 --> Loader Class Initialized
INFO - 2021-07-28 05:04:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:25 --> Controller Class Initialized
DEBUG - 2021-07-28 05:04:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:04:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:04:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:25 --> Total execution time: 0.0434
INFO - 2021-07-28 05:04:27 --> Config Class Initialized
INFO - 2021-07-28 05:04:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:27 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:27 --> URI Class Initialized
INFO - 2021-07-28 05:04:27 --> Router Class Initialized
INFO - 2021-07-28 05:04:27 --> Output Class Initialized
INFO - 2021-07-28 05:04:27 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:27 --> Input Class Initialized
INFO - 2021-07-28 05:04:27 --> Language Class Initialized
INFO - 2021-07-28 05:04:27 --> Language Class Initialized
INFO - 2021-07-28 05:04:27 --> Config Class Initialized
INFO - 2021-07-28 05:04:27 --> Loader Class Initialized
INFO - 2021-07-28 05:04:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:28 --> Controller Class Initialized
DEBUG - 2021-07-28 05:04:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:04:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:04:28 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:28 --> Total execution time: 0.0559
INFO - 2021-07-28 05:04:29 --> Config Class Initialized
INFO - 2021-07-28 05:04:29 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:29 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:29 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:29 --> URI Class Initialized
INFO - 2021-07-28 05:04:29 --> Router Class Initialized
INFO - 2021-07-28 05:04:29 --> Output Class Initialized
INFO - 2021-07-28 05:04:29 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:29 --> Input Class Initialized
INFO - 2021-07-28 05:04:29 --> Language Class Initialized
INFO - 2021-07-28 05:04:29 --> Language Class Initialized
INFO - 2021-07-28 05:04:29 --> Config Class Initialized
INFO - 2021-07-28 05:04:29 --> Loader Class Initialized
INFO - 2021-07-28 05:04:29 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:29 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:29 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:29 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:29 --> Controller Class Initialized
INFO - 2021-07-28 05:04:29 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:29 --> Total execution time: 0.0771
INFO - 2021-07-28 05:04:37 --> Config Class Initialized
INFO - 2021-07-28 05:04:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:37 --> URI Class Initialized
INFO - 2021-07-28 05:04:37 --> Router Class Initialized
INFO - 2021-07-28 05:04:37 --> Output Class Initialized
INFO - 2021-07-28 05:04:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:37 --> Input Class Initialized
INFO - 2021-07-28 05:04:37 --> Language Class Initialized
INFO - 2021-07-28 05:04:37 --> Language Class Initialized
INFO - 2021-07-28 05:04:37 --> Config Class Initialized
INFO - 2021-07-28 05:04:37 --> Loader Class Initialized
INFO - 2021-07-28 05:04:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:37 --> Controller Class Initialized
INFO - 2021-07-28 05:04:38 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:38 --> Total execution time: 0.9991
INFO - 2021-07-28 05:04:40 --> Config Class Initialized
INFO - 2021-07-28 05:04:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:40 --> URI Class Initialized
INFO - 2021-07-28 05:04:40 --> Router Class Initialized
INFO - 2021-07-28 05:04:40 --> Output Class Initialized
INFO - 2021-07-28 05:04:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:40 --> Input Class Initialized
INFO - 2021-07-28 05:04:40 --> Language Class Initialized
INFO - 2021-07-28 05:04:40 --> Language Class Initialized
INFO - 2021-07-28 05:04:40 --> Config Class Initialized
INFO - 2021-07-28 05:04:40 --> Loader Class Initialized
INFO - 2021-07-28 05:04:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:40 --> Controller Class Initialized
INFO - 2021-07-28 05:04:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:40 --> Total execution time: 0.0762
INFO - 2021-07-28 05:04:44 --> Config Class Initialized
INFO - 2021-07-28 05:04:44 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:44 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:44 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:44 --> URI Class Initialized
INFO - 2021-07-28 05:04:44 --> Router Class Initialized
INFO - 2021-07-28 05:04:44 --> Output Class Initialized
INFO - 2021-07-28 05:04:44 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:44 --> Input Class Initialized
INFO - 2021-07-28 05:04:44 --> Language Class Initialized
INFO - 2021-07-28 05:04:44 --> Language Class Initialized
INFO - 2021-07-28 05:04:44 --> Config Class Initialized
INFO - 2021-07-28 05:04:44 --> Loader Class Initialized
INFO - 2021-07-28 05:04:44 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:44 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:44 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:44 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:44 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:44 --> Controller Class Initialized
INFO - 2021-07-28 05:04:45 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:45 --> Total execution time: 0.9331
INFO - 2021-07-28 05:04:45 --> Config Class Initialized
INFO - 2021-07-28 05:04:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:45 --> URI Class Initialized
INFO - 2021-07-28 05:04:45 --> Router Class Initialized
INFO - 2021-07-28 05:04:45 --> Output Class Initialized
INFO - 2021-07-28 05:04:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:45 --> Input Class Initialized
INFO - 2021-07-28 05:04:45 --> Language Class Initialized
INFO - 2021-07-28 05:04:45 --> Language Class Initialized
INFO - 2021-07-28 05:04:45 --> Config Class Initialized
INFO - 2021-07-28 05:04:45 --> Loader Class Initialized
INFO - 2021-07-28 05:04:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:45 --> Controller Class Initialized
INFO - 2021-07-28 05:04:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:46 --> Total execution time: 0.9401
INFO - 2021-07-28 05:04:50 --> Config Class Initialized
INFO - 2021-07-28 05:04:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:50 --> URI Class Initialized
INFO - 2021-07-28 05:04:50 --> Router Class Initialized
INFO - 2021-07-28 05:04:50 --> Output Class Initialized
INFO - 2021-07-28 05:04:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:50 --> Input Class Initialized
INFO - 2021-07-28 05:04:50 --> Language Class Initialized
INFO - 2021-07-28 05:04:50 --> Language Class Initialized
INFO - 2021-07-28 05:04:50 --> Config Class Initialized
INFO - 2021-07-28 05:04:50 --> Loader Class Initialized
INFO - 2021-07-28 05:04:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:50 --> Controller Class Initialized
DEBUG - 2021-07-28 05:04:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:04:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:04:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:50 --> Total execution time: 0.0699
INFO - 2021-07-28 05:04:51 --> Config Class Initialized
INFO - 2021-07-28 05:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:51 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:51 --> URI Class Initialized
INFO - 2021-07-28 05:04:51 --> Router Class Initialized
INFO - 2021-07-28 05:04:51 --> Output Class Initialized
INFO - 2021-07-28 05:04:51 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:51 --> Input Class Initialized
INFO - 2021-07-28 05:04:51 --> Language Class Initialized
INFO - 2021-07-28 05:04:51 --> Language Class Initialized
INFO - 2021-07-28 05:04:51 --> Config Class Initialized
INFO - 2021-07-28 05:04:51 --> Loader Class Initialized
INFO - 2021-07-28 05:04:51 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:51 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:51 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:51 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:51 --> Controller Class Initialized
INFO - 2021-07-28 05:04:51 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:04:51 --> Config Class Initialized
INFO - 2021-07-28 05:04:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:04:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:04:51 --> Utf8 Class Initialized
INFO - 2021-07-28 05:04:51 --> URI Class Initialized
INFO - 2021-07-28 05:04:51 --> Router Class Initialized
INFO - 2021-07-28 05:04:51 --> Output Class Initialized
INFO - 2021-07-28 05:04:51 --> Security Class Initialized
DEBUG - 2021-07-28 05:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:04:51 --> Input Class Initialized
INFO - 2021-07-28 05:04:51 --> Language Class Initialized
INFO - 2021-07-28 05:04:51 --> Language Class Initialized
INFO - 2021-07-28 05:04:51 --> Config Class Initialized
INFO - 2021-07-28 05:04:51 --> Loader Class Initialized
INFO - 2021-07-28 05:04:51 --> Helper loaded: url_helper
INFO - 2021-07-28 05:04:51 --> Helper loaded: file_helper
INFO - 2021-07-28 05:04:51 --> Helper loaded: form_helper
INFO - 2021-07-28 05:04:51 --> Helper loaded: my_helper
INFO - 2021-07-28 05:04:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:04:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:04:51 --> Controller Class Initialized
DEBUG - 2021-07-28 05:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:04:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:04:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:04:51 --> Total execution time: 0.0547
INFO - 2021-07-28 05:05:09 --> Config Class Initialized
INFO - 2021-07-28 05:05:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:09 --> URI Class Initialized
INFO - 2021-07-28 05:05:09 --> Router Class Initialized
INFO - 2021-07-28 05:05:09 --> Output Class Initialized
INFO - 2021-07-28 05:05:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:09 --> Input Class Initialized
INFO - 2021-07-28 05:05:09 --> Language Class Initialized
INFO - 2021-07-28 05:05:09 --> Language Class Initialized
INFO - 2021-07-28 05:05:09 --> Config Class Initialized
INFO - 2021-07-28 05:05:09 --> Loader Class Initialized
INFO - 2021-07-28 05:05:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:09 --> Controller Class Initialized
INFO - 2021-07-28 05:05:09 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:05:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:09 --> Total execution time: 0.0604
INFO - 2021-07-28 05:05:11 --> Config Class Initialized
INFO - 2021-07-28 05:05:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:11 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:11 --> URI Class Initialized
INFO - 2021-07-28 05:05:11 --> Router Class Initialized
INFO - 2021-07-28 05:05:11 --> Output Class Initialized
INFO - 2021-07-28 05:05:11 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:11 --> Input Class Initialized
INFO - 2021-07-28 05:05:11 --> Language Class Initialized
INFO - 2021-07-28 05:05:11 --> Language Class Initialized
INFO - 2021-07-28 05:05:11 --> Config Class Initialized
INFO - 2021-07-28 05:05:11 --> Loader Class Initialized
INFO - 2021-07-28 05:05:11 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:11 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:11 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:11 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:11 --> Controller Class Initialized
DEBUG - 2021-07-28 05:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:05:11 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:11 --> Total execution time: 0.7170
INFO - 2021-07-28 05:05:14 --> Config Class Initialized
INFO - 2021-07-28 05:05:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:14 --> URI Class Initialized
INFO - 2021-07-28 05:05:14 --> Router Class Initialized
INFO - 2021-07-28 05:05:14 --> Output Class Initialized
INFO - 2021-07-28 05:05:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:14 --> Input Class Initialized
INFO - 2021-07-28 05:05:14 --> Language Class Initialized
INFO - 2021-07-28 05:05:14 --> Language Class Initialized
INFO - 2021-07-28 05:05:14 --> Config Class Initialized
INFO - 2021-07-28 05:05:14 --> Loader Class Initialized
INFO - 2021-07-28 05:05:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:14 --> Controller Class Initialized
DEBUG - 2021-07-28 05:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:05:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:05:14 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:14 --> Total execution time: 0.0429
INFO - 2021-07-28 05:05:34 --> Config Class Initialized
INFO - 2021-07-28 05:05:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:34 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:34 --> URI Class Initialized
INFO - 2021-07-28 05:05:34 --> Router Class Initialized
INFO - 2021-07-28 05:05:34 --> Output Class Initialized
INFO - 2021-07-28 05:05:34 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:34 --> Input Class Initialized
INFO - 2021-07-28 05:05:34 --> Language Class Initialized
INFO - 2021-07-28 05:05:34 --> Language Class Initialized
INFO - 2021-07-28 05:05:34 --> Config Class Initialized
INFO - 2021-07-28 05:05:34 --> Loader Class Initialized
INFO - 2021-07-28 05:05:34 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:34 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:34 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:34 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:34 --> Controller Class Initialized
DEBUG - 2021-07-28 05:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:05:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:05:34 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:34 --> Total execution time: 0.0653
INFO - 2021-07-28 05:05:34 --> Config Class Initialized
INFO - 2021-07-28 05:05:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:34 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:34 --> URI Class Initialized
INFO - 2021-07-28 05:05:34 --> Router Class Initialized
INFO - 2021-07-28 05:05:34 --> Output Class Initialized
INFO - 2021-07-28 05:05:34 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:34 --> Input Class Initialized
INFO - 2021-07-28 05:05:34 --> Language Class Initialized
INFO - 2021-07-28 05:05:34 --> Language Class Initialized
INFO - 2021-07-28 05:05:34 --> Config Class Initialized
INFO - 2021-07-28 05:05:34 --> Loader Class Initialized
INFO - 2021-07-28 05:05:34 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:34 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:34 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:34 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:34 --> Controller Class Initialized
INFO - 2021-07-28 05:05:39 --> Config Class Initialized
INFO - 2021-07-28 05:05:39 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:39 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:39 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:39 --> URI Class Initialized
INFO - 2021-07-28 05:05:39 --> Router Class Initialized
INFO - 2021-07-28 05:05:39 --> Output Class Initialized
INFO - 2021-07-28 05:05:39 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:39 --> Input Class Initialized
INFO - 2021-07-28 05:05:39 --> Language Class Initialized
INFO - 2021-07-28 05:05:39 --> Language Class Initialized
INFO - 2021-07-28 05:05:39 --> Config Class Initialized
INFO - 2021-07-28 05:05:39 --> Loader Class Initialized
INFO - 2021-07-28 05:05:39 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:39 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:39 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:39 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:39 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:39 --> Controller Class Initialized
INFO - 2021-07-28 05:05:39 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:39 --> Total execution time: 0.0889
INFO - 2021-07-28 05:05:43 --> Config Class Initialized
INFO - 2021-07-28 05:05:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:43 --> URI Class Initialized
INFO - 2021-07-28 05:05:43 --> Router Class Initialized
INFO - 2021-07-28 05:05:43 --> Output Class Initialized
INFO - 2021-07-28 05:05:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:43 --> Input Class Initialized
INFO - 2021-07-28 05:05:43 --> Language Class Initialized
INFO - 2021-07-28 05:05:43 --> Language Class Initialized
INFO - 2021-07-28 05:05:43 --> Config Class Initialized
INFO - 2021-07-28 05:05:43 --> Loader Class Initialized
INFO - 2021-07-28 05:05:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:43 --> Controller Class Initialized
INFO - 2021-07-28 05:05:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:43 --> Total execution time: 0.0665
INFO - 2021-07-28 05:05:45 --> Config Class Initialized
INFO - 2021-07-28 05:05:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:45 --> URI Class Initialized
INFO - 2021-07-28 05:05:45 --> Router Class Initialized
INFO - 2021-07-28 05:05:45 --> Output Class Initialized
INFO - 2021-07-28 05:05:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:45 --> Input Class Initialized
INFO - 2021-07-28 05:05:45 --> Language Class Initialized
INFO - 2021-07-28 05:05:45 --> Language Class Initialized
INFO - 2021-07-28 05:05:45 --> Config Class Initialized
INFO - 2021-07-28 05:05:45 --> Loader Class Initialized
INFO - 2021-07-28 05:05:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:45 --> Controller Class Initialized
INFO - 2021-07-28 05:05:45 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:45 --> Total execution time: 0.0585
INFO - 2021-07-28 05:05:48 --> Config Class Initialized
INFO - 2021-07-28 05:05:48 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:48 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:48 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:48 --> URI Class Initialized
INFO - 2021-07-28 05:05:48 --> Router Class Initialized
INFO - 2021-07-28 05:05:48 --> Output Class Initialized
INFO - 2021-07-28 05:05:48 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:48 --> Input Class Initialized
INFO - 2021-07-28 05:05:48 --> Language Class Initialized
INFO - 2021-07-28 05:05:48 --> Language Class Initialized
INFO - 2021-07-28 05:05:48 --> Config Class Initialized
INFO - 2021-07-28 05:05:48 --> Loader Class Initialized
INFO - 2021-07-28 05:05:48 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:48 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:48 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:48 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:48 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:48 --> Controller Class Initialized
INFO - 2021-07-28 05:05:48 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:48 --> Total execution time: 0.0757
INFO - 2021-07-28 05:05:49 --> Config Class Initialized
INFO - 2021-07-28 05:05:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:49 --> URI Class Initialized
INFO - 2021-07-28 05:05:49 --> Router Class Initialized
INFO - 2021-07-28 05:05:49 --> Output Class Initialized
INFO - 2021-07-28 05:05:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:49 --> Input Class Initialized
INFO - 2021-07-28 05:05:49 --> Language Class Initialized
INFO - 2021-07-28 05:05:49 --> Language Class Initialized
INFO - 2021-07-28 05:05:49 --> Config Class Initialized
INFO - 2021-07-28 05:05:49 --> Loader Class Initialized
INFO - 2021-07-28 05:05:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:49 --> Controller Class Initialized
INFO - 2021-07-28 05:05:49 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:49 --> Total execution time: 0.0670
INFO - 2021-07-28 05:05:54 --> Config Class Initialized
INFO - 2021-07-28 05:05:54 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:05:54 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:05:54 --> Utf8 Class Initialized
INFO - 2021-07-28 05:05:54 --> URI Class Initialized
INFO - 2021-07-28 05:05:54 --> Router Class Initialized
INFO - 2021-07-28 05:05:54 --> Output Class Initialized
INFO - 2021-07-28 05:05:54 --> Security Class Initialized
DEBUG - 2021-07-28 05:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:05:54 --> Input Class Initialized
INFO - 2021-07-28 05:05:54 --> Language Class Initialized
INFO - 2021-07-28 05:05:54 --> Language Class Initialized
INFO - 2021-07-28 05:05:54 --> Config Class Initialized
INFO - 2021-07-28 05:05:54 --> Loader Class Initialized
INFO - 2021-07-28 05:05:54 --> Helper loaded: url_helper
INFO - 2021-07-28 05:05:54 --> Helper loaded: file_helper
INFO - 2021-07-28 05:05:54 --> Helper loaded: form_helper
INFO - 2021-07-28 05:05:54 --> Helper loaded: my_helper
INFO - 2021-07-28 05:05:54 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:05:54 --> Controller Class Initialized
INFO - 2021-07-28 05:05:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:05:56 --> Total execution time: 2.1369
INFO - 2021-07-28 05:06:01 --> Config Class Initialized
INFO - 2021-07-28 05:06:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:01 --> URI Class Initialized
INFO - 2021-07-28 05:06:01 --> Router Class Initialized
INFO - 2021-07-28 05:06:01 --> Output Class Initialized
INFO - 2021-07-28 05:06:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:01 --> Input Class Initialized
INFO - 2021-07-28 05:06:01 --> Language Class Initialized
INFO - 2021-07-28 05:06:01 --> Language Class Initialized
INFO - 2021-07-28 05:06:01 --> Config Class Initialized
INFO - 2021-07-28 05:06:01 --> Loader Class Initialized
INFO - 2021-07-28 05:06:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:01 --> Controller Class Initialized
DEBUG - 2021-07-28 05:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:06:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:01 --> Total execution time: 0.0674
INFO - 2021-07-28 05:06:03 --> Config Class Initialized
INFO - 2021-07-28 05:06:03 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:03 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:03 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:03 --> URI Class Initialized
INFO - 2021-07-28 05:06:03 --> Router Class Initialized
INFO - 2021-07-28 05:06:03 --> Output Class Initialized
INFO - 2021-07-28 05:06:03 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:03 --> Input Class Initialized
INFO - 2021-07-28 05:06:03 --> Language Class Initialized
INFO - 2021-07-28 05:06:03 --> Language Class Initialized
INFO - 2021-07-28 05:06:03 --> Config Class Initialized
INFO - 2021-07-28 05:06:03 --> Loader Class Initialized
INFO - 2021-07-28 05:06:03 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:03 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:03 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:03 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:03 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:03 --> Controller Class Initialized
DEBUG - 2021-07-28 05:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:06:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:03 --> Total execution time: 0.0627
INFO - 2021-07-28 05:06:04 --> Config Class Initialized
INFO - 2021-07-28 05:06:04 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:04 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:04 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:04 --> URI Class Initialized
INFO - 2021-07-28 05:06:04 --> Router Class Initialized
INFO - 2021-07-28 05:06:04 --> Output Class Initialized
INFO - 2021-07-28 05:06:04 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:04 --> Input Class Initialized
INFO - 2021-07-28 05:06:04 --> Language Class Initialized
INFO - 2021-07-28 05:06:04 --> Language Class Initialized
INFO - 2021-07-28 05:06:04 --> Config Class Initialized
INFO - 2021-07-28 05:06:04 --> Loader Class Initialized
INFO - 2021-07-28 05:06:04 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:04 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:04 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:04 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:04 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:04 --> Controller Class Initialized
INFO - 2021-07-28 05:06:04 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:04 --> Total execution time: 0.1055
INFO - 2021-07-28 05:06:09 --> Config Class Initialized
INFO - 2021-07-28 05:06:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:09 --> URI Class Initialized
INFO - 2021-07-28 05:06:09 --> Router Class Initialized
INFO - 2021-07-28 05:06:09 --> Output Class Initialized
INFO - 2021-07-28 05:06:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:10 --> Input Class Initialized
INFO - 2021-07-28 05:06:10 --> Language Class Initialized
INFO - 2021-07-28 05:06:10 --> Language Class Initialized
INFO - 2021-07-28 05:06:10 --> Config Class Initialized
INFO - 2021-07-28 05:06:10 --> Loader Class Initialized
INFO - 2021-07-28 05:06:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:10 --> Controller Class Initialized
INFO - 2021-07-28 05:06:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:10 --> Total execution time: 0.0589
INFO - 2021-07-28 05:06:11 --> Config Class Initialized
INFO - 2021-07-28 05:06:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:11 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:11 --> URI Class Initialized
INFO - 2021-07-28 05:06:11 --> Router Class Initialized
INFO - 2021-07-28 05:06:11 --> Output Class Initialized
INFO - 2021-07-28 05:06:11 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:11 --> Input Class Initialized
INFO - 2021-07-28 05:06:11 --> Language Class Initialized
INFO - 2021-07-28 05:06:11 --> Language Class Initialized
INFO - 2021-07-28 05:06:11 --> Config Class Initialized
INFO - 2021-07-28 05:06:11 --> Loader Class Initialized
INFO - 2021-07-28 05:06:11 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:11 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:11 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:11 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:11 --> Controller Class Initialized
INFO - 2021-07-28 05:06:11 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:11 --> Total execution time: 0.0644
INFO - 2021-07-28 05:06:13 --> Config Class Initialized
INFO - 2021-07-28 05:06:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:13 --> URI Class Initialized
INFO - 2021-07-28 05:06:13 --> Router Class Initialized
INFO - 2021-07-28 05:06:13 --> Output Class Initialized
INFO - 2021-07-28 05:06:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:13 --> Input Class Initialized
INFO - 2021-07-28 05:06:13 --> Language Class Initialized
INFO - 2021-07-28 05:06:13 --> Language Class Initialized
INFO - 2021-07-28 05:06:13 --> Config Class Initialized
INFO - 2021-07-28 05:06:13 --> Loader Class Initialized
INFO - 2021-07-28 05:06:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:13 --> Controller Class Initialized
DEBUG - 2021-07-28 05:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:06:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:13 --> Total execution time: 0.0553
INFO - 2021-07-28 05:06:20 --> Config Class Initialized
INFO - 2021-07-28 05:06:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:20 --> URI Class Initialized
INFO - 2021-07-28 05:06:20 --> Router Class Initialized
INFO - 2021-07-28 05:06:20 --> Output Class Initialized
INFO - 2021-07-28 05:06:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:20 --> Input Class Initialized
INFO - 2021-07-28 05:06:20 --> Language Class Initialized
INFO - 2021-07-28 05:06:20 --> Language Class Initialized
INFO - 2021-07-28 05:06:20 --> Config Class Initialized
INFO - 2021-07-28 05:06:20 --> Loader Class Initialized
INFO - 2021-07-28 05:06:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:20 --> Controller Class Initialized
DEBUG - 2021-07-28 05:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:06:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:06:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:20 --> Total execution time: 0.0645
INFO - 2021-07-28 05:06:20 --> Config Class Initialized
INFO - 2021-07-28 05:06:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:20 --> URI Class Initialized
INFO - 2021-07-28 05:06:20 --> Router Class Initialized
INFO - 2021-07-28 05:06:20 --> Output Class Initialized
INFO - 2021-07-28 05:06:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:20 --> Input Class Initialized
INFO - 2021-07-28 05:06:20 --> Language Class Initialized
INFO - 2021-07-28 05:06:20 --> Language Class Initialized
INFO - 2021-07-28 05:06:20 --> Config Class Initialized
INFO - 2021-07-28 05:06:20 --> Loader Class Initialized
INFO - 2021-07-28 05:06:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:20 --> Controller Class Initialized
INFO - 2021-07-28 05:06:22 --> Config Class Initialized
INFO - 2021-07-28 05:06:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:22 --> URI Class Initialized
INFO - 2021-07-28 05:06:22 --> Router Class Initialized
INFO - 2021-07-28 05:06:22 --> Output Class Initialized
INFO - 2021-07-28 05:06:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:22 --> Input Class Initialized
INFO - 2021-07-28 05:06:22 --> Language Class Initialized
INFO - 2021-07-28 05:06:22 --> Language Class Initialized
INFO - 2021-07-28 05:06:22 --> Config Class Initialized
INFO - 2021-07-28 05:06:22 --> Loader Class Initialized
INFO - 2021-07-28 05:06:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:22 --> Controller Class Initialized
INFO - 2021-07-28 05:06:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:22 --> Total execution time: 0.0579
INFO - 2021-07-28 05:06:27 --> Config Class Initialized
INFO - 2021-07-28 05:06:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:27 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:27 --> URI Class Initialized
INFO - 2021-07-28 05:06:27 --> Router Class Initialized
INFO - 2021-07-28 05:06:27 --> Output Class Initialized
INFO - 2021-07-28 05:06:27 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:27 --> Input Class Initialized
INFO - 2021-07-28 05:06:27 --> Language Class Initialized
INFO - 2021-07-28 05:06:27 --> Language Class Initialized
INFO - 2021-07-28 05:06:27 --> Config Class Initialized
INFO - 2021-07-28 05:06:27 --> Loader Class Initialized
INFO - 2021-07-28 05:06:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:27 --> Controller Class Initialized
INFO - 2021-07-28 05:06:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:27 --> Total execution time: 0.0596
INFO - 2021-07-28 05:06:29 --> Config Class Initialized
INFO - 2021-07-28 05:06:29 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:29 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:29 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:29 --> URI Class Initialized
INFO - 2021-07-28 05:06:29 --> Router Class Initialized
INFO - 2021-07-28 05:06:29 --> Output Class Initialized
INFO - 2021-07-28 05:06:29 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:29 --> Input Class Initialized
INFO - 2021-07-28 05:06:29 --> Language Class Initialized
INFO - 2021-07-28 05:06:29 --> Language Class Initialized
INFO - 2021-07-28 05:06:29 --> Config Class Initialized
INFO - 2021-07-28 05:06:29 --> Loader Class Initialized
INFO - 2021-07-28 05:06:29 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:29 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:29 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:29 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:29 --> Controller Class Initialized
INFO - 2021-07-28 05:06:29 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:29 --> Total execution time: 0.0435
INFO - 2021-07-28 05:06:31 --> Config Class Initialized
INFO - 2021-07-28 05:06:31 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:31 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:31 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:31 --> URI Class Initialized
INFO - 2021-07-28 05:06:31 --> Router Class Initialized
INFO - 2021-07-28 05:06:31 --> Output Class Initialized
INFO - 2021-07-28 05:06:31 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:31 --> Input Class Initialized
INFO - 2021-07-28 05:06:31 --> Language Class Initialized
INFO - 2021-07-28 05:06:31 --> Language Class Initialized
INFO - 2021-07-28 05:06:31 --> Config Class Initialized
INFO - 2021-07-28 05:06:31 --> Loader Class Initialized
INFO - 2021-07-28 05:06:31 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:31 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:31 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:31 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:31 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:31 --> Controller Class Initialized
INFO - 2021-07-28 05:06:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:31 --> Total execution time: 0.0581
INFO - 2021-07-28 05:06:33 --> Config Class Initialized
INFO - 2021-07-28 05:06:33 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:33 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:33 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:33 --> URI Class Initialized
INFO - 2021-07-28 05:06:33 --> Router Class Initialized
INFO - 2021-07-28 05:06:33 --> Output Class Initialized
INFO - 2021-07-28 05:06:33 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:33 --> Input Class Initialized
INFO - 2021-07-28 05:06:33 --> Language Class Initialized
INFO - 2021-07-28 05:06:33 --> Language Class Initialized
INFO - 2021-07-28 05:06:33 --> Config Class Initialized
INFO - 2021-07-28 05:06:33 --> Loader Class Initialized
INFO - 2021-07-28 05:06:33 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:33 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:33 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:33 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:33 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:33 --> Controller Class Initialized
INFO - 2021-07-28 05:06:33 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:33 --> Total execution time: 0.0573
INFO - 2021-07-28 05:06:34 --> Config Class Initialized
INFO - 2021-07-28 05:06:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:34 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:34 --> URI Class Initialized
INFO - 2021-07-28 05:06:34 --> Router Class Initialized
INFO - 2021-07-28 05:06:34 --> Output Class Initialized
INFO - 2021-07-28 05:06:34 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:34 --> Input Class Initialized
INFO - 2021-07-28 05:06:34 --> Language Class Initialized
INFO - 2021-07-28 05:06:34 --> Language Class Initialized
INFO - 2021-07-28 05:06:34 --> Config Class Initialized
INFO - 2021-07-28 05:06:34 --> Loader Class Initialized
INFO - 2021-07-28 05:06:34 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:34 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:34 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:34 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:34 --> Controller Class Initialized
INFO - 2021-07-28 05:06:34 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:34 --> Total execution time: 0.0578
INFO - 2021-07-28 05:06:37 --> Config Class Initialized
INFO - 2021-07-28 05:06:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:37 --> URI Class Initialized
INFO - 2021-07-28 05:06:37 --> Router Class Initialized
INFO - 2021-07-28 05:06:37 --> Output Class Initialized
INFO - 2021-07-28 05:06:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:37 --> Input Class Initialized
INFO - 2021-07-28 05:06:37 --> Language Class Initialized
INFO - 2021-07-28 05:06:37 --> Language Class Initialized
INFO - 2021-07-28 05:06:37 --> Config Class Initialized
INFO - 2021-07-28 05:06:37 --> Loader Class Initialized
INFO - 2021-07-28 05:06:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:37 --> Controller Class Initialized
DEBUG - 2021-07-28 05:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:06:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:06:37 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:37 --> Total execution time: 0.0586
INFO - 2021-07-28 05:06:40 --> Config Class Initialized
INFO - 2021-07-28 05:06:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:40 --> URI Class Initialized
INFO - 2021-07-28 05:06:40 --> Router Class Initialized
INFO - 2021-07-28 05:06:40 --> Output Class Initialized
INFO - 2021-07-28 05:06:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:40 --> Input Class Initialized
INFO - 2021-07-28 05:06:40 --> Language Class Initialized
INFO - 2021-07-28 05:06:40 --> Language Class Initialized
INFO - 2021-07-28 05:06:40 --> Config Class Initialized
INFO - 2021-07-28 05:06:40 --> Loader Class Initialized
INFO - 2021-07-28 05:06:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:40 --> Controller Class Initialized
DEBUG - 2021-07-28 05:06:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:06:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:06:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:40 --> Total execution time: 0.0448
INFO - 2021-07-28 05:06:43 --> Config Class Initialized
INFO - 2021-07-28 05:06:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:43 --> URI Class Initialized
INFO - 2021-07-28 05:06:43 --> Router Class Initialized
INFO - 2021-07-28 05:06:43 --> Output Class Initialized
INFO - 2021-07-28 05:06:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:43 --> Input Class Initialized
INFO - 2021-07-28 05:06:43 --> Language Class Initialized
INFO - 2021-07-28 05:06:43 --> Language Class Initialized
INFO - 2021-07-28 05:06:43 --> Config Class Initialized
INFO - 2021-07-28 05:06:43 --> Loader Class Initialized
INFO - 2021-07-28 05:06:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:43 --> Controller Class Initialized
INFO - 2021-07-28 05:06:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:43 --> Total execution time: 0.0520
INFO - 2021-07-28 05:06:48 --> Config Class Initialized
INFO - 2021-07-28 05:06:48 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:48 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:48 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:48 --> URI Class Initialized
INFO - 2021-07-28 05:06:48 --> Router Class Initialized
INFO - 2021-07-28 05:06:48 --> Output Class Initialized
INFO - 2021-07-28 05:06:48 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:48 --> Input Class Initialized
INFO - 2021-07-28 05:06:48 --> Language Class Initialized
INFO - 2021-07-28 05:06:48 --> Language Class Initialized
INFO - 2021-07-28 05:06:48 --> Config Class Initialized
INFO - 2021-07-28 05:06:48 --> Loader Class Initialized
INFO - 2021-07-28 05:06:48 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:48 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:48 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:48 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:48 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:48 --> Controller Class Initialized
INFO - 2021-07-28 05:06:48 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:48 --> Total execution time: 0.0525
INFO - 2021-07-28 05:06:50 --> Config Class Initialized
INFO - 2021-07-28 05:06:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:50 --> URI Class Initialized
INFO - 2021-07-28 05:06:50 --> Router Class Initialized
INFO - 2021-07-28 05:06:50 --> Output Class Initialized
INFO - 2021-07-28 05:06:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:50 --> Input Class Initialized
INFO - 2021-07-28 05:06:50 --> Language Class Initialized
INFO - 2021-07-28 05:06:50 --> Language Class Initialized
INFO - 2021-07-28 05:06:50 --> Config Class Initialized
INFO - 2021-07-28 05:06:50 --> Loader Class Initialized
INFO - 2021-07-28 05:06:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:50 --> Controller Class Initialized
INFO - 2021-07-28 05:06:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:50 --> Total execution time: 0.0641
INFO - 2021-07-28 05:06:52 --> Config Class Initialized
INFO - 2021-07-28 05:06:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:52 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:52 --> URI Class Initialized
INFO - 2021-07-28 05:06:52 --> Router Class Initialized
INFO - 2021-07-28 05:06:52 --> Output Class Initialized
INFO - 2021-07-28 05:06:52 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:52 --> Input Class Initialized
INFO - 2021-07-28 05:06:52 --> Language Class Initialized
INFO - 2021-07-28 05:06:52 --> Language Class Initialized
INFO - 2021-07-28 05:06:52 --> Config Class Initialized
INFO - 2021-07-28 05:06:52 --> Loader Class Initialized
INFO - 2021-07-28 05:06:52 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:52 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:52 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:52 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:52 --> Controller Class Initialized
INFO - 2021-07-28 05:06:52 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:52 --> Total execution time: 0.0740
INFO - 2021-07-28 05:06:56 --> Config Class Initialized
INFO - 2021-07-28 05:06:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:06:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:06:56 --> Utf8 Class Initialized
INFO - 2021-07-28 05:06:56 --> URI Class Initialized
INFO - 2021-07-28 05:06:56 --> Router Class Initialized
INFO - 2021-07-28 05:06:56 --> Output Class Initialized
INFO - 2021-07-28 05:06:56 --> Security Class Initialized
DEBUG - 2021-07-28 05:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:06:56 --> Input Class Initialized
INFO - 2021-07-28 05:06:56 --> Language Class Initialized
INFO - 2021-07-28 05:06:56 --> Language Class Initialized
INFO - 2021-07-28 05:06:56 --> Config Class Initialized
INFO - 2021-07-28 05:06:56 --> Loader Class Initialized
INFO - 2021-07-28 05:06:56 --> Helper loaded: url_helper
INFO - 2021-07-28 05:06:56 --> Helper loaded: file_helper
INFO - 2021-07-28 05:06:56 --> Helper loaded: form_helper
INFO - 2021-07-28 05:06:56 --> Helper loaded: my_helper
INFO - 2021-07-28 05:06:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:06:56 --> Controller Class Initialized
DEBUG - 2021-07-28 05:06:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:06:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:06:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:06:56 --> Total execution time: 0.0574
INFO - 2021-07-28 05:07:01 --> Config Class Initialized
INFO - 2021-07-28 05:07:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:01 --> URI Class Initialized
INFO - 2021-07-28 05:07:01 --> Router Class Initialized
INFO - 2021-07-28 05:07:01 --> Output Class Initialized
INFO - 2021-07-28 05:07:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:01 --> Input Class Initialized
INFO - 2021-07-28 05:07:01 --> Language Class Initialized
INFO - 2021-07-28 05:07:01 --> Language Class Initialized
INFO - 2021-07-28 05:07:01 --> Config Class Initialized
INFO - 2021-07-28 05:07:01 --> Loader Class Initialized
INFO - 2021-07-28 05:07:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:01 --> Controller Class Initialized
DEBUG - 2021-07-28 05:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:07:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:01 --> Total execution time: 0.0530
INFO - 2021-07-28 05:07:01 --> Config Class Initialized
INFO - 2021-07-28 05:07:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:01 --> URI Class Initialized
INFO - 2021-07-28 05:07:01 --> Router Class Initialized
INFO - 2021-07-28 05:07:01 --> Output Class Initialized
INFO - 2021-07-28 05:07:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:01 --> Input Class Initialized
INFO - 2021-07-28 05:07:01 --> Language Class Initialized
INFO - 2021-07-28 05:07:01 --> Language Class Initialized
INFO - 2021-07-28 05:07:01 --> Config Class Initialized
INFO - 2021-07-28 05:07:01 --> Loader Class Initialized
INFO - 2021-07-28 05:07:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:01 --> Controller Class Initialized
INFO - 2021-07-28 05:07:02 --> Config Class Initialized
INFO - 2021-07-28 05:07:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:02 --> URI Class Initialized
INFO - 2021-07-28 05:07:02 --> Router Class Initialized
INFO - 2021-07-28 05:07:02 --> Output Class Initialized
INFO - 2021-07-28 05:07:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:02 --> Input Class Initialized
INFO - 2021-07-28 05:07:02 --> Language Class Initialized
INFO - 2021-07-28 05:07:02 --> Language Class Initialized
INFO - 2021-07-28 05:07:02 --> Config Class Initialized
INFO - 2021-07-28 05:07:02 --> Loader Class Initialized
INFO - 2021-07-28 05:07:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:02 --> Controller Class Initialized
INFO - 2021-07-28 05:07:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:02 --> Total execution time: 0.0642
INFO - 2021-07-28 05:07:07 --> Config Class Initialized
INFO - 2021-07-28 05:07:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:07 --> URI Class Initialized
INFO - 2021-07-28 05:07:07 --> Router Class Initialized
INFO - 2021-07-28 05:07:07 --> Output Class Initialized
INFO - 2021-07-28 05:07:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:07 --> Input Class Initialized
INFO - 2021-07-28 05:07:07 --> Language Class Initialized
INFO - 2021-07-28 05:07:07 --> Language Class Initialized
INFO - 2021-07-28 05:07:07 --> Config Class Initialized
INFO - 2021-07-28 05:07:07 --> Loader Class Initialized
INFO - 2021-07-28 05:07:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:07 --> Controller Class Initialized
INFO - 2021-07-28 05:07:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:08 --> Total execution time: 0.9378
INFO - 2021-07-28 05:07:10 --> Config Class Initialized
INFO - 2021-07-28 05:07:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:10 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:10 --> URI Class Initialized
INFO - 2021-07-28 05:07:10 --> Router Class Initialized
INFO - 2021-07-28 05:07:10 --> Output Class Initialized
INFO - 2021-07-28 05:07:10 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:10 --> Input Class Initialized
INFO - 2021-07-28 05:07:10 --> Language Class Initialized
INFO - 2021-07-28 05:07:10 --> Language Class Initialized
INFO - 2021-07-28 05:07:10 --> Config Class Initialized
INFO - 2021-07-28 05:07:10 --> Loader Class Initialized
INFO - 2021-07-28 05:07:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:10 --> Controller Class Initialized
INFO - 2021-07-28 05:07:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:10 --> Total execution time: 0.0534
INFO - 2021-07-28 05:07:14 --> Config Class Initialized
INFO - 2021-07-28 05:07:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:14 --> URI Class Initialized
INFO - 2021-07-28 05:07:14 --> Router Class Initialized
INFO - 2021-07-28 05:07:14 --> Output Class Initialized
INFO - 2021-07-28 05:07:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:14 --> Input Class Initialized
INFO - 2021-07-28 05:07:14 --> Language Class Initialized
INFO - 2021-07-28 05:07:14 --> Language Class Initialized
INFO - 2021-07-28 05:07:14 --> Config Class Initialized
INFO - 2021-07-28 05:07:14 --> Loader Class Initialized
INFO - 2021-07-28 05:07:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:14 --> Controller Class Initialized
INFO - 2021-07-28 05:07:15 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:15 --> Total execution time: 0.9051
INFO - 2021-07-28 05:07:16 --> Config Class Initialized
INFO - 2021-07-28 05:07:16 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:16 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:16 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:16 --> URI Class Initialized
INFO - 2021-07-28 05:07:16 --> Router Class Initialized
INFO - 2021-07-28 05:07:16 --> Output Class Initialized
INFO - 2021-07-28 05:07:16 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:16 --> Input Class Initialized
INFO - 2021-07-28 05:07:16 --> Language Class Initialized
INFO - 2021-07-28 05:07:16 --> Language Class Initialized
INFO - 2021-07-28 05:07:16 --> Config Class Initialized
INFO - 2021-07-28 05:07:16 --> Loader Class Initialized
INFO - 2021-07-28 05:07:16 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:16 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:16 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:16 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:16 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:16 --> Controller Class Initialized
INFO - 2021-07-28 05:07:16 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:16 --> Total execution time: 0.0733
INFO - 2021-07-28 05:07:20 --> Config Class Initialized
INFO - 2021-07-28 05:07:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:20 --> URI Class Initialized
INFO - 2021-07-28 05:07:20 --> Router Class Initialized
INFO - 2021-07-28 05:07:20 --> Output Class Initialized
INFO - 2021-07-28 05:07:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:20 --> Input Class Initialized
INFO - 2021-07-28 05:07:20 --> Language Class Initialized
INFO - 2021-07-28 05:07:20 --> Language Class Initialized
INFO - 2021-07-28 05:07:20 --> Config Class Initialized
INFO - 2021-07-28 05:07:20 --> Loader Class Initialized
INFO - 2021-07-28 05:07:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:21 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:21 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:21 --> Controller Class Initialized
INFO - 2021-07-28 05:07:21 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:21 --> Total execution time: 0.8970
INFO - 2021-07-28 05:07:26 --> Config Class Initialized
INFO - 2021-07-28 05:07:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:26 --> URI Class Initialized
INFO - 2021-07-28 05:07:26 --> Router Class Initialized
INFO - 2021-07-28 05:07:26 --> Output Class Initialized
INFO - 2021-07-28 05:07:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:26 --> Input Class Initialized
INFO - 2021-07-28 05:07:26 --> Language Class Initialized
INFO - 2021-07-28 05:07:26 --> Language Class Initialized
INFO - 2021-07-28 05:07:26 --> Config Class Initialized
INFO - 2021-07-28 05:07:26 --> Loader Class Initialized
INFO - 2021-07-28 05:07:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:26 --> Controller Class Initialized
INFO - 2021-07-28 05:07:26 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:26 --> Total execution time: 0.0597
INFO - 2021-07-28 05:07:33 --> Config Class Initialized
INFO - 2021-07-28 05:07:33 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:33 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:33 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:33 --> URI Class Initialized
INFO - 2021-07-28 05:07:33 --> Router Class Initialized
INFO - 2021-07-28 05:07:33 --> Output Class Initialized
INFO - 2021-07-28 05:07:33 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:33 --> Input Class Initialized
INFO - 2021-07-28 05:07:33 --> Language Class Initialized
INFO - 2021-07-28 05:07:33 --> Language Class Initialized
INFO - 2021-07-28 05:07:33 --> Config Class Initialized
INFO - 2021-07-28 05:07:33 --> Loader Class Initialized
INFO - 2021-07-28 05:07:33 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:33 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:33 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:33 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:33 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:33 --> Controller Class Initialized
INFO - 2021-07-28 05:07:33 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:33 --> Total execution time: 0.9020
INFO - 2021-07-28 05:07:36 --> Config Class Initialized
INFO - 2021-07-28 05:07:36 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:36 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:36 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:36 --> URI Class Initialized
INFO - 2021-07-28 05:07:36 --> Router Class Initialized
INFO - 2021-07-28 05:07:36 --> Output Class Initialized
INFO - 2021-07-28 05:07:36 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:36 --> Input Class Initialized
INFO - 2021-07-28 05:07:36 --> Language Class Initialized
INFO - 2021-07-28 05:07:36 --> Language Class Initialized
INFO - 2021-07-28 05:07:36 --> Config Class Initialized
INFO - 2021-07-28 05:07:36 --> Loader Class Initialized
INFO - 2021-07-28 05:07:36 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:36 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:36 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:36 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:36 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:36 --> Controller Class Initialized
INFO - 2021-07-28 05:07:36 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:36 --> Total execution time: 0.0683
INFO - 2021-07-28 05:07:44 --> Config Class Initialized
INFO - 2021-07-28 05:07:44 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:44 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:44 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:44 --> URI Class Initialized
INFO - 2021-07-28 05:07:44 --> Router Class Initialized
INFO - 2021-07-28 05:07:44 --> Output Class Initialized
INFO - 2021-07-28 05:07:44 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:44 --> Input Class Initialized
INFO - 2021-07-28 05:07:44 --> Language Class Initialized
INFO - 2021-07-28 05:07:44 --> Language Class Initialized
INFO - 2021-07-28 05:07:44 --> Config Class Initialized
INFO - 2021-07-28 05:07:44 --> Loader Class Initialized
INFO - 2021-07-28 05:07:44 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:44 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:44 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:44 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:44 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:44 --> Controller Class Initialized
INFO - 2021-07-28 05:07:44 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:44 --> Total execution time: 0.9078
INFO - 2021-07-28 05:07:45 --> Config Class Initialized
INFO - 2021-07-28 05:07:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:45 --> URI Class Initialized
INFO - 2021-07-28 05:07:45 --> Router Class Initialized
INFO - 2021-07-28 05:07:45 --> Output Class Initialized
INFO - 2021-07-28 05:07:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:45 --> Input Class Initialized
INFO - 2021-07-28 05:07:45 --> Language Class Initialized
INFO - 2021-07-28 05:07:45 --> Language Class Initialized
INFO - 2021-07-28 05:07:45 --> Config Class Initialized
INFO - 2021-07-28 05:07:45 --> Loader Class Initialized
INFO - 2021-07-28 05:07:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:45 --> Controller Class Initialized
INFO - 2021-07-28 05:07:45 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:45 --> Total execution time: 0.0586
INFO - 2021-07-28 05:07:50 --> Config Class Initialized
INFO - 2021-07-28 05:07:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:50 --> URI Class Initialized
INFO - 2021-07-28 05:07:50 --> Router Class Initialized
INFO - 2021-07-28 05:07:50 --> Output Class Initialized
INFO - 2021-07-28 05:07:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:50 --> Input Class Initialized
INFO - 2021-07-28 05:07:50 --> Language Class Initialized
INFO - 2021-07-28 05:07:50 --> Language Class Initialized
INFO - 2021-07-28 05:07:50 --> Config Class Initialized
INFO - 2021-07-28 05:07:50 --> Loader Class Initialized
INFO - 2021-07-28 05:07:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:50 --> Controller Class Initialized
INFO - 2021-07-28 05:07:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:51 --> Total execution time: 0.9183
INFO - 2021-07-28 05:07:58 --> Config Class Initialized
INFO - 2021-07-28 05:07:58 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:07:58 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:07:58 --> Utf8 Class Initialized
INFO - 2021-07-28 05:07:58 --> URI Class Initialized
INFO - 2021-07-28 05:07:58 --> Router Class Initialized
INFO - 2021-07-28 05:07:58 --> Output Class Initialized
INFO - 2021-07-28 05:07:58 --> Security Class Initialized
DEBUG - 2021-07-28 05:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:07:58 --> Input Class Initialized
INFO - 2021-07-28 05:07:58 --> Language Class Initialized
INFO - 2021-07-28 05:07:58 --> Language Class Initialized
INFO - 2021-07-28 05:07:58 --> Config Class Initialized
INFO - 2021-07-28 05:07:58 --> Loader Class Initialized
INFO - 2021-07-28 05:07:58 --> Helper loaded: url_helper
INFO - 2021-07-28 05:07:58 --> Helper loaded: file_helper
INFO - 2021-07-28 05:07:58 --> Helper loaded: form_helper
INFO - 2021-07-28 05:07:58 --> Helper loaded: my_helper
INFO - 2021-07-28 05:07:58 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:07:58 --> Controller Class Initialized
DEBUG - 2021-07-28 05:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:07:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:07:58 --> Total execution time: 0.0582
INFO - 2021-07-28 05:08:01 --> Config Class Initialized
INFO - 2021-07-28 05:08:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:01 --> URI Class Initialized
INFO - 2021-07-28 05:08:01 --> Router Class Initialized
INFO - 2021-07-28 05:08:01 --> Output Class Initialized
INFO - 2021-07-28 05:08:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:01 --> Input Class Initialized
INFO - 2021-07-28 05:08:01 --> Language Class Initialized
INFO - 2021-07-28 05:08:01 --> Language Class Initialized
INFO - 2021-07-28 05:08:01 --> Config Class Initialized
INFO - 2021-07-28 05:08:01 --> Loader Class Initialized
INFO - 2021-07-28 05:08:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:01 --> Controller Class Initialized
DEBUG - 2021-07-28 05:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:08:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:08:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:01 --> Total execution time: 0.0672
INFO - 2021-07-28 05:08:03 --> Config Class Initialized
INFO - 2021-07-28 05:08:03 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:03 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:03 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:03 --> URI Class Initialized
INFO - 2021-07-28 05:08:03 --> Router Class Initialized
INFO - 2021-07-28 05:08:03 --> Output Class Initialized
INFO - 2021-07-28 05:08:03 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:03 --> Input Class Initialized
INFO - 2021-07-28 05:08:03 --> Language Class Initialized
INFO - 2021-07-28 05:08:03 --> Language Class Initialized
INFO - 2021-07-28 05:08:03 --> Config Class Initialized
INFO - 2021-07-28 05:08:03 --> Loader Class Initialized
INFO - 2021-07-28 05:08:03 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:03 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:03 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:03 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:03 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:03 --> Controller Class Initialized
INFO - 2021-07-28 05:08:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:03 --> Total execution time: 0.1170
INFO - 2021-07-28 05:08:10 --> Config Class Initialized
INFO - 2021-07-28 05:08:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:10 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:10 --> URI Class Initialized
INFO - 2021-07-28 05:08:10 --> Router Class Initialized
INFO - 2021-07-28 05:08:10 --> Output Class Initialized
INFO - 2021-07-28 05:08:10 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:10 --> Input Class Initialized
INFO - 2021-07-28 05:08:10 --> Language Class Initialized
INFO - 2021-07-28 05:08:10 --> Language Class Initialized
INFO - 2021-07-28 05:08:10 --> Config Class Initialized
INFO - 2021-07-28 05:08:10 --> Loader Class Initialized
INFO - 2021-07-28 05:08:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:10 --> Controller Class Initialized
INFO - 2021-07-28 05:08:11 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:11 --> Total execution time: 0.8039
INFO - 2021-07-28 05:08:12 --> Config Class Initialized
INFO - 2021-07-28 05:08:12 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:12 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:12 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:12 --> URI Class Initialized
INFO - 2021-07-28 05:08:12 --> Router Class Initialized
INFO - 2021-07-28 05:08:12 --> Output Class Initialized
INFO - 2021-07-28 05:08:12 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:12 --> Input Class Initialized
INFO - 2021-07-28 05:08:12 --> Language Class Initialized
INFO - 2021-07-28 05:08:12 --> Language Class Initialized
INFO - 2021-07-28 05:08:12 --> Config Class Initialized
INFO - 2021-07-28 05:08:12 --> Loader Class Initialized
INFO - 2021-07-28 05:08:12 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:12 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:12 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:12 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:12 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:12 --> Controller Class Initialized
INFO - 2021-07-28 05:08:12 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:12 --> Total execution time: 0.0673
INFO - 2021-07-28 05:08:18 --> Config Class Initialized
INFO - 2021-07-28 05:08:18 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:18 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:18 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:18 --> URI Class Initialized
INFO - 2021-07-28 05:08:18 --> Router Class Initialized
INFO - 2021-07-28 05:08:18 --> Output Class Initialized
INFO - 2021-07-28 05:08:18 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:18 --> Input Class Initialized
INFO - 2021-07-28 05:08:18 --> Language Class Initialized
INFO - 2021-07-28 05:08:18 --> Language Class Initialized
INFO - 2021-07-28 05:08:18 --> Config Class Initialized
INFO - 2021-07-28 05:08:18 --> Loader Class Initialized
INFO - 2021-07-28 05:08:19 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:19 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:19 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:19 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:19 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:19 --> Controller Class Initialized
INFO - 2021-07-28 05:08:19 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:19 --> Total execution time: 0.8208
INFO - 2021-07-28 05:08:20 --> Config Class Initialized
INFO - 2021-07-28 05:08:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:20 --> URI Class Initialized
INFO - 2021-07-28 05:08:20 --> Router Class Initialized
INFO - 2021-07-28 05:08:20 --> Output Class Initialized
INFO - 2021-07-28 05:08:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:20 --> Input Class Initialized
INFO - 2021-07-28 05:08:20 --> Language Class Initialized
INFO - 2021-07-28 05:08:20 --> Language Class Initialized
INFO - 2021-07-28 05:08:20 --> Config Class Initialized
INFO - 2021-07-28 05:08:20 --> Loader Class Initialized
INFO - 2021-07-28 05:08:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:20 --> Controller Class Initialized
INFO - 2021-07-28 05:08:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:20 --> Total execution time: 0.0668
INFO - 2021-07-28 05:08:25 --> Config Class Initialized
INFO - 2021-07-28 05:08:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:25 --> URI Class Initialized
INFO - 2021-07-28 05:08:25 --> Router Class Initialized
INFO - 2021-07-28 05:08:25 --> Output Class Initialized
INFO - 2021-07-28 05:08:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:25 --> Input Class Initialized
INFO - 2021-07-28 05:08:25 --> Language Class Initialized
INFO - 2021-07-28 05:08:25 --> Language Class Initialized
INFO - 2021-07-28 05:08:25 --> Config Class Initialized
INFO - 2021-07-28 05:08:25 --> Loader Class Initialized
INFO - 2021-07-28 05:08:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:25 --> Controller Class Initialized
INFO - 2021-07-28 05:08:26 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:26 --> Total execution time: 0.7716
INFO - 2021-07-28 05:08:26 --> Config Class Initialized
INFO - 2021-07-28 05:08:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:26 --> URI Class Initialized
INFO - 2021-07-28 05:08:26 --> Router Class Initialized
INFO - 2021-07-28 05:08:26 --> Output Class Initialized
INFO - 2021-07-28 05:08:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:26 --> Input Class Initialized
INFO - 2021-07-28 05:08:26 --> Language Class Initialized
INFO - 2021-07-28 05:08:26 --> Language Class Initialized
INFO - 2021-07-28 05:08:26 --> Config Class Initialized
INFO - 2021-07-28 05:08:26 --> Loader Class Initialized
INFO - 2021-07-28 05:08:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:26 --> Controller Class Initialized
INFO - 2021-07-28 05:08:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:27 --> Total execution time: 0.0995
INFO - 2021-07-28 05:08:30 --> Config Class Initialized
INFO - 2021-07-28 05:08:30 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:30 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:30 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:30 --> URI Class Initialized
INFO - 2021-07-28 05:08:30 --> Router Class Initialized
INFO - 2021-07-28 05:08:30 --> Output Class Initialized
INFO - 2021-07-28 05:08:30 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:30 --> Input Class Initialized
INFO - 2021-07-28 05:08:30 --> Language Class Initialized
INFO - 2021-07-28 05:08:30 --> Language Class Initialized
INFO - 2021-07-28 05:08:30 --> Config Class Initialized
INFO - 2021-07-28 05:08:30 --> Loader Class Initialized
INFO - 2021-07-28 05:08:30 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:30 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:30 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:30 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:30 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:30 --> Controller Class Initialized
INFO - 2021-07-28 05:08:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:31 --> Total execution time: 0.8120
INFO - 2021-07-28 05:08:52 --> Config Class Initialized
INFO - 2021-07-28 05:08:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:52 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:52 --> URI Class Initialized
INFO - 2021-07-28 05:08:52 --> Router Class Initialized
INFO - 2021-07-28 05:08:52 --> Output Class Initialized
INFO - 2021-07-28 05:08:52 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:52 --> Input Class Initialized
INFO - 2021-07-28 05:08:52 --> Language Class Initialized
INFO - 2021-07-28 05:08:52 --> Language Class Initialized
INFO - 2021-07-28 05:08:52 --> Config Class Initialized
INFO - 2021-07-28 05:08:52 --> Loader Class Initialized
INFO - 2021-07-28 05:08:52 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:52 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:52 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:52 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:52 --> Controller Class Initialized
INFO - 2021-07-28 05:08:52 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:08:52 --> Config Class Initialized
INFO - 2021-07-28 05:08:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:52 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:52 --> URI Class Initialized
INFO - 2021-07-28 05:08:52 --> Router Class Initialized
INFO - 2021-07-28 05:08:52 --> Output Class Initialized
INFO - 2021-07-28 05:08:52 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:52 --> Input Class Initialized
INFO - 2021-07-28 05:08:52 --> Language Class Initialized
INFO - 2021-07-28 05:08:52 --> Language Class Initialized
INFO - 2021-07-28 05:08:52 --> Config Class Initialized
INFO - 2021-07-28 05:08:52 --> Loader Class Initialized
INFO - 2021-07-28 05:08:52 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:52 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:52 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:52 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:52 --> Controller Class Initialized
DEBUG - 2021-07-28 05:08:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:08:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:08:52 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:52 --> Total execution time: 0.0547
INFO - 2021-07-28 05:08:57 --> Config Class Initialized
INFO - 2021-07-28 05:08:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:57 --> URI Class Initialized
INFO - 2021-07-28 05:08:57 --> Router Class Initialized
INFO - 2021-07-28 05:08:57 --> Output Class Initialized
INFO - 2021-07-28 05:08:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:57 --> Input Class Initialized
INFO - 2021-07-28 05:08:57 --> Language Class Initialized
INFO - 2021-07-28 05:08:57 --> Language Class Initialized
INFO - 2021-07-28 05:08:57 --> Config Class Initialized
INFO - 2021-07-28 05:08:57 --> Loader Class Initialized
INFO - 2021-07-28 05:08:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:58 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:58 --> Controller Class Initialized
INFO - 2021-07-28 05:08:58 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:08:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:08:58 --> Total execution time: 0.0572
INFO - 2021-07-28 05:08:59 --> Config Class Initialized
INFO - 2021-07-28 05:08:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:08:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:08:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:08:59 --> URI Class Initialized
INFO - 2021-07-28 05:08:59 --> Router Class Initialized
INFO - 2021-07-28 05:08:59 --> Output Class Initialized
INFO - 2021-07-28 05:08:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:08:59 --> Input Class Initialized
INFO - 2021-07-28 05:08:59 --> Language Class Initialized
INFO - 2021-07-28 05:08:59 --> Language Class Initialized
INFO - 2021-07-28 05:08:59 --> Config Class Initialized
INFO - 2021-07-28 05:08:59 --> Loader Class Initialized
INFO - 2021-07-28 05:08:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:08:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:08:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:08:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:08:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:08:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:08:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:08:59 --> Controller Class Initialized
DEBUG - 2021-07-28 05:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:09:00 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:00 --> Total execution time: 0.6862
INFO - 2021-07-28 05:09:02 --> Config Class Initialized
INFO - 2021-07-28 05:09:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:02 --> URI Class Initialized
INFO - 2021-07-28 05:09:02 --> Router Class Initialized
INFO - 2021-07-28 05:09:02 --> Output Class Initialized
INFO - 2021-07-28 05:09:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:02 --> Input Class Initialized
INFO - 2021-07-28 05:09:02 --> Language Class Initialized
INFO - 2021-07-28 05:09:02 --> Language Class Initialized
INFO - 2021-07-28 05:09:02 --> Config Class Initialized
INFO - 2021-07-28 05:09:02 --> Loader Class Initialized
INFO - 2021-07-28 05:09:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:02 --> Controller Class Initialized
DEBUG - 2021-07-28 05:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:09:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:02 --> Total execution time: 0.0632
INFO - 2021-07-28 05:09:09 --> Config Class Initialized
INFO - 2021-07-28 05:09:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:09 --> URI Class Initialized
INFO - 2021-07-28 05:09:09 --> Router Class Initialized
INFO - 2021-07-28 05:09:09 --> Output Class Initialized
INFO - 2021-07-28 05:09:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:09 --> Input Class Initialized
INFO - 2021-07-28 05:09:09 --> Language Class Initialized
INFO - 2021-07-28 05:09:09 --> Language Class Initialized
INFO - 2021-07-28 05:09:09 --> Config Class Initialized
INFO - 2021-07-28 05:09:09 --> Loader Class Initialized
INFO - 2021-07-28 05:09:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:09 --> Controller Class Initialized
DEBUG - 2021-07-28 05:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:09:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:09 --> Total execution time: 0.0708
INFO - 2021-07-28 05:09:09 --> Config Class Initialized
INFO - 2021-07-28 05:09:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:09 --> URI Class Initialized
INFO - 2021-07-28 05:09:09 --> Router Class Initialized
INFO - 2021-07-28 05:09:09 --> Output Class Initialized
INFO - 2021-07-28 05:09:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:09 --> Input Class Initialized
INFO - 2021-07-28 05:09:09 --> Language Class Initialized
INFO - 2021-07-28 05:09:09 --> Language Class Initialized
INFO - 2021-07-28 05:09:09 --> Config Class Initialized
INFO - 2021-07-28 05:09:09 --> Loader Class Initialized
INFO - 2021-07-28 05:09:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:09 --> Controller Class Initialized
INFO - 2021-07-28 05:09:11 --> Config Class Initialized
INFO - 2021-07-28 05:09:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:11 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:11 --> URI Class Initialized
INFO - 2021-07-28 05:09:11 --> Router Class Initialized
INFO - 2021-07-28 05:09:11 --> Output Class Initialized
INFO - 2021-07-28 05:09:11 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:11 --> Input Class Initialized
INFO - 2021-07-28 05:09:11 --> Language Class Initialized
INFO - 2021-07-28 05:09:11 --> Language Class Initialized
INFO - 2021-07-28 05:09:11 --> Config Class Initialized
INFO - 2021-07-28 05:09:11 --> Loader Class Initialized
INFO - 2021-07-28 05:09:11 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:11 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:11 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:11 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:11 --> Controller Class Initialized
INFO - 2021-07-28 05:09:11 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:11 --> Total execution time: 0.0977
INFO - 2021-07-28 05:09:23 --> Config Class Initialized
INFO - 2021-07-28 05:09:23 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:23 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:23 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:23 --> URI Class Initialized
INFO - 2021-07-28 05:09:23 --> Router Class Initialized
INFO - 2021-07-28 05:09:23 --> Output Class Initialized
INFO - 2021-07-28 05:09:23 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:23 --> Input Class Initialized
INFO - 2021-07-28 05:09:23 --> Language Class Initialized
INFO - 2021-07-28 05:09:23 --> Language Class Initialized
INFO - 2021-07-28 05:09:23 --> Config Class Initialized
INFO - 2021-07-28 05:09:23 --> Loader Class Initialized
INFO - 2021-07-28 05:09:23 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:23 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:23 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:23 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:23 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:23 --> Controller Class Initialized
INFO - 2021-07-28 05:09:23 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:23 --> Total execution time: 0.0542
INFO - 2021-07-28 05:09:26 --> Config Class Initialized
INFO - 2021-07-28 05:09:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:26 --> URI Class Initialized
INFO - 2021-07-28 05:09:26 --> Router Class Initialized
INFO - 2021-07-28 05:09:26 --> Output Class Initialized
INFO - 2021-07-28 05:09:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:26 --> Input Class Initialized
INFO - 2021-07-28 05:09:26 --> Language Class Initialized
INFO - 2021-07-28 05:09:26 --> Language Class Initialized
INFO - 2021-07-28 05:09:26 --> Config Class Initialized
INFO - 2021-07-28 05:09:26 --> Loader Class Initialized
INFO - 2021-07-28 05:09:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:26 --> Controller Class Initialized
INFO - 2021-07-28 05:09:26 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:26 --> Total execution time: 0.0586
INFO - 2021-07-28 05:09:31 --> Config Class Initialized
INFO - 2021-07-28 05:09:31 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:31 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:31 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:31 --> URI Class Initialized
INFO - 2021-07-28 05:09:31 --> Router Class Initialized
INFO - 2021-07-28 05:09:31 --> Output Class Initialized
INFO - 2021-07-28 05:09:31 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:31 --> Input Class Initialized
INFO - 2021-07-28 05:09:31 --> Language Class Initialized
INFO - 2021-07-28 05:09:31 --> Language Class Initialized
INFO - 2021-07-28 05:09:31 --> Config Class Initialized
INFO - 2021-07-28 05:09:31 --> Loader Class Initialized
INFO - 2021-07-28 05:09:31 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:31 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:31 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:31 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:31 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:31 --> Controller Class Initialized
INFO - 2021-07-28 05:09:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:32 --> Total execution time: 0.9123
INFO - 2021-07-28 05:09:34 --> Config Class Initialized
INFO - 2021-07-28 05:09:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:34 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:34 --> URI Class Initialized
INFO - 2021-07-28 05:09:34 --> Router Class Initialized
INFO - 2021-07-28 05:09:35 --> Output Class Initialized
INFO - 2021-07-28 05:09:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:35 --> Input Class Initialized
INFO - 2021-07-28 05:09:35 --> Language Class Initialized
INFO - 2021-07-28 05:09:35 --> Language Class Initialized
INFO - 2021-07-28 05:09:35 --> Config Class Initialized
INFO - 2021-07-28 05:09:35 --> Loader Class Initialized
INFO - 2021-07-28 05:09:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:35 --> Controller Class Initialized
INFO - 2021-07-28 05:09:35 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:35 --> Total execution time: 0.0562
INFO - 2021-07-28 05:09:38 --> Config Class Initialized
INFO - 2021-07-28 05:09:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:38 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:38 --> URI Class Initialized
INFO - 2021-07-28 05:09:38 --> Router Class Initialized
INFO - 2021-07-28 05:09:39 --> Output Class Initialized
INFO - 2021-07-28 05:09:39 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:39 --> Input Class Initialized
INFO - 2021-07-28 05:09:39 --> Language Class Initialized
INFO - 2021-07-28 05:09:39 --> Language Class Initialized
INFO - 2021-07-28 05:09:39 --> Config Class Initialized
INFO - 2021-07-28 05:09:39 --> Loader Class Initialized
INFO - 2021-07-28 05:09:39 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:39 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:39 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:39 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:39 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:39 --> Controller Class Initialized
INFO - 2021-07-28 05:09:39 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:39 --> Total execution time: 0.8942
INFO - 2021-07-28 05:09:40 --> Config Class Initialized
INFO - 2021-07-28 05:09:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:40 --> URI Class Initialized
INFO - 2021-07-28 05:09:40 --> Router Class Initialized
INFO - 2021-07-28 05:09:40 --> Output Class Initialized
INFO - 2021-07-28 05:09:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:40 --> Input Class Initialized
INFO - 2021-07-28 05:09:40 --> Language Class Initialized
INFO - 2021-07-28 05:09:40 --> Language Class Initialized
INFO - 2021-07-28 05:09:40 --> Config Class Initialized
INFO - 2021-07-28 05:09:40 --> Loader Class Initialized
INFO - 2021-07-28 05:09:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:40 --> Controller Class Initialized
INFO - 2021-07-28 05:09:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:40 --> Total execution time: 0.0610
INFO - 2021-07-28 05:09:45 --> Config Class Initialized
INFO - 2021-07-28 05:09:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:45 --> URI Class Initialized
INFO - 2021-07-28 05:09:45 --> Router Class Initialized
INFO - 2021-07-28 05:09:45 --> Output Class Initialized
INFO - 2021-07-28 05:09:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:45 --> Input Class Initialized
INFO - 2021-07-28 05:09:45 --> Language Class Initialized
INFO - 2021-07-28 05:09:45 --> Language Class Initialized
INFO - 2021-07-28 05:09:45 --> Config Class Initialized
INFO - 2021-07-28 05:09:45 --> Loader Class Initialized
INFO - 2021-07-28 05:09:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:45 --> Controller Class Initialized
INFO - 2021-07-28 05:09:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:46 --> Total execution time: 0.9168
INFO - 2021-07-28 05:09:49 --> Config Class Initialized
INFO - 2021-07-28 05:09:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:49 --> URI Class Initialized
INFO - 2021-07-28 05:09:49 --> Router Class Initialized
INFO - 2021-07-28 05:09:49 --> Output Class Initialized
INFO - 2021-07-28 05:09:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:49 --> Input Class Initialized
INFO - 2021-07-28 05:09:49 --> Language Class Initialized
INFO - 2021-07-28 05:09:49 --> Language Class Initialized
INFO - 2021-07-28 05:09:49 --> Config Class Initialized
INFO - 2021-07-28 05:09:49 --> Loader Class Initialized
INFO - 2021-07-28 05:09:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:49 --> Controller Class Initialized
INFO - 2021-07-28 05:09:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:50 --> Total execution time: 0.9087
INFO - 2021-07-28 05:09:53 --> Config Class Initialized
INFO - 2021-07-28 05:09:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:53 --> URI Class Initialized
INFO - 2021-07-28 05:09:53 --> Router Class Initialized
INFO - 2021-07-28 05:09:53 --> Output Class Initialized
INFO - 2021-07-28 05:09:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:53 --> Input Class Initialized
INFO - 2021-07-28 05:09:53 --> Language Class Initialized
INFO - 2021-07-28 05:09:53 --> Language Class Initialized
INFO - 2021-07-28 05:09:53 --> Config Class Initialized
INFO - 2021-07-28 05:09:53 --> Loader Class Initialized
INFO - 2021-07-28 05:09:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:53 --> Controller Class Initialized
DEBUG - 2021-07-28 05:09:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:09:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:09:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:53 --> Total execution time: 0.0589
INFO - 2021-07-28 05:09:55 --> Config Class Initialized
INFO - 2021-07-28 05:09:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:55 --> URI Class Initialized
INFO - 2021-07-28 05:09:55 --> Router Class Initialized
INFO - 2021-07-28 05:09:55 --> Output Class Initialized
INFO - 2021-07-28 05:09:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:55 --> Input Class Initialized
INFO - 2021-07-28 05:09:55 --> Language Class Initialized
INFO - 2021-07-28 05:09:55 --> Language Class Initialized
INFO - 2021-07-28 05:09:55 --> Config Class Initialized
INFO - 2021-07-28 05:09:55 --> Loader Class Initialized
INFO - 2021-07-28 05:09:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:55 --> Controller Class Initialized
DEBUG - 2021-07-28 05:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:09:55 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:55 --> Total execution time: 0.0715
INFO - 2021-07-28 05:09:56 --> Config Class Initialized
INFO - 2021-07-28 05:09:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:09:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:09:56 --> Utf8 Class Initialized
INFO - 2021-07-28 05:09:56 --> URI Class Initialized
INFO - 2021-07-28 05:09:56 --> Router Class Initialized
INFO - 2021-07-28 05:09:56 --> Output Class Initialized
INFO - 2021-07-28 05:09:56 --> Security Class Initialized
DEBUG - 2021-07-28 05:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:09:56 --> Input Class Initialized
INFO - 2021-07-28 05:09:56 --> Language Class Initialized
INFO - 2021-07-28 05:09:56 --> Language Class Initialized
INFO - 2021-07-28 05:09:56 --> Config Class Initialized
INFO - 2021-07-28 05:09:56 --> Loader Class Initialized
INFO - 2021-07-28 05:09:56 --> Helper loaded: url_helper
INFO - 2021-07-28 05:09:56 --> Helper loaded: file_helper
INFO - 2021-07-28 05:09:56 --> Helper loaded: form_helper
INFO - 2021-07-28 05:09:56 --> Helper loaded: my_helper
INFO - 2021-07-28 05:09:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:09:56 --> Controller Class Initialized
INFO - 2021-07-28 05:09:57 --> Final output sent to browser
DEBUG - 2021-07-28 05:09:57 --> Total execution time: 0.0991
INFO - 2021-07-28 05:10:02 --> Config Class Initialized
INFO - 2021-07-28 05:10:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:02 --> URI Class Initialized
INFO - 2021-07-28 05:10:02 --> Router Class Initialized
INFO - 2021-07-28 05:10:02 --> Output Class Initialized
INFO - 2021-07-28 05:10:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:02 --> Input Class Initialized
INFO - 2021-07-28 05:10:02 --> Language Class Initialized
INFO - 2021-07-28 05:10:02 --> Language Class Initialized
INFO - 2021-07-28 05:10:02 --> Config Class Initialized
INFO - 2021-07-28 05:10:02 --> Loader Class Initialized
INFO - 2021-07-28 05:10:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:02 --> Controller Class Initialized
INFO - 2021-07-28 05:10:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:03 --> Total execution time: 0.8051
INFO - 2021-07-28 05:10:03 --> Config Class Initialized
INFO - 2021-07-28 05:10:03 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:03 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:03 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:03 --> URI Class Initialized
INFO - 2021-07-28 05:10:03 --> Router Class Initialized
INFO - 2021-07-28 05:10:03 --> Output Class Initialized
INFO - 2021-07-28 05:10:03 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:03 --> Input Class Initialized
INFO - 2021-07-28 05:10:03 --> Language Class Initialized
INFO - 2021-07-28 05:10:03 --> Language Class Initialized
INFO - 2021-07-28 05:10:03 --> Config Class Initialized
INFO - 2021-07-28 05:10:03 --> Loader Class Initialized
INFO - 2021-07-28 05:10:03 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:03 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:03 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:03 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:03 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:03 --> Controller Class Initialized
INFO - 2021-07-28 05:10:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:03 --> Total execution time: 0.0465
INFO - 2021-07-28 05:10:07 --> Config Class Initialized
INFO - 2021-07-28 05:10:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:07 --> URI Class Initialized
INFO - 2021-07-28 05:10:07 --> Router Class Initialized
INFO - 2021-07-28 05:10:07 --> Output Class Initialized
INFO - 2021-07-28 05:10:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:07 --> Input Class Initialized
INFO - 2021-07-28 05:10:07 --> Language Class Initialized
INFO - 2021-07-28 05:10:07 --> Language Class Initialized
INFO - 2021-07-28 05:10:07 --> Config Class Initialized
INFO - 2021-07-28 05:10:07 --> Loader Class Initialized
INFO - 2021-07-28 05:10:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:07 --> Controller Class Initialized
INFO - 2021-07-28 05:10:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:08 --> Total execution time: 0.7987
INFO - 2021-07-28 05:10:09 --> Config Class Initialized
INFO - 2021-07-28 05:10:09 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:09 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:09 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:09 --> URI Class Initialized
INFO - 2021-07-28 05:10:09 --> Router Class Initialized
INFO - 2021-07-28 05:10:09 --> Output Class Initialized
INFO - 2021-07-28 05:10:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:09 --> Input Class Initialized
INFO - 2021-07-28 05:10:09 --> Language Class Initialized
INFO - 2021-07-28 05:10:09 --> Language Class Initialized
INFO - 2021-07-28 05:10:09 --> Config Class Initialized
INFO - 2021-07-28 05:10:09 --> Loader Class Initialized
INFO - 2021-07-28 05:10:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:09 --> Controller Class Initialized
INFO - 2021-07-28 05:10:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:09 --> Total execution time: 0.1044
INFO - 2021-07-28 05:10:13 --> Config Class Initialized
INFO - 2021-07-28 05:10:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:13 --> URI Class Initialized
INFO - 2021-07-28 05:10:13 --> Router Class Initialized
INFO - 2021-07-28 05:10:13 --> Output Class Initialized
INFO - 2021-07-28 05:10:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:13 --> Input Class Initialized
INFO - 2021-07-28 05:10:13 --> Language Class Initialized
INFO - 2021-07-28 05:10:13 --> Language Class Initialized
INFO - 2021-07-28 05:10:13 --> Config Class Initialized
INFO - 2021-07-28 05:10:13 --> Loader Class Initialized
INFO - 2021-07-28 05:10:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:13 --> Controller Class Initialized
INFO - 2021-07-28 05:10:14 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:14 --> Total execution time: 0.7366
INFO - 2021-07-28 05:10:19 --> Config Class Initialized
INFO - 2021-07-28 05:10:19 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:19 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:19 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:19 --> URI Class Initialized
INFO - 2021-07-28 05:10:19 --> Router Class Initialized
INFO - 2021-07-28 05:10:19 --> Output Class Initialized
INFO - 2021-07-28 05:10:19 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:19 --> Input Class Initialized
INFO - 2021-07-28 05:10:19 --> Language Class Initialized
INFO - 2021-07-28 05:10:19 --> Language Class Initialized
INFO - 2021-07-28 05:10:19 --> Config Class Initialized
INFO - 2021-07-28 05:10:19 --> Loader Class Initialized
INFO - 2021-07-28 05:10:19 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:19 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:19 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:19 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:19 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:19 --> Controller Class Initialized
INFO - 2021-07-28 05:10:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:20 --> Total execution time: 0.7481
INFO - 2021-07-28 05:10:22 --> Config Class Initialized
INFO - 2021-07-28 05:10:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:22 --> URI Class Initialized
INFO - 2021-07-28 05:10:22 --> Router Class Initialized
INFO - 2021-07-28 05:10:22 --> Output Class Initialized
INFO - 2021-07-28 05:10:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:22 --> Input Class Initialized
INFO - 2021-07-28 05:10:22 --> Language Class Initialized
INFO - 2021-07-28 05:10:22 --> Language Class Initialized
INFO - 2021-07-28 05:10:22 --> Config Class Initialized
INFO - 2021-07-28 05:10:22 --> Loader Class Initialized
INFO - 2021-07-28 05:10:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:22 --> Controller Class Initialized
DEBUG - 2021-07-28 05:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:10:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:22 --> Total execution time: 0.0670
INFO - 2021-07-28 05:10:28 --> Config Class Initialized
INFO - 2021-07-28 05:10:28 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:28 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:28 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:28 --> URI Class Initialized
INFO - 2021-07-28 05:10:28 --> Router Class Initialized
INFO - 2021-07-28 05:10:28 --> Output Class Initialized
INFO - 2021-07-28 05:10:28 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:28 --> Input Class Initialized
INFO - 2021-07-28 05:10:28 --> Language Class Initialized
INFO - 2021-07-28 05:10:28 --> Language Class Initialized
INFO - 2021-07-28 05:10:28 --> Config Class Initialized
INFO - 2021-07-28 05:10:28 --> Loader Class Initialized
INFO - 2021-07-28 05:10:28 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:28 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:28 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:28 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:28 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:28 --> Controller Class Initialized
INFO - 2021-07-28 05:10:28 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:10:28 --> Config Class Initialized
INFO - 2021-07-28 05:10:28 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:28 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:28 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:28 --> URI Class Initialized
INFO - 2021-07-28 05:10:28 --> Router Class Initialized
INFO - 2021-07-28 05:10:28 --> Output Class Initialized
INFO - 2021-07-28 05:10:28 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:28 --> Input Class Initialized
INFO - 2021-07-28 05:10:28 --> Language Class Initialized
INFO - 2021-07-28 05:10:28 --> Language Class Initialized
INFO - 2021-07-28 05:10:28 --> Config Class Initialized
INFO - 2021-07-28 05:10:28 --> Loader Class Initialized
INFO - 2021-07-28 05:10:28 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:28 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:28 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:28 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:28 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:28 --> Controller Class Initialized
DEBUG - 2021-07-28 05:10:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:10:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:10:28 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:28 --> Total execution time: 0.0418
INFO - 2021-07-28 05:10:37 --> Config Class Initialized
INFO - 2021-07-28 05:10:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:37 --> URI Class Initialized
INFO - 2021-07-28 05:10:37 --> Router Class Initialized
INFO - 2021-07-28 05:10:37 --> Output Class Initialized
INFO - 2021-07-28 05:10:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:37 --> Input Class Initialized
INFO - 2021-07-28 05:10:37 --> Language Class Initialized
INFO - 2021-07-28 05:10:37 --> Language Class Initialized
INFO - 2021-07-28 05:10:37 --> Config Class Initialized
INFO - 2021-07-28 05:10:37 --> Loader Class Initialized
INFO - 2021-07-28 05:10:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:37 --> Controller Class Initialized
INFO - 2021-07-28 05:10:37 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:10:37 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:37 --> Total execution time: 0.0454
INFO - 2021-07-28 05:10:39 --> Config Class Initialized
INFO - 2021-07-28 05:10:39 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:39 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:39 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:39 --> URI Class Initialized
INFO - 2021-07-28 05:10:39 --> Router Class Initialized
INFO - 2021-07-28 05:10:39 --> Output Class Initialized
INFO - 2021-07-28 05:10:39 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:39 --> Input Class Initialized
INFO - 2021-07-28 05:10:39 --> Language Class Initialized
INFO - 2021-07-28 05:10:39 --> Language Class Initialized
INFO - 2021-07-28 05:10:39 --> Config Class Initialized
INFO - 2021-07-28 05:10:39 --> Loader Class Initialized
INFO - 2021-07-28 05:10:39 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:39 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:39 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:39 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:39 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:39 --> Controller Class Initialized
DEBUG - 2021-07-28 05:10:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:10:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:10:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:40 --> Total execution time: 0.6960
INFO - 2021-07-28 05:10:49 --> Config Class Initialized
INFO - 2021-07-28 05:10:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:49 --> URI Class Initialized
INFO - 2021-07-28 05:10:49 --> Router Class Initialized
INFO - 2021-07-28 05:10:49 --> Output Class Initialized
INFO - 2021-07-28 05:10:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:49 --> Input Class Initialized
INFO - 2021-07-28 05:10:49 --> Language Class Initialized
INFO - 2021-07-28 05:10:49 --> Language Class Initialized
INFO - 2021-07-28 05:10:49 --> Config Class Initialized
INFO - 2021-07-28 05:10:49 --> Loader Class Initialized
INFO - 2021-07-28 05:10:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:49 --> Controller Class Initialized
DEBUG - 2021-07-28 05:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:10:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:10:49 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:49 --> Total execution time: 0.0529
INFO - 2021-07-28 05:10:50 --> Config Class Initialized
INFO - 2021-07-28 05:10:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:50 --> URI Class Initialized
INFO - 2021-07-28 05:10:50 --> Router Class Initialized
INFO - 2021-07-28 05:10:50 --> Output Class Initialized
INFO - 2021-07-28 05:10:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:50 --> Input Class Initialized
INFO - 2021-07-28 05:10:50 --> Language Class Initialized
INFO - 2021-07-28 05:10:50 --> Language Class Initialized
INFO - 2021-07-28 05:10:50 --> Config Class Initialized
INFO - 2021-07-28 05:10:50 --> Loader Class Initialized
INFO - 2021-07-28 05:10:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:50 --> Controller Class Initialized
DEBUG - 2021-07-28 05:10:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:10:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:10:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:50 --> Total execution time: 0.0569
INFO - 2021-07-28 05:10:50 --> Config Class Initialized
INFO - 2021-07-28 05:10:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:50 --> URI Class Initialized
INFO - 2021-07-28 05:10:50 --> Router Class Initialized
INFO - 2021-07-28 05:10:50 --> Output Class Initialized
INFO - 2021-07-28 05:10:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:50 --> Input Class Initialized
INFO - 2021-07-28 05:10:50 --> Language Class Initialized
INFO - 2021-07-28 05:10:50 --> Language Class Initialized
INFO - 2021-07-28 05:10:50 --> Config Class Initialized
INFO - 2021-07-28 05:10:50 --> Loader Class Initialized
INFO - 2021-07-28 05:10:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:50 --> Controller Class Initialized
INFO - 2021-07-28 05:10:53 --> Config Class Initialized
INFO - 2021-07-28 05:10:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:53 --> URI Class Initialized
INFO - 2021-07-28 05:10:53 --> Router Class Initialized
INFO - 2021-07-28 05:10:53 --> Output Class Initialized
INFO - 2021-07-28 05:10:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:53 --> Input Class Initialized
INFO - 2021-07-28 05:10:53 --> Language Class Initialized
INFO - 2021-07-28 05:10:53 --> Language Class Initialized
INFO - 2021-07-28 05:10:53 --> Config Class Initialized
INFO - 2021-07-28 05:10:53 --> Loader Class Initialized
INFO - 2021-07-28 05:10:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:53 --> Controller Class Initialized
INFO - 2021-07-28 05:10:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:53 --> Total execution time: 0.1035
INFO - 2021-07-28 05:10:56 --> Config Class Initialized
INFO - 2021-07-28 05:10:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:56 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:56 --> URI Class Initialized
INFO - 2021-07-28 05:10:56 --> Router Class Initialized
INFO - 2021-07-28 05:10:56 --> Output Class Initialized
INFO - 2021-07-28 05:10:56 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:56 --> Input Class Initialized
INFO - 2021-07-28 05:10:56 --> Language Class Initialized
INFO - 2021-07-28 05:10:56 --> Language Class Initialized
INFO - 2021-07-28 05:10:56 --> Config Class Initialized
INFO - 2021-07-28 05:10:56 --> Loader Class Initialized
INFO - 2021-07-28 05:10:56 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:56 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:56 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:56 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:56 --> Controller Class Initialized
INFO - 2021-07-28 05:10:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:56 --> Total execution time: 0.0474
INFO - 2021-07-28 05:10:58 --> Config Class Initialized
INFO - 2021-07-28 05:10:58 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:10:58 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:10:58 --> Utf8 Class Initialized
INFO - 2021-07-28 05:10:58 --> URI Class Initialized
INFO - 2021-07-28 05:10:58 --> Router Class Initialized
INFO - 2021-07-28 05:10:58 --> Output Class Initialized
INFO - 2021-07-28 05:10:58 --> Security Class Initialized
DEBUG - 2021-07-28 05:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:10:58 --> Input Class Initialized
INFO - 2021-07-28 05:10:58 --> Language Class Initialized
INFO - 2021-07-28 05:10:58 --> Language Class Initialized
INFO - 2021-07-28 05:10:58 --> Config Class Initialized
INFO - 2021-07-28 05:10:58 --> Loader Class Initialized
INFO - 2021-07-28 05:10:58 --> Helper loaded: url_helper
INFO - 2021-07-28 05:10:58 --> Helper loaded: file_helper
INFO - 2021-07-28 05:10:58 --> Helper loaded: form_helper
INFO - 2021-07-28 05:10:58 --> Helper loaded: my_helper
INFO - 2021-07-28 05:10:58 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:10:58 --> Controller Class Initialized
INFO - 2021-07-28 05:10:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:10:58 --> Total execution time: 0.0541
INFO - 2021-07-28 05:11:00 --> Config Class Initialized
INFO - 2021-07-28 05:11:00 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:00 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:00 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:00 --> URI Class Initialized
INFO - 2021-07-28 05:11:00 --> Router Class Initialized
INFO - 2021-07-28 05:11:00 --> Output Class Initialized
INFO - 2021-07-28 05:11:00 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:00 --> Input Class Initialized
INFO - 2021-07-28 05:11:00 --> Language Class Initialized
INFO - 2021-07-28 05:11:00 --> Language Class Initialized
INFO - 2021-07-28 05:11:00 --> Config Class Initialized
INFO - 2021-07-28 05:11:00 --> Loader Class Initialized
INFO - 2021-07-28 05:11:00 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:00 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:00 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:00 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:00 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:00 --> Controller Class Initialized
INFO - 2021-07-28 05:11:00 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:00 --> Total execution time: 0.0613
INFO - 2021-07-28 05:11:06 --> Config Class Initialized
INFO - 2021-07-28 05:11:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:06 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:06 --> URI Class Initialized
INFO - 2021-07-28 05:11:06 --> Router Class Initialized
INFO - 2021-07-28 05:11:06 --> Output Class Initialized
INFO - 2021-07-28 05:11:06 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:06 --> Input Class Initialized
INFO - 2021-07-28 05:11:06 --> Language Class Initialized
INFO - 2021-07-28 05:11:06 --> Language Class Initialized
INFO - 2021-07-28 05:11:06 --> Config Class Initialized
INFO - 2021-07-28 05:11:06 --> Loader Class Initialized
INFO - 2021-07-28 05:11:06 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:06 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:06 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:06 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:06 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:06 --> Controller Class Initialized
DEBUG - 2021-07-28 05:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:11:06 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:06 --> Total execution time: 0.0697
INFO - 2021-07-28 05:11:07 --> Config Class Initialized
INFO - 2021-07-28 05:11:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:07 --> URI Class Initialized
INFO - 2021-07-28 05:11:07 --> Router Class Initialized
INFO - 2021-07-28 05:11:07 --> Output Class Initialized
INFO - 2021-07-28 05:11:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:07 --> Input Class Initialized
INFO - 2021-07-28 05:11:07 --> Language Class Initialized
INFO - 2021-07-28 05:11:07 --> Language Class Initialized
INFO - 2021-07-28 05:11:07 --> Config Class Initialized
INFO - 2021-07-28 05:11:07 --> Loader Class Initialized
INFO - 2021-07-28 05:11:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:07 --> Controller Class Initialized
DEBUG - 2021-07-28 05:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:11:07 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:07 --> Total execution time: 0.0434
INFO - 2021-07-28 05:11:08 --> Config Class Initialized
INFO - 2021-07-28 05:11:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:08 --> URI Class Initialized
INFO - 2021-07-28 05:11:08 --> Router Class Initialized
INFO - 2021-07-28 05:11:08 --> Output Class Initialized
INFO - 2021-07-28 05:11:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:08 --> Input Class Initialized
INFO - 2021-07-28 05:11:08 --> Language Class Initialized
INFO - 2021-07-28 05:11:08 --> Language Class Initialized
INFO - 2021-07-28 05:11:08 --> Config Class Initialized
INFO - 2021-07-28 05:11:08 --> Loader Class Initialized
INFO - 2021-07-28 05:11:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:08 --> Controller Class Initialized
INFO - 2021-07-28 05:11:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:09 --> Total execution time: 0.0853
INFO - 2021-07-28 05:11:13 --> Config Class Initialized
INFO - 2021-07-28 05:11:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:13 --> URI Class Initialized
INFO - 2021-07-28 05:11:13 --> Router Class Initialized
INFO - 2021-07-28 05:11:13 --> Output Class Initialized
INFO - 2021-07-28 05:11:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:13 --> Input Class Initialized
INFO - 2021-07-28 05:11:13 --> Language Class Initialized
INFO - 2021-07-28 05:11:13 --> Language Class Initialized
INFO - 2021-07-28 05:11:13 --> Config Class Initialized
INFO - 2021-07-28 05:11:13 --> Loader Class Initialized
INFO - 2021-07-28 05:11:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:13 --> Controller Class Initialized
INFO - 2021-07-28 05:11:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:13 --> Total execution time: 0.0540
INFO - 2021-07-28 05:11:17 --> Config Class Initialized
INFO - 2021-07-28 05:11:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:17 --> URI Class Initialized
INFO - 2021-07-28 05:11:17 --> Router Class Initialized
INFO - 2021-07-28 05:11:17 --> Output Class Initialized
INFO - 2021-07-28 05:11:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:17 --> Input Class Initialized
INFO - 2021-07-28 05:11:17 --> Language Class Initialized
INFO - 2021-07-28 05:11:17 --> Language Class Initialized
INFO - 2021-07-28 05:11:17 --> Config Class Initialized
INFO - 2021-07-28 05:11:17 --> Loader Class Initialized
INFO - 2021-07-28 05:11:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:17 --> Controller Class Initialized
INFO - 2021-07-28 05:11:17 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:11:17 --> Config Class Initialized
INFO - 2021-07-28 05:11:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:17 --> URI Class Initialized
INFO - 2021-07-28 05:11:17 --> Router Class Initialized
INFO - 2021-07-28 05:11:17 --> Output Class Initialized
INFO - 2021-07-28 05:11:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:17 --> Input Class Initialized
INFO - 2021-07-28 05:11:17 --> Language Class Initialized
INFO - 2021-07-28 05:11:17 --> Language Class Initialized
INFO - 2021-07-28 05:11:17 --> Config Class Initialized
INFO - 2021-07-28 05:11:17 --> Loader Class Initialized
INFO - 2021-07-28 05:11:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:17 --> Controller Class Initialized
DEBUG - 2021-07-28 05:11:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:11:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:11:17 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:17 --> Total execution time: 0.0412
INFO - 2021-07-28 05:11:32 --> Config Class Initialized
INFO - 2021-07-28 05:11:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:32 --> URI Class Initialized
INFO - 2021-07-28 05:11:32 --> Router Class Initialized
INFO - 2021-07-28 05:11:32 --> Output Class Initialized
INFO - 2021-07-28 05:11:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:32 --> Input Class Initialized
INFO - 2021-07-28 05:11:32 --> Language Class Initialized
INFO - 2021-07-28 05:11:32 --> Language Class Initialized
INFO - 2021-07-28 05:11:32 --> Config Class Initialized
INFO - 2021-07-28 05:11:32 --> Loader Class Initialized
INFO - 2021-07-28 05:11:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:32 --> Controller Class Initialized
INFO - 2021-07-28 05:11:32 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:11:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:32 --> Total execution time: 0.0651
INFO - 2021-07-28 05:11:34 --> Config Class Initialized
INFO - 2021-07-28 05:11:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:34 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:34 --> URI Class Initialized
INFO - 2021-07-28 05:11:34 --> Router Class Initialized
INFO - 2021-07-28 05:11:34 --> Output Class Initialized
INFO - 2021-07-28 05:11:34 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:34 --> Input Class Initialized
INFO - 2021-07-28 05:11:34 --> Language Class Initialized
INFO - 2021-07-28 05:11:34 --> Language Class Initialized
INFO - 2021-07-28 05:11:34 --> Config Class Initialized
INFO - 2021-07-28 05:11:34 --> Loader Class Initialized
INFO - 2021-07-28 05:11:34 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:34 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:34 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:34 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:34 --> Controller Class Initialized
DEBUG - 2021-07-28 05:11:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:11:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:11:34 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:34 --> Total execution time: 0.6940
INFO - 2021-07-28 05:11:36 --> Config Class Initialized
INFO - 2021-07-28 05:11:36 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:36 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:36 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:36 --> URI Class Initialized
INFO - 2021-07-28 05:11:36 --> Router Class Initialized
INFO - 2021-07-28 05:11:36 --> Output Class Initialized
INFO - 2021-07-28 05:11:36 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:36 --> Input Class Initialized
INFO - 2021-07-28 05:11:36 --> Language Class Initialized
INFO - 2021-07-28 05:11:36 --> Language Class Initialized
INFO - 2021-07-28 05:11:36 --> Config Class Initialized
INFO - 2021-07-28 05:11:36 --> Loader Class Initialized
INFO - 2021-07-28 05:11:36 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:36 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:36 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:36 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:36 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:36 --> Controller Class Initialized
DEBUG - 2021-07-28 05:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:11:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:11:36 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:36 --> Total execution time: 0.0562
INFO - 2021-07-28 05:11:41 --> Config Class Initialized
INFO - 2021-07-28 05:11:41 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:41 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:41 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:41 --> URI Class Initialized
INFO - 2021-07-28 05:11:41 --> Router Class Initialized
INFO - 2021-07-28 05:11:41 --> Output Class Initialized
INFO - 2021-07-28 05:11:41 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:41 --> Input Class Initialized
INFO - 2021-07-28 05:11:41 --> Language Class Initialized
INFO - 2021-07-28 05:11:41 --> Language Class Initialized
INFO - 2021-07-28 05:11:41 --> Config Class Initialized
INFO - 2021-07-28 05:11:41 --> Loader Class Initialized
INFO - 2021-07-28 05:11:41 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:41 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:41 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:41 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:41 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:41 --> Controller Class Initialized
DEBUG - 2021-07-28 05:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:11:41 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:41 --> Total execution time: 0.0583
INFO - 2021-07-28 05:11:41 --> Config Class Initialized
INFO - 2021-07-28 05:11:41 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:41 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:41 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:41 --> URI Class Initialized
INFO - 2021-07-28 05:11:41 --> Router Class Initialized
INFO - 2021-07-28 05:11:41 --> Output Class Initialized
INFO - 2021-07-28 05:11:41 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:41 --> Input Class Initialized
INFO - 2021-07-28 05:11:41 --> Language Class Initialized
INFO - 2021-07-28 05:11:41 --> Language Class Initialized
INFO - 2021-07-28 05:11:41 --> Config Class Initialized
INFO - 2021-07-28 05:11:41 --> Loader Class Initialized
INFO - 2021-07-28 05:11:41 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:41 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:41 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:41 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:41 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:41 --> Controller Class Initialized
INFO - 2021-07-28 05:11:43 --> Config Class Initialized
INFO - 2021-07-28 05:11:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:43 --> URI Class Initialized
INFO - 2021-07-28 05:11:43 --> Router Class Initialized
INFO - 2021-07-28 05:11:43 --> Output Class Initialized
INFO - 2021-07-28 05:11:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:43 --> Input Class Initialized
INFO - 2021-07-28 05:11:43 --> Language Class Initialized
INFO - 2021-07-28 05:11:43 --> Language Class Initialized
INFO - 2021-07-28 05:11:43 --> Config Class Initialized
INFO - 2021-07-28 05:11:43 --> Loader Class Initialized
INFO - 2021-07-28 05:11:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:43 --> Controller Class Initialized
INFO - 2021-07-28 05:11:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:43 --> Total execution time: 0.0928
INFO - 2021-07-28 05:11:48 --> Config Class Initialized
INFO - 2021-07-28 05:11:48 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:48 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:48 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:48 --> URI Class Initialized
INFO - 2021-07-28 05:11:48 --> Router Class Initialized
INFO - 2021-07-28 05:11:48 --> Output Class Initialized
INFO - 2021-07-28 05:11:48 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:48 --> Input Class Initialized
INFO - 2021-07-28 05:11:48 --> Language Class Initialized
INFO - 2021-07-28 05:11:48 --> Language Class Initialized
INFO - 2021-07-28 05:11:48 --> Config Class Initialized
INFO - 2021-07-28 05:11:48 --> Loader Class Initialized
INFO - 2021-07-28 05:11:48 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:48 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:48 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:48 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:48 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:48 --> Controller Class Initialized
INFO - 2021-07-28 05:11:49 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:49 --> Total execution time: 0.9227
INFO - 2021-07-28 05:11:50 --> Config Class Initialized
INFO - 2021-07-28 05:11:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:50 --> URI Class Initialized
INFO - 2021-07-28 05:11:50 --> Router Class Initialized
INFO - 2021-07-28 05:11:50 --> Output Class Initialized
INFO - 2021-07-28 05:11:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:50 --> Input Class Initialized
INFO - 2021-07-28 05:11:50 --> Language Class Initialized
INFO - 2021-07-28 05:11:50 --> Language Class Initialized
INFO - 2021-07-28 05:11:50 --> Config Class Initialized
INFO - 2021-07-28 05:11:50 --> Loader Class Initialized
INFO - 2021-07-28 05:11:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:50 --> Controller Class Initialized
INFO - 2021-07-28 05:11:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:50 --> Total execution time: 0.0761
INFO - 2021-07-28 05:11:55 --> Config Class Initialized
INFO - 2021-07-28 05:11:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:55 --> URI Class Initialized
INFO - 2021-07-28 05:11:55 --> Router Class Initialized
INFO - 2021-07-28 05:11:55 --> Output Class Initialized
INFO - 2021-07-28 05:11:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:55 --> Input Class Initialized
INFO - 2021-07-28 05:11:55 --> Language Class Initialized
INFO - 2021-07-28 05:11:55 --> Language Class Initialized
INFO - 2021-07-28 05:11:55 --> Config Class Initialized
INFO - 2021-07-28 05:11:55 --> Loader Class Initialized
INFO - 2021-07-28 05:11:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:55 --> Controller Class Initialized
INFO - 2021-07-28 05:11:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:56 --> Total execution time: 0.9080
INFO - 2021-07-28 05:11:57 --> Config Class Initialized
INFO - 2021-07-28 05:11:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:11:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:11:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:11:57 --> URI Class Initialized
INFO - 2021-07-28 05:11:57 --> Router Class Initialized
INFO - 2021-07-28 05:11:57 --> Output Class Initialized
INFO - 2021-07-28 05:11:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:11:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:11:57 --> Input Class Initialized
INFO - 2021-07-28 05:11:57 --> Language Class Initialized
INFO - 2021-07-28 05:11:57 --> Language Class Initialized
INFO - 2021-07-28 05:11:57 --> Config Class Initialized
INFO - 2021-07-28 05:11:57 --> Loader Class Initialized
INFO - 2021-07-28 05:11:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:11:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:11:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:11:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:11:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:11:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:11:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:11:57 --> Controller Class Initialized
INFO - 2021-07-28 05:11:57 --> Final output sent to browser
DEBUG - 2021-07-28 05:11:57 --> Total execution time: 0.0546
INFO - 2021-07-28 05:12:00 --> Config Class Initialized
INFO - 2021-07-28 05:12:00 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:00 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:00 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:00 --> URI Class Initialized
INFO - 2021-07-28 05:12:00 --> Router Class Initialized
INFO - 2021-07-28 05:12:00 --> Output Class Initialized
INFO - 2021-07-28 05:12:00 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:00 --> Input Class Initialized
INFO - 2021-07-28 05:12:00 --> Language Class Initialized
INFO - 2021-07-28 05:12:00 --> Language Class Initialized
INFO - 2021-07-28 05:12:00 --> Config Class Initialized
INFO - 2021-07-28 05:12:00 --> Loader Class Initialized
INFO - 2021-07-28 05:12:00 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:00 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:00 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:00 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:00 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:00 --> Controller Class Initialized
INFO - 2021-07-28 05:12:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:01 --> Total execution time: 0.9251
INFO - 2021-07-28 05:12:01 --> Config Class Initialized
INFO - 2021-07-28 05:12:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:01 --> URI Class Initialized
INFO - 2021-07-28 05:12:01 --> Router Class Initialized
INFO - 2021-07-28 05:12:01 --> Output Class Initialized
INFO - 2021-07-28 05:12:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:01 --> Input Class Initialized
INFO - 2021-07-28 05:12:01 --> Language Class Initialized
INFO - 2021-07-28 05:12:01 --> Language Class Initialized
INFO - 2021-07-28 05:12:01 --> Config Class Initialized
INFO - 2021-07-28 05:12:01 --> Loader Class Initialized
INFO - 2021-07-28 05:12:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:01 --> Controller Class Initialized
INFO - 2021-07-28 05:12:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:02 --> Total execution time: 0.0727
INFO - 2021-07-28 05:12:05 --> Config Class Initialized
INFO - 2021-07-28 05:12:05 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:05 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:05 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:05 --> URI Class Initialized
INFO - 2021-07-28 05:12:05 --> Router Class Initialized
INFO - 2021-07-28 05:12:05 --> Output Class Initialized
INFO - 2021-07-28 05:12:05 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:05 --> Input Class Initialized
INFO - 2021-07-28 05:12:05 --> Language Class Initialized
INFO - 2021-07-28 05:12:05 --> Language Class Initialized
INFO - 2021-07-28 05:12:05 --> Config Class Initialized
INFO - 2021-07-28 05:12:05 --> Loader Class Initialized
INFO - 2021-07-28 05:12:05 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:05 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:05 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:05 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:05 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:05 --> Controller Class Initialized
INFO - 2021-07-28 05:12:06 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:06 --> Total execution time: 0.8901
INFO - 2021-07-28 05:12:06 --> Config Class Initialized
INFO - 2021-07-28 05:12:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:06 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:06 --> URI Class Initialized
INFO - 2021-07-28 05:12:06 --> Router Class Initialized
INFO - 2021-07-28 05:12:06 --> Output Class Initialized
INFO - 2021-07-28 05:12:06 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:06 --> Input Class Initialized
INFO - 2021-07-28 05:12:06 --> Language Class Initialized
INFO - 2021-07-28 05:12:06 --> Language Class Initialized
INFO - 2021-07-28 05:12:06 --> Config Class Initialized
INFO - 2021-07-28 05:12:06 --> Loader Class Initialized
INFO - 2021-07-28 05:12:06 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:06 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:06 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:06 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:06 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:06 --> Controller Class Initialized
INFO - 2021-07-28 05:12:06 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:06 --> Total execution time: 0.0583
INFO - 2021-07-28 05:12:12 --> Config Class Initialized
INFO - 2021-07-28 05:12:12 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:12 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:12 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:12 --> URI Class Initialized
INFO - 2021-07-28 05:12:12 --> Router Class Initialized
INFO - 2021-07-28 05:12:12 --> Output Class Initialized
INFO - 2021-07-28 05:12:12 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:12 --> Input Class Initialized
INFO - 2021-07-28 05:12:12 --> Language Class Initialized
INFO - 2021-07-28 05:12:12 --> Language Class Initialized
INFO - 2021-07-28 05:12:12 --> Config Class Initialized
INFO - 2021-07-28 05:12:12 --> Loader Class Initialized
INFO - 2021-07-28 05:12:12 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:12 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:12 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:12 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:12 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:12 --> Controller Class Initialized
INFO - 2021-07-28 05:12:12 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:12 --> Total execution time: 0.9211
INFO - 2021-07-28 05:12:13 --> Config Class Initialized
INFO - 2021-07-28 05:12:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:13 --> URI Class Initialized
INFO - 2021-07-28 05:12:13 --> Router Class Initialized
INFO - 2021-07-28 05:12:13 --> Output Class Initialized
INFO - 2021-07-28 05:12:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:13 --> Input Class Initialized
INFO - 2021-07-28 05:12:13 --> Language Class Initialized
INFO - 2021-07-28 05:12:13 --> Language Class Initialized
INFO - 2021-07-28 05:12:13 --> Config Class Initialized
INFO - 2021-07-28 05:12:13 --> Loader Class Initialized
INFO - 2021-07-28 05:12:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:13 --> Controller Class Initialized
INFO - 2021-07-28 05:12:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:13 --> Total execution time: 0.0457
INFO - 2021-07-28 05:12:16 --> Config Class Initialized
INFO - 2021-07-28 05:12:16 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:16 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:16 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:16 --> URI Class Initialized
INFO - 2021-07-28 05:12:16 --> Router Class Initialized
INFO - 2021-07-28 05:12:16 --> Output Class Initialized
INFO - 2021-07-28 05:12:16 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:16 --> Input Class Initialized
INFO - 2021-07-28 05:12:16 --> Language Class Initialized
INFO - 2021-07-28 05:12:16 --> Language Class Initialized
INFO - 2021-07-28 05:12:16 --> Config Class Initialized
INFO - 2021-07-28 05:12:16 --> Loader Class Initialized
INFO - 2021-07-28 05:12:16 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:16 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:16 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:16 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:16 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:16 --> Controller Class Initialized
INFO - 2021-07-28 05:12:17 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:17 --> Total execution time: 0.8864
INFO - 2021-07-28 05:12:18 --> Config Class Initialized
INFO - 2021-07-28 05:12:18 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:18 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:18 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:18 --> URI Class Initialized
INFO - 2021-07-28 05:12:18 --> Router Class Initialized
INFO - 2021-07-28 05:12:18 --> Output Class Initialized
INFO - 2021-07-28 05:12:18 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:18 --> Input Class Initialized
INFO - 2021-07-28 05:12:18 --> Language Class Initialized
INFO - 2021-07-28 05:12:18 --> Language Class Initialized
INFO - 2021-07-28 05:12:18 --> Config Class Initialized
INFO - 2021-07-28 05:12:18 --> Loader Class Initialized
INFO - 2021-07-28 05:12:18 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:18 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:18 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:18 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:19 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:19 --> Controller Class Initialized
DEBUG - 2021-07-28 05:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:12:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:12:19 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:19 --> Total execution time: 0.0475
INFO - 2021-07-28 05:12:22 --> Config Class Initialized
INFO - 2021-07-28 05:12:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:22 --> URI Class Initialized
INFO - 2021-07-28 05:12:22 --> Router Class Initialized
INFO - 2021-07-28 05:12:22 --> Output Class Initialized
INFO - 2021-07-28 05:12:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:22 --> Input Class Initialized
INFO - 2021-07-28 05:12:22 --> Language Class Initialized
INFO - 2021-07-28 05:12:22 --> Language Class Initialized
INFO - 2021-07-28 05:12:22 --> Config Class Initialized
INFO - 2021-07-28 05:12:22 --> Loader Class Initialized
INFO - 2021-07-28 05:12:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:22 --> Controller Class Initialized
DEBUG - 2021-07-28 05:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:12:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:12:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:22 --> Total execution time: 0.0570
INFO - 2021-07-28 05:12:25 --> Config Class Initialized
INFO - 2021-07-28 05:12:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:25 --> URI Class Initialized
INFO - 2021-07-28 05:12:25 --> Router Class Initialized
INFO - 2021-07-28 05:12:25 --> Output Class Initialized
INFO - 2021-07-28 05:12:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:25 --> Input Class Initialized
INFO - 2021-07-28 05:12:25 --> Language Class Initialized
INFO - 2021-07-28 05:12:25 --> Language Class Initialized
INFO - 2021-07-28 05:12:25 --> Config Class Initialized
INFO - 2021-07-28 05:12:25 --> Loader Class Initialized
INFO - 2021-07-28 05:12:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:25 --> Controller Class Initialized
INFO - 2021-07-28 05:12:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:25 --> Total execution time: 0.0932
INFO - 2021-07-28 05:12:30 --> Config Class Initialized
INFO - 2021-07-28 05:12:30 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:30 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:30 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:30 --> URI Class Initialized
INFO - 2021-07-28 05:12:30 --> Router Class Initialized
INFO - 2021-07-28 05:12:30 --> Output Class Initialized
INFO - 2021-07-28 05:12:30 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:30 --> Input Class Initialized
INFO - 2021-07-28 05:12:30 --> Language Class Initialized
INFO - 2021-07-28 05:12:30 --> Language Class Initialized
INFO - 2021-07-28 05:12:30 --> Config Class Initialized
INFO - 2021-07-28 05:12:30 --> Loader Class Initialized
INFO - 2021-07-28 05:12:30 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:30 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:30 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:30 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:30 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:30 --> Controller Class Initialized
INFO - 2021-07-28 05:12:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:31 --> Total execution time: 0.8465
INFO - 2021-07-28 05:12:32 --> Config Class Initialized
INFO - 2021-07-28 05:12:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:32 --> URI Class Initialized
INFO - 2021-07-28 05:12:32 --> Router Class Initialized
INFO - 2021-07-28 05:12:32 --> Output Class Initialized
INFO - 2021-07-28 05:12:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:32 --> Input Class Initialized
INFO - 2021-07-28 05:12:32 --> Language Class Initialized
INFO - 2021-07-28 05:12:32 --> Language Class Initialized
INFO - 2021-07-28 05:12:32 --> Config Class Initialized
INFO - 2021-07-28 05:12:32 --> Loader Class Initialized
INFO - 2021-07-28 05:12:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:32 --> Controller Class Initialized
INFO - 2021-07-28 05:12:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:32 --> Total execution time: 0.0544
INFO - 2021-07-28 05:12:36 --> Config Class Initialized
INFO - 2021-07-28 05:12:36 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:36 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:36 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:36 --> URI Class Initialized
INFO - 2021-07-28 05:12:36 --> Router Class Initialized
INFO - 2021-07-28 05:12:36 --> Output Class Initialized
INFO - 2021-07-28 05:12:36 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:36 --> Input Class Initialized
INFO - 2021-07-28 05:12:36 --> Language Class Initialized
INFO - 2021-07-28 05:12:36 --> Language Class Initialized
INFO - 2021-07-28 05:12:36 --> Config Class Initialized
INFO - 2021-07-28 05:12:36 --> Loader Class Initialized
INFO - 2021-07-28 05:12:36 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:36 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:36 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:36 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:36 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:36 --> Controller Class Initialized
INFO - 2021-07-28 05:12:37 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:37 --> Total execution time: 0.7613
INFO - 2021-07-28 05:12:38 --> Config Class Initialized
INFO - 2021-07-28 05:12:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:38 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:38 --> URI Class Initialized
INFO - 2021-07-28 05:12:38 --> Router Class Initialized
INFO - 2021-07-28 05:12:38 --> Output Class Initialized
INFO - 2021-07-28 05:12:38 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:38 --> Input Class Initialized
INFO - 2021-07-28 05:12:38 --> Language Class Initialized
INFO - 2021-07-28 05:12:38 --> Language Class Initialized
INFO - 2021-07-28 05:12:38 --> Config Class Initialized
INFO - 2021-07-28 05:12:38 --> Loader Class Initialized
INFO - 2021-07-28 05:12:38 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:38 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:38 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:38 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:38 --> Controller Class Initialized
INFO - 2021-07-28 05:12:38 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:38 --> Total execution time: 0.0708
INFO - 2021-07-28 05:12:43 --> Config Class Initialized
INFO - 2021-07-28 05:12:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:43 --> URI Class Initialized
INFO - 2021-07-28 05:12:43 --> Router Class Initialized
INFO - 2021-07-28 05:12:43 --> Output Class Initialized
INFO - 2021-07-28 05:12:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:43 --> Input Class Initialized
INFO - 2021-07-28 05:12:43 --> Language Class Initialized
INFO - 2021-07-28 05:12:43 --> Language Class Initialized
INFO - 2021-07-28 05:12:43 --> Config Class Initialized
INFO - 2021-07-28 05:12:43 --> Loader Class Initialized
INFO - 2021-07-28 05:12:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:43 --> Controller Class Initialized
INFO - 2021-07-28 05:12:44 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:44 --> Total execution time: 0.8124
INFO - 2021-07-28 05:12:45 --> Config Class Initialized
INFO - 2021-07-28 05:12:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:45 --> URI Class Initialized
INFO - 2021-07-28 05:12:45 --> Router Class Initialized
INFO - 2021-07-28 05:12:45 --> Output Class Initialized
INFO - 2021-07-28 05:12:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:45 --> Input Class Initialized
INFO - 2021-07-28 05:12:45 --> Language Class Initialized
INFO - 2021-07-28 05:12:45 --> Language Class Initialized
INFO - 2021-07-28 05:12:45 --> Config Class Initialized
INFO - 2021-07-28 05:12:45 --> Loader Class Initialized
INFO - 2021-07-28 05:12:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:45 --> Controller Class Initialized
INFO - 2021-07-28 05:12:45 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:45 --> Total execution time: 0.0542
INFO - 2021-07-28 05:12:49 --> Config Class Initialized
INFO - 2021-07-28 05:12:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:49 --> URI Class Initialized
INFO - 2021-07-28 05:12:49 --> Router Class Initialized
INFO - 2021-07-28 05:12:49 --> Output Class Initialized
INFO - 2021-07-28 05:12:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:49 --> Input Class Initialized
INFO - 2021-07-28 05:12:49 --> Language Class Initialized
INFO - 2021-07-28 05:12:49 --> Language Class Initialized
INFO - 2021-07-28 05:12:49 --> Config Class Initialized
INFO - 2021-07-28 05:12:49 --> Loader Class Initialized
INFO - 2021-07-28 05:12:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:49 --> Controller Class Initialized
INFO - 2021-07-28 05:12:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:50 --> Total execution time: 0.7648
INFO - 2021-07-28 05:12:53 --> Config Class Initialized
INFO - 2021-07-28 05:12:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:53 --> URI Class Initialized
INFO - 2021-07-28 05:12:53 --> Router Class Initialized
INFO - 2021-07-28 05:12:53 --> Output Class Initialized
INFO - 2021-07-28 05:12:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:53 --> Input Class Initialized
INFO - 2021-07-28 05:12:53 --> Language Class Initialized
INFO - 2021-07-28 05:12:53 --> Language Class Initialized
INFO - 2021-07-28 05:12:53 --> Config Class Initialized
INFO - 2021-07-28 05:12:53 --> Loader Class Initialized
INFO - 2021-07-28 05:12:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:54 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:54 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:54 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:54 --> Controller Class Initialized
INFO - 2021-07-28 05:12:54 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:54 --> Total execution time: 0.7933
INFO - 2021-07-28 05:12:57 --> Config Class Initialized
INFO - 2021-07-28 05:12:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:12:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:12:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:12:57 --> URI Class Initialized
INFO - 2021-07-28 05:12:57 --> Router Class Initialized
INFO - 2021-07-28 05:12:57 --> Output Class Initialized
INFO - 2021-07-28 05:12:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:12:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:12:57 --> Input Class Initialized
INFO - 2021-07-28 05:12:57 --> Language Class Initialized
INFO - 2021-07-28 05:12:57 --> Language Class Initialized
INFO - 2021-07-28 05:12:57 --> Config Class Initialized
INFO - 2021-07-28 05:12:57 --> Loader Class Initialized
INFO - 2021-07-28 05:12:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:12:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:12:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:12:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:12:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:12:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:12:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:12:57 --> Controller Class Initialized
DEBUG - 2021-07-28 05:12:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:12:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:12:57 --> Final output sent to browser
DEBUG - 2021-07-28 05:12:57 --> Total execution time: 0.0604
INFO - 2021-07-28 05:13:13 --> Config Class Initialized
INFO - 2021-07-28 05:13:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:13:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:13:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:13:13 --> URI Class Initialized
INFO - 2021-07-28 05:13:13 --> Router Class Initialized
INFO - 2021-07-28 05:13:13 --> Output Class Initialized
INFO - 2021-07-28 05:13:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:13:13 --> Input Class Initialized
INFO - 2021-07-28 05:13:13 --> Language Class Initialized
INFO - 2021-07-28 05:13:13 --> Language Class Initialized
INFO - 2021-07-28 05:13:13 --> Config Class Initialized
INFO - 2021-07-28 05:13:13 --> Loader Class Initialized
INFO - 2021-07-28 05:13:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:13:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:13:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:13:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:13:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:13:14 --> Controller Class Initialized
DEBUG - 2021-07-28 05:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:13:14 --> Final output sent to browser
DEBUG - 2021-07-28 05:13:14 --> Total execution time: 0.0596
INFO - 2021-07-28 05:13:14 --> Config Class Initialized
INFO - 2021-07-28 05:13:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:13:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:13:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:13:14 --> URI Class Initialized
INFO - 2021-07-28 05:13:14 --> Router Class Initialized
INFO - 2021-07-28 05:13:14 --> Output Class Initialized
INFO - 2021-07-28 05:13:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:13:14 --> Input Class Initialized
INFO - 2021-07-28 05:13:14 --> Language Class Initialized
INFO - 2021-07-28 05:13:14 --> Language Class Initialized
INFO - 2021-07-28 05:13:14 --> Config Class Initialized
INFO - 2021-07-28 05:13:14 --> Loader Class Initialized
INFO - 2021-07-28 05:13:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:13:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:13:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:13:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:13:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:13:14 --> Controller Class Initialized
INFO - 2021-07-28 05:16:19 --> Config Class Initialized
INFO - 2021-07-28 05:16:19 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:19 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:19 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:19 --> URI Class Initialized
INFO - 2021-07-28 05:16:19 --> Router Class Initialized
INFO - 2021-07-28 05:16:19 --> Output Class Initialized
INFO - 2021-07-28 05:16:19 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:19 --> Input Class Initialized
INFO - 2021-07-28 05:16:19 --> Language Class Initialized
INFO - 2021-07-28 05:16:19 --> Language Class Initialized
INFO - 2021-07-28 05:16:19 --> Config Class Initialized
INFO - 2021-07-28 05:16:19 --> Loader Class Initialized
INFO - 2021-07-28 05:16:19 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:19 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:19 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:19 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:19 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:19 --> Controller Class Initialized
INFO - 2021-07-28 05:16:19 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:19 --> Total execution time: 0.1080
INFO - 2021-07-28 05:16:37 --> Config Class Initialized
INFO - 2021-07-28 05:16:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:37 --> URI Class Initialized
INFO - 2021-07-28 05:16:37 --> Router Class Initialized
INFO - 2021-07-28 05:16:37 --> Output Class Initialized
INFO - 2021-07-28 05:16:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:37 --> Input Class Initialized
INFO - 2021-07-28 05:16:37 --> Language Class Initialized
INFO - 2021-07-28 05:16:37 --> Language Class Initialized
INFO - 2021-07-28 05:16:37 --> Config Class Initialized
INFO - 2021-07-28 05:16:37 --> Loader Class Initialized
INFO - 2021-07-28 05:16:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:37 --> Controller Class Initialized
INFO - 2021-07-28 05:16:38 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:38 --> Total execution time: 0.9450
INFO - 2021-07-28 05:16:38 --> Config Class Initialized
INFO - 2021-07-28 05:16:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:38 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:38 --> URI Class Initialized
INFO - 2021-07-28 05:16:38 --> Router Class Initialized
INFO - 2021-07-28 05:16:38 --> Output Class Initialized
INFO - 2021-07-28 05:16:38 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:38 --> Input Class Initialized
INFO - 2021-07-28 05:16:38 --> Language Class Initialized
INFO - 2021-07-28 05:16:38 --> Language Class Initialized
INFO - 2021-07-28 05:16:38 --> Config Class Initialized
INFO - 2021-07-28 05:16:38 --> Loader Class Initialized
INFO - 2021-07-28 05:16:38 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:38 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:38 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:38 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:39 --> Controller Class Initialized
INFO - 2021-07-28 05:16:39 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:39 --> Total execution time: 0.0546
INFO - 2021-07-28 05:16:42 --> Config Class Initialized
INFO - 2021-07-28 05:16:42 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:42 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:42 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:42 --> URI Class Initialized
INFO - 2021-07-28 05:16:42 --> Router Class Initialized
INFO - 2021-07-28 05:16:42 --> Output Class Initialized
INFO - 2021-07-28 05:16:42 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:42 --> Input Class Initialized
INFO - 2021-07-28 05:16:42 --> Language Class Initialized
INFO - 2021-07-28 05:16:42 --> Language Class Initialized
INFO - 2021-07-28 05:16:42 --> Config Class Initialized
INFO - 2021-07-28 05:16:42 --> Loader Class Initialized
INFO - 2021-07-28 05:16:42 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:42 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:42 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:42 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:42 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:42 --> Controller Class Initialized
INFO - 2021-07-28 05:16:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:43 --> Total execution time: 0.9102
INFO - 2021-07-28 05:16:43 --> Config Class Initialized
INFO - 2021-07-28 05:16:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:43 --> URI Class Initialized
INFO - 2021-07-28 05:16:43 --> Router Class Initialized
INFO - 2021-07-28 05:16:43 --> Output Class Initialized
INFO - 2021-07-28 05:16:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:43 --> Input Class Initialized
INFO - 2021-07-28 05:16:43 --> Language Class Initialized
INFO - 2021-07-28 05:16:43 --> Language Class Initialized
INFO - 2021-07-28 05:16:43 --> Config Class Initialized
INFO - 2021-07-28 05:16:43 --> Loader Class Initialized
INFO - 2021-07-28 05:16:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:43 --> Controller Class Initialized
INFO - 2021-07-28 05:16:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:43 --> Total execution time: 0.0445
INFO - 2021-07-28 05:16:46 --> Config Class Initialized
INFO - 2021-07-28 05:16:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:46 --> URI Class Initialized
INFO - 2021-07-28 05:16:46 --> Router Class Initialized
INFO - 2021-07-28 05:16:46 --> Output Class Initialized
INFO - 2021-07-28 05:16:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:46 --> Input Class Initialized
INFO - 2021-07-28 05:16:46 --> Language Class Initialized
INFO - 2021-07-28 05:16:46 --> Language Class Initialized
INFO - 2021-07-28 05:16:46 --> Config Class Initialized
INFO - 2021-07-28 05:16:46 --> Loader Class Initialized
INFO - 2021-07-28 05:16:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:46 --> Controller Class Initialized
INFO - 2021-07-28 05:16:47 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:47 --> Total execution time: 0.9346
INFO - 2021-07-28 05:16:49 --> Config Class Initialized
INFO - 2021-07-28 05:16:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:49 --> URI Class Initialized
INFO - 2021-07-28 05:16:49 --> Router Class Initialized
INFO - 2021-07-28 05:16:49 --> Output Class Initialized
INFO - 2021-07-28 05:16:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:49 --> Input Class Initialized
INFO - 2021-07-28 05:16:49 --> Language Class Initialized
INFO - 2021-07-28 05:16:49 --> Language Class Initialized
INFO - 2021-07-28 05:16:49 --> Config Class Initialized
INFO - 2021-07-28 05:16:49 --> Loader Class Initialized
INFO - 2021-07-28 05:16:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:49 --> Controller Class Initialized
INFO - 2021-07-28 05:16:49 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:49 --> Total execution time: 0.0780
INFO - 2021-07-28 05:16:51 --> Config Class Initialized
INFO - 2021-07-28 05:16:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:51 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:51 --> URI Class Initialized
INFO - 2021-07-28 05:16:51 --> Router Class Initialized
INFO - 2021-07-28 05:16:51 --> Output Class Initialized
INFO - 2021-07-28 05:16:51 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:51 --> Input Class Initialized
INFO - 2021-07-28 05:16:51 --> Language Class Initialized
INFO - 2021-07-28 05:16:51 --> Language Class Initialized
INFO - 2021-07-28 05:16:51 --> Config Class Initialized
INFO - 2021-07-28 05:16:51 --> Loader Class Initialized
INFO - 2021-07-28 05:16:51 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:51 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:51 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:51 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:51 --> Controller Class Initialized
INFO - 2021-07-28 05:16:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:51 --> Total execution time: 0.0607
INFO - 2021-07-28 05:16:54 --> Config Class Initialized
INFO - 2021-07-28 05:16:54 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:54 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:54 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:54 --> URI Class Initialized
INFO - 2021-07-28 05:16:54 --> Router Class Initialized
INFO - 2021-07-28 05:16:54 --> Output Class Initialized
INFO - 2021-07-28 05:16:54 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:54 --> Input Class Initialized
INFO - 2021-07-28 05:16:54 --> Language Class Initialized
INFO - 2021-07-28 05:16:54 --> Language Class Initialized
INFO - 2021-07-28 05:16:54 --> Config Class Initialized
INFO - 2021-07-28 05:16:54 --> Loader Class Initialized
INFO - 2021-07-28 05:16:54 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:54 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:54 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:54 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:54 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:54 --> Controller Class Initialized
INFO - 2021-07-28 05:16:55 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:55 --> Total execution time: 0.9393
INFO - 2021-07-28 05:16:55 --> Config Class Initialized
INFO - 2021-07-28 05:16:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:55 --> URI Class Initialized
INFO - 2021-07-28 05:16:55 --> Router Class Initialized
INFO - 2021-07-28 05:16:55 --> Output Class Initialized
INFO - 2021-07-28 05:16:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:56 --> Input Class Initialized
INFO - 2021-07-28 05:16:56 --> Language Class Initialized
INFO - 2021-07-28 05:16:56 --> Language Class Initialized
INFO - 2021-07-28 05:16:56 --> Config Class Initialized
INFO - 2021-07-28 05:16:56 --> Loader Class Initialized
INFO - 2021-07-28 05:16:56 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:56 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:56 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:56 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:56 --> Controller Class Initialized
INFO - 2021-07-28 05:16:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:16:56 --> Total execution time: 0.0685
INFO - 2021-07-28 05:16:59 --> Config Class Initialized
INFO - 2021-07-28 05:16:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:16:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:16:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:16:59 --> URI Class Initialized
INFO - 2021-07-28 05:16:59 --> Router Class Initialized
INFO - 2021-07-28 05:16:59 --> Output Class Initialized
INFO - 2021-07-28 05:16:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:16:59 --> Input Class Initialized
INFO - 2021-07-28 05:16:59 --> Language Class Initialized
INFO - 2021-07-28 05:16:59 --> Language Class Initialized
INFO - 2021-07-28 05:16:59 --> Config Class Initialized
INFO - 2021-07-28 05:16:59 --> Loader Class Initialized
INFO - 2021-07-28 05:16:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:16:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:16:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:16:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:16:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:16:59 --> Controller Class Initialized
INFO - 2021-07-28 05:17:00 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:00 --> Total execution time: 0.9124
INFO - 2021-07-28 05:17:00 --> Config Class Initialized
INFO - 2021-07-28 05:17:00 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:00 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:00 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:00 --> URI Class Initialized
INFO - 2021-07-28 05:17:00 --> Router Class Initialized
INFO - 2021-07-28 05:17:00 --> Output Class Initialized
INFO - 2021-07-28 05:17:00 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:00 --> Input Class Initialized
INFO - 2021-07-28 05:17:00 --> Language Class Initialized
INFO - 2021-07-28 05:17:00 --> Language Class Initialized
INFO - 2021-07-28 05:17:00 --> Config Class Initialized
INFO - 2021-07-28 05:17:00 --> Loader Class Initialized
INFO - 2021-07-28 05:17:00 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:00 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:00 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:00 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:00 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:00 --> Controller Class Initialized
INFO - 2021-07-28 05:17:00 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:00 --> Total execution time: 0.0623
INFO - 2021-07-28 05:17:03 --> Config Class Initialized
INFO - 2021-07-28 05:17:03 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:03 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:03 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:03 --> URI Class Initialized
INFO - 2021-07-28 05:17:03 --> Router Class Initialized
INFO - 2021-07-28 05:17:03 --> Output Class Initialized
INFO - 2021-07-28 05:17:03 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:03 --> Input Class Initialized
INFO - 2021-07-28 05:17:03 --> Language Class Initialized
INFO - 2021-07-28 05:17:03 --> Language Class Initialized
INFO - 2021-07-28 05:17:03 --> Config Class Initialized
INFO - 2021-07-28 05:17:03 --> Loader Class Initialized
INFO - 2021-07-28 05:17:03 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:03 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:03 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:03 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:03 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:03 --> Controller Class Initialized
INFO - 2021-07-28 05:17:04 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:04 --> Total execution time: 0.8988
INFO - 2021-07-28 05:17:08 --> Config Class Initialized
INFO - 2021-07-28 05:17:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:08 --> URI Class Initialized
INFO - 2021-07-28 05:17:08 --> Router Class Initialized
INFO - 2021-07-28 05:17:08 --> Output Class Initialized
INFO - 2021-07-28 05:17:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:08 --> Input Class Initialized
INFO - 2021-07-28 05:17:08 --> Language Class Initialized
INFO - 2021-07-28 05:17:08 --> Language Class Initialized
INFO - 2021-07-28 05:17:08 --> Config Class Initialized
INFO - 2021-07-28 05:17:08 --> Loader Class Initialized
INFO - 2021-07-28 05:17:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:08 --> Controller Class Initialized
DEBUG - 2021-07-28 05:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:17:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:17:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:08 --> Total execution time: 0.0585
INFO - 2021-07-28 05:17:11 --> Config Class Initialized
INFO - 2021-07-28 05:17:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:11 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:11 --> URI Class Initialized
INFO - 2021-07-28 05:17:11 --> Router Class Initialized
INFO - 2021-07-28 05:17:11 --> Output Class Initialized
INFO - 2021-07-28 05:17:11 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:11 --> Input Class Initialized
INFO - 2021-07-28 05:17:11 --> Language Class Initialized
INFO - 2021-07-28 05:17:11 --> Language Class Initialized
INFO - 2021-07-28 05:17:11 --> Config Class Initialized
INFO - 2021-07-28 05:17:11 --> Loader Class Initialized
INFO - 2021-07-28 05:17:11 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:11 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:11 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:11 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:11 --> Controller Class Initialized
DEBUG - 2021-07-28 05:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:17:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:17:11 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:11 --> Total execution time: 0.0569
INFO - 2021-07-28 05:17:13 --> Config Class Initialized
INFO - 2021-07-28 05:17:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:13 --> URI Class Initialized
INFO - 2021-07-28 05:17:13 --> Router Class Initialized
INFO - 2021-07-28 05:17:13 --> Output Class Initialized
INFO - 2021-07-28 05:17:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:13 --> Input Class Initialized
INFO - 2021-07-28 05:17:13 --> Language Class Initialized
INFO - 2021-07-28 05:17:13 --> Language Class Initialized
INFO - 2021-07-28 05:17:13 --> Config Class Initialized
INFO - 2021-07-28 05:17:13 --> Loader Class Initialized
INFO - 2021-07-28 05:17:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:13 --> Controller Class Initialized
INFO - 2021-07-28 05:17:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:13 --> Total execution time: 0.1085
INFO - 2021-07-28 05:17:17 --> Config Class Initialized
INFO - 2021-07-28 05:17:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:17 --> URI Class Initialized
INFO - 2021-07-28 05:17:17 --> Router Class Initialized
INFO - 2021-07-28 05:17:17 --> Output Class Initialized
INFO - 2021-07-28 05:17:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:17 --> Input Class Initialized
INFO - 2021-07-28 05:17:17 --> Language Class Initialized
INFO - 2021-07-28 05:17:17 --> Language Class Initialized
INFO - 2021-07-28 05:17:17 --> Config Class Initialized
INFO - 2021-07-28 05:17:17 --> Loader Class Initialized
INFO - 2021-07-28 05:17:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:17 --> Controller Class Initialized
INFO - 2021-07-28 05:17:18 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:18 --> Total execution time: 0.8263
INFO - 2021-07-28 05:17:21 --> Config Class Initialized
INFO - 2021-07-28 05:17:21 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:21 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:21 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:21 --> URI Class Initialized
INFO - 2021-07-28 05:17:21 --> Router Class Initialized
INFO - 2021-07-28 05:17:21 --> Output Class Initialized
INFO - 2021-07-28 05:17:21 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:21 --> Input Class Initialized
INFO - 2021-07-28 05:17:21 --> Language Class Initialized
INFO - 2021-07-28 05:17:21 --> Language Class Initialized
INFO - 2021-07-28 05:17:21 --> Config Class Initialized
INFO - 2021-07-28 05:17:21 --> Loader Class Initialized
INFO - 2021-07-28 05:17:21 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:21 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:21 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:21 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:21 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:21 --> Controller Class Initialized
INFO - 2021-07-28 05:17:21 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:21 --> Total execution time: 0.0596
INFO - 2021-07-28 05:17:23 --> Config Class Initialized
INFO - 2021-07-28 05:17:23 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:23 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:23 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:23 --> URI Class Initialized
INFO - 2021-07-28 05:17:23 --> Router Class Initialized
INFO - 2021-07-28 05:17:23 --> Output Class Initialized
INFO - 2021-07-28 05:17:23 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:23 --> Input Class Initialized
INFO - 2021-07-28 05:17:23 --> Language Class Initialized
INFO - 2021-07-28 05:17:23 --> Language Class Initialized
INFO - 2021-07-28 05:17:23 --> Config Class Initialized
INFO - 2021-07-28 05:17:23 --> Loader Class Initialized
INFO - 2021-07-28 05:17:23 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:23 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:23 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:23 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:23 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:24 --> Controller Class Initialized
INFO - 2021-07-28 05:17:24 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:24 --> Total execution time: 0.8223
INFO - 2021-07-28 05:17:25 --> Config Class Initialized
INFO - 2021-07-28 05:17:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:25 --> URI Class Initialized
INFO - 2021-07-28 05:17:25 --> Router Class Initialized
INFO - 2021-07-28 05:17:25 --> Output Class Initialized
INFO - 2021-07-28 05:17:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:25 --> Input Class Initialized
INFO - 2021-07-28 05:17:25 --> Language Class Initialized
INFO - 2021-07-28 05:17:25 --> Language Class Initialized
INFO - 2021-07-28 05:17:25 --> Config Class Initialized
INFO - 2021-07-28 05:17:25 --> Loader Class Initialized
INFO - 2021-07-28 05:17:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:25 --> Controller Class Initialized
INFO - 2021-07-28 05:17:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:25 --> Total execution time: 0.0653
INFO - 2021-07-28 05:17:28 --> Config Class Initialized
INFO - 2021-07-28 05:17:28 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:28 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:28 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:28 --> URI Class Initialized
INFO - 2021-07-28 05:17:28 --> Router Class Initialized
INFO - 2021-07-28 05:17:28 --> Output Class Initialized
INFO - 2021-07-28 05:17:28 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:28 --> Input Class Initialized
INFO - 2021-07-28 05:17:28 --> Language Class Initialized
INFO - 2021-07-28 05:17:28 --> Language Class Initialized
INFO - 2021-07-28 05:17:28 --> Config Class Initialized
INFO - 2021-07-28 05:17:28 --> Loader Class Initialized
INFO - 2021-07-28 05:17:28 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:28 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:28 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:28 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:28 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:28 --> Controller Class Initialized
INFO - 2021-07-28 05:17:29 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:29 --> Total execution time: 0.7876
INFO - 2021-07-28 05:17:32 --> Config Class Initialized
INFO - 2021-07-28 05:17:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:32 --> URI Class Initialized
INFO - 2021-07-28 05:17:32 --> Router Class Initialized
INFO - 2021-07-28 05:17:32 --> Output Class Initialized
INFO - 2021-07-28 05:17:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:32 --> Input Class Initialized
INFO - 2021-07-28 05:17:32 --> Language Class Initialized
INFO - 2021-07-28 05:17:32 --> Language Class Initialized
INFO - 2021-07-28 05:17:32 --> Config Class Initialized
INFO - 2021-07-28 05:17:32 --> Loader Class Initialized
INFO - 2021-07-28 05:17:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:32 --> Controller Class Initialized
INFO - 2021-07-28 05:17:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:32 --> Total execution time: 0.0743
INFO - 2021-07-28 05:17:35 --> Config Class Initialized
INFO - 2021-07-28 05:17:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:35 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:35 --> URI Class Initialized
INFO - 2021-07-28 05:17:35 --> Router Class Initialized
INFO - 2021-07-28 05:17:35 --> Output Class Initialized
INFO - 2021-07-28 05:17:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:35 --> Input Class Initialized
INFO - 2021-07-28 05:17:35 --> Language Class Initialized
INFO - 2021-07-28 05:17:35 --> Language Class Initialized
INFO - 2021-07-28 05:17:35 --> Config Class Initialized
INFO - 2021-07-28 05:17:35 --> Loader Class Initialized
INFO - 2021-07-28 05:17:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:35 --> Controller Class Initialized
INFO - 2021-07-28 05:17:36 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:36 --> Total execution time: 0.9075
INFO - 2021-07-28 05:17:37 --> Config Class Initialized
INFO - 2021-07-28 05:17:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:37 --> URI Class Initialized
INFO - 2021-07-28 05:17:37 --> Router Class Initialized
INFO - 2021-07-28 05:17:37 --> Output Class Initialized
INFO - 2021-07-28 05:17:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:37 --> Input Class Initialized
INFO - 2021-07-28 05:17:37 --> Language Class Initialized
INFO - 2021-07-28 05:17:37 --> Language Class Initialized
INFO - 2021-07-28 05:17:37 --> Config Class Initialized
INFO - 2021-07-28 05:17:37 --> Loader Class Initialized
INFO - 2021-07-28 05:17:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:37 --> Controller Class Initialized
DEBUG - 2021-07-28 05:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:17:37 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:37 --> Total execution time: 0.0628
INFO - 2021-07-28 05:17:45 --> Config Class Initialized
INFO - 2021-07-28 05:17:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:45 --> URI Class Initialized
INFO - 2021-07-28 05:17:45 --> Router Class Initialized
INFO - 2021-07-28 05:17:45 --> Output Class Initialized
INFO - 2021-07-28 05:17:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:45 --> Input Class Initialized
INFO - 2021-07-28 05:17:45 --> Language Class Initialized
INFO - 2021-07-28 05:17:45 --> Language Class Initialized
INFO - 2021-07-28 05:17:45 --> Config Class Initialized
INFO - 2021-07-28 05:17:45 --> Loader Class Initialized
INFO - 2021-07-28 05:17:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:45 --> Controller Class Initialized
INFO - 2021-07-28 05:17:45 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:17:45 --> Config Class Initialized
INFO - 2021-07-28 05:17:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:45 --> URI Class Initialized
INFO - 2021-07-28 05:17:45 --> Router Class Initialized
INFO - 2021-07-28 05:17:45 --> Output Class Initialized
INFO - 2021-07-28 05:17:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:45 --> Input Class Initialized
INFO - 2021-07-28 05:17:45 --> Language Class Initialized
INFO - 2021-07-28 05:17:45 --> Language Class Initialized
INFO - 2021-07-28 05:17:45 --> Config Class Initialized
INFO - 2021-07-28 05:17:45 --> Loader Class Initialized
INFO - 2021-07-28 05:17:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:46 --> Controller Class Initialized
DEBUG - 2021-07-28 05:17:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:17:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:17:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:46 --> Total execution time: 0.0419
INFO - 2021-07-28 05:17:53 --> Config Class Initialized
INFO - 2021-07-28 05:17:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:53 --> URI Class Initialized
INFO - 2021-07-28 05:17:53 --> Router Class Initialized
INFO - 2021-07-28 05:17:53 --> Output Class Initialized
INFO - 2021-07-28 05:17:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:53 --> Input Class Initialized
INFO - 2021-07-28 05:17:53 --> Language Class Initialized
INFO - 2021-07-28 05:17:53 --> Language Class Initialized
INFO - 2021-07-28 05:17:53 --> Config Class Initialized
INFO - 2021-07-28 05:17:53 --> Loader Class Initialized
INFO - 2021-07-28 05:17:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:53 --> Controller Class Initialized
INFO - 2021-07-28 05:17:53 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:17:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:53 --> Total execution time: 0.0622
INFO - 2021-07-28 05:17:55 --> Config Class Initialized
INFO - 2021-07-28 05:17:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:55 --> URI Class Initialized
INFO - 2021-07-28 05:17:55 --> Router Class Initialized
INFO - 2021-07-28 05:17:55 --> Output Class Initialized
INFO - 2021-07-28 05:17:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:55 --> Input Class Initialized
INFO - 2021-07-28 05:17:55 --> Language Class Initialized
INFO - 2021-07-28 05:17:55 --> Language Class Initialized
INFO - 2021-07-28 05:17:55 --> Config Class Initialized
INFO - 2021-07-28 05:17:55 --> Loader Class Initialized
INFO - 2021-07-28 05:17:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:55 --> Controller Class Initialized
DEBUG - 2021-07-28 05:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:17:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:56 --> Total execution time: 0.6877
INFO - 2021-07-28 05:17:57 --> Config Class Initialized
INFO - 2021-07-28 05:17:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:57 --> URI Class Initialized
INFO - 2021-07-28 05:17:57 --> Router Class Initialized
INFO - 2021-07-28 05:17:57 --> Output Class Initialized
INFO - 2021-07-28 05:17:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:57 --> Input Class Initialized
INFO - 2021-07-28 05:17:57 --> Language Class Initialized
INFO - 2021-07-28 05:17:57 --> Language Class Initialized
INFO - 2021-07-28 05:17:57 --> Config Class Initialized
INFO - 2021-07-28 05:17:57 --> Loader Class Initialized
INFO - 2021-07-28 05:17:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:57 --> Controller Class Initialized
DEBUG - 2021-07-28 05:17:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:17:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:17:57 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:57 --> Total execution time: 0.0660
INFO - 2021-07-28 05:17:59 --> Config Class Initialized
INFO - 2021-07-28 05:17:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:59 --> URI Class Initialized
INFO - 2021-07-28 05:17:59 --> Router Class Initialized
INFO - 2021-07-28 05:17:59 --> Output Class Initialized
INFO - 2021-07-28 05:17:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:59 --> Input Class Initialized
INFO - 2021-07-28 05:17:59 --> Language Class Initialized
INFO - 2021-07-28 05:17:59 --> Language Class Initialized
INFO - 2021-07-28 05:17:59 --> Config Class Initialized
INFO - 2021-07-28 05:17:59 --> Loader Class Initialized
INFO - 2021-07-28 05:17:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:59 --> Controller Class Initialized
DEBUG - 2021-07-28 05:17:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:17:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:17:59 --> Final output sent to browser
DEBUG - 2021-07-28 05:17:59 --> Total execution time: 0.0589
INFO - 2021-07-28 05:17:59 --> Config Class Initialized
INFO - 2021-07-28 05:17:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:17:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:17:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:17:59 --> URI Class Initialized
INFO - 2021-07-28 05:17:59 --> Router Class Initialized
INFO - 2021-07-28 05:17:59 --> Output Class Initialized
INFO - 2021-07-28 05:17:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:17:59 --> Input Class Initialized
INFO - 2021-07-28 05:17:59 --> Language Class Initialized
INFO - 2021-07-28 05:17:59 --> Language Class Initialized
INFO - 2021-07-28 05:17:59 --> Config Class Initialized
INFO - 2021-07-28 05:17:59 --> Loader Class Initialized
INFO - 2021-07-28 05:17:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:17:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:17:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:17:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:17:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:17:59 --> Controller Class Initialized
INFO - 2021-07-28 05:18:02 --> Config Class Initialized
INFO - 2021-07-28 05:18:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:02 --> URI Class Initialized
INFO - 2021-07-28 05:18:02 --> Router Class Initialized
INFO - 2021-07-28 05:18:02 --> Output Class Initialized
INFO - 2021-07-28 05:18:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:02 --> Input Class Initialized
INFO - 2021-07-28 05:18:02 --> Language Class Initialized
INFO - 2021-07-28 05:18:02 --> Language Class Initialized
INFO - 2021-07-28 05:18:02 --> Config Class Initialized
INFO - 2021-07-28 05:18:02 --> Loader Class Initialized
INFO - 2021-07-28 05:18:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:02 --> Controller Class Initialized
INFO - 2021-07-28 05:18:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:02 --> Total execution time: 0.1008
INFO - 2021-07-28 05:18:05 --> Config Class Initialized
INFO - 2021-07-28 05:18:05 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:05 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:05 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:05 --> URI Class Initialized
INFO - 2021-07-28 05:18:05 --> Router Class Initialized
INFO - 2021-07-28 05:18:05 --> Output Class Initialized
INFO - 2021-07-28 05:18:05 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:05 --> Input Class Initialized
INFO - 2021-07-28 05:18:05 --> Language Class Initialized
INFO - 2021-07-28 05:18:05 --> Language Class Initialized
INFO - 2021-07-28 05:18:05 --> Config Class Initialized
INFO - 2021-07-28 05:18:05 --> Loader Class Initialized
INFO - 2021-07-28 05:18:05 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:05 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:05 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:05 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:05 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:05 --> Controller Class Initialized
INFO - 2021-07-28 05:18:05 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:05 --> Total execution time: 0.0607
INFO - 2021-07-28 05:18:08 --> Config Class Initialized
INFO - 2021-07-28 05:18:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:08 --> URI Class Initialized
INFO - 2021-07-28 05:18:08 --> Router Class Initialized
INFO - 2021-07-28 05:18:08 --> Output Class Initialized
INFO - 2021-07-28 05:18:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:08 --> Input Class Initialized
INFO - 2021-07-28 05:18:08 --> Language Class Initialized
INFO - 2021-07-28 05:18:08 --> Language Class Initialized
INFO - 2021-07-28 05:18:08 --> Config Class Initialized
INFO - 2021-07-28 05:18:08 --> Loader Class Initialized
INFO - 2021-07-28 05:18:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:08 --> Controller Class Initialized
INFO - 2021-07-28 05:18:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:08 --> Total execution time: 0.0755
INFO - 2021-07-28 05:18:10 --> Config Class Initialized
INFO - 2021-07-28 05:18:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:10 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:10 --> URI Class Initialized
INFO - 2021-07-28 05:18:10 --> Router Class Initialized
INFO - 2021-07-28 05:18:10 --> Output Class Initialized
INFO - 2021-07-28 05:18:10 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:10 --> Input Class Initialized
INFO - 2021-07-28 05:18:10 --> Language Class Initialized
INFO - 2021-07-28 05:18:10 --> Language Class Initialized
INFO - 2021-07-28 05:18:10 --> Config Class Initialized
INFO - 2021-07-28 05:18:10 --> Loader Class Initialized
INFO - 2021-07-28 05:18:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:10 --> Controller Class Initialized
INFO - 2021-07-28 05:18:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:10 --> Total execution time: 0.0429
INFO - 2021-07-28 05:18:12 --> Config Class Initialized
INFO - 2021-07-28 05:18:12 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:12 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:12 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:12 --> URI Class Initialized
INFO - 2021-07-28 05:18:12 --> Router Class Initialized
INFO - 2021-07-28 05:18:12 --> Output Class Initialized
INFO - 2021-07-28 05:18:12 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:12 --> Input Class Initialized
INFO - 2021-07-28 05:18:12 --> Language Class Initialized
INFO - 2021-07-28 05:18:12 --> Language Class Initialized
INFO - 2021-07-28 05:18:12 --> Config Class Initialized
INFO - 2021-07-28 05:18:12 --> Loader Class Initialized
INFO - 2021-07-28 05:18:12 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:12 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:12 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:12 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:12 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:12 --> Controller Class Initialized
INFO - 2021-07-28 05:18:12 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:12 --> Total execution time: 0.0605
INFO - 2021-07-28 05:18:17 --> Config Class Initialized
INFO - 2021-07-28 05:18:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:17 --> URI Class Initialized
INFO - 2021-07-28 05:18:17 --> Router Class Initialized
INFO - 2021-07-28 05:18:17 --> Output Class Initialized
INFO - 2021-07-28 05:18:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:17 --> Input Class Initialized
INFO - 2021-07-28 05:18:17 --> Language Class Initialized
INFO - 2021-07-28 05:18:17 --> Language Class Initialized
INFO - 2021-07-28 05:18:17 --> Config Class Initialized
INFO - 2021-07-28 05:18:17 --> Loader Class Initialized
INFO - 2021-07-28 05:18:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:17 --> Controller Class Initialized
INFO - 2021-07-28 05:18:18 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:18 --> Total execution time: 0.9036
INFO - 2021-07-28 05:18:20 --> Config Class Initialized
INFO - 2021-07-28 05:18:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:20 --> URI Class Initialized
INFO - 2021-07-28 05:18:20 --> Router Class Initialized
INFO - 2021-07-28 05:18:20 --> Output Class Initialized
INFO - 2021-07-28 05:18:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:20 --> Input Class Initialized
INFO - 2021-07-28 05:18:20 --> Language Class Initialized
INFO - 2021-07-28 05:18:20 --> Language Class Initialized
INFO - 2021-07-28 05:18:20 --> Config Class Initialized
INFO - 2021-07-28 05:18:20 --> Loader Class Initialized
INFO - 2021-07-28 05:18:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:20 --> Controller Class Initialized
DEBUG - 2021-07-28 05:18:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:18:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:18:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:20 --> Total execution time: 0.0508
INFO - 2021-07-28 05:18:22 --> Config Class Initialized
INFO - 2021-07-28 05:18:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:22 --> URI Class Initialized
INFO - 2021-07-28 05:18:22 --> Router Class Initialized
INFO - 2021-07-28 05:18:22 --> Output Class Initialized
INFO - 2021-07-28 05:18:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:22 --> Input Class Initialized
INFO - 2021-07-28 05:18:22 --> Language Class Initialized
INFO - 2021-07-28 05:18:22 --> Language Class Initialized
INFO - 2021-07-28 05:18:22 --> Config Class Initialized
INFO - 2021-07-28 05:18:22 --> Loader Class Initialized
INFO - 2021-07-28 05:18:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:22 --> Controller Class Initialized
DEBUG - 2021-07-28 05:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:18:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:22 --> Total execution time: 0.0617
INFO - 2021-07-28 05:18:23 --> Config Class Initialized
INFO - 2021-07-28 05:18:23 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:23 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:23 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:23 --> URI Class Initialized
INFO - 2021-07-28 05:18:23 --> Router Class Initialized
INFO - 2021-07-28 05:18:23 --> Output Class Initialized
INFO - 2021-07-28 05:18:23 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:23 --> Input Class Initialized
INFO - 2021-07-28 05:18:23 --> Language Class Initialized
INFO - 2021-07-28 05:18:23 --> Language Class Initialized
INFO - 2021-07-28 05:18:23 --> Config Class Initialized
INFO - 2021-07-28 05:18:23 --> Loader Class Initialized
INFO - 2021-07-28 05:18:23 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:23 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:23 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:23 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:23 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:23 --> Controller Class Initialized
INFO - 2021-07-28 05:18:23 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:23 --> Total execution time: 0.0993
INFO - 2021-07-28 05:18:26 --> Config Class Initialized
INFO - 2021-07-28 05:18:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:26 --> URI Class Initialized
INFO - 2021-07-28 05:18:26 --> Router Class Initialized
INFO - 2021-07-28 05:18:26 --> Output Class Initialized
INFO - 2021-07-28 05:18:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:26 --> Input Class Initialized
INFO - 2021-07-28 05:18:26 --> Language Class Initialized
INFO - 2021-07-28 05:18:26 --> Language Class Initialized
INFO - 2021-07-28 05:18:26 --> Config Class Initialized
INFO - 2021-07-28 05:18:27 --> Loader Class Initialized
INFO - 2021-07-28 05:18:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:27 --> Controller Class Initialized
INFO - 2021-07-28 05:18:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:27 --> Total execution time: 0.0597
INFO - 2021-07-28 05:18:28 --> Config Class Initialized
INFO - 2021-07-28 05:18:28 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:28 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:28 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:28 --> URI Class Initialized
INFO - 2021-07-28 05:18:28 --> Router Class Initialized
INFO - 2021-07-28 05:18:28 --> Output Class Initialized
INFO - 2021-07-28 05:18:28 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:28 --> Input Class Initialized
INFO - 2021-07-28 05:18:28 --> Language Class Initialized
INFO - 2021-07-28 05:18:28 --> Language Class Initialized
INFO - 2021-07-28 05:18:28 --> Config Class Initialized
INFO - 2021-07-28 05:18:28 --> Loader Class Initialized
INFO - 2021-07-28 05:18:28 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:28 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:28 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:28 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:28 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:28 --> Controller Class Initialized
INFO - 2021-07-28 05:18:28 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:28 --> Total execution time: 0.0431
INFO - 2021-07-28 05:18:31 --> Config Class Initialized
INFO - 2021-07-28 05:18:31 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:31 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:31 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:31 --> URI Class Initialized
INFO - 2021-07-28 05:18:31 --> Router Class Initialized
INFO - 2021-07-28 05:18:31 --> Output Class Initialized
INFO - 2021-07-28 05:18:31 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:31 --> Input Class Initialized
INFO - 2021-07-28 05:18:31 --> Language Class Initialized
INFO - 2021-07-28 05:18:31 --> Language Class Initialized
INFO - 2021-07-28 05:18:31 --> Config Class Initialized
INFO - 2021-07-28 05:18:31 --> Loader Class Initialized
INFO - 2021-07-28 05:18:31 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:31 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:31 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:31 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:31 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:31 --> Controller Class Initialized
DEBUG - 2021-07-28 05:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:18:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:18:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:31 --> Total execution time: 0.0449
INFO - 2021-07-28 05:18:38 --> Config Class Initialized
INFO - 2021-07-28 05:18:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:38 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:38 --> URI Class Initialized
INFO - 2021-07-28 05:18:38 --> Router Class Initialized
INFO - 2021-07-28 05:18:38 --> Output Class Initialized
INFO - 2021-07-28 05:18:38 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:38 --> Input Class Initialized
INFO - 2021-07-28 05:18:38 --> Language Class Initialized
INFO - 2021-07-28 05:18:38 --> Language Class Initialized
INFO - 2021-07-28 05:18:38 --> Config Class Initialized
INFO - 2021-07-28 05:18:38 --> Loader Class Initialized
INFO - 2021-07-28 05:18:38 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:38 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:38 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:38 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:38 --> Controller Class Initialized
INFO - 2021-07-28 05:18:38 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:18:38 --> Config Class Initialized
INFO - 2021-07-28 05:18:38 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:38 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:38 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:38 --> URI Class Initialized
INFO - 2021-07-28 05:18:38 --> Router Class Initialized
INFO - 2021-07-28 05:18:38 --> Output Class Initialized
INFO - 2021-07-28 05:18:38 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:38 --> Input Class Initialized
INFO - 2021-07-28 05:18:38 --> Language Class Initialized
INFO - 2021-07-28 05:18:38 --> Language Class Initialized
INFO - 2021-07-28 05:18:38 --> Config Class Initialized
INFO - 2021-07-28 05:18:38 --> Loader Class Initialized
INFO - 2021-07-28 05:18:38 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:38 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:38 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:38 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:38 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:38 --> Controller Class Initialized
DEBUG - 2021-07-28 05:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:18:38 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:38 --> Total execution time: 0.0562
INFO - 2021-07-28 05:18:50 --> Config Class Initialized
INFO - 2021-07-28 05:18:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:50 --> URI Class Initialized
INFO - 2021-07-28 05:18:50 --> Router Class Initialized
INFO - 2021-07-28 05:18:50 --> Output Class Initialized
INFO - 2021-07-28 05:18:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:50 --> Input Class Initialized
INFO - 2021-07-28 05:18:50 --> Language Class Initialized
INFO - 2021-07-28 05:18:50 --> Language Class Initialized
INFO - 2021-07-28 05:18:50 --> Config Class Initialized
INFO - 2021-07-28 05:18:50 --> Loader Class Initialized
INFO - 2021-07-28 05:18:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:50 --> Controller Class Initialized
INFO - 2021-07-28 05:18:50 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:18:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:50 --> Total execution time: 0.0434
INFO - 2021-07-28 05:18:51 --> Config Class Initialized
INFO - 2021-07-28 05:18:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:51 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:51 --> URI Class Initialized
INFO - 2021-07-28 05:18:51 --> Router Class Initialized
INFO - 2021-07-28 05:18:51 --> Output Class Initialized
INFO - 2021-07-28 05:18:51 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:51 --> Input Class Initialized
INFO - 2021-07-28 05:18:51 --> Language Class Initialized
INFO - 2021-07-28 05:18:51 --> Language Class Initialized
INFO - 2021-07-28 05:18:51 --> Config Class Initialized
INFO - 2021-07-28 05:18:51 --> Loader Class Initialized
INFO - 2021-07-28 05:18:51 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:51 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:51 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:51 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:51 --> Controller Class Initialized
DEBUG - 2021-07-28 05:18:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:18:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:18:52 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:52 --> Total execution time: 0.7291
INFO - 2021-07-28 05:18:53 --> Config Class Initialized
INFO - 2021-07-28 05:18:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:53 --> URI Class Initialized
INFO - 2021-07-28 05:18:53 --> Router Class Initialized
INFO - 2021-07-28 05:18:53 --> Output Class Initialized
INFO - 2021-07-28 05:18:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:53 --> Input Class Initialized
INFO - 2021-07-28 05:18:53 --> Language Class Initialized
INFO - 2021-07-28 05:18:53 --> Language Class Initialized
INFO - 2021-07-28 05:18:53 --> Config Class Initialized
INFO - 2021-07-28 05:18:53 --> Loader Class Initialized
INFO - 2021-07-28 05:18:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:53 --> Controller Class Initialized
DEBUG - 2021-07-28 05:18:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:18:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:18:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:53 --> Total execution time: 0.0625
INFO - 2021-07-28 05:18:55 --> Config Class Initialized
INFO - 2021-07-28 05:18:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:55 --> URI Class Initialized
INFO - 2021-07-28 05:18:55 --> Router Class Initialized
INFO - 2021-07-28 05:18:55 --> Output Class Initialized
INFO - 2021-07-28 05:18:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:55 --> Input Class Initialized
INFO - 2021-07-28 05:18:55 --> Language Class Initialized
INFO - 2021-07-28 05:18:55 --> Language Class Initialized
INFO - 2021-07-28 05:18:55 --> Config Class Initialized
INFO - 2021-07-28 05:18:55 --> Loader Class Initialized
INFO - 2021-07-28 05:18:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:55 --> Controller Class Initialized
DEBUG - 2021-07-28 05:18:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:18:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:18:55 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:55 --> Total execution time: 0.0567
INFO - 2021-07-28 05:18:55 --> Config Class Initialized
INFO - 2021-07-28 05:18:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:55 --> URI Class Initialized
INFO - 2021-07-28 05:18:55 --> Router Class Initialized
INFO - 2021-07-28 05:18:55 --> Output Class Initialized
INFO - 2021-07-28 05:18:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:55 --> Input Class Initialized
INFO - 2021-07-28 05:18:55 --> Language Class Initialized
INFO - 2021-07-28 05:18:55 --> Language Class Initialized
INFO - 2021-07-28 05:18:55 --> Config Class Initialized
INFO - 2021-07-28 05:18:55 --> Loader Class Initialized
INFO - 2021-07-28 05:18:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:55 --> Controller Class Initialized
INFO - 2021-07-28 05:18:58 --> Config Class Initialized
INFO - 2021-07-28 05:18:58 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:18:58 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:18:58 --> Utf8 Class Initialized
INFO - 2021-07-28 05:18:58 --> URI Class Initialized
INFO - 2021-07-28 05:18:58 --> Router Class Initialized
INFO - 2021-07-28 05:18:58 --> Output Class Initialized
INFO - 2021-07-28 05:18:58 --> Security Class Initialized
DEBUG - 2021-07-28 05:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:18:58 --> Input Class Initialized
INFO - 2021-07-28 05:18:58 --> Language Class Initialized
INFO - 2021-07-28 05:18:58 --> Language Class Initialized
INFO - 2021-07-28 05:18:58 --> Config Class Initialized
INFO - 2021-07-28 05:18:58 --> Loader Class Initialized
INFO - 2021-07-28 05:18:58 --> Helper loaded: url_helper
INFO - 2021-07-28 05:18:58 --> Helper loaded: file_helper
INFO - 2021-07-28 05:18:58 --> Helper loaded: form_helper
INFO - 2021-07-28 05:18:58 --> Helper loaded: my_helper
INFO - 2021-07-28 05:18:58 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:18:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:18:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:18:58 --> Controller Class Initialized
INFO - 2021-07-28 05:18:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:18:58 --> Total execution time: 0.0972
INFO - 2021-07-28 05:19:01 --> Config Class Initialized
INFO - 2021-07-28 05:19:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:01 --> URI Class Initialized
INFO - 2021-07-28 05:19:01 --> Router Class Initialized
INFO - 2021-07-28 05:19:01 --> Output Class Initialized
INFO - 2021-07-28 05:19:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:01 --> Input Class Initialized
INFO - 2021-07-28 05:19:01 --> Language Class Initialized
INFO - 2021-07-28 05:19:01 --> Language Class Initialized
INFO - 2021-07-28 05:19:01 --> Config Class Initialized
INFO - 2021-07-28 05:19:01 --> Loader Class Initialized
INFO - 2021-07-28 05:19:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:01 --> Controller Class Initialized
INFO - 2021-07-28 05:19:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:01 --> Total execution time: 0.0634
INFO - 2021-07-28 05:19:07 --> Config Class Initialized
INFO - 2021-07-28 05:19:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:07 --> URI Class Initialized
INFO - 2021-07-28 05:19:07 --> Router Class Initialized
INFO - 2021-07-28 05:19:07 --> Output Class Initialized
INFO - 2021-07-28 05:19:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:07 --> Input Class Initialized
INFO - 2021-07-28 05:19:07 --> Language Class Initialized
INFO - 2021-07-28 05:19:07 --> Language Class Initialized
INFO - 2021-07-28 05:19:07 --> Config Class Initialized
INFO - 2021-07-28 05:19:07 --> Loader Class Initialized
INFO - 2021-07-28 05:19:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:07 --> Controller Class Initialized
INFO - 2021-07-28 05:19:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:08 --> Total execution time: 0.9253
INFO - 2021-07-28 05:19:08 --> Config Class Initialized
INFO - 2021-07-28 05:19:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:08 --> URI Class Initialized
INFO - 2021-07-28 05:19:09 --> Router Class Initialized
INFO - 2021-07-28 05:19:09 --> Output Class Initialized
INFO - 2021-07-28 05:19:09 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:09 --> Input Class Initialized
INFO - 2021-07-28 05:19:09 --> Language Class Initialized
INFO - 2021-07-28 05:19:09 --> Language Class Initialized
INFO - 2021-07-28 05:19:09 --> Config Class Initialized
INFO - 2021-07-28 05:19:09 --> Loader Class Initialized
INFO - 2021-07-28 05:19:09 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:09 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:09 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:09 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:09 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:09 --> Controller Class Initialized
INFO - 2021-07-28 05:19:09 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:09 --> Total execution time: 0.0571
INFO - 2021-07-28 05:19:11 --> Config Class Initialized
INFO - 2021-07-28 05:19:11 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:11 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:11 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:11 --> URI Class Initialized
INFO - 2021-07-28 05:19:11 --> Router Class Initialized
INFO - 2021-07-28 05:19:11 --> Output Class Initialized
INFO - 2021-07-28 05:19:11 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:11 --> Input Class Initialized
INFO - 2021-07-28 05:19:11 --> Language Class Initialized
INFO - 2021-07-28 05:19:11 --> Language Class Initialized
INFO - 2021-07-28 05:19:11 --> Config Class Initialized
INFO - 2021-07-28 05:19:11 --> Loader Class Initialized
INFO - 2021-07-28 05:19:11 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:11 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:11 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:11 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:11 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:11 --> Controller Class Initialized
INFO - 2021-07-28 05:19:12 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:12 --> Total execution time: 0.9173
INFO - 2021-07-28 05:19:13 --> Config Class Initialized
INFO - 2021-07-28 05:19:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:13 --> URI Class Initialized
INFO - 2021-07-28 05:19:13 --> Router Class Initialized
INFO - 2021-07-28 05:19:13 --> Output Class Initialized
INFO - 2021-07-28 05:19:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:13 --> Input Class Initialized
INFO - 2021-07-28 05:19:13 --> Language Class Initialized
INFO - 2021-07-28 05:19:13 --> Language Class Initialized
INFO - 2021-07-28 05:19:13 --> Config Class Initialized
INFO - 2021-07-28 05:19:13 --> Loader Class Initialized
INFO - 2021-07-28 05:19:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:13 --> Controller Class Initialized
INFO - 2021-07-28 05:19:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:13 --> Total execution time: 0.0631
INFO - 2021-07-28 05:19:15 --> Config Class Initialized
INFO - 2021-07-28 05:19:15 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:15 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:15 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:15 --> URI Class Initialized
INFO - 2021-07-28 05:19:15 --> Router Class Initialized
INFO - 2021-07-28 05:19:15 --> Output Class Initialized
INFO - 2021-07-28 05:19:15 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:15 --> Input Class Initialized
INFO - 2021-07-28 05:19:15 --> Language Class Initialized
INFO - 2021-07-28 05:19:15 --> Language Class Initialized
INFO - 2021-07-28 05:19:15 --> Config Class Initialized
INFO - 2021-07-28 05:19:15 --> Loader Class Initialized
INFO - 2021-07-28 05:19:15 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:15 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:15 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:15 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:15 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:15 --> Controller Class Initialized
INFO - 2021-07-28 05:19:15 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:15 --> Total execution time: 0.0632
INFO - 2021-07-28 05:19:18 --> Config Class Initialized
INFO - 2021-07-28 05:19:18 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:18 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:18 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:18 --> URI Class Initialized
INFO - 2021-07-28 05:19:18 --> Router Class Initialized
INFO - 2021-07-28 05:19:18 --> Output Class Initialized
INFO - 2021-07-28 05:19:18 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:18 --> Input Class Initialized
INFO - 2021-07-28 05:19:18 --> Language Class Initialized
INFO - 2021-07-28 05:19:18 --> Language Class Initialized
INFO - 2021-07-28 05:19:18 --> Config Class Initialized
INFO - 2021-07-28 05:19:18 --> Loader Class Initialized
INFO - 2021-07-28 05:19:18 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:18 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:18 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:18 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:18 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:18 --> Controller Class Initialized
INFO - 2021-07-28 05:19:19 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:19 --> Total execution time: 0.8952
INFO - 2021-07-28 05:19:25 --> Config Class Initialized
INFO - 2021-07-28 05:19:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:25 --> URI Class Initialized
INFO - 2021-07-28 05:19:25 --> Router Class Initialized
INFO - 2021-07-28 05:19:25 --> Output Class Initialized
INFO - 2021-07-28 05:19:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:25 --> Input Class Initialized
INFO - 2021-07-28 05:19:25 --> Language Class Initialized
INFO - 2021-07-28 05:19:25 --> Language Class Initialized
INFO - 2021-07-28 05:19:25 --> Config Class Initialized
INFO - 2021-07-28 05:19:25 --> Loader Class Initialized
INFO - 2021-07-28 05:19:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:25 --> Controller Class Initialized
DEBUG - 2021-07-28 05:19:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:19:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:19:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:25 --> Total execution time: 0.0601
INFO - 2021-07-28 05:19:27 --> Config Class Initialized
INFO - 2021-07-28 05:19:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:27 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:27 --> URI Class Initialized
INFO - 2021-07-28 05:19:27 --> Router Class Initialized
INFO - 2021-07-28 05:19:27 --> Output Class Initialized
INFO - 2021-07-28 05:19:27 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:27 --> Input Class Initialized
INFO - 2021-07-28 05:19:27 --> Language Class Initialized
INFO - 2021-07-28 05:19:27 --> Language Class Initialized
INFO - 2021-07-28 05:19:27 --> Config Class Initialized
INFO - 2021-07-28 05:19:27 --> Loader Class Initialized
INFO - 2021-07-28 05:19:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:27 --> Controller Class Initialized
DEBUG - 2021-07-28 05:19:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:19:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:19:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:27 --> Total execution time: 0.0607
INFO - 2021-07-28 05:19:29 --> Config Class Initialized
INFO - 2021-07-28 05:19:29 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:29 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:29 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:29 --> URI Class Initialized
INFO - 2021-07-28 05:19:29 --> Router Class Initialized
INFO - 2021-07-28 05:19:29 --> Output Class Initialized
INFO - 2021-07-28 05:19:29 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:29 --> Input Class Initialized
INFO - 2021-07-28 05:19:29 --> Language Class Initialized
INFO - 2021-07-28 05:19:29 --> Language Class Initialized
INFO - 2021-07-28 05:19:29 --> Config Class Initialized
INFO - 2021-07-28 05:19:29 --> Loader Class Initialized
INFO - 2021-07-28 05:19:29 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:29 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:29 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:29 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:29 --> Controller Class Initialized
INFO - 2021-07-28 05:19:29 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:29 --> Total execution time: 0.0977
INFO - 2021-07-28 05:19:32 --> Config Class Initialized
INFO - 2021-07-28 05:19:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:32 --> URI Class Initialized
INFO - 2021-07-28 05:19:32 --> Router Class Initialized
INFO - 2021-07-28 05:19:32 --> Output Class Initialized
INFO - 2021-07-28 05:19:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:32 --> Input Class Initialized
INFO - 2021-07-28 05:19:32 --> Language Class Initialized
INFO - 2021-07-28 05:19:32 --> Language Class Initialized
INFO - 2021-07-28 05:19:32 --> Config Class Initialized
INFO - 2021-07-28 05:19:32 --> Loader Class Initialized
INFO - 2021-07-28 05:19:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:32 --> Controller Class Initialized
INFO - 2021-07-28 05:19:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:32 --> Total execution time: 0.0621
INFO - 2021-07-28 05:19:35 --> Config Class Initialized
INFO - 2021-07-28 05:19:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:35 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:35 --> URI Class Initialized
INFO - 2021-07-28 05:19:35 --> Router Class Initialized
INFO - 2021-07-28 05:19:35 --> Output Class Initialized
INFO - 2021-07-28 05:19:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:35 --> Input Class Initialized
INFO - 2021-07-28 05:19:35 --> Language Class Initialized
INFO - 2021-07-28 05:19:35 --> Language Class Initialized
INFO - 2021-07-28 05:19:35 --> Config Class Initialized
INFO - 2021-07-28 05:19:35 --> Loader Class Initialized
INFO - 2021-07-28 05:19:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:35 --> Controller Class Initialized
INFO - 2021-07-28 05:19:36 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:36 --> Total execution time: 0.8257
INFO - 2021-07-28 05:19:37 --> Config Class Initialized
INFO - 2021-07-28 05:19:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:37 --> URI Class Initialized
INFO - 2021-07-28 05:19:37 --> Router Class Initialized
INFO - 2021-07-28 05:19:37 --> Output Class Initialized
INFO - 2021-07-28 05:19:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:37 --> Input Class Initialized
INFO - 2021-07-28 05:19:37 --> Language Class Initialized
INFO - 2021-07-28 05:19:37 --> Language Class Initialized
INFO - 2021-07-28 05:19:37 --> Config Class Initialized
INFO - 2021-07-28 05:19:37 --> Loader Class Initialized
INFO - 2021-07-28 05:19:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:37 --> Controller Class Initialized
INFO - 2021-07-28 05:19:37 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:37 --> Total execution time: 0.0665
INFO - 2021-07-28 05:19:42 --> Config Class Initialized
INFO - 2021-07-28 05:19:42 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:42 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:42 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:42 --> URI Class Initialized
INFO - 2021-07-28 05:19:42 --> Router Class Initialized
INFO - 2021-07-28 05:19:42 --> Output Class Initialized
INFO - 2021-07-28 05:19:42 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:42 --> Input Class Initialized
INFO - 2021-07-28 05:19:42 --> Language Class Initialized
INFO - 2021-07-28 05:19:42 --> Language Class Initialized
INFO - 2021-07-28 05:19:42 --> Config Class Initialized
INFO - 2021-07-28 05:19:42 --> Loader Class Initialized
INFO - 2021-07-28 05:19:42 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:42 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:42 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:42 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:42 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:42 --> Controller Class Initialized
INFO - 2021-07-28 05:19:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:43 --> Total execution time: 0.8086
INFO - 2021-07-28 05:19:46 --> Config Class Initialized
INFO - 2021-07-28 05:19:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:46 --> URI Class Initialized
INFO - 2021-07-28 05:19:46 --> Router Class Initialized
INFO - 2021-07-28 05:19:46 --> Output Class Initialized
INFO - 2021-07-28 05:19:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:46 --> Input Class Initialized
INFO - 2021-07-28 05:19:46 --> Language Class Initialized
INFO - 2021-07-28 05:19:46 --> Language Class Initialized
INFO - 2021-07-28 05:19:46 --> Config Class Initialized
INFO - 2021-07-28 05:19:46 --> Loader Class Initialized
INFO - 2021-07-28 05:19:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:46 --> Controller Class Initialized
DEBUG - 2021-07-28 05:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:19:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:46 --> Total execution time: 0.0627
INFO - 2021-07-28 05:19:46 --> Config Class Initialized
INFO - 2021-07-28 05:19:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:46 --> URI Class Initialized
INFO - 2021-07-28 05:19:46 --> Router Class Initialized
INFO - 2021-07-28 05:19:46 --> Output Class Initialized
INFO - 2021-07-28 05:19:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:46 --> Input Class Initialized
INFO - 2021-07-28 05:19:46 --> Language Class Initialized
INFO - 2021-07-28 05:19:46 --> Language Class Initialized
INFO - 2021-07-28 05:19:46 --> Config Class Initialized
INFO - 2021-07-28 05:19:46 --> Loader Class Initialized
INFO - 2021-07-28 05:19:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:47 --> Controller Class Initialized
INFO - 2021-07-28 05:19:47 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:19:47 --> Config Class Initialized
INFO - 2021-07-28 05:19:47 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:47 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:47 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:47 --> URI Class Initialized
INFO - 2021-07-28 05:19:47 --> Router Class Initialized
INFO - 2021-07-28 05:19:47 --> Output Class Initialized
INFO - 2021-07-28 05:19:47 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:47 --> Input Class Initialized
INFO - 2021-07-28 05:19:47 --> Language Class Initialized
INFO - 2021-07-28 05:19:47 --> Language Class Initialized
INFO - 2021-07-28 05:19:47 --> Config Class Initialized
INFO - 2021-07-28 05:19:47 --> Loader Class Initialized
INFO - 2021-07-28 05:19:47 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:47 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:47 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:47 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:47 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:47 --> Controller Class Initialized
DEBUG - 2021-07-28 05:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:19:47 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:47 --> Total execution time: 0.0399
INFO - 2021-07-28 05:19:56 --> Config Class Initialized
INFO - 2021-07-28 05:19:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:56 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:56 --> URI Class Initialized
INFO - 2021-07-28 05:19:56 --> Router Class Initialized
INFO - 2021-07-28 05:19:56 --> Output Class Initialized
INFO - 2021-07-28 05:19:56 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:56 --> Input Class Initialized
INFO - 2021-07-28 05:19:56 --> Language Class Initialized
INFO - 2021-07-28 05:19:56 --> Language Class Initialized
INFO - 2021-07-28 05:19:56 --> Config Class Initialized
INFO - 2021-07-28 05:19:56 --> Loader Class Initialized
INFO - 2021-07-28 05:19:56 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:56 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:56 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:56 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:56 --> Controller Class Initialized
INFO - 2021-07-28 05:19:56 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:19:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:56 --> Total execution time: 0.0562
INFO - 2021-07-28 05:19:57 --> Config Class Initialized
INFO - 2021-07-28 05:19:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:19:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:19:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:19:57 --> URI Class Initialized
INFO - 2021-07-28 05:19:57 --> Router Class Initialized
INFO - 2021-07-28 05:19:57 --> Output Class Initialized
INFO - 2021-07-28 05:19:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:19:57 --> Input Class Initialized
INFO - 2021-07-28 05:19:57 --> Language Class Initialized
INFO - 2021-07-28 05:19:57 --> Language Class Initialized
INFO - 2021-07-28 05:19:57 --> Config Class Initialized
INFO - 2021-07-28 05:19:57 --> Loader Class Initialized
INFO - 2021-07-28 05:19:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:19:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:19:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:19:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:19:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:19:57 --> Controller Class Initialized
DEBUG - 2021-07-28 05:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:19:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:19:58 --> Total execution time: 0.7062
INFO - 2021-07-28 05:20:51 --> Config Class Initialized
INFO - 2021-07-28 05:20:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:20:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:20:51 --> Utf8 Class Initialized
INFO - 2021-07-28 05:20:51 --> URI Class Initialized
INFO - 2021-07-28 05:20:51 --> Router Class Initialized
INFO - 2021-07-28 05:20:51 --> Output Class Initialized
INFO - 2021-07-28 05:20:51 --> Security Class Initialized
DEBUG - 2021-07-28 05:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:20:51 --> Input Class Initialized
INFO - 2021-07-28 05:20:51 --> Language Class Initialized
INFO - 2021-07-28 05:20:51 --> Language Class Initialized
INFO - 2021-07-28 05:20:51 --> Config Class Initialized
INFO - 2021-07-28 05:20:51 --> Loader Class Initialized
INFO - 2021-07-28 05:20:51 --> Helper loaded: url_helper
INFO - 2021-07-28 05:20:51 --> Helper loaded: file_helper
INFO - 2021-07-28 05:20:51 --> Helper loaded: form_helper
INFO - 2021-07-28 05:20:51 --> Helper loaded: my_helper
INFO - 2021-07-28 05:20:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:20:51 --> Controller Class Initialized
DEBUG - 2021-07-28 05:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:20:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:20:51 --> Total execution time: 0.0614
INFO - 2021-07-28 05:20:52 --> Config Class Initialized
INFO - 2021-07-28 05:20:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:20:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:20:52 --> Utf8 Class Initialized
INFO - 2021-07-28 05:20:52 --> URI Class Initialized
INFO - 2021-07-28 05:20:52 --> Router Class Initialized
INFO - 2021-07-28 05:20:52 --> Output Class Initialized
INFO - 2021-07-28 05:20:52 --> Security Class Initialized
DEBUG - 2021-07-28 05:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:20:52 --> Input Class Initialized
INFO - 2021-07-28 05:20:52 --> Language Class Initialized
INFO - 2021-07-28 05:20:52 --> Language Class Initialized
INFO - 2021-07-28 05:20:52 --> Config Class Initialized
INFO - 2021-07-28 05:20:52 --> Loader Class Initialized
INFO - 2021-07-28 05:20:52 --> Helper loaded: url_helper
INFO - 2021-07-28 05:20:52 --> Helper loaded: file_helper
INFO - 2021-07-28 05:20:52 --> Helper loaded: form_helper
INFO - 2021-07-28 05:20:52 --> Helper loaded: my_helper
INFO - 2021-07-28 05:20:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:20:52 --> Controller Class Initialized
DEBUG - 2021-07-28 05:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:20:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:20:52 --> Final output sent to browser
DEBUG - 2021-07-28 05:20:52 --> Total execution time: 0.0722
INFO - 2021-07-28 05:20:52 --> Config Class Initialized
INFO - 2021-07-28 05:20:52 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:20:52 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:20:52 --> Utf8 Class Initialized
INFO - 2021-07-28 05:20:52 --> URI Class Initialized
INFO - 2021-07-28 05:20:52 --> Router Class Initialized
INFO - 2021-07-28 05:20:52 --> Output Class Initialized
INFO - 2021-07-28 05:20:52 --> Security Class Initialized
DEBUG - 2021-07-28 05:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:20:52 --> Input Class Initialized
INFO - 2021-07-28 05:20:52 --> Language Class Initialized
INFO - 2021-07-28 05:20:52 --> Language Class Initialized
INFO - 2021-07-28 05:20:52 --> Config Class Initialized
INFO - 2021-07-28 05:20:52 --> Loader Class Initialized
INFO - 2021-07-28 05:20:52 --> Helper loaded: url_helper
INFO - 2021-07-28 05:20:52 --> Helper loaded: file_helper
INFO - 2021-07-28 05:20:52 --> Helper loaded: form_helper
INFO - 2021-07-28 05:20:52 --> Helper loaded: my_helper
INFO - 2021-07-28 05:20:52 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:20:52 --> Controller Class Initialized
INFO - 2021-07-28 05:20:56 --> Config Class Initialized
INFO - 2021-07-28 05:20:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:20:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:20:56 --> Utf8 Class Initialized
INFO - 2021-07-28 05:20:56 --> URI Class Initialized
INFO - 2021-07-28 05:20:56 --> Router Class Initialized
INFO - 2021-07-28 05:20:56 --> Output Class Initialized
INFO - 2021-07-28 05:20:56 --> Security Class Initialized
DEBUG - 2021-07-28 05:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:20:56 --> Input Class Initialized
INFO - 2021-07-28 05:20:56 --> Language Class Initialized
INFO - 2021-07-28 05:20:56 --> Language Class Initialized
INFO - 2021-07-28 05:20:56 --> Config Class Initialized
INFO - 2021-07-28 05:20:56 --> Loader Class Initialized
INFO - 2021-07-28 05:20:56 --> Helper loaded: url_helper
INFO - 2021-07-28 05:20:56 --> Helper loaded: file_helper
INFO - 2021-07-28 05:20:56 --> Helper loaded: form_helper
INFO - 2021-07-28 05:20:56 --> Helper loaded: my_helper
INFO - 2021-07-28 05:20:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:20:56 --> Controller Class Initialized
INFO - 2021-07-28 05:20:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:20:56 --> Total execution time: 0.1033
INFO - 2021-07-28 05:22:42 --> Config Class Initialized
INFO - 2021-07-28 05:22:42 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:22:42 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:22:42 --> Utf8 Class Initialized
INFO - 2021-07-28 05:22:42 --> URI Class Initialized
INFO - 2021-07-28 05:22:42 --> Router Class Initialized
INFO - 2021-07-28 05:22:42 --> Output Class Initialized
INFO - 2021-07-28 05:22:42 --> Security Class Initialized
DEBUG - 2021-07-28 05:22:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:22:42 --> Input Class Initialized
INFO - 2021-07-28 05:22:42 --> Language Class Initialized
INFO - 2021-07-28 05:22:42 --> Language Class Initialized
INFO - 2021-07-28 05:22:42 --> Config Class Initialized
INFO - 2021-07-28 05:22:42 --> Loader Class Initialized
INFO - 2021-07-28 05:22:42 --> Helper loaded: url_helper
INFO - 2021-07-28 05:22:42 --> Helper loaded: file_helper
INFO - 2021-07-28 05:22:42 --> Helper loaded: form_helper
INFO - 2021-07-28 05:22:42 --> Helper loaded: my_helper
INFO - 2021-07-28 05:22:42 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:22:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:22:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:22:42 --> Controller Class Initialized
INFO - 2021-07-28 05:22:42 --> Final output sent to browser
DEBUG - 2021-07-28 05:22:42 --> Total execution time: 0.9025
INFO - 2021-07-28 05:22:45 --> Config Class Initialized
INFO - 2021-07-28 05:22:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:22:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:22:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:22:45 --> URI Class Initialized
INFO - 2021-07-28 05:22:45 --> Router Class Initialized
INFO - 2021-07-28 05:22:45 --> Output Class Initialized
INFO - 2021-07-28 05:22:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:22:45 --> Input Class Initialized
INFO - 2021-07-28 05:22:45 --> Language Class Initialized
INFO - 2021-07-28 05:22:45 --> Language Class Initialized
INFO - 2021-07-28 05:22:45 --> Config Class Initialized
INFO - 2021-07-28 05:22:45 --> Loader Class Initialized
INFO - 2021-07-28 05:22:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:22:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:22:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:22:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:22:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:22:45 --> Controller Class Initialized
INFO - 2021-07-28 05:22:45 --> Final output sent to browser
DEBUG - 2021-07-28 05:22:45 --> Total execution time: 0.0479
INFO - 2021-07-28 05:22:46 --> Config Class Initialized
INFO - 2021-07-28 05:22:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:22:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:22:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:22:46 --> URI Class Initialized
INFO - 2021-07-28 05:22:46 --> Router Class Initialized
INFO - 2021-07-28 05:22:46 --> Output Class Initialized
INFO - 2021-07-28 05:22:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:22:46 --> Input Class Initialized
INFO - 2021-07-28 05:22:46 --> Language Class Initialized
INFO - 2021-07-28 05:22:46 --> Language Class Initialized
INFO - 2021-07-28 05:22:46 --> Config Class Initialized
INFO - 2021-07-28 05:22:46 --> Loader Class Initialized
INFO - 2021-07-28 05:22:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:22:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:22:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:22:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:22:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:22:46 --> Controller Class Initialized
INFO - 2021-07-28 05:22:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:22:46 --> Total execution time: 0.0619
INFO - 2021-07-28 05:22:50 --> Config Class Initialized
INFO - 2021-07-28 05:22:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:22:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:22:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:22:50 --> URI Class Initialized
INFO - 2021-07-28 05:22:50 --> Router Class Initialized
INFO - 2021-07-28 05:22:50 --> Output Class Initialized
INFO - 2021-07-28 05:22:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:22:50 --> Input Class Initialized
INFO - 2021-07-28 05:22:50 --> Language Class Initialized
INFO - 2021-07-28 05:22:50 --> Language Class Initialized
INFO - 2021-07-28 05:22:50 --> Config Class Initialized
INFO - 2021-07-28 05:22:50 --> Loader Class Initialized
INFO - 2021-07-28 05:22:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:22:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:22:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:22:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:22:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:22:50 --> Controller Class Initialized
INFO - 2021-07-28 05:22:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:22:51 --> Total execution time: 0.9072
INFO - 2021-07-28 05:22:53 --> Config Class Initialized
INFO - 2021-07-28 05:22:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:22:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:22:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:22:53 --> URI Class Initialized
INFO - 2021-07-28 05:22:53 --> Router Class Initialized
INFO - 2021-07-28 05:22:53 --> Output Class Initialized
INFO - 2021-07-28 05:22:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:22:53 --> Input Class Initialized
INFO - 2021-07-28 05:22:53 --> Language Class Initialized
INFO - 2021-07-28 05:22:53 --> Language Class Initialized
INFO - 2021-07-28 05:22:53 --> Config Class Initialized
INFO - 2021-07-28 05:22:53 --> Loader Class Initialized
INFO - 2021-07-28 05:22:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:22:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:22:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:22:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:22:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:22:53 --> Controller Class Initialized
INFO - 2021-07-28 05:22:53 --> Final output sent to browser
DEBUG - 2021-07-28 05:22:53 --> Total execution time: 0.0629
INFO - 2021-07-28 05:22:57 --> Config Class Initialized
INFO - 2021-07-28 05:22:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:22:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:22:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:22:57 --> URI Class Initialized
INFO - 2021-07-28 05:22:57 --> Router Class Initialized
INFO - 2021-07-28 05:22:57 --> Output Class Initialized
INFO - 2021-07-28 05:22:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:22:57 --> Input Class Initialized
INFO - 2021-07-28 05:22:57 --> Language Class Initialized
INFO - 2021-07-28 05:22:57 --> Language Class Initialized
INFO - 2021-07-28 05:22:57 --> Config Class Initialized
INFO - 2021-07-28 05:22:57 --> Loader Class Initialized
INFO - 2021-07-28 05:22:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:22:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:22:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:22:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:22:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:22:57 --> Controller Class Initialized
INFO - 2021-07-28 05:22:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:22:58 --> Total execution time: 0.9038
INFO - 2021-07-28 05:22:59 --> Config Class Initialized
INFO - 2021-07-28 05:22:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:22:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:22:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:22:59 --> URI Class Initialized
INFO - 2021-07-28 05:22:59 --> Router Class Initialized
INFO - 2021-07-28 05:22:59 --> Output Class Initialized
INFO - 2021-07-28 05:22:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:22:59 --> Input Class Initialized
INFO - 2021-07-28 05:22:59 --> Language Class Initialized
INFO - 2021-07-28 05:22:59 --> Language Class Initialized
INFO - 2021-07-28 05:22:59 --> Config Class Initialized
INFO - 2021-07-28 05:22:59 --> Loader Class Initialized
INFO - 2021-07-28 05:22:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:22:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:22:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:22:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:22:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:22:59 --> Controller Class Initialized
INFO - 2021-07-28 05:22:59 --> Final output sent to browser
DEBUG - 2021-07-28 05:22:59 --> Total execution time: 0.0581
INFO - 2021-07-28 05:23:02 --> Config Class Initialized
INFO - 2021-07-28 05:23:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:02 --> URI Class Initialized
INFO - 2021-07-28 05:23:02 --> Router Class Initialized
INFO - 2021-07-28 05:23:02 --> Output Class Initialized
INFO - 2021-07-28 05:23:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:02 --> Input Class Initialized
INFO - 2021-07-28 05:23:02 --> Language Class Initialized
INFO - 2021-07-28 05:23:02 --> Language Class Initialized
INFO - 2021-07-28 05:23:02 --> Config Class Initialized
INFO - 2021-07-28 05:23:02 --> Loader Class Initialized
INFO - 2021-07-28 05:23:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:02 --> Controller Class Initialized
INFO - 2021-07-28 05:23:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:03 --> Total execution time: 0.9016
INFO - 2021-07-28 05:23:05 --> Config Class Initialized
INFO - 2021-07-28 05:23:05 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:05 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:05 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:05 --> URI Class Initialized
INFO - 2021-07-28 05:23:05 --> Router Class Initialized
INFO - 2021-07-28 05:23:05 --> Output Class Initialized
INFO - 2021-07-28 05:23:05 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:05 --> Input Class Initialized
INFO - 2021-07-28 05:23:05 --> Language Class Initialized
INFO - 2021-07-28 05:23:05 --> Language Class Initialized
INFO - 2021-07-28 05:23:05 --> Config Class Initialized
INFO - 2021-07-28 05:23:05 --> Loader Class Initialized
INFO - 2021-07-28 05:23:05 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:05 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:05 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:05 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:05 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:05 --> Controller Class Initialized
INFO - 2021-07-28 05:23:05 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:05 --> Total execution time: 0.0657
INFO - 2021-07-28 05:23:07 --> Config Class Initialized
INFO - 2021-07-28 05:23:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:07 --> URI Class Initialized
INFO - 2021-07-28 05:23:07 --> Router Class Initialized
INFO - 2021-07-28 05:23:07 --> Output Class Initialized
INFO - 2021-07-28 05:23:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:07 --> Input Class Initialized
INFO - 2021-07-28 05:23:07 --> Language Class Initialized
INFO - 2021-07-28 05:23:07 --> Language Class Initialized
INFO - 2021-07-28 05:23:07 --> Config Class Initialized
INFO - 2021-07-28 05:23:07 --> Loader Class Initialized
INFO - 2021-07-28 05:23:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:07 --> Controller Class Initialized
INFO - 2021-07-28 05:23:07 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:07 --> Total execution time: 0.0571
INFO - 2021-07-28 05:23:20 --> Config Class Initialized
INFO - 2021-07-28 05:23:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:20 --> URI Class Initialized
INFO - 2021-07-28 05:23:20 --> Router Class Initialized
INFO - 2021-07-28 05:23:20 --> Output Class Initialized
INFO - 2021-07-28 05:23:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:20 --> Input Class Initialized
INFO - 2021-07-28 05:23:20 --> Language Class Initialized
INFO - 2021-07-28 05:23:20 --> Language Class Initialized
INFO - 2021-07-28 05:23:20 --> Config Class Initialized
INFO - 2021-07-28 05:23:20 --> Loader Class Initialized
INFO - 2021-07-28 05:23:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:20 --> Controller Class Initialized
DEBUG - 2021-07-28 05:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:23:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:20 --> Total execution time: 0.0464
INFO - 2021-07-28 05:23:21 --> Config Class Initialized
INFO - 2021-07-28 05:23:21 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:21 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:21 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:21 --> URI Class Initialized
INFO - 2021-07-28 05:23:21 --> Router Class Initialized
INFO - 2021-07-28 05:23:21 --> Output Class Initialized
INFO - 2021-07-28 05:23:21 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:21 --> Input Class Initialized
INFO - 2021-07-28 05:23:21 --> Language Class Initialized
INFO - 2021-07-28 05:23:21 --> Language Class Initialized
INFO - 2021-07-28 05:23:21 --> Config Class Initialized
INFO - 2021-07-28 05:23:21 --> Loader Class Initialized
INFO - 2021-07-28 05:23:21 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:21 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:21 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:21 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:21 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:21 --> Controller Class Initialized
DEBUG - 2021-07-28 05:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:23:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:23:21 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:21 --> Total execution time: 0.0669
INFO - 2021-07-28 05:23:22 --> Config Class Initialized
INFO - 2021-07-28 05:23:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:22 --> URI Class Initialized
INFO - 2021-07-28 05:23:22 --> Router Class Initialized
INFO - 2021-07-28 05:23:22 --> Output Class Initialized
INFO - 2021-07-28 05:23:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:22 --> Input Class Initialized
INFO - 2021-07-28 05:23:22 --> Language Class Initialized
INFO - 2021-07-28 05:23:22 --> Language Class Initialized
INFO - 2021-07-28 05:23:22 --> Config Class Initialized
INFO - 2021-07-28 05:23:22 --> Loader Class Initialized
INFO - 2021-07-28 05:23:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:22 --> Controller Class Initialized
INFO - 2021-07-28 05:23:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:22 --> Total execution time: 0.1006
INFO - 2021-07-28 05:23:26 --> Config Class Initialized
INFO - 2021-07-28 05:23:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:26 --> URI Class Initialized
INFO - 2021-07-28 05:23:26 --> Router Class Initialized
INFO - 2021-07-28 05:23:26 --> Output Class Initialized
INFO - 2021-07-28 05:23:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:26 --> Input Class Initialized
INFO - 2021-07-28 05:23:26 --> Language Class Initialized
INFO - 2021-07-28 05:23:26 --> Language Class Initialized
INFO - 2021-07-28 05:23:26 --> Config Class Initialized
INFO - 2021-07-28 05:23:26 --> Loader Class Initialized
INFO - 2021-07-28 05:23:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:26 --> Controller Class Initialized
INFO - 2021-07-28 05:23:26 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:26 --> Total execution time: 0.8032
INFO - 2021-07-28 05:23:27 --> Config Class Initialized
INFO - 2021-07-28 05:23:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:27 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:27 --> URI Class Initialized
INFO - 2021-07-28 05:23:27 --> Router Class Initialized
INFO - 2021-07-28 05:23:27 --> Output Class Initialized
INFO - 2021-07-28 05:23:27 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:27 --> Input Class Initialized
INFO - 2021-07-28 05:23:27 --> Language Class Initialized
INFO - 2021-07-28 05:23:27 --> Language Class Initialized
INFO - 2021-07-28 05:23:27 --> Config Class Initialized
INFO - 2021-07-28 05:23:27 --> Loader Class Initialized
INFO - 2021-07-28 05:23:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:27 --> Controller Class Initialized
INFO - 2021-07-28 05:23:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:27 --> Total execution time: 0.0480
INFO - 2021-07-28 05:23:30 --> Config Class Initialized
INFO - 2021-07-28 05:23:30 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:30 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:30 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:30 --> URI Class Initialized
INFO - 2021-07-28 05:23:30 --> Router Class Initialized
INFO - 2021-07-28 05:23:30 --> Output Class Initialized
INFO - 2021-07-28 05:23:30 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:30 --> Input Class Initialized
INFO - 2021-07-28 05:23:30 --> Language Class Initialized
INFO - 2021-07-28 05:23:30 --> Language Class Initialized
INFO - 2021-07-28 05:23:30 --> Config Class Initialized
INFO - 2021-07-28 05:23:30 --> Loader Class Initialized
INFO - 2021-07-28 05:23:30 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:30 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:30 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:30 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:30 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:30 --> Controller Class Initialized
INFO - 2021-07-28 05:23:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:31 --> Total execution time: 0.8092
INFO - 2021-07-28 05:23:32 --> Config Class Initialized
INFO - 2021-07-28 05:23:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:32 --> URI Class Initialized
INFO - 2021-07-28 05:23:32 --> Router Class Initialized
INFO - 2021-07-28 05:23:32 --> Output Class Initialized
INFO - 2021-07-28 05:23:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:32 --> Input Class Initialized
INFO - 2021-07-28 05:23:32 --> Language Class Initialized
INFO - 2021-07-28 05:23:32 --> Language Class Initialized
INFO - 2021-07-28 05:23:32 --> Config Class Initialized
INFO - 2021-07-28 05:23:32 --> Loader Class Initialized
INFO - 2021-07-28 05:23:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:32 --> Controller Class Initialized
DEBUG - 2021-07-28 05:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:23:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:23:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:32 --> Total execution time: 0.0591
INFO - 2021-07-28 05:23:39 --> Config Class Initialized
INFO - 2021-07-28 05:23:39 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:39 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:39 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:39 --> URI Class Initialized
INFO - 2021-07-28 05:23:39 --> Router Class Initialized
INFO - 2021-07-28 05:23:39 --> Output Class Initialized
INFO - 2021-07-28 05:23:39 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:39 --> Input Class Initialized
INFO - 2021-07-28 05:23:39 --> Language Class Initialized
INFO - 2021-07-28 05:23:39 --> Language Class Initialized
INFO - 2021-07-28 05:23:39 --> Config Class Initialized
INFO - 2021-07-28 05:23:39 --> Loader Class Initialized
INFO - 2021-07-28 05:23:39 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:39 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:39 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:39 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:39 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:39 --> Controller Class Initialized
DEBUG - 2021-07-28 05:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:23:39 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:39 --> Total execution time: 0.0464
INFO - 2021-07-28 05:23:39 --> Config Class Initialized
INFO - 2021-07-28 05:23:39 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:39 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:39 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:39 --> URI Class Initialized
INFO - 2021-07-28 05:23:39 --> Router Class Initialized
INFO - 2021-07-28 05:23:39 --> Output Class Initialized
INFO - 2021-07-28 05:23:39 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:39 --> Input Class Initialized
INFO - 2021-07-28 05:23:39 --> Language Class Initialized
INFO - 2021-07-28 05:23:39 --> Language Class Initialized
INFO - 2021-07-28 05:23:39 --> Config Class Initialized
INFO - 2021-07-28 05:23:39 --> Loader Class Initialized
INFO - 2021-07-28 05:23:39 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:39 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:39 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:39 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:39 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:39 --> Controller Class Initialized
INFO - 2021-07-28 05:23:42 --> Config Class Initialized
INFO - 2021-07-28 05:23:42 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:42 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:42 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:42 --> URI Class Initialized
INFO - 2021-07-28 05:23:42 --> Router Class Initialized
INFO - 2021-07-28 05:23:42 --> Output Class Initialized
INFO - 2021-07-28 05:23:42 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:42 --> Input Class Initialized
INFO - 2021-07-28 05:23:42 --> Language Class Initialized
INFO - 2021-07-28 05:23:42 --> Language Class Initialized
INFO - 2021-07-28 05:23:42 --> Config Class Initialized
INFO - 2021-07-28 05:23:42 --> Loader Class Initialized
INFO - 2021-07-28 05:23:42 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:42 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:42 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:42 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:42 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:42 --> Controller Class Initialized
INFO - 2021-07-28 05:23:42 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:42 --> Total execution time: 0.0914
INFO - 2021-07-28 05:23:46 --> Config Class Initialized
INFO - 2021-07-28 05:23:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:46 --> URI Class Initialized
INFO - 2021-07-28 05:23:46 --> Router Class Initialized
INFO - 2021-07-28 05:23:46 --> Output Class Initialized
INFO - 2021-07-28 05:23:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:46 --> Input Class Initialized
INFO - 2021-07-28 05:23:46 --> Language Class Initialized
INFO - 2021-07-28 05:23:46 --> Language Class Initialized
INFO - 2021-07-28 05:23:46 --> Config Class Initialized
INFO - 2021-07-28 05:23:46 --> Loader Class Initialized
INFO - 2021-07-28 05:23:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:46 --> Controller Class Initialized
INFO - 2021-07-28 05:23:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:46 --> Total execution time: 0.9041
INFO - 2021-07-28 05:23:47 --> Config Class Initialized
INFO - 2021-07-28 05:23:47 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:47 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:47 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:47 --> URI Class Initialized
INFO - 2021-07-28 05:23:47 --> Router Class Initialized
INFO - 2021-07-28 05:23:47 --> Output Class Initialized
INFO - 2021-07-28 05:23:47 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:47 --> Input Class Initialized
INFO - 2021-07-28 05:23:47 --> Language Class Initialized
INFO - 2021-07-28 05:23:47 --> Language Class Initialized
INFO - 2021-07-28 05:23:47 --> Config Class Initialized
INFO - 2021-07-28 05:23:47 --> Loader Class Initialized
INFO - 2021-07-28 05:23:47 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:47 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:47 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:47 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:47 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:47 --> Controller Class Initialized
INFO - 2021-07-28 05:23:47 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:47 --> Total execution time: 0.0619
INFO - 2021-07-28 05:23:49 --> Config Class Initialized
INFO - 2021-07-28 05:23:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:49 --> URI Class Initialized
INFO - 2021-07-28 05:23:49 --> Router Class Initialized
INFO - 2021-07-28 05:23:49 --> Output Class Initialized
INFO - 2021-07-28 05:23:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:49 --> Input Class Initialized
INFO - 2021-07-28 05:23:49 --> Language Class Initialized
INFO - 2021-07-28 05:23:49 --> Language Class Initialized
INFO - 2021-07-28 05:23:49 --> Config Class Initialized
INFO - 2021-07-28 05:23:49 --> Loader Class Initialized
INFO - 2021-07-28 05:23:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:49 --> Controller Class Initialized
INFO - 2021-07-28 05:23:49 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:49 --> Total execution time: 0.0758
INFO - 2021-07-28 05:23:54 --> Config Class Initialized
INFO - 2021-07-28 05:23:54 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:54 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:54 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:54 --> URI Class Initialized
INFO - 2021-07-28 05:23:54 --> Router Class Initialized
INFO - 2021-07-28 05:23:54 --> Output Class Initialized
INFO - 2021-07-28 05:23:54 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:54 --> Input Class Initialized
INFO - 2021-07-28 05:23:54 --> Language Class Initialized
INFO - 2021-07-28 05:23:54 --> Language Class Initialized
INFO - 2021-07-28 05:23:54 --> Config Class Initialized
INFO - 2021-07-28 05:23:54 --> Loader Class Initialized
INFO - 2021-07-28 05:23:54 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:54 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:54 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:54 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:54 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:54 --> Controller Class Initialized
INFO - 2021-07-28 05:23:55 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:55 --> Total execution time: 0.9003
INFO - 2021-07-28 05:23:56 --> Config Class Initialized
INFO - 2021-07-28 05:23:56 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:23:56 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:23:56 --> Utf8 Class Initialized
INFO - 2021-07-28 05:23:56 --> URI Class Initialized
INFO - 2021-07-28 05:23:56 --> Router Class Initialized
INFO - 2021-07-28 05:23:56 --> Output Class Initialized
INFO - 2021-07-28 05:23:56 --> Security Class Initialized
DEBUG - 2021-07-28 05:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:23:56 --> Input Class Initialized
INFO - 2021-07-28 05:23:56 --> Language Class Initialized
INFO - 2021-07-28 05:23:56 --> Language Class Initialized
INFO - 2021-07-28 05:23:56 --> Config Class Initialized
INFO - 2021-07-28 05:23:56 --> Loader Class Initialized
INFO - 2021-07-28 05:23:56 --> Helper loaded: url_helper
INFO - 2021-07-28 05:23:56 --> Helper loaded: file_helper
INFO - 2021-07-28 05:23:56 --> Helper loaded: form_helper
INFO - 2021-07-28 05:23:56 --> Helper loaded: my_helper
INFO - 2021-07-28 05:23:56 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:23:56 --> Controller Class Initialized
INFO - 2021-07-28 05:23:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:23:56 --> Total execution time: 0.0525
INFO - 2021-07-28 05:24:02 --> Config Class Initialized
INFO - 2021-07-28 05:24:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:02 --> URI Class Initialized
INFO - 2021-07-28 05:24:02 --> Router Class Initialized
INFO - 2021-07-28 05:24:02 --> Output Class Initialized
INFO - 2021-07-28 05:24:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:02 --> Input Class Initialized
INFO - 2021-07-28 05:24:02 --> Language Class Initialized
INFO - 2021-07-28 05:24:02 --> Language Class Initialized
INFO - 2021-07-28 05:24:02 --> Config Class Initialized
INFO - 2021-07-28 05:24:02 --> Loader Class Initialized
INFO - 2021-07-28 05:24:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:02 --> Controller Class Initialized
INFO - 2021-07-28 05:24:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:03 --> Total execution time: 0.9234
INFO - 2021-07-28 05:24:05 --> Config Class Initialized
INFO - 2021-07-28 05:24:05 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:05 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:05 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:05 --> URI Class Initialized
INFO - 2021-07-28 05:24:05 --> Router Class Initialized
INFO - 2021-07-28 05:24:05 --> Output Class Initialized
INFO - 2021-07-28 05:24:05 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:05 --> Input Class Initialized
INFO - 2021-07-28 05:24:05 --> Language Class Initialized
INFO - 2021-07-28 05:24:05 --> Language Class Initialized
INFO - 2021-07-28 05:24:05 --> Config Class Initialized
INFO - 2021-07-28 05:24:05 --> Loader Class Initialized
INFO - 2021-07-28 05:24:05 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:05 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:05 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:05 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:05 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:05 --> Controller Class Initialized
INFO - 2021-07-28 05:24:05 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:05 --> Total execution time: 0.0621
INFO - 2021-07-28 05:24:15 --> Config Class Initialized
INFO - 2021-07-28 05:24:15 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:15 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:15 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:15 --> URI Class Initialized
INFO - 2021-07-28 05:24:15 --> Router Class Initialized
INFO - 2021-07-28 05:24:15 --> Output Class Initialized
INFO - 2021-07-28 05:24:15 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:15 --> Input Class Initialized
INFO - 2021-07-28 05:24:15 --> Language Class Initialized
INFO - 2021-07-28 05:24:15 --> Language Class Initialized
INFO - 2021-07-28 05:24:15 --> Config Class Initialized
INFO - 2021-07-28 05:24:15 --> Loader Class Initialized
INFO - 2021-07-28 05:24:15 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:15 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:15 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:15 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:15 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:15 --> Controller Class Initialized
INFO - 2021-07-28 05:24:16 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:16 --> Total execution time: 0.8816
INFO - 2021-07-28 05:24:20 --> Config Class Initialized
INFO - 2021-07-28 05:24:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:20 --> URI Class Initialized
INFO - 2021-07-28 05:24:20 --> Router Class Initialized
INFO - 2021-07-28 05:24:20 --> Output Class Initialized
INFO - 2021-07-28 05:24:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:20 --> Input Class Initialized
INFO - 2021-07-28 05:24:20 --> Language Class Initialized
INFO - 2021-07-28 05:24:20 --> Language Class Initialized
INFO - 2021-07-28 05:24:20 --> Config Class Initialized
INFO - 2021-07-28 05:24:20 --> Loader Class Initialized
INFO - 2021-07-28 05:24:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:20 --> Controller Class Initialized
DEBUG - 2021-07-28 05:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:24:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:20 --> Total execution time: 0.0665
INFO - 2021-07-28 05:24:24 --> Config Class Initialized
INFO - 2021-07-28 05:24:24 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:24 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:24 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:24 --> URI Class Initialized
INFO - 2021-07-28 05:24:24 --> Router Class Initialized
INFO - 2021-07-28 05:24:24 --> Output Class Initialized
INFO - 2021-07-28 05:24:24 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:24 --> Input Class Initialized
INFO - 2021-07-28 05:24:24 --> Language Class Initialized
INFO - 2021-07-28 05:24:24 --> Language Class Initialized
INFO - 2021-07-28 05:24:24 --> Config Class Initialized
INFO - 2021-07-28 05:24:24 --> Loader Class Initialized
INFO - 2021-07-28 05:24:24 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:24 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:24 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:24 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:24 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:24 --> Controller Class Initialized
DEBUG - 2021-07-28 05:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:24:24 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:24 --> Total execution time: 0.0458
INFO - 2021-07-28 05:24:27 --> Config Class Initialized
INFO - 2021-07-28 05:24:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:27 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:27 --> URI Class Initialized
INFO - 2021-07-28 05:24:27 --> Router Class Initialized
INFO - 2021-07-28 05:24:27 --> Output Class Initialized
INFO - 2021-07-28 05:24:27 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:27 --> Input Class Initialized
INFO - 2021-07-28 05:24:27 --> Language Class Initialized
INFO - 2021-07-28 05:24:27 --> Language Class Initialized
INFO - 2021-07-28 05:24:27 --> Config Class Initialized
INFO - 2021-07-28 05:24:27 --> Loader Class Initialized
INFO - 2021-07-28 05:24:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:27 --> Controller Class Initialized
INFO - 2021-07-28 05:24:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:27 --> Total execution time: 0.1032
INFO - 2021-07-28 05:24:32 --> Config Class Initialized
INFO - 2021-07-28 05:24:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:32 --> URI Class Initialized
INFO - 2021-07-28 05:24:32 --> Router Class Initialized
INFO - 2021-07-28 05:24:32 --> Output Class Initialized
INFO - 2021-07-28 05:24:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:32 --> Input Class Initialized
INFO - 2021-07-28 05:24:32 --> Language Class Initialized
INFO - 2021-07-28 05:24:32 --> Language Class Initialized
INFO - 2021-07-28 05:24:32 --> Config Class Initialized
INFO - 2021-07-28 05:24:32 --> Loader Class Initialized
INFO - 2021-07-28 05:24:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:32 --> Controller Class Initialized
INFO - 2021-07-28 05:24:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:32 --> Total execution time: 0.8427
INFO - 2021-07-28 05:24:35 --> Config Class Initialized
INFO - 2021-07-28 05:24:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:35 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:35 --> URI Class Initialized
INFO - 2021-07-28 05:24:35 --> Router Class Initialized
INFO - 2021-07-28 05:24:35 --> Output Class Initialized
INFO - 2021-07-28 05:24:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:35 --> Input Class Initialized
INFO - 2021-07-28 05:24:35 --> Language Class Initialized
INFO - 2021-07-28 05:24:35 --> Language Class Initialized
INFO - 2021-07-28 05:24:35 --> Config Class Initialized
INFO - 2021-07-28 05:24:35 --> Loader Class Initialized
INFO - 2021-07-28 05:24:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:35 --> Controller Class Initialized
INFO - 2021-07-28 05:24:35 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:35 --> Total execution time: 0.0713
INFO - 2021-07-28 05:24:43 --> Config Class Initialized
INFO - 2021-07-28 05:24:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:43 --> URI Class Initialized
INFO - 2021-07-28 05:24:43 --> Router Class Initialized
INFO - 2021-07-28 05:24:43 --> Output Class Initialized
INFO - 2021-07-28 05:24:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:43 --> Input Class Initialized
INFO - 2021-07-28 05:24:43 --> Language Class Initialized
INFO - 2021-07-28 05:24:43 --> Language Class Initialized
INFO - 2021-07-28 05:24:43 --> Config Class Initialized
INFO - 2021-07-28 05:24:43 --> Loader Class Initialized
INFO - 2021-07-28 05:24:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:43 --> Controller Class Initialized
INFO - 2021-07-28 05:24:44 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:44 --> Total execution time: 0.7549
INFO - 2021-07-28 05:24:46 --> Config Class Initialized
INFO - 2021-07-28 05:24:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:46 --> URI Class Initialized
INFO - 2021-07-28 05:24:46 --> Router Class Initialized
INFO - 2021-07-28 05:24:46 --> Output Class Initialized
INFO - 2021-07-28 05:24:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:46 --> Input Class Initialized
INFO - 2021-07-28 05:24:46 --> Language Class Initialized
INFO - 2021-07-28 05:24:46 --> Language Class Initialized
INFO - 2021-07-28 05:24:46 --> Config Class Initialized
INFO - 2021-07-28 05:24:46 --> Loader Class Initialized
INFO - 2021-07-28 05:24:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:46 --> Controller Class Initialized
DEBUG - 2021-07-28 05:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:24:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:46 --> Total execution time: 0.0477
INFO - 2021-07-28 05:24:48 --> Config Class Initialized
INFO - 2021-07-28 05:24:48 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:48 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:48 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:48 --> URI Class Initialized
INFO - 2021-07-28 05:24:48 --> Router Class Initialized
INFO - 2021-07-28 05:24:48 --> Output Class Initialized
INFO - 2021-07-28 05:24:48 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:48 --> Input Class Initialized
INFO - 2021-07-28 05:24:48 --> Language Class Initialized
INFO - 2021-07-28 05:24:48 --> Language Class Initialized
INFO - 2021-07-28 05:24:48 --> Config Class Initialized
INFO - 2021-07-28 05:24:48 --> Loader Class Initialized
INFO - 2021-07-28 05:24:48 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:48 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:48 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:48 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:48 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:48 --> Controller Class Initialized
INFO - 2021-07-28 05:24:48 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:24:48 --> Config Class Initialized
INFO - 2021-07-28 05:24:48 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:48 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:48 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:48 --> URI Class Initialized
INFO - 2021-07-28 05:24:48 --> Router Class Initialized
INFO - 2021-07-28 05:24:48 --> Output Class Initialized
INFO - 2021-07-28 05:24:48 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:48 --> Input Class Initialized
INFO - 2021-07-28 05:24:48 --> Language Class Initialized
INFO - 2021-07-28 05:24:48 --> Language Class Initialized
INFO - 2021-07-28 05:24:48 --> Config Class Initialized
INFO - 2021-07-28 05:24:48 --> Loader Class Initialized
INFO - 2021-07-28 05:24:48 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:48 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:48 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:48 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:48 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:48 --> Controller Class Initialized
DEBUG - 2021-07-28 05:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:24:48 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:48 --> Total execution time: 0.0535
INFO - 2021-07-28 05:24:58 --> Config Class Initialized
INFO - 2021-07-28 05:24:58 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:24:58 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:24:58 --> Utf8 Class Initialized
INFO - 2021-07-28 05:24:58 --> URI Class Initialized
INFO - 2021-07-28 05:24:58 --> Router Class Initialized
INFO - 2021-07-28 05:24:58 --> Output Class Initialized
INFO - 2021-07-28 05:24:58 --> Security Class Initialized
DEBUG - 2021-07-28 05:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:24:58 --> Input Class Initialized
INFO - 2021-07-28 05:24:58 --> Language Class Initialized
INFO - 2021-07-28 05:24:58 --> Language Class Initialized
INFO - 2021-07-28 05:24:58 --> Config Class Initialized
INFO - 2021-07-28 05:24:58 --> Loader Class Initialized
INFO - 2021-07-28 05:24:58 --> Helper loaded: url_helper
INFO - 2021-07-28 05:24:58 --> Helper loaded: file_helper
INFO - 2021-07-28 05:24:58 --> Helper loaded: form_helper
INFO - 2021-07-28 05:24:58 --> Helper loaded: my_helper
INFO - 2021-07-28 05:24:58 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:24:58 --> Controller Class Initialized
INFO - 2021-07-28 05:24:58 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:24:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:24:58 --> Total execution time: 0.0596
INFO - 2021-07-28 05:25:00 --> Config Class Initialized
INFO - 2021-07-28 05:25:00 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:00 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:00 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:00 --> URI Class Initialized
INFO - 2021-07-28 05:25:00 --> Router Class Initialized
INFO - 2021-07-28 05:25:00 --> Output Class Initialized
INFO - 2021-07-28 05:25:00 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:00 --> Input Class Initialized
INFO - 2021-07-28 05:25:00 --> Language Class Initialized
INFO - 2021-07-28 05:25:00 --> Language Class Initialized
INFO - 2021-07-28 05:25:00 --> Config Class Initialized
INFO - 2021-07-28 05:25:00 --> Loader Class Initialized
INFO - 2021-07-28 05:25:00 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:00 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:00 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:00 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:00 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:00 --> Controller Class Initialized
DEBUG - 2021-07-28 05:25:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:25:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:25:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:01 --> Total execution time: 0.7117
INFO - 2021-07-28 05:25:02 --> Config Class Initialized
INFO - 2021-07-28 05:25:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:02 --> URI Class Initialized
INFO - 2021-07-28 05:25:02 --> Router Class Initialized
INFO - 2021-07-28 05:25:02 --> Output Class Initialized
INFO - 2021-07-28 05:25:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:02 --> Input Class Initialized
INFO - 2021-07-28 05:25:02 --> Language Class Initialized
INFO - 2021-07-28 05:25:02 --> Language Class Initialized
INFO - 2021-07-28 05:25:02 --> Config Class Initialized
INFO - 2021-07-28 05:25:02 --> Loader Class Initialized
INFO - 2021-07-28 05:25:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:02 --> Controller Class Initialized
DEBUG - 2021-07-28 05:25:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:25:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:25:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:02 --> Total execution time: 0.0638
INFO - 2021-07-28 05:25:07 --> Config Class Initialized
INFO - 2021-07-28 05:25:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:07 --> URI Class Initialized
INFO - 2021-07-28 05:25:07 --> Router Class Initialized
INFO - 2021-07-28 05:25:07 --> Output Class Initialized
INFO - 2021-07-28 05:25:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:07 --> Input Class Initialized
INFO - 2021-07-28 05:25:07 --> Language Class Initialized
INFO - 2021-07-28 05:25:07 --> Language Class Initialized
INFO - 2021-07-28 05:25:07 --> Config Class Initialized
INFO - 2021-07-28 05:25:07 --> Loader Class Initialized
INFO - 2021-07-28 05:25:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:07 --> Controller Class Initialized
DEBUG - 2021-07-28 05:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:25:07 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:07 --> Total execution time: 0.0566
INFO - 2021-07-28 05:25:07 --> Config Class Initialized
INFO - 2021-07-28 05:25:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:07 --> URI Class Initialized
INFO - 2021-07-28 05:25:07 --> Router Class Initialized
INFO - 2021-07-28 05:25:07 --> Output Class Initialized
INFO - 2021-07-28 05:25:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:07 --> Input Class Initialized
INFO - 2021-07-28 05:25:07 --> Language Class Initialized
INFO - 2021-07-28 05:25:07 --> Language Class Initialized
INFO - 2021-07-28 05:25:07 --> Config Class Initialized
INFO - 2021-07-28 05:25:07 --> Loader Class Initialized
INFO - 2021-07-28 05:25:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:07 --> Controller Class Initialized
INFO - 2021-07-28 05:25:10 --> Config Class Initialized
INFO - 2021-07-28 05:25:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:10 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:10 --> URI Class Initialized
INFO - 2021-07-28 05:25:10 --> Router Class Initialized
INFO - 2021-07-28 05:25:10 --> Output Class Initialized
INFO - 2021-07-28 05:25:10 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:10 --> Input Class Initialized
INFO - 2021-07-28 05:25:10 --> Language Class Initialized
INFO - 2021-07-28 05:25:10 --> Language Class Initialized
INFO - 2021-07-28 05:25:10 --> Config Class Initialized
INFO - 2021-07-28 05:25:10 --> Loader Class Initialized
INFO - 2021-07-28 05:25:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:10 --> Controller Class Initialized
INFO - 2021-07-28 05:25:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:10 --> Total execution time: 0.0910
INFO - 2021-07-28 05:25:14 --> Config Class Initialized
INFO - 2021-07-28 05:25:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:14 --> URI Class Initialized
INFO - 2021-07-28 05:25:14 --> Router Class Initialized
INFO - 2021-07-28 05:25:14 --> Output Class Initialized
INFO - 2021-07-28 05:25:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:14 --> Input Class Initialized
INFO - 2021-07-28 05:25:14 --> Language Class Initialized
INFO - 2021-07-28 05:25:14 --> Language Class Initialized
INFO - 2021-07-28 05:25:14 --> Config Class Initialized
INFO - 2021-07-28 05:25:14 --> Loader Class Initialized
INFO - 2021-07-28 05:25:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:14 --> Controller Class Initialized
INFO - 2021-07-28 05:25:15 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:15 --> Total execution time: 0.9316
INFO - 2021-07-28 05:25:15 --> Config Class Initialized
INFO - 2021-07-28 05:25:15 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:15 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:15 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:15 --> URI Class Initialized
INFO - 2021-07-28 05:25:15 --> Router Class Initialized
INFO - 2021-07-28 05:25:15 --> Output Class Initialized
INFO - 2021-07-28 05:25:15 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:15 --> Input Class Initialized
INFO - 2021-07-28 05:25:15 --> Language Class Initialized
INFO - 2021-07-28 05:25:15 --> Language Class Initialized
INFO - 2021-07-28 05:25:15 --> Config Class Initialized
INFO - 2021-07-28 05:25:15 --> Loader Class Initialized
INFO - 2021-07-28 05:25:15 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:15 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:15 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:15 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:15 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:15 --> Controller Class Initialized
INFO - 2021-07-28 05:25:15 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:15 --> Total execution time: 0.0707
INFO - 2021-07-28 05:25:19 --> Config Class Initialized
INFO - 2021-07-28 05:25:19 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:19 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:19 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:19 --> URI Class Initialized
INFO - 2021-07-28 05:25:19 --> Router Class Initialized
INFO - 2021-07-28 05:25:19 --> Output Class Initialized
INFO - 2021-07-28 05:25:19 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:19 --> Input Class Initialized
INFO - 2021-07-28 05:25:19 --> Language Class Initialized
INFO - 2021-07-28 05:25:19 --> Language Class Initialized
INFO - 2021-07-28 05:25:19 --> Config Class Initialized
INFO - 2021-07-28 05:25:19 --> Loader Class Initialized
INFO - 2021-07-28 05:25:19 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:19 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:19 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:19 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:19 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:19 --> Controller Class Initialized
INFO - 2021-07-28 05:25:19 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:19 --> Total execution time: 0.8872
INFO - 2021-07-28 05:25:20 --> Config Class Initialized
INFO - 2021-07-28 05:25:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:20 --> URI Class Initialized
INFO - 2021-07-28 05:25:20 --> Router Class Initialized
INFO - 2021-07-28 05:25:20 --> Output Class Initialized
INFO - 2021-07-28 05:25:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:20 --> Input Class Initialized
INFO - 2021-07-28 05:25:20 --> Language Class Initialized
INFO - 2021-07-28 05:25:20 --> Language Class Initialized
INFO - 2021-07-28 05:25:20 --> Config Class Initialized
INFO - 2021-07-28 05:25:20 --> Loader Class Initialized
INFO - 2021-07-28 05:25:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:20 --> Controller Class Initialized
INFO - 2021-07-28 05:25:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:20 --> Total execution time: 0.0556
INFO - 2021-07-28 05:25:24 --> Config Class Initialized
INFO - 2021-07-28 05:25:24 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:24 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:24 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:24 --> URI Class Initialized
INFO - 2021-07-28 05:25:24 --> Router Class Initialized
INFO - 2021-07-28 05:25:24 --> Output Class Initialized
INFO - 2021-07-28 05:25:24 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:24 --> Input Class Initialized
INFO - 2021-07-28 05:25:24 --> Language Class Initialized
INFO - 2021-07-28 05:25:24 --> Language Class Initialized
INFO - 2021-07-28 05:25:24 --> Config Class Initialized
INFO - 2021-07-28 05:25:24 --> Loader Class Initialized
INFO - 2021-07-28 05:25:24 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:24 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:24 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:24 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:24 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:24 --> Controller Class Initialized
INFO - 2021-07-28 05:25:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:25 --> Total execution time: 0.8976
INFO - 2021-07-28 05:25:26 --> Config Class Initialized
INFO - 2021-07-28 05:25:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:26 --> URI Class Initialized
INFO - 2021-07-28 05:25:26 --> Router Class Initialized
INFO - 2021-07-28 05:25:26 --> Output Class Initialized
INFO - 2021-07-28 05:25:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:26 --> Input Class Initialized
INFO - 2021-07-28 05:25:26 --> Language Class Initialized
INFO - 2021-07-28 05:25:26 --> Language Class Initialized
INFO - 2021-07-28 05:25:26 --> Config Class Initialized
INFO - 2021-07-28 05:25:26 --> Loader Class Initialized
INFO - 2021-07-28 05:25:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:26 --> Controller Class Initialized
INFO - 2021-07-28 05:25:26 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:26 --> Total execution time: 0.0453
INFO - 2021-07-28 05:25:30 --> Config Class Initialized
INFO - 2021-07-28 05:25:30 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:30 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:30 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:30 --> URI Class Initialized
INFO - 2021-07-28 05:25:30 --> Router Class Initialized
INFO - 2021-07-28 05:25:30 --> Output Class Initialized
INFO - 2021-07-28 05:25:30 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:30 --> Input Class Initialized
INFO - 2021-07-28 05:25:30 --> Language Class Initialized
INFO - 2021-07-28 05:25:30 --> Language Class Initialized
INFO - 2021-07-28 05:25:30 --> Config Class Initialized
INFO - 2021-07-28 05:25:30 --> Loader Class Initialized
INFO - 2021-07-28 05:25:30 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:30 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:30 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:30 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:30 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:30 --> Controller Class Initialized
INFO - 2021-07-28 05:25:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:31 --> Total execution time: 0.9479
INFO - 2021-07-28 05:25:31 --> Config Class Initialized
INFO - 2021-07-28 05:25:31 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:31 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:31 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:31 --> URI Class Initialized
INFO - 2021-07-28 05:25:31 --> Router Class Initialized
INFO - 2021-07-28 05:25:31 --> Output Class Initialized
INFO - 2021-07-28 05:25:31 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:31 --> Input Class Initialized
INFO - 2021-07-28 05:25:31 --> Language Class Initialized
INFO - 2021-07-28 05:25:31 --> Language Class Initialized
INFO - 2021-07-28 05:25:31 --> Config Class Initialized
INFO - 2021-07-28 05:25:31 --> Loader Class Initialized
INFO - 2021-07-28 05:25:31 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:31 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:31 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:31 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:31 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:31 --> Controller Class Initialized
INFO - 2021-07-28 05:25:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:31 --> Total execution time: 0.0691
INFO - 2021-07-28 05:25:35 --> Config Class Initialized
INFO - 2021-07-28 05:25:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:35 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:35 --> URI Class Initialized
INFO - 2021-07-28 05:25:35 --> Router Class Initialized
INFO - 2021-07-28 05:25:35 --> Output Class Initialized
INFO - 2021-07-28 05:25:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:35 --> Input Class Initialized
INFO - 2021-07-28 05:25:35 --> Language Class Initialized
INFO - 2021-07-28 05:25:35 --> Language Class Initialized
INFO - 2021-07-28 05:25:35 --> Config Class Initialized
INFO - 2021-07-28 05:25:35 --> Loader Class Initialized
INFO - 2021-07-28 05:25:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:35 --> Controller Class Initialized
INFO - 2021-07-28 05:25:36 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:36 --> Total execution time: 0.8929
INFO - 2021-07-28 05:25:37 --> Config Class Initialized
INFO - 2021-07-28 05:25:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:37 --> URI Class Initialized
INFO - 2021-07-28 05:25:37 --> Router Class Initialized
INFO - 2021-07-28 05:25:37 --> Output Class Initialized
INFO - 2021-07-28 05:25:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:37 --> Input Class Initialized
INFO - 2021-07-28 05:25:37 --> Language Class Initialized
INFO - 2021-07-28 05:25:37 --> Language Class Initialized
INFO - 2021-07-28 05:25:37 --> Config Class Initialized
INFO - 2021-07-28 05:25:37 --> Loader Class Initialized
INFO - 2021-07-28 05:25:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:37 --> Controller Class Initialized
INFO - 2021-07-28 05:25:37 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:37 --> Total execution time: 0.0681
INFO - 2021-07-28 05:25:40 --> Config Class Initialized
INFO - 2021-07-28 05:25:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:40 --> URI Class Initialized
INFO - 2021-07-28 05:25:40 --> Router Class Initialized
INFO - 2021-07-28 05:25:40 --> Output Class Initialized
INFO - 2021-07-28 05:25:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:40 --> Input Class Initialized
INFO - 2021-07-28 05:25:40 --> Language Class Initialized
INFO - 2021-07-28 05:25:40 --> Language Class Initialized
INFO - 2021-07-28 05:25:40 --> Config Class Initialized
INFO - 2021-07-28 05:25:40 --> Loader Class Initialized
INFO - 2021-07-28 05:25:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:40 --> Controller Class Initialized
INFO - 2021-07-28 05:25:41 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:41 --> Total execution time: 0.8980
INFO - 2021-07-28 05:25:46 --> Config Class Initialized
INFO - 2021-07-28 05:25:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:46 --> URI Class Initialized
INFO - 2021-07-28 05:25:46 --> Router Class Initialized
INFO - 2021-07-28 05:25:46 --> Output Class Initialized
INFO - 2021-07-28 05:25:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:46 --> Input Class Initialized
INFO - 2021-07-28 05:25:46 --> Language Class Initialized
INFO - 2021-07-28 05:25:46 --> Language Class Initialized
INFO - 2021-07-28 05:25:46 --> Config Class Initialized
INFO - 2021-07-28 05:25:46 --> Loader Class Initialized
INFO - 2021-07-28 05:25:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:46 --> Controller Class Initialized
DEBUG - 2021-07-28 05:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:25:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:25:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:46 --> Total execution time: 0.0594
INFO - 2021-07-28 05:25:47 --> Config Class Initialized
INFO - 2021-07-28 05:25:47 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:47 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:47 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:47 --> URI Class Initialized
INFO - 2021-07-28 05:25:47 --> Router Class Initialized
INFO - 2021-07-28 05:25:47 --> Output Class Initialized
INFO - 2021-07-28 05:25:47 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:47 --> Input Class Initialized
INFO - 2021-07-28 05:25:47 --> Language Class Initialized
INFO - 2021-07-28 05:25:47 --> Language Class Initialized
INFO - 2021-07-28 05:25:47 --> Config Class Initialized
INFO - 2021-07-28 05:25:47 --> Loader Class Initialized
INFO - 2021-07-28 05:25:47 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:47 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:47 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:47 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:47 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:47 --> Controller Class Initialized
DEBUG - 2021-07-28 05:25:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:25:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:25:47 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:47 --> Total execution time: 0.0613
INFO - 2021-07-28 05:25:49 --> Config Class Initialized
INFO - 2021-07-28 05:25:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:49 --> URI Class Initialized
INFO - 2021-07-28 05:25:49 --> Router Class Initialized
INFO - 2021-07-28 05:25:49 --> Output Class Initialized
INFO - 2021-07-28 05:25:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:49 --> Input Class Initialized
INFO - 2021-07-28 05:25:49 --> Language Class Initialized
INFO - 2021-07-28 05:25:49 --> Language Class Initialized
INFO - 2021-07-28 05:25:49 --> Config Class Initialized
INFO - 2021-07-28 05:25:49 --> Loader Class Initialized
INFO - 2021-07-28 05:25:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:49 --> Controller Class Initialized
INFO - 2021-07-28 05:25:49 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:49 --> Total execution time: 0.0947
INFO - 2021-07-28 05:25:53 --> Config Class Initialized
INFO - 2021-07-28 05:25:53 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:53 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:53 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:53 --> URI Class Initialized
INFO - 2021-07-28 05:25:53 --> Router Class Initialized
INFO - 2021-07-28 05:25:53 --> Output Class Initialized
INFO - 2021-07-28 05:25:53 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:53 --> Input Class Initialized
INFO - 2021-07-28 05:25:53 --> Language Class Initialized
INFO - 2021-07-28 05:25:53 --> Language Class Initialized
INFO - 2021-07-28 05:25:53 --> Config Class Initialized
INFO - 2021-07-28 05:25:53 --> Loader Class Initialized
INFO - 2021-07-28 05:25:53 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:53 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:53 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:53 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:53 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:53 --> Controller Class Initialized
INFO - 2021-07-28 05:25:54 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:54 --> Total execution time: 0.8010
INFO - 2021-07-28 05:25:55 --> Config Class Initialized
INFO - 2021-07-28 05:25:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:25:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:25:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:25:55 --> URI Class Initialized
INFO - 2021-07-28 05:25:55 --> Router Class Initialized
INFO - 2021-07-28 05:25:55 --> Output Class Initialized
INFO - 2021-07-28 05:25:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:25:55 --> Input Class Initialized
INFO - 2021-07-28 05:25:55 --> Language Class Initialized
INFO - 2021-07-28 05:25:55 --> Language Class Initialized
INFO - 2021-07-28 05:25:55 --> Config Class Initialized
INFO - 2021-07-28 05:25:55 --> Loader Class Initialized
INFO - 2021-07-28 05:25:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:25:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:25:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:25:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:25:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:25:55 --> Controller Class Initialized
INFO - 2021-07-28 05:25:55 --> Final output sent to browser
DEBUG - 2021-07-28 05:25:55 --> Total execution time: 0.0654
INFO - 2021-07-28 05:26:00 --> Config Class Initialized
INFO - 2021-07-28 05:26:00 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:00 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:00 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:00 --> URI Class Initialized
INFO - 2021-07-28 05:26:00 --> Router Class Initialized
INFO - 2021-07-28 05:26:00 --> Output Class Initialized
INFO - 2021-07-28 05:26:00 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:00 --> Input Class Initialized
INFO - 2021-07-28 05:26:00 --> Language Class Initialized
INFO - 2021-07-28 05:26:00 --> Language Class Initialized
INFO - 2021-07-28 05:26:00 --> Config Class Initialized
INFO - 2021-07-28 05:26:00 --> Loader Class Initialized
INFO - 2021-07-28 05:26:00 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:00 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:00 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:00 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:00 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:00 --> Controller Class Initialized
INFO - 2021-07-28 05:26:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:01 --> Total execution time: 0.8373
INFO - 2021-07-28 05:26:01 --> Config Class Initialized
INFO - 2021-07-28 05:26:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:01 --> URI Class Initialized
INFO - 2021-07-28 05:26:01 --> Router Class Initialized
INFO - 2021-07-28 05:26:01 --> Output Class Initialized
INFO - 2021-07-28 05:26:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:01 --> Input Class Initialized
INFO - 2021-07-28 05:26:01 --> Language Class Initialized
INFO - 2021-07-28 05:26:01 --> Language Class Initialized
INFO - 2021-07-28 05:26:01 --> Config Class Initialized
INFO - 2021-07-28 05:26:01 --> Loader Class Initialized
INFO - 2021-07-28 05:26:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:01 --> Controller Class Initialized
INFO - 2021-07-28 05:26:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:02 --> Total execution time: 0.7816
INFO - 2021-07-28 05:26:03 --> Config Class Initialized
INFO - 2021-07-28 05:26:03 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:03 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:03 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:03 --> URI Class Initialized
INFO - 2021-07-28 05:26:03 --> Router Class Initialized
INFO - 2021-07-28 05:26:03 --> Output Class Initialized
INFO - 2021-07-28 05:26:03 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:03 --> Input Class Initialized
INFO - 2021-07-28 05:26:03 --> Language Class Initialized
INFO - 2021-07-28 05:26:03 --> Language Class Initialized
INFO - 2021-07-28 05:26:03 --> Config Class Initialized
INFO - 2021-07-28 05:26:03 --> Loader Class Initialized
INFO - 2021-07-28 05:26:03 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:03 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:03 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:03 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:03 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:03 --> Controller Class Initialized
INFO - 2021-07-28 05:26:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:03 --> Total execution time: 0.1030
INFO - 2021-07-28 05:26:07 --> Config Class Initialized
INFO - 2021-07-28 05:26:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:07 --> URI Class Initialized
INFO - 2021-07-28 05:26:07 --> Router Class Initialized
INFO - 2021-07-28 05:26:07 --> Output Class Initialized
INFO - 2021-07-28 05:26:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:07 --> Input Class Initialized
INFO - 2021-07-28 05:26:07 --> Language Class Initialized
INFO - 2021-07-28 05:26:07 --> Language Class Initialized
INFO - 2021-07-28 05:26:07 --> Config Class Initialized
INFO - 2021-07-28 05:26:07 --> Loader Class Initialized
INFO - 2021-07-28 05:26:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:07 --> Controller Class Initialized
INFO - 2021-07-28 05:26:07 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:07 --> Total execution time: 0.7957
INFO - 2021-07-28 05:26:08 --> Config Class Initialized
INFO - 2021-07-28 05:26:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:08 --> URI Class Initialized
INFO - 2021-07-28 05:26:08 --> Router Class Initialized
INFO - 2021-07-28 05:26:08 --> Output Class Initialized
INFO - 2021-07-28 05:26:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:08 --> Input Class Initialized
INFO - 2021-07-28 05:26:08 --> Language Class Initialized
INFO - 2021-07-28 05:26:08 --> Language Class Initialized
INFO - 2021-07-28 05:26:08 --> Config Class Initialized
INFO - 2021-07-28 05:26:08 --> Loader Class Initialized
INFO - 2021-07-28 05:26:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:08 --> Controller Class Initialized
INFO - 2021-07-28 05:26:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:08 --> Total execution time: 0.0558
INFO - 2021-07-28 05:26:12 --> Config Class Initialized
INFO - 2021-07-28 05:26:12 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:12 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:12 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:12 --> URI Class Initialized
INFO - 2021-07-28 05:26:12 --> Router Class Initialized
INFO - 2021-07-28 05:26:12 --> Output Class Initialized
INFO - 2021-07-28 05:26:12 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:12 --> Input Class Initialized
INFO - 2021-07-28 05:26:12 --> Language Class Initialized
INFO - 2021-07-28 05:26:12 --> Language Class Initialized
INFO - 2021-07-28 05:26:12 --> Config Class Initialized
INFO - 2021-07-28 05:26:12 --> Loader Class Initialized
INFO - 2021-07-28 05:26:12 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:12 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:12 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:12 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:12 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:12 --> Controller Class Initialized
INFO - 2021-07-28 05:26:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:13 --> Total execution time: 0.8002
INFO - 2021-07-28 05:26:17 --> Config Class Initialized
INFO - 2021-07-28 05:26:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:17 --> URI Class Initialized
INFO - 2021-07-28 05:26:17 --> Router Class Initialized
INFO - 2021-07-28 05:26:17 --> Output Class Initialized
INFO - 2021-07-28 05:26:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:17 --> Input Class Initialized
INFO - 2021-07-28 05:26:17 --> Language Class Initialized
INFO - 2021-07-28 05:26:17 --> Language Class Initialized
INFO - 2021-07-28 05:26:17 --> Config Class Initialized
INFO - 2021-07-28 05:26:17 --> Loader Class Initialized
INFO - 2021-07-28 05:26:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:17 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:17 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:17 --> Total execution time: 0.0475
INFO - 2021-07-28 05:26:23 --> Config Class Initialized
INFO - 2021-07-28 05:26:23 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:23 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:23 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:23 --> URI Class Initialized
INFO - 2021-07-28 05:26:23 --> Router Class Initialized
INFO - 2021-07-28 05:26:23 --> Output Class Initialized
INFO - 2021-07-28 05:26:23 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:23 --> Input Class Initialized
INFO - 2021-07-28 05:26:23 --> Language Class Initialized
INFO - 2021-07-28 05:26:23 --> Language Class Initialized
INFO - 2021-07-28 05:26:23 --> Config Class Initialized
INFO - 2021-07-28 05:26:23 --> Loader Class Initialized
INFO - 2021-07-28 05:26:23 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:23 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:23 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:23 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:23 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:23 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:23 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:23 --> Total execution time: 0.0436
INFO - 2021-07-28 05:26:26 --> Config Class Initialized
INFO - 2021-07-28 05:26:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:26 --> URI Class Initialized
INFO - 2021-07-28 05:26:26 --> Router Class Initialized
INFO - 2021-07-28 05:26:26 --> Output Class Initialized
INFO - 2021-07-28 05:26:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:26 --> Input Class Initialized
INFO - 2021-07-28 05:26:26 --> Language Class Initialized
INFO - 2021-07-28 05:26:26 --> Language Class Initialized
INFO - 2021-07-28 05:26:26 --> Config Class Initialized
INFO - 2021-07-28 05:26:26 --> Loader Class Initialized
INFO - 2021-07-28 05:26:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:26 --> Controller Class Initialized
INFO - 2021-07-28 05:26:26 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:26:26 --> Config Class Initialized
INFO - 2021-07-28 05:26:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:26 --> URI Class Initialized
INFO - 2021-07-28 05:26:26 --> Router Class Initialized
INFO - 2021-07-28 05:26:26 --> Output Class Initialized
INFO - 2021-07-28 05:26:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:26 --> Input Class Initialized
INFO - 2021-07-28 05:26:26 --> Language Class Initialized
INFO - 2021-07-28 05:26:26 --> Language Class Initialized
INFO - 2021-07-28 05:26:26 --> Config Class Initialized
INFO - 2021-07-28 05:26:26 --> Loader Class Initialized
INFO - 2021-07-28 05:26:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:26 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:26 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:26 --> Total execution time: 0.0631
INFO - 2021-07-28 05:26:33 --> Config Class Initialized
INFO - 2021-07-28 05:26:33 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:33 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:33 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:33 --> URI Class Initialized
INFO - 2021-07-28 05:26:33 --> Router Class Initialized
INFO - 2021-07-28 05:26:33 --> Output Class Initialized
INFO - 2021-07-28 05:26:33 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:33 --> Input Class Initialized
INFO - 2021-07-28 05:26:33 --> Language Class Initialized
INFO - 2021-07-28 05:26:33 --> Language Class Initialized
INFO - 2021-07-28 05:26:33 --> Config Class Initialized
INFO - 2021-07-28 05:26:33 --> Loader Class Initialized
INFO - 2021-07-28 05:26:33 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:33 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:33 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:33 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:33 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:33 --> Controller Class Initialized
INFO - 2021-07-28 05:26:33 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:26:33 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:33 --> Total execution time: 0.0542
INFO - 2021-07-28 05:26:35 --> Config Class Initialized
INFO - 2021-07-28 05:26:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:35 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:35 --> URI Class Initialized
INFO - 2021-07-28 05:26:35 --> Router Class Initialized
INFO - 2021-07-28 05:26:35 --> Output Class Initialized
INFO - 2021-07-28 05:26:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:35 --> Input Class Initialized
INFO - 2021-07-28 05:26:35 --> Language Class Initialized
INFO - 2021-07-28 05:26:35 --> Language Class Initialized
INFO - 2021-07-28 05:26:35 --> Config Class Initialized
INFO - 2021-07-28 05:26:35 --> Loader Class Initialized
INFO - 2021-07-28 05:26:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:35 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:35 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:35 --> Total execution time: 0.6842
INFO - 2021-07-28 05:26:37 --> Config Class Initialized
INFO - 2021-07-28 05:26:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:37 --> URI Class Initialized
INFO - 2021-07-28 05:26:37 --> Router Class Initialized
INFO - 2021-07-28 05:26:37 --> Output Class Initialized
INFO - 2021-07-28 05:26:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:37 --> Input Class Initialized
INFO - 2021-07-28 05:26:37 --> Language Class Initialized
INFO - 2021-07-28 05:26:37 --> Language Class Initialized
INFO - 2021-07-28 05:26:37 --> Config Class Initialized
INFO - 2021-07-28 05:26:37 --> Loader Class Initialized
INFO - 2021-07-28 05:26:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:37 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:37 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:37 --> Total execution time: 0.0619
INFO - 2021-07-28 05:26:39 --> Config Class Initialized
INFO - 2021-07-28 05:26:39 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:39 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:39 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:39 --> URI Class Initialized
INFO - 2021-07-28 05:26:39 --> Router Class Initialized
INFO - 2021-07-28 05:26:39 --> Output Class Initialized
INFO - 2021-07-28 05:26:39 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:39 --> Input Class Initialized
INFO - 2021-07-28 05:26:39 --> Language Class Initialized
INFO - 2021-07-28 05:26:39 --> Language Class Initialized
INFO - 2021-07-28 05:26:39 --> Config Class Initialized
INFO - 2021-07-28 05:26:39 --> Loader Class Initialized
INFO - 2021-07-28 05:26:39 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:39 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:39 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:39 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:39 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:39 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:26:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:39 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:39 --> Total execution time: 0.0553
INFO - 2021-07-28 05:26:40 --> Config Class Initialized
INFO - 2021-07-28 05:26:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:40 --> URI Class Initialized
INFO - 2021-07-28 05:26:40 --> Router Class Initialized
INFO - 2021-07-28 05:26:40 --> Output Class Initialized
INFO - 2021-07-28 05:26:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:40 --> Input Class Initialized
INFO - 2021-07-28 05:26:40 --> Language Class Initialized
INFO - 2021-07-28 05:26:40 --> Language Class Initialized
INFO - 2021-07-28 05:26:40 --> Config Class Initialized
INFO - 2021-07-28 05:26:40 --> Loader Class Initialized
INFO - 2021-07-28 05:26:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:40 --> Controller Class Initialized
INFO - 2021-07-28 05:26:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:40 --> Total execution time: 0.0839
INFO - 2021-07-28 05:26:44 --> Config Class Initialized
INFO - 2021-07-28 05:26:44 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:44 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:44 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:44 --> URI Class Initialized
INFO - 2021-07-28 05:26:44 --> Router Class Initialized
INFO - 2021-07-28 05:26:44 --> Output Class Initialized
INFO - 2021-07-28 05:26:44 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:44 --> Input Class Initialized
INFO - 2021-07-28 05:26:44 --> Language Class Initialized
INFO - 2021-07-28 05:26:44 --> Language Class Initialized
INFO - 2021-07-28 05:26:44 --> Config Class Initialized
INFO - 2021-07-28 05:26:44 --> Loader Class Initialized
INFO - 2021-07-28 05:26:44 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:44 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:44 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:44 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:44 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:44 --> Controller Class Initialized
INFO - 2021-07-28 05:26:45 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:45 --> Total execution time: 0.8107
INFO - 2021-07-28 05:26:45 --> Config Class Initialized
INFO - 2021-07-28 05:26:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:45 --> URI Class Initialized
INFO - 2021-07-28 05:26:45 --> Router Class Initialized
INFO - 2021-07-28 05:26:45 --> Output Class Initialized
INFO - 2021-07-28 05:26:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:45 --> Input Class Initialized
INFO - 2021-07-28 05:26:45 --> Language Class Initialized
INFO - 2021-07-28 05:26:45 --> Language Class Initialized
INFO - 2021-07-28 05:26:45 --> Config Class Initialized
INFO - 2021-07-28 05:26:45 --> Loader Class Initialized
INFO - 2021-07-28 05:26:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:46 --> Controller Class Initialized
INFO - 2021-07-28 05:26:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:46 --> Total execution time: 0.0598
INFO - 2021-07-28 05:26:49 --> Config Class Initialized
INFO - 2021-07-28 05:26:49 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:49 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:49 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:49 --> URI Class Initialized
INFO - 2021-07-28 05:26:49 --> Router Class Initialized
INFO - 2021-07-28 05:26:49 --> Output Class Initialized
INFO - 2021-07-28 05:26:49 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:49 --> Input Class Initialized
INFO - 2021-07-28 05:26:49 --> Language Class Initialized
INFO - 2021-07-28 05:26:49 --> Language Class Initialized
INFO - 2021-07-28 05:26:49 --> Config Class Initialized
INFO - 2021-07-28 05:26:49 --> Loader Class Initialized
INFO - 2021-07-28 05:26:49 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:49 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:49 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:49 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:49 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:49 --> Controller Class Initialized
INFO - 2021-07-28 05:26:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:50 --> Total execution time: 0.8060
INFO - 2021-07-28 05:26:51 --> Config Class Initialized
INFO - 2021-07-28 05:26:51 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:51 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:51 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:51 --> URI Class Initialized
INFO - 2021-07-28 05:26:51 --> Router Class Initialized
INFO - 2021-07-28 05:26:51 --> Output Class Initialized
INFO - 2021-07-28 05:26:51 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:51 --> Input Class Initialized
INFO - 2021-07-28 05:26:51 --> Language Class Initialized
INFO - 2021-07-28 05:26:51 --> Language Class Initialized
INFO - 2021-07-28 05:26:51 --> Config Class Initialized
INFO - 2021-07-28 05:26:51 --> Loader Class Initialized
INFO - 2021-07-28 05:26:51 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:51 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:51 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:51 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:51 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:51 --> Controller Class Initialized
INFO - 2021-07-28 05:26:51 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:51 --> Total execution time: 0.0590
INFO - 2021-07-28 05:26:55 --> Config Class Initialized
INFO - 2021-07-28 05:26:55 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:55 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:55 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:55 --> URI Class Initialized
INFO - 2021-07-28 05:26:55 --> Router Class Initialized
INFO - 2021-07-28 05:26:55 --> Output Class Initialized
INFO - 2021-07-28 05:26:55 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:55 --> Input Class Initialized
INFO - 2021-07-28 05:26:55 --> Language Class Initialized
INFO - 2021-07-28 05:26:55 --> Language Class Initialized
INFO - 2021-07-28 05:26:55 --> Config Class Initialized
INFO - 2021-07-28 05:26:55 --> Loader Class Initialized
INFO - 2021-07-28 05:26:55 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:55 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:55 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:55 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:55 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:55 --> Controller Class Initialized
INFO - 2021-07-28 05:26:56 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:56 --> Total execution time: 0.7718
INFO - 2021-07-28 05:26:57 --> Config Class Initialized
INFO - 2021-07-28 05:26:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:57 --> URI Class Initialized
INFO - 2021-07-28 05:26:57 --> Router Class Initialized
INFO - 2021-07-28 05:26:57 --> Output Class Initialized
INFO - 2021-07-28 05:26:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:57 --> Input Class Initialized
INFO - 2021-07-28 05:26:57 --> Language Class Initialized
INFO - 2021-07-28 05:26:57 --> Language Class Initialized
INFO - 2021-07-28 05:26:57 --> Config Class Initialized
INFO - 2021-07-28 05:26:57 --> Loader Class Initialized
INFO - 2021-07-28 05:26:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:57 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:57 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:57 --> Total execution time: 0.0459
INFO - 2021-07-28 05:26:58 --> Config Class Initialized
INFO - 2021-07-28 05:26:58 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:58 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:58 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:58 --> URI Class Initialized
INFO - 2021-07-28 05:26:58 --> Router Class Initialized
INFO - 2021-07-28 05:26:58 --> Output Class Initialized
INFO - 2021-07-28 05:26:58 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:58 --> Input Class Initialized
INFO - 2021-07-28 05:26:58 --> Language Class Initialized
INFO - 2021-07-28 05:26:58 --> Language Class Initialized
INFO - 2021-07-28 05:26:58 --> Config Class Initialized
INFO - 2021-07-28 05:26:58 --> Loader Class Initialized
INFO - 2021-07-28 05:26:58 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:58 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:58 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:58 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:58 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:58 --> Controller Class Initialized
DEBUG - 2021-07-28 05:26:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:26:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:26:58 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:58 --> Total execution time: 0.0650
INFO - 2021-07-28 05:26:58 --> Config Class Initialized
INFO - 2021-07-28 05:26:58 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:58 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:58 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:58 --> URI Class Initialized
INFO - 2021-07-28 05:26:58 --> Router Class Initialized
INFO - 2021-07-28 05:26:58 --> Output Class Initialized
INFO - 2021-07-28 05:26:58 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:58 --> Input Class Initialized
INFO - 2021-07-28 05:26:58 --> Language Class Initialized
INFO - 2021-07-28 05:26:58 --> Language Class Initialized
INFO - 2021-07-28 05:26:58 --> Config Class Initialized
INFO - 2021-07-28 05:26:58 --> Loader Class Initialized
INFO - 2021-07-28 05:26:58 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:58 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:58 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:58 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:58 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:58 --> Controller Class Initialized
INFO - 2021-07-28 05:26:59 --> Config Class Initialized
INFO - 2021-07-28 05:26:59 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:26:59 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:26:59 --> Utf8 Class Initialized
INFO - 2021-07-28 05:26:59 --> URI Class Initialized
INFO - 2021-07-28 05:26:59 --> Router Class Initialized
INFO - 2021-07-28 05:26:59 --> Output Class Initialized
INFO - 2021-07-28 05:26:59 --> Security Class Initialized
DEBUG - 2021-07-28 05:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:26:59 --> Input Class Initialized
INFO - 2021-07-28 05:26:59 --> Language Class Initialized
INFO - 2021-07-28 05:26:59 --> Language Class Initialized
INFO - 2021-07-28 05:26:59 --> Config Class Initialized
INFO - 2021-07-28 05:26:59 --> Loader Class Initialized
INFO - 2021-07-28 05:26:59 --> Helper loaded: url_helper
INFO - 2021-07-28 05:26:59 --> Helper loaded: file_helper
INFO - 2021-07-28 05:26:59 --> Helper loaded: form_helper
INFO - 2021-07-28 05:26:59 --> Helper loaded: my_helper
INFO - 2021-07-28 05:26:59 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:26:59 --> Controller Class Initialized
INFO - 2021-07-28 05:26:59 --> Final output sent to browser
DEBUG - 2021-07-28 05:26:59 --> Total execution time: 0.1137
INFO - 2021-07-28 05:27:02 --> Config Class Initialized
INFO - 2021-07-28 05:27:02 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:02 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:02 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:02 --> URI Class Initialized
INFO - 2021-07-28 05:27:02 --> Router Class Initialized
INFO - 2021-07-28 05:27:02 --> Output Class Initialized
INFO - 2021-07-28 05:27:02 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:02 --> Input Class Initialized
INFO - 2021-07-28 05:27:02 --> Language Class Initialized
INFO - 2021-07-28 05:27:02 --> Language Class Initialized
INFO - 2021-07-28 05:27:02 --> Config Class Initialized
INFO - 2021-07-28 05:27:02 --> Loader Class Initialized
INFO - 2021-07-28 05:27:02 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:02 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:02 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:02 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:02 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:02 --> Controller Class Initialized
INFO - 2021-07-28 05:27:02 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:02 --> Total execution time: 0.0570
INFO - 2021-07-28 05:27:04 --> Config Class Initialized
INFO - 2021-07-28 05:27:04 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:04 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:04 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:04 --> URI Class Initialized
INFO - 2021-07-28 05:27:04 --> Router Class Initialized
INFO - 2021-07-28 05:27:04 --> Output Class Initialized
INFO - 2021-07-28 05:27:04 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:04 --> Input Class Initialized
INFO - 2021-07-28 05:27:04 --> Language Class Initialized
INFO - 2021-07-28 05:27:04 --> Language Class Initialized
INFO - 2021-07-28 05:27:04 --> Config Class Initialized
INFO - 2021-07-28 05:27:04 --> Loader Class Initialized
INFO - 2021-07-28 05:27:04 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:04 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:04 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:04 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:04 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:04 --> Controller Class Initialized
INFO - 2021-07-28 05:27:04 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:04 --> Total execution time: 0.0697
INFO - 2021-07-28 05:27:06 --> Config Class Initialized
INFO - 2021-07-28 05:27:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:06 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:06 --> URI Class Initialized
INFO - 2021-07-28 05:27:06 --> Router Class Initialized
INFO - 2021-07-28 05:27:06 --> Output Class Initialized
INFO - 2021-07-28 05:27:06 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:06 --> Input Class Initialized
INFO - 2021-07-28 05:27:06 --> Language Class Initialized
INFO - 2021-07-28 05:27:06 --> Language Class Initialized
INFO - 2021-07-28 05:27:06 --> Config Class Initialized
INFO - 2021-07-28 05:27:06 --> Loader Class Initialized
INFO - 2021-07-28 05:27:06 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:06 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:06 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:06 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:06 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:06 --> Controller Class Initialized
INFO - 2021-07-28 05:27:06 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:06 --> Total execution time: 0.0722
INFO - 2021-07-28 05:27:07 --> Config Class Initialized
INFO - 2021-07-28 05:27:07 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:07 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:07 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:07 --> URI Class Initialized
INFO - 2021-07-28 05:27:07 --> Router Class Initialized
INFO - 2021-07-28 05:27:07 --> Output Class Initialized
INFO - 2021-07-28 05:27:07 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:07 --> Input Class Initialized
INFO - 2021-07-28 05:27:07 --> Language Class Initialized
INFO - 2021-07-28 05:27:07 --> Language Class Initialized
INFO - 2021-07-28 05:27:07 --> Config Class Initialized
INFO - 2021-07-28 05:27:07 --> Loader Class Initialized
INFO - 2021-07-28 05:27:07 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:07 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:07 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:07 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:07 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:07 --> Controller Class Initialized
INFO - 2021-07-28 05:27:07 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:07 --> Total execution time: 0.0532
INFO - 2021-07-28 05:27:10 --> Config Class Initialized
INFO - 2021-07-28 05:27:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:10 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:10 --> URI Class Initialized
INFO - 2021-07-28 05:27:10 --> Router Class Initialized
INFO - 2021-07-28 05:27:10 --> Output Class Initialized
INFO - 2021-07-28 05:27:10 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:10 --> Input Class Initialized
INFO - 2021-07-28 05:27:10 --> Language Class Initialized
INFO - 2021-07-28 05:27:10 --> Language Class Initialized
INFO - 2021-07-28 05:27:10 --> Config Class Initialized
INFO - 2021-07-28 05:27:10 --> Loader Class Initialized
INFO - 2021-07-28 05:27:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:10 --> Controller Class Initialized
DEBUG - 2021-07-28 05:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:27:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:10 --> Total execution time: 0.0445
INFO - 2021-07-28 05:27:13 --> Config Class Initialized
INFO - 2021-07-28 05:27:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:13 --> URI Class Initialized
INFO - 2021-07-28 05:27:13 --> Router Class Initialized
INFO - 2021-07-28 05:27:13 --> Output Class Initialized
INFO - 2021-07-28 05:27:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:13 --> Input Class Initialized
INFO - 2021-07-28 05:27:13 --> Language Class Initialized
INFO - 2021-07-28 05:27:13 --> Language Class Initialized
INFO - 2021-07-28 05:27:13 --> Config Class Initialized
INFO - 2021-07-28 05:27:13 --> Loader Class Initialized
INFO - 2021-07-28 05:27:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:13 --> Controller Class Initialized
DEBUG - 2021-07-28 05:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:27:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:27:13 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:13 --> Total execution time: 0.0629
INFO - 2021-07-28 05:27:13 --> Config Class Initialized
INFO - 2021-07-28 05:27:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:13 --> URI Class Initialized
INFO - 2021-07-28 05:27:13 --> Router Class Initialized
INFO - 2021-07-28 05:27:13 --> Output Class Initialized
INFO - 2021-07-28 05:27:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:13 --> Input Class Initialized
INFO - 2021-07-28 05:27:13 --> Language Class Initialized
INFO - 2021-07-28 05:27:13 --> Language Class Initialized
INFO - 2021-07-28 05:27:13 --> Config Class Initialized
INFO - 2021-07-28 05:27:13 --> Loader Class Initialized
INFO - 2021-07-28 05:27:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:13 --> Controller Class Initialized
INFO - 2021-07-28 05:27:14 --> Config Class Initialized
INFO - 2021-07-28 05:27:14 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:14 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:14 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:14 --> URI Class Initialized
INFO - 2021-07-28 05:27:14 --> Router Class Initialized
INFO - 2021-07-28 05:27:14 --> Output Class Initialized
INFO - 2021-07-28 05:27:14 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:14 --> Input Class Initialized
INFO - 2021-07-28 05:27:14 --> Language Class Initialized
INFO - 2021-07-28 05:27:14 --> Language Class Initialized
INFO - 2021-07-28 05:27:14 --> Config Class Initialized
INFO - 2021-07-28 05:27:14 --> Loader Class Initialized
INFO - 2021-07-28 05:27:14 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:14 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:14 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:14 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:14 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:14 --> Controller Class Initialized
INFO - 2021-07-28 05:27:14 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:14 --> Total execution time: 0.0615
INFO - 2021-07-28 05:27:19 --> Config Class Initialized
INFO - 2021-07-28 05:27:19 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:19 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:19 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:19 --> URI Class Initialized
INFO - 2021-07-28 05:27:19 --> Router Class Initialized
INFO - 2021-07-28 05:27:19 --> Output Class Initialized
INFO - 2021-07-28 05:27:19 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:19 --> Input Class Initialized
INFO - 2021-07-28 05:27:19 --> Language Class Initialized
INFO - 2021-07-28 05:27:19 --> Language Class Initialized
INFO - 2021-07-28 05:27:19 --> Config Class Initialized
INFO - 2021-07-28 05:27:19 --> Loader Class Initialized
INFO - 2021-07-28 05:27:19 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:19 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:19 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:19 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:19 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:19 --> Controller Class Initialized
INFO - 2021-07-28 05:27:19 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:19 --> Total execution time: 0.0714
INFO - 2021-07-28 05:27:20 --> Config Class Initialized
INFO - 2021-07-28 05:27:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:20 --> URI Class Initialized
INFO - 2021-07-28 05:27:20 --> Router Class Initialized
INFO - 2021-07-28 05:27:20 --> Output Class Initialized
INFO - 2021-07-28 05:27:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:20 --> Input Class Initialized
INFO - 2021-07-28 05:27:20 --> Language Class Initialized
INFO - 2021-07-28 05:27:20 --> Language Class Initialized
INFO - 2021-07-28 05:27:20 --> Config Class Initialized
INFO - 2021-07-28 05:27:20 --> Loader Class Initialized
INFO - 2021-07-28 05:27:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:20 --> Controller Class Initialized
INFO - 2021-07-28 05:27:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:20 --> Total execution time: 0.0690
INFO - 2021-07-28 05:27:21 --> Config Class Initialized
INFO - 2021-07-28 05:27:21 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:21 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:21 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:21 --> URI Class Initialized
INFO - 2021-07-28 05:27:21 --> Router Class Initialized
INFO - 2021-07-28 05:27:21 --> Output Class Initialized
INFO - 2021-07-28 05:27:21 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:21 --> Input Class Initialized
INFO - 2021-07-28 05:27:21 --> Language Class Initialized
INFO - 2021-07-28 05:27:21 --> Language Class Initialized
INFO - 2021-07-28 05:27:21 --> Config Class Initialized
INFO - 2021-07-28 05:27:21 --> Loader Class Initialized
INFO - 2021-07-28 05:27:21 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:21 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:21 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:21 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:21 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:21 --> Controller Class Initialized
INFO - 2021-07-28 05:27:21 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:21 --> Total execution time: 0.0646
INFO - 2021-07-28 05:27:22 --> Config Class Initialized
INFO - 2021-07-28 05:27:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:22 --> URI Class Initialized
INFO - 2021-07-28 05:27:22 --> Router Class Initialized
INFO - 2021-07-28 05:27:22 --> Output Class Initialized
INFO - 2021-07-28 05:27:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:22 --> Input Class Initialized
INFO - 2021-07-28 05:27:22 --> Language Class Initialized
INFO - 2021-07-28 05:27:22 --> Language Class Initialized
INFO - 2021-07-28 05:27:22 --> Config Class Initialized
INFO - 2021-07-28 05:27:22 --> Loader Class Initialized
INFO - 2021-07-28 05:27:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:22 --> Controller Class Initialized
INFO - 2021-07-28 05:27:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:22 --> Total execution time: 0.0523
INFO - 2021-07-28 05:27:24 --> Config Class Initialized
INFO - 2021-07-28 05:27:24 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:24 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:24 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:24 --> URI Class Initialized
INFO - 2021-07-28 05:27:24 --> Router Class Initialized
INFO - 2021-07-28 05:27:24 --> Output Class Initialized
INFO - 2021-07-28 05:27:24 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:24 --> Input Class Initialized
INFO - 2021-07-28 05:27:24 --> Language Class Initialized
INFO - 2021-07-28 05:27:24 --> Language Class Initialized
INFO - 2021-07-28 05:27:24 --> Config Class Initialized
INFO - 2021-07-28 05:27:24 --> Loader Class Initialized
INFO - 2021-07-28 05:27:24 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:24 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:24 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:24 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:24 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:24 --> Controller Class Initialized
DEBUG - 2021-07-28 05:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:27:24 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:24 --> Total execution time: 0.0603
INFO - 2021-07-28 05:27:26 --> Config Class Initialized
INFO - 2021-07-28 05:27:26 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:26 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:26 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:26 --> URI Class Initialized
INFO - 2021-07-28 05:27:26 --> Router Class Initialized
INFO - 2021-07-28 05:27:26 --> Output Class Initialized
INFO - 2021-07-28 05:27:26 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:26 --> Input Class Initialized
INFO - 2021-07-28 05:27:26 --> Language Class Initialized
INFO - 2021-07-28 05:27:26 --> Language Class Initialized
INFO - 2021-07-28 05:27:26 --> Config Class Initialized
INFO - 2021-07-28 05:27:26 --> Loader Class Initialized
INFO - 2021-07-28 05:27:26 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:26 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:26 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:26 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:26 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:26 --> Controller Class Initialized
DEBUG - 2021-07-28 05:27:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:27:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:27:26 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:26 --> Total execution time: 0.0646
INFO - 2021-07-28 05:27:27 --> Config Class Initialized
INFO - 2021-07-28 05:27:27 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:27 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:27 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:27 --> URI Class Initialized
INFO - 2021-07-28 05:27:27 --> Router Class Initialized
INFO - 2021-07-28 05:27:27 --> Output Class Initialized
INFO - 2021-07-28 05:27:27 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:27 --> Input Class Initialized
INFO - 2021-07-28 05:27:27 --> Language Class Initialized
INFO - 2021-07-28 05:27:27 --> Language Class Initialized
INFO - 2021-07-28 05:27:27 --> Config Class Initialized
INFO - 2021-07-28 05:27:27 --> Loader Class Initialized
INFO - 2021-07-28 05:27:27 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:27 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:27 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:27 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:27 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:27 --> Controller Class Initialized
INFO - 2021-07-28 05:27:27 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:27 --> Total execution time: 0.0864
INFO - 2021-07-28 05:27:30 --> Config Class Initialized
INFO - 2021-07-28 05:27:30 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:30 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:30 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:30 --> URI Class Initialized
INFO - 2021-07-28 05:27:30 --> Router Class Initialized
INFO - 2021-07-28 05:27:30 --> Output Class Initialized
INFO - 2021-07-28 05:27:30 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:30 --> Input Class Initialized
INFO - 2021-07-28 05:27:30 --> Language Class Initialized
INFO - 2021-07-28 05:27:30 --> Language Class Initialized
INFO - 2021-07-28 05:27:30 --> Config Class Initialized
INFO - 2021-07-28 05:27:30 --> Loader Class Initialized
INFO - 2021-07-28 05:27:30 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:30 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:30 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:30 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:30 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:30 --> Controller Class Initialized
INFO - 2021-07-28 05:27:30 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:30 --> Total execution time: 0.0526
INFO - 2021-07-28 05:27:32 --> Config Class Initialized
INFO - 2021-07-28 05:27:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:32 --> URI Class Initialized
INFO - 2021-07-28 05:27:32 --> Router Class Initialized
INFO - 2021-07-28 05:27:32 --> Output Class Initialized
INFO - 2021-07-28 05:27:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:32 --> Input Class Initialized
INFO - 2021-07-28 05:27:32 --> Language Class Initialized
INFO - 2021-07-28 05:27:32 --> Language Class Initialized
INFO - 2021-07-28 05:27:32 --> Config Class Initialized
INFO - 2021-07-28 05:27:32 --> Loader Class Initialized
INFO - 2021-07-28 05:27:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:32 --> Controller Class Initialized
INFO - 2021-07-28 05:27:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:32 --> Total execution time: 0.0456
INFO - 2021-07-28 05:27:34 --> Config Class Initialized
INFO - 2021-07-28 05:27:34 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:34 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:34 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:34 --> URI Class Initialized
INFO - 2021-07-28 05:27:34 --> Router Class Initialized
INFO - 2021-07-28 05:27:34 --> Output Class Initialized
INFO - 2021-07-28 05:27:34 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:34 --> Input Class Initialized
INFO - 2021-07-28 05:27:34 --> Language Class Initialized
INFO - 2021-07-28 05:27:34 --> Language Class Initialized
INFO - 2021-07-28 05:27:34 --> Config Class Initialized
INFO - 2021-07-28 05:27:34 --> Loader Class Initialized
INFO - 2021-07-28 05:27:34 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:34 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:34 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:34 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:34 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:34 --> Controller Class Initialized
DEBUG - 2021-07-28 05:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:27:34 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:34 --> Total execution time: 0.0621
INFO - 2021-07-28 05:27:39 --> Config Class Initialized
INFO - 2021-07-28 05:27:39 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:27:39 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:27:39 --> Utf8 Class Initialized
INFO - 2021-07-28 05:27:39 --> URI Class Initialized
INFO - 2021-07-28 05:27:40 --> Router Class Initialized
INFO - 2021-07-28 05:27:40 --> Output Class Initialized
INFO - 2021-07-28 05:27:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:27:40 --> Input Class Initialized
INFO - 2021-07-28 05:27:40 --> Language Class Initialized
INFO - 2021-07-28 05:27:40 --> Language Class Initialized
INFO - 2021-07-28 05:27:40 --> Config Class Initialized
INFO - 2021-07-28 05:27:40 --> Loader Class Initialized
INFO - 2021-07-28 05:27:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:27:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:27:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:27:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:27:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:27:40 --> Controller Class Initialized
DEBUG - 2021-07-28 05:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-28 05:27:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:27:40 --> Total execution time: 0.1541
INFO - 2021-07-28 05:28:00 --> Config Class Initialized
INFO - 2021-07-28 05:28:00 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:00 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:00 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:00 --> URI Class Initialized
INFO - 2021-07-28 05:28:00 --> Router Class Initialized
INFO - 2021-07-28 05:28:00 --> Output Class Initialized
INFO - 2021-07-28 05:28:00 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:00 --> Input Class Initialized
INFO - 2021-07-28 05:28:00 --> Language Class Initialized
INFO - 2021-07-28 05:28:00 --> Language Class Initialized
INFO - 2021-07-28 05:28:00 --> Config Class Initialized
INFO - 2021-07-28 05:28:00 --> Loader Class Initialized
INFO - 2021-07-28 05:28:00 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:00 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:00 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:00 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:00 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:00 --> Controller Class Initialized
DEBUG - 2021-07-28 05:28:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-28 05:28:00 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:00 --> Total execution time: 0.1405
INFO - 2021-07-28 05:28:06 --> Config Class Initialized
INFO - 2021-07-28 05:28:06 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:06 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:06 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:06 --> URI Class Initialized
INFO - 2021-07-28 05:28:06 --> Router Class Initialized
INFO - 2021-07-28 05:28:06 --> Output Class Initialized
INFO - 2021-07-28 05:28:06 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:06 --> Input Class Initialized
INFO - 2021-07-28 05:28:06 --> Language Class Initialized
INFO - 2021-07-28 05:28:06 --> Language Class Initialized
INFO - 2021-07-28 05:28:06 --> Config Class Initialized
INFO - 2021-07-28 05:28:06 --> Loader Class Initialized
INFO - 2021-07-28 05:28:06 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:06 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:06 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:06 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:06 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:06 --> Controller Class Initialized
DEBUG - 2021-07-28 05:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:28:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:28:06 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:06 --> Total execution time: 0.0612
INFO - 2021-07-28 05:28:08 --> Config Class Initialized
INFO - 2021-07-28 05:28:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:08 --> URI Class Initialized
INFO - 2021-07-28 05:28:08 --> Router Class Initialized
INFO - 2021-07-28 05:28:08 --> Output Class Initialized
INFO - 2021-07-28 05:28:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:08 --> Input Class Initialized
INFO - 2021-07-28 05:28:08 --> Language Class Initialized
INFO - 2021-07-28 05:28:08 --> Language Class Initialized
INFO - 2021-07-28 05:28:08 --> Config Class Initialized
INFO - 2021-07-28 05:28:08 --> Loader Class Initialized
INFO - 2021-07-28 05:28:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:08 --> Controller Class Initialized
INFO - 2021-07-28 05:28:08 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:28:08 --> Config Class Initialized
INFO - 2021-07-28 05:28:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:08 --> URI Class Initialized
INFO - 2021-07-28 05:28:08 --> Router Class Initialized
INFO - 2021-07-28 05:28:08 --> Output Class Initialized
INFO - 2021-07-28 05:28:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:08 --> Input Class Initialized
INFO - 2021-07-28 05:28:08 --> Language Class Initialized
INFO - 2021-07-28 05:28:08 --> Language Class Initialized
INFO - 2021-07-28 05:28:08 --> Config Class Initialized
INFO - 2021-07-28 05:28:08 --> Loader Class Initialized
INFO - 2021-07-28 05:28:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:08 --> Controller Class Initialized
DEBUG - 2021-07-28 05:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:28:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:28:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:08 --> Total execution time: 0.0411
INFO - 2021-07-28 05:28:15 --> Config Class Initialized
INFO - 2021-07-28 05:28:15 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:15 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:15 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:15 --> URI Class Initialized
INFO - 2021-07-28 05:28:15 --> Router Class Initialized
INFO - 2021-07-28 05:28:15 --> Output Class Initialized
INFO - 2021-07-28 05:28:15 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:15 --> Input Class Initialized
INFO - 2021-07-28 05:28:15 --> Language Class Initialized
INFO - 2021-07-28 05:28:15 --> Language Class Initialized
INFO - 2021-07-28 05:28:15 --> Config Class Initialized
INFO - 2021-07-28 05:28:15 --> Loader Class Initialized
INFO - 2021-07-28 05:28:15 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:15 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:15 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:15 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:15 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:15 --> Controller Class Initialized
INFO - 2021-07-28 05:28:15 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:28:15 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:15 --> Total execution time: 0.0606
INFO - 2021-07-28 05:28:17 --> Config Class Initialized
INFO - 2021-07-28 05:28:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:17 --> URI Class Initialized
INFO - 2021-07-28 05:28:17 --> Router Class Initialized
INFO - 2021-07-28 05:28:17 --> Output Class Initialized
INFO - 2021-07-28 05:28:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:17 --> Input Class Initialized
INFO - 2021-07-28 05:28:17 --> Language Class Initialized
INFO - 2021-07-28 05:28:17 --> Language Class Initialized
INFO - 2021-07-28 05:28:17 --> Config Class Initialized
INFO - 2021-07-28 05:28:17 --> Loader Class Initialized
INFO - 2021-07-28 05:28:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:17 --> Controller Class Initialized
DEBUG - 2021-07-28 05:28:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:28:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:28:17 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:17 --> Total execution time: 0.7104
INFO - 2021-07-28 05:28:20 --> Config Class Initialized
INFO - 2021-07-28 05:28:20 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:20 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:20 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:20 --> URI Class Initialized
INFO - 2021-07-28 05:28:20 --> Router Class Initialized
INFO - 2021-07-28 05:28:20 --> Output Class Initialized
INFO - 2021-07-28 05:28:20 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:20 --> Input Class Initialized
INFO - 2021-07-28 05:28:20 --> Language Class Initialized
INFO - 2021-07-28 05:28:20 --> Language Class Initialized
INFO - 2021-07-28 05:28:20 --> Config Class Initialized
INFO - 2021-07-28 05:28:20 --> Loader Class Initialized
INFO - 2021-07-28 05:28:20 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:20 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:20 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:20 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:20 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:20 --> Controller Class Initialized
DEBUG - 2021-07-28 05:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:28:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:28:20 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:20 --> Total execution time: 0.0444
INFO - 2021-07-28 05:28:23 --> Config Class Initialized
INFO - 2021-07-28 05:28:23 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:23 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:23 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:23 --> URI Class Initialized
INFO - 2021-07-28 05:28:23 --> Router Class Initialized
INFO - 2021-07-28 05:28:23 --> Output Class Initialized
INFO - 2021-07-28 05:28:23 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:23 --> Input Class Initialized
INFO - 2021-07-28 05:28:23 --> Language Class Initialized
INFO - 2021-07-28 05:28:23 --> Language Class Initialized
INFO - 2021-07-28 05:28:23 --> Config Class Initialized
INFO - 2021-07-28 05:28:23 --> Loader Class Initialized
INFO - 2021-07-28 05:28:23 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:23 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:23 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:23 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:23 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:23 --> Controller Class Initialized
DEBUG - 2021-07-28 05:28:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-07-28 05:28:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:28:23 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:23 --> Total execution time: 0.0638
INFO - 2021-07-28 05:28:23 --> Config Class Initialized
INFO - 2021-07-28 05:28:23 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:23 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:23 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:23 --> URI Class Initialized
INFO - 2021-07-28 05:28:23 --> Router Class Initialized
INFO - 2021-07-28 05:28:23 --> Output Class Initialized
INFO - 2021-07-28 05:28:23 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:23 --> Input Class Initialized
INFO - 2021-07-28 05:28:23 --> Language Class Initialized
INFO - 2021-07-28 05:28:23 --> Language Class Initialized
INFO - 2021-07-28 05:28:23 --> Config Class Initialized
INFO - 2021-07-28 05:28:23 --> Loader Class Initialized
INFO - 2021-07-28 05:28:23 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:23 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:23 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:23 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:23 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:23 --> Controller Class Initialized
INFO - 2021-07-28 05:28:25 --> Config Class Initialized
INFO - 2021-07-28 05:28:25 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:25 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:25 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:25 --> URI Class Initialized
INFO - 2021-07-28 05:28:25 --> Router Class Initialized
INFO - 2021-07-28 05:28:25 --> Output Class Initialized
INFO - 2021-07-28 05:28:25 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:25 --> Input Class Initialized
INFO - 2021-07-28 05:28:25 --> Language Class Initialized
INFO - 2021-07-28 05:28:25 --> Language Class Initialized
INFO - 2021-07-28 05:28:25 --> Config Class Initialized
INFO - 2021-07-28 05:28:25 --> Loader Class Initialized
INFO - 2021-07-28 05:28:25 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:25 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:25 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:25 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:25 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:25 --> Controller Class Initialized
INFO - 2021-07-28 05:28:25 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:25 --> Total execution time: 0.0947
INFO - 2021-07-28 05:28:32 --> Config Class Initialized
INFO - 2021-07-28 05:28:32 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:32 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:32 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:32 --> URI Class Initialized
INFO - 2021-07-28 05:28:32 --> Router Class Initialized
INFO - 2021-07-28 05:28:32 --> Output Class Initialized
INFO - 2021-07-28 05:28:32 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:32 --> Input Class Initialized
INFO - 2021-07-28 05:28:32 --> Language Class Initialized
INFO - 2021-07-28 05:28:32 --> Language Class Initialized
INFO - 2021-07-28 05:28:32 --> Config Class Initialized
INFO - 2021-07-28 05:28:32 --> Loader Class Initialized
INFO - 2021-07-28 05:28:32 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:32 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:32 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:32 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:32 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:32 --> Controller Class Initialized
INFO - 2021-07-28 05:28:32 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:32 --> Total execution time: 0.0573
INFO - 2021-07-28 05:28:40 --> Config Class Initialized
INFO - 2021-07-28 05:28:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:40 --> URI Class Initialized
INFO - 2021-07-28 05:28:40 --> Router Class Initialized
INFO - 2021-07-28 05:28:40 --> Output Class Initialized
INFO - 2021-07-28 05:28:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:40 --> Input Class Initialized
INFO - 2021-07-28 05:28:40 --> Language Class Initialized
INFO - 2021-07-28 05:28:40 --> Language Class Initialized
INFO - 2021-07-28 05:28:40 --> Config Class Initialized
INFO - 2021-07-28 05:28:40 --> Loader Class Initialized
INFO - 2021-07-28 05:28:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:40 --> Controller Class Initialized
INFO - 2021-07-28 05:28:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:40 --> Total execution time: 0.0613
INFO - 2021-07-28 05:28:43 --> Config Class Initialized
INFO - 2021-07-28 05:28:43 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:43 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:43 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:43 --> URI Class Initialized
INFO - 2021-07-28 05:28:43 --> Router Class Initialized
INFO - 2021-07-28 05:28:43 --> Output Class Initialized
INFO - 2021-07-28 05:28:43 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:43 --> Input Class Initialized
INFO - 2021-07-28 05:28:43 --> Language Class Initialized
INFO - 2021-07-28 05:28:43 --> Language Class Initialized
INFO - 2021-07-28 05:28:43 --> Config Class Initialized
INFO - 2021-07-28 05:28:43 --> Loader Class Initialized
INFO - 2021-07-28 05:28:43 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:43 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:43 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:43 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:43 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:43 --> Controller Class Initialized
INFO - 2021-07-28 05:28:43 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:43 --> Total execution time: 0.0601
INFO - 2021-07-28 05:28:46 --> Config Class Initialized
INFO - 2021-07-28 05:28:46 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:46 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:46 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:46 --> URI Class Initialized
INFO - 2021-07-28 05:28:46 --> Router Class Initialized
INFO - 2021-07-28 05:28:46 --> Output Class Initialized
INFO - 2021-07-28 05:28:46 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:46 --> Input Class Initialized
INFO - 2021-07-28 05:28:46 --> Language Class Initialized
INFO - 2021-07-28 05:28:46 --> Language Class Initialized
INFO - 2021-07-28 05:28:46 --> Config Class Initialized
INFO - 2021-07-28 05:28:46 --> Loader Class Initialized
INFO - 2021-07-28 05:28:46 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:46 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:46 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:46 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:46 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:46 --> Controller Class Initialized
INFO - 2021-07-28 05:28:46 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:46 --> Total execution time: 0.0710
INFO - 2021-07-28 05:28:50 --> Config Class Initialized
INFO - 2021-07-28 05:28:50 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:28:50 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:28:50 --> Utf8 Class Initialized
INFO - 2021-07-28 05:28:50 --> URI Class Initialized
INFO - 2021-07-28 05:28:50 --> Router Class Initialized
INFO - 2021-07-28 05:28:50 --> Output Class Initialized
INFO - 2021-07-28 05:28:50 --> Security Class Initialized
DEBUG - 2021-07-28 05:28:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:28:50 --> Input Class Initialized
INFO - 2021-07-28 05:28:50 --> Language Class Initialized
INFO - 2021-07-28 05:28:50 --> Language Class Initialized
INFO - 2021-07-28 05:28:50 --> Config Class Initialized
INFO - 2021-07-28 05:28:50 --> Loader Class Initialized
INFO - 2021-07-28 05:28:50 --> Helper loaded: url_helper
INFO - 2021-07-28 05:28:50 --> Helper loaded: file_helper
INFO - 2021-07-28 05:28:50 --> Helper loaded: form_helper
INFO - 2021-07-28 05:28:50 --> Helper loaded: my_helper
INFO - 2021-07-28 05:28:50 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:28:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:28:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:28:50 --> Controller Class Initialized
INFO - 2021-07-28 05:28:50 --> Final output sent to browser
DEBUG - 2021-07-28 05:28:50 --> Total execution time: 0.0572
INFO - 2021-07-28 05:29:01 --> Config Class Initialized
INFO - 2021-07-28 05:29:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:01 --> URI Class Initialized
INFO - 2021-07-28 05:29:01 --> Router Class Initialized
INFO - 2021-07-28 05:29:01 --> Output Class Initialized
INFO - 2021-07-28 05:29:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:01 --> Input Class Initialized
INFO - 2021-07-28 05:29:01 --> Language Class Initialized
INFO - 2021-07-28 05:29:01 --> Language Class Initialized
INFO - 2021-07-28 05:29:01 --> Config Class Initialized
INFO - 2021-07-28 05:29:01 --> Loader Class Initialized
INFO - 2021-07-28 05:29:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:01 --> Controller Class Initialized
INFO - 2021-07-28 05:29:03 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:03 --> Total execution time: 2.1700
INFO - 2021-07-28 05:29:08 --> Config Class Initialized
INFO - 2021-07-28 05:29:08 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:08 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:08 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:08 --> URI Class Initialized
INFO - 2021-07-28 05:29:08 --> Router Class Initialized
INFO - 2021-07-28 05:29:08 --> Output Class Initialized
INFO - 2021-07-28 05:29:08 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:08 --> Input Class Initialized
INFO - 2021-07-28 05:29:08 --> Language Class Initialized
INFO - 2021-07-28 05:29:08 --> Language Class Initialized
INFO - 2021-07-28 05:29:08 --> Config Class Initialized
INFO - 2021-07-28 05:29:08 --> Loader Class Initialized
INFO - 2021-07-28 05:29:08 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:08 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:08 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:08 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:08 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:08 --> Controller Class Initialized
DEBUG - 2021-07-28 05:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-28 05:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:29:08 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:08 --> Total execution time: 0.0494
INFO - 2021-07-28 05:29:10 --> Config Class Initialized
INFO - 2021-07-28 05:29:10 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:10 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:10 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:10 --> URI Class Initialized
INFO - 2021-07-28 05:29:10 --> Router Class Initialized
INFO - 2021-07-28 05:29:10 --> Output Class Initialized
INFO - 2021-07-28 05:29:10 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:10 --> Input Class Initialized
INFO - 2021-07-28 05:29:10 --> Language Class Initialized
INFO - 2021-07-28 05:29:10 --> Language Class Initialized
INFO - 2021-07-28 05:29:10 --> Config Class Initialized
INFO - 2021-07-28 05:29:10 --> Loader Class Initialized
INFO - 2021-07-28 05:29:10 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:10 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:10 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:10 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:10 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:10 --> Controller Class Initialized
DEBUG - 2021-07-28 05:29:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-07-28 05:29:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:29:10 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:10 --> Total execution time: 0.0612
INFO - 2021-07-28 05:29:13 --> Config Class Initialized
INFO - 2021-07-28 05:29:13 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:13 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:13 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:13 --> URI Class Initialized
INFO - 2021-07-28 05:29:13 --> Router Class Initialized
INFO - 2021-07-28 05:29:13 --> Output Class Initialized
INFO - 2021-07-28 05:29:13 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:13 --> Input Class Initialized
INFO - 2021-07-28 05:29:13 --> Language Class Initialized
INFO - 2021-07-28 05:29:13 --> Language Class Initialized
INFO - 2021-07-28 05:29:13 --> Config Class Initialized
INFO - 2021-07-28 05:29:13 --> Loader Class Initialized
INFO - 2021-07-28 05:29:13 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:13 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:13 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:13 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:13 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:13 --> Controller Class Initialized
INFO - 2021-07-28 05:29:14 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:14 --> Total execution time: 0.0959
INFO - 2021-07-28 05:29:17 --> Config Class Initialized
INFO - 2021-07-28 05:29:17 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:17 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:17 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:17 --> URI Class Initialized
INFO - 2021-07-28 05:29:17 --> Router Class Initialized
INFO - 2021-07-28 05:29:17 --> Output Class Initialized
INFO - 2021-07-28 05:29:17 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:17 --> Input Class Initialized
INFO - 2021-07-28 05:29:17 --> Language Class Initialized
INFO - 2021-07-28 05:29:17 --> Language Class Initialized
INFO - 2021-07-28 05:29:17 --> Config Class Initialized
INFO - 2021-07-28 05:29:17 --> Loader Class Initialized
INFO - 2021-07-28 05:29:17 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:17 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:17 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:17 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:17 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:17 --> Controller Class Initialized
INFO - 2021-07-28 05:29:17 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:17 --> Total execution time: 0.0612
INFO - 2021-07-28 05:29:19 --> Config Class Initialized
INFO - 2021-07-28 05:29:19 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:19 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:19 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:19 --> URI Class Initialized
INFO - 2021-07-28 05:29:19 --> Router Class Initialized
INFO - 2021-07-28 05:29:19 --> Output Class Initialized
INFO - 2021-07-28 05:29:19 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:19 --> Input Class Initialized
INFO - 2021-07-28 05:29:19 --> Language Class Initialized
INFO - 2021-07-28 05:29:19 --> Language Class Initialized
INFO - 2021-07-28 05:29:19 --> Config Class Initialized
INFO - 2021-07-28 05:29:19 --> Loader Class Initialized
INFO - 2021-07-28 05:29:19 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:19 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:19 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:19 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:19 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:19 --> Controller Class Initialized
INFO - 2021-07-28 05:29:19 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:19 --> Total execution time: 0.0579
INFO - 2021-07-28 05:29:22 --> Config Class Initialized
INFO - 2021-07-28 05:29:22 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:22 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:22 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:22 --> URI Class Initialized
INFO - 2021-07-28 05:29:22 --> Router Class Initialized
INFO - 2021-07-28 05:29:22 --> Output Class Initialized
INFO - 2021-07-28 05:29:22 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:22 --> Input Class Initialized
INFO - 2021-07-28 05:29:22 --> Language Class Initialized
INFO - 2021-07-28 05:29:22 --> Language Class Initialized
INFO - 2021-07-28 05:29:22 --> Config Class Initialized
INFO - 2021-07-28 05:29:22 --> Loader Class Initialized
INFO - 2021-07-28 05:29:22 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:22 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:22 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:22 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:22 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:22 --> Controller Class Initialized
INFO - 2021-07-28 05:29:22 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:22 --> Total execution time: 0.0571
INFO - 2021-07-28 05:29:28 --> Config Class Initialized
INFO - 2021-07-28 05:29:28 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:28 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:28 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:28 --> URI Class Initialized
INFO - 2021-07-28 05:29:28 --> Router Class Initialized
INFO - 2021-07-28 05:29:28 --> Output Class Initialized
INFO - 2021-07-28 05:29:28 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:28 --> Input Class Initialized
INFO - 2021-07-28 05:29:28 --> Language Class Initialized
INFO - 2021-07-28 05:29:28 --> Language Class Initialized
INFO - 2021-07-28 05:29:28 --> Config Class Initialized
INFO - 2021-07-28 05:29:28 --> Loader Class Initialized
INFO - 2021-07-28 05:29:28 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:28 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:28 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:29 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:29 --> Controller Class Initialized
INFO - 2021-07-28 05:29:29 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:29:29 --> Config Class Initialized
INFO - 2021-07-28 05:29:29 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:29 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:29 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:29 --> URI Class Initialized
INFO - 2021-07-28 05:29:29 --> Router Class Initialized
INFO - 2021-07-28 05:29:29 --> Output Class Initialized
INFO - 2021-07-28 05:29:29 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:29 --> Input Class Initialized
INFO - 2021-07-28 05:29:29 --> Language Class Initialized
INFO - 2021-07-28 05:29:29 --> Language Class Initialized
INFO - 2021-07-28 05:29:29 --> Config Class Initialized
INFO - 2021-07-28 05:29:29 --> Loader Class Initialized
INFO - 2021-07-28 05:29:29 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:29 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:29 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:29 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:29 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:29 --> Controller Class Initialized
DEBUG - 2021-07-28 05:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-28 05:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:29:29 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:29 --> Total execution time: 0.0490
INFO - 2021-07-28 05:29:31 --> Config Class Initialized
INFO - 2021-07-28 05:29:31 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:29:31 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:29:31 --> Utf8 Class Initialized
INFO - 2021-07-28 05:29:31 --> URI Class Initialized
INFO - 2021-07-28 05:29:31 --> Router Class Initialized
INFO - 2021-07-28 05:29:31 --> Output Class Initialized
INFO - 2021-07-28 05:29:31 --> Security Class Initialized
DEBUG - 2021-07-28 05:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:29:31 --> Input Class Initialized
INFO - 2021-07-28 05:29:31 --> Language Class Initialized
INFO - 2021-07-28 05:29:31 --> Language Class Initialized
INFO - 2021-07-28 05:29:31 --> Config Class Initialized
INFO - 2021-07-28 05:29:31 --> Loader Class Initialized
INFO - 2021-07-28 05:29:31 --> Helper loaded: url_helper
INFO - 2021-07-28 05:29:31 --> Helper loaded: file_helper
INFO - 2021-07-28 05:29:31 --> Helper loaded: form_helper
INFO - 2021-07-28 05:29:31 --> Helper loaded: my_helper
INFO - 2021-07-28 05:29:31 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:29:31 --> Controller Class Initialized
DEBUG - 2021-07-28 05:29:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-28 05:29:31 --> Final output sent to browser
DEBUG - 2021-07-28 05:29:31 --> Total execution time: 0.1445
INFO - 2021-07-28 05:31:35 --> Config Class Initialized
INFO - 2021-07-28 05:31:35 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:35 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:35 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:35 --> URI Class Initialized
INFO - 2021-07-28 05:31:35 --> Router Class Initialized
INFO - 2021-07-28 05:31:35 --> Output Class Initialized
INFO - 2021-07-28 05:31:35 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:35 --> Input Class Initialized
INFO - 2021-07-28 05:31:35 --> Language Class Initialized
INFO - 2021-07-28 05:31:35 --> Language Class Initialized
INFO - 2021-07-28 05:31:35 --> Config Class Initialized
INFO - 2021-07-28 05:31:35 --> Loader Class Initialized
INFO - 2021-07-28 05:31:35 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:35 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:35 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:35 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:35 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:35 --> Controller Class Initialized
INFO - 2021-07-28 05:31:35 --> Helper loaded: cookie_helper
INFO - 2021-07-28 05:31:35 --> Final output sent to browser
DEBUG - 2021-07-28 05:31:35 --> Total execution time: 0.0683
INFO - 2021-07-28 05:31:37 --> Config Class Initialized
INFO - 2021-07-28 05:31:37 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:37 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:37 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:37 --> URI Class Initialized
INFO - 2021-07-28 05:31:37 --> Router Class Initialized
INFO - 2021-07-28 05:31:37 --> Output Class Initialized
INFO - 2021-07-28 05:31:37 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:37 --> Input Class Initialized
INFO - 2021-07-28 05:31:37 --> Language Class Initialized
INFO - 2021-07-28 05:31:37 --> Language Class Initialized
INFO - 2021-07-28 05:31:37 --> Config Class Initialized
INFO - 2021-07-28 05:31:37 --> Loader Class Initialized
INFO - 2021-07-28 05:31:37 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:37 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:37 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:37 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:37 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:37 --> Controller Class Initialized
DEBUG - 2021-07-28 05:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-28 05:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:31:38 --> Final output sent to browser
DEBUG - 2021-07-28 05:31:38 --> Total execution time: 0.7183
INFO - 2021-07-28 05:31:40 --> Config Class Initialized
INFO - 2021-07-28 05:31:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:40 --> URI Class Initialized
INFO - 2021-07-28 05:31:40 --> Router Class Initialized
INFO - 2021-07-28 05:31:40 --> Output Class Initialized
INFO - 2021-07-28 05:31:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:40 --> Input Class Initialized
INFO - 2021-07-28 05:31:40 --> Language Class Initialized
INFO - 2021-07-28 05:31:40 --> Language Class Initialized
INFO - 2021-07-28 05:31:40 --> Config Class Initialized
INFO - 2021-07-28 05:31:40 --> Loader Class Initialized
INFO - 2021-07-28 05:31:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:40 --> Controller Class Initialized
DEBUG - 2021-07-28 05:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-28 05:31:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:31:40 --> Final output sent to browser
DEBUG - 2021-07-28 05:31:40 --> Total execution time: 0.0839
INFO - 2021-07-28 05:31:40 --> Config Class Initialized
INFO - 2021-07-28 05:31:40 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:40 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:40 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:40 --> URI Class Initialized
INFO - 2021-07-28 05:31:40 --> Router Class Initialized
INFO - 2021-07-28 05:31:40 --> Output Class Initialized
INFO - 2021-07-28 05:31:40 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:40 --> Input Class Initialized
INFO - 2021-07-28 05:31:40 --> Language Class Initialized
INFO - 2021-07-28 05:31:40 --> Language Class Initialized
INFO - 2021-07-28 05:31:40 --> Config Class Initialized
INFO - 2021-07-28 05:31:40 --> Loader Class Initialized
INFO - 2021-07-28 05:31:40 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:40 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:40 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:40 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:40 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:40 --> Controller Class Initialized
INFO - 2021-07-28 05:31:44 --> Config Class Initialized
INFO - 2021-07-28 05:31:44 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:44 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:44 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:44 --> URI Class Initialized
INFO - 2021-07-28 05:31:44 --> Router Class Initialized
INFO - 2021-07-28 05:31:44 --> Output Class Initialized
INFO - 2021-07-28 05:31:44 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:44 --> Input Class Initialized
INFO - 2021-07-28 05:31:44 --> Language Class Initialized
INFO - 2021-07-28 05:31:44 --> Language Class Initialized
INFO - 2021-07-28 05:31:44 --> Config Class Initialized
INFO - 2021-07-28 05:31:44 --> Loader Class Initialized
INFO - 2021-07-28 05:31:44 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:44 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:44 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:44 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:44 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:44 --> Controller Class Initialized
INFO - 2021-07-28 05:31:44 --> Config Class Initialized
INFO - 2021-07-28 05:31:44 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:44 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:44 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:44 --> URI Class Initialized
INFO - 2021-07-28 05:31:44 --> Router Class Initialized
INFO - 2021-07-28 05:31:44 --> Output Class Initialized
INFO - 2021-07-28 05:31:44 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:44 --> Input Class Initialized
INFO - 2021-07-28 05:31:44 --> Language Class Initialized
INFO - 2021-07-28 05:31:44 --> Language Class Initialized
INFO - 2021-07-28 05:31:44 --> Config Class Initialized
INFO - 2021-07-28 05:31:44 --> Loader Class Initialized
INFO - 2021-07-28 05:31:44 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:44 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:44 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:44 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:44 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:44 --> Controller Class Initialized
INFO - 2021-07-28 05:31:45 --> Config Class Initialized
INFO - 2021-07-28 05:31:45 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:45 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:45 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:45 --> URI Class Initialized
INFO - 2021-07-28 05:31:45 --> Router Class Initialized
INFO - 2021-07-28 05:31:45 --> Output Class Initialized
INFO - 2021-07-28 05:31:45 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:45 --> Input Class Initialized
INFO - 2021-07-28 05:31:45 --> Language Class Initialized
INFO - 2021-07-28 05:31:45 --> Language Class Initialized
INFO - 2021-07-28 05:31:45 --> Config Class Initialized
INFO - 2021-07-28 05:31:45 --> Loader Class Initialized
INFO - 2021-07-28 05:31:45 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:45 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:45 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:45 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:45 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:45 --> Controller Class Initialized
INFO - 2021-07-28 05:31:47 --> Config Class Initialized
INFO - 2021-07-28 05:31:47 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:47 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:47 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:47 --> URI Class Initialized
INFO - 2021-07-28 05:31:47 --> Router Class Initialized
INFO - 2021-07-28 05:31:47 --> Output Class Initialized
INFO - 2021-07-28 05:31:47 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:47 --> Input Class Initialized
INFO - 2021-07-28 05:31:47 --> Language Class Initialized
INFO - 2021-07-28 05:31:47 --> Language Class Initialized
INFO - 2021-07-28 05:31:47 --> Config Class Initialized
INFO - 2021-07-28 05:31:47 --> Loader Class Initialized
INFO - 2021-07-28 05:31:47 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:47 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:47 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:47 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:47 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:47 --> Controller Class Initialized
ERROR - 2021-07-28 05:31:47 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-28 05:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-28 05:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:31:47 --> Final output sent to browser
DEBUG - 2021-07-28 05:31:47 --> Total execution time: 0.1121
INFO - 2021-07-28 05:31:57 --> Config Class Initialized
INFO - 2021-07-28 05:31:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:57 --> URI Class Initialized
INFO - 2021-07-28 05:31:57 --> Router Class Initialized
INFO - 2021-07-28 05:31:57 --> Output Class Initialized
INFO - 2021-07-28 05:31:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:57 --> Input Class Initialized
INFO - 2021-07-28 05:31:57 --> Language Class Initialized
INFO - 2021-07-28 05:31:57 --> Language Class Initialized
INFO - 2021-07-28 05:31:57 --> Config Class Initialized
INFO - 2021-07-28 05:31:57 --> Loader Class Initialized
INFO - 2021-07-28 05:31:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:57 --> Controller Class Initialized
INFO - 2021-07-28 05:31:57 --> Upload Class Initialized
INFO - 2021-07-28 05:31:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-28 05:31:57 --> The upload path does not appear to be valid.
INFO - 2021-07-28 05:31:57 --> Config Class Initialized
INFO - 2021-07-28 05:31:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:57 --> URI Class Initialized
INFO - 2021-07-28 05:31:57 --> Router Class Initialized
INFO - 2021-07-28 05:31:57 --> Output Class Initialized
INFO - 2021-07-28 05:31:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:57 --> Input Class Initialized
INFO - 2021-07-28 05:31:57 --> Language Class Initialized
INFO - 2021-07-28 05:31:57 --> Language Class Initialized
INFO - 2021-07-28 05:31:57 --> Config Class Initialized
INFO - 2021-07-28 05:31:57 --> Loader Class Initialized
INFO - 2021-07-28 05:31:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:57 --> Controller Class Initialized
DEBUG - 2021-07-28 05:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-28 05:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-28 05:31:57 --> Final output sent to browser
DEBUG - 2021-07-28 05:31:57 --> Total execution time: 0.0443
INFO - 2021-07-28 05:31:57 --> Config Class Initialized
INFO - 2021-07-28 05:31:57 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:31:57 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:31:57 --> Utf8 Class Initialized
INFO - 2021-07-28 05:31:57 --> URI Class Initialized
INFO - 2021-07-28 05:31:57 --> Router Class Initialized
INFO - 2021-07-28 05:31:57 --> Output Class Initialized
INFO - 2021-07-28 05:31:57 --> Security Class Initialized
DEBUG - 2021-07-28 05:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:31:57 --> Input Class Initialized
INFO - 2021-07-28 05:31:57 --> Language Class Initialized
INFO - 2021-07-28 05:31:57 --> Language Class Initialized
INFO - 2021-07-28 05:31:57 --> Config Class Initialized
INFO - 2021-07-28 05:31:57 --> Loader Class Initialized
INFO - 2021-07-28 05:31:57 --> Helper loaded: url_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: file_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: form_helper
INFO - 2021-07-28 05:31:57 --> Helper loaded: my_helper
INFO - 2021-07-28 05:31:57 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:31:57 --> Controller Class Initialized
INFO - 2021-07-28 05:32:01 --> Config Class Initialized
INFO - 2021-07-28 05:32:01 --> Hooks Class Initialized
DEBUG - 2021-07-28 05:32:01 --> UTF-8 Support Enabled
INFO - 2021-07-28 05:32:01 --> Utf8 Class Initialized
INFO - 2021-07-28 05:32:01 --> URI Class Initialized
INFO - 2021-07-28 05:32:01 --> Router Class Initialized
INFO - 2021-07-28 05:32:01 --> Output Class Initialized
INFO - 2021-07-28 05:32:01 --> Security Class Initialized
DEBUG - 2021-07-28 05:32:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-28 05:32:01 --> Input Class Initialized
INFO - 2021-07-28 05:32:01 --> Language Class Initialized
INFO - 2021-07-28 05:32:01 --> Language Class Initialized
INFO - 2021-07-28 05:32:01 --> Config Class Initialized
INFO - 2021-07-28 05:32:01 --> Loader Class Initialized
INFO - 2021-07-28 05:32:01 --> Helper loaded: url_helper
INFO - 2021-07-28 05:32:01 --> Helper loaded: file_helper
INFO - 2021-07-28 05:32:01 --> Helper loaded: form_helper
INFO - 2021-07-28 05:32:01 --> Helper loaded: my_helper
INFO - 2021-07-28 05:32:01 --> Database Driver Class Initialized
DEBUG - 2021-07-28 05:32:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-28 05:32:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-28 05:32:01 --> Controller Class Initialized
DEBUG - 2021-07-28 05:32:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-07-28 05:32:01 --> Final output sent to browser
DEBUG - 2021-07-28 05:32:01 --> Total execution time: 0.2047
