<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-09-13 10:03:25 --> Config Class Initialized
INFO - 2022-09-13 10:03:25 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:03:25 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:03:25 --> Utf8 Class Initialized
INFO - 2022-09-13 10:03:25 --> URI Class Initialized
DEBUG - 2022-09-13 10:03:25 --> No URI present. Default controller set.
INFO - 2022-09-13 10:03:25 --> Router Class Initialized
INFO - 2022-09-13 10:03:25 --> Output Class Initialized
INFO - 2022-09-13 10:03:25 --> Security Class Initialized
DEBUG - 2022-09-13 10:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:03:25 --> Input Class Initialized
INFO - 2022-09-13 10:03:25 --> Language Class Initialized
INFO - 2022-09-13 10:03:25 --> Language Class Initialized
INFO - 2022-09-13 10:03:25 --> Config Class Initialized
INFO - 2022-09-13 10:03:25 --> Loader Class Initialized
INFO - 2022-09-13 10:03:25 --> Helper loaded: url_helper
INFO - 2022-09-13 10:03:25 --> Helper loaded: file_helper
INFO - 2022-09-13 10:03:25 --> Helper loaded: form_helper
INFO - 2022-09-13 10:03:25 --> Helper loaded: my_helper
INFO - 2022-09-13 10:03:25 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:03:25 --> Controller Class Initialized
INFO - 2022-09-13 10:03:26 --> Config Class Initialized
INFO - 2022-09-13 10:03:26 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:03:26 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:03:26 --> Utf8 Class Initialized
INFO - 2022-09-13 10:03:26 --> URI Class Initialized
INFO - 2022-09-13 10:03:26 --> Router Class Initialized
INFO - 2022-09-13 10:03:26 --> Output Class Initialized
INFO - 2022-09-13 10:03:26 --> Security Class Initialized
DEBUG - 2022-09-13 10:03:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:03:26 --> Input Class Initialized
INFO - 2022-09-13 10:03:26 --> Language Class Initialized
INFO - 2022-09-13 10:03:26 --> Language Class Initialized
INFO - 2022-09-13 10:03:26 --> Config Class Initialized
INFO - 2022-09-13 10:03:26 --> Loader Class Initialized
INFO - 2022-09-13 10:03:26 --> Helper loaded: url_helper
INFO - 2022-09-13 10:03:26 --> Helper loaded: file_helper
INFO - 2022-09-13 10:03:26 --> Helper loaded: form_helper
INFO - 2022-09-13 10:03:26 --> Helper loaded: my_helper
INFO - 2022-09-13 10:03:26 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:03:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:03:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:03:26 --> Controller Class Initialized
DEBUG - 2022-09-13 10:03:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-13 10:03:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:03:26 --> Final output sent to browser
DEBUG - 2022-09-13 10:03:26 --> Total execution time: 0.1034
INFO - 2022-09-13 10:05:58 --> Config Class Initialized
INFO - 2022-09-13 10:05:58 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:05:58 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:05:58 --> Utf8 Class Initialized
INFO - 2022-09-13 10:05:58 --> URI Class Initialized
INFO - 2022-09-13 10:05:58 --> Router Class Initialized
INFO - 2022-09-13 10:05:58 --> Output Class Initialized
INFO - 2022-09-13 10:05:58 --> Security Class Initialized
DEBUG - 2022-09-13 10:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:05:58 --> Input Class Initialized
INFO - 2022-09-13 10:05:58 --> Language Class Initialized
INFO - 2022-09-13 10:05:58 --> Language Class Initialized
INFO - 2022-09-13 10:05:58 --> Config Class Initialized
INFO - 2022-09-13 10:05:58 --> Loader Class Initialized
INFO - 2022-09-13 10:05:58 --> Helper loaded: url_helper
INFO - 2022-09-13 10:05:58 --> Helper loaded: file_helper
INFO - 2022-09-13 10:05:58 --> Helper loaded: form_helper
INFO - 2022-09-13 10:05:58 --> Helper loaded: my_helper
INFO - 2022-09-13 10:05:58 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:05:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:05:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:05:58 --> Controller Class Initialized
INFO - 2022-09-13 10:05:58 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:05:58 --> Final output sent to browser
DEBUG - 2022-09-13 10:05:58 --> Total execution time: 0.0887
INFO - 2022-09-13 10:05:58 --> Config Class Initialized
INFO - 2022-09-13 10:05:58 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:05:58 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:05:58 --> Utf8 Class Initialized
INFO - 2022-09-13 10:05:58 --> URI Class Initialized
INFO - 2022-09-13 10:05:58 --> Router Class Initialized
INFO - 2022-09-13 10:05:58 --> Output Class Initialized
INFO - 2022-09-13 10:05:58 --> Security Class Initialized
DEBUG - 2022-09-13 10:05:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:05:58 --> Input Class Initialized
INFO - 2022-09-13 10:05:58 --> Language Class Initialized
INFO - 2022-09-13 10:05:59 --> Language Class Initialized
INFO - 2022-09-13 10:05:59 --> Config Class Initialized
INFO - 2022-09-13 10:05:59 --> Loader Class Initialized
INFO - 2022-09-13 10:05:59 --> Helper loaded: url_helper
INFO - 2022-09-13 10:05:59 --> Helper loaded: file_helper
INFO - 2022-09-13 10:05:59 --> Helper loaded: form_helper
INFO - 2022-09-13 10:05:59 --> Helper loaded: my_helper
INFO - 2022-09-13 10:05:59 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:05:59 --> Controller Class Initialized
DEBUG - 2022-09-13 10:05:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-09-13 10:05:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:05:59 --> Final output sent to browser
DEBUG - 2022-09-13 10:05:59 --> Total execution time: 0.6049
INFO - 2022-09-13 10:06:01 --> Config Class Initialized
INFO - 2022-09-13 10:06:01 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:01 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:01 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:01 --> URI Class Initialized
INFO - 2022-09-13 10:06:01 --> Router Class Initialized
INFO - 2022-09-13 10:06:01 --> Output Class Initialized
INFO - 2022-09-13 10:06:01 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:01 --> Input Class Initialized
INFO - 2022-09-13 10:06:01 --> Language Class Initialized
INFO - 2022-09-13 10:06:01 --> Language Class Initialized
INFO - 2022-09-13 10:06:01 --> Config Class Initialized
INFO - 2022-09-13 10:06:01 --> Loader Class Initialized
INFO - 2022-09-13 10:06:01 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:01 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:01 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:01 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:01 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:01 --> Controller Class Initialized
DEBUG - 2022-09-13 10:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-09-13 10:06:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:06:01 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:01 --> Total execution time: 0.0871
INFO - 2022-09-13 10:06:01 --> Config Class Initialized
INFO - 2022-09-13 10:06:01 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:01 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:01 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:01 --> URI Class Initialized
INFO - 2022-09-13 10:06:01 --> Router Class Initialized
INFO - 2022-09-13 10:06:01 --> Output Class Initialized
INFO - 2022-09-13 10:06:01 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:01 --> Input Class Initialized
INFO - 2022-09-13 10:06:01 --> Language Class Initialized
INFO - 2022-09-13 10:06:01 --> Language Class Initialized
INFO - 2022-09-13 10:06:01 --> Config Class Initialized
INFO - 2022-09-13 10:06:01 --> Loader Class Initialized
INFO - 2022-09-13 10:06:01 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:01 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:01 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:01 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:01 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:01 --> Controller Class Initialized
INFO - 2022-09-13 10:06:04 --> Config Class Initialized
INFO - 2022-09-13 10:06:04 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:04 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:04 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:04 --> URI Class Initialized
INFO - 2022-09-13 10:06:04 --> Router Class Initialized
INFO - 2022-09-13 10:06:04 --> Output Class Initialized
INFO - 2022-09-13 10:06:04 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:04 --> Input Class Initialized
INFO - 2022-09-13 10:06:04 --> Language Class Initialized
INFO - 2022-09-13 10:06:04 --> Language Class Initialized
INFO - 2022-09-13 10:06:04 --> Config Class Initialized
INFO - 2022-09-13 10:06:04 --> Loader Class Initialized
INFO - 2022-09-13 10:06:04 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:04 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:04 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:04 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:04 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:04 --> Controller Class Initialized
INFO - 2022-09-13 10:06:04 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:04 --> Total execution time: 0.0574
INFO - 2022-09-13 10:06:04 --> Config Class Initialized
INFO - 2022-09-13 10:06:04 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:04 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:04 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:05 --> URI Class Initialized
INFO - 2022-09-13 10:06:05 --> Router Class Initialized
INFO - 2022-09-13 10:06:05 --> Output Class Initialized
INFO - 2022-09-13 10:06:05 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:05 --> Input Class Initialized
INFO - 2022-09-13 10:06:05 --> Language Class Initialized
INFO - 2022-09-13 10:06:05 --> Language Class Initialized
INFO - 2022-09-13 10:06:05 --> Config Class Initialized
INFO - 2022-09-13 10:06:05 --> Loader Class Initialized
INFO - 2022-09-13 10:06:05 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:05 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:05 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:05 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:05 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:05 --> Controller Class Initialized
INFO - 2022-09-13 10:06:13 --> Config Class Initialized
INFO - 2022-09-13 10:06:13 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:13 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:13 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:13 --> URI Class Initialized
INFO - 2022-09-13 10:06:13 --> Router Class Initialized
INFO - 2022-09-13 10:06:13 --> Output Class Initialized
INFO - 2022-09-13 10:06:13 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:13 --> Input Class Initialized
INFO - 2022-09-13 10:06:13 --> Language Class Initialized
INFO - 2022-09-13 10:06:13 --> Language Class Initialized
INFO - 2022-09-13 10:06:13 --> Config Class Initialized
INFO - 2022-09-13 10:06:13 --> Loader Class Initialized
INFO - 2022-09-13 10:06:13 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:13 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:13 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:13 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:13 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:13 --> Controller Class Initialized
INFO - 2022-09-13 10:06:13 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:06:13 --> Config Class Initialized
INFO - 2022-09-13 10:06:13 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:13 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:13 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:13 --> URI Class Initialized
INFO - 2022-09-13 10:06:13 --> Router Class Initialized
INFO - 2022-09-13 10:06:13 --> Output Class Initialized
INFO - 2022-09-13 10:06:13 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:13 --> Input Class Initialized
INFO - 2022-09-13 10:06:13 --> Language Class Initialized
INFO - 2022-09-13 10:06:13 --> Language Class Initialized
INFO - 2022-09-13 10:06:13 --> Config Class Initialized
INFO - 2022-09-13 10:06:13 --> Loader Class Initialized
INFO - 2022-09-13 10:06:13 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:13 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:13 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:13 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:13 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:13 --> Controller Class Initialized
DEBUG - 2022-09-13 10:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-13 10:06:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:06:13 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:13 --> Total execution time: 0.0408
INFO - 2022-09-13 10:06:20 --> Config Class Initialized
INFO - 2022-09-13 10:06:20 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:20 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:20 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:20 --> URI Class Initialized
INFO - 2022-09-13 10:06:20 --> Router Class Initialized
INFO - 2022-09-13 10:06:20 --> Output Class Initialized
INFO - 2022-09-13 10:06:20 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:20 --> Input Class Initialized
INFO - 2022-09-13 10:06:20 --> Language Class Initialized
INFO - 2022-09-13 10:06:20 --> Language Class Initialized
INFO - 2022-09-13 10:06:20 --> Config Class Initialized
INFO - 2022-09-13 10:06:20 --> Loader Class Initialized
INFO - 2022-09-13 10:06:20 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:20 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:20 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:20 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:20 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:20 --> Controller Class Initialized
INFO - 2022-09-13 10:06:20 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:06:20 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:20 --> Total execution time: 0.0608
INFO - 2022-09-13 10:06:20 --> Config Class Initialized
INFO - 2022-09-13 10:06:20 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:20 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:20 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:20 --> URI Class Initialized
INFO - 2022-09-13 10:06:20 --> Router Class Initialized
INFO - 2022-09-13 10:06:20 --> Output Class Initialized
INFO - 2022-09-13 10:06:20 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:20 --> Input Class Initialized
INFO - 2022-09-13 10:06:20 --> Language Class Initialized
INFO - 2022-09-13 10:06:20 --> Language Class Initialized
INFO - 2022-09-13 10:06:20 --> Config Class Initialized
INFO - 2022-09-13 10:06:20 --> Loader Class Initialized
INFO - 2022-09-13 10:06:20 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:20 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:20 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:20 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:20 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:20 --> Controller Class Initialized
DEBUG - 2022-09-13 10:06:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-09-13 10:06:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:06:21 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:21 --> Total execution time: 0.5187
INFO - 2022-09-13 10:06:28 --> Config Class Initialized
INFO - 2022-09-13 10:06:28 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:28 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:28 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:28 --> URI Class Initialized
INFO - 2022-09-13 10:06:28 --> Router Class Initialized
INFO - 2022-09-13 10:06:28 --> Output Class Initialized
INFO - 2022-09-13 10:06:28 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:28 --> Input Class Initialized
INFO - 2022-09-13 10:06:28 --> Language Class Initialized
INFO - 2022-09-13 10:06:28 --> Language Class Initialized
INFO - 2022-09-13 10:06:28 --> Config Class Initialized
INFO - 2022-09-13 10:06:28 --> Loader Class Initialized
INFO - 2022-09-13 10:06:28 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:28 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:28 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:28 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:28 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:28 --> Controller Class Initialized
DEBUG - 2022-09-13 10:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-09-13 10:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:06:28 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:28 --> Total execution time: 0.1305
INFO - 2022-09-13 10:06:32 --> Config Class Initialized
INFO - 2022-09-13 10:06:32 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:32 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:32 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:32 --> URI Class Initialized
INFO - 2022-09-13 10:06:32 --> Router Class Initialized
INFO - 2022-09-13 10:06:32 --> Output Class Initialized
INFO - 2022-09-13 10:06:32 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:32 --> Input Class Initialized
INFO - 2022-09-13 10:06:32 --> Language Class Initialized
INFO - 2022-09-13 10:06:33 --> Language Class Initialized
INFO - 2022-09-13 10:06:33 --> Config Class Initialized
INFO - 2022-09-13 10:06:33 --> Loader Class Initialized
INFO - 2022-09-13 10:06:33 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:33 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:33 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:33 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:33 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:33 --> Controller Class Initialized
DEBUG - 2022-09-13 10:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-09-13 10:06:33 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:33 --> Total execution time: 0.3194
INFO - 2022-09-13 10:06:42 --> Config Class Initialized
INFO - 2022-09-13 10:06:42 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:06:42 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:06:42 --> Utf8 Class Initialized
INFO - 2022-09-13 10:06:42 --> URI Class Initialized
DEBUG - 2022-09-13 10:06:42 --> No URI present. Default controller set.
INFO - 2022-09-13 10:06:42 --> Router Class Initialized
INFO - 2022-09-13 10:06:42 --> Output Class Initialized
INFO - 2022-09-13 10:06:42 --> Security Class Initialized
DEBUG - 2022-09-13 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:06:42 --> Input Class Initialized
INFO - 2022-09-13 10:06:42 --> Language Class Initialized
INFO - 2022-09-13 10:06:42 --> Language Class Initialized
INFO - 2022-09-13 10:06:42 --> Config Class Initialized
INFO - 2022-09-13 10:06:42 --> Loader Class Initialized
INFO - 2022-09-13 10:06:42 --> Helper loaded: url_helper
INFO - 2022-09-13 10:06:42 --> Helper loaded: file_helper
INFO - 2022-09-13 10:06:42 --> Helper loaded: form_helper
INFO - 2022-09-13 10:06:42 --> Helper loaded: my_helper
INFO - 2022-09-13 10:06:42 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:06:42 --> Controller Class Initialized
DEBUG - 2022-09-13 10:06:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-09-13 10:06:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:06:43 --> Final output sent to browser
DEBUG - 2022-09-13 10:06:43 --> Total execution time: 0.5457
INFO - 2022-09-13 10:07:03 --> Config Class Initialized
INFO - 2022-09-13 10:07:03 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:07:03 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:07:03 --> Utf8 Class Initialized
INFO - 2022-09-13 10:07:03 --> URI Class Initialized
INFO - 2022-09-13 10:07:03 --> Router Class Initialized
INFO - 2022-09-13 10:07:03 --> Output Class Initialized
INFO - 2022-09-13 10:07:03 --> Security Class Initialized
DEBUG - 2022-09-13 10:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:07:03 --> Input Class Initialized
INFO - 2022-09-13 10:07:03 --> Language Class Initialized
INFO - 2022-09-13 10:07:03 --> Language Class Initialized
INFO - 2022-09-13 10:07:03 --> Config Class Initialized
INFO - 2022-09-13 10:07:03 --> Loader Class Initialized
INFO - 2022-09-13 10:07:03 --> Helper loaded: url_helper
INFO - 2022-09-13 10:07:03 --> Helper loaded: file_helper
INFO - 2022-09-13 10:07:03 --> Helper loaded: form_helper
INFO - 2022-09-13 10:07:03 --> Helper loaded: my_helper
INFO - 2022-09-13 10:07:03 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:07:03 --> Controller Class Initialized
DEBUG - 2022-09-13 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-09-13 10:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:07:03 --> Final output sent to browser
DEBUG - 2022-09-13 10:07:03 --> Total execution time: 0.0653
INFO - 2022-09-13 10:07:06 --> Config Class Initialized
INFO - 2022-09-13 10:07:06 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:07:06 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:07:06 --> Utf8 Class Initialized
INFO - 2022-09-13 10:07:06 --> URI Class Initialized
INFO - 2022-09-13 10:07:07 --> Router Class Initialized
INFO - 2022-09-13 10:07:07 --> Output Class Initialized
INFO - 2022-09-13 10:07:07 --> Security Class Initialized
DEBUG - 2022-09-13 10:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:07:07 --> Input Class Initialized
INFO - 2022-09-13 10:07:07 --> Language Class Initialized
INFO - 2022-09-13 10:07:07 --> Language Class Initialized
INFO - 2022-09-13 10:07:07 --> Config Class Initialized
INFO - 2022-09-13 10:07:07 --> Loader Class Initialized
INFO - 2022-09-13 10:07:07 --> Helper loaded: url_helper
INFO - 2022-09-13 10:07:07 --> Helper loaded: file_helper
INFO - 2022-09-13 10:07:07 --> Helper loaded: form_helper
INFO - 2022-09-13 10:07:07 --> Helper loaded: my_helper
INFO - 2022-09-13 10:07:07 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:07:07 --> Controller Class Initialized
DEBUG - 2022-09-13 10:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-09-13 10:07:07 --> Final output sent to browser
DEBUG - 2022-09-13 10:07:07 --> Total execution time: 0.2521
INFO - 2022-09-13 10:07:35 --> Config Class Initialized
INFO - 2022-09-13 10:07:35 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:07:35 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:07:35 --> Utf8 Class Initialized
INFO - 2022-09-13 10:07:35 --> URI Class Initialized
INFO - 2022-09-13 10:07:35 --> Router Class Initialized
INFO - 2022-09-13 10:07:35 --> Output Class Initialized
INFO - 2022-09-13 10:07:35 --> Security Class Initialized
DEBUG - 2022-09-13 10:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:07:35 --> Input Class Initialized
INFO - 2022-09-13 10:07:35 --> Language Class Initialized
INFO - 2022-09-13 10:07:35 --> Language Class Initialized
INFO - 2022-09-13 10:07:35 --> Config Class Initialized
INFO - 2022-09-13 10:07:35 --> Loader Class Initialized
INFO - 2022-09-13 10:07:35 --> Helper loaded: url_helper
INFO - 2022-09-13 10:07:35 --> Helper loaded: file_helper
INFO - 2022-09-13 10:07:35 --> Helper loaded: form_helper
INFO - 2022-09-13 10:07:35 --> Helper loaded: my_helper
INFO - 2022-09-13 10:07:35 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:07:35 --> Controller Class Initialized
DEBUG - 2022-09-13 10:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-09-13 10:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:07:35 --> Final output sent to browser
DEBUG - 2022-09-13 10:07:35 --> Total execution time: 0.0579
INFO - 2022-09-13 10:07:35 --> Config Class Initialized
INFO - 2022-09-13 10:07:35 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:07:35 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:07:35 --> Utf8 Class Initialized
INFO - 2022-09-13 10:07:35 --> URI Class Initialized
INFO - 2022-09-13 10:07:35 --> Router Class Initialized
INFO - 2022-09-13 10:07:35 --> Output Class Initialized
INFO - 2022-09-13 10:07:35 --> Security Class Initialized
DEBUG - 2022-09-13 10:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:07:35 --> Input Class Initialized
INFO - 2022-09-13 10:07:35 --> Language Class Initialized
INFO - 2022-09-13 10:07:35 --> Language Class Initialized
INFO - 2022-09-13 10:07:35 --> Config Class Initialized
INFO - 2022-09-13 10:07:35 --> Loader Class Initialized
INFO - 2022-09-13 10:07:35 --> Helper loaded: url_helper
INFO - 2022-09-13 10:07:35 --> Helper loaded: file_helper
INFO - 2022-09-13 10:07:35 --> Helper loaded: form_helper
INFO - 2022-09-13 10:07:35 --> Helper loaded: my_helper
INFO - 2022-09-13 10:07:35 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:07:35 --> Controller Class Initialized
DEBUG - 2022-09-13 10:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-09-13 10:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:07:35 --> Final output sent to browser
DEBUG - 2022-09-13 10:07:35 --> Total execution time: 0.0837
INFO - 2022-09-13 10:07:37 --> Config Class Initialized
INFO - 2022-09-13 10:07:37 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:07:37 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:07:37 --> Utf8 Class Initialized
INFO - 2022-09-13 10:07:37 --> URI Class Initialized
INFO - 2022-09-13 10:07:37 --> Router Class Initialized
INFO - 2022-09-13 10:07:37 --> Output Class Initialized
INFO - 2022-09-13 10:07:37 --> Security Class Initialized
DEBUG - 2022-09-13 10:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:07:37 --> Input Class Initialized
INFO - 2022-09-13 10:07:37 --> Language Class Initialized
INFO - 2022-09-13 10:07:37 --> Language Class Initialized
INFO - 2022-09-13 10:07:37 --> Config Class Initialized
INFO - 2022-09-13 10:07:37 --> Loader Class Initialized
INFO - 2022-09-13 10:07:37 --> Helper loaded: url_helper
INFO - 2022-09-13 10:07:37 --> Helper loaded: file_helper
INFO - 2022-09-13 10:07:37 --> Helper loaded: form_helper
INFO - 2022-09-13 10:07:37 --> Helper loaded: my_helper
INFO - 2022-09-13 10:07:37 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:07:37 --> Controller Class Initialized
DEBUG - 2022-09-13 10:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2022-09-13 10:07:37 --> Final output sent to browser
DEBUG - 2022-09-13 10:07:37 --> Total execution time: 0.2291
INFO - 2022-09-13 10:07:57 --> Config Class Initialized
INFO - 2022-09-13 10:07:57 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:07:57 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:07:57 --> Utf8 Class Initialized
INFO - 2022-09-13 10:07:57 --> URI Class Initialized
INFO - 2022-09-13 10:07:57 --> Router Class Initialized
INFO - 2022-09-13 10:07:57 --> Output Class Initialized
INFO - 2022-09-13 10:07:57 --> Security Class Initialized
DEBUG - 2022-09-13 10:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:07:57 --> Input Class Initialized
INFO - 2022-09-13 10:07:57 --> Language Class Initialized
INFO - 2022-09-13 10:07:57 --> Language Class Initialized
INFO - 2022-09-13 10:07:57 --> Config Class Initialized
INFO - 2022-09-13 10:07:57 --> Loader Class Initialized
INFO - 2022-09-13 10:07:57 --> Helper loaded: url_helper
INFO - 2022-09-13 10:07:57 --> Helper loaded: file_helper
INFO - 2022-09-13 10:07:57 --> Helper loaded: form_helper
INFO - 2022-09-13 10:07:57 --> Helper loaded: my_helper
INFO - 2022-09-13 10:07:57 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:07:57 --> Controller Class Initialized
DEBUG - 2022-09-13 10:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-09-13 10:07:57 --> Final output sent to browser
DEBUG - 2022-09-13 10:07:57 --> Total execution time: 0.1907
INFO - 2022-09-13 10:08:26 --> Config Class Initialized
INFO - 2022-09-13 10:08:26 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:26 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:26 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:26 --> URI Class Initialized
INFO - 2022-09-13 10:08:26 --> Router Class Initialized
INFO - 2022-09-13 10:08:26 --> Output Class Initialized
INFO - 2022-09-13 10:08:26 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:26 --> Input Class Initialized
INFO - 2022-09-13 10:08:26 --> Language Class Initialized
INFO - 2022-09-13 10:08:26 --> Language Class Initialized
INFO - 2022-09-13 10:08:26 --> Config Class Initialized
INFO - 2022-09-13 10:08:26 --> Loader Class Initialized
INFO - 2022-09-13 10:08:26 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:26 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:26 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:26 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:26 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:26 --> Controller Class Initialized
INFO - 2022-09-13 10:08:26 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:08:26 --> Config Class Initialized
INFO - 2022-09-13 10:08:26 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:26 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:26 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:26 --> URI Class Initialized
INFO - 2022-09-13 10:08:26 --> Router Class Initialized
INFO - 2022-09-13 10:08:26 --> Output Class Initialized
INFO - 2022-09-13 10:08:26 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:26 --> Input Class Initialized
INFO - 2022-09-13 10:08:26 --> Language Class Initialized
INFO - 2022-09-13 10:08:26 --> Language Class Initialized
INFO - 2022-09-13 10:08:26 --> Config Class Initialized
INFO - 2022-09-13 10:08:26 --> Loader Class Initialized
INFO - 2022-09-13 10:08:26 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:26 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:26 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:26 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:26 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:26 --> Controller Class Initialized
DEBUG - 2022-09-13 10:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-13 10:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:08:26 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:26 --> Total execution time: 0.0444
INFO - 2022-09-13 10:08:30 --> Config Class Initialized
INFO - 2022-09-13 10:08:30 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:30 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:30 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:30 --> URI Class Initialized
INFO - 2022-09-13 10:08:30 --> Router Class Initialized
INFO - 2022-09-13 10:08:30 --> Output Class Initialized
INFO - 2022-09-13 10:08:30 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:30 --> Input Class Initialized
INFO - 2022-09-13 10:08:30 --> Language Class Initialized
INFO - 2022-09-13 10:08:30 --> Language Class Initialized
INFO - 2022-09-13 10:08:30 --> Config Class Initialized
INFO - 2022-09-13 10:08:30 --> Loader Class Initialized
INFO - 2022-09-13 10:08:30 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:30 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:30 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:30 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:30 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:30 --> Controller Class Initialized
INFO - 2022-09-13 10:08:30 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:08:30 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:30 --> Total execution time: 0.0617
INFO - 2022-09-13 10:08:30 --> Config Class Initialized
INFO - 2022-09-13 10:08:30 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:30 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:30 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:30 --> URI Class Initialized
INFO - 2022-09-13 10:08:30 --> Router Class Initialized
INFO - 2022-09-13 10:08:30 --> Output Class Initialized
INFO - 2022-09-13 10:08:30 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:30 --> Input Class Initialized
INFO - 2022-09-13 10:08:30 --> Language Class Initialized
INFO - 2022-09-13 10:08:30 --> Language Class Initialized
INFO - 2022-09-13 10:08:30 --> Config Class Initialized
INFO - 2022-09-13 10:08:30 --> Loader Class Initialized
INFO - 2022-09-13 10:08:30 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:30 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:30 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:30 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:30 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:30 --> Controller Class Initialized
DEBUG - 2022-09-13 10:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-09-13 10:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:08:31 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:31 --> Total execution time: 0.6139
INFO - 2022-09-13 10:08:33 --> Config Class Initialized
INFO - 2022-09-13 10:08:33 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:33 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:33 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:33 --> URI Class Initialized
INFO - 2022-09-13 10:08:33 --> Router Class Initialized
INFO - 2022-09-13 10:08:33 --> Output Class Initialized
INFO - 2022-09-13 10:08:33 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:33 --> Input Class Initialized
INFO - 2022-09-13 10:08:33 --> Language Class Initialized
INFO - 2022-09-13 10:08:33 --> Language Class Initialized
INFO - 2022-09-13 10:08:33 --> Config Class Initialized
INFO - 2022-09-13 10:08:33 --> Loader Class Initialized
INFO - 2022-09-13 10:08:33 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:33 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:33 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:33 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:33 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:33 --> Controller Class Initialized
DEBUG - 2022-09-13 10:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-09-13 10:08:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:08:33 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:33 --> Total execution time: 0.0669
INFO - 2022-09-13 10:08:33 --> Config Class Initialized
INFO - 2022-09-13 10:08:33 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:33 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:33 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:33 --> URI Class Initialized
INFO - 2022-09-13 10:08:33 --> Router Class Initialized
INFO - 2022-09-13 10:08:33 --> Output Class Initialized
INFO - 2022-09-13 10:08:33 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:33 --> Input Class Initialized
INFO - 2022-09-13 10:08:33 --> Language Class Initialized
INFO - 2022-09-13 10:08:33 --> Language Class Initialized
INFO - 2022-09-13 10:08:33 --> Config Class Initialized
INFO - 2022-09-13 10:08:33 --> Loader Class Initialized
INFO - 2022-09-13 10:08:33 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:33 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:33 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:33 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:33 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:33 --> Controller Class Initialized
INFO - 2022-09-13 10:08:38 --> Config Class Initialized
INFO - 2022-09-13 10:08:38 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:39 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:39 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:39 --> URI Class Initialized
INFO - 2022-09-13 10:08:39 --> Router Class Initialized
INFO - 2022-09-13 10:08:39 --> Output Class Initialized
INFO - 2022-09-13 10:08:39 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:39 --> Input Class Initialized
INFO - 2022-09-13 10:08:39 --> Language Class Initialized
INFO - 2022-09-13 10:08:39 --> Language Class Initialized
INFO - 2022-09-13 10:08:39 --> Config Class Initialized
INFO - 2022-09-13 10:08:39 --> Loader Class Initialized
INFO - 2022-09-13 10:08:39 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:39 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:39 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:39 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:39 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:39 --> Controller Class Initialized
INFO - 2022-09-13 10:08:39 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:39 --> Total execution time: 0.8204
INFO - 2022-09-13 10:08:39 --> Config Class Initialized
INFO - 2022-09-13 10:08:39 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:39 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:39 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:39 --> URI Class Initialized
INFO - 2022-09-13 10:08:39 --> Router Class Initialized
INFO - 2022-09-13 10:08:39 --> Output Class Initialized
INFO - 2022-09-13 10:08:39 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:39 --> Input Class Initialized
INFO - 2022-09-13 10:08:39 --> Language Class Initialized
INFO - 2022-09-13 10:08:39 --> Language Class Initialized
INFO - 2022-09-13 10:08:39 --> Config Class Initialized
INFO - 2022-09-13 10:08:39 --> Loader Class Initialized
INFO - 2022-09-13 10:08:39 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:39 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:39 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:39 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:39 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:39 --> Controller Class Initialized
INFO - 2022-09-13 10:08:44 --> Config Class Initialized
INFO - 2022-09-13 10:08:44 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:44 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:44 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:44 --> URI Class Initialized
INFO - 2022-09-13 10:08:44 --> Router Class Initialized
INFO - 2022-09-13 10:08:44 --> Output Class Initialized
INFO - 2022-09-13 10:08:44 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:44 --> Input Class Initialized
INFO - 2022-09-13 10:08:44 --> Language Class Initialized
INFO - 2022-09-13 10:08:44 --> Language Class Initialized
INFO - 2022-09-13 10:08:44 --> Config Class Initialized
INFO - 2022-09-13 10:08:44 --> Loader Class Initialized
INFO - 2022-09-13 10:08:44 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:44 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:44 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:44 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:44 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:44 --> Controller Class Initialized
INFO - 2022-09-13 10:08:44 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:08:44 --> Config Class Initialized
INFO - 2022-09-13 10:08:44 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:44 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:44 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:44 --> URI Class Initialized
INFO - 2022-09-13 10:08:44 --> Router Class Initialized
INFO - 2022-09-13 10:08:44 --> Output Class Initialized
INFO - 2022-09-13 10:08:44 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:44 --> Input Class Initialized
INFO - 2022-09-13 10:08:44 --> Language Class Initialized
INFO - 2022-09-13 10:08:44 --> Language Class Initialized
INFO - 2022-09-13 10:08:44 --> Config Class Initialized
INFO - 2022-09-13 10:08:44 --> Loader Class Initialized
INFO - 2022-09-13 10:08:44 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:44 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:44 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:44 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:44 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:44 --> Controller Class Initialized
DEBUG - 2022-09-13 10:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-13 10:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:08:44 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:44 --> Total execution time: 0.0909
INFO - 2022-09-13 10:08:48 --> Config Class Initialized
INFO - 2022-09-13 10:08:48 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:48 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:48 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:48 --> URI Class Initialized
INFO - 2022-09-13 10:08:48 --> Router Class Initialized
INFO - 2022-09-13 10:08:48 --> Output Class Initialized
INFO - 2022-09-13 10:08:48 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:48 --> Input Class Initialized
INFO - 2022-09-13 10:08:48 --> Language Class Initialized
INFO - 2022-09-13 10:08:48 --> Language Class Initialized
INFO - 2022-09-13 10:08:48 --> Config Class Initialized
INFO - 2022-09-13 10:08:48 --> Loader Class Initialized
INFO - 2022-09-13 10:08:48 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:48 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:48 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:48 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:48 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:48 --> Controller Class Initialized
INFO - 2022-09-13 10:08:48 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:08:48 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:48 --> Total execution time: 0.0546
INFO - 2022-09-13 10:08:48 --> Config Class Initialized
INFO - 2022-09-13 10:08:48 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:48 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:48 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:48 --> URI Class Initialized
INFO - 2022-09-13 10:08:48 --> Router Class Initialized
INFO - 2022-09-13 10:08:48 --> Output Class Initialized
INFO - 2022-09-13 10:08:48 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:48 --> Input Class Initialized
INFO - 2022-09-13 10:08:48 --> Language Class Initialized
INFO - 2022-09-13 10:08:48 --> Language Class Initialized
INFO - 2022-09-13 10:08:48 --> Config Class Initialized
INFO - 2022-09-13 10:08:48 --> Loader Class Initialized
INFO - 2022-09-13 10:08:48 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:48 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:48 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:48 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:48 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:48 --> Controller Class Initialized
DEBUG - 2022-09-13 10:08:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-09-13 10:08:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:08:49 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:49 --> Total execution time: 0.5659
INFO - 2022-09-13 10:08:50 --> Config Class Initialized
INFO - 2022-09-13 10:08:50 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:50 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:50 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:50 --> URI Class Initialized
INFO - 2022-09-13 10:08:50 --> Router Class Initialized
INFO - 2022-09-13 10:08:50 --> Output Class Initialized
INFO - 2022-09-13 10:08:50 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:50 --> Input Class Initialized
INFO - 2022-09-13 10:08:50 --> Language Class Initialized
INFO - 2022-09-13 10:08:50 --> Language Class Initialized
INFO - 2022-09-13 10:08:50 --> Config Class Initialized
INFO - 2022-09-13 10:08:50 --> Loader Class Initialized
INFO - 2022-09-13 10:08:50 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:50 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:50 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:50 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:50 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:50 --> Controller Class Initialized
DEBUG - 2022-09-13 10:08:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-09-13 10:08:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:08:50 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:50 --> Total execution time: 0.1214
INFO - 2022-09-13 10:08:55 --> Config Class Initialized
INFO - 2022-09-13 10:08:55 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:08:55 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:08:55 --> Utf8 Class Initialized
INFO - 2022-09-13 10:08:55 --> URI Class Initialized
INFO - 2022-09-13 10:08:55 --> Router Class Initialized
INFO - 2022-09-13 10:08:55 --> Output Class Initialized
INFO - 2022-09-13 10:08:55 --> Security Class Initialized
DEBUG - 2022-09-13 10:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:08:55 --> Input Class Initialized
INFO - 2022-09-13 10:08:55 --> Language Class Initialized
INFO - 2022-09-13 10:08:55 --> Language Class Initialized
INFO - 2022-09-13 10:08:55 --> Config Class Initialized
INFO - 2022-09-13 10:08:55 --> Loader Class Initialized
INFO - 2022-09-13 10:08:55 --> Helper loaded: url_helper
INFO - 2022-09-13 10:08:55 --> Helper loaded: file_helper
INFO - 2022-09-13 10:08:55 --> Helper loaded: form_helper
INFO - 2022-09-13 10:08:55 --> Helper loaded: my_helper
INFO - 2022-09-13 10:08:55 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:08:55 --> Controller Class Initialized
DEBUG - 2022-09-13 10:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-09-13 10:08:55 --> Final output sent to browser
DEBUG - 2022-09-13 10:08:55 --> Total execution time: 0.2720
INFO - 2022-09-13 10:09:00 --> Config Class Initialized
INFO - 2022-09-13 10:09:00 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:09:00 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:09:00 --> Utf8 Class Initialized
INFO - 2022-09-13 10:09:00 --> URI Class Initialized
INFO - 2022-09-13 10:09:00 --> Router Class Initialized
INFO - 2022-09-13 10:09:00 --> Output Class Initialized
INFO - 2022-09-13 10:09:00 --> Security Class Initialized
DEBUG - 2022-09-13 10:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:09:00 --> Input Class Initialized
INFO - 2022-09-13 10:09:00 --> Language Class Initialized
INFO - 2022-09-13 10:09:00 --> Language Class Initialized
INFO - 2022-09-13 10:09:00 --> Config Class Initialized
INFO - 2022-09-13 10:09:00 --> Loader Class Initialized
INFO - 2022-09-13 10:09:00 --> Helper loaded: url_helper
INFO - 2022-09-13 10:09:00 --> Helper loaded: file_helper
INFO - 2022-09-13 10:09:00 --> Helper loaded: form_helper
INFO - 2022-09-13 10:09:00 --> Helper loaded: my_helper
INFO - 2022-09-13 10:09:00 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:09:00 --> Controller Class Initialized
DEBUG - 2022-09-13 10:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2022-09-13 10:09:00 --> Final output sent to browser
DEBUG - 2022-09-13 10:09:00 --> Total execution time: 0.1988
INFO - 2022-09-13 10:09:13 --> Config Class Initialized
INFO - 2022-09-13 10:09:13 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:09:13 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:09:13 --> Utf8 Class Initialized
INFO - 2022-09-13 10:09:13 --> URI Class Initialized
INFO - 2022-09-13 10:09:13 --> Router Class Initialized
INFO - 2022-09-13 10:09:13 --> Output Class Initialized
INFO - 2022-09-13 10:09:13 --> Security Class Initialized
DEBUG - 2022-09-13 10:09:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:09:13 --> Input Class Initialized
INFO - 2022-09-13 10:09:13 --> Language Class Initialized
INFO - 2022-09-13 10:09:13 --> Language Class Initialized
INFO - 2022-09-13 10:09:13 --> Config Class Initialized
INFO - 2022-09-13 10:09:13 --> Loader Class Initialized
INFO - 2022-09-13 10:09:13 --> Helper loaded: url_helper
INFO - 2022-09-13 10:09:13 --> Helper loaded: file_helper
INFO - 2022-09-13 10:09:13 --> Helper loaded: form_helper
INFO - 2022-09-13 10:09:13 --> Helper loaded: my_helper
INFO - 2022-09-13 10:09:13 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:09:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:09:13 --> Controller Class Initialized
DEBUG - 2022-09-13 10:09:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2022-09-13 10:09:13 --> Final output sent to browser
DEBUG - 2022-09-13 10:09:13 --> Total execution time: 0.1252
INFO - 2022-09-13 10:09:17 --> Config Class Initialized
INFO - 2022-09-13 10:09:17 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:09:17 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:09:17 --> Utf8 Class Initialized
INFO - 2022-09-13 10:09:17 --> URI Class Initialized
INFO - 2022-09-13 10:09:17 --> Router Class Initialized
INFO - 2022-09-13 10:09:17 --> Output Class Initialized
INFO - 2022-09-13 10:09:17 --> Security Class Initialized
DEBUG - 2022-09-13 10:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:09:17 --> Input Class Initialized
INFO - 2022-09-13 10:09:17 --> Language Class Initialized
INFO - 2022-09-13 10:09:17 --> Language Class Initialized
INFO - 2022-09-13 10:09:17 --> Config Class Initialized
INFO - 2022-09-13 10:09:17 --> Loader Class Initialized
INFO - 2022-09-13 10:09:17 --> Helper loaded: url_helper
INFO - 2022-09-13 10:09:17 --> Helper loaded: file_helper
INFO - 2022-09-13 10:09:17 --> Helper loaded: form_helper
INFO - 2022-09-13 10:09:17 --> Helper loaded: my_helper
INFO - 2022-09-13 10:09:17 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:09:17 --> Controller Class Initialized
DEBUG - 2022-09-13 10:09:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-09-13 10:09:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:09:17 --> Final output sent to browser
DEBUG - 2022-09-13 10:09:17 --> Total execution time: 0.0867
INFO - 2022-09-13 10:09:18 --> Config Class Initialized
INFO - 2022-09-13 10:09:18 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:09:18 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:09:18 --> Utf8 Class Initialized
INFO - 2022-09-13 10:09:18 --> URI Class Initialized
INFO - 2022-09-13 10:09:18 --> Router Class Initialized
INFO - 2022-09-13 10:09:18 --> Output Class Initialized
INFO - 2022-09-13 10:09:18 --> Security Class Initialized
DEBUG - 2022-09-13 10:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:09:18 --> Input Class Initialized
INFO - 2022-09-13 10:09:18 --> Language Class Initialized
INFO - 2022-09-13 10:09:18 --> Language Class Initialized
INFO - 2022-09-13 10:09:18 --> Config Class Initialized
INFO - 2022-09-13 10:09:18 --> Loader Class Initialized
INFO - 2022-09-13 10:09:18 --> Helper loaded: url_helper
INFO - 2022-09-13 10:09:18 --> Helper loaded: file_helper
INFO - 2022-09-13 10:09:18 --> Helper loaded: form_helper
INFO - 2022-09-13 10:09:18 --> Helper loaded: my_helper
INFO - 2022-09-13 10:09:18 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:09:18 --> Controller Class Initialized
DEBUG - 2022-09-13 10:09:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2022-09-13 10:09:19 --> Final output sent to browser
DEBUG - 2022-09-13 10:09:19 --> Total execution time: 0.2203
INFO - 2022-09-13 10:09:24 --> Config Class Initialized
INFO - 2022-09-13 10:09:24 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:09:24 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:09:24 --> Utf8 Class Initialized
INFO - 2022-09-13 10:09:24 --> URI Class Initialized
INFO - 2022-09-13 10:09:24 --> Router Class Initialized
INFO - 2022-09-13 10:09:24 --> Output Class Initialized
INFO - 2022-09-13 10:09:24 --> Security Class Initialized
DEBUG - 2022-09-13 10:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:09:24 --> Input Class Initialized
INFO - 2022-09-13 10:09:24 --> Language Class Initialized
INFO - 2022-09-13 10:09:24 --> Language Class Initialized
INFO - 2022-09-13 10:09:24 --> Config Class Initialized
INFO - 2022-09-13 10:09:24 --> Loader Class Initialized
INFO - 2022-09-13 10:09:24 --> Helper loaded: url_helper
INFO - 2022-09-13 10:09:24 --> Helper loaded: file_helper
INFO - 2022-09-13 10:09:24 --> Helper loaded: form_helper
INFO - 2022-09-13 10:09:24 --> Helper loaded: my_helper
INFO - 2022-09-13 10:09:24 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:09:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:09:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:09:24 --> Controller Class Initialized
DEBUG - 2022-09-13 10:09:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2022-09-13 10:09:24 --> Final output sent to browser
DEBUG - 2022-09-13 10:09:24 --> Total execution time: 0.2212
INFO - 2022-09-13 10:09:37 --> Config Class Initialized
INFO - 2022-09-13 10:09:37 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:09:37 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:09:37 --> Utf8 Class Initialized
INFO - 2022-09-13 10:09:37 --> URI Class Initialized
INFO - 2022-09-13 10:09:37 --> Router Class Initialized
INFO - 2022-09-13 10:09:37 --> Output Class Initialized
INFO - 2022-09-13 10:09:37 --> Security Class Initialized
DEBUG - 2022-09-13 10:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:09:37 --> Input Class Initialized
INFO - 2022-09-13 10:09:37 --> Language Class Initialized
INFO - 2022-09-13 10:09:37 --> Language Class Initialized
INFO - 2022-09-13 10:09:37 --> Config Class Initialized
INFO - 2022-09-13 10:09:37 --> Loader Class Initialized
INFO - 2022-09-13 10:09:37 --> Helper loaded: url_helper
INFO - 2022-09-13 10:09:37 --> Helper loaded: file_helper
INFO - 2022-09-13 10:09:37 --> Helper loaded: form_helper
INFO - 2022-09-13 10:09:37 --> Helper loaded: my_helper
INFO - 2022-09-13 10:09:37 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:09:37 --> Controller Class Initialized
DEBUG - 2022-09-13 10:09:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-09-13 10:09:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:09:37 --> Final output sent to browser
DEBUG - 2022-09-13 10:09:37 --> Total execution time: 0.0640
INFO - 2022-09-13 10:11:01 --> Config Class Initialized
INFO - 2022-09-13 10:11:01 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:01 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:01 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:01 --> URI Class Initialized
INFO - 2022-09-13 10:11:01 --> Router Class Initialized
INFO - 2022-09-13 10:11:01 --> Output Class Initialized
INFO - 2022-09-13 10:11:01 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:01 --> Input Class Initialized
INFO - 2022-09-13 10:11:01 --> Language Class Initialized
INFO - 2022-09-13 10:11:01 --> Language Class Initialized
INFO - 2022-09-13 10:11:01 --> Config Class Initialized
INFO - 2022-09-13 10:11:01 --> Loader Class Initialized
INFO - 2022-09-13 10:11:01 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:01 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:01 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:01 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:01 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:01 --> Controller Class Initialized
DEBUG - 2022-09-13 10:11:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2022-09-13 10:11:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:11:01 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:01 --> Total execution time: 0.0539
INFO - 2022-09-13 10:11:03 --> Config Class Initialized
INFO - 2022-09-13 10:11:03 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:03 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:03 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:03 --> URI Class Initialized
INFO - 2022-09-13 10:11:03 --> Router Class Initialized
INFO - 2022-09-13 10:11:03 --> Output Class Initialized
INFO - 2022-09-13 10:11:03 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:03 --> Input Class Initialized
INFO - 2022-09-13 10:11:03 --> Language Class Initialized
INFO - 2022-09-13 10:11:03 --> Language Class Initialized
INFO - 2022-09-13 10:11:03 --> Config Class Initialized
INFO - 2022-09-13 10:11:03 --> Loader Class Initialized
INFO - 2022-09-13 10:11:03 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:03 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:03 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:03 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:03 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:03 --> Controller Class Initialized
DEBUG - 2022-09-13 10:11:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2022-09-13 10:11:03 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:03 --> Total execution time: 0.1960
INFO - 2022-09-13 10:11:15 --> Config Class Initialized
INFO - 2022-09-13 10:11:15 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:15 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:15 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:15 --> URI Class Initialized
INFO - 2022-09-13 10:11:15 --> Router Class Initialized
INFO - 2022-09-13 10:11:15 --> Output Class Initialized
INFO - 2022-09-13 10:11:15 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:15 --> Input Class Initialized
INFO - 2022-09-13 10:11:15 --> Language Class Initialized
INFO - 2022-09-13 10:11:15 --> Language Class Initialized
INFO - 2022-09-13 10:11:15 --> Config Class Initialized
INFO - 2022-09-13 10:11:15 --> Loader Class Initialized
INFO - 2022-09-13 10:11:15 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:15 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:15 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:15 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:15 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:15 --> Controller Class Initialized
INFO - 2022-09-13 10:11:15 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:11:15 --> Config Class Initialized
INFO - 2022-09-13 10:11:15 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:15 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:15 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:15 --> URI Class Initialized
INFO - 2022-09-13 10:11:15 --> Router Class Initialized
INFO - 2022-09-13 10:11:15 --> Output Class Initialized
INFO - 2022-09-13 10:11:15 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:15 --> Input Class Initialized
INFO - 2022-09-13 10:11:15 --> Language Class Initialized
INFO - 2022-09-13 10:11:15 --> Language Class Initialized
INFO - 2022-09-13 10:11:15 --> Config Class Initialized
INFO - 2022-09-13 10:11:15 --> Loader Class Initialized
INFO - 2022-09-13 10:11:15 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:15 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:15 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:15 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:15 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:15 --> Controller Class Initialized
DEBUG - 2022-09-13 10:11:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-13 10:11:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:11:15 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:15 --> Total execution time: 0.0540
INFO - 2022-09-13 10:11:29 --> Config Class Initialized
INFO - 2022-09-13 10:11:29 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:29 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:29 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:29 --> URI Class Initialized
INFO - 2022-09-13 10:11:29 --> Router Class Initialized
INFO - 2022-09-13 10:11:29 --> Output Class Initialized
INFO - 2022-09-13 10:11:29 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:29 --> Input Class Initialized
INFO - 2022-09-13 10:11:29 --> Language Class Initialized
INFO - 2022-09-13 10:11:29 --> Language Class Initialized
INFO - 2022-09-13 10:11:29 --> Config Class Initialized
INFO - 2022-09-13 10:11:29 --> Loader Class Initialized
INFO - 2022-09-13 10:11:29 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:29 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:29 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:29 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:29 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:29 --> Controller Class Initialized
INFO - 2022-09-13 10:11:29 --> Helper loaded: cookie_helper
INFO - 2022-09-13 10:11:29 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:29 --> Total execution time: 0.0462
INFO - 2022-09-13 10:11:29 --> Config Class Initialized
INFO - 2022-09-13 10:11:29 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:29 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:29 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:29 --> URI Class Initialized
INFO - 2022-09-13 10:11:29 --> Router Class Initialized
INFO - 2022-09-13 10:11:29 --> Output Class Initialized
INFO - 2022-09-13 10:11:29 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:29 --> Input Class Initialized
INFO - 2022-09-13 10:11:29 --> Language Class Initialized
INFO - 2022-09-13 10:11:29 --> Language Class Initialized
INFO - 2022-09-13 10:11:29 --> Config Class Initialized
INFO - 2022-09-13 10:11:29 --> Loader Class Initialized
INFO - 2022-09-13 10:11:29 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:29 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:29 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:29 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:29 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:29 --> Controller Class Initialized
DEBUG - 2022-09-13 10:11:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-09-13 10:11:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:11:29 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:29 --> Total execution time: 0.5419
INFO - 2022-09-13 10:11:30 --> Config Class Initialized
INFO - 2022-09-13 10:11:30 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:30 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:30 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:30 --> URI Class Initialized
INFO - 2022-09-13 10:11:30 --> Router Class Initialized
INFO - 2022-09-13 10:11:30 --> Output Class Initialized
INFO - 2022-09-13 10:11:30 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:31 --> Input Class Initialized
INFO - 2022-09-13 10:11:31 --> Language Class Initialized
INFO - 2022-09-13 10:11:31 --> Language Class Initialized
INFO - 2022-09-13 10:11:31 --> Config Class Initialized
INFO - 2022-09-13 10:11:31 --> Loader Class Initialized
INFO - 2022-09-13 10:11:31 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:31 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:31 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:31 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:31 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:31 --> Controller Class Initialized
DEBUG - 2022-09-13 10:11:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-09-13 10:11:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-13 10:11:31 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:31 --> Total execution time: 0.0531
INFO - 2022-09-13 10:11:40 --> Config Class Initialized
INFO - 2022-09-13 10:11:40 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:40 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:40 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:40 --> URI Class Initialized
INFO - 2022-09-13 10:11:40 --> Router Class Initialized
INFO - 2022-09-13 10:11:40 --> Output Class Initialized
INFO - 2022-09-13 10:11:40 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:40 --> Input Class Initialized
INFO - 2022-09-13 10:11:40 --> Language Class Initialized
INFO - 2022-09-13 10:11:40 --> Language Class Initialized
INFO - 2022-09-13 10:11:40 --> Config Class Initialized
INFO - 2022-09-13 10:11:40 --> Loader Class Initialized
INFO - 2022-09-13 10:11:40 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:40 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:40 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:40 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:40 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:40 --> Controller Class Initialized
DEBUG - 2022-09-13 10:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2022-09-13 10:11:41 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:41 --> Total execution time: 0.2616
INFO - 2022-09-13 10:11:41 --> Config Class Initialized
INFO - 2022-09-13 10:11:41 --> Hooks Class Initialized
DEBUG - 2022-09-13 10:11:41 --> UTF-8 Support Enabled
INFO - 2022-09-13 10:11:41 --> Utf8 Class Initialized
INFO - 2022-09-13 10:11:41 --> URI Class Initialized
INFO - 2022-09-13 10:11:41 --> Router Class Initialized
INFO - 2022-09-13 10:11:41 --> Output Class Initialized
INFO - 2022-09-13 10:11:41 --> Security Class Initialized
DEBUG - 2022-09-13 10:11:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-13 10:11:41 --> Input Class Initialized
INFO - 2022-09-13 10:11:41 --> Language Class Initialized
INFO - 2022-09-13 10:11:41 --> Language Class Initialized
INFO - 2022-09-13 10:11:41 --> Config Class Initialized
INFO - 2022-09-13 10:11:41 --> Loader Class Initialized
INFO - 2022-09-13 10:11:41 --> Helper loaded: url_helper
INFO - 2022-09-13 10:11:41 --> Helper loaded: file_helper
INFO - 2022-09-13 10:11:41 --> Helper loaded: form_helper
INFO - 2022-09-13 10:11:41 --> Helper loaded: my_helper
INFO - 2022-09-13 10:11:41 --> Database Driver Class Initialized
DEBUG - 2022-09-13 10:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-13 10:11:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-13 10:11:41 --> Controller Class Initialized
DEBUG - 2022-09-13 10:11:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2022-09-13 10:11:41 --> Final output sent to browser
DEBUG - 2022-09-13 10:11:41 --> Total execution time: 0.2045
