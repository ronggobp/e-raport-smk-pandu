<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-09-23 08:20:08 --> Config Class Initialized
INFO - 2020-09-23 08:20:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:20:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:20:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:20:08 --> URI Class Initialized
DEBUG - 2020-09-23 08:20:08 --> No URI present. Default controller set.
INFO - 2020-09-23 08:20:08 --> Router Class Initialized
INFO - 2020-09-23 08:20:08 --> Output Class Initialized
INFO - 2020-09-23 08:20:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:20:08 --> Input Class Initialized
INFO - 2020-09-23 08:20:08 --> Language Class Initialized
INFO - 2020-09-23 08:20:08 --> Language Class Initialized
INFO - 2020-09-23 08:20:08 --> Config Class Initialized
INFO - 2020-09-23 08:20:08 --> Loader Class Initialized
INFO - 2020-09-23 08:20:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:20:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:20:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:20:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:20:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:20:08 --> Controller Class Initialized
INFO - 2020-09-23 08:20:08 --> Config Class Initialized
INFO - 2020-09-23 08:20:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:20:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:20:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:20:08 --> URI Class Initialized
INFO - 2020-09-23 08:20:08 --> Router Class Initialized
INFO - 2020-09-23 08:20:08 --> Output Class Initialized
INFO - 2020-09-23 08:20:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:20:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:20:08 --> Input Class Initialized
INFO - 2020-09-23 08:20:08 --> Language Class Initialized
INFO - 2020-09-23 08:20:08 --> Language Class Initialized
INFO - 2020-09-23 08:20:08 --> Config Class Initialized
INFO - 2020-09-23 08:20:08 --> Loader Class Initialized
INFO - 2020-09-23 08:20:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:20:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:20:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:20:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:20:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:20:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:20:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:20:08 --> Controller Class Initialized
DEBUG - 2020-09-23 08:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:20:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:20:08 --> Final output sent to browser
DEBUG - 2020-09-23 08:20:08 --> Total execution time: 0.0396
INFO - 2020-09-23 08:24:38 --> Config Class Initialized
INFO - 2020-09-23 08:24:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:24:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:24:38 --> Utf8 Class Initialized
INFO - 2020-09-23 08:24:38 --> URI Class Initialized
INFO - 2020-09-23 08:24:38 --> Router Class Initialized
INFO - 2020-09-23 08:24:38 --> Output Class Initialized
INFO - 2020-09-23 08:24:38 --> Security Class Initialized
DEBUG - 2020-09-23 08:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:24:38 --> Input Class Initialized
INFO - 2020-09-23 08:24:38 --> Language Class Initialized
INFO - 2020-09-23 08:24:38 --> Language Class Initialized
INFO - 2020-09-23 08:24:38 --> Config Class Initialized
INFO - 2020-09-23 08:24:38 --> Loader Class Initialized
INFO - 2020-09-23 08:24:38 --> Helper loaded: url_helper
INFO - 2020-09-23 08:24:38 --> Helper loaded: file_helper
INFO - 2020-09-23 08:24:38 --> Helper loaded: form_helper
INFO - 2020-09-23 08:24:38 --> Helper loaded: my_helper
INFO - 2020-09-23 08:24:38 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:24:38 --> Controller Class Initialized
INFO - 2020-09-23 08:24:38 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:24:38 --> Final output sent to browser
DEBUG - 2020-09-23 08:24:38 --> Total execution time: 0.0618
INFO - 2020-09-23 08:24:40 --> Config Class Initialized
INFO - 2020-09-23 08:24:40 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:24:40 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:24:40 --> Utf8 Class Initialized
INFO - 2020-09-23 08:24:40 --> URI Class Initialized
INFO - 2020-09-23 08:24:40 --> Router Class Initialized
INFO - 2020-09-23 08:24:40 --> Output Class Initialized
INFO - 2020-09-23 08:24:40 --> Security Class Initialized
DEBUG - 2020-09-23 08:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:24:40 --> Input Class Initialized
INFO - 2020-09-23 08:24:40 --> Language Class Initialized
INFO - 2020-09-23 08:24:40 --> Language Class Initialized
INFO - 2020-09-23 08:24:40 --> Config Class Initialized
INFO - 2020-09-23 08:24:40 --> Loader Class Initialized
INFO - 2020-09-23 08:24:40 --> Helper loaded: url_helper
INFO - 2020-09-23 08:24:40 --> Helper loaded: file_helper
INFO - 2020-09-23 08:24:40 --> Helper loaded: form_helper
INFO - 2020-09-23 08:24:40 --> Helper loaded: my_helper
INFO - 2020-09-23 08:24:40 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:24:40 --> Controller Class Initialized
DEBUG - 2020-09-23 08:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:24:40 --> Final output sent to browser
DEBUG - 2020-09-23 08:24:40 --> Total execution time: 0.5805
INFO - 2020-09-23 08:24:55 --> Config Class Initialized
INFO - 2020-09-23 08:24:55 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:24:55 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:24:55 --> Utf8 Class Initialized
INFO - 2020-09-23 08:24:55 --> URI Class Initialized
INFO - 2020-09-23 08:24:56 --> Router Class Initialized
INFO - 2020-09-23 08:24:56 --> Output Class Initialized
INFO - 2020-09-23 08:24:56 --> Security Class Initialized
DEBUG - 2020-09-23 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:24:56 --> Input Class Initialized
INFO - 2020-09-23 08:24:56 --> Language Class Initialized
INFO - 2020-09-23 08:24:56 --> Language Class Initialized
INFO - 2020-09-23 08:24:56 --> Config Class Initialized
INFO - 2020-09-23 08:24:56 --> Loader Class Initialized
INFO - 2020-09-23 08:24:56 --> Helper loaded: url_helper
INFO - 2020-09-23 08:24:56 --> Helper loaded: file_helper
INFO - 2020-09-23 08:24:56 --> Helper loaded: form_helper
INFO - 2020-09-23 08:24:56 --> Helper loaded: my_helper
INFO - 2020-09-23 08:24:56 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:24:56 --> Controller Class Initialized
DEBUG - 2020-09-23 08:24:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-09-23 08:24:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:24:56 --> Final output sent to browser
DEBUG - 2020-09-23 08:24:56 --> Total execution time: 0.0529
INFO - 2020-09-23 08:26:11 --> Config Class Initialized
INFO - 2020-09-23 08:26:11 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:26:11 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:26:11 --> Utf8 Class Initialized
INFO - 2020-09-23 08:26:11 --> URI Class Initialized
INFO - 2020-09-23 08:26:11 --> Router Class Initialized
INFO - 2020-09-23 08:26:11 --> Output Class Initialized
INFO - 2020-09-23 08:26:11 --> Security Class Initialized
DEBUG - 2020-09-23 08:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:26:11 --> Input Class Initialized
INFO - 2020-09-23 08:26:11 --> Language Class Initialized
INFO - 2020-09-23 08:26:11 --> Language Class Initialized
INFO - 2020-09-23 08:26:11 --> Config Class Initialized
INFO - 2020-09-23 08:26:11 --> Loader Class Initialized
INFO - 2020-09-23 08:26:11 --> Helper loaded: url_helper
INFO - 2020-09-23 08:26:11 --> Helper loaded: file_helper
INFO - 2020-09-23 08:26:11 --> Helper loaded: form_helper
INFO - 2020-09-23 08:26:11 --> Helper loaded: my_helper
INFO - 2020-09-23 08:26:11 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:26:11 --> Controller Class Initialized
DEBUG - 2020-09-23 08:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-09-23 08:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:26:11 --> Final output sent to browser
DEBUG - 2020-09-23 08:26:11 --> Total execution time: 0.0535
INFO - 2020-09-23 08:26:11 --> Config Class Initialized
INFO - 2020-09-23 08:26:11 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:26:11 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:26:11 --> Utf8 Class Initialized
INFO - 2020-09-23 08:26:11 --> URI Class Initialized
INFO - 2020-09-23 08:26:11 --> Router Class Initialized
INFO - 2020-09-23 08:26:11 --> Output Class Initialized
INFO - 2020-09-23 08:26:11 --> Security Class Initialized
DEBUG - 2020-09-23 08:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:26:11 --> Input Class Initialized
INFO - 2020-09-23 08:26:11 --> Language Class Initialized
INFO - 2020-09-23 08:26:11 --> Language Class Initialized
INFO - 2020-09-23 08:26:11 --> Config Class Initialized
INFO - 2020-09-23 08:26:11 --> Loader Class Initialized
INFO - 2020-09-23 08:26:11 --> Helper loaded: url_helper
INFO - 2020-09-23 08:26:11 --> Helper loaded: file_helper
INFO - 2020-09-23 08:26:11 --> Helper loaded: form_helper
INFO - 2020-09-23 08:26:11 --> Helper loaded: my_helper
INFO - 2020-09-23 08:26:11 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:26:11 --> Controller Class Initialized
DEBUG - 2020-09-23 08:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-09-23 08:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:26:11 --> Final output sent to browser
DEBUG - 2020-09-23 08:26:11 --> Total execution time: 0.0517
INFO - 2020-09-23 08:26:23 --> Config Class Initialized
INFO - 2020-09-23 08:26:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:26:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:26:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:26:23 --> URI Class Initialized
INFO - 2020-09-23 08:26:23 --> Router Class Initialized
INFO - 2020-09-23 08:26:23 --> Output Class Initialized
INFO - 2020-09-23 08:26:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:26:23 --> Input Class Initialized
INFO - 2020-09-23 08:26:23 --> Language Class Initialized
INFO - 2020-09-23 08:26:23 --> Language Class Initialized
INFO - 2020-09-23 08:26:23 --> Config Class Initialized
INFO - 2020-09-23 08:26:23 --> Loader Class Initialized
INFO - 2020-09-23 08:26:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:26:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:26:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:26:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:26:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:26:23 --> Controller Class Initialized
INFO - 2020-09-23 08:27:17 --> Config Class Initialized
INFO - 2020-09-23 08:27:17 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:27:17 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:27:17 --> Utf8 Class Initialized
INFO - 2020-09-23 08:27:17 --> URI Class Initialized
INFO - 2020-09-23 08:27:17 --> Router Class Initialized
INFO - 2020-09-23 08:27:17 --> Output Class Initialized
INFO - 2020-09-23 08:27:17 --> Security Class Initialized
DEBUG - 2020-09-23 08:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:27:17 --> Input Class Initialized
INFO - 2020-09-23 08:27:17 --> Language Class Initialized
INFO - 2020-09-23 08:27:17 --> Language Class Initialized
INFO - 2020-09-23 08:27:17 --> Config Class Initialized
INFO - 2020-09-23 08:27:17 --> Loader Class Initialized
INFO - 2020-09-23 08:27:17 --> Helper loaded: url_helper
INFO - 2020-09-23 08:27:17 --> Helper loaded: file_helper
INFO - 2020-09-23 08:27:17 --> Helper loaded: form_helper
INFO - 2020-09-23 08:27:17 --> Helper loaded: my_helper
INFO - 2020-09-23 08:27:17 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:27:17 --> Controller Class Initialized
INFO - 2020-09-23 08:27:17 --> Final output sent to browser
DEBUG - 2020-09-23 08:27:17 --> Total execution time: 0.1131
INFO - 2020-09-23 08:27:17 --> Config Class Initialized
INFO - 2020-09-23 08:27:17 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:27:17 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:27:17 --> Utf8 Class Initialized
INFO - 2020-09-23 08:27:17 --> URI Class Initialized
INFO - 2020-09-23 08:27:17 --> Router Class Initialized
INFO - 2020-09-23 08:27:17 --> Output Class Initialized
INFO - 2020-09-23 08:27:17 --> Security Class Initialized
DEBUG - 2020-09-23 08:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:27:17 --> Input Class Initialized
INFO - 2020-09-23 08:27:17 --> Language Class Initialized
INFO - 2020-09-23 08:27:17 --> Language Class Initialized
INFO - 2020-09-23 08:27:17 --> Config Class Initialized
INFO - 2020-09-23 08:27:17 --> Loader Class Initialized
INFO - 2020-09-23 08:27:17 --> Helper loaded: url_helper
INFO - 2020-09-23 08:27:17 --> Helper loaded: file_helper
INFO - 2020-09-23 08:27:17 --> Helper loaded: form_helper
INFO - 2020-09-23 08:27:17 --> Helper loaded: my_helper
INFO - 2020-09-23 08:27:17 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:27:17 --> Controller Class Initialized
INFO - 2020-09-23 08:27:17 --> Final output sent to browser
DEBUG - 2020-09-23 08:27:17 --> Total execution time: 0.0571
INFO - 2020-09-23 08:27:43 --> Config Class Initialized
INFO - 2020-09-23 08:27:43 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:27:43 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:27:43 --> Utf8 Class Initialized
INFO - 2020-09-23 08:27:43 --> URI Class Initialized
INFO - 2020-09-23 08:27:43 --> Router Class Initialized
INFO - 2020-09-23 08:27:43 --> Output Class Initialized
INFO - 2020-09-23 08:27:43 --> Security Class Initialized
DEBUG - 2020-09-23 08:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:27:43 --> Input Class Initialized
INFO - 2020-09-23 08:27:43 --> Language Class Initialized
INFO - 2020-09-23 08:27:43 --> Language Class Initialized
INFO - 2020-09-23 08:27:43 --> Config Class Initialized
INFO - 2020-09-23 08:27:43 --> Loader Class Initialized
INFO - 2020-09-23 08:27:43 --> Helper loaded: url_helper
INFO - 2020-09-23 08:27:43 --> Helper loaded: file_helper
INFO - 2020-09-23 08:27:44 --> Helper loaded: form_helper
INFO - 2020-09-23 08:27:44 --> Helper loaded: my_helper
INFO - 2020-09-23 08:27:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:27:44 --> Controller Class Initialized
INFO - 2020-09-23 08:27:45 --> Final output sent to browser
DEBUG - 2020-09-23 08:27:45 --> Total execution time: 1.2575
INFO - 2020-09-23 08:28:08 --> Config Class Initialized
INFO - 2020-09-23 08:28:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:28:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:28:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:28:08 --> URI Class Initialized
INFO - 2020-09-23 08:28:08 --> Router Class Initialized
INFO - 2020-09-23 08:28:08 --> Output Class Initialized
INFO - 2020-09-23 08:28:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:28:08 --> Input Class Initialized
INFO - 2020-09-23 08:28:08 --> Language Class Initialized
INFO - 2020-09-23 08:28:08 --> Language Class Initialized
INFO - 2020-09-23 08:28:08 --> Config Class Initialized
INFO - 2020-09-23 08:28:08 --> Loader Class Initialized
INFO - 2020-09-23 08:28:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:28:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:28:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:28:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:28:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:28:08 --> Controller Class Initialized
INFO - 2020-09-23 08:28:08 --> Final output sent to browser
DEBUG - 2020-09-23 08:28:08 --> Total execution time: 0.0855
INFO - 2020-09-23 08:28:25 --> Config Class Initialized
INFO - 2020-09-23 08:28:25 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:28:25 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:28:25 --> Utf8 Class Initialized
INFO - 2020-09-23 08:28:25 --> URI Class Initialized
INFO - 2020-09-23 08:28:25 --> Router Class Initialized
INFO - 2020-09-23 08:28:25 --> Output Class Initialized
INFO - 2020-09-23 08:28:25 --> Security Class Initialized
DEBUG - 2020-09-23 08:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:28:25 --> Input Class Initialized
INFO - 2020-09-23 08:28:25 --> Language Class Initialized
INFO - 2020-09-23 08:28:25 --> Language Class Initialized
INFO - 2020-09-23 08:28:25 --> Config Class Initialized
INFO - 2020-09-23 08:28:25 --> Loader Class Initialized
INFO - 2020-09-23 08:28:25 --> Helper loaded: url_helper
INFO - 2020-09-23 08:28:25 --> Helper loaded: file_helper
INFO - 2020-09-23 08:28:25 --> Helper loaded: form_helper
INFO - 2020-09-23 08:28:25 --> Helper loaded: my_helper
INFO - 2020-09-23 08:28:25 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:28:25 --> Controller Class Initialized
INFO - 2020-09-23 08:28:25 --> Final output sent to browser
DEBUG - 2020-09-23 08:28:25 --> Total execution time: 0.0525
INFO - 2020-09-23 08:28:26 --> Config Class Initialized
INFO - 2020-09-23 08:28:26 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:28:26 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:28:26 --> Utf8 Class Initialized
INFO - 2020-09-23 08:28:26 --> URI Class Initialized
INFO - 2020-09-23 08:28:26 --> Router Class Initialized
INFO - 2020-09-23 08:28:26 --> Output Class Initialized
INFO - 2020-09-23 08:28:26 --> Security Class Initialized
DEBUG - 2020-09-23 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:28:26 --> Input Class Initialized
INFO - 2020-09-23 08:28:26 --> Language Class Initialized
INFO - 2020-09-23 08:28:26 --> Language Class Initialized
INFO - 2020-09-23 08:28:26 --> Config Class Initialized
INFO - 2020-09-23 08:28:26 --> Loader Class Initialized
INFO - 2020-09-23 08:28:26 --> Helper loaded: url_helper
INFO - 2020-09-23 08:28:26 --> Helper loaded: file_helper
INFO - 2020-09-23 08:28:26 --> Helper loaded: form_helper
INFO - 2020-09-23 08:28:26 --> Helper loaded: my_helper
INFO - 2020-09-23 08:28:26 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:28:26 --> Controller Class Initialized
INFO - 2020-09-23 08:28:26 --> Final output sent to browser
DEBUG - 2020-09-23 08:28:26 --> Total execution time: 0.0522
INFO - 2020-09-23 08:28:39 --> Config Class Initialized
INFO - 2020-09-23 08:28:39 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:28:39 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:28:39 --> Utf8 Class Initialized
INFO - 2020-09-23 08:28:39 --> URI Class Initialized
INFO - 2020-09-23 08:28:39 --> Router Class Initialized
INFO - 2020-09-23 08:28:39 --> Output Class Initialized
INFO - 2020-09-23 08:28:39 --> Security Class Initialized
DEBUG - 2020-09-23 08:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:28:39 --> Input Class Initialized
INFO - 2020-09-23 08:28:39 --> Language Class Initialized
INFO - 2020-09-23 08:28:39 --> Language Class Initialized
INFO - 2020-09-23 08:28:39 --> Config Class Initialized
INFO - 2020-09-23 08:28:39 --> Loader Class Initialized
INFO - 2020-09-23 08:28:39 --> Helper loaded: url_helper
INFO - 2020-09-23 08:28:39 --> Helper loaded: file_helper
INFO - 2020-09-23 08:28:39 --> Helper loaded: form_helper
INFO - 2020-09-23 08:28:39 --> Helper loaded: my_helper
INFO - 2020-09-23 08:28:39 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:28:39 --> Controller Class Initialized
INFO - 2020-09-23 08:28:40 --> Final output sent to browser
DEBUG - 2020-09-23 08:28:40 --> Total execution time: 1.3335
INFO - 2020-09-23 08:28:41 --> Config Class Initialized
INFO - 2020-09-23 08:28:41 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:28:41 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:28:41 --> Utf8 Class Initialized
INFO - 2020-09-23 08:28:41 --> URI Class Initialized
INFO - 2020-09-23 08:28:41 --> Router Class Initialized
INFO - 2020-09-23 08:28:41 --> Output Class Initialized
INFO - 2020-09-23 08:28:41 --> Security Class Initialized
DEBUG - 2020-09-23 08:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:28:41 --> Input Class Initialized
INFO - 2020-09-23 08:28:41 --> Language Class Initialized
INFO - 2020-09-23 08:28:41 --> Language Class Initialized
INFO - 2020-09-23 08:28:41 --> Config Class Initialized
INFO - 2020-09-23 08:28:41 --> Loader Class Initialized
INFO - 2020-09-23 08:28:41 --> Helper loaded: url_helper
INFO - 2020-09-23 08:28:41 --> Helper loaded: file_helper
INFO - 2020-09-23 08:28:41 --> Helper loaded: form_helper
INFO - 2020-09-23 08:28:41 --> Helper loaded: my_helper
INFO - 2020-09-23 08:28:41 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:28:41 --> Controller Class Initialized
INFO - 2020-09-23 08:28:41 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:28:41 --> Final output sent to browser
DEBUG - 2020-09-23 08:28:41 --> Total execution time: 0.0543
INFO - 2020-09-23 08:28:42 --> Config Class Initialized
INFO - 2020-09-23 08:28:42 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:28:42 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:28:42 --> Utf8 Class Initialized
INFO - 2020-09-23 08:28:42 --> URI Class Initialized
INFO - 2020-09-23 08:28:42 --> Router Class Initialized
INFO - 2020-09-23 08:28:42 --> Output Class Initialized
INFO - 2020-09-23 08:28:42 --> Security Class Initialized
DEBUG - 2020-09-23 08:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:28:42 --> Input Class Initialized
INFO - 2020-09-23 08:28:42 --> Language Class Initialized
INFO - 2020-09-23 08:28:42 --> Language Class Initialized
INFO - 2020-09-23 08:28:42 --> Config Class Initialized
INFO - 2020-09-23 08:28:42 --> Loader Class Initialized
INFO - 2020-09-23 08:28:42 --> Helper loaded: url_helper
INFO - 2020-09-23 08:28:42 --> Helper loaded: file_helper
INFO - 2020-09-23 08:28:42 --> Helper loaded: form_helper
INFO - 2020-09-23 08:28:42 --> Helper loaded: my_helper
INFO - 2020-09-23 08:28:42 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:28:42 --> Controller Class Initialized
DEBUG - 2020-09-23 08:28:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:28:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:28:43 --> Final output sent to browser
DEBUG - 2020-09-23 08:28:43 --> Total execution time: 0.6678
INFO - 2020-09-23 08:28:56 --> Config Class Initialized
INFO - 2020-09-23 08:28:56 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:28:56 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:28:56 --> Utf8 Class Initialized
INFO - 2020-09-23 08:28:56 --> URI Class Initialized
INFO - 2020-09-23 08:28:56 --> Router Class Initialized
INFO - 2020-09-23 08:28:56 --> Output Class Initialized
INFO - 2020-09-23 08:28:56 --> Security Class Initialized
DEBUG - 2020-09-23 08:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:28:56 --> Input Class Initialized
INFO - 2020-09-23 08:28:56 --> Language Class Initialized
INFO - 2020-09-23 08:28:56 --> Language Class Initialized
INFO - 2020-09-23 08:28:56 --> Config Class Initialized
INFO - 2020-09-23 08:28:56 --> Loader Class Initialized
INFO - 2020-09-23 08:28:56 --> Helper loaded: url_helper
INFO - 2020-09-23 08:28:56 --> Helper loaded: file_helper
INFO - 2020-09-23 08:28:56 --> Helper loaded: form_helper
INFO - 2020-09-23 08:28:56 --> Helper loaded: my_helper
INFO - 2020-09-23 08:28:56 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:28:57 --> Controller Class Initialized
INFO - 2020-09-23 08:28:57 --> Final output sent to browser
DEBUG - 2020-09-23 08:28:57 --> Total execution time: 0.1132
INFO - 2020-09-23 08:29:08 --> Config Class Initialized
INFO - 2020-09-23 08:29:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:08 --> URI Class Initialized
INFO - 2020-09-23 08:29:08 --> Router Class Initialized
INFO - 2020-09-23 08:29:08 --> Output Class Initialized
INFO - 2020-09-23 08:29:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:08 --> Input Class Initialized
INFO - 2020-09-23 08:29:08 --> Language Class Initialized
INFO - 2020-09-23 08:29:08 --> Language Class Initialized
INFO - 2020-09-23 08:29:08 --> Config Class Initialized
INFO - 2020-09-23 08:29:08 --> Loader Class Initialized
INFO - 2020-09-23 08:29:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:08 --> Controller Class Initialized
INFO - 2020-09-23 08:29:09 --> Final output sent to browser
DEBUG - 2020-09-23 08:29:09 --> Total execution time: 1.3140
INFO - 2020-09-23 08:29:15 --> Config Class Initialized
INFO - 2020-09-23 08:29:15 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:15 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:15 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:15 --> URI Class Initialized
INFO - 2020-09-23 08:29:15 --> Router Class Initialized
INFO - 2020-09-23 08:29:15 --> Output Class Initialized
INFO - 2020-09-23 08:29:15 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:15 --> Input Class Initialized
INFO - 2020-09-23 08:29:15 --> Language Class Initialized
INFO - 2020-09-23 08:29:15 --> Language Class Initialized
INFO - 2020-09-23 08:29:15 --> Config Class Initialized
INFO - 2020-09-23 08:29:15 --> Loader Class Initialized
INFO - 2020-09-23 08:29:15 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:15 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:15 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:15 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:15 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:15 --> Controller Class Initialized
INFO - 2020-09-23 08:29:15 --> Final output sent to browser
DEBUG - 2020-09-23 08:29:15 --> Total execution time: 0.0669
INFO - 2020-09-23 08:29:36 --> Config Class Initialized
INFO - 2020-09-23 08:29:36 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:36 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:36 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:36 --> URI Class Initialized
INFO - 2020-09-23 08:29:36 --> Router Class Initialized
INFO - 2020-09-23 08:29:36 --> Output Class Initialized
INFO - 2020-09-23 08:29:36 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:36 --> Input Class Initialized
INFO - 2020-09-23 08:29:36 --> Language Class Initialized
INFO - 2020-09-23 08:29:36 --> Language Class Initialized
INFO - 2020-09-23 08:29:36 --> Config Class Initialized
INFO - 2020-09-23 08:29:36 --> Loader Class Initialized
INFO - 2020-09-23 08:29:36 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:36 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:36 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:36 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:36 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:36 --> Controller Class Initialized
INFO - 2020-09-23 08:29:38 --> Final output sent to browser
DEBUG - 2020-09-23 08:29:38 --> Total execution time: 1.2802
INFO - 2020-09-23 08:29:44 --> Config Class Initialized
INFO - 2020-09-23 08:29:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:44 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:44 --> URI Class Initialized
INFO - 2020-09-23 08:29:44 --> Router Class Initialized
INFO - 2020-09-23 08:29:44 --> Output Class Initialized
INFO - 2020-09-23 08:29:44 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:44 --> Input Class Initialized
INFO - 2020-09-23 08:29:44 --> Language Class Initialized
INFO - 2020-09-23 08:29:44 --> Language Class Initialized
INFO - 2020-09-23 08:29:44 --> Config Class Initialized
INFO - 2020-09-23 08:29:44 --> Loader Class Initialized
INFO - 2020-09-23 08:29:44 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:44 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:44 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:44 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:44 --> Controller Class Initialized
DEBUG - 2020-09-23 08:29:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-09-23 08:29:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:29:44 --> Final output sent to browser
DEBUG - 2020-09-23 08:29:44 --> Total execution time: 0.0470
INFO - 2020-09-23 08:29:45 --> Config Class Initialized
INFO - 2020-09-23 08:29:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:45 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:45 --> URI Class Initialized
INFO - 2020-09-23 08:29:45 --> Router Class Initialized
INFO - 2020-09-23 08:29:45 --> Output Class Initialized
INFO - 2020-09-23 08:29:45 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:45 --> Input Class Initialized
INFO - 2020-09-23 08:29:45 --> Language Class Initialized
INFO - 2020-09-23 08:29:45 --> Language Class Initialized
INFO - 2020-09-23 08:29:45 --> Config Class Initialized
INFO - 2020-09-23 08:29:45 --> Loader Class Initialized
INFO - 2020-09-23 08:29:45 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:45 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:45 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:45 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:45 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:45 --> Controller Class Initialized
DEBUG - 2020-09-23 08:29:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:29:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:29:45 --> Final output sent to browser
DEBUG - 2020-09-23 08:29:45 --> Total execution time: 0.6249
INFO - 2020-09-23 08:29:46 --> Config Class Initialized
INFO - 2020-09-23 08:29:46 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:46 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:46 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:46 --> URI Class Initialized
INFO - 2020-09-23 08:29:46 --> Router Class Initialized
INFO - 2020-09-23 08:29:46 --> Output Class Initialized
INFO - 2020-09-23 08:29:46 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:46 --> Input Class Initialized
INFO - 2020-09-23 08:29:46 --> Language Class Initialized
INFO - 2020-09-23 08:29:46 --> Language Class Initialized
INFO - 2020-09-23 08:29:46 --> Config Class Initialized
INFO - 2020-09-23 08:29:46 --> Loader Class Initialized
INFO - 2020-09-23 08:29:46 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:46 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:46 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:46 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:46 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:46 --> Controller Class Initialized
DEBUG - 2020-09-23 08:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-09-23 08:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:29:46 --> Final output sent to browser
DEBUG - 2020-09-23 08:29:46 --> Total execution time: 0.0516
INFO - 2020-09-23 08:29:46 --> Config Class Initialized
INFO - 2020-09-23 08:29:46 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:46 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:46 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:46 --> URI Class Initialized
INFO - 2020-09-23 08:29:46 --> Router Class Initialized
INFO - 2020-09-23 08:29:46 --> Output Class Initialized
INFO - 2020-09-23 08:29:46 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:46 --> Input Class Initialized
INFO - 2020-09-23 08:29:46 --> Language Class Initialized
INFO - 2020-09-23 08:29:46 --> Language Class Initialized
INFO - 2020-09-23 08:29:46 --> Config Class Initialized
INFO - 2020-09-23 08:29:46 --> Loader Class Initialized
INFO - 2020-09-23 08:29:46 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:46 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:46 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:46 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:46 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:46 --> Controller Class Initialized
INFO - 2020-09-23 08:29:51 --> Config Class Initialized
INFO - 2020-09-23 08:29:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:29:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:29:51 --> Utf8 Class Initialized
INFO - 2020-09-23 08:29:51 --> URI Class Initialized
INFO - 2020-09-23 08:29:51 --> Router Class Initialized
INFO - 2020-09-23 08:29:51 --> Output Class Initialized
INFO - 2020-09-23 08:29:51 --> Security Class Initialized
DEBUG - 2020-09-23 08:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:29:51 --> Input Class Initialized
INFO - 2020-09-23 08:29:51 --> Language Class Initialized
INFO - 2020-09-23 08:29:51 --> Language Class Initialized
INFO - 2020-09-23 08:29:51 --> Config Class Initialized
INFO - 2020-09-23 08:29:51 --> Loader Class Initialized
INFO - 2020-09-23 08:29:51 --> Helper loaded: url_helper
INFO - 2020-09-23 08:29:51 --> Helper loaded: file_helper
INFO - 2020-09-23 08:29:51 --> Helper loaded: form_helper
INFO - 2020-09-23 08:29:51 --> Helper loaded: my_helper
INFO - 2020-09-23 08:29:51 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:29:51 --> Controller Class Initialized
ERROR - 2020-09-23 08:29:51 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-09-23 08:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-09-23 08:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:29:51 --> Final output sent to browser
DEBUG - 2020-09-23 08:29:51 --> Total execution time: 0.0550
INFO - 2020-09-23 08:30:07 --> Config Class Initialized
INFO - 2020-09-23 08:30:07 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:07 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:07 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:07 --> URI Class Initialized
INFO - 2020-09-23 08:30:07 --> Router Class Initialized
INFO - 2020-09-23 08:30:07 --> Output Class Initialized
INFO - 2020-09-23 08:30:07 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:07 --> Input Class Initialized
INFO - 2020-09-23 08:30:07 --> Language Class Initialized
INFO - 2020-09-23 08:30:07 --> Language Class Initialized
INFO - 2020-09-23 08:30:07 --> Config Class Initialized
INFO - 2020-09-23 08:30:07 --> Loader Class Initialized
INFO - 2020-09-23 08:30:07 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:07 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:07 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:07 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:07 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:07 --> Controller Class Initialized
DEBUG - 2020-09-23 08:30:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-09-23 08:30:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:30:07 --> Final output sent to browser
DEBUG - 2020-09-23 08:30:07 --> Total execution time: 0.0511
INFO - 2020-09-23 08:30:30 --> Config Class Initialized
INFO - 2020-09-23 08:30:30 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:30 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:30 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:30 --> URI Class Initialized
INFO - 2020-09-23 08:30:30 --> Router Class Initialized
INFO - 2020-09-23 08:30:30 --> Output Class Initialized
INFO - 2020-09-23 08:30:30 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:30 --> Input Class Initialized
INFO - 2020-09-23 08:30:30 --> Language Class Initialized
INFO - 2020-09-23 08:30:30 --> Language Class Initialized
INFO - 2020-09-23 08:30:30 --> Config Class Initialized
INFO - 2020-09-23 08:30:30 --> Loader Class Initialized
INFO - 2020-09-23 08:30:30 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:30 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:30 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:30 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:30 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:30 --> Controller Class Initialized
DEBUG - 2020-09-23 08:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-09-23 08:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:30:30 --> Final output sent to browser
DEBUG - 2020-09-23 08:30:30 --> Total execution time: 0.0474
INFO - 2020-09-23 08:30:30 --> Config Class Initialized
INFO - 2020-09-23 08:30:30 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:30 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:30 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:30 --> URI Class Initialized
INFO - 2020-09-23 08:30:30 --> Router Class Initialized
INFO - 2020-09-23 08:30:30 --> Output Class Initialized
INFO - 2020-09-23 08:30:30 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:30 --> Input Class Initialized
INFO - 2020-09-23 08:30:30 --> Language Class Initialized
INFO - 2020-09-23 08:30:30 --> Language Class Initialized
INFO - 2020-09-23 08:30:30 --> Config Class Initialized
INFO - 2020-09-23 08:30:30 --> Loader Class Initialized
INFO - 2020-09-23 08:30:30 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:30 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:30 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:30 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:30 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:30 --> Controller Class Initialized
DEBUG - 2020-09-23 08:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-09-23 08:30:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:30:30 --> Final output sent to browser
DEBUG - 2020-09-23 08:30:30 --> Total execution time: 0.0521
INFO - 2020-09-23 08:30:47 --> Config Class Initialized
INFO - 2020-09-23 08:30:47 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:47 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:47 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:47 --> URI Class Initialized
INFO - 2020-09-23 08:30:47 --> Router Class Initialized
INFO - 2020-09-23 08:30:47 --> Output Class Initialized
INFO - 2020-09-23 08:30:47 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:47 --> Input Class Initialized
INFO - 2020-09-23 08:30:47 --> Language Class Initialized
INFO - 2020-09-23 08:30:47 --> Language Class Initialized
INFO - 2020-09-23 08:30:47 --> Config Class Initialized
INFO - 2020-09-23 08:30:47 --> Loader Class Initialized
INFO - 2020-09-23 08:30:47 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:47 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:47 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:47 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:47 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:47 --> Controller Class Initialized
INFO - 2020-09-23 08:30:47 --> Final output sent to browser
DEBUG - 2020-09-23 08:30:47 --> Total execution time: 0.1112
INFO - 2020-09-23 08:30:51 --> Config Class Initialized
INFO - 2020-09-23 08:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:51 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:51 --> URI Class Initialized
INFO - 2020-09-23 08:30:51 --> Router Class Initialized
INFO - 2020-09-23 08:30:51 --> Output Class Initialized
INFO - 2020-09-23 08:30:51 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:51 --> Input Class Initialized
INFO - 2020-09-23 08:30:51 --> Language Class Initialized
INFO - 2020-09-23 08:30:51 --> Language Class Initialized
INFO - 2020-09-23 08:30:51 --> Config Class Initialized
INFO - 2020-09-23 08:30:51 --> Loader Class Initialized
INFO - 2020-09-23 08:30:51 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:51 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:51 --> Controller Class Initialized
INFO - 2020-09-23 08:30:51 --> Upload Class Initialized
INFO - 2020-09-23 08:30:51 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-09-23 08:30:51 --> The upload path does not appear to be valid.
INFO - 2020-09-23 08:30:51 --> Config Class Initialized
INFO - 2020-09-23 08:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:51 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:51 --> URI Class Initialized
INFO - 2020-09-23 08:30:51 --> Router Class Initialized
INFO - 2020-09-23 08:30:51 --> Output Class Initialized
INFO - 2020-09-23 08:30:51 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:51 --> Input Class Initialized
INFO - 2020-09-23 08:30:51 --> Language Class Initialized
INFO - 2020-09-23 08:30:51 --> Language Class Initialized
INFO - 2020-09-23 08:30:51 --> Config Class Initialized
INFO - 2020-09-23 08:30:51 --> Loader Class Initialized
INFO - 2020-09-23 08:30:51 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:51 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:51 --> Controller Class Initialized
DEBUG - 2020-09-23 08:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-09-23 08:30:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:30:51 --> Final output sent to browser
DEBUG - 2020-09-23 08:30:51 --> Total execution time: 0.0506
INFO - 2020-09-23 08:30:51 --> Config Class Initialized
INFO - 2020-09-23 08:30:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:51 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:51 --> URI Class Initialized
INFO - 2020-09-23 08:30:51 --> Router Class Initialized
INFO - 2020-09-23 08:30:51 --> Output Class Initialized
INFO - 2020-09-23 08:30:51 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:51 --> Input Class Initialized
INFO - 2020-09-23 08:30:51 --> Language Class Initialized
INFO - 2020-09-23 08:30:51 --> Language Class Initialized
INFO - 2020-09-23 08:30:51 --> Config Class Initialized
INFO - 2020-09-23 08:30:51 --> Loader Class Initialized
INFO - 2020-09-23 08:30:51 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:51 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:51 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:51 --> Controller Class Initialized
INFO - 2020-09-23 08:30:55 --> Config Class Initialized
INFO - 2020-09-23 08:30:55 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:55 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:55 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:55 --> URI Class Initialized
INFO - 2020-09-23 08:30:55 --> Router Class Initialized
INFO - 2020-09-23 08:30:55 --> Output Class Initialized
INFO - 2020-09-23 08:30:55 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:55 --> Input Class Initialized
INFO - 2020-09-23 08:30:55 --> Language Class Initialized
INFO - 2020-09-23 08:30:55 --> Language Class Initialized
INFO - 2020-09-23 08:30:55 --> Config Class Initialized
INFO - 2020-09-23 08:30:55 --> Loader Class Initialized
INFO - 2020-09-23 08:30:55 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:55 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:55 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:55 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:55 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:55 --> Controller Class Initialized
INFO - 2020-09-23 08:30:59 --> Config Class Initialized
INFO - 2020-09-23 08:30:59 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:59 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:59 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:59 --> URI Class Initialized
INFO - 2020-09-23 08:30:59 --> Router Class Initialized
INFO - 2020-09-23 08:30:59 --> Output Class Initialized
INFO - 2020-09-23 08:30:59 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:59 --> Input Class Initialized
INFO - 2020-09-23 08:30:59 --> Language Class Initialized
INFO - 2020-09-23 08:30:59 --> Language Class Initialized
INFO - 2020-09-23 08:30:59 --> Config Class Initialized
INFO - 2020-09-23 08:30:59 --> Loader Class Initialized
INFO - 2020-09-23 08:30:59 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:59 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:59 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:59 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:59 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:59 --> Controller Class Initialized
INFO - 2020-09-23 08:30:59 --> Config Class Initialized
INFO - 2020-09-23 08:30:59 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:30:59 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:30:59 --> Utf8 Class Initialized
INFO - 2020-09-23 08:30:59 --> URI Class Initialized
INFO - 2020-09-23 08:30:59 --> Router Class Initialized
INFO - 2020-09-23 08:30:59 --> Output Class Initialized
INFO - 2020-09-23 08:30:59 --> Security Class Initialized
DEBUG - 2020-09-23 08:30:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:30:59 --> Input Class Initialized
INFO - 2020-09-23 08:30:59 --> Language Class Initialized
INFO - 2020-09-23 08:30:59 --> Language Class Initialized
INFO - 2020-09-23 08:30:59 --> Config Class Initialized
INFO - 2020-09-23 08:30:59 --> Loader Class Initialized
INFO - 2020-09-23 08:30:59 --> Helper loaded: url_helper
INFO - 2020-09-23 08:30:59 --> Helper loaded: file_helper
INFO - 2020-09-23 08:30:59 --> Helper loaded: form_helper
INFO - 2020-09-23 08:30:59 --> Helper loaded: my_helper
INFO - 2020-09-23 08:30:59 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:30:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:30:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:30:59 --> Controller Class Initialized
INFO - 2020-09-23 08:31:00 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:00 --> Total execution time: 1.1411
INFO - 2020-09-23 08:31:01 --> Config Class Initialized
INFO - 2020-09-23 08:31:01 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:01 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:01 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:01 --> URI Class Initialized
INFO - 2020-09-23 08:31:01 --> Router Class Initialized
INFO - 2020-09-23 08:31:01 --> Output Class Initialized
INFO - 2020-09-23 08:31:01 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:01 --> Input Class Initialized
INFO - 2020-09-23 08:31:01 --> Language Class Initialized
INFO - 2020-09-23 08:31:01 --> Language Class Initialized
INFO - 2020-09-23 08:31:01 --> Config Class Initialized
INFO - 2020-09-23 08:31:01 --> Loader Class Initialized
INFO - 2020-09-23 08:31:01 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:01 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:01 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:01 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:01 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:01 --> Controller Class Initialized
INFO - 2020-09-23 08:31:06 --> Config Class Initialized
INFO - 2020-09-23 08:31:06 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:06 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:06 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:06 --> URI Class Initialized
INFO - 2020-09-23 08:31:06 --> Router Class Initialized
INFO - 2020-09-23 08:31:06 --> Output Class Initialized
INFO - 2020-09-23 08:31:06 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:06 --> Input Class Initialized
INFO - 2020-09-23 08:31:06 --> Language Class Initialized
INFO - 2020-09-23 08:31:06 --> Language Class Initialized
INFO - 2020-09-23 08:31:06 --> Config Class Initialized
INFO - 2020-09-23 08:31:06 --> Loader Class Initialized
INFO - 2020-09-23 08:31:06 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:06 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:06 --> Controller Class Initialized
INFO - 2020-09-23 08:31:06 --> Config Class Initialized
INFO - 2020-09-23 08:31:06 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:06 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:06 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:06 --> URI Class Initialized
INFO - 2020-09-23 08:31:06 --> Router Class Initialized
INFO - 2020-09-23 08:31:06 --> Output Class Initialized
INFO - 2020-09-23 08:31:06 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:06 --> Total execution time: 0.0613
INFO - 2020-09-23 08:31:06 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:06 --> Input Class Initialized
INFO - 2020-09-23 08:31:06 --> Language Class Initialized
INFO - 2020-09-23 08:31:06 --> Language Class Initialized
INFO - 2020-09-23 08:31:06 --> Config Class Initialized
INFO - 2020-09-23 08:31:06 --> Loader Class Initialized
INFO - 2020-09-23 08:31:06 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:06 --> Config Class Initialized
INFO - 2020-09-23 08:31:06 --> Hooks Class Initialized
INFO - 2020-09-23 08:31:06 --> Helper loaded: my_helper
DEBUG - 2020-09-23 08:31:06 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:06 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:06 --> URI Class Initialized
INFO - 2020-09-23 08:31:06 --> Database Driver Class Initialized
INFO - 2020-09-23 08:31:06 --> Router Class Initialized
INFO - 2020-09-23 08:31:06 --> Output Class Initialized
INFO - 2020-09-23 08:31:06 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:06 --> Session: Class initialized using 'files' driver.
DEBUG - 2020-09-23 08:31:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:06 --> Input Class Initialized
INFO - 2020-09-23 08:31:06 --> Controller Class Initialized
INFO - 2020-09-23 08:31:06 --> Language Class Initialized
INFO - 2020-09-23 08:31:06 --> Language Class Initialized
INFO - 2020-09-23 08:31:06 --> Config Class Initialized
INFO - 2020-09-23 08:31:06 --> Loader Class Initialized
INFO - 2020-09-23 08:31:06 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:06 --> Helper loaded: my_helper
DEBUG - 2020-09-23 08:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-23 08:31:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:06 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:06 --> Total execution time: 0.0565
INFO - 2020-09-23 08:31:06 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:06 --> Controller Class Initialized
INFO - 2020-09-23 08:31:06 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:06 --> Total execution time: 0.0693
INFO - 2020-09-23 08:31:08 --> Config Class Initialized
INFO - 2020-09-23 08:31:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:08 --> URI Class Initialized
INFO - 2020-09-23 08:31:08 --> Router Class Initialized
INFO - 2020-09-23 08:31:08 --> Output Class Initialized
INFO - 2020-09-23 08:31:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:08 --> Input Class Initialized
INFO - 2020-09-23 08:31:08 --> Language Class Initialized
INFO - 2020-09-23 08:31:08 --> Language Class Initialized
INFO - 2020-09-23 08:31:08 --> Config Class Initialized
INFO - 2020-09-23 08:31:08 --> Loader Class Initialized
INFO - 2020-09-23 08:31:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:08 --> Controller Class Initialized
DEBUG - 2020-09-23 08:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-09-23 08:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:08 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:08 --> Total execution time: 0.0545
INFO - 2020-09-23 08:31:14 --> Config Class Initialized
INFO - 2020-09-23 08:31:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:14 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:14 --> URI Class Initialized
INFO - 2020-09-23 08:31:14 --> Router Class Initialized
INFO - 2020-09-23 08:31:14 --> Output Class Initialized
INFO - 2020-09-23 08:31:14 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:14 --> Input Class Initialized
INFO - 2020-09-23 08:31:14 --> Language Class Initialized
INFO - 2020-09-23 08:31:14 --> Language Class Initialized
INFO - 2020-09-23 08:31:14 --> Config Class Initialized
INFO - 2020-09-23 08:31:14 --> Loader Class Initialized
INFO - 2020-09-23 08:31:14 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:14 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:14 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:14 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:14 --> Controller Class Initialized
INFO - 2020-09-23 08:31:14 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:14 --> Total execution time: 0.0532
INFO - 2020-09-23 08:31:14 --> Config Class Initialized
INFO - 2020-09-23 08:31:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:15 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:15 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:15 --> URI Class Initialized
INFO - 2020-09-23 08:31:15 --> Router Class Initialized
INFO - 2020-09-23 08:31:15 --> Output Class Initialized
INFO - 2020-09-23 08:31:15 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:15 --> Input Class Initialized
INFO - 2020-09-23 08:31:15 --> Language Class Initialized
INFO - 2020-09-23 08:31:15 --> Language Class Initialized
INFO - 2020-09-23 08:31:15 --> Config Class Initialized
INFO - 2020-09-23 08:31:15 --> Loader Class Initialized
INFO - 2020-09-23 08:31:15 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:15 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:15 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:15 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:15 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:15 --> Controller Class Initialized
INFO - 2020-09-23 08:31:15 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:15 --> Total execution time: 0.0533
INFO - 2020-09-23 08:31:16 --> Config Class Initialized
INFO - 2020-09-23 08:31:16 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:16 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:16 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:16 --> URI Class Initialized
INFO - 2020-09-23 08:31:16 --> Router Class Initialized
INFO - 2020-09-23 08:31:16 --> Output Class Initialized
INFO - 2020-09-23 08:31:16 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:16 --> Input Class Initialized
INFO - 2020-09-23 08:31:16 --> Language Class Initialized
INFO - 2020-09-23 08:31:16 --> Language Class Initialized
INFO - 2020-09-23 08:31:16 --> Config Class Initialized
INFO - 2020-09-23 08:31:16 --> Loader Class Initialized
INFO - 2020-09-23 08:31:16 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:16 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:16 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:16 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:16 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:16 --> Controller Class Initialized
INFO - 2020-09-23 08:31:16 --> Config Class Initialized
INFO - 2020-09-23 08:31:16 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:16 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:16 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:16 --> URI Class Initialized
INFO - 2020-09-23 08:31:16 --> Router Class Initialized
INFO - 2020-09-23 08:31:16 --> Output Class Initialized
INFO - 2020-09-23 08:31:16 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:16 --> Input Class Initialized
INFO - 2020-09-23 08:31:16 --> Language Class Initialized
INFO - 2020-09-23 08:31:16 --> Language Class Initialized
INFO - 2020-09-23 08:31:16 --> Config Class Initialized
INFO - 2020-09-23 08:31:16 --> Loader Class Initialized
INFO - 2020-09-23 08:31:16 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:16 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:16 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:16 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:16 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:16 --> Controller Class Initialized
DEBUG - 2020-09-23 08:31:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-09-23 08:31:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:16 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:16 --> Total execution time: 0.0630
INFO - 2020-09-23 08:31:20 --> Config Class Initialized
INFO - 2020-09-23 08:31:20 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:20 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:20 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:20 --> URI Class Initialized
INFO - 2020-09-23 08:31:20 --> Router Class Initialized
INFO - 2020-09-23 08:31:20 --> Output Class Initialized
INFO - 2020-09-23 08:31:20 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:20 --> Input Class Initialized
INFO - 2020-09-23 08:31:20 --> Language Class Initialized
INFO - 2020-09-23 08:31:20 --> Language Class Initialized
INFO - 2020-09-23 08:31:20 --> Config Class Initialized
INFO - 2020-09-23 08:31:20 --> Loader Class Initialized
INFO - 2020-09-23 08:31:20 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:20 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:20 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:20 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:20 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:20 --> Controller Class Initialized
INFO - 2020-09-23 08:31:20 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:20 --> Total execution time: 0.0522
INFO - 2020-09-23 08:31:23 --> Config Class Initialized
INFO - 2020-09-23 08:31:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:23 --> URI Class Initialized
INFO - 2020-09-23 08:31:23 --> Router Class Initialized
INFO - 2020-09-23 08:31:23 --> Output Class Initialized
INFO - 2020-09-23 08:31:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:23 --> Input Class Initialized
INFO - 2020-09-23 08:31:23 --> Language Class Initialized
INFO - 2020-09-23 08:31:23 --> Language Class Initialized
INFO - 2020-09-23 08:31:23 --> Config Class Initialized
INFO - 2020-09-23 08:31:23 --> Loader Class Initialized
INFO - 2020-09-23 08:31:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:23 --> Controller Class Initialized
INFO - 2020-09-23 08:31:23 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:31:23 --> Config Class Initialized
INFO - 2020-09-23 08:31:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:23 --> URI Class Initialized
INFO - 2020-09-23 08:31:23 --> Router Class Initialized
INFO - 2020-09-23 08:31:23 --> Output Class Initialized
INFO - 2020-09-23 08:31:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:23 --> Input Class Initialized
INFO - 2020-09-23 08:31:23 --> Language Class Initialized
INFO - 2020-09-23 08:31:23 --> Language Class Initialized
INFO - 2020-09-23 08:31:23 --> Config Class Initialized
INFO - 2020-09-23 08:31:23 --> Loader Class Initialized
INFO - 2020-09-23 08:31:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:23 --> Controller Class Initialized
DEBUG - 2020-09-23 08:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:23 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:23 --> Total execution time: 0.0512
INFO - 2020-09-23 08:31:27 --> Config Class Initialized
INFO - 2020-09-23 08:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:27 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:27 --> URI Class Initialized
INFO - 2020-09-23 08:31:27 --> Router Class Initialized
INFO - 2020-09-23 08:31:27 --> Output Class Initialized
INFO - 2020-09-23 08:31:27 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:27 --> Input Class Initialized
INFO - 2020-09-23 08:31:27 --> Language Class Initialized
INFO - 2020-09-23 08:31:27 --> Language Class Initialized
INFO - 2020-09-23 08:31:27 --> Config Class Initialized
INFO - 2020-09-23 08:31:27 --> Loader Class Initialized
INFO - 2020-09-23 08:31:27 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:27 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:27 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:27 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:27 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:27 --> Controller Class Initialized
INFO - 2020-09-23 08:31:27 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:27 --> Total execution time: 0.0414
INFO - 2020-09-23 08:31:27 --> Config Class Initialized
INFO - 2020-09-23 08:31:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:27 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:27 --> URI Class Initialized
INFO - 2020-09-23 08:31:27 --> Router Class Initialized
INFO - 2020-09-23 08:31:27 --> Output Class Initialized
INFO - 2020-09-23 08:31:27 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:27 --> Input Class Initialized
INFO - 2020-09-23 08:31:27 --> Language Class Initialized
INFO - 2020-09-23 08:31:27 --> Language Class Initialized
INFO - 2020-09-23 08:31:27 --> Config Class Initialized
INFO - 2020-09-23 08:31:27 --> Loader Class Initialized
INFO - 2020-09-23 08:31:27 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:27 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:27 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:27 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:27 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:27 --> Controller Class Initialized
INFO - 2020-09-23 08:31:27 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:31:27 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:27 --> Total execution time: 0.0478
INFO - 2020-09-23 08:31:28 --> Config Class Initialized
INFO - 2020-09-23 08:31:28 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:28 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:28 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:28 --> URI Class Initialized
INFO - 2020-09-23 08:31:28 --> Router Class Initialized
INFO - 2020-09-23 08:31:28 --> Output Class Initialized
INFO - 2020-09-23 08:31:28 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:28 --> Input Class Initialized
INFO - 2020-09-23 08:31:28 --> Language Class Initialized
INFO - 2020-09-23 08:31:28 --> Language Class Initialized
INFO - 2020-09-23 08:31:28 --> Config Class Initialized
INFO - 2020-09-23 08:31:28 --> Loader Class Initialized
INFO - 2020-09-23 08:31:28 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:28 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:28 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:28 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:28 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:28 --> Controller Class Initialized
DEBUG - 2020-09-23 08:31:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:31:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:28 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:28 --> Total execution time: 0.6252
INFO - 2020-09-23 08:31:31 --> Config Class Initialized
INFO - 2020-09-23 08:31:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:31 --> URI Class Initialized
INFO - 2020-09-23 08:31:31 --> Router Class Initialized
INFO - 2020-09-23 08:31:31 --> Output Class Initialized
INFO - 2020-09-23 08:31:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:31 --> Input Class Initialized
INFO - 2020-09-23 08:31:31 --> Language Class Initialized
INFO - 2020-09-23 08:31:31 --> Language Class Initialized
INFO - 2020-09-23 08:31:31 --> Config Class Initialized
INFO - 2020-09-23 08:31:31 --> Loader Class Initialized
INFO - 2020-09-23 08:31:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:31 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:31 --> Controller Class Initialized
INFO - 2020-09-23 08:31:31 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:31 --> Total execution time: 0.0705
INFO - 2020-09-23 08:31:31 --> Config Class Initialized
INFO - 2020-09-23 08:31:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:31 --> URI Class Initialized
INFO - 2020-09-23 08:31:31 --> Router Class Initialized
INFO - 2020-09-23 08:31:31 --> Output Class Initialized
INFO - 2020-09-23 08:31:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:31 --> Input Class Initialized
INFO - 2020-09-23 08:31:31 --> Language Class Initialized
INFO - 2020-09-23 08:31:31 --> Language Class Initialized
INFO - 2020-09-23 08:31:31 --> Config Class Initialized
INFO - 2020-09-23 08:31:31 --> Loader Class Initialized
INFO - 2020-09-23 08:31:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:31 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:31 --> Controller Class Initialized
INFO - 2020-09-23 08:31:31 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:31 --> Total execution time: 0.0679
INFO - 2020-09-23 08:31:33 --> Config Class Initialized
INFO - 2020-09-23 08:31:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:33 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:33 --> URI Class Initialized
INFO - 2020-09-23 08:31:33 --> Router Class Initialized
INFO - 2020-09-23 08:31:33 --> Output Class Initialized
INFO - 2020-09-23 08:31:33 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:33 --> Input Class Initialized
INFO - 2020-09-23 08:31:33 --> Language Class Initialized
INFO - 2020-09-23 08:31:33 --> Language Class Initialized
INFO - 2020-09-23 08:31:33 --> Config Class Initialized
INFO - 2020-09-23 08:31:33 --> Loader Class Initialized
INFO - 2020-09-23 08:31:33 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:33 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:33 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:33 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:33 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:33 --> Controller Class Initialized
DEBUG - 2020-09-23 08:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-09-23 08:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:33 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:33 --> Total execution time: 0.1244
INFO - 2020-09-23 08:31:38 --> Config Class Initialized
INFO - 2020-09-23 08:31:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:38 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:38 --> URI Class Initialized
INFO - 2020-09-23 08:31:38 --> Router Class Initialized
INFO - 2020-09-23 08:31:38 --> Output Class Initialized
INFO - 2020-09-23 08:31:38 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:38 --> Input Class Initialized
INFO - 2020-09-23 08:31:38 --> Language Class Initialized
INFO - 2020-09-23 08:31:38 --> Language Class Initialized
INFO - 2020-09-23 08:31:38 --> Config Class Initialized
INFO - 2020-09-23 08:31:38 --> Loader Class Initialized
INFO - 2020-09-23 08:31:38 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:38 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:38 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:38 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:38 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:38 --> Controller Class Initialized
INFO - 2020-09-23 08:31:39 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:39 --> Total execution time: 1.1042
INFO - 2020-09-23 08:31:39 --> Config Class Initialized
INFO - 2020-09-23 08:31:39 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:39 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:39 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:39 --> URI Class Initialized
INFO - 2020-09-23 08:31:39 --> Router Class Initialized
INFO - 2020-09-23 08:31:39 --> Output Class Initialized
INFO - 2020-09-23 08:31:39 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:39 --> Input Class Initialized
INFO - 2020-09-23 08:31:39 --> Language Class Initialized
INFO - 2020-09-23 08:31:39 --> Language Class Initialized
INFO - 2020-09-23 08:31:39 --> Config Class Initialized
INFO - 2020-09-23 08:31:39 --> Loader Class Initialized
INFO - 2020-09-23 08:31:39 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:39 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:39 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:39 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:39 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:39 --> Controller Class Initialized
INFO - 2020-09-23 08:31:40 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:40 --> Total execution time: 1.0851
INFO - 2020-09-23 08:31:44 --> Config Class Initialized
INFO - 2020-09-23 08:31:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:44 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:44 --> URI Class Initialized
INFO - 2020-09-23 08:31:44 --> Router Class Initialized
INFO - 2020-09-23 08:31:44 --> Output Class Initialized
INFO - 2020-09-23 08:31:44 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:44 --> Input Class Initialized
INFO - 2020-09-23 08:31:44 --> Language Class Initialized
INFO - 2020-09-23 08:31:44 --> Language Class Initialized
INFO - 2020-09-23 08:31:44 --> Config Class Initialized
INFO - 2020-09-23 08:31:44 --> Loader Class Initialized
INFO - 2020-09-23 08:31:44 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:44 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:44 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:44 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:44 --> Controller Class Initialized
DEBUG - 2020-09-23 08:31:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-09-23 08:31:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:44 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:44 --> Total execution time: 0.0462
INFO - 2020-09-23 08:31:59 --> Config Class Initialized
INFO - 2020-09-23 08:31:59 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:59 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:59 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:59 --> URI Class Initialized
INFO - 2020-09-23 08:31:59 --> Router Class Initialized
INFO - 2020-09-23 08:31:59 --> Output Class Initialized
INFO - 2020-09-23 08:31:59 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:59 --> Input Class Initialized
INFO - 2020-09-23 08:31:59 --> Language Class Initialized
INFO - 2020-09-23 08:31:59 --> Language Class Initialized
INFO - 2020-09-23 08:31:59 --> Config Class Initialized
INFO - 2020-09-23 08:31:59 --> Loader Class Initialized
INFO - 2020-09-23 08:31:59 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:59 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:59 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:59 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:59 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:59 --> Controller Class Initialized
INFO - 2020-09-23 08:31:59 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:31:59 --> Config Class Initialized
INFO - 2020-09-23 08:31:59 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:31:59 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:31:59 --> Utf8 Class Initialized
INFO - 2020-09-23 08:31:59 --> URI Class Initialized
INFO - 2020-09-23 08:31:59 --> Router Class Initialized
INFO - 2020-09-23 08:31:59 --> Output Class Initialized
INFO - 2020-09-23 08:31:59 --> Security Class Initialized
DEBUG - 2020-09-23 08:31:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:31:59 --> Input Class Initialized
INFO - 2020-09-23 08:31:59 --> Language Class Initialized
INFO - 2020-09-23 08:31:59 --> Language Class Initialized
INFO - 2020-09-23 08:31:59 --> Config Class Initialized
INFO - 2020-09-23 08:31:59 --> Loader Class Initialized
INFO - 2020-09-23 08:31:59 --> Helper loaded: url_helper
INFO - 2020-09-23 08:31:59 --> Helper loaded: file_helper
INFO - 2020-09-23 08:31:59 --> Helper loaded: form_helper
INFO - 2020-09-23 08:31:59 --> Helper loaded: my_helper
INFO - 2020-09-23 08:31:59 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:31:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:31:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:31:59 --> Controller Class Initialized
DEBUG - 2020-09-23 08:31:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:31:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:31:59 --> Final output sent to browser
DEBUG - 2020-09-23 08:31:59 --> Total execution time: 0.0499
INFO - 2020-09-23 08:32:32 --> Config Class Initialized
INFO - 2020-09-23 08:32:32 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:32:32 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:32:32 --> Utf8 Class Initialized
INFO - 2020-09-23 08:32:32 --> URI Class Initialized
INFO - 2020-09-23 08:32:32 --> Router Class Initialized
INFO - 2020-09-23 08:32:32 --> Output Class Initialized
INFO - 2020-09-23 08:32:32 --> Security Class Initialized
DEBUG - 2020-09-23 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:32:32 --> Input Class Initialized
INFO - 2020-09-23 08:32:32 --> Language Class Initialized
INFO - 2020-09-23 08:32:32 --> Language Class Initialized
INFO - 2020-09-23 08:32:32 --> Config Class Initialized
INFO - 2020-09-23 08:32:32 --> Loader Class Initialized
INFO - 2020-09-23 08:32:32 --> Helper loaded: url_helper
INFO - 2020-09-23 08:32:32 --> Helper loaded: file_helper
INFO - 2020-09-23 08:32:32 --> Helper loaded: form_helper
INFO - 2020-09-23 08:32:32 --> Helper loaded: my_helper
INFO - 2020-09-23 08:32:32 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:32:32 --> Controller Class Initialized
INFO - 2020-09-23 08:32:32 --> Final output sent to browser
DEBUG - 2020-09-23 08:32:32 --> Total execution time: 0.0539
INFO - 2020-09-23 08:32:38 --> Config Class Initialized
INFO - 2020-09-23 08:32:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:32:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:32:38 --> Utf8 Class Initialized
INFO - 2020-09-23 08:32:38 --> URI Class Initialized
INFO - 2020-09-23 08:32:38 --> Router Class Initialized
INFO - 2020-09-23 08:32:38 --> Output Class Initialized
INFO - 2020-09-23 08:32:38 --> Security Class Initialized
DEBUG - 2020-09-23 08:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:32:38 --> Input Class Initialized
INFO - 2020-09-23 08:32:38 --> Language Class Initialized
INFO - 2020-09-23 08:32:38 --> Language Class Initialized
INFO - 2020-09-23 08:32:38 --> Config Class Initialized
INFO - 2020-09-23 08:32:38 --> Loader Class Initialized
INFO - 2020-09-23 08:32:38 --> Helper loaded: url_helper
INFO - 2020-09-23 08:32:38 --> Helper loaded: file_helper
INFO - 2020-09-23 08:32:38 --> Helper loaded: form_helper
INFO - 2020-09-23 08:32:38 --> Helper loaded: my_helper
INFO - 2020-09-23 08:32:38 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:32:38 --> Controller Class Initialized
INFO - 2020-09-23 08:32:38 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:32:38 --> Final output sent to browser
DEBUG - 2020-09-23 08:32:38 --> Total execution time: 0.0434
INFO - 2020-09-23 08:32:43 --> Config Class Initialized
INFO - 2020-09-23 08:32:43 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:32:43 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:32:43 --> Utf8 Class Initialized
INFO - 2020-09-23 08:32:43 --> URI Class Initialized
INFO - 2020-09-23 08:32:43 --> Router Class Initialized
INFO - 2020-09-23 08:32:43 --> Output Class Initialized
INFO - 2020-09-23 08:32:43 --> Security Class Initialized
DEBUG - 2020-09-23 08:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:32:43 --> Input Class Initialized
INFO - 2020-09-23 08:32:43 --> Language Class Initialized
INFO - 2020-09-23 08:32:43 --> Language Class Initialized
INFO - 2020-09-23 08:32:43 --> Config Class Initialized
INFO - 2020-09-23 08:32:43 --> Loader Class Initialized
INFO - 2020-09-23 08:32:43 --> Helper loaded: url_helper
INFO - 2020-09-23 08:32:43 --> Helper loaded: file_helper
INFO - 2020-09-23 08:32:43 --> Helper loaded: form_helper
INFO - 2020-09-23 08:32:43 --> Helper loaded: my_helper
INFO - 2020-09-23 08:32:43 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:32:43 --> Controller Class Initialized
DEBUG - 2020-09-23 08:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:32:43 --> Final output sent to browser
DEBUG - 2020-09-23 08:32:43 --> Total execution time: 0.6131
INFO - 2020-09-23 08:33:01 --> Config Class Initialized
INFO - 2020-09-23 08:33:01 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:33:01 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:33:01 --> Utf8 Class Initialized
INFO - 2020-09-23 08:33:01 --> URI Class Initialized
INFO - 2020-09-23 08:33:01 --> Router Class Initialized
INFO - 2020-09-23 08:33:01 --> Output Class Initialized
INFO - 2020-09-23 08:33:01 --> Security Class Initialized
DEBUG - 2020-09-23 08:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:33:01 --> Input Class Initialized
INFO - 2020-09-23 08:33:01 --> Language Class Initialized
INFO - 2020-09-23 08:33:01 --> Language Class Initialized
INFO - 2020-09-23 08:33:01 --> Config Class Initialized
INFO - 2020-09-23 08:33:01 --> Loader Class Initialized
INFO - 2020-09-23 08:33:01 --> Helper loaded: url_helper
INFO - 2020-09-23 08:33:01 --> Helper loaded: file_helper
INFO - 2020-09-23 08:33:01 --> Helper loaded: form_helper
INFO - 2020-09-23 08:33:01 --> Helper loaded: my_helper
INFO - 2020-09-23 08:33:01 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:33:01 --> Controller Class Initialized
DEBUG - 2020-09-23 08:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:33:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:33:01 --> Final output sent to browser
DEBUG - 2020-09-23 08:33:01 --> Total execution time: 0.0597
INFO - 2020-09-23 08:33:34 --> Config Class Initialized
INFO - 2020-09-23 08:33:34 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:33:34 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:33:34 --> Utf8 Class Initialized
INFO - 2020-09-23 08:33:34 --> URI Class Initialized
INFO - 2020-09-23 08:33:34 --> Router Class Initialized
INFO - 2020-09-23 08:33:34 --> Output Class Initialized
INFO - 2020-09-23 08:33:34 --> Security Class Initialized
DEBUG - 2020-09-23 08:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:33:34 --> Input Class Initialized
INFO - 2020-09-23 08:33:34 --> Language Class Initialized
INFO - 2020-09-23 08:33:34 --> Language Class Initialized
INFO - 2020-09-23 08:33:34 --> Config Class Initialized
INFO - 2020-09-23 08:33:34 --> Loader Class Initialized
INFO - 2020-09-23 08:33:34 --> Helper loaded: url_helper
INFO - 2020-09-23 08:33:34 --> Helper loaded: file_helper
INFO - 2020-09-23 08:33:34 --> Helper loaded: form_helper
INFO - 2020-09-23 08:33:34 --> Helper loaded: my_helper
INFO - 2020-09-23 08:33:34 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:33:34 --> Controller Class Initialized
DEBUG - 2020-09-23 08:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2020-09-23 08:33:35 --> Final output sent to browser
DEBUG - 2020-09-23 08:33:35 --> Total execution time: 0.3693
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:38:53 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:38:53 --> Utf8 Class Initialized
INFO - 2020-09-23 08:38:53 --> URI Class Initialized
INFO - 2020-09-23 08:38:53 --> Router Class Initialized
INFO - 2020-09-23 08:38:53 --> Output Class Initialized
INFO - 2020-09-23 08:38:53 --> Security Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:38:53 --> Input Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Loader Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: url_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: file_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: form_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: my_helper
INFO - 2020-09-23 08:38:53 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:38:53 --> Controller Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:38:53 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:38:53 --> Utf8 Class Initialized
INFO - 2020-09-23 08:38:53 --> URI Class Initialized
INFO - 2020-09-23 08:38:53 --> Router Class Initialized
INFO - 2020-09-23 08:38:53 --> Output Class Initialized
INFO - 2020-09-23 08:38:53 --> Security Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:38:53 --> Input Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Loader Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: url_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: file_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: form_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: my_helper
INFO - 2020-09-23 08:38:53 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:38:53 --> Controller Class Initialized
DEBUG - 2020-09-23 08:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:38:53 --> Final output sent to browser
DEBUG - 2020-09-23 08:38:53 --> Total execution time: 0.0498
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:38:53 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:38:53 --> Utf8 Class Initialized
INFO - 2020-09-23 08:38:53 --> URI Class Initialized
INFO - 2020-09-23 08:38:53 --> Router Class Initialized
INFO - 2020-09-23 08:38:53 --> Output Class Initialized
INFO - 2020-09-23 08:38:53 --> Security Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:38:53 --> Input Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Loader Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: url_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: file_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: form_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: my_helper
INFO - 2020-09-23 08:38:53 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:38:53 --> Controller Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: cookie_helper
ERROR - 2020-09-23 08:38:53 --> Severity: Warning --> session_destroy(): Session object destruction failed C:\xampp\htdocs\nilai\system\libraries\Session\Session.php 628
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:38:53 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:38:53 --> Utf8 Class Initialized
INFO - 2020-09-23 08:38:53 --> URI Class Initialized
INFO - 2020-09-23 08:38:53 --> Router Class Initialized
INFO - 2020-09-23 08:38:53 --> Output Class Initialized
INFO - 2020-09-23 08:38:53 --> Security Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:38:53 --> Input Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Loader Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: url_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: file_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: form_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: my_helper
INFO - 2020-09-23 08:38:53 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:38:53 --> Controller Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:38:53 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:38:53 --> Utf8 Class Initialized
INFO - 2020-09-23 08:38:53 --> URI Class Initialized
INFO - 2020-09-23 08:38:53 --> Router Class Initialized
INFO - 2020-09-23 08:38:53 --> Output Class Initialized
INFO - 2020-09-23 08:38:53 --> Security Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:38:53 --> Input Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Language Class Initialized
INFO - 2020-09-23 08:38:53 --> Config Class Initialized
INFO - 2020-09-23 08:38:53 --> Loader Class Initialized
INFO - 2020-09-23 08:38:53 --> Helper loaded: url_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: file_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: form_helper
INFO - 2020-09-23 08:38:53 --> Helper loaded: my_helper
INFO - 2020-09-23 08:38:53 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:38:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:38:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:38:53 --> Controller Class Initialized
DEBUG - 2020-09-23 08:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:38:53 --> Final output sent to browser
DEBUG - 2020-09-23 08:38:53 --> Total execution time: 0.0491
INFO - 2020-09-23 08:42:48 --> Config Class Initialized
INFO - 2020-09-23 08:42:48 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:42:48 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:42:48 --> Utf8 Class Initialized
INFO - 2020-09-23 08:42:48 --> URI Class Initialized
INFO - 2020-09-23 08:42:48 --> Router Class Initialized
INFO - 2020-09-23 08:42:48 --> Output Class Initialized
INFO - 2020-09-23 08:42:48 --> Security Class Initialized
DEBUG - 2020-09-23 08:42:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:42:48 --> Input Class Initialized
INFO - 2020-09-23 08:42:48 --> Language Class Initialized
INFO - 2020-09-23 08:42:48 --> Language Class Initialized
INFO - 2020-09-23 08:42:48 --> Config Class Initialized
INFO - 2020-09-23 08:42:48 --> Loader Class Initialized
INFO - 2020-09-23 08:42:48 --> Helper loaded: url_helper
INFO - 2020-09-23 08:42:48 --> Helper loaded: file_helper
INFO - 2020-09-23 08:42:48 --> Helper loaded: form_helper
INFO - 2020-09-23 08:42:48 --> Helper loaded: my_helper
INFO - 2020-09-23 08:42:48 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:42:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:42:48 --> Controller Class Initialized
DEBUG - 2020-09-23 08:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-09-23 08:42:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:42:48 --> Final output sent to browser
DEBUG - 2020-09-23 08:42:48 --> Total execution time: 0.0965
INFO - 2020-09-23 08:42:59 --> Config Class Initialized
INFO - 2020-09-23 08:42:59 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:42:59 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:42:59 --> Utf8 Class Initialized
INFO - 2020-09-23 08:42:59 --> URI Class Initialized
INFO - 2020-09-23 08:42:59 --> Router Class Initialized
INFO - 2020-09-23 08:42:59 --> Output Class Initialized
INFO - 2020-09-23 08:42:59 --> Security Class Initialized
DEBUG - 2020-09-23 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:42:59 --> Input Class Initialized
INFO - 2020-09-23 08:42:59 --> Language Class Initialized
INFO - 2020-09-23 08:42:59 --> Language Class Initialized
INFO - 2020-09-23 08:42:59 --> Config Class Initialized
INFO - 2020-09-23 08:42:59 --> Loader Class Initialized
INFO - 2020-09-23 08:42:59 --> Helper loaded: url_helper
INFO - 2020-09-23 08:42:59 --> Helper loaded: file_helper
INFO - 2020-09-23 08:42:59 --> Helper loaded: form_helper
INFO - 2020-09-23 08:42:59 --> Helper loaded: my_helper
INFO - 2020-09-23 08:42:59 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:42:59 --> Controller Class Initialized
DEBUG - 2020-09-23 08:42:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-09-23 08:42:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:42:59 --> Final output sent to browser
DEBUG - 2020-09-23 08:42:59 --> Total execution time: 0.1001
INFO - 2020-09-23 08:43:23 --> Config Class Initialized
INFO - 2020-09-23 08:43:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:43:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:43:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:43:23 --> URI Class Initialized
INFO - 2020-09-23 08:43:23 --> Router Class Initialized
INFO - 2020-09-23 08:43:23 --> Output Class Initialized
INFO - 2020-09-23 08:43:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:43:23 --> Input Class Initialized
INFO - 2020-09-23 08:43:23 --> Language Class Initialized
INFO - 2020-09-23 08:43:23 --> Language Class Initialized
INFO - 2020-09-23 08:43:23 --> Config Class Initialized
INFO - 2020-09-23 08:43:23 --> Loader Class Initialized
INFO - 2020-09-23 08:43:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:43:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:43:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:43:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:43:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:43:23 --> Controller Class Initialized
DEBUG - 2020-09-23 08:43:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-09-23 08:43:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:43:23 --> Final output sent to browser
DEBUG - 2020-09-23 08:43:23 --> Total execution time: 0.0612
INFO - 2020-09-23 08:44:00 --> Config Class Initialized
INFO - 2020-09-23 08:44:00 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:44:00 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:44:00 --> Utf8 Class Initialized
INFO - 2020-09-23 08:44:00 --> URI Class Initialized
INFO - 2020-09-23 08:44:00 --> Router Class Initialized
INFO - 2020-09-23 08:44:00 --> Output Class Initialized
INFO - 2020-09-23 08:44:00 --> Security Class Initialized
DEBUG - 2020-09-23 08:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:44:00 --> Input Class Initialized
INFO - 2020-09-23 08:44:00 --> Language Class Initialized
INFO - 2020-09-23 08:44:00 --> Language Class Initialized
INFO - 2020-09-23 08:44:00 --> Config Class Initialized
INFO - 2020-09-23 08:44:00 --> Loader Class Initialized
INFO - 2020-09-23 08:44:00 --> Helper loaded: url_helper
INFO - 2020-09-23 08:44:00 --> Helper loaded: file_helper
INFO - 2020-09-23 08:44:00 --> Helper loaded: form_helper
INFO - 2020-09-23 08:44:00 --> Helper loaded: my_helper
INFO - 2020-09-23 08:44:00 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:44:00 --> Controller Class Initialized
DEBUG - 2020-09-23 08:44:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-09-23 08:44:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:44:01 --> Final output sent to browser
DEBUG - 2020-09-23 08:44:01 --> Total execution time: 0.0962
INFO - 2020-09-23 08:50:58 --> Config Class Initialized
INFO - 2020-09-23 08:50:58 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:50:58 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:50:58 --> Utf8 Class Initialized
INFO - 2020-09-23 08:50:58 --> URI Class Initialized
INFO - 2020-09-23 08:50:58 --> Router Class Initialized
INFO - 2020-09-23 08:50:58 --> Output Class Initialized
INFO - 2020-09-23 08:50:58 --> Security Class Initialized
DEBUG - 2020-09-23 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:50:58 --> Input Class Initialized
INFO - 2020-09-23 08:50:58 --> Language Class Initialized
INFO - 2020-09-23 08:50:58 --> Language Class Initialized
INFO - 2020-09-23 08:50:58 --> Config Class Initialized
INFO - 2020-09-23 08:50:58 --> Loader Class Initialized
INFO - 2020-09-23 08:50:58 --> Helper loaded: url_helper
INFO - 2020-09-23 08:50:58 --> Helper loaded: file_helper
INFO - 2020-09-23 08:50:58 --> Helper loaded: form_helper
INFO - 2020-09-23 08:50:58 --> Helper loaded: my_helper
INFO - 2020-09-23 08:50:58 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:50:58 --> Controller Class Initialized
INFO - 2020-09-23 08:50:58 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:50:58 --> Config Class Initialized
INFO - 2020-09-23 08:50:58 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:50:58 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:50:58 --> Utf8 Class Initialized
INFO - 2020-09-23 08:50:58 --> URI Class Initialized
INFO - 2020-09-23 08:50:58 --> Router Class Initialized
INFO - 2020-09-23 08:50:58 --> Output Class Initialized
INFO - 2020-09-23 08:50:58 --> Security Class Initialized
DEBUG - 2020-09-23 08:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:50:58 --> Input Class Initialized
INFO - 2020-09-23 08:50:58 --> Language Class Initialized
INFO - 2020-09-23 08:50:58 --> Language Class Initialized
INFO - 2020-09-23 08:50:58 --> Config Class Initialized
INFO - 2020-09-23 08:50:58 --> Loader Class Initialized
INFO - 2020-09-23 08:50:58 --> Helper loaded: url_helper
INFO - 2020-09-23 08:50:58 --> Helper loaded: file_helper
INFO - 2020-09-23 08:50:58 --> Helper loaded: form_helper
INFO - 2020-09-23 08:50:58 --> Helper loaded: my_helper
INFO - 2020-09-23 08:50:58 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:50:58 --> Controller Class Initialized
DEBUG - 2020-09-23 08:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:50:58 --> Final output sent to browser
DEBUG - 2020-09-23 08:50:58 --> Total execution time: 0.0522
INFO - 2020-09-23 08:51:11 --> Config Class Initialized
INFO - 2020-09-23 08:51:11 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:51:11 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:51:11 --> Utf8 Class Initialized
INFO - 2020-09-23 08:51:11 --> URI Class Initialized
INFO - 2020-09-23 08:51:11 --> Router Class Initialized
INFO - 2020-09-23 08:51:11 --> Output Class Initialized
INFO - 2020-09-23 08:51:11 --> Security Class Initialized
DEBUG - 2020-09-23 08:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:51:11 --> Input Class Initialized
INFO - 2020-09-23 08:51:11 --> Language Class Initialized
INFO - 2020-09-23 08:51:11 --> Language Class Initialized
INFO - 2020-09-23 08:51:11 --> Config Class Initialized
INFO - 2020-09-23 08:51:11 --> Loader Class Initialized
INFO - 2020-09-23 08:51:11 --> Helper loaded: url_helper
INFO - 2020-09-23 08:51:11 --> Helper loaded: file_helper
INFO - 2020-09-23 08:51:11 --> Helper loaded: form_helper
INFO - 2020-09-23 08:51:11 --> Helper loaded: my_helper
INFO - 2020-09-23 08:51:11 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:51:11 --> Controller Class Initialized
INFO - 2020-09-23 08:51:11 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:51:11 --> Config Class Initialized
INFO - 2020-09-23 08:51:11 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:51:11 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:51:11 --> Utf8 Class Initialized
INFO - 2020-09-23 08:51:11 --> URI Class Initialized
INFO - 2020-09-23 08:51:11 --> Router Class Initialized
INFO - 2020-09-23 08:51:11 --> Output Class Initialized
INFO - 2020-09-23 08:51:11 --> Security Class Initialized
DEBUG - 2020-09-23 08:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:51:11 --> Input Class Initialized
INFO - 2020-09-23 08:51:11 --> Language Class Initialized
INFO - 2020-09-23 08:51:11 --> Language Class Initialized
INFO - 2020-09-23 08:51:11 --> Config Class Initialized
INFO - 2020-09-23 08:51:11 --> Loader Class Initialized
INFO - 2020-09-23 08:51:11 --> Helper loaded: url_helper
INFO - 2020-09-23 08:51:11 --> Helper loaded: file_helper
INFO - 2020-09-23 08:51:11 --> Helper loaded: form_helper
INFO - 2020-09-23 08:51:11 --> Helper loaded: my_helper
INFO - 2020-09-23 08:51:11 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:51:11 --> Controller Class Initialized
DEBUG - 2020-09-23 08:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:51:11 --> Final output sent to browser
DEBUG - 2020-09-23 08:51:11 --> Total execution time: 0.0404
INFO - 2020-09-23 08:51:33 --> Config Class Initialized
INFO - 2020-09-23 08:51:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:51:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:51:33 --> Utf8 Class Initialized
INFO - 2020-09-23 08:51:33 --> URI Class Initialized
INFO - 2020-09-23 08:51:33 --> Router Class Initialized
INFO - 2020-09-23 08:51:33 --> Output Class Initialized
INFO - 2020-09-23 08:51:33 --> Security Class Initialized
DEBUG - 2020-09-23 08:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:51:33 --> Input Class Initialized
INFO - 2020-09-23 08:51:33 --> Language Class Initialized
INFO - 2020-09-23 08:51:33 --> Language Class Initialized
INFO - 2020-09-23 08:51:33 --> Config Class Initialized
INFO - 2020-09-23 08:51:33 --> Loader Class Initialized
INFO - 2020-09-23 08:51:33 --> Helper loaded: url_helper
INFO - 2020-09-23 08:51:33 --> Helper loaded: file_helper
INFO - 2020-09-23 08:51:33 --> Helper loaded: form_helper
INFO - 2020-09-23 08:51:33 --> Helper loaded: my_helper
INFO - 2020-09-23 08:51:33 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:51:33 --> Controller Class Initialized
INFO - 2020-09-23 08:51:33 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:51:33 --> Final output sent to browser
DEBUG - 2020-09-23 08:51:33 --> Total execution time: 0.0444
INFO - 2020-09-23 08:51:33 --> Config Class Initialized
INFO - 2020-09-23 08:51:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:51:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:51:33 --> Utf8 Class Initialized
INFO - 2020-09-23 08:51:33 --> URI Class Initialized
INFO - 2020-09-23 08:51:33 --> Router Class Initialized
INFO - 2020-09-23 08:51:33 --> Output Class Initialized
INFO - 2020-09-23 08:51:33 --> Security Class Initialized
DEBUG - 2020-09-23 08:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:51:33 --> Input Class Initialized
INFO - 2020-09-23 08:51:33 --> Language Class Initialized
INFO - 2020-09-23 08:51:33 --> Language Class Initialized
INFO - 2020-09-23 08:51:33 --> Config Class Initialized
INFO - 2020-09-23 08:51:33 --> Loader Class Initialized
INFO - 2020-09-23 08:51:33 --> Helper loaded: url_helper
INFO - 2020-09-23 08:51:33 --> Helper loaded: file_helper
INFO - 2020-09-23 08:51:33 --> Helper loaded: form_helper
INFO - 2020-09-23 08:51:33 --> Helper loaded: my_helper
INFO - 2020-09-23 08:51:33 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:51:33 --> Controller Class Initialized
DEBUG - 2020-09-23 08:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:51:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:51:34 --> Final output sent to browser
DEBUG - 2020-09-23 08:51:34 --> Total execution time: 0.6484
INFO - 2020-09-23 08:51:36 --> Config Class Initialized
INFO - 2020-09-23 08:51:36 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:51:36 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:51:36 --> Utf8 Class Initialized
INFO - 2020-09-23 08:51:36 --> URI Class Initialized
INFO - 2020-09-23 08:51:36 --> Router Class Initialized
INFO - 2020-09-23 08:51:36 --> Output Class Initialized
INFO - 2020-09-23 08:51:36 --> Security Class Initialized
DEBUG - 2020-09-23 08:51:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:51:36 --> Input Class Initialized
INFO - 2020-09-23 08:51:36 --> Language Class Initialized
INFO - 2020-09-23 08:51:36 --> Language Class Initialized
INFO - 2020-09-23 08:51:36 --> Config Class Initialized
INFO - 2020-09-23 08:51:36 --> Loader Class Initialized
INFO - 2020-09-23 08:51:36 --> Helper loaded: url_helper
INFO - 2020-09-23 08:51:36 --> Helper loaded: file_helper
INFO - 2020-09-23 08:51:36 --> Helper loaded: form_helper
INFO - 2020-09-23 08:51:36 --> Helper loaded: my_helper
INFO - 2020-09-23 08:51:36 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:51:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:51:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:51:36 --> Controller Class Initialized
DEBUG - 2020-09-23 08:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:51:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:51:36 --> Final output sent to browser
DEBUG - 2020-09-23 08:51:36 --> Total execution time: 0.0541
INFO - 2020-09-23 08:51:37 --> Config Class Initialized
INFO - 2020-09-23 08:51:37 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:51:37 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:51:37 --> Utf8 Class Initialized
INFO - 2020-09-23 08:51:37 --> URI Class Initialized
INFO - 2020-09-23 08:51:37 --> Router Class Initialized
INFO - 2020-09-23 08:51:37 --> Output Class Initialized
INFO - 2020-09-23 08:51:37 --> Security Class Initialized
DEBUG - 2020-09-23 08:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:51:37 --> Input Class Initialized
INFO - 2020-09-23 08:51:37 --> Language Class Initialized
INFO - 2020-09-23 08:51:37 --> Language Class Initialized
INFO - 2020-09-23 08:51:37 --> Config Class Initialized
INFO - 2020-09-23 08:51:37 --> Loader Class Initialized
INFO - 2020-09-23 08:51:37 --> Helper loaded: url_helper
INFO - 2020-09-23 08:51:37 --> Helper loaded: file_helper
INFO - 2020-09-23 08:51:37 --> Helper loaded: form_helper
INFO - 2020-09-23 08:51:37 --> Helper loaded: my_helper
INFO - 2020-09-23 08:51:37 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:51:37 --> Controller Class Initialized
DEBUG - 2020-09-23 08:51:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2020-09-23 08:51:38 --> Final output sent to browser
DEBUG - 2020-09-23 08:51:38 --> Total execution time: 0.3333
INFO - 2020-09-23 08:52:14 --> Config Class Initialized
INFO - 2020-09-23 08:52:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:52:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:52:14 --> Utf8 Class Initialized
INFO - 2020-09-23 08:52:14 --> URI Class Initialized
INFO - 2020-09-23 08:52:14 --> Router Class Initialized
INFO - 2020-09-23 08:52:14 --> Output Class Initialized
INFO - 2020-09-23 08:52:14 --> Security Class Initialized
DEBUG - 2020-09-23 08:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:52:14 --> Input Class Initialized
INFO - 2020-09-23 08:52:14 --> Language Class Initialized
INFO - 2020-09-23 08:52:14 --> Language Class Initialized
INFO - 2020-09-23 08:52:14 --> Config Class Initialized
INFO - 2020-09-23 08:52:14 --> Loader Class Initialized
INFO - 2020-09-23 08:52:14 --> Helper loaded: url_helper
INFO - 2020-09-23 08:52:14 --> Helper loaded: file_helper
INFO - 2020-09-23 08:52:14 --> Helper loaded: form_helper
INFO - 2020-09-23 08:52:14 --> Helper loaded: my_helper
INFO - 2020-09-23 08:52:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:52:14 --> Controller Class Initialized
INFO - 2020-09-23 08:52:14 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:52:14 --> Config Class Initialized
INFO - 2020-09-23 08:52:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:52:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:52:14 --> Utf8 Class Initialized
INFO - 2020-09-23 08:52:14 --> URI Class Initialized
INFO - 2020-09-23 08:52:14 --> Router Class Initialized
INFO - 2020-09-23 08:52:14 --> Output Class Initialized
INFO - 2020-09-23 08:52:14 --> Security Class Initialized
DEBUG - 2020-09-23 08:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:52:14 --> Input Class Initialized
INFO - 2020-09-23 08:52:14 --> Language Class Initialized
INFO - 2020-09-23 08:52:14 --> Language Class Initialized
INFO - 2020-09-23 08:52:14 --> Config Class Initialized
INFO - 2020-09-23 08:52:14 --> Loader Class Initialized
INFO - 2020-09-23 08:52:14 --> Helper loaded: url_helper
INFO - 2020-09-23 08:52:14 --> Helper loaded: file_helper
INFO - 2020-09-23 08:52:14 --> Helper loaded: form_helper
INFO - 2020-09-23 08:52:14 --> Helper loaded: my_helper
INFO - 2020-09-23 08:52:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:52:14 --> Controller Class Initialized
DEBUG - 2020-09-23 08:52:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:52:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:52:14 --> Final output sent to browser
DEBUG - 2020-09-23 08:52:14 --> Total execution time: 0.0503
INFO - 2020-09-23 08:52:19 --> Config Class Initialized
INFO - 2020-09-23 08:52:19 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:52:19 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:52:19 --> Utf8 Class Initialized
INFO - 2020-09-23 08:52:19 --> URI Class Initialized
INFO - 2020-09-23 08:52:19 --> Router Class Initialized
INFO - 2020-09-23 08:52:19 --> Output Class Initialized
INFO - 2020-09-23 08:52:19 --> Security Class Initialized
DEBUG - 2020-09-23 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:52:19 --> Input Class Initialized
INFO - 2020-09-23 08:52:19 --> Language Class Initialized
INFO - 2020-09-23 08:52:19 --> Language Class Initialized
INFO - 2020-09-23 08:52:19 --> Config Class Initialized
INFO - 2020-09-23 08:52:19 --> Loader Class Initialized
INFO - 2020-09-23 08:52:19 --> Helper loaded: url_helper
INFO - 2020-09-23 08:52:19 --> Helper loaded: file_helper
INFO - 2020-09-23 08:52:19 --> Helper loaded: form_helper
INFO - 2020-09-23 08:52:19 --> Helper loaded: my_helper
INFO - 2020-09-23 08:52:19 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:52:19 --> Controller Class Initialized
INFO - 2020-09-23 08:52:19 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:52:19 --> Final output sent to browser
DEBUG - 2020-09-23 08:52:19 --> Total execution time: 0.0466
INFO - 2020-09-23 08:52:19 --> Config Class Initialized
INFO - 2020-09-23 08:52:19 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:52:19 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:52:19 --> Utf8 Class Initialized
INFO - 2020-09-23 08:52:19 --> URI Class Initialized
INFO - 2020-09-23 08:52:19 --> Router Class Initialized
INFO - 2020-09-23 08:52:19 --> Output Class Initialized
INFO - 2020-09-23 08:52:19 --> Security Class Initialized
DEBUG - 2020-09-23 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:52:19 --> Input Class Initialized
INFO - 2020-09-23 08:52:19 --> Language Class Initialized
INFO - 2020-09-23 08:52:19 --> Language Class Initialized
INFO - 2020-09-23 08:52:19 --> Config Class Initialized
INFO - 2020-09-23 08:52:19 --> Loader Class Initialized
INFO - 2020-09-23 08:52:19 --> Helper loaded: url_helper
INFO - 2020-09-23 08:52:19 --> Helper loaded: file_helper
INFO - 2020-09-23 08:52:19 --> Helper loaded: form_helper
INFO - 2020-09-23 08:52:19 --> Helper loaded: my_helper
INFO - 2020-09-23 08:52:19 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:52:19 --> Controller Class Initialized
DEBUG - 2020-09-23 08:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:52:20 --> Final output sent to browser
DEBUG - 2020-09-23 08:52:20 --> Total execution time: 0.6339
INFO - 2020-09-23 08:52:21 --> Config Class Initialized
INFO - 2020-09-23 08:52:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:52:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:52:21 --> Utf8 Class Initialized
INFO - 2020-09-23 08:52:21 --> URI Class Initialized
INFO - 2020-09-23 08:52:21 --> Router Class Initialized
INFO - 2020-09-23 08:52:21 --> Output Class Initialized
INFO - 2020-09-23 08:52:21 --> Security Class Initialized
DEBUG - 2020-09-23 08:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:52:21 --> Input Class Initialized
INFO - 2020-09-23 08:52:21 --> Language Class Initialized
INFO - 2020-09-23 08:52:21 --> Language Class Initialized
INFO - 2020-09-23 08:52:21 --> Config Class Initialized
INFO - 2020-09-23 08:52:21 --> Loader Class Initialized
INFO - 2020-09-23 08:52:21 --> Helper loaded: url_helper
INFO - 2020-09-23 08:52:21 --> Helper loaded: file_helper
INFO - 2020-09-23 08:52:21 --> Helper loaded: form_helper
INFO - 2020-09-23 08:52:21 --> Helper loaded: my_helper
INFO - 2020-09-23 08:52:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:52:21 --> Controller Class Initialized
DEBUG - 2020-09-23 08:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:52:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:52:21 --> Final output sent to browser
DEBUG - 2020-09-23 08:52:21 --> Total execution time: 0.0520
INFO - 2020-09-23 08:52:23 --> Config Class Initialized
INFO - 2020-09-23 08:52:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:52:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:52:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:52:23 --> URI Class Initialized
INFO - 2020-09-23 08:52:23 --> Router Class Initialized
INFO - 2020-09-23 08:52:23 --> Output Class Initialized
INFO - 2020-09-23 08:52:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:52:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:52:23 --> Input Class Initialized
INFO - 2020-09-23 08:52:23 --> Language Class Initialized
INFO - 2020-09-23 08:52:23 --> Language Class Initialized
INFO - 2020-09-23 08:52:23 --> Config Class Initialized
INFO - 2020-09-23 08:52:23 --> Loader Class Initialized
INFO - 2020-09-23 08:52:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:52:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:52:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:52:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:52:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:52:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:52:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:52:23 --> Controller Class Initialized
DEBUG - 2020-09-23 08:52:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xii.php
INFO - 2020-09-23 08:52:23 --> Final output sent to browser
DEBUG - 2020-09-23 08:52:23 --> Total execution time: 0.3342
INFO - 2020-09-23 08:53:16 --> Config Class Initialized
INFO - 2020-09-23 08:53:16 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:16 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:16 --> URI Class Initialized
INFO - 2020-09-23 08:53:16 --> Router Class Initialized
INFO - 2020-09-23 08:53:16 --> Output Class Initialized
INFO - 2020-09-23 08:53:16 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:16 --> Input Class Initialized
INFO - 2020-09-23 08:53:16 --> Language Class Initialized
INFO - 2020-09-23 08:53:16 --> Language Class Initialized
INFO - 2020-09-23 08:53:16 --> Config Class Initialized
INFO - 2020-09-23 08:53:16 --> Loader Class Initialized
INFO - 2020-09-23 08:53:16 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:16 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:16 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:16 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:16 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:16 --> Controller Class Initialized
INFO - 2020-09-23 08:53:16 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:53:16 --> Config Class Initialized
INFO - 2020-09-23 08:53:16 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:16 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:16 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:16 --> URI Class Initialized
INFO - 2020-09-23 08:53:16 --> Router Class Initialized
INFO - 2020-09-23 08:53:16 --> Output Class Initialized
INFO - 2020-09-23 08:53:16 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:16 --> Input Class Initialized
INFO - 2020-09-23 08:53:16 --> Language Class Initialized
INFO - 2020-09-23 08:53:16 --> Language Class Initialized
INFO - 2020-09-23 08:53:16 --> Config Class Initialized
INFO - 2020-09-23 08:53:16 --> Loader Class Initialized
INFO - 2020-09-23 08:53:16 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:16 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:16 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:16 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:16 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:16 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:53:16 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:16 --> Total execution time: 0.0511
INFO - 2020-09-23 08:53:23 --> Config Class Initialized
INFO - 2020-09-23 08:53:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:23 --> URI Class Initialized
INFO - 2020-09-23 08:53:23 --> Router Class Initialized
INFO - 2020-09-23 08:53:23 --> Output Class Initialized
INFO - 2020-09-23 08:53:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:23 --> Input Class Initialized
INFO - 2020-09-23 08:53:23 --> Language Class Initialized
INFO - 2020-09-23 08:53:23 --> Language Class Initialized
INFO - 2020-09-23 08:53:23 --> Config Class Initialized
INFO - 2020-09-23 08:53:23 --> Loader Class Initialized
INFO - 2020-09-23 08:53:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:23 --> Controller Class Initialized
INFO - 2020-09-23 08:53:23 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:53:23 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:23 --> Total execution time: 0.0517
INFO - 2020-09-23 08:53:23 --> Config Class Initialized
INFO - 2020-09-23 08:53:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:23 --> URI Class Initialized
INFO - 2020-09-23 08:53:23 --> Router Class Initialized
INFO - 2020-09-23 08:53:23 --> Output Class Initialized
INFO - 2020-09-23 08:53:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:23 --> Input Class Initialized
INFO - 2020-09-23 08:53:23 --> Language Class Initialized
INFO - 2020-09-23 08:53:23 --> Language Class Initialized
INFO - 2020-09-23 08:53:23 --> Config Class Initialized
INFO - 2020-09-23 08:53:23 --> Loader Class Initialized
INFO - 2020-09-23 08:53:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:23 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:53:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:53:24 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:24 --> Total execution time: 0.6454
INFO - 2020-09-23 08:53:25 --> Config Class Initialized
INFO - 2020-09-23 08:53:25 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:25 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:25 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:25 --> URI Class Initialized
INFO - 2020-09-23 08:53:25 --> Router Class Initialized
INFO - 2020-09-23 08:53:25 --> Output Class Initialized
INFO - 2020-09-23 08:53:25 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:25 --> Input Class Initialized
INFO - 2020-09-23 08:53:25 --> Language Class Initialized
INFO - 2020-09-23 08:53:25 --> Language Class Initialized
INFO - 2020-09-23 08:53:25 --> Config Class Initialized
INFO - 2020-09-23 08:53:25 --> Loader Class Initialized
INFO - 2020-09-23 08:53:25 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:25 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:25 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:25 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:25 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:25 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:53:25 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:25 --> Total execution time: 0.0740
INFO - 2020-09-23 08:53:27 --> Config Class Initialized
INFO - 2020-09-23 08:53:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:27 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:27 --> URI Class Initialized
INFO - 2020-09-23 08:53:27 --> Router Class Initialized
INFO - 2020-09-23 08:53:27 --> Output Class Initialized
INFO - 2020-09-23 08:53:27 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:27 --> Input Class Initialized
INFO - 2020-09-23 08:53:27 --> Language Class Initialized
INFO - 2020-09-23 08:53:27 --> Language Class Initialized
INFO - 2020-09-23 08:53:27 --> Config Class Initialized
INFO - 2020-09-23 08:53:27 --> Loader Class Initialized
INFO - 2020-09-23 08:53:27 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:27 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:27 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:27 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:27 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:27 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2020-09-23 08:53:28 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:28 --> Total execution time: 0.3588
INFO - 2020-09-23 08:53:40 --> Config Class Initialized
INFO - 2020-09-23 08:53:40 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:40 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:40 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:40 --> URI Class Initialized
INFO - 2020-09-23 08:53:40 --> Router Class Initialized
INFO - 2020-09-23 08:53:40 --> Output Class Initialized
INFO - 2020-09-23 08:53:40 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:40 --> Input Class Initialized
INFO - 2020-09-23 08:53:40 --> Language Class Initialized
INFO - 2020-09-23 08:53:40 --> Language Class Initialized
INFO - 2020-09-23 08:53:40 --> Config Class Initialized
INFO - 2020-09-23 08:53:40 --> Loader Class Initialized
INFO - 2020-09-23 08:53:40 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:40 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:40 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:40 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:40 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:40 --> Controller Class Initialized
INFO - 2020-09-23 08:53:40 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:53:40 --> Config Class Initialized
INFO - 2020-09-23 08:53:40 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:40 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:40 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:40 --> URI Class Initialized
INFO - 2020-09-23 08:53:40 --> Router Class Initialized
INFO - 2020-09-23 08:53:40 --> Output Class Initialized
INFO - 2020-09-23 08:53:40 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:40 --> Input Class Initialized
INFO - 2020-09-23 08:53:40 --> Language Class Initialized
INFO - 2020-09-23 08:53:40 --> Language Class Initialized
INFO - 2020-09-23 08:53:40 --> Config Class Initialized
INFO - 2020-09-23 08:53:40 --> Loader Class Initialized
INFO - 2020-09-23 08:53:40 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:40 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:40 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:40 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:40 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:40 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:53:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:53:40 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:40 --> Total execution time: 0.0526
INFO - 2020-09-23 08:53:48 --> Config Class Initialized
INFO - 2020-09-23 08:53:48 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:48 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:48 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:48 --> URI Class Initialized
INFO - 2020-09-23 08:53:48 --> Router Class Initialized
INFO - 2020-09-23 08:53:48 --> Output Class Initialized
INFO - 2020-09-23 08:53:48 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:48 --> Input Class Initialized
INFO - 2020-09-23 08:53:48 --> Language Class Initialized
INFO - 2020-09-23 08:53:48 --> Language Class Initialized
INFO - 2020-09-23 08:53:48 --> Config Class Initialized
INFO - 2020-09-23 08:53:48 --> Loader Class Initialized
INFO - 2020-09-23 08:53:48 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:48 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:48 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:48 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:48 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:48 --> Controller Class Initialized
INFO - 2020-09-23 08:53:48 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:53:48 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:48 --> Total execution time: 0.0464
INFO - 2020-09-23 08:53:49 --> Config Class Initialized
INFO - 2020-09-23 08:53:49 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:49 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:49 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:49 --> URI Class Initialized
INFO - 2020-09-23 08:53:49 --> Router Class Initialized
INFO - 2020-09-23 08:53:49 --> Output Class Initialized
INFO - 2020-09-23 08:53:49 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:49 --> Input Class Initialized
INFO - 2020-09-23 08:53:49 --> Language Class Initialized
INFO - 2020-09-23 08:53:49 --> Language Class Initialized
INFO - 2020-09-23 08:53:49 --> Config Class Initialized
INFO - 2020-09-23 08:53:49 --> Loader Class Initialized
INFO - 2020-09-23 08:53:49 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:49 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:49 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:49 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:49 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:49 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:53:49 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:49 --> Total execution time: 0.6392
INFO - 2020-09-23 08:53:51 --> Config Class Initialized
INFO - 2020-09-23 08:53:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:51 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:51 --> URI Class Initialized
INFO - 2020-09-23 08:53:51 --> Router Class Initialized
INFO - 2020-09-23 08:53:51 --> Output Class Initialized
INFO - 2020-09-23 08:53:51 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:51 --> Input Class Initialized
INFO - 2020-09-23 08:53:51 --> Language Class Initialized
INFO - 2020-09-23 08:53:51 --> Language Class Initialized
INFO - 2020-09-23 08:53:51 --> Config Class Initialized
INFO - 2020-09-23 08:53:51 --> Loader Class Initialized
INFO - 2020-09-23 08:53:51 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:51 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:51 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:51 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:51 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:51 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:53:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:53:51 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:51 --> Total execution time: 0.0623
INFO - 2020-09-23 08:53:57 --> Config Class Initialized
INFO - 2020-09-23 08:53:57 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:53:57 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:53:57 --> Utf8 Class Initialized
INFO - 2020-09-23 08:53:57 --> URI Class Initialized
INFO - 2020-09-23 08:53:57 --> Router Class Initialized
INFO - 2020-09-23 08:53:57 --> Output Class Initialized
INFO - 2020-09-23 08:53:57 --> Security Class Initialized
DEBUG - 2020-09-23 08:53:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:53:57 --> Input Class Initialized
INFO - 2020-09-23 08:53:57 --> Language Class Initialized
INFO - 2020-09-23 08:53:57 --> Language Class Initialized
INFO - 2020-09-23 08:53:57 --> Config Class Initialized
INFO - 2020-09-23 08:53:57 --> Loader Class Initialized
INFO - 2020-09-23 08:53:57 --> Helper loaded: url_helper
INFO - 2020-09-23 08:53:57 --> Helper loaded: file_helper
INFO - 2020-09-23 08:53:57 --> Helper loaded: form_helper
INFO - 2020-09-23 08:53:57 --> Helper loaded: my_helper
INFO - 2020-09-23 08:53:57 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:53:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:53:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:53:57 --> Controller Class Initialized
DEBUG - 2020-09-23 08:53:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2020-09-23 08:53:57 --> Final output sent to browser
DEBUG - 2020-09-23 08:53:57 --> Total execution time: 0.2747
INFO - 2020-09-23 08:54:08 --> Config Class Initialized
INFO - 2020-09-23 08:54:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:08 --> URI Class Initialized
INFO - 2020-09-23 08:54:08 --> Router Class Initialized
INFO - 2020-09-23 08:54:08 --> Output Class Initialized
INFO - 2020-09-23 08:54:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:08 --> Input Class Initialized
INFO - 2020-09-23 08:54:08 --> Language Class Initialized
INFO - 2020-09-23 08:54:08 --> Language Class Initialized
INFO - 2020-09-23 08:54:08 --> Config Class Initialized
INFO - 2020-09-23 08:54:08 --> Loader Class Initialized
INFO - 2020-09-23 08:54:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:08 --> Controller Class Initialized
INFO - 2020-09-23 08:54:08 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:54:08 --> Config Class Initialized
INFO - 2020-09-23 08:54:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:08 --> URI Class Initialized
INFO - 2020-09-23 08:54:08 --> Router Class Initialized
INFO - 2020-09-23 08:54:08 --> Output Class Initialized
INFO - 2020-09-23 08:54:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:08 --> Input Class Initialized
INFO - 2020-09-23 08:54:08 --> Language Class Initialized
INFO - 2020-09-23 08:54:08 --> Language Class Initialized
INFO - 2020-09-23 08:54:08 --> Config Class Initialized
INFO - 2020-09-23 08:54:08 --> Loader Class Initialized
INFO - 2020-09-23 08:54:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:08 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:54:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:54:08 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:08 --> Total execution time: 0.0506
INFO - 2020-09-23 08:54:14 --> Config Class Initialized
INFO - 2020-09-23 08:54:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:14 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:14 --> URI Class Initialized
INFO - 2020-09-23 08:54:14 --> Router Class Initialized
INFO - 2020-09-23 08:54:14 --> Output Class Initialized
INFO - 2020-09-23 08:54:14 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:14 --> Input Class Initialized
INFO - 2020-09-23 08:54:14 --> Language Class Initialized
INFO - 2020-09-23 08:54:14 --> Language Class Initialized
INFO - 2020-09-23 08:54:14 --> Config Class Initialized
INFO - 2020-09-23 08:54:14 --> Loader Class Initialized
INFO - 2020-09-23 08:54:14 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:14 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:14 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:14 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:14 --> Controller Class Initialized
INFO - 2020-09-23 08:54:14 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:54:14 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:14 --> Total execution time: 0.0461
INFO - 2020-09-23 08:54:15 --> Config Class Initialized
INFO - 2020-09-23 08:54:15 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:15 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:15 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:15 --> URI Class Initialized
INFO - 2020-09-23 08:54:15 --> Router Class Initialized
INFO - 2020-09-23 08:54:15 --> Output Class Initialized
INFO - 2020-09-23 08:54:15 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:15 --> Input Class Initialized
INFO - 2020-09-23 08:54:15 --> Language Class Initialized
INFO - 2020-09-23 08:54:15 --> Language Class Initialized
INFO - 2020-09-23 08:54:15 --> Config Class Initialized
INFO - 2020-09-23 08:54:15 --> Loader Class Initialized
INFO - 2020-09-23 08:54:15 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:15 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:15 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:15 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:15 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:15 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:54:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:54:15 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:15 --> Total execution time: 0.6403
INFO - 2020-09-23 08:54:17 --> Config Class Initialized
INFO - 2020-09-23 08:54:17 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:17 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:17 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:17 --> URI Class Initialized
INFO - 2020-09-23 08:54:17 --> Router Class Initialized
INFO - 2020-09-23 08:54:17 --> Output Class Initialized
INFO - 2020-09-23 08:54:17 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:17 --> Input Class Initialized
INFO - 2020-09-23 08:54:17 --> Language Class Initialized
INFO - 2020-09-23 08:54:17 --> Language Class Initialized
INFO - 2020-09-23 08:54:17 --> Config Class Initialized
INFO - 2020-09-23 08:54:17 --> Loader Class Initialized
INFO - 2020-09-23 08:54:17 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:17 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:17 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:17 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:17 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:17 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:54:17 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:17 --> Total execution time: 0.0519
INFO - 2020-09-23 08:54:21 --> Config Class Initialized
INFO - 2020-09-23 08:54:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:21 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:21 --> URI Class Initialized
INFO - 2020-09-23 08:54:21 --> Router Class Initialized
INFO - 2020-09-23 08:54:21 --> Output Class Initialized
INFO - 2020-09-23 08:54:21 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:21 --> Input Class Initialized
INFO - 2020-09-23 08:54:21 --> Language Class Initialized
INFO - 2020-09-23 08:54:21 --> Language Class Initialized
INFO - 2020-09-23 08:54:21 --> Config Class Initialized
INFO - 2020-09-23 08:54:21 --> Loader Class Initialized
INFO - 2020-09-23 08:54:21 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:21 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:21 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:21 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:21 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2020-09-23 08:54:21 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:21 --> Total execution time: 0.3883
INFO - 2020-09-23 08:54:31 --> Config Class Initialized
INFO - 2020-09-23 08:54:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:31 --> URI Class Initialized
INFO - 2020-09-23 08:54:31 --> Router Class Initialized
INFO - 2020-09-23 08:54:31 --> Output Class Initialized
INFO - 2020-09-23 08:54:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:31 --> Input Class Initialized
INFO - 2020-09-23 08:54:31 --> Language Class Initialized
INFO - 2020-09-23 08:54:31 --> Language Class Initialized
INFO - 2020-09-23 08:54:31 --> Config Class Initialized
INFO - 2020-09-23 08:54:31 --> Loader Class Initialized
INFO - 2020-09-23 08:54:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:31 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:31 --> Controller Class Initialized
INFO - 2020-09-23 08:54:31 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:54:31 --> Config Class Initialized
INFO - 2020-09-23 08:54:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:31 --> URI Class Initialized
INFO - 2020-09-23 08:54:31 --> Router Class Initialized
INFO - 2020-09-23 08:54:31 --> Output Class Initialized
INFO - 2020-09-23 08:54:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:31 --> Input Class Initialized
INFO - 2020-09-23 08:54:31 --> Language Class Initialized
INFO - 2020-09-23 08:54:31 --> Language Class Initialized
INFO - 2020-09-23 08:54:31 --> Config Class Initialized
INFO - 2020-09-23 08:54:31 --> Loader Class Initialized
INFO - 2020-09-23 08:54:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:32 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:32 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:54:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:54:32 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:32 --> Total execution time: 0.0507
INFO - 2020-09-23 08:54:37 --> Config Class Initialized
INFO - 2020-09-23 08:54:37 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:37 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:37 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:37 --> URI Class Initialized
INFO - 2020-09-23 08:54:37 --> Router Class Initialized
INFO - 2020-09-23 08:54:37 --> Output Class Initialized
INFO - 2020-09-23 08:54:37 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:37 --> Input Class Initialized
INFO - 2020-09-23 08:54:37 --> Language Class Initialized
INFO - 2020-09-23 08:54:37 --> Language Class Initialized
INFO - 2020-09-23 08:54:37 --> Config Class Initialized
INFO - 2020-09-23 08:54:37 --> Loader Class Initialized
INFO - 2020-09-23 08:54:37 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:37 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:37 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:37 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:37 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:37 --> Controller Class Initialized
INFO - 2020-09-23 08:54:37 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:54:37 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:37 --> Total execution time: 0.0465
INFO - 2020-09-23 08:54:38 --> Config Class Initialized
INFO - 2020-09-23 08:54:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:38 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:38 --> URI Class Initialized
INFO - 2020-09-23 08:54:38 --> Router Class Initialized
INFO - 2020-09-23 08:54:38 --> Output Class Initialized
INFO - 2020-09-23 08:54:38 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:38 --> Input Class Initialized
INFO - 2020-09-23 08:54:38 --> Language Class Initialized
INFO - 2020-09-23 08:54:38 --> Language Class Initialized
INFO - 2020-09-23 08:54:38 --> Config Class Initialized
INFO - 2020-09-23 08:54:38 --> Loader Class Initialized
INFO - 2020-09-23 08:54:38 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:38 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:38 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:38 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:38 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:38 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:54:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:54:38 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:38 --> Total execution time: 0.6352
INFO - 2020-09-23 08:54:40 --> Config Class Initialized
INFO - 2020-09-23 08:54:40 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:40 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:40 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:40 --> URI Class Initialized
INFO - 2020-09-23 08:54:40 --> Router Class Initialized
INFO - 2020-09-23 08:54:40 --> Output Class Initialized
INFO - 2020-09-23 08:54:40 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:40 --> Input Class Initialized
INFO - 2020-09-23 08:54:40 --> Language Class Initialized
INFO - 2020-09-23 08:54:40 --> Language Class Initialized
INFO - 2020-09-23 08:54:40 --> Config Class Initialized
INFO - 2020-09-23 08:54:40 --> Loader Class Initialized
INFO - 2020-09-23 08:54:40 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:40 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:40 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:40 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:40 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:40 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:54:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:54:40 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:40 --> Total execution time: 0.0535
INFO - 2020-09-23 08:54:44 --> Config Class Initialized
INFO - 2020-09-23 08:54:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:44 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:44 --> URI Class Initialized
INFO - 2020-09-23 08:54:44 --> Router Class Initialized
INFO - 2020-09-23 08:54:44 --> Output Class Initialized
INFO - 2020-09-23 08:54:44 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:44 --> Input Class Initialized
INFO - 2020-09-23 08:54:44 --> Language Class Initialized
INFO - 2020-09-23 08:54:44 --> Language Class Initialized
INFO - 2020-09-23 08:54:44 --> Config Class Initialized
INFO - 2020-09-23 08:54:44 --> Loader Class Initialized
INFO - 2020-09-23 08:54:44 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:44 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:44 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:44 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:44 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2020-09-23 08:54:45 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:45 --> Total execution time: 0.3380
INFO - 2020-09-23 08:54:56 --> Config Class Initialized
INFO - 2020-09-23 08:54:56 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:56 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:56 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:56 --> URI Class Initialized
INFO - 2020-09-23 08:54:56 --> Router Class Initialized
INFO - 2020-09-23 08:54:56 --> Output Class Initialized
INFO - 2020-09-23 08:54:56 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:56 --> Input Class Initialized
INFO - 2020-09-23 08:54:56 --> Language Class Initialized
INFO - 2020-09-23 08:54:56 --> Language Class Initialized
INFO - 2020-09-23 08:54:56 --> Config Class Initialized
INFO - 2020-09-23 08:54:56 --> Loader Class Initialized
INFO - 2020-09-23 08:54:56 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:56 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:56 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:56 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:56 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:56 --> Controller Class Initialized
INFO - 2020-09-23 08:54:56 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:54:56 --> Config Class Initialized
INFO - 2020-09-23 08:54:56 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:54:56 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:54:56 --> Utf8 Class Initialized
INFO - 2020-09-23 08:54:56 --> URI Class Initialized
INFO - 2020-09-23 08:54:56 --> Router Class Initialized
INFO - 2020-09-23 08:54:56 --> Output Class Initialized
INFO - 2020-09-23 08:54:56 --> Security Class Initialized
DEBUG - 2020-09-23 08:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:54:56 --> Input Class Initialized
INFO - 2020-09-23 08:54:56 --> Language Class Initialized
INFO - 2020-09-23 08:54:56 --> Language Class Initialized
INFO - 2020-09-23 08:54:56 --> Config Class Initialized
INFO - 2020-09-23 08:54:56 --> Loader Class Initialized
INFO - 2020-09-23 08:54:56 --> Helper loaded: url_helper
INFO - 2020-09-23 08:54:56 --> Helper loaded: file_helper
INFO - 2020-09-23 08:54:56 --> Helper loaded: form_helper
INFO - 2020-09-23 08:54:56 --> Helper loaded: my_helper
INFO - 2020-09-23 08:54:56 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:54:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:54:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:54:56 --> Controller Class Initialized
DEBUG - 2020-09-23 08:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:54:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:54:56 --> Final output sent to browser
DEBUG - 2020-09-23 08:54:56 --> Total execution time: 0.0404
INFO - 2020-09-23 08:55:00 --> Config Class Initialized
INFO - 2020-09-23 08:55:00 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:00 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:00 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:00 --> URI Class Initialized
INFO - 2020-09-23 08:55:00 --> Router Class Initialized
INFO - 2020-09-23 08:55:00 --> Output Class Initialized
INFO - 2020-09-23 08:55:00 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:00 --> Input Class Initialized
INFO - 2020-09-23 08:55:00 --> Language Class Initialized
INFO - 2020-09-23 08:55:00 --> Language Class Initialized
INFO - 2020-09-23 08:55:00 --> Config Class Initialized
INFO - 2020-09-23 08:55:00 --> Loader Class Initialized
INFO - 2020-09-23 08:55:00 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:00 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:00 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:00 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:00 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:00 --> Controller Class Initialized
INFO - 2020-09-23 08:55:00 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:55:00 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:00 --> Total execution time: 0.0453
INFO - 2020-09-23 08:55:00 --> Config Class Initialized
INFO - 2020-09-23 08:55:00 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:00 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:00 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:00 --> URI Class Initialized
INFO - 2020-09-23 08:55:00 --> Router Class Initialized
INFO - 2020-09-23 08:55:00 --> Output Class Initialized
INFO - 2020-09-23 08:55:00 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:00 --> Input Class Initialized
INFO - 2020-09-23 08:55:00 --> Language Class Initialized
INFO - 2020-09-23 08:55:00 --> Language Class Initialized
INFO - 2020-09-23 08:55:00 --> Config Class Initialized
INFO - 2020-09-23 08:55:00 --> Loader Class Initialized
INFO - 2020-09-23 08:55:00 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:00 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:00 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:00 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:00 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:00 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:55:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:01 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:01 --> Total execution time: 0.6376
INFO - 2020-09-23 08:55:02 --> Config Class Initialized
INFO - 2020-09-23 08:55:02 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:02 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:02 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:02 --> URI Class Initialized
INFO - 2020-09-23 08:55:02 --> Router Class Initialized
INFO - 2020-09-23 08:55:02 --> Output Class Initialized
INFO - 2020-09-23 08:55:02 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:02 --> Input Class Initialized
INFO - 2020-09-23 08:55:02 --> Language Class Initialized
INFO - 2020-09-23 08:55:02 --> Language Class Initialized
INFO - 2020-09-23 08:55:02 --> Config Class Initialized
INFO - 2020-09-23 08:55:02 --> Loader Class Initialized
INFO - 2020-09-23 08:55:02 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:02 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:02 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:02 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:02 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:02 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-09-23 08:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:02 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:02 --> Total execution time: 0.0611
INFO - 2020-09-23 08:55:03 --> Config Class Initialized
INFO - 2020-09-23 08:55:03 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:03 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:03 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:03 --> URI Class Initialized
INFO - 2020-09-23 08:55:03 --> Router Class Initialized
INFO - 2020-09-23 08:55:03 --> Output Class Initialized
INFO - 2020-09-23 08:55:03 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:03 --> Input Class Initialized
INFO - 2020-09-23 08:55:03 --> Language Class Initialized
INFO - 2020-09-23 08:55:03 --> Language Class Initialized
INFO - 2020-09-23 08:55:03 --> Config Class Initialized
INFO - 2020-09-23 08:55:03 --> Loader Class Initialized
INFO - 2020-09-23 08:55:03 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:03 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:03 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:03 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:03 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:03 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:55:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:03 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:03 --> Total execution time: 0.0631
INFO - 2020-09-23 08:55:07 --> Config Class Initialized
INFO - 2020-09-23 08:55:07 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:07 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:07 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:07 --> URI Class Initialized
INFO - 2020-09-23 08:55:07 --> Router Class Initialized
INFO - 2020-09-23 08:55:07 --> Output Class Initialized
INFO - 2020-09-23 08:55:07 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:07 --> Input Class Initialized
INFO - 2020-09-23 08:55:07 --> Language Class Initialized
INFO - 2020-09-23 08:55:07 --> Language Class Initialized
INFO - 2020-09-23 08:55:07 --> Config Class Initialized
INFO - 2020-09-23 08:55:07 --> Loader Class Initialized
INFO - 2020-09-23 08:55:07 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:07 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:07 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:07 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:07 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:07 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2020-09-23 08:55:07 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:07 --> Total execution time: 0.3162
INFO - 2020-09-23 08:55:16 --> Config Class Initialized
INFO - 2020-09-23 08:55:16 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:16 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:16 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:16 --> URI Class Initialized
INFO - 2020-09-23 08:55:16 --> Router Class Initialized
INFO - 2020-09-23 08:55:16 --> Output Class Initialized
INFO - 2020-09-23 08:55:16 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:16 --> Input Class Initialized
INFO - 2020-09-23 08:55:16 --> Language Class Initialized
INFO - 2020-09-23 08:55:16 --> Language Class Initialized
INFO - 2020-09-23 08:55:16 --> Config Class Initialized
INFO - 2020-09-23 08:55:16 --> Loader Class Initialized
INFO - 2020-09-23 08:55:16 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:16 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:16 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:16 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:16 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:16 --> Controller Class Initialized
INFO - 2020-09-23 08:55:16 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:55:16 --> Config Class Initialized
INFO - 2020-09-23 08:55:16 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:16 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:16 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:16 --> URI Class Initialized
INFO - 2020-09-23 08:55:16 --> Router Class Initialized
INFO - 2020-09-23 08:55:16 --> Output Class Initialized
INFO - 2020-09-23 08:55:16 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:16 --> Input Class Initialized
INFO - 2020-09-23 08:55:16 --> Language Class Initialized
INFO - 2020-09-23 08:55:16 --> Language Class Initialized
INFO - 2020-09-23 08:55:16 --> Config Class Initialized
INFO - 2020-09-23 08:55:16 --> Loader Class Initialized
INFO - 2020-09-23 08:55:16 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:16 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:16 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:16 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:17 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:17 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:55:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:17 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:17 --> Total execution time: 0.0523
INFO - 2020-09-23 08:55:21 --> Config Class Initialized
INFO - 2020-09-23 08:55:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:21 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:21 --> URI Class Initialized
INFO - 2020-09-23 08:55:21 --> Router Class Initialized
INFO - 2020-09-23 08:55:21 --> Output Class Initialized
INFO - 2020-09-23 08:55:21 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:21 --> Input Class Initialized
INFO - 2020-09-23 08:55:21 --> Language Class Initialized
INFO - 2020-09-23 08:55:21 --> Language Class Initialized
INFO - 2020-09-23 08:55:21 --> Config Class Initialized
INFO - 2020-09-23 08:55:21 --> Loader Class Initialized
INFO - 2020-09-23 08:55:21 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:21 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:21 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:21 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:21 --> Controller Class Initialized
INFO - 2020-09-23 08:55:21 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:55:21 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:21 --> Total execution time: 0.0459
INFO - 2020-09-23 08:55:21 --> Config Class Initialized
INFO - 2020-09-23 08:55:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:21 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:21 --> URI Class Initialized
INFO - 2020-09-23 08:55:21 --> Router Class Initialized
INFO - 2020-09-23 08:55:21 --> Output Class Initialized
INFO - 2020-09-23 08:55:21 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:21 --> Input Class Initialized
INFO - 2020-09-23 08:55:21 --> Language Class Initialized
INFO - 2020-09-23 08:55:21 --> Language Class Initialized
INFO - 2020-09-23 08:55:21 --> Config Class Initialized
INFO - 2020-09-23 08:55:21 --> Loader Class Initialized
INFO - 2020-09-23 08:55:21 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:21 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:21 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:21 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:21 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:55:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:22 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:22 --> Total execution time: 0.6465
INFO - 2020-09-23 08:55:23 --> Config Class Initialized
INFO - 2020-09-23 08:55:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:23 --> URI Class Initialized
INFO - 2020-09-23 08:55:23 --> Router Class Initialized
INFO - 2020-09-23 08:55:23 --> Output Class Initialized
INFO - 2020-09-23 08:55:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:23 --> Input Class Initialized
INFO - 2020-09-23 08:55:23 --> Language Class Initialized
INFO - 2020-09-23 08:55:23 --> Language Class Initialized
INFO - 2020-09-23 08:55:23 --> Config Class Initialized
INFO - 2020-09-23 08:55:23 --> Loader Class Initialized
INFO - 2020-09-23 08:55:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:23 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:55:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:23 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:23 --> Total execution time: 0.0614
INFO - 2020-09-23 08:55:27 --> Config Class Initialized
INFO - 2020-09-23 08:55:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:27 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:27 --> URI Class Initialized
INFO - 2020-09-23 08:55:27 --> Router Class Initialized
INFO - 2020-09-23 08:55:27 --> Output Class Initialized
INFO - 2020-09-23 08:55:27 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:27 --> Input Class Initialized
INFO - 2020-09-23 08:55:27 --> Language Class Initialized
INFO - 2020-09-23 08:55:27 --> Language Class Initialized
INFO - 2020-09-23 08:55:27 --> Config Class Initialized
INFO - 2020-09-23 08:55:27 --> Loader Class Initialized
INFO - 2020-09-23 08:55:27 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:27 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:27 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:27 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:27 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:27 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2020-09-23 08:55:27 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:27 --> Total execution time: 0.3229
INFO - 2020-09-23 08:55:44 --> Config Class Initialized
INFO - 2020-09-23 08:55:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:44 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:44 --> URI Class Initialized
INFO - 2020-09-23 08:55:44 --> Router Class Initialized
INFO - 2020-09-23 08:55:44 --> Output Class Initialized
INFO - 2020-09-23 08:55:44 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:44 --> Input Class Initialized
INFO - 2020-09-23 08:55:44 --> Language Class Initialized
INFO - 2020-09-23 08:55:44 --> Language Class Initialized
INFO - 2020-09-23 08:55:44 --> Config Class Initialized
INFO - 2020-09-23 08:55:44 --> Loader Class Initialized
INFO - 2020-09-23 08:55:44 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:44 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:44 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:44 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:44 --> Controller Class Initialized
INFO - 2020-09-23 08:55:44 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:55:44 --> Config Class Initialized
INFO - 2020-09-23 08:55:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:44 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:44 --> URI Class Initialized
INFO - 2020-09-23 08:55:44 --> Router Class Initialized
INFO - 2020-09-23 08:55:44 --> Output Class Initialized
INFO - 2020-09-23 08:55:44 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:44 --> Input Class Initialized
INFO - 2020-09-23 08:55:44 --> Language Class Initialized
INFO - 2020-09-23 08:55:44 --> Language Class Initialized
INFO - 2020-09-23 08:55:44 --> Config Class Initialized
INFO - 2020-09-23 08:55:44 --> Loader Class Initialized
INFO - 2020-09-23 08:55:44 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:44 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:44 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:44 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:44 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:44 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:44 --> Total execution time: 0.0509
INFO - 2020-09-23 08:55:48 --> Config Class Initialized
INFO - 2020-09-23 08:55:48 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:48 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:48 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:48 --> URI Class Initialized
INFO - 2020-09-23 08:55:48 --> Router Class Initialized
INFO - 2020-09-23 08:55:48 --> Output Class Initialized
INFO - 2020-09-23 08:55:48 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:48 --> Input Class Initialized
INFO - 2020-09-23 08:55:48 --> Language Class Initialized
INFO - 2020-09-23 08:55:48 --> Language Class Initialized
INFO - 2020-09-23 08:55:48 --> Config Class Initialized
INFO - 2020-09-23 08:55:48 --> Loader Class Initialized
INFO - 2020-09-23 08:55:48 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:48 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:48 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:48 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:48 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:48 --> Controller Class Initialized
INFO - 2020-09-23 08:55:48 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:55:48 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:48 --> Total execution time: 0.0460
INFO - 2020-09-23 08:55:48 --> Config Class Initialized
INFO - 2020-09-23 08:55:48 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:48 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:48 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:48 --> URI Class Initialized
INFO - 2020-09-23 08:55:48 --> Router Class Initialized
INFO - 2020-09-23 08:55:48 --> Output Class Initialized
INFO - 2020-09-23 08:55:48 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:48 --> Input Class Initialized
INFO - 2020-09-23 08:55:48 --> Language Class Initialized
INFO - 2020-09-23 08:55:48 --> Language Class Initialized
INFO - 2020-09-23 08:55:48 --> Config Class Initialized
INFO - 2020-09-23 08:55:48 --> Loader Class Initialized
INFO - 2020-09-23 08:55:48 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:48 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:48 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:48 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:48 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:48 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:55:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:49 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:49 --> Total execution time: 0.6393
INFO - 2020-09-23 08:55:51 --> Config Class Initialized
INFO - 2020-09-23 08:55:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:51 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:51 --> URI Class Initialized
INFO - 2020-09-23 08:55:51 --> Router Class Initialized
INFO - 2020-09-23 08:55:51 --> Output Class Initialized
INFO - 2020-09-23 08:55:51 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:51 --> Input Class Initialized
INFO - 2020-09-23 08:55:51 --> Language Class Initialized
INFO - 2020-09-23 08:55:51 --> Language Class Initialized
INFO - 2020-09-23 08:55:51 --> Config Class Initialized
INFO - 2020-09-23 08:55:51 --> Loader Class Initialized
INFO - 2020-09-23 08:55:51 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:51 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:51 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:51 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:51 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:51 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:55:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:55:51 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:51 --> Total execution time: 0.0615
INFO - 2020-09-23 08:55:52 --> Config Class Initialized
INFO - 2020-09-23 08:55:52 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:55:52 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:55:52 --> Utf8 Class Initialized
INFO - 2020-09-23 08:55:52 --> URI Class Initialized
INFO - 2020-09-23 08:55:52 --> Router Class Initialized
INFO - 2020-09-23 08:55:52 --> Output Class Initialized
INFO - 2020-09-23 08:55:52 --> Security Class Initialized
DEBUG - 2020-09-23 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:55:52 --> Input Class Initialized
INFO - 2020-09-23 08:55:52 --> Language Class Initialized
INFO - 2020-09-23 08:55:52 --> Language Class Initialized
INFO - 2020-09-23 08:55:52 --> Config Class Initialized
INFO - 2020-09-23 08:55:52 --> Loader Class Initialized
INFO - 2020-09-23 08:55:52 --> Helper loaded: url_helper
INFO - 2020-09-23 08:55:52 --> Helper loaded: file_helper
INFO - 2020-09-23 08:55:52 --> Helper loaded: form_helper
INFO - 2020-09-23 08:55:52 --> Helper loaded: my_helper
INFO - 2020-09-23 08:55:52 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:55:52 --> Controller Class Initialized
DEBUG - 2020-09-23 08:55:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xii.php
INFO - 2020-09-23 08:55:53 --> Final output sent to browser
DEBUG - 2020-09-23 08:55:53 --> Total execution time: 0.2940
INFO - 2020-09-23 08:56:02 --> Config Class Initialized
INFO - 2020-09-23 08:56:02 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:02 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:02 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:02 --> URI Class Initialized
INFO - 2020-09-23 08:56:02 --> Router Class Initialized
INFO - 2020-09-23 08:56:02 --> Output Class Initialized
INFO - 2020-09-23 08:56:02 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:02 --> Input Class Initialized
INFO - 2020-09-23 08:56:02 --> Language Class Initialized
INFO - 2020-09-23 08:56:02 --> Language Class Initialized
INFO - 2020-09-23 08:56:02 --> Config Class Initialized
INFO - 2020-09-23 08:56:02 --> Loader Class Initialized
INFO - 2020-09-23 08:56:02 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:02 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:02 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:02 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:02 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:02 --> Controller Class Initialized
INFO - 2020-09-23 08:56:02 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:56:02 --> Config Class Initialized
INFO - 2020-09-23 08:56:02 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:02 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:02 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:02 --> URI Class Initialized
INFO - 2020-09-23 08:56:02 --> Router Class Initialized
INFO - 2020-09-23 08:56:02 --> Output Class Initialized
INFO - 2020-09-23 08:56:02 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:02 --> Input Class Initialized
INFO - 2020-09-23 08:56:02 --> Language Class Initialized
INFO - 2020-09-23 08:56:02 --> Language Class Initialized
INFO - 2020-09-23 08:56:02 --> Config Class Initialized
INFO - 2020-09-23 08:56:02 --> Loader Class Initialized
INFO - 2020-09-23 08:56:02 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:02 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:02 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:02 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:02 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:02 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:56:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:56:02 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:02 --> Total execution time: 0.0516
INFO - 2020-09-23 08:56:08 --> Config Class Initialized
INFO - 2020-09-23 08:56:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:08 --> URI Class Initialized
INFO - 2020-09-23 08:56:08 --> Router Class Initialized
INFO - 2020-09-23 08:56:08 --> Output Class Initialized
INFO - 2020-09-23 08:56:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:08 --> Input Class Initialized
INFO - 2020-09-23 08:56:08 --> Language Class Initialized
INFO - 2020-09-23 08:56:08 --> Language Class Initialized
INFO - 2020-09-23 08:56:08 --> Config Class Initialized
INFO - 2020-09-23 08:56:08 --> Loader Class Initialized
INFO - 2020-09-23 08:56:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:08 --> Controller Class Initialized
INFO - 2020-09-23 08:56:08 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:56:08 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:08 --> Total execution time: 0.0458
INFO - 2020-09-23 08:56:08 --> Config Class Initialized
INFO - 2020-09-23 08:56:08 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:08 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:08 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:08 --> URI Class Initialized
INFO - 2020-09-23 08:56:08 --> Router Class Initialized
INFO - 2020-09-23 08:56:08 --> Output Class Initialized
INFO - 2020-09-23 08:56:08 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:08 --> Input Class Initialized
INFO - 2020-09-23 08:56:08 --> Language Class Initialized
INFO - 2020-09-23 08:56:08 --> Language Class Initialized
INFO - 2020-09-23 08:56:08 --> Config Class Initialized
INFO - 2020-09-23 08:56:08 --> Loader Class Initialized
INFO - 2020-09-23 08:56:08 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:08 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:08 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:08 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:08 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:08 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:56:09 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:09 --> Total execution time: 0.6375
INFO - 2020-09-23 08:56:10 --> Config Class Initialized
INFO - 2020-09-23 08:56:10 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:10 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:10 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:10 --> URI Class Initialized
INFO - 2020-09-23 08:56:10 --> Router Class Initialized
INFO - 2020-09-23 08:56:10 --> Output Class Initialized
INFO - 2020-09-23 08:56:10 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:10 --> Input Class Initialized
INFO - 2020-09-23 08:56:10 --> Language Class Initialized
INFO - 2020-09-23 08:56:10 --> Language Class Initialized
INFO - 2020-09-23 08:56:10 --> Config Class Initialized
INFO - 2020-09-23 08:56:10 --> Loader Class Initialized
INFO - 2020-09-23 08:56:10 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:10 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:10 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:10 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:10 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:10 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:56:10 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:10 --> Total execution time: 0.0623
INFO - 2020-09-23 08:56:14 --> Config Class Initialized
INFO - 2020-09-23 08:56:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:14 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:14 --> URI Class Initialized
INFO - 2020-09-23 08:56:14 --> Router Class Initialized
INFO - 2020-09-23 08:56:14 --> Output Class Initialized
INFO - 2020-09-23 08:56:14 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:14 --> Input Class Initialized
INFO - 2020-09-23 08:56:14 --> Language Class Initialized
INFO - 2020-09-23 08:56:14 --> Language Class Initialized
INFO - 2020-09-23 08:56:14 --> Config Class Initialized
INFO - 2020-09-23 08:56:14 --> Loader Class Initialized
INFO - 2020-09-23 08:56:14 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:14 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:14 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:14 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:14 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2020-09-23 08:56:14 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:14 --> Total execution time: 0.3466
INFO - 2020-09-23 08:56:27 --> Config Class Initialized
INFO - 2020-09-23 08:56:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:27 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:27 --> URI Class Initialized
INFO - 2020-09-23 08:56:27 --> Router Class Initialized
INFO - 2020-09-23 08:56:27 --> Output Class Initialized
INFO - 2020-09-23 08:56:27 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:27 --> Input Class Initialized
INFO - 2020-09-23 08:56:27 --> Language Class Initialized
INFO - 2020-09-23 08:56:27 --> Language Class Initialized
INFO - 2020-09-23 08:56:27 --> Config Class Initialized
INFO - 2020-09-23 08:56:27 --> Loader Class Initialized
INFO - 2020-09-23 08:56:27 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:27 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:27 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:27 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:27 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:27 --> Controller Class Initialized
INFO - 2020-09-23 08:56:27 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:56:27 --> Config Class Initialized
INFO - 2020-09-23 08:56:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:27 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:27 --> URI Class Initialized
INFO - 2020-09-23 08:56:27 --> Router Class Initialized
INFO - 2020-09-23 08:56:27 --> Output Class Initialized
INFO - 2020-09-23 08:56:27 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:27 --> Input Class Initialized
INFO - 2020-09-23 08:56:27 --> Language Class Initialized
INFO - 2020-09-23 08:56:27 --> Language Class Initialized
INFO - 2020-09-23 08:56:27 --> Config Class Initialized
INFO - 2020-09-23 08:56:27 --> Loader Class Initialized
INFO - 2020-09-23 08:56:27 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:27 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:27 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:27 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:27 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:27 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:56:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:56:27 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:27 --> Total execution time: 0.0424
INFO - 2020-09-23 08:56:31 --> Config Class Initialized
INFO - 2020-09-23 08:56:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:31 --> URI Class Initialized
INFO - 2020-09-23 08:56:31 --> Router Class Initialized
INFO - 2020-09-23 08:56:31 --> Output Class Initialized
INFO - 2020-09-23 08:56:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:31 --> Input Class Initialized
INFO - 2020-09-23 08:56:31 --> Language Class Initialized
INFO - 2020-09-23 08:56:31 --> Language Class Initialized
INFO - 2020-09-23 08:56:31 --> Config Class Initialized
INFO - 2020-09-23 08:56:31 --> Loader Class Initialized
INFO - 2020-09-23 08:56:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:31 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:31 --> Controller Class Initialized
INFO - 2020-09-23 08:56:31 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:56:31 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:31 --> Total execution time: 0.0570
INFO - 2020-09-23 08:56:31 --> Config Class Initialized
INFO - 2020-09-23 08:56:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:31 --> URI Class Initialized
INFO - 2020-09-23 08:56:31 --> Router Class Initialized
INFO - 2020-09-23 08:56:31 --> Output Class Initialized
INFO - 2020-09-23 08:56:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:31 --> Input Class Initialized
INFO - 2020-09-23 08:56:31 --> Language Class Initialized
INFO - 2020-09-23 08:56:31 --> Language Class Initialized
INFO - 2020-09-23 08:56:31 --> Config Class Initialized
INFO - 2020-09-23 08:56:31 --> Loader Class Initialized
INFO - 2020-09-23 08:56:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:31 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:31 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:56:32 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:32 --> Total execution time: 0.6510
INFO - 2020-09-23 08:56:33 --> Config Class Initialized
INFO - 2020-09-23 08:56:33 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:33 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:33 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:33 --> URI Class Initialized
INFO - 2020-09-23 08:56:33 --> Router Class Initialized
INFO - 2020-09-23 08:56:33 --> Output Class Initialized
INFO - 2020-09-23 08:56:33 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:33 --> Input Class Initialized
INFO - 2020-09-23 08:56:33 --> Language Class Initialized
INFO - 2020-09-23 08:56:33 --> Language Class Initialized
INFO - 2020-09-23 08:56:33 --> Config Class Initialized
INFO - 2020-09-23 08:56:33 --> Loader Class Initialized
INFO - 2020-09-23 08:56:33 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:33 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:33 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:33 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:33 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:33 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:56:33 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:33 --> Total execution time: 0.0607
INFO - 2020-09-23 08:56:36 --> Config Class Initialized
INFO - 2020-09-23 08:56:36 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:56:36 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:56:36 --> Utf8 Class Initialized
INFO - 2020-09-23 08:56:36 --> URI Class Initialized
INFO - 2020-09-23 08:56:36 --> Router Class Initialized
INFO - 2020-09-23 08:56:36 --> Output Class Initialized
INFO - 2020-09-23 08:56:36 --> Security Class Initialized
DEBUG - 2020-09-23 08:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:56:36 --> Input Class Initialized
INFO - 2020-09-23 08:56:36 --> Language Class Initialized
INFO - 2020-09-23 08:56:36 --> Language Class Initialized
INFO - 2020-09-23 08:56:36 --> Config Class Initialized
INFO - 2020-09-23 08:56:36 --> Loader Class Initialized
INFO - 2020-09-23 08:56:36 --> Helper loaded: url_helper
INFO - 2020-09-23 08:56:36 --> Helper loaded: file_helper
INFO - 2020-09-23 08:56:36 --> Helper loaded: form_helper
INFO - 2020-09-23 08:56:36 --> Helper loaded: my_helper
INFO - 2020-09-23 08:56:36 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:56:36 --> Controller Class Initialized
DEBUG - 2020-09-23 08:56:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2020-09-23 08:56:36 --> Final output sent to browser
DEBUG - 2020-09-23 08:56:36 --> Total execution time: 0.3524
INFO - 2020-09-23 08:57:23 --> Config Class Initialized
INFO - 2020-09-23 08:57:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:23 --> URI Class Initialized
INFO - 2020-09-23 08:57:23 --> Router Class Initialized
INFO - 2020-09-23 08:57:23 --> Output Class Initialized
INFO - 2020-09-23 08:57:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:23 --> Input Class Initialized
INFO - 2020-09-23 08:57:23 --> Language Class Initialized
INFO - 2020-09-23 08:57:23 --> Language Class Initialized
INFO - 2020-09-23 08:57:23 --> Config Class Initialized
INFO - 2020-09-23 08:57:23 --> Loader Class Initialized
INFO - 2020-09-23 08:57:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:23 --> Controller Class Initialized
INFO - 2020-09-23 08:57:24 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:57:24 --> Config Class Initialized
INFO - 2020-09-23 08:57:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:24 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:24 --> URI Class Initialized
INFO - 2020-09-23 08:57:24 --> Router Class Initialized
INFO - 2020-09-23 08:57:24 --> Output Class Initialized
INFO - 2020-09-23 08:57:24 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:24 --> Input Class Initialized
INFO - 2020-09-23 08:57:24 --> Language Class Initialized
INFO - 2020-09-23 08:57:24 --> Language Class Initialized
INFO - 2020-09-23 08:57:24 --> Config Class Initialized
INFO - 2020-09-23 08:57:24 --> Loader Class Initialized
INFO - 2020-09-23 08:57:24 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:24 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:24 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:24 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:24 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:24 --> Controller Class Initialized
DEBUG - 2020-09-23 08:57:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:57:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:57:24 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:24 --> Total execution time: 0.0501
INFO - 2020-09-23 08:57:31 --> Config Class Initialized
INFO - 2020-09-23 08:57:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:31 --> URI Class Initialized
INFO - 2020-09-23 08:57:31 --> Router Class Initialized
INFO - 2020-09-23 08:57:31 --> Output Class Initialized
INFO - 2020-09-23 08:57:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:31 --> Input Class Initialized
INFO - 2020-09-23 08:57:31 --> Language Class Initialized
INFO - 2020-09-23 08:57:31 --> Language Class Initialized
INFO - 2020-09-23 08:57:31 --> Config Class Initialized
INFO - 2020-09-23 08:57:31 --> Loader Class Initialized
INFO - 2020-09-23 08:57:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:31 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:31 --> Controller Class Initialized
INFO - 2020-09-23 08:57:31 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:57:31 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:31 --> Total execution time: 0.0459
INFO - 2020-09-23 08:57:31 --> Config Class Initialized
INFO - 2020-09-23 08:57:31 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:31 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:31 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:31 --> URI Class Initialized
INFO - 2020-09-23 08:57:31 --> Router Class Initialized
INFO - 2020-09-23 08:57:31 --> Output Class Initialized
INFO - 2020-09-23 08:57:31 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:31 --> Input Class Initialized
INFO - 2020-09-23 08:57:31 --> Language Class Initialized
INFO - 2020-09-23 08:57:31 --> Language Class Initialized
INFO - 2020-09-23 08:57:31 --> Config Class Initialized
INFO - 2020-09-23 08:57:31 --> Loader Class Initialized
INFO - 2020-09-23 08:57:31 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:31 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:31 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:31 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:31 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:31 --> Controller Class Initialized
DEBUG - 2020-09-23 08:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:57:32 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:32 --> Total execution time: 0.6411
INFO - 2020-09-23 08:57:32 --> Config Class Initialized
INFO - 2020-09-23 08:57:32 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:32 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:32 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:32 --> URI Class Initialized
INFO - 2020-09-23 08:57:32 --> Router Class Initialized
INFO - 2020-09-23 08:57:32 --> Output Class Initialized
INFO - 2020-09-23 08:57:32 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:32 --> Input Class Initialized
INFO - 2020-09-23 08:57:32 --> Language Class Initialized
INFO - 2020-09-23 08:57:32 --> Language Class Initialized
INFO - 2020-09-23 08:57:32 --> Config Class Initialized
INFO - 2020-09-23 08:57:32 --> Loader Class Initialized
INFO - 2020-09-23 08:57:32 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:32 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:32 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:32 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:32 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:32 --> Controller Class Initialized
DEBUG - 2020-09-23 08:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:57:32 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:32 --> Total execution time: 0.0619
INFO - 2020-09-23 08:57:37 --> Config Class Initialized
INFO - 2020-09-23 08:57:37 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:37 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:37 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:37 --> URI Class Initialized
INFO - 2020-09-23 08:57:37 --> Router Class Initialized
INFO - 2020-09-23 08:57:37 --> Output Class Initialized
INFO - 2020-09-23 08:57:37 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:37 --> Input Class Initialized
INFO - 2020-09-23 08:57:37 --> Language Class Initialized
INFO - 2020-09-23 08:57:37 --> Language Class Initialized
INFO - 2020-09-23 08:57:37 --> Config Class Initialized
INFO - 2020-09-23 08:57:37 --> Loader Class Initialized
INFO - 2020-09-23 08:57:37 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:37 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:37 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:37 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:37 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:37 --> Controller Class Initialized
DEBUG - 2020-09-23 08:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2020-09-23 08:57:37 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:37 --> Total execution time: 0.3288
INFO - 2020-09-23 08:57:49 --> Config Class Initialized
INFO - 2020-09-23 08:57:49 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:49 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:49 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:49 --> URI Class Initialized
INFO - 2020-09-23 08:57:49 --> Router Class Initialized
INFO - 2020-09-23 08:57:49 --> Output Class Initialized
INFO - 2020-09-23 08:57:49 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:49 --> Input Class Initialized
INFO - 2020-09-23 08:57:49 --> Language Class Initialized
INFO - 2020-09-23 08:57:49 --> Language Class Initialized
INFO - 2020-09-23 08:57:49 --> Config Class Initialized
INFO - 2020-09-23 08:57:49 --> Loader Class Initialized
INFO - 2020-09-23 08:57:49 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:49 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:49 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:49 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:49 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:49 --> Controller Class Initialized
INFO - 2020-09-23 08:57:49 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:57:49 --> Config Class Initialized
INFO - 2020-09-23 08:57:49 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:49 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:49 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:49 --> URI Class Initialized
INFO - 2020-09-23 08:57:49 --> Router Class Initialized
INFO - 2020-09-23 08:57:49 --> Output Class Initialized
INFO - 2020-09-23 08:57:49 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:49 --> Input Class Initialized
INFO - 2020-09-23 08:57:49 --> Language Class Initialized
INFO - 2020-09-23 08:57:49 --> Language Class Initialized
INFO - 2020-09-23 08:57:49 --> Config Class Initialized
INFO - 2020-09-23 08:57:49 --> Loader Class Initialized
INFO - 2020-09-23 08:57:49 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:49 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:49 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:49 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:49 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:49 --> Controller Class Initialized
DEBUG - 2020-09-23 08:57:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:57:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:57:49 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:49 --> Total execution time: 0.0501
INFO - 2020-09-23 08:57:55 --> Config Class Initialized
INFO - 2020-09-23 08:57:55 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:55 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:55 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:55 --> URI Class Initialized
INFO - 2020-09-23 08:57:55 --> Router Class Initialized
INFO - 2020-09-23 08:57:55 --> Output Class Initialized
INFO - 2020-09-23 08:57:55 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:55 --> Input Class Initialized
INFO - 2020-09-23 08:57:55 --> Language Class Initialized
INFO - 2020-09-23 08:57:55 --> Language Class Initialized
INFO - 2020-09-23 08:57:55 --> Config Class Initialized
INFO - 2020-09-23 08:57:55 --> Loader Class Initialized
INFO - 2020-09-23 08:57:55 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:55 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:55 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:55 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:55 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:55 --> Controller Class Initialized
INFO - 2020-09-23 08:57:55 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:57:55 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:55 --> Total execution time: 0.0461
INFO - 2020-09-23 08:57:55 --> Config Class Initialized
INFO - 2020-09-23 08:57:55 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:55 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:55 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:55 --> URI Class Initialized
INFO - 2020-09-23 08:57:55 --> Router Class Initialized
INFO - 2020-09-23 08:57:55 --> Output Class Initialized
INFO - 2020-09-23 08:57:55 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:55 --> Input Class Initialized
INFO - 2020-09-23 08:57:55 --> Language Class Initialized
INFO - 2020-09-23 08:57:55 --> Language Class Initialized
INFO - 2020-09-23 08:57:55 --> Config Class Initialized
INFO - 2020-09-23 08:57:55 --> Loader Class Initialized
INFO - 2020-09-23 08:57:55 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:55 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:55 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:55 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:55 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:55 --> Controller Class Initialized
DEBUG - 2020-09-23 08:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:57:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:57:56 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:56 --> Total execution time: 0.6407
INFO - 2020-09-23 08:57:57 --> Config Class Initialized
INFO - 2020-09-23 08:57:57 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:57:57 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:57:57 --> Utf8 Class Initialized
INFO - 2020-09-23 08:57:57 --> URI Class Initialized
INFO - 2020-09-23 08:57:57 --> Router Class Initialized
INFO - 2020-09-23 08:57:57 --> Output Class Initialized
INFO - 2020-09-23 08:57:57 --> Security Class Initialized
DEBUG - 2020-09-23 08:57:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:57:57 --> Input Class Initialized
INFO - 2020-09-23 08:57:57 --> Language Class Initialized
INFO - 2020-09-23 08:57:57 --> Language Class Initialized
INFO - 2020-09-23 08:57:57 --> Config Class Initialized
INFO - 2020-09-23 08:57:57 --> Loader Class Initialized
INFO - 2020-09-23 08:57:57 --> Helper loaded: url_helper
INFO - 2020-09-23 08:57:57 --> Helper loaded: file_helper
INFO - 2020-09-23 08:57:57 --> Helper loaded: form_helper
INFO - 2020-09-23 08:57:57 --> Helper loaded: my_helper
INFO - 2020-09-23 08:57:57 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:57:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:57:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:57:57 --> Controller Class Initialized
DEBUG - 2020-09-23 08:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:57:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:57:57 --> Final output sent to browser
DEBUG - 2020-09-23 08:57:57 --> Total execution time: 0.0611
INFO - 2020-09-23 08:58:01 --> Config Class Initialized
INFO - 2020-09-23 08:58:01 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:01 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:01 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:01 --> URI Class Initialized
INFO - 2020-09-23 08:58:01 --> Router Class Initialized
INFO - 2020-09-23 08:58:01 --> Output Class Initialized
INFO - 2020-09-23 08:58:01 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:01 --> Input Class Initialized
INFO - 2020-09-23 08:58:01 --> Language Class Initialized
INFO - 2020-09-23 08:58:01 --> Language Class Initialized
INFO - 2020-09-23 08:58:01 --> Config Class Initialized
INFO - 2020-09-23 08:58:01 --> Loader Class Initialized
INFO - 2020-09-23 08:58:01 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:01 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:01 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:01 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:01 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:01 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2020-09-23 08:58:02 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:02 --> Total execution time: 0.3250
INFO - 2020-09-23 08:58:14 --> Config Class Initialized
INFO - 2020-09-23 08:58:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:14 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:14 --> URI Class Initialized
INFO - 2020-09-23 08:58:14 --> Router Class Initialized
INFO - 2020-09-23 08:58:14 --> Output Class Initialized
INFO - 2020-09-23 08:58:14 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:14 --> Input Class Initialized
INFO - 2020-09-23 08:58:14 --> Language Class Initialized
INFO - 2020-09-23 08:58:14 --> Language Class Initialized
INFO - 2020-09-23 08:58:14 --> Config Class Initialized
INFO - 2020-09-23 08:58:14 --> Loader Class Initialized
INFO - 2020-09-23 08:58:14 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:14 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:14 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:14 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:14 --> Controller Class Initialized
INFO - 2020-09-23 08:58:14 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:58:14 --> Config Class Initialized
INFO - 2020-09-23 08:58:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:14 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:14 --> URI Class Initialized
INFO - 2020-09-23 08:58:14 --> Router Class Initialized
INFO - 2020-09-23 08:58:14 --> Output Class Initialized
INFO - 2020-09-23 08:58:14 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:14 --> Input Class Initialized
INFO - 2020-09-23 08:58:14 --> Language Class Initialized
INFO - 2020-09-23 08:58:14 --> Language Class Initialized
INFO - 2020-09-23 08:58:14 --> Config Class Initialized
INFO - 2020-09-23 08:58:14 --> Loader Class Initialized
INFO - 2020-09-23 08:58:14 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:14 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:14 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:14 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:14 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:58:14 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:14 --> Total execution time: 0.0411
INFO - 2020-09-23 08:58:21 --> Config Class Initialized
INFO - 2020-09-23 08:58:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:21 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:21 --> URI Class Initialized
INFO - 2020-09-23 08:58:21 --> Router Class Initialized
INFO - 2020-09-23 08:58:21 --> Output Class Initialized
INFO - 2020-09-23 08:58:21 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:21 --> Input Class Initialized
INFO - 2020-09-23 08:58:21 --> Language Class Initialized
INFO - 2020-09-23 08:58:21 --> Language Class Initialized
INFO - 2020-09-23 08:58:21 --> Config Class Initialized
INFO - 2020-09-23 08:58:21 --> Loader Class Initialized
INFO - 2020-09-23 08:58:21 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:21 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:21 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:21 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:21 --> Controller Class Initialized
INFO - 2020-09-23 08:58:21 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:58:21 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:21 --> Total execution time: 0.0459
INFO - 2020-09-23 08:58:21 --> Config Class Initialized
INFO - 2020-09-23 08:58:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:21 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:21 --> URI Class Initialized
INFO - 2020-09-23 08:58:21 --> Router Class Initialized
INFO - 2020-09-23 08:58:21 --> Output Class Initialized
INFO - 2020-09-23 08:58:21 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:21 --> Input Class Initialized
INFO - 2020-09-23 08:58:21 --> Language Class Initialized
INFO - 2020-09-23 08:58:21 --> Language Class Initialized
INFO - 2020-09-23 08:58:21 --> Config Class Initialized
INFO - 2020-09-23 08:58:21 --> Loader Class Initialized
INFO - 2020-09-23 08:58:21 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:21 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:21 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:21 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:21 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:58:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:58:22 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:22 --> Total execution time: 0.6355
INFO - 2020-09-23 08:58:23 --> Config Class Initialized
INFO - 2020-09-23 08:58:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:23 --> URI Class Initialized
INFO - 2020-09-23 08:58:23 --> Router Class Initialized
INFO - 2020-09-23 08:58:23 --> Output Class Initialized
INFO - 2020-09-23 08:58:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:23 --> Input Class Initialized
INFO - 2020-09-23 08:58:23 --> Language Class Initialized
INFO - 2020-09-23 08:58:23 --> Language Class Initialized
INFO - 2020-09-23 08:58:23 --> Config Class Initialized
INFO - 2020-09-23 08:58:23 --> Loader Class Initialized
INFO - 2020-09-23 08:58:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:23 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:58:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:58:23 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:23 --> Total execution time: 0.0605
INFO - 2020-09-23 08:58:27 --> Config Class Initialized
INFO - 2020-09-23 08:58:27 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:27 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:27 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:27 --> URI Class Initialized
INFO - 2020-09-23 08:58:27 --> Router Class Initialized
INFO - 2020-09-23 08:58:27 --> Output Class Initialized
INFO - 2020-09-23 08:58:27 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:27 --> Input Class Initialized
INFO - 2020-09-23 08:58:27 --> Language Class Initialized
INFO - 2020-09-23 08:58:27 --> Language Class Initialized
INFO - 2020-09-23 08:58:27 --> Config Class Initialized
INFO - 2020-09-23 08:58:27 --> Loader Class Initialized
INFO - 2020-09-23 08:58:27 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:27 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:27 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:27 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:27 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:27 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2020-09-23 08:58:27 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:27 --> Total execution time: 0.3659
INFO - 2020-09-23 08:58:37 --> Config Class Initialized
INFO - 2020-09-23 08:58:37 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:37 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:37 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:37 --> URI Class Initialized
INFO - 2020-09-23 08:58:37 --> Router Class Initialized
INFO - 2020-09-23 08:58:37 --> Output Class Initialized
INFO - 2020-09-23 08:58:37 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:37 --> Input Class Initialized
INFO - 2020-09-23 08:58:37 --> Language Class Initialized
INFO - 2020-09-23 08:58:37 --> Language Class Initialized
INFO - 2020-09-23 08:58:37 --> Config Class Initialized
INFO - 2020-09-23 08:58:37 --> Loader Class Initialized
INFO - 2020-09-23 08:58:37 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:37 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:37 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:37 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:37 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:37 --> Controller Class Initialized
INFO - 2020-09-23 08:58:37 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:58:37 --> Config Class Initialized
INFO - 2020-09-23 08:58:37 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:37 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:37 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:37 --> URI Class Initialized
INFO - 2020-09-23 08:58:37 --> Router Class Initialized
INFO - 2020-09-23 08:58:37 --> Output Class Initialized
INFO - 2020-09-23 08:58:37 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:37 --> Input Class Initialized
INFO - 2020-09-23 08:58:37 --> Language Class Initialized
INFO - 2020-09-23 08:58:37 --> Language Class Initialized
INFO - 2020-09-23 08:58:37 --> Config Class Initialized
INFO - 2020-09-23 08:58:37 --> Loader Class Initialized
INFO - 2020-09-23 08:58:37 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:37 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:37 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:37 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:37 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:37 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:58:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:58:37 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:37 --> Total execution time: 0.0514
INFO - 2020-09-23 08:58:42 --> Config Class Initialized
INFO - 2020-09-23 08:58:42 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:42 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:42 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:42 --> URI Class Initialized
INFO - 2020-09-23 08:58:42 --> Router Class Initialized
INFO - 2020-09-23 08:58:42 --> Output Class Initialized
INFO - 2020-09-23 08:58:42 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:42 --> Input Class Initialized
INFO - 2020-09-23 08:58:42 --> Language Class Initialized
INFO - 2020-09-23 08:58:42 --> Language Class Initialized
INFO - 2020-09-23 08:58:42 --> Config Class Initialized
INFO - 2020-09-23 08:58:42 --> Loader Class Initialized
INFO - 2020-09-23 08:58:42 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:42 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:42 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:42 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:42 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:42 --> Controller Class Initialized
INFO - 2020-09-23 08:58:42 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:58:42 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:42 --> Total execution time: 0.0457
INFO - 2020-09-23 08:58:42 --> Config Class Initialized
INFO - 2020-09-23 08:58:42 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:42 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:42 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:42 --> URI Class Initialized
INFO - 2020-09-23 08:58:42 --> Router Class Initialized
INFO - 2020-09-23 08:58:42 --> Output Class Initialized
INFO - 2020-09-23 08:58:42 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:42 --> Input Class Initialized
INFO - 2020-09-23 08:58:42 --> Language Class Initialized
INFO - 2020-09-23 08:58:42 --> Language Class Initialized
INFO - 2020-09-23 08:58:42 --> Config Class Initialized
INFO - 2020-09-23 08:58:42 --> Loader Class Initialized
INFO - 2020-09-23 08:58:42 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:42 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:42 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:42 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:42 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:42 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:58:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:58:43 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:43 --> Total execution time: 0.6360
INFO - 2020-09-23 08:58:44 --> Config Class Initialized
INFO - 2020-09-23 08:58:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:44 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:44 --> URI Class Initialized
INFO - 2020-09-23 08:58:44 --> Router Class Initialized
INFO - 2020-09-23 08:58:44 --> Output Class Initialized
INFO - 2020-09-23 08:58:44 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:44 --> Input Class Initialized
INFO - 2020-09-23 08:58:44 --> Language Class Initialized
INFO - 2020-09-23 08:58:44 --> Language Class Initialized
INFO - 2020-09-23 08:58:44 --> Config Class Initialized
INFO - 2020-09-23 08:58:44 --> Loader Class Initialized
INFO - 2020-09-23 08:58:44 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:44 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:44 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:44 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:44 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:58:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:58:44 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:44 --> Total execution time: 0.0608
INFO - 2020-09-23 08:58:46 --> Config Class Initialized
INFO - 2020-09-23 08:58:46 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:46 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:46 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:46 --> URI Class Initialized
INFO - 2020-09-23 08:58:46 --> Router Class Initialized
INFO - 2020-09-23 08:58:46 --> Output Class Initialized
INFO - 2020-09-23 08:58:46 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:46 --> Input Class Initialized
INFO - 2020-09-23 08:58:46 --> Language Class Initialized
INFO - 2020-09-23 08:58:46 --> Language Class Initialized
INFO - 2020-09-23 08:58:46 --> Config Class Initialized
INFO - 2020-09-23 08:58:46 --> Loader Class Initialized
INFO - 2020-09-23 08:58:46 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:46 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:46 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:46 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:46 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:46 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2020-09-23 08:58:46 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:46 --> Total execution time: 0.3113
INFO - 2020-09-23 08:58:56 --> Config Class Initialized
INFO - 2020-09-23 08:58:56 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:56 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:56 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:56 --> URI Class Initialized
INFO - 2020-09-23 08:58:56 --> Router Class Initialized
INFO - 2020-09-23 08:58:56 --> Output Class Initialized
INFO - 2020-09-23 08:58:56 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:56 --> Input Class Initialized
INFO - 2020-09-23 08:58:56 --> Language Class Initialized
INFO - 2020-09-23 08:58:56 --> Language Class Initialized
INFO - 2020-09-23 08:58:56 --> Config Class Initialized
INFO - 2020-09-23 08:58:56 --> Loader Class Initialized
INFO - 2020-09-23 08:58:56 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:56 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:56 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:56 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:56 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:56 --> Controller Class Initialized
INFO - 2020-09-23 08:58:56 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:58:56 --> Config Class Initialized
INFO - 2020-09-23 08:58:56 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:58:56 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:58:56 --> Utf8 Class Initialized
INFO - 2020-09-23 08:58:56 --> URI Class Initialized
INFO - 2020-09-23 08:58:56 --> Router Class Initialized
INFO - 2020-09-23 08:58:56 --> Output Class Initialized
INFO - 2020-09-23 08:58:56 --> Security Class Initialized
DEBUG - 2020-09-23 08:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:58:56 --> Input Class Initialized
INFO - 2020-09-23 08:58:56 --> Language Class Initialized
INFO - 2020-09-23 08:58:56 --> Language Class Initialized
INFO - 2020-09-23 08:58:56 --> Config Class Initialized
INFO - 2020-09-23 08:58:56 --> Loader Class Initialized
INFO - 2020-09-23 08:58:56 --> Helper loaded: url_helper
INFO - 2020-09-23 08:58:56 --> Helper loaded: file_helper
INFO - 2020-09-23 08:58:56 --> Helper loaded: form_helper
INFO - 2020-09-23 08:58:56 --> Helper loaded: my_helper
INFO - 2020-09-23 08:58:56 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:58:56 --> Controller Class Initialized
DEBUG - 2020-09-23 08:58:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:58:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:58:56 --> Final output sent to browser
DEBUG - 2020-09-23 08:58:56 --> Total execution time: 0.0498
INFO - 2020-09-23 08:59:01 --> Config Class Initialized
INFO - 2020-09-23 08:59:01 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:01 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:01 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:01 --> URI Class Initialized
INFO - 2020-09-23 08:59:01 --> Router Class Initialized
INFO - 2020-09-23 08:59:01 --> Output Class Initialized
INFO - 2020-09-23 08:59:01 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:01 --> Input Class Initialized
INFO - 2020-09-23 08:59:01 --> Language Class Initialized
INFO - 2020-09-23 08:59:01 --> Language Class Initialized
INFO - 2020-09-23 08:59:01 --> Config Class Initialized
INFO - 2020-09-23 08:59:01 --> Loader Class Initialized
INFO - 2020-09-23 08:59:01 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:01 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:01 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:01 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:01 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:01 --> Controller Class Initialized
INFO - 2020-09-23 08:59:01 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:59:01 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:01 --> Total execution time: 0.0455
INFO - 2020-09-23 08:59:01 --> Config Class Initialized
INFO - 2020-09-23 08:59:01 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:01 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:01 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:01 --> URI Class Initialized
INFO - 2020-09-23 08:59:01 --> Router Class Initialized
INFO - 2020-09-23 08:59:01 --> Output Class Initialized
INFO - 2020-09-23 08:59:01 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:01 --> Input Class Initialized
INFO - 2020-09-23 08:59:01 --> Language Class Initialized
INFO - 2020-09-23 08:59:01 --> Language Class Initialized
INFO - 2020-09-23 08:59:01 --> Config Class Initialized
INFO - 2020-09-23 08:59:01 --> Loader Class Initialized
INFO - 2020-09-23 08:59:01 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:01 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:01 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:01 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:01 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:01 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:59:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:02 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:02 --> Total execution time: 0.6432
INFO - 2020-09-23 08:59:03 --> Config Class Initialized
INFO - 2020-09-23 08:59:03 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:03 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:03 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:03 --> URI Class Initialized
INFO - 2020-09-23 08:59:03 --> Router Class Initialized
INFO - 2020-09-23 08:59:03 --> Output Class Initialized
INFO - 2020-09-23 08:59:03 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:03 --> Input Class Initialized
INFO - 2020-09-23 08:59:03 --> Language Class Initialized
INFO - 2020-09-23 08:59:03 --> Language Class Initialized
INFO - 2020-09-23 08:59:03 --> Config Class Initialized
INFO - 2020-09-23 08:59:03 --> Loader Class Initialized
INFO - 2020-09-23 08:59:03 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:03 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:03 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:03 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:03 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:03 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:59:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:03 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:03 --> Total execution time: 0.0619
INFO - 2020-09-23 08:59:04 --> Config Class Initialized
INFO - 2020-09-23 08:59:04 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:04 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:04 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:04 --> URI Class Initialized
INFO - 2020-09-23 08:59:04 --> Router Class Initialized
INFO - 2020-09-23 08:59:04 --> Output Class Initialized
INFO - 2020-09-23 08:59:04 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:04 --> Input Class Initialized
INFO - 2020-09-23 08:59:04 --> Language Class Initialized
INFO - 2020-09-23 08:59:04 --> Language Class Initialized
INFO - 2020-09-23 08:59:04 --> Config Class Initialized
INFO - 2020-09-23 08:59:04 --> Loader Class Initialized
INFO - 2020-09-23 08:59:04 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:04 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:04 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:04 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:04 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:04 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2020-09-23 08:59:05 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:05 --> Total execution time: 0.3161
INFO - 2020-09-23 08:59:13 --> Config Class Initialized
INFO - 2020-09-23 08:59:13 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:13 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:13 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:13 --> URI Class Initialized
INFO - 2020-09-23 08:59:13 --> Router Class Initialized
INFO - 2020-09-23 08:59:13 --> Output Class Initialized
INFO - 2020-09-23 08:59:13 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:13 --> Input Class Initialized
INFO - 2020-09-23 08:59:13 --> Language Class Initialized
INFO - 2020-09-23 08:59:13 --> Language Class Initialized
INFO - 2020-09-23 08:59:13 --> Config Class Initialized
INFO - 2020-09-23 08:59:13 --> Loader Class Initialized
INFO - 2020-09-23 08:59:13 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:13 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:13 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:13 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:13 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:13 --> Controller Class Initialized
INFO - 2020-09-23 08:59:13 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:59:13 --> Config Class Initialized
INFO - 2020-09-23 08:59:13 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:13 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:13 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:13 --> URI Class Initialized
INFO - 2020-09-23 08:59:13 --> Router Class Initialized
INFO - 2020-09-23 08:59:13 --> Output Class Initialized
INFO - 2020-09-23 08:59:13 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:13 --> Input Class Initialized
INFO - 2020-09-23 08:59:13 --> Language Class Initialized
INFO - 2020-09-23 08:59:13 --> Language Class Initialized
INFO - 2020-09-23 08:59:13 --> Config Class Initialized
INFO - 2020-09-23 08:59:13 --> Loader Class Initialized
INFO - 2020-09-23 08:59:13 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:13 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:13 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:13 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:13 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:13 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:59:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:13 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:13 --> Total execution time: 0.0415
INFO - 2020-09-23 08:59:19 --> Config Class Initialized
INFO - 2020-09-23 08:59:19 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:19 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:19 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:19 --> URI Class Initialized
INFO - 2020-09-23 08:59:19 --> Router Class Initialized
INFO - 2020-09-23 08:59:19 --> Output Class Initialized
INFO - 2020-09-23 08:59:19 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:19 --> Input Class Initialized
INFO - 2020-09-23 08:59:19 --> Language Class Initialized
INFO - 2020-09-23 08:59:19 --> Language Class Initialized
INFO - 2020-09-23 08:59:19 --> Config Class Initialized
INFO - 2020-09-23 08:59:19 --> Loader Class Initialized
INFO - 2020-09-23 08:59:19 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:19 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:19 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:19 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:19 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:19 --> Controller Class Initialized
INFO - 2020-09-23 08:59:19 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:59:19 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:19 --> Total execution time: 0.0459
INFO - 2020-09-23 08:59:19 --> Config Class Initialized
INFO - 2020-09-23 08:59:19 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:19 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:19 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:19 --> URI Class Initialized
INFO - 2020-09-23 08:59:19 --> Router Class Initialized
INFO - 2020-09-23 08:59:19 --> Output Class Initialized
INFO - 2020-09-23 08:59:19 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:19 --> Input Class Initialized
INFO - 2020-09-23 08:59:19 --> Language Class Initialized
INFO - 2020-09-23 08:59:19 --> Language Class Initialized
INFO - 2020-09-23 08:59:19 --> Config Class Initialized
INFO - 2020-09-23 08:59:19 --> Loader Class Initialized
INFO - 2020-09-23 08:59:19 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:19 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:19 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:19 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:19 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:19 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:20 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:20 --> Total execution time: 0.6416
INFO - 2020-09-23 08:59:21 --> Config Class Initialized
INFO - 2020-09-23 08:59:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:21 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:21 --> URI Class Initialized
INFO - 2020-09-23 08:59:21 --> Router Class Initialized
INFO - 2020-09-23 08:59:21 --> Output Class Initialized
INFO - 2020-09-23 08:59:21 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:21 --> Input Class Initialized
INFO - 2020-09-23 08:59:21 --> Language Class Initialized
INFO - 2020-09-23 08:59:21 --> Language Class Initialized
INFO - 2020-09-23 08:59:21 --> Config Class Initialized
INFO - 2020-09-23 08:59:21 --> Loader Class Initialized
INFO - 2020-09-23 08:59:21 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:21 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:21 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:21 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:21 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:21 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:21 --> Total execution time: 0.0608
INFO - 2020-09-23 08:59:23 --> Config Class Initialized
INFO - 2020-09-23 08:59:23 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:23 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:23 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:23 --> URI Class Initialized
INFO - 2020-09-23 08:59:23 --> Router Class Initialized
INFO - 2020-09-23 08:59:23 --> Output Class Initialized
INFO - 2020-09-23 08:59:23 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:23 --> Input Class Initialized
INFO - 2020-09-23 08:59:23 --> Language Class Initialized
INFO - 2020-09-23 08:59:23 --> Language Class Initialized
INFO - 2020-09-23 08:59:23 --> Config Class Initialized
INFO - 2020-09-23 08:59:23 --> Loader Class Initialized
INFO - 2020-09-23 08:59:23 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:23 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:23 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:23 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:23 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:23 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2020-09-23 08:59:23 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:23 --> Total execution time: 0.3438
INFO - 2020-09-23 08:59:29 --> Config Class Initialized
INFO - 2020-09-23 08:59:29 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:29 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:29 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:29 --> URI Class Initialized
INFO - 2020-09-23 08:59:29 --> Router Class Initialized
INFO - 2020-09-23 08:59:29 --> Output Class Initialized
INFO - 2020-09-23 08:59:29 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:29 --> Input Class Initialized
INFO - 2020-09-23 08:59:29 --> Language Class Initialized
INFO - 2020-09-23 08:59:29 --> Language Class Initialized
INFO - 2020-09-23 08:59:29 --> Config Class Initialized
INFO - 2020-09-23 08:59:29 --> Loader Class Initialized
INFO - 2020-09-23 08:59:29 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:29 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:29 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:29 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:29 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:29 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2020-09-23 08:59:29 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:29 --> Total execution time: 0.2507
INFO - 2020-09-23 08:59:45 --> Config Class Initialized
INFO - 2020-09-23 08:59:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:45 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:45 --> URI Class Initialized
INFO - 2020-09-23 08:59:45 --> Router Class Initialized
INFO - 2020-09-23 08:59:45 --> Output Class Initialized
INFO - 2020-09-23 08:59:45 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:45 --> Input Class Initialized
INFO - 2020-09-23 08:59:45 --> Language Class Initialized
INFO - 2020-09-23 08:59:45 --> Language Class Initialized
INFO - 2020-09-23 08:59:45 --> Config Class Initialized
INFO - 2020-09-23 08:59:45 --> Loader Class Initialized
INFO - 2020-09-23 08:59:45 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:45 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:45 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:45 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:45 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:45 --> Controller Class Initialized
INFO - 2020-09-23 08:59:45 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:59:45 --> Config Class Initialized
INFO - 2020-09-23 08:59:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:45 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:45 --> URI Class Initialized
INFO - 2020-09-23 08:59:45 --> Router Class Initialized
INFO - 2020-09-23 08:59:45 --> Output Class Initialized
INFO - 2020-09-23 08:59:45 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:45 --> Input Class Initialized
INFO - 2020-09-23 08:59:45 --> Language Class Initialized
INFO - 2020-09-23 08:59:45 --> Language Class Initialized
INFO - 2020-09-23 08:59:45 --> Config Class Initialized
INFO - 2020-09-23 08:59:45 --> Loader Class Initialized
INFO - 2020-09-23 08:59:45 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:45 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:45 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:45 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:45 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:45 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 08:59:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:45 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:45 --> Total execution time: 0.0518
INFO - 2020-09-23 08:59:52 --> Config Class Initialized
INFO - 2020-09-23 08:59:52 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:52 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:52 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:52 --> URI Class Initialized
INFO - 2020-09-23 08:59:52 --> Router Class Initialized
INFO - 2020-09-23 08:59:52 --> Output Class Initialized
INFO - 2020-09-23 08:59:52 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:52 --> Input Class Initialized
INFO - 2020-09-23 08:59:52 --> Language Class Initialized
INFO - 2020-09-23 08:59:52 --> Language Class Initialized
INFO - 2020-09-23 08:59:52 --> Config Class Initialized
INFO - 2020-09-23 08:59:52 --> Loader Class Initialized
INFO - 2020-09-23 08:59:52 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:52 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:52 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:52 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:52 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:52 --> Controller Class Initialized
INFO - 2020-09-23 08:59:52 --> Helper loaded: cookie_helper
INFO - 2020-09-23 08:59:52 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:52 --> Total execution time: 0.0455
INFO - 2020-09-23 08:59:52 --> Config Class Initialized
INFO - 2020-09-23 08:59:52 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:52 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:52 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:52 --> URI Class Initialized
INFO - 2020-09-23 08:59:52 --> Router Class Initialized
INFO - 2020-09-23 08:59:52 --> Output Class Initialized
INFO - 2020-09-23 08:59:52 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:52 --> Input Class Initialized
INFO - 2020-09-23 08:59:52 --> Language Class Initialized
INFO - 2020-09-23 08:59:52 --> Language Class Initialized
INFO - 2020-09-23 08:59:52 --> Config Class Initialized
INFO - 2020-09-23 08:59:52 --> Loader Class Initialized
INFO - 2020-09-23 08:59:52 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:52 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:52 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:52 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:52 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:52 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 08:59:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:53 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:53 --> Total execution time: 0.6349
INFO - 2020-09-23 08:59:55 --> Config Class Initialized
INFO - 2020-09-23 08:59:55 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:55 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:55 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:55 --> URI Class Initialized
INFO - 2020-09-23 08:59:55 --> Router Class Initialized
INFO - 2020-09-23 08:59:55 --> Output Class Initialized
INFO - 2020-09-23 08:59:55 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:55 --> Input Class Initialized
INFO - 2020-09-23 08:59:55 --> Language Class Initialized
INFO - 2020-09-23 08:59:55 --> Language Class Initialized
INFO - 2020-09-23 08:59:55 --> Config Class Initialized
INFO - 2020-09-23 08:59:55 --> Loader Class Initialized
INFO - 2020-09-23 08:59:55 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:55 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:55 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:55 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:55 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:55 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 08:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 08:59:55 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:55 --> Total execution time: 0.0609
INFO - 2020-09-23 08:59:56 --> Config Class Initialized
INFO - 2020-09-23 08:59:56 --> Hooks Class Initialized
DEBUG - 2020-09-23 08:59:56 --> UTF-8 Support Enabled
INFO - 2020-09-23 08:59:56 --> Utf8 Class Initialized
INFO - 2020-09-23 08:59:56 --> URI Class Initialized
INFO - 2020-09-23 08:59:56 --> Router Class Initialized
INFO - 2020-09-23 08:59:56 --> Output Class Initialized
INFO - 2020-09-23 08:59:56 --> Security Class Initialized
DEBUG - 2020-09-23 08:59:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 08:59:56 --> Input Class Initialized
INFO - 2020-09-23 08:59:56 --> Language Class Initialized
INFO - 2020-09-23 08:59:56 --> Language Class Initialized
INFO - 2020-09-23 08:59:56 --> Config Class Initialized
INFO - 2020-09-23 08:59:56 --> Loader Class Initialized
INFO - 2020-09-23 08:59:56 --> Helper loaded: url_helper
INFO - 2020-09-23 08:59:56 --> Helper loaded: file_helper
INFO - 2020-09-23 08:59:56 --> Helper loaded: form_helper
INFO - 2020-09-23 08:59:56 --> Helper loaded: my_helper
INFO - 2020-09-23 08:59:56 --> Database Driver Class Initialized
DEBUG - 2020-09-23 08:59:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 08:59:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 08:59:56 --> Controller Class Initialized
DEBUG - 2020-09-23 08:59:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2020-09-23 08:59:57 --> Final output sent to browser
DEBUG - 2020-09-23 08:59:57 --> Total execution time: 0.3241
INFO - 2020-09-23 09:00:12 --> Config Class Initialized
INFO - 2020-09-23 09:00:12 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:12 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:12 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:12 --> URI Class Initialized
INFO - 2020-09-23 09:00:12 --> Router Class Initialized
INFO - 2020-09-23 09:00:12 --> Output Class Initialized
INFO - 2020-09-23 09:00:12 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:12 --> Input Class Initialized
INFO - 2020-09-23 09:00:12 --> Language Class Initialized
INFO - 2020-09-23 09:00:12 --> Language Class Initialized
INFO - 2020-09-23 09:00:12 --> Config Class Initialized
INFO - 2020-09-23 09:00:12 --> Loader Class Initialized
INFO - 2020-09-23 09:00:12 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:12 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:12 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:12 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:12 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:12 --> Controller Class Initialized
INFO - 2020-09-23 09:00:12 --> Helper loaded: cookie_helper
INFO - 2020-09-23 09:00:12 --> Config Class Initialized
INFO - 2020-09-23 09:00:12 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:12 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:12 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:12 --> URI Class Initialized
INFO - 2020-09-23 09:00:12 --> Router Class Initialized
INFO - 2020-09-23 09:00:12 --> Output Class Initialized
INFO - 2020-09-23 09:00:12 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:12 --> Input Class Initialized
INFO - 2020-09-23 09:00:12 --> Language Class Initialized
INFO - 2020-09-23 09:00:12 --> Language Class Initialized
INFO - 2020-09-23 09:00:12 --> Config Class Initialized
INFO - 2020-09-23 09:00:12 --> Loader Class Initialized
INFO - 2020-09-23 09:00:12 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:12 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:12 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:12 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:12 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:12 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 09:00:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:00:12 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:12 --> Total execution time: 0.0523
INFO - 2020-09-23 09:00:20 --> Config Class Initialized
INFO - 2020-09-23 09:00:20 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:20 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:20 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:20 --> URI Class Initialized
INFO - 2020-09-23 09:00:20 --> Router Class Initialized
INFO - 2020-09-23 09:00:20 --> Output Class Initialized
INFO - 2020-09-23 09:00:20 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:20 --> Input Class Initialized
INFO - 2020-09-23 09:00:20 --> Language Class Initialized
INFO - 2020-09-23 09:00:20 --> Language Class Initialized
INFO - 2020-09-23 09:00:20 --> Config Class Initialized
INFO - 2020-09-23 09:00:20 --> Loader Class Initialized
INFO - 2020-09-23 09:00:20 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:20 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:20 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:20 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:20 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:20 --> Controller Class Initialized
INFO - 2020-09-23 09:00:20 --> Helper loaded: cookie_helper
INFO - 2020-09-23 09:00:20 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:20 --> Total execution time: 0.0455
INFO - 2020-09-23 09:00:21 --> Config Class Initialized
INFO - 2020-09-23 09:00:21 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:21 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:21 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:21 --> URI Class Initialized
INFO - 2020-09-23 09:00:21 --> Router Class Initialized
INFO - 2020-09-23 09:00:21 --> Output Class Initialized
INFO - 2020-09-23 09:00:21 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:21 --> Input Class Initialized
INFO - 2020-09-23 09:00:21 --> Language Class Initialized
INFO - 2020-09-23 09:00:21 --> Language Class Initialized
INFO - 2020-09-23 09:00:21 --> Config Class Initialized
INFO - 2020-09-23 09:00:21 --> Loader Class Initialized
INFO - 2020-09-23 09:00:21 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:21 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:21 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:21 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:21 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:21 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 09:00:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:00:21 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:21 --> Total execution time: 0.6438
INFO - 2020-09-23 09:00:24 --> Config Class Initialized
INFO - 2020-09-23 09:00:24 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:24 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:24 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:24 --> URI Class Initialized
INFO - 2020-09-23 09:00:24 --> Router Class Initialized
INFO - 2020-09-23 09:00:24 --> Output Class Initialized
INFO - 2020-09-23 09:00:24 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:24 --> Input Class Initialized
INFO - 2020-09-23 09:00:24 --> Language Class Initialized
INFO - 2020-09-23 09:00:24 --> Language Class Initialized
INFO - 2020-09-23 09:00:24 --> Config Class Initialized
INFO - 2020-09-23 09:00:24 --> Loader Class Initialized
INFO - 2020-09-23 09:00:24 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:24 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:24 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:24 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:24 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:24 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 09:00:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:00:24 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:24 --> Total execution time: 0.0594
INFO - 2020-09-23 09:00:25 --> Config Class Initialized
INFO - 2020-09-23 09:00:25 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:25 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:25 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:25 --> URI Class Initialized
INFO - 2020-09-23 09:00:25 --> Router Class Initialized
INFO - 2020-09-23 09:00:25 --> Output Class Initialized
INFO - 2020-09-23 09:00:25 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:25 --> Input Class Initialized
INFO - 2020-09-23 09:00:25 --> Language Class Initialized
INFO - 2020-09-23 09:00:25 --> Language Class Initialized
INFO - 2020-09-23 09:00:25 --> Config Class Initialized
INFO - 2020-09-23 09:00:25 --> Loader Class Initialized
INFO - 2020-09-23 09:00:25 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:25 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:25 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:25 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:25 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:25 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2020-09-23 09:00:26 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:26 --> Total execution time: 0.3220
INFO - 2020-09-23 09:00:38 --> Config Class Initialized
INFO - 2020-09-23 09:00:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:38 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:38 --> URI Class Initialized
INFO - 2020-09-23 09:00:38 --> Router Class Initialized
INFO - 2020-09-23 09:00:38 --> Output Class Initialized
INFO - 2020-09-23 09:00:38 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:38 --> Input Class Initialized
INFO - 2020-09-23 09:00:38 --> Language Class Initialized
INFO - 2020-09-23 09:00:38 --> Language Class Initialized
INFO - 2020-09-23 09:00:38 --> Config Class Initialized
INFO - 2020-09-23 09:00:38 --> Loader Class Initialized
INFO - 2020-09-23 09:00:38 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:38 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:38 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:38 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:38 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:38 --> Controller Class Initialized
INFO - 2020-09-23 09:00:38 --> Helper loaded: cookie_helper
INFO - 2020-09-23 09:00:38 --> Config Class Initialized
INFO - 2020-09-23 09:00:38 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:38 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:38 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:38 --> URI Class Initialized
INFO - 2020-09-23 09:00:38 --> Router Class Initialized
INFO - 2020-09-23 09:00:38 --> Output Class Initialized
INFO - 2020-09-23 09:00:38 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:38 --> Input Class Initialized
INFO - 2020-09-23 09:00:38 --> Language Class Initialized
INFO - 2020-09-23 09:00:38 --> Language Class Initialized
INFO - 2020-09-23 09:00:38 --> Config Class Initialized
INFO - 2020-09-23 09:00:38 --> Loader Class Initialized
INFO - 2020-09-23 09:00:38 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:38 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:38 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:38 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:38 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:38 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 09:00:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:00:38 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:38 --> Total execution time: 0.0532
INFO - 2020-09-23 09:00:44 --> Config Class Initialized
INFO - 2020-09-23 09:00:44 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:44 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:44 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:44 --> URI Class Initialized
INFO - 2020-09-23 09:00:44 --> Router Class Initialized
INFO - 2020-09-23 09:00:44 --> Output Class Initialized
INFO - 2020-09-23 09:00:44 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:44 --> Input Class Initialized
INFO - 2020-09-23 09:00:44 --> Language Class Initialized
INFO - 2020-09-23 09:00:44 --> Language Class Initialized
INFO - 2020-09-23 09:00:44 --> Config Class Initialized
INFO - 2020-09-23 09:00:44 --> Loader Class Initialized
INFO - 2020-09-23 09:00:44 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:44 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:44 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:44 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:44 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:44 --> Controller Class Initialized
INFO - 2020-09-23 09:00:44 --> Helper loaded: cookie_helper
INFO - 2020-09-23 09:00:44 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:44 --> Total execution time: 0.0462
INFO - 2020-09-23 09:00:45 --> Config Class Initialized
INFO - 2020-09-23 09:00:45 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:45 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:45 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:45 --> URI Class Initialized
INFO - 2020-09-23 09:00:45 --> Router Class Initialized
INFO - 2020-09-23 09:00:45 --> Output Class Initialized
INFO - 2020-09-23 09:00:45 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:45 --> Input Class Initialized
INFO - 2020-09-23 09:00:45 --> Language Class Initialized
INFO - 2020-09-23 09:00:45 --> Language Class Initialized
INFO - 2020-09-23 09:00:45 --> Config Class Initialized
INFO - 2020-09-23 09:00:45 --> Loader Class Initialized
INFO - 2020-09-23 09:00:45 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:45 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:45 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:45 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:45 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:45 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 09:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:00:45 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:45 --> Total execution time: 0.6412
INFO - 2020-09-23 09:00:46 --> Config Class Initialized
INFO - 2020-09-23 09:00:46 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:46 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:46 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:46 --> URI Class Initialized
INFO - 2020-09-23 09:00:46 --> Router Class Initialized
INFO - 2020-09-23 09:00:46 --> Output Class Initialized
INFO - 2020-09-23 09:00:46 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:46 --> Input Class Initialized
INFO - 2020-09-23 09:00:46 --> Language Class Initialized
INFO - 2020-09-23 09:00:46 --> Language Class Initialized
INFO - 2020-09-23 09:00:46 --> Config Class Initialized
INFO - 2020-09-23 09:00:46 --> Loader Class Initialized
INFO - 2020-09-23 09:00:46 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:46 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:46 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:46 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:46 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:46 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 09:00:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:00:47 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:47 --> Total execution time: 0.0512
INFO - 2020-09-23 09:00:51 --> Config Class Initialized
INFO - 2020-09-23 09:00:51 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:00:51 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:00:51 --> Utf8 Class Initialized
INFO - 2020-09-23 09:00:51 --> URI Class Initialized
INFO - 2020-09-23 09:00:51 --> Router Class Initialized
INFO - 2020-09-23 09:00:51 --> Output Class Initialized
INFO - 2020-09-23 09:00:51 --> Security Class Initialized
DEBUG - 2020-09-23 09:00:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:00:51 --> Input Class Initialized
INFO - 2020-09-23 09:00:51 --> Language Class Initialized
INFO - 2020-09-23 09:00:51 --> Language Class Initialized
INFO - 2020-09-23 09:00:51 --> Config Class Initialized
INFO - 2020-09-23 09:00:51 --> Loader Class Initialized
INFO - 2020-09-23 09:00:51 --> Helper loaded: url_helper
INFO - 2020-09-23 09:00:51 --> Helper loaded: file_helper
INFO - 2020-09-23 09:00:51 --> Helper loaded: form_helper
INFO - 2020-09-23 09:00:51 --> Helper loaded: my_helper
INFO - 2020-09-23 09:00:51 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:00:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:00:51 --> Controller Class Initialized
DEBUG - 2020-09-23 09:00:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2020-09-23 09:00:51 --> Final output sent to browser
DEBUG - 2020-09-23 09:00:51 --> Total execution time: 0.3947
INFO - 2020-09-23 09:01:07 --> Config Class Initialized
INFO - 2020-09-23 09:01:07 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:01:07 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:01:07 --> Utf8 Class Initialized
INFO - 2020-09-23 09:01:07 --> URI Class Initialized
INFO - 2020-09-23 09:01:07 --> Router Class Initialized
INFO - 2020-09-23 09:01:07 --> Output Class Initialized
INFO - 2020-09-23 09:01:07 --> Security Class Initialized
DEBUG - 2020-09-23 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:01:07 --> Input Class Initialized
INFO - 2020-09-23 09:01:07 --> Language Class Initialized
INFO - 2020-09-23 09:01:07 --> Language Class Initialized
INFO - 2020-09-23 09:01:07 --> Config Class Initialized
INFO - 2020-09-23 09:01:07 --> Loader Class Initialized
INFO - 2020-09-23 09:01:07 --> Helper loaded: url_helper
INFO - 2020-09-23 09:01:07 --> Helper loaded: file_helper
INFO - 2020-09-23 09:01:07 --> Helper loaded: form_helper
INFO - 2020-09-23 09:01:07 --> Helper loaded: my_helper
INFO - 2020-09-23 09:01:07 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:01:07 --> Controller Class Initialized
INFO - 2020-09-23 09:01:07 --> Helper loaded: cookie_helper
INFO - 2020-09-23 09:01:07 --> Config Class Initialized
INFO - 2020-09-23 09:01:07 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:01:07 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:01:07 --> Utf8 Class Initialized
INFO - 2020-09-23 09:01:07 --> URI Class Initialized
INFO - 2020-09-23 09:01:07 --> Router Class Initialized
INFO - 2020-09-23 09:01:07 --> Output Class Initialized
INFO - 2020-09-23 09:01:07 --> Security Class Initialized
DEBUG - 2020-09-23 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:01:07 --> Input Class Initialized
INFO - 2020-09-23 09:01:07 --> Language Class Initialized
INFO - 2020-09-23 09:01:07 --> Language Class Initialized
INFO - 2020-09-23 09:01:07 --> Config Class Initialized
INFO - 2020-09-23 09:01:07 --> Loader Class Initialized
INFO - 2020-09-23 09:01:07 --> Helper loaded: url_helper
INFO - 2020-09-23 09:01:07 --> Helper loaded: file_helper
INFO - 2020-09-23 09:01:07 --> Helper loaded: form_helper
INFO - 2020-09-23 09:01:07 --> Helper loaded: my_helper
INFO - 2020-09-23 09:01:07 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:01:07 --> Controller Class Initialized
DEBUG - 2020-09-23 09:01:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-09-23 09:01:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:01:07 --> Final output sent to browser
DEBUG - 2020-09-23 09:01:07 --> Total execution time: 0.0525
INFO - 2020-09-23 09:01:12 --> Config Class Initialized
INFO - 2020-09-23 09:01:12 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:01:12 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:01:12 --> Utf8 Class Initialized
INFO - 2020-09-23 09:01:12 --> URI Class Initialized
INFO - 2020-09-23 09:01:12 --> Router Class Initialized
INFO - 2020-09-23 09:01:12 --> Output Class Initialized
INFO - 2020-09-23 09:01:12 --> Security Class Initialized
DEBUG - 2020-09-23 09:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:01:12 --> Input Class Initialized
INFO - 2020-09-23 09:01:12 --> Language Class Initialized
INFO - 2020-09-23 09:01:12 --> Language Class Initialized
INFO - 2020-09-23 09:01:12 --> Config Class Initialized
INFO - 2020-09-23 09:01:12 --> Loader Class Initialized
INFO - 2020-09-23 09:01:12 --> Helper loaded: url_helper
INFO - 2020-09-23 09:01:12 --> Helper loaded: file_helper
INFO - 2020-09-23 09:01:12 --> Helper loaded: form_helper
INFO - 2020-09-23 09:01:12 --> Helper loaded: my_helper
INFO - 2020-09-23 09:01:12 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:01:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:01:12 --> Controller Class Initialized
INFO - 2020-09-23 09:01:12 --> Helper loaded: cookie_helper
INFO - 2020-09-23 09:01:12 --> Final output sent to browser
DEBUG - 2020-09-23 09:01:12 --> Total execution time: 0.0452
INFO - 2020-09-23 09:01:13 --> Config Class Initialized
INFO - 2020-09-23 09:01:13 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:01:13 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:01:13 --> Utf8 Class Initialized
INFO - 2020-09-23 09:01:13 --> URI Class Initialized
INFO - 2020-09-23 09:01:13 --> Router Class Initialized
INFO - 2020-09-23 09:01:13 --> Output Class Initialized
INFO - 2020-09-23 09:01:13 --> Security Class Initialized
DEBUG - 2020-09-23 09:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:01:13 --> Input Class Initialized
INFO - 2020-09-23 09:01:13 --> Language Class Initialized
INFO - 2020-09-23 09:01:13 --> Language Class Initialized
INFO - 2020-09-23 09:01:13 --> Config Class Initialized
INFO - 2020-09-23 09:01:13 --> Loader Class Initialized
INFO - 2020-09-23 09:01:13 --> Helper loaded: url_helper
INFO - 2020-09-23 09:01:13 --> Helper loaded: file_helper
INFO - 2020-09-23 09:01:13 --> Helper loaded: form_helper
INFO - 2020-09-23 09:01:13 --> Helper loaded: my_helper
INFO - 2020-09-23 09:01:13 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:01:13 --> Controller Class Initialized
DEBUG - 2020-09-23 09:01:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-09-23 09:01:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:01:13 --> Final output sent to browser
DEBUG - 2020-09-23 09:01:13 --> Total execution time: 0.6416
INFO - 2020-09-23 09:01:14 --> Config Class Initialized
INFO - 2020-09-23 09:01:14 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:01:14 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:01:14 --> Utf8 Class Initialized
INFO - 2020-09-23 09:01:14 --> URI Class Initialized
INFO - 2020-09-23 09:01:14 --> Router Class Initialized
INFO - 2020-09-23 09:01:14 --> Output Class Initialized
INFO - 2020-09-23 09:01:14 --> Security Class Initialized
DEBUG - 2020-09-23 09:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:01:14 --> Input Class Initialized
INFO - 2020-09-23 09:01:14 --> Language Class Initialized
INFO - 2020-09-23 09:01:14 --> Language Class Initialized
INFO - 2020-09-23 09:01:14 --> Config Class Initialized
INFO - 2020-09-23 09:01:14 --> Loader Class Initialized
INFO - 2020-09-23 09:01:14 --> Helper loaded: url_helper
INFO - 2020-09-23 09:01:14 --> Helper loaded: file_helper
INFO - 2020-09-23 09:01:14 --> Helper loaded: form_helper
INFO - 2020-09-23 09:01:14 --> Helper loaded: my_helper
INFO - 2020-09-23 09:01:14 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:01:14 --> Controller Class Initialized
DEBUG - 2020-09-23 09:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-09-23 09:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-09-23 09:01:14 --> Final output sent to browser
DEBUG - 2020-09-23 09:01:14 --> Total execution time: 0.0501
INFO - 2020-09-23 09:01:16 --> Config Class Initialized
INFO - 2020-09-23 09:01:16 --> Hooks Class Initialized
DEBUG - 2020-09-23 09:01:16 --> UTF-8 Support Enabled
INFO - 2020-09-23 09:01:16 --> Utf8 Class Initialized
INFO - 2020-09-23 09:01:16 --> URI Class Initialized
INFO - 2020-09-23 09:01:16 --> Router Class Initialized
INFO - 2020-09-23 09:01:16 --> Output Class Initialized
INFO - 2020-09-23 09:01:16 --> Security Class Initialized
DEBUG - 2020-09-23 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-09-23 09:01:16 --> Input Class Initialized
INFO - 2020-09-23 09:01:16 --> Language Class Initialized
INFO - 2020-09-23 09:01:16 --> Language Class Initialized
INFO - 2020-09-23 09:01:16 --> Config Class Initialized
INFO - 2020-09-23 09:01:16 --> Loader Class Initialized
INFO - 2020-09-23 09:01:16 --> Helper loaded: url_helper
INFO - 2020-09-23 09:01:16 --> Helper loaded: file_helper
INFO - 2020-09-23 09:01:16 --> Helper loaded: form_helper
INFO - 2020-09-23 09:01:16 --> Helper loaded: my_helper
INFO - 2020-09-23 09:01:16 --> Database Driver Class Initialized
DEBUG - 2020-09-23 09:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-09-23 09:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-09-23 09:01:16 --> Controller Class Initialized
DEBUG - 2020-09-23 09:01:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xii.php
INFO - 2020-09-23 09:01:17 --> Final output sent to browser
DEBUG - 2020-09-23 09:01:17 --> Total execution time: 0.3490
