<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-31 08:58:03 --> Config Class Initialized
INFO - 2021-03-31 08:58:03 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:03 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:03 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:03 --> URI Class Initialized
DEBUG - 2021-03-31 08:58:03 --> No URI present. Default controller set.
INFO - 2021-03-31 08:58:03 --> Router Class Initialized
INFO - 2021-03-31 08:58:03 --> Output Class Initialized
INFO - 2021-03-31 08:58:03 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:03 --> Input Class Initialized
INFO - 2021-03-31 08:58:03 --> Language Class Initialized
INFO - 2021-03-31 08:58:04 --> Language Class Initialized
INFO - 2021-03-31 08:58:04 --> Config Class Initialized
INFO - 2021-03-31 08:58:04 --> Loader Class Initialized
INFO - 2021-03-31 08:58:04 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:04 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:04 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:04 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:04 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:04 --> Controller Class Initialized
INFO - 2021-03-31 08:58:04 --> Config Class Initialized
INFO - 2021-03-31 08:58:04 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:04 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:04 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:04 --> URI Class Initialized
INFO - 2021-03-31 08:58:04 --> Router Class Initialized
INFO - 2021-03-31 08:58:04 --> Output Class Initialized
INFO - 2021-03-31 08:58:04 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:04 --> Input Class Initialized
INFO - 2021-03-31 08:58:04 --> Language Class Initialized
INFO - 2021-03-31 08:58:04 --> Language Class Initialized
INFO - 2021-03-31 08:58:04 --> Config Class Initialized
INFO - 2021-03-31 08:58:04 --> Loader Class Initialized
INFO - 2021-03-31 08:58:04 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:04 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:04 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:04 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:04 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:05 --> Controller Class Initialized
DEBUG - 2021-03-31 08:58:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-03-31 08:58:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 08:58:05 --> Final output sent to browser
DEBUG - 2021-03-31 08:58:05 --> Total execution time: 0.3745
INFO - 2021-03-31 08:58:17 --> Config Class Initialized
INFO - 2021-03-31 08:58:17 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:17 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:17 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:17 --> URI Class Initialized
INFO - 2021-03-31 08:58:17 --> Router Class Initialized
INFO - 2021-03-31 08:58:17 --> Output Class Initialized
INFO - 2021-03-31 08:58:17 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:17 --> Input Class Initialized
INFO - 2021-03-31 08:58:17 --> Language Class Initialized
INFO - 2021-03-31 08:58:17 --> Language Class Initialized
INFO - 2021-03-31 08:58:17 --> Config Class Initialized
INFO - 2021-03-31 08:58:17 --> Loader Class Initialized
INFO - 2021-03-31 08:58:17 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:17 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:17 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:17 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:17 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:17 --> Controller Class Initialized
INFO - 2021-03-31 08:58:17 --> Helper loaded: cookie_helper
INFO - 2021-03-31 08:58:17 --> Final output sent to browser
DEBUG - 2021-03-31 08:58:17 --> Total execution time: 0.3127
INFO - 2021-03-31 08:58:20 --> Config Class Initialized
INFO - 2021-03-31 08:58:20 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:20 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:20 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:20 --> URI Class Initialized
INFO - 2021-03-31 08:58:20 --> Router Class Initialized
INFO - 2021-03-31 08:58:20 --> Output Class Initialized
INFO - 2021-03-31 08:58:20 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:20 --> Input Class Initialized
INFO - 2021-03-31 08:58:20 --> Language Class Initialized
INFO - 2021-03-31 08:58:20 --> Language Class Initialized
INFO - 2021-03-31 08:58:20 --> Config Class Initialized
INFO - 2021-03-31 08:58:20 --> Loader Class Initialized
INFO - 2021-03-31 08:58:20 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:20 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:20 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:20 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:20 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:20 --> Controller Class Initialized
DEBUG - 2021-03-31 08:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-03-31 08:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 08:58:21 --> Final output sent to browser
DEBUG - 2021-03-31 08:58:21 --> Total execution time: 0.4501
INFO - 2021-03-31 08:58:40 --> Config Class Initialized
INFO - 2021-03-31 08:58:40 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:40 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:40 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:40 --> URI Class Initialized
INFO - 2021-03-31 08:58:40 --> Router Class Initialized
INFO - 2021-03-31 08:58:40 --> Output Class Initialized
INFO - 2021-03-31 08:58:40 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:40 --> Input Class Initialized
INFO - 2021-03-31 08:58:40 --> Language Class Initialized
INFO - 2021-03-31 08:58:40 --> Language Class Initialized
INFO - 2021-03-31 08:58:40 --> Config Class Initialized
INFO - 2021-03-31 08:58:40 --> Loader Class Initialized
INFO - 2021-03-31 08:58:40 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:40 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:40 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:40 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:40 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:40 --> Controller Class Initialized
DEBUG - 2021-03-31 08:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-03-31 08:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 08:58:40 --> Final output sent to browser
DEBUG - 2021-03-31 08:58:40 --> Total execution time: 0.2497
INFO - 2021-03-31 08:58:40 --> Config Class Initialized
INFO - 2021-03-31 08:58:40 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:40 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:40 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:40 --> URI Class Initialized
INFO - 2021-03-31 08:58:40 --> Router Class Initialized
INFO - 2021-03-31 08:58:40 --> Output Class Initialized
INFO - 2021-03-31 08:58:40 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:40 --> Input Class Initialized
INFO - 2021-03-31 08:58:40 --> Language Class Initialized
INFO - 2021-03-31 08:58:40 --> Language Class Initialized
INFO - 2021-03-31 08:58:40 --> Config Class Initialized
INFO - 2021-03-31 08:58:40 --> Loader Class Initialized
INFO - 2021-03-31 08:58:40 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:40 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:40 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:40 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:40 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:40 --> Controller Class Initialized
INFO - 2021-03-31 08:58:42 --> Config Class Initialized
INFO - 2021-03-31 08:58:42 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:42 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:42 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:42 --> URI Class Initialized
INFO - 2021-03-31 08:58:42 --> Router Class Initialized
INFO - 2021-03-31 08:58:42 --> Output Class Initialized
INFO - 2021-03-31 08:58:42 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:42 --> Input Class Initialized
INFO - 2021-03-31 08:58:42 --> Language Class Initialized
INFO - 2021-03-31 08:58:42 --> Language Class Initialized
INFO - 2021-03-31 08:58:42 --> Config Class Initialized
INFO - 2021-03-31 08:58:42 --> Loader Class Initialized
INFO - 2021-03-31 08:58:42 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:42 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:42 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:42 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:42 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:42 --> Controller Class Initialized
DEBUG - 2021-03-31 08:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 08:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 08:58:42 --> Final output sent to browser
DEBUG - 2021-03-31 08:58:42 --> Total execution time: 0.2834
INFO - 2021-03-31 08:58:44 --> Config Class Initialized
INFO - 2021-03-31 08:58:44 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:44 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:44 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:44 --> URI Class Initialized
INFO - 2021-03-31 08:58:44 --> Router Class Initialized
INFO - 2021-03-31 08:58:44 --> Output Class Initialized
INFO - 2021-03-31 08:58:44 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:44 --> Input Class Initialized
INFO - 2021-03-31 08:58:44 --> Language Class Initialized
INFO - 2021-03-31 08:58:44 --> Language Class Initialized
INFO - 2021-03-31 08:58:44 --> Config Class Initialized
INFO - 2021-03-31 08:58:44 --> Loader Class Initialized
INFO - 2021-03-31 08:58:44 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:44 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:44 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:44 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:44 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:45 --> Controller Class Initialized
DEBUG - 2021-03-31 08:58:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-31 08:58:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 08:58:45 --> Final output sent to browser
DEBUG - 2021-03-31 08:58:45 --> Total execution time: 0.3173
INFO - 2021-03-31 08:58:54 --> Config Class Initialized
INFO - 2021-03-31 08:58:54 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:54 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:54 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:54 --> URI Class Initialized
INFO - 2021-03-31 08:58:54 --> Router Class Initialized
INFO - 2021-03-31 08:58:54 --> Output Class Initialized
INFO - 2021-03-31 08:58:54 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:54 --> Input Class Initialized
INFO - 2021-03-31 08:58:54 --> Language Class Initialized
INFO - 2021-03-31 08:58:54 --> Language Class Initialized
INFO - 2021-03-31 08:58:54 --> Config Class Initialized
INFO - 2021-03-31 08:58:54 --> Loader Class Initialized
INFO - 2021-03-31 08:58:54 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:54 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:54 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:54 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:54 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:54 --> Controller Class Initialized
INFO - 2021-03-31 08:58:54 --> Config Class Initialized
INFO - 2021-03-31 08:58:54 --> Hooks Class Initialized
DEBUG - 2021-03-31 08:58:54 --> UTF-8 Support Enabled
INFO - 2021-03-31 08:58:54 --> Utf8 Class Initialized
INFO - 2021-03-31 08:58:54 --> URI Class Initialized
INFO - 2021-03-31 08:58:54 --> Router Class Initialized
INFO - 2021-03-31 08:58:54 --> Output Class Initialized
INFO - 2021-03-31 08:58:54 --> Security Class Initialized
DEBUG - 2021-03-31 08:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 08:58:54 --> Input Class Initialized
INFO - 2021-03-31 08:58:54 --> Language Class Initialized
INFO - 2021-03-31 08:58:54 --> Language Class Initialized
INFO - 2021-03-31 08:58:54 --> Config Class Initialized
INFO - 2021-03-31 08:58:54 --> Loader Class Initialized
INFO - 2021-03-31 08:58:55 --> Helper loaded: url_helper
INFO - 2021-03-31 08:58:55 --> Helper loaded: file_helper
INFO - 2021-03-31 08:58:55 --> Helper loaded: form_helper
INFO - 2021-03-31 08:58:55 --> Helper loaded: my_helper
INFO - 2021-03-31 08:58:55 --> Database Driver Class Initialized
DEBUG - 2021-03-31 08:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 08:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 08:58:55 --> Controller Class Initialized
DEBUG - 2021-03-31 08:58:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 08:58:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 08:58:55 --> Final output sent to browser
DEBUG - 2021-03-31 08:58:55 --> Total execution time: 0.2510
INFO - 2021-03-31 09:02:14 --> Config Class Initialized
INFO - 2021-03-31 09:02:14 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:02:14 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:02:14 --> Utf8 Class Initialized
INFO - 2021-03-31 09:02:14 --> URI Class Initialized
INFO - 2021-03-31 09:02:14 --> Router Class Initialized
INFO - 2021-03-31 09:02:14 --> Output Class Initialized
INFO - 2021-03-31 09:02:14 --> Security Class Initialized
DEBUG - 2021-03-31 09:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:02:14 --> Input Class Initialized
INFO - 2021-03-31 09:02:14 --> Language Class Initialized
INFO - 2021-03-31 09:02:14 --> Language Class Initialized
INFO - 2021-03-31 09:02:14 --> Config Class Initialized
INFO - 2021-03-31 09:02:14 --> Loader Class Initialized
INFO - 2021-03-31 09:02:14 --> Helper loaded: url_helper
INFO - 2021-03-31 09:02:14 --> Helper loaded: file_helper
INFO - 2021-03-31 09:02:14 --> Helper loaded: form_helper
INFO - 2021-03-31 09:02:14 --> Helper loaded: my_helper
INFO - 2021-03-31 09:02:14 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:02:14 --> Controller Class Initialized
DEBUG - 2021-03-31 09:02:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-31 09:02:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:02:14 --> Final output sent to browser
DEBUG - 2021-03-31 09:02:14 --> Total execution time: 0.3305
INFO - 2021-03-31 09:02:16 --> Config Class Initialized
INFO - 2021-03-31 09:02:16 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:02:16 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:02:16 --> Utf8 Class Initialized
INFO - 2021-03-31 09:02:16 --> URI Class Initialized
INFO - 2021-03-31 09:02:16 --> Router Class Initialized
INFO - 2021-03-31 09:02:16 --> Output Class Initialized
INFO - 2021-03-31 09:02:16 --> Security Class Initialized
DEBUG - 2021-03-31 09:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:02:16 --> Input Class Initialized
INFO - 2021-03-31 09:02:16 --> Language Class Initialized
INFO - 2021-03-31 09:02:16 --> Language Class Initialized
INFO - 2021-03-31 09:02:16 --> Config Class Initialized
INFO - 2021-03-31 09:02:16 --> Loader Class Initialized
INFO - 2021-03-31 09:02:16 --> Helper loaded: url_helper
INFO - 2021-03-31 09:02:16 --> Helper loaded: file_helper
INFO - 2021-03-31 09:02:16 --> Helper loaded: form_helper
INFO - 2021-03-31 09:02:16 --> Helper loaded: my_helper
INFO - 2021-03-31 09:02:16 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:02:16 --> Controller Class Initialized
DEBUG - 2021-03-31 09:02:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-31 09:02:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:02:17 --> Final output sent to browser
DEBUG - 2021-03-31 09:02:17 --> Total execution time: 0.3053
INFO - 2021-03-31 09:02:21 --> Config Class Initialized
INFO - 2021-03-31 09:02:21 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:02:21 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:02:21 --> Utf8 Class Initialized
INFO - 2021-03-31 09:02:21 --> URI Class Initialized
INFO - 2021-03-31 09:02:21 --> Router Class Initialized
INFO - 2021-03-31 09:02:21 --> Output Class Initialized
INFO - 2021-03-31 09:02:21 --> Security Class Initialized
DEBUG - 2021-03-31 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:02:21 --> Input Class Initialized
INFO - 2021-03-31 09:02:21 --> Language Class Initialized
INFO - 2021-03-31 09:02:21 --> Language Class Initialized
INFO - 2021-03-31 09:02:21 --> Config Class Initialized
INFO - 2021-03-31 09:02:21 --> Loader Class Initialized
INFO - 2021-03-31 09:02:21 --> Helper loaded: url_helper
INFO - 2021-03-31 09:02:21 --> Helper loaded: file_helper
INFO - 2021-03-31 09:02:21 --> Helper loaded: form_helper
INFO - 2021-03-31 09:02:21 --> Helper loaded: my_helper
INFO - 2021-03-31 09:02:21 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:02:21 --> Controller Class Initialized
INFO - 2021-03-31 09:02:21 --> Config Class Initialized
INFO - 2021-03-31 09:02:21 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:02:21 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:02:21 --> Utf8 Class Initialized
INFO - 2021-03-31 09:02:21 --> URI Class Initialized
INFO - 2021-03-31 09:02:21 --> Router Class Initialized
INFO - 2021-03-31 09:02:21 --> Output Class Initialized
INFO - 2021-03-31 09:02:21 --> Security Class Initialized
DEBUG - 2021-03-31 09:02:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:02:21 --> Input Class Initialized
INFO - 2021-03-31 09:02:21 --> Language Class Initialized
INFO - 2021-03-31 09:02:21 --> Language Class Initialized
INFO - 2021-03-31 09:02:21 --> Config Class Initialized
INFO - 2021-03-31 09:02:21 --> Loader Class Initialized
INFO - 2021-03-31 09:02:21 --> Helper loaded: url_helper
INFO - 2021-03-31 09:02:21 --> Helper loaded: file_helper
INFO - 2021-03-31 09:02:21 --> Helper loaded: form_helper
INFO - 2021-03-31 09:02:21 --> Helper loaded: my_helper
INFO - 2021-03-31 09:02:21 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:02:21 --> Controller Class Initialized
DEBUG - 2021-03-31 09:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:02:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:02:22 --> Final output sent to browser
DEBUG - 2021-03-31 09:02:22 --> Total execution time: 0.3291
INFO - 2021-03-31 09:02:23 --> Config Class Initialized
INFO - 2021-03-31 09:02:23 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:02:23 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:02:23 --> Utf8 Class Initialized
INFO - 2021-03-31 09:02:23 --> URI Class Initialized
INFO - 2021-03-31 09:02:23 --> Router Class Initialized
INFO - 2021-03-31 09:02:23 --> Output Class Initialized
INFO - 2021-03-31 09:02:23 --> Security Class Initialized
DEBUG - 2021-03-31 09:02:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:02:23 --> Input Class Initialized
INFO - 2021-03-31 09:02:23 --> Language Class Initialized
INFO - 2021-03-31 09:02:23 --> Language Class Initialized
INFO - 2021-03-31 09:02:23 --> Config Class Initialized
INFO - 2021-03-31 09:02:23 --> Loader Class Initialized
INFO - 2021-03-31 09:02:23 --> Helper loaded: url_helper
INFO - 2021-03-31 09:02:24 --> Helper loaded: file_helper
INFO - 2021-03-31 09:02:24 --> Helper loaded: form_helper
INFO - 2021-03-31 09:02:24 --> Helper loaded: my_helper
INFO - 2021-03-31 09:02:24 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:02:24 --> Controller Class Initialized
DEBUG - 2021-03-31 09:02:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-31 09:02:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:02:24 --> Final output sent to browser
DEBUG - 2021-03-31 09:02:24 --> Total execution time: 0.3714
INFO - 2021-03-31 09:17:27 --> Config Class Initialized
INFO - 2021-03-31 09:17:27 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:27 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:27 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:27 --> URI Class Initialized
INFO - 2021-03-31 09:17:27 --> Router Class Initialized
INFO - 2021-03-31 09:17:27 --> Output Class Initialized
INFO - 2021-03-31 09:17:27 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:27 --> Input Class Initialized
INFO - 2021-03-31 09:17:27 --> Language Class Initialized
INFO - 2021-03-31 09:17:27 --> Language Class Initialized
INFO - 2021-03-31 09:17:27 --> Config Class Initialized
INFO - 2021-03-31 09:17:27 --> Loader Class Initialized
INFO - 2021-03-31 09:17:27 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:27 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:27 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:27 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:27 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:27 --> Controller Class Initialized
DEBUG - 2021-03-31 09:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:17:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:17:27 --> Final output sent to browser
DEBUG - 2021-03-31 09:17:27 --> Total execution time: 0.2560
INFO - 2021-03-31 09:17:28 --> Config Class Initialized
INFO - 2021-03-31 09:17:28 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:28 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:28 --> URI Class Initialized
INFO - 2021-03-31 09:17:28 --> Router Class Initialized
INFO - 2021-03-31 09:17:28 --> Output Class Initialized
INFO - 2021-03-31 09:17:28 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:28 --> Input Class Initialized
INFO - 2021-03-31 09:17:28 --> Language Class Initialized
INFO - 2021-03-31 09:17:28 --> Language Class Initialized
INFO - 2021-03-31 09:17:28 --> Config Class Initialized
INFO - 2021-03-31 09:17:28 --> Loader Class Initialized
INFO - 2021-03-31 09:17:28 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:28 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:28 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:28 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:28 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:28 --> Controller Class Initialized
DEBUG - 2021-03-31 09:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:17:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:17:28 --> Final output sent to browser
DEBUG - 2021-03-31 09:17:28 --> Total execution time: 0.2371
INFO - 2021-03-31 09:17:30 --> Config Class Initialized
INFO - 2021-03-31 09:17:30 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:30 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:30 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:30 --> URI Class Initialized
INFO - 2021-03-31 09:17:30 --> Router Class Initialized
INFO - 2021-03-31 09:17:30 --> Output Class Initialized
INFO - 2021-03-31 09:17:30 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:30 --> Input Class Initialized
INFO - 2021-03-31 09:17:30 --> Language Class Initialized
INFO - 2021-03-31 09:17:30 --> Language Class Initialized
INFO - 2021-03-31 09:17:30 --> Config Class Initialized
INFO - 2021-03-31 09:17:30 --> Loader Class Initialized
INFO - 2021-03-31 09:17:30 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:30 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:30 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:30 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:30 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:30 --> Controller Class Initialized
DEBUG - 2021-03-31 09:17:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-31 09:17:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:17:30 --> Final output sent to browser
DEBUG - 2021-03-31 09:17:30 --> Total execution time: 0.2785
INFO - 2021-03-31 09:17:37 --> Config Class Initialized
INFO - 2021-03-31 09:17:37 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:37 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:37 --> URI Class Initialized
INFO - 2021-03-31 09:17:37 --> Router Class Initialized
INFO - 2021-03-31 09:17:37 --> Output Class Initialized
INFO - 2021-03-31 09:17:37 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:37 --> Input Class Initialized
INFO - 2021-03-31 09:17:37 --> Language Class Initialized
INFO - 2021-03-31 09:17:37 --> Language Class Initialized
INFO - 2021-03-31 09:17:37 --> Config Class Initialized
INFO - 2021-03-31 09:17:37 --> Loader Class Initialized
INFO - 2021-03-31 09:17:37 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:37 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:37 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:37 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:37 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:37 --> Controller Class Initialized
INFO - 2021-03-31 09:17:37 --> Config Class Initialized
INFO - 2021-03-31 09:17:37 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:37 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:37 --> URI Class Initialized
INFO - 2021-03-31 09:17:37 --> Router Class Initialized
INFO - 2021-03-31 09:17:37 --> Output Class Initialized
INFO - 2021-03-31 09:17:37 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:37 --> Input Class Initialized
INFO - 2021-03-31 09:17:37 --> Language Class Initialized
INFO - 2021-03-31 09:17:37 --> Language Class Initialized
INFO - 2021-03-31 09:17:37 --> Config Class Initialized
INFO - 2021-03-31 09:17:37 --> Loader Class Initialized
INFO - 2021-03-31 09:17:37 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:37 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:37 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:37 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:37 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:37 --> Controller Class Initialized
DEBUG - 2021-03-31 09:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:17:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:17:37 --> Final output sent to browser
DEBUG - 2021-03-31 09:17:37 --> Total execution time: 0.2135
INFO - 2021-03-31 09:17:41 --> Config Class Initialized
INFO - 2021-03-31 09:17:41 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:41 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:41 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:41 --> URI Class Initialized
INFO - 2021-03-31 09:17:41 --> Router Class Initialized
INFO - 2021-03-31 09:17:41 --> Output Class Initialized
INFO - 2021-03-31 09:17:41 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:41 --> Input Class Initialized
INFO - 2021-03-31 09:17:41 --> Language Class Initialized
INFO - 2021-03-31 09:17:41 --> Language Class Initialized
INFO - 2021-03-31 09:17:41 --> Config Class Initialized
INFO - 2021-03-31 09:17:41 --> Loader Class Initialized
INFO - 2021-03-31 09:17:41 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:41 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:41 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:41 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:41 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:41 --> Controller Class Initialized
DEBUG - 2021-03-31 09:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-31 09:17:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:17:41 --> Final output sent to browser
DEBUG - 2021-03-31 09:17:41 --> Total execution time: 0.3317
INFO - 2021-03-31 09:17:41 --> Config Class Initialized
INFO - 2021-03-31 09:17:41 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:41 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:41 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:41 --> URI Class Initialized
INFO - 2021-03-31 09:17:41 --> Router Class Initialized
INFO - 2021-03-31 09:17:41 --> Output Class Initialized
INFO - 2021-03-31 09:17:41 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:41 --> Input Class Initialized
INFO - 2021-03-31 09:17:41 --> Language Class Initialized
INFO - 2021-03-31 09:17:41 --> Language Class Initialized
INFO - 2021-03-31 09:17:41 --> Config Class Initialized
INFO - 2021-03-31 09:17:41 --> Loader Class Initialized
INFO - 2021-03-31 09:17:41 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:41 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:41 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:41 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:41 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:42 --> Controller Class Initialized
INFO - 2021-03-31 09:17:43 --> Config Class Initialized
INFO - 2021-03-31 09:17:43 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:43 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:43 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:43 --> URI Class Initialized
INFO - 2021-03-31 09:17:43 --> Router Class Initialized
INFO - 2021-03-31 09:17:43 --> Output Class Initialized
INFO - 2021-03-31 09:17:43 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:43 --> Input Class Initialized
INFO - 2021-03-31 09:17:43 --> Language Class Initialized
INFO - 2021-03-31 09:17:43 --> Language Class Initialized
INFO - 2021-03-31 09:17:43 --> Config Class Initialized
INFO - 2021-03-31 09:17:43 --> Loader Class Initialized
INFO - 2021-03-31 09:17:43 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:43 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:43 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:43 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:43 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:43 --> Controller Class Initialized
INFO - 2021-03-31 09:17:43 --> Final output sent to browser
DEBUG - 2021-03-31 09:17:43 --> Total execution time: 0.2323
INFO - 2021-03-31 09:17:48 --> Config Class Initialized
INFO - 2021-03-31 09:17:48 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:48 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:48 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:48 --> URI Class Initialized
INFO - 2021-03-31 09:17:48 --> Router Class Initialized
INFO - 2021-03-31 09:17:48 --> Output Class Initialized
INFO - 2021-03-31 09:17:48 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:48 --> Input Class Initialized
INFO - 2021-03-31 09:17:48 --> Language Class Initialized
INFO - 2021-03-31 09:17:48 --> Language Class Initialized
INFO - 2021-03-31 09:17:48 --> Config Class Initialized
INFO - 2021-03-31 09:17:48 --> Loader Class Initialized
INFO - 2021-03-31 09:17:48 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:48 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:48 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:48 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:48 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:48 --> Controller Class Initialized
ERROR - 2021-03-31 09:17:48 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '2'
INFO - 2021-03-31 09:17:48 --> Language file loaded: language/english/db_lang.php
INFO - 2021-03-31 09:17:53 --> Config Class Initialized
INFO - 2021-03-31 09:17:53 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:17:53 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:17:53 --> Utf8 Class Initialized
INFO - 2021-03-31 09:17:53 --> URI Class Initialized
INFO - 2021-03-31 09:17:53 --> Router Class Initialized
INFO - 2021-03-31 09:17:53 --> Output Class Initialized
INFO - 2021-03-31 09:17:53 --> Security Class Initialized
DEBUG - 2021-03-31 09:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:17:53 --> Input Class Initialized
INFO - 2021-03-31 09:17:53 --> Language Class Initialized
INFO - 2021-03-31 09:17:53 --> Language Class Initialized
INFO - 2021-03-31 09:17:53 --> Config Class Initialized
INFO - 2021-03-31 09:17:53 --> Loader Class Initialized
INFO - 2021-03-31 09:17:53 --> Helper loaded: url_helper
INFO - 2021-03-31 09:17:53 --> Helper loaded: file_helper
INFO - 2021-03-31 09:17:53 --> Helper loaded: form_helper
INFO - 2021-03-31 09:17:53 --> Helper loaded: my_helper
INFO - 2021-03-31 09:17:53 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:17:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:17:53 --> Controller Class Initialized
ERROR - 2021-03-31 09:17:53 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '2'
INFO - 2021-03-31 09:17:53 --> Language file loaded: language/english/db_lang.php
INFO - 2021-03-31 09:18:02 --> Config Class Initialized
INFO - 2021-03-31 09:18:02 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:18:02 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:18:02 --> Utf8 Class Initialized
INFO - 2021-03-31 09:18:02 --> URI Class Initialized
INFO - 2021-03-31 09:18:02 --> Router Class Initialized
INFO - 2021-03-31 09:18:02 --> Output Class Initialized
INFO - 2021-03-31 09:18:02 --> Security Class Initialized
DEBUG - 2021-03-31 09:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:18:02 --> Input Class Initialized
INFO - 2021-03-31 09:18:02 --> Language Class Initialized
INFO - 2021-03-31 09:18:02 --> Language Class Initialized
INFO - 2021-03-31 09:18:02 --> Config Class Initialized
INFO - 2021-03-31 09:18:02 --> Loader Class Initialized
INFO - 2021-03-31 09:18:02 --> Helper loaded: url_helper
INFO - 2021-03-31 09:18:02 --> Helper loaded: file_helper
INFO - 2021-03-31 09:18:02 --> Helper loaded: form_helper
INFO - 2021-03-31 09:18:02 --> Helper loaded: my_helper
INFO - 2021-03-31 09:18:02 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:18:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:18:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:18:02 --> Controller Class Initialized
DEBUG - 2021-03-31 09:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-31 09:18:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:18:02 --> Final output sent to browser
DEBUG - 2021-03-31 09:18:02 --> Total execution time: 0.2497
INFO - 2021-03-31 09:18:02 --> Config Class Initialized
INFO - 2021-03-31 09:18:02 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:18:02 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:18:02 --> Utf8 Class Initialized
INFO - 2021-03-31 09:18:02 --> URI Class Initialized
INFO - 2021-03-31 09:18:02 --> Router Class Initialized
INFO - 2021-03-31 09:18:02 --> Output Class Initialized
INFO - 2021-03-31 09:18:02 --> Security Class Initialized
DEBUG - 2021-03-31 09:18:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:18:02 --> Input Class Initialized
INFO - 2021-03-31 09:18:02 --> Language Class Initialized
INFO - 2021-03-31 09:18:02 --> Language Class Initialized
INFO - 2021-03-31 09:18:03 --> Config Class Initialized
INFO - 2021-03-31 09:18:03 --> Loader Class Initialized
INFO - 2021-03-31 09:18:03 --> Helper loaded: url_helper
INFO - 2021-03-31 09:18:03 --> Helper loaded: file_helper
INFO - 2021-03-31 09:18:03 --> Helper loaded: form_helper
INFO - 2021-03-31 09:18:03 --> Helper loaded: my_helper
INFO - 2021-03-31 09:18:03 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:18:03 --> Controller Class Initialized
INFO - 2021-03-31 09:18:07 --> Config Class Initialized
INFO - 2021-03-31 09:18:07 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:18:08 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:18:08 --> Utf8 Class Initialized
INFO - 2021-03-31 09:18:08 --> URI Class Initialized
INFO - 2021-03-31 09:18:08 --> Router Class Initialized
INFO - 2021-03-31 09:18:08 --> Output Class Initialized
INFO - 2021-03-31 09:18:08 --> Security Class Initialized
DEBUG - 2021-03-31 09:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:18:08 --> Input Class Initialized
INFO - 2021-03-31 09:18:08 --> Language Class Initialized
INFO - 2021-03-31 09:18:08 --> Language Class Initialized
INFO - 2021-03-31 09:18:08 --> Config Class Initialized
INFO - 2021-03-31 09:18:08 --> Loader Class Initialized
INFO - 2021-03-31 09:18:08 --> Helper loaded: url_helper
INFO - 2021-03-31 09:18:08 --> Helper loaded: file_helper
INFO - 2021-03-31 09:18:08 --> Helper loaded: form_helper
INFO - 2021-03-31 09:18:08 --> Helper loaded: my_helper
INFO - 2021-03-31 09:18:08 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:18:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:18:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:18:08 --> Controller Class Initialized
ERROR - 2021-03-31 09:18:08 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '2'
INFO - 2021-03-31 09:18:08 --> Language file loaded: language/english/db_lang.php
INFO - 2021-03-31 09:20:01 --> Config Class Initialized
INFO - 2021-03-31 09:20:01 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:20:01 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:20:01 --> Utf8 Class Initialized
INFO - 2021-03-31 09:20:01 --> URI Class Initialized
INFO - 2021-03-31 09:20:01 --> Router Class Initialized
INFO - 2021-03-31 09:20:01 --> Output Class Initialized
INFO - 2021-03-31 09:20:01 --> Security Class Initialized
DEBUG - 2021-03-31 09:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:20:01 --> Input Class Initialized
INFO - 2021-03-31 09:20:01 --> Language Class Initialized
INFO - 2021-03-31 09:20:01 --> Language Class Initialized
INFO - 2021-03-31 09:20:01 --> Config Class Initialized
INFO - 2021-03-31 09:20:01 --> Loader Class Initialized
INFO - 2021-03-31 09:20:01 --> Helper loaded: url_helper
INFO - 2021-03-31 09:20:01 --> Helper loaded: file_helper
INFO - 2021-03-31 09:20:01 --> Helper loaded: form_helper
INFO - 2021-03-31 09:20:01 --> Helper loaded: my_helper
INFO - 2021-03-31 09:20:01 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:20:01 --> Controller Class Initialized
INFO - 2021-03-31 09:20:01 --> Helper loaded: cookie_helper
INFO - 2021-03-31 09:20:01 --> Config Class Initialized
INFO - 2021-03-31 09:20:01 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:20:01 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:20:01 --> Utf8 Class Initialized
INFO - 2021-03-31 09:20:01 --> URI Class Initialized
INFO - 2021-03-31 09:20:01 --> Router Class Initialized
INFO - 2021-03-31 09:20:01 --> Output Class Initialized
INFO - 2021-03-31 09:20:01 --> Security Class Initialized
DEBUG - 2021-03-31 09:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:20:01 --> Input Class Initialized
INFO - 2021-03-31 09:20:01 --> Language Class Initialized
INFO - 2021-03-31 09:20:01 --> Language Class Initialized
INFO - 2021-03-31 09:20:01 --> Config Class Initialized
INFO - 2021-03-31 09:20:01 --> Loader Class Initialized
INFO - 2021-03-31 09:20:01 --> Helper loaded: url_helper
INFO - 2021-03-31 09:20:01 --> Helper loaded: file_helper
INFO - 2021-03-31 09:20:01 --> Helper loaded: form_helper
INFO - 2021-03-31 09:20:01 --> Helper loaded: my_helper
INFO - 2021-03-31 09:20:01 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:20:01 --> Controller Class Initialized
DEBUG - 2021-03-31 09:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-03-31 09:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:20:01 --> Final output sent to browser
DEBUG - 2021-03-31 09:20:01 --> Total execution time: 0.2522
INFO - 2021-03-31 09:21:18 --> Config Class Initialized
INFO - 2021-03-31 09:21:18 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:18 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:18 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:18 --> URI Class Initialized
DEBUG - 2021-03-31 09:21:18 --> No URI present. Default controller set.
INFO - 2021-03-31 09:21:18 --> Router Class Initialized
INFO - 2021-03-31 09:21:18 --> Output Class Initialized
INFO - 2021-03-31 09:21:18 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:18 --> Input Class Initialized
INFO - 2021-03-31 09:21:18 --> Language Class Initialized
INFO - 2021-03-31 09:21:18 --> Language Class Initialized
INFO - 2021-03-31 09:21:18 --> Config Class Initialized
INFO - 2021-03-31 09:21:18 --> Loader Class Initialized
INFO - 2021-03-31 09:21:18 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:18 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:18 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:18 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:18 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:18 --> Controller Class Initialized
INFO - 2021-03-31 09:21:18 --> Config Class Initialized
INFO - 2021-03-31 09:21:18 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:18 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:18 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:18 --> URI Class Initialized
INFO - 2021-03-31 09:21:18 --> Router Class Initialized
INFO - 2021-03-31 09:21:18 --> Output Class Initialized
INFO - 2021-03-31 09:21:18 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:18 --> Input Class Initialized
INFO - 2021-03-31 09:21:18 --> Language Class Initialized
INFO - 2021-03-31 09:21:19 --> Language Class Initialized
INFO - 2021-03-31 09:21:19 --> Config Class Initialized
INFO - 2021-03-31 09:21:19 --> Loader Class Initialized
INFO - 2021-03-31 09:21:19 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:19 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:19 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:19 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:19 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:19 --> Controller Class Initialized
DEBUG - 2021-03-31 09:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-03-31 09:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:21:19 --> Final output sent to browser
DEBUG - 2021-03-31 09:21:19 --> Total execution time: 0.2971
INFO - 2021-03-31 09:21:24 --> Config Class Initialized
INFO - 2021-03-31 09:21:24 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:24 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:24 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:24 --> URI Class Initialized
INFO - 2021-03-31 09:21:24 --> Router Class Initialized
INFO - 2021-03-31 09:21:24 --> Output Class Initialized
INFO - 2021-03-31 09:21:24 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:24 --> Input Class Initialized
INFO - 2021-03-31 09:21:24 --> Language Class Initialized
INFO - 2021-03-31 09:21:24 --> Language Class Initialized
INFO - 2021-03-31 09:21:24 --> Config Class Initialized
INFO - 2021-03-31 09:21:24 --> Loader Class Initialized
INFO - 2021-03-31 09:21:24 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:24 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:24 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:24 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:24 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:24 --> Controller Class Initialized
INFO - 2021-03-31 09:21:25 --> Helper loaded: cookie_helper
INFO - 2021-03-31 09:21:25 --> Final output sent to browser
DEBUG - 2021-03-31 09:21:25 --> Total execution time: 0.2892
INFO - 2021-03-31 09:21:25 --> Config Class Initialized
INFO - 2021-03-31 09:21:25 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:25 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:25 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:25 --> URI Class Initialized
INFO - 2021-03-31 09:21:25 --> Router Class Initialized
INFO - 2021-03-31 09:21:25 --> Output Class Initialized
INFO - 2021-03-31 09:21:25 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:25 --> Input Class Initialized
INFO - 2021-03-31 09:21:25 --> Language Class Initialized
INFO - 2021-03-31 09:21:25 --> Language Class Initialized
INFO - 2021-03-31 09:21:25 --> Config Class Initialized
INFO - 2021-03-31 09:21:25 --> Loader Class Initialized
INFO - 2021-03-31 09:21:25 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:25 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:25 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:25 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:25 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:25 --> Controller Class Initialized
DEBUG - 2021-03-31 09:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-03-31 09:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:21:25 --> Final output sent to browser
DEBUG - 2021-03-31 09:21:25 --> Total execution time: 0.3357
INFO - 2021-03-31 09:21:29 --> Config Class Initialized
INFO - 2021-03-31 09:21:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:29 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:29 --> URI Class Initialized
INFO - 2021-03-31 09:21:29 --> Router Class Initialized
INFO - 2021-03-31 09:21:29 --> Output Class Initialized
INFO - 2021-03-31 09:21:29 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:29 --> Input Class Initialized
INFO - 2021-03-31 09:21:29 --> Language Class Initialized
INFO - 2021-03-31 09:21:29 --> Language Class Initialized
INFO - 2021-03-31 09:21:29 --> Config Class Initialized
INFO - 2021-03-31 09:21:29 --> Loader Class Initialized
INFO - 2021-03-31 09:21:29 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:29 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:29 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:29 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:29 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:29 --> Controller Class Initialized
DEBUG - 2021-03-31 09:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-31 09:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:21:29 --> Final output sent to browser
DEBUG - 2021-03-31 09:21:29 --> Total execution time: 0.2192
INFO - 2021-03-31 09:21:29 --> Config Class Initialized
INFO - 2021-03-31 09:21:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:29 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:29 --> URI Class Initialized
INFO - 2021-03-31 09:21:29 --> Router Class Initialized
INFO - 2021-03-31 09:21:29 --> Output Class Initialized
INFO - 2021-03-31 09:21:29 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:29 --> Input Class Initialized
INFO - 2021-03-31 09:21:29 --> Language Class Initialized
INFO - 2021-03-31 09:21:29 --> Language Class Initialized
INFO - 2021-03-31 09:21:29 --> Config Class Initialized
INFO - 2021-03-31 09:21:29 --> Loader Class Initialized
INFO - 2021-03-31 09:21:29 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:29 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:29 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:29 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:29 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:29 --> Controller Class Initialized
INFO - 2021-03-31 09:21:32 --> Config Class Initialized
INFO - 2021-03-31 09:21:32 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:32 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:32 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:32 --> URI Class Initialized
INFO - 2021-03-31 09:21:32 --> Router Class Initialized
INFO - 2021-03-31 09:21:32 --> Output Class Initialized
INFO - 2021-03-31 09:21:32 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:32 --> Input Class Initialized
INFO - 2021-03-31 09:21:32 --> Language Class Initialized
INFO - 2021-03-31 09:21:32 --> Language Class Initialized
INFO - 2021-03-31 09:21:32 --> Config Class Initialized
INFO - 2021-03-31 09:21:32 --> Loader Class Initialized
INFO - 2021-03-31 09:21:32 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:32 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:32 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:32 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:32 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:32 --> Controller Class Initialized
ERROR - 2021-03-31 09:21:32 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_kelas_siswa`, CONSTRAINT `t_kelas_siswa_ibfk_1` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '2'
INFO - 2021-03-31 09:21:32 --> Language file loaded: language/english/db_lang.php
INFO - 2021-03-31 09:21:33 --> Config Class Initialized
INFO - 2021-03-31 09:21:33 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:33 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:33 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:33 --> URI Class Initialized
INFO - 2021-03-31 09:21:33 --> Router Class Initialized
INFO - 2021-03-31 09:21:33 --> Output Class Initialized
INFO - 2021-03-31 09:21:33 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:33 --> Input Class Initialized
INFO - 2021-03-31 09:21:33 --> Language Class Initialized
INFO - 2021-03-31 09:21:33 --> Language Class Initialized
INFO - 2021-03-31 09:21:33 --> Config Class Initialized
INFO - 2021-03-31 09:21:33 --> Loader Class Initialized
INFO - 2021-03-31 09:21:33 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:33 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:33 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:33 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:33 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:33 --> Controller Class Initialized
INFO - 2021-03-31 09:21:33 --> Final output sent to browser
DEBUG - 2021-03-31 09:21:34 --> Total execution time: 0.2533
INFO - 2021-03-31 09:21:39 --> Config Class Initialized
INFO - 2021-03-31 09:21:39 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:39 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:39 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:39 --> URI Class Initialized
INFO - 2021-03-31 09:21:39 --> Router Class Initialized
INFO - 2021-03-31 09:21:39 --> Output Class Initialized
INFO - 2021-03-31 09:21:39 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:40 --> Input Class Initialized
INFO - 2021-03-31 09:21:40 --> Language Class Initialized
INFO - 2021-03-31 09:21:40 --> Language Class Initialized
INFO - 2021-03-31 09:21:40 --> Config Class Initialized
INFO - 2021-03-31 09:21:40 --> Loader Class Initialized
INFO - 2021-03-31 09:21:40 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:40 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:40 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:40 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:40 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:40 --> Controller Class Initialized
INFO - 2021-03-31 09:21:40 --> Final output sent to browser
DEBUG - 2021-03-31 09:21:40 --> Total execution time: 0.2567
INFO - 2021-03-31 09:21:40 --> Config Class Initialized
INFO - 2021-03-31 09:21:40 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:21:40 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:21:40 --> Utf8 Class Initialized
INFO - 2021-03-31 09:21:40 --> URI Class Initialized
INFO - 2021-03-31 09:21:40 --> Router Class Initialized
INFO - 2021-03-31 09:21:40 --> Output Class Initialized
INFO - 2021-03-31 09:21:40 --> Security Class Initialized
DEBUG - 2021-03-31 09:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:21:40 --> Input Class Initialized
INFO - 2021-03-31 09:21:40 --> Language Class Initialized
INFO - 2021-03-31 09:21:40 --> Language Class Initialized
INFO - 2021-03-31 09:21:40 --> Config Class Initialized
INFO - 2021-03-31 09:21:40 --> Loader Class Initialized
INFO - 2021-03-31 09:21:40 --> Helper loaded: url_helper
INFO - 2021-03-31 09:21:40 --> Helper loaded: file_helper
INFO - 2021-03-31 09:21:40 --> Helper loaded: form_helper
INFO - 2021-03-31 09:21:40 --> Helper loaded: my_helper
INFO - 2021-03-31 09:21:40 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:21:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:21:40 --> Controller Class Initialized
INFO - 2021-03-31 09:24:58 --> Config Class Initialized
INFO - 2021-03-31 09:24:58 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:24:58 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:24:58 --> Utf8 Class Initialized
INFO - 2021-03-31 09:24:58 --> URI Class Initialized
INFO - 2021-03-31 09:24:58 --> Router Class Initialized
INFO - 2021-03-31 09:24:58 --> Output Class Initialized
INFO - 2021-03-31 09:24:58 --> Security Class Initialized
DEBUG - 2021-03-31 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:24:59 --> Input Class Initialized
INFO - 2021-03-31 09:24:59 --> Language Class Initialized
INFO - 2021-03-31 09:24:59 --> Language Class Initialized
INFO - 2021-03-31 09:24:59 --> Config Class Initialized
INFO - 2021-03-31 09:24:59 --> Loader Class Initialized
INFO - 2021-03-31 09:24:59 --> Helper loaded: url_helper
INFO - 2021-03-31 09:24:59 --> Helper loaded: file_helper
INFO - 2021-03-31 09:24:59 --> Helper loaded: form_helper
INFO - 2021-03-31 09:24:59 --> Helper loaded: my_helper
INFO - 2021-03-31 09:24:59 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:24:59 --> Controller Class Initialized
DEBUG - 2021-03-31 09:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-31 09:24:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:24:59 --> Final output sent to browser
DEBUG - 2021-03-31 09:24:59 --> Total execution time: 0.3161
INFO - 2021-03-31 09:24:59 --> Config Class Initialized
INFO - 2021-03-31 09:24:59 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:24:59 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:24:59 --> Utf8 Class Initialized
INFO - 2021-03-31 09:24:59 --> URI Class Initialized
INFO - 2021-03-31 09:24:59 --> Router Class Initialized
INFO - 2021-03-31 09:24:59 --> Output Class Initialized
INFO - 2021-03-31 09:24:59 --> Security Class Initialized
DEBUG - 2021-03-31 09:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:24:59 --> Input Class Initialized
INFO - 2021-03-31 09:24:59 --> Language Class Initialized
INFO - 2021-03-31 09:24:59 --> Language Class Initialized
INFO - 2021-03-31 09:24:59 --> Config Class Initialized
INFO - 2021-03-31 09:24:59 --> Loader Class Initialized
INFO - 2021-03-31 09:24:59 --> Helper loaded: url_helper
INFO - 2021-03-31 09:24:59 --> Helper loaded: file_helper
INFO - 2021-03-31 09:24:59 --> Helper loaded: form_helper
INFO - 2021-03-31 09:24:59 --> Helper loaded: my_helper
INFO - 2021-03-31 09:24:59 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:24:59 --> Controller Class Initialized
INFO - 2021-03-31 09:25:00 --> Config Class Initialized
INFO - 2021-03-31 09:25:00 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:25:00 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:25:00 --> Utf8 Class Initialized
INFO - 2021-03-31 09:25:00 --> URI Class Initialized
INFO - 2021-03-31 09:25:00 --> Router Class Initialized
INFO - 2021-03-31 09:25:00 --> Output Class Initialized
INFO - 2021-03-31 09:25:00 --> Security Class Initialized
DEBUG - 2021-03-31 09:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:25:00 --> Input Class Initialized
INFO - 2021-03-31 09:25:00 --> Language Class Initialized
INFO - 2021-03-31 09:25:00 --> Language Class Initialized
INFO - 2021-03-31 09:25:00 --> Config Class Initialized
INFO - 2021-03-31 09:25:00 --> Loader Class Initialized
INFO - 2021-03-31 09:25:00 --> Helper loaded: url_helper
INFO - 2021-03-31 09:25:00 --> Helper loaded: file_helper
INFO - 2021-03-31 09:25:00 --> Helper loaded: form_helper
INFO - 2021-03-31 09:25:00 --> Helper loaded: my_helper
INFO - 2021-03-31 09:25:00 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:25:00 --> Controller Class Initialized
INFO - 2021-03-31 09:25:00 --> Final output sent to browser
DEBUG - 2021-03-31 09:25:00 --> Total execution time: 0.2678
INFO - 2021-03-31 09:33:46 --> Config Class Initialized
INFO - 2021-03-31 09:33:46 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:33:46 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:33:46 --> Utf8 Class Initialized
INFO - 2021-03-31 09:33:46 --> URI Class Initialized
INFO - 2021-03-31 09:33:46 --> Router Class Initialized
INFO - 2021-03-31 09:33:46 --> Output Class Initialized
INFO - 2021-03-31 09:33:46 --> Security Class Initialized
DEBUG - 2021-03-31 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:33:47 --> Input Class Initialized
INFO - 2021-03-31 09:33:47 --> Language Class Initialized
INFO - 2021-03-31 09:33:47 --> Language Class Initialized
INFO - 2021-03-31 09:33:47 --> Config Class Initialized
INFO - 2021-03-31 09:33:47 --> Loader Class Initialized
INFO - 2021-03-31 09:33:47 --> Helper loaded: url_helper
INFO - 2021-03-31 09:33:47 --> Helper loaded: file_helper
INFO - 2021-03-31 09:33:47 --> Helper loaded: form_helper
INFO - 2021-03-31 09:33:47 --> Helper loaded: my_helper
INFO - 2021-03-31 09:33:47 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:33:47 --> Controller Class Initialized
DEBUG - 2021-03-31 09:33:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-31 09:33:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:33:47 --> Final output sent to browser
DEBUG - 2021-03-31 09:33:47 --> Total execution time: 0.2983
INFO - 2021-03-31 09:33:47 --> Config Class Initialized
INFO - 2021-03-31 09:33:47 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:33:47 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:33:47 --> Utf8 Class Initialized
INFO - 2021-03-31 09:33:47 --> URI Class Initialized
INFO - 2021-03-31 09:33:47 --> Router Class Initialized
INFO - 2021-03-31 09:33:47 --> Output Class Initialized
INFO - 2021-03-31 09:33:47 --> Security Class Initialized
DEBUG - 2021-03-31 09:33:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:33:47 --> Input Class Initialized
INFO - 2021-03-31 09:33:47 --> Language Class Initialized
INFO - 2021-03-31 09:33:47 --> Language Class Initialized
INFO - 2021-03-31 09:33:47 --> Config Class Initialized
INFO - 2021-03-31 09:33:47 --> Loader Class Initialized
INFO - 2021-03-31 09:33:47 --> Helper loaded: url_helper
INFO - 2021-03-31 09:33:47 --> Helper loaded: file_helper
INFO - 2021-03-31 09:33:47 --> Helper loaded: form_helper
INFO - 2021-03-31 09:33:47 --> Helper loaded: my_helper
INFO - 2021-03-31 09:33:47 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:33:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:33:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:33:47 --> Controller Class Initialized
INFO - 2021-03-31 09:33:48 --> Config Class Initialized
INFO - 2021-03-31 09:33:48 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:33:48 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:33:48 --> Utf8 Class Initialized
INFO - 2021-03-31 09:33:48 --> URI Class Initialized
INFO - 2021-03-31 09:33:48 --> Router Class Initialized
INFO - 2021-03-31 09:33:48 --> Output Class Initialized
INFO - 2021-03-31 09:33:48 --> Security Class Initialized
DEBUG - 2021-03-31 09:33:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:33:48 --> Input Class Initialized
INFO - 2021-03-31 09:33:48 --> Language Class Initialized
INFO - 2021-03-31 09:33:48 --> Language Class Initialized
INFO - 2021-03-31 09:33:48 --> Config Class Initialized
INFO - 2021-03-31 09:33:48 --> Loader Class Initialized
INFO - 2021-03-31 09:33:48 --> Helper loaded: url_helper
INFO - 2021-03-31 09:33:48 --> Helper loaded: file_helper
INFO - 2021-03-31 09:33:48 --> Helper loaded: form_helper
INFO - 2021-03-31 09:33:48 --> Helper loaded: my_helper
INFO - 2021-03-31 09:33:48 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:33:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:33:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:33:48 --> Controller Class Initialized
INFO - 2021-03-31 09:33:48 --> Final output sent to browser
DEBUG - 2021-03-31 09:33:48 --> Total execution time: 0.2658
INFO - 2021-03-31 09:33:51 --> Config Class Initialized
INFO - 2021-03-31 09:33:51 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:33:51 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:33:51 --> Utf8 Class Initialized
INFO - 2021-03-31 09:33:51 --> URI Class Initialized
INFO - 2021-03-31 09:33:51 --> Router Class Initialized
INFO - 2021-03-31 09:33:51 --> Output Class Initialized
INFO - 2021-03-31 09:33:51 --> Security Class Initialized
DEBUG - 2021-03-31 09:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:33:51 --> Input Class Initialized
INFO - 2021-03-31 09:33:51 --> Language Class Initialized
INFO - 2021-03-31 09:33:51 --> Language Class Initialized
INFO - 2021-03-31 09:33:51 --> Config Class Initialized
INFO - 2021-03-31 09:33:51 --> Loader Class Initialized
INFO - 2021-03-31 09:33:51 --> Helper loaded: url_helper
INFO - 2021-03-31 09:33:51 --> Helper loaded: file_helper
INFO - 2021-03-31 09:33:51 --> Helper loaded: form_helper
INFO - 2021-03-31 09:33:51 --> Helper loaded: my_helper
INFO - 2021-03-31 09:33:52 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:33:52 --> Controller Class Initialized
INFO - 2021-03-31 09:33:52 --> Final output sent to browser
DEBUG - 2021-03-31 09:33:52 --> Total execution time: 0.2601
INFO - 2021-03-31 09:33:52 --> Config Class Initialized
INFO - 2021-03-31 09:33:52 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:33:52 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:33:52 --> Utf8 Class Initialized
INFO - 2021-03-31 09:33:52 --> URI Class Initialized
INFO - 2021-03-31 09:33:52 --> Router Class Initialized
INFO - 2021-03-31 09:33:52 --> Output Class Initialized
INFO - 2021-03-31 09:33:52 --> Security Class Initialized
DEBUG - 2021-03-31 09:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:33:52 --> Input Class Initialized
INFO - 2021-03-31 09:33:52 --> Language Class Initialized
INFO - 2021-03-31 09:33:52 --> Language Class Initialized
INFO - 2021-03-31 09:33:52 --> Config Class Initialized
INFO - 2021-03-31 09:33:52 --> Loader Class Initialized
INFO - 2021-03-31 09:33:52 --> Helper loaded: url_helper
INFO - 2021-03-31 09:33:52 --> Helper loaded: file_helper
INFO - 2021-03-31 09:33:52 --> Helper loaded: form_helper
INFO - 2021-03-31 09:33:52 --> Helper loaded: my_helper
INFO - 2021-03-31 09:33:52 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:33:52 --> Controller Class Initialized
INFO - 2021-03-31 09:33:54 --> Config Class Initialized
INFO - 2021-03-31 09:33:54 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:33:54 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:33:54 --> Utf8 Class Initialized
INFO - 2021-03-31 09:33:54 --> URI Class Initialized
INFO - 2021-03-31 09:33:54 --> Router Class Initialized
INFO - 2021-03-31 09:33:54 --> Output Class Initialized
INFO - 2021-03-31 09:33:54 --> Security Class Initialized
DEBUG - 2021-03-31 09:33:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:33:54 --> Input Class Initialized
INFO - 2021-03-31 09:33:54 --> Language Class Initialized
INFO - 2021-03-31 09:33:54 --> Language Class Initialized
INFO - 2021-03-31 09:33:54 --> Config Class Initialized
INFO - 2021-03-31 09:33:54 --> Loader Class Initialized
INFO - 2021-03-31 09:33:54 --> Helper loaded: url_helper
INFO - 2021-03-31 09:33:54 --> Helper loaded: file_helper
INFO - 2021-03-31 09:33:54 --> Helper loaded: form_helper
INFO - 2021-03-31 09:33:54 --> Helper loaded: my_helper
INFO - 2021-03-31 09:33:54 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:33:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:33:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:33:54 --> Controller Class Initialized
INFO - 2021-03-31 09:33:54 --> Final output sent to browser
DEBUG - 2021-03-31 09:33:54 --> Total execution time: 0.2391
INFO - 2021-03-31 09:34:04 --> Config Class Initialized
INFO - 2021-03-31 09:34:04 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:04 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:04 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:04 --> URI Class Initialized
INFO - 2021-03-31 09:34:04 --> Router Class Initialized
INFO - 2021-03-31 09:34:04 --> Output Class Initialized
INFO - 2021-03-31 09:34:04 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:04 --> Input Class Initialized
INFO - 2021-03-31 09:34:04 --> Language Class Initialized
INFO - 2021-03-31 09:34:04 --> Language Class Initialized
INFO - 2021-03-31 09:34:04 --> Config Class Initialized
INFO - 2021-03-31 09:34:04 --> Loader Class Initialized
INFO - 2021-03-31 09:34:04 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:04 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:04 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:04 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:04 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:04 --> Controller Class Initialized
INFO - 2021-03-31 09:34:04 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:04 --> Total execution time: 0.2767
INFO - 2021-03-31 09:34:04 --> Config Class Initialized
INFO - 2021-03-31 09:34:04 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:04 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:04 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:04 --> URI Class Initialized
INFO - 2021-03-31 09:34:04 --> Router Class Initialized
INFO - 2021-03-31 09:34:04 --> Output Class Initialized
INFO - 2021-03-31 09:34:04 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:04 --> Input Class Initialized
INFO - 2021-03-31 09:34:04 --> Language Class Initialized
INFO - 2021-03-31 09:34:04 --> Language Class Initialized
INFO - 2021-03-31 09:34:04 --> Config Class Initialized
INFO - 2021-03-31 09:34:04 --> Loader Class Initialized
INFO - 2021-03-31 09:34:04 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:04 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:04 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:04 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:04 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:04 --> Controller Class Initialized
INFO - 2021-03-31 09:34:18 --> Config Class Initialized
INFO - 2021-03-31 09:34:18 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:18 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:18 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:18 --> URI Class Initialized
INFO - 2021-03-31 09:34:18 --> Router Class Initialized
INFO - 2021-03-31 09:34:18 --> Output Class Initialized
INFO - 2021-03-31 09:34:18 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:18 --> Input Class Initialized
INFO - 2021-03-31 09:34:18 --> Language Class Initialized
INFO - 2021-03-31 09:34:18 --> Language Class Initialized
INFO - 2021-03-31 09:34:18 --> Config Class Initialized
INFO - 2021-03-31 09:34:18 --> Loader Class Initialized
INFO - 2021-03-31 09:34:18 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:18 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:18 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:18 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:18 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:18 --> Controller Class Initialized
DEBUG - 2021-03-31 09:34:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-03-31 09:34:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:34:18 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:18 --> Total execution time: 0.3231
INFO - 2021-03-31 09:34:18 --> Config Class Initialized
INFO - 2021-03-31 09:34:18 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:18 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:18 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:18 --> URI Class Initialized
INFO - 2021-03-31 09:34:18 --> Router Class Initialized
INFO - 2021-03-31 09:34:18 --> Output Class Initialized
INFO - 2021-03-31 09:34:18 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:18 --> Input Class Initialized
INFO - 2021-03-31 09:34:18 --> Language Class Initialized
INFO - 2021-03-31 09:34:18 --> Language Class Initialized
INFO - 2021-03-31 09:34:18 --> Config Class Initialized
INFO - 2021-03-31 09:34:18 --> Loader Class Initialized
INFO - 2021-03-31 09:34:18 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:18 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:18 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:18 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:18 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:18 --> Controller Class Initialized
INFO - 2021-03-31 09:34:21 --> Config Class Initialized
INFO - 2021-03-31 09:34:21 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:21 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:21 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:21 --> URI Class Initialized
INFO - 2021-03-31 09:34:21 --> Router Class Initialized
INFO - 2021-03-31 09:34:22 --> Output Class Initialized
INFO - 2021-03-31 09:34:22 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:22 --> Input Class Initialized
INFO - 2021-03-31 09:34:22 --> Language Class Initialized
INFO - 2021-03-31 09:34:22 --> Language Class Initialized
INFO - 2021-03-31 09:34:22 --> Config Class Initialized
INFO - 2021-03-31 09:34:22 --> Loader Class Initialized
INFO - 2021-03-31 09:34:22 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:22 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:22 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:22 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:22 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:22 --> Controller Class Initialized
INFO - 2021-03-31 09:34:22 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:22 --> Total execution time: 0.2897
INFO - 2021-03-31 09:34:22 --> Config Class Initialized
INFO - 2021-03-31 09:34:22 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:22 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:22 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:22 --> URI Class Initialized
INFO - 2021-03-31 09:34:22 --> Router Class Initialized
INFO - 2021-03-31 09:34:22 --> Output Class Initialized
INFO - 2021-03-31 09:34:22 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:22 --> Input Class Initialized
INFO - 2021-03-31 09:34:22 --> Language Class Initialized
INFO - 2021-03-31 09:34:22 --> Language Class Initialized
INFO - 2021-03-31 09:34:22 --> Config Class Initialized
INFO - 2021-03-31 09:34:22 --> Loader Class Initialized
INFO - 2021-03-31 09:34:22 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:22 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:22 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:22 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:22 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:22 --> Controller Class Initialized
INFO - 2021-03-31 09:34:23 --> Config Class Initialized
INFO - 2021-03-31 09:34:23 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:23 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:23 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:23 --> URI Class Initialized
INFO - 2021-03-31 09:34:23 --> Router Class Initialized
INFO - 2021-03-31 09:34:23 --> Output Class Initialized
INFO - 2021-03-31 09:34:23 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:23 --> Input Class Initialized
INFO - 2021-03-31 09:34:23 --> Language Class Initialized
INFO - 2021-03-31 09:34:23 --> Language Class Initialized
INFO - 2021-03-31 09:34:23 --> Config Class Initialized
INFO - 2021-03-31 09:34:23 --> Loader Class Initialized
INFO - 2021-03-31 09:34:23 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:23 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:23 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:23 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:23 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:23 --> Controller Class Initialized
INFO - 2021-03-31 09:34:23 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:23 --> Total execution time: 0.2196
INFO - 2021-03-31 09:34:28 --> Config Class Initialized
INFO - 2021-03-31 09:34:28 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:28 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:28 --> URI Class Initialized
INFO - 2021-03-31 09:34:28 --> Router Class Initialized
INFO - 2021-03-31 09:34:28 --> Output Class Initialized
INFO - 2021-03-31 09:34:28 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:28 --> Input Class Initialized
INFO - 2021-03-31 09:34:28 --> Language Class Initialized
INFO - 2021-03-31 09:34:28 --> Language Class Initialized
INFO - 2021-03-31 09:34:28 --> Config Class Initialized
INFO - 2021-03-31 09:34:28 --> Loader Class Initialized
INFO - 2021-03-31 09:34:28 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:28 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:28 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:28 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:28 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:28 --> Controller Class Initialized
INFO - 2021-03-31 09:34:28 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:28 --> Total execution time: 0.2924
INFO - 2021-03-31 09:34:28 --> Config Class Initialized
INFO - 2021-03-31 09:34:28 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:28 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:28 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:28 --> URI Class Initialized
INFO - 2021-03-31 09:34:28 --> Router Class Initialized
INFO - 2021-03-31 09:34:28 --> Output Class Initialized
INFO - 2021-03-31 09:34:28 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:28 --> Input Class Initialized
INFO - 2021-03-31 09:34:28 --> Language Class Initialized
INFO - 2021-03-31 09:34:28 --> Language Class Initialized
INFO - 2021-03-31 09:34:28 --> Config Class Initialized
INFO - 2021-03-31 09:34:28 --> Loader Class Initialized
INFO - 2021-03-31 09:34:28 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:28 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:28 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:28 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:28 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:28 --> Controller Class Initialized
INFO - 2021-03-31 09:34:29 --> Config Class Initialized
INFO - 2021-03-31 09:34:29 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:29 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:29 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:29 --> URI Class Initialized
INFO - 2021-03-31 09:34:29 --> Router Class Initialized
INFO - 2021-03-31 09:34:29 --> Output Class Initialized
INFO - 2021-03-31 09:34:29 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:29 --> Input Class Initialized
INFO - 2021-03-31 09:34:29 --> Language Class Initialized
INFO - 2021-03-31 09:34:29 --> Language Class Initialized
INFO - 2021-03-31 09:34:29 --> Config Class Initialized
INFO - 2021-03-31 09:34:29 --> Loader Class Initialized
INFO - 2021-03-31 09:34:29 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:29 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:29 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:29 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:29 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:29 --> Controller Class Initialized
INFO - 2021-03-31 09:34:29 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:29 --> Total execution time: 0.2827
INFO - 2021-03-31 09:34:35 --> Config Class Initialized
INFO - 2021-03-31 09:34:35 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:35 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:35 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:35 --> URI Class Initialized
INFO - 2021-03-31 09:34:35 --> Router Class Initialized
INFO - 2021-03-31 09:34:35 --> Output Class Initialized
INFO - 2021-03-31 09:34:35 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:35 --> Input Class Initialized
INFO - 2021-03-31 09:34:35 --> Language Class Initialized
INFO - 2021-03-31 09:34:35 --> Language Class Initialized
INFO - 2021-03-31 09:34:35 --> Config Class Initialized
INFO - 2021-03-31 09:34:35 --> Loader Class Initialized
INFO - 2021-03-31 09:34:36 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:36 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:36 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:36 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:36 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:36 --> Controller Class Initialized
DEBUG - 2021-03-31 09:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:34:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:34:36 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:36 --> Total execution time: 0.3164
INFO - 2021-03-31 09:34:37 --> Config Class Initialized
INFO - 2021-03-31 09:34:37 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:37 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:37 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:37 --> URI Class Initialized
INFO - 2021-03-31 09:34:37 --> Router Class Initialized
INFO - 2021-03-31 09:34:37 --> Output Class Initialized
INFO - 2021-03-31 09:34:37 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:37 --> Input Class Initialized
INFO - 2021-03-31 09:34:37 --> Language Class Initialized
INFO - 2021-03-31 09:34:37 --> Language Class Initialized
INFO - 2021-03-31 09:34:37 --> Config Class Initialized
INFO - 2021-03-31 09:34:37 --> Loader Class Initialized
INFO - 2021-03-31 09:34:37 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:37 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:37 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:37 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:37 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:38 --> Controller Class Initialized
DEBUG - 2021-03-31 09:34:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-03-31 09:34:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:34:38 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:38 --> Total execution time: 0.2744
INFO - 2021-03-31 09:34:42 --> Config Class Initialized
INFO - 2021-03-31 09:34:42 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:42 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:42 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:42 --> URI Class Initialized
INFO - 2021-03-31 09:34:42 --> Router Class Initialized
INFO - 2021-03-31 09:34:42 --> Output Class Initialized
INFO - 2021-03-31 09:34:42 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:42 --> Input Class Initialized
INFO - 2021-03-31 09:34:42 --> Language Class Initialized
INFO - 2021-03-31 09:34:42 --> Language Class Initialized
INFO - 2021-03-31 09:34:42 --> Config Class Initialized
INFO - 2021-03-31 09:34:42 --> Loader Class Initialized
INFO - 2021-03-31 09:34:42 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:42 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:42 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:42 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:42 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:42 --> Controller Class Initialized
INFO - 2021-03-31 09:34:42 --> Config Class Initialized
INFO - 2021-03-31 09:34:42 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:34:42 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:34:42 --> Utf8 Class Initialized
INFO - 2021-03-31 09:34:42 --> URI Class Initialized
INFO - 2021-03-31 09:34:42 --> Router Class Initialized
INFO - 2021-03-31 09:34:42 --> Output Class Initialized
INFO - 2021-03-31 09:34:42 --> Security Class Initialized
DEBUG - 2021-03-31 09:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:34:42 --> Input Class Initialized
INFO - 2021-03-31 09:34:42 --> Language Class Initialized
INFO - 2021-03-31 09:34:42 --> Language Class Initialized
INFO - 2021-03-31 09:34:42 --> Config Class Initialized
INFO - 2021-03-31 09:34:42 --> Loader Class Initialized
INFO - 2021-03-31 09:34:42 --> Helper loaded: url_helper
INFO - 2021-03-31 09:34:42 --> Helper loaded: file_helper
INFO - 2021-03-31 09:34:42 --> Helper loaded: form_helper
INFO - 2021-03-31 09:34:42 --> Helper loaded: my_helper
INFO - 2021-03-31 09:34:42 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:34:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:34:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:34:42 --> Controller Class Initialized
DEBUG - 2021-03-31 09:34:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:34:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:34:42 --> Final output sent to browser
DEBUG - 2021-03-31 09:34:42 --> Total execution time: 0.2426
INFO - 2021-03-31 09:39:17 --> Config Class Initialized
INFO - 2021-03-31 09:39:17 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:39:17 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:39:17 --> Utf8 Class Initialized
INFO - 2021-03-31 09:39:17 --> URI Class Initialized
INFO - 2021-03-31 09:39:17 --> Router Class Initialized
INFO - 2021-03-31 09:39:17 --> Output Class Initialized
INFO - 2021-03-31 09:39:17 --> Security Class Initialized
DEBUG - 2021-03-31 09:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:39:17 --> Input Class Initialized
INFO - 2021-03-31 09:39:17 --> Language Class Initialized
INFO - 2021-03-31 09:39:17 --> Language Class Initialized
INFO - 2021-03-31 09:39:17 --> Config Class Initialized
INFO - 2021-03-31 09:39:17 --> Loader Class Initialized
INFO - 2021-03-31 09:39:17 --> Helper loaded: url_helper
INFO - 2021-03-31 09:39:17 --> Helper loaded: file_helper
INFO - 2021-03-31 09:39:17 --> Helper loaded: form_helper
INFO - 2021-03-31 09:39:17 --> Helper loaded: my_helper
INFO - 2021-03-31 09:39:17 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:39:17 --> Controller Class Initialized
DEBUG - 2021-03-31 09:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:39:17 --> Final output sent to browser
DEBUG - 2021-03-31 09:39:17 --> Total execution time: 0.2768
INFO - 2021-03-31 09:39:18 --> Config Class Initialized
INFO - 2021-03-31 09:39:18 --> Hooks Class Initialized
DEBUG - 2021-03-31 09:39:18 --> UTF-8 Support Enabled
INFO - 2021-03-31 09:39:18 --> Utf8 Class Initialized
INFO - 2021-03-31 09:39:18 --> URI Class Initialized
INFO - 2021-03-31 09:39:18 --> Router Class Initialized
INFO - 2021-03-31 09:39:18 --> Output Class Initialized
INFO - 2021-03-31 09:39:18 --> Security Class Initialized
DEBUG - 2021-03-31 09:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-31 09:39:18 --> Input Class Initialized
INFO - 2021-03-31 09:39:18 --> Language Class Initialized
INFO - 2021-03-31 09:39:18 --> Language Class Initialized
INFO - 2021-03-31 09:39:18 --> Config Class Initialized
INFO - 2021-03-31 09:39:18 --> Loader Class Initialized
INFO - 2021-03-31 09:39:18 --> Helper loaded: url_helper
INFO - 2021-03-31 09:39:18 --> Helper loaded: file_helper
INFO - 2021-03-31 09:39:18 --> Helper loaded: form_helper
INFO - 2021-03-31 09:39:18 --> Helper loaded: my_helper
INFO - 2021-03-31 09:39:18 --> Database Driver Class Initialized
DEBUG - 2021-03-31 09:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-31 09:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-31 09:39:18 --> Controller Class Initialized
DEBUG - 2021-03-31 09:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-03-31 09:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-31 09:39:18 --> Final output sent to browser
DEBUG - 2021-03-31 09:39:18 --> Total execution time: 0.2614
