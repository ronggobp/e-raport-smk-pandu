<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-18 10:06:41 --> Config Class Initialized
INFO - 2022-05-18 10:06:41 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:41 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:41 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:41 --> URI Class Initialized
DEBUG - 2022-05-18 10:06:42 --> No URI present. Default controller set.
INFO - 2022-05-18 10:06:42 --> Router Class Initialized
INFO - 2022-05-18 10:06:42 --> Output Class Initialized
INFO - 2022-05-18 10:06:42 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:42 --> Input Class Initialized
INFO - 2022-05-18 10:06:42 --> Language Class Initialized
INFO - 2022-05-18 10:06:42 --> Language Class Initialized
INFO - 2022-05-18 10:06:42 --> Config Class Initialized
INFO - 2022-05-18 10:06:42 --> Loader Class Initialized
INFO - 2022-05-18 10:06:42 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:42 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:42 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:42 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:42 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:42 --> Controller Class Initialized
INFO - 2022-05-18 10:06:42 --> Config Class Initialized
INFO - 2022-05-18 10:06:42 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:42 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:42 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:42 --> URI Class Initialized
INFO - 2022-05-18 10:06:42 --> Router Class Initialized
INFO - 2022-05-18 10:06:42 --> Output Class Initialized
INFO - 2022-05-18 10:06:42 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:42 --> Input Class Initialized
INFO - 2022-05-18 10:06:42 --> Language Class Initialized
INFO - 2022-05-18 10:06:42 --> Language Class Initialized
INFO - 2022-05-18 10:06:42 --> Config Class Initialized
INFO - 2022-05-18 10:06:42 --> Loader Class Initialized
INFO - 2022-05-18 10:06:42 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:42 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:42 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:42 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:42 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:42 --> Controller Class Initialized
DEBUG - 2022-05-18 10:06:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-18 10:06:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-18 10:06:43 --> Final output sent to browser
DEBUG - 2022-05-18 10:06:43 --> Total execution time: 0.1960
INFO - 2022-05-18 10:06:49 --> Config Class Initialized
INFO - 2022-05-18 10:06:49 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:49 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:49 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:49 --> URI Class Initialized
INFO - 2022-05-18 10:06:49 --> Router Class Initialized
INFO - 2022-05-18 10:06:49 --> Output Class Initialized
INFO - 2022-05-18 10:06:49 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:49 --> Input Class Initialized
INFO - 2022-05-18 10:06:49 --> Language Class Initialized
INFO - 2022-05-18 10:06:49 --> Language Class Initialized
INFO - 2022-05-18 10:06:49 --> Config Class Initialized
INFO - 2022-05-18 10:06:49 --> Loader Class Initialized
INFO - 2022-05-18 10:06:49 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:49 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:49 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:49 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:49 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:49 --> Controller Class Initialized
INFO - 2022-05-18 10:06:49 --> Helper loaded: cookie_helper
INFO - 2022-05-18 10:06:49 --> Final output sent to browser
DEBUG - 2022-05-18 10:06:49 --> Total execution time: 0.1000
INFO - 2022-05-18 10:06:49 --> Config Class Initialized
INFO - 2022-05-18 10:06:49 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:49 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:49 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:49 --> URI Class Initialized
INFO - 2022-05-18 10:06:49 --> Router Class Initialized
INFO - 2022-05-18 10:06:49 --> Output Class Initialized
INFO - 2022-05-18 10:06:49 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:49 --> Input Class Initialized
INFO - 2022-05-18 10:06:49 --> Language Class Initialized
INFO - 2022-05-18 10:06:49 --> Language Class Initialized
INFO - 2022-05-18 10:06:49 --> Config Class Initialized
INFO - 2022-05-18 10:06:49 --> Loader Class Initialized
INFO - 2022-05-18 10:06:49 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:49 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:49 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:49 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:49 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:49 --> Controller Class Initialized
DEBUG - 2022-05-18 10:06:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-18 10:06:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-18 10:06:49 --> Final output sent to browser
DEBUG - 2022-05-18 10:06:49 --> Total execution time: 0.1704
INFO - 2022-05-18 10:06:51 --> Config Class Initialized
INFO - 2022-05-18 10:06:51 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:51 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:51 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:51 --> URI Class Initialized
INFO - 2022-05-18 10:06:51 --> Router Class Initialized
INFO - 2022-05-18 10:06:51 --> Output Class Initialized
INFO - 2022-05-18 10:06:51 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:51 --> Input Class Initialized
INFO - 2022-05-18 10:06:51 --> Language Class Initialized
INFO - 2022-05-18 10:06:51 --> Language Class Initialized
INFO - 2022-05-18 10:06:51 --> Config Class Initialized
INFO - 2022-05-18 10:06:51 --> Loader Class Initialized
INFO - 2022-05-18 10:06:51 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:51 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:51 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:51 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:51 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:51 --> Controller Class Initialized
DEBUG - 2022-05-18 10:06:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2022-05-18 10:06:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-18 10:06:51 --> Final output sent to browser
DEBUG - 2022-05-18 10:06:51 --> Total execution time: 0.1160
INFO - 2022-05-18 10:06:51 --> Config Class Initialized
INFO - 2022-05-18 10:06:51 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:51 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:51 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:51 --> URI Class Initialized
INFO - 2022-05-18 10:06:51 --> Router Class Initialized
INFO - 2022-05-18 10:06:51 --> Output Class Initialized
INFO - 2022-05-18 10:06:51 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:51 --> Input Class Initialized
INFO - 2022-05-18 10:06:51 --> Language Class Initialized
INFO - 2022-05-18 10:06:51 --> Language Class Initialized
INFO - 2022-05-18 10:06:51 --> Config Class Initialized
INFO - 2022-05-18 10:06:51 --> Loader Class Initialized
INFO - 2022-05-18 10:06:51 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:51 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:51 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:51 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:51 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:51 --> Controller Class Initialized
INFO - 2022-05-18 10:06:52 --> Config Class Initialized
INFO - 2022-05-18 10:06:52 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:53 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:53 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:53 --> URI Class Initialized
INFO - 2022-05-18 10:06:53 --> Router Class Initialized
INFO - 2022-05-18 10:06:53 --> Output Class Initialized
INFO - 2022-05-18 10:06:53 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:53 --> Input Class Initialized
INFO - 2022-05-18 10:06:53 --> Language Class Initialized
INFO - 2022-05-18 10:06:53 --> Language Class Initialized
INFO - 2022-05-18 10:06:53 --> Config Class Initialized
INFO - 2022-05-18 10:06:53 --> Loader Class Initialized
INFO - 2022-05-18 10:06:53 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:53 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:53 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:53 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:53 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:53 --> Controller Class Initialized
DEBUG - 2022-05-18 10:06:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-05-18 10:06:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-18 10:06:53 --> Final output sent to browser
DEBUG - 2022-05-18 10:06:53 --> Total execution time: 0.1099
INFO - 2022-05-18 10:06:53 --> Config Class Initialized
INFO - 2022-05-18 10:06:53 --> Hooks Class Initialized
DEBUG - 2022-05-18 10:06:53 --> UTF-8 Support Enabled
INFO - 2022-05-18 10:06:53 --> Utf8 Class Initialized
INFO - 2022-05-18 10:06:53 --> URI Class Initialized
INFO - 2022-05-18 10:06:53 --> Router Class Initialized
INFO - 2022-05-18 10:06:53 --> Output Class Initialized
INFO - 2022-05-18 10:06:53 --> Security Class Initialized
DEBUG - 2022-05-18 10:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-18 10:06:53 --> Input Class Initialized
INFO - 2022-05-18 10:06:53 --> Language Class Initialized
INFO - 2022-05-18 10:06:53 --> Language Class Initialized
INFO - 2022-05-18 10:06:53 --> Config Class Initialized
INFO - 2022-05-18 10:06:53 --> Loader Class Initialized
INFO - 2022-05-18 10:06:53 --> Helper loaded: url_helper
INFO - 2022-05-18 10:06:53 --> Helper loaded: file_helper
INFO - 2022-05-18 10:06:53 --> Helper loaded: form_helper
INFO - 2022-05-18 10:06:53 --> Helper loaded: my_helper
INFO - 2022-05-18 10:06:53 --> Database Driver Class Initialized
DEBUG - 2022-05-18 10:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-18 10:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-18 10:06:53 --> Controller Class Initialized
