<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-06-08 03:42:24 --> Config Class Initialized
INFO - 2021-06-08 03:42:24 --> Hooks Class Initialized
DEBUG - 2021-06-08 03:42:24 --> UTF-8 Support Enabled
INFO - 2021-06-08 03:42:24 --> Utf8 Class Initialized
INFO - 2021-06-08 03:42:24 --> URI Class Initialized
INFO - 2021-06-08 03:42:24 --> Router Class Initialized
INFO - 2021-06-08 03:42:24 --> Output Class Initialized
INFO - 2021-06-08 03:42:24 --> Security Class Initialized
DEBUG - 2021-06-08 03:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 03:42:24 --> Input Class Initialized
INFO - 2021-06-08 03:42:24 --> Language Class Initialized
INFO - 2021-06-08 03:42:24 --> Language Class Initialized
INFO - 2021-06-08 03:42:24 --> Config Class Initialized
INFO - 2021-06-08 03:42:24 --> Loader Class Initialized
INFO - 2021-06-08 03:42:24 --> Helper loaded: url_helper
INFO - 2021-06-08 03:42:24 --> Helper loaded: file_helper
INFO - 2021-06-08 03:42:24 --> Helper loaded: form_helper
INFO - 2021-06-08 03:42:24 --> Helper loaded: my_helper
INFO - 2021-06-08 03:42:24 --> Database Driver Class Initialized
DEBUG - 2021-06-08 03:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 03:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 03:42:24 --> Controller Class Initialized
DEBUG - 2021-06-08 03:42:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-08 03:42:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-08 03:42:24 --> Final output sent to browser
DEBUG - 2021-06-08 03:42:24 --> Total execution time: 0.6827
INFO - 2021-06-08 05:06:54 --> Config Class Initialized
INFO - 2021-06-08 05:06:54 --> Hooks Class Initialized
DEBUG - 2021-06-08 05:06:54 --> UTF-8 Support Enabled
INFO - 2021-06-08 05:06:54 --> Utf8 Class Initialized
INFO - 2021-06-08 05:06:54 --> URI Class Initialized
DEBUG - 2021-06-08 05:06:54 --> No URI present. Default controller set.
INFO - 2021-06-08 05:06:54 --> Router Class Initialized
INFO - 2021-06-08 05:06:54 --> Output Class Initialized
INFO - 2021-06-08 05:06:54 --> Security Class Initialized
DEBUG - 2021-06-08 05:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 05:06:54 --> Input Class Initialized
INFO - 2021-06-08 05:06:54 --> Language Class Initialized
INFO - 2021-06-08 05:06:54 --> Language Class Initialized
INFO - 2021-06-08 05:06:54 --> Config Class Initialized
INFO - 2021-06-08 05:06:54 --> Loader Class Initialized
INFO - 2021-06-08 05:06:54 --> Helper loaded: url_helper
INFO - 2021-06-08 05:06:54 --> Helper loaded: file_helper
INFO - 2021-06-08 05:06:54 --> Helper loaded: form_helper
INFO - 2021-06-08 05:06:54 --> Helper loaded: my_helper
INFO - 2021-06-08 05:06:54 --> Database Driver Class Initialized
DEBUG - 2021-06-08 05:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 05:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 05:06:54 --> Controller Class Initialized
INFO - 2021-06-08 05:06:54 --> Config Class Initialized
INFO - 2021-06-08 05:06:54 --> Hooks Class Initialized
DEBUG - 2021-06-08 05:06:54 --> UTF-8 Support Enabled
INFO - 2021-06-08 05:06:54 --> Utf8 Class Initialized
INFO - 2021-06-08 05:06:54 --> URI Class Initialized
INFO - 2021-06-08 05:06:54 --> Router Class Initialized
INFO - 2021-06-08 05:06:54 --> Output Class Initialized
INFO - 2021-06-08 05:06:54 --> Security Class Initialized
DEBUG - 2021-06-08 05:06:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-06-08 05:06:54 --> Input Class Initialized
INFO - 2021-06-08 05:06:54 --> Language Class Initialized
INFO - 2021-06-08 05:06:54 --> Language Class Initialized
INFO - 2021-06-08 05:06:54 --> Config Class Initialized
INFO - 2021-06-08 05:06:54 --> Loader Class Initialized
INFO - 2021-06-08 05:06:54 --> Helper loaded: url_helper
INFO - 2021-06-08 05:06:54 --> Helper loaded: file_helper
INFO - 2021-06-08 05:06:54 --> Helper loaded: form_helper
INFO - 2021-06-08 05:06:54 --> Helper loaded: my_helper
INFO - 2021-06-08 05:06:54 --> Database Driver Class Initialized
DEBUG - 2021-06-08 05:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-06-08 05:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-06-08 05:06:55 --> Controller Class Initialized
DEBUG - 2021-06-08 05:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-06-08 05:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-06-08 05:06:55 --> Final output sent to browser
DEBUG - 2021-06-08 05:06:55 --> Total execution time: 0.0430
