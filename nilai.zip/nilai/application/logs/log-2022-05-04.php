<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-04 08:42:59 --> Config Class Initialized
INFO - 2022-05-04 08:42:59 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:42:59 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:42:59 --> Utf8 Class Initialized
INFO - 2022-05-04 08:42:59 --> URI Class Initialized
DEBUG - 2022-05-04 08:42:59 --> No URI present. Default controller set.
INFO - 2022-05-04 08:42:59 --> Router Class Initialized
INFO - 2022-05-04 08:42:59 --> Output Class Initialized
INFO - 2022-05-04 08:42:59 --> Security Class Initialized
DEBUG - 2022-05-04 08:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:42:59 --> Input Class Initialized
INFO - 2022-05-04 08:42:59 --> Language Class Initialized
INFO - 2022-05-04 08:43:00 --> Language Class Initialized
INFO - 2022-05-04 08:43:00 --> Config Class Initialized
INFO - 2022-05-04 08:43:00 --> Loader Class Initialized
INFO - 2022-05-04 08:43:00 --> Helper loaded: url_helper
INFO - 2022-05-04 08:43:00 --> Helper loaded: file_helper
INFO - 2022-05-04 08:43:00 --> Helper loaded: form_helper
INFO - 2022-05-04 08:43:00 --> Helper loaded: my_helper
INFO - 2022-05-04 08:43:00 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:43:00 --> Controller Class Initialized
INFO - 2022-05-04 08:43:00 --> Config Class Initialized
INFO - 2022-05-04 08:43:00 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:43:00 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:43:00 --> Utf8 Class Initialized
INFO - 2022-05-04 08:43:00 --> URI Class Initialized
INFO - 2022-05-04 08:43:00 --> Router Class Initialized
INFO - 2022-05-04 08:43:00 --> Output Class Initialized
INFO - 2022-05-04 08:43:00 --> Security Class Initialized
DEBUG - 2022-05-04 08:43:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:43:00 --> Input Class Initialized
INFO - 2022-05-04 08:43:00 --> Language Class Initialized
INFO - 2022-05-04 08:43:00 --> Language Class Initialized
INFO - 2022-05-04 08:43:00 --> Config Class Initialized
INFO - 2022-05-04 08:43:00 --> Loader Class Initialized
INFO - 2022-05-04 08:43:00 --> Helper loaded: url_helper
INFO - 2022-05-04 08:43:00 --> Helper loaded: file_helper
INFO - 2022-05-04 08:43:00 --> Helper loaded: form_helper
INFO - 2022-05-04 08:43:00 --> Helper loaded: my_helper
INFO - 2022-05-04 08:43:00 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:43:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:43:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:43:00 --> Controller Class Initialized
DEBUG - 2022-05-04 08:43:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-04 08:43:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-04 08:43:00 --> Final output sent to browser
DEBUG - 2022-05-04 08:43:00 --> Total execution time: 0.3320
INFO - 2022-05-04 08:43:06 --> Config Class Initialized
INFO - 2022-05-04 08:43:06 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:43:06 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:43:06 --> Utf8 Class Initialized
INFO - 2022-05-04 08:43:06 --> URI Class Initialized
INFO - 2022-05-04 08:43:06 --> Router Class Initialized
INFO - 2022-05-04 08:43:06 --> Output Class Initialized
INFO - 2022-05-04 08:43:06 --> Security Class Initialized
DEBUG - 2022-05-04 08:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:43:06 --> Input Class Initialized
INFO - 2022-05-04 08:43:06 --> Language Class Initialized
INFO - 2022-05-04 08:43:06 --> Language Class Initialized
INFO - 2022-05-04 08:43:06 --> Config Class Initialized
INFO - 2022-05-04 08:43:06 --> Loader Class Initialized
INFO - 2022-05-04 08:43:06 --> Helper loaded: url_helper
INFO - 2022-05-04 08:43:06 --> Helper loaded: file_helper
INFO - 2022-05-04 08:43:06 --> Helper loaded: form_helper
INFO - 2022-05-04 08:43:06 --> Helper loaded: my_helper
INFO - 2022-05-04 08:43:06 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:43:06 --> Controller Class Initialized
INFO - 2022-05-04 08:43:07 --> Helper loaded: cookie_helper
INFO - 2022-05-04 08:43:07 --> Final output sent to browser
DEBUG - 2022-05-04 08:43:07 --> Total execution time: 0.2398
INFO - 2022-05-04 08:43:07 --> Config Class Initialized
INFO - 2022-05-04 08:43:07 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:43:07 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:43:07 --> Utf8 Class Initialized
INFO - 2022-05-04 08:43:07 --> URI Class Initialized
INFO - 2022-05-04 08:43:07 --> Router Class Initialized
INFO - 2022-05-04 08:43:07 --> Output Class Initialized
INFO - 2022-05-04 08:43:07 --> Security Class Initialized
DEBUG - 2022-05-04 08:43:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:43:07 --> Input Class Initialized
INFO - 2022-05-04 08:43:07 --> Language Class Initialized
INFO - 2022-05-04 08:43:07 --> Language Class Initialized
INFO - 2022-05-04 08:43:07 --> Config Class Initialized
INFO - 2022-05-04 08:43:07 --> Loader Class Initialized
INFO - 2022-05-04 08:43:07 --> Helper loaded: url_helper
INFO - 2022-05-04 08:43:07 --> Helper loaded: file_helper
INFO - 2022-05-04 08:43:07 --> Helper loaded: form_helper
INFO - 2022-05-04 08:43:07 --> Helper loaded: my_helper
INFO - 2022-05-04 08:43:07 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:43:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:43:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:43:07 --> Controller Class Initialized
DEBUG - 2022-05-04 08:43:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-04 08:43:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-04 08:43:08 --> Final output sent to browser
DEBUG - 2022-05-04 08:43:08 --> Total execution time: 0.2550
INFO - 2022-05-04 08:43:09 --> Config Class Initialized
INFO - 2022-05-04 08:43:09 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:43:09 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:43:09 --> Utf8 Class Initialized
INFO - 2022-05-04 08:43:09 --> URI Class Initialized
INFO - 2022-05-04 08:43:09 --> Router Class Initialized
INFO - 2022-05-04 08:43:09 --> Output Class Initialized
INFO - 2022-05-04 08:43:09 --> Security Class Initialized
DEBUG - 2022-05-04 08:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:43:09 --> Input Class Initialized
INFO - 2022-05-04 08:43:09 --> Language Class Initialized
INFO - 2022-05-04 08:43:09 --> Language Class Initialized
INFO - 2022-05-04 08:43:09 --> Config Class Initialized
INFO - 2022-05-04 08:43:09 --> Loader Class Initialized
INFO - 2022-05-04 08:43:09 --> Helper loaded: url_helper
INFO - 2022-05-04 08:43:09 --> Helper loaded: file_helper
INFO - 2022-05-04 08:43:09 --> Helper loaded: form_helper
INFO - 2022-05-04 08:43:09 --> Helper loaded: my_helper
INFO - 2022-05-04 08:43:09 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:43:09 --> Controller Class Initialized
DEBUG - 2022-05-04 08:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-05-04 08:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-04 08:43:09 --> Final output sent to browser
DEBUG - 2022-05-04 08:43:09 --> Total execution time: 0.2908
INFO - 2022-05-04 08:43:10 --> Config Class Initialized
INFO - 2022-05-04 08:43:10 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:43:10 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:43:10 --> Utf8 Class Initialized
INFO - 2022-05-04 08:43:10 --> URI Class Initialized
INFO - 2022-05-04 08:43:10 --> Router Class Initialized
INFO - 2022-05-04 08:43:10 --> Output Class Initialized
INFO - 2022-05-04 08:43:10 --> Security Class Initialized
DEBUG - 2022-05-04 08:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:43:10 --> Input Class Initialized
INFO - 2022-05-04 08:43:10 --> Language Class Initialized
INFO - 2022-05-04 08:43:11 --> Language Class Initialized
INFO - 2022-05-04 08:43:11 --> Config Class Initialized
INFO - 2022-05-04 08:43:11 --> Loader Class Initialized
INFO - 2022-05-04 08:43:11 --> Helper loaded: url_helper
INFO - 2022-05-04 08:43:11 --> Helper loaded: file_helper
INFO - 2022-05-04 08:43:11 --> Helper loaded: form_helper
INFO - 2022-05-04 08:43:11 --> Helper loaded: my_helper
INFO - 2022-05-04 08:43:11 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:43:11 --> Controller Class Initialized
DEBUG - 2022-05-04 08:43:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2022-05-04 08:43:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-04 08:43:11 --> Final output sent to browser
DEBUG - 2022-05-04 08:43:11 --> Total execution time: 0.2512
INFO - 2022-05-04 08:51:05 --> Config Class Initialized
INFO - 2022-05-04 08:51:05 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:51:05 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:51:05 --> Utf8 Class Initialized
INFO - 2022-05-04 08:51:05 --> URI Class Initialized
INFO - 2022-05-04 08:51:05 --> Router Class Initialized
INFO - 2022-05-04 08:51:05 --> Output Class Initialized
INFO - 2022-05-04 08:51:05 --> Security Class Initialized
DEBUG - 2022-05-04 08:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:51:05 --> Input Class Initialized
INFO - 2022-05-04 08:51:05 --> Language Class Initialized
INFO - 2022-05-04 08:51:05 --> Language Class Initialized
INFO - 2022-05-04 08:51:05 --> Config Class Initialized
INFO - 2022-05-04 08:51:05 --> Loader Class Initialized
INFO - 2022-05-04 08:51:05 --> Helper loaded: url_helper
INFO - 2022-05-04 08:51:05 --> Helper loaded: file_helper
INFO - 2022-05-04 08:51:05 --> Helper loaded: form_helper
INFO - 2022-05-04 08:51:05 --> Helper loaded: my_helper
INFO - 2022-05-04 08:51:05 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:51:05 --> Controller Class Initialized
DEBUG - 2022-05-04 08:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2022-05-04 08:51:05 --> Final output sent to browser
DEBUG - 2022-05-04 08:51:05 --> Total execution time: 0.2433
INFO - 2022-05-04 08:51:11 --> Config Class Initialized
INFO - 2022-05-04 08:51:11 --> Hooks Class Initialized
DEBUG - 2022-05-04 08:51:11 --> UTF-8 Support Enabled
INFO - 2022-05-04 08:51:11 --> Utf8 Class Initialized
INFO - 2022-05-04 08:51:11 --> URI Class Initialized
INFO - 2022-05-04 08:51:11 --> Router Class Initialized
INFO - 2022-05-04 08:51:11 --> Output Class Initialized
INFO - 2022-05-04 08:51:11 --> Security Class Initialized
DEBUG - 2022-05-04 08:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-04 08:51:11 --> Input Class Initialized
INFO - 2022-05-04 08:51:11 --> Language Class Initialized
INFO - 2022-05-04 08:51:11 --> Language Class Initialized
INFO - 2022-05-04 08:51:11 --> Config Class Initialized
INFO - 2022-05-04 08:51:11 --> Loader Class Initialized
INFO - 2022-05-04 08:51:11 --> Helper loaded: url_helper
INFO - 2022-05-04 08:51:11 --> Helper loaded: file_helper
INFO - 2022-05-04 08:51:11 --> Helper loaded: form_helper
INFO - 2022-05-04 08:51:11 --> Helper loaded: my_helper
INFO - 2022-05-04 08:51:11 --> Database Driver Class Initialized
DEBUG - 2022-05-04 08:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-04 08:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-04 08:51:11 --> Controller Class Initialized
DEBUG - 2022-05-04 08:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2022-05-04 08:51:11 --> Final output sent to browser
DEBUG - 2022-05-04 08:51:11 --> Total execution time: 0.1495
