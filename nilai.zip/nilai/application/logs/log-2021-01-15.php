<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-15 03:00:24 --> Config Class Initialized
INFO - 2021-01-15 03:00:24 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:00:24 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:00:24 --> Utf8 Class Initialized
INFO - 2021-01-15 03:00:24 --> URI Class Initialized
DEBUG - 2021-01-15 03:00:24 --> No URI present. Default controller set.
INFO - 2021-01-15 03:00:25 --> Router Class Initialized
INFO - 2021-01-15 03:00:25 --> Output Class Initialized
INFO - 2021-01-15 03:00:25 --> Security Class Initialized
DEBUG - 2021-01-15 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:00:25 --> Input Class Initialized
INFO - 2021-01-15 03:00:25 --> Language Class Initialized
INFO - 2021-01-15 03:00:25 --> Language Class Initialized
INFO - 2021-01-15 03:00:25 --> Config Class Initialized
INFO - 2021-01-15 03:00:25 --> Loader Class Initialized
INFO - 2021-01-15 03:00:25 --> Helper loaded: url_helper
INFO - 2021-01-15 03:00:25 --> Helper loaded: file_helper
INFO - 2021-01-15 03:00:25 --> Helper loaded: form_helper
INFO - 2021-01-15 03:00:25 --> Helper loaded: my_helper
INFO - 2021-01-15 03:00:25 --> Database Driver Class Initialized
ERROR - 2021-01-15 03:00:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): No connection could be made because the target machine actively refused it.
 C:\xampp\htdocs\nilai\system\database\drivers\mysqli\mysqli_driver.php 202
ERROR - 2021-01-15 03:00:29 --> Unable to connect to the database
INFO - 2021-01-15 03:00:29 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-15 03:00:35 --> Config Class Initialized
INFO - 2021-01-15 03:00:35 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:00:35 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:00:35 --> Utf8 Class Initialized
INFO - 2021-01-15 03:00:35 --> URI Class Initialized
DEBUG - 2021-01-15 03:00:35 --> No URI present. Default controller set.
INFO - 2021-01-15 03:00:35 --> Router Class Initialized
INFO - 2021-01-15 03:00:35 --> Output Class Initialized
INFO - 2021-01-15 03:00:35 --> Security Class Initialized
DEBUG - 2021-01-15 03:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:00:35 --> Input Class Initialized
INFO - 2021-01-15 03:00:35 --> Language Class Initialized
INFO - 2021-01-15 03:00:35 --> Language Class Initialized
INFO - 2021-01-15 03:00:35 --> Config Class Initialized
INFO - 2021-01-15 03:00:35 --> Loader Class Initialized
INFO - 2021-01-15 03:00:35 --> Helper loaded: url_helper
INFO - 2021-01-15 03:00:35 --> Helper loaded: file_helper
INFO - 2021-01-15 03:00:35 --> Helper loaded: form_helper
INFO - 2021-01-15 03:00:35 --> Helper loaded: my_helper
INFO - 2021-01-15 03:00:35 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:00:35 --> Controller Class Initialized
INFO - 2021-01-15 03:00:35 --> Config Class Initialized
INFO - 2021-01-15 03:00:35 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:00:35 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:00:35 --> Utf8 Class Initialized
INFO - 2021-01-15 03:00:35 --> URI Class Initialized
INFO - 2021-01-15 03:00:35 --> Router Class Initialized
INFO - 2021-01-15 03:00:35 --> Output Class Initialized
INFO - 2021-01-15 03:00:35 --> Security Class Initialized
DEBUG - 2021-01-15 03:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:00:35 --> Input Class Initialized
INFO - 2021-01-15 03:00:35 --> Language Class Initialized
INFO - 2021-01-15 03:00:35 --> Language Class Initialized
INFO - 2021-01-15 03:00:35 --> Config Class Initialized
INFO - 2021-01-15 03:00:35 --> Loader Class Initialized
INFO - 2021-01-15 03:00:35 --> Helper loaded: url_helper
INFO - 2021-01-15 03:00:35 --> Helper loaded: file_helper
INFO - 2021-01-15 03:00:35 --> Helper loaded: form_helper
INFO - 2021-01-15 03:00:35 --> Helper loaded: my_helper
INFO - 2021-01-15 03:00:36 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:00:36 --> Controller Class Initialized
DEBUG - 2021-01-15 03:00:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-15 03:00:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 03:00:36 --> Final output sent to browser
DEBUG - 2021-01-15 03:00:36 --> Total execution time: 0.3436
INFO - 2021-01-15 03:00:44 --> Config Class Initialized
INFO - 2021-01-15 03:00:44 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:00:44 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:00:44 --> Utf8 Class Initialized
INFO - 2021-01-15 03:00:44 --> URI Class Initialized
INFO - 2021-01-15 03:00:44 --> Router Class Initialized
INFO - 2021-01-15 03:00:44 --> Output Class Initialized
INFO - 2021-01-15 03:00:44 --> Security Class Initialized
DEBUG - 2021-01-15 03:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:00:44 --> Input Class Initialized
INFO - 2021-01-15 03:00:44 --> Language Class Initialized
INFO - 2021-01-15 03:00:44 --> Language Class Initialized
INFO - 2021-01-15 03:00:44 --> Config Class Initialized
INFO - 2021-01-15 03:00:44 --> Loader Class Initialized
INFO - 2021-01-15 03:00:44 --> Helper loaded: url_helper
INFO - 2021-01-15 03:00:44 --> Helper loaded: file_helper
INFO - 2021-01-15 03:00:44 --> Helper loaded: form_helper
INFO - 2021-01-15 03:00:44 --> Helper loaded: my_helper
INFO - 2021-01-15 03:00:44 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:00:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:00:44 --> Controller Class Initialized
INFO - 2021-01-15 03:00:44 --> Helper loaded: cookie_helper
INFO - 2021-01-15 03:00:44 --> Final output sent to browser
DEBUG - 2021-01-15 03:00:44 --> Total execution time: 0.3529
INFO - 2021-01-15 03:00:45 --> Config Class Initialized
INFO - 2021-01-15 03:00:45 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:00:45 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:00:45 --> Utf8 Class Initialized
INFO - 2021-01-15 03:00:45 --> URI Class Initialized
INFO - 2021-01-15 03:00:45 --> Router Class Initialized
INFO - 2021-01-15 03:00:45 --> Output Class Initialized
INFO - 2021-01-15 03:00:45 --> Security Class Initialized
DEBUG - 2021-01-15 03:00:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:00:45 --> Input Class Initialized
INFO - 2021-01-15 03:00:45 --> Language Class Initialized
INFO - 2021-01-15 03:00:45 --> Language Class Initialized
INFO - 2021-01-15 03:00:45 --> Config Class Initialized
INFO - 2021-01-15 03:00:45 --> Loader Class Initialized
INFO - 2021-01-15 03:00:45 --> Helper loaded: url_helper
INFO - 2021-01-15 03:00:45 --> Helper loaded: file_helper
INFO - 2021-01-15 03:00:45 --> Helper loaded: form_helper
INFO - 2021-01-15 03:00:45 --> Helper loaded: my_helper
INFO - 2021-01-15 03:00:45 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:00:45 --> Controller Class Initialized
DEBUG - 2021-01-15 03:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 03:00:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 03:00:45 --> Final output sent to browser
DEBUG - 2021-01-15 03:00:45 --> Total execution time: 0.4384
INFO - 2021-01-15 03:00:49 --> Config Class Initialized
INFO - 2021-01-15 03:00:49 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:00:49 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:00:49 --> Utf8 Class Initialized
INFO - 2021-01-15 03:00:49 --> URI Class Initialized
INFO - 2021-01-15 03:00:49 --> Router Class Initialized
INFO - 2021-01-15 03:00:49 --> Output Class Initialized
INFO - 2021-01-15 03:00:49 --> Security Class Initialized
DEBUG - 2021-01-15 03:00:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:00:49 --> Input Class Initialized
INFO - 2021-01-15 03:00:49 --> Language Class Initialized
INFO - 2021-01-15 03:00:49 --> Language Class Initialized
INFO - 2021-01-15 03:00:49 --> Config Class Initialized
INFO - 2021-01-15 03:00:49 --> Loader Class Initialized
INFO - 2021-01-15 03:00:49 --> Helper loaded: url_helper
INFO - 2021-01-15 03:00:49 --> Helper loaded: file_helper
INFO - 2021-01-15 03:00:49 --> Helper loaded: form_helper
INFO - 2021-01-15 03:00:49 --> Helper loaded: my_helper
INFO - 2021-01-15 03:00:49 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:00:49 --> Controller Class Initialized
DEBUG - 2021-01-15 03:00:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 03:00:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 03:00:49 --> Final output sent to browser
DEBUG - 2021-01-15 03:00:49 --> Total execution time: 0.2252
INFO - 2021-01-15 03:01:03 --> Config Class Initialized
INFO - 2021-01-15 03:01:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:01:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:01:03 --> Utf8 Class Initialized
INFO - 2021-01-15 03:01:03 --> URI Class Initialized
INFO - 2021-01-15 03:01:03 --> Router Class Initialized
INFO - 2021-01-15 03:01:03 --> Output Class Initialized
INFO - 2021-01-15 03:01:03 --> Security Class Initialized
DEBUG - 2021-01-15 03:01:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:01:04 --> Input Class Initialized
INFO - 2021-01-15 03:01:04 --> Language Class Initialized
INFO - 2021-01-15 03:01:04 --> Language Class Initialized
INFO - 2021-01-15 03:01:04 --> Config Class Initialized
INFO - 2021-01-15 03:01:04 --> Loader Class Initialized
INFO - 2021-01-15 03:01:04 --> Helper loaded: url_helper
INFO - 2021-01-15 03:01:04 --> Helper loaded: file_helper
INFO - 2021-01-15 03:01:04 --> Helper loaded: form_helper
INFO - 2021-01-15 03:01:04 --> Helper loaded: my_helper
INFO - 2021-01-15 03:01:04 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:01:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:01:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:01:04 --> Controller Class Initialized
DEBUG - 2021-01-15 03:01:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-15 03:01:04 --> Final output sent to browser
DEBUG - 2021-01-15 03:01:04 --> Total execution time: 0.8974
INFO - 2021-01-15 03:33:13 --> Config Class Initialized
INFO - 2021-01-15 03:33:13 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:33:13 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:33:13 --> Utf8 Class Initialized
INFO - 2021-01-15 03:33:13 --> URI Class Initialized
INFO - 2021-01-15 03:33:13 --> Router Class Initialized
INFO - 2021-01-15 03:33:13 --> Output Class Initialized
INFO - 2021-01-15 03:33:13 --> Security Class Initialized
DEBUG - 2021-01-15 03:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:33:13 --> Input Class Initialized
INFO - 2021-01-15 03:33:13 --> Language Class Initialized
INFO - 2021-01-15 03:33:13 --> Language Class Initialized
INFO - 2021-01-15 03:33:13 --> Config Class Initialized
INFO - 2021-01-15 03:33:13 --> Loader Class Initialized
INFO - 2021-01-15 03:33:13 --> Helper loaded: url_helper
INFO - 2021-01-15 03:33:13 --> Helper loaded: file_helper
INFO - 2021-01-15 03:33:13 --> Helper loaded: form_helper
INFO - 2021-01-15 03:33:13 --> Helper loaded: my_helper
INFO - 2021-01-15 03:33:13 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:33:13 --> Controller Class Initialized
DEBUG - 2021-01-15 03:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 03:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 03:33:13 --> Final output sent to browser
DEBUG - 2021-01-15 03:33:13 --> Total execution time: 0.3172
INFO - 2021-01-15 03:33:14 --> Config Class Initialized
INFO - 2021-01-15 03:33:14 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:33:14 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:33:14 --> Utf8 Class Initialized
INFO - 2021-01-15 03:33:14 --> URI Class Initialized
INFO - 2021-01-15 03:33:14 --> Router Class Initialized
INFO - 2021-01-15 03:33:14 --> Output Class Initialized
INFO - 2021-01-15 03:33:14 --> Security Class Initialized
DEBUG - 2021-01-15 03:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:33:14 --> Input Class Initialized
INFO - 2021-01-15 03:33:14 --> Language Class Initialized
INFO - 2021-01-15 03:33:14 --> Language Class Initialized
INFO - 2021-01-15 03:33:14 --> Config Class Initialized
INFO - 2021-01-15 03:33:14 --> Loader Class Initialized
INFO - 2021-01-15 03:33:14 --> Helper loaded: url_helper
INFO - 2021-01-15 03:33:14 --> Helper loaded: file_helper
INFO - 2021-01-15 03:33:14 --> Helper loaded: form_helper
INFO - 2021-01-15 03:33:14 --> Helper loaded: my_helper
INFO - 2021-01-15 03:33:14 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:33:14 --> Controller Class Initialized
DEBUG - 2021-01-15 03:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:33:14 --> Final output sent to browser
DEBUG - 2021-01-15 03:33:14 --> Total execution time: 0.2448
INFO - 2021-01-15 03:34:10 --> Config Class Initialized
INFO - 2021-01-15 03:34:10 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:34:10 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:34:10 --> Utf8 Class Initialized
INFO - 2021-01-15 03:34:10 --> URI Class Initialized
INFO - 2021-01-15 03:34:10 --> Router Class Initialized
INFO - 2021-01-15 03:34:10 --> Output Class Initialized
INFO - 2021-01-15 03:34:10 --> Security Class Initialized
DEBUG - 2021-01-15 03:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:34:10 --> Input Class Initialized
INFO - 2021-01-15 03:34:10 --> Language Class Initialized
INFO - 2021-01-15 03:34:10 --> Language Class Initialized
INFO - 2021-01-15 03:34:10 --> Config Class Initialized
INFO - 2021-01-15 03:34:11 --> Loader Class Initialized
INFO - 2021-01-15 03:34:11 --> Helper loaded: url_helper
INFO - 2021-01-15 03:34:11 --> Helper loaded: file_helper
INFO - 2021-01-15 03:34:11 --> Helper loaded: form_helper
INFO - 2021-01-15 03:34:11 --> Helper loaded: my_helper
INFO - 2021-01-15 03:34:11 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:34:11 --> Controller Class Initialized
DEBUG - 2021-01-15 03:34:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:34:11 --> Final output sent to browser
DEBUG - 2021-01-15 03:34:11 --> Total execution time: 0.2334
INFO - 2021-01-15 03:34:14 --> Config Class Initialized
INFO - 2021-01-15 03:34:14 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:34:14 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:34:14 --> Utf8 Class Initialized
INFO - 2021-01-15 03:34:14 --> URI Class Initialized
INFO - 2021-01-15 03:34:14 --> Router Class Initialized
INFO - 2021-01-15 03:34:14 --> Output Class Initialized
INFO - 2021-01-15 03:34:14 --> Security Class Initialized
DEBUG - 2021-01-15 03:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:34:14 --> Input Class Initialized
INFO - 2021-01-15 03:34:14 --> Language Class Initialized
INFO - 2021-01-15 03:34:14 --> Language Class Initialized
INFO - 2021-01-15 03:34:14 --> Config Class Initialized
INFO - 2021-01-15 03:34:14 --> Loader Class Initialized
INFO - 2021-01-15 03:34:14 --> Helper loaded: url_helper
INFO - 2021-01-15 03:34:14 --> Helper loaded: file_helper
INFO - 2021-01-15 03:34:14 --> Helper loaded: form_helper
INFO - 2021-01-15 03:34:14 --> Helper loaded: my_helper
INFO - 2021-01-15 03:34:14 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:34:14 --> Controller Class Initialized
DEBUG - 2021-01-15 03:34:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:34:14 --> Final output sent to browser
DEBUG - 2021-01-15 03:34:14 --> Total execution time: 0.2483
INFO - 2021-01-15 03:39:39 --> Config Class Initialized
INFO - 2021-01-15 03:39:39 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:39:39 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:39:39 --> Utf8 Class Initialized
INFO - 2021-01-15 03:39:39 --> URI Class Initialized
INFO - 2021-01-15 03:39:39 --> Router Class Initialized
INFO - 2021-01-15 03:39:39 --> Output Class Initialized
INFO - 2021-01-15 03:39:39 --> Security Class Initialized
DEBUG - 2021-01-15 03:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:39:39 --> Input Class Initialized
INFO - 2021-01-15 03:39:39 --> Language Class Initialized
INFO - 2021-01-15 03:39:39 --> Language Class Initialized
INFO - 2021-01-15 03:39:39 --> Config Class Initialized
INFO - 2021-01-15 03:39:39 --> Loader Class Initialized
INFO - 2021-01-15 03:39:39 --> Helper loaded: url_helper
INFO - 2021-01-15 03:39:39 --> Helper loaded: file_helper
INFO - 2021-01-15 03:39:39 --> Helper loaded: form_helper
INFO - 2021-01-15 03:39:39 --> Helper loaded: my_helper
INFO - 2021-01-15 03:39:39 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:39:39 --> Controller Class Initialized
DEBUG - 2021-01-15 03:39:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:39:39 --> Final output sent to browser
DEBUG - 2021-01-15 03:39:39 --> Total execution time: 0.2422
INFO - 2021-01-15 03:40:02 --> Config Class Initialized
INFO - 2021-01-15 03:40:02 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:40:02 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:40:02 --> Utf8 Class Initialized
INFO - 2021-01-15 03:40:02 --> URI Class Initialized
INFO - 2021-01-15 03:40:02 --> Router Class Initialized
INFO - 2021-01-15 03:40:02 --> Output Class Initialized
INFO - 2021-01-15 03:40:02 --> Security Class Initialized
DEBUG - 2021-01-15 03:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:40:02 --> Input Class Initialized
INFO - 2021-01-15 03:40:02 --> Language Class Initialized
INFO - 2021-01-15 03:40:02 --> Language Class Initialized
INFO - 2021-01-15 03:40:02 --> Config Class Initialized
INFO - 2021-01-15 03:40:02 --> Loader Class Initialized
INFO - 2021-01-15 03:40:02 --> Helper loaded: url_helper
INFO - 2021-01-15 03:40:02 --> Helper loaded: file_helper
INFO - 2021-01-15 03:40:02 --> Helper loaded: form_helper
INFO - 2021-01-15 03:40:02 --> Helper loaded: my_helper
INFO - 2021-01-15 03:40:02 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:40:02 --> Controller Class Initialized
DEBUG - 2021-01-15 03:40:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:40:02 --> Final output sent to browser
DEBUG - 2021-01-15 03:40:02 --> Total execution time: 0.2600
INFO - 2021-01-15 03:40:36 --> Config Class Initialized
INFO - 2021-01-15 03:40:36 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:40:36 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:40:36 --> Utf8 Class Initialized
INFO - 2021-01-15 03:40:36 --> URI Class Initialized
INFO - 2021-01-15 03:40:36 --> Router Class Initialized
INFO - 2021-01-15 03:40:36 --> Output Class Initialized
INFO - 2021-01-15 03:40:36 --> Security Class Initialized
DEBUG - 2021-01-15 03:40:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:40:36 --> Input Class Initialized
INFO - 2021-01-15 03:40:36 --> Language Class Initialized
INFO - 2021-01-15 03:40:36 --> Language Class Initialized
INFO - 2021-01-15 03:40:36 --> Config Class Initialized
INFO - 2021-01-15 03:40:36 --> Loader Class Initialized
INFO - 2021-01-15 03:40:36 --> Helper loaded: url_helper
INFO - 2021-01-15 03:40:36 --> Helper loaded: file_helper
INFO - 2021-01-15 03:40:36 --> Helper loaded: form_helper
INFO - 2021-01-15 03:40:36 --> Helper loaded: my_helper
INFO - 2021-01-15 03:40:36 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:40:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:40:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:40:36 --> Controller Class Initialized
DEBUG - 2021-01-15 03:40:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:40:36 --> Final output sent to browser
DEBUG - 2021-01-15 03:40:36 --> Total execution time: 0.2244
INFO - 2021-01-15 03:42:01 --> Config Class Initialized
INFO - 2021-01-15 03:42:01 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:42:01 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:42:01 --> Utf8 Class Initialized
INFO - 2021-01-15 03:42:01 --> URI Class Initialized
INFO - 2021-01-15 03:42:01 --> Router Class Initialized
INFO - 2021-01-15 03:42:01 --> Output Class Initialized
INFO - 2021-01-15 03:42:01 --> Security Class Initialized
DEBUG - 2021-01-15 03:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:42:01 --> Input Class Initialized
INFO - 2021-01-15 03:42:01 --> Language Class Initialized
INFO - 2021-01-15 03:42:01 --> Language Class Initialized
INFO - 2021-01-15 03:42:01 --> Config Class Initialized
INFO - 2021-01-15 03:42:01 --> Loader Class Initialized
INFO - 2021-01-15 03:42:01 --> Helper loaded: url_helper
INFO - 2021-01-15 03:42:01 --> Helper loaded: file_helper
INFO - 2021-01-15 03:42:01 --> Helper loaded: form_helper
INFO - 2021-01-15 03:42:01 --> Helper loaded: my_helper
INFO - 2021-01-15 03:42:01 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:42:01 --> Controller Class Initialized
DEBUG - 2021-01-15 03:42:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:42:01 --> Final output sent to browser
DEBUG - 2021-01-15 03:42:01 --> Total execution time: 0.2240
INFO - 2021-01-15 03:42:41 --> Config Class Initialized
INFO - 2021-01-15 03:42:41 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:42:41 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:42:41 --> Utf8 Class Initialized
INFO - 2021-01-15 03:42:41 --> URI Class Initialized
INFO - 2021-01-15 03:42:41 --> Router Class Initialized
INFO - 2021-01-15 03:42:41 --> Output Class Initialized
INFO - 2021-01-15 03:42:41 --> Security Class Initialized
DEBUG - 2021-01-15 03:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:42:41 --> Input Class Initialized
INFO - 2021-01-15 03:42:41 --> Language Class Initialized
INFO - 2021-01-15 03:42:41 --> Language Class Initialized
INFO - 2021-01-15 03:42:41 --> Config Class Initialized
INFO - 2021-01-15 03:42:41 --> Loader Class Initialized
INFO - 2021-01-15 03:42:41 --> Helper loaded: url_helper
INFO - 2021-01-15 03:42:41 --> Helper loaded: file_helper
INFO - 2021-01-15 03:42:41 --> Helper loaded: form_helper
INFO - 2021-01-15 03:42:41 --> Helper loaded: my_helper
INFO - 2021-01-15 03:42:41 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:42:41 --> Controller Class Initialized
DEBUG - 2021-01-15 03:42:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:42:41 --> Final output sent to browser
DEBUG - 2021-01-15 03:42:41 --> Total execution time: 0.2275
INFO - 2021-01-15 03:43:46 --> Config Class Initialized
INFO - 2021-01-15 03:43:46 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:43:46 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:43:46 --> Utf8 Class Initialized
INFO - 2021-01-15 03:43:46 --> URI Class Initialized
INFO - 2021-01-15 03:43:46 --> Router Class Initialized
INFO - 2021-01-15 03:43:46 --> Output Class Initialized
INFO - 2021-01-15 03:43:46 --> Security Class Initialized
DEBUG - 2021-01-15 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:43:46 --> Input Class Initialized
INFO - 2021-01-15 03:43:46 --> Language Class Initialized
INFO - 2021-01-15 03:43:46 --> Language Class Initialized
INFO - 2021-01-15 03:43:46 --> Config Class Initialized
INFO - 2021-01-15 03:43:46 --> Loader Class Initialized
INFO - 2021-01-15 03:43:46 --> Helper loaded: url_helper
INFO - 2021-01-15 03:43:46 --> Helper loaded: file_helper
INFO - 2021-01-15 03:43:46 --> Helper loaded: form_helper
INFO - 2021-01-15 03:43:46 --> Helper loaded: my_helper
INFO - 2021-01-15 03:43:46 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:43:46 --> Controller Class Initialized
DEBUG - 2021-01-15 03:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:43:46 --> Final output sent to browser
DEBUG - 2021-01-15 03:43:46 --> Total execution time: 0.2235
INFO - 2021-01-15 03:43:47 --> Config Class Initialized
INFO - 2021-01-15 03:43:47 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:43:47 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:43:47 --> Utf8 Class Initialized
INFO - 2021-01-15 03:43:47 --> URI Class Initialized
INFO - 2021-01-15 03:43:47 --> Router Class Initialized
INFO - 2021-01-15 03:43:47 --> Output Class Initialized
INFO - 2021-01-15 03:43:47 --> Security Class Initialized
DEBUG - 2021-01-15 03:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:43:47 --> Input Class Initialized
INFO - 2021-01-15 03:43:47 --> Language Class Initialized
INFO - 2021-01-15 03:43:47 --> Language Class Initialized
INFO - 2021-01-15 03:43:47 --> Config Class Initialized
INFO - 2021-01-15 03:43:47 --> Loader Class Initialized
INFO - 2021-01-15 03:43:47 --> Helper loaded: url_helper
INFO - 2021-01-15 03:43:47 --> Helper loaded: file_helper
INFO - 2021-01-15 03:43:47 --> Helper loaded: form_helper
INFO - 2021-01-15 03:43:47 --> Helper loaded: my_helper
INFO - 2021-01-15 03:43:47 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:43:47 --> Controller Class Initialized
DEBUG - 2021-01-15 03:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:43:47 --> Final output sent to browser
DEBUG - 2021-01-15 03:43:47 --> Total execution time: 0.2161
INFO - 2021-01-15 03:44:18 --> Config Class Initialized
INFO - 2021-01-15 03:44:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:44:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:44:18 --> Utf8 Class Initialized
INFO - 2021-01-15 03:44:18 --> URI Class Initialized
INFO - 2021-01-15 03:44:18 --> Router Class Initialized
INFO - 2021-01-15 03:44:18 --> Output Class Initialized
INFO - 2021-01-15 03:44:18 --> Security Class Initialized
DEBUG - 2021-01-15 03:44:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:44:18 --> Input Class Initialized
INFO - 2021-01-15 03:44:18 --> Language Class Initialized
INFO - 2021-01-15 03:44:18 --> Language Class Initialized
INFO - 2021-01-15 03:44:18 --> Config Class Initialized
INFO - 2021-01-15 03:44:18 --> Loader Class Initialized
INFO - 2021-01-15 03:44:18 --> Helper loaded: url_helper
INFO - 2021-01-15 03:44:18 --> Helper loaded: file_helper
INFO - 2021-01-15 03:44:18 --> Helper loaded: form_helper
INFO - 2021-01-15 03:44:18 --> Helper loaded: my_helper
INFO - 2021-01-15 03:44:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:44:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:44:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:44:18 --> Controller Class Initialized
DEBUG - 2021-01-15 03:44:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:44:18 --> Final output sent to browser
DEBUG - 2021-01-15 03:44:18 --> Total execution time: 0.2341
INFO - 2021-01-15 03:44:29 --> Config Class Initialized
INFO - 2021-01-15 03:44:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:44:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:44:29 --> Utf8 Class Initialized
INFO - 2021-01-15 03:44:29 --> URI Class Initialized
INFO - 2021-01-15 03:44:29 --> Router Class Initialized
INFO - 2021-01-15 03:44:29 --> Output Class Initialized
INFO - 2021-01-15 03:44:29 --> Security Class Initialized
DEBUG - 2021-01-15 03:44:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:44:29 --> Input Class Initialized
INFO - 2021-01-15 03:44:29 --> Language Class Initialized
INFO - 2021-01-15 03:44:29 --> Language Class Initialized
INFO - 2021-01-15 03:44:29 --> Config Class Initialized
INFO - 2021-01-15 03:44:29 --> Loader Class Initialized
INFO - 2021-01-15 03:44:29 --> Helper loaded: url_helper
INFO - 2021-01-15 03:44:29 --> Helper loaded: file_helper
INFO - 2021-01-15 03:44:29 --> Helper loaded: form_helper
INFO - 2021-01-15 03:44:29 --> Helper loaded: my_helper
INFO - 2021-01-15 03:44:29 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:44:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:44:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:44:29 --> Controller Class Initialized
DEBUG - 2021-01-15 03:44:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:44:29 --> Final output sent to browser
DEBUG - 2021-01-15 03:44:29 --> Total execution time: 0.2594
INFO - 2021-01-15 03:47:09 --> Config Class Initialized
INFO - 2021-01-15 03:47:09 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:47:09 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:47:09 --> Utf8 Class Initialized
INFO - 2021-01-15 03:47:09 --> URI Class Initialized
INFO - 2021-01-15 03:47:09 --> Router Class Initialized
INFO - 2021-01-15 03:47:09 --> Output Class Initialized
INFO - 2021-01-15 03:47:09 --> Security Class Initialized
DEBUG - 2021-01-15 03:47:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:47:09 --> Input Class Initialized
INFO - 2021-01-15 03:47:09 --> Language Class Initialized
INFO - 2021-01-15 03:47:09 --> Language Class Initialized
INFO - 2021-01-15 03:47:09 --> Config Class Initialized
INFO - 2021-01-15 03:47:09 --> Loader Class Initialized
INFO - 2021-01-15 03:47:09 --> Helper loaded: url_helper
INFO - 2021-01-15 03:47:09 --> Helper loaded: file_helper
INFO - 2021-01-15 03:47:09 --> Helper loaded: form_helper
INFO - 2021-01-15 03:47:09 --> Helper loaded: my_helper
INFO - 2021-01-15 03:47:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:47:09 --> Controller Class Initialized
DEBUG - 2021-01-15 03:47:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:47:09 --> Final output sent to browser
DEBUG - 2021-01-15 03:47:09 --> Total execution time: 0.2463
INFO - 2021-01-15 03:47:23 --> Config Class Initialized
INFO - 2021-01-15 03:47:23 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:47:23 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:47:23 --> Utf8 Class Initialized
INFO - 2021-01-15 03:47:23 --> URI Class Initialized
INFO - 2021-01-15 03:47:23 --> Router Class Initialized
INFO - 2021-01-15 03:47:23 --> Output Class Initialized
INFO - 2021-01-15 03:47:23 --> Security Class Initialized
DEBUG - 2021-01-15 03:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:47:23 --> Input Class Initialized
INFO - 2021-01-15 03:47:23 --> Language Class Initialized
INFO - 2021-01-15 03:47:23 --> Language Class Initialized
INFO - 2021-01-15 03:47:23 --> Config Class Initialized
INFO - 2021-01-15 03:47:23 --> Loader Class Initialized
INFO - 2021-01-15 03:47:23 --> Helper loaded: url_helper
INFO - 2021-01-15 03:47:23 --> Helper loaded: file_helper
INFO - 2021-01-15 03:47:23 --> Helper loaded: form_helper
INFO - 2021-01-15 03:47:23 --> Helper loaded: my_helper
INFO - 2021-01-15 03:47:23 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:47:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:47:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:47:23 --> Controller Class Initialized
DEBUG - 2021-01-15 03:47:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:47:23 --> Final output sent to browser
DEBUG - 2021-01-15 03:47:23 --> Total execution time: 0.2613
INFO - 2021-01-15 03:47:31 --> Config Class Initialized
INFO - 2021-01-15 03:47:31 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:47:31 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:47:31 --> Utf8 Class Initialized
INFO - 2021-01-15 03:47:31 --> URI Class Initialized
INFO - 2021-01-15 03:47:31 --> Router Class Initialized
INFO - 2021-01-15 03:47:31 --> Output Class Initialized
INFO - 2021-01-15 03:47:31 --> Security Class Initialized
DEBUG - 2021-01-15 03:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:47:31 --> Input Class Initialized
INFO - 2021-01-15 03:47:31 --> Language Class Initialized
INFO - 2021-01-15 03:47:31 --> Language Class Initialized
INFO - 2021-01-15 03:47:31 --> Config Class Initialized
INFO - 2021-01-15 03:47:31 --> Loader Class Initialized
INFO - 2021-01-15 03:47:31 --> Helper loaded: url_helper
INFO - 2021-01-15 03:47:31 --> Helper loaded: file_helper
INFO - 2021-01-15 03:47:31 --> Helper loaded: form_helper
INFO - 2021-01-15 03:47:31 --> Helper loaded: my_helper
INFO - 2021-01-15 03:47:31 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:47:31 --> Controller Class Initialized
DEBUG - 2021-01-15 03:47:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:47:31 --> Final output sent to browser
DEBUG - 2021-01-15 03:47:31 --> Total execution time: 0.2423
INFO - 2021-01-15 03:47:51 --> Config Class Initialized
INFO - 2021-01-15 03:47:51 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:47:51 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:47:51 --> Utf8 Class Initialized
INFO - 2021-01-15 03:47:51 --> URI Class Initialized
INFO - 2021-01-15 03:47:51 --> Router Class Initialized
INFO - 2021-01-15 03:47:51 --> Output Class Initialized
INFO - 2021-01-15 03:47:51 --> Security Class Initialized
DEBUG - 2021-01-15 03:47:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:47:51 --> Input Class Initialized
INFO - 2021-01-15 03:47:51 --> Language Class Initialized
INFO - 2021-01-15 03:47:51 --> Language Class Initialized
INFO - 2021-01-15 03:47:51 --> Config Class Initialized
INFO - 2021-01-15 03:47:51 --> Loader Class Initialized
INFO - 2021-01-15 03:47:51 --> Helper loaded: url_helper
INFO - 2021-01-15 03:47:51 --> Helper loaded: file_helper
INFO - 2021-01-15 03:47:51 --> Helper loaded: form_helper
INFO - 2021-01-15 03:47:51 --> Helper loaded: my_helper
INFO - 2021-01-15 03:47:51 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:47:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:47:52 --> Controller Class Initialized
DEBUG - 2021-01-15 03:47:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:47:52 --> Final output sent to browser
DEBUG - 2021-01-15 03:47:52 --> Total execution time: 0.2424
INFO - 2021-01-15 03:48:15 --> Config Class Initialized
INFO - 2021-01-15 03:48:15 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:48:15 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:48:15 --> Utf8 Class Initialized
INFO - 2021-01-15 03:48:15 --> URI Class Initialized
INFO - 2021-01-15 03:48:15 --> Router Class Initialized
INFO - 2021-01-15 03:48:15 --> Output Class Initialized
INFO - 2021-01-15 03:48:15 --> Security Class Initialized
DEBUG - 2021-01-15 03:48:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:48:15 --> Input Class Initialized
INFO - 2021-01-15 03:48:15 --> Language Class Initialized
INFO - 2021-01-15 03:48:15 --> Language Class Initialized
INFO - 2021-01-15 03:48:15 --> Config Class Initialized
INFO - 2021-01-15 03:48:15 --> Loader Class Initialized
INFO - 2021-01-15 03:48:15 --> Helper loaded: url_helper
INFO - 2021-01-15 03:48:15 --> Helper loaded: file_helper
INFO - 2021-01-15 03:48:15 --> Helper loaded: form_helper
INFO - 2021-01-15 03:48:15 --> Helper loaded: my_helper
INFO - 2021-01-15 03:48:15 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:48:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:48:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:48:15 --> Controller Class Initialized
DEBUG - 2021-01-15 03:48:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:48:15 --> Final output sent to browser
DEBUG - 2021-01-15 03:48:15 --> Total execution time: 0.2228
INFO - 2021-01-15 03:48:23 --> Config Class Initialized
INFO - 2021-01-15 03:48:23 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:48:23 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:48:23 --> Utf8 Class Initialized
INFO - 2021-01-15 03:48:23 --> URI Class Initialized
INFO - 2021-01-15 03:48:23 --> Router Class Initialized
INFO - 2021-01-15 03:48:23 --> Output Class Initialized
INFO - 2021-01-15 03:48:23 --> Security Class Initialized
DEBUG - 2021-01-15 03:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:48:23 --> Input Class Initialized
INFO - 2021-01-15 03:48:23 --> Language Class Initialized
INFO - 2021-01-15 03:48:23 --> Language Class Initialized
INFO - 2021-01-15 03:48:23 --> Config Class Initialized
INFO - 2021-01-15 03:48:23 --> Loader Class Initialized
INFO - 2021-01-15 03:48:23 --> Helper loaded: url_helper
INFO - 2021-01-15 03:48:23 --> Helper loaded: file_helper
INFO - 2021-01-15 03:48:23 --> Helper loaded: form_helper
INFO - 2021-01-15 03:48:23 --> Helper loaded: my_helper
INFO - 2021-01-15 03:48:23 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:48:23 --> Controller Class Initialized
DEBUG - 2021-01-15 03:48:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:48:23 --> Final output sent to browser
DEBUG - 2021-01-15 03:48:23 --> Total execution time: 0.2374
INFO - 2021-01-15 03:48:43 --> Config Class Initialized
INFO - 2021-01-15 03:48:43 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:48:43 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:48:43 --> Utf8 Class Initialized
INFO - 2021-01-15 03:48:43 --> URI Class Initialized
INFO - 2021-01-15 03:48:43 --> Router Class Initialized
INFO - 2021-01-15 03:48:43 --> Output Class Initialized
INFO - 2021-01-15 03:48:43 --> Security Class Initialized
DEBUG - 2021-01-15 03:48:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:48:43 --> Input Class Initialized
INFO - 2021-01-15 03:48:43 --> Language Class Initialized
INFO - 2021-01-15 03:48:43 --> Language Class Initialized
INFO - 2021-01-15 03:48:43 --> Config Class Initialized
INFO - 2021-01-15 03:48:43 --> Loader Class Initialized
INFO - 2021-01-15 03:48:43 --> Helper loaded: url_helper
INFO - 2021-01-15 03:48:43 --> Helper loaded: file_helper
INFO - 2021-01-15 03:48:43 --> Helper loaded: form_helper
INFO - 2021-01-15 03:48:43 --> Helper loaded: my_helper
INFO - 2021-01-15 03:48:43 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:48:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:48:43 --> Controller Class Initialized
DEBUG - 2021-01-15 03:48:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:48:43 --> Final output sent to browser
DEBUG - 2021-01-15 03:48:43 --> Total execution time: 0.2695
INFO - 2021-01-15 03:48:51 --> Config Class Initialized
INFO - 2021-01-15 03:48:51 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:48:51 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:48:51 --> Utf8 Class Initialized
INFO - 2021-01-15 03:48:51 --> URI Class Initialized
INFO - 2021-01-15 03:48:51 --> Router Class Initialized
INFO - 2021-01-15 03:48:51 --> Output Class Initialized
INFO - 2021-01-15 03:48:51 --> Security Class Initialized
DEBUG - 2021-01-15 03:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:48:51 --> Input Class Initialized
INFO - 2021-01-15 03:48:51 --> Language Class Initialized
INFO - 2021-01-15 03:48:51 --> Language Class Initialized
INFO - 2021-01-15 03:48:51 --> Config Class Initialized
INFO - 2021-01-15 03:48:51 --> Loader Class Initialized
INFO - 2021-01-15 03:48:51 --> Helper loaded: url_helper
INFO - 2021-01-15 03:48:51 --> Helper loaded: file_helper
INFO - 2021-01-15 03:48:51 --> Helper loaded: form_helper
INFO - 2021-01-15 03:48:51 --> Helper loaded: my_helper
INFO - 2021-01-15 03:48:51 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:48:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:48:52 --> Controller Class Initialized
DEBUG - 2021-01-15 03:48:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:48:52 --> Final output sent to browser
DEBUG - 2021-01-15 03:48:52 --> Total execution time: 0.2497
INFO - 2021-01-15 03:49:07 --> Config Class Initialized
INFO - 2021-01-15 03:49:07 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:49:07 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:49:07 --> Utf8 Class Initialized
INFO - 2021-01-15 03:49:07 --> URI Class Initialized
INFO - 2021-01-15 03:49:07 --> Router Class Initialized
INFO - 2021-01-15 03:49:07 --> Output Class Initialized
INFO - 2021-01-15 03:49:07 --> Security Class Initialized
DEBUG - 2021-01-15 03:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:49:07 --> Input Class Initialized
INFO - 2021-01-15 03:49:07 --> Language Class Initialized
INFO - 2021-01-15 03:49:07 --> Language Class Initialized
INFO - 2021-01-15 03:49:07 --> Config Class Initialized
INFO - 2021-01-15 03:49:07 --> Loader Class Initialized
INFO - 2021-01-15 03:49:07 --> Helper loaded: url_helper
INFO - 2021-01-15 03:49:07 --> Helper loaded: file_helper
INFO - 2021-01-15 03:49:07 --> Helper loaded: form_helper
INFO - 2021-01-15 03:49:07 --> Helper loaded: my_helper
INFO - 2021-01-15 03:49:07 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:49:07 --> Controller Class Initialized
DEBUG - 2021-01-15 03:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:49:07 --> Final output sent to browser
DEBUG - 2021-01-15 03:49:07 --> Total execution time: 0.2474
INFO - 2021-01-15 03:51:53 --> Config Class Initialized
INFO - 2021-01-15 03:51:53 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:51:53 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:51:53 --> Utf8 Class Initialized
INFO - 2021-01-15 03:51:53 --> URI Class Initialized
INFO - 2021-01-15 03:51:53 --> Router Class Initialized
INFO - 2021-01-15 03:51:53 --> Output Class Initialized
INFO - 2021-01-15 03:51:53 --> Security Class Initialized
DEBUG - 2021-01-15 03:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:51:53 --> Input Class Initialized
INFO - 2021-01-15 03:51:53 --> Language Class Initialized
INFO - 2021-01-15 03:51:53 --> Language Class Initialized
INFO - 2021-01-15 03:51:53 --> Config Class Initialized
INFO - 2021-01-15 03:51:53 --> Loader Class Initialized
INFO - 2021-01-15 03:51:53 --> Helper loaded: url_helper
INFO - 2021-01-15 03:51:53 --> Helper loaded: file_helper
INFO - 2021-01-15 03:51:53 --> Helper loaded: form_helper
INFO - 2021-01-15 03:51:53 --> Helper loaded: my_helper
INFO - 2021-01-15 03:51:53 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:51:53 --> Controller Class Initialized
DEBUG - 2021-01-15 03:51:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:51:53 --> Final output sent to browser
DEBUG - 2021-01-15 03:51:53 --> Total execution time: 0.2220
INFO - 2021-01-15 03:52:58 --> Config Class Initialized
INFO - 2021-01-15 03:52:58 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:52:58 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:52:58 --> Utf8 Class Initialized
INFO - 2021-01-15 03:52:58 --> URI Class Initialized
INFO - 2021-01-15 03:52:58 --> Router Class Initialized
INFO - 2021-01-15 03:52:58 --> Output Class Initialized
INFO - 2021-01-15 03:52:58 --> Security Class Initialized
DEBUG - 2021-01-15 03:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:52:58 --> Input Class Initialized
INFO - 2021-01-15 03:52:58 --> Language Class Initialized
INFO - 2021-01-15 03:52:58 --> Language Class Initialized
INFO - 2021-01-15 03:52:58 --> Config Class Initialized
INFO - 2021-01-15 03:52:58 --> Loader Class Initialized
INFO - 2021-01-15 03:52:58 --> Helper loaded: url_helper
INFO - 2021-01-15 03:52:58 --> Helper loaded: file_helper
INFO - 2021-01-15 03:52:58 --> Helper loaded: form_helper
INFO - 2021-01-15 03:52:58 --> Helper loaded: my_helper
INFO - 2021-01-15 03:52:58 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:52:58 --> Controller Class Initialized
DEBUG - 2021-01-15 03:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:52:58 --> Final output sent to browser
DEBUG - 2021-01-15 03:52:58 --> Total execution time: 0.2596
INFO - 2021-01-15 03:53:29 --> Config Class Initialized
INFO - 2021-01-15 03:53:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:53:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:53:29 --> Utf8 Class Initialized
INFO - 2021-01-15 03:53:29 --> URI Class Initialized
INFO - 2021-01-15 03:53:29 --> Router Class Initialized
INFO - 2021-01-15 03:53:29 --> Output Class Initialized
INFO - 2021-01-15 03:53:29 --> Security Class Initialized
DEBUG - 2021-01-15 03:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:53:29 --> Input Class Initialized
INFO - 2021-01-15 03:53:29 --> Language Class Initialized
INFO - 2021-01-15 03:53:29 --> Language Class Initialized
INFO - 2021-01-15 03:53:29 --> Config Class Initialized
INFO - 2021-01-15 03:53:29 --> Loader Class Initialized
INFO - 2021-01-15 03:53:29 --> Helper loaded: url_helper
INFO - 2021-01-15 03:53:29 --> Helper loaded: file_helper
INFO - 2021-01-15 03:53:29 --> Helper loaded: form_helper
INFO - 2021-01-15 03:53:29 --> Helper loaded: my_helper
INFO - 2021-01-15 03:53:29 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:53:30 --> Controller Class Initialized
DEBUG - 2021-01-15 03:53:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:53:30 --> Final output sent to browser
DEBUG - 2021-01-15 03:53:30 --> Total execution time: 0.2426
INFO - 2021-01-15 03:53:48 --> Config Class Initialized
INFO - 2021-01-15 03:53:48 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:53:48 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:53:48 --> Utf8 Class Initialized
INFO - 2021-01-15 03:53:48 --> URI Class Initialized
INFO - 2021-01-15 03:53:48 --> Router Class Initialized
INFO - 2021-01-15 03:53:48 --> Output Class Initialized
INFO - 2021-01-15 03:53:48 --> Security Class Initialized
DEBUG - 2021-01-15 03:53:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:53:48 --> Input Class Initialized
INFO - 2021-01-15 03:53:48 --> Language Class Initialized
INFO - 2021-01-15 03:53:48 --> Language Class Initialized
INFO - 2021-01-15 03:53:48 --> Config Class Initialized
INFO - 2021-01-15 03:53:48 --> Loader Class Initialized
INFO - 2021-01-15 03:53:48 --> Helper loaded: url_helper
INFO - 2021-01-15 03:53:48 --> Helper loaded: file_helper
INFO - 2021-01-15 03:53:48 --> Helper loaded: form_helper
INFO - 2021-01-15 03:53:48 --> Helper loaded: my_helper
INFO - 2021-01-15 03:53:48 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:53:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:53:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:53:49 --> Controller Class Initialized
DEBUG - 2021-01-15 03:53:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:53:49 --> Final output sent to browser
DEBUG - 2021-01-15 03:53:49 --> Total execution time: 0.2411
INFO - 2021-01-15 03:53:58 --> Config Class Initialized
INFO - 2021-01-15 03:53:58 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:53:58 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:53:58 --> Utf8 Class Initialized
INFO - 2021-01-15 03:53:58 --> URI Class Initialized
INFO - 2021-01-15 03:53:58 --> Router Class Initialized
INFO - 2021-01-15 03:53:58 --> Output Class Initialized
INFO - 2021-01-15 03:53:58 --> Security Class Initialized
DEBUG - 2021-01-15 03:53:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:53:58 --> Input Class Initialized
INFO - 2021-01-15 03:53:58 --> Language Class Initialized
INFO - 2021-01-15 03:53:58 --> Language Class Initialized
INFO - 2021-01-15 03:53:58 --> Config Class Initialized
INFO - 2021-01-15 03:53:58 --> Loader Class Initialized
INFO - 2021-01-15 03:53:58 --> Helper loaded: url_helper
INFO - 2021-01-15 03:53:58 --> Helper loaded: file_helper
INFO - 2021-01-15 03:53:58 --> Helper loaded: form_helper
INFO - 2021-01-15 03:53:58 --> Helper loaded: my_helper
INFO - 2021-01-15 03:53:58 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:53:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:53:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:53:58 --> Controller Class Initialized
DEBUG - 2021-01-15 03:53:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:53:58 --> Final output sent to browser
DEBUG - 2021-01-15 03:53:58 --> Total execution time: 0.2412
INFO - 2021-01-15 03:54:25 --> Config Class Initialized
INFO - 2021-01-15 03:54:25 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:54:25 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:54:25 --> Utf8 Class Initialized
INFO - 2021-01-15 03:54:25 --> URI Class Initialized
INFO - 2021-01-15 03:54:25 --> Router Class Initialized
INFO - 2021-01-15 03:54:25 --> Output Class Initialized
INFO - 2021-01-15 03:54:25 --> Security Class Initialized
DEBUG - 2021-01-15 03:54:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:54:25 --> Input Class Initialized
INFO - 2021-01-15 03:54:25 --> Language Class Initialized
INFO - 2021-01-15 03:54:25 --> Language Class Initialized
INFO - 2021-01-15 03:54:25 --> Config Class Initialized
INFO - 2021-01-15 03:54:25 --> Loader Class Initialized
INFO - 2021-01-15 03:54:25 --> Helper loaded: url_helper
INFO - 2021-01-15 03:54:25 --> Helper loaded: file_helper
INFO - 2021-01-15 03:54:25 --> Helper loaded: form_helper
INFO - 2021-01-15 03:54:25 --> Helper loaded: my_helper
INFO - 2021-01-15 03:54:25 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:54:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:54:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:54:25 --> Controller Class Initialized
DEBUG - 2021-01-15 03:54:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:54:25 --> Final output sent to browser
DEBUG - 2021-01-15 03:54:25 --> Total execution time: 0.2390
INFO - 2021-01-15 03:54:42 --> Config Class Initialized
INFO - 2021-01-15 03:54:42 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:54:42 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:54:42 --> Utf8 Class Initialized
INFO - 2021-01-15 03:54:42 --> URI Class Initialized
INFO - 2021-01-15 03:54:42 --> Router Class Initialized
INFO - 2021-01-15 03:54:42 --> Output Class Initialized
INFO - 2021-01-15 03:54:42 --> Security Class Initialized
DEBUG - 2021-01-15 03:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:54:42 --> Input Class Initialized
INFO - 2021-01-15 03:54:42 --> Language Class Initialized
INFO - 2021-01-15 03:54:42 --> Language Class Initialized
INFO - 2021-01-15 03:54:42 --> Config Class Initialized
INFO - 2021-01-15 03:54:42 --> Loader Class Initialized
INFO - 2021-01-15 03:54:42 --> Helper loaded: url_helper
INFO - 2021-01-15 03:54:42 --> Helper loaded: file_helper
INFO - 2021-01-15 03:54:42 --> Helper loaded: form_helper
INFO - 2021-01-15 03:54:42 --> Helper loaded: my_helper
INFO - 2021-01-15 03:54:42 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:54:42 --> Controller Class Initialized
DEBUG - 2021-01-15 03:54:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:54:43 --> Final output sent to browser
DEBUG - 2021-01-15 03:54:43 --> Total execution time: 0.2278
INFO - 2021-01-15 03:57:20 --> Config Class Initialized
INFO - 2021-01-15 03:57:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:57:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:57:20 --> Utf8 Class Initialized
INFO - 2021-01-15 03:57:20 --> URI Class Initialized
INFO - 2021-01-15 03:57:20 --> Router Class Initialized
INFO - 2021-01-15 03:57:20 --> Output Class Initialized
INFO - 2021-01-15 03:57:20 --> Security Class Initialized
DEBUG - 2021-01-15 03:57:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:57:20 --> Input Class Initialized
INFO - 2021-01-15 03:57:20 --> Language Class Initialized
INFO - 2021-01-15 03:57:20 --> Language Class Initialized
INFO - 2021-01-15 03:57:20 --> Config Class Initialized
INFO - 2021-01-15 03:57:20 --> Loader Class Initialized
INFO - 2021-01-15 03:57:20 --> Helper loaded: url_helper
INFO - 2021-01-15 03:57:20 --> Helper loaded: file_helper
INFO - 2021-01-15 03:57:20 --> Helper loaded: form_helper
INFO - 2021-01-15 03:57:20 --> Helper loaded: my_helper
INFO - 2021-01-15 03:57:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:57:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:57:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:57:20 --> Controller Class Initialized
DEBUG - 2021-01-15 03:57:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:57:20 --> Final output sent to browser
DEBUG - 2021-01-15 03:57:20 --> Total execution time: 0.2299
INFO - 2021-01-15 03:57:31 --> Config Class Initialized
INFO - 2021-01-15 03:57:31 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:57:31 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:57:31 --> Utf8 Class Initialized
INFO - 2021-01-15 03:57:31 --> URI Class Initialized
INFO - 2021-01-15 03:57:31 --> Router Class Initialized
INFO - 2021-01-15 03:57:31 --> Output Class Initialized
INFO - 2021-01-15 03:57:31 --> Security Class Initialized
DEBUG - 2021-01-15 03:57:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:57:31 --> Input Class Initialized
INFO - 2021-01-15 03:57:31 --> Language Class Initialized
INFO - 2021-01-15 03:57:31 --> Language Class Initialized
INFO - 2021-01-15 03:57:31 --> Config Class Initialized
INFO - 2021-01-15 03:57:31 --> Loader Class Initialized
INFO - 2021-01-15 03:57:31 --> Helper loaded: url_helper
INFO - 2021-01-15 03:57:31 --> Helper loaded: file_helper
INFO - 2021-01-15 03:57:31 --> Helper loaded: form_helper
INFO - 2021-01-15 03:57:31 --> Helper loaded: my_helper
INFO - 2021-01-15 03:57:31 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:57:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:57:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:57:31 --> Controller Class Initialized
DEBUG - 2021-01-15 03:57:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:57:31 --> Final output sent to browser
DEBUG - 2021-01-15 03:57:31 --> Total execution time: 0.2734
INFO - 2021-01-15 03:58:06 --> Config Class Initialized
INFO - 2021-01-15 03:58:06 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:58:06 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:58:06 --> Utf8 Class Initialized
INFO - 2021-01-15 03:58:06 --> URI Class Initialized
INFO - 2021-01-15 03:58:06 --> Router Class Initialized
INFO - 2021-01-15 03:58:06 --> Output Class Initialized
INFO - 2021-01-15 03:58:06 --> Security Class Initialized
DEBUG - 2021-01-15 03:58:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:58:06 --> Input Class Initialized
INFO - 2021-01-15 03:58:06 --> Language Class Initialized
INFO - 2021-01-15 03:58:06 --> Language Class Initialized
INFO - 2021-01-15 03:58:06 --> Config Class Initialized
INFO - 2021-01-15 03:58:06 --> Loader Class Initialized
INFO - 2021-01-15 03:58:06 --> Helper loaded: url_helper
INFO - 2021-01-15 03:58:06 --> Helper loaded: file_helper
INFO - 2021-01-15 03:58:06 --> Helper loaded: form_helper
INFO - 2021-01-15 03:58:06 --> Helper loaded: my_helper
INFO - 2021-01-15 03:58:06 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:58:06 --> Controller Class Initialized
DEBUG - 2021-01-15 03:58:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:58:06 --> Final output sent to browser
DEBUG - 2021-01-15 03:58:06 --> Total execution time: 0.2303
INFO - 2021-01-15 03:58:23 --> Config Class Initialized
INFO - 2021-01-15 03:58:23 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:58:23 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:58:23 --> Utf8 Class Initialized
INFO - 2021-01-15 03:58:23 --> URI Class Initialized
INFO - 2021-01-15 03:58:23 --> Router Class Initialized
INFO - 2021-01-15 03:58:23 --> Output Class Initialized
INFO - 2021-01-15 03:58:23 --> Security Class Initialized
DEBUG - 2021-01-15 03:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:58:23 --> Input Class Initialized
INFO - 2021-01-15 03:58:23 --> Language Class Initialized
INFO - 2021-01-15 03:58:23 --> Language Class Initialized
INFO - 2021-01-15 03:58:23 --> Config Class Initialized
INFO - 2021-01-15 03:58:23 --> Loader Class Initialized
INFO - 2021-01-15 03:58:23 --> Helper loaded: url_helper
INFO - 2021-01-15 03:58:23 --> Helper loaded: file_helper
INFO - 2021-01-15 03:58:23 --> Helper loaded: form_helper
INFO - 2021-01-15 03:58:23 --> Helper loaded: my_helper
INFO - 2021-01-15 03:58:23 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:58:23 --> Controller Class Initialized
DEBUG - 2021-01-15 03:58:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:58:23 --> Final output sent to browser
DEBUG - 2021-01-15 03:58:23 --> Total execution time: 0.2513
INFO - 2021-01-15 03:58:43 --> Config Class Initialized
INFO - 2021-01-15 03:58:43 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:58:43 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:58:43 --> Utf8 Class Initialized
INFO - 2021-01-15 03:58:43 --> URI Class Initialized
INFO - 2021-01-15 03:58:43 --> Router Class Initialized
INFO - 2021-01-15 03:58:43 --> Output Class Initialized
INFO - 2021-01-15 03:58:43 --> Security Class Initialized
DEBUG - 2021-01-15 03:58:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:58:43 --> Input Class Initialized
INFO - 2021-01-15 03:58:44 --> Language Class Initialized
INFO - 2021-01-15 03:58:44 --> Language Class Initialized
INFO - 2021-01-15 03:58:44 --> Config Class Initialized
INFO - 2021-01-15 03:58:44 --> Loader Class Initialized
INFO - 2021-01-15 03:58:44 --> Helper loaded: url_helper
INFO - 2021-01-15 03:58:44 --> Helper loaded: file_helper
INFO - 2021-01-15 03:58:44 --> Helper loaded: form_helper
INFO - 2021-01-15 03:58:44 --> Helper loaded: my_helper
INFO - 2021-01-15 03:58:44 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:58:44 --> Controller Class Initialized
DEBUG - 2021-01-15 03:58:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:58:44 --> Final output sent to browser
DEBUG - 2021-01-15 03:58:44 --> Total execution time: 0.2302
INFO - 2021-01-15 03:59:06 --> Config Class Initialized
INFO - 2021-01-15 03:59:06 --> Hooks Class Initialized
DEBUG - 2021-01-15 03:59:06 --> UTF-8 Support Enabled
INFO - 2021-01-15 03:59:06 --> Utf8 Class Initialized
INFO - 2021-01-15 03:59:06 --> URI Class Initialized
INFO - 2021-01-15 03:59:06 --> Router Class Initialized
INFO - 2021-01-15 03:59:06 --> Output Class Initialized
INFO - 2021-01-15 03:59:06 --> Security Class Initialized
DEBUG - 2021-01-15 03:59:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 03:59:06 --> Input Class Initialized
INFO - 2021-01-15 03:59:06 --> Language Class Initialized
INFO - 2021-01-15 03:59:06 --> Language Class Initialized
INFO - 2021-01-15 03:59:06 --> Config Class Initialized
INFO - 2021-01-15 03:59:06 --> Loader Class Initialized
INFO - 2021-01-15 03:59:06 --> Helper loaded: url_helper
INFO - 2021-01-15 03:59:06 --> Helper loaded: file_helper
INFO - 2021-01-15 03:59:06 --> Helper loaded: form_helper
INFO - 2021-01-15 03:59:06 --> Helper loaded: my_helper
INFO - 2021-01-15 03:59:06 --> Database Driver Class Initialized
DEBUG - 2021-01-15 03:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 03:59:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 03:59:06 --> Controller Class Initialized
DEBUG - 2021-01-15 03:59:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 03:59:06 --> Final output sent to browser
DEBUG - 2021-01-15 03:59:06 --> Total execution time: 0.2670
INFO - 2021-01-15 04:01:08 --> Config Class Initialized
INFO - 2021-01-15 04:01:08 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:01:09 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:01:09 --> Utf8 Class Initialized
INFO - 2021-01-15 04:01:09 --> URI Class Initialized
INFO - 2021-01-15 04:01:09 --> Router Class Initialized
INFO - 2021-01-15 04:01:09 --> Output Class Initialized
INFO - 2021-01-15 04:01:09 --> Security Class Initialized
DEBUG - 2021-01-15 04:01:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:01:09 --> Input Class Initialized
INFO - 2021-01-15 04:01:09 --> Language Class Initialized
INFO - 2021-01-15 04:01:09 --> Language Class Initialized
INFO - 2021-01-15 04:01:09 --> Config Class Initialized
INFO - 2021-01-15 04:01:09 --> Loader Class Initialized
INFO - 2021-01-15 04:01:09 --> Helper loaded: url_helper
INFO - 2021-01-15 04:01:09 --> Helper loaded: file_helper
INFO - 2021-01-15 04:01:09 --> Helper loaded: form_helper
INFO - 2021-01-15 04:01:09 --> Helper loaded: my_helper
INFO - 2021-01-15 04:01:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:01:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:01:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:01:09 --> Controller Class Initialized
DEBUG - 2021-01-15 04:01:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:01:09 --> Final output sent to browser
DEBUG - 2021-01-15 04:01:09 --> Total execution time: 0.2348
INFO - 2021-01-15 04:03:18 --> Config Class Initialized
INFO - 2021-01-15 04:03:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:03:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:03:18 --> Utf8 Class Initialized
INFO - 2021-01-15 04:03:18 --> URI Class Initialized
INFO - 2021-01-15 04:03:18 --> Router Class Initialized
INFO - 2021-01-15 04:03:18 --> Output Class Initialized
INFO - 2021-01-15 04:03:18 --> Security Class Initialized
DEBUG - 2021-01-15 04:03:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:03:18 --> Input Class Initialized
INFO - 2021-01-15 04:03:18 --> Language Class Initialized
INFO - 2021-01-15 04:03:18 --> Language Class Initialized
INFO - 2021-01-15 04:03:18 --> Config Class Initialized
INFO - 2021-01-15 04:03:18 --> Loader Class Initialized
INFO - 2021-01-15 04:03:18 --> Helper loaded: url_helper
INFO - 2021-01-15 04:03:18 --> Helper loaded: file_helper
INFO - 2021-01-15 04:03:18 --> Helper loaded: form_helper
INFO - 2021-01-15 04:03:18 --> Helper loaded: my_helper
INFO - 2021-01-15 04:03:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:03:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:03:18 --> Controller Class Initialized
DEBUG - 2021-01-15 04:03:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:03:18 --> Final output sent to browser
DEBUG - 2021-01-15 04:03:18 --> Total execution time: 0.2639
INFO - 2021-01-15 04:03:19 --> Config Class Initialized
INFO - 2021-01-15 04:03:19 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:03:19 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:03:19 --> Utf8 Class Initialized
INFO - 2021-01-15 04:03:19 --> URI Class Initialized
INFO - 2021-01-15 04:03:19 --> Router Class Initialized
INFO - 2021-01-15 04:03:19 --> Output Class Initialized
INFO - 2021-01-15 04:03:19 --> Security Class Initialized
DEBUG - 2021-01-15 04:03:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:03:19 --> Input Class Initialized
INFO - 2021-01-15 04:03:19 --> Language Class Initialized
INFO - 2021-01-15 04:03:19 --> Language Class Initialized
INFO - 2021-01-15 04:03:19 --> Config Class Initialized
INFO - 2021-01-15 04:03:19 --> Loader Class Initialized
INFO - 2021-01-15 04:03:19 --> Helper loaded: url_helper
INFO - 2021-01-15 04:03:19 --> Helper loaded: file_helper
INFO - 2021-01-15 04:03:19 --> Helper loaded: form_helper
INFO - 2021-01-15 04:03:19 --> Helper loaded: my_helper
INFO - 2021-01-15 04:03:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:03:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:03:19 --> Controller Class Initialized
DEBUG - 2021-01-15 04:03:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:03:19 --> Final output sent to browser
DEBUG - 2021-01-15 04:03:19 --> Total execution time: 0.2670
INFO - 2021-01-15 04:03:42 --> Config Class Initialized
INFO - 2021-01-15 04:03:42 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:03:42 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:03:42 --> Utf8 Class Initialized
INFO - 2021-01-15 04:03:42 --> URI Class Initialized
INFO - 2021-01-15 04:03:42 --> Router Class Initialized
INFO - 2021-01-15 04:03:42 --> Output Class Initialized
INFO - 2021-01-15 04:03:42 --> Security Class Initialized
DEBUG - 2021-01-15 04:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:03:42 --> Input Class Initialized
INFO - 2021-01-15 04:03:42 --> Language Class Initialized
INFO - 2021-01-15 04:03:42 --> Language Class Initialized
INFO - 2021-01-15 04:03:42 --> Config Class Initialized
INFO - 2021-01-15 04:03:42 --> Loader Class Initialized
INFO - 2021-01-15 04:03:43 --> Helper loaded: url_helper
INFO - 2021-01-15 04:03:43 --> Helper loaded: file_helper
INFO - 2021-01-15 04:03:43 --> Helper loaded: form_helper
INFO - 2021-01-15 04:03:43 --> Helper loaded: my_helper
INFO - 2021-01-15 04:03:43 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:03:43 --> Controller Class Initialized
DEBUG - 2021-01-15 04:03:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:03:43 --> Final output sent to browser
DEBUG - 2021-01-15 04:03:43 --> Total execution time: 0.2653
INFO - 2021-01-15 04:03:54 --> Config Class Initialized
INFO - 2021-01-15 04:03:54 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:03:54 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:03:54 --> Utf8 Class Initialized
INFO - 2021-01-15 04:03:54 --> URI Class Initialized
INFO - 2021-01-15 04:03:54 --> Router Class Initialized
INFO - 2021-01-15 04:03:54 --> Output Class Initialized
INFO - 2021-01-15 04:03:54 --> Security Class Initialized
DEBUG - 2021-01-15 04:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:03:54 --> Input Class Initialized
INFO - 2021-01-15 04:03:54 --> Language Class Initialized
INFO - 2021-01-15 04:03:54 --> Language Class Initialized
INFO - 2021-01-15 04:03:54 --> Config Class Initialized
INFO - 2021-01-15 04:03:54 --> Loader Class Initialized
INFO - 2021-01-15 04:03:54 --> Helper loaded: url_helper
INFO - 2021-01-15 04:03:54 --> Helper loaded: file_helper
INFO - 2021-01-15 04:03:54 --> Helper loaded: form_helper
INFO - 2021-01-15 04:03:54 --> Helper loaded: my_helper
INFO - 2021-01-15 04:03:54 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:03:54 --> Controller Class Initialized
DEBUG - 2021-01-15 04:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:03:54 --> Final output sent to browser
DEBUG - 2021-01-15 04:03:54 --> Total execution time: 0.2461
INFO - 2021-01-15 04:04:03 --> Config Class Initialized
INFO - 2021-01-15 04:04:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:04:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:04:03 --> Utf8 Class Initialized
INFO - 2021-01-15 04:04:03 --> URI Class Initialized
INFO - 2021-01-15 04:04:03 --> Router Class Initialized
INFO - 2021-01-15 04:04:03 --> Output Class Initialized
INFO - 2021-01-15 04:04:03 --> Security Class Initialized
DEBUG - 2021-01-15 04:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:04:03 --> Input Class Initialized
INFO - 2021-01-15 04:04:03 --> Language Class Initialized
INFO - 2021-01-15 04:04:03 --> Language Class Initialized
INFO - 2021-01-15 04:04:03 --> Config Class Initialized
INFO - 2021-01-15 04:04:03 --> Loader Class Initialized
INFO - 2021-01-15 04:04:03 --> Helper loaded: url_helper
INFO - 2021-01-15 04:04:03 --> Helper loaded: file_helper
INFO - 2021-01-15 04:04:03 --> Helper loaded: form_helper
INFO - 2021-01-15 04:04:03 --> Helper loaded: my_helper
INFO - 2021-01-15 04:04:03 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:04:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:04:04 --> Controller Class Initialized
DEBUG - 2021-01-15 04:04:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:04:04 --> Final output sent to browser
DEBUG - 2021-01-15 04:04:04 --> Total execution time: 0.3014
INFO - 2021-01-15 04:05:15 --> Config Class Initialized
INFO - 2021-01-15 04:05:15 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:05:15 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:05:15 --> Utf8 Class Initialized
INFO - 2021-01-15 04:05:15 --> URI Class Initialized
INFO - 2021-01-15 04:05:15 --> Router Class Initialized
INFO - 2021-01-15 04:05:15 --> Output Class Initialized
INFO - 2021-01-15 04:05:15 --> Security Class Initialized
DEBUG - 2021-01-15 04:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:05:15 --> Input Class Initialized
INFO - 2021-01-15 04:05:15 --> Language Class Initialized
INFO - 2021-01-15 04:05:15 --> Language Class Initialized
INFO - 2021-01-15 04:05:15 --> Config Class Initialized
INFO - 2021-01-15 04:05:15 --> Loader Class Initialized
INFO - 2021-01-15 04:05:15 --> Helper loaded: url_helper
INFO - 2021-01-15 04:05:15 --> Helper loaded: file_helper
INFO - 2021-01-15 04:05:15 --> Helper loaded: form_helper
INFO - 2021-01-15 04:05:15 --> Helper loaded: my_helper
INFO - 2021-01-15 04:05:15 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:05:15 --> Controller Class Initialized
DEBUG - 2021-01-15 04:05:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2021-01-15 04:05:15 --> Final output sent to browser
DEBUG - 2021-01-15 04:05:15 --> Total execution time: 0.2854
INFO - 2021-01-15 04:06:06 --> Config Class Initialized
INFO - 2021-01-15 04:06:06 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:06:06 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:06:06 --> Utf8 Class Initialized
INFO - 2021-01-15 04:06:06 --> URI Class Initialized
INFO - 2021-01-15 04:06:06 --> Router Class Initialized
INFO - 2021-01-15 04:06:06 --> Output Class Initialized
INFO - 2021-01-15 04:06:06 --> Security Class Initialized
DEBUG - 2021-01-15 04:06:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:06:06 --> Input Class Initialized
INFO - 2021-01-15 04:06:06 --> Language Class Initialized
INFO - 2021-01-15 04:06:06 --> Language Class Initialized
INFO - 2021-01-15 04:06:06 --> Config Class Initialized
INFO - 2021-01-15 04:06:06 --> Loader Class Initialized
INFO - 2021-01-15 04:06:06 --> Helper loaded: url_helper
INFO - 2021-01-15 04:06:06 --> Helper loaded: file_helper
INFO - 2021-01-15 04:06:06 --> Helper loaded: form_helper
INFO - 2021-01-15 04:06:06 --> Helper loaded: my_helper
INFO - 2021-01-15 04:06:06 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:06:06 --> Controller Class Initialized
DEBUG - 2021-01-15 04:06:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_ekstra.php
INFO - 2021-01-15 04:06:06 --> Final output sent to browser
DEBUG - 2021-01-15 04:06:06 --> Total execution time: 0.2472
INFO - 2021-01-15 04:06:09 --> Config Class Initialized
INFO - 2021-01-15 04:06:09 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:06:09 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:06:09 --> Utf8 Class Initialized
INFO - 2021-01-15 04:06:09 --> URI Class Initialized
INFO - 2021-01-15 04:06:09 --> Router Class Initialized
INFO - 2021-01-15 04:06:09 --> Output Class Initialized
INFO - 2021-01-15 04:06:09 --> Security Class Initialized
DEBUG - 2021-01-15 04:06:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:06:09 --> Input Class Initialized
INFO - 2021-01-15 04:06:09 --> Language Class Initialized
INFO - 2021-01-15 04:06:09 --> Language Class Initialized
INFO - 2021-01-15 04:06:09 --> Config Class Initialized
INFO - 2021-01-15 04:06:09 --> Loader Class Initialized
INFO - 2021-01-15 04:06:09 --> Helper loaded: url_helper
INFO - 2021-01-15 04:06:09 --> Helper loaded: file_helper
INFO - 2021-01-15 04:06:09 --> Helper loaded: form_helper
INFO - 2021-01-15 04:06:09 --> Helper loaded: my_helper
INFO - 2021-01-15 04:06:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:06:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:06:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:06:09 --> Controller Class Initialized
DEBUG - 2021-01-15 04:06:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:06:09 --> Final output sent to browser
DEBUG - 2021-01-15 04:06:09 --> Total execution time: 0.2446
INFO - 2021-01-15 04:06:43 --> Config Class Initialized
INFO - 2021-01-15 04:06:43 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:06:43 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:06:43 --> Utf8 Class Initialized
INFO - 2021-01-15 04:06:43 --> URI Class Initialized
INFO - 2021-01-15 04:06:43 --> Router Class Initialized
INFO - 2021-01-15 04:06:43 --> Output Class Initialized
INFO - 2021-01-15 04:06:43 --> Security Class Initialized
DEBUG - 2021-01-15 04:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:06:43 --> Input Class Initialized
INFO - 2021-01-15 04:06:43 --> Language Class Initialized
INFO - 2021-01-15 04:06:43 --> Language Class Initialized
INFO - 2021-01-15 04:06:43 --> Config Class Initialized
INFO - 2021-01-15 04:06:43 --> Loader Class Initialized
INFO - 2021-01-15 04:06:43 --> Helper loaded: url_helper
INFO - 2021-01-15 04:06:43 --> Helper loaded: file_helper
INFO - 2021-01-15 04:06:43 --> Helper loaded: form_helper
INFO - 2021-01-15 04:06:43 --> Helper loaded: my_helper
INFO - 2021-01-15 04:06:43 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:06:43 --> Controller Class Initialized
DEBUG - 2021-01-15 04:06:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:06:43 --> Final output sent to browser
DEBUG - 2021-01-15 04:06:43 --> Total execution time: 0.2679
INFO - 2021-01-15 04:07:02 --> Config Class Initialized
INFO - 2021-01-15 04:07:02 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:07:02 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:07:02 --> Utf8 Class Initialized
INFO - 2021-01-15 04:07:02 --> URI Class Initialized
INFO - 2021-01-15 04:07:02 --> Router Class Initialized
INFO - 2021-01-15 04:07:02 --> Output Class Initialized
INFO - 2021-01-15 04:07:02 --> Security Class Initialized
DEBUG - 2021-01-15 04:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:07:02 --> Input Class Initialized
INFO - 2021-01-15 04:07:02 --> Language Class Initialized
ERROR - 2021-01-15 04:07:02 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 114
INFO - 2021-01-15 04:07:13 --> Config Class Initialized
INFO - 2021-01-15 04:07:13 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:07:13 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:07:13 --> Utf8 Class Initialized
INFO - 2021-01-15 04:07:13 --> URI Class Initialized
INFO - 2021-01-15 04:07:13 --> Router Class Initialized
INFO - 2021-01-15 04:07:13 --> Output Class Initialized
INFO - 2021-01-15 04:07:13 --> Security Class Initialized
DEBUG - 2021-01-15 04:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:07:13 --> Input Class Initialized
INFO - 2021-01-15 04:07:13 --> Language Class Initialized
ERROR - 2021-01-15 04:07:13 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 114
INFO - 2021-01-15 04:07:44 --> Config Class Initialized
INFO - 2021-01-15 04:07:44 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:07:44 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:07:44 --> Utf8 Class Initialized
INFO - 2021-01-15 04:07:44 --> URI Class Initialized
INFO - 2021-01-15 04:07:44 --> Router Class Initialized
INFO - 2021-01-15 04:07:44 --> Output Class Initialized
INFO - 2021-01-15 04:07:44 --> Security Class Initialized
DEBUG - 2021-01-15 04:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:07:44 --> Input Class Initialized
INFO - 2021-01-15 04:07:44 --> Language Class Initialized
INFO - 2021-01-15 04:07:44 --> Language Class Initialized
INFO - 2021-01-15 04:07:44 --> Config Class Initialized
INFO - 2021-01-15 04:07:44 --> Loader Class Initialized
INFO - 2021-01-15 04:07:44 --> Helper loaded: url_helper
INFO - 2021-01-15 04:07:44 --> Helper loaded: file_helper
INFO - 2021-01-15 04:07:44 --> Helper loaded: form_helper
INFO - 2021-01-15 04:07:44 --> Helper loaded: my_helper
INFO - 2021-01-15 04:07:44 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:07:44 --> Controller Class Initialized
DEBUG - 2021-01-15 04:07:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:07:44 --> Final output sent to browser
DEBUG - 2021-01-15 04:07:44 --> Total execution time: 0.2399
INFO - 2021-01-15 04:08:19 --> Config Class Initialized
INFO - 2021-01-15 04:08:19 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:08:19 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:08:19 --> Utf8 Class Initialized
INFO - 2021-01-15 04:08:19 --> URI Class Initialized
INFO - 2021-01-15 04:08:19 --> Router Class Initialized
INFO - 2021-01-15 04:08:19 --> Output Class Initialized
INFO - 2021-01-15 04:08:19 --> Security Class Initialized
DEBUG - 2021-01-15 04:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:08:19 --> Input Class Initialized
INFO - 2021-01-15 04:08:19 --> Language Class Initialized
INFO - 2021-01-15 04:08:19 --> Language Class Initialized
INFO - 2021-01-15 04:08:19 --> Config Class Initialized
INFO - 2021-01-15 04:08:19 --> Loader Class Initialized
INFO - 2021-01-15 04:08:19 --> Helper loaded: url_helper
INFO - 2021-01-15 04:08:19 --> Helper loaded: file_helper
INFO - 2021-01-15 04:08:19 --> Helper loaded: form_helper
INFO - 2021-01-15 04:08:19 --> Helper loaded: my_helper
INFO - 2021-01-15 04:08:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:08:19 --> Controller Class Initialized
DEBUG - 2021-01-15 04:08:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:08:19 --> Final output sent to browser
DEBUG - 2021-01-15 04:08:19 --> Total execution time: 0.2382
INFO - 2021-01-15 04:10:00 --> Config Class Initialized
INFO - 2021-01-15 04:10:00 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:10:00 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:10:00 --> Utf8 Class Initialized
INFO - 2021-01-15 04:10:00 --> URI Class Initialized
INFO - 2021-01-15 04:10:00 --> Router Class Initialized
INFO - 2021-01-15 04:10:00 --> Output Class Initialized
INFO - 2021-01-15 04:10:00 --> Security Class Initialized
DEBUG - 2021-01-15 04:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:10:00 --> Input Class Initialized
INFO - 2021-01-15 04:10:00 --> Language Class Initialized
INFO - 2021-01-15 04:10:00 --> Language Class Initialized
INFO - 2021-01-15 04:10:00 --> Config Class Initialized
INFO - 2021-01-15 04:10:00 --> Loader Class Initialized
INFO - 2021-01-15 04:10:00 --> Helper loaded: url_helper
INFO - 2021-01-15 04:10:00 --> Helper loaded: file_helper
INFO - 2021-01-15 04:10:00 --> Helper loaded: form_helper
INFO - 2021-01-15 04:10:00 --> Helper loaded: my_helper
INFO - 2021-01-15 04:10:00 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:10:00 --> Controller Class Initialized
DEBUG - 2021-01-15 04:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:10:00 --> Final output sent to browser
DEBUG - 2021-01-15 04:10:00 --> Total execution time: 0.2709
INFO - 2021-01-15 04:10:20 --> Config Class Initialized
INFO - 2021-01-15 04:10:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:10:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:10:20 --> Utf8 Class Initialized
INFO - 2021-01-15 04:10:20 --> URI Class Initialized
INFO - 2021-01-15 04:10:20 --> Router Class Initialized
INFO - 2021-01-15 04:10:20 --> Output Class Initialized
INFO - 2021-01-15 04:10:20 --> Security Class Initialized
DEBUG - 2021-01-15 04:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:10:20 --> Input Class Initialized
INFO - 2021-01-15 04:10:20 --> Language Class Initialized
INFO - 2021-01-15 04:10:20 --> Language Class Initialized
INFO - 2021-01-15 04:10:20 --> Config Class Initialized
INFO - 2021-01-15 04:10:20 --> Loader Class Initialized
INFO - 2021-01-15 04:10:20 --> Helper loaded: url_helper
INFO - 2021-01-15 04:10:20 --> Helper loaded: file_helper
INFO - 2021-01-15 04:10:20 --> Helper loaded: form_helper
INFO - 2021-01-15 04:10:20 --> Helper loaded: my_helper
INFO - 2021-01-15 04:10:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:10:20 --> Controller Class Initialized
DEBUG - 2021-01-15 04:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:10:20 --> Final output sent to browser
DEBUG - 2021-01-15 04:10:20 --> Total execution time: 0.2496
INFO - 2021-01-15 04:10:44 --> Config Class Initialized
INFO - 2021-01-15 04:10:44 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:10:44 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:10:44 --> Utf8 Class Initialized
INFO - 2021-01-15 04:10:44 --> URI Class Initialized
INFO - 2021-01-15 04:10:44 --> Router Class Initialized
INFO - 2021-01-15 04:10:44 --> Output Class Initialized
INFO - 2021-01-15 04:10:44 --> Security Class Initialized
DEBUG - 2021-01-15 04:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:10:44 --> Input Class Initialized
INFO - 2021-01-15 04:10:44 --> Language Class Initialized
INFO - 2021-01-15 04:10:44 --> Language Class Initialized
INFO - 2021-01-15 04:10:44 --> Config Class Initialized
INFO - 2021-01-15 04:10:44 --> Loader Class Initialized
INFO - 2021-01-15 04:10:44 --> Helper loaded: url_helper
INFO - 2021-01-15 04:10:44 --> Helper loaded: file_helper
INFO - 2021-01-15 04:10:44 --> Helper loaded: form_helper
INFO - 2021-01-15 04:10:44 --> Helper loaded: my_helper
INFO - 2021-01-15 04:10:44 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:10:44 --> Controller Class Initialized
DEBUG - 2021-01-15 04:10:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:10:44 --> Final output sent to browser
DEBUG - 2021-01-15 04:10:44 --> Total execution time: 0.2528
INFO - 2021-01-15 04:11:11 --> Config Class Initialized
INFO - 2021-01-15 04:11:11 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:11:11 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:11:11 --> Utf8 Class Initialized
INFO - 2021-01-15 04:11:11 --> URI Class Initialized
INFO - 2021-01-15 04:11:11 --> Router Class Initialized
INFO - 2021-01-15 04:11:11 --> Output Class Initialized
INFO - 2021-01-15 04:11:11 --> Security Class Initialized
DEBUG - 2021-01-15 04:11:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:11:11 --> Input Class Initialized
INFO - 2021-01-15 04:11:11 --> Language Class Initialized
INFO - 2021-01-15 04:11:11 --> Language Class Initialized
INFO - 2021-01-15 04:11:11 --> Config Class Initialized
INFO - 2021-01-15 04:11:11 --> Loader Class Initialized
INFO - 2021-01-15 04:11:11 --> Helper loaded: url_helper
INFO - 2021-01-15 04:11:11 --> Helper loaded: file_helper
INFO - 2021-01-15 04:11:11 --> Helper loaded: form_helper
INFO - 2021-01-15 04:11:11 --> Helper loaded: my_helper
INFO - 2021-01-15 04:11:11 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:11:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:11:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:11:11 --> Controller Class Initialized
DEBUG - 2021-01-15 04:11:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:11:11 --> Final output sent to browser
DEBUG - 2021-01-15 04:11:11 --> Total execution time: 0.2718
INFO - 2021-01-15 04:19:21 --> Config Class Initialized
INFO - 2021-01-15 04:19:21 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:21 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:21 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:21 --> URI Class Initialized
INFO - 2021-01-15 04:19:21 --> Router Class Initialized
INFO - 2021-01-15 04:19:21 --> Output Class Initialized
INFO - 2021-01-15 04:19:21 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:21 --> Input Class Initialized
INFO - 2021-01-15 04:19:21 --> Language Class Initialized
INFO - 2021-01-15 04:19:21 --> Language Class Initialized
INFO - 2021-01-15 04:19:21 --> Config Class Initialized
INFO - 2021-01-15 04:19:21 --> Loader Class Initialized
INFO - 2021-01-15 04:19:21 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:21 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:21 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:21 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:21 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:21 --> Controller Class Initialized
INFO - 2021-01-15 04:19:21 --> Helper loaded: cookie_helper
INFO - 2021-01-15 04:19:21 --> Config Class Initialized
INFO - 2021-01-15 04:19:21 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:21 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:22 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:22 --> URI Class Initialized
INFO - 2021-01-15 04:19:22 --> Router Class Initialized
INFO - 2021-01-15 04:19:22 --> Output Class Initialized
INFO - 2021-01-15 04:19:22 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:22 --> Input Class Initialized
INFO - 2021-01-15 04:19:22 --> Language Class Initialized
INFO - 2021-01-15 04:19:22 --> Language Class Initialized
INFO - 2021-01-15 04:19:22 --> Config Class Initialized
INFO - 2021-01-15 04:19:22 --> Loader Class Initialized
INFO - 2021-01-15 04:19:22 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:22 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:22 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:22 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:22 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:22 --> Controller Class Initialized
DEBUG - 2021-01-15 04:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-15 04:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:19:22 --> Final output sent to browser
DEBUG - 2021-01-15 04:19:22 --> Total execution time: 0.3172
INFO - 2021-01-15 04:19:27 --> Config Class Initialized
INFO - 2021-01-15 04:19:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:27 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:27 --> URI Class Initialized
INFO - 2021-01-15 04:19:27 --> Router Class Initialized
INFO - 2021-01-15 04:19:27 --> Output Class Initialized
INFO - 2021-01-15 04:19:27 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:27 --> Input Class Initialized
INFO - 2021-01-15 04:19:27 --> Language Class Initialized
INFO - 2021-01-15 04:19:27 --> Language Class Initialized
INFO - 2021-01-15 04:19:27 --> Config Class Initialized
INFO - 2021-01-15 04:19:27 --> Loader Class Initialized
INFO - 2021-01-15 04:19:27 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:27 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:27 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:27 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:27 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:27 --> Controller Class Initialized
INFO - 2021-01-15 04:19:27 --> Helper loaded: cookie_helper
INFO - 2021-01-15 04:19:27 --> Final output sent to browser
DEBUG - 2021-01-15 04:19:27 --> Total execution time: 0.3224
INFO - 2021-01-15 04:19:28 --> Config Class Initialized
INFO - 2021-01-15 04:19:28 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:28 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:28 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:28 --> URI Class Initialized
INFO - 2021-01-15 04:19:28 --> Router Class Initialized
INFO - 2021-01-15 04:19:28 --> Output Class Initialized
INFO - 2021-01-15 04:19:28 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:28 --> Input Class Initialized
INFO - 2021-01-15 04:19:28 --> Language Class Initialized
INFO - 2021-01-15 04:19:28 --> Language Class Initialized
INFO - 2021-01-15 04:19:28 --> Config Class Initialized
INFO - 2021-01-15 04:19:28 --> Loader Class Initialized
INFO - 2021-01-15 04:19:28 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:28 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:28 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:28 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:28 --> Controller Class Initialized
DEBUG - 2021-01-15 04:19:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 04:19:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:19:28 --> Final output sent to browser
DEBUG - 2021-01-15 04:19:28 --> Total execution time: 0.4190
INFO - 2021-01-15 04:19:43 --> Config Class Initialized
INFO - 2021-01-15 04:19:43 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:43 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:43 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:43 --> URI Class Initialized
INFO - 2021-01-15 04:19:43 --> Router Class Initialized
INFO - 2021-01-15 04:19:43 --> Output Class Initialized
INFO - 2021-01-15 04:19:43 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:43 --> Input Class Initialized
INFO - 2021-01-15 04:19:43 --> Language Class Initialized
INFO - 2021-01-15 04:19:43 --> Language Class Initialized
INFO - 2021-01-15 04:19:43 --> Config Class Initialized
INFO - 2021-01-15 04:19:43 --> Loader Class Initialized
INFO - 2021-01-15 04:19:43 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:43 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:43 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:43 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:43 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:43 --> Controller Class Initialized
DEBUG - 2021-01-15 04:19:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2021-01-15 04:19:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:19:44 --> Final output sent to browser
DEBUG - 2021-01-15 04:19:44 --> Total execution time: 0.2750
INFO - 2021-01-15 04:19:44 --> Config Class Initialized
INFO - 2021-01-15 04:19:44 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:44 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:44 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:44 --> URI Class Initialized
INFO - 2021-01-15 04:19:44 --> Router Class Initialized
INFO - 2021-01-15 04:19:44 --> Output Class Initialized
INFO - 2021-01-15 04:19:44 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:44 --> Input Class Initialized
INFO - 2021-01-15 04:19:44 --> Language Class Initialized
INFO - 2021-01-15 04:19:44 --> Language Class Initialized
INFO - 2021-01-15 04:19:44 --> Config Class Initialized
INFO - 2021-01-15 04:19:44 --> Loader Class Initialized
INFO - 2021-01-15 04:19:44 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:44 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:44 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:44 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:44 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:44 --> Controller Class Initialized
INFO - 2021-01-15 04:19:50 --> Config Class Initialized
INFO - 2021-01-15 04:19:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:50 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:50 --> URI Class Initialized
INFO - 2021-01-15 04:19:51 --> Router Class Initialized
INFO - 2021-01-15 04:19:51 --> Output Class Initialized
INFO - 2021-01-15 04:19:51 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:51 --> Input Class Initialized
INFO - 2021-01-15 04:19:51 --> Language Class Initialized
INFO - 2021-01-15 04:19:51 --> Language Class Initialized
INFO - 2021-01-15 04:19:51 --> Config Class Initialized
INFO - 2021-01-15 04:19:51 --> Loader Class Initialized
INFO - 2021-01-15 04:19:51 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:51 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:51 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:51 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:51 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:51 --> Controller Class Initialized
DEBUG - 2021-01-15 04:19:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-15 04:19:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:19:51 --> Final output sent to browser
DEBUG - 2021-01-15 04:19:51 --> Total execution time: 0.3157
INFO - 2021-01-15 04:19:51 --> Config Class Initialized
INFO - 2021-01-15 04:19:51 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:19:51 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:19:51 --> Utf8 Class Initialized
INFO - 2021-01-15 04:19:51 --> URI Class Initialized
INFO - 2021-01-15 04:19:51 --> Router Class Initialized
INFO - 2021-01-15 04:19:51 --> Output Class Initialized
INFO - 2021-01-15 04:19:51 --> Security Class Initialized
DEBUG - 2021-01-15 04:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:19:51 --> Input Class Initialized
INFO - 2021-01-15 04:19:51 --> Language Class Initialized
INFO - 2021-01-15 04:19:51 --> Language Class Initialized
INFO - 2021-01-15 04:19:51 --> Config Class Initialized
INFO - 2021-01-15 04:19:51 --> Loader Class Initialized
INFO - 2021-01-15 04:19:51 --> Helper loaded: url_helper
INFO - 2021-01-15 04:19:51 --> Helper loaded: file_helper
INFO - 2021-01-15 04:19:51 --> Helper loaded: form_helper
INFO - 2021-01-15 04:19:51 --> Helper loaded: my_helper
INFO - 2021-01-15 04:19:51 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:19:51 --> Controller Class Initialized
INFO - 2021-01-15 04:20:02 --> Config Class Initialized
INFO - 2021-01-15 04:20:02 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:02 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:02 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:02 --> URI Class Initialized
INFO - 2021-01-15 04:20:02 --> Router Class Initialized
INFO - 2021-01-15 04:20:02 --> Output Class Initialized
INFO - 2021-01-15 04:20:02 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:02 --> Input Class Initialized
INFO - 2021-01-15 04:20:02 --> Language Class Initialized
INFO - 2021-01-15 04:20:02 --> Language Class Initialized
INFO - 2021-01-15 04:20:02 --> Config Class Initialized
INFO - 2021-01-15 04:20:02 --> Loader Class Initialized
INFO - 2021-01-15 04:20:02 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:02 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:02 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:02 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:02 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:02 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-15 04:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:02 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:02 --> Total execution time: 0.3094
INFO - 2021-01-15 04:20:18 --> Config Class Initialized
INFO - 2021-01-15 04:20:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:18 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:18 --> URI Class Initialized
INFO - 2021-01-15 04:20:18 --> Router Class Initialized
INFO - 2021-01-15 04:20:18 --> Output Class Initialized
INFO - 2021-01-15 04:20:18 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:18 --> Input Class Initialized
INFO - 2021-01-15 04:20:18 --> Language Class Initialized
INFO - 2021-01-15 04:20:18 --> Language Class Initialized
INFO - 2021-01-15 04:20:18 --> Config Class Initialized
INFO - 2021-01-15 04:20:18 --> Loader Class Initialized
INFO - 2021-01-15 04:20:18 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:18 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:18 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:18 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:18 --> Controller Class Initialized
INFO - 2021-01-15 04:20:18 --> Config Class Initialized
INFO - 2021-01-15 04:20:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:18 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:18 --> URI Class Initialized
INFO - 2021-01-15 04:20:18 --> Router Class Initialized
INFO - 2021-01-15 04:20:18 --> Output Class Initialized
INFO - 2021-01-15 04:20:18 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:18 --> Input Class Initialized
INFO - 2021-01-15 04:20:18 --> Language Class Initialized
INFO - 2021-01-15 04:20:18 --> Language Class Initialized
INFO - 2021-01-15 04:20:18 --> Config Class Initialized
INFO - 2021-01-15 04:20:18 --> Loader Class Initialized
INFO - 2021-01-15 04:20:19 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:19 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:19 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:19 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:19 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-15 04:20:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:19 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:19 --> Total execution time: 0.2722
INFO - 2021-01-15 04:20:19 --> Config Class Initialized
INFO - 2021-01-15 04:20:19 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:19 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:19 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:19 --> URI Class Initialized
INFO - 2021-01-15 04:20:19 --> Router Class Initialized
INFO - 2021-01-15 04:20:19 --> Output Class Initialized
INFO - 2021-01-15 04:20:19 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:19 --> Input Class Initialized
INFO - 2021-01-15 04:20:19 --> Language Class Initialized
INFO - 2021-01-15 04:20:19 --> Language Class Initialized
INFO - 2021-01-15 04:20:19 --> Config Class Initialized
INFO - 2021-01-15 04:20:19 --> Loader Class Initialized
INFO - 2021-01-15 04:20:19 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:19 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:19 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:19 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:19 --> Controller Class Initialized
INFO - 2021-01-15 04:20:20 --> Config Class Initialized
INFO - 2021-01-15 04:20:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:20 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:20 --> URI Class Initialized
INFO - 2021-01-15 04:20:20 --> Router Class Initialized
INFO - 2021-01-15 04:20:20 --> Output Class Initialized
INFO - 2021-01-15 04:20:20 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:20 --> Input Class Initialized
INFO - 2021-01-15 04:20:20 --> Language Class Initialized
INFO - 2021-01-15 04:20:20 --> Language Class Initialized
INFO - 2021-01-15 04:20:20 --> Config Class Initialized
INFO - 2021-01-15 04:20:20 --> Loader Class Initialized
INFO - 2021-01-15 04:20:20 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:20 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:20 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:20 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:20 --> Controller Class Initialized
INFO - 2021-01-15 04:20:20 --> Helper loaded: cookie_helper
INFO - 2021-01-15 04:20:20 --> Config Class Initialized
INFO - 2021-01-15 04:20:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:20 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:20 --> URI Class Initialized
INFO - 2021-01-15 04:20:20 --> Router Class Initialized
INFO - 2021-01-15 04:20:20 --> Output Class Initialized
INFO - 2021-01-15 04:20:20 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:20 --> Input Class Initialized
INFO - 2021-01-15 04:20:20 --> Language Class Initialized
INFO - 2021-01-15 04:20:20 --> Language Class Initialized
INFO - 2021-01-15 04:20:20 --> Config Class Initialized
INFO - 2021-01-15 04:20:20 --> Loader Class Initialized
INFO - 2021-01-15 04:20:20 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:20 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:20 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:20 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:20 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-15 04:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:20 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:20 --> Total execution time: 0.2945
INFO - 2021-01-15 04:20:27 --> Config Class Initialized
INFO - 2021-01-15 04:20:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:27 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:27 --> URI Class Initialized
INFO - 2021-01-15 04:20:27 --> Router Class Initialized
INFO - 2021-01-15 04:20:27 --> Output Class Initialized
INFO - 2021-01-15 04:20:27 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:27 --> Input Class Initialized
INFO - 2021-01-15 04:20:27 --> Language Class Initialized
INFO - 2021-01-15 04:20:27 --> Language Class Initialized
INFO - 2021-01-15 04:20:28 --> Config Class Initialized
INFO - 2021-01-15 04:20:28 --> Loader Class Initialized
INFO - 2021-01-15 04:20:28 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:28 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:28 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:28 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:28 --> Controller Class Initialized
INFO - 2021-01-15 04:20:28 --> Helper loaded: cookie_helper
INFO - 2021-01-15 04:20:28 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:28 --> Total execution time: 0.4124
INFO - 2021-01-15 04:20:28 --> Config Class Initialized
INFO - 2021-01-15 04:20:28 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:28 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:28 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:28 --> URI Class Initialized
INFO - 2021-01-15 04:20:28 --> Router Class Initialized
INFO - 2021-01-15 04:20:28 --> Output Class Initialized
INFO - 2021-01-15 04:20:28 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:28 --> Input Class Initialized
INFO - 2021-01-15 04:20:28 --> Language Class Initialized
INFO - 2021-01-15 04:20:28 --> Language Class Initialized
INFO - 2021-01-15 04:20:28 --> Config Class Initialized
INFO - 2021-01-15 04:20:28 --> Loader Class Initialized
INFO - 2021-01-15 04:20:28 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:28 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:28 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:28 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:28 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 04:20:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:29 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:29 --> Total execution time: 0.4396
INFO - 2021-01-15 04:20:33 --> Config Class Initialized
INFO - 2021-01-15 04:20:33 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:33 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:33 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:33 --> URI Class Initialized
INFO - 2021-01-15 04:20:33 --> Router Class Initialized
INFO - 2021-01-15 04:20:33 --> Output Class Initialized
INFO - 2021-01-15 04:20:33 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:33 --> Input Class Initialized
INFO - 2021-01-15 04:20:33 --> Language Class Initialized
INFO - 2021-01-15 04:20:33 --> Language Class Initialized
INFO - 2021-01-15 04:20:33 --> Config Class Initialized
INFO - 2021-01-15 04:20:33 --> Loader Class Initialized
INFO - 2021-01-15 04:20:33 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:33 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:33 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:33 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:33 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:33 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-15 04:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:33 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:33 --> Total execution time: 0.2682
INFO - 2021-01-15 04:20:35 --> Config Class Initialized
INFO - 2021-01-15 04:20:35 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:35 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:35 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:35 --> URI Class Initialized
INFO - 2021-01-15 04:20:35 --> Router Class Initialized
INFO - 2021-01-15 04:20:35 --> Output Class Initialized
INFO - 2021-01-15 04:20:35 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:36 --> Input Class Initialized
INFO - 2021-01-15 04:20:36 --> Language Class Initialized
INFO - 2021-01-15 04:20:36 --> Language Class Initialized
INFO - 2021-01-15 04:20:36 --> Config Class Initialized
INFO - 2021-01-15 04:20:36 --> Loader Class Initialized
INFO - 2021-01-15 04:20:36 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:36 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:36 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:36 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:36 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:36 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-15 04:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:36 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:36 --> Total execution time: 0.2882
INFO - 2021-01-15 04:20:36 --> Config Class Initialized
INFO - 2021-01-15 04:20:36 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:36 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:36 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:36 --> URI Class Initialized
INFO - 2021-01-15 04:20:36 --> Router Class Initialized
INFO - 2021-01-15 04:20:36 --> Output Class Initialized
INFO - 2021-01-15 04:20:36 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:36 --> Input Class Initialized
INFO - 2021-01-15 04:20:36 --> Language Class Initialized
INFO - 2021-01-15 04:20:36 --> Language Class Initialized
INFO - 2021-01-15 04:20:36 --> Config Class Initialized
INFO - 2021-01-15 04:20:36 --> Loader Class Initialized
INFO - 2021-01-15 04:20:36 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:36 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:36 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:36 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:36 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:36 --> Controller Class Initialized
INFO - 2021-01-15 04:20:54 --> Config Class Initialized
INFO - 2021-01-15 04:20:54 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:54 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:54 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:54 --> URI Class Initialized
INFO - 2021-01-15 04:20:54 --> Router Class Initialized
INFO - 2021-01-15 04:20:54 --> Output Class Initialized
INFO - 2021-01-15 04:20:54 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:54 --> Input Class Initialized
INFO - 2021-01-15 04:20:54 --> Language Class Initialized
INFO - 2021-01-15 04:20:54 --> Language Class Initialized
INFO - 2021-01-15 04:20:54 --> Config Class Initialized
INFO - 2021-01-15 04:20:54 --> Loader Class Initialized
INFO - 2021-01-15 04:20:54 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:54 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:54 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:54 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:54 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:54 --> Controller Class Initialized
INFO - 2021-01-15 04:20:54 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:54 --> Total execution time: 0.2869
INFO - 2021-01-15 04:20:56 --> Config Class Initialized
INFO - 2021-01-15 04:20:56 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:56 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:56 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:56 --> URI Class Initialized
INFO - 2021-01-15 04:20:56 --> Router Class Initialized
INFO - 2021-01-15 04:20:56 --> Output Class Initialized
INFO - 2021-01-15 04:20:56 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:56 --> Input Class Initialized
INFO - 2021-01-15 04:20:56 --> Language Class Initialized
INFO - 2021-01-15 04:20:56 --> Language Class Initialized
INFO - 2021-01-15 04:20:56 --> Config Class Initialized
INFO - 2021-01-15 04:20:56 --> Loader Class Initialized
INFO - 2021-01-15 04:20:56 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:56 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:56 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:56 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:56 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:56 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-15 04:20:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:56 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:56 --> Total execution time: 0.2835
INFO - 2021-01-15 04:20:58 --> Config Class Initialized
INFO - 2021-01-15 04:20:58 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:58 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:58 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:58 --> URI Class Initialized
INFO - 2021-01-15 04:20:58 --> Router Class Initialized
INFO - 2021-01-15 04:20:58 --> Output Class Initialized
INFO - 2021-01-15 04:20:58 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:58 --> Input Class Initialized
INFO - 2021-01-15 04:20:58 --> Language Class Initialized
INFO - 2021-01-15 04:20:58 --> Language Class Initialized
INFO - 2021-01-15 04:20:58 --> Config Class Initialized
INFO - 2021-01-15 04:20:58 --> Loader Class Initialized
INFO - 2021-01-15 04:20:58 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:58 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:58 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:58 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:58 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:58 --> Controller Class Initialized
DEBUG - 2021-01-15 04:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-15 04:20:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:20:58 --> Final output sent to browser
DEBUG - 2021-01-15 04:20:58 --> Total execution time: 0.2610
INFO - 2021-01-15 04:20:58 --> Config Class Initialized
INFO - 2021-01-15 04:20:58 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:20:58 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:20:58 --> Utf8 Class Initialized
INFO - 2021-01-15 04:20:58 --> URI Class Initialized
INFO - 2021-01-15 04:20:58 --> Router Class Initialized
INFO - 2021-01-15 04:20:58 --> Output Class Initialized
INFO - 2021-01-15 04:20:58 --> Security Class Initialized
DEBUG - 2021-01-15 04:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:20:58 --> Input Class Initialized
INFO - 2021-01-15 04:20:58 --> Language Class Initialized
INFO - 2021-01-15 04:20:58 --> Language Class Initialized
INFO - 2021-01-15 04:20:58 --> Config Class Initialized
INFO - 2021-01-15 04:20:58 --> Loader Class Initialized
INFO - 2021-01-15 04:20:58 --> Helper loaded: url_helper
INFO - 2021-01-15 04:20:58 --> Helper loaded: file_helper
INFO - 2021-01-15 04:20:58 --> Helper loaded: form_helper
INFO - 2021-01-15 04:20:58 --> Helper loaded: my_helper
INFO - 2021-01-15 04:20:58 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:20:58 --> Controller Class Initialized
INFO - 2021-01-15 04:21:01 --> Config Class Initialized
INFO - 2021-01-15 04:21:01 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:01 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:01 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:01 --> URI Class Initialized
INFO - 2021-01-15 04:21:01 --> Router Class Initialized
INFO - 2021-01-15 04:21:01 --> Output Class Initialized
INFO - 2021-01-15 04:21:01 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:01 --> Input Class Initialized
INFO - 2021-01-15 04:21:01 --> Language Class Initialized
INFO - 2021-01-15 04:21:01 --> Language Class Initialized
INFO - 2021-01-15 04:21:01 --> Config Class Initialized
INFO - 2021-01-15 04:21:01 --> Loader Class Initialized
INFO - 2021-01-15 04:21:01 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:01 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:01 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:01 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:01 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:01 --> Controller Class Initialized
DEBUG - 2021-01-15 04:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-15 04:21:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:21:01 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:01 --> Total execution time: 0.3180
INFO - 2021-01-15 04:21:03 --> Config Class Initialized
INFO - 2021-01-15 04:21:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:03 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:03 --> URI Class Initialized
INFO - 2021-01-15 04:21:03 --> Router Class Initialized
INFO - 2021-01-15 04:21:03 --> Output Class Initialized
INFO - 2021-01-15 04:21:03 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:03 --> Input Class Initialized
INFO - 2021-01-15 04:21:03 --> Language Class Initialized
INFO - 2021-01-15 04:21:03 --> Language Class Initialized
INFO - 2021-01-15 04:21:03 --> Config Class Initialized
INFO - 2021-01-15 04:21:03 --> Loader Class Initialized
INFO - 2021-01-15 04:21:03 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:03 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:03 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:03 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:03 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:03 --> Controller Class Initialized
DEBUG - 2021-01-15 04:21:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-15 04:21:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:21:03 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:03 --> Total execution time: 0.2555
INFO - 2021-01-15 04:21:04 --> Config Class Initialized
INFO - 2021-01-15 04:21:04 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:04 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:04 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:04 --> URI Class Initialized
INFO - 2021-01-15 04:21:04 --> Router Class Initialized
INFO - 2021-01-15 04:21:04 --> Output Class Initialized
INFO - 2021-01-15 04:21:04 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:04 --> Input Class Initialized
INFO - 2021-01-15 04:21:04 --> Language Class Initialized
INFO - 2021-01-15 04:21:04 --> Language Class Initialized
INFO - 2021-01-15 04:21:04 --> Config Class Initialized
INFO - 2021-01-15 04:21:04 --> Loader Class Initialized
INFO - 2021-01-15 04:21:04 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:04 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:04 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:04 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:04 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:04 --> Controller Class Initialized
DEBUG - 2021-01-15 04:21:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-15 04:21:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:21:04 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:04 --> Total execution time: 0.3130
INFO - 2021-01-15 04:21:05 --> Config Class Initialized
INFO - 2021-01-15 04:21:05 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:05 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:05 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:05 --> URI Class Initialized
INFO - 2021-01-15 04:21:05 --> Router Class Initialized
INFO - 2021-01-15 04:21:05 --> Output Class Initialized
INFO - 2021-01-15 04:21:05 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:05 --> Input Class Initialized
INFO - 2021-01-15 04:21:05 --> Language Class Initialized
INFO - 2021-01-15 04:21:05 --> Language Class Initialized
INFO - 2021-01-15 04:21:05 --> Config Class Initialized
INFO - 2021-01-15 04:21:05 --> Loader Class Initialized
INFO - 2021-01-15 04:21:05 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:05 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:05 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:05 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:05 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:05 --> Controller Class Initialized
DEBUG - 2021-01-15 04:21:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-15 04:21:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:21:05 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:05 --> Total execution time: 0.2816
INFO - 2021-01-15 04:21:05 --> Config Class Initialized
INFO - 2021-01-15 04:21:05 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:05 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:05 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:05 --> URI Class Initialized
INFO - 2021-01-15 04:21:05 --> Router Class Initialized
INFO - 2021-01-15 04:21:06 --> Output Class Initialized
INFO - 2021-01-15 04:21:06 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:06 --> Input Class Initialized
INFO - 2021-01-15 04:21:06 --> Language Class Initialized
INFO - 2021-01-15 04:21:06 --> Language Class Initialized
INFO - 2021-01-15 04:21:06 --> Config Class Initialized
INFO - 2021-01-15 04:21:06 --> Loader Class Initialized
INFO - 2021-01-15 04:21:06 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:06 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:06 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:06 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:06 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:06 --> Controller Class Initialized
INFO - 2021-01-15 04:21:06 --> Config Class Initialized
INFO - 2021-01-15 04:21:06 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:06 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:06 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:06 --> URI Class Initialized
INFO - 2021-01-15 04:21:06 --> Router Class Initialized
INFO - 2021-01-15 04:21:06 --> Output Class Initialized
INFO - 2021-01-15 04:21:06 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:06 --> Input Class Initialized
INFO - 2021-01-15 04:21:06 --> Language Class Initialized
INFO - 2021-01-15 04:21:06 --> Language Class Initialized
INFO - 2021-01-15 04:21:06 --> Config Class Initialized
INFO - 2021-01-15 04:21:06 --> Loader Class Initialized
INFO - 2021-01-15 04:21:06 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:06 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:07 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:07 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:07 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:07 --> Controller Class Initialized
INFO - 2021-01-15 04:21:07 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:07 --> Total execution time: 0.2756
INFO - 2021-01-15 04:21:29 --> Config Class Initialized
INFO - 2021-01-15 04:21:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:29 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:29 --> URI Class Initialized
INFO - 2021-01-15 04:21:29 --> Router Class Initialized
INFO - 2021-01-15 04:21:29 --> Output Class Initialized
INFO - 2021-01-15 04:21:29 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:29 --> Input Class Initialized
INFO - 2021-01-15 04:21:29 --> Language Class Initialized
INFO - 2021-01-15 04:21:29 --> Language Class Initialized
INFO - 2021-01-15 04:21:29 --> Config Class Initialized
INFO - 2021-01-15 04:21:29 --> Loader Class Initialized
INFO - 2021-01-15 04:21:29 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:29 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:29 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:29 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:29 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:29 --> Controller Class Initialized
INFO - 2021-01-15 04:21:29 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:29 --> Total execution time: 0.3290
INFO - 2021-01-15 04:21:29 --> Config Class Initialized
INFO - 2021-01-15 04:21:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:29 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:29 --> URI Class Initialized
INFO - 2021-01-15 04:21:29 --> Router Class Initialized
INFO - 2021-01-15 04:21:29 --> Output Class Initialized
INFO - 2021-01-15 04:21:29 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:29 --> Input Class Initialized
INFO - 2021-01-15 04:21:29 --> Language Class Initialized
INFO - 2021-01-15 04:21:29 --> Language Class Initialized
INFO - 2021-01-15 04:21:29 --> Config Class Initialized
INFO - 2021-01-15 04:21:29 --> Loader Class Initialized
INFO - 2021-01-15 04:21:29 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:29 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:29 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:29 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:30 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:30 --> Controller Class Initialized
INFO - 2021-01-15 04:21:33 --> Config Class Initialized
INFO - 2021-01-15 04:21:33 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:33 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:33 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:33 --> URI Class Initialized
INFO - 2021-01-15 04:21:33 --> Router Class Initialized
INFO - 2021-01-15 04:21:33 --> Output Class Initialized
INFO - 2021-01-15 04:21:33 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:33 --> Input Class Initialized
INFO - 2021-01-15 04:21:33 --> Language Class Initialized
INFO - 2021-01-15 04:21:33 --> Language Class Initialized
INFO - 2021-01-15 04:21:33 --> Config Class Initialized
INFO - 2021-01-15 04:21:33 --> Loader Class Initialized
INFO - 2021-01-15 04:21:33 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:33 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:33 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:33 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:33 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:33 --> Controller Class Initialized
INFO - 2021-01-15 04:21:33 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:33 --> Total execution time: 0.3275
INFO - 2021-01-15 04:21:57 --> Config Class Initialized
INFO - 2021-01-15 04:21:57 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:57 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:57 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:57 --> URI Class Initialized
INFO - 2021-01-15 04:21:57 --> Router Class Initialized
INFO - 2021-01-15 04:21:57 --> Output Class Initialized
INFO - 2021-01-15 04:21:57 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:57 --> Input Class Initialized
INFO - 2021-01-15 04:21:57 --> Language Class Initialized
INFO - 2021-01-15 04:21:57 --> Language Class Initialized
INFO - 2021-01-15 04:21:57 --> Config Class Initialized
INFO - 2021-01-15 04:21:57 --> Loader Class Initialized
INFO - 2021-01-15 04:21:57 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:57 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:57 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:57 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:57 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:57 --> Controller Class Initialized
INFO - 2021-01-15 04:21:57 --> Final output sent to browser
DEBUG - 2021-01-15 04:21:57 --> Total execution time: 0.3542
INFO - 2021-01-15 04:21:57 --> Config Class Initialized
INFO - 2021-01-15 04:21:57 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:21:57 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:21:57 --> Utf8 Class Initialized
INFO - 2021-01-15 04:21:57 --> URI Class Initialized
INFO - 2021-01-15 04:21:57 --> Router Class Initialized
INFO - 2021-01-15 04:21:57 --> Output Class Initialized
INFO - 2021-01-15 04:21:57 --> Security Class Initialized
DEBUG - 2021-01-15 04:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:21:57 --> Input Class Initialized
INFO - 2021-01-15 04:21:57 --> Language Class Initialized
INFO - 2021-01-15 04:21:57 --> Language Class Initialized
INFO - 2021-01-15 04:21:57 --> Config Class Initialized
INFO - 2021-01-15 04:21:57 --> Loader Class Initialized
INFO - 2021-01-15 04:21:57 --> Helper loaded: url_helper
INFO - 2021-01-15 04:21:57 --> Helper loaded: file_helper
INFO - 2021-01-15 04:21:57 --> Helper loaded: form_helper
INFO - 2021-01-15 04:21:57 --> Helper loaded: my_helper
INFO - 2021-01-15 04:21:57 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:21:57 --> Controller Class Initialized
INFO - 2021-01-15 04:22:00 --> Config Class Initialized
INFO - 2021-01-15 04:22:00 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:00 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:00 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:00 --> URI Class Initialized
INFO - 2021-01-15 04:22:00 --> Router Class Initialized
INFO - 2021-01-15 04:22:00 --> Output Class Initialized
INFO - 2021-01-15 04:22:00 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:00 --> Input Class Initialized
INFO - 2021-01-15 04:22:00 --> Language Class Initialized
INFO - 2021-01-15 04:22:00 --> Language Class Initialized
INFO - 2021-01-15 04:22:00 --> Config Class Initialized
INFO - 2021-01-15 04:22:00 --> Loader Class Initialized
INFO - 2021-01-15 04:22:00 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:00 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:00 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:00 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:00 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:00 --> Controller Class Initialized
INFO - 2021-01-15 04:22:00 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:00 --> Total execution time: 0.2325
INFO - 2021-01-15 04:22:05 --> Config Class Initialized
INFO - 2021-01-15 04:22:05 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:05 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:05 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:05 --> URI Class Initialized
INFO - 2021-01-15 04:22:05 --> Router Class Initialized
INFO - 2021-01-15 04:22:05 --> Output Class Initialized
INFO - 2021-01-15 04:22:05 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:05 --> Input Class Initialized
INFO - 2021-01-15 04:22:05 --> Language Class Initialized
INFO - 2021-01-15 04:22:05 --> Language Class Initialized
INFO - 2021-01-15 04:22:05 --> Config Class Initialized
INFO - 2021-01-15 04:22:05 --> Loader Class Initialized
INFO - 2021-01-15 04:22:05 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:05 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:05 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:05 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:05 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:05 --> Controller Class Initialized
INFO - 2021-01-15 04:22:05 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:05 --> Total execution time: 0.3376
INFO - 2021-01-15 04:22:07 --> Config Class Initialized
INFO - 2021-01-15 04:22:07 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:07 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:07 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:07 --> URI Class Initialized
INFO - 2021-01-15 04:22:07 --> Router Class Initialized
INFO - 2021-01-15 04:22:07 --> Output Class Initialized
INFO - 2021-01-15 04:22:07 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:07 --> Input Class Initialized
INFO - 2021-01-15 04:22:07 --> Language Class Initialized
INFO - 2021-01-15 04:22:07 --> Language Class Initialized
INFO - 2021-01-15 04:22:07 --> Config Class Initialized
INFO - 2021-01-15 04:22:07 --> Loader Class Initialized
INFO - 2021-01-15 04:22:07 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:07 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:07 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:07 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:07 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:07 --> Controller Class Initialized
INFO - 2021-01-15 04:22:07 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:07 --> Total execution time: 0.2731
INFO - 2021-01-15 04:22:11 --> Config Class Initialized
INFO - 2021-01-15 04:22:11 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:11 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:11 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:11 --> URI Class Initialized
INFO - 2021-01-15 04:22:11 --> Router Class Initialized
INFO - 2021-01-15 04:22:11 --> Output Class Initialized
INFO - 2021-01-15 04:22:11 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:11 --> Input Class Initialized
INFO - 2021-01-15 04:22:11 --> Language Class Initialized
INFO - 2021-01-15 04:22:11 --> Language Class Initialized
INFO - 2021-01-15 04:22:11 --> Config Class Initialized
INFO - 2021-01-15 04:22:11 --> Loader Class Initialized
INFO - 2021-01-15 04:22:11 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:11 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:11 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:11 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:11 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:11 --> Controller Class Initialized
INFO - 2021-01-15 04:22:11 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:11 --> Total execution time: 0.3601
INFO - 2021-01-15 04:22:13 --> Config Class Initialized
INFO - 2021-01-15 04:22:13 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:13 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:13 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:13 --> URI Class Initialized
INFO - 2021-01-15 04:22:13 --> Router Class Initialized
INFO - 2021-01-15 04:22:13 --> Output Class Initialized
INFO - 2021-01-15 04:22:13 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:13 --> Input Class Initialized
INFO - 2021-01-15 04:22:13 --> Language Class Initialized
INFO - 2021-01-15 04:22:13 --> Language Class Initialized
INFO - 2021-01-15 04:22:13 --> Config Class Initialized
INFO - 2021-01-15 04:22:13 --> Loader Class Initialized
INFO - 2021-01-15 04:22:13 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:13 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:13 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:13 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:13 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:13 --> Controller Class Initialized
INFO - 2021-01-15 04:22:13 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:13 --> Total execution time: 0.2653
INFO - 2021-01-15 04:22:16 --> Config Class Initialized
INFO - 2021-01-15 04:22:16 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:16 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:16 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:16 --> URI Class Initialized
INFO - 2021-01-15 04:22:16 --> Router Class Initialized
INFO - 2021-01-15 04:22:16 --> Output Class Initialized
INFO - 2021-01-15 04:22:16 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:16 --> Input Class Initialized
INFO - 2021-01-15 04:22:16 --> Language Class Initialized
INFO - 2021-01-15 04:22:16 --> Language Class Initialized
INFO - 2021-01-15 04:22:16 --> Config Class Initialized
INFO - 2021-01-15 04:22:16 --> Loader Class Initialized
INFO - 2021-01-15 04:22:16 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:16 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:16 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:16 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:16 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:16 --> Controller Class Initialized
INFO - 2021-01-15 04:22:16 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:16 --> Total execution time: 0.3547
INFO - 2021-01-15 04:22:17 --> Config Class Initialized
INFO - 2021-01-15 04:22:17 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:17 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:17 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:17 --> URI Class Initialized
INFO - 2021-01-15 04:22:17 --> Router Class Initialized
INFO - 2021-01-15 04:22:17 --> Output Class Initialized
INFO - 2021-01-15 04:22:17 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:18 --> Input Class Initialized
INFO - 2021-01-15 04:22:18 --> Language Class Initialized
INFO - 2021-01-15 04:22:18 --> Language Class Initialized
INFO - 2021-01-15 04:22:18 --> Config Class Initialized
INFO - 2021-01-15 04:22:18 --> Loader Class Initialized
INFO - 2021-01-15 04:22:18 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:18 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:18 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:18 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:18 --> Controller Class Initialized
INFO - 2021-01-15 04:22:18 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:18 --> Total execution time: 0.3536
INFO - 2021-01-15 04:22:20 --> Config Class Initialized
INFO - 2021-01-15 04:22:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:20 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:20 --> URI Class Initialized
INFO - 2021-01-15 04:22:20 --> Router Class Initialized
INFO - 2021-01-15 04:22:20 --> Output Class Initialized
INFO - 2021-01-15 04:22:20 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:20 --> Input Class Initialized
INFO - 2021-01-15 04:22:20 --> Language Class Initialized
INFO - 2021-01-15 04:22:20 --> Language Class Initialized
INFO - 2021-01-15 04:22:20 --> Config Class Initialized
INFO - 2021-01-15 04:22:20 --> Loader Class Initialized
INFO - 2021-01-15 04:22:20 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:20 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:20 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:20 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:20 --> Controller Class Initialized
INFO - 2021-01-15 04:22:21 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:21 --> Total execution time: 0.2995
INFO - 2021-01-15 04:22:23 --> Config Class Initialized
INFO - 2021-01-15 04:22:23 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:23 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:23 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:23 --> URI Class Initialized
INFO - 2021-01-15 04:22:23 --> Router Class Initialized
INFO - 2021-01-15 04:22:23 --> Output Class Initialized
INFO - 2021-01-15 04:22:23 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:23 --> Input Class Initialized
INFO - 2021-01-15 04:22:23 --> Language Class Initialized
INFO - 2021-01-15 04:22:23 --> Language Class Initialized
INFO - 2021-01-15 04:22:23 --> Config Class Initialized
INFO - 2021-01-15 04:22:23 --> Loader Class Initialized
INFO - 2021-01-15 04:22:23 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:23 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:23 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:23 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:23 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:23 --> Controller Class Initialized
DEBUG - 2021-01-15 04:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-15 04:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:22:23 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:23 --> Total execution time: 0.3346
INFO - 2021-01-15 04:22:24 --> Config Class Initialized
INFO - 2021-01-15 04:22:24 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:24 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:24 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:24 --> URI Class Initialized
INFO - 2021-01-15 04:22:24 --> Router Class Initialized
INFO - 2021-01-15 04:22:24 --> Output Class Initialized
INFO - 2021-01-15 04:22:24 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:24 --> Input Class Initialized
INFO - 2021-01-15 04:22:24 --> Language Class Initialized
INFO - 2021-01-15 04:22:24 --> Language Class Initialized
INFO - 2021-01-15 04:22:24 --> Config Class Initialized
INFO - 2021-01-15 04:22:24 --> Loader Class Initialized
INFO - 2021-01-15 04:22:24 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:24 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:24 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:24 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:24 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:24 --> Controller Class Initialized
DEBUG - 2021-01-15 04:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-15 04:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:22:24 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:24 --> Total execution time: 0.2807
INFO - 2021-01-15 04:22:26 --> Config Class Initialized
INFO - 2021-01-15 04:22:26 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:26 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:26 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:26 --> URI Class Initialized
INFO - 2021-01-15 04:22:26 --> Router Class Initialized
INFO - 2021-01-15 04:22:26 --> Output Class Initialized
INFO - 2021-01-15 04:22:26 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:26 --> Input Class Initialized
INFO - 2021-01-15 04:22:26 --> Language Class Initialized
INFO - 2021-01-15 04:22:26 --> Language Class Initialized
INFO - 2021-01-15 04:22:26 --> Config Class Initialized
INFO - 2021-01-15 04:22:26 --> Loader Class Initialized
INFO - 2021-01-15 04:22:26 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:26 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:26 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:26 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:26 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:26 --> Controller Class Initialized
INFO - 2021-01-15 04:22:26 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:26 --> Total execution time: 0.2913
INFO - 2021-01-15 04:22:34 --> Config Class Initialized
INFO - 2021-01-15 04:22:34 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:34 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:34 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:34 --> URI Class Initialized
INFO - 2021-01-15 04:22:34 --> Router Class Initialized
INFO - 2021-01-15 04:22:34 --> Output Class Initialized
INFO - 2021-01-15 04:22:34 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:34 --> Input Class Initialized
INFO - 2021-01-15 04:22:34 --> Language Class Initialized
INFO - 2021-01-15 04:22:34 --> Language Class Initialized
INFO - 2021-01-15 04:22:34 --> Config Class Initialized
INFO - 2021-01-15 04:22:34 --> Loader Class Initialized
INFO - 2021-01-15 04:22:34 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:34 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:34 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:34 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:34 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:34 --> Controller Class Initialized
INFO - 2021-01-15 04:22:34 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:34 --> Total execution time: 0.2944
INFO - 2021-01-15 04:22:34 --> Config Class Initialized
INFO - 2021-01-15 04:22:34 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:34 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:34 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:34 --> URI Class Initialized
INFO - 2021-01-15 04:22:34 --> Router Class Initialized
INFO - 2021-01-15 04:22:34 --> Output Class Initialized
INFO - 2021-01-15 04:22:34 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:34 --> Input Class Initialized
INFO - 2021-01-15 04:22:34 --> Language Class Initialized
INFO - 2021-01-15 04:22:34 --> Language Class Initialized
INFO - 2021-01-15 04:22:34 --> Config Class Initialized
INFO - 2021-01-15 04:22:34 --> Loader Class Initialized
INFO - 2021-01-15 04:22:34 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:34 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:34 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:34 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:34 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:34 --> Controller Class Initialized
DEBUG - 2021-01-15 04:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-15 04:22:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:22:34 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:34 --> Total execution time: 0.4060
INFO - 2021-01-15 04:22:36 --> Config Class Initialized
INFO - 2021-01-15 04:22:36 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:36 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:36 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:36 --> URI Class Initialized
INFO - 2021-01-15 04:22:36 --> Router Class Initialized
INFO - 2021-01-15 04:22:36 --> Output Class Initialized
INFO - 2021-01-15 04:22:36 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:36 --> Input Class Initialized
INFO - 2021-01-15 04:22:36 --> Language Class Initialized
INFO - 2021-01-15 04:22:36 --> Language Class Initialized
INFO - 2021-01-15 04:22:36 --> Config Class Initialized
INFO - 2021-01-15 04:22:36 --> Loader Class Initialized
INFO - 2021-01-15 04:22:36 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:36 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:36 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:36 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:36 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:36 --> Controller Class Initialized
INFO - 2021-01-15 04:22:36 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:36 --> Total execution time: 0.3299
INFO - 2021-01-15 04:22:45 --> Config Class Initialized
INFO - 2021-01-15 04:22:45 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:45 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:45 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:45 --> URI Class Initialized
INFO - 2021-01-15 04:22:45 --> Router Class Initialized
INFO - 2021-01-15 04:22:45 --> Output Class Initialized
INFO - 2021-01-15 04:22:45 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:45 --> Input Class Initialized
INFO - 2021-01-15 04:22:45 --> Language Class Initialized
INFO - 2021-01-15 04:22:45 --> Language Class Initialized
INFO - 2021-01-15 04:22:45 --> Config Class Initialized
INFO - 2021-01-15 04:22:45 --> Loader Class Initialized
INFO - 2021-01-15 04:22:45 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:45 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:45 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:45 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:45 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:45 --> Controller Class Initialized
INFO - 2021-01-15 04:22:45 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:45 --> Total execution time: 0.3380
INFO - 2021-01-15 04:22:45 --> Config Class Initialized
INFO - 2021-01-15 04:22:45 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:45 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:45 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:45 --> URI Class Initialized
INFO - 2021-01-15 04:22:46 --> Router Class Initialized
INFO - 2021-01-15 04:22:46 --> Output Class Initialized
INFO - 2021-01-15 04:22:46 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:46 --> Input Class Initialized
INFO - 2021-01-15 04:22:46 --> Language Class Initialized
INFO - 2021-01-15 04:22:46 --> Language Class Initialized
INFO - 2021-01-15 04:22:46 --> Config Class Initialized
INFO - 2021-01-15 04:22:46 --> Loader Class Initialized
INFO - 2021-01-15 04:22:46 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:46 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:46 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:46 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:46 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:46 --> Controller Class Initialized
DEBUG - 2021-01-15 04:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-15 04:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:22:46 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:46 --> Total execution time: 0.4288
INFO - 2021-01-15 04:22:46 --> Config Class Initialized
INFO - 2021-01-15 04:22:46 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:46 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:46 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:46 --> URI Class Initialized
INFO - 2021-01-15 04:22:46 --> Router Class Initialized
INFO - 2021-01-15 04:22:46 --> Output Class Initialized
INFO - 2021-01-15 04:22:46 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:47 --> Input Class Initialized
INFO - 2021-01-15 04:22:47 --> Language Class Initialized
INFO - 2021-01-15 04:22:47 --> Language Class Initialized
INFO - 2021-01-15 04:22:47 --> Config Class Initialized
INFO - 2021-01-15 04:22:47 --> Loader Class Initialized
INFO - 2021-01-15 04:22:47 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:47 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:47 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:47 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:47 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:47 --> Controller Class Initialized
INFO - 2021-01-15 04:22:47 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:47 --> Total execution time: 0.2847
INFO - 2021-01-15 04:22:50 --> Config Class Initialized
INFO - 2021-01-15 04:22:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:50 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:50 --> URI Class Initialized
INFO - 2021-01-15 04:22:50 --> Router Class Initialized
INFO - 2021-01-15 04:22:50 --> Output Class Initialized
INFO - 2021-01-15 04:22:50 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:50 --> Input Class Initialized
INFO - 2021-01-15 04:22:50 --> Language Class Initialized
INFO - 2021-01-15 04:22:50 --> Language Class Initialized
INFO - 2021-01-15 04:22:50 --> Config Class Initialized
INFO - 2021-01-15 04:22:50 --> Loader Class Initialized
INFO - 2021-01-15 04:22:50 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:50 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:50 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:50 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:50 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:50 --> Controller Class Initialized
INFO - 2021-01-15 04:22:50 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:50 --> Total execution time: 0.3468
INFO - 2021-01-15 04:22:52 --> Config Class Initialized
INFO - 2021-01-15 04:22:52 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:52 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:52 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:52 --> URI Class Initialized
INFO - 2021-01-15 04:22:52 --> Router Class Initialized
INFO - 2021-01-15 04:22:52 --> Output Class Initialized
INFO - 2021-01-15 04:22:52 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:52 --> Input Class Initialized
INFO - 2021-01-15 04:22:52 --> Language Class Initialized
INFO - 2021-01-15 04:22:52 --> Language Class Initialized
INFO - 2021-01-15 04:22:52 --> Config Class Initialized
INFO - 2021-01-15 04:22:52 --> Loader Class Initialized
INFO - 2021-01-15 04:22:52 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:52 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:52 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:52 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:52 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:52 --> Controller Class Initialized
INFO - 2021-01-15 04:22:52 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:52 --> Total execution time: 0.2262
INFO - 2021-01-15 04:22:56 --> Config Class Initialized
INFO - 2021-01-15 04:22:56 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:56 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:56 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:56 --> URI Class Initialized
INFO - 2021-01-15 04:22:56 --> Router Class Initialized
INFO - 2021-01-15 04:22:56 --> Output Class Initialized
INFO - 2021-01-15 04:22:56 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:56 --> Input Class Initialized
INFO - 2021-01-15 04:22:56 --> Language Class Initialized
INFO - 2021-01-15 04:22:56 --> Language Class Initialized
INFO - 2021-01-15 04:22:56 --> Config Class Initialized
INFO - 2021-01-15 04:22:56 --> Loader Class Initialized
INFO - 2021-01-15 04:22:56 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:56 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:56 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:56 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:56 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:57 --> Controller Class Initialized
INFO - 2021-01-15 04:22:57 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:57 --> Total execution time: 0.3553
INFO - 2021-01-15 04:22:59 --> Config Class Initialized
INFO - 2021-01-15 04:22:59 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:22:59 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:22:59 --> Utf8 Class Initialized
INFO - 2021-01-15 04:22:59 --> URI Class Initialized
INFO - 2021-01-15 04:22:59 --> Router Class Initialized
INFO - 2021-01-15 04:22:59 --> Output Class Initialized
INFO - 2021-01-15 04:22:59 --> Security Class Initialized
DEBUG - 2021-01-15 04:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:22:59 --> Input Class Initialized
INFO - 2021-01-15 04:22:59 --> Language Class Initialized
INFO - 2021-01-15 04:22:59 --> Language Class Initialized
INFO - 2021-01-15 04:22:59 --> Config Class Initialized
INFO - 2021-01-15 04:22:59 --> Loader Class Initialized
INFO - 2021-01-15 04:22:59 --> Helper loaded: url_helper
INFO - 2021-01-15 04:22:59 --> Helper loaded: file_helper
INFO - 2021-01-15 04:22:59 --> Helper loaded: form_helper
INFO - 2021-01-15 04:22:59 --> Helper loaded: my_helper
INFO - 2021-01-15 04:22:59 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:22:59 --> Controller Class Initialized
INFO - 2021-01-15 04:22:59 --> Final output sent to browser
DEBUG - 2021-01-15 04:22:59 --> Total execution time: 0.3427
INFO - 2021-01-15 04:23:05 --> Config Class Initialized
INFO - 2021-01-15 04:23:05 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:23:05 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:23:05 --> Utf8 Class Initialized
INFO - 2021-01-15 04:23:05 --> URI Class Initialized
INFO - 2021-01-15 04:23:05 --> Router Class Initialized
INFO - 2021-01-15 04:23:05 --> Output Class Initialized
INFO - 2021-01-15 04:23:05 --> Security Class Initialized
DEBUG - 2021-01-15 04:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:23:05 --> Input Class Initialized
INFO - 2021-01-15 04:23:05 --> Language Class Initialized
INFO - 2021-01-15 04:23:05 --> Language Class Initialized
INFO - 2021-01-15 04:23:05 --> Config Class Initialized
INFO - 2021-01-15 04:23:05 --> Loader Class Initialized
INFO - 2021-01-15 04:23:05 --> Helper loaded: url_helper
INFO - 2021-01-15 04:23:05 --> Helper loaded: file_helper
INFO - 2021-01-15 04:23:05 --> Helper loaded: form_helper
INFO - 2021-01-15 04:23:05 --> Helper loaded: my_helper
INFO - 2021-01-15 04:23:05 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:23:05 --> Controller Class Initialized
DEBUG - 2021-01-15 04:23:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:23:05 --> Final output sent to browser
DEBUG - 2021-01-15 04:23:05 --> Total execution time: 0.2667
INFO - 2021-01-15 04:23:20 --> Config Class Initialized
INFO - 2021-01-15 04:23:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:23:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:23:20 --> Utf8 Class Initialized
INFO - 2021-01-15 04:23:20 --> URI Class Initialized
INFO - 2021-01-15 04:23:20 --> Router Class Initialized
INFO - 2021-01-15 04:23:20 --> Output Class Initialized
INFO - 2021-01-15 04:23:20 --> Security Class Initialized
DEBUG - 2021-01-15 04:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:23:20 --> Input Class Initialized
INFO - 2021-01-15 04:23:20 --> Language Class Initialized
INFO - 2021-01-15 04:23:20 --> Language Class Initialized
INFO - 2021-01-15 04:23:20 --> Config Class Initialized
INFO - 2021-01-15 04:23:20 --> Loader Class Initialized
INFO - 2021-01-15 04:23:20 --> Helper loaded: url_helper
INFO - 2021-01-15 04:23:20 --> Helper loaded: file_helper
INFO - 2021-01-15 04:23:20 --> Helper loaded: form_helper
INFO - 2021-01-15 04:23:20 --> Helper loaded: my_helper
INFO - 2021-01-15 04:23:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:23:20 --> Controller Class Initialized
INFO - 2021-01-15 04:23:20 --> Helper loaded: cookie_helper
INFO - 2021-01-15 04:23:20 --> Config Class Initialized
INFO - 2021-01-15 04:23:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:23:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:23:20 --> Utf8 Class Initialized
INFO - 2021-01-15 04:23:20 --> URI Class Initialized
INFO - 2021-01-15 04:23:20 --> Router Class Initialized
INFO - 2021-01-15 04:23:20 --> Output Class Initialized
INFO - 2021-01-15 04:23:20 --> Security Class Initialized
DEBUG - 2021-01-15 04:23:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:23:20 --> Input Class Initialized
INFO - 2021-01-15 04:23:20 --> Language Class Initialized
INFO - 2021-01-15 04:23:20 --> Language Class Initialized
INFO - 2021-01-15 04:23:20 --> Config Class Initialized
INFO - 2021-01-15 04:23:20 --> Loader Class Initialized
INFO - 2021-01-15 04:23:20 --> Helper loaded: url_helper
INFO - 2021-01-15 04:23:20 --> Helper loaded: file_helper
INFO - 2021-01-15 04:23:20 --> Helper loaded: form_helper
INFO - 2021-01-15 04:23:20 --> Helper loaded: my_helper
INFO - 2021-01-15 04:23:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:23:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:23:20 --> Controller Class Initialized
DEBUG - 2021-01-15 04:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-15 04:23:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:23:20 --> Final output sent to browser
DEBUG - 2021-01-15 04:23:20 --> Total execution time: 0.3134
INFO - 2021-01-15 04:23:25 --> Config Class Initialized
INFO - 2021-01-15 04:23:25 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:23:25 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:23:25 --> Utf8 Class Initialized
INFO - 2021-01-15 04:23:25 --> URI Class Initialized
INFO - 2021-01-15 04:23:25 --> Router Class Initialized
INFO - 2021-01-15 04:23:25 --> Output Class Initialized
INFO - 2021-01-15 04:23:25 --> Security Class Initialized
DEBUG - 2021-01-15 04:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:23:25 --> Input Class Initialized
INFO - 2021-01-15 04:23:25 --> Language Class Initialized
INFO - 2021-01-15 04:23:25 --> Language Class Initialized
INFO - 2021-01-15 04:23:25 --> Config Class Initialized
INFO - 2021-01-15 04:23:25 --> Loader Class Initialized
INFO - 2021-01-15 04:23:25 --> Helper loaded: url_helper
INFO - 2021-01-15 04:23:25 --> Helper loaded: file_helper
INFO - 2021-01-15 04:23:25 --> Helper loaded: form_helper
INFO - 2021-01-15 04:23:25 --> Helper loaded: my_helper
INFO - 2021-01-15 04:23:25 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:23:25 --> Controller Class Initialized
INFO - 2021-01-15 04:23:25 --> Helper loaded: cookie_helper
INFO - 2021-01-15 04:23:25 --> Final output sent to browser
DEBUG - 2021-01-15 04:23:25 --> Total execution time: 0.3994
INFO - 2021-01-15 04:23:25 --> Config Class Initialized
INFO - 2021-01-15 04:23:25 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:23:25 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:23:25 --> Utf8 Class Initialized
INFO - 2021-01-15 04:23:25 --> URI Class Initialized
INFO - 2021-01-15 04:23:25 --> Router Class Initialized
INFO - 2021-01-15 04:23:25 --> Output Class Initialized
INFO - 2021-01-15 04:23:26 --> Security Class Initialized
DEBUG - 2021-01-15 04:23:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:23:26 --> Input Class Initialized
INFO - 2021-01-15 04:23:26 --> Language Class Initialized
INFO - 2021-01-15 04:23:26 --> Language Class Initialized
INFO - 2021-01-15 04:23:26 --> Config Class Initialized
INFO - 2021-01-15 04:23:26 --> Loader Class Initialized
INFO - 2021-01-15 04:23:26 --> Helper loaded: url_helper
INFO - 2021-01-15 04:23:26 --> Helper loaded: file_helper
INFO - 2021-01-15 04:23:26 --> Helper loaded: form_helper
INFO - 2021-01-15 04:23:26 --> Helper loaded: my_helper
INFO - 2021-01-15 04:23:26 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:23:26 --> Controller Class Initialized
DEBUG - 2021-01-15 04:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 04:23:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:23:26 --> Final output sent to browser
DEBUG - 2021-01-15 04:23:26 --> Total execution time: 0.4568
INFO - 2021-01-15 04:23:29 --> Config Class Initialized
INFO - 2021-01-15 04:23:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:23:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:23:29 --> Utf8 Class Initialized
INFO - 2021-01-15 04:23:29 --> URI Class Initialized
INFO - 2021-01-15 04:23:29 --> Router Class Initialized
INFO - 2021-01-15 04:23:29 --> Output Class Initialized
INFO - 2021-01-15 04:23:29 --> Security Class Initialized
DEBUG - 2021-01-15 04:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:23:29 --> Input Class Initialized
INFO - 2021-01-15 04:23:29 --> Language Class Initialized
INFO - 2021-01-15 04:23:29 --> Language Class Initialized
INFO - 2021-01-15 04:23:29 --> Config Class Initialized
INFO - 2021-01-15 04:23:29 --> Loader Class Initialized
INFO - 2021-01-15 04:23:29 --> Helper loaded: url_helper
INFO - 2021-01-15 04:23:29 --> Helper loaded: file_helper
INFO - 2021-01-15 04:23:29 --> Helper loaded: form_helper
INFO - 2021-01-15 04:23:29 --> Helper loaded: my_helper
INFO - 2021-01-15 04:23:29 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:23:29 --> Controller Class Initialized
DEBUG - 2021-01-15 04:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 04:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 04:23:29 --> Final output sent to browser
DEBUG - 2021-01-15 04:23:29 --> Total execution time: 0.3218
INFO - 2021-01-15 04:23:30 --> Config Class Initialized
INFO - 2021-01-15 04:23:30 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:23:30 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:23:30 --> Utf8 Class Initialized
INFO - 2021-01-15 04:23:30 --> URI Class Initialized
INFO - 2021-01-15 04:23:30 --> Router Class Initialized
INFO - 2021-01-15 04:23:30 --> Output Class Initialized
INFO - 2021-01-15 04:23:30 --> Security Class Initialized
DEBUG - 2021-01-15 04:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:23:30 --> Input Class Initialized
INFO - 2021-01-15 04:23:30 --> Language Class Initialized
INFO - 2021-01-15 04:23:30 --> Language Class Initialized
INFO - 2021-01-15 04:23:30 --> Config Class Initialized
INFO - 2021-01-15 04:23:30 --> Loader Class Initialized
INFO - 2021-01-15 04:23:30 --> Helper loaded: url_helper
INFO - 2021-01-15 04:23:30 --> Helper loaded: file_helper
INFO - 2021-01-15 04:23:30 --> Helper loaded: form_helper
INFO - 2021-01-15 04:23:30 --> Helper loaded: my_helper
INFO - 2021-01-15 04:23:30 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:23:30 --> Controller Class Initialized
DEBUG - 2021-01-15 04:23:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:23:30 --> Final output sent to browser
DEBUG - 2021-01-15 04:23:30 --> Total execution time: 0.3032
INFO - 2021-01-15 04:25:18 --> Config Class Initialized
INFO - 2021-01-15 04:25:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:25:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:25:18 --> Utf8 Class Initialized
INFO - 2021-01-15 04:25:18 --> URI Class Initialized
INFO - 2021-01-15 04:25:18 --> Router Class Initialized
INFO - 2021-01-15 04:25:18 --> Output Class Initialized
INFO - 2021-01-15 04:25:18 --> Security Class Initialized
DEBUG - 2021-01-15 04:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:25:18 --> Input Class Initialized
INFO - 2021-01-15 04:25:18 --> Language Class Initialized
ERROR - 2021-01-15 04:25:18 --> Severity: Parsing Error --> syntax error, unexpected '$nap' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 227
INFO - 2021-01-15 04:25:28 --> Config Class Initialized
INFO - 2021-01-15 04:25:28 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:25:28 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:25:28 --> Utf8 Class Initialized
INFO - 2021-01-15 04:25:28 --> URI Class Initialized
INFO - 2021-01-15 04:25:28 --> Router Class Initialized
INFO - 2021-01-15 04:25:28 --> Output Class Initialized
INFO - 2021-01-15 04:25:28 --> Security Class Initialized
DEBUG - 2021-01-15 04:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:25:28 --> Input Class Initialized
INFO - 2021-01-15 04:25:28 --> Language Class Initialized
INFO - 2021-01-15 04:25:28 --> Language Class Initialized
INFO - 2021-01-15 04:25:28 --> Config Class Initialized
INFO - 2021-01-15 04:25:28 --> Loader Class Initialized
INFO - 2021-01-15 04:25:28 --> Helper loaded: url_helper
INFO - 2021-01-15 04:25:28 --> Helper loaded: file_helper
INFO - 2021-01-15 04:25:28 --> Helper loaded: form_helper
INFO - 2021-01-15 04:25:28 --> Helper loaded: my_helper
INFO - 2021-01-15 04:25:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:25:28 --> Controller Class Initialized
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
ERROR - 2021-01-15 04:25:28 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 231
DEBUG - 2021-01-15 04:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:25:28 --> Final output sent to browser
DEBUG - 2021-01-15 04:25:28 --> Total execution time: 0.4844
INFO - 2021-01-15 04:26:11 --> Config Class Initialized
INFO - 2021-01-15 04:26:11 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:26:11 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:26:11 --> Utf8 Class Initialized
INFO - 2021-01-15 04:26:11 --> URI Class Initialized
INFO - 2021-01-15 04:26:11 --> Router Class Initialized
INFO - 2021-01-15 04:26:11 --> Output Class Initialized
INFO - 2021-01-15 04:26:11 --> Security Class Initialized
DEBUG - 2021-01-15 04:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:26:11 --> Input Class Initialized
INFO - 2021-01-15 04:26:11 --> Language Class Initialized
INFO - 2021-01-15 04:26:11 --> Language Class Initialized
INFO - 2021-01-15 04:26:11 --> Config Class Initialized
INFO - 2021-01-15 04:26:11 --> Loader Class Initialized
INFO - 2021-01-15 04:26:11 --> Helper loaded: url_helper
INFO - 2021-01-15 04:26:11 --> Helper loaded: file_helper
INFO - 2021-01-15 04:26:11 --> Helper loaded: form_helper
INFO - 2021-01-15 04:26:11 --> Helper loaded: my_helper
INFO - 2021-01-15 04:26:11 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:26:11 --> Controller Class Initialized
ERROR - 2021-01-15 04:26:11 --> Severity: Notice --> Undefined variable: jml_na C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 224
DEBUG - 2021-01-15 04:26:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:26:11 --> Final output sent to browser
DEBUG - 2021-01-15 04:26:11 --> Total execution time: 0.3077
INFO - 2021-01-15 04:27:01 --> Config Class Initialized
INFO - 2021-01-15 04:27:01 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:27:01 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:27:01 --> Utf8 Class Initialized
INFO - 2021-01-15 04:27:01 --> URI Class Initialized
INFO - 2021-01-15 04:27:01 --> Router Class Initialized
INFO - 2021-01-15 04:27:01 --> Output Class Initialized
INFO - 2021-01-15 04:27:01 --> Security Class Initialized
DEBUG - 2021-01-15 04:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:27:01 --> Input Class Initialized
INFO - 2021-01-15 04:27:01 --> Language Class Initialized
INFO - 2021-01-15 04:27:01 --> Language Class Initialized
INFO - 2021-01-15 04:27:01 --> Config Class Initialized
INFO - 2021-01-15 04:27:01 --> Loader Class Initialized
INFO - 2021-01-15 04:27:01 --> Helper loaded: url_helper
INFO - 2021-01-15 04:27:01 --> Helper loaded: file_helper
INFO - 2021-01-15 04:27:01 --> Helper loaded: form_helper
INFO - 2021-01-15 04:27:01 --> Helper loaded: my_helper
INFO - 2021-01-15 04:27:01 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:27:01 --> Controller Class Initialized
DEBUG - 2021-01-15 04:27:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:27:01 --> Final output sent to browser
DEBUG - 2021-01-15 04:27:01 --> Total execution time: 0.2961
INFO - 2021-01-15 04:28:01 --> Config Class Initialized
INFO - 2021-01-15 04:28:01 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:28:01 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:28:01 --> Utf8 Class Initialized
INFO - 2021-01-15 04:28:01 --> URI Class Initialized
INFO - 2021-01-15 04:28:01 --> Router Class Initialized
INFO - 2021-01-15 04:28:01 --> Output Class Initialized
INFO - 2021-01-15 04:28:01 --> Security Class Initialized
DEBUG - 2021-01-15 04:28:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:28:01 --> Input Class Initialized
INFO - 2021-01-15 04:28:01 --> Language Class Initialized
INFO - 2021-01-15 04:28:02 --> Language Class Initialized
INFO - 2021-01-15 04:28:02 --> Config Class Initialized
INFO - 2021-01-15 04:28:02 --> Loader Class Initialized
INFO - 2021-01-15 04:28:02 --> Helper loaded: url_helper
INFO - 2021-01-15 04:28:02 --> Helper loaded: file_helper
INFO - 2021-01-15 04:28:02 --> Helper loaded: form_helper
INFO - 2021-01-15 04:28:02 --> Helper loaded: my_helper
INFO - 2021-01-15 04:28:02 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:28:02 --> Controller Class Initialized
DEBUG - 2021-01-15 04:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:28:02 --> Final output sent to browser
DEBUG - 2021-01-15 04:28:02 --> Total execution time: 0.2881
INFO - 2021-01-15 04:41:37 --> Config Class Initialized
INFO - 2021-01-15 04:41:37 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:41:37 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:41:37 --> Utf8 Class Initialized
INFO - 2021-01-15 04:41:37 --> URI Class Initialized
INFO - 2021-01-15 04:41:37 --> Router Class Initialized
INFO - 2021-01-15 04:41:37 --> Output Class Initialized
INFO - 2021-01-15 04:41:37 --> Security Class Initialized
DEBUG - 2021-01-15 04:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:41:37 --> Input Class Initialized
INFO - 2021-01-15 04:41:37 --> Language Class Initialized
INFO - 2021-01-15 04:41:37 --> Language Class Initialized
INFO - 2021-01-15 04:41:37 --> Config Class Initialized
INFO - 2021-01-15 04:41:37 --> Loader Class Initialized
INFO - 2021-01-15 04:41:37 --> Helper loaded: url_helper
INFO - 2021-01-15 04:41:37 --> Helper loaded: file_helper
INFO - 2021-01-15 04:41:37 --> Helper loaded: form_helper
INFO - 2021-01-15 04:41:37 --> Helper loaded: my_helper
INFO - 2021-01-15 04:41:37 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:41:37 --> Controller Class Initialized
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
ERROR - 2021-01-15 04:41:37 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 240
DEBUG - 2021-01-15 04:41:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:41:37 --> Final output sent to browser
DEBUG - 2021-01-15 04:41:37 --> Total execution time: 0.4834
INFO - 2021-01-15 04:46:30 --> Config Class Initialized
INFO - 2021-01-15 04:46:30 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:46:30 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:46:30 --> Utf8 Class Initialized
INFO - 2021-01-15 04:46:30 --> URI Class Initialized
INFO - 2021-01-15 04:46:30 --> Router Class Initialized
INFO - 2021-01-15 04:46:30 --> Output Class Initialized
INFO - 2021-01-15 04:46:30 --> Security Class Initialized
DEBUG - 2021-01-15 04:46:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:46:30 --> Input Class Initialized
INFO - 2021-01-15 04:46:30 --> Language Class Initialized
INFO - 2021-01-15 04:46:30 --> Language Class Initialized
INFO - 2021-01-15 04:46:30 --> Config Class Initialized
INFO - 2021-01-15 04:46:30 --> Loader Class Initialized
INFO - 2021-01-15 04:46:30 --> Helper loaded: url_helper
INFO - 2021-01-15 04:46:30 --> Helper loaded: file_helper
INFO - 2021-01-15 04:46:30 --> Helper loaded: form_helper
INFO - 2021-01-15 04:46:30 --> Helper loaded: my_helper
INFO - 2021-01-15 04:46:30 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:46:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:46:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:46:30 --> Controller Class Initialized
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
ERROR - 2021-01-15 04:46:30 --> Severity: Warning --> Division by zero C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 242
DEBUG - 2021-01-15 04:46:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:46:30 --> Final output sent to browser
DEBUG - 2021-01-15 04:46:30 --> Total execution time: 0.4758
INFO - 2021-01-15 04:47:34 --> Config Class Initialized
INFO - 2021-01-15 04:47:34 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:47:34 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:47:34 --> Utf8 Class Initialized
INFO - 2021-01-15 04:47:34 --> URI Class Initialized
INFO - 2021-01-15 04:47:34 --> Router Class Initialized
INFO - 2021-01-15 04:47:34 --> Output Class Initialized
INFO - 2021-01-15 04:47:34 --> Security Class Initialized
DEBUG - 2021-01-15 04:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:47:35 --> Input Class Initialized
INFO - 2021-01-15 04:47:35 --> Language Class Initialized
INFO - 2021-01-15 04:47:35 --> Language Class Initialized
INFO - 2021-01-15 04:47:35 --> Config Class Initialized
INFO - 2021-01-15 04:47:35 --> Loader Class Initialized
INFO - 2021-01-15 04:47:35 --> Helper loaded: url_helper
INFO - 2021-01-15 04:47:35 --> Helper loaded: file_helper
INFO - 2021-01-15 04:47:35 --> Helper loaded: form_helper
INFO - 2021-01-15 04:47:35 --> Helper loaded: my_helper
INFO - 2021-01-15 04:47:35 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:47:35 --> Controller Class Initialized
DEBUG - 2021-01-15 04:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:47:35 --> Final output sent to browser
DEBUG - 2021-01-15 04:47:35 --> Total execution time: 0.2929
INFO - 2021-01-15 04:49:48 --> Config Class Initialized
INFO - 2021-01-15 04:49:48 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:49:48 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:49:48 --> Utf8 Class Initialized
INFO - 2021-01-15 04:49:48 --> URI Class Initialized
INFO - 2021-01-15 04:49:48 --> Router Class Initialized
INFO - 2021-01-15 04:49:48 --> Output Class Initialized
INFO - 2021-01-15 04:49:48 --> Security Class Initialized
DEBUG - 2021-01-15 04:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:49:48 --> Input Class Initialized
INFO - 2021-01-15 04:49:48 --> Language Class Initialized
INFO - 2021-01-15 04:49:48 --> Language Class Initialized
INFO - 2021-01-15 04:49:48 --> Config Class Initialized
INFO - 2021-01-15 04:49:48 --> Loader Class Initialized
INFO - 2021-01-15 04:49:48 --> Helper loaded: url_helper
INFO - 2021-01-15 04:49:48 --> Helper loaded: file_helper
INFO - 2021-01-15 04:49:48 --> Helper loaded: form_helper
INFO - 2021-01-15 04:49:48 --> Helper loaded: my_helper
INFO - 2021-01-15 04:49:48 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:49:48 --> Controller Class Initialized
DEBUG - 2021-01-15 04:49:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:49:48 --> Final output sent to browser
DEBUG - 2021-01-15 04:49:48 --> Total execution time: 0.2924
INFO - 2021-01-15 04:49:58 --> Config Class Initialized
INFO - 2021-01-15 04:49:58 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:49:59 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:49:59 --> Utf8 Class Initialized
INFO - 2021-01-15 04:49:59 --> URI Class Initialized
INFO - 2021-01-15 04:49:59 --> Router Class Initialized
INFO - 2021-01-15 04:49:59 --> Output Class Initialized
INFO - 2021-01-15 04:49:59 --> Security Class Initialized
DEBUG - 2021-01-15 04:49:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:49:59 --> Input Class Initialized
INFO - 2021-01-15 04:49:59 --> Language Class Initialized
INFO - 2021-01-15 04:49:59 --> Language Class Initialized
INFO - 2021-01-15 04:49:59 --> Config Class Initialized
INFO - 2021-01-15 04:49:59 --> Loader Class Initialized
INFO - 2021-01-15 04:49:59 --> Helper loaded: url_helper
INFO - 2021-01-15 04:49:59 --> Helper loaded: file_helper
INFO - 2021-01-15 04:49:59 --> Helper loaded: form_helper
INFO - 2021-01-15 04:49:59 --> Helper loaded: my_helper
INFO - 2021-01-15 04:49:59 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:49:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:49:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:49:59 --> Controller Class Initialized
DEBUG - 2021-01-15 04:49:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:49:59 --> Final output sent to browser
DEBUG - 2021-01-15 04:49:59 --> Total execution time: 0.3713
INFO - 2021-01-15 04:50:06 --> Config Class Initialized
INFO - 2021-01-15 04:50:06 --> Hooks Class Initialized
DEBUG - 2021-01-15 04:50:06 --> UTF-8 Support Enabled
INFO - 2021-01-15 04:50:06 --> Utf8 Class Initialized
INFO - 2021-01-15 04:50:06 --> URI Class Initialized
INFO - 2021-01-15 04:50:06 --> Router Class Initialized
INFO - 2021-01-15 04:50:06 --> Output Class Initialized
INFO - 2021-01-15 04:50:06 --> Security Class Initialized
DEBUG - 2021-01-15 04:50:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 04:50:06 --> Input Class Initialized
INFO - 2021-01-15 04:50:06 --> Language Class Initialized
INFO - 2021-01-15 04:50:06 --> Language Class Initialized
INFO - 2021-01-15 04:50:06 --> Config Class Initialized
INFO - 2021-01-15 04:50:06 --> Loader Class Initialized
INFO - 2021-01-15 04:50:06 --> Helper loaded: url_helper
INFO - 2021-01-15 04:50:06 --> Helper loaded: file_helper
INFO - 2021-01-15 04:50:07 --> Helper loaded: form_helper
INFO - 2021-01-15 04:50:07 --> Helper loaded: my_helper
INFO - 2021-01-15 04:50:07 --> Database Driver Class Initialized
DEBUG - 2021-01-15 04:50:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 04:50:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 04:50:07 --> Controller Class Initialized
DEBUG - 2021-01-15 04:50:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 04:50:07 --> Final output sent to browser
DEBUG - 2021-01-15 04:50:07 --> Total execution time: 0.2806
INFO - 2021-01-15 05:05:03 --> Config Class Initialized
INFO - 2021-01-15 05:05:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:03 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:03 --> URI Class Initialized
INFO - 2021-01-15 05:05:03 --> Router Class Initialized
INFO - 2021-01-15 05:05:03 --> Output Class Initialized
INFO - 2021-01-15 05:05:03 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:03 --> Input Class Initialized
INFO - 2021-01-15 05:05:03 --> Language Class Initialized
INFO - 2021-01-15 05:05:03 --> Language Class Initialized
INFO - 2021-01-15 05:05:03 --> Config Class Initialized
INFO - 2021-01-15 05:05:03 --> Loader Class Initialized
INFO - 2021-01-15 05:05:03 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:03 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:03 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:03 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:03 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:03 --> Controller Class Initialized
INFO - 2021-01-15 05:05:03 --> Helper loaded: cookie_helper
INFO - 2021-01-15 05:05:03 --> Config Class Initialized
INFO - 2021-01-15 05:05:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:03 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:03 --> URI Class Initialized
INFO - 2021-01-15 05:05:03 --> Router Class Initialized
INFO - 2021-01-15 05:05:03 --> Output Class Initialized
INFO - 2021-01-15 05:05:03 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:03 --> Input Class Initialized
INFO - 2021-01-15 05:05:03 --> Language Class Initialized
INFO - 2021-01-15 05:05:03 --> Language Class Initialized
INFO - 2021-01-15 05:05:03 --> Config Class Initialized
INFO - 2021-01-15 05:05:03 --> Loader Class Initialized
INFO - 2021-01-15 05:05:03 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:03 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:03 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:03 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:03 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:03 --> Controller Class Initialized
DEBUG - 2021-01-15 05:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-15 05:05:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:05:03 --> Final output sent to browser
DEBUG - 2021-01-15 05:05:03 --> Total execution time: 0.3361
INFO - 2021-01-15 05:05:09 --> Config Class Initialized
INFO - 2021-01-15 05:05:09 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:09 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:09 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:09 --> URI Class Initialized
INFO - 2021-01-15 05:05:09 --> Router Class Initialized
INFO - 2021-01-15 05:05:09 --> Output Class Initialized
INFO - 2021-01-15 05:05:09 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:09 --> Input Class Initialized
INFO - 2021-01-15 05:05:09 --> Language Class Initialized
INFO - 2021-01-15 05:05:09 --> Language Class Initialized
INFO - 2021-01-15 05:05:09 --> Config Class Initialized
INFO - 2021-01-15 05:05:09 --> Loader Class Initialized
INFO - 2021-01-15 05:05:09 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:09 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:09 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:09 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:09 --> Controller Class Initialized
INFO - 2021-01-15 05:05:09 --> Helper loaded: cookie_helper
INFO - 2021-01-15 05:05:09 --> Final output sent to browser
DEBUG - 2021-01-15 05:05:09 --> Total execution time: 0.3982
INFO - 2021-01-15 05:05:10 --> Config Class Initialized
INFO - 2021-01-15 05:05:11 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:11 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:11 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:11 --> URI Class Initialized
INFO - 2021-01-15 05:05:11 --> Router Class Initialized
INFO - 2021-01-15 05:05:11 --> Output Class Initialized
INFO - 2021-01-15 05:05:11 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:11 --> Input Class Initialized
INFO - 2021-01-15 05:05:11 --> Language Class Initialized
INFO - 2021-01-15 05:05:11 --> Language Class Initialized
INFO - 2021-01-15 05:05:11 --> Config Class Initialized
INFO - 2021-01-15 05:05:11 --> Loader Class Initialized
INFO - 2021-01-15 05:05:11 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:11 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:11 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:11 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:11 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:11 --> Controller Class Initialized
DEBUG - 2021-01-15 05:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 05:05:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:05:11 --> Final output sent to browser
DEBUG - 2021-01-15 05:05:11 --> Total execution time: 0.4820
INFO - 2021-01-15 05:05:13 --> Config Class Initialized
INFO - 2021-01-15 05:05:13 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:13 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:13 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:13 --> URI Class Initialized
INFO - 2021-01-15 05:05:13 --> Router Class Initialized
INFO - 2021-01-15 05:05:13 --> Output Class Initialized
INFO - 2021-01-15 05:05:13 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:13 --> Input Class Initialized
INFO - 2021-01-15 05:05:13 --> Language Class Initialized
INFO - 2021-01-15 05:05:13 --> Language Class Initialized
INFO - 2021-01-15 05:05:13 --> Config Class Initialized
INFO - 2021-01-15 05:05:13 --> Loader Class Initialized
INFO - 2021-01-15 05:05:13 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:13 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:13 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:13 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:13 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:13 --> Controller Class Initialized
INFO - 2021-01-15 05:05:16 --> Config Class Initialized
INFO - 2021-01-15 05:05:16 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:16 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:16 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:16 --> URI Class Initialized
INFO - 2021-01-15 05:05:16 --> Router Class Initialized
INFO - 2021-01-15 05:05:17 --> Output Class Initialized
INFO - 2021-01-15 05:05:17 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:17 --> Input Class Initialized
INFO - 2021-01-15 05:05:17 --> Language Class Initialized
INFO - 2021-01-15 05:05:17 --> Language Class Initialized
INFO - 2021-01-15 05:05:17 --> Config Class Initialized
INFO - 2021-01-15 05:05:17 --> Loader Class Initialized
INFO - 2021-01-15 05:05:17 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:17 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:17 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:17 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:17 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:17 --> Controller Class Initialized
DEBUG - 2021-01-15 05:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:05:17 --> Final output sent to browser
DEBUG - 2021-01-15 05:05:17 --> Total execution time: 0.4097
INFO - 2021-01-15 05:05:17 --> Config Class Initialized
INFO - 2021-01-15 05:05:17 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:18 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:18 --> URI Class Initialized
INFO - 2021-01-15 05:05:18 --> Router Class Initialized
INFO - 2021-01-15 05:05:18 --> Output Class Initialized
INFO - 2021-01-15 05:05:18 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:18 --> Input Class Initialized
INFO - 2021-01-15 05:05:18 --> Language Class Initialized
INFO - 2021-01-15 05:05:18 --> Language Class Initialized
INFO - 2021-01-15 05:05:18 --> Config Class Initialized
INFO - 2021-01-15 05:05:18 --> Loader Class Initialized
INFO - 2021-01-15 05:05:18 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:18 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:18 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:18 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:18 --> Controller Class Initialized
INFO - 2021-01-15 05:05:32 --> Config Class Initialized
INFO - 2021-01-15 05:05:32 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:05:32 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:05:32 --> Utf8 Class Initialized
INFO - 2021-01-15 05:05:32 --> URI Class Initialized
INFO - 2021-01-15 05:05:32 --> Router Class Initialized
INFO - 2021-01-15 05:05:32 --> Output Class Initialized
INFO - 2021-01-15 05:05:32 --> Security Class Initialized
DEBUG - 2021-01-15 05:05:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:05:32 --> Input Class Initialized
INFO - 2021-01-15 05:05:32 --> Language Class Initialized
INFO - 2021-01-15 05:05:32 --> Language Class Initialized
INFO - 2021-01-15 05:05:32 --> Config Class Initialized
INFO - 2021-01-15 05:05:32 --> Loader Class Initialized
INFO - 2021-01-15 05:05:32 --> Helper loaded: url_helper
INFO - 2021-01-15 05:05:32 --> Helper loaded: file_helper
INFO - 2021-01-15 05:05:32 --> Helper loaded: form_helper
INFO - 2021-01-15 05:05:32 --> Helper loaded: my_helper
INFO - 2021-01-15 05:05:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:05:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:05:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:05:32 --> Controller Class Initialized
INFO - 2021-01-15 05:06:03 --> Config Class Initialized
INFO - 2021-01-15 05:06:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:06:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:06:03 --> Utf8 Class Initialized
INFO - 2021-01-15 05:06:03 --> URI Class Initialized
INFO - 2021-01-15 05:06:03 --> Router Class Initialized
INFO - 2021-01-15 05:06:03 --> Output Class Initialized
INFO - 2021-01-15 05:06:03 --> Security Class Initialized
DEBUG - 2021-01-15 05:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:06:03 --> Input Class Initialized
INFO - 2021-01-15 05:06:03 --> Language Class Initialized
INFO - 2021-01-15 05:06:03 --> Language Class Initialized
INFO - 2021-01-15 05:06:03 --> Config Class Initialized
INFO - 2021-01-15 05:06:03 --> Loader Class Initialized
INFO - 2021-01-15 05:06:03 --> Helper loaded: url_helper
INFO - 2021-01-15 05:06:03 --> Helper loaded: file_helper
INFO - 2021-01-15 05:06:03 --> Helper loaded: form_helper
INFO - 2021-01-15 05:06:03 --> Helper loaded: my_helper
INFO - 2021-01-15 05:06:03 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:06:03 --> Controller Class Initialized
DEBUG - 2021-01-15 05:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 05:06:03 --> Final output sent to browser
DEBUG - 2021-01-15 05:06:03 --> Total execution time: 0.3028
INFO - 2021-01-15 05:08:43 --> Config Class Initialized
INFO - 2021-01-15 05:08:43 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:08:43 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:08:43 --> Utf8 Class Initialized
INFO - 2021-01-15 05:08:43 --> URI Class Initialized
INFO - 2021-01-15 05:08:43 --> Router Class Initialized
INFO - 2021-01-15 05:08:43 --> Output Class Initialized
INFO - 2021-01-15 05:08:44 --> Security Class Initialized
DEBUG - 2021-01-15 05:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:08:44 --> Input Class Initialized
INFO - 2021-01-15 05:08:44 --> Language Class Initialized
ERROR - 2021-01-15 05:08:44 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 385
INFO - 2021-01-15 05:08:52 --> Config Class Initialized
INFO - 2021-01-15 05:08:52 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:08:52 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:08:52 --> Utf8 Class Initialized
INFO - 2021-01-15 05:08:52 --> URI Class Initialized
INFO - 2021-01-15 05:08:53 --> Router Class Initialized
INFO - 2021-01-15 05:08:53 --> Output Class Initialized
INFO - 2021-01-15 05:08:53 --> Security Class Initialized
DEBUG - 2021-01-15 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:08:53 --> Input Class Initialized
INFO - 2021-01-15 05:08:53 --> Language Class Initialized
ERROR - 2021-01-15 05:08:53 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 385
INFO - 2021-01-15 05:08:55 --> Config Class Initialized
INFO - 2021-01-15 05:08:55 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:08:55 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:08:55 --> Utf8 Class Initialized
INFO - 2021-01-15 05:08:55 --> URI Class Initialized
INFO - 2021-01-15 05:08:55 --> Router Class Initialized
INFO - 2021-01-15 05:08:55 --> Output Class Initialized
INFO - 2021-01-15 05:08:55 --> Security Class Initialized
DEBUG - 2021-01-15 05:08:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:08:55 --> Input Class Initialized
INFO - 2021-01-15 05:08:55 --> Language Class Initialized
INFO - 2021-01-15 05:08:55 --> Language Class Initialized
INFO - 2021-01-15 05:08:55 --> Config Class Initialized
INFO - 2021-01-15 05:08:55 --> Loader Class Initialized
INFO - 2021-01-15 05:08:55 --> Helper loaded: url_helper
INFO - 2021-01-15 05:08:55 --> Helper loaded: file_helper
INFO - 2021-01-15 05:08:55 --> Helper loaded: form_helper
INFO - 2021-01-15 05:08:55 --> Helper loaded: my_helper
INFO - 2021-01-15 05:08:55 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:08:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:08:55 --> Controller Class Initialized
DEBUG - 2021-01-15 05:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 05:08:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:08:55 --> Final output sent to browser
DEBUG - 2021-01-15 05:08:55 --> Total execution time: 0.3189
INFO - 2021-01-15 05:08:57 --> Config Class Initialized
INFO - 2021-01-15 05:08:58 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:08:58 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:08:58 --> Utf8 Class Initialized
INFO - 2021-01-15 05:08:58 --> URI Class Initialized
INFO - 2021-01-15 05:08:58 --> Router Class Initialized
INFO - 2021-01-15 05:08:58 --> Output Class Initialized
INFO - 2021-01-15 05:08:58 --> Security Class Initialized
DEBUG - 2021-01-15 05:08:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:08:58 --> Input Class Initialized
INFO - 2021-01-15 05:08:58 --> Language Class Initialized
INFO - 2021-01-15 05:08:58 --> Language Class Initialized
INFO - 2021-01-15 05:08:58 --> Config Class Initialized
INFO - 2021-01-15 05:08:58 --> Loader Class Initialized
INFO - 2021-01-15 05:08:58 --> Helper loaded: url_helper
INFO - 2021-01-15 05:08:58 --> Helper loaded: file_helper
INFO - 2021-01-15 05:08:58 --> Helper loaded: form_helper
INFO - 2021-01-15 05:08:58 --> Helper loaded: my_helper
INFO - 2021-01-15 05:08:58 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:08:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:08:58 --> Controller Class Initialized
DEBUG - 2021-01-15 05:08:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-01-15 05:08:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:08:58 --> Final output sent to browser
DEBUG - 2021-01-15 05:08:58 --> Total execution time: 0.3290
INFO - 2021-01-15 05:08:59 --> Config Class Initialized
INFO - 2021-01-15 05:08:59 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:08:59 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:08:59 --> Utf8 Class Initialized
INFO - 2021-01-15 05:08:59 --> URI Class Initialized
INFO - 2021-01-15 05:08:59 --> Router Class Initialized
INFO - 2021-01-15 05:08:59 --> Output Class Initialized
INFO - 2021-01-15 05:08:59 --> Security Class Initialized
DEBUG - 2021-01-15 05:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:08:59 --> Input Class Initialized
INFO - 2021-01-15 05:08:59 --> Language Class Initialized
ERROR - 2021-01-15 05:08:59 --> Severity: Parsing Error --> syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 385
INFO - 2021-01-15 05:10:02 --> Config Class Initialized
INFO - 2021-01-15 05:10:02 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:10:02 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:10:02 --> Utf8 Class Initialized
INFO - 2021-01-15 05:10:02 --> URI Class Initialized
INFO - 2021-01-15 05:10:02 --> Router Class Initialized
INFO - 2021-01-15 05:10:02 --> Output Class Initialized
INFO - 2021-01-15 05:10:02 --> Security Class Initialized
DEBUG - 2021-01-15 05:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:10:02 --> Input Class Initialized
INFO - 2021-01-15 05:10:02 --> Language Class Initialized
ERROR - 2021-01-15 05:10:02 --> Severity: Parsing Error --> syntax error, unexpected end of file, expecting function (T_FUNCTION) C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 383
INFO - 2021-01-15 05:10:16 --> Config Class Initialized
INFO - 2021-01-15 05:10:16 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:10:16 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:10:16 --> Utf8 Class Initialized
INFO - 2021-01-15 05:10:16 --> URI Class Initialized
INFO - 2021-01-15 05:10:16 --> Router Class Initialized
INFO - 2021-01-15 05:10:16 --> Output Class Initialized
INFO - 2021-01-15 05:10:16 --> Security Class Initialized
DEBUG - 2021-01-15 05:10:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:10:16 --> Input Class Initialized
INFO - 2021-01-15 05:10:16 --> Language Class Initialized
INFO - 2021-01-15 05:10:16 --> Language Class Initialized
INFO - 2021-01-15 05:10:16 --> Config Class Initialized
INFO - 2021-01-15 05:10:16 --> Loader Class Initialized
INFO - 2021-01-15 05:10:16 --> Helper loaded: url_helper
INFO - 2021-01-15 05:10:16 --> Helper loaded: file_helper
INFO - 2021-01-15 05:10:16 --> Helper loaded: form_helper
INFO - 2021-01-15 05:10:16 --> Helper loaded: my_helper
INFO - 2021-01-15 05:10:16 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:10:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:10:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:10:16 --> Controller Class Initialized
DEBUG - 2021-01-15 05:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:10:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:10:16 --> Final output sent to browser
DEBUG - 2021-01-15 05:10:16 --> Total execution time: 0.3053
INFO - 2021-01-15 05:11:17 --> Config Class Initialized
INFO - 2021-01-15 05:11:17 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:11:17 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:11:17 --> Utf8 Class Initialized
INFO - 2021-01-15 05:11:17 --> URI Class Initialized
INFO - 2021-01-15 05:11:17 --> Router Class Initialized
INFO - 2021-01-15 05:11:17 --> Output Class Initialized
INFO - 2021-01-15 05:11:17 --> Security Class Initialized
DEBUG - 2021-01-15 05:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:11:17 --> Input Class Initialized
INFO - 2021-01-15 05:11:17 --> Language Class Initialized
INFO - 2021-01-15 05:11:17 --> Language Class Initialized
INFO - 2021-01-15 05:11:17 --> Config Class Initialized
INFO - 2021-01-15 05:11:17 --> Loader Class Initialized
INFO - 2021-01-15 05:11:17 --> Helper loaded: url_helper
INFO - 2021-01-15 05:11:17 --> Helper loaded: file_helper
INFO - 2021-01-15 05:11:17 --> Helper loaded: form_helper
INFO - 2021-01-15 05:11:17 --> Helper loaded: my_helper
INFO - 2021-01-15 05:11:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:11:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:11:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:11:18 --> Controller Class Initialized
DEBUG - 2021-01-15 05:11:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:11:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:11:18 --> Final output sent to browser
DEBUG - 2021-01-15 05:11:18 --> Total execution time: 0.3063
INFO - 2021-01-15 05:11:19 --> Config Class Initialized
INFO - 2021-01-15 05:11:19 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:11:19 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:11:19 --> Utf8 Class Initialized
INFO - 2021-01-15 05:11:19 --> URI Class Initialized
INFO - 2021-01-15 05:11:19 --> Router Class Initialized
INFO - 2021-01-15 05:11:19 --> Output Class Initialized
INFO - 2021-01-15 05:11:19 --> Security Class Initialized
DEBUG - 2021-01-15 05:11:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:11:19 --> Input Class Initialized
INFO - 2021-01-15 05:11:19 --> Language Class Initialized
INFO - 2021-01-15 05:11:19 --> Language Class Initialized
INFO - 2021-01-15 05:11:19 --> Config Class Initialized
INFO - 2021-01-15 05:11:19 --> Loader Class Initialized
INFO - 2021-01-15 05:11:19 --> Helper loaded: url_helper
INFO - 2021-01-15 05:11:19 --> Helper loaded: file_helper
INFO - 2021-01-15 05:11:19 --> Helper loaded: form_helper
INFO - 2021-01-15 05:11:19 --> Helper loaded: my_helper
INFO - 2021-01-15 05:11:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:11:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:11:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:11:20 --> Controller Class Initialized
DEBUG - 2021-01-15 05:11:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 05:11:20 --> Final output sent to browser
DEBUG - 2021-01-15 05:11:20 --> Total execution time: 0.3551
INFO - 2021-01-15 05:11:21 --> Config Class Initialized
INFO - 2021-01-15 05:11:21 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:11:21 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:11:21 --> Utf8 Class Initialized
INFO - 2021-01-15 05:11:21 --> URI Class Initialized
INFO - 2021-01-15 05:11:21 --> Router Class Initialized
INFO - 2021-01-15 05:11:21 --> Output Class Initialized
INFO - 2021-01-15 05:11:21 --> Security Class Initialized
DEBUG - 2021-01-15 05:11:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:11:21 --> Input Class Initialized
INFO - 2021-01-15 05:11:21 --> Language Class Initialized
ERROR - 2021-01-15 05:11:21 --> 404 Page Not Found: ../modules/cetak_leger/controllers/Cetak_leger/cetak_ekstra
INFO - 2021-01-15 05:24:22 --> Config Class Initialized
INFO - 2021-01-15 05:24:22 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:24:22 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:24:22 --> Utf8 Class Initialized
INFO - 2021-01-15 05:24:22 --> URI Class Initialized
INFO - 2021-01-15 05:24:22 --> Router Class Initialized
INFO - 2021-01-15 05:24:22 --> Output Class Initialized
INFO - 2021-01-15 05:24:22 --> Security Class Initialized
DEBUG - 2021-01-15 05:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:24:22 --> Input Class Initialized
INFO - 2021-01-15 05:24:22 --> Language Class Initialized
INFO - 2021-01-15 05:24:22 --> Language Class Initialized
INFO - 2021-01-15 05:24:22 --> Config Class Initialized
INFO - 2021-01-15 05:24:22 --> Loader Class Initialized
INFO - 2021-01-15 05:24:22 --> Helper loaded: url_helper
INFO - 2021-01-15 05:24:22 --> Helper loaded: file_helper
INFO - 2021-01-15 05:24:22 --> Helper loaded: form_helper
INFO - 2021-01-15 05:24:22 --> Helper loaded: my_helper
INFO - 2021-01-15 05:24:22 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:24:22 --> Controller Class Initialized
DEBUG - 2021-01-15 05:24:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 05:24:22 --> Final output sent to browser
DEBUG - 2021-01-15 05:24:22 --> Total execution time: 0.3065
INFO - 2021-01-15 05:24:23 --> Config Class Initialized
INFO - 2021-01-15 05:24:23 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:24:23 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:24:23 --> Utf8 Class Initialized
INFO - 2021-01-15 05:24:23 --> URI Class Initialized
INFO - 2021-01-15 05:24:23 --> Router Class Initialized
INFO - 2021-01-15 05:24:23 --> Output Class Initialized
INFO - 2021-01-15 05:24:23 --> Security Class Initialized
DEBUG - 2021-01-15 05:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:24:23 --> Input Class Initialized
INFO - 2021-01-15 05:24:23 --> Language Class Initialized
INFO - 2021-01-15 05:24:23 --> Language Class Initialized
INFO - 2021-01-15 05:24:23 --> Config Class Initialized
INFO - 2021-01-15 05:24:23 --> Loader Class Initialized
INFO - 2021-01-15 05:24:23 --> Helper loaded: url_helper
INFO - 2021-01-15 05:24:23 --> Helper loaded: file_helper
INFO - 2021-01-15 05:24:23 --> Helper loaded: form_helper
INFO - 2021-01-15 05:24:23 --> Helper loaded: my_helper
INFO - 2021-01-15 05:24:23 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:24:23 --> Controller Class Initialized
DEBUG - 2021-01-15 05:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-15 05:24:23 --> Final output sent to browser
DEBUG - 2021-01-15 05:24:23 --> Total execution time: 0.3014
INFO - 2021-01-15 05:24:33 --> Config Class Initialized
INFO - 2021-01-15 05:24:33 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:24:33 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:24:33 --> Utf8 Class Initialized
INFO - 2021-01-15 05:24:33 --> URI Class Initialized
INFO - 2021-01-15 05:24:33 --> Router Class Initialized
INFO - 2021-01-15 05:24:33 --> Output Class Initialized
INFO - 2021-01-15 05:24:33 --> Security Class Initialized
DEBUG - 2021-01-15 05:24:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:24:33 --> Input Class Initialized
INFO - 2021-01-15 05:24:33 --> Language Class Initialized
INFO - 2021-01-15 05:24:33 --> Language Class Initialized
INFO - 2021-01-15 05:24:33 --> Config Class Initialized
INFO - 2021-01-15 05:24:33 --> Loader Class Initialized
INFO - 2021-01-15 05:24:34 --> Helper loaded: url_helper
INFO - 2021-01-15 05:24:34 --> Helper loaded: file_helper
INFO - 2021-01-15 05:24:34 --> Helper loaded: form_helper
INFO - 2021-01-15 05:24:34 --> Helper loaded: my_helper
INFO - 2021-01-15 05:24:34 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:24:34 --> Controller Class Initialized
INFO - 2021-01-15 05:24:51 --> Config Class Initialized
INFO - 2021-01-15 05:24:51 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:24:51 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:24:51 --> Utf8 Class Initialized
INFO - 2021-01-15 05:24:51 --> URI Class Initialized
INFO - 2021-01-15 05:24:51 --> Router Class Initialized
INFO - 2021-01-15 05:24:51 --> Output Class Initialized
INFO - 2021-01-15 05:24:51 --> Security Class Initialized
DEBUG - 2021-01-15 05:24:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:24:51 --> Input Class Initialized
INFO - 2021-01-15 05:24:51 --> Language Class Initialized
INFO - 2021-01-15 05:24:51 --> Language Class Initialized
INFO - 2021-01-15 05:24:51 --> Config Class Initialized
INFO - 2021-01-15 05:24:51 --> Loader Class Initialized
INFO - 2021-01-15 05:24:51 --> Helper loaded: url_helper
INFO - 2021-01-15 05:24:51 --> Helper loaded: file_helper
INFO - 2021-01-15 05:24:51 --> Helper loaded: form_helper
INFO - 2021-01-15 05:24:51 --> Helper loaded: my_helper
INFO - 2021-01-15 05:24:51 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:24:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:24:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:24:51 --> Controller Class Initialized
INFO - 2021-01-15 05:25:28 --> Config Class Initialized
INFO - 2021-01-15 05:25:28 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:25:28 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:25:28 --> Utf8 Class Initialized
INFO - 2021-01-15 05:25:28 --> URI Class Initialized
INFO - 2021-01-15 05:25:28 --> Router Class Initialized
INFO - 2021-01-15 05:25:28 --> Output Class Initialized
INFO - 2021-01-15 05:25:28 --> Security Class Initialized
DEBUG - 2021-01-15 05:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:25:28 --> Input Class Initialized
INFO - 2021-01-15 05:25:28 --> Language Class Initialized
INFO - 2021-01-15 05:25:28 --> Language Class Initialized
INFO - 2021-01-15 05:25:28 --> Config Class Initialized
INFO - 2021-01-15 05:25:28 --> Loader Class Initialized
INFO - 2021-01-15 05:25:28 --> Helper loaded: url_helper
INFO - 2021-01-15 05:25:28 --> Helper loaded: file_helper
INFO - 2021-01-15 05:25:28 --> Helper loaded: form_helper
INFO - 2021-01-15 05:25:28 --> Helper loaded: my_helper
INFO - 2021-01-15 05:25:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:25:28 --> Controller Class Initialized
INFO - 2021-01-15 05:26:15 --> Config Class Initialized
INFO - 2021-01-15 05:26:15 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:26:15 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:26:15 --> Utf8 Class Initialized
INFO - 2021-01-15 05:26:15 --> URI Class Initialized
INFO - 2021-01-15 05:26:15 --> Router Class Initialized
INFO - 2021-01-15 05:26:15 --> Output Class Initialized
INFO - 2021-01-15 05:26:15 --> Security Class Initialized
DEBUG - 2021-01-15 05:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:26:15 --> Input Class Initialized
INFO - 2021-01-15 05:26:15 --> Language Class Initialized
INFO - 2021-01-15 05:26:15 --> Language Class Initialized
INFO - 2021-01-15 05:26:15 --> Config Class Initialized
INFO - 2021-01-15 05:26:15 --> Loader Class Initialized
INFO - 2021-01-15 05:26:15 --> Helper loaded: url_helper
INFO - 2021-01-15 05:26:15 --> Helper loaded: file_helper
INFO - 2021-01-15 05:26:15 --> Helper loaded: form_helper
INFO - 2021-01-15 05:26:15 --> Helper loaded: my_helper
INFO - 2021-01-15 05:26:15 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:26:15 --> Controller Class Initialized
DEBUG - 2021-01-15 05:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:26:15 --> Final output sent to browser
DEBUG - 2021-01-15 05:26:15 --> Total execution time: 0.3306
INFO - 2021-01-15 05:26:16 --> Config Class Initialized
INFO - 2021-01-15 05:26:16 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:26:16 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:26:16 --> Utf8 Class Initialized
INFO - 2021-01-15 05:26:16 --> URI Class Initialized
INFO - 2021-01-15 05:26:16 --> Router Class Initialized
INFO - 2021-01-15 05:26:16 --> Output Class Initialized
INFO - 2021-01-15 05:26:16 --> Security Class Initialized
DEBUG - 2021-01-15 05:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:26:16 --> Input Class Initialized
INFO - 2021-01-15 05:26:16 --> Language Class Initialized
INFO - 2021-01-15 05:26:16 --> Language Class Initialized
INFO - 2021-01-15 05:26:16 --> Config Class Initialized
INFO - 2021-01-15 05:26:16 --> Loader Class Initialized
INFO - 2021-01-15 05:26:16 --> Helper loaded: url_helper
INFO - 2021-01-15 05:26:16 --> Helper loaded: file_helper
INFO - 2021-01-15 05:26:16 --> Helper loaded: form_helper
INFO - 2021-01-15 05:26:16 --> Helper loaded: my_helper
INFO - 2021-01-15 05:26:16 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:26:17 --> Controller Class Initialized
DEBUG - 2021-01-15 05:26:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-15 05:26:17 --> Final output sent to browser
DEBUG - 2021-01-15 05:26:17 --> Total execution time: 0.3339
INFO - 2021-01-15 05:27:05 --> Config Class Initialized
INFO - 2021-01-15 05:27:05 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:27:05 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:27:05 --> Utf8 Class Initialized
INFO - 2021-01-15 05:27:05 --> URI Class Initialized
INFO - 2021-01-15 05:27:05 --> Router Class Initialized
INFO - 2021-01-15 05:27:05 --> Output Class Initialized
INFO - 2021-01-15 05:27:05 --> Security Class Initialized
DEBUG - 2021-01-15 05:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:27:05 --> Input Class Initialized
INFO - 2021-01-15 05:27:05 --> Language Class Initialized
INFO - 2021-01-15 05:27:05 --> Language Class Initialized
INFO - 2021-01-15 05:27:05 --> Config Class Initialized
INFO - 2021-01-15 05:27:05 --> Loader Class Initialized
INFO - 2021-01-15 05:27:05 --> Helper loaded: url_helper
INFO - 2021-01-15 05:27:05 --> Helper loaded: file_helper
INFO - 2021-01-15 05:27:05 --> Helper loaded: form_helper
INFO - 2021-01-15 05:27:05 --> Helper loaded: my_helper
INFO - 2021-01-15 05:27:05 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:27:05 --> Controller Class Initialized
DEBUG - 2021-01-15 05:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 05:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:27:05 --> Final output sent to browser
DEBUG - 2021-01-15 05:27:05 --> Total execution time: 0.3415
INFO - 2021-01-15 05:27:34 --> Config Class Initialized
INFO - 2021-01-15 05:27:34 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:27:34 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:27:34 --> Utf8 Class Initialized
INFO - 2021-01-15 05:27:34 --> URI Class Initialized
INFO - 2021-01-15 05:27:35 --> Router Class Initialized
INFO - 2021-01-15 05:27:35 --> Output Class Initialized
INFO - 2021-01-15 05:27:35 --> Security Class Initialized
DEBUG - 2021-01-15 05:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:27:35 --> Input Class Initialized
INFO - 2021-01-15 05:27:35 --> Language Class Initialized
INFO - 2021-01-15 05:27:35 --> Language Class Initialized
INFO - 2021-01-15 05:27:35 --> Config Class Initialized
INFO - 2021-01-15 05:27:35 --> Loader Class Initialized
INFO - 2021-01-15 05:27:35 --> Helper loaded: url_helper
INFO - 2021-01-15 05:27:35 --> Helper loaded: file_helper
INFO - 2021-01-15 05:27:35 --> Helper loaded: form_helper
INFO - 2021-01-15 05:27:35 --> Helper loaded: my_helper
INFO - 2021-01-15 05:27:35 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:27:35 --> Controller Class Initialized
DEBUG - 2021-01-15 05:27:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:27:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:27:35 --> Final output sent to browser
DEBUG - 2021-01-15 05:27:35 --> Total execution time: 0.3969
INFO - 2021-01-15 05:28:02 --> Config Class Initialized
INFO - 2021-01-15 05:28:02 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:28:02 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:28:02 --> Utf8 Class Initialized
INFO - 2021-01-15 05:28:02 --> URI Class Initialized
INFO - 2021-01-15 05:28:02 --> Router Class Initialized
INFO - 2021-01-15 05:28:02 --> Output Class Initialized
INFO - 2021-01-15 05:28:02 --> Security Class Initialized
DEBUG - 2021-01-15 05:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:28:02 --> Input Class Initialized
INFO - 2021-01-15 05:28:02 --> Language Class Initialized
INFO - 2021-01-15 05:28:02 --> Language Class Initialized
INFO - 2021-01-15 05:28:02 --> Config Class Initialized
INFO - 2021-01-15 05:28:02 --> Loader Class Initialized
INFO - 2021-01-15 05:28:02 --> Helper loaded: url_helper
INFO - 2021-01-15 05:28:02 --> Helper loaded: file_helper
INFO - 2021-01-15 05:28:02 --> Helper loaded: form_helper
INFO - 2021-01-15 05:28:02 --> Helper loaded: my_helper
INFO - 2021-01-15 05:28:02 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:28:02 --> Controller Class Initialized
DEBUG - 2021-01-15 05:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:28:02 --> Final output sent to browser
DEBUG - 2021-01-15 05:28:02 --> Total execution time: 0.2960
INFO - 2021-01-15 05:28:09 --> Config Class Initialized
INFO - 2021-01-15 05:28:09 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:28:09 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:28:09 --> Utf8 Class Initialized
INFO - 2021-01-15 05:28:09 --> URI Class Initialized
INFO - 2021-01-15 05:28:09 --> Router Class Initialized
INFO - 2021-01-15 05:28:09 --> Output Class Initialized
INFO - 2021-01-15 05:28:09 --> Security Class Initialized
DEBUG - 2021-01-15 05:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:28:09 --> Input Class Initialized
INFO - 2021-01-15 05:28:09 --> Language Class Initialized
INFO - 2021-01-15 05:28:09 --> Language Class Initialized
INFO - 2021-01-15 05:28:09 --> Config Class Initialized
INFO - 2021-01-15 05:28:09 --> Loader Class Initialized
INFO - 2021-01-15 05:28:09 --> Helper loaded: url_helper
INFO - 2021-01-15 05:28:09 --> Helper loaded: file_helper
INFO - 2021-01-15 05:28:09 --> Helper loaded: form_helper
INFO - 2021-01-15 05:28:09 --> Helper loaded: my_helper
INFO - 2021-01-15 05:28:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:28:09 --> Controller Class Initialized
DEBUG - 2021-01-15 05:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 05:28:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:28:10 --> Final output sent to browser
DEBUG - 2021-01-15 05:28:10 --> Total execution time: 0.3500
INFO - 2021-01-15 05:28:13 --> Config Class Initialized
INFO - 2021-01-15 05:28:13 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:28:13 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:28:13 --> Utf8 Class Initialized
INFO - 2021-01-15 05:28:13 --> URI Class Initialized
INFO - 2021-01-15 05:28:13 --> Router Class Initialized
INFO - 2021-01-15 05:28:13 --> Output Class Initialized
INFO - 2021-01-15 05:28:13 --> Security Class Initialized
DEBUG - 2021-01-15 05:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:28:13 --> Input Class Initialized
INFO - 2021-01-15 05:28:13 --> Language Class Initialized
INFO - 2021-01-15 05:28:13 --> Language Class Initialized
INFO - 2021-01-15 05:28:13 --> Config Class Initialized
INFO - 2021-01-15 05:28:13 --> Loader Class Initialized
INFO - 2021-01-15 05:28:13 --> Helper loaded: url_helper
INFO - 2021-01-15 05:28:14 --> Helper loaded: file_helper
INFO - 2021-01-15 05:28:14 --> Helper loaded: form_helper
INFO - 2021-01-15 05:28:14 --> Helper loaded: my_helper
INFO - 2021-01-15 05:28:14 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:28:14 --> Controller Class Initialized
DEBUG - 2021-01-15 05:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:28:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:28:14 --> Final output sent to browser
DEBUG - 2021-01-15 05:28:14 --> Total execution time: 0.4170
INFO - 2021-01-15 05:29:27 --> Config Class Initialized
INFO - 2021-01-15 05:29:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:29:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:29:27 --> Utf8 Class Initialized
INFO - 2021-01-15 05:29:27 --> URI Class Initialized
INFO - 2021-01-15 05:29:27 --> Router Class Initialized
INFO - 2021-01-15 05:29:27 --> Output Class Initialized
INFO - 2021-01-15 05:29:27 --> Security Class Initialized
DEBUG - 2021-01-15 05:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:29:27 --> Input Class Initialized
INFO - 2021-01-15 05:29:27 --> Language Class Initialized
INFO - 2021-01-15 05:29:27 --> Language Class Initialized
INFO - 2021-01-15 05:29:27 --> Config Class Initialized
INFO - 2021-01-15 05:29:27 --> Loader Class Initialized
INFO - 2021-01-15 05:29:27 --> Helper loaded: url_helper
INFO - 2021-01-15 05:29:27 --> Helper loaded: file_helper
INFO - 2021-01-15 05:29:27 --> Helper loaded: form_helper
INFO - 2021-01-15 05:29:27 --> Helper loaded: my_helper
INFO - 2021-01-15 05:29:27 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:29:27 --> Controller Class Initialized
DEBUG - 2021-01-15 05:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 05:29:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:29:27 --> Final output sent to browser
DEBUG - 2021-01-15 05:29:27 --> Total execution time: 0.3601
INFO - 2021-01-15 05:30:27 --> Config Class Initialized
INFO - 2021-01-15 05:30:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:30:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:30:27 --> Utf8 Class Initialized
INFO - 2021-01-15 05:30:27 --> URI Class Initialized
INFO - 2021-01-15 05:30:27 --> Router Class Initialized
INFO - 2021-01-15 05:30:27 --> Output Class Initialized
INFO - 2021-01-15 05:30:27 --> Security Class Initialized
DEBUG - 2021-01-15 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:30:27 --> Input Class Initialized
INFO - 2021-01-15 05:30:27 --> Language Class Initialized
INFO - 2021-01-15 05:30:27 --> Language Class Initialized
INFO - 2021-01-15 05:30:27 --> Config Class Initialized
INFO - 2021-01-15 05:30:27 --> Loader Class Initialized
INFO - 2021-01-15 05:30:27 --> Helper loaded: url_helper
INFO - 2021-01-15 05:30:27 --> Helper loaded: file_helper
INFO - 2021-01-15 05:30:27 --> Helper loaded: form_helper
INFO - 2021-01-15 05:30:27 --> Helper loaded: my_helper
INFO - 2021-01-15 05:30:27 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:30:27 --> Controller Class Initialized
DEBUG - 2021-01-15 05:30:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:30:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:30:27 --> Final output sent to browser
DEBUG - 2021-01-15 05:30:27 --> Total execution time: 0.3397
INFO - 2021-01-15 05:31:38 --> Config Class Initialized
INFO - 2021-01-15 05:31:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:31:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:31:38 --> Utf8 Class Initialized
INFO - 2021-01-15 05:31:38 --> URI Class Initialized
INFO - 2021-01-15 05:31:38 --> Router Class Initialized
INFO - 2021-01-15 05:31:38 --> Output Class Initialized
INFO - 2021-01-15 05:31:38 --> Security Class Initialized
DEBUG - 2021-01-15 05:31:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:31:38 --> Input Class Initialized
INFO - 2021-01-15 05:31:38 --> Language Class Initialized
INFO - 2021-01-15 05:31:38 --> Language Class Initialized
INFO - 2021-01-15 05:31:38 --> Config Class Initialized
INFO - 2021-01-15 05:31:38 --> Loader Class Initialized
INFO - 2021-01-15 05:31:38 --> Helper loaded: url_helper
INFO - 2021-01-15 05:31:38 --> Helper loaded: file_helper
INFO - 2021-01-15 05:31:38 --> Helper loaded: form_helper
INFO - 2021-01-15 05:31:38 --> Helper loaded: my_helper
INFO - 2021-01-15 05:31:38 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:31:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:31:38 --> Controller Class Initialized
DEBUG - 2021-01-15 05:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:31:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:31:38 --> Final output sent to browser
DEBUG - 2021-01-15 05:31:38 --> Total execution time: 0.3091
INFO - 2021-01-15 05:32:02 --> Config Class Initialized
INFO - 2021-01-15 05:32:02 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:32:02 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:32:02 --> Utf8 Class Initialized
INFO - 2021-01-15 05:32:02 --> URI Class Initialized
INFO - 2021-01-15 05:32:02 --> Router Class Initialized
INFO - 2021-01-15 05:32:02 --> Output Class Initialized
INFO - 2021-01-15 05:32:02 --> Security Class Initialized
DEBUG - 2021-01-15 05:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:32:02 --> Input Class Initialized
INFO - 2021-01-15 05:32:02 --> Language Class Initialized
INFO - 2021-01-15 05:32:02 --> Language Class Initialized
INFO - 2021-01-15 05:32:02 --> Config Class Initialized
INFO - 2021-01-15 05:32:02 --> Loader Class Initialized
INFO - 2021-01-15 05:32:02 --> Helper loaded: url_helper
INFO - 2021-01-15 05:32:02 --> Helper loaded: file_helper
INFO - 2021-01-15 05:32:02 --> Helper loaded: form_helper
INFO - 2021-01-15 05:32:02 --> Helper loaded: my_helper
INFO - 2021-01-15 05:32:02 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:32:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:32:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:32:02 --> Controller Class Initialized
DEBUG - 2021-01-15 05:32:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 05:32:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:32:02 --> Final output sent to browser
DEBUG - 2021-01-15 05:32:02 --> Total execution time: 0.3238
INFO - 2021-01-15 05:37:30 --> Config Class Initialized
INFO - 2021-01-15 05:37:30 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:37:30 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:37:30 --> Utf8 Class Initialized
INFO - 2021-01-15 05:37:30 --> URI Class Initialized
INFO - 2021-01-15 05:37:30 --> Router Class Initialized
INFO - 2021-01-15 05:37:30 --> Output Class Initialized
INFO - 2021-01-15 05:37:30 --> Security Class Initialized
DEBUG - 2021-01-15 05:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:37:30 --> Input Class Initialized
INFO - 2021-01-15 05:37:30 --> Language Class Initialized
INFO - 2021-01-15 05:37:30 --> Language Class Initialized
INFO - 2021-01-15 05:37:30 --> Config Class Initialized
INFO - 2021-01-15 05:37:30 --> Loader Class Initialized
INFO - 2021-01-15 05:37:30 --> Helper loaded: url_helper
INFO - 2021-01-15 05:37:30 --> Helper loaded: file_helper
INFO - 2021-01-15 05:37:31 --> Helper loaded: form_helper
INFO - 2021-01-15 05:37:31 --> Helper loaded: my_helper
INFO - 2021-01-15 05:37:31 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:37:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:37:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:37:31 --> Controller Class Initialized
DEBUG - 2021-01-15 05:37:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-15 05:37:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:37:31 --> Final output sent to browser
DEBUG - 2021-01-15 05:37:31 --> Total execution time: 0.3742
INFO - 2021-01-15 05:37:32 --> Config Class Initialized
INFO - 2021-01-15 05:37:32 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:37:32 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:37:32 --> Utf8 Class Initialized
INFO - 2021-01-15 05:37:32 --> URI Class Initialized
INFO - 2021-01-15 05:37:32 --> Router Class Initialized
INFO - 2021-01-15 05:37:32 --> Output Class Initialized
INFO - 2021-01-15 05:37:32 --> Security Class Initialized
DEBUG - 2021-01-15 05:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:37:32 --> Input Class Initialized
INFO - 2021-01-15 05:37:32 --> Language Class Initialized
INFO - 2021-01-15 05:37:32 --> Language Class Initialized
INFO - 2021-01-15 05:37:32 --> Config Class Initialized
INFO - 2021-01-15 05:37:32 --> Loader Class Initialized
INFO - 2021-01-15 05:37:32 --> Helper loaded: url_helper
INFO - 2021-01-15 05:37:32 --> Helper loaded: file_helper
INFO - 2021-01-15 05:37:32 --> Helper loaded: form_helper
INFO - 2021-01-15 05:37:32 --> Helper loaded: my_helper
INFO - 2021-01-15 05:37:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:37:32 --> Controller Class Initialized
DEBUG - 2021-01-15 05:37:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-15 05:37:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:37:32 --> Final output sent to browser
DEBUG - 2021-01-15 05:37:32 --> Total execution time: 0.3150
INFO - 2021-01-15 05:37:32 --> Config Class Initialized
INFO - 2021-01-15 05:37:32 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:37:32 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:37:32 --> Utf8 Class Initialized
INFO - 2021-01-15 05:37:32 --> URI Class Initialized
INFO - 2021-01-15 05:37:32 --> Router Class Initialized
INFO - 2021-01-15 05:37:32 --> Output Class Initialized
INFO - 2021-01-15 05:37:32 --> Security Class Initialized
DEBUG - 2021-01-15 05:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:37:32 --> Input Class Initialized
INFO - 2021-01-15 05:37:32 --> Language Class Initialized
INFO - 2021-01-15 05:37:32 --> Language Class Initialized
INFO - 2021-01-15 05:37:32 --> Config Class Initialized
INFO - 2021-01-15 05:37:32 --> Loader Class Initialized
INFO - 2021-01-15 05:37:32 --> Helper loaded: url_helper
INFO - 2021-01-15 05:37:32 --> Helper loaded: file_helper
INFO - 2021-01-15 05:37:32 --> Helper loaded: form_helper
INFO - 2021-01-15 05:37:32 --> Helper loaded: my_helper
INFO - 2021-01-15 05:37:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:37:32 --> Controller Class Initialized
INFO - 2021-01-15 05:37:38 --> Config Class Initialized
INFO - 2021-01-15 05:37:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:37:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:37:38 --> Utf8 Class Initialized
INFO - 2021-01-15 05:37:38 --> URI Class Initialized
INFO - 2021-01-15 05:37:38 --> Router Class Initialized
INFO - 2021-01-15 05:37:38 --> Output Class Initialized
INFO - 2021-01-15 05:37:38 --> Security Class Initialized
DEBUG - 2021-01-15 05:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:37:38 --> Input Class Initialized
INFO - 2021-01-15 05:37:38 --> Language Class Initialized
INFO - 2021-01-15 05:37:39 --> Language Class Initialized
INFO - 2021-01-15 05:37:39 --> Config Class Initialized
INFO - 2021-01-15 05:37:39 --> Loader Class Initialized
INFO - 2021-01-15 05:37:39 --> Helper loaded: url_helper
INFO - 2021-01-15 05:37:39 --> Helper loaded: file_helper
INFO - 2021-01-15 05:37:39 --> Helper loaded: form_helper
INFO - 2021-01-15 05:37:39 --> Helper loaded: my_helper
INFO - 2021-01-15 05:37:39 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:37:39 --> Controller Class Initialized
INFO - 2021-01-15 05:37:39 --> Final output sent to browser
DEBUG - 2021-01-15 05:37:39 --> Total execution time: 0.2870
INFO - 2021-01-15 05:37:59 --> Config Class Initialized
INFO - 2021-01-15 05:37:59 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:37:59 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:37:59 --> Utf8 Class Initialized
INFO - 2021-01-15 05:37:59 --> URI Class Initialized
INFO - 2021-01-15 05:38:00 --> Router Class Initialized
INFO - 2021-01-15 05:38:00 --> Output Class Initialized
INFO - 2021-01-15 05:38:00 --> Security Class Initialized
DEBUG - 2021-01-15 05:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:38:00 --> Input Class Initialized
INFO - 2021-01-15 05:38:00 --> Language Class Initialized
INFO - 2021-01-15 05:38:00 --> Language Class Initialized
INFO - 2021-01-15 05:38:00 --> Config Class Initialized
INFO - 2021-01-15 05:38:00 --> Loader Class Initialized
INFO - 2021-01-15 05:38:00 --> Helper loaded: url_helper
INFO - 2021-01-15 05:38:00 --> Helper loaded: file_helper
INFO - 2021-01-15 05:38:00 --> Helper loaded: form_helper
INFO - 2021-01-15 05:38:00 --> Helper loaded: my_helper
INFO - 2021-01-15 05:38:00 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:38:00 --> Controller Class Initialized
DEBUG - 2021-01-15 05:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-15 05:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:38:00 --> Final output sent to browser
DEBUG - 2021-01-15 05:38:00 --> Total execution time: 0.3840
INFO - 2021-01-15 05:38:01 --> Config Class Initialized
INFO - 2021-01-15 05:38:01 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:38:01 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:38:01 --> Utf8 Class Initialized
INFO - 2021-01-15 05:38:01 --> URI Class Initialized
INFO - 2021-01-15 05:38:01 --> Router Class Initialized
INFO - 2021-01-15 05:38:01 --> Output Class Initialized
INFO - 2021-01-15 05:38:01 --> Security Class Initialized
DEBUG - 2021-01-15 05:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:38:01 --> Input Class Initialized
INFO - 2021-01-15 05:38:01 --> Language Class Initialized
INFO - 2021-01-15 05:38:01 --> Language Class Initialized
INFO - 2021-01-15 05:38:01 --> Config Class Initialized
INFO - 2021-01-15 05:38:01 --> Loader Class Initialized
INFO - 2021-01-15 05:38:01 --> Helper loaded: url_helper
INFO - 2021-01-15 05:38:01 --> Helper loaded: file_helper
INFO - 2021-01-15 05:38:01 --> Helper loaded: form_helper
INFO - 2021-01-15 05:38:01 --> Helper loaded: my_helper
INFO - 2021-01-15 05:38:01 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:38:01 --> Controller Class Initialized
DEBUG - 2021-01-15 05:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-15 05:38:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:38:01 --> Final output sent to browser
DEBUG - 2021-01-15 05:38:01 --> Total execution time: 0.3470
INFO - 2021-01-15 05:39:05 --> Config Class Initialized
INFO - 2021-01-15 05:39:05 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:39:05 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:39:05 --> Utf8 Class Initialized
INFO - 2021-01-15 05:39:05 --> URI Class Initialized
INFO - 2021-01-15 05:39:05 --> Router Class Initialized
INFO - 2021-01-15 05:39:05 --> Output Class Initialized
INFO - 2021-01-15 05:39:05 --> Security Class Initialized
DEBUG - 2021-01-15 05:39:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:39:05 --> Input Class Initialized
INFO - 2021-01-15 05:39:05 --> Language Class Initialized
INFO - 2021-01-15 05:39:05 --> Language Class Initialized
INFO - 2021-01-15 05:39:05 --> Config Class Initialized
INFO - 2021-01-15 05:39:05 --> Loader Class Initialized
INFO - 2021-01-15 05:39:05 --> Helper loaded: url_helper
INFO - 2021-01-15 05:39:05 --> Helper loaded: file_helper
INFO - 2021-01-15 05:39:05 --> Helper loaded: form_helper
INFO - 2021-01-15 05:39:05 --> Helper loaded: my_helper
INFO - 2021-01-15 05:39:05 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:39:06 --> Controller Class Initialized
INFO - 2021-01-15 05:39:06 --> Helper loaded: cookie_helper
INFO - 2021-01-15 05:39:06 --> Config Class Initialized
INFO - 2021-01-15 05:39:06 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:39:06 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:39:06 --> Utf8 Class Initialized
INFO - 2021-01-15 05:39:06 --> URI Class Initialized
INFO - 2021-01-15 05:39:06 --> Router Class Initialized
INFO - 2021-01-15 05:39:06 --> Output Class Initialized
INFO - 2021-01-15 05:39:06 --> Security Class Initialized
DEBUG - 2021-01-15 05:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:39:06 --> Input Class Initialized
INFO - 2021-01-15 05:39:06 --> Language Class Initialized
INFO - 2021-01-15 05:39:06 --> Language Class Initialized
INFO - 2021-01-15 05:39:06 --> Config Class Initialized
INFO - 2021-01-15 05:39:06 --> Loader Class Initialized
INFO - 2021-01-15 05:39:06 --> Helper loaded: url_helper
INFO - 2021-01-15 05:39:06 --> Helper loaded: file_helper
INFO - 2021-01-15 05:39:06 --> Helper loaded: form_helper
INFO - 2021-01-15 05:39:06 --> Helper loaded: my_helper
INFO - 2021-01-15 05:39:06 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:39:06 --> Controller Class Initialized
DEBUG - 2021-01-15 05:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-15 05:39:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:39:06 --> Final output sent to browser
DEBUG - 2021-01-15 05:39:06 --> Total execution time: 0.3116
INFO - 2021-01-15 05:39:15 --> Config Class Initialized
INFO - 2021-01-15 05:39:15 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:39:15 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:39:15 --> Utf8 Class Initialized
INFO - 2021-01-15 05:39:15 --> URI Class Initialized
INFO - 2021-01-15 05:39:15 --> Router Class Initialized
INFO - 2021-01-15 05:39:15 --> Output Class Initialized
INFO - 2021-01-15 05:39:15 --> Security Class Initialized
DEBUG - 2021-01-15 05:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:39:15 --> Input Class Initialized
INFO - 2021-01-15 05:39:15 --> Language Class Initialized
INFO - 2021-01-15 05:39:16 --> Language Class Initialized
INFO - 2021-01-15 05:39:16 --> Config Class Initialized
INFO - 2021-01-15 05:39:16 --> Loader Class Initialized
INFO - 2021-01-15 05:39:16 --> Helper loaded: url_helper
INFO - 2021-01-15 05:39:16 --> Helper loaded: file_helper
INFO - 2021-01-15 05:39:16 --> Helper loaded: form_helper
INFO - 2021-01-15 05:39:16 --> Helper loaded: my_helper
INFO - 2021-01-15 05:39:16 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:39:16 --> Controller Class Initialized
INFO - 2021-01-15 05:39:16 --> Helper loaded: cookie_helper
INFO - 2021-01-15 05:39:16 --> Final output sent to browser
DEBUG - 2021-01-15 05:39:16 --> Total execution time: 0.4223
INFO - 2021-01-15 05:39:17 --> Config Class Initialized
INFO - 2021-01-15 05:39:17 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:39:17 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:39:17 --> Utf8 Class Initialized
INFO - 2021-01-15 05:39:17 --> URI Class Initialized
INFO - 2021-01-15 05:39:17 --> Router Class Initialized
INFO - 2021-01-15 05:39:17 --> Output Class Initialized
INFO - 2021-01-15 05:39:17 --> Security Class Initialized
DEBUG - 2021-01-15 05:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:39:17 --> Input Class Initialized
INFO - 2021-01-15 05:39:17 --> Language Class Initialized
INFO - 2021-01-15 05:39:17 --> Language Class Initialized
INFO - 2021-01-15 05:39:17 --> Config Class Initialized
INFO - 2021-01-15 05:39:17 --> Loader Class Initialized
INFO - 2021-01-15 05:39:17 --> Helper loaded: url_helper
INFO - 2021-01-15 05:39:17 --> Helper loaded: file_helper
INFO - 2021-01-15 05:39:17 --> Helper loaded: form_helper
INFO - 2021-01-15 05:39:17 --> Helper loaded: my_helper
INFO - 2021-01-15 05:39:17 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:39:17 --> Controller Class Initialized
DEBUG - 2021-01-15 05:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 05:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:39:18 --> Final output sent to browser
DEBUG - 2021-01-15 05:39:18 --> Total execution time: 0.4484
INFO - 2021-01-15 05:39:19 --> Config Class Initialized
INFO - 2021-01-15 05:39:19 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:39:19 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:39:19 --> Utf8 Class Initialized
INFO - 2021-01-15 05:39:19 --> URI Class Initialized
INFO - 2021-01-15 05:39:19 --> Router Class Initialized
INFO - 2021-01-15 05:39:19 --> Output Class Initialized
INFO - 2021-01-15 05:39:19 --> Security Class Initialized
DEBUG - 2021-01-15 05:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:39:19 --> Input Class Initialized
INFO - 2021-01-15 05:39:19 --> Language Class Initialized
INFO - 2021-01-15 05:39:19 --> Language Class Initialized
INFO - 2021-01-15 05:39:19 --> Config Class Initialized
INFO - 2021-01-15 05:39:19 --> Loader Class Initialized
INFO - 2021-01-15 05:39:19 --> Helper loaded: url_helper
INFO - 2021-01-15 05:39:19 --> Helper loaded: file_helper
INFO - 2021-01-15 05:39:19 --> Helper loaded: form_helper
INFO - 2021-01-15 05:39:19 --> Helper loaded: my_helper
INFO - 2021-01-15 05:39:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:39:19 --> Controller Class Initialized
DEBUG - 2021-01-15 05:39:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-01-15 05:39:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 05:39:20 --> Final output sent to browser
DEBUG - 2021-01-15 05:39:20 --> Total execution time: 0.3362
INFO - 2021-01-15 05:39:20 --> Config Class Initialized
INFO - 2021-01-15 05:39:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:39:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:39:20 --> Utf8 Class Initialized
INFO - 2021-01-15 05:39:20 --> URI Class Initialized
INFO - 2021-01-15 05:39:20 --> Router Class Initialized
INFO - 2021-01-15 05:39:20 --> Output Class Initialized
INFO - 2021-01-15 05:39:20 --> Security Class Initialized
DEBUG - 2021-01-15 05:39:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:39:20 --> Input Class Initialized
INFO - 2021-01-15 05:39:20 --> Language Class Initialized
INFO - 2021-01-15 05:39:20 --> Language Class Initialized
INFO - 2021-01-15 05:39:20 --> Config Class Initialized
INFO - 2021-01-15 05:39:20 --> Loader Class Initialized
INFO - 2021-01-15 05:39:20 --> Helper loaded: url_helper
INFO - 2021-01-15 05:39:20 --> Helper loaded: file_helper
INFO - 2021-01-15 05:39:20 --> Helper loaded: form_helper
INFO - 2021-01-15 05:39:20 --> Helper loaded: my_helper
INFO - 2021-01-15 05:39:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:39:20 --> Controller Class Initialized
INFO - 2021-01-15 05:39:29 --> Config Class Initialized
INFO - 2021-01-15 05:39:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:39:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:39:29 --> Utf8 Class Initialized
INFO - 2021-01-15 05:39:29 --> URI Class Initialized
INFO - 2021-01-15 05:39:29 --> Router Class Initialized
INFO - 2021-01-15 05:39:29 --> Output Class Initialized
INFO - 2021-01-15 05:39:29 --> Security Class Initialized
DEBUG - 2021-01-15 05:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:39:29 --> Input Class Initialized
INFO - 2021-01-15 05:39:29 --> Language Class Initialized
INFO - 2021-01-15 05:39:29 --> Language Class Initialized
INFO - 2021-01-15 05:39:29 --> Config Class Initialized
INFO - 2021-01-15 05:39:29 --> Loader Class Initialized
INFO - 2021-01-15 05:39:29 --> Helper loaded: url_helper
INFO - 2021-01-15 05:39:29 --> Helper loaded: file_helper
INFO - 2021-01-15 05:39:29 --> Helper loaded: form_helper
INFO - 2021-01-15 05:39:29 --> Helper loaded: my_helper
INFO - 2021-01-15 05:39:29 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:39:29 --> Controller Class Initialized
INFO - 2021-01-15 05:39:29 --> Final output sent to browser
DEBUG - 2021-01-15 05:39:29 --> Total execution time: 0.4058
INFO - 2021-01-15 05:40:14 --> Config Class Initialized
INFO - 2021-01-15 05:40:14 --> Hooks Class Initialized
DEBUG - 2021-01-15 05:40:14 --> UTF-8 Support Enabled
INFO - 2021-01-15 05:40:14 --> Utf8 Class Initialized
INFO - 2021-01-15 05:40:14 --> URI Class Initialized
INFO - 2021-01-15 05:40:14 --> Router Class Initialized
INFO - 2021-01-15 05:40:14 --> Output Class Initialized
INFO - 2021-01-15 05:40:14 --> Security Class Initialized
DEBUG - 2021-01-15 05:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 05:40:14 --> Input Class Initialized
INFO - 2021-01-15 05:40:14 --> Language Class Initialized
INFO - 2021-01-15 05:40:14 --> Language Class Initialized
INFO - 2021-01-15 05:40:14 --> Config Class Initialized
INFO - 2021-01-15 05:40:14 --> Loader Class Initialized
INFO - 2021-01-15 05:40:14 --> Helper loaded: url_helper
INFO - 2021-01-15 05:40:14 --> Helper loaded: file_helper
INFO - 2021-01-15 05:40:14 --> Helper loaded: form_helper
INFO - 2021-01-15 05:40:14 --> Helper loaded: my_helper
INFO - 2021-01-15 05:40:14 --> Database Driver Class Initialized
DEBUG - 2021-01-15 05:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 05:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 05:40:14 --> Controller Class Initialized
INFO - 2021-01-15 05:40:14 --> Final output sent to browser
DEBUG - 2021-01-15 05:40:14 --> Total execution time: 0.4752
INFO - 2021-01-15 07:58:41 --> Config Class Initialized
INFO - 2021-01-15 07:58:41 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:41 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:41 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:41 --> URI Class Initialized
INFO - 2021-01-15 07:58:41 --> Router Class Initialized
INFO - 2021-01-15 07:58:41 --> Output Class Initialized
INFO - 2021-01-15 07:58:41 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:41 --> Input Class Initialized
INFO - 2021-01-15 07:58:41 --> Language Class Initialized
INFO - 2021-01-15 07:58:41 --> Language Class Initialized
INFO - 2021-01-15 07:58:41 --> Config Class Initialized
INFO - 2021-01-15 07:58:41 --> Loader Class Initialized
INFO - 2021-01-15 07:58:41 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:41 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:41 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:41 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:41 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:42 --> Controller Class Initialized
INFO - 2021-01-15 07:58:42 --> Helper loaded: cookie_helper
INFO - 2021-01-15 07:58:42 --> Config Class Initialized
INFO - 2021-01-15 07:58:42 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:42 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:42 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:42 --> URI Class Initialized
INFO - 2021-01-15 07:58:42 --> Router Class Initialized
INFO - 2021-01-15 07:58:42 --> Output Class Initialized
INFO - 2021-01-15 07:58:42 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:42 --> Input Class Initialized
INFO - 2021-01-15 07:58:42 --> Language Class Initialized
INFO - 2021-01-15 07:58:42 --> Language Class Initialized
INFO - 2021-01-15 07:58:42 --> Config Class Initialized
INFO - 2021-01-15 07:58:42 --> Loader Class Initialized
INFO - 2021-01-15 07:58:42 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:42 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:42 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:42 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:42 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:42 --> Controller Class Initialized
DEBUG - 2021-01-15 07:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-15 07:58:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 07:58:42 --> Final output sent to browser
DEBUG - 2021-01-15 07:58:42 --> Total execution time: 0.3318
INFO - 2021-01-15 07:58:49 --> Config Class Initialized
INFO - 2021-01-15 07:58:49 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:49 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:49 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:49 --> URI Class Initialized
INFO - 2021-01-15 07:58:49 --> Router Class Initialized
INFO - 2021-01-15 07:58:49 --> Output Class Initialized
INFO - 2021-01-15 07:58:49 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:49 --> Input Class Initialized
INFO - 2021-01-15 07:58:49 --> Language Class Initialized
INFO - 2021-01-15 07:58:49 --> Language Class Initialized
INFO - 2021-01-15 07:58:49 --> Config Class Initialized
INFO - 2021-01-15 07:58:49 --> Loader Class Initialized
INFO - 2021-01-15 07:58:49 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:49 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:49 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:49 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:49 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:49 --> Controller Class Initialized
INFO - 2021-01-15 07:58:49 --> Helper loaded: cookie_helper
INFO - 2021-01-15 07:58:49 --> Final output sent to browser
DEBUG - 2021-01-15 07:58:49 --> Total execution time: 0.4022
INFO - 2021-01-15 07:58:50 --> Config Class Initialized
INFO - 2021-01-15 07:58:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:50 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:50 --> URI Class Initialized
INFO - 2021-01-15 07:58:50 --> Router Class Initialized
INFO - 2021-01-15 07:58:50 --> Output Class Initialized
INFO - 2021-01-15 07:58:50 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:50 --> Input Class Initialized
INFO - 2021-01-15 07:58:50 --> Language Class Initialized
INFO - 2021-01-15 07:58:50 --> Language Class Initialized
INFO - 2021-01-15 07:58:50 --> Config Class Initialized
INFO - 2021-01-15 07:58:50 --> Loader Class Initialized
INFO - 2021-01-15 07:58:50 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:50 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:50 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:50 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:50 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:50 --> Controller Class Initialized
DEBUG - 2021-01-15 07:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 07:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 07:58:50 --> Final output sent to browser
DEBUG - 2021-01-15 07:58:50 --> Total execution time: 0.4682
INFO - 2021-01-15 07:58:52 --> Config Class Initialized
INFO - 2021-01-15 07:58:52 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:52 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:52 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:52 --> URI Class Initialized
INFO - 2021-01-15 07:58:52 --> Router Class Initialized
INFO - 2021-01-15 07:58:52 --> Output Class Initialized
INFO - 2021-01-15 07:58:52 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:52 --> Input Class Initialized
INFO - 2021-01-15 07:58:52 --> Language Class Initialized
INFO - 2021-01-15 07:58:52 --> Language Class Initialized
INFO - 2021-01-15 07:58:52 --> Config Class Initialized
INFO - 2021-01-15 07:58:52 --> Loader Class Initialized
INFO - 2021-01-15 07:58:52 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:52 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:52 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:52 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:52 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:52 --> Controller Class Initialized
DEBUG - 2021-01-15 07:58:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 07:58:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 07:58:52 --> Final output sent to browser
DEBUG - 2021-01-15 07:58:52 --> Total execution time: 0.3585
INFO - 2021-01-15 07:58:54 --> Config Class Initialized
INFO - 2021-01-15 07:58:54 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:54 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:54 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:54 --> URI Class Initialized
DEBUG - 2021-01-15 07:58:54 --> No URI present. Default controller set.
INFO - 2021-01-15 07:58:54 --> Router Class Initialized
INFO - 2021-01-15 07:58:54 --> Output Class Initialized
INFO - 2021-01-15 07:58:54 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:54 --> Input Class Initialized
INFO - 2021-01-15 07:58:54 --> Language Class Initialized
INFO - 2021-01-15 07:58:54 --> Language Class Initialized
INFO - 2021-01-15 07:58:54 --> Config Class Initialized
INFO - 2021-01-15 07:58:54 --> Loader Class Initialized
INFO - 2021-01-15 07:58:54 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:54 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:54 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:54 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:54 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:54 --> Controller Class Initialized
DEBUG - 2021-01-15 07:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-15 07:58:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 07:58:54 --> Final output sent to browser
DEBUG - 2021-01-15 07:58:54 --> Total execution time: 0.4382
INFO - 2021-01-15 07:58:56 --> Config Class Initialized
INFO - 2021-01-15 07:58:56 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:56 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:56 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:56 --> URI Class Initialized
INFO - 2021-01-15 07:58:56 --> Router Class Initialized
INFO - 2021-01-15 07:58:56 --> Output Class Initialized
INFO - 2021-01-15 07:58:56 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:56 --> Input Class Initialized
INFO - 2021-01-15 07:58:56 --> Language Class Initialized
INFO - 2021-01-15 07:58:56 --> Language Class Initialized
INFO - 2021-01-15 07:58:56 --> Config Class Initialized
INFO - 2021-01-15 07:58:56 --> Loader Class Initialized
INFO - 2021-01-15 07:58:56 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:56 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:56 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:56 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:56 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:56 --> Controller Class Initialized
DEBUG - 2021-01-15 07:58:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 07:58:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 07:58:56 --> Final output sent to browser
DEBUG - 2021-01-15 07:58:56 --> Total execution time: 0.3887
INFO - 2021-01-15 07:58:57 --> Config Class Initialized
INFO - 2021-01-15 07:58:57 --> Hooks Class Initialized
DEBUG - 2021-01-15 07:58:57 --> UTF-8 Support Enabled
INFO - 2021-01-15 07:58:57 --> Utf8 Class Initialized
INFO - 2021-01-15 07:58:57 --> URI Class Initialized
INFO - 2021-01-15 07:58:57 --> Router Class Initialized
INFO - 2021-01-15 07:58:57 --> Output Class Initialized
INFO - 2021-01-15 07:58:57 --> Security Class Initialized
DEBUG - 2021-01-15 07:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 07:58:57 --> Input Class Initialized
INFO - 2021-01-15 07:58:57 --> Language Class Initialized
INFO - 2021-01-15 07:58:57 --> Language Class Initialized
INFO - 2021-01-15 07:58:58 --> Config Class Initialized
INFO - 2021-01-15 07:58:58 --> Loader Class Initialized
INFO - 2021-01-15 07:58:58 --> Helper loaded: url_helper
INFO - 2021-01-15 07:58:58 --> Helper loaded: file_helper
INFO - 2021-01-15 07:58:58 --> Helper loaded: form_helper
INFO - 2021-01-15 07:58:58 --> Helper loaded: my_helper
INFO - 2021-01-15 07:58:58 --> Database Driver Class Initialized
DEBUG - 2021-01-15 07:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 07:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 07:58:58 --> Controller Class Initialized
DEBUG - 2021-01-15 07:58:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 07:58:58 --> Final output sent to browser
DEBUG - 2021-01-15 07:58:58 --> Total execution time: 0.3484
INFO - 2021-01-15 08:00:21 --> Config Class Initialized
INFO - 2021-01-15 08:00:21 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:00:21 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:00:21 --> Utf8 Class Initialized
INFO - 2021-01-15 08:00:21 --> URI Class Initialized
INFO - 2021-01-15 08:00:21 --> Router Class Initialized
INFO - 2021-01-15 08:00:21 --> Output Class Initialized
INFO - 2021-01-15 08:00:21 --> Security Class Initialized
DEBUG - 2021-01-15 08:00:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:00:21 --> Input Class Initialized
INFO - 2021-01-15 08:00:21 --> Language Class Initialized
INFO - 2021-01-15 08:00:21 --> Language Class Initialized
INFO - 2021-01-15 08:00:22 --> Config Class Initialized
INFO - 2021-01-15 08:00:22 --> Loader Class Initialized
INFO - 2021-01-15 08:00:22 --> Helper loaded: url_helper
INFO - 2021-01-15 08:00:22 --> Helper loaded: file_helper
INFO - 2021-01-15 08:00:22 --> Helper loaded: form_helper
INFO - 2021-01-15 08:00:22 --> Helper loaded: my_helper
INFO - 2021-01-15 08:00:22 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:00:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:00:22 --> Controller Class Initialized
ERROR - 2021-01-15 08:00:22 --> Severity: Notice --> Undefined variable: m5 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 125
ERROR - 2021-01-15 08:00:22 --> Severity: Notice --> Undefined variable: m5 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 125
DEBUG - 2021-01-15 08:00:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:00:22 --> Final output sent to browser
DEBUG - 2021-01-15 08:00:22 --> Total execution time: 0.3313
INFO - 2021-01-15 08:00:37 --> Config Class Initialized
INFO - 2021-01-15 08:00:37 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:00:37 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:00:37 --> Utf8 Class Initialized
INFO - 2021-01-15 08:00:37 --> URI Class Initialized
INFO - 2021-01-15 08:00:37 --> Router Class Initialized
INFO - 2021-01-15 08:00:37 --> Output Class Initialized
INFO - 2021-01-15 08:00:37 --> Security Class Initialized
DEBUG - 2021-01-15 08:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:00:37 --> Input Class Initialized
INFO - 2021-01-15 08:00:37 --> Language Class Initialized
INFO - 2021-01-15 08:00:37 --> Language Class Initialized
INFO - 2021-01-15 08:00:37 --> Config Class Initialized
INFO - 2021-01-15 08:00:37 --> Loader Class Initialized
INFO - 2021-01-15 08:00:37 --> Helper loaded: url_helper
INFO - 2021-01-15 08:00:37 --> Helper loaded: file_helper
INFO - 2021-01-15 08:00:37 --> Helper loaded: form_helper
INFO - 2021-01-15 08:00:37 --> Helper loaded: my_helper
INFO - 2021-01-15 08:00:37 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:00:37 --> Controller Class Initialized
DEBUG - 2021-01-15 08:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:00:37 --> Final output sent to browser
DEBUG - 2021-01-15 08:00:37 --> Total execution time: 0.3053
INFO - 2021-01-15 08:01:17 --> Config Class Initialized
INFO - 2021-01-15 08:01:17 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:01:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:01:18 --> Utf8 Class Initialized
INFO - 2021-01-15 08:01:18 --> URI Class Initialized
INFO - 2021-01-15 08:01:18 --> Router Class Initialized
INFO - 2021-01-15 08:01:18 --> Output Class Initialized
INFO - 2021-01-15 08:01:18 --> Security Class Initialized
DEBUG - 2021-01-15 08:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:01:18 --> Input Class Initialized
INFO - 2021-01-15 08:01:18 --> Language Class Initialized
INFO - 2021-01-15 08:01:18 --> Language Class Initialized
INFO - 2021-01-15 08:01:18 --> Config Class Initialized
INFO - 2021-01-15 08:01:18 --> Loader Class Initialized
INFO - 2021-01-15 08:01:18 --> Helper loaded: url_helper
INFO - 2021-01-15 08:01:18 --> Helper loaded: file_helper
INFO - 2021-01-15 08:01:18 --> Helper loaded: form_helper
INFO - 2021-01-15 08:01:18 --> Helper loaded: my_helper
INFO - 2021-01-15 08:01:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:01:18 --> Controller Class Initialized
DEBUG - 2021-01-15 08:01:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:01:18 --> Final output sent to browser
DEBUG - 2021-01-15 08:01:18 --> Total execution time: 0.3268
INFO - 2021-01-15 08:03:04 --> Config Class Initialized
INFO - 2021-01-15 08:03:04 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:03:04 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:03:04 --> Utf8 Class Initialized
INFO - 2021-01-15 08:03:04 --> URI Class Initialized
INFO - 2021-01-15 08:03:04 --> Router Class Initialized
INFO - 2021-01-15 08:03:04 --> Output Class Initialized
INFO - 2021-01-15 08:03:04 --> Security Class Initialized
DEBUG - 2021-01-15 08:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:03:04 --> Input Class Initialized
INFO - 2021-01-15 08:03:04 --> Language Class Initialized
INFO - 2021-01-15 08:03:04 --> Language Class Initialized
INFO - 2021-01-15 08:03:04 --> Config Class Initialized
INFO - 2021-01-15 08:03:04 --> Loader Class Initialized
INFO - 2021-01-15 08:03:04 --> Helper loaded: url_helper
INFO - 2021-01-15 08:03:04 --> Helper loaded: file_helper
INFO - 2021-01-15 08:03:04 --> Helper loaded: form_helper
INFO - 2021-01-15 08:03:04 --> Helper loaded: my_helper
INFO - 2021-01-15 08:03:04 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:03:05 --> Controller Class Initialized
DEBUG - 2021-01-15 08:03:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:03:05 --> Final output sent to browser
DEBUG - 2021-01-15 08:03:05 --> Total execution time: 0.3413
INFO - 2021-01-15 08:03:46 --> Config Class Initialized
INFO - 2021-01-15 08:03:46 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:03:46 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:03:46 --> Utf8 Class Initialized
INFO - 2021-01-15 08:03:46 --> URI Class Initialized
INFO - 2021-01-15 08:03:46 --> Router Class Initialized
INFO - 2021-01-15 08:03:46 --> Output Class Initialized
INFO - 2021-01-15 08:03:46 --> Security Class Initialized
DEBUG - 2021-01-15 08:03:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:03:46 --> Input Class Initialized
INFO - 2021-01-15 08:03:46 --> Language Class Initialized
INFO - 2021-01-15 08:03:46 --> Language Class Initialized
INFO - 2021-01-15 08:03:46 --> Config Class Initialized
INFO - 2021-01-15 08:03:46 --> Loader Class Initialized
INFO - 2021-01-15 08:03:46 --> Helper loaded: url_helper
INFO - 2021-01-15 08:03:46 --> Helper loaded: file_helper
INFO - 2021-01-15 08:03:46 --> Helper loaded: form_helper
INFO - 2021-01-15 08:03:46 --> Helper loaded: my_helper
INFO - 2021-01-15 08:03:46 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:03:47 --> Controller Class Initialized
DEBUG - 2021-01-15 08:03:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:03:47 --> Final output sent to browser
DEBUG - 2021-01-15 08:03:47 --> Total execution time: 0.3229
INFO - 2021-01-15 08:05:50 --> Config Class Initialized
INFO - 2021-01-15 08:05:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:05:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:05:50 --> Utf8 Class Initialized
INFO - 2021-01-15 08:05:50 --> URI Class Initialized
INFO - 2021-01-15 08:05:50 --> Router Class Initialized
INFO - 2021-01-15 08:05:50 --> Output Class Initialized
INFO - 2021-01-15 08:05:50 --> Security Class Initialized
DEBUG - 2021-01-15 08:05:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:05:50 --> Input Class Initialized
INFO - 2021-01-15 08:05:50 --> Language Class Initialized
INFO - 2021-01-15 08:05:50 --> Language Class Initialized
INFO - 2021-01-15 08:05:50 --> Config Class Initialized
INFO - 2021-01-15 08:05:50 --> Loader Class Initialized
INFO - 2021-01-15 08:05:50 --> Helper loaded: url_helper
INFO - 2021-01-15 08:05:50 --> Helper loaded: file_helper
INFO - 2021-01-15 08:05:50 --> Helper loaded: form_helper
INFO - 2021-01-15 08:05:50 --> Helper loaded: my_helper
INFO - 2021-01-15 08:05:50 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:05:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:05:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:05:50 --> Controller Class Initialized
DEBUG - 2021-01-15 08:05:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:05:50 --> Final output sent to browser
DEBUG - 2021-01-15 08:05:50 --> Total execution time: 0.3345
INFO - 2021-01-15 08:06:00 --> Config Class Initialized
INFO - 2021-01-15 08:06:00 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:06:00 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:06:00 --> Utf8 Class Initialized
INFO - 2021-01-15 08:06:00 --> URI Class Initialized
INFO - 2021-01-15 08:06:00 --> Router Class Initialized
INFO - 2021-01-15 08:06:00 --> Output Class Initialized
INFO - 2021-01-15 08:06:00 --> Security Class Initialized
DEBUG - 2021-01-15 08:06:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:06:00 --> Input Class Initialized
INFO - 2021-01-15 08:06:00 --> Language Class Initialized
INFO - 2021-01-15 08:06:00 --> Language Class Initialized
INFO - 2021-01-15 08:06:00 --> Config Class Initialized
INFO - 2021-01-15 08:06:00 --> Loader Class Initialized
INFO - 2021-01-15 08:06:00 --> Helper loaded: url_helper
INFO - 2021-01-15 08:06:00 --> Helper loaded: file_helper
INFO - 2021-01-15 08:06:00 --> Helper loaded: form_helper
INFO - 2021-01-15 08:06:00 --> Helper loaded: my_helper
INFO - 2021-01-15 08:06:00 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:06:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:06:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:06:00 --> Controller Class Initialized
DEBUG - 2021-01-15 08:06:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:06:00 --> Final output sent to browser
DEBUG - 2021-01-15 08:06:00 --> Total execution time: 0.3114
INFO - 2021-01-15 08:06:10 --> Config Class Initialized
INFO - 2021-01-15 08:06:10 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:06:10 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:06:10 --> Utf8 Class Initialized
INFO - 2021-01-15 08:06:10 --> URI Class Initialized
INFO - 2021-01-15 08:06:10 --> Router Class Initialized
INFO - 2021-01-15 08:06:10 --> Output Class Initialized
INFO - 2021-01-15 08:06:10 --> Security Class Initialized
DEBUG - 2021-01-15 08:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:06:10 --> Input Class Initialized
INFO - 2021-01-15 08:06:10 --> Language Class Initialized
INFO - 2021-01-15 08:06:10 --> Language Class Initialized
INFO - 2021-01-15 08:06:10 --> Config Class Initialized
INFO - 2021-01-15 08:06:10 --> Loader Class Initialized
INFO - 2021-01-15 08:06:10 --> Helper loaded: url_helper
INFO - 2021-01-15 08:06:10 --> Helper loaded: file_helper
INFO - 2021-01-15 08:06:10 --> Helper loaded: form_helper
INFO - 2021-01-15 08:06:10 --> Helper loaded: my_helper
INFO - 2021-01-15 08:06:10 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:06:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:06:10 --> Controller Class Initialized
DEBUG - 2021-01-15 08:06:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:06:10 --> Final output sent to browser
DEBUG - 2021-01-15 08:06:10 --> Total execution time: 0.3206
INFO - 2021-01-15 08:06:24 --> Config Class Initialized
INFO - 2021-01-15 08:06:24 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:06:24 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:06:24 --> Utf8 Class Initialized
INFO - 2021-01-15 08:06:24 --> URI Class Initialized
INFO - 2021-01-15 08:06:24 --> Router Class Initialized
INFO - 2021-01-15 08:06:24 --> Output Class Initialized
INFO - 2021-01-15 08:06:24 --> Security Class Initialized
DEBUG - 2021-01-15 08:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:06:24 --> Input Class Initialized
INFO - 2021-01-15 08:06:24 --> Language Class Initialized
INFO - 2021-01-15 08:06:24 --> Language Class Initialized
INFO - 2021-01-15 08:06:24 --> Config Class Initialized
INFO - 2021-01-15 08:06:24 --> Loader Class Initialized
INFO - 2021-01-15 08:06:24 --> Helper loaded: url_helper
INFO - 2021-01-15 08:06:24 --> Helper loaded: file_helper
INFO - 2021-01-15 08:06:24 --> Helper loaded: form_helper
INFO - 2021-01-15 08:06:24 --> Helper loaded: my_helper
INFO - 2021-01-15 08:06:24 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:06:24 --> Controller Class Initialized
DEBUG - 2021-01-15 08:06:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:06:24 --> Final output sent to browser
DEBUG - 2021-01-15 08:06:24 --> Total execution time: 0.3222
INFO - 2021-01-15 08:07:27 --> Config Class Initialized
INFO - 2021-01-15 08:07:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:07:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:07:27 --> Utf8 Class Initialized
INFO - 2021-01-15 08:07:27 --> URI Class Initialized
INFO - 2021-01-15 08:07:27 --> Router Class Initialized
INFO - 2021-01-15 08:07:27 --> Output Class Initialized
INFO - 2021-01-15 08:07:27 --> Security Class Initialized
DEBUG - 2021-01-15 08:07:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:07:27 --> Input Class Initialized
INFO - 2021-01-15 08:07:28 --> Language Class Initialized
INFO - 2021-01-15 08:07:28 --> Language Class Initialized
INFO - 2021-01-15 08:07:28 --> Config Class Initialized
INFO - 2021-01-15 08:07:28 --> Loader Class Initialized
INFO - 2021-01-15 08:07:28 --> Helper loaded: url_helper
INFO - 2021-01-15 08:07:28 --> Helper loaded: file_helper
INFO - 2021-01-15 08:07:28 --> Helper loaded: form_helper
INFO - 2021-01-15 08:07:28 --> Helper loaded: my_helper
INFO - 2021-01-15 08:07:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:07:28 --> Controller Class Initialized
DEBUG - 2021-01-15 08:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:07:28 --> Final output sent to browser
DEBUG - 2021-01-15 08:07:28 --> Total execution time: 0.3188
INFO - 2021-01-15 08:11:45 --> Config Class Initialized
INFO - 2021-01-15 08:11:45 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:11:45 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:11:45 --> Utf8 Class Initialized
INFO - 2021-01-15 08:11:45 --> URI Class Initialized
INFO - 2021-01-15 08:11:45 --> Router Class Initialized
INFO - 2021-01-15 08:11:45 --> Output Class Initialized
INFO - 2021-01-15 08:11:45 --> Security Class Initialized
DEBUG - 2021-01-15 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:11:45 --> Input Class Initialized
INFO - 2021-01-15 08:11:45 --> Language Class Initialized
INFO - 2021-01-15 08:11:45 --> Language Class Initialized
INFO - 2021-01-15 08:11:45 --> Config Class Initialized
INFO - 2021-01-15 08:11:45 --> Loader Class Initialized
INFO - 2021-01-15 08:11:45 --> Helper loaded: url_helper
INFO - 2021-01-15 08:11:45 --> Helper loaded: file_helper
INFO - 2021-01-15 08:11:45 --> Helper loaded: form_helper
INFO - 2021-01-15 08:11:45 --> Helper loaded: my_helper
INFO - 2021-01-15 08:11:45 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:11:45 --> Controller Class Initialized
DEBUG - 2021-01-15 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:11:45 --> Final output sent to browser
DEBUG - 2021-01-15 08:11:45 --> Total execution time: 0.3796
INFO - 2021-01-15 08:11:47 --> Config Class Initialized
INFO - 2021-01-15 08:11:47 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:11:47 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:11:47 --> Utf8 Class Initialized
INFO - 2021-01-15 08:11:47 --> URI Class Initialized
INFO - 2021-01-15 08:11:47 --> Router Class Initialized
INFO - 2021-01-15 08:11:47 --> Output Class Initialized
INFO - 2021-01-15 08:11:47 --> Security Class Initialized
DEBUG - 2021-01-15 08:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:11:47 --> Input Class Initialized
INFO - 2021-01-15 08:11:47 --> Language Class Initialized
INFO - 2021-01-15 08:11:47 --> Language Class Initialized
INFO - 2021-01-15 08:11:47 --> Config Class Initialized
INFO - 2021-01-15 08:11:47 --> Loader Class Initialized
INFO - 2021-01-15 08:11:47 --> Helper loaded: url_helper
INFO - 2021-01-15 08:11:47 --> Helper loaded: file_helper
INFO - 2021-01-15 08:11:47 --> Helper loaded: form_helper
INFO - 2021-01-15 08:11:47 --> Helper loaded: my_helper
INFO - 2021-01-15 08:11:47 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:11:47 --> Controller Class Initialized
DEBUG - 2021-01-15 08:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-15 08:11:47 --> Final output sent to browser
DEBUG - 2021-01-15 08:11:47 --> Total execution time: 0.4142
INFO - 2021-01-15 08:13:20 --> Config Class Initialized
INFO - 2021-01-15 08:13:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:13:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:13:20 --> Utf8 Class Initialized
INFO - 2021-01-15 08:13:20 --> URI Class Initialized
INFO - 2021-01-15 08:13:20 --> Router Class Initialized
INFO - 2021-01-15 08:13:20 --> Output Class Initialized
INFO - 2021-01-15 08:13:20 --> Security Class Initialized
DEBUG - 2021-01-15 08:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:13:21 --> Input Class Initialized
INFO - 2021-01-15 08:13:21 --> Language Class Initialized
INFO - 2021-01-15 08:13:21 --> Language Class Initialized
INFO - 2021-01-15 08:13:21 --> Config Class Initialized
INFO - 2021-01-15 08:13:21 --> Loader Class Initialized
INFO - 2021-01-15 08:13:21 --> Helper loaded: url_helper
INFO - 2021-01-15 08:13:21 --> Helper loaded: file_helper
INFO - 2021-01-15 08:13:21 --> Helper loaded: form_helper
INFO - 2021-01-15 08:13:21 --> Helper loaded: my_helper
INFO - 2021-01-15 08:13:21 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:13:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:13:21 --> Controller Class Initialized
DEBUG - 2021-01-15 08:13:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2021-01-15 08:13:21 --> Final output sent to browser
DEBUG - 2021-01-15 08:13:21 --> Total execution time: 0.4418
INFO - 2021-01-15 08:13:23 --> Config Class Initialized
INFO - 2021-01-15 08:13:23 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:13:23 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:13:23 --> Utf8 Class Initialized
INFO - 2021-01-15 08:13:23 --> URI Class Initialized
INFO - 2021-01-15 08:13:23 --> Router Class Initialized
INFO - 2021-01-15 08:13:23 --> Output Class Initialized
INFO - 2021-01-15 08:13:23 --> Security Class Initialized
DEBUG - 2021-01-15 08:13:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:13:23 --> Input Class Initialized
INFO - 2021-01-15 08:13:23 --> Language Class Initialized
INFO - 2021-01-15 08:13:23 --> Language Class Initialized
INFO - 2021-01-15 08:13:23 --> Config Class Initialized
INFO - 2021-01-15 08:13:23 --> Loader Class Initialized
INFO - 2021-01-15 08:13:23 --> Helper loaded: url_helper
INFO - 2021-01-15 08:13:23 --> Helper loaded: file_helper
INFO - 2021-01-15 08:13:23 --> Helper loaded: form_helper
INFO - 2021-01-15 08:13:23 --> Helper loaded: my_helper
INFO - 2021-01-15 08:13:23 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:13:23 --> Controller Class Initialized
DEBUG - 2021-01-15 08:13:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:13:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:13:23 --> Final output sent to browser
DEBUG - 2021-01-15 08:13:23 --> Total execution time: 0.4196
INFO - 2021-01-15 08:13:25 --> Config Class Initialized
INFO - 2021-01-15 08:13:25 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:13:25 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:13:25 --> Utf8 Class Initialized
INFO - 2021-01-15 08:13:25 --> URI Class Initialized
INFO - 2021-01-15 08:13:25 --> Router Class Initialized
INFO - 2021-01-15 08:13:25 --> Output Class Initialized
INFO - 2021-01-15 08:13:25 --> Security Class Initialized
DEBUG - 2021-01-15 08:13:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:13:25 --> Input Class Initialized
INFO - 2021-01-15 08:13:25 --> Language Class Initialized
INFO - 2021-01-15 08:13:25 --> Language Class Initialized
INFO - 2021-01-15 08:13:25 --> Config Class Initialized
INFO - 2021-01-15 08:13:25 --> Loader Class Initialized
INFO - 2021-01-15 08:13:25 --> Helper loaded: url_helper
INFO - 2021-01-15 08:13:25 --> Helper loaded: file_helper
INFO - 2021-01-15 08:13:25 --> Helper loaded: form_helper
INFO - 2021-01-15 08:13:25 --> Helper loaded: my_helper
INFO - 2021-01-15 08:13:25 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:13:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:13:25 --> Controller Class Initialized
DEBUG - 2021-01-15 08:13:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-01-15 08:13:25 --> Final output sent to browser
DEBUG - 2021-01-15 08:13:25 --> Total execution time: 0.3735
INFO - 2021-01-15 08:13:32 --> Config Class Initialized
INFO - 2021-01-15 08:13:32 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:13:32 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:13:32 --> Utf8 Class Initialized
INFO - 2021-01-15 08:13:32 --> URI Class Initialized
INFO - 2021-01-15 08:13:32 --> Router Class Initialized
INFO - 2021-01-15 08:13:32 --> Output Class Initialized
INFO - 2021-01-15 08:13:32 --> Security Class Initialized
DEBUG - 2021-01-15 08:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:13:32 --> Input Class Initialized
INFO - 2021-01-15 08:13:32 --> Language Class Initialized
INFO - 2021-01-15 08:13:32 --> Language Class Initialized
INFO - 2021-01-15 08:13:32 --> Config Class Initialized
INFO - 2021-01-15 08:13:32 --> Loader Class Initialized
INFO - 2021-01-15 08:13:32 --> Helper loaded: url_helper
INFO - 2021-01-15 08:13:32 --> Helper loaded: file_helper
INFO - 2021-01-15 08:13:32 --> Helper loaded: form_helper
INFO - 2021-01-15 08:13:32 --> Helper loaded: my_helper
INFO - 2021-01-15 08:13:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:13:32 --> Controller Class Initialized
DEBUG - 2021-01-15 08:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:13:32 --> Final output sent to browser
DEBUG - 2021-01-15 08:13:33 --> Total execution time: 0.3557
INFO - 2021-01-15 08:13:38 --> Config Class Initialized
INFO - 2021-01-15 08:13:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:13:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:13:38 --> Utf8 Class Initialized
INFO - 2021-01-15 08:13:38 --> URI Class Initialized
INFO - 2021-01-15 08:13:38 --> Router Class Initialized
INFO - 2021-01-15 08:13:38 --> Output Class Initialized
INFO - 2021-01-15 08:13:38 --> Security Class Initialized
DEBUG - 2021-01-15 08:13:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:13:38 --> Input Class Initialized
INFO - 2021-01-15 08:13:38 --> Language Class Initialized
ERROR - 2021-01-15 08:13:38 --> 404 Page Not Found: ../modules/cetak_leger/controllers/Cetak_leger/cetak_tkro_xi
INFO - 2021-01-15 08:19:19 --> Config Class Initialized
INFO - 2021-01-15 08:19:19 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:19:19 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:19:20 --> Utf8 Class Initialized
INFO - 2021-01-15 08:19:20 --> URI Class Initialized
INFO - 2021-01-15 08:19:20 --> Router Class Initialized
INFO - 2021-01-15 08:19:20 --> Output Class Initialized
INFO - 2021-01-15 08:19:20 --> Security Class Initialized
DEBUG - 2021-01-15 08:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:19:20 --> Input Class Initialized
INFO - 2021-01-15 08:19:20 --> Language Class Initialized
INFO - 2021-01-15 08:19:20 --> Language Class Initialized
INFO - 2021-01-15 08:19:20 --> Config Class Initialized
INFO - 2021-01-15 08:19:20 --> Loader Class Initialized
INFO - 2021-01-15 08:19:20 --> Helper loaded: url_helper
INFO - 2021-01-15 08:19:20 --> Helper loaded: file_helper
INFO - 2021-01-15 08:19:20 --> Helper loaded: form_helper
INFO - 2021-01-15 08:19:20 --> Helper loaded: my_helper
INFO - 2021-01-15 08:19:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:19:20 --> Controller Class Initialized
DEBUG - 2021-01-15 08:19:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 08:19:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:19:20 --> Final output sent to browser
DEBUG - 2021-01-15 08:19:20 --> Total execution time: 0.4287
INFO - 2021-01-15 08:19:21 --> Config Class Initialized
INFO - 2021-01-15 08:19:21 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:19:22 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:19:22 --> Utf8 Class Initialized
INFO - 2021-01-15 08:19:22 --> URI Class Initialized
INFO - 2021-01-15 08:19:22 --> Router Class Initialized
INFO - 2021-01-15 08:19:22 --> Output Class Initialized
INFO - 2021-01-15 08:19:22 --> Security Class Initialized
DEBUG - 2021-01-15 08:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:19:22 --> Input Class Initialized
INFO - 2021-01-15 08:19:22 --> Language Class Initialized
INFO - 2021-01-15 08:19:22 --> Language Class Initialized
INFO - 2021-01-15 08:19:22 --> Config Class Initialized
INFO - 2021-01-15 08:19:22 --> Loader Class Initialized
INFO - 2021-01-15 08:19:22 --> Helper loaded: url_helper
INFO - 2021-01-15 08:19:22 --> Helper loaded: file_helper
INFO - 2021-01-15 08:19:22 --> Helper loaded: form_helper
INFO - 2021-01-15 08:19:22 --> Helper loaded: my_helper
INFO - 2021-01-15 08:19:22 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:19:22 --> Controller Class Initialized
DEBUG - 2021-01-15 08:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-01-15 08:19:22 --> Final output sent to browser
DEBUG - 2021-01-15 08:19:22 --> Total execution time: 0.3600
INFO - 2021-01-15 08:19:32 --> Config Class Initialized
INFO - 2021-01-15 08:19:32 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:19:32 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:19:32 --> Utf8 Class Initialized
INFO - 2021-01-15 08:19:32 --> URI Class Initialized
INFO - 2021-01-15 08:19:32 --> Router Class Initialized
INFO - 2021-01-15 08:19:32 --> Output Class Initialized
INFO - 2021-01-15 08:19:32 --> Security Class Initialized
DEBUG - 2021-01-15 08:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:19:32 --> Input Class Initialized
INFO - 2021-01-15 08:19:32 --> Language Class Initialized
INFO - 2021-01-15 08:19:32 --> Language Class Initialized
INFO - 2021-01-15 08:19:32 --> Config Class Initialized
INFO - 2021-01-15 08:19:32 --> Loader Class Initialized
INFO - 2021-01-15 08:19:32 --> Helper loaded: url_helper
INFO - 2021-01-15 08:19:32 --> Helper loaded: file_helper
INFO - 2021-01-15 08:19:32 --> Helper loaded: form_helper
INFO - 2021-01-15 08:19:32 --> Helper loaded: my_helper
INFO - 2021-01-15 08:19:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:19:32 --> Controller Class Initialized
DEBUG - 2021-01-15 08:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xii.php
INFO - 2021-01-15 08:19:32 --> Final output sent to browser
DEBUG - 2021-01-15 08:19:32 --> Total execution time: 0.4140
INFO - 2021-01-15 08:23:00 --> Config Class Initialized
INFO - 2021-01-15 08:23:00 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:23:00 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:23:00 --> Utf8 Class Initialized
INFO - 2021-01-15 08:23:00 --> URI Class Initialized
INFO - 2021-01-15 08:23:00 --> Router Class Initialized
INFO - 2021-01-15 08:23:00 --> Output Class Initialized
INFO - 2021-01-15 08:23:00 --> Security Class Initialized
DEBUG - 2021-01-15 08:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:23:00 --> Input Class Initialized
INFO - 2021-01-15 08:23:00 --> Language Class Initialized
INFO - 2021-01-15 08:23:00 --> Language Class Initialized
INFO - 2021-01-15 08:23:00 --> Config Class Initialized
INFO - 2021-01-15 08:23:00 --> Loader Class Initialized
INFO - 2021-01-15 08:23:00 --> Helper loaded: url_helper
INFO - 2021-01-15 08:23:00 --> Helper loaded: file_helper
INFO - 2021-01-15 08:23:00 --> Helper loaded: form_helper
INFO - 2021-01-15 08:23:00 --> Helper loaded: my_helper
INFO - 2021-01-15 08:23:00 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:23:00 --> Controller Class Initialized
DEBUG - 2021-01-15 08:23:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 08:23:00 --> Final output sent to browser
DEBUG - 2021-01-15 08:23:00 --> Total execution time: 0.4513
INFO - 2021-01-15 08:23:05 --> Config Class Initialized
INFO - 2021-01-15 08:23:05 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:23:05 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:23:05 --> Utf8 Class Initialized
INFO - 2021-01-15 08:23:05 --> URI Class Initialized
INFO - 2021-01-15 08:23:05 --> Router Class Initialized
INFO - 2021-01-15 08:23:05 --> Output Class Initialized
INFO - 2021-01-15 08:23:05 --> Security Class Initialized
DEBUG - 2021-01-15 08:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:23:05 --> Input Class Initialized
INFO - 2021-01-15 08:23:05 --> Language Class Initialized
INFO - 2021-01-15 08:23:05 --> Language Class Initialized
INFO - 2021-01-15 08:23:05 --> Config Class Initialized
INFO - 2021-01-15 08:23:05 --> Loader Class Initialized
INFO - 2021-01-15 08:23:05 --> Helper loaded: url_helper
INFO - 2021-01-15 08:23:05 --> Helper loaded: file_helper
INFO - 2021-01-15 08:23:05 --> Helper loaded: form_helper
INFO - 2021-01-15 08:23:05 --> Helper loaded: my_helper
INFO - 2021-01-15 08:23:05 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:23:05 --> Controller Class Initialized
DEBUG - 2021-01-15 08:23:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:23:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:23:05 --> Final output sent to browser
DEBUG - 2021-01-15 08:23:05 --> Total execution time: 0.3869
INFO - 2021-01-15 08:23:06 --> Config Class Initialized
INFO - 2021-01-15 08:23:06 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:23:06 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:23:06 --> Utf8 Class Initialized
INFO - 2021-01-15 08:23:06 --> URI Class Initialized
INFO - 2021-01-15 08:23:06 --> Router Class Initialized
INFO - 2021-01-15 08:23:07 --> Output Class Initialized
INFO - 2021-01-15 08:23:07 --> Security Class Initialized
DEBUG - 2021-01-15 08:23:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:23:07 --> Input Class Initialized
INFO - 2021-01-15 08:23:07 --> Language Class Initialized
INFO - 2021-01-15 08:23:07 --> Language Class Initialized
INFO - 2021-01-15 08:23:07 --> Config Class Initialized
INFO - 2021-01-15 08:23:07 --> Loader Class Initialized
INFO - 2021-01-15 08:23:07 --> Helper loaded: url_helper
INFO - 2021-01-15 08:23:07 --> Helper loaded: file_helper
INFO - 2021-01-15 08:23:07 --> Helper loaded: form_helper
INFO - 2021-01-15 08:23:07 --> Helper loaded: my_helper
INFO - 2021-01-15 08:23:07 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:23:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:23:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:23:07 --> Controller Class Initialized
DEBUG - 2021-01-15 08:23:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:23:07 --> Final output sent to browser
DEBUG - 2021-01-15 08:23:07 --> Total execution time: 0.3952
INFO - 2021-01-15 08:23:08 --> Config Class Initialized
INFO - 2021-01-15 08:23:08 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:23:09 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:23:09 --> Utf8 Class Initialized
INFO - 2021-01-15 08:23:09 --> URI Class Initialized
INFO - 2021-01-15 08:23:09 --> Router Class Initialized
INFO - 2021-01-15 08:23:09 --> Output Class Initialized
INFO - 2021-01-15 08:23:09 --> Security Class Initialized
DEBUG - 2021-01-15 08:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:23:09 --> Input Class Initialized
INFO - 2021-01-15 08:23:09 --> Language Class Initialized
INFO - 2021-01-15 08:23:09 --> Language Class Initialized
INFO - 2021-01-15 08:23:09 --> Config Class Initialized
INFO - 2021-01-15 08:23:09 --> Loader Class Initialized
INFO - 2021-01-15 08:23:09 --> Helper loaded: url_helper
INFO - 2021-01-15 08:23:09 --> Helper loaded: file_helper
INFO - 2021-01-15 08:23:09 --> Helper loaded: form_helper
INFO - 2021-01-15 08:23:09 --> Helper loaded: my_helper
INFO - 2021-01-15 08:23:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:23:09 --> Controller Class Initialized
DEBUG - 2021-01-15 08:23:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-01-15 08:23:09 --> Final output sent to browser
DEBUG - 2021-01-15 08:23:09 --> Total execution time: 0.3598
INFO - 2021-01-15 08:26:38 --> Config Class Initialized
INFO - 2021-01-15 08:26:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:26:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:26:38 --> Utf8 Class Initialized
INFO - 2021-01-15 08:26:38 --> URI Class Initialized
INFO - 2021-01-15 08:26:38 --> Router Class Initialized
INFO - 2021-01-15 08:26:38 --> Output Class Initialized
INFO - 2021-01-15 08:26:38 --> Security Class Initialized
DEBUG - 2021-01-15 08:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:26:38 --> Input Class Initialized
INFO - 2021-01-15 08:26:38 --> Language Class Initialized
INFO - 2021-01-15 08:26:38 --> Language Class Initialized
INFO - 2021-01-15 08:26:38 --> Config Class Initialized
INFO - 2021-01-15 08:26:38 --> Loader Class Initialized
INFO - 2021-01-15 08:26:38 --> Helper loaded: url_helper
INFO - 2021-01-15 08:26:38 --> Helper loaded: file_helper
INFO - 2021-01-15 08:26:38 --> Helper loaded: form_helper
INFO - 2021-01-15 08:26:38 --> Helper loaded: my_helper
INFO - 2021-01-15 08:26:38 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:26:39 --> Controller Class Initialized
DEBUG - 2021-01-15 08:26:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:26:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:26:39 --> Final output sent to browser
DEBUG - 2021-01-15 08:26:39 --> Total execution time: 0.4542
INFO - 2021-01-15 08:26:40 --> Config Class Initialized
INFO - 2021-01-15 08:26:40 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:26:40 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:26:40 --> Utf8 Class Initialized
INFO - 2021-01-15 08:26:40 --> URI Class Initialized
INFO - 2021-01-15 08:26:40 --> Router Class Initialized
INFO - 2021-01-15 08:26:40 --> Output Class Initialized
INFO - 2021-01-15 08:26:40 --> Security Class Initialized
DEBUG - 2021-01-15 08:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:26:40 --> Input Class Initialized
INFO - 2021-01-15 08:26:40 --> Language Class Initialized
INFO - 2021-01-15 08:26:40 --> Language Class Initialized
INFO - 2021-01-15 08:26:40 --> Config Class Initialized
INFO - 2021-01-15 08:26:40 --> Loader Class Initialized
INFO - 2021-01-15 08:26:40 --> Helper loaded: url_helper
INFO - 2021-01-15 08:26:40 --> Helper loaded: file_helper
INFO - 2021-01-15 08:26:40 --> Helper loaded: form_helper
INFO - 2021-01-15 08:26:40 --> Helper loaded: my_helper
INFO - 2021-01-15 08:26:40 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:26:40 --> Controller Class Initialized
DEBUG - 2021-01-15 08:26:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2021-01-15 08:26:40 --> Final output sent to browser
DEBUG - 2021-01-15 08:26:40 --> Total execution time: 0.3665
INFO - 2021-01-15 08:26:43 --> Config Class Initialized
INFO - 2021-01-15 08:26:43 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:26:43 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:26:43 --> Utf8 Class Initialized
INFO - 2021-01-15 08:26:43 --> URI Class Initialized
INFO - 2021-01-15 08:26:43 --> Router Class Initialized
INFO - 2021-01-15 08:26:43 --> Output Class Initialized
INFO - 2021-01-15 08:26:43 --> Security Class Initialized
DEBUG - 2021-01-15 08:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:26:43 --> Input Class Initialized
INFO - 2021-01-15 08:26:43 --> Language Class Initialized
INFO - 2021-01-15 08:26:43 --> Language Class Initialized
INFO - 2021-01-15 08:26:43 --> Config Class Initialized
INFO - 2021-01-15 08:26:43 --> Loader Class Initialized
INFO - 2021-01-15 08:26:43 --> Helper loaded: url_helper
INFO - 2021-01-15 08:26:43 --> Helper loaded: file_helper
INFO - 2021-01-15 08:26:43 --> Helper loaded: form_helper
INFO - 2021-01-15 08:26:43 --> Helper loaded: my_helper
INFO - 2021-01-15 08:26:43 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:26:43 --> Controller Class Initialized
DEBUG - 2021-01-15 08:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-01-15 08:26:43 --> Final output sent to browser
DEBUG - 2021-01-15 08:26:43 --> Total execution time: 0.3391
INFO - 2021-01-15 08:29:18 --> Config Class Initialized
INFO - 2021-01-15 08:29:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:29:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:29:18 --> Utf8 Class Initialized
INFO - 2021-01-15 08:29:18 --> URI Class Initialized
INFO - 2021-01-15 08:29:18 --> Router Class Initialized
INFO - 2021-01-15 08:29:18 --> Output Class Initialized
INFO - 2021-01-15 08:29:18 --> Security Class Initialized
DEBUG - 2021-01-15 08:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:29:18 --> Input Class Initialized
INFO - 2021-01-15 08:29:18 --> Language Class Initialized
INFO - 2021-01-15 08:29:18 --> Language Class Initialized
INFO - 2021-01-15 08:29:18 --> Config Class Initialized
INFO - 2021-01-15 08:29:18 --> Loader Class Initialized
INFO - 2021-01-15 08:29:18 --> Helper loaded: url_helper
INFO - 2021-01-15 08:29:18 --> Helper loaded: file_helper
INFO - 2021-01-15 08:29:18 --> Helper loaded: form_helper
INFO - 2021-01-15 08:29:18 --> Helper loaded: my_helper
INFO - 2021-01-15 08:29:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:29:18 --> Controller Class Initialized
DEBUG - 2021-01-15 08:29:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-01-15 08:29:18 --> Final output sent to browser
DEBUG - 2021-01-15 08:29:18 --> Total execution time: 0.3532
INFO - 2021-01-15 08:29:24 --> Config Class Initialized
INFO - 2021-01-15 08:29:24 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:29:24 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:29:24 --> Utf8 Class Initialized
INFO - 2021-01-15 08:29:24 --> URI Class Initialized
INFO - 2021-01-15 08:29:24 --> Router Class Initialized
INFO - 2021-01-15 08:29:24 --> Output Class Initialized
INFO - 2021-01-15 08:29:24 --> Security Class Initialized
DEBUG - 2021-01-15 08:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:29:25 --> Input Class Initialized
INFO - 2021-01-15 08:29:25 --> Language Class Initialized
INFO - 2021-01-15 08:29:25 --> Language Class Initialized
INFO - 2021-01-15 08:29:25 --> Config Class Initialized
INFO - 2021-01-15 08:29:25 --> Loader Class Initialized
INFO - 2021-01-15 08:29:25 --> Helper loaded: url_helper
INFO - 2021-01-15 08:29:25 --> Helper loaded: file_helper
INFO - 2021-01-15 08:29:25 --> Helper loaded: form_helper
INFO - 2021-01-15 08:29:25 --> Helper loaded: my_helper
INFO - 2021-01-15 08:29:25 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:29:25 --> Controller Class Initialized
ERROR - 2021-01-15 08:29:25 --> Severity: Notice --> Undefined variable: s_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 1410
ERROR - 2021-01-15 08:29:25 --> Severity: Warning --> mysqli::query(): Empty query C:\xampp\htdocs\nilai\system\database\drivers\mysqli\mysqli_driver.php 306
ERROR - 2021-01-15 08:29:25 --> Query error:  - Invalid query: 
INFO - 2021-01-15 08:29:25 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-15 08:29:50 --> Config Class Initialized
INFO - 2021-01-15 08:29:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:29:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:29:50 --> Utf8 Class Initialized
INFO - 2021-01-15 08:29:50 --> URI Class Initialized
INFO - 2021-01-15 08:29:50 --> Router Class Initialized
INFO - 2021-01-15 08:29:50 --> Output Class Initialized
INFO - 2021-01-15 08:29:50 --> Security Class Initialized
DEBUG - 2021-01-15 08:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:29:50 --> Input Class Initialized
INFO - 2021-01-15 08:29:50 --> Language Class Initialized
INFO - 2021-01-15 08:29:50 --> Language Class Initialized
INFO - 2021-01-15 08:29:50 --> Config Class Initialized
INFO - 2021-01-15 08:29:50 --> Loader Class Initialized
INFO - 2021-01-15 08:29:50 --> Helper loaded: url_helper
INFO - 2021-01-15 08:29:50 --> Helper loaded: file_helper
INFO - 2021-01-15 08:29:50 --> Helper loaded: form_helper
INFO - 2021-01-15 08:29:50 --> Helper loaded: my_helper
INFO - 2021-01-15 08:29:50 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:29:50 --> Controller Class Initialized
DEBUG - 2021-01-15 08:29:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-01-15 08:29:50 --> Final output sent to browser
DEBUG - 2021-01-15 08:29:50 --> Total execution time: 0.3344
INFO - 2021-01-15 08:29:56 --> Config Class Initialized
INFO - 2021-01-15 08:29:56 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:29:56 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:29:56 --> Utf8 Class Initialized
INFO - 2021-01-15 08:29:56 --> URI Class Initialized
INFO - 2021-01-15 08:29:56 --> Router Class Initialized
INFO - 2021-01-15 08:29:56 --> Output Class Initialized
INFO - 2021-01-15 08:29:56 --> Security Class Initialized
DEBUG - 2021-01-15 08:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:29:56 --> Input Class Initialized
INFO - 2021-01-15 08:29:56 --> Language Class Initialized
INFO - 2021-01-15 08:29:56 --> Language Class Initialized
INFO - 2021-01-15 08:29:56 --> Config Class Initialized
INFO - 2021-01-15 08:29:56 --> Loader Class Initialized
INFO - 2021-01-15 08:29:56 --> Helper loaded: url_helper
INFO - 2021-01-15 08:29:56 --> Helper loaded: file_helper
INFO - 2021-01-15 08:29:56 --> Helper loaded: form_helper
INFO - 2021-01-15 08:29:56 --> Helper loaded: my_helper
INFO - 2021-01-15 08:29:56 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:29:56 --> Controller Class Initialized
DEBUG - 2021-01-15 08:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2021-01-15 08:29:56 --> Final output sent to browser
DEBUG - 2021-01-15 08:29:56 --> Total execution time: 0.3512
INFO - 2021-01-15 08:32:10 --> Config Class Initialized
INFO - 2021-01-15 08:32:10 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:10 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:10 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:10 --> URI Class Initialized
INFO - 2021-01-15 08:32:10 --> Router Class Initialized
INFO - 2021-01-15 08:32:10 --> Output Class Initialized
INFO - 2021-01-15 08:32:10 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:10 --> Input Class Initialized
INFO - 2021-01-15 08:32:10 --> Language Class Initialized
INFO - 2021-01-15 08:32:10 --> Language Class Initialized
INFO - 2021-01-15 08:32:10 --> Config Class Initialized
INFO - 2021-01-15 08:32:10 --> Loader Class Initialized
INFO - 2021-01-15 08:32:10 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:10 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:10 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:10 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:10 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:11 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:32:11 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:11 --> Total execution time: 0.4223
INFO - 2021-01-15 08:32:11 --> Config Class Initialized
INFO - 2021-01-15 08:32:11 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:11 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:11 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:11 --> URI Class Initialized
INFO - 2021-01-15 08:32:11 --> Router Class Initialized
INFO - 2021-01-15 08:32:11 --> Output Class Initialized
INFO - 2021-01-15 08:32:11 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:11 --> Input Class Initialized
INFO - 2021-01-15 08:32:11 --> Language Class Initialized
INFO - 2021-01-15 08:32:11 --> Language Class Initialized
INFO - 2021-01-15 08:32:11 --> Config Class Initialized
INFO - 2021-01-15 08:32:11 --> Loader Class Initialized
INFO - 2021-01-15 08:32:11 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:11 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:11 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:12 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:12 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:12 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2021-01-15 08:32:12 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:12 --> Total execution time: 0.3385
INFO - 2021-01-15 08:32:18 --> Config Class Initialized
INFO - 2021-01-15 08:32:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:18 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:18 --> URI Class Initialized
INFO - 2021-01-15 08:32:19 --> Router Class Initialized
INFO - 2021-01-15 08:32:19 --> Output Class Initialized
INFO - 2021-01-15 08:32:19 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:19 --> Input Class Initialized
INFO - 2021-01-15 08:32:19 --> Language Class Initialized
INFO - 2021-01-15 08:32:19 --> Language Class Initialized
INFO - 2021-01-15 08:32:19 --> Config Class Initialized
INFO - 2021-01-15 08:32:19 --> Loader Class Initialized
INFO - 2021-01-15 08:32:19 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:19 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:19 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:19 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:19 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2021-01-15 08:32:19 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:19 --> Total execution time: 0.3507
INFO - 2021-01-15 08:32:20 --> Config Class Initialized
INFO - 2021-01-15 08:32:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:20 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:20 --> URI Class Initialized
INFO - 2021-01-15 08:32:20 --> Router Class Initialized
INFO - 2021-01-15 08:32:20 --> Output Class Initialized
INFO - 2021-01-15 08:32:21 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:21 --> Input Class Initialized
INFO - 2021-01-15 08:32:21 --> Language Class Initialized
ERROR - 2021-01-15 08:32:21 --> 404 Page Not Found: ../modules/cetak_leger/controllers/Cetak_leger/cetak_otr_xi
INFO - 2021-01-15 08:32:22 --> Config Class Initialized
INFO - 2021-01-15 08:32:22 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:23 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:23 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:23 --> URI Class Initialized
INFO - 2021-01-15 08:32:23 --> Router Class Initialized
INFO - 2021-01-15 08:32:23 --> Output Class Initialized
INFO - 2021-01-15 08:32:23 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:23 --> Input Class Initialized
INFO - 2021-01-15 08:32:23 --> Language Class Initialized
INFO - 2021-01-15 08:32:23 --> Language Class Initialized
INFO - 2021-01-15 08:32:23 --> Config Class Initialized
INFO - 2021-01-15 08:32:23 --> Loader Class Initialized
INFO - 2021-01-15 08:32:23 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:23 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:23 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:23 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:23 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:23 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-01-15 08:32:23 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:23 --> Total execution time: 0.3709
INFO - 2021-01-15 08:32:29 --> Config Class Initialized
INFO - 2021-01-15 08:32:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:30 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:30 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:30 --> URI Class Initialized
INFO - 2021-01-15 08:32:30 --> Router Class Initialized
INFO - 2021-01-15 08:32:30 --> Output Class Initialized
INFO - 2021-01-15 08:32:30 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:30 --> Input Class Initialized
INFO - 2021-01-15 08:32:30 --> Language Class Initialized
INFO - 2021-01-15 08:32:30 --> Language Class Initialized
INFO - 2021-01-15 08:32:30 --> Config Class Initialized
INFO - 2021-01-15 08:32:30 --> Loader Class Initialized
INFO - 2021-01-15 08:32:30 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:30 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:30 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:30 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:30 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:30 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-01-15 08:32:30 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:30 --> Total execution time: 0.4114
INFO - 2021-01-15 08:32:32 --> Config Class Initialized
INFO - 2021-01-15 08:32:32 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:32 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:32 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:32 --> URI Class Initialized
INFO - 2021-01-15 08:32:32 --> Router Class Initialized
INFO - 2021-01-15 08:32:32 --> Output Class Initialized
INFO - 2021-01-15 08:32:32 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:32 --> Input Class Initialized
INFO - 2021-01-15 08:32:32 --> Language Class Initialized
INFO - 2021-01-15 08:32:32 --> Language Class Initialized
INFO - 2021-01-15 08:32:32 --> Config Class Initialized
INFO - 2021-01-15 08:32:32 --> Loader Class Initialized
INFO - 2021-01-15 08:32:32 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:32 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:32 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:32 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:32 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-01-15 08:32:32 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:32 --> Total execution time: 0.4018
INFO - 2021-01-15 08:32:38 --> Config Class Initialized
INFO - 2021-01-15 08:32:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:38 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:38 --> URI Class Initialized
INFO - 2021-01-15 08:32:38 --> Router Class Initialized
INFO - 2021-01-15 08:32:38 --> Output Class Initialized
INFO - 2021-01-15 08:32:38 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:38 --> Input Class Initialized
INFO - 2021-01-15 08:32:38 --> Language Class Initialized
INFO - 2021-01-15 08:32:38 --> Language Class Initialized
INFO - 2021-01-15 08:32:38 --> Config Class Initialized
INFO - 2021-01-15 08:32:38 --> Loader Class Initialized
INFO - 2021-01-15 08:32:38 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:38 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:38 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:38 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:38 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:38 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2021-01-15 08:32:38 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:38 --> Total execution time: 0.4214
INFO - 2021-01-15 08:32:55 --> Config Class Initialized
INFO - 2021-01-15 08:32:55 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:55 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:55 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:55 --> URI Class Initialized
INFO - 2021-01-15 08:32:55 --> Router Class Initialized
INFO - 2021-01-15 08:32:55 --> Output Class Initialized
INFO - 2021-01-15 08:32:55 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:55 --> Input Class Initialized
INFO - 2021-01-15 08:32:55 --> Language Class Initialized
INFO - 2021-01-15 08:32:56 --> Language Class Initialized
INFO - 2021-01-15 08:32:56 --> Config Class Initialized
INFO - 2021-01-15 08:32:56 --> Loader Class Initialized
INFO - 2021-01-15 08:32:56 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:56 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:56 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:56 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:56 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:56 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:32:56 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:56 --> Total execution time: 0.4842
INFO - 2021-01-15 08:32:56 --> Config Class Initialized
INFO - 2021-01-15 08:32:56 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:32:56 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:32:56 --> Utf8 Class Initialized
INFO - 2021-01-15 08:32:56 --> URI Class Initialized
INFO - 2021-01-15 08:32:56 --> Router Class Initialized
INFO - 2021-01-15 08:32:56 --> Output Class Initialized
INFO - 2021-01-15 08:32:56 --> Security Class Initialized
DEBUG - 2021-01-15 08:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:32:56 --> Input Class Initialized
INFO - 2021-01-15 08:32:56 --> Language Class Initialized
INFO - 2021-01-15 08:32:56 --> Language Class Initialized
INFO - 2021-01-15 08:32:56 --> Config Class Initialized
INFO - 2021-01-15 08:32:56 --> Loader Class Initialized
INFO - 2021-01-15 08:32:56 --> Helper loaded: url_helper
INFO - 2021-01-15 08:32:56 --> Helper loaded: file_helper
INFO - 2021-01-15 08:32:56 --> Helper loaded: form_helper
INFO - 2021-01-15 08:32:56 --> Helper loaded: my_helper
INFO - 2021-01-15 08:32:57 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:32:57 --> Controller Class Initialized
DEBUG - 2021-01-15 08:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2021-01-15 08:32:57 --> Final output sent to browser
DEBUG - 2021-01-15 08:32:57 --> Total execution time: 0.4031
INFO - 2021-01-15 08:33:49 --> Config Class Initialized
INFO - 2021-01-15 08:33:49 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:33:49 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:33:49 --> Utf8 Class Initialized
INFO - 2021-01-15 08:33:49 --> URI Class Initialized
INFO - 2021-01-15 08:33:49 --> Router Class Initialized
INFO - 2021-01-15 08:33:49 --> Output Class Initialized
INFO - 2021-01-15 08:33:50 --> Security Class Initialized
DEBUG - 2021-01-15 08:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:33:50 --> Input Class Initialized
INFO - 2021-01-15 08:33:50 --> Language Class Initialized
INFO - 2021-01-15 08:33:50 --> Language Class Initialized
INFO - 2021-01-15 08:33:50 --> Config Class Initialized
INFO - 2021-01-15 08:33:50 --> Loader Class Initialized
INFO - 2021-01-15 08:33:50 --> Helper loaded: url_helper
INFO - 2021-01-15 08:33:50 --> Helper loaded: file_helper
INFO - 2021-01-15 08:33:50 --> Helper loaded: form_helper
INFO - 2021-01-15 08:33:50 --> Helper loaded: my_helper
INFO - 2021-01-15 08:33:50 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:33:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:33:50 --> Controller Class Initialized
DEBUG - 2021-01-15 08:33:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:33:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:33:50 --> Final output sent to browser
DEBUG - 2021-01-15 08:33:50 --> Total execution time: 0.4754
INFO - 2021-01-15 08:33:50 --> Config Class Initialized
INFO - 2021-01-15 08:33:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:33:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:33:50 --> Utf8 Class Initialized
INFO - 2021-01-15 08:33:51 --> URI Class Initialized
INFO - 2021-01-15 08:33:51 --> Router Class Initialized
INFO - 2021-01-15 08:33:51 --> Output Class Initialized
INFO - 2021-01-15 08:33:51 --> Security Class Initialized
DEBUG - 2021-01-15 08:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:33:51 --> Input Class Initialized
INFO - 2021-01-15 08:33:51 --> Language Class Initialized
INFO - 2021-01-15 08:33:51 --> Language Class Initialized
INFO - 2021-01-15 08:33:51 --> Config Class Initialized
INFO - 2021-01-15 08:33:51 --> Loader Class Initialized
INFO - 2021-01-15 08:33:51 --> Helper loaded: url_helper
INFO - 2021-01-15 08:33:51 --> Helper loaded: file_helper
INFO - 2021-01-15 08:33:51 --> Helper loaded: form_helper
INFO - 2021-01-15 08:33:51 --> Helper loaded: my_helper
INFO - 2021-01-15 08:33:51 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:33:51 --> Controller Class Initialized
DEBUG - 2021-01-15 08:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-01-15 08:33:51 --> Final output sent to browser
DEBUG - 2021-01-15 08:33:51 --> Total execution time: 0.3525
INFO - 2021-01-15 08:34:04 --> Config Class Initialized
INFO - 2021-01-15 08:34:04 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:34:04 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:34:04 --> Utf8 Class Initialized
INFO - 2021-01-15 08:34:04 --> URI Class Initialized
INFO - 2021-01-15 08:34:04 --> Router Class Initialized
INFO - 2021-01-15 08:34:04 --> Output Class Initialized
INFO - 2021-01-15 08:34:04 --> Security Class Initialized
DEBUG - 2021-01-15 08:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:34:04 --> Input Class Initialized
INFO - 2021-01-15 08:34:04 --> Language Class Initialized
INFO - 2021-01-15 08:34:04 --> Language Class Initialized
INFO - 2021-01-15 08:34:04 --> Config Class Initialized
INFO - 2021-01-15 08:34:04 --> Loader Class Initialized
INFO - 2021-01-15 08:34:04 --> Helper loaded: url_helper
INFO - 2021-01-15 08:34:04 --> Helper loaded: file_helper
INFO - 2021-01-15 08:34:04 --> Helper loaded: form_helper
INFO - 2021-01-15 08:34:04 --> Helper loaded: my_helper
INFO - 2021-01-15 08:34:04 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:34:04 --> Controller Class Initialized
DEBUG - 2021-01-15 08:34:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2021-01-15 08:34:04 --> Final output sent to browser
DEBUG - 2021-01-15 08:34:04 --> Total execution time: 0.3621
INFO - 2021-01-15 08:34:08 --> Config Class Initialized
INFO - 2021-01-15 08:34:08 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:34:08 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:34:08 --> Utf8 Class Initialized
INFO - 2021-01-15 08:34:08 --> URI Class Initialized
INFO - 2021-01-15 08:34:08 --> Router Class Initialized
INFO - 2021-01-15 08:34:08 --> Output Class Initialized
INFO - 2021-01-15 08:34:08 --> Security Class Initialized
DEBUG - 2021-01-15 08:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:34:08 --> Input Class Initialized
INFO - 2021-01-15 08:34:08 --> Language Class Initialized
ERROR - 2021-01-15 08:34:08 --> 404 Page Not Found: ../modules/cetak_leger/controllers/Cetak_leger/cetak_otr_xi
INFO - 2021-01-15 08:42:27 --> Config Class Initialized
INFO - 2021-01-15 08:42:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:42:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:42:27 --> Utf8 Class Initialized
INFO - 2021-01-15 08:42:27 --> URI Class Initialized
INFO - 2021-01-15 08:42:27 --> Router Class Initialized
INFO - 2021-01-15 08:42:27 --> Output Class Initialized
INFO - 2021-01-15 08:42:27 --> Security Class Initialized
DEBUG - 2021-01-15 08:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:42:27 --> Input Class Initialized
INFO - 2021-01-15 08:42:27 --> Language Class Initialized
INFO - 2021-01-15 08:42:27 --> Language Class Initialized
INFO - 2021-01-15 08:42:27 --> Config Class Initialized
INFO - 2021-01-15 08:42:27 --> Loader Class Initialized
INFO - 2021-01-15 08:42:27 --> Helper loaded: url_helper
INFO - 2021-01-15 08:42:27 --> Helper loaded: file_helper
INFO - 2021-01-15 08:42:27 --> Helper loaded: form_helper
INFO - 2021-01-15 08:42:27 --> Helper loaded: my_helper
INFO - 2021-01-15 08:42:27 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:42:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:42:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:42:28 --> Controller Class Initialized
DEBUG - 2021-01-15 08:42:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:42:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:42:28 --> Final output sent to browser
DEBUG - 2021-01-15 08:42:28 --> Total execution time: 0.4611
INFO - 2021-01-15 08:42:29 --> Config Class Initialized
INFO - 2021-01-15 08:42:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:42:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:42:29 --> Utf8 Class Initialized
INFO - 2021-01-15 08:42:29 --> URI Class Initialized
INFO - 2021-01-15 08:42:29 --> Router Class Initialized
INFO - 2021-01-15 08:42:29 --> Output Class Initialized
INFO - 2021-01-15 08:42:29 --> Security Class Initialized
DEBUG - 2021-01-15 08:42:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:42:29 --> Input Class Initialized
INFO - 2021-01-15 08:42:29 --> Language Class Initialized
INFO - 2021-01-15 08:42:29 --> Language Class Initialized
INFO - 2021-01-15 08:42:29 --> Config Class Initialized
INFO - 2021-01-15 08:42:29 --> Loader Class Initialized
INFO - 2021-01-15 08:42:29 --> Helper loaded: url_helper
INFO - 2021-01-15 08:42:29 --> Helper loaded: file_helper
INFO - 2021-01-15 08:42:29 --> Helper loaded: form_helper
INFO - 2021-01-15 08:42:29 --> Helper loaded: my_helper
INFO - 2021-01-15 08:42:29 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:42:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:42:29 --> Controller Class Initialized
DEBUG - 2021-01-15 08:42:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xi.php
INFO - 2021-01-15 08:42:29 --> Final output sent to browser
DEBUG - 2021-01-15 08:42:29 --> Total execution time: 0.3545
INFO - 2021-01-15 08:42:41 --> Config Class Initialized
INFO - 2021-01-15 08:42:41 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:42:41 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:42:41 --> Utf8 Class Initialized
INFO - 2021-01-15 08:42:41 --> URI Class Initialized
INFO - 2021-01-15 08:42:41 --> Router Class Initialized
INFO - 2021-01-15 08:42:41 --> Output Class Initialized
INFO - 2021-01-15 08:42:41 --> Security Class Initialized
DEBUG - 2021-01-15 08:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:42:41 --> Input Class Initialized
INFO - 2021-01-15 08:42:41 --> Language Class Initialized
INFO - 2021-01-15 08:42:41 --> Language Class Initialized
INFO - 2021-01-15 08:42:41 --> Config Class Initialized
INFO - 2021-01-15 08:42:41 --> Loader Class Initialized
INFO - 2021-01-15 08:42:41 --> Helper loaded: url_helper
INFO - 2021-01-15 08:42:41 --> Helper loaded: file_helper
INFO - 2021-01-15 08:42:41 --> Helper loaded: form_helper
INFO - 2021-01-15 08:42:41 --> Helper loaded: my_helper
INFO - 2021-01-15 08:42:41 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:42:41 --> Controller Class Initialized
ERROR - 2021-01-15 08:42:41 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:41 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Notice --> Undefined variable: queri_mapel3 C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
ERROR - 2021-01-15 08:42:42 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_leger\controllers\Cetak_leger.php 3102
DEBUG - 2021-01-15 08:42:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xii.php
INFO - 2021-01-15 08:42:42 --> Final output sent to browser
DEBUG - 2021-01-15 08:42:42 --> Total execution time: 1.1402
INFO - 2021-01-15 08:43:03 --> Config Class Initialized
INFO - 2021-01-15 08:43:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:43:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:43:03 --> Utf8 Class Initialized
INFO - 2021-01-15 08:43:03 --> URI Class Initialized
INFO - 2021-01-15 08:43:03 --> Router Class Initialized
INFO - 2021-01-15 08:43:03 --> Output Class Initialized
INFO - 2021-01-15 08:43:03 --> Security Class Initialized
DEBUG - 2021-01-15 08:43:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:43:03 --> Input Class Initialized
INFO - 2021-01-15 08:43:03 --> Language Class Initialized
INFO - 2021-01-15 08:43:03 --> Language Class Initialized
INFO - 2021-01-15 08:43:03 --> Config Class Initialized
INFO - 2021-01-15 08:43:03 --> Loader Class Initialized
INFO - 2021-01-15 08:43:03 --> Helper loaded: url_helper
INFO - 2021-01-15 08:43:03 --> Helper loaded: file_helper
INFO - 2021-01-15 08:43:03 --> Helper loaded: form_helper
INFO - 2021-01-15 08:43:03 --> Helper loaded: my_helper
INFO - 2021-01-15 08:43:03 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:43:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:43:04 --> Controller Class Initialized
DEBUG - 2021-01-15 08:43:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xii.php
INFO - 2021-01-15 08:43:04 --> Final output sent to browser
DEBUG - 2021-01-15 08:43:04 --> Total execution time: 0.3802
INFO - 2021-01-15 08:43:16 --> Config Class Initialized
INFO - 2021-01-15 08:43:16 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:43:16 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:43:16 --> Utf8 Class Initialized
INFO - 2021-01-15 08:43:16 --> URI Class Initialized
INFO - 2021-01-15 08:43:16 --> Router Class Initialized
INFO - 2021-01-15 08:43:16 --> Output Class Initialized
INFO - 2021-01-15 08:43:16 --> Security Class Initialized
DEBUG - 2021-01-15 08:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:43:16 --> Input Class Initialized
INFO - 2021-01-15 08:43:16 --> Language Class Initialized
INFO - 2021-01-15 08:43:16 --> Language Class Initialized
INFO - 2021-01-15 08:43:16 --> Config Class Initialized
INFO - 2021-01-15 08:43:16 --> Loader Class Initialized
INFO - 2021-01-15 08:43:16 --> Helper loaded: url_helper
INFO - 2021-01-15 08:43:16 --> Helper loaded: file_helper
INFO - 2021-01-15 08:43:16 --> Helper loaded: form_helper
INFO - 2021-01-15 08:43:16 --> Helper loaded: my_helper
INFO - 2021-01-15 08:43:16 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:43:16 --> Controller Class Initialized
DEBUG - 2021-01-15 08:43:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xii.php
INFO - 2021-01-15 08:43:16 --> Final output sent to browser
DEBUG - 2021-01-15 08:43:16 --> Total execution time: 0.3466
INFO - 2021-01-15 08:49:33 --> Config Class Initialized
INFO - 2021-01-15 08:49:33 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:49:33 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:49:33 --> Utf8 Class Initialized
INFO - 2021-01-15 08:49:33 --> URI Class Initialized
INFO - 2021-01-15 08:49:33 --> Router Class Initialized
INFO - 2021-01-15 08:49:33 --> Output Class Initialized
INFO - 2021-01-15 08:49:33 --> Security Class Initialized
DEBUG - 2021-01-15 08:49:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:49:33 --> Input Class Initialized
INFO - 2021-01-15 08:49:33 --> Language Class Initialized
INFO - 2021-01-15 08:49:33 --> Language Class Initialized
INFO - 2021-01-15 08:49:33 --> Config Class Initialized
INFO - 2021-01-15 08:49:33 --> Loader Class Initialized
INFO - 2021-01-15 08:49:33 --> Helper loaded: url_helper
INFO - 2021-01-15 08:49:33 --> Helper loaded: file_helper
INFO - 2021-01-15 08:49:33 --> Helper loaded: form_helper
INFO - 2021-01-15 08:49:33 --> Helper loaded: my_helper
INFO - 2021-01-15 08:49:33 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:49:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:49:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:49:34 --> Controller Class Initialized
DEBUG - 2021-01-15 08:49:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:49:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:49:34 --> Final output sent to browser
DEBUG - 2021-01-15 08:49:34 --> Total execution time: 0.4463
INFO - 2021-01-15 08:49:34 --> Config Class Initialized
INFO - 2021-01-15 08:49:34 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:49:34 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:49:34 --> Utf8 Class Initialized
INFO - 2021-01-15 08:49:34 --> URI Class Initialized
INFO - 2021-01-15 08:49:34 --> Router Class Initialized
INFO - 2021-01-15 08:49:34 --> Output Class Initialized
INFO - 2021-01-15 08:49:34 --> Security Class Initialized
DEBUG - 2021-01-15 08:49:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:49:34 --> Input Class Initialized
INFO - 2021-01-15 08:49:34 --> Language Class Initialized
INFO - 2021-01-15 08:49:34 --> Language Class Initialized
INFO - 2021-01-15 08:49:35 --> Config Class Initialized
INFO - 2021-01-15 08:49:35 --> Loader Class Initialized
INFO - 2021-01-15 08:49:35 --> Helper loaded: url_helper
INFO - 2021-01-15 08:49:35 --> Helper loaded: file_helper
INFO - 2021-01-15 08:49:35 --> Helper loaded: form_helper
INFO - 2021-01-15 08:49:35 --> Helper loaded: my_helper
INFO - 2021-01-15 08:49:35 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:49:35 --> Controller Class Initialized
DEBUG - 2021-01-15 08:49:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xi.php
INFO - 2021-01-15 08:49:35 --> Final output sent to browser
DEBUG - 2021-01-15 08:49:35 --> Total execution time: 0.3543
INFO - 2021-01-15 08:49:39 --> Config Class Initialized
INFO - 2021-01-15 08:49:39 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:49:39 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:49:39 --> Utf8 Class Initialized
INFO - 2021-01-15 08:49:39 --> URI Class Initialized
INFO - 2021-01-15 08:49:39 --> Router Class Initialized
INFO - 2021-01-15 08:49:39 --> Output Class Initialized
INFO - 2021-01-15 08:49:39 --> Security Class Initialized
DEBUG - 2021-01-15 08:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:49:39 --> Input Class Initialized
INFO - 2021-01-15 08:49:39 --> Language Class Initialized
INFO - 2021-01-15 08:49:40 --> Language Class Initialized
INFO - 2021-01-15 08:49:40 --> Config Class Initialized
INFO - 2021-01-15 08:49:40 --> Loader Class Initialized
INFO - 2021-01-15 08:49:40 --> Helper loaded: url_helper
INFO - 2021-01-15 08:49:40 --> Helper loaded: file_helper
INFO - 2021-01-15 08:49:40 --> Helper loaded: form_helper
INFO - 2021-01-15 08:49:40 --> Helper loaded: my_helper
INFO - 2021-01-15 08:49:40 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:49:40 --> Controller Class Initialized
DEBUG - 2021-01-15 08:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_otr_xii.php
INFO - 2021-01-15 08:49:40 --> Final output sent to browser
DEBUG - 2021-01-15 08:49:40 --> Total execution time: 0.3839
INFO - 2021-01-15 08:49:45 --> Config Class Initialized
INFO - 2021-01-15 08:49:45 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:49:45 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:49:45 --> Utf8 Class Initialized
INFO - 2021-01-15 08:49:45 --> URI Class Initialized
INFO - 2021-01-15 08:49:45 --> Router Class Initialized
INFO - 2021-01-15 08:49:45 --> Output Class Initialized
INFO - 2021-01-15 08:49:45 --> Security Class Initialized
DEBUG - 2021-01-15 08:49:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:49:45 --> Input Class Initialized
INFO - 2021-01-15 08:49:45 --> Language Class Initialized
INFO - 2021-01-15 08:49:45 --> Language Class Initialized
INFO - 2021-01-15 08:49:45 --> Config Class Initialized
INFO - 2021-01-15 08:49:45 --> Loader Class Initialized
INFO - 2021-01-15 08:49:45 --> Helper loaded: url_helper
INFO - 2021-01-15 08:49:45 --> Helper loaded: file_helper
INFO - 2021-01-15 08:49:45 --> Helper loaded: form_helper
INFO - 2021-01-15 08:49:45 --> Helper loaded: my_helper
INFO - 2021-01-15 08:49:45 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:49:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:49:45 --> Controller Class Initialized
DEBUG - 2021-01-15 08:49:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xi.php
INFO - 2021-01-15 08:49:45 --> Final output sent to browser
DEBUG - 2021-01-15 08:49:45 --> Total execution time: 0.3671
INFO - 2021-01-15 08:52:19 --> Config Class Initialized
INFO - 2021-01-15 08:52:19 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:52:19 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:52:19 --> Utf8 Class Initialized
INFO - 2021-01-15 08:52:19 --> URI Class Initialized
INFO - 2021-01-15 08:52:19 --> Router Class Initialized
INFO - 2021-01-15 08:52:19 --> Output Class Initialized
INFO - 2021-01-15 08:52:19 --> Security Class Initialized
DEBUG - 2021-01-15 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:52:19 --> Input Class Initialized
INFO - 2021-01-15 08:52:19 --> Language Class Initialized
INFO - 2021-01-15 08:52:19 --> Language Class Initialized
INFO - 2021-01-15 08:52:19 --> Config Class Initialized
INFO - 2021-01-15 08:52:19 --> Loader Class Initialized
INFO - 2021-01-15 08:52:19 --> Helper loaded: url_helper
INFO - 2021-01-15 08:52:19 --> Helper loaded: file_helper
INFO - 2021-01-15 08:52:19 --> Helper loaded: form_helper
INFO - 2021-01-15 08:52:19 --> Helper loaded: my_helper
INFO - 2021-01-15 08:52:19 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:52:19 --> Controller Class Initialized
DEBUG - 2021-01-15 08:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:52:19 --> Final output sent to browser
DEBUG - 2021-01-15 08:52:19 --> Total execution time: 0.4942
INFO - 2021-01-15 08:52:20 --> Config Class Initialized
INFO - 2021-01-15 08:52:20 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:52:20 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:52:20 --> Utf8 Class Initialized
INFO - 2021-01-15 08:52:20 --> URI Class Initialized
INFO - 2021-01-15 08:52:20 --> Router Class Initialized
INFO - 2021-01-15 08:52:20 --> Output Class Initialized
INFO - 2021-01-15 08:52:20 --> Security Class Initialized
DEBUG - 2021-01-15 08:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:52:20 --> Input Class Initialized
INFO - 2021-01-15 08:52:20 --> Language Class Initialized
INFO - 2021-01-15 08:52:20 --> Language Class Initialized
INFO - 2021-01-15 08:52:20 --> Config Class Initialized
INFO - 2021-01-15 08:52:20 --> Loader Class Initialized
INFO - 2021-01-15 08:52:20 --> Helper loaded: url_helper
INFO - 2021-01-15 08:52:20 --> Helper loaded: file_helper
INFO - 2021-01-15 08:52:20 --> Helper loaded: form_helper
INFO - 2021-01-15 08:52:20 --> Helper loaded: my_helper
INFO - 2021-01-15 08:52:20 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:52:20 --> Controller Class Initialized
DEBUG - 2021-01-15 08:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkj_xii.php
INFO - 2021-01-15 08:52:20 --> Final output sent to browser
DEBUG - 2021-01-15 08:52:20 --> Total execution time: 0.3715
INFO - 2021-01-15 08:52:39 --> Config Class Initialized
INFO - 2021-01-15 08:52:39 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:52:39 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:52:39 --> Utf8 Class Initialized
INFO - 2021-01-15 08:52:39 --> URI Class Initialized
INFO - 2021-01-15 08:52:39 --> Router Class Initialized
INFO - 2021-01-15 08:52:39 --> Output Class Initialized
INFO - 2021-01-15 08:52:39 --> Security Class Initialized
DEBUG - 2021-01-15 08:52:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:52:39 --> Input Class Initialized
INFO - 2021-01-15 08:52:39 --> Language Class Initialized
INFO - 2021-01-15 08:52:39 --> Language Class Initialized
INFO - 2021-01-15 08:52:39 --> Config Class Initialized
INFO - 2021-01-15 08:52:39 --> Loader Class Initialized
INFO - 2021-01-15 08:52:39 --> Helper loaded: url_helper
INFO - 2021-01-15 08:52:39 --> Helper loaded: file_helper
INFO - 2021-01-15 08:52:39 --> Helper loaded: form_helper
INFO - 2021-01-15 08:52:39 --> Helper loaded: my_helper
INFO - 2021-01-15 08:52:39 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:52:39 --> Controller Class Initialized
DEBUG - 2021-01-15 08:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-01-15 08:52:39 --> Final output sent to browser
DEBUG - 2021-01-15 08:52:39 --> Total execution time: 0.3872
INFO - 2021-01-15 08:54:41 --> Config Class Initialized
INFO - 2021-01-15 08:54:41 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:54:41 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:54:41 --> Utf8 Class Initialized
INFO - 2021-01-15 08:54:41 --> URI Class Initialized
INFO - 2021-01-15 08:54:41 --> Router Class Initialized
INFO - 2021-01-15 08:54:41 --> Output Class Initialized
INFO - 2021-01-15 08:54:41 --> Security Class Initialized
DEBUG - 2021-01-15 08:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:54:41 --> Input Class Initialized
INFO - 2021-01-15 08:54:41 --> Language Class Initialized
INFO - 2021-01-15 08:54:41 --> Language Class Initialized
INFO - 2021-01-15 08:54:41 --> Config Class Initialized
INFO - 2021-01-15 08:54:41 --> Loader Class Initialized
INFO - 2021-01-15 08:54:41 --> Helper loaded: url_helper
INFO - 2021-01-15 08:54:41 --> Helper loaded: file_helper
INFO - 2021-01-15 08:54:41 --> Helper loaded: form_helper
INFO - 2021-01-15 08:54:41 --> Helper loaded: my_helper
INFO - 2021-01-15 08:54:41 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:54:41 --> Controller Class Initialized
DEBUG - 2021-01-15 08:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:54:41 --> Final output sent to browser
DEBUG - 2021-01-15 08:54:41 --> Total execution time: 0.4427
INFO - 2021-01-15 08:54:42 --> Config Class Initialized
INFO - 2021-01-15 08:54:42 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:54:42 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:54:42 --> Utf8 Class Initialized
INFO - 2021-01-15 08:54:42 --> URI Class Initialized
INFO - 2021-01-15 08:54:42 --> Router Class Initialized
INFO - 2021-01-15 08:54:42 --> Output Class Initialized
INFO - 2021-01-15 08:54:42 --> Security Class Initialized
DEBUG - 2021-01-15 08:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:54:42 --> Input Class Initialized
INFO - 2021-01-15 08:54:42 --> Language Class Initialized
INFO - 2021-01-15 08:54:42 --> Language Class Initialized
INFO - 2021-01-15 08:54:42 --> Config Class Initialized
INFO - 2021-01-15 08:54:42 --> Loader Class Initialized
INFO - 2021-01-15 08:54:42 --> Helper loaded: url_helper
INFO - 2021-01-15 08:54:42 --> Helper loaded: file_helper
INFO - 2021-01-15 08:54:42 --> Helper loaded: form_helper
INFO - 2021-01-15 08:54:42 --> Helper loaded: my_helper
INFO - 2021-01-15 08:54:42 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:54:42 --> Controller Class Initialized
DEBUG - 2021-01-15 08:54:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xi.php
INFO - 2021-01-15 08:54:42 --> Final output sent to browser
DEBUG - 2021-01-15 08:54:42 --> Total execution time: 0.3501
INFO - 2021-01-15 08:57:18 --> Config Class Initialized
INFO - 2021-01-15 08:57:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:57:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:57:18 --> Utf8 Class Initialized
INFO - 2021-01-15 08:57:18 --> URI Class Initialized
INFO - 2021-01-15 08:57:18 --> Router Class Initialized
INFO - 2021-01-15 08:57:18 --> Output Class Initialized
INFO - 2021-01-15 08:57:18 --> Security Class Initialized
DEBUG - 2021-01-15 08:57:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:57:18 --> Input Class Initialized
INFO - 2021-01-15 08:57:18 --> Language Class Initialized
INFO - 2021-01-15 08:57:18 --> Language Class Initialized
INFO - 2021-01-15 08:57:18 --> Config Class Initialized
INFO - 2021-01-15 08:57:18 --> Loader Class Initialized
INFO - 2021-01-15 08:57:18 --> Helper loaded: url_helper
INFO - 2021-01-15 08:57:18 --> Helper loaded: file_helper
INFO - 2021-01-15 08:57:18 --> Helper loaded: form_helper
INFO - 2021-01-15 08:57:18 --> Helper loaded: my_helper
INFO - 2021-01-15 08:57:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:57:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:57:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:57:18 --> Controller Class Initialized
DEBUG - 2021-01-15 08:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:57:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:57:18 --> Final output sent to browser
DEBUG - 2021-01-15 08:57:18 --> Total execution time: 0.3610
INFO - 2021-01-15 08:57:32 --> Config Class Initialized
INFO - 2021-01-15 08:57:32 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:57:32 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:57:32 --> Utf8 Class Initialized
INFO - 2021-01-15 08:57:32 --> URI Class Initialized
INFO - 2021-01-15 08:57:32 --> Router Class Initialized
INFO - 2021-01-15 08:57:32 --> Output Class Initialized
INFO - 2021-01-15 08:57:32 --> Security Class Initialized
DEBUG - 2021-01-15 08:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:57:32 --> Input Class Initialized
INFO - 2021-01-15 08:57:32 --> Language Class Initialized
INFO - 2021-01-15 08:57:32 --> Language Class Initialized
INFO - 2021-01-15 08:57:32 --> Config Class Initialized
INFO - 2021-01-15 08:57:32 --> Loader Class Initialized
INFO - 2021-01-15 08:57:32 --> Helper loaded: url_helper
INFO - 2021-01-15 08:57:32 --> Helper loaded: file_helper
INFO - 2021-01-15 08:57:32 --> Helper loaded: form_helper
INFO - 2021-01-15 08:57:32 --> Helper loaded: my_helper
INFO - 2021-01-15 08:57:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:57:32 --> Controller Class Initialized
DEBUG - 2021-01-15 08:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:57:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:57:32 --> Final output sent to browser
DEBUG - 2021-01-15 08:57:32 --> Total execution time: 0.3638
INFO - 2021-01-15 08:58:17 --> Config Class Initialized
INFO - 2021-01-15 08:58:17 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:58:17 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:58:17 --> Utf8 Class Initialized
INFO - 2021-01-15 08:58:17 --> URI Class Initialized
INFO - 2021-01-15 08:58:17 --> Router Class Initialized
INFO - 2021-01-15 08:58:17 --> Output Class Initialized
INFO - 2021-01-15 08:58:17 --> Security Class Initialized
DEBUG - 2021-01-15 08:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:58:17 --> Input Class Initialized
INFO - 2021-01-15 08:58:17 --> Language Class Initialized
INFO - 2021-01-15 08:58:17 --> Language Class Initialized
INFO - 2021-01-15 08:58:17 --> Config Class Initialized
INFO - 2021-01-15 08:58:17 --> Loader Class Initialized
INFO - 2021-01-15 08:58:17 --> Helper loaded: url_helper
INFO - 2021-01-15 08:58:17 --> Helper loaded: file_helper
INFO - 2021-01-15 08:58:17 --> Helper loaded: form_helper
INFO - 2021-01-15 08:58:17 --> Helper loaded: my_helper
INFO - 2021-01-15 08:58:17 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:58:17 --> Controller Class Initialized
DEBUG - 2021-01-15 08:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:58:17 --> Final output sent to browser
DEBUG - 2021-01-15 08:58:17 --> Total execution time: 0.3742
INFO - 2021-01-15 08:58:31 --> Config Class Initialized
INFO - 2021-01-15 08:58:31 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:58:31 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:58:31 --> Utf8 Class Initialized
INFO - 2021-01-15 08:58:31 --> URI Class Initialized
INFO - 2021-01-15 08:58:31 --> Router Class Initialized
INFO - 2021-01-15 08:58:31 --> Output Class Initialized
INFO - 2021-01-15 08:58:31 --> Security Class Initialized
DEBUG - 2021-01-15 08:58:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:58:31 --> Input Class Initialized
INFO - 2021-01-15 08:58:31 --> Language Class Initialized
INFO - 2021-01-15 08:58:31 --> Language Class Initialized
INFO - 2021-01-15 08:58:31 --> Config Class Initialized
INFO - 2021-01-15 08:58:31 --> Loader Class Initialized
INFO - 2021-01-15 08:58:31 --> Helper loaded: url_helper
INFO - 2021-01-15 08:58:31 --> Helper loaded: file_helper
INFO - 2021-01-15 08:58:31 --> Helper loaded: form_helper
INFO - 2021-01-15 08:58:31 --> Helper loaded: my_helper
INFO - 2021-01-15 08:58:31 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:58:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:58:31 --> Controller Class Initialized
DEBUG - 2021-01-15 08:58:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:58:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:58:31 --> Final output sent to browser
DEBUG - 2021-01-15 08:58:31 --> Total execution time: 0.4086
INFO - 2021-01-15 08:58:50 --> Config Class Initialized
INFO - 2021-01-15 08:58:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:58:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:58:50 --> Utf8 Class Initialized
INFO - 2021-01-15 08:58:50 --> URI Class Initialized
INFO - 2021-01-15 08:58:50 --> Router Class Initialized
INFO - 2021-01-15 08:58:50 --> Output Class Initialized
INFO - 2021-01-15 08:58:50 --> Security Class Initialized
DEBUG - 2021-01-15 08:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:58:50 --> Input Class Initialized
INFO - 2021-01-15 08:58:50 --> Language Class Initialized
INFO - 2021-01-15 08:58:50 --> Language Class Initialized
INFO - 2021-01-15 08:58:50 --> Config Class Initialized
INFO - 2021-01-15 08:58:50 --> Loader Class Initialized
INFO - 2021-01-15 08:58:50 --> Helper loaded: url_helper
INFO - 2021-01-15 08:58:50 --> Helper loaded: file_helper
INFO - 2021-01-15 08:58:50 --> Helper loaded: form_helper
INFO - 2021-01-15 08:58:50 --> Helper loaded: my_helper
INFO - 2021-01-15 08:58:50 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:58:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:58:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:58:50 --> Controller Class Initialized
DEBUG - 2021-01-15 08:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:58:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:58:50 --> Final output sent to browser
DEBUG - 2021-01-15 08:58:50 --> Total execution time: 0.3627
INFO - 2021-01-15 08:58:57 --> Config Class Initialized
INFO - 2021-01-15 08:58:57 --> Hooks Class Initialized
DEBUG - 2021-01-15 08:58:57 --> UTF-8 Support Enabled
INFO - 2021-01-15 08:58:57 --> Utf8 Class Initialized
INFO - 2021-01-15 08:58:57 --> URI Class Initialized
INFO - 2021-01-15 08:58:57 --> Router Class Initialized
INFO - 2021-01-15 08:58:57 --> Output Class Initialized
INFO - 2021-01-15 08:58:57 --> Security Class Initialized
DEBUG - 2021-01-15 08:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 08:58:57 --> Input Class Initialized
INFO - 2021-01-15 08:58:57 --> Language Class Initialized
INFO - 2021-01-15 08:58:57 --> Language Class Initialized
INFO - 2021-01-15 08:58:57 --> Config Class Initialized
INFO - 2021-01-15 08:58:57 --> Loader Class Initialized
INFO - 2021-01-15 08:58:57 --> Helper loaded: url_helper
INFO - 2021-01-15 08:58:57 --> Helper loaded: file_helper
INFO - 2021-01-15 08:58:57 --> Helper loaded: form_helper
INFO - 2021-01-15 08:58:57 --> Helper loaded: my_helper
INFO - 2021-01-15 08:58:57 --> Database Driver Class Initialized
DEBUG - 2021-01-15 08:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 08:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 08:58:58 --> Controller Class Initialized
DEBUG - 2021-01-15 08:58:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-15 08:58:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 08:58:58 --> Final output sent to browser
DEBUG - 2021-01-15 08:58:58 --> Total execution time: 0.3845
INFO - 2021-01-15 09:08:31 --> Config Class Initialized
INFO - 2021-01-15 09:08:31 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:08:31 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:08:31 --> Utf8 Class Initialized
INFO - 2021-01-15 09:08:31 --> URI Class Initialized
INFO - 2021-01-15 09:08:31 --> Router Class Initialized
INFO - 2021-01-15 09:08:31 --> Output Class Initialized
INFO - 2021-01-15 09:08:31 --> Security Class Initialized
DEBUG - 2021-01-15 09:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:08:31 --> Input Class Initialized
INFO - 2021-01-15 09:08:31 --> Language Class Initialized
INFO - 2021-01-15 09:08:31 --> Language Class Initialized
INFO - 2021-01-15 09:08:32 --> Config Class Initialized
INFO - 2021-01-15 09:08:32 --> Loader Class Initialized
INFO - 2021-01-15 09:08:32 --> Helper loaded: url_helper
INFO - 2021-01-15 09:08:32 --> Helper loaded: file_helper
INFO - 2021-01-15 09:08:32 --> Helper loaded: form_helper
INFO - 2021-01-15 09:08:32 --> Helper loaded: my_helper
INFO - 2021-01-15 09:08:32 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:08:32 --> Controller Class Initialized
DEBUG - 2021-01-15 09:08:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 09:08:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 09:08:32 --> Final output sent to browser
DEBUG - 2021-01-15 09:08:32 --> Total execution time: 0.4480
INFO - 2021-01-15 09:08:39 --> Config Class Initialized
INFO - 2021-01-15 09:08:39 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:08:39 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:08:39 --> Utf8 Class Initialized
INFO - 2021-01-15 09:08:39 --> URI Class Initialized
INFO - 2021-01-15 09:08:39 --> Router Class Initialized
INFO - 2021-01-15 09:08:39 --> Output Class Initialized
INFO - 2021-01-15 09:08:39 --> Security Class Initialized
DEBUG - 2021-01-15 09:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:08:39 --> Input Class Initialized
INFO - 2021-01-15 09:08:39 --> Language Class Initialized
INFO - 2021-01-15 09:08:39 --> Language Class Initialized
INFO - 2021-01-15 09:08:39 --> Config Class Initialized
INFO - 2021-01-15 09:08:39 --> Loader Class Initialized
INFO - 2021-01-15 09:08:39 --> Helper loaded: url_helper
INFO - 2021-01-15 09:08:39 --> Helper loaded: file_helper
INFO - 2021-01-15 09:08:39 --> Helper loaded: form_helper
INFO - 2021-01-15 09:08:39 --> Helper loaded: my_helper
INFO - 2021-01-15 09:08:39 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:08:39 --> Controller Class Initialized
DEBUG - 2021-01-15 09:08:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:08:39 --> Final output sent to browser
DEBUG - 2021-01-15 09:08:39 --> Total execution time: 0.3709
INFO - 2021-01-15 09:09:08 --> Config Class Initialized
INFO - 2021-01-15 09:09:08 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:09:08 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:09:08 --> Utf8 Class Initialized
INFO - 2021-01-15 09:09:08 --> URI Class Initialized
INFO - 2021-01-15 09:09:08 --> Router Class Initialized
INFO - 2021-01-15 09:09:08 --> Output Class Initialized
INFO - 2021-01-15 09:09:08 --> Security Class Initialized
DEBUG - 2021-01-15 09:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:09:08 --> Input Class Initialized
INFO - 2021-01-15 09:09:08 --> Language Class Initialized
INFO - 2021-01-15 09:09:08 --> Language Class Initialized
INFO - 2021-01-15 09:09:08 --> Config Class Initialized
INFO - 2021-01-15 09:09:08 --> Loader Class Initialized
INFO - 2021-01-15 09:09:08 --> Helper loaded: url_helper
INFO - 2021-01-15 09:09:08 --> Helper loaded: file_helper
INFO - 2021-01-15 09:09:08 --> Helper loaded: form_helper
INFO - 2021-01-15 09:09:09 --> Helper loaded: my_helper
INFO - 2021-01-15 09:09:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:09:09 --> Controller Class Initialized
DEBUG - 2021-01-15 09:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:09:09 --> Final output sent to browser
DEBUG - 2021-01-15 09:09:09 --> Total execution time: 0.4243
INFO - 2021-01-15 09:09:35 --> Config Class Initialized
INFO - 2021-01-15 09:09:35 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:09:35 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:09:35 --> Utf8 Class Initialized
INFO - 2021-01-15 09:09:35 --> URI Class Initialized
INFO - 2021-01-15 09:09:35 --> Router Class Initialized
INFO - 2021-01-15 09:09:35 --> Output Class Initialized
INFO - 2021-01-15 09:09:35 --> Security Class Initialized
DEBUG - 2021-01-15 09:09:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:09:35 --> Input Class Initialized
INFO - 2021-01-15 09:09:35 --> Language Class Initialized
INFO - 2021-01-15 09:09:35 --> Language Class Initialized
INFO - 2021-01-15 09:09:35 --> Config Class Initialized
INFO - 2021-01-15 09:09:35 --> Loader Class Initialized
INFO - 2021-01-15 09:09:35 --> Helper loaded: url_helper
INFO - 2021-01-15 09:09:35 --> Helper loaded: file_helper
INFO - 2021-01-15 09:09:35 --> Helper loaded: form_helper
INFO - 2021-01-15 09:09:35 --> Helper loaded: my_helper
INFO - 2021-01-15 09:09:35 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:09:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:09:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:09:35 --> Controller Class Initialized
DEBUG - 2021-01-15 09:09:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:09:35 --> Final output sent to browser
DEBUG - 2021-01-15 09:09:35 --> Total execution time: 0.4106
INFO - 2021-01-15 09:09:56 --> Config Class Initialized
INFO - 2021-01-15 09:09:56 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:09:56 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:09:56 --> Utf8 Class Initialized
INFO - 2021-01-15 09:09:56 --> URI Class Initialized
INFO - 2021-01-15 09:09:56 --> Router Class Initialized
INFO - 2021-01-15 09:09:56 --> Output Class Initialized
INFO - 2021-01-15 09:09:56 --> Security Class Initialized
DEBUG - 2021-01-15 09:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:09:56 --> Input Class Initialized
INFO - 2021-01-15 09:09:56 --> Language Class Initialized
INFO - 2021-01-15 09:09:56 --> Language Class Initialized
INFO - 2021-01-15 09:09:56 --> Config Class Initialized
INFO - 2021-01-15 09:09:56 --> Loader Class Initialized
INFO - 2021-01-15 09:09:56 --> Helper loaded: url_helper
INFO - 2021-01-15 09:09:56 --> Helper loaded: file_helper
INFO - 2021-01-15 09:09:56 --> Helper loaded: form_helper
INFO - 2021-01-15 09:09:56 --> Helper loaded: my_helper
INFO - 2021-01-15 09:09:56 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:09:56 --> Controller Class Initialized
DEBUG - 2021-01-15 09:09:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:09:56 --> Final output sent to browser
DEBUG - 2021-01-15 09:09:56 --> Total execution time: 0.4142
INFO - 2021-01-15 09:10:21 --> Config Class Initialized
INFO - 2021-01-15 09:10:21 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:10:21 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:10:21 --> Utf8 Class Initialized
INFO - 2021-01-15 09:10:21 --> URI Class Initialized
INFO - 2021-01-15 09:10:21 --> Router Class Initialized
INFO - 2021-01-15 09:10:21 --> Output Class Initialized
INFO - 2021-01-15 09:10:21 --> Security Class Initialized
DEBUG - 2021-01-15 09:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:10:21 --> Input Class Initialized
INFO - 2021-01-15 09:10:21 --> Language Class Initialized
INFO - 2021-01-15 09:10:21 --> Language Class Initialized
INFO - 2021-01-15 09:10:21 --> Config Class Initialized
INFO - 2021-01-15 09:10:21 --> Loader Class Initialized
INFO - 2021-01-15 09:10:21 --> Helper loaded: url_helper
INFO - 2021-01-15 09:10:21 --> Helper loaded: file_helper
INFO - 2021-01-15 09:10:21 --> Helper loaded: form_helper
INFO - 2021-01-15 09:10:21 --> Helper loaded: my_helper
INFO - 2021-01-15 09:10:21 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:10:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:10:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:10:21 --> Controller Class Initialized
DEBUG - 2021-01-15 09:10:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:10:21 --> Final output sent to browser
DEBUG - 2021-01-15 09:10:21 --> Total execution time: 0.4161
INFO - 2021-01-15 09:10:34 --> Config Class Initialized
INFO - 2021-01-15 09:10:34 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:10:34 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:10:34 --> Utf8 Class Initialized
INFO - 2021-01-15 09:10:34 --> URI Class Initialized
INFO - 2021-01-15 09:10:34 --> Router Class Initialized
INFO - 2021-01-15 09:10:34 --> Output Class Initialized
INFO - 2021-01-15 09:10:35 --> Security Class Initialized
DEBUG - 2021-01-15 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:10:35 --> Input Class Initialized
INFO - 2021-01-15 09:10:35 --> Language Class Initialized
INFO - 2021-01-15 09:10:35 --> Language Class Initialized
INFO - 2021-01-15 09:10:35 --> Config Class Initialized
INFO - 2021-01-15 09:10:35 --> Loader Class Initialized
INFO - 2021-01-15 09:10:35 --> Helper loaded: url_helper
INFO - 2021-01-15 09:10:35 --> Helper loaded: file_helper
INFO - 2021-01-15 09:10:35 --> Helper loaded: form_helper
INFO - 2021-01-15 09:10:35 --> Helper loaded: my_helper
INFO - 2021-01-15 09:10:35 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:10:35 --> Controller Class Initialized
DEBUG - 2021-01-15 09:10:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:10:35 --> Final output sent to browser
DEBUG - 2021-01-15 09:10:35 --> Total execution time: 0.4151
INFO - 2021-01-15 09:10:48 --> Config Class Initialized
INFO - 2021-01-15 09:10:48 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:10:48 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:10:48 --> Utf8 Class Initialized
INFO - 2021-01-15 09:10:48 --> URI Class Initialized
INFO - 2021-01-15 09:10:48 --> Router Class Initialized
INFO - 2021-01-15 09:10:48 --> Output Class Initialized
INFO - 2021-01-15 09:10:48 --> Security Class Initialized
DEBUG - 2021-01-15 09:10:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:10:48 --> Input Class Initialized
INFO - 2021-01-15 09:10:48 --> Language Class Initialized
INFO - 2021-01-15 09:10:48 --> Language Class Initialized
INFO - 2021-01-15 09:10:48 --> Config Class Initialized
INFO - 2021-01-15 09:10:48 --> Loader Class Initialized
INFO - 2021-01-15 09:10:48 --> Helper loaded: url_helper
INFO - 2021-01-15 09:10:48 --> Helper loaded: file_helper
INFO - 2021-01-15 09:10:48 --> Helper loaded: form_helper
INFO - 2021-01-15 09:10:48 --> Helper loaded: my_helper
INFO - 2021-01-15 09:10:48 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:10:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:10:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:10:48 --> Controller Class Initialized
DEBUG - 2021-01-15 09:10:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:10:48 --> Final output sent to browser
DEBUG - 2021-01-15 09:10:48 --> Total execution time: 0.4085
INFO - 2021-01-15 09:11:00 --> Config Class Initialized
INFO - 2021-01-15 09:11:00 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:11:00 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:11:00 --> Utf8 Class Initialized
INFO - 2021-01-15 09:11:00 --> URI Class Initialized
INFO - 2021-01-15 09:11:00 --> Router Class Initialized
INFO - 2021-01-15 09:11:00 --> Output Class Initialized
INFO - 2021-01-15 09:11:00 --> Security Class Initialized
DEBUG - 2021-01-15 09:11:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:11:00 --> Input Class Initialized
INFO - 2021-01-15 09:11:00 --> Language Class Initialized
INFO - 2021-01-15 09:11:00 --> Language Class Initialized
INFO - 2021-01-15 09:11:00 --> Config Class Initialized
INFO - 2021-01-15 09:11:00 --> Loader Class Initialized
INFO - 2021-01-15 09:11:00 --> Helper loaded: url_helper
INFO - 2021-01-15 09:11:00 --> Helper loaded: file_helper
INFO - 2021-01-15 09:11:00 --> Helper loaded: form_helper
INFO - 2021-01-15 09:11:00 --> Helper loaded: my_helper
INFO - 2021-01-15 09:11:00 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:11:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:11:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:11:00 --> Controller Class Initialized
DEBUG - 2021-01-15 09:11:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:11:00 --> Final output sent to browser
DEBUG - 2021-01-15 09:11:00 --> Total execution time: 0.4477
INFO - 2021-01-15 09:12:03 --> Config Class Initialized
INFO - 2021-01-15 09:12:03 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:12:03 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:12:03 --> Utf8 Class Initialized
INFO - 2021-01-15 09:12:03 --> URI Class Initialized
INFO - 2021-01-15 09:12:03 --> Router Class Initialized
INFO - 2021-01-15 09:12:03 --> Output Class Initialized
INFO - 2021-01-15 09:12:03 --> Security Class Initialized
DEBUG - 2021-01-15 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:12:03 --> Input Class Initialized
INFO - 2021-01-15 09:12:03 --> Language Class Initialized
INFO - 2021-01-15 09:12:03 --> Language Class Initialized
INFO - 2021-01-15 09:12:03 --> Config Class Initialized
INFO - 2021-01-15 09:12:03 --> Loader Class Initialized
INFO - 2021-01-15 09:12:03 --> Helper loaded: url_helper
INFO - 2021-01-15 09:12:03 --> Helper loaded: file_helper
INFO - 2021-01-15 09:12:03 --> Helper loaded: form_helper
INFO - 2021-01-15 09:12:03 --> Helper loaded: my_helper
INFO - 2021-01-15 09:12:03 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:12:03 --> Controller Class Initialized
DEBUG - 2021-01-15 09:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:12:03 --> Final output sent to browser
DEBUG - 2021-01-15 09:12:03 --> Total execution time: 0.4690
INFO - 2021-01-15 09:12:27 --> Config Class Initialized
INFO - 2021-01-15 09:12:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:12:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:12:27 --> Utf8 Class Initialized
INFO - 2021-01-15 09:12:27 --> URI Class Initialized
INFO - 2021-01-15 09:12:27 --> Router Class Initialized
INFO - 2021-01-15 09:12:27 --> Output Class Initialized
INFO - 2021-01-15 09:12:27 --> Security Class Initialized
DEBUG - 2021-01-15 09:12:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:12:27 --> Input Class Initialized
INFO - 2021-01-15 09:12:27 --> Language Class Initialized
INFO - 2021-01-15 09:12:27 --> Language Class Initialized
INFO - 2021-01-15 09:12:27 --> Config Class Initialized
INFO - 2021-01-15 09:12:27 --> Loader Class Initialized
INFO - 2021-01-15 09:12:27 --> Helper loaded: url_helper
INFO - 2021-01-15 09:12:27 --> Helper loaded: file_helper
INFO - 2021-01-15 09:12:27 --> Helper loaded: form_helper
INFO - 2021-01-15 09:12:27 --> Helper loaded: my_helper
INFO - 2021-01-15 09:12:27 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:12:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:12:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:12:27 --> Controller Class Initialized
DEBUG - 2021-01-15 09:12:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:12:27 --> Final output sent to browser
DEBUG - 2021-01-15 09:12:27 --> Total execution time: 0.4114
INFO - 2021-01-15 09:14:38 --> Config Class Initialized
INFO - 2021-01-15 09:14:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:14:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:14:38 --> Utf8 Class Initialized
INFO - 2021-01-15 09:14:38 --> URI Class Initialized
INFO - 2021-01-15 09:14:38 --> Router Class Initialized
INFO - 2021-01-15 09:14:38 --> Output Class Initialized
INFO - 2021-01-15 09:14:38 --> Security Class Initialized
DEBUG - 2021-01-15 09:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:14:38 --> Input Class Initialized
INFO - 2021-01-15 09:14:38 --> Language Class Initialized
INFO - 2021-01-15 09:14:38 --> Language Class Initialized
INFO - 2021-01-15 09:14:38 --> Config Class Initialized
INFO - 2021-01-15 09:14:38 --> Loader Class Initialized
INFO - 2021-01-15 09:14:38 --> Helper loaded: url_helper
INFO - 2021-01-15 09:14:39 --> Helper loaded: file_helper
INFO - 2021-01-15 09:14:39 --> Helper loaded: form_helper
INFO - 2021-01-15 09:14:39 --> Helper loaded: my_helper
INFO - 2021-01-15 09:14:39 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:14:39 --> Controller Class Initialized
DEBUG - 2021-01-15 09:14:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:14:39 --> Final output sent to browser
DEBUG - 2021-01-15 09:14:39 --> Total execution time: 0.4931
INFO - 2021-01-15 09:18:38 --> Config Class Initialized
INFO - 2021-01-15 09:18:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:18:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:18:38 --> Utf8 Class Initialized
INFO - 2021-01-15 09:18:38 --> URI Class Initialized
INFO - 2021-01-15 09:18:38 --> Router Class Initialized
INFO - 2021-01-15 09:18:38 --> Output Class Initialized
INFO - 2021-01-15 09:18:38 --> Security Class Initialized
DEBUG - 2021-01-15 09:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:18:39 --> Input Class Initialized
INFO - 2021-01-15 09:18:39 --> Language Class Initialized
INFO - 2021-01-15 09:18:39 --> Language Class Initialized
INFO - 2021-01-15 09:18:39 --> Config Class Initialized
INFO - 2021-01-15 09:18:39 --> Loader Class Initialized
INFO - 2021-01-15 09:18:39 --> Helper loaded: url_helper
INFO - 2021-01-15 09:18:39 --> Helper loaded: file_helper
INFO - 2021-01-15 09:18:39 --> Helper loaded: form_helper
INFO - 2021-01-15 09:18:39 --> Helper loaded: my_helper
INFO - 2021-01-15 09:18:39 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:18:39 --> Controller Class Initialized
DEBUG - 2021-01-15 09:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-15 09:18:39 --> Final output sent to browser
DEBUG - 2021-01-15 09:18:39 --> Total execution time: 0.4129
INFO - 2021-01-15 09:19:09 --> Config Class Initialized
INFO - 2021-01-15 09:19:09 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:19:09 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:19:09 --> Utf8 Class Initialized
INFO - 2021-01-15 09:19:09 --> URI Class Initialized
INFO - 2021-01-15 09:19:09 --> Router Class Initialized
INFO - 2021-01-15 09:19:09 --> Output Class Initialized
INFO - 2021-01-15 09:19:09 --> Security Class Initialized
DEBUG - 2021-01-15 09:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:19:09 --> Input Class Initialized
INFO - 2021-01-15 09:19:09 --> Language Class Initialized
INFO - 2021-01-15 09:19:09 --> Language Class Initialized
INFO - 2021-01-15 09:19:09 --> Config Class Initialized
INFO - 2021-01-15 09:19:09 --> Loader Class Initialized
INFO - 2021-01-15 09:19:09 --> Helper loaded: url_helper
INFO - 2021-01-15 09:19:09 --> Helper loaded: file_helper
INFO - 2021-01-15 09:19:09 --> Helper loaded: form_helper
INFO - 2021-01-15 09:19:09 --> Helper loaded: my_helper
INFO - 2021-01-15 09:19:09 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:19:09 --> Controller Class Initialized
DEBUG - 2021-01-15 09:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-15 09:19:09 --> Final output sent to browser
DEBUG - 2021-01-15 09:19:09 --> Total execution time: 0.4838
INFO - 2021-01-15 09:19:57 --> Config Class Initialized
INFO - 2021-01-15 09:19:57 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:19:57 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:19:57 --> Utf8 Class Initialized
INFO - 2021-01-15 09:19:57 --> URI Class Initialized
INFO - 2021-01-15 09:19:57 --> Router Class Initialized
INFO - 2021-01-15 09:19:57 --> Output Class Initialized
INFO - 2021-01-15 09:19:57 --> Security Class Initialized
DEBUG - 2021-01-15 09:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:19:57 --> Input Class Initialized
INFO - 2021-01-15 09:19:57 --> Language Class Initialized
INFO - 2021-01-15 09:19:57 --> Language Class Initialized
INFO - 2021-01-15 09:19:57 --> Config Class Initialized
INFO - 2021-01-15 09:19:58 --> Loader Class Initialized
INFO - 2021-01-15 09:19:58 --> Helper loaded: url_helper
INFO - 2021-01-15 09:19:58 --> Helper loaded: file_helper
INFO - 2021-01-15 09:19:58 --> Helper loaded: form_helper
INFO - 2021-01-15 09:19:58 --> Helper loaded: my_helper
INFO - 2021-01-15 09:19:58 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:19:58 --> Controller Class Initialized
DEBUG - 2021-01-15 09:19:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-15 09:19:58 --> Final output sent to browser
DEBUG - 2021-01-15 09:19:58 --> Total execution time: 0.4582
INFO - 2021-01-15 09:20:47 --> Config Class Initialized
INFO - 2021-01-15 09:20:47 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:20:47 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:20:47 --> Utf8 Class Initialized
INFO - 2021-01-15 09:20:47 --> URI Class Initialized
INFO - 2021-01-15 09:20:47 --> Router Class Initialized
INFO - 2021-01-15 09:20:47 --> Output Class Initialized
INFO - 2021-01-15 09:20:47 --> Security Class Initialized
DEBUG - 2021-01-15 09:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:20:47 --> Input Class Initialized
INFO - 2021-01-15 09:20:47 --> Language Class Initialized
INFO - 2021-01-15 09:20:47 --> Language Class Initialized
INFO - 2021-01-15 09:20:47 --> Config Class Initialized
INFO - 2021-01-15 09:20:47 --> Loader Class Initialized
INFO - 2021-01-15 09:20:47 --> Helper loaded: url_helper
INFO - 2021-01-15 09:20:47 --> Helper loaded: file_helper
INFO - 2021-01-15 09:20:47 --> Helper loaded: form_helper
INFO - 2021-01-15 09:20:47 --> Helper loaded: my_helper
INFO - 2021-01-15 09:20:48 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:20:48 --> Controller Class Initialized
DEBUG - 2021-01-15 09:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-15 09:20:48 --> Final output sent to browser
DEBUG - 2021-01-15 09:20:48 --> Total execution time: 0.4104
INFO - 2021-01-15 09:21:46 --> Config Class Initialized
INFO - 2021-01-15 09:21:46 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:21:46 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:21:46 --> Utf8 Class Initialized
INFO - 2021-01-15 09:21:46 --> URI Class Initialized
INFO - 2021-01-15 09:21:46 --> Router Class Initialized
INFO - 2021-01-15 09:21:46 --> Output Class Initialized
INFO - 2021-01-15 09:21:46 --> Security Class Initialized
DEBUG - 2021-01-15 09:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:21:46 --> Input Class Initialized
INFO - 2021-01-15 09:21:46 --> Language Class Initialized
INFO - 2021-01-15 09:21:46 --> Language Class Initialized
INFO - 2021-01-15 09:21:46 --> Config Class Initialized
INFO - 2021-01-15 09:21:46 --> Loader Class Initialized
INFO - 2021-01-15 09:21:46 --> Helper loaded: url_helper
INFO - 2021-01-15 09:21:46 --> Helper loaded: file_helper
INFO - 2021-01-15 09:21:46 --> Helper loaded: form_helper
INFO - 2021-01-15 09:21:46 --> Helper loaded: my_helper
INFO - 2021-01-15 09:21:46 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:21:46 --> Controller Class Initialized
DEBUG - 2021-01-15 09:21:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-15 09:21:47 --> Final output sent to browser
DEBUG - 2021-01-15 09:21:47 --> Total execution time: 0.4284
INFO - 2021-01-15 09:22:27 --> Config Class Initialized
INFO - 2021-01-15 09:22:27 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:22:27 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:22:27 --> Utf8 Class Initialized
INFO - 2021-01-15 09:22:27 --> URI Class Initialized
INFO - 2021-01-15 09:22:27 --> Router Class Initialized
INFO - 2021-01-15 09:22:27 --> Output Class Initialized
INFO - 2021-01-15 09:22:27 --> Security Class Initialized
DEBUG - 2021-01-15 09:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:22:28 --> Input Class Initialized
INFO - 2021-01-15 09:22:28 --> Language Class Initialized
INFO - 2021-01-15 09:22:28 --> Language Class Initialized
INFO - 2021-01-15 09:22:28 --> Config Class Initialized
INFO - 2021-01-15 09:22:28 --> Loader Class Initialized
INFO - 2021-01-15 09:22:28 --> Helper loaded: url_helper
INFO - 2021-01-15 09:22:28 --> Helper loaded: file_helper
INFO - 2021-01-15 09:22:28 --> Helper loaded: form_helper
INFO - 2021-01-15 09:22:28 --> Helper loaded: my_helper
INFO - 2021-01-15 09:22:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:22:28 --> Controller Class Initialized
DEBUG - 2021-01-15 09:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-01-15 09:22:28 --> Final output sent to browser
DEBUG - 2021-01-15 09:22:28 --> Total execution time: 0.3999
INFO - 2021-01-15 09:28:36 --> Config Class Initialized
INFO - 2021-01-15 09:28:36 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:28:36 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:28:36 --> Utf8 Class Initialized
INFO - 2021-01-15 09:28:36 --> URI Class Initialized
INFO - 2021-01-15 09:28:36 --> Router Class Initialized
INFO - 2021-01-15 09:28:36 --> Output Class Initialized
INFO - 2021-01-15 09:28:36 --> Security Class Initialized
DEBUG - 2021-01-15 09:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:28:36 --> Input Class Initialized
INFO - 2021-01-15 09:28:36 --> Language Class Initialized
INFO - 2021-01-15 09:28:36 --> Language Class Initialized
INFO - 2021-01-15 09:28:36 --> Config Class Initialized
INFO - 2021-01-15 09:28:36 --> Loader Class Initialized
INFO - 2021-01-15 09:28:36 --> Helper loaded: url_helper
INFO - 2021-01-15 09:28:36 --> Helper loaded: file_helper
INFO - 2021-01-15 09:28:36 --> Helper loaded: form_helper
INFO - 2021-01-15 09:28:36 --> Helper loaded: my_helper
INFO - 2021-01-15 09:28:37 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:28:37 --> Controller Class Initialized
DEBUG - 2021-01-15 09:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-15 09:28:37 --> Final output sent to browser
DEBUG - 2021-01-15 09:28:37 --> Total execution time: 0.4337
INFO - 2021-01-15 09:28:38 --> Config Class Initialized
INFO - 2021-01-15 09:28:38 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:28:38 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:28:38 --> Utf8 Class Initialized
INFO - 2021-01-15 09:28:38 --> URI Class Initialized
INFO - 2021-01-15 09:28:38 --> Router Class Initialized
INFO - 2021-01-15 09:28:38 --> Output Class Initialized
INFO - 2021-01-15 09:28:38 --> Security Class Initialized
DEBUG - 2021-01-15 09:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:28:38 --> Input Class Initialized
INFO - 2021-01-15 09:28:38 --> Language Class Initialized
INFO - 2021-01-15 09:28:38 --> Language Class Initialized
INFO - 2021-01-15 09:28:38 --> Config Class Initialized
INFO - 2021-01-15 09:28:38 --> Loader Class Initialized
INFO - 2021-01-15 09:28:38 --> Helper loaded: url_helper
INFO - 2021-01-15 09:28:38 --> Helper loaded: file_helper
INFO - 2021-01-15 09:28:38 --> Helper loaded: form_helper
INFO - 2021-01-15 09:28:38 --> Helper loaded: my_helper
INFO - 2021-01-15 09:28:38 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:28:38 --> Controller Class Initialized
DEBUG - 2021-01-15 09:28:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-15 09:28:38 --> Final output sent to browser
DEBUG - 2021-01-15 09:28:38 --> Total execution time: 0.4443
INFO - 2021-01-15 09:29:21 --> Config Class Initialized
INFO - 2021-01-15 09:29:21 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:29:21 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:29:21 --> Utf8 Class Initialized
INFO - 2021-01-15 09:29:21 --> URI Class Initialized
INFO - 2021-01-15 09:29:21 --> Router Class Initialized
INFO - 2021-01-15 09:29:21 --> Output Class Initialized
INFO - 2021-01-15 09:29:21 --> Security Class Initialized
DEBUG - 2021-01-15 09:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:29:21 --> Input Class Initialized
INFO - 2021-01-15 09:29:21 --> Language Class Initialized
INFO - 2021-01-15 09:29:21 --> Language Class Initialized
INFO - 2021-01-15 09:29:21 --> Config Class Initialized
INFO - 2021-01-15 09:29:21 --> Loader Class Initialized
INFO - 2021-01-15 09:29:21 --> Helper loaded: url_helper
INFO - 2021-01-15 09:29:21 --> Helper loaded: file_helper
INFO - 2021-01-15 09:29:21 --> Helper loaded: form_helper
INFO - 2021-01-15 09:29:21 --> Helper loaded: my_helper
INFO - 2021-01-15 09:29:21 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:29:21 --> Controller Class Initialized
DEBUG - 2021-01-15 09:29:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xi.php
INFO - 2021-01-15 09:29:22 --> Final output sent to browser
DEBUG - 2021-01-15 09:29:22 --> Total execution time: 0.3678
INFO - 2021-01-15 09:29:28 --> Config Class Initialized
INFO - 2021-01-15 09:29:28 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:29:28 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:29:28 --> Utf8 Class Initialized
INFO - 2021-01-15 09:29:28 --> URI Class Initialized
INFO - 2021-01-15 09:29:28 --> Router Class Initialized
INFO - 2021-01-15 09:29:28 --> Output Class Initialized
INFO - 2021-01-15 09:29:28 --> Security Class Initialized
DEBUG - 2021-01-15 09:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:29:28 --> Input Class Initialized
INFO - 2021-01-15 09:29:28 --> Language Class Initialized
INFO - 2021-01-15 09:29:28 --> Language Class Initialized
INFO - 2021-01-15 09:29:28 --> Config Class Initialized
INFO - 2021-01-15 09:29:28 --> Loader Class Initialized
INFO - 2021-01-15 09:29:28 --> Helper loaded: url_helper
INFO - 2021-01-15 09:29:28 --> Helper loaded: file_helper
INFO - 2021-01-15 09:29:28 --> Helper loaded: form_helper
INFO - 2021-01-15 09:29:28 --> Helper loaded: my_helper
INFO - 2021-01-15 09:29:28 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:29:29 --> Controller Class Initialized
DEBUG - 2021-01-15 09:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-15 09:29:29 --> Final output sent to browser
DEBUG - 2021-01-15 09:29:29 --> Total execution time: 0.4625
INFO - 2021-01-15 09:29:57 --> Config Class Initialized
INFO - 2021-01-15 09:29:57 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:29:57 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:29:57 --> Utf8 Class Initialized
INFO - 2021-01-15 09:29:57 --> URI Class Initialized
INFO - 2021-01-15 09:29:57 --> Router Class Initialized
INFO - 2021-01-15 09:29:57 --> Output Class Initialized
INFO - 2021-01-15 09:29:57 --> Security Class Initialized
DEBUG - 2021-01-15 09:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:29:57 --> Input Class Initialized
INFO - 2021-01-15 09:29:57 --> Language Class Initialized
INFO - 2021-01-15 09:29:57 --> Language Class Initialized
INFO - 2021-01-15 09:29:57 --> Config Class Initialized
INFO - 2021-01-15 09:29:57 --> Loader Class Initialized
INFO - 2021-01-15 09:29:57 --> Helper loaded: url_helper
INFO - 2021-01-15 09:29:57 --> Helper loaded: file_helper
INFO - 2021-01-15 09:29:57 --> Helper loaded: form_helper
INFO - 2021-01-15 09:29:57 --> Helper loaded: my_helper
INFO - 2021-01-15 09:29:57 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:29:57 --> Controller Class Initialized
DEBUG - 2021-01-15 09:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-15 09:29:58 --> Final output sent to browser
DEBUG - 2021-01-15 09:29:58 --> Total execution time: 0.4347
INFO - 2021-01-15 09:30:16 --> Config Class Initialized
INFO - 2021-01-15 09:30:16 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:30:16 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:30:16 --> Utf8 Class Initialized
INFO - 2021-01-15 09:30:16 --> URI Class Initialized
INFO - 2021-01-15 09:30:16 --> Router Class Initialized
INFO - 2021-01-15 09:30:16 --> Output Class Initialized
INFO - 2021-01-15 09:30:16 --> Security Class Initialized
DEBUG - 2021-01-15 09:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:30:16 --> Input Class Initialized
INFO - 2021-01-15 09:30:16 --> Language Class Initialized
INFO - 2021-01-15 09:30:16 --> Language Class Initialized
INFO - 2021-01-15 09:30:16 --> Config Class Initialized
INFO - 2021-01-15 09:30:16 --> Loader Class Initialized
INFO - 2021-01-15 09:30:16 --> Helper loaded: url_helper
INFO - 2021-01-15 09:30:16 --> Helper loaded: file_helper
INFO - 2021-01-15 09:30:16 --> Helper loaded: form_helper
INFO - 2021-01-15 09:30:16 --> Helper loaded: my_helper
INFO - 2021-01-15 09:30:16 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:30:16 --> Controller Class Initialized
DEBUG - 2021-01-15 09:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-15 09:30:16 --> Final output sent to browser
DEBUG - 2021-01-15 09:30:16 --> Total execution time: 0.4562
INFO - 2021-01-15 09:30:47 --> Config Class Initialized
INFO - 2021-01-15 09:30:47 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:30:47 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:30:48 --> Utf8 Class Initialized
INFO - 2021-01-15 09:30:48 --> URI Class Initialized
INFO - 2021-01-15 09:30:48 --> Router Class Initialized
INFO - 2021-01-15 09:30:48 --> Output Class Initialized
INFO - 2021-01-15 09:30:48 --> Security Class Initialized
DEBUG - 2021-01-15 09:30:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:30:48 --> Input Class Initialized
INFO - 2021-01-15 09:30:48 --> Language Class Initialized
INFO - 2021-01-15 09:30:48 --> Language Class Initialized
INFO - 2021-01-15 09:30:48 --> Config Class Initialized
INFO - 2021-01-15 09:30:48 --> Loader Class Initialized
INFO - 2021-01-15 09:30:48 --> Helper loaded: url_helper
INFO - 2021-01-15 09:30:48 --> Helper loaded: file_helper
INFO - 2021-01-15 09:30:48 --> Helper loaded: form_helper
INFO - 2021-01-15 09:30:48 --> Helper loaded: my_helper
INFO - 2021-01-15 09:30:48 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:30:48 --> Controller Class Initialized
DEBUG - 2021-01-15 09:30:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-15 09:30:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-15 09:30:48 --> Final output sent to browser
DEBUG - 2021-01-15 09:30:48 --> Total execution time: 0.5550
INFO - 2021-01-15 09:30:50 --> Config Class Initialized
INFO - 2021-01-15 09:30:50 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:30:50 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:30:50 --> Utf8 Class Initialized
INFO - 2021-01-15 09:30:50 --> URI Class Initialized
INFO - 2021-01-15 09:30:50 --> Router Class Initialized
INFO - 2021-01-15 09:30:50 --> Output Class Initialized
INFO - 2021-01-15 09:30:50 --> Security Class Initialized
DEBUG - 2021-01-15 09:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:30:50 --> Input Class Initialized
INFO - 2021-01-15 09:30:50 --> Language Class Initialized
INFO - 2021-01-15 09:30:50 --> Language Class Initialized
INFO - 2021-01-15 09:30:50 --> Config Class Initialized
INFO - 2021-01-15 09:30:50 --> Loader Class Initialized
INFO - 2021-01-15 09:30:50 --> Helper loaded: url_helper
INFO - 2021-01-15 09:30:50 --> Helper loaded: file_helper
INFO - 2021-01-15 09:30:50 --> Helper loaded: form_helper
INFO - 2021-01-15 09:30:50 --> Helper loaded: my_helper
INFO - 2021-01-15 09:30:50 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:30:50 --> Controller Class Initialized
DEBUG - 2021-01-15 09:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-15 09:30:50 --> Final output sent to browser
DEBUG - 2021-01-15 09:30:50 --> Total execution time: 0.4861
INFO - 2021-01-15 09:31:18 --> Config Class Initialized
INFO - 2021-01-15 09:31:18 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:31:18 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:31:18 --> Utf8 Class Initialized
INFO - 2021-01-15 09:31:18 --> URI Class Initialized
INFO - 2021-01-15 09:31:18 --> Router Class Initialized
INFO - 2021-01-15 09:31:18 --> Output Class Initialized
INFO - 2021-01-15 09:31:18 --> Security Class Initialized
DEBUG - 2021-01-15 09:31:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:31:18 --> Input Class Initialized
INFO - 2021-01-15 09:31:18 --> Language Class Initialized
INFO - 2021-01-15 09:31:18 --> Language Class Initialized
INFO - 2021-01-15 09:31:18 --> Config Class Initialized
INFO - 2021-01-15 09:31:18 --> Loader Class Initialized
INFO - 2021-01-15 09:31:18 --> Helper loaded: url_helper
INFO - 2021-01-15 09:31:18 --> Helper loaded: file_helper
INFO - 2021-01-15 09:31:18 --> Helper loaded: form_helper
INFO - 2021-01-15 09:31:18 --> Helper loaded: my_helper
INFO - 2021-01-15 09:31:18 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:31:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:31:18 --> Controller Class Initialized
DEBUG - 2021-01-15 09:31:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-15 09:31:19 --> Final output sent to browser
DEBUG - 2021-01-15 09:31:19 --> Total execution time: 0.4248
INFO - 2021-01-15 09:31:29 --> Config Class Initialized
INFO - 2021-01-15 09:31:29 --> Hooks Class Initialized
DEBUG - 2021-01-15 09:31:29 --> UTF-8 Support Enabled
INFO - 2021-01-15 09:31:29 --> Utf8 Class Initialized
INFO - 2021-01-15 09:31:29 --> URI Class Initialized
INFO - 2021-01-15 09:31:29 --> Router Class Initialized
INFO - 2021-01-15 09:31:29 --> Output Class Initialized
INFO - 2021-01-15 09:31:29 --> Security Class Initialized
DEBUG - 2021-01-15 09:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-15 09:31:29 --> Input Class Initialized
INFO - 2021-01-15 09:31:29 --> Language Class Initialized
INFO - 2021-01-15 09:31:29 --> Language Class Initialized
INFO - 2021-01-15 09:31:29 --> Config Class Initialized
INFO - 2021-01-15 09:31:29 --> Loader Class Initialized
INFO - 2021-01-15 09:31:29 --> Helper loaded: url_helper
INFO - 2021-01-15 09:31:29 --> Helper loaded: file_helper
INFO - 2021-01-15 09:31:29 --> Helper loaded: form_helper
INFO - 2021-01-15 09:31:29 --> Helper loaded: my_helper
INFO - 2021-01-15 09:31:29 --> Database Driver Class Initialized
DEBUG - 2021-01-15 09:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-15 09:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-15 09:31:29 --> Controller Class Initialized
DEBUG - 2021-01-15 09:31:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-01-15 09:31:29 --> Final output sent to browser
DEBUG - 2021-01-15 09:31:29 --> Total execution time: 0.4172
