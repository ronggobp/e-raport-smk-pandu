<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-05-28 10:08:24 --> Config Class Initialized
INFO - 2022-05-28 10:08:24 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:24 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:24 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:24 --> URI Class Initialized
DEBUG - 2022-05-28 10:08:24 --> No URI present. Default controller set.
INFO - 2022-05-28 10:08:24 --> Router Class Initialized
INFO - 2022-05-28 10:08:24 --> Output Class Initialized
INFO - 2022-05-28 10:08:24 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:24 --> Input Class Initialized
INFO - 2022-05-28 10:08:24 --> Language Class Initialized
INFO - 2022-05-28 10:08:25 --> Language Class Initialized
INFO - 2022-05-28 10:08:25 --> Config Class Initialized
INFO - 2022-05-28 10:08:25 --> Loader Class Initialized
INFO - 2022-05-28 10:08:25 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:25 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:25 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:25 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:25 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:25 --> Controller Class Initialized
INFO - 2022-05-28 10:08:25 --> Config Class Initialized
INFO - 2022-05-28 10:08:25 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:25 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:25 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:25 --> URI Class Initialized
INFO - 2022-05-28 10:08:25 --> Router Class Initialized
INFO - 2022-05-28 10:08:25 --> Output Class Initialized
INFO - 2022-05-28 10:08:25 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:25 --> Input Class Initialized
INFO - 2022-05-28 10:08:25 --> Language Class Initialized
INFO - 2022-05-28 10:08:25 --> Language Class Initialized
INFO - 2022-05-28 10:08:25 --> Config Class Initialized
INFO - 2022-05-28 10:08:25 --> Loader Class Initialized
INFO - 2022-05-28 10:08:25 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:25 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:25 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:25 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:25 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:25 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-28 10:08:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:25 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:25 --> Total execution time: 0.1264
INFO - 2022-05-28 10:08:35 --> Config Class Initialized
INFO - 2022-05-28 10:08:35 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:35 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:35 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:35 --> URI Class Initialized
INFO - 2022-05-28 10:08:35 --> Router Class Initialized
INFO - 2022-05-28 10:08:35 --> Output Class Initialized
INFO - 2022-05-28 10:08:35 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:35 --> Input Class Initialized
INFO - 2022-05-28 10:08:35 --> Language Class Initialized
INFO - 2022-05-28 10:08:35 --> Language Class Initialized
INFO - 2022-05-28 10:08:35 --> Config Class Initialized
INFO - 2022-05-28 10:08:35 --> Loader Class Initialized
INFO - 2022-05-28 10:08:35 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:35 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:35 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:35 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:35 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:35 --> Controller Class Initialized
INFO - 2022-05-28 10:08:35 --> Helper loaded: cookie_helper
INFO - 2022-05-28 10:08:35 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:35 --> Total execution time: 0.1166
INFO - 2022-05-28 10:08:36 --> Config Class Initialized
INFO - 2022-05-28 10:08:36 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:36 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:36 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:36 --> URI Class Initialized
INFO - 2022-05-28 10:08:36 --> Router Class Initialized
INFO - 2022-05-28 10:08:36 --> Output Class Initialized
INFO - 2022-05-28 10:08:36 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:36 --> Input Class Initialized
INFO - 2022-05-28 10:08:36 --> Language Class Initialized
INFO - 2022-05-28 10:08:36 --> Language Class Initialized
INFO - 2022-05-28 10:08:36 --> Config Class Initialized
INFO - 2022-05-28 10:08:36 --> Loader Class Initialized
INFO - 2022-05-28 10:08:36 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:36 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:36 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:36 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:36 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:36 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-28 10:08:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:36 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:36 --> Total execution time: 0.1566
INFO - 2022-05-28 10:08:38 --> Config Class Initialized
INFO - 2022-05-28 10:08:38 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:38 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:38 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:38 --> URI Class Initialized
INFO - 2022-05-28 10:08:38 --> Router Class Initialized
INFO - 2022-05-28 10:08:38 --> Output Class Initialized
INFO - 2022-05-28 10:08:38 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:38 --> Input Class Initialized
INFO - 2022-05-28 10:08:38 --> Language Class Initialized
INFO - 2022-05-28 10:08:38 --> Language Class Initialized
INFO - 2022-05-28 10:08:38 --> Config Class Initialized
INFO - 2022-05-28 10:08:38 --> Loader Class Initialized
INFO - 2022-05-28 10:08:38 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:38 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:38 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:38 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:38 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:38 --> Controller Class Initialized
INFO - 2022-05-28 10:08:38 --> Helper loaded: cookie_helper
INFO - 2022-05-28 10:08:38 --> Config Class Initialized
INFO - 2022-05-28 10:08:38 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:38 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:38 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:38 --> URI Class Initialized
INFO - 2022-05-28 10:08:38 --> Router Class Initialized
INFO - 2022-05-28 10:08:38 --> Output Class Initialized
INFO - 2022-05-28 10:08:38 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:38 --> Input Class Initialized
INFO - 2022-05-28 10:08:38 --> Language Class Initialized
INFO - 2022-05-28 10:08:38 --> Language Class Initialized
INFO - 2022-05-28 10:08:38 --> Config Class Initialized
INFO - 2022-05-28 10:08:38 --> Loader Class Initialized
INFO - 2022-05-28 10:08:38 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:38 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:38 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:38 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:38 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:38 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-28 10:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:38 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:38 --> Total execution time: 0.0644
INFO - 2022-05-28 10:08:43 --> Config Class Initialized
INFO - 2022-05-28 10:08:43 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:43 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:43 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:43 --> URI Class Initialized
INFO - 2022-05-28 10:08:43 --> Router Class Initialized
INFO - 2022-05-28 10:08:43 --> Output Class Initialized
INFO - 2022-05-28 10:08:43 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:43 --> Input Class Initialized
INFO - 2022-05-28 10:08:43 --> Language Class Initialized
INFO - 2022-05-28 10:08:43 --> Language Class Initialized
INFO - 2022-05-28 10:08:43 --> Config Class Initialized
INFO - 2022-05-28 10:08:43 --> Loader Class Initialized
INFO - 2022-05-28 10:08:43 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:43 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:43 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:43 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:43 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:43 --> Controller Class Initialized
INFO - 2022-05-28 10:08:43 --> Helper loaded: cookie_helper
INFO - 2022-05-28 10:08:43 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:43 --> Total execution time: 0.0541
INFO - 2022-05-28 10:08:44 --> Config Class Initialized
INFO - 2022-05-28 10:08:44 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:44 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:44 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:44 --> URI Class Initialized
INFO - 2022-05-28 10:08:44 --> Router Class Initialized
INFO - 2022-05-28 10:08:44 --> Output Class Initialized
INFO - 2022-05-28 10:08:44 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:44 --> Input Class Initialized
INFO - 2022-05-28 10:08:44 --> Language Class Initialized
INFO - 2022-05-28 10:08:44 --> Language Class Initialized
INFO - 2022-05-28 10:08:44 --> Config Class Initialized
INFO - 2022-05-28 10:08:44 --> Loader Class Initialized
INFO - 2022-05-28 10:08:44 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:44 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:44 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:44 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:44 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:44 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-28 10:08:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:44 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:44 --> Total execution time: 0.0889
INFO - 2022-05-28 10:08:45 --> Config Class Initialized
INFO - 2022-05-28 10:08:45 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:45 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:45 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:45 --> URI Class Initialized
INFO - 2022-05-28 10:08:45 --> Router Class Initialized
INFO - 2022-05-28 10:08:45 --> Output Class Initialized
INFO - 2022-05-28 10:08:45 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:45 --> Input Class Initialized
INFO - 2022-05-28 10:08:45 --> Language Class Initialized
INFO - 2022-05-28 10:08:45 --> Language Class Initialized
INFO - 2022-05-28 10:08:45 --> Config Class Initialized
INFO - 2022-05-28 10:08:45 --> Loader Class Initialized
INFO - 2022-05-28 10:08:45 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:45 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:45 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:45 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:45 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:45 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2022-05-28 10:08:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:45 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:45 --> Total execution time: 0.0920
INFO - 2022-05-28 10:08:46 --> Config Class Initialized
INFO - 2022-05-28 10:08:46 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:46 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:46 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:46 --> URI Class Initialized
INFO - 2022-05-28 10:08:46 --> Router Class Initialized
INFO - 2022-05-28 10:08:46 --> Output Class Initialized
INFO - 2022-05-28 10:08:46 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:46 --> Input Class Initialized
INFO - 2022-05-28 10:08:46 --> Language Class Initialized
INFO - 2022-05-28 10:08:46 --> Language Class Initialized
INFO - 2022-05-28 10:08:46 --> Config Class Initialized
INFO - 2022-05-28 10:08:46 --> Loader Class Initialized
INFO - 2022-05-28 10:08:46 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:46 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:46 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:46 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:46 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:46 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-05-28 10:08:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:46 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:46 --> Total execution time: 0.1015
INFO - 2022-05-28 10:08:46 --> Config Class Initialized
INFO - 2022-05-28 10:08:46 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:46 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:46 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:46 --> URI Class Initialized
INFO - 2022-05-28 10:08:46 --> Router Class Initialized
INFO - 2022-05-28 10:08:46 --> Output Class Initialized
INFO - 2022-05-28 10:08:46 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:46 --> Input Class Initialized
INFO - 2022-05-28 10:08:46 --> Language Class Initialized
INFO - 2022-05-28 10:08:46 --> Language Class Initialized
INFO - 2022-05-28 10:08:46 --> Config Class Initialized
INFO - 2022-05-28 10:08:46 --> Loader Class Initialized
INFO - 2022-05-28 10:08:46 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:46 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:46 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:46 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:46 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:46 --> Controller Class Initialized
INFO - 2022-05-28 10:08:48 --> Config Class Initialized
INFO - 2022-05-28 10:08:48 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:48 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:48 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:48 --> URI Class Initialized
INFO - 2022-05-28 10:08:48 --> Router Class Initialized
INFO - 2022-05-28 10:08:48 --> Output Class Initialized
INFO - 2022-05-28 10:08:48 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:48 --> Input Class Initialized
INFO - 2022-05-28 10:08:48 --> Language Class Initialized
INFO - 2022-05-28 10:08:48 --> Language Class Initialized
INFO - 2022-05-28 10:08:48 --> Config Class Initialized
INFO - 2022-05-28 10:08:48 --> Loader Class Initialized
INFO - 2022-05-28 10:08:48 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:48 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:48 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:48 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:48 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:48 --> Controller Class Initialized
INFO - 2022-05-28 10:08:48 --> Helper loaded: cookie_helper
INFO - 2022-05-28 10:08:48 --> Config Class Initialized
INFO - 2022-05-28 10:08:48 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:48 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:48 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:48 --> URI Class Initialized
INFO - 2022-05-28 10:08:48 --> Router Class Initialized
INFO - 2022-05-28 10:08:48 --> Output Class Initialized
INFO - 2022-05-28 10:08:48 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:48 --> Input Class Initialized
INFO - 2022-05-28 10:08:48 --> Language Class Initialized
INFO - 2022-05-28 10:08:48 --> Language Class Initialized
INFO - 2022-05-28 10:08:48 --> Config Class Initialized
INFO - 2022-05-28 10:08:48 --> Loader Class Initialized
INFO - 2022-05-28 10:08:48 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:48 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:48 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:48 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:48 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:48 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-05-28 10:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:48 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:48 --> Total execution time: 0.0507
INFO - 2022-05-28 10:08:54 --> Config Class Initialized
INFO - 2022-05-28 10:08:54 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:54 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:54 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:54 --> URI Class Initialized
INFO - 2022-05-28 10:08:54 --> Router Class Initialized
INFO - 2022-05-28 10:08:54 --> Output Class Initialized
INFO - 2022-05-28 10:08:54 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:54 --> Input Class Initialized
INFO - 2022-05-28 10:08:54 --> Language Class Initialized
INFO - 2022-05-28 10:08:54 --> Language Class Initialized
INFO - 2022-05-28 10:08:54 --> Config Class Initialized
INFO - 2022-05-28 10:08:54 --> Loader Class Initialized
INFO - 2022-05-28 10:08:54 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:54 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:54 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:54 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:54 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:54 --> Controller Class Initialized
INFO - 2022-05-28 10:08:54 --> Helper loaded: cookie_helper
INFO - 2022-05-28 10:08:54 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:54 --> Total execution time: 0.0717
INFO - 2022-05-28 10:08:54 --> Config Class Initialized
INFO - 2022-05-28 10:08:54 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:54 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:54 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:54 --> URI Class Initialized
INFO - 2022-05-28 10:08:54 --> Router Class Initialized
INFO - 2022-05-28 10:08:54 --> Output Class Initialized
INFO - 2022-05-28 10:08:54 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:54 --> Input Class Initialized
INFO - 2022-05-28 10:08:54 --> Language Class Initialized
INFO - 2022-05-28 10:08:54 --> Language Class Initialized
INFO - 2022-05-28 10:08:54 --> Config Class Initialized
INFO - 2022-05-28 10:08:54 --> Loader Class Initialized
INFO - 2022-05-28 10:08:54 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:54 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:54 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:54 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:54 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:54 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-05-28 10:08:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:54 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:54 --> Total execution time: 0.0824
INFO - 2022-05-28 10:08:56 --> Config Class Initialized
INFO - 2022-05-28 10:08:56 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:08:56 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:08:56 --> Utf8 Class Initialized
INFO - 2022-05-28 10:08:56 --> URI Class Initialized
INFO - 2022-05-28 10:08:56 --> Router Class Initialized
INFO - 2022-05-28 10:08:56 --> Output Class Initialized
INFO - 2022-05-28 10:08:56 --> Security Class Initialized
DEBUG - 2022-05-28 10:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:08:56 --> Input Class Initialized
INFO - 2022-05-28 10:08:56 --> Language Class Initialized
INFO - 2022-05-28 10:08:56 --> Language Class Initialized
INFO - 2022-05-28 10:08:56 --> Config Class Initialized
INFO - 2022-05-28 10:08:56 --> Loader Class Initialized
INFO - 2022-05-28 10:08:56 --> Helper loaded: url_helper
INFO - 2022-05-28 10:08:56 --> Helper loaded: file_helper
INFO - 2022-05-28 10:08:56 --> Helper loaded: form_helper
INFO - 2022-05-28 10:08:56 --> Helper loaded: my_helper
INFO - 2022-05-28 10:08:56 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:08:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:08:56 --> Controller Class Initialized
DEBUG - 2022-05-28 10:08:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:08:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:08:56 --> Final output sent to browser
DEBUG - 2022-05-28 10:08:56 --> Total execution time: 0.1289
INFO - 2022-05-28 10:11:39 --> Config Class Initialized
INFO - 2022-05-28 10:11:39 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:11:39 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:11:39 --> Utf8 Class Initialized
INFO - 2022-05-28 10:11:39 --> URI Class Initialized
INFO - 2022-05-28 10:11:39 --> Router Class Initialized
INFO - 2022-05-28 10:11:39 --> Output Class Initialized
INFO - 2022-05-28 10:11:39 --> Security Class Initialized
DEBUG - 2022-05-28 10:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:11:39 --> Input Class Initialized
INFO - 2022-05-28 10:11:39 --> Language Class Initialized
INFO - 2022-05-28 10:11:39 --> Language Class Initialized
INFO - 2022-05-28 10:11:39 --> Config Class Initialized
INFO - 2022-05-28 10:11:39 --> Loader Class Initialized
INFO - 2022-05-28 10:11:39 --> Helper loaded: url_helper
INFO - 2022-05-28 10:11:39 --> Helper loaded: file_helper
INFO - 2022-05-28 10:11:39 --> Helper loaded: form_helper
INFO - 2022-05-28 10:11:39 --> Helper loaded: my_helper
INFO - 2022-05-28 10:11:39 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:11:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:11:40 --> Controller Class Initialized
ERROR - 2022-05-28 10:11:40 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `t_nilai_ekstra_ibfk_1` FOREIGN KEY (`ekstra`) REFERENCES `m_ekstra` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (id_siswa,tasm,ekstra,nilai,ekstra2,nilai2) VALUES ('1','20212','1','B','4','A')
INFO - 2022-05-28 10:11:40 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-28 10:11:47 --> Config Class Initialized
INFO - 2022-05-28 10:11:47 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:11:47 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:11:47 --> Utf8 Class Initialized
INFO - 2022-05-28 10:11:47 --> URI Class Initialized
INFO - 2022-05-28 10:11:47 --> Router Class Initialized
INFO - 2022-05-28 10:11:47 --> Output Class Initialized
INFO - 2022-05-28 10:11:47 --> Security Class Initialized
DEBUG - 2022-05-28 10:11:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:11:47 --> Input Class Initialized
INFO - 2022-05-28 10:11:47 --> Language Class Initialized
INFO - 2022-05-28 10:11:47 --> Language Class Initialized
INFO - 2022-05-28 10:11:47 --> Config Class Initialized
INFO - 2022-05-28 10:11:47 --> Loader Class Initialized
INFO - 2022-05-28 10:11:47 --> Helper loaded: url_helper
INFO - 2022-05-28 10:11:47 --> Helper loaded: file_helper
INFO - 2022-05-28 10:11:47 --> Helper loaded: form_helper
INFO - 2022-05-28 10:11:47 --> Helper loaded: my_helper
INFO - 2022-05-28 10:11:47 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:11:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:11:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:11:47 --> Controller Class Initialized
DEBUG - 2022-05-28 10:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:11:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:11:47 --> Final output sent to browser
DEBUG - 2022-05-28 10:11:47 --> Total execution time: 0.0804
INFO - 2022-05-28 10:16:57 --> Config Class Initialized
INFO - 2022-05-28 10:16:57 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:16:57 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:16:57 --> Utf8 Class Initialized
INFO - 2022-05-28 10:16:57 --> URI Class Initialized
INFO - 2022-05-28 10:16:57 --> Router Class Initialized
INFO - 2022-05-28 10:16:57 --> Output Class Initialized
INFO - 2022-05-28 10:16:57 --> Security Class Initialized
DEBUG - 2022-05-28 10:16:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:16:57 --> Input Class Initialized
INFO - 2022-05-28 10:16:57 --> Language Class Initialized
INFO - 2022-05-28 10:16:57 --> Language Class Initialized
INFO - 2022-05-28 10:16:57 --> Config Class Initialized
INFO - 2022-05-28 10:16:57 --> Loader Class Initialized
INFO - 2022-05-28 10:16:57 --> Helper loaded: url_helper
INFO - 2022-05-28 10:16:57 --> Helper loaded: file_helper
INFO - 2022-05-28 10:16:57 --> Helper loaded: form_helper
INFO - 2022-05-28 10:16:57 --> Helper loaded: my_helper
INFO - 2022-05-28 10:16:57 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:16:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:16:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:16:57 --> Controller Class Initialized
ERROR - 2022-05-28 10:16:57 --> Severity: Notice --> Undefined index: ekstra2_ C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 49
ERROR - 2022-05-28 10:16:57 --> Severity: Notice --> Undefined index: nilai2_ C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 54
DEBUG - 2022-05-28 10:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:16:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:16:57 --> Final output sent to browser
DEBUG - 2022-05-28 10:16:57 --> Total execution time: 0.0940
INFO - 2022-05-28 10:18:38 --> Config Class Initialized
INFO - 2022-05-28 10:18:38 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:18:38 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:18:38 --> Utf8 Class Initialized
INFO - 2022-05-28 10:18:38 --> URI Class Initialized
INFO - 2022-05-28 10:18:38 --> Router Class Initialized
INFO - 2022-05-28 10:18:38 --> Output Class Initialized
INFO - 2022-05-28 10:18:38 --> Security Class Initialized
DEBUG - 2022-05-28 10:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:18:38 --> Input Class Initialized
INFO - 2022-05-28 10:18:38 --> Language Class Initialized
INFO - 2022-05-28 10:18:38 --> Language Class Initialized
INFO - 2022-05-28 10:18:38 --> Config Class Initialized
INFO - 2022-05-28 10:18:38 --> Loader Class Initialized
INFO - 2022-05-28 10:18:38 --> Helper loaded: url_helper
INFO - 2022-05-28 10:18:38 --> Helper loaded: file_helper
INFO - 2022-05-28 10:18:38 --> Helper loaded: form_helper
INFO - 2022-05-28 10:18:38 --> Helper loaded: my_helper
INFO - 2022-05-28 10:18:38 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:18:38 --> Controller Class Initialized
DEBUG - 2022-05-28 10:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:18:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:18:38 --> Final output sent to browser
DEBUG - 2022-05-28 10:18:38 --> Total execution time: 0.0781
INFO - 2022-05-28 10:18:46 --> Config Class Initialized
INFO - 2022-05-28 10:18:46 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:18:46 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:18:46 --> Utf8 Class Initialized
INFO - 2022-05-28 10:18:46 --> URI Class Initialized
INFO - 2022-05-28 10:18:46 --> Router Class Initialized
INFO - 2022-05-28 10:18:46 --> Output Class Initialized
INFO - 2022-05-28 10:18:46 --> Security Class Initialized
DEBUG - 2022-05-28 10:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:18:46 --> Input Class Initialized
INFO - 2022-05-28 10:18:46 --> Language Class Initialized
INFO - 2022-05-28 10:18:46 --> Language Class Initialized
INFO - 2022-05-28 10:18:46 --> Config Class Initialized
INFO - 2022-05-28 10:18:46 --> Loader Class Initialized
INFO - 2022-05-28 10:18:46 --> Helper loaded: url_helper
INFO - 2022-05-28 10:18:46 --> Helper loaded: file_helper
INFO - 2022-05-28 10:18:46 --> Helper loaded: form_helper
INFO - 2022-05-28 10:18:46 --> Helper loaded: my_helper
INFO - 2022-05-28 10:18:46 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:18:46 --> Controller Class Initialized
ERROR - 2022-05-28 10:18:46 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `t_nilai_ekstra_ibfk_1` FOREIGN KEY (`ekstra`) REFERENCES `m_ekstra` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (id_siswa,tasm,ekstra,nilai,ekstra2,nilai2) VALUES ('1','20212','1','B','5','A')
INFO - 2022-05-28 10:18:46 --> Language file loaded: language/english/db_lang.php
INFO - 2022-05-28 10:19:42 --> Config Class Initialized
INFO - 2022-05-28 10:19:42 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:19:42 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:19:42 --> Utf8 Class Initialized
INFO - 2022-05-28 10:19:42 --> URI Class Initialized
INFO - 2022-05-28 10:19:42 --> Router Class Initialized
INFO - 2022-05-28 10:19:42 --> Output Class Initialized
INFO - 2022-05-28 10:19:42 --> Security Class Initialized
DEBUG - 2022-05-28 10:19:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:19:42 --> Input Class Initialized
INFO - 2022-05-28 10:19:42 --> Language Class Initialized
INFO - 2022-05-28 10:19:42 --> Language Class Initialized
INFO - 2022-05-28 10:19:42 --> Config Class Initialized
INFO - 2022-05-28 10:19:42 --> Loader Class Initialized
INFO - 2022-05-28 10:19:42 --> Helper loaded: url_helper
INFO - 2022-05-28 10:19:42 --> Helper loaded: file_helper
INFO - 2022-05-28 10:19:42 --> Helper loaded: form_helper
INFO - 2022-05-28 10:19:42 --> Helper loaded: my_helper
INFO - 2022-05-28 10:19:42 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:19:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:19:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:19:42 --> Controller Class Initialized
DEBUG - 2022-05-28 10:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:19:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:19:42 --> Final output sent to browser
DEBUG - 2022-05-28 10:19:42 --> Total execution time: 0.0747
INFO - 2022-05-28 10:21:59 --> Config Class Initialized
INFO - 2022-05-28 10:21:59 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:21:59 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:21:59 --> Utf8 Class Initialized
INFO - 2022-05-28 10:21:59 --> URI Class Initialized
INFO - 2022-05-28 10:21:59 --> Router Class Initialized
INFO - 2022-05-28 10:21:59 --> Output Class Initialized
INFO - 2022-05-28 10:21:59 --> Security Class Initialized
DEBUG - 2022-05-28 10:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:21:59 --> Input Class Initialized
INFO - 2022-05-28 10:21:59 --> Language Class Initialized
INFO - 2022-05-28 10:21:59 --> Language Class Initialized
INFO - 2022-05-28 10:21:59 --> Config Class Initialized
INFO - 2022-05-28 10:21:59 --> Loader Class Initialized
INFO - 2022-05-28 10:21:59 --> Helper loaded: url_helper
INFO - 2022-05-28 10:21:59 --> Helper loaded: file_helper
INFO - 2022-05-28 10:21:59 --> Helper loaded: form_helper
INFO - 2022-05-28 10:21:59 --> Helper loaded: my_helper
INFO - 2022-05-28 10:21:59 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:21:59 --> Controller Class Initialized
DEBUG - 2022-05-28 10:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:21:59 --> Final output sent to browser
DEBUG - 2022-05-28 10:21:59 --> Total execution time: 0.0715
INFO - 2022-05-28 10:22:06 --> Config Class Initialized
INFO - 2022-05-28 10:22:06 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:22:06 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:22:06 --> Utf8 Class Initialized
INFO - 2022-05-28 10:22:06 --> URI Class Initialized
INFO - 2022-05-28 10:22:06 --> Router Class Initialized
INFO - 2022-05-28 10:22:06 --> Output Class Initialized
INFO - 2022-05-28 10:22:06 --> Security Class Initialized
DEBUG - 2022-05-28 10:22:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:22:06 --> Input Class Initialized
INFO - 2022-05-28 10:22:06 --> Language Class Initialized
INFO - 2022-05-28 10:22:06 --> Language Class Initialized
INFO - 2022-05-28 10:22:06 --> Config Class Initialized
INFO - 2022-05-28 10:22:06 --> Loader Class Initialized
INFO - 2022-05-28 10:22:06 --> Helper loaded: url_helper
INFO - 2022-05-28 10:22:06 --> Helper loaded: file_helper
INFO - 2022-05-28 10:22:06 --> Helper loaded: form_helper
INFO - 2022-05-28 10:22:06 --> Helper loaded: my_helper
INFO - 2022-05-28 10:22:06 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:22:06 --> Controller Class Initialized
INFO - 2022-05-28 10:22:06 --> Final output sent to browser
DEBUG - 2022-05-28 10:22:06 --> Total execution time: 0.0598
INFO - 2022-05-28 10:22:09 --> Config Class Initialized
INFO - 2022-05-28 10:22:09 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:22:09 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:22:09 --> Utf8 Class Initialized
INFO - 2022-05-28 10:22:09 --> URI Class Initialized
INFO - 2022-05-28 10:22:09 --> Router Class Initialized
INFO - 2022-05-28 10:22:09 --> Output Class Initialized
INFO - 2022-05-28 10:22:09 --> Security Class Initialized
DEBUG - 2022-05-28 10:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:22:09 --> Input Class Initialized
INFO - 2022-05-28 10:22:09 --> Language Class Initialized
INFO - 2022-05-28 10:22:09 --> Language Class Initialized
INFO - 2022-05-28 10:22:09 --> Config Class Initialized
INFO - 2022-05-28 10:22:09 --> Loader Class Initialized
INFO - 2022-05-28 10:22:09 --> Helper loaded: url_helper
INFO - 2022-05-28 10:22:09 --> Helper loaded: file_helper
INFO - 2022-05-28 10:22:09 --> Helper loaded: form_helper
INFO - 2022-05-28 10:22:09 --> Helper loaded: my_helper
INFO - 2022-05-28 10:22:09 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:22:09 --> Controller Class Initialized
DEBUG - 2022-05-28 10:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:22:09 --> Final output sent to browser
DEBUG - 2022-05-28 10:22:09 --> Total execution time: 0.0647
INFO - 2022-05-28 10:22:10 --> Config Class Initialized
INFO - 2022-05-28 10:22:10 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:22:10 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:22:10 --> Utf8 Class Initialized
INFO - 2022-05-28 10:22:10 --> URI Class Initialized
INFO - 2022-05-28 10:22:10 --> Router Class Initialized
INFO - 2022-05-28 10:22:10 --> Output Class Initialized
INFO - 2022-05-28 10:22:10 --> Security Class Initialized
DEBUG - 2022-05-28 10:22:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:22:10 --> Input Class Initialized
INFO - 2022-05-28 10:22:10 --> Language Class Initialized
INFO - 2022-05-28 10:22:10 --> Language Class Initialized
INFO - 2022-05-28 10:22:10 --> Config Class Initialized
INFO - 2022-05-28 10:22:10 --> Loader Class Initialized
INFO - 2022-05-28 10:22:10 --> Helper loaded: url_helper
INFO - 2022-05-28 10:22:10 --> Helper loaded: file_helper
INFO - 2022-05-28 10:22:10 --> Helper loaded: form_helper
INFO - 2022-05-28 10:22:10 --> Helper loaded: my_helper
INFO - 2022-05-28 10:22:10 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:22:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:22:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:22:10 --> Controller Class Initialized
DEBUG - 2022-05-28 10:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:22:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:22:10 --> Final output sent to browser
DEBUG - 2022-05-28 10:22:10 --> Total execution time: 0.0617
INFO - 2022-05-28 10:22:27 --> Config Class Initialized
INFO - 2022-05-28 10:22:27 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:22:27 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:22:27 --> Utf8 Class Initialized
INFO - 2022-05-28 10:22:27 --> URI Class Initialized
INFO - 2022-05-28 10:22:27 --> Router Class Initialized
INFO - 2022-05-28 10:22:27 --> Output Class Initialized
INFO - 2022-05-28 10:22:27 --> Security Class Initialized
DEBUG - 2022-05-28 10:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:22:27 --> Input Class Initialized
INFO - 2022-05-28 10:22:27 --> Language Class Initialized
INFO - 2022-05-28 10:22:27 --> Language Class Initialized
INFO - 2022-05-28 10:22:27 --> Config Class Initialized
INFO - 2022-05-28 10:22:27 --> Loader Class Initialized
INFO - 2022-05-28 10:22:27 --> Helper loaded: url_helper
INFO - 2022-05-28 10:22:27 --> Helper loaded: file_helper
INFO - 2022-05-28 10:22:27 --> Helper loaded: form_helper
INFO - 2022-05-28 10:22:27 --> Helper loaded: my_helper
INFO - 2022-05-28 10:22:27 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:22:27 --> Controller Class Initialized
DEBUG - 2022-05-28 10:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-05-28 10:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:22:27 --> Final output sent to browser
DEBUG - 2022-05-28 10:22:27 --> Total execution time: 0.0900
INFO - 2022-05-28 10:22:28 --> Config Class Initialized
INFO - 2022-05-28 10:22:28 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:22:28 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:22:28 --> Utf8 Class Initialized
INFO - 2022-05-28 10:22:28 --> URI Class Initialized
INFO - 2022-05-28 10:22:28 --> Router Class Initialized
INFO - 2022-05-28 10:22:28 --> Output Class Initialized
INFO - 2022-05-28 10:22:28 --> Security Class Initialized
DEBUG - 2022-05-28 10:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:22:28 --> Input Class Initialized
INFO - 2022-05-28 10:22:28 --> Language Class Initialized
INFO - 2022-05-28 10:22:28 --> Language Class Initialized
INFO - 2022-05-28 10:22:28 --> Config Class Initialized
INFO - 2022-05-28 10:22:28 --> Loader Class Initialized
INFO - 2022-05-28 10:22:28 --> Helper loaded: url_helper
INFO - 2022-05-28 10:22:28 --> Helper loaded: file_helper
INFO - 2022-05-28 10:22:28 --> Helper loaded: form_helper
INFO - 2022-05-28 10:22:28 --> Helper loaded: my_helper
INFO - 2022-05-28 10:22:28 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:22:28 --> Controller Class Initialized
DEBUG - 2022-05-28 10:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:22:28 --> Final output sent to browser
DEBUG - 2022-05-28 10:22:28 --> Total execution time: 0.0721
INFO - 2022-05-28 10:22:30 --> Config Class Initialized
INFO - 2022-05-28 10:22:30 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:22:30 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:22:30 --> Utf8 Class Initialized
INFO - 2022-05-28 10:22:30 --> URI Class Initialized
INFO - 2022-05-28 10:22:30 --> Router Class Initialized
INFO - 2022-05-28 10:22:30 --> Output Class Initialized
INFO - 2022-05-28 10:22:30 --> Security Class Initialized
DEBUG - 2022-05-28 10:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:22:30 --> Input Class Initialized
INFO - 2022-05-28 10:22:30 --> Language Class Initialized
INFO - 2022-05-28 10:22:30 --> Language Class Initialized
INFO - 2022-05-28 10:22:30 --> Config Class Initialized
INFO - 2022-05-28 10:22:30 --> Loader Class Initialized
INFO - 2022-05-28 10:22:30 --> Helper loaded: url_helper
INFO - 2022-05-28 10:22:30 --> Helper loaded: file_helper
INFO - 2022-05-28 10:22:30 --> Helper loaded: form_helper
INFO - 2022-05-28 10:22:30 --> Helper loaded: my_helper
INFO - 2022-05-28 10:22:30 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:22:30 --> Controller Class Initialized
DEBUG - 2022-05-28 10:22:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:22:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:22:30 --> Final output sent to browser
DEBUG - 2022-05-28 10:22:30 --> Total execution time: 0.0682
INFO - 2022-05-28 10:24:57 --> Config Class Initialized
INFO - 2022-05-28 10:24:57 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:24:57 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:24:57 --> Utf8 Class Initialized
INFO - 2022-05-28 10:24:57 --> URI Class Initialized
INFO - 2022-05-28 10:24:57 --> Router Class Initialized
INFO - 2022-05-28 10:24:57 --> Output Class Initialized
INFO - 2022-05-28 10:24:57 --> Security Class Initialized
DEBUG - 2022-05-28 10:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:24:57 --> Input Class Initialized
INFO - 2022-05-28 10:24:57 --> Language Class Initialized
INFO - 2022-05-28 10:24:57 --> Language Class Initialized
INFO - 2022-05-28 10:24:57 --> Config Class Initialized
INFO - 2022-05-28 10:24:57 --> Loader Class Initialized
INFO - 2022-05-28 10:24:57 --> Helper loaded: url_helper
INFO - 2022-05-28 10:24:57 --> Helper loaded: file_helper
INFO - 2022-05-28 10:24:57 --> Helper loaded: form_helper
INFO - 2022-05-28 10:24:57 --> Helper loaded: my_helper
INFO - 2022-05-28 10:24:57 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:24:57 --> Controller Class Initialized
DEBUG - 2022-05-28 10:24:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:24:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:24:57 --> Final output sent to browser
DEBUG - 2022-05-28 10:24:57 --> Total execution time: 0.0663
INFO - 2022-05-28 10:25:04 --> Config Class Initialized
INFO - 2022-05-28 10:25:04 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:25:04 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:25:04 --> Utf8 Class Initialized
INFO - 2022-05-28 10:25:04 --> URI Class Initialized
INFO - 2022-05-28 10:25:04 --> Router Class Initialized
INFO - 2022-05-28 10:25:04 --> Output Class Initialized
INFO - 2022-05-28 10:25:04 --> Security Class Initialized
DEBUG - 2022-05-28 10:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:25:04 --> Input Class Initialized
INFO - 2022-05-28 10:25:04 --> Language Class Initialized
INFO - 2022-05-28 10:25:04 --> Language Class Initialized
INFO - 2022-05-28 10:25:04 --> Config Class Initialized
INFO - 2022-05-28 10:25:04 --> Loader Class Initialized
INFO - 2022-05-28 10:25:04 --> Helper loaded: url_helper
INFO - 2022-05-28 10:25:04 --> Helper loaded: file_helper
INFO - 2022-05-28 10:25:04 --> Helper loaded: form_helper
INFO - 2022-05-28 10:25:04 --> Helper loaded: my_helper
INFO - 2022-05-28 10:25:04 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:25:04 --> Controller Class Initialized
INFO - 2022-05-28 10:25:04 --> Final output sent to browser
DEBUG - 2022-05-28 10:25:04 --> Total execution time: 0.0678
INFO - 2022-05-28 10:25:05 --> Config Class Initialized
INFO - 2022-05-28 10:25:05 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:25:05 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:25:05 --> Utf8 Class Initialized
INFO - 2022-05-28 10:25:05 --> URI Class Initialized
INFO - 2022-05-28 10:25:05 --> Router Class Initialized
INFO - 2022-05-28 10:25:05 --> Output Class Initialized
INFO - 2022-05-28 10:25:05 --> Security Class Initialized
DEBUG - 2022-05-28 10:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:25:06 --> Input Class Initialized
INFO - 2022-05-28 10:25:06 --> Language Class Initialized
INFO - 2022-05-28 10:25:06 --> Language Class Initialized
INFO - 2022-05-28 10:25:06 --> Config Class Initialized
INFO - 2022-05-28 10:25:06 --> Loader Class Initialized
INFO - 2022-05-28 10:25:06 --> Helper loaded: url_helper
INFO - 2022-05-28 10:25:06 --> Helper loaded: file_helper
INFO - 2022-05-28 10:25:06 --> Helper loaded: form_helper
INFO - 2022-05-28 10:25:06 --> Helper loaded: my_helper
INFO - 2022-05-28 10:25:06 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:25:06 --> Controller Class Initialized
DEBUG - 2022-05-28 10:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:25:06 --> Final output sent to browser
DEBUG - 2022-05-28 10:25:06 --> Total execution time: 0.0724
INFO - 2022-05-28 10:25:07 --> Config Class Initialized
INFO - 2022-05-28 10:25:07 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:25:07 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:25:07 --> Utf8 Class Initialized
INFO - 2022-05-28 10:25:07 --> URI Class Initialized
INFO - 2022-05-28 10:25:07 --> Router Class Initialized
INFO - 2022-05-28 10:25:07 --> Output Class Initialized
INFO - 2022-05-28 10:25:07 --> Security Class Initialized
DEBUG - 2022-05-28 10:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:25:07 --> Input Class Initialized
INFO - 2022-05-28 10:25:07 --> Language Class Initialized
INFO - 2022-05-28 10:25:07 --> Language Class Initialized
INFO - 2022-05-28 10:25:07 --> Config Class Initialized
INFO - 2022-05-28 10:25:07 --> Loader Class Initialized
INFO - 2022-05-28 10:25:07 --> Helper loaded: url_helper
INFO - 2022-05-28 10:25:07 --> Helper loaded: file_helper
INFO - 2022-05-28 10:25:07 --> Helper loaded: form_helper
INFO - 2022-05-28 10:25:07 --> Helper loaded: my_helper
INFO - 2022-05-28 10:25:07 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:25:07 --> Controller Class Initialized
DEBUG - 2022-05-28 10:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:25:07 --> Final output sent to browser
DEBUG - 2022-05-28 10:25:07 --> Total execution time: 0.0645
INFO - 2022-05-28 10:27:02 --> Config Class Initialized
INFO - 2022-05-28 10:27:02 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:27:02 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:27:02 --> Utf8 Class Initialized
INFO - 2022-05-28 10:27:02 --> URI Class Initialized
INFO - 2022-05-28 10:27:02 --> Router Class Initialized
INFO - 2022-05-28 10:27:02 --> Output Class Initialized
INFO - 2022-05-28 10:27:02 --> Security Class Initialized
DEBUG - 2022-05-28 10:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:27:02 --> Input Class Initialized
INFO - 2022-05-28 10:27:02 --> Language Class Initialized
INFO - 2022-05-28 10:27:02 --> Language Class Initialized
INFO - 2022-05-28 10:27:02 --> Config Class Initialized
INFO - 2022-05-28 10:27:02 --> Loader Class Initialized
INFO - 2022-05-28 10:27:02 --> Helper loaded: url_helper
INFO - 2022-05-28 10:27:02 --> Helper loaded: file_helper
INFO - 2022-05-28 10:27:02 --> Helper loaded: form_helper
INFO - 2022-05-28 10:27:02 --> Helper loaded: my_helper
INFO - 2022-05-28 10:27:02 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:27:02 --> Controller Class Initialized
DEBUG - 2022-05-28 10:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:27:02 --> Final output sent to browser
DEBUG - 2022-05-28 10:27:02 --> Total execution time: 0.0538
INFO - 2022-05-28 10:27:03 --> Config Class Initialized
INFO - 2022-05-28 10:27:03 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:27:03 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:27:03 --> Utf8 Class Initialized
INFO - 2022-05-28 10:27:03 --> URI Class Initialized
INFO - 2022-05-28 10:27:03 --> Router Class Initialized
INFO - 2022-05-28 10:27:03 --> Output Class Initialized
INFO - 2022-05-28 10:27:03 --> Security Class Initialized
DEBUG - 2022-05-28 10:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:27:03 --> Input Class Initialized
INFO - 2022-05-28 10:27:03 --> Language Class Initialized
INFO - 2022-05-28 10:27:03 --> Language Class Initialized
INFO - 2022-05-28 10:27:03 --> Config Class Initialized
INFO - 2022-05-28 10:27:03 --> Loader Class Initialized
INFO - 2022-05-28 10:27:03 --> Helper loaded: url_helper
INFO - 2022-05-28 10:27:03 --> Helper loaded: file_helper
INFO - 2022-05-28 10:27:03 --> Helper loaded: form_helper
INFO - 2022-05-28 10:27:03 --> Helper loaded: my_helper
INFO - 2022-05-28 10:27:03 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:27:03 --> Controller Class Initialized
DEBUG - 2022-05-28 10:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:27:03 --> Final output sent to browser
DEBUG - 2022-05-28 10:27:03 --> Total execution time: 0.0654
INFO - 2022-05-28 10:27:03 --> Config Class Initialized
INFO - 2022-05-28 10:27:03 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:27:03 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:27:03 --> Utf8 Class Initialized
INFO - 2022-05-28 10:27:03 --> URI Class Initialized
INFO - 2022-05-28 10:27:03 --> Router Class Initialized
INFO - 2022-05-28 10:27:03 --> Output Class Initialized
INFO - 2022-05-28 10:27:03 --> Security Class Initialized
DEBUG - 2022-05-28 10:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:27:03 --> Input Class Initialized
INFO - 2022-05-28 10:27:03 --> Language Class Initialized
INFO - 2022-05-28 10:27:03 --> Language Class Initialized
INFO - 2022-05-28 10:27:03 --> Config Class Initialized
INFO - 2022-05-28 10:27:03 --> Loader Class Initialized
INFO - 2022-05-28 10:27:03 --> Helper loaded: url_helper
INFO - 2022-05-28 10:27:03 --> Helper loaded: file_helper
INFO - 2022-05-28 10:27:03 --> Helper loaded: form_helper
INFO - 2022-05-28 10:27:03 --> Helper loaded: my_helper
INFO - 2022-05-28 10:27:03 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:27:03 --> Controller Class Initialized
DEBUG - 2022-05-28 10:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:27:03 --> Final output sent to browser
DEBUG - 2022-05-28 10:27:03 --> Total execution time: 0.0644
INFO - 2022-05-28 10:39:13 --> Config Class Initialized
INFO - 2022-05-28 10:39:13 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:39:13 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:39:13 --> Utf8 Class Initialized
INFO - 2022-05-28 10:39:13 --> URI Class Initialized
INFO - 2022-05-28 10:39:13 --> Router Class Initialized
INFO - 2022-05-28 10:39:13 --> Output Class Initialized
INFO - 2022-05-28 10:39:13 --> Security Class Initialized
DEBUG - 2022-05-28 10:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:39:13 --> Input Class Initialized
INFO - 2022-05-28 10:39:13 --> Language Class Initialized
INFO - 2022-05-28 10:39:13 --> Language Class Initialized
INFO - 2022-05-28 10:39:13 --> Config Class Initialized
INFO - 2022-05-28 10:39:13 --> Loader Class Initialized
INFO - 2022-05-28 10:39:13 --> Helper loaded: url_helper
INFO - 2022-05-28 10:39:13 --> Helper loaded: file_helper
INFO - 2022-05-28 10:39:13 --> Helper loaded: form_helper
INFO - 2022-05-28 10:39:13 --> Helper loaded: my_helper
INFO - 2022-05-28 10:39:13 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:39:13 --> Controller Class Initialized
INFO - 2022-05-28 10:39:13 --> Final output sent to browser
DEBUG - 2022-05-28 10:39:13 --> Total execution time: 0.0935
INFO - 2022-05-28 10:39:15 --> Config Class Initialized
INFO - 2022-05-28 10:39:15 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:39:15 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:39:15 --> Utf8 Class Initialized
INFO - 2022-05-28 10:39:15 --> URI Class Initialized
INFO - 2022-05-28 10:39:15 --> Router Class Initialized
INFO - 2022-05-28 10:39:15 --> Output Class Initialized
INFO - 2022-05-28 10:39:15 --> Security Class Initialized
DEBUG - 2022-05-28 10:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:39:15 --> Input Class Initialized
INFO - 2022-05-28 10:39:15 --> Language Class Initialized
INFO - 2022-05-28 10:39:15 --> Language Class Initialized
INFO - 2022-05-28 10:39:15 --> Config Class Initialized
INFO - 2022-05-28 10:39:15 --> Loader Class Initialized
INFO - 2022-05-28 10:39:15 --> Helper loaded: url_helper
INFO - 2022-05-28 10:39:15 --> Helper loaded: file_helper
INFO - 2022-05-28 10:39:15 --> Helper loaded: form_helper
INFO - 2022-05-28 10:39:15 --> Helper loaded: my_helper
INFO - 2022-05-28 10:39:15 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:39:15 --> Controller Class Initialized
DEBUG - 2022-05-28 10:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:39:15 --> Final output sent to browser
DEBUG - 2022-05-28 10:39:15 --> Total execution time: 0.0665
INFO - 2022-05-28 10:42:52 --> Config Class Initialized
INFO - 2022-05-28 10:42:52 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:42:52 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:42:52 --> Utf8 Class Initialized
INFO - 2022-05-28 10:42:52 --> URI Class Initialized
INFO - 2022-05-28 10:42:52 --> Router Class Initialized
INFO - 2022-05-28 10:42:52 --> Output Class Initialized
INFO - 2022-05-28 10:42:52 --> Security Class Initialized
DEBUG - 2022-05-28 10:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:42:52 --> Input Class Initialized
INFO - 2022-05-28 10:42:52 --> Language Class Initialized
INFO - 2022-05-28 10:42:52 --> Language Class Initialized
INFO - 2022-05-28 10:42:52 --> Config Class Initialized
INFO - 2022-05-28 10:42:52 --> Loader Class Initialized
INFO - 2022-05-28 10:42:52 --> Helper loaded: url_helper
INFO - 2022-05-28 10:42:52 --> Helper loaded: file_helper
INFO - 2022-05-28 10:42:52 --> Helper loaded: form_helper
INFO - 2022-05-28 10:42:52 --> Helper loaded: my_helper
INFO - 2022-05-28 10:42:52 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:42:52 --> Controller Class Initialized
DEBUG - 2022-05-28 10:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:42:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:42:52 --> Final output sent to browser
DEBUG - 2022-05-28 10:42:52 --> Total execution time: 0.0526
INFO - 2022-05-28 10:43:39 --> Config Class Initialized
INFO - 2022-05-28 10:43:39 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:43:39 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:43:39 --> Utf8 Class Initialized
INFO - 2022-05-28 10:43:39 --> URI Class Initialized
INFO - 2022-05-28 10:43:39 --> Router Class Initialized
INFO - 2022-05-28 10:43:39 --> Output Class Initialized
INFO - 2022-05-28 10:43:39 --> Security Class Initialized
DEBUG - 2022-05-28 10:43:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:43:39 --> Input Class Initialized
INFO - 2022-05-28 10:43:39 --> Language Class Initialized
INFO - 2022-05-28 10:43:39 --> Language Class Initialized
INFO - 2022-05-28 10:43:39 --> Config Class Initialized
INFO - 2022-05-28 10:43:39 --> Loader Class Initialized
INFO - 2022-05-28 10:43:39 --> Helper loaded: url_helper
INFO - 2022-05-28 10:43:39 --> Helper loaded: file_helper
INFO - 2022-05-28 10:43:39 --> Helper loaded: form_helper
INFO - 2022-05-28 10:43:39 --> Helper loaded: my_helper
INFO - 2022-05-28 10:43:39 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:43:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:43:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:43:39 --> Controller Class Initialized
DEBUG - 2022-05-28 10:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:43:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:43:39 --> Final output sent to browser
DEBUG - 2022-05-28 10:43:39 --> Total execution time: 0.0719
INFO - 2022-05-28 10:43:42 --> Config Class Initialized
INFO - 2022-05-28 10:43:42 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:43:42 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:43:42 --> Utf8 Class Initialized
INFO - 2022-05-28 10:43:42 --> URI Class Initialized
INFO - 2022-05-28 10:43:42 --> Router Class Initialized
INFO - 2022-05-28 10:43:42 --> Output Class Initialized
INFO - 2022-05-28 10:43:42 --> Security Class Initialized
DEBUG - 2022-05-28 10:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:43:42 --> Input Class Initialized
INFO - 2022-05-28 10:43:42 --> Language Class Initialized
INFO - 2022-05-28 10:43:42 --> Language Class Initialized
INFO - 2022-05-28 10:43:42 --> Config Class Initialized
INFO - 2022-05-28 10:43:42 --> Loader Class Initialized
INFO - 2022-05-28 10:43:42 --> Helper loaded: url_helper
INFO - 2022-05-28 10:43:42 --> Helper loaded: file_helper
INFO - 2022-05-28 10:43:42 --> Helper loaded: form_helper
INFO - 2022-05-28 10:43:42 --> Helper loaded: my_helper
INFO - 2022-05-28 10:43:42 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:43:42 --> Controller Class Initialized
DEBUG - 2022-05-28 10:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:43:42 --> Final output sent to browser
DEBUG - 2022-05-28 10:43:42 --> Total execution time: 0.0618
INFO - 2022-05-28 10:43:48 --> Config Class Initialized
INFO - 2022-05-28 10:43:48 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:43:48 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:43:48 --> Utf8 Class Initialized
INFO - 2022-05-28 10:43:48 --> URI Class Initialized
INFO - 2022-05-28 10:43:48 --> Router Class Initialized
INFO - 2022-05-28 10:43:48 --> Output Class Initialized
INFO - 2022-05-28 10:43:48 --> Security Class Initialized
DEBUG - 2022-05-28 10:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:43:48 --> Input Class Initialized
INFO - 2022-05-28 10:43:48 --> Language Class Initialized
INFO - 2022-05-28 10:43:48 --> Language Class Initialized
INFO - 2022-05-28 10:43:48 --> Config Class Initialized
INFO - 2022-05-28 10:43:48 --> Loader Class Initialized
INFO - 2022-05-28 10:43:48 --> Helper loaded: url_helper
INFO - 2022-05-28 10:43:48 --> Helper loaded: file_helper
INFO - 2022-05-28 10:43:48 --> Helper loaded: form_helper
INFO - 2022-05-28 10:43:48 --> Helper loaded: my_helper
INFO - 2022-05-28 10:43:48 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:43:48 --> Controller Class Initialized
INFO - 2022-05-28 10:43:48 --> Final output sent to browser
DEBUG - 2022-05-28 10:43:48 --> Total execution time: 0.0681
INFO - 2022-05-28 10:43:49 --> Config Class Initialized
INFO - 2022-05-28 10:43:49 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:43:49 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:43:49 --> Utf8 Class Initialized
INFO - 2022-05-28 10:43:49 --> URI Class Initialized
INFO - 2022-05-28 10:43:49 --> Router Class Initialized
INFO - 2022-05-28 10:43:49 --> Output Class Initialized
INFO - 2022-05-28 10:43:49 --> Security Class Initialized
DEBUG - 2022-05-28 10:43:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:43:49 --> Input Class Initialized
INFO - 2022-05-28 10:43:49 --> Language Class Initialized
INFO - 2022-05-28 10:43:49 --> Language Class Initialized
INFO - 2022-05-28 10:43:49 --> Config Class Initialized
INFO - 2022-05-28 10:43:49 --> Loader Class Initialized
INFO - 2022-05-28 10:43:49 --> Helper loaded: url_helper
INFO - 2022-05-28 10:43:49 --> Helper loaded: file_helper
INFO - 2022-05-28 10:43:49 --> Helper loaded: form_helper
INFO - 2022-05-28 10:43:49 --> Helper loaded: my_helper
INFO - 2022-05-28 10:43:49 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:43:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:43:49 --> Controller Class Initialized
DEBUG - 2022-05-28 10:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:43:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:43:49 --> Final output sent to browser
DEBUG - 2022-05-28 10:43:49 --> Total execution time: 0.0687
INFO - 2022-05-28 10:44:12 --> Config Class Initialized
INFO - 2022-05-28 10:44:12 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:44:12 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:44:12 --> Utf8 Class Initialized
INFO - 2022-05-28 10:44:12 --> URI Class Initialized
INFO - 2022-05-28 10:44:12 --> Router Class Initialized
INFO - 2022-05-28 10:44:12 --> Output Class Initialized
INFO - 2022-05-28 10:44:12 --> Security Class Initialized
DEBUG - 2022-05-28 10:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:44:12 --> Input Class Initialized
INFO - 2022-05-28 10:44:12 --> Language Class Initialized
INFO - 2022-05-28 10:44:12 --> Language Class Initialized
INFO - 2022-05-28 10:44:12 --> Config Class Initialized
INFO - 2022-05-28 10:44:12 --> Loader Class Initialized
INFO - 2022-05-28 10:44:12 --> Helper loaded: url_helper
INFO - 2022-05-28 10:44:12 --> Helper loaded: file_helper
INFO - 2022-05-28 10:44:12 --> Helper loaded: form_helper
INFO - 2022-05-28 10:44:12 --> Helper loaded: my_helper
INFO - 2022-05-28 10:44:12 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:44:12 --> Controller Class Initialized
INFO - 2022-05-28 10:44:12 --> Final output sent to browser
DEBUG - 2022-05-28 10:44:12 --> Total execution time: 0.0730
INFO - 2022-05-28 10:44:14 --> Config Class Initialized
INFO - 2022-05-28 10:44:14 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:44:14 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:44:14 --> Utf8 Class Initialized
INFO - 2022-05-28 10:44:14 --> URI Class Initialized
INFO - 2022-05-28 10:44:14 --> Router Class Initialized
INFO - 2022-05-28 10:44:14 --> Output Class Initialized
INFO - 2022-05-28 10:44:14 --> Security Class Initialized
DEBUG - 2022-05-28 10:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:44:14 --> Input Class Initialized
INFO - 2022-05-28 10:44:14 --> Language Class Initialized
INFO - 2022-05-28 10:44:14 --> Language Class Initialized
INFO - 2022-05-28 10:44:14 --> Config Class Initialized
INFO - 2022-05-28 10:44:14 --> Loader Class Initialized
INFO - 2022-05-28 10:44:14 --> Helper loaded: url_helper
INFO - 2022-05-28 10:44:14 --> Helper loaded: file_helper
INFO - 2022-05-28 10:44:14 --> Helper loaded: form_helper
INFO - 2022-05-28 10:44:14 --> Helper loaded: my_helper
INFO - 2022-05-28 10:44:14 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:44:14 --> Controller Class Initialized
DEBUG - 2022-05-28 10:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:44:14 --> Final output sent to browser
DEBUG - 2022-05-28 10:44:14 --> Total execution time: 0.0660
INFO - 2022-05-28 10:45:05 --> Config Class Initialized
INFO - 2022-05-28 10:45:05 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:45:05 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:45:05 --> Utf8 Class Initialized
INFO - 2022-05-28 10:45:05 --> URI Class Initialized
INFO - 2022-05-28 10:45:05 --> Router Class Initialized
INFO - 2022-05-28 10:45:05 --> Output Class Initialized
INFO - 2022-05-28 10:45:05 --> Security Class Initialized
DEBUG - 2022-05-28 10:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:45:05 --> Input Class Initialized
INFO - 2022-05-28 10:45:05 --> Language Class Initialized
INFO - 2022-05-28 10:45:05 --> Language Class Initialized
INFO - 2022-05-28 10:45:05 --> Config Class Initialized
INFO - 2022-05-28 10:45:05 --> Loader Class Initialized
INFO - 2022-05-28 10:45:05 --> Helper loaded: url_helper
INFO - 2022-05-28 10:45:05 --> Helper loaded: file_helper
INFO - 2022-05-28 10:45:05 --> Helper loaded: form_helper
INFO - 2022-05-28 10:45:05 --> Helper loaded: my_helper
INFO - 2022-05-28 10:45:05 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:45:05 --> Controller Class Initialized
DEBUG - 2022-05-28 10:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-05-28 10:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:45:05 --> Final output sent to browser
DEBUG - 2022-05-28 10:45:05 --> Total execution time: 0.0803
INFO - 2022-05-28 10:45:14 --> Config Class Initialized
INFO - 2022-05-28 10:45:14 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:45:14 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:45:14 --> Utf8 Class Initialized
INFO - 2022-05-28 10:45:14 --> URI Class Initialized
INFO - 2022-05-28 10:45:14 --> Router Class Initialized
INFO - 2022-05-28 10:45:14 --> Output Class Initialized
INFO - 2022-05-28 10:45:14 --> Security Class Initialized
DEBUG - 2022-05-28 10:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:45:14 --> Input Class Initialized
INFO - 2022-05-28 10:45:14 --> Language Class Initialized
INFO - 2022-05-28 10:45:14 --> Language Class Initialized
INFO - 2022-05-28 10:45:14 --> Config Class Initialized
INFO - 2022-05-28 10:45:14 --> Loader Class Initialized
INFO - 2022-05-28 10:45:14 --> Helper loaded: url_helper
INFO - 2022-05-28 10:45:14 --> Helper loaded: file_helper
INFO - 2022-05-28 10:45:14 --> Helper loaded: form_helper
INFO - 2022-05-28 10:45:14 --> Helper loaded: my_helper
INFO - 2022-05-28 10:45:14 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:45:14 --> Controller Class Initialized
INFO - 2022-05-28 10:45:14 --> Final output sent to browser
DEBUG - 2022-05-28 10:45:14 --> Total execution time: 0.0636
INFO - 2022-05-28 10:45:15 --> Config Class Initialized
INFO - 2022-05-28 10:45:15 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:45:15 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:45:15 --> Utf8 Class Initialized
INFO - 2022-05-28 10:45:15 --> URI Class Initialized
INFO - 2022-05-28 10:45:15 --> Router Class Initialized
INFO - 2022-05-28 10:45:15 --> Output Class Initialized
INFO - 2022-05-28 10:45:15 --> Security Class Initialized
DEBUG - 2022-05-28 10:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:45:15 --> Input Class Initialized
INFO - 2022-05-28 10:45:15 --> Language Class Initialized
INFO - 2022-05-28 10:45:15 --> Language Class Initialized
INFO - 2022-05-28 10:45:15 --> Config Class Initialized
INFO - 2022-05-28 10:45:15 --> Loader Class Initialized
INFO - 2022-05-28 10:45:15 --> Helper loaded: url_helper
INFO - 2022-05-28 10:45:15 --> Helper loaded: file_helper
INFO - 2022-05-28 10:45:15 --> Helper loaded: form_helper
INFO - 2022-05-28 10:45:15 --> Helper loaded: my_helper
INFO - 2022-05-28 10:45:15 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:45:15 --> Controller Class Initialized
DEBUG - 2022-05-28 10:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-05-28 10:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:45:15 --> Final output sent to browser
DEBUG - 2022-05-28 10:45:15 --> Total execution time: 0.0784
INFO - 2022-05-28 10:45:16 --> Config Class Initialized
INFO - 2022-05-28 10:45:16 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:45:16 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:45:16 --> Utf8 Class Initialized
INFO - 2022-05-28 10:45:16 --> URI Class Initialized
INFO - 2022-05-28 10:45:16 --> Router Class Initialized
INFO - 2022-05-28 10:45:16 --> Output Class Initialized
INFO - 2022-05-28 10:45:16 --> Security Class Initialized
DEBUG - 2022-05-28 10:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:45:16 --> Input Class Initialized
INFO - 2022-05-28 10:45:16 --> Language Class Initialized
INFO - 2022-05-28 10:45:16 --> Language Class Initialized
INFO - 2022-05-28 10:45:16 --> Config Class Initialized
INFO - 2022-05-28 10:45:16 --> Loader Class Initialized
INFO - 2022-05-28 10:45:16 --> Helper loaded: url_helper
INFO - 2022-05-28 10:45:16 --> Helper loaded: file_helper
INFO - 2022-05-28 10:45:16 --> Helper loaded: form_helper
INFO - 2022-05-28 10:45:16 --> Helper loaded: my_helper
INFO - 2022-05-28 10:45:16 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:45:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:45:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:45:16 --> Controller Class Initialized
DEBUG - 2022-05-28 10:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-05-28 10:45:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:45:16 --> Final output sent to browser
DEBUG - 2022-05-28 10:45:16 --> Total execution time: 0.0470
INFO - 2022-05-28 10:45:19 --> Config Class Initialized
INFO - 2022-05-28 10:45:19 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:45:19 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:45:19 --> Utf8 Class Initialized
INFO - 2022-05-28 10:45:19 --> URI Class Initialized
INFO - 2022-05-28 10:45:19 --> Router Class Initialized
INFO - 2022-05-28 10:45:19 --> Output Class Initialized
INFO - 2022-05-28 10:45:19 --> Security Class Initialized
DEBUG - 2022-05-28 10:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:45:19 --> Input Class Initialized
INFO - 2022-05-28 10:45:19 --> Language Class Initialized
INFO - 2022-05-28 10:45:19 --> Language Class Initialized
INFO - 2022-05-28 10:45:19 --> Config Class Initialized
INFO - 2022-05-28 10:45:19 --> Loader Class Initialized
INFO - 2022-05-28 10:45:19 --> Helper loaded: url_helper
INFO - 2022-05-28 10:45:19 --> Helper loaded: file_helper
INFO - 2022-05-28 10:45:19 --> Helper loaded: form_helper
INFO - 2022-05-28 10:45:19 --> Helper loaded: my_helper
INFO - 2022-05-28 10:45:19 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:45:19 --> Controller Class Initialized
DEBUG - 2022-05-28 10:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-05-28 10:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:45:19 --> Final output sent to browser
DEBUG - 2022-05-28 10:45:19 --> Total execution time: 0.0652
INFO - 2022-05-28 10:49:26 --> Config Class Initialized
INFO - 2022-05-28 10:49:26 --> Hooks Class Initialized
DEBUG - 2022-05-28 10:49:26 --> UTF-8 Support Enabled
INFO - 2022-05-28 10:49:26 --> Utf8 Class Initialized
INFO - 2022-05-28 10:49:26 --> URI Class Initialized
INFO - 2022-05-28 10:49:26 --> Router Class Initialized
INFO - 2022-05-28 10:49:26 --> Output Class Initialized
INFO - 2022-05-28 10:49:26 --> Security Class Initialized
DEBUG - 2022-05-28 10:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-05-28 10:49:26 --> Input Class Initialized
INFO - 2022-05-28 10:49:26 --> Language Class Initialized
INFO - 2022-05-28 10:49:26 --> Language Class Initialized
INFO - 2022-05-28 10:49:26 --> Config Class Initialized
INFO - 2022-05-28 10:49:26 --> Loader Class Initialized
INFO - 2022-05-28 10:49:26 --> Helper loaded: url_helper
INFO - 2022-05-28 10:49:26 --> Helper loaded: file_helper
INFO - 2022-05-28 10:49:26 --> Helper loaded: form_helper
INFO - 2022-05-28 10:49:26 --> Helper loaded: my_helper
INFO - 2022-05-28 10:49:27 --> Database Driver Class Initialized
DEBUG - 2022-05-28 10:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-05-28 10:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-05-28 10:49:27 --> Controller Class Initialized
ERROR - 2022-05-28 10:49:27 --> Severity: Notice --> Undefined index: ekstra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 40
ERROR - 2022-05-28 10:49:27 --> Severity: Notice --> Undefined index: nilai C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-05-28 10:49:27 --> Severity: Notice --> Undefined index: ekstra2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-05-28 10:49:27 --> Severity: Notice --> Undefined index: nilai2 C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 55
DEBUG - 2022-05-28 10:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-05-28 10:49:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-05-28 10:49:27 --> Final output sent to browser
DEBUG - 2022-05-28 10:49:27 --> Total execution time: 0.0779
