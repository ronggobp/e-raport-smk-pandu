<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-09 01:31:12 --> Config Class Initialized
INFO - 2021-12-09 01:31:12 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:31:12 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:31:12 --> Utf8 Class Initialized
INFO - 2021-12-09 01:31:12 --> URI Class Initialized
DEBUG - 2021-12-09 01:31:12 --> No URI present. Default controller set.
INFO - 2021-12-09 01:31:12 --> Router Class Initialized
INFO - 2021-12-09 01:31:12 --> Output Class Initialized
INFO - 2021-12-09 01:31:12 --> Security Class Initialized
DEBUG - 2021-12-09 01:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:31:12 --> Input Class Initialized
INFO - 2021-12-09 01:31:12 --> Language Class Initialized
INFO - 2021-12-09 01:31:12 --> Language Class Initialized
INFO - 2021-12-09 01:31:12 --> Config Class Initialized
INFO - 2021-12-09 01:31:12 --> Loader Class Initialized
INFO - 2021-12-09 01:31:12 --> Helper loaded: url_helper
INFO - 2021-12-09 01:31:12 --> Helper loaded: file_helper
INFO - 2021-12-09 01:31:12 --> Helper loaded: form_helper
INFO - 2021-12-09 01:31:12 --> Helper loaded: my_helper
INFO - 2021-12-09 01:31:12 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:31:12 --> Controller Class Initialized
INFO - 2021-12-09 01:31:12 --> Config Class Initialized
INFO - 2021-12-09 01:31:12 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:31:12 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:31:12 --> Utf8 Class Initialized
INFO - 2021-12-09 01:31:12 --> URI Class Initialized
INFO - 2021-12-09 01:31:12 --> Router Class Initialized
INFO - 2021-12-09 01:31:12 --> Output Class Initialized
INFO - 2021-12-09 01:31:12 --> Security Class Initialized
DEBUG - 2021-12-09 01:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:31:12 --> Input Class Initialized
INFO - 2021-12-09 01:31:12 --> Language Class Initialized
INFO - 2021-12-09 01:31:12 --> Language Class Initialized
INFO - 2021-12-09 01:31:12 --> Config Class Initialized
INFO - 2021-12-09 01:31:12 --> Loader Class Initialized
INFO - 2021-12-09 01:31:12 --> Helper loaded: url_helper
INFO - 2021-12-09 01:31:12 --> Helper loaded: file_helper
INFO - 2021-12-09 01:31:12 --> Helper loaded: form_helper
INFO - 2021-12-09 01:31:12 --> Helper loaded: my_helper
INFO - 2021-12-09 01:31:12 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:31:12 --> Controller Class Initialized
DEBUG - 2021-12-09 01:31:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-09 01:31:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:31:12 --> Final output sent to browser
DEBUG - 2021-12-09 01:31:12 --> Total execution time: 0.0380
INFO - 2021-12-09 01:34:53 --> Config Class Initialized
INFO - 2021-12-09 01:34:53 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:34:53 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:34:53 --> Utf8 Class Initialized
INFO - 2021-12-09 01:34:53 --> URI Class Initialized
INFO - 2021-12-09 01:34:53 --> Router Class Initialized
INFO - 2021-12-09 01:34:53 --> Output Class Initialized
INFO - 2021-12-09 01:34:53 --> Security Class Initialized
DEBUG - 2021-12-09 01:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:34:53 --> Input Class Initialized
INFO - 2021-12-09 01:34:53 --> Language Class Initialized
INFO - 2021-12-09 01:34:53 --> Language Class Initialized
INFO - 2021-12-09 01:34:53 --> Config Class Initialized
INFO - 2021-12-09 01:34:53 --> Loader Class Initialized
INFO - 2021-12-09 01:34:53 --> Helper loaded: url_helper
INFO - 2021-12-09 01:34:53 --> Helper loaded: file_helper
INFO - 2021-12-09 01:34:53 --> Helper loaded: form_helper
INFO - 2021-12-09 01:34:53 --> Helper loaded: my_helper
INFO - 2021-12-09 01:34:53 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:34:53 --> Controller Class Initialized
INFO - 2021-12-09 01:34:53 --> Helper loaded: cookie_helper
INFO - 2021-12-09 01:34:53 --> Final output sent to browser
DEBUG - 2021-12-09 01:34:53 --> Total execution time: 0.0520
INFO - 2021-12-09 01:34:54 --> Config Class Initialized
INFO - 2021-12-09 01:34:54 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:34:54 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:34:54 --> Utf8 Class Initialized
INFO - 2021-12-09 01:34:54 --> URI Class Initialized
INFO - 2021-12-09 01:34:54 --> Router Class Initialized
INFO - 2021-12-09 01:34:54 --> Output Class Initialized
INFO - 2021-12-09 01:34:54 --> Security Class Initialized
DEBUG - 2021-12-09 01:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:34:54 --> Input Class Initialized
INFO - 2021-12-09 01:34:54 --> Language Class Initialized
INFO - 2021-12-09 01:34:54 --> Language Class Initialized
INFO - 2021-12-09 01:34:54 --> Config Class Initialized
INFO - 2021-12-09 01:34:54 --> Loader Class Initialized
INFO - 2021-12-09 01:34:54 --> Helper loaded: url_helper
INFO - 2021-12-09 01:34:54 --> Helper loaded: file_helper
INFO - 2021-12-09 01:34:54 --> Helper loaded: form_helper
INFO - 2021-12-09 01:34:54 --> Helper loaded: my_helper
INFO - 2021-12-09 01:34:54 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:34:54 --> Controller Class Initialized
DEBUG - 2021-12-09 01:34:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-09 01:34:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:34:54 --> Final output sent to browser
DEBUG - 2021-12-09 01:34:54 --> Total execution time: 0.2510
INFO - 2021-12-09 01:34:57 --> Config Class Initialized
INFO - 2021-12-09 01:34:57 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:34:57 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:34:57 --> Utf8 Class Initialized
INFO - 2021-12-09 01:34:57 --> URI Class Initialized
INFO - 2021-12-09 01:34:57 --> Router Class Initialized
INFO - 2021-12-09 01:34:57 --> Output Class Initialized
INFO - 2021-12-09 01:34:57 --> Security Class Initialized
DEBUG - 2021-12-09 01:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:34:57 --> Input Class Initialized
INFO - 2021-12-09 01:34:57 --> Language Class Initialized
INFO - 2021-12-09 01:34:57 --> Language Class Initialized
INFO - 2021-12-09 01:34:57 --> Config Class Initialized
INFO - 2021-12-09 01:34:57 --> Loader Class Initialized
INFO - 2021-12-09 01:34:57 --> Helper loaded: url_helper
INFO - 2021-12-09 01:34:57 --> Helper loaded: file_helper
INFO - 2021-12-09 01:34:57 --> Helper loaded: form_helper
INFO - 2021-12-09 01:34:57 --> Helper loaded: my_helper
INFO - 2021-12-09 01:34:57 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:34:57 --> Controller Class Initialized
DEBUG - 2021-12-09 01:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-09 01:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:34:57 --> Final output sent to browser
DEBUG - 2021-12-09 01:34:57 --> Total execution time: 0.0610
INFO - 2021-12-09 01:34:57 --> Config Class Initialized
INFO - 2021-12-09 01:34:57 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:34:57 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:34:57 --> Utf8 Class Initialized
INFO - 2021-12-09 01:34:57 --> URI Class Initialized
INFO - 2021-12-09 01:34:57 --> Router Class Initialized
INFO - 2021-12-09 01:34:57 --> Output Class Initialized
INFO - 2021-12-09 01:34:57 --> Security Class Initialized
DEBUG - 2021-12-09 01:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:34:57 --> Input Class Initialized
INFO - 2021-12-09 01:34:57 --> Language Class Initialized
INFO - 2021-12-09 01:34:57 --> Language Class Initialized
INFO - 2021-12-09 01:34:57 --> Config Class Initialized
INFO - 2021-12-09 01:34:57 --> Loader Class Initialized
INFO - 2021-12-09 01:34:57 --> Helper loaded: url_helper
INFO - 2021-12-09 01:34:57 --> Helper loaded: file_helper
INFO - 2021-12-09 01:34:57 --> Helper loaded: form_helper
INFO - 2021-12-09 01:34:57 --> Helper loaded: my_helper
INFO - 2021-12-09 01:34:57 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:34:57 --> Controller Class Initialized
INFO - 2021-12-09 01:34:58 --> Config Class Initialized
INFO - 2021-12-09 01:34:58 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:34:58 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:34:58 --> Utf8 Class Initialized
INFO - 2021-12-09 01:34:58 --> URI Class Initialized
INFO - 2021-12-09 01:34:58 --> Router Class Initialized
INFO - 2021-12-09 01:34:58 --> Output Class Initialized
INFO - 2021-12-09 01:34:58 --> Security Class Initialized
DEBUG - 2021-12-09 01:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:34:58 --> Input Class Initialized
INFO - 2021-12-09 01:34:58 --> Language Class Initialized
INFO - 2021-12-09 01:34:58 --> Language Class Initialized
INFO - 2021-12-09 01:34:58 --> Config Class Initialized
INFO - 2021-12-09 01:34:58 --> Loader Class Initialized
INFO - 2021-12-09 01:34:58 --> Helper loaded: url_helper
INFO - 2021-12-09 01:34:58 --> Helper loaded: file_helper
INFO - 2021-12-09 01:34:58 --> Helper loaded: form_helper
INFO - 2021-12-09 01:34:58 --> Helper loaded: my_helper
INFO - 2021-12-09 01:34:58 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:34:58 --> Controller Class Initialized
INFO - 2021-12-09 01:34:58 --> Final output sent to browser
DEBUG - 2021-12-09 01:34:58 --> Total execution time: 0.0600
INFO - 2021-12-09 01:34:58 --> Config Class Initialized
INFO - 2021-12-09 01:34:58 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:34:58 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:34:58 --> Utf8 Class Initialized
INFO - 2021-12-09 01:34:58 --> URI Class Initialized
INFO - 2021-12-09 01:34:58 --> Router Class Initialized
INFO - 2021-12-09 01:34:58 --> Output Class Initialized
INFO - 2021-12-09 01:34:58 --> Security Class Initialized
DEBUG - 2021-12-09 01:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:34:58 --> Input Class Initialized
INFO - 2021-12-09 01:34:58 --> Language Class Initialized
INFO - 2021-12-09 01:34:58 --> Language Class Initialized
INFO - 2021-12-09 01:34:58 --> Config Class Initialized
INFO - 2021-12-09 01:34:58 --> Loader Class Initialized
INFO - 2021-12-09 01:34:58 --> Helper loaded: url_helper
INFO - 2021-12-09 01:34:58 --> Helper loaded: file_helper
INFO - 2021-12-09 01:34:58 --> Helper loaded: form_helper
INFO - 2021-12-09 01:34:58 --> Helper loaded: my_helper
INFO - 2021-12-09 01:34:58 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:34:58 --> Controller Class Initialized
INFO - 2021-12-09 01:35:01 --> Config Class Initialized
INFO - 2021-12-09 01:35:01 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:35:01 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:35:01 --> Utf8 Class Initialized
INFO - 2021-12-09 01:35:01 --> URI Class Initialized
INFO - 2021-12-09 01:35:01 --> Router Class Initialized
INFO - 2021-12-09 01:35:01 --> Output Class Initialized
INFO - 2021-12-09 01:35:01 --> Security Class Initialized
DEBUG - 2021-12-09 01:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:35:01 --> Input Class Initialized
INFO - 2021-12-09 01:35:01 --> Language Class Initialized
INFO - 2021-12-09 01:35:01 --> Language Class Initialized
INFO - 2021-12-09 01:35:01 --> Config Class Initialized
INFO - 2021-12-09 01:35:01 --> Loader Class Initialized
INFO - 2021-12-09 01:35:01 --> Helper loaded: url_helper
INFO - 2021-12-09 01:35:01 --> Helper loaded: file_helper
INFO - 2021-12-09 01:35:01 --> Helper loaded: form_helper
INFO - 2021-12-09 01:35:01 --> Helper loaded: my_helper
INFO - 2021-12-09 01:35:01 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:35:01 --> Controller Class Initialized
INFO - 2021-12-09 01:35:01 --> Helper loaded: cookie_helper
INFO - 2021-12-09 01:35:01 --> Config Class Initialized
INFO - 2021-12-09 01:35:01 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:35:01 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:35:01 --> Utf8 Class Initialized
INFO - 2021-12-09 01:35:01 --> URI Class Initialized
INFO - 2021-12-09 01:35:01 --> Router Class Initialized
INFO - 2021-12-09 01:35:01 --> Output Class Initialized
INFO - 2021-12-09 01:35:01 --> Security Class Initialized
DEBUG - 2021-12-09 01:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:35:01 --> Input Class Initialized
INFO - 2021-12-09 01:35:01 --> Language Class Initialized
INFO - 2021-12-09 01:35:01 --> Language Class Initialized
INFO - 2021-12-09 01:35:01 --> Config Class Initialized
INFO - 2021-12-09 01:35:01 --> Loader Class Initialized
INFO - 2021-12-09 01:35:01 --> Helper loaded: url_helper
INFO - 2021-12-09 01:35:01 --> Helper loaded: file_helper
INFO - 2021-12-09 01:35:01 --> Helper loaded: form_helper
INFO - 2021-12-09 01:35:01 --> Helper loaded: my_helper
INFO - 2021-12-09 01:35:01 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:35:01 --> Controller Class Initialized
DEBUG - 2021-12-09 01:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-09 01:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:35:01 --> Final output sent to browser
DEBUG - 2021-12-09 01:35:01 --> Total execution time: 0.0360
INFO - 2021-12-09 01:35:06 --> Config Class Initialized
INFO - 2021-12-09 01:35:06 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:35:06 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:35:06 --> Utf8 Class Initialized
INFO - 2021-12-09 01:35:06 --> URI Class Initialized
INFO - 2021-12-09 01:35:06 --> Router Class Initialized
INFO - 2021-12-09 01:35:06 --> Output Class Initialized
INFO - 2021-12-09 01:35:06 --> Security Class Initialized
DEBUG - 2021-12-09 01:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:35:06 --> Input Class Initialized
INFO - 2021-12-09 01:35:06 --> Language Class Initialized
INFO - 2021-12-09 01:35:06 --> Language Class Initialized
INFO - 2021-12-09 01:35:06 --> Config Class Initialized
INFO - 2021-12-09 01:35:06 --> Loader Class Initialized
INFO - 2021-12-09 01:35:06 --> Helper loaded: url_helper
INFO - 2021-12-09 01:35:06 --> Helper loaded: file_helper
INFO - 2021-12-09 01:35:06 --> Helper loaded: form_helper
INFO - 2021-12-09 01:35:06 --> Helper loaded: my_helper
INFO - 2021-12-09 01:35:06 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:35:06 --> Controller Class Initialized
INFO - 2021-12-09 01:35:06 --> Helper loaded: cookie_helper
INFO - 2021-12-09 01:35:06 --> Final output sent to browser
DEBUG - 2021-12-09 01:35:06 --> Total execution time: 0.0700
INFO - 2021-12-09 01:35:06 --> Config Class Initialized
INFO - 2021-12-09 01:35:06 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:35:06 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:35:06 --> Utf8 Class Initialized
INFO - 2021-12-09 01:35:06 --> URI Class Initialized
INFO - 2021-12-09 01:35:06 --> Router Class Initialized
INFO - 2021-12-09 01:35:06 --> Output Class Initialized
INFO - 2021-12-09 01:35:06 --> Security Class Initialized
DEBUG - 2021-12-09 01:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:35:06 --> Input Class Initialized
INFO - 2021-12-09 01:35:06 --> Language Class Initialized
INFO - 2021-12-09 01:35:06 --> Language Class Initialized
INFO - 2021-12-09 01:35:06 --> Config Class Initialized
INFO - 2021-12-09 01:35:06 --> Loader Class Initialized
INFO - 2021-12-09 01:35:06 --> Helper loaded: url_helper
INFO - 2021-12-09 01:35:06 --> Helper loaded: file_helper
INFO - 2021-12-09 01:35:06 --> Helper loaded: form_helper
INFO - 2021-12-09 01:35:06 --> Helper loaded: my_helper
INFO - 2021-12-09 01:35:06 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:35:06 --> Controller Class Initialized
DEBUG - 2021-12-09 01:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-09 01:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:35:06 --> Final output sent to browser
DEBUG - 2021-12-09 01:35:06 --> Total execution time: 0.1640
INFO - 2021-12-09 01:35:08 --> Config Class Initialized
INFO - 2021-12-09 01:35:08 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:35:08 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:35:08 --> Utf8 Class Initialized
INFO - 2021-12-09 01:35:08 --> URI Class Initialized
INFO - 2021-12-09 01:35:08 --> Router Class Initialized
INFO - 2021-12-09 01:35:08 --> Output Class Initialized
INFO - 2021-12-09 01:35:08 --> Security Class Initialized
DEBUG - 2021-12-09 01:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:35:08 --> Input Class Initialized
INFO - 2021-12-09 01:35:08 --> Language Class Initialized
INFO - 2021-12-09 01:35:08 --> Language Class Initialized
INFO - 2021-12-09 01:35:08 --> Config Class Initialized
INFO - 2021-12-09 01:35:08 --> Loader Class Initialized
INFO - 2021-12-09 01:35:08 --> Helper loaded: url_helper
INFO - 2021-12-09 01:35:08 --> Helper loaded: file_helper
INFO - 2021-12-09 01:35:08 --> Helper loaded: form_helper
INFO - 2021-12-09 01:35:08 --> Helper loaded: my_helper
INFO - 2021-12-09 01:35:08 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:35:08 --> Controller Class Initialized
DEBUG - 2021-12-09 01:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-09 01:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:35:08 --> Final output sent to browser
DEBUG - 2021-12-09 01:35:08 --> Total execution time: 0.0810
INFO - 2021-12-09 01:35:10 --> Config Class Initialized
INFO - 2021-12-09 01:35:10 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:35:10 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:35:10 --> Utf8 Class Initialized
INFO - 2021-12-09 01:35:10 --> URI Class Initialized
INFO - 2021-12-09 01:35:10 --> Router Class Initialized
INFO - 2021-12-09 01:35:10 --> Output Class Initialized
INFO - 2021-12-09 01:35:10 --> Security Class Initialized
DEBUG - 2021-12-09 01:35:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:35:10 --> Input Class Initialized
INFO - 2021-12-09 01:35:10 --> Language Class Initialized
INFO - 2021-12-09 01:35:10 --> Language Class Initialized
INFO - 2021-12-09 01:35:10 --> Config Class Initialized
INFO - 2021-12-09 01:35:10 --> Loader Class Initialized
INFO - 2021-12-09 01:35:10 --> Helper loaded: url_helper
INFO - 2021-12-09 01:35:10 --> Helper loaded: file_helper
INFO - 2021-12-09 01:35:10 --> Helper loaded: form_helper
INFO - 2021-12-09 01:35:10 --> Helper loaded: my_helper
INFO - 2021-12-09 01:35:10 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:35:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:35:10 --> Controller Class Initialized
DEBUG - 2021-12-09 01:35:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:35:10 --> Final output sent to browser
DEBUG - 2021-12-09 01:35:10 --> Total execution time: 0.1210
INFO - 2021-12-09 01:46:07 --> Config Class Initialized
INFO - 2021-12-09 01:46:07 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:46:07 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:46:07 --> Utf8 Class Initialized
INFO - 2021-12-09 01:46:07 --> URI Class Initialized
INFO - 2021-12-09 01:46:07 --> Router Class Initialized
INFO - 2021-12-09 01:46:07 --> Output Class Initialized
INFO - 2021-12-09 01:46:07 --> Security Class Initialized
DEBUG - 2021-12-09 01:46:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:46:07 --> Input Class Initialized
INFO - 2021-12-09 01:46:07 --> Language Class Initialized
INFO - 2021-12-09 01:46:07 --> Language Class Initialized
INFO - 2021-12-09 01:46:07 --> Config Class Initialized
INFO - 2021-12-09 01:46:07 --> Loader Class Initialized
INFO - 2021-12-09 01:46:07 --> Helper loaded: url_helper
INFO - 2021-12-09 01:46:07 --> Helper loaded: file_helper
INFO - 2021-12-09 01:46:07 --> Helper loaded: form_helper
INFO - 2021-12-09 01:46:07 --> Helper loaded: my_helper
INFO - 2021-12-09 01:46:07 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:46:07 --> Controller Class Initialized
DEBUG - 2021-12-09 01:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:46:07 --> Final output sent to browser
DEBUG - 2021-12-09 01:46:07 --> Total execution time: 0.0600
INFO - 2021-12-09 01:46:10 --> Config Class Initialized
INFO - 2021-12-09 01:46:10 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:46:10 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:46:10 --> Utf8 Class Initialized
INFO - 2021-12-09 01:46:10 --> URI Class Initialized
INFO - 2021-12-09 01:46:10 --> Router Class Initialized
INFO - 2021-12-09 01:46:10 --> Output Class Initialized
INFO - 2021-12-09 01:46:10 --> Security Class Initialized
DEBUG - 2021-12-09 01:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:46:10 --> Input Class Initialized
INFO - 2021-12-09 01:46:10 --> Language Class Initialized
INFO - 2021-12-09 01:46:10 --> Language Class Initialized
INFO - 2021-12-09 01:46:10 --> Config Class Initialized
INFO - 2021-12-09 01:46:10 --> Loader Class Initialized
INFO - 2021-12-09 01:46:10 --> Helper loaded: url_helper
INFO - 2021-12-09 01:46:10 --> Helper loaded: file_helper
INFO - 2021-12-09 01:46:10 --> Helper loaded: form_helper
INFO - 2021-12-09 01:46:10 --> Helper loaded: my_helper
INFO - 2021-12-09 01:46:10 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:46:10 --> Controller Class Initialized
DEBUG - 2021-12-09 01:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:46:10 --> Final output sent to browser
DEBUG - 2021-12-09 01:46:10 --> Total execution time: 0.0610
INFO - 2021-12-09 01:47:24 --> Config Class Initialized
INFO - 2021-12-09 01:47:24 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:24 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:24 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:24 --> URI Class Initialized
INFO - 2021-12-09 01:47:24 --> Router Class Initialized
INFO - 2021-12-09 01:47:24 --> Output Class Initialized
INFO - 2021-12-09 01:47:24 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:24 --> Input Class Initialized
INFO - 2021-12-09 01:47:24 --> Language Class Initialized
INFO - 2021-12-09 01:47:24 --> Language Class Initialized
INFO - 2021-12-09 01:47:24 --> Config Class Initialized
INFO - 2021-12-09 01:47:24 --> Loader Class Initialized
INFO - 2021-12-09 01:47:24 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:24 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:24 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:24 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:24 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:24 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:47:24 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:24 --> Total execution time: 0.0680
INFO - 2021-12-09 01:47:28 --> Config Class Initialized
INFO - 2021-12-09 01:47:28 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:28 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:28 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:28 --> URI Class Initialized
INFO - 2021-12-09 01:47:28 --> Router Class Initialized
INFO - 2021-12-09 01:47:28 --> Output Class Initialized
INFO - 2021-12-09 01:47:28 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:28 --> Input Class Initialized
INFO - 2021-12-09 01:47:28 --> Language Class Initialized
INFO - 2021-12-09 01:47:28 --> Language Class Initialized
INFO - 2021-12-09 01:47:28 --> Config Class Initialized
INFO - 2021-12-09 01:47:28 --> Loader Class Initialized
INFO - 2021-12-09 01:47:28 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:28 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:28 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:28 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:28 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:28 --> Controller Class Initialized
INFO - 2021-12-09 01:47:28 --> Helper loaded: cookie_helper
INFO - 2021-12-09 01:47:29 --> Config Class Initialized
INFO - 2021-12-09 01:47:29 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:29 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:29 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:29 --> URI Class Initialized
INFO - 2021-12-09 01:47:29 --> Router Class Initialized
INFO - 2021-12-09 01:47:29 --> Output Class Initialized
INFO - 2021-12-09 01:47:29 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:29 --> Input Class Initialized
INFO - 2021-12-09 01:47:29 --> Language Class Initialized
INFO - 2021-12-09 01:47:29 --> Language Class Initialized
INFO - 2021-12-09 01:47:29 --> Config Class Initialized
INFO - 2021-12-09 01:47:29 --> Loader Class Initialized
INFO - 2021-12-09 01:47:29 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:29 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:29 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:29 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:29 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:29 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-09 01:47:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:47:29 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:29 --> Total execution time: 0.0350
INFO - 2021-12-09 01:47:34 --> Config Class Initialized
INFO - 2021-12-09 01:47:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:34 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:34 --> URI Class Initialized
INFO - 2021-12-09 01:47:34 --> Router Class Initialized
INFO - 2021-12-09 01:47:34 --> Output Class Initialized
INFO - 2021-12-09 01:47:34 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:34 --> Input Class Initialized
INFO - 2021-12-09 01:47:34 --> Language Class Initialized
INFO - 2021-12-09 01:47:34 --> Language Class Initialized
INFO - 2021-12-09 01:47:34 --> Config Class Initialized
INFO - 2021-12-09 01:47:34 --> Loader Class Initialized
INFO - 2021-12-09 01:47:34 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:34 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:34 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:34 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:34 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:34 --> Controller Class Initialized
INFO - 2021-12-09 01:47:34 --> Helper loaded: cookie_helper
INFO - 2021-12-09 01:47:34 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:34 --> Total execution time: 0.0480
INFO - 2021-12-09 01:47:34 --> Config Class Initialized
INFO - 2021-12-09 01:47:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:34 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:34 --> URI Class Initialized
INFO - 2021-12-09 01:47:34 --> Router Class Initialized
INFO - 2021-12-09 01:47:34 --> Output Class Initialized
INFO - 2021-12-09 01:47:34 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:34 --> Input Class Initialized
INFO - 2021-12-09 01:47:34 --> Language Class Initialized
INFO - 2021-12-09 01:47:34 --> Language Class Initialized
INFO - 2021-12-09 01:47:34 --> Config Class Initialized
INFO - 2021-12-09 01:47:34 --> Loader Class Initialized
INFO - 2021-12-09 01:47:34 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:34 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:34 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:34 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:34 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:34 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-09 01:47:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:47:34 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:34 --> Total execution time: 0.2480
INFO - 2021-12-09 01:47:35 --> Config Class Initialized
INFO - 2021-12-09 01:47:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:35 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:35 --> URI Class Initialized
INFO - 2021-12-09 01:47:35 --> Router Class Initialized
INFO - 2021-12-09 01:47:35 --> Output Class Initialized
INFO - 2021-12-09 01:47:35 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:35 --> Input Class Initialized
INFO - 2021-12-09 01:47:35 --> Language Class Initialized
INFO - 2021-12-09 01:47:35 --> Language Class Initialized
INFO - 2021-12-09 01:47:35 --> Config Class Initialized
INFO - 2021-12-09 01:47:35 --> Loader Class Initialized
INFO - 2021-12-09 01:47:35 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:35 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:35 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:35 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:35 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:35 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-09 01:47:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:47:35 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:35 --> Total execution time: 0.0480
INFO - 2021-12-09 01:47:35 --> Config Class Initialized
INFO - 2021-12-09 01:47:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:35 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:35 --> URI Class Initialized
INFO - 2021-12-09 01:47:35 --> Router Class Initialized
INFO - 2021-12-09 01:47:35 --> Output Class Initialized
INFO - 2021-12-09 01:47:35 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:35 --> Input Class Initialized
INFO - 2021-12-09 01:47:35 --> Language Class Initialized
INFO - 2021-12-09 01:47:35 --> Language Class Initialized
INFO - 2021-12-09 01:47:35 --> Config Class Initialized
INFO - 2021-12-09 01:47:35 --> Loader Class Initialized
INFO - 2021-12-09 01:47:35 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:35 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:35 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:35 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:35 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:35 --> Controller Class Initialized
INFO - 2021-12-09 01:47:37 --> Config Class Initialized
INFO - 2021-12-09 01:47:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:37 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:37 --> URI Class Initialized
INFO - 2021-12-09 01:47:37 --> Router Class Initialized
INFO - 2021-12-09 01:47:37 --> Output Class Initialized
INFO - 2021-12-09 01:47:37 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:37 --> Input Class Initialized
INFO - 2021-12-09 01:47:37 --> Language Class Initialized
INFO - 2021-12-09 01:47:37 --> Language Class Initialized
INFO - 2021-12-09 01:47:37 --> Config Class Initialized
INFO - 2021-12-09 01:47:37 --> Loader Class Initialized
INFO - 2021-12-09 01:47:37 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:37 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:37 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:37 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:37 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:37 --> Controller Class Initialized
INFO - 2021-12-09 01:47:37 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:37 --> Total execution time: 0.0530
INFO - 2021-12-09 01:47:37 --> Config Class Initialized
INFO - 2021-12-09 01:47:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:37 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:37 --> URI Class Initialized
INFO - 2021-12-09 01:47:37 --> Router Class Initialized
INFO - 2021-12-09 01:47:37 --> Output Class Initialized
INFO - 2021-12-09 01:47:37 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:37 --> Input Class Initialized
INFO - 2021-12-09 01:47:37 --> Language Class Initialized
INFO - 2021-12-09 01:47:37 --> Language Class Initialized
INFO - 2021-12-09 01:47:37 --> Config Class Initialized
INFO - 2021-12-09 01:47:37 --> Loader Class Initialized
INFO - 2021-12-09 01:47:37 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:37 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:37 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:37 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:37 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:37 --> Controller Class Initialized
INFO - 2021-12-09 01:47:39 --> Config Class Initialized
INFO - 2021-12-09 01:47:39 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:39 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:39 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:39 --> URI Class Initialized
INFO - 2021-12-09 01:47:39 --> Router Class Initialized
INFO - 2021-12-09 01:47:39 --> Output Class Initialized
INFO - 2021-12-09 01:47:39 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:39 --> Input Class Initialized
INFO - 2021-12-09 01:47:39 --> Language Class Initialized
INFO - 2021-12-09 01:47:39 --> Language Class Initialized
INFO - 2021-12-09 01:47:39 --> Config Class Initialized
INFO - 2021-12-09 01:47:39 --> Loader Class Initialized
INFO - 2021-12-09 01:47:39 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:39 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:39 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:39 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:39 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:39 --> Controller Class Initialized
INFO - 2021-12-09 01:47:39 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:39 --> Total execution time: 0.0520
INFO - 2021-12-09 01:47:39 --> Config Class Initialized
INFO - 2021-12-09 01:47:39 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:39 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:39 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:39 --> URI Class Initialized
INFO - 2021-12-09 01:47:39 --> Router Class Initialized
INFO - 2021-12-09 01:47:39 --> Output Class Initialized
INFO - 2021-12-09 01:47:39 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:39 --> Input Class Initialized
INFO - 2021-12-09 01:47:39 --> Language Class Initialized
INFO - 2021-12-09 01:47:39 --> Language Class Initialized
INFO - 2021-12-09 01:47:39 --> Config Class Initialized
INFO - 2021-12-09 01:47:39 --> Loader Class Initialized
INFO - 2021-12-09 01:47:39 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:39 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:39 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:39 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:39 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:39 --> Controller Class Initialized
INFO - 2021-12-09 01:47:43 --> Config Class Initialized
INFO - 2021-12-09 01:47:43 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:43 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:43 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:43 --> URI Class Initialized
INFO - 2021-12-09 01:47:43 --> Router Class Initialized
INFO - 2021-12-09 01:47:43 --> Output Class Initialized
INFO - 2021-12-09 01:47:43 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:43 --> Input Class Initialized
INFO - 2021-12-09 01:47:43 --> Language Class Initialized
INFO - 2021-12-09 01:47:43 --> Language Class Initialized
INFO - 2021-12-09 01:47:43 --> Config Class Initialized
INFO - 2021-12-09 01:47:43 --> Loader Class Initialized
INFO - 2021-12-09 01:47:43 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:43 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:43 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:43 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:43 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:43 --> Controller Class Initialized
INFO - 2021-12-09 01:47:43 --> Helper loaded: cookie_helper
INFO - 2021-12-09 01:47:43 --> Config Class Initialized
INFO - 2021-12-09 01:47:43 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:43 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:43 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:43 --> URI Class Initialized
INFO - 2021-12-09 01:47:43 --> Router Class Initialized
INFO - 2021-12-09 01:47:43 --> Output Class Initialized
INFO - 2021-12-09 01:47:43 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:43 --> Input Class Initialized
INFO - 2021-12-09 01:47:43 --> Language Class Initialized
INFO - 2021-12-09 01:47:43 --> Language Class Initialized
INFO - 2021-12-09 01:47:43 --> Config Class Initialized
INFO - 2021-12-09 01:47:43 --> Loader Class Initialized
INFO - 2021-12-09 01:47:43 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:43 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:43 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:43 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:43 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:43 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-09 01:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:47:43 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:43 --> Total execution time: 0.0390
INFO - 2021-12-09 01:47:47 --> Config Class Initialized
INFO - 2021-12-09 01:47:47 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:47 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:47 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:47 --> URI Class Initialized
INFO - 2021-12-09 01:47:47 --> Router Class Initialized
INFO - 2021-12-09 01:47:47 --> Output Class Initialized
INFO - 2021-12-09 01:47:47 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:47 --> Input Class Initialized
INFO - 2021-12-09 01:47:47 --> Language Class Initialized
INFO - 2021-12-09 01:47:47 --> Language Class Initialized
INFO - 2021-12-09 01:47:47 --> Config Class Initialized
INFO - 2021-12-09 01:47:47 --> Loader Class Initialized
INFO - 2021-12-09 01:47:47 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:47 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:47 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:47 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:47 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:47 --> Controller Class Initialized
INFO - 2021-12-09 01:47:47 --> Helper loaded: cookie_helper
INFO - 2021-12-09 01:47:47 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:47 --> Total execution time: 0.0550
INFO - 2021-12-09 01:47:47 --> Config Class Initialized
INFO - 2021-12-09 01:47:47 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:47 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:47 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:47 --> URI Class Initialized
INFO - 2021-12-09 01:47:47 --> Router Class Initialized
INFO - 2021-12-09 01:47:47 --> Output Class Initialized
INFO - 2021-12-09 01:47:47 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:47 --> Input Class Initialized
INFO - 2021-12-09 01:47:47 --> Language Class Initialized
INFO - 2021-12-09 01:47:47 --> Language Class Initialized
INFO - 2021-12-09 01:47:47 --> Config Class Initialized
INFO - 2021-12-09 01:47:47 --> Loader Class Initialized
INFO - 2021-12-09 01:47:47 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:47 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:47 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:47 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:47 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:47 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-09 01:47:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:47:48 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:48 --> Total execution time: 0.6470
INFO - 2021-12-09 01:47:54 --> Config Class Initialized
INFO - 2021-12-09 01:47:54 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:54 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:54 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:54 --> URI Class Initialized
INFO - 2021-12-09 01:47:54 --> Router Class Initialized
INFO - 2021-12-09 01:47:54 --> Output Class Initialized
INFO - 2021-12-09 01:47:54 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:54 --> Input Class Initialized
INFO - 2021-12-09 01:47:54 --> Language Class Initialized
INFO - 2021-12-09 01:47:54 --> Language Class Initialized
INFO - 2021-12-09 01:47:54 --> Config Class Initialized
INFO - 2021-12-09 01:47:54 --> Loader Class Initialized
INFO - 2021-12-09 01:47:54 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:54 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:54 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:54 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:54 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:54 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-09 01:47:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 01:47:54 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:54 --> Total execution time: 0.0710
INFO - 2021-12-09 01:47:56 --> Config Class Initialized
INFO - 2021-12-09 01:47:56 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:47:56 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:47:56 --> Utf8 Class Initialized
INFO - 2021-12-09 01:47:56 --> URI Class Initialized
INFO - 2021-12-09 01:47:56 --> Router Class Initialized
INFO - 2021-12-09 01:47:56 --> Output Class Initialized
INFO - 2021-12-09 01:47:56 --> Security Class Initialized
DEBUG - 2021-12-09 01:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:47:56 --> Input Class Initialized
INFO - 2021-12-09 01:47:56 --> Language Class Initialized
INFO - 2021-12-09 01:47:56 --> Language Class Initialized
INFO - 2021-12-09 01:47:56 --> Config Class Initialized
INFO - 2021-12-09 01:47:56 --> Loader Class Initialized
INFO - 2021-12-09 01:47:56 --> Helper loaded: url_helper
INFO - 2021-12-09 01:47:56 --> Helper loaded: file_helper
INFO - 2021-12-09 01:47:56 --> Helper loaded: form_helper
INFO - 2021-12-09 01:47:56 --> Helper loaded: my_helper
INFO - 2021-12-09 01:47:56 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:47:56 --> Controller Class Initialized
DEBUG - 2021-12-09 01:47:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:47:56 --> Final output sent to browser
DEBUG - 2021-12-09 01:47:56 --> Total execution time: 0.1960
INFO - 2021-12-09 01:57:05 --> Config Class Initialized
INFO - 2021-12-09 01:57:05 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:57:05 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:57:05 --> Utf8 Class Initialized
INFO - 2021-12-09 01:57:05 --> URI Class Initialized
INFO - 2021-12-09 01:57:05 --> Router Class Initialized
INFO - 2021-12-09 01:57:05 --> Output Class Initialized
INFO - 2021-12-09 01:57:05 --> Security Class Initialized
DEBUG - 2021-12-09 01:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:57:05 --> Input Class Initialized
INFO - 2021-12-09 01:57:05 --> Language Class Initialized
INFO - 2021-12-09 01:57:05 --> Language Class Initialized
INFO - 2021-12-09 01:57:05 --> Config Class Initialized
INFO - 2021-12-09 01:57:05 --> Loader Class Initialized
INFO - 2021-12-09 01:57:05 --> Helper loaded: url_helper
INFO - 2021-12-09 01:57:05 --> Helper loaded: file_helper
INFO - 2021-12-09 01:57:05 --> Helper loaded: form_helper
INFO - 2021-12-09 01:57:05 --> Helper loaded: my_helper
INFO - 2021-12-09 01:57:05 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:57:05 --> Controller Class Initialized
DEBUG - 2021-12-09 01:57:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:57:06 --> Final output sent to browser
DEBUG - 2021-12-09 01:57:06 --> Total execution time: 0.1650
INFO - 2021-12-09 01:58:25 --> Config Class Initialized
INFO - 2021-12-09 01:58:25 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:58:25 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:58:25 --> Utf8 Class Initialized
INFO - 2021-12-09 01:58:25 --> URI Class Initialized
INFO - 2021-12-09 01:58:25 --> Router Class Initialized
INFO - 2021-12-09 01:58:25 --> Output Class Initialized
INFO - 2021-12-09 01:58:25 --> Security Class Initialized
DEBUG - 2021-12-09 01:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:58:25 --> Input Class Initialized
INFO - 2021-12-09 01:58:25 --> Language Class Initialized
INFO - 2021-12-09 01:58:25 --> Language Class Initialized
INFO - 2021-12-09 01:58:25 --> Config Class Initialized
INFO - 2021-12-09 01:58:25 --> Loader Class Initialized
INFO - 2021-12-09 01:58:25 --> Helper loaded: url_helper
INFO - 2021-12-09 01:58:25 --> Helper loaded: file_helper
INFO - 2021-12-09 01:58:25 --> Helper loaded: form_helper
INFO - 2021-12-09 01:58:25 --> Helper loaded: my_helper
INFO - 2021-12-09 01:58:25 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:58:25 --> Controller Class Initialized
DEBUG - 2021-12-09 01:58:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:58:25 --> Final output sent to browser
DEBUG - 2021-12-09 01:58:25 --> Total execution time: 0.1330
INFO - 2021-12-09 01:58:34 --> Config Class Initialized
INFO - 2021-12-09 01:58:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:58:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:58:34 --> Utf8 Class Initialized
INFO - 2021-12-09 01:58:34 --> URI Class Initialized
INFO - 2021-12-09 01:58:34 --> Router Class Initialized
INFO - 2021-12-09 01:58:34 --> Output Class Initialized
INFO - 2021-12-09 01:58:34 --> Security Class Initialized
DEBUG - 2021-12-09 01:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:58:34 --> Input Class Initialized
INFO - 2021-12-09 01:58:34 --> Language Class Initialized
INFO - 2021-12-09 01:58:34 --> Language Class Initialized
INFO - 2021-12-09 01:58:34 --> Config Class Initialized
INFO - 2021-12-09 01:58:34 --> Loader Class Initialized
INFO - 2021-12-09 01:58:34 --> Helper loaded: url_helper
INFO - 2021-12-09 01:58:34 --> Helper loaded: file_helper
INFO - 2021-12-09 01:58:34 --> Helper loaded: form_helper
INFO - 2021-12-09 01:58:34 --> Helper loaded: my_helper
INFO - 2021-12-09 01:58:34 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:58:34 --> Controller Class Initialized
DEBUG - 2021-12-09 01:58:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:58:34 --> Final output sent to browser
DEBUG - 2021-12-09 01:58:34 --> Total execution time: 0.1220
INFO - 2021-12-09 01:58:46 --> Config Class Initialized
INFO - 2021-12-09 01:58:46 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:58:46 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:58:46 --> Utf8 Class Initialized
INFO - 2021-12-09 01:58:46 --> URI Class Initialized
INFO - 2021-12-09 01:58:46 --> Router Class Initialized
INFO - 2021-12-09 01:58:46 --> Output Class Initialized
INFO - 2021-12-09 01:58:46 --> Security Class Initialized
DEBUG - 2021-12-09 01:58:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:58:46 --> Input Class Initialized
INFO - 2021-12-09 01:58:46 --> Language Class Initialized
INFO - 2021-12-09 01:58:46 --> Language Class Initialized
INFO - 2021-12-09 01:58:46 --> Config Class Initialized
INFO - 2021-12-09 01:58:46 --> Loader Class Initialized
INFO - 2021-12-09 01:58:46 --> Helper loaded: url_helper
INFO - 2021-12-09 01:58:46 --> Helper loaded: file_helper
INFO - 2021-12-09 01:58:46 --> Helper loaded: form_helper
INFO - 2021-12-09 01:58:46 --> Helper loaded: my_helper
INFO - 2021-12-09 01:58:46 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:58:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:58:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:58:46 --> Controller Class Initialized
DEBUG - 2021-12-09 01:58:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:58:46 --> Final output sent to browser
DEBUG - 2021-12-09 01:58:46 --> Total execution time: 0.1410
INFO - 2021-12-09 01:58:52 --> Config Class Initialized
INFO - 2021-12-09 01:58:52 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:58:52 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:58:52 --> Utf8 Class Initialized
INFO - 2021-12-09 01:58:52 --> URI Class Initialized
INFO - 2021-12-09 01:58:52 --> Router Class Initialized
INFO - 2021-12-09 01:58:52 --> Output Class Initialized
INFO - 2021-12-09 01:58:52 --> Security Class Initialized
DEBUG - 2021-12-09 01:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:58:52 --> Input Class Initialized
INFO - 2021-12-09 01:58:52 --> Language Class Initialized
INFO - 2021-12-09 01:58:52 --> Language Class Initialized
INFO - 2021-12-09 01:58:52 --> Config Class Initialized
INFO - 2021-12-09 01:58:52 --> Loader Class Initialized
INFO - 2021-12-09 01:58:52 --> Helper loaded: url_helper
INFO - 2021-12-09 01:58:52 --> Helper loaded: file_helper
INFO - 2021-12-09 01:58:52 --> Helper loaded: form_helper
INFO - 2021-12-09 01:58:52 --> Helper loaded: my_helper
INFO - 2021-12-09 01:58:52 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:58:52 --> Controller Class Initialized
DEBUG - 2021-12-09 01:58:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:58:53 --> Final output sent to browser
DEBUG - 2021-12-09 01:58:53 --> Total execution time: 0.1570
INFO - 2021-12-09 01:59:07 --> Config Class Initialized
INFO - 2021-12-09 01:59:07 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:59:07 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:59:07 --> Utf8 Class Initialized
INFO - 2021-12-09 01:59:07 --> URI Class Initialized
INFO - 2021-12-09 01:59:07 --> Router Class Initialized
INFO - 2021-12-09 01:59:07 --> Output Class Initialized
INFO - 2021-12-09 01:59:07 --> Security Class Initialized
DEBUG - 2021-12-09 01:59:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:59:07 --> Input Class Initialized
INFO - 2021-12-09 01:59:07 --> Language Class Initialized
INFO - 2021-12-09 01:59:07 --> Language Class Initialized
INFO - 2021-12-09 01:59:07 --> Config Class Initialized
INFO - 2021-12-09 01:59:07 --> Loader Class Initialized
INFO - 2021-12-09 01:59:07 --> Helper loaded: url_helper
INFO - 2021-12-09 01:59:07 --> Helper loaded: file_helper
INFO - 2021-12-09 01:59:07 --> Helper loaded: form_helper
INFO - 2021-12-09 01:59:07 --> Helper loaded: my_helper
INFO - 2021-12-09 01:59:07 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:59:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:59:07 --> Controller Class Initialized
DEBUG - 2021-12-09 01:59:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:59:07 --> Final output sent to browser
DEBUG - 2021-12-09 01:59:07 --> Total execution time: 0.1320
INFO - 2021-12-09 01:59:19 --> Config Class Initialized
INFO - 2021-12-09 01:59:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:59:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:59:19 --> Utf8 Class Initialized
INFO - 2021-12-09 01:59:19 --> URI Class Initialized
INFO - 2021-12-09 01:59:19 --> Router Class Initialized
INFO - 2021-12-09 01:59:19 --> Output Class Initialized
INFO - 2021-12-09 01:59:19 --> Security Class Initialized
DEBUG - 2021-12-09 01:59:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:59:19 --> Input Class Initialized
INFO - 2021-12-09 01:59:19 --> Language Class Initialized
INFO - 2021-12-09 01:59:19 --> Language Class Initialized
INFO - 2021-12-09 01:59:19 --> Config Class Initialized
INFO - 2021-12-09 01:59:19 --> Loader Class Initialized
INFO - 2021-12-09 01:59:19 --> Helper loaded: url_helper
INFO - 2021-12-09 01:59:19 --> Helper loaded: file_helper
INFO - 2021-12-09 01:59:19 --> Helper loaded: form_helper
INFO - 2021-12-09 01:59:19 --> Helper loaded: my_helper
INFO - 2021-12-09 01:59:19 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:59:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:59:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:59:19 --> Controller Class Initialized
DEBUG - 2021-12-09 01:59:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:59:19 --> Final output sent to browser
DEBUG - 2021-12-09 01:59:19 --> Total execution time: 0.1160
INFO - 2021-12-09 01:59:33 --> Config Class Initialized
INFO - 2021-12-09 01:59:33 --> Hooks Class Initialized
DEBUG - 2021-12-09 01:59:33 --> UTF-8 Support Enabled
INFO - 2021-12-09 01:59:33 --> Utf8 Class Initialized
INFO - 2021-12-09 01:59:33 --> URI Class Initialized
INFO - 2021-12-09 01:59:33 --> Router Class Initialized
INFO - 2021-12-09 01:59:33 --> Output Class Initialized
INFO - 2021-12-09 01:59:33 --> Security Class Initialized
DEBUG - 2021-12-09 01:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 01:59:33 --> Input Class Initialized
INFO - 2021-12-09 01:59:33 --> Language Class Initialized
INFO - 2021-12-09 01:59:33 --> Language Class Initialized
INFO - 2021-12-09 01:59:33 --> Config Class Initialized
INFO - 2021-12-09 01:59:33 --> Loader Class Initialized
INFO - 2021-12-09 01:59:33 --> Helper loaded: url_helper
INFO - 2021-12-09 01:59:33 --> Helper loaded: file_helper
INFO - 2021-12-09 01:59:33 --> Helper loaded: form_helper
INFO - 2021-12-09 01:59:33 --> Helper loaded: my_helper
INFO - 2021-12-09 01:59:33 --> Database Driver Class Initialized
DEBUG - 2021-12-09 01:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 01:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 01:59:33 --> Controller Class Initialized
DEBUG - 2021-12-09 01:59:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 01:59:33 --> Final output sent to browser
DEBUG - 2021-12-09 01:59:33 --> Total execution time: 0.1530
INFO - 2021-12-09 02:06:27 --> Config Class Initialized
INFO - 2021-12-09 02:06:27 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:06:27 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:06:27 --> Utf8 Class Initialized
INFO - 2021-12-09 02:06:27 --> URI Class Initialized
INFO - 2021-12-09 02:06:27 --> Router Class Initialized
INFO - 2021-12-09 02:06:27 --> Output Class Initialized
INFO - 2021-12-09 02:06:27 --> Security Class Initialized
DEBUG - 2021-12-09 02:06:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:06:27 --> Input Class Initialized
INFO - 2021-12-09 02:06:27 --> Language Class Initialized
INFO - 2021-12-09 02:06:27 --> Language Class Initialized
INFO - 2021-12-09 02:06:27 --> Config Class Initialized
INFO - 2021-12-09 02:06:27 --> Loader Class Initialized
INFO - 2021-12-09 02:06:27 --> Helper loaded: url_helper
INFO - 2021-12-09 02:06:27 --> Helper loaded: file_helper
INFO - 2021-12-09 02:06:27 --> Helper loaded: form_helper
INFO - 2021-12-09 02:06:27 --> Helper loaded: my_helper
INFO - 2021-12-09 02:06:27 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:06:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:06:27 --> Controller Class Initialized
DEBUG - 2021-12-09 02:06:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:06:27 --> Final output sent to browser
DEBUG - 2021-12-09 02:06:27 --> Total execution time: 0.1180
INFO - 2021-12-09 02:07:15 --> Config Class Initialized
INFO - 2021-12-09 02:07:15 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:07:15 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:07:15 --> Utf8 Class Initialized
INFO - 2021-12-09 02:07:15 --> URI Class Initialized
INFO - 2021-12-09 02:07:15 --> Router Class Initialized
INFO - 2021-12-09 02:07:15 --> Output Class Initialized
INFO - 2021-12-09 02:07:15 --> Security Class Initialized
DEBUG - 2021-12-09 02:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:07:15 --> Input Class Initialized
INFO - 2021-12-09 02:07:15 --> Language Class Initialized
INFO - 2021-12-09 02:07:15 --> Language Class Initialized
INFO - 2021-12-09 02:07:15 --> Config Class Initialized
INFO - 2021-12-09 02:07:15 --> Loader Class Initialized
INFO - 2021-12-09 02:07:15 --> Helper loaded: url_helper
INFO - 2021-12-09 02:07:15 --> Helper loaded: file_helper
INFO - 2021-12-09 02:07:15 --> Helper loaded: form_helper
INFO - 2021-12-09 02:07:15 --> Helper loaded: my_helper
INFO - 2021-12-09 02:07:15 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:07:15 --> Controller Class Initialized
DEBUG - 2021-12-09 02:07:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:07:15 --> Final output sent to browser
DEBUG - 2021-12-09 02:07:15 --> Total execution time: 0.1700
INFO - 2021-12-09 02:07:34 --> Config Class Initialized
INFO - 2021-12-09 02:07:34 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:07:34 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:07:34 --> Utf8 Class Initialized
INFO - 2021-12-09 02:07:34 --> URI Class Initialized
INFO - 2021-12-09 02:07:34 --> Router Class Initialized
INFO - 2021-12-09 02:07:34 --> Output Class Initialized
INFO - 2021-12-09 02:07:34 --> Security Class Initialized
DEBUG - 2021-12-09 02:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:07:35 --> Input Class Initialized
INFO - 2021-12-09 02:07:35 --> Language Class Initialized
INFO - 2021-12-09 02:07:35 --> Language Class Initialized
INFO - 2021-12-09 02:07:35 --> Config Class Initialized
INFO - 2021-12-09 02:07:35 --> Loader Class Initialized
INFO - 2021-12-09 02:07:35 --> Helper loaded: url_helper
INFO - 2021-12-09 02:07:35 --> Helper loaded: file_helper
INFO - 2021-12-09 02:07:35 --> Helper loaded: form_helper
INFO - 2021-12-09 02:07:35 --> Helper loaded: my_helper
INFO - 2021-12-09 02:07:35 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:07:35 --> Controller Class Initialized
DEBUG - 2021-12-09 02:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:07:35 --> Final output sent to browser
DEBUG - 2021-12-09 02:07:35 --> Total execution time: 0.1440
INFO - 2021-12-09 02:07:57 --> Config Class Initialized
INFO - 2021-12-09 02:07:57 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:07:57 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:07:57 --> Utf8 Class Initialized
INFO - 2021-12-09 02:07:57 --> URI Class Initialized
INFO - 2021-12-09 02:07:57 --> Router Class Initialized
INFO - 2021-12-09 02:07:57 --> Output Class Initialized
INFO - 2021-12-09 02:07:57 --> Security Class Initialized
DEBUG - 2021-12-09 02:07:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:07:57 --> Input Class Initialized
INFO - 2021-12-09 02:07:57 --> Language Class Initialized
INFO - 2021-12-09 02:07:57 --> Language Class Initialized
INFO - 2021-12-09 02:07:57 --> Config Class Initialized
INFO - 2021-12-09 02:07:57 --> Loader Class Initialized
INFO - 2021-12-09 02:07:57 --> Helper loaded: url_helper
INFO - 2021-12-09 02:07:57 --> Helper loaded: file_helper
INFO - 2021-12-09 02:07:57 --> Helper loaded: form_helper
INFO - 2021-12-09 02:07:57 --> Helper loaded: my_helper
INFO - 2021-12-09 02:07:57 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:07:57 --> Controller Class Initialized
DEBUG - 2021-12-09 02:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:07:57 --> Final output sent to browser
DEBUG - 2021-12-09 02:07:57 --> Total execution time: 0.1250
INFO - 2021-12-09 02:18:18 --> Config Class Initialized
INFO - 2021-12-09 02:18:18 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:18:18 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:18:18 --> Utf8 Class Initialized
INFO - 2021-12-09 02:18:18 --> URI Class Initialized
INFO - 2021-12-09 02:18:18 --> Router Class Initialized
INFO - 2021-12-09 02:18:18 --> Output Class Initialized
INFO - 2021-12-09 02:18:18 --> Security Class Initialized
DEBUG - 2021-12-09 02:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:18:18 --> Input Class Initialized
INFO - 2021-12-09 02:18:18 --> Language Class Initialized
INFO - 2021-12-09 02:18:18 --> Language Class Initialized
INFO - 2021-12-09 02:18:18 --> Config Class Initialized
INFO - 2021-12-09 02:18:18 --> Loader Class Initialized
INFO - 2021-12-09 02:18:18 --> Helper loaded: url_helper
INFO - 2021-12-09 02:18:18 --> Helper loaded: file_helper
INFO - 2021-12-09 02:18:18 --> Helper loaded: form_helper
INFO - 2021-12-09 02:18:18 --> Helper loaded: my_helper
INFO - 2021-12-09 02:18:18 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:18:18 --> Controller Class Initialized
DEBUG - 2021-12-09 02:18:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:18:18 --> Final output sent to browser
DEBUG - 2021-12-09 02:18:18 --> Total execution time: 0.1400
INFO - 2021-12-09 02:18:27 --> Config Class Initialized
INFO - 2021-12-09 02:18:27 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:18:27 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:18:27 --> Utf8 Class Initialized
INFO - 2021-12-09 02:18:27 --> URI Class Initialized
INFO - 2021-12-09 02:18:27 --> Router Class Initialized
INFO - 2021-12-09 02:18:27 --> Output Class Initialized
INFO - 2021-12-09 02:18:27 --> Security Class Initialized
DEBUG - 2021-12-09 02:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:18:27 --> Input Class Initialized
INFO - 2021-12-09 02:18:27 --> Language Class Initialized
INFO - 2021-12-09 02:18:27 --> Language Class Initialized
INFO - 2021-12-09 02:18:27 --> Config Class Initialized
INFO - 2021-12-09 02:18:27 --> Loader Class Initialized
INFO - 2021-12-09 02:18:27 --> Helper loaded: url_helper
INFO - 2021-12-09 02:18:27 --> Helper loaded: file_helper
INFO - 2021-12-09 02:18:27 --> Helper loaded: form_helper
INFO - 2021-12-09 02:18:27 --> Helper loaded: my_helper
INFO - 2021-12-09 02:18:27 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:18:27 --> Controller Class Initialized
INFO - 2021-12-09 02:18:27 --> Helper loaded: cookie_helper
INFO - 2021-12-09 02:18:27 --> Config Class Initialized
INFO - 2021-12-09 02:18:27 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:18:27 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:18:27 --> Utf8 Class Initialized
INFO - 2021-12-09 02:18:27 --> URI Class Initialized
INFO - 2021-12-09 02:18:27 --> Router Class Initialized
INFO - 2021-12-09 02:18:27 --> Output Class Initialized
INFO - 2021-12-09 02:18:27 --> Security Class Initialized
DEBUG - 2021-12-09 02:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:18:27 --> Input Class Initialized
INFO - 2021-12-09 02:18:27 --> Language Class Initialized
INFO - 2021-12-09 02:18:27 --> Language Class Initialized
INFO - 2021-12-09 02:18:27 --> Config Class Initialized
INFO - 2021-12-09 02:18:27 --> Loader Class Initialized
INFO - 2021-12-09 02:18:27 --> Helper loaded: url_helper
INFO - 2021-12-09 02:18:27 --> Helper loaded: file_helper
INFO - 2021-12-09 02:18:27 --> Helper loaded: form_helper
INFO - 2021-12-09 02:18:27 --> Helper loaded: my_helper
INFO - 2021-12-09 02:18:27 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:18:27 --> Controller Class Initialized
DEBUG - 2021-12-09 02:18:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-09 02:18:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:18:27 --> Final output sent to browser
DEBUG - 2021-12-09 02:18:27 --> Total execution time: 0.0350
INFO - 2021-12-09 02:18:32 --> Config Class Initialized
INFO - 2021-12-09 02:18:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:18:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:18:32 --> Utf8 Class Initialized
INFO - 2021-12-09 02:18:32 --> URI Class Initialized
INFO - 2021-12-09 02:18:32 --> Router Class Initialized
INFO - 2021-12-09 02:18:32 --> Output Class Initialized
INFO - 2021-12-09 02:18:32 --> Security Class Initialized
DEBUG - 2021-12-09 02:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:18:32 --> Input Class Initialized
INFO - 2021-12-09 02:18:32 --> Language Class Initialized
INFO - 2021-12-09 02:18:32 --> Language Class Initialized
INFO - 2021-12-09 02:18:32 --> Config Class Initialized
INFO - 2021-12-09 02:18:32 --> Loader Class Initialized
INFO - 2021-12-09 02:18:32 --> Helper loaded: url_helper
INFO - 2021-12-09 02:18:32 --> Helper loaded: file_helper
INFO - 2021-12-09 02:18:32 --> Helper loaded: form_helper
INFO - 2021-12-09 02:18:32 --> Helper loaded: my_helper
INFO - 2021-12-09 02:18:32 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:18:32 --> Controller Class Initialized
INFO - 2021-12-09 02:18:32 --> Helper loaded: cookie_helper
INFO - 2021-12-09 02:18:32 --> Final output sent to browser
DEBUG - 2021-12-09 02:18:32 --> Total execution time: 0.0520
INFO - 2021-12-09 02:18:32 --> Config Class Initialized
INFO - 2021-12-09 02:18:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:18:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:18:32 --> Utf8 Class Initialized
INFO - 2021-12-09 02:18:32 --> URI Class Initialized
INFO - 2021-12-09 02:18:32 --> Router Class Initialized
INFO - 2021-12-09 02:18:32 --> Output Class Initialized
INFO - 2021-12-09 02:18:32 --> Security Class Initialized
DEBUG - 2021-12-09 02:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:18:32 --> Input Class Initialized
INFO - 2021-12-09 02:18:32 --> Language Class Initialized
INFO - 2021-12-09 02:18:32 --> Language Class Initialized
INFO - 2021-12-09 02:18:32 --> Config Class Initialized
INFO - 2021-12-09 02:18:32 --> Loader Class Initialized
INFO - 2021-12-09 02:18:32 --> Helper loaded: url_helper
INFO - 2021-12-09 02:18:32 --> Helper loaded: file_helper
INFO - 2021-12-09 02:18:32 --> Helper loaded: form_helper
INFO - 2021-12-09 02:18:32 --> Helper loaded: my_helper
INFO - 2021-12-09 02:18:32 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:18:32 --> Controller Class Initialized
DEBUG - 2021-12-09 02:18:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-09 02:18:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:18:33 --> Final output sent to browser
DEBUG - 2021-12-09 02:18:33 --> Total execution time: 0.7060
INFO - 2021-12-09 02:18:35 --> Config Class Initialized
INFO - 2021-12-09 02:18:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:18:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:18:35 --> Utf8 Class Initialized
INFO - 2021-12-09 02:18:35 --> URI Class Initialized
INFO - 2021-12-09 02:18:35 --> Router Class Initialized
INFO - 2021-12-09 02:18:35 --> Output Class Initialized
INFO - 2021-12-09 02:18:35 --> Security Class Initialized
DEBUG - 2021-12-09 02:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:18:35 --> Input Class Initialized
INFO - 2021-12-09 02:18:35 --> Language Class Initialized
INFO - 2021-12-09 02:18:35 --> Language Class Initialized
INFO - 2021-12-09 02:18:35 --> Config Class Initialized
INFO - 2021-12-09 02:18:35 --> Loader Class Initialized
INFO - 2021-12-09 02:18:35 --> Helper loaded: url_helper
INFO - 2021-12-09 02:18:35 --> Helper loaded: file_helper
INFO - 2021-12-09 02:18:35 --> Helper loaded: form_helper
INFO - 2021-12-09 02:18:35 --> Helper loaded: my_helper
INFO - 2021-12-09 02:18:35 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:18:35 --> Controller Class Initialized
DEBUG - 2021-12-09 02:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-09 02:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:18:35 --> Final output sent to browser
DEBUG - 2021-12-09 02:18:35 --> Total execution time: 0.0610
INFO - 2021-12-09 02:18:36 --> Config Class Initialized
INFO - 2021-12-09 02:18:36 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:18:36 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:18:36 --> Utf8 Class Initialized
INFO - 2021-12-09 02:18:36 --> URI Class Initialized
INFO - 2021-12-09 02:18:36 --> Router Class Initialized
INFO - 2021-12-09 02:18:36 --> Output Class Initialized
INFO - 2021-12-09 02:18:36 --> Security Class Initialized
DEBUG - 2021-12-09 02:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:18:36 --> Input Class Initialized
INFO - 2021-12-09 02:18:36 --> Language Class Initialized
INFO - 2021-12-09 02:18:36 --> Language Class Initialized
INFO - 2021-12-09 02:18:36 --> Config Class Initialized
INFO - 2021-12-09 02:18:36 --> Loader Class Initialized
INFO - 2021-12-09 02:18:36 --> Helper loaded: url_helper
INFO - 2021-12-09 02:18:36 --> Helper loaded: file_helper
INFO - 2021-12-09 02:18:36 --> Helper loaded: form_helper
INFO - 2021-12-09 02:18:36 --> Helper loaded: my_helper
INFO - 2021-12-09 02:18:36 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:18:36 --> Controller Class Initialized
DEBUG - 2021-12-09 02:18:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-12-09 02:18:37 --> Final output sent to browser
DEBUG - 2021-12-09 02:18:37 --> Total execution time: 0.1950
INFO - 2021-12-09 02:19:03 --> Config Class Initialized
INFO - 2021-12-09 02:19:03 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:03 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:03 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:03 --> URI Class Initialized
INFO - 2021-12-09 02:19:03 --> Router Class Initialized
INFO - 2021-12-09 02:19:03 --> Output Class Initialized
INFO - 2021-12-09 02:19:03 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:03 --> Input Class Initialized
INFO - 2021-12-09 02:19:03 --> Language Class Initialized
INFO - 2021-12-09 02:19:03 --> Language Class Initialized
INFO - 2021-12-09 02:19:03 --> Config Class Initialized
INFO - 2021-12-09 02:19:03 --> Loader Class Initialized
INFO - 2021-12-09 02:19:03 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:03 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:03 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:03 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:03 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:03 --> Controller Class Initialized
INFO - 2021-12-09 02:19:03 --> Helper loaded: cookie_helper
INFO - 2021-12-09 02:19:03 --> Config Class Initialized
INFO - 2021-12-09 02:19:03 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:03 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:03 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:03 --> URI Class Initialized
INFO - 2021-12-09 02:19:03 --> Router Class Initialized
INFO - 2021-12-09 02:19:03 --> Output Class Initialized
INFO - 2021-12-09 02:19:03 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:03 --> Input Class Initialized
INFO - 2021-12-09 02:19:03 --> Language Class Initialized
INFO - 2021-12-09 02:19:03 --> Language Class Initialized
INFO - 2021-12-09 02:19:03 --> Config Class Initialized
INFO - 2021-12-09 02:19:03 --> Loader Class Initialized
INFO - 2021-12-09 02:19:03 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:03 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:03 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:03 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:03 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:03 --> Controller Class Initialized
DEBUG - 2021-12-09 02:19:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-09 02:19:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:19:03 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:03 --> Total execution time: 0.0420
INFO - 2021-12-09 02:19:08 --> Config Class Initialized
INFO - 2021-12-09 02:19:08 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:08 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:08 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:08 --> URI Class Initialized
INFO - 2021-12-09 02:19:08 --> Router Class Initialized
INFO - 2021-12-09 02:19:08 --> Output Class Initialized
INFO - 2021-12-09 02:19:08 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:08 --> Input Class Initialized
INFO - 2021-12-09 02:19:08 --> Language Class Initialized
INFO - 2021-12-09 02:19:08 --> Language Class Initialized
INFO - 2021-12-09 02:19:08 --> Config Class Initialized
INFO - 2021-12-09 02:19:08 --> Loader Class Initialized
INFO - 2021-12-09 02:19:08 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:08 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:08 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:08 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:08 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:08 --> Controller Class Initialized
INFO - 2021-12-09 02:19:08 --> Helper loaded: cookie_helper
INFO - 2021-12-09 02:19:08 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:08 --> Total execution time: 0.0530
INFO - 2021-12-09 02:19:09 --> Config Class Initialized
INFO - 2021-12-09 02:19:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:09 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:09 --> URI Class Initialized
INFO - 2021-12-09 02:19:09 --> Router Class Initialized
INFO - 2021-12-09 02:19:09 --> Output Class Initialized
INFO - 2021-12-09 02:19:09 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:09 --> Input Class Initialized
INFO - 2021-12-09 02:19:09 --> Language Class Initialized
INFO - 2021-12-09 02:19:09 --> Language Class Initialized
INFO - 2021-12-09 02:19:09 --> Config Class Initialized
INFO - 2021-12-09 02:19:09 --> Loader Class Initialized
INFO - 2021-12-09 02:19:09 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:09 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:09 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:09 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:09 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:09 --> Controller Class Initialized
DEBUG - 2021-12-09 02:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-09 02:19:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:19:10 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:10 --> Total execution time: 0.7540
INFO - 2021-12-09 02:19:11 --> Config Class Initialized
INFO - 2021-12-09 02:19:11 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:11 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:11 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:11 --> URI Class Initialized
INFO - 2021-12-09 02:19:11 --> Router Class Initialized
INFO - 2021-12-09 02:19:11 --> Output Class Initialized
INFO - 2021-12-09 02:19:11 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:11 --> Input Class Initialized
INFO - 2021-12-09 02:19:11 --> Language Class Initialized
INFO - 2021-12-09 02:19:11 --> Language Class Initialized
INFO - 2021-12-09 02:19:11 --> Config Class Initialized
INFO - 2021-12-09 02:19:11 --> Loader Class Initialized
INFO - 2021-12-09 02:19:11 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:11 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:11 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:11 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:11 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:11 --> Controller Class Initialized
DEBUG - 2021-12-09 02:19:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-09 02:19:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:19:11 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:11 --> Total execution time: 0.0610
INFO - 2021-12-09 02:19:11 --> Config Class Initialized
INFO - 2021-12-09 02:19:11 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:11 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:11 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:11 --> URI Class Initialized
INFO - 2021-12-09 02:19:11 --> Router Class Initialized
INFO - 2021-12-09 02:19:11 --> Output Class Initialized
INFO - 2021-12-09 02:19:11 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:11 --> Input Class Initialized
INFO - 2021-12-09 02:19:11 --> Language Class Initialized
INFO - 2021-12-09 02:19:11 --> Language Class Initialized
INFO - 2021-12-09 02:19:11 --> Config Class Initialized
INFO - 2021-12-09 02:19:11 --> Loader Class Initialized
INFO - 2021-12-09 02:19:11 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:11 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:11 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:11 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:11 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:11 --> Controller Class Initialized
INFO - 2021-12-09 02:19:13 --> Config Class Initialized
INFO - 2021-12-09 02:19:13 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:13 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:13 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:13 --> URI Class Initialized
INFO - 2021-12-09 02:19:13 --> Router Class Initialized
INFO - 2021-12-09 02:19:13 --> Output Class Initialized
INFO - 2021-12-09 02:19:13 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:13 --> Input Class Initialized
INFO - 2021-12-09 02:19:13 --> Language Class Initialized
INFO - 2021-12-09 02:19:13 --> Language Class Initialized
INFO - 2021-12-09 02:19:13 --> Config Class Initialized
INFO - 2021-12-09 02:19:13 --> Loader Class Initialized
INFO - 2021-12-09 02:19:13 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:13 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:13 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:13 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:13 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:13 --> Controller Class Initialized
INFO - 2021-12-09 02:19:13 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:13 --> Total execution time: 0.0500
INFO - 2021-12-09 02:19:13 --> Config Class Initialized
INFO - 2021-12-09 02:19:13 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:13 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:13 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:13 --> URI Class Initialized
INFO - 2021-12-09 02:19:13 --> Router Class Initialized
INFO - 2021-12-09 02:19:13 --> Output Class Initialized
INFO - 2021-12-09 02:19:13 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:13 --> Input Class Initialized
INFO - 2021-12-09 02:19:13 --> Language Class Initialized
INFO - 2021-12-09 02:19:13 --> Language Class Initialized
INFO - 2021-12-09 02:19:13 --> Config Class Initialized
INFO - 2021-12-09 02:19:13 --> Loader Class Initialized
INFO - 2021-12-09 02:19:13 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:13 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:13 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:13 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:13 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:13 --> Controller Class Initialized
INFO - 2021-12-09 02:19:16 --> Config Class Initialized
INFO - 2021-12-09 02:19:16 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:16 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:16 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:16 --> URI Class Initialized
INFO - 2021-12-09 02:19:16 --> Router Class Initialized
INFO - 2021-12-09 02:19:16 --> Output Class Initialized
INFO - 2021-12-09 02:19:16 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:16 --> Input Class Initialized
INFO - 2021-12-09 02:19:16 --> Language Class Initialized
INFO - 2021-12-09 02:19:16 --> Language Class Initialized
INFO - 2021-12-09 02:19:16 --> Config Class Initialized
INFO - 2021-12-09 02:19:16 --> Loader Class Initialized
INFO - 2021-12-09 02:19:16 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:16 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:16 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:16 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:16 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:16 --> Controller Class Initialized
INFO - 2021-12-09 02:19:16 --> Helper loaded: cookie_helper
INFO - 2021-12-09 02:19:16 --> Config Class Initialized
INFO - 2021-12-09 02:19:16 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:16 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:16 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:16 --> URI Class Initialized
INFO - 2021-12-09 02:19:16 --> Router Class Initialized
INFO - 2021-12-09 02:19:16 --> Output Class Initialized
INFO - 2021-12-09 02:19:16 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:16 --> Input Class Initialized
INFO - 2021-12-09 02:19:16 --> Language Class Initialized
INFO - 2021-12-09 02:19:16 --> Language Class Initialized
INFO - 2021-12-09 02:19:16 --> Config Class Initialized
INFO - 2021-12-09 02:19:16 --> Loader Class Initialized
INFO - 2021-12-09 02:19:16 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:16 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:16 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:16 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:16 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:16 --> Controller Class Initialized
DEBUG - 2021-12-09 02:19:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-09 02:19:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:19:16 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:16 --> Total execution time: 0.0390
INFO - 2021-12-09 02:19:19 --> Config Class Initialized
INFO - 2021-12-09 02:19:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:19 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:19 --> URI Class Initialized
INFO - 2021-12-09 02:19:19 --> Router Class Initialized
INFO - 2021-12-09 02:19:19 --> Output Class Initialized
INFO - 2021-12-09 02:19:19 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:19 --> Input Class Initialized
INFO - 2021-12-09 02:19:19 --> Language Class Initialized
INFO - 2021-12-09 02:19:19 --> Language Class Initialized
INFO - 2021-12-09 02:19:19 --> Config Class Initialized
INFO - 2021-12-09 02:19:19 --> Loader Class Initialized
INFO - 2021-12-09 02:19:19 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:19 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:19 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:19 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:19 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:19 --> Controller Class Initialized
INFO - 2021-12-09 02:19:19 --> Helper loaded: cookie_helper
INFO - 2021-12-09 02:19:19 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:19 --> Total execution time: 0.0660
INFO - 2021-12-09 02:19:19 --> Config Class Initialized
INFO - 2021-12-09 02:19:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:19 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:19 --> URI Class Initialized
INFO - 2021-12-09 02:19:19 --> Router Class Initialized
INFO - 2021-12-09 02:19:19 --> Output Class Initialized
INFO - 2021-12-09 02:19:19 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:19 --> Input Class Initialized
INFO - 2021-12-09 02:19:19 --> Language Class Initialized
INFO - 2021-12-09 02:19:19 --> Language Class Initialized
INFO - 2021-12-09 02:19:19 --> Config Class Initialized
INFO - 2021-12-09 02:19:19 --> Loader Class Initialized
INFO - 2021-12-09 02:19:19 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:19 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:19 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:19 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:19 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:19 --> Controller Class Initialized
DEBUG - 2021-12-09 02:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-09 02:19:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:19:19 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:19 --> Total execution time: 0.1550
INFO - 2021-12-09 02:19:22 --> Config Class Initialized
INFO - 2021-12-09 02:19:22 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:22 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:22 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:22 --> URI Class Initialized
INFO - 2021-12-09 02:19:22 --> Router Class Initialized
INFO - 2021-12-09 02:19:22 --> Output Class Initialized
INFO - 2021-12-09 02:19:22 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:22 --> Input Class Initialized
INFO - 2021-12-09 02:19:22 --> Language Class Initialized
INFO - 2021-12-09 02:19:22 --> Language Class Initialized
INFO - 2021-12-09 02:19:22 --> Config Class Initialized
INFO - 2021-12-09 02:19:22 --> Loader Class Initialized
INFO - 2021-12-09 02:19:22 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:22 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:22 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:22 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:22 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:22 --> Controller Class Initialized
DEBUG - 2021-12-09 02:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-09 02:19:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-09 02:19:22 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:22 --> Total execution time: 0.0740
INFO - 2021-12-09 02:19:24 --> Config Class Initialized
INFO - 2021-12-09 02:19:24 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:19:24 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:19:24 --> Utf8 Class Initialized
INFO - 2021-12-09 02:19:24 --> URI Class Initialized
INFO - 2021-12-09 02:19:24 --> Router Class Initialized
INFO - 2021-12-09 02:19:24 --> Output Class Initialized
INFO - 2021-12-09 02:19:24 --> Security Class Initialized
DEBUG - 2021-12-09 02:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:19:24 --> Input Class Initialized
INFO - 2021-12-09 02:19:24 --> Language Class Initialized
INFO - 2021-12-09 02:19:24 --> Language Class Initialized
INFO - 2021-12-09 02:19:24 --> Config Class Initialized
INFO - 2021-12-09 02:19:24 --> Loader Class Initialized
INFO - 2021-12-09 02:19:24 --> Helper loaded: url_helper
INFO - 2021-12-09 02:19:24 --> Helper loaded: file_helper
INFO - 2021-12-09 02:19:24 --> Helper loaded: form_helper
INFO - 2021-12-09 02:19:24 --> Helper loaded: my_helper
INFO - 2021-12-09 02:19:24 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:19:24 --> Controller Class Initialized
DEBUG - 2021-12-09 02:19:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:19:24 --> Final output sent to browser
DEBUG - 2021-12-09 02:19:24 --> Total execution time: 0.0960
INFO - 2021-12-09 02:21:57 --> Config Class Initialized
INFO - 2021-12-09 02:21:57 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:21:57 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:21:57 --> Utf8 Class Initialized
INFO - 2021-12-09 02:21:57 --> URI Class Initialized
INFO - 2021-12-09 02:21:57 --> Router Class Initialized
INFO - 2021-12-09 02:21:57 --> Output Class Initialized
INFO - 2021-12-09 02:21:57 --> Security Class Initialized
DEBUG - 2021-12-09 02:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:21:57 --> Input Class Initialized
INFO - 2021-12-09 02:21:57 --> Language Class Initialized
INFO - 2021-12-09 02:21:58 --> Language Class Initialized
INFO - 2021-12-09 02:21:58 --> Config Class Initialized
INFO - 2021-12-09 02:21:58 --> Loader Class Initialized
INFO - 2021-12-09 02:21:58 --> Helper loaded: url_helper
INFO - 2021-12-09 02:21:58 --> Helper loaded: file_helper
INFO - 2021-12-09 02:21:58 --> Helper loaded: form_helper
INFO - 2021-12-09 02:21:58 --> Helper loaded: my_helper
INFO - 2021-12-09 02:21:58 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:21:58 --> Controller Class Initialized
DEBUG - 2021-12-09 02:21:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:21:58 --> Final output sent to browser
DEBUG - 2021-12-09 02:21:58 --> Total execution time: 0.0800
INFO - 2021-12-09 02:22:47 --> Config Class Initialized
INFO - 2021-12-09 02:22:47 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:22:47 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:22:47 --> Utf8 Class Initialized
INFO - 2021-12-09 02:22:47 --> URI Class Initialized
INFO - 2021-12-09 02:22:47 --> Router Class Initialized
INFO - 2021-12-09 02:22:47 --> Output Class Initialized
INFO - 2021-12-09 02:22:47 --> Security Class Initialized
DEBUG - 2021-12-09 02:22:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:22:47 --> Input Class Initialized
INFO - 2021-12-09 02:22:47 --> Language Class Initialized
INFO - 2021-12-09 02:22:47 --> Language Class Initialized
INFO - 2021-12-09 02:22:47 --> Config Class Initialized
INFO - 2021-12-09 02:22:47 --> Loader Class Initialized
INFO - 2021-12-09 02:22:47 --> Helper loaded: url_helper
INFO - 2021-12-09 02:22:47 --> Helper loaded: file_helper
INFO - 2021-12-09 02:22:47 --> Helper loaded: form_helper
INFO - 2021-12-09 02:22:47 --> Helper loaded: my_helper
INFO - 2021-12-09 02:22:47 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:22:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:22:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:22:47 --> Controller Class Initialized
DEBUG - 2021-12-09 02:22:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:22:47 --> Final output sent to browser
DEBUG - 2021-12-09 02:22:47 --> Total execution time: 0.0830
INFO - 2021-12-09 02:23:00 --> Config Class Initialized
INFO - 2021-12-09 02:23:00 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:23:00 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:23:00 --> Utf8 Class Initialized
INFO - 2021-12-09 02:23:00 --> URI Class Initialized
INFO - 2021-12-09 02:23:00 --> Router Class Initialized
INFO - 2021-12-09 02:23:00 --> Output Class Initialized
INFO - 2021-12-09 02:23:00 --> Security Class Initialized
DEBUG - 2021-12-09 02:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:23:00 --> Input Class Initialized
INFO - 2021-12-09 02:23:00 --> Language Class Initialized
INFO - 2021-12-09 02:23:00 --> Language Class Initialized
INFO - 2021-12-09 02:23:00 --> Config Class Initialized
INFO - 2021-12-09 02:23:00 --> Loader Class Initialized
INFO - 2021-12-09 02:23:00 --> Helper loaded: url_helper
INFO - 2021-12-09 02:23:00 --> Helper loaded: file_helper
INFO - 2021-12-09 02:23:00 --> Helper loaded: form_helper
INFO - 2021-12-09 02:23:00 --> Helper loaded: my_helper
INFO - 2021-12-09 02:23:00 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:23:00 --> Controller Class Initialized
DEBUG - 2021-12-09 02:23:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:23:00 --> Final output sent to browser
DEBUG - 2021-12-09 02:23:00 --> Total execution time: 0.0710
INFO - 2021-12-09 02:23:10 --> Config Class Initialized
INFO - 2021-12-09 02:23:10 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:23:10 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:23:10 --> Utf8 Class Initialized
INFO - 2021-12-09 02:23:10 --> URI Class Initialized
INFO - 2021-12-09 02:23:10 --> Router Class Initialized
INFO - 2021-12-09 02:23:10 --> Output Class Initialized
INFO - 2021-12-09 02:23:10 --> Security Class Initialized
DEBUG - 2021-12-09 02:23:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:23:10 --> Input Class Initialized
INFO - 2021-12-09 02:23:10 --> Language Class Initialized
INFO - 2021-12-09 02:23:10 --> Language Class Initialized
INFO - 2021-12-09 02:23:10 --> Config Class Initialized
INFO - 2021-12-09 02:23:10 --> Loader Class Initialized
INFO - 2021-12-09 02:23:10 --> Helper loaded: url_helper
INFO - 2021-12-09 02:23:10 --> Helper loaded: file_helper
INFO - 2021-12-09 02:23:10 --> Helper loaded: form_helper
INFO - 2021-12-09 02:23:10 --> Helper loaded: my_helper
INFO - 2021-12-09 02:23:10 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:23:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:23:10 --> Controller Class Initialized
DEBUG - 2021-12-09 02:23:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:23:10 --> Final output sent to browser
DEBUG - 2021-12-09 02:23:10 --> Total execution time: 0.0670
INFO - 2021-12-09 02:23:54 --> Config Class Initialized
INFO - 2021-12-09 02:23:54 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:23:54 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:23:54 --> Utf8 Class Initialized
INFO - 2021-12-09 02:23:55 --> URI Class Initialized
INFO - 2021-12-09 02:23:55 --> Router Class Initialized
INFO - 2021-12-09 02:23:55 --> Output Class Initialized
INFO - 2021-12-09 02:23:55 --> Security Class Initialized
DEBUG - 2021-12-09 02:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:23:55 --> Input Class Initialized
INFO - 2021-12-09 02:23:55 --> Language Class Initialized
INFO - 2021-12-09 02:23:55 --> Language Class Initialized
INFO - 2021-12-09 02:23:55 --> Config Class Initialized
INFO - 2021-12-09 02:23:55 --> Loader Class Initialized
INFO - 2021-12-09 02:23:55 --> Helper loaded: url_helper
INFO - 2021-12-09 02:23:55 --> Helper loaded: file_helper
INFO - 2021-12-09 02:23:55 --> Helper loaded: form_helper
INFO - 2021-12-09 02:23:55 --> Helper loaded: my_helper
INFO - 2021-12-09 02:23:55 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:23:55 --> Controller Class Initialized
DEBUG - 2021-12-09 02:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:23:55 --> Final output sent to browser
DEBUG - 2021-12-09 02:23:55 --> Total execution time: 0.0660
INFO - 2021-12-09 02:26:23 --> Config Class Initialized
INFO - 2021-12-09 02:26:23 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:26:23 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:26:23 --> Utf8 Class Initialized
INFO - 2021-12-09 02:26:23 --> URI Class Initialized
INFO - 2021-12-09 02:26:23 --> Router Class Initialized
INFO - 2021-12-09 02:26:23 --> Output Class Initialized
INFO - 2021-12-09 02:26:23 --> Security Class Initialized
DEBUG - 2021-12-09 02:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:26:23 --> Input Class Initialized
INFO - 2021-12-09 02:26:23 --> Language Class Initialized
INFO - 2021-12-09 02:26:23 --> Language Class Initialized
INFO - 2021-12-09 02:26:23 --> Config Class Initialized
INFO - 2021-12-09 02:26:23 --> Loader Class Initialized
INFO - 2021-12-09 02:26:23 --> Helper loaded: url_helper
INFO - 2021-12-09 02:26:23 --> Helper loaded: file_helper
INFO - 2021-12-09 02:26:23 --> Helper loaded: form_helper
INFO - 2021-12-09 02:26:23 --> Helper loaded: my_helper
INFO - 2021-12-09 02:26:23 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:26:23 --> Controller Class Initialized
DEBUG - 2021-12-09 02:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:26:23 --> Final output sent to browser
DEBUG - 2021-12-09 02:26:23 --> Total execution time: 0.0640
INFO - 2021-12-09 02:26:52 --> Config Class Initialized
INFO - 2021-12-09 02:26:52 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:26:53 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:26:53 --> Utf8 Class Initialized
INFO - 2021-12-09 02:26:53 --> URI Class Initialized
INFO - 2021-12-09 02:26:53 --> Router Class Initialized
INFO - 2021-12-09 02:26:53 --> Output Class Initialized
INFO - 2021-12-09 02:26:53 --> Security Class Initialized
DEBUG - 2021-12-09 02:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:26:53 --> Input Class Initialized
INFO - 2021-12-09 02:26:53 --> Language Class Initialized
INFO - 2021-12-09 02:26:53 --> Language Class Initialized
INFO - 2021-12-09 02:26:53 --> Config Class Initialized
INFO - 2021-12-09 02:26:53 --> Loader Class Initialized
INFO - 2021-12-09 02:26:53 --> Helper loaded: url_helper
INFO - 2021-12-09 02:26:53 --> Helper loaded: file_helper
INFO - 2021-12-09 02:26:53 --> Helper loaded: form_helper
INFO - 2021-12-09 02:26:53 --> Helper loaded: my_helper
INFO - 2021-12-09 02:26:53 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:26:53 --> Controller Class Initialized
DEBUG - 2021-12-09 02:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:26:53 --> Final output sent to browser
DEBUG - 2021-12-09 02:26:53 --> Total execution time: 0.0690
INFO - 2021-12-09 02:27:19 --> Config Class Initialized
INFO - 2021-12-09 02:27:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:27:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:27:19 --> Utf8 Class Initialized
INFO - 2021-12-09 02:27:19 --> URI Class Initialized
INFO - 2021-12-09 02:27:19 --> Router Class Initialized
INFO - 2021-12-09 02:27:19 --> Output Class Initialized
INFO - 2021-12-09 02:27:19 --> Security Class Initialized
DEBUG - 2021-12-09 02:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:27:19 --> Input Class Initialized
INFO - 2021-12-09 02:27:19 --> Language Class Initialized
INFO - 2021-12-09 02:27:19 --> Language Class Initialized
INFO - 2021-12-09 02:27:19 --> Config Class Initialized
INFO - 2021-12-09 02:27:19 --> Loader Class Initialized
INFO - 2021-12-09 02:27:19 --> Helper loaded: url_helper
INFO - 2021-12-09 02:27:19 --> Helper loaded: file_helper
INFO - 2021-12-09 02:27:19 --> Helper loaded: form_helper
INFO - 2021-12-09 02:27:19 --> Helper loaded: my_helper
INFO - 2021-12-09 02:27:19 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:27:19 --> Controller Class Initialized
DEBUG - 2021-12-09 02:27:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:27:19 --> Final output sent to browser
DEBUG - 2021-12-09 02:27:19 --> Total execution time: 0.0690
INFO - 2021-12-09 02:33:18 --> Config Class Initialized
INFO - 2021-12-09 02:33:18 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:33:18 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:33:18 --> Utf8 Class Initialized
INFO - 2021-12-09 02:33:18 --> URI Class Initialized
INFO - 2021-12-09 02:33:18 --> Router Class Initialized
INFO - 2021-12-09 02:33:18 --> Output Class Initialized
INFO - 2021-12-09 02:33:18 --> Security Class Initialized
DEBUG - 2021-12-09 02:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:33:18 --> Input Class Initialized
INFO - 2021-12-09 02:33:18 --> Language Class Initialized
INFO - 2021-12-09 02:33:18 --> Language Class Initialized
INFO - 2021-12-09 02:33:18 --> Config Class Initialized
INFO - 2021-12-09 02:33:18 --> Loader Class Initialized
INFO - 2021-12-09 02:33:18 --> Helper loaded: url_helper
INFO - 2021-12-09 02:33:18 --> Helper loaded: file_helper
INFO - 2021-12-09 02:33:18 --> Helper loaded: form_helper
INFO - 2021-12-09 02:33:18 --> Helper loaded: my_helper
INFO - 2021-12-09 02:33:18 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:33:18 --> Controller Class Initialized
DEBUG - 2021-12-09 02:33:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:33:18 --> Final output sent to browser
DEBUG - 2021-12-09 02:33:18 --> Total execution time: 0.0620
INFO - 2021-12-09 02:33:19 --> Config Class Initialized
INFO - 2021-12-09 02:33:19 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:33:19 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:33:19 --> Utf8 Class Initialized
INFO - 2021-12-09 02:33:19 --> URI Class Initialized
INFO - 2021-12-09 02:33:19 --> Router Class Initialized
INFO - 2021-12-09 02:33:19 --> Output Class Initialized
INFO - 2021-12-09 02:33:19 --> Security Class Initialized
DEBUG - 2021-12-09 02:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:33:19 --> Input Class Initialized
INFO - 2021-12-09 02:33:19 --> Language Class Initialized
INFO - 2021-12-09 02:33:19 --> Language Class Initialized
INFO - 2021-12-09 02:33:19 --> Config Class Initialized
INFO - 2021-12-09 02:33:19 --> Loader Class Initialized
INFO - 2021-12-09 02:33:19 --> Helper loaded: url_helper
INFO - 2021-12-09 02:33:19 --> Helper loaded: file_helper
INFO - 2021-12-09 02:33:19 --> Helper loaded: form_helper
INFO - 2021-12-09 02:33:19 --> Helper loaded: my_helper
INFO - 2021-12-09 02:33:19 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:33:19 --> Controller Class Initialized
DEBUG - 2021-12-09 02:33:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:33:19 --> Final output sent to browser
DEBUG - 2021-12-09 02:33:19 --> Total execution time: 0.0670
INFO - 2021-12-09 02:34:53 --> Config Class Initialized
INFO - 2021-12-09 02:34:53 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:34:53 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:34:53 --> Utf8 Class Initialized
INFO - 2021-12-09 02:34:53 --> URI Class Initialized
INFO - 2021-12-09 02:34:53 --> Router Class Initialized
INFO - 2021-12-09 02:34:53 --> Output Class Initialized
INFO - 2021-12-09 02:34:53 --> Security Class Initialized
DEBUG - 2021-12-09 02:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:34:53 --> Input Class Initialized
INFO - 2021-12-09 02:34:53 --> Language Class Initialized
INFO - 2021-12-09 02:34:53 --> Language Class Initialized
INFO - 2021-12-09 02:34:53 --> Config Class Initialized
INFO - 2021-12-09 02:34:53 --> Loader Class Initialized
INFO - 2021-12-09 02:34:53 --> Helper loaded: url_helper
INFO - 2021-12-09 02:34:53 --> Helper loaded: file_helper
INFO - 2021-12-09 02:34:53 --> Helper loaded: form_helper
INFO - 2021-12-09 02:34:53 --> Helper loaded: my_helper
INFO - 2021-12-09 02:34:53 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:34:53 --> Controller Class Initialized
DEBUG - 2021-12-09 02:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:34:53 --> Final output sent to browser
DEBUG - 2021-12-09 02:34:53 --> Total execution time: 0.0530
INFO - 2021-12-09 02:42:03 --> Config Class Initialized
INFO - 2021-12-09 02:42:03 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:42:03 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:42:03 --> Utf8 Class Initialized
INFO - 2021-12-09 02:42:03 --> URI Class Initialized
INFO - 2021-12-09 02:42:03 --> Router Class Initialized
INFO - 2021-12-09 02:42:03 --> Output Class Initialized
INFO - 2021-12-09 02:42:03 --> Security Class Initialized
DEBUG - 2021-12-09 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:42:03 --> Input Class Initialized
INFO - 2021-12-09 02:42:03 --> Language Class Initialized
INFO - 2021-12-09 02:42:03 --> Language Class Initialized
INFO - 2021-12-09 02:42:03 --> Config Class Initialized
INFO - 2021-12-09 02:42:03 --> Loader Class Initialized
INFO - 2021-12-09 02:42:03 --> Helper loaded: url_helper
INFO - 2021-12-09 02:42:03 --> Helper loaded: file_helper
INFO - 2021-12-09 02:42:03 --> Helper loaded: form_helper
INFO - 2021-12-09 02:42:03 --> Helper loaded: my_helper
INFO - 2021-12-09 02:42:03 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:42:03 --> Controller Class Initialized
DEBUG - 2021-12-09 02:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:42:03 --> Final output sent to browser
DEBUG - 2021-12-09 02:42:03 --> Total execution time: 0.0610
INFO - 2021-12-09 02:42:49 --> Config Class Initialized
INFO - 2021-12-09 02:42:49 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:42:49 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:42:49 --> Utf8 Class Initialized
INFO - 2021-12-09 02:42:49 --> URI Class Initialized
INFO - 2021-12-09 02:42:49 --> Router Class Initialized
INFO - 2021-12-09 02:42:49 --> Output Class Initialized
INFO - 2021-12-09 02:42:49 --> Security Class Initialized
DEBUG - 2021-12-09 02:42:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:42:49 --> Input Class Initialized
INFO - 2021-12-09 02:42:49 --> Language Class Initialized
INFO - 2021-12-09 02:42:49 --> Language Class Initialized
INFO - 2021-12-09 02:42:49 --> Config Class Initialized
INFO - 2021-12-09 02:42:49 --> Loader Class Initialized
INFO - 2021-12-09 02:42:49 --> Helper loaded: url_helper
INFO - 2021-12-09 02:42:49 --> Helper loaded: file_helper
INFO - 2021-12-09 02:42:49 --> Helper loaded: form_helper
INFO - 2021-12-09 02:42:49 --> Helper loaded: my_helper
INFO - 2021-12-09 02:42:49 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:42:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:42:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:42:49 --> Controller Class Initialized
DEBUG - 2021-12-09 02:42:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:42:49 --> Final output sent to browser
DEBUG - 2021-12-09 02:42:49 --> Total execution time: 0.0640
INFO - 2021-12-09 02:43:09 --> Config Class Initialized
INFO - 2021-12-09 02:43:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:43:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:43:09 --> Utf8 Class Initialized
INFO - 2021-12-09 02:43:09 --> URI Class Initialized
INFO - 2021-12-09 02:43:09 --> Router Class Initialized
INFO - 2021-12-09 02:43:09 --> Output Class Initialized
INFO - 2021-12-09 02:43:09 --> Security Class Initialized
DEBUG - 2021-12-09 02:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:43:09 --> Input Class Initialized
INFO - 2021-12-09 02:43:09 --> Language Class Initialized
INFO - 2021-12-09 02:43:09 --> Language Class Initialized
INFO - 2021-12-09 02:43:09 --> Config Class Initialized
INFO - 2021-12-09 02:43:09 --> Loader Class Initialized
INFO - 2021-12-09 02:43:09 --> Helper loaded: url_helper
INFO - 2021-12-09 02:43:09 --> Helper loaded: file_helper
INFO - 2021-12-09 02:43:09 --> Helper loaded: form_helper
INFO - 2021-12-09 02:43:09 --> Helper loaded: my_helper
INFO - 2021-12-09 02:43:09 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:43:09 --> Controller Class Initialized
DEBUG - 2021-12-09 02:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:43:09 --> Final output sent to browser
DEBUG - 2021-12-09 02:43:09 --> Total execution time: 0.0650
INFO - 2021-12-09 02:43:25 --> Config Class Initialized
INFO - 2021-12-09 02:43:25 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:43:25 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:43:25 --> Utf8 Class Initialized
INFO - 2021-12-09 02:43:25 --> URI Class Initialized
INFO - 2021-12-09 02:43:25 --> Router Class Initialized
INFO - 2021-12-09 02:43:25 --> Output Class Initialized
INFO - 2021-12-09 02:43:25 --> Security Class Initialized
DEBUG - 2021-12-09 02:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:43:25 --> Input Class Initialized
INFO - 2021-12-09 02:43:25 --> Language Class Initialized
INFO - 2021-12-09 02:43:25 --> Language Class Initialized
INFO - 2021-12-09 02:43:25 --> Config Class Initialized
INFO - 2021-12-09 02:43:25 --> Loader Class Initialized
INFO - 2021-12-09 02:43:25 --> Helper loaded: url_helper
INFO - 2021-12-09 02:43:25 --> Helper loaded: file_helper
INFO - 2021-12-09 02:43:25 --> Helper loaded: form_helper
INFO - 2021-12-09 02:43:25 --> Helper loaded: my_helper
INFO - 2021-12-09 02:43:25 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:43:25 --> Controller Class Initialized
DEBUG - 2021-12-09 02:43:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:43:25 --> Final output sent to browser
DEBUG - 2021-12-09 02:43:25 --> Total execution time: 0.0720
INFO - 2021-12-09 02:44:52 --> Config Class Initialized
INFO - 2021-12-09 02:44:52 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:44:52 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:44:52 --> Utf8 Class Initialized
INFO - 2021-12-09 02:44:52 --> URI Class Initialized
INFO - 2021-12-09 02:44:52 --> Router Class Initialized
INFO - 2021-12-09 02:44:52 --> Output Class Initialized
INFO - 2021-12-09 02:44:52 --> Security Class Initialized
DEBUG - 2021-12-09 02:44:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:44:52 --> Input Class Initialized
INFO - 2021-12-09 02:44:52 --> Language Class Initialized
INFO - 2021-12-09 02:44:52 --> Language Class Initialized
INFO - 2021-12-09 02:44:52 --> Config Class Initialized
INFO - 2021-12-09 02:44:52 --> Loader Class Initialized
INFO - 2021-12-09 02:44:52 --> Helper loaded: url_helper
INFO - 2021-12-09 02:44:52 --> Helper loaded: file_helper
INFO - 2021-12-09 02:44:52 --> Helper loaded: form_helper
INFO - 2021-12-09 02:44:52 --> Helper loaded: my_helper
INFO - 2021-12-09 02:44:52 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:44:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:44:52 --> Controller Class Initialized
DEBUG - 2021-12-09 02:44:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:44:52 --> Final output sent to browser
DEBUG - 2021-12-09 02:44:52 --> Total execution time: 0.0650
INFO - 2021-12-09 02:56:25 --> Config Class Initialized
INFO - 2021-12-09 02:56:25 --> Hooks Class Initialized
DEBUG - 2021-12-09 02:56:25 --> UTF-8 Support Enabled
INFO - 2021-12-09 02:56:25 --> Utf8 Class Initialized
INFO - 2021-12-09 02:56:25 --> URI Class Initialized
INFO - 2021-12-09 02:56:25 --> Router Class Initialized
INFO - 2021-12-09 02:56:25 --> Output Class Initialized
INFO - 2021-12-09 02:56:25 --> Security Class Initialized
DEBUG - 2021-12-09 02:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 02:56:25 --> Input Class Initialized
INFO - 2021-12-09 02:56:25 --> Language Class Initialized
INFO - 2021-12-09 02:56:25 --> Language Class Initialized
INFO - 2021-12-09 02:56:25 --> Config Class Initialized
INFO - 2021-12-09 02:56:25 --> Loader Class Initialized
INFO - 2021-12-09 02:56:25 --> Helper loaded: url_helper
INFO - 2021-12-09 02:56:25 --> Helper loaded: file_helper
INFO - 2021-12-09 02:56:25 --> Helper loaded: form_helper
INFO - 2021-12-09 02:56:25 --> Helper loaded: my_helper
INFO - 2021-12-09 02:56:25 --> Database Driver Class Initialized
DEBUG - 2021-12-09 02:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 02:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 02:56:25 --> Controller Class Initialized
DEBUG - 2021-12-09 02:56:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 02:56:25 --> Final output sent to browser
DEBUG - 2021-12-09 02:56:25 --> Total execution time: 0.0660
INFO - 2021-12-09 03:02:03 --> Config Class Initialized
INFO - 2021-12-09 03:02:03 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:02:03 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:02:03 --> Utf8 Class Initialized
INFO - 2021-12-09 03:02:03 --> URI Class Initialized
INFO - 2021-12-09 03:02:03 --> Router Class Initialized
INFO - 2021-12-09 03:02:03 --> Output Class Initialized
INFO - 2021-12-09 03:02:03 --> Security Class Initialized
DEBUG - 2021-12-09 03:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:02:03 --> Input Class Initialized
INFO - 2021-12-09 03:02:03 --> Language Class Initialized
INFO - 2021-12-09 03:02:03 --> Language Class Initialized
INFO - 2021-12-09 03:02:03 --> Config Class Initialized
INFO - 2021-12-09 03:02:03 --> Loader Class Initialized
INFO - 2021-12-09 03:02:03 --> Helper loaded: url_helper
INFO - 2021-12-09 03:02:03 --> Helper loaded: file_helper
INFO - 2021-12-09 03:02:03 --> Helper loaded: form_helper
INFO - 2021-12-09 03:02:03 --> Helper loaded: my_helper
INFO - 2021-12-09 03:02:03 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:02:03 --> Controller Class Initialized
DEBUG - 2021-12-09 03:02:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:02:03 --> Final output sent to browser
DEBUG - 2021-12-09 03:02:03 --> Total execution time: 0.0670
INFO - 2021-12-09 03:04:27 --> Config Class Initialized
INFO - 2021-12-09 03:04:27 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:04:27 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:04:27 --> Utf8 Class Initialized
INFO - 2021-12-09 03:04:27 --> URI Class Initialized
INFO - 2021-12-09 03:04:27 --> Router Class Initialized
INFO - 2021-12-09 03:04:27 --> Output Class Initialized
INFO - 2021-12-09 03:04:27 --> Security Class Initialized
DEBUG - 2021-12-09 03:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:04:27 --> Input Class Initialized
INFO - 2021-12-09 03:04:27 --> Language Class Initialized
INFO - 2021-12-09 03:04:27 --> Language Class Initialized
INFO - 2021-12-09 03:04:27 --> Config Class Initialized
INFO - 2021-12-09 03:04:27 --> Loader Class Initialized
INFO - 2021-12-09 03:04:27 --> Helper loaded: url_helper
INFO - 2021-12-09 03:04:27 --> Helper loaded: file_helper
INFO - 2021-12-09 03:04:27 --> Helper loaded: form_helper
INFO - 2021-12-09 03:04:27 --> Helper loaded: my_helper
INFO - 2021-12-09 03:04:27 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:04:27 --> Controller Class Initialized
DEBUG - 2021-12-09 03:04:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:04:27 --> Final output sent to browser
DEBUG - 2021-12-09 03:04:27 --> Total execution time: 0.0630
INFO - 2021-12-09 03:04:42 --> Config Class Initialized
INFO - 2021-12-09 03:04:42 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:04:42 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:04:42 --> Utf8 Class Initialized
INFO - 2021-12-09 03:04:42 --> URI Class Initialized
INFO - 2021-12-09 03:04:42 --> Router Class Initialized
INFO - 2021-12-09 03:04:42 --> Output Class Initialized
INFO - 2021-12-09 03:04:42 --> Security Class Initialized
DEBUG - 2021-12-09 03:04:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:04:42 --> Input Class Initialized
INFO - 2021-12-09 03:04:42 --> Language Class Initialized
INFO - 2021-12-09 03:04:42 --> Language Class Initialized
INFO - 2021-12-09 03:04:42 --> Config Class Initialized
INFO - 2021-12-09 03:04:42 --> Loader Class Initialized
INFO - 2021-12-09 03:04:42 --> Helper loaded: url_helper
INFO - 2021-12-09 03:04:42 --> Helper loaded: file_helper
INFO - 2021-12-09 03:04:42 --> Helper loaded: form_helper
INFO - 2021-12-09 03:04:42 --> Helper loaded: my_helper
INFO - 2021-12-09 03:04:42 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:04:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:04:42 --> Controller Class Initialized
DEBUG - 2021-12-09 03:04:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:04:42 --> Final output sent to browser
DEBUG - 2021-12-09 03:04:42 --> Total execution time: 0.0560
INFO - 2021-12-09 03:08:17 --> Config Class Initialized
INFO - 2021-12-09 03:08:17 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:08:17 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:08:17 --> Utf8 Class Initialized
INFO - 2021-12-09 03:08:17 --> URI Class Initialized
INFO - 2021-12-09 03:08:17 --> Router Class Initialized
INFO - 2021-12-09 03:08:17 --> Output Class Initialized
INFO - 2021-12-09 03:08:17 --> Security Class Initialized
DEBUG - 2021-12-09 03:08:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:08:17 --> Input Class Initialized
INFO - 2021-12-09 03:08:17 --> Language Class Initialized
INFO - 2021-12-09 03:08:17 --> Language Class Initialized
INFO - 2021-12-09 03:08:17 --> Config Class Initialized
INFO - 2021-12-09 03:08:17 --> Loader Class Initialized
INFO - 2021-12-09 03:08:17 --> Helper loaded: url_helper
INFO - 2021-12-09 03:08:17 --> Helper loaded: file_helper
INFO - 2021-12-09 03:08:17 --> Helper loaded: form_helper
INFO - 2021-12-09 03:08:17 --> Helper loaded: my_helper
INFO - 2021-12-09 03:08:17 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:08:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:08:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:08:17 --> Controller Class Initialized
DEBUG - 2021-12-09 03:08:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:08:17 --> Final output sent to browser
DEBUG - 2021-12-09 03:08:17 --> Total execution time: 0.0520
INFO - 2021-12-09 03:11:13 --> Config Class Initialized
INFO - 2021-12-09 03:11:13 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:11:13 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:11:13 --> Utf8 Class Initialized
INFO - 2021-12-09 03:11:13 --> URI Class Initialized
INFO - 2021-12-09 03:11:13 --> Router Class Initialized
INFO - 2021-12-09 03:11:13 --> Output Class Initialized
INFO - 2021-12-09 03:11:13 --> Security Class Initialized
DEBUG - 2021-12-09 03:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:11:13 --> Input Class Initialized
INFO - 2021-12-09 03:11:13 --> Language Class Initialized
INFO - 2021-12-09 03:11:13 --> Language Class Initialized
INFO - 2021-12-09 03:11:13 --> Config Class Initialized
INFO - 2021-12-09 03:11:13 --> Loader Class Initialized
INFO - 2021-12-09 03:11:13 --> Helper loaded: url_helper
INFO - 2021-12-09 03:11:13 --> Helper loaded: file_helper
INFO - 2021-12-09 03:11:13 --> Helper loaded: form_helper
INFO - 2021-12-09 03:11:13 --> Helper loaded: my_helper
INFO - 2021-12-09 03:11:13 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:11:13 --> Controller Class Initialized
DEBUG - 2021-12-09 03:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:11:13 --> Final output sent to browser
DEBUG - 2021-12-09 03:11:13 --> Total execution time: 0.0630
INFO - 2021-12-09 03:12:04 --> Config Class Initialized
INFO - 2021-12-09 03:12:04 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:12:04 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:12:04 --> Utf8 Class Initialized
INFO - 2021-12-09 03:12:04 --> URI Class Initialized
INFO - 2021-12-09 03:12:04 --> Router Class Initialized
INFO - 2021-12-09 03:12:04 --> Output Class Initialized
INFO - 2021-12-09 03:12:04 --> Security Class Initialized
DEBUG - 2021-12-09 03:12:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:12:04 --> Input Class Initialized
INFO - 2021-12-09 03:12:04 --> Language Class Initialized
INFO - 2021-12-09 03:12:04 --> Language Class Initialized
INFO - 2021-12-09 03:12:04 --> Config Class Initialized
INFO - 2021-12-09 03:12:04 --> Loader Class Initialized
INFO - 2021-12-09 03:12:04 --> Helper loaded: url_helper
INFO - 2021-12-09 03:12:04 --> Helper loaded: file_helper
INFO - 2021-12-09 03:12:04 --> Helper loaded: form_helper
INFO - 2021-12-09 03:12:04 --> Helper loaded: my_helper
INFO - 2021-12-09 03:12:04 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:12:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:12:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:12:04 --> Controller Class Initialized
DEBUG - 2021-12-09 03:12:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:12:04 --> Final output sent to browser
DEBUG - 2021-12-09 03:12:04 --> Total execution time: 0.0790
INFO - 2021-12-09 03:12:28 --> Config Class Initialized
INFO - 2021-12-09 03:12:28 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:12:28 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:12:28 --> Utf8 Class Initialized
INFO - 2021-12-09 03:12:28 --> URI Class Initialized
INFO - 2021-12-09 03:12:28 --> Router Class Initialized
INFO - 2021-12-09 03:12:28 --> Output Class Initialized
INFO - 2021-12-09 03:12:28 --> Security Class Initialized
DEBUG - 2021-12-09 03:12:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:12:28 --> Input Class Initialized
INFO - 2021-12-09 03:12:28 --> Language Class Initialized
INFO - 2021-12-09 03:12:28 --> Language Class Initialized
INFO - 2021-12-09 03:12:28 --> Config Class Initialized
INFO - 2021-12-09 03:12:28 --> Loader Class Initialized
INFO - 2021-12-09 03:12:28 --> Helper loaded: url_helper
INFO - 2021-12-09 03:12:28 --> Helper loaded: file_helper
INFO - 2021-12-09 03:12:28 --> Helper loaded: form_helper
INFO - 2021-12-09 03:12:28 --> Helper loaded: my_helper
INFO - 2021-12-09 03:12:28 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:12:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:12:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:12:28 --> Controller Class Initialized
DEBUG - 2021-12-09 03:12:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:12:28 --> Final output sent to browser
DEBUG - 2021-12-09 03:12:28 --> Total execution time: 0.0700
INFO - 2021-12-09 03:12:30 --> Config Class Initialized
INFO - 2021-12-09 03:12:30 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:12:30 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:12:30 --> Utf8 Class Initialized
INFO - 2021-12-09 03:12:30 --> URI Class Initialized
INFO - 2021-12-09 03:12:30 --> Router Class Initialized
INFO - 2021-12-09 03:12:30 --> Output Class Initialized
INFO - 2021-12-09 03:12:30 --> Security Class Initialized
DEBUG - 2021-12-09 03:12:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:12:30 --> Input Class Initialized
INFO - 2021-12-09 03:12:30 --> Language Class Initialized
INFO - 2021-12-09 03:12:30 --> Language Class Initialized
INFO - 2021-12-09 03:12:30 --> Config Class Initialized
INFO - 2021-12-09 03:12:30 --> Loader Class Initialized
INFO - 2021-12-09 03:12:30 --> Helper loaded: url_helper
INFO - 2021-12-09 03:12:30 --> Helper loaded: file_helper
INFO - 2021-12-09 03:12:30 --> Helper loaded: form_helper
INFO - 2021-12-09 03:12:30 --> Helper loaded: my_helper
INFO - 2021-12-09 03:12:30 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:12:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:12:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:12:30 --> Controller Class Initialized
DEBUG - 2021-12-09 03:12:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:12:30 --> Final output sent to browser
DEBUG - 2021-12-09 03:12:30 --> Total execution time: 0.0680
INFO - 2021-12-09 03:19:35 --> Config Class Initialized
INFO - 2021-12-09 03:19:35 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:19:35 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:19:35 --> Utf8 Class Initialized
INFO - 2021-12-09 03:19:35 --> URI Class Initialized
INFO - 2021-12-09 03:19:35 --> Router Class Initialized
INFO - 2021-12-09 03:19:35 --> Output Class Initialized
INFO - 2021-12-09 03:19:35 --> Security Class Initialized
DEBUG - 2021-12-09 03:19:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:19:35 --> Input Class Initialized
INFO - 2021-12-09 03:19:35 --> Language Class Initialized
INFO - 2021-12-09 03:19:35 --> Language Class Initialized
INFO - 2021-12-09 03:19:35 --> Config Class Initialized
INFO - 2021-12-09 03:19:35 --> Loader Class Initialized
INFO - 2021-12-09 03:19:35 --> Helper loaded: url_helper
INFO - 2021-12-09 03:19:35 --> Helper loaded: file_helper
INFO - 2021-12-09 03:19:35 --> Helper loaded: form_helper
INFO - 2021-12-09 03:19:35 --> Helper loaded: my_helper
INFO - 2021-12-09 03:19:35 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:19:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:19:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:19:35 --> Controller Class Initialized
DEBUG - 2021-12-09 03:19:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:19:35 --> Final output sent to browser
DEBUG - 2021-12-09 03:19:35 --> Total execution time: 0.0710
INFO - 2021-12-09 03:20:47 --> Config Class Initialized
INFO - 2021-12-09 03:20:47 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:20:47 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:20:47 --> Utf8 Class Initialized
INFO - 2021-12-09 03:20:47 --> URI Class Initialized
INFO - 2021-12-09 03:20:47 --> Router Class Initialized
INFO - 2021-12-09 03:20:47 --> Output Class Initialized
INFO - 2021-12-09 03:20:47 --> Security Class Initialized
DEBUG - 2021-12-09 03:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:20:47 --> Input Class Initialized
INFO - 2021-12-09 03:20:47 --> Language Class Initialized
INFO - 2021-12-09 03:20:47 --> Language Class Initialized
INFO - 2021-12-09 03:20:47 --> Config Class Initialized
INFO - 2021-12-09 03:20:47 --> Loader Class Initialized
INFO - 2021-12-09 03:20:47 --> Helper loaded: url_helper
INFO - 2021-12-09 03:20:47 --> Helper loaded: file_helper
INFO - 2021-12-09 03:20:47 --> Helper loaded: form_helper
INFO - 2021-12-09 03:20:47 --> Helper loaded: my_helper
INFO - 2021-12-09 03:20:47 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:20:48 --> Controller Class Initialized
DEBUG - 2021-12-09 03:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:20:48 --> Final output sent to browser
DEBUG - 2021-12-09 03:20:48 --> Total execution time: 0.0750
INFO - 2021-12-09 03:27:51 --> Config Class Initialized
INFO - 2021-12-09 03:27:51 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:27:51 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:27:51 --> Utf8 Class Initialized
INFO - 2021-12-09 03:27:51 --> URI Class Initialized
INFO - 2021-12-09 03:27:51 --> Router Class Initialized
INFO - 2021-12-09 03:27:51 --> Output Class Initialized
INFO - 2021-12-09 03:27:51 --> Security Class Initialized
DEBUG - 2021-12-09 03:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:27:51 --> Input Class Initialized
INFO - 2021-12-09 03:27:51 --> Language Class Initialized
INFO - 2021-12-09 03:27:51 --> Language Class Initialized
INFO - 2021-12-09 03:27:51 --> Config Class Initialized
INFO - 2021-12-09 03:27:51 --> Loader Class Initialized
INFO - 2021-12-09 03:27:51 --> Helper loaded: url_helper
INFO - 2021-12-09 03:27:51 --> Helper loaded: file_helper
INFO - 2021-12-09 03:27:51 --> Helper loaded: form_helper
INFO - 2021-12-09 03:27:51 --> Helper loaded: my_helper
INFO - 2021-12-09 03:27:51 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:27:51 --> Controller Class Initialized
DEBUG - 2021-12-09 03:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:27:51 --> Final output sent to browser
DEBUG - 2021-12-09 03:27:51 --> Total execution time: 0.0760
INFO - 2021-12-09 03:32:18 --> Config Class Initialized
INFO - 2021-12-09 03:32:18 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:32:18 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:32:18 --> Utf8 Class Initialized
INFO - 2021-12-09 03:32:18 --> URI Class Initialized
INFO - 2021-12-09 03:32:18 --> Router Class Initialized
INFO - 2021-12-09 03:32:18 --> Output Class Initialized
INFO - 2021-12-09 03:32:18 --> Security Class Initialized
DEBUG - 2021-12-09 03:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:32:18 --> Input Class Initialized
INFO - 2021-12-09 03:32:18 --> Language Class Initialized
INFO - 2021-12-09 03:32:18 --> Language Class Initialized
INFO - 2021-12-09 03:32:18 --> Config Class Initialized
INFO - 2021-12-09 03:32:18 --> Loader Class Initialized
INFO - 2021-12-09 03:32:18 --> Helper loaded: url_helper
INFO - 2021-12-09 03:32:18 --> Helper loaded: file_helper
INFO - 2021-12-09 03:32:18 --> Helper loaded: form_helper
INFO - 2021-12-09 03:32:18 --> Helper loaded: my_helper
INFO - 2021-12-09 03:32:18 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:32:18 --> Controller Class Initialized
DEBUG - 2021-12-09 03:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:32:18 --> Final output sent to browser
DEBUG - 2021-12-09 03:32:18 --> Total execution time: 0.0630
INFO - 2021-12-09 03:33:25 --> Config Class Initialized
INFO - 2021-12-09 03:33:25 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:33:25 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:33:25 --> Utf8 Class Initialized
INFO - 2021-12-09 03:33:25 --> URI Class Initialized
INFO - 2021-12-09 03:33:25 --> Router Class Initialized
INFO - 2021-12-09 03:33:25 --> Output Class Initialized
INFO - 2021-12-09 03:33:25 --> Security Class Initialized
DEBUG - 2021-12-09 03:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:33:25 --> Input Class Initialized
INFO - 2021-12-09 03:33:25 --> Language Class Initialized
INFO - 2021-12-09 03:33:25 --> Language Class Initialized
INFO - 2021-12-09 03:33:25 --> Config Class Initialized
INFO - 2021-12-09 03:33:25 --> Loader Class Initialized
INFO - 2021-12-09 03:33:25 --> Helper loaded: url_helper
INFO - 2021-12-09 03:33:25 --> Helper loaded: file_helper
INFO - 2021-12-09 03:33:25 --> Helper loaded: form_helper
INFO - 2021-12-09 03:33:25 --> Helper loaded: my_helper
INFO - 2021-12-09 03:33:25 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:33:25 --> Controller Class Initialized
DEBUG - 2021-12-09 03:33:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:33:25 --> Final output sent to browser
DEBUG - 2021-12-09 03:33:25 --> Total execution time: 0.0660
INFO - 2021-12-09 03:34:15 --> Config Class Initialized
INFO - 2021-12-09 03:34:15 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:34:15 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:34:15 --> Utf8 Class Initialized
INFO - 2021-12-09 03:34:15 --> URI Class Initialized
INFO - 2021-12-09 03:34:15 --> Router Class Initialized
INFO - 2021-12-09 03:34:15 --> Output Class Initialized
INFO - 2021-12-09 03:34:15 --> Security Class Initialized
DEBUG - 2021-12-09 03:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:34:15 --> Input Class Initialized
INFO - 2021-12-09 03:34:15 --> Language Class Initialized
INFO - 2021-12-09 03:34:15 --> Language Class Initialized
INFO - 2021-12-09 03:34:15 --> Config Class Initialized
INFO - 2021-12-09 03:34:15 --> Loader Class Initialized
INFO - 2021-12-09 03:34:15 --> Helper loaded: url_helper
INFO - 2021-12-09 03:34:15 --> Helper loaded: file_helper
INFO - 2021-12-09 03:34:15 --> Helper loaded: form_helper
INFO - 2021-12-09 03:34:15 --> Helper loaded: my_helper
INFO - 2021-12-09 03:34:15 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:34:15 --> Controller Class Initialized
DEBUG - 2021-12-09 03:34:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:34:15 --> Final output sent to browser
DEBUG - 2021-12-09 03:34:15 --> Total execution time: 0.0680
INFO - 2021-12-09 03:34:32 --> Config Class Initialized
INFO - 2021-12-09 03:34:32 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:34:32 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:34:32 --> Utf8 Class Initialized
INFO - 2021-12-09 03:34:32 --> URI Class Initialized
INFO - 2021-12-09 03:34:32 --> Router Class Initialized
INFO - 2021-12-09 03:34:32 --> Output Class Initialized
INFO - 2021-12-09 03:34:32 --> Security Class Initialized
DEBUG - 2021-12-09 03:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:34:32 --> Input Class Initialized
INFO - 2021-12-09 03:34:32 --> Language Class Initialized
INFO - 2021-12-09 03:34:32 --> Language Class Initialized
INFO - 2021-12-09 03:34:32 --> Config Class Initialized
INFO - 2021-12-09 03:34:32 --> Loader Class Initialized
INFO - 2021-12-09 03:34:32 --> Helper loaded: url_helper
INFO - 2021-12-09 03:34:32 --> Helper loaded: file_helper
INFO - 2021-12-09 03:34:32 --> Helper loaded: form_helper
INFO - 2021-12-09 03:34:32 --> Helper loaded: my_helper
INFO - 2021-12-09 03:34:32 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:34:32 --> Controller Class Initialized
DEBUG - 2021-12-09 03:34:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:34:32 --> Final output sent to browser
DEBUG - 2021-12-09 03:34:32 --> Total execution time: 0.0790
INFO - 2021-12-09 03:35:24 --> Config Class Initialized
INFO - 2021-12-09 03:35:24 --> Hooks Class Initialized
DEBUG - 2021-12-09 03:35:24 --> UTF-8 Support Enabled
INFO - 2021-12-09 03:35:24 --> Utf8 Class Initialized
INFO - 2021-12-09 03:35:24 --> URI Class Initialized
INFO - 2021-12-09 03:35:24 --> Router Class Initialized
INFO - 2021-12-09 03:35:24 --> Output Class Initialized
INFO - 2021-12-09 03:35:24 --> Security Class Initialized
DEBUG - 2021-12-09 03:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 03:35:24 --> Input Class Initialized
INFO - 2021-12-09 03:35:24 --> Language Class Initialized
INFO - 2021-12-09 03:35:24 --> Language Class Initialized
INFO - 2021-12-09 03:35:24 --> Config Class Initialized
INFO - 2021-12-09 03:35:24 --> Loader Class Initialized
INFO - 2021-12-09 03:35:24 --> Helper loaded: url_helper
INFO - 2021-12-09 03:35:24 --> Helper loaded: file_helper
INFO - 2021-12-09 03:35:24 --> Helper loaded: form_helper
INFO - 2021-12-09 03:35:24 --> Helper loaded: my_helper
INFO - 2021-12-09 03:35:24 --> Database Driver Class Initialized
DEBUG - 2021-12-09 03:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 03:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 03:35:24 --> Controller Class Initialized
DEBUG - 2021-12-09 03:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 03:35:24 --> Final output sent to browser
DEBUG - 2021-12-09 03:35:24 --> Total execution time: 0.0630
INFO - 2021-12-09 04:19:59 --> Config Class Initialized
INFO - 2021-12-09 04:19:59 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:19:59 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:19:59 --> Utf8 Class Initialized
INFO - 2021-12-09 04:19:59 --> URI Class Initialized
INFO - 2021-12-09 04:19:59 --> Router Class Initialized
INFO - 2021-12-09 04:19:59 --> Output Class Initialized
INFO - 2021-12-09 04:19:59 --> Security Class Initialized
DEBUG - 2021-12-09 04:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:19:59 --> Input Class Initialized
INFO - 2021-12-09 04:19:59 --> Language Class Initialized
INFO - 2021-12-09 04:19:59 --> Language Class Initialized
INFO - 2021-12-09 04:19:59 --> Config Class Initialized
INFO - 2021-12-09 04:19:59 --> Loader Class Initialized
INFO - 2021-12-09 04:19:59 --> Helper loaded: url_helper
INFO - 2021-12-09 04:19:59 --> Helper loaded: file_helper
INFO - 2021-12-09 04:19:59 --> Helper loaded: form_helper
INFO - 2021-12-09 04:19:59 --> Helper loaded: my_helper
INFO - 2021-12-09 04:19:59 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:19:59 --> Controller Class Initialized
DEBUG - 2021-12-09 04:19:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:19:59 --> Final output sent to browser
DEBUG - 2021-12-09 04:19:59 --> Total execution time: 0.0560
INFO - 2021-12-09 04:20:15 --> Config Class Initialized
INFO - 2021-12-09 04:20:15 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:20:15 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:20:15 --> Utf8 Class Initialized
INFO - 2021-12-09 04:20:15 --> URI Class Initialized
INFO - 2021-12-09 04:20:15 --> Router Class Initialized
INFO - 2021-12-09 04:20:15 --> Output Class Initialized
INFO - 2021-12-09 04:20:15 --> Security Class Initialized
DEBUG - 2021-12-09 04:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:20:15 --> Input Class Initialized
INFO - 2021-12-09 04:20:15 --> Language Class Initialized
INFO - 2021-12-09 04:20:15 --> Language Class Initialized
INFO - 2021-12-09 04:20:15 --> Config Class Initialized
INFO - 2021-12-09 04:20:15 --> Loader Class Initialized
INFO - 2021-12-09 04:20:15 --> Helper loaded: url_helper
INFO - 2021-12-09 04:20:15 --> Helper loaded: file_helper
INFO - 2021-12-09 04:20:15 --> Helper loaded: form_helper
INFO - 2021-12-09 04:20:15 --> Helper loaded: my_helper
INFO - 2021-12-09 04:20:15 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:20:15 --> Controller Class Initialized
DEBUG - 2021-12-09 04:20:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:20:15 --> Final output sent to browser
DEBUG - 2021-12-09 04:20:15 --> Total execution time: 0.0630
INFO - 2021-12-09 04:20:33 --> Config Class Initialized
INFO - 2021-12-09 04:20:33 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:20:33 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:20:33 --> Utf8 Class Initialized
INFO - 2021-12-09 04:20:33 --> URI Class Initialized
INFO - 2021-12-09 04:20:33 --> Router Class Initialized
INFO - 2021-12-09 04:20:33 --> Output Class Initialized
INFO - 2021-12-09 04:20:33 --> Security Class Initialized
DEBUG - 2021-12-09 04:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:20:33 --> Input Class Initialized
INFO - 2021-12-09 04:20:33 --> Language Class Initialized
INFO - 2021-12-09 04:20:33 --> Language Class Initialized
INFO - 2021-12-09 04:20:33 --> Config Class Initialized
INFO - 2021-12-09 04:20:33 --> Loader Class Initialized
INFO - 2021-12-09 04:20:33 --> Helper loaded: url_helper
INFO - 2021-12-09 04:20:33 --> Helper loaded: file_helper
INFO - 2021-12-09 04:20:33 --> Helper loaded: form_helper
INFO - 2021-12-09 04:20:33 --> Helper loaded: my_helper
INFO - 2021-12-09 04:20:33 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:20:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:20:33 --> Controller Class Initialized
DEBUG - 2021-12-09 04:20:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:20:33 --> Final output sent to browser
DEBUG - 2021-12-09 04:20:33 --> Total execution time: 0.0700
INFO - 2021-12-09 04:20:47 --> Config Class Initialized
INFO - 2021-12-09 04:20:47 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:20:47 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:20:47 --> Utf8 Class Initialized
INFO - 2021-12-09 04:20:47 --> URI Class Initialized
INFO - 2021-12-09 04:20:47 --> Router Class Initialized
INFO - 2021-12-09 04:20:47 --> Output Class Initialized
INFO - 2021-12-09 04:20:47 --> Security Class Initialized
DEBUG - 2021-12-09 04:20:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:20:47 --> Input Class Initialized
INFO - 2021-12-09 04:20:47 --> Language Class Initialized
INFO - 2021-12-09 04:20:47 --> Language Class Initialized
INFO - 2021-12-09 04:20:47 --> Config Class Initialized
INFO - 2021-12-09 04:20:47 --> Loader Class Initialized
INFO - 2021-12-09 04:20:47 --> Helper loaded: url_helper
INFO - 2021-12-09 04:20:47 --> Helper loaded: file_helper
INFO - 2021-12-09 04:20:47 --> Helper loaded: form_helper
INFO - 2021-12-09 04:20:47 --> Helper loaded: my_helper
INFO - 2021-12-09 04:20:48 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:20:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:20:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:20:48 --> Controller Class Initialized
DEBUG - 2021-12-09 04:20:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:20:48 --> Final output sent to browser
DEBUG - 2021-12-09 04:20:48 --> Total execution time: 0.0630
INFO - 2021-12-09 04:20:55 --> Config Class Initialized
INFO - 2021-12-09 04:20:55 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:20:55 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:20:55 --> Utf8 Class Initialized
INFO - 2021-12-09 04:20:55 --> URI Class Initialized
INFO - 2021-12-09 04:20:55 --> Router Class Initialized
INFO - 2021-12-09 04:20:55 --> Output Class Initialized
INFO - 2021-12-09 04:20:55 --> Security Class Initialized
DEBUG - 2021-12-09 04:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:20:55 --> Input Class Initialized
INFO - 2021-12-09 04:20:55 --> Language Class Initialized
INFO - 2021-12-09 04:20:55 --> Language Class Initialized
INFO - 2021-12-09 04:20:55 --> Config Class Initialized
INFO - 2021-12-09 04:20:55 --> Loader Class Initialized
INFO - 2021-12-09 04:20:55 --> Helper loaded: url_helper
INFO - 2021-12-09 04:20:55 --> Helper loaded: file_helper
INFO - 2021-12-09 04:20:55 --> Helper loaded: form_helper
INFO - 2021-12-09 04:20:55 --> Helper loaded: my_helper
INFO - 2021-12-09 04:20:55 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:20:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:20:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:20:55 --> Controller Class Initialized
DEBUG - 2021-12-09 04:20:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:20:55 --> Final output sent to browser
DEBUG - 2021-12-09 04:20:55 --> Total execution time: 0.0690
INFO - 2021-12-09 04:21:07 --> Config Class Initialized
INFO - 2021-12-09 04:21:07 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:21:07 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:21:07 --> Utf8 Class Initialized
INFO - 2021-12-09 04:21:07 --> URI Class Initialized
INFO - 2021-12-09 04:21:07 --> Router Class Initialized
INFO - 2021-12-09 04:21:07 --> Output Class Initialized
INFO - 2021-12-09 04:21:07 --> Security Class Initialized
DEBUG - 2021-12-09 04:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:21:07 --> Input Class Initialized
INFO - 2021-12-09 04:21:07 --> Language Class Initialized
INFO - 2021-12-09 04:21:07 --> Language Class Initialized
INFO - 2021-12-09 04:21:07 --> Config Class Initialized
INFO - 2021-12-09 04:21:07 --> Loader Class Initialized
INFO - 2021-12-09 04:21:07 --> Helper loaded: url_helper
INFO - 2021-12-09 04:21:07 --> Helper loaded: file_helper
INFO - 2021-12-09 04:21:07 --> Helper loaded: form_helper
INFO - 2021-12-09 04:21:07 --> Helper loaded: my_helper
INFO - 2021-12-09 04:21:07 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:21:07 --> Controller Class Initialized
DEBUG - 2021-12-09 04:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:21:08 --> Final output sent to browser
DEBUG - 2021-12-09 04:21:08 --> Total execution time: 0.0700
INFO - 2021-12-09 04:22:16 --> Config Class Initialized
INFO - 2021-12-09 04:22:16 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:22:16 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:22:16 --> Utf8 Class Initialized
INFO - 2021-12-09 04:22:16 --> URI Class Initialized
INFO - 2021-12-09 04:22:16 --> Router Class Initialized
INFO - 2021-12-09 04:22:16 --> Output Class Initialized
INFO - 2021-12-09 04:22:16 --> Security Class Initialized
DEBUG - 2021-12-09 04:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:22:16 --> Input Class Initialized
INFO - 2021-12-09 04:22:16 --> Language Class Initialized
INFO - 2021-12-09 04:22:16 --> Language Class Initialized
INFO - 2021-12-09 04:22:16 --> Config Class Initialized
INFO - 2021-12-09 04:22:16 --> Loader Class Initialized
INFO - 2021-12-09 04:22:16 --> Helper loaded: url_helper
INFO - 2021-12-09 04:22:16 --> Helper loaded: file_helper
INFO - 2021-12-09 04:22:16 --> Helper loaded: form_helper
INFO - 2021-12-09 04:22:16 --> Helper loaded: my_helper
INFO - 2021-12-09 04:22:16 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:22:16 --> Controller Class Initialized
DEBUG - 2021-12-09 04:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:22:16 --> Final output sent to browser
DEBUG - 2021-12-09 04:22:16 --> Total execution time: 0.0760
INFO - 2021-12-09 04:22:18 --> Config Class Initialized
INFO - 2021-12-09 04:22:18 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:22:18 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:22:18 --> Utf8 Class Initialized
INFO - 2021-12-09 04:22:18 --> URI Class Initialized
INFO - 2021-12-09 04:22:18 --> Router Class Initialized
INFO - 2021-12-09 04:22:18 --> Output Class Initialized
INFO - 2021-12-09 04:22:18 --> Security Class Initialized
DEBUG - 2021-12-09 04:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:22:18 --> Input Class Initialized
INFO - 2021-12-09 04:22:18 --> Language Class Initialized
INFO - 2021-12-09 04:22:18 --> Language Class Initialized
INFO - 2021-12-09 04:22:18 --> Config Class Initialized
INFO - 2021-12-09 04:22:18 --> Loader Class Initialized
INFO - 2021-12-09 04:22:18 --> Helper loaded: url_helper
INFO - 2021-12-09 04:22:18 --> Helper loaded: file_helper
INFO - 2021-12-09 04:22:18 --> Helper loaded: form_helper
INFO - 2021-12-09 04:22:18 --> Helper loaded: my_helper
INFO - 2021-12-09 04:22:18 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:22:18 --> Controller Class Initialized
DEBUG - 2021-12-09 04:22:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:22:18 --> Final output sent to browser
DEBUG - 2021-12-09 04:22:18 --> Total execution time: 0.0650
INFO - 2021-12-09 04:22:40 --> Config Class Initialized
INFO - 2021-12-09 04:22:40 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:22:40 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:22:40 --> Utf8 Class Initialized
INFO - 2021-12-09 04:22:40 --> URI Class Initialized
INFO - 2021-12-09 04:22:40 --> Router Class Initialized
INFO - 2021-12-09 04:22:40 --> Output Class Initialized
INFO - 2021-12-09 04:22:40 --> Security Class Initialized
DEBUG - 2021-12-09 04:22:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:22:40 --> Input Class Initialized
INFO - 2021-12-09 04:22:40 --> Language Class Initialized
INFO - 2021-12-09 04:22:40 --> Language Class Initialized
INFO - 2021-12-09 04:22:40 --> Config Class Initialized
INFO - 2021-12-09 04:22:40 --> Loader Class Initialized
INFO - 2021-12-09 04:22:40 --> Helper loaded: url_helper
INFO - 2021-12-09 04:22:40 --> Helper loaded: file_helper
INFO - 2021-12-09 04:22:40 --> Helper loaded: form_helper
INFO - 2021-12-09 04:22:40 --> Helper loaded: my_helper
INFO - 2021-12-09 04:22:40 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:22:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:22:40 --> Controller Class Initialized
DEBUG - 2021-12-09 04:22:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:22:40 --> Final output sent to browser
DEBUG - 2021-12-09 04:22:40 --> Total execution time: 0.0570
INFO - 2021-12-09 04:23:09 --> Config Class Initialized
INFO - 2021-12-09 04:23:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:23:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:23:09 --> Utf8 Class Initialized
INFO - 2021-12-09 04:23:09 --> URI Class Initialized
INFO - 2021-12-09 04:23:09 --> Router Class Initialized
INFO - 2021-12-09 04:23:09 --> Output Class Initialized
INFO - 2021-12-09 04:23:09 --> Security Class Initialized
DEBUG - 2021-12-09 04:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:23:09 --> Input Class Initialized
INFO - 2021-12-09 04:23:09 --> Language Class Initialized
INFO - 2021-12-09 04:23:09 --> Language Class Initialized
INFO - 2021-12-09 04:23:09 --> Config Class Initialized
INFO - 2021-12-09 04:23:09 --> Loader Class Initialized
INFO - 2021-12-09 04:23:09 --> Helper loaded: url_helper
INFO - 2021-12-09 04:23:09 --> Helper loaded: file_helper
INFO - 2021-12-09 04:23:09 --> Helper loaded: form_helper
INFO - 2021-12-09 04:23:09 --> Helper loaded: my_helper
INFO - 2021-12-09 04:23:09 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:23:09 --> Controller Class Initialized
DEBUG - 2021-12-09 04:23:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:23:09 --> Final output sent to browser
DEBUG - 2021-12-09 04:23:09 --> Total execution time: 0.0740
INFO - 2021-12-09 04:23:37 --> Config Class Initialized
INFO - 2021-12-09 04:23:37 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:23:37 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:23:37 --> Utf8 Class Initialized
INFO - 2021-12-09 04:23:37 --> URI Class Initialized
INFO - 2021-12-09 04:23:37 --> Router Class Initialized
INFO - 2021-12-09 04:23:37 --> Output Class Initialized
INFO - 2021-12-09 04:23:37 --> Security Class Initialized
DEBUG - 2021-12-09 04:23:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:23:37 --> Input Class Initialized
INFO - 2021-12-09 04:23:37 --> Language Class Initialized
INFO - 2021-12-09 04:23:37 --> Language Class Initialized
INFO - 2021-12-09 04:23:37 --> Config Class Initialized
INFO - 2021-12-09 04:23:37 --> Loader Class Initialized
INFO - 2021-12-09 04:23:37 --> Helper loaded: url_helper
INFO - 2021-12-09 04:23:37 --> Helper loaded: file_helper
INFO - 2021-12-09 04:23:37 --> Helper loaded: form_helper
INFO - 2021-12-09 04:23:37 --> Helper loaded: my_helper
INFO - 2021-12-09 04:23:37 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:23:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:23:37 --> Controller Class Initialized
DEBUG - 2021-12-09 04:23:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:23:37 --> Final output sent to browser
DEBUG - 2021-12-09 04:23:37 --> Total execution time: 0.0700
INFO - 2021-12-09 04:30:44 --> Config Class Initialized
INFO - 2021-12-09 04:30:44 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:30:44 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:30:44 --> Utf8 Class Initialized
INFO - 2021-12-09 04:30:44 --> URI Class Initialized
INFO - 2021-12-09 04:30:44 --> Router Class Initialized
INFO - 2021-12-09 04:30:44 --> Output Class Initialized
INFO - 2021-12-09 04:30:44 --> Security Class Initialized
DEBUG - 2021-12-09 04:30:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:30:44 --> Input Class Initialized
INFO - 2021-12-09 04:30:44 --> Language Class Initialized
INFO - 2021-12-09 04:30:44 --> Language Class Initialized
INFO - 2021-12-09 04:30:44 --> Config Class Initialized
INFO - 2021-12-09 04:30:44 --> Loader Class Initialized
INFO - 2021-12-09 04:30:44 --> Helper loaded: url_helper
INFO - 2021-12-09 04:30:44 --> Helper loaded: file_helper
INFO - 2021-12-09 04:30:44 --> Helper loaded: form_helper
INFO - 2021-12-09 04:30:44 --> Helper loaded: my_helper
INFO - 2021-12-09 04:30:44 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:30:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:30:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:30:44 --> Controller Class Initialized
DEBUG - 2021-12-09 04:30:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:30:44 --> Final output sent to browser
DEBUG - 2021-12-09 04:30:44 --> Total execution time: 0.0670
INFO - 2021-12-09 04:31:00 --> Config Class Initialized
INFO - 2021-12-09 04:31:00 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:31:00 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:31:00 --> Utf8 Class Initialized
INFO - 2021-12-09 04:31:00 --> URI Class Initialized
INFO - 2021-12-09 04:31:00 --> Router Class Initialized
INFO - 2021-12-09 04:31:00 --> Output Class Initialized
INFO - 2021-12-09 04:31:00 --> Security Class Initialized
DEBUG - 2021-12-09 04:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:31:00 --> Input Class Initialized
INFO - 2021-12-09 04:31:00 --> Language Class Initialized
INFO - 2021-12-09 04:31:00 --> Language Class Initialized
INFO - 2021-12-09 04:31:00 --> Config Class Initialized
INFO - 2021-12-09 04:31:00 --> Loader Class Initialized
INFO - 2021-12-09 04:31:00 --> Helper loaded: url_helper
INFO - 2021-12-09 04:31:00 --> Helper loaded: file_helper
INFO - 2021-12-09 04:31:00 --> Helper loaded: form_helper
INFO - 2021-12-09 04:31:00 --> Helper loaded: my_helper
INFO - 2021-12-09 04:31:00 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:31:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:31:00 --> Controller Class Initialized
DEBUG - 2021-12-09 04:31:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:31:00 --> Final output sent to browser
DEBUG - 2021-12-09 04:31:00 --> Total execution time: 0.0590
INFO - 2021-12-09 04:32:17 --> Config Class Initialized
INFO - 2021-12-09 04:32:17 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:32:17 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:32:17 --> Utf8 Class Initialized
INFO - 2021-12-09 04:32:17 --> URI Class Initialized
INFO - 2021-12-09 04:32:17 --> Router Class Initialized
INFO - 2021-12-09 04:32:17 --> Output Class Initialized
INFO - 2021-12-09 04:32:17 --> Security Class Initialized
DEBUG - 2021-12-09 04:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:32:17 --> Input Class Initialized
INFO - 2021-12-09 04:32:17 --> Language Class Initialized
INFO - 2021-12-09 04:32:17 --> Language Class Initialized
INFO - 2021-12-09 04:32:17 --> Config Class Initialized
INFO - 2021-12-09 04:32:17 --> Loader Class Initialized
INFO - 2021-12-09 04:32:17 --> Helper loaded: url_helper
INFO - 2021-12-09 04:32:17 --> Helper loaded: file_helper
INFO - 2021-12-09 04:32:17 --> Helper loaded: form_helper
INFO - 2021-12-09 04:32:17 --> Helper loaded: my_helper
INFO - 2021-12-09 04:32:17 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:32:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:32:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:32:17 --> Controller Class Initialized
DEBUG - 2021-12-09 04:32:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:32:17 --> Final output sent to browser
DEBUG - 2021-12-09 04:32:17 --> Total execution time: 0.0530
INFO - 2021-12-09 04:32:26 --> Config Class Initialized
INFO - 2021-12-09 04:32:26 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:32:26 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:32:26 --> Utf8 Class Initialized
INFO - 2021-12-09 04:32:26 --> URI Class Initialized
INFO - 2021-12-09 04:32:26 --> Router Class Initialized
INFO - 2021-12-09 04:32:27 --> Output Class Initialized
INFO - 2021-12-09 04:32:27 --> Security Class Initialized
DEBUG - 2021-12-09 04:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:32:27 --> Input Class Initialized
INFO - 2021-12-09 04:32:27 --> Language Class Initialized
INFO - 2021-12-09 04:32:27 --> Language Class Initialized
INFO - 2021-12-09 04:32:27 --> Config Class Initialized
INFO - 2021-12-09 04:32:27 --> Loader Class Initialized
INFO - 2021-12-09 04:32:27 --> Helper loaded: url_helper
INFO - 2021-12-09 04:32:27 --> Helper loaded: file_helper
INFO - 2021-12-09 04:32:27 --> Helper loaded: form_helper
INFO - 2021-12-09 04:32:27 --> Helper loaded: my_helper
INFO - 2021-12-09 04:32:27 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:32:27 --> Controller Class Initialized
DEBUG - 2021-12-09 04:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:32:27 --> Final output sent to browser
DEBUG - 2021-12-09 04:32:27 --> Total execution time: 0.0730
INFO - 2021-12-09 04:34:25 --> Config Class Initialized
INFO - 2021-12-09 04:34:25 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:34:25 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:34:25 --> Utf8 Class Initialized
INFO - 2021-12-09 04:34:25 --> URI Class Initialized
INFO - 2021-12-09 04:34:25 --> Router Class Initialized
INFO - 2021-12-09 04:34:25 --> Output Class Initialized
INFO - 2021-12-09 04:34:25 --> Security Class Initialized
DEBUG - 2021-12-09 04:34:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:34:25 --> Input Class Initialized
INFO - 2021-12-09 04:34:25 --> Language Class Initialized
INFO - 2021-12-09 04:34:25 --> Language Class Initialized
INFO - 2021-12-09 04:34:25 --> Config Class Initialized
INFO - 2021-12-09 04:34:25 --> Loader Class Initialized
INFO - 2021-12-09 04:34:25 --> Helper loaded: url_helper
INFO - 2021-12-09 04:34:25 --> Helper loaded: file_helper
INFO - 2021-12-09 04:34:25 --> Helper loaded: form_helper
INFO - 2021-12-09 04:34:25 --> Helper loaded: my_helper
INFO - 2021-12-09 04:34:25 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:34:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:34:25 --> Controller Class Initialized
DEBUG - 2021-12-09 04:34:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:34:25 --> Final output sent to browser
DEBUG - 2021-12-09 04:34:25 --> Total execution time: 0.0740
INFO - 2021-12-09 04:38:58 --> Config Class Initialized
INFO - 2021-12-09 04:38:58 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:38:58 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:38:58 --> Utf8 Class Initialized
INFO - 2021-12-09 04:38:58 --> URI Class Initialized
INFO - 2021-12-09 04:38:58 --> Router Class Initialized
INFO - 2021-12-09 04:38:58 --> Output Class Initialized
INFO - 2021-12-09 04:38:58 --> Security Class Initialized
DEBUG - 2021-12-09 04:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:38:58 --> Input Class Initialized
INFO - 2021-12-09 04:38:58 --> Language Class Initialized
INFO - 2021-12-09 04:38:58 --> Language Class Initialized
INFO - 2021-12-09 04:38:58 --> Config Class Initialized
INFO - 2021-12-09 04:38:58 --> Loader Class Initialized
INFO - 2021-12-09 04:38:58 --> Helper loaded: url_helper
INFO - 2021-12-09 04:38:58 --> Helper loaded: file_helper
INFO - 2021-12-09 04:38:58 --> Helper loaded: form_helper
INFO - 2021-12-09 04:38:58 --> Helper loaded: my_helper
INFO - 2021-12-09 04:38:58 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:38:58 --> Controller Class Initialized
DEBUG - 2021-12-09 04:38:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:38:58 --> Final output sent to browser
DEBUG - 2021-12-09 04:38:58 --> Total execution time: 0.0670
INFO - 2021-12-09 04:39:15 --> Config Class Initialized
INFO - 2021-12-09 04:39:15 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:39:15 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:39:15 --> Utf8 Class Initialized
INFO - 2021-12-09 04:39:15 --> URI Class Initialized
INFO - 2021-12-09 04:39:15 --> Router Class Initialized
INFO - 2021-12-09 04:39:15 --> Output Class Initialized
INFO - 2021-12-09 04:39:15 --> Security Class Initialized
DEBUG - 2021-12-09 04:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:39:15 --> Input Class Initialized
INFO - 2021-12-09 04:39:15 --> Language Class Initialized
INFO - 2021-12-09 04:39:15 --> Language Class Initialized
INFO - 2021-12-09 04:39:15 --> Config Class Initialized
INFO - 2021-12-09 04:39:15 --> Loader Class Initialized
INFO - 2021-12-09 04:39:15 --> Helper loaded: url_helper
INFO - 2021-12-09 04:39:15 --> Helper loaded: file_helper
INFO - 2021-12-09 04:39:15 --> Helper loaded: form_helper
INFO - 2021-12-09 04:39:15 --> Helper loaded: my_helper
INFO - 2021-12-09 04:39:15 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:39:15 --> Controller Class Initialized
DEBUG - 2021-12-09 04:39:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:39:15 --> Final output sent to browser
DEBUG - 2021-12-09 04:39:15 --> Total execution time: 0.0700
INFO - 2021-12-09 04:39:29 --> Config Class Initialized
INFO - 2021-12-09 04:39:29 --> Hooks Class Initialized
DEBUG - 2021-12-09 04:39:29 --> UTF-8 Support Enabled
INFO - 2021-12-09 04:39:29 --> Utf8 Class Initialized
INFO - 2021-12-09 04:39:29 --> URI Class Initialized
INFO - 2021-12-09 04:39:29 --> Router Class Initialized
INFO - 2021-12-09 04:39:29 --> Output Class Initialized
INFO - 2021-12-09 04:39:29 --> Security Class Initialized
DEBUG - 2021-12-09 04:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 04:39:29 --> Input Class Initialized
INFO - 2021-12-09 04:39:29 --> Language Class Initialized
INFO - 2021-12-09 04:39:29 --> Language Class Initialized
INFO - 2021-12-09 04:39:29 --> Config Class Initialized
INFO - 2021-12-09 04:39:29 --> Loader Class Initialized
INFO - 2021-12-09 04:39:29 --> Helper loaded: url_helper
INFO - 2021-12-09 04:39:29 --> Helper loaded: file_helper
INFO - 2021-12-09 04:39:29 --> Helper loaded: form_helper
INFO - 2021-12-09 04:39:29 --> Helper loaded: my_helper
INFO - 2021-12-09 04:39:29 --> Database Driver Class Initialized
DEBUG - 2021-12-09 04:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 04:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 04:39:29 --> Controller Class Initialized
DEBUG - 2021-12-09 04:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 04:39:29 --> Final output sent to browser
DEBUG - 2021-12-09 04:39:29 --> Total execution time: 0.0630
INFO - 2021-12-09 05:07:30 --> Config Class Initialized
INFO - 2021-12-09 05:07:30 --> Hooks Class Initialized
DEBUG - 2021-12-09 05:07:30 --> UTF-8 Support Enabled
INFO - 2021-12-09 05:07:30 --> Utf8 Class Initialized
INFO - 2021-12-09 05:07:30 --> URI Class Initialized
INFO - 2021-12-09 05:07:30 --> Router Class Initialized
INFO - 2021-12-09 05:07:30 --> Output Class Initialized
INFO - 2021-12-09 05:07:30 --> Security Class Initialized
DEBUG - 2021-12-09 05:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 05:07:30 --> Input Class Initialized
INFO - 2021-12-09 05:07:30 --> Language Class Initialized
INFO - 2021-12-09 05:07:30 --> Language Class Initialized
INFO - 2021-12-09 05:07:30 --> Config Class Initialized
INFO - 2021-12-09 05:07:30 --> Loader Class Initialized
INFO - 2021-12-09 05:07:30 --> Helper loaded: url_helper
INFO - 2021-12-09 05:07:30 --> Helper loaded: file_helper
INFO - 2021-12-09 05:07:30 --> Helper loaded: form_helper
INFO - 2021-12-09 05:07:30 --> Helper loaded: my_helper
INFO - 2021-12-09 05:07:30 --> Database Driver Class Initialized
DEBUG - 2021-12-09 05:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 05:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 05:07:30 --> Controller Class Initialized
DEBUG - 2021-12-09 05:07:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 05:07:30 --> Final output sent to browser
DEBUG - 2021-12-09 05:07:30 --> Total execution time: 0.0630
INFO - 2021-12-09 05:10:20 --> Config Class Initialized
INFO - 2021-12-09 05:10:20 --> Hooks Class Initialized
DEBUG - 2021-12-09 05:10:20 --> UTF-8 Support Enabled
INFO - 2021-12-09 05:10:20 --> Utf8 Class Initialized
INFO - 2021-12-09 05:10:20 --> URI Class Initialized
INFO - 2021-12-09 05:10:20 --> Router Class Initialized
INFO - 2021-12-09 05:10:20 --> Output Class Initialized
INFO - 2021-12-09 05:10:20 --> Security Class Initialized
DEBUG - 2021-12-09 05:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 05:10:20 --> Input Class Initialized
INFO - 2021-12-09 05:10:20 --> Language Class Initialized
INFO - 2021-12-09 05:10:20 --> Language Class Initialized
INFO - 2021-12-09 05:10:20 --> Config Class Initialized
INFO - 2021-12-09 05:10:20 --> Loader Class Initialized
INFO - 2021-12-09 05:10:20 --> Helper loaded: url_helper
INFO - 2021-12-09 05:10:20 --> Helper loaded: file_helper
INFO - 2021-12-09 05:10:20 --> Helper loaded: form_helper
INFO - 2021-12-09 05:10:20 --> Helper loaded: my_helper
INFO - 2021-12-09 05:10:20 --> Database Driver Class Initialized
DEBUG - 2021-12-09 05:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 05:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 05:10:20 --> Controller Class Initialized
DEBUG - 2021-12-09 05:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 05:10:20 --> Final output sent to browser
DEBUG - 2021-12-09 05:10:20 --> Total execution time: 0.0780
INFO - 2021-12-09 05:16:06 --> Config Class Initialized
INFO - 2021-12-09 05:16:06 --> Hooks Class Initialized
DEBUG - 2021-12-09 05:16:06 --> UTF-8 Support Enabled
INFO - 2021-12-09 05:16:06 --> Utf8 Class Initialized
INFO - 2021-12-09 05:16:06 --> URI Class Initialized
INFO - 2021-12-09 05:16:06 --> Router Class Initialized
INFO - 2021-12-09 05:16:06 --> Output Class Initialized
INFO - 2021-12-09 05:16:06 --> Security Class Initialized
DEBUG - 2021-12-09 05:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 05:16:06 --> Input Class Initialized
INFO - 2021-12-09 05:16:06 --> Language Class Initialized
INFO - 2021-12-09 05:16:06 --> Language Class Initialized
INFO - 2021-12-09 05:16:06 --> Config Class Initialized
INFO - 2021-12-09 05:16:06 --> Loader Class Initialized
INFO - 2021-12-09 05:16:06 --> Helper loaded: url_helper
INFO - 2021-12-09 05:16:06 --> Helper loaded: file_helper
INFO - 2021-12-09 05:16:06 --> Helper loaded: form_helper
INFO - 2021-12-09 05:16:06 --> Helper loaded: my_helper
INFO - 2021-12-09 05:16:06 --> Database Driver Class Initialized
DEBUG - 2021-12-09 05:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 05:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 05:16:06 --> Controller Class Initialized
DEBUG - 2021-12-09 05:16:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 05:16:06 --> Final output sent to browser
DEBUG - 2021-12-09 05:16:06 --> Total execution time: 0.0720
INFO - 2021-12-09 05:32:09 --> Config Class Initialized
INFO - 2021-12-09 05:32:09 --> Hooks Class Initialized
DEBUG - 2021-12-09 05:32:09 --> UTF-8 Support Enabled
INFO - 2021-12-09 05:32:09 --> Utf8 Class Initialized
INFO - 2021-12-09 05:32:09 --> URI Class Initialized
INFO - 2021-12-09 05:32:09 --> Router Class Initialized
INFO - 2021-12-09 05:32:09 --> Output Class Initialized
INFO - 2021-12-09 05:32:09 --> Security Class Initialized
DEBUG - 2021-12-09 05:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-09 05:32:09 --> Input Class Initialized
INFO - 2021-12-09 05:32:09 --> Language Class Initialized
INFO - 2021-12-09 05:32:09 --> Language Class Initialized
INFO - 2021-12-09 05:32:09 --> Config Class Initialized
INFO - 2021-12-09 05:32:09 --> Loader Class Initialized
INFO - 2021-12-09 05:32:09 --> Helper loaded: url_helper
INFO - 2021-12-09 05:32:09 --> Helper loaded: file_helper
INFO - 2021-12-09 05:32:09 --> Helper loaded: form_helper
INFO - 2021-12-09 05:32:09 --> Helper loaded: my_helper
INFO - 2021-12-09 05:32:09 --> Database Driver Class Initialized
DEBUG - 2021-12-09 05:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-09 05:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-09 05:32:09 --> Controller Class Initialized
DEBUG - 2021-12-09 05:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-09 05:32:09 --> Final output sent to browser
DEBUG - 2021-12-09 05:32:09 --> Total execution time: 0.0630
