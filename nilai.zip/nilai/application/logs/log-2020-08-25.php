<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-08-25 03:15:51 --> Config Class Initialized
INFO - 2020-08-25 03:15:51 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:15:51 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:15:51 --> Utf8 Class Initialized
INFO - 2020-08-25 03:15:51 --> URI Class Initialized
INFO - 2020-08-25 03:15:51 --> Router Class Initialized
INFO - 2020-08-25 03:15:51 --> Output Class Initialized
INFO - 2020-08-25 03:15:51 --> Security Class Initialized
DEBUG - 2020-08-25 03:15:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:15:51 --> Input Class Initialized
INFO - 2020-08-25 03:15:51 --> Language Class Initialized
INFO - 2020-08-25 03:15:51 --> Language Class Initialized
INFO - 2020-08-25 03:15:51 --> Config Class Initialized
INFO - 2020-08-25 03:15:51 --> Loader Class Initialized
INFO - 2020-08-25 03:15:51 --> Helper loaded: url_helper
INFO - 2020-08-25 03:15:51 --> Helper loaded: file_helper
INFO - 2020-08-25 03:15:51 --> Helper loaded: form_helper
INFO - 2020-08-25 03:15:51 --> Helper loaded: my_helper
INFO - 2020-08-25 03:15:51 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:15:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:15:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:15:51 --> Controller Class Initialized
DEBUG - 2020-08-25 03:15:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:15:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:15:51 --> Final output sent to browser
DEBUG - 2020-08-25 03:15:51 --> Total execution time: 0.0657
INFO - 2020-08-25 03:16:47 --> Config Class Initialized
INFO - 2020-08-25 03:16:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:16:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:16:47 --> Utf8 Class Initialized
INFO - 2020-08-25 03:16:47 --> URI Class Initialized
INFO - 2020-08-25 03:16:47 --> Router Class Initialized
INFO - 2020-08-25 03:16:47 --> Output Class Initialized
INFO - 2020-08-25 03:16:47 --> Security Class Initialized
DEBUG - 2020-08-25 03:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:16:47 --> Input Class Initialized
INFO - 2020-08-25 03:16:47 --> Language Class Initialized
INFO - 2020-08-25 03:16:47 --> Language Class Initialized
INFO - 2020-08-25 03:16:47 --> Config Class Initialized
INFO - 2020-08-25 03:16:47 --> Loader Class Initialized
INFO - 2020-08-25 03:16:47 --> Helper loaded: url_helper
INFO - 2020-08-25 03:16:47 --> Helper loaded: file_helper
INFO - 2020-08-25 03:16:47 --> Helper loaded: form_helper
INFO - 2020-08-25 03:16:47 --> Helper loaded: my_helper
INFO - 2020-08-25 03:16:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:16:47 --> Controller Class Initialized
INFO - 2020-08-25 03:16:48 --> Final output sent to browser
DEBUG - 2020-08-25 03:16:48 --> Total execution time: 0.2731
INFO - 2020-08-25 03:16:54 --> Config Class Initialized
INFO - 2020-08-25 03:16:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:16:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:16:54 --> Utf8 Class Initialized
INFO - 2020-08-25 03:16:54 --> URI Class Initialized
INFO - 2020-08-25 03:16:54 --> Router Class Initialized
INFO - 2020-08-25 03:16:54 --> Output Class Initialized
INFO - 2020-08-25 03:16:54 --> Security Class Initialized
DEBUG - 2020-08-25 03:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:16:54 --> Input Class Initialized
INFO - 2020-08-25 03:16:54 --> Language Class Initialized
INFO - 2020-08-25 03:16:54 --> Language Class Initialized
INFO - 2020-08-25 03:16:54 --> Config Class Initialized
INFO - 2020-08-25 03:16:54 --> Loader Class Initialized
INFO - 2020-08-25 03:16:54 --> Helper loaded: url_helper
INFO - 2020-08-25 03:16:54 --> Helper loaded: file_helper
INFO - 2020-08-25 03:16:54 --> Helper loaded: form_helper
INFO - 2020-08-25 03:16:54 --> Helper loaded: my_helper
INFO - 2020-08-25 03:16:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:16:54 --> Controller Class Initialized
INFO - 2020-08-25 03:16:54 --> Final output sent to browser
DEBUG - 2020-08-25 03:16:54 --> Total execution time: 0.1686
INFO - 2020-08-25 03:17:08 --> Config Class Initialized
INFO - 2020-08-25 03:17:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:17:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:17:08 --> Utf8 Class Initialized
INFO - 2020-08-25 03:17:08 --> URI Class Initialized
INFO - 2020-08-25 03:17:08 --> Router Class Initialized
INFO - 2020-08-25 03:17:08 --> Output Class Initialized
INFO - 2020-08-25 03:17:08 --> Security Class Initialized
DEBUG - 2020-08-25 03:17:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:17:08 --> Input Class Initialized
INFO - 2020-08-25 03:17:08 --> Language Class Initialized
INFO - 2020-08-25 03:17:08 --> Language Class Initialized
INFO - 2020-08-25 03:17:08 --> Config Class Initialized
INFO - 2020-08-25 03:17:08 --> Loader Class Initialized
INFO - 2020-08-25 03:17:08 --> Helper loaded: url_helper
INFO - 2020-08-25 03:17:08 --> Helper loaded: file_helper
INFO - 2020-08-25 03:17:08 --> Helper loaded: form_helper
INFO - 2020-08-25 03:17:08 --> Helper loaded: my_helper
INFO - 2020-08-25 03:17:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:17:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:17:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:17:08 --> Controller Class Initialized
INFO - 2020-08-25 03:17:08 --> Final output sent to browser
DEBUG - 2020-08-25 03:17:08 --> Total execution time: 0.1936
INFO - 2020-08-25 03:17:21 --> Config Class Initialized
INFO - 2020-08-25 03:17:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:17:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:17:21 --> Utf8 Class Initialized
INFO - 2020-08-25 03:17:21 --> URI Class Initialized
INFO - 2020-08-25 03:17:21 --> Router Class Initialized
INFO - 2020-08-25 03:17:21 --> Output Class Initialized
INFO - 2020-08-25 03:17:21 --> Security Class Initialized
DEBUG - 2020-08-25 03:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:17:21 --> Input Class Initialized
INFO - 2020-08-25 03:17:21 --> Language Class Initialized
INFO - 2020-08-25 03:17:21 --> Language Class Initialized
INFO - 2020-08-25 03:17:21 --> Config Class Initialized
INFO - 2020-08-25 03:17:21 --> Loader Class Initialized
INFO - 2020-08-25 03:17:21 --> Helper loaded: url_helper
INFO - 2020-08-25 03:17:21 --> Helper loaded: file_helper
INFO - 2020-08-25 03:17:21 --> Helper loaded: form_helper
INFO - 2020-08-25 03:17:21 --> Helper loaded: my_helper
INFO - 2020-08-25 03:17:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:17:21 --> Controller Class Initialized
INFO - 2020-08-25 03:17:21 --> Final output sent to browser
DEBUG - 2020-08-25 03:17:21 --> Total execution time: 0.2071
INFO - 2020-08-25 03:17:37 --> Config Class Initialized
INFO - 2020-08-25 03:17:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:17:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:17:37 --> Utf8 Class Initialized
INFO - 2020-08-25 03:17:37 --> URI Class Initialized
INFO - 2020-08-25 03:17:37 --> Router Class Initialized
INFO - 2020-08-25 03:17:37 --> Output Class Initialized
INFO - 2020-08-25 03:17:37 --> Security Class Initialized
DEBUG - 2020-08-25 03:17:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:17:37 --> Input Class Initialized
INFO - 2020-08-25 03:17:37 --> Language Class Initialized
INFO - 2020-08-25 03:17:37 --> Language Class Initialized
INFO - 2020-08-25 03:17:37 --> Config Class Initialized
INFO - 2020-08-25 03:17:37 --> Loader Class Initialized
INFO - 2020-08-25 03:17:37 --> Helper loaded: url_helper
INFO - 2020-08-25 03:17:37 --> Helper loaded: file_helper
INFO - 2020-08-25 03:17:37 --> Helper loaded: form_helper
INFO - 2020-08-25 03:17:37 --> Helper loaded: my_helper
INFO - 2020-08-25 03:17:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:17:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:17:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:17:37 --> Controller Class Initialized
INFO - 2020-08-25 03:17:37 --> Final output sent to browser
DEBUG - 2020-08-25 03:17:37 --> Total execution time: 0.1646
INFO - 2020-08-25 03:17:38 --> Config Class Initialized
INFO - 2020-08-25 03:17:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:17:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:17:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:17:38 --> URI Class Initialized
INFO - 2020-08-25 03:17:38 --> Router Class Initialized
INFO - 2020-08-25 03:17:38 --> Output Class Initialized
INFO - 2020-08-25 03:17:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:17:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:17:38 --> Input Class Initialized
INFO - 2020-08-25 03:17:38 --> Language Class Initialized
INFO - 2020-08-25 03:17:38 --> Language Class Initialized
INFO - 2020-08-25 03:17:38 --> Config Class Initialized
INFO - 2020-08-25 03:17:38 --> Loader Class Initialized
INFO - 2020-08-25 03:17:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:17:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:17:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:17:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:17:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:17:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:17:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:17:38 --> Controller Class Initialized
INFO - 2020-08-25 03:17:38 --> Final output sent to browser
DEBUG - 2020-08-25 03:17:38 --> Total execution time: 0.1777
INFO - 2020-08-25 03:17:41 --> Config Class Initialized
INFO - 2020-08-25 03:17:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:17:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:17:41 --> Utf8 Class Initialized
INFO - 2020-08-25 03:17:41 --> URI Class Initialized
INFO - 2020-08-25 03:17:41 --> Router Class Initialized
INFO - 2020-08-25 03:17:41 --> Output Class Initialized
INFO - 2020-08-25 03:17:41 --> Security Class Initialized
DEBUG - 2020-08-25 03:17:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:17:41 --> Input Class Initialized
INFO - 2020-08-25 03:17:41 --> Language Class Initialized
INFO - 2020-08-25 03:17:41 --> Language Class Initialized
INFO - 2020-08-25 03:17:41 --> Config Class Initialized
INFO - 2020-08-25 03:17:41 --> Loader Class Initialized
INFO - 2020-08-25 03:17:41 --> Helper loaded: url_helper
INFO - 2020-08-25 03:17:41 --> Helper loaded: file_helper
INFO - 2020-08-25 03:17:41 --> Helper loaded: form_helper
INFO - 2020-08-25 03:17:41 --> Helper loaded: my_helper
INFO - 2020-08-25 03:17:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:17:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:17:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:17:41 --> Controller Class Initialized
INFO - 2020-08-25 03:17:42 --> Final output sent to browser
DEBUG - 2020-08-25 03:17:42 --> Total execution time: 0.1739
INFO - 2020-08-25 03:17:44 --> Config Class Initialized
INFO - 2020-08-25 03:17:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:17:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:17:44 --> Utf8 Class Initialized
INFO - 2020-08-25 03:17:44 --> URI Class Initialized
INFO - 2020-08-25 03:17:44 --> Router Class Initialized
INFO - 2020-08-25 03:17:44 --> Output Class Initialized
INFO - 2020-08-25 03:17:44 --> Security Class Initialized
DEBUG - 2020-08-25 03:17:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:17:44 --> Input Class Initialized
INFO - 2020-08-25 03:17:44 --> Language Class Initialized
INFO - 2020-08-25 03:17:44 --> Language Class Initialized
INFO - 2020-08-25 03:17:44 --> Config Class Initialized
INFO - 2020-08-25 03:17:44 --> Loader Class Initialized
INFO - 2020-08-25 03:17:44 --> Helper loaded: url_helper
INFO - 2020-08-25 03:17:44 --> Helper loaded: file_helper
INFO - 2020-08-25 03:17:44 --> Helper loaded: form_helper
INFO - 2020-08-25 03:17:44 --> Helper loaded: my_helper
INFO - 2020-08-25 03:17:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:17:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:17:44 --> Controller Class Initialized
INFO - 2020-08-25 03:17:44 --> Final output sent to browser
DEBUG - 2020-08-25 03:17:44 --> Total execution time: 0.1790
INFO - 2020-08-25 03:18:04 --> Config Class Initialized
INFO - 2020-08-25 03:18:04 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:18:04 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:18:04 --> Utf8 Class Initialized
INFO - 2020-08-25 03:18:04 --> URI Class Initialized
INFO - 2020-08-25 03:18:04 --> Router Class Initialized
INFO - 2020-08-25 03:18:04 --> Output Class Initialized
INFO - 2020-08-25 03:18:04 --> Security Class Initialized
DEBUG - 2020-08-25 03:18:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:18:04 --> Input Class Initialized
INFO - 2020-08-25 03:18:04 --> Language Class Initialized
INFO - 2020-08-25 03:18:04 --> Language Class Initialized
INFO - 2020-08-25 03:18:04 --> Config Class Initialized
INFO - 2020-08-25 03:18:04 --> Loader Class Initialized
INFO - 2020-08-25 03:18:04 --> Helper loaded: url_helper
INFO - 2020-08-25 03:18:04 --> Helper loaded: file_helper
INFO - 2020-08-25 03:18:04 --> Helper loaded: form_helper
INFO - 2020-08-25 03:18:04 --> Helper loaded: my_helper
INFO - 2020-08-25 03:18:04 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:18:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:18:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:18:04 --> Controller Class Initialized
INFO - 2020-08-25 03:18:04 --> Final output sent to browser
DEBUG - 2020-08-25 03:18:04 --> Total execution time: 0.1650
INFO - 2020-08-25 03:18:31 --> Config Class Initialized
INFO - 2020-08-25 03:18:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:18:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:18:31 --> Utf8 Class Initialized
INFO - 2020-08-25 03:18:31 --> URI Class Initialized
INFO - 2020-08-25 03:18:31 --> Router Class Initialized
INFO - 2020-08-25 03:18:31 --> Output Class Initialized
INFO - 2020-08-25 03:18:31 --> Security Class Initialized
DEBUG - 2020-08-25 03:18:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:18:31 --> Input Class Initialized
INFO - 2020-08-25 03:18:31 --> Language Class Initialized
INFO - 2020-08-25 03:18:31 --> Language Class Initialized
INFO - 2020-08-25 03:18:31 --> Config Class Initialized
INFO - 2020-08-25 03:18:31 --> Loader Class Initialized
INFO - 2020-08-25 03:18:31 --> Helper loaded: url_helper
INFO - 2020-08-25 03:18:31 --> Helper loaded: file_helper
INFO - 2020-08-25 03:18:31 --> Helper loaded: form_helper
INFO - 2020-08-25 03:18:31 --> Helper loaded: my_helper
INFO - 2020-08-25 03:18:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:18:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:18:31 --> Controller Class Initialized
INFO - 2020-08-25 03:18:31 --> Final output sent to browser
DEBUG - 2020-08-25 03:18:31 --> Total execution time: 0.1681
INFO - 2020-08-25 03:18:32 --> Config Class Initialized
INFO - 2020-08-25 03:18:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:18:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:18:32 --> Utf8 Class Initialized
INFO - 2020-08-25 03:18:32 --> URI Class Initialized
INFO - 2020-08-25 03:18:32 --> Router Class Initialized
INFO - 2020-08-25 03:18:32 --> Output Class Initialized
INFO - 2020-08-25 03:18:32 --> Security Class Initialized
DEBUG - 2020-08-25 03:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:18:32 --> Input Class Initialized
INFO - 2020-08-25 03:18:32 --> Language Class Initialized
INFO - 2020-08-25 03:18:33 --> Language Class Initialized
INFO - 2020-08-25 03:18:33 --> Config Class Initialized
INFO - 2020-08-25 03:18:33 --> Loader Class Initialized
INFO - 2020-08-25 03:18:33 --> Helper loaded: url_helper
INFO - 2020-08-25 03:18:33 --> Helper loaded: file_helper
INFO - 2020-08-25 03:18:33 --> Helper loaded: form_helper
INFO - 2020-08-25 03:18:33 --> Helper loaded: my_helper
INFO - 2020-08-25 03:18:33 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:18:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:18:33 --> Controller Class Initialized
INFO - 2020-08-25 03:18:33 --> Final output sent to browser
DEBUG - 2020-08-25 03:18:33 --> Total execution time: 0.1752
INFO - 2020-08-25 03:18:34 --> Config Class Initialized
INFO - 2020-08-25 03:18:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:18:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:18:34 --> Utf8 Class Initialized
INFO - 2020-08-25 03:18:34 --> URI Class Initialized
INFO - 2020-08-25 03:18:34 --> Router Class Initialized
INFO - 2020-08-25 03:18:34 --> Output Class Initialized
INFO - 2020-08-25 03:18:34 --> Security Class Initialized
DEBUG - 2020-08-25 03:18:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:18:34 --> Input Class Initialized
INFO - 2020-08-25 03:18:34 --> Language Class Initialized
INFO - 2020-08-25 03:18:34 --> Language Class Initialized
INFO - 2020-08-25 03:18:34 --> Config Class Initialized
INFO - 2020-08-25 03:18:34 --> Loader Class Initialized
INFO - 2020-08-25 03:18:34 --> Helper loaded: url_helper
INFO - 2020-08-25 03:18:34 --> Helper loaded: file_helper
INFO - 2020-08-25 03:18:34 --> Helper loaded: form_helper
INFO - 2020-08-25 03:18:34 --> Helper loaded: my_helper
INFO - 2020-08-25 03:18:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:18:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:18:34 --> Controller Class Initialized
INFO - 2020-08-25 03:18:34 --> Final output sent to browser
DEBUG - 2020-08-25 03:18:34 --> Total execution time: 0.1686
INFO - 2020-08-25 03:18:36 --> Config Class Initialized
INFO - 2020-08-25 03:18:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:18:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:18:36 --> Utf8 Class Initialized
INFO - 2020-08-25 03:18:36 --> URI Class Initialized
INFO - 2020-08-25 03:18:36 --> Router Class Initialized
INFO - 2020-08-25 03:18:36 --> Output Class Initialized
INFO - 2020-08-25 03:18:36 --> Security Class Initialized
DEBUG - 2020-08-25 03:18:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:18:36 --> Input Class Initialized
INFO - 2020-08-25 03:18:36 --> Language Class Initialized
INFO - 2020-08-25 03:18:36 --> Language Class Initialized
INFO - 2020-08-25 03:18:36 --> Config Class Initialized
INFO - 2020-08-25 03:18:36 --> Loader Class Initialized
INFO - 2020-08-25 03:18:36 --> Helper loaded: url_helper
INFO - 2020-08-25 03:18:36 --> Helper loaded: file_helper
INFO - 2020-08-25 03:18:36 --> Helper loaded: form_helper
INFO - 2020-08-25 03:18:36 --> Helper loaded: my_helper
INFO - 2020-08-25 03:18:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:18:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:18:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:18:36 --> Controller Class Initialized
INFO - 2020-08-25 03:18:36 --> Final output sent to browser
DEBUG - 2020-08-25 03:18:36 --> Total execution time: 0.1768
INFO - 2020-08-25 03:18:38 --> Config Class Initialized
INFO - 2020-08-25 03:18:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:18:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:18:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:18:38 --> URI Class Initialized
INFO - 2020-08-25 03:18:38 --> Router Class Initialized
INFO - 2020-08-25 03:18:38 --> Output Class Initialized
INFO - 2020-08-25 03:18:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:18:38 --> Input Class Initialized
INFO - 2020-08-25 03:18:38 --> Language Class Initialized
INFO - 2020-08-25 03:18:38 --> Language Class Initialized
INFO - 2020-08-25 03:18:38 --> Config Class Initialized
INFO - 2020-08-25 03:18:38 --> Loader Class Initialized
INFO - 2020-08-25 03:18:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:18:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:18:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:18:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:18:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:18:38 --> Controller Class Initialized
INFO - 2020-08-25 03:18:38 --> Final output sent to browser
DEBUG - 2020-08-25 03:18:38 --> Total execution time: 0.1750
INFO - 2020-08-25 03:18:56 --> Config Class Initialized
INFO - 2020-08-25 03:18:56 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:18:56 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:18:56 --> Utf8 Class Initialized
INFO - 2020-08-25 03:18:56 --> URI Class Initialized
INFO - 2020-08-25 03:18:56 --> Router Class Initialized
INFO - 2020-08-25 03:18:56 --> Output Class Initialized
INFO - 2020-08-25 03:18:56 --> Security Class Initialized
DEBUG - 2020-08-25 03:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:18:56 --> Input Class Initialized
INFO - 2020-08-25 03:18:56 --> Language Class Initialized
INFO - 2020-08-25 03:18:56 --> Language Class Initialized
INFO - 2020-08-25 03:18:56 --> Config Class Initialized
INFO - 2020-08-25 03:18:56 --> Loader Class Initialized
INFO - 2020-08-25 03:18:56 --> Helper loaded: url_helper
INFO - 2020-08-25 03:18:56 --> Helper loaded: file_helper
INFO - 2020-08-25 03:18:56 --> Helper loaded: form_helper
INFO - 2020-08-25 03:18:56 --> Helper loaded: my_helper
INFO - 2020-08-25 03:18:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:18:56 --> Controller Class Initialized
DEBUG - 2020-08-25 03:18:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:18:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:18:56 --> Final output sent to browser
DEBUG - 2020-08-25 03:18:56 --> Total execution time: 0.0656
INFO - 2020-08-25 03:19:23 --> Config Class Initialized
INFO - 2020-08-25 03:19:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:19:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:19:23 --> Utf8 Class Initialized
INFO - 2020-08-25 03:19:23 --> URI Class Initialized
INFO - 2020-08-25 03:19:23 --> Router Class Initialized
INFO - 2020-08-25 03:19:23 --> Output Class Initialized
INFO - 2020-08-25 03:19:23 --> Security Class Initialized
DEBUG - 2020-08-25 03:19:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:19:23 --> Input Class Initialized
INFO - 2020-08-25 03:19:23 --> Language Class Initialized
INFO - 2020-08-25 03:19:23 --> Language Class Initialized
INFO - 2020-08-25 03:19:23 --> Config Class Initialized
INFO - 2020-08-25 03:19:23 --> Loader Class Initialized
INFO - 2020-08-25 03:19:23 --> Helper loaded: url_helper
INFO - 2020-08-25 03:19:23 --> Helper loaded: file_helper
INFO - 2020-08-25 03:19:23 --> Helper loaded: form_helper
INFO - 2020-08-25 03:19:23 --> Helper loaded: my_helper
INFO - 2020-08-25 03:19:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:19:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:19:23 --> Controller Class Initialized
INFO - 2020-08-25 03:19:23 --> Final output sent to browser
DEBUG - 2020-08-25 03:19:23 --> Total execution time: 0.1838
INFO - 2020-08-25 03:19:27 --> Config Class Initialized
INFO - 2020-08-25 03:19:27 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:19:27 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:19:27 --> Utf8 Class Initialized
INFO - 2020-08-25 03:19:27 --> URI Class Initialized
INFO - 2020-08-25 03:19:27 --> Router Class Initialized
INFO - 2020-08-25 03:19:27 --> Output Class Initialized
INFO - 2020-08-25 03:19:27 --> Security Class Initialized
DEBUG - 2020-08-25 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:19:27 --> Input Class Initialized
INFO - 2020-08-25 03:19:27 --> Language Class Initialized
INFO - 2020-08-25 03:19:27 --> Language Class Initialized
INFO - 2020-08-25 03:19:27 --> Config Class Initialized
INFO - 2020-08-25 03:19:27 --> Loader Class Initialized
INFO - 2020-08-25 03:19:27 --> Helper loaded: url_helper
INFO - 2020-08-25 03:19:27 --> Helper loaded: file_helper
INFO - 2020-08-25 03:19:27 --> Helper loaded: form_helper
INFO - 2020-08-25 03:19:27 --> Helper loaded: my_helper
INFO - 2020-08-25 03:19:27 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:19:27 --> Controller Class Initialized
INFO - 2020-08-25 03:19:27 --> Final output sent to browser
DEBUG - 2020-08-25 03:19:27 --> Total execution time: 0.1714
INFO - 2020-08-25 03:19:32 --> Config Class Initialized
INFO - 2020-08-25 03:19:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:19:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:19:32 --> Utf8 Class Initialized
INFO - 2020-08-25 03:19:32 --> URI Class Initialized
INFO - 2020-08-25 03:19:32 --> Router Class Initialized
INFO - 2020-08-25 03:19:32 --> Output Class Initialized
INFO - 2020-08-25 03:19:32 --> Security Class Initialized
DEBUG - 2020-08-25 03:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:19:32 --> Input Class Initialized
INFO - 2020-08-25 03:19:32 --> Language Class Initialized
INFO - 2020-08-25 03:19:32 --> Language Class Initialized
INFO - 2020-08-25 03:19:32 --> Config Class Initialized
INFO - 2020-08-25 03:19:32 --> Loader Class Initialized
INFO - 2020-08-25 03:19:32 --> Helper loaded: url_helper
INFO - 2020-08-25 03:19:32 --> Helper loaded: file_helper
INFO - 2020-08-25 03:19:32 --> Helper loaded: form_helper
INFO - 2020-08-25 03:19:32 --> Helper loaded: my_helper
INFO - 2020-08-25 03:19:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:19:32 --> Controller Class Initialized
DEBUG - 2020-08-25 03:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-25 03:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:19:32 --> Final output sent to browser
DEBUG - 2020-08-25 03:19:32 --> Total execution time: 0.0680
INFO - 2020-08-25 03:20:46 --> Config Class Initialized
INFO - 2020-08-25 03:20:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:20:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:20:46 --> Utf8 Class Initialized
INFO - 2020-08-25 03:20:46 --> URI Class Initialized
INFO - 2020-08-25 03:20:46 --> Router Class Initialized
INFO - 2020-08-25 03:20:46 --> Output Class Initialized
INFO - 2020-08-25 03:20:46 --> Security Class Initialized
DEBUG - 2020-08-25 03:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:20:46 --> Input Class Initialized
INFO - 2020-08-25 03:20:46 --> Language Class Initialized
INFO - 2020-08-25 03:20:46 --> Language Class Initialized
INFO - 2020-08-25 03:20:46 --> Config Class Initialized
INFO - 2020-08-25 03:20:46 --> Loader Class Initialized
INFO - 2020-08-25 03:20:46 --> Helper loaded: url_helper
INFO - 2020-08-25 03:20:46 --> Helper loaded: file_helper
INFO - 2020-08-25 03:20:46 --> Helper loaded: form_helper
INFO - 2020-08-25 03:20:46 --> Helper loaded: my_helper
INFO - 2020-08-25 03:20:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:20:46 --> Controller Class Initialized
INFO - 2020-08-25 03:20:46 --> Config Class Initialized
INFO - 2020-08-25 03:20:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:20:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:20:46 --> Utf8 Class Initialized
INFO - 2020-08-25 03:20:46 --> URI Class Initialized
INFO - 2020-08-25 03:20:46 --> Router Class Initialized
INFO - 2020-08-25 03:20:46 --> Output Class Initialized
INFO - 2020-08-25 03:20:46 --> Security Class Initialized
DEBUG - 2020-08-25 03:20:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:20:46 --> Input Class Initialized
INFO - 2020-08-25 03:20:46 --> Language Class Initialized
INFO - 2020-08-25 03:20:46 --> Language Class Initialized
INFO - 2020-08-25 03:20:46 --> Config Class Initialized
INFO - 2020-08-25 03:20:46 --> Loader Class Initialized
INFO - 2020-08-25 03:20:46 --> Helper loaded: url_helper
INFO - 2020-08-25 03:20:46 --> Helper loaded: file_helper
INFO - 2020-08-25 03:20:46 --> Helper loaded: form_helper
INFO - 2020-08-25 03:20:46 --> Helper loaded: my_helper
INFO - 2020-08-25 03:20:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:20:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:20:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:20:46 --> Controller Class Initialized
DEBUG - 2020-08-25 03:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:20:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:20:46 --> Final output sent to browser
DEBUG - 2020-08-25 03:20:46 --> Total execution time: 0.0622
INFO - 2020-08-25 03:21:20 --> Config Class Initialized
INFO - 2020-08-25 03:21:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:21:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:21:20 --> Utf8 Class Initialized
INFO - 2020-08-25 03:21:20 --> URI Class Initialized
INFO - 2020-08-25 03:21:20 --> Router Class Initialized
INFO - 2020-08-25 03:21:20 --> Output Class Initialized
INFO - 2020-08-25 03:21:20 --> Security Class Initialized
DEBUG - 2020-08-25 03:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:21:20 --> Input Class Initialized
INFO - 2020-08-25 03:21:20 --> Language Class Initialized
INFO - 2020-08-25 03:21:20 --> Language Class Initialized
INFO - 2020-08-25 03:21:20 --> Config Class Initialized
INFO - 2020-08-25 03:21:20 --> Loader Class Initialized
INFO - 2020-08-25 03:21:20 --> Helper loaded: url_helper
INFO - 2020-08-25 03:21:20 --> Helper loaded: file_helper
INFO - 2020-08-25 03:21:20 --> Helper loaded: form_helper
INFO - 2020-08-25 03:21:20 --> Helper loaded: my_helper
INFO - 2020-08-25 03:21:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:21:20 --> Controller Class Initialized
INFO - 2020-08-25 03:21:20 --> Final output sent to browser
DEBUG - 2020-08-25 03:21:20 --> Total execution time: 0.1832
INFO - 2020-08-25 03:21:23 --> Config Class Initialized
INFO - 2020-08-25 03:21:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:21:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:21:23 --> Utf8 Class Initialized
INFO - 2020-08-25 03:21:23 --> URI Class Initialized
INFO - 2020-08-25 03:21:23 --> Router Class Initialized
INFO - 2020-08-25 03:21:23 --> Output Class Initialized
INFO - 2020-08-25 03:21:23 --> Security Class Initialized
DEBUG - 2020-08-25 03:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:21:23 --> Input Class Initialized
INFO - 2020-08-25 03:21:23 --> Language Class Initialized
INFO - 2020-08-25 03:21:23 --> Language Class Initialized
INFO - 2020-08-25 03:21:23 --> Config Class Initialized
INFO - 2020-08-25 03:21:23 --> Loader Class Initialized
INFO - 2020-08-25 03:21:23 --> Helper loaded: url_helper
INFO - 2020-08-25 03:21:23 --> Helper loaded: file_helper
INFO - 2020-08-25 03:21:23 --> Helper loaded: form_helper
INFO - 2020-08-25 03:21:23 --> Helper loaded: my_helper
INFO - 2020-08-25 03:21:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:21:23 --> Controller Class Initialized
INFO - 2020-08-25 03:21:23 --> Final output sent to browser
DEBUG - 2020-08-25 03:21:23 --> Total execution time: 0.2325
INFO - 2020-08-25 03:21:48 --> Config Class Initialized
INFO - 2020-08-25 03:21:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:21:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:21:48 --> Utf8 Class Initialized
INFO - 2020-08-25 03:21:48 --> URI Class Initialized
INFO - 2020-08-25 03:21:48 --> Router Class Initialized
INFO - 2020-08-25 03:21:48 --> Output Class Initialized
INFO - 2020-08-25 03:21:48 --> Security Class Initialized
DEBUG - 2020-08-25 03:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:21:48 --> Input Class Initialized
INFO - 2020-08-25 03:21:48 --> Language Class Initialized
INFO - 2020-08-25 03:21:48 --> Language Class Initialized
INFO - 2020-08-25 03:21:48 --> Config Class Initialized
INFO - 2020-08-25 03:21:48 --> Loader Class Initialized
INFO - 2020-08-25 03:21:48 --> Helper loaded: url_helper
INFO - 2020-08-25 03:21:48 --> Helper loaded: file_helper
INFO - 2020-08-25 03:21:48 --> Helper loaded: form_helper
INFO - 2020-08-25 03:21:48 --> Helper loaded: my_helper
INFO - 2020-08-25 03:21:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:21:48 --> Controller Class Initialized
INFO - 2020-08-25 03:21:48 --> Final output sent to browser
DEBUG - 2020-08-25 03:21:48 --> Total execution time: 0.1741
INFO - 2020-08-25 03:21:49 --> Config Class Initialized
INFO - 2020-08-25 03:21:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:21:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:21:49 --> Utf8 Class Initialized
INFO - 2020-08-25 03:21:49 --> URI Class Initialized
INFO - 2020-08-25 03:21:49 --> Router Class Initialized
INFO - 2020-08-25 03:21:49 --> Output Class Initialized
INFO - 2020-08-25 03:21:49 --> Security Class Initialized
DEBUG - 2020-08-25 03:21:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:21:49 --> Input Class Initialized
INFO - 2020-08-25 03:21:49 --> Language Class Initialized
INFO - 2020-08-25 03:21:49 --> Language Class Initialized
INFO - 2020-08-25 03:21:49 --> Config Class Initialized
INFO - 2020-08-25 03:21:49 --> Loader Class Initialized
INFO - 2020-08-25 03:21:49 --> Helper loaded: url_helper
INFO - 2020-08-25 03:21:49 --> Helper loaded: file_helper
INFO - 2020-08-25 03:21:49 --> Helper loaded: form_helper
INFO - 2020-08-25 03:21:49 --> Helper loaded: my_helper
INFO - 2020-08-25 03:21:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:21:49 --> Controller Class Initialized
INFO - 2020-08-25 03:21:49 --> Final output sent to browser
DEBUG - 2020-08-25 03:21:49 --> Total execution time: 0.1683
INFO - 2020-08-25 03:21:52 --> Config Class Initialized
INFO - 2020-08-25 03:21:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:21:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:21:52 --> Utf8 Class Initialized
INFO - 2020-08-25 03:21:52 --> URI Class Initialized
INFO - 2020-08-25 03:21:52 --> Router Class Initialized
INFO - 2020-08-25 03:21:52 --> Output Class Initialized
INFO - 2020-08-25 03:21:52 --> Security Class Initialized
DEBUG - 2020-08-25 03:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:21:52 --> Input Class Initialized
INFO - 2020-08-25 03:21:52 --> Language Class Initialized
INFO - 2020-08-25 03:21:52 --> Language Class Initialized
INFO - 2020-08-25 03:21:52 --> Config Class Initialized
INFO - 2020-08-25 03:21:52 --> Loader Class Initialized
INFO - 2020-08-25 03:21:52 --> Helper loaded: url_helper
INFO - 2020-08-25 03:21:52 --> Helper loaded: file_helper
INFO - 2020-08-25 03:21:52 --> Helper loaded: form_helper
INFO - 2020-08-25 03:21:52 --> Helper loaded: my_helper
INFO - 2020-08-25 03:21:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:21:52 --> Controller Class Initialized
INFO - 2020-08-25 03:21:52 --> Final output sent to browser
DEBUG - 2020-08-25 03:21:52 --> Total execution time: 0.1600
INFO - 2020-08-25 03:21:54 --> Config Class Initialized
INFO - 2020-08-25 03:21:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:21:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:21:54 --> Utf8 Class Initialized
INFO - 2020-08-25 03:21:54 --> URI Class Initialized
INFO - 2020-08-25 03:21:54 --> Router Class Initialized
INFO - 2020-08-25 03:21:54 --> Output Class Initialized
INFO - 2020-08-25 03:21:54 --> Security Class Initialized
DEBUG - 2020-08-25 03:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:21:54 --> Input Class Initialized
INFO - 2020-08-25 03:21:54 --> Language Class Initialized
INFO - 2020-08-25 03:21:54 --> Language Class Initialized
INFO - 2020-08-25 03:21:54 --> Config Class Initialized
INFO - 2020-08-25 03:21:54 --> Loader Class Initialized
INFO - 2020-08-25 03:21:54 --> Helper loaded: url_helper
INFO - 2020-08-25 03:21:54 --> Helper loaded: file_helper
INFO - 2020-08-25 03:21:54 --> Helper loaded: form_helper
INFO - 2020-08-25 03:21:54 --> Helper loaded: my_helper
INFO - 2020-08-25 03:21:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:21:54 --> Controller Class Initialized
INFO - 2020-08-25 03:21:54 --> Final output sent to browser
DEBUG - 2020-08-25 03:21:54 --> Total execution time: 0.1821
INFO - 2020-08-25 03:22:12 --> Config Class Initialized
INFO - 2020-08-25 03:22:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:22:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:22:12 --> Utf8 Class Initialized
INFO - 2020-08-25 03:22:12 --> URI Class Initialized
INFO - 2020-08-25 03:22:12 --> Router Class Initialized
INFO - 2020-08-25 03:22:12 --> Output Class Initialized
INFO - 2020-08-25 03:22:12 --> Security Class Initialized
DEBUG - 2020-08-25 03:22:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:22:12 --> Input Class Initialized
INFO - 2020-08-25 03:22:12 --> Language Class Initialized
INFO - 2020-08-25 03:22:12 --> Language Class Initialized
INFO - 2020-08-25 03:22:12 --> Config Class Initialized
INFO - 2020-08-25 03:22:12 --> Loader Class Initialized
INFO - 2020-08-25 03:22:12 --> Helper loaded: url_helper
INFO - 2020-08-25 03:22:12 --> Helper loaded: file_helper
INFO - 2020-08-25 03:22:12 --> Helper loaded: form_helper
INFO - 2020-08-25 03:22:12 --> Helper loaded: my_helper
INFO - 2020-08-25 03:22:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:22:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:22:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:22:12 --> Controller Class Initialized
INFO - 2020-08-25 03:22:12 --> Final output sent to browser
DEBUG - 2020-08-25 03:22:12 --> Total execution time: 0.1810
INFO - 2020-08-25 03:22:26 --> Config Class Initialized
INFO - 2020-08-25 03:22:26 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:22:26 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:22:26 --> Utf8 Class Initialized
INFO - 2020-08-25 03:22:26 --> URI Class Initialized
INFO - 2020-08-25 03:22:26 --> Router Class Initialized
INFO - 2020-08-25 03:22:26 --> Output Class Initialized
INFO - 2020-08-25 03:22:26 --> Security Class Initialized
DEBUG - 2020-08-25 03:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:22:26 --> Input Class Initialized
INFO - 2020-08-25 03:22:26 --> Language Class Initialized
INFO - 2020-08-25 03:22:26 --> Language Class Initialized
INFO - 2020-08-25 03:22:26 --> Config Class Initialized
INFO - 2020-08-25 03:22:26 --> Loader Class Initialized
INFO - 2020-08-25 03:22:26 --> Helper loaded: url_helper
INFO - 2020-08-25 03:22:26 --> Helper loaded: file_helper
INFO - 2020-08-25 03:22:26 --> Helper loaded: form_helper
INFO - 2020-08-25 03:22:26 --> Helper loaded: my_helper
INFO - 2020-08-25 03:22:26 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:22:26 --> Controller Class Initialized
INFO - 2020-08-25 03:22:26 --> Final output sent to browser
DEBUG - 2020-08-25 03:22:26 --> Total execution time: 0.1740
INFO - 2020-08-25 03:22:28 --> Config Class Initialized
INFO - 2020-08-25 03:22:28 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:22:28 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:22:28 --> Utf8 Class Initialized
INFO - 2020-08-25 03:22:28 --> URI Class Initialized
INFO - 2020-08-25 03:22:28 --> Router Class Initialized
INFO - 2020-08-25 03:22:28 --> Output Class Initialized
INFO - 2020-08-25 03:22:28 --> Security Class Initialized
DEBUG - 2020-08-25 03:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:22:28 --> Input Class Initialized
INFO - 2020-08-25 03:22:28 --> Language Class Initialized
INFO - 2020-08-25 03:22:28 --> Language Class Initialized
INFO - 2020-08-25 03:22:28 --> Config Class Initialized
INFO - 2020-08-25 03:22:28 --> Loader Class Initialized
INFO - 2020-08-25 03:22:28 --> Helper loaded: url_helper
INFO - 2020-08-25 03:22:28 --> Helper loaded: file_helper
INFO - 2020-08-25 03:22:28 --> Helper loaded: form_helper
INFO - 2020-08-25 03:22:28 --> Helper loaded: my_helper
INFO - 2020-08-25 03:22:28 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:22:28 --> Controller Class Initialized
INFO - 2020-08-25 03:22:28 --> Final output sent to browser
DEBUG - 2020-08-25 03:22:28 --> Total execution time: 0.1638
INFO - 2020-08-25 03:22:31 --> Config Class Initialized
INFO - 2020-08-25 03:22:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:22:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:22:31 --> Utf8 Class Initialized
INFO - 2020-08-25 03:22:31 --> URI Class Initialized
INFO - 2020-08-25 03:22:31 --> Router Class Initialized
INFO - 2020-08-25 03:22:31 --> Output Class Initialized
INFO - 2020-08-25 03:22:31 --> Security Class Initialized
DEBUG - 2020-08-25 03:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:22:31 --> Input Class Initialized
INFO - 2020-08-25 03:22:31 --> Language Class Initialized
INFO - 2020-08-25 03:22:31 --> Language Class Initialized
INFO - 2020-08-25 03:22:31 --> Config Class Initialized
INFO - 2020-08-25 03:22:31 --> Loader Class Initialized
INFO - 2020-08-25 03:22:31 --> Helper loaded: url_helper
INFO - 2020-08-25 03:22:31 --> Helper loaded: file_helper
INFO - 2020-08-25 03:22:31 --> Helper loaded: form_helper
INFO - 2020-08-25 03:22:31 --> Helper loaded: my_helper
INFO - 2020-08-25 03:22:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:22:31 --> Controller Class Initialized
DEBUG - 2020-08-25 03:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:22:31 --> Final output sent to browser
DEBUG - 2020-08-25 03:22:31 --> Total execution time: 0.0739
INFO - 2020-08-25 03:22:54 --> Config Class Initialized
INFO - 2020-08-25 03:22:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:22:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:22:54 --> Utf8 Class Initialized
INFO - 2020-08-25 03:22:54 --> URI Class Initialized
INFO - 2020-08-25 03:22:54 --> Router Class Initialized
INFO - 2020-08-25 03:22:54 --> Output Class Initialized
INFO - 2020-08-25 03:22:54 --> Security Class Initialized
DEBUG - 2020-08-25 03:22:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:22:54 --> Input Class Initialized
INFO - 2020-08-25 03:22:54 --> Language Class Initialized
INFO - 2020-08-25 03:22:54 --> Language Class Initialized
INFO - 2020-08-25 03:22:54 --> Config Class Initialized
INFO - 2020-08-25 03:22:54 --> Loader Class Initialized
INFO - 2020-08-25 03:22:54 --> Helper loaded: url_helper
INFO - 2020-08-25 03:22:54 --> Helper loaded: file_helper
INFO - 2020-08-25 03:22:54 --> Helper loaded: form_helper
INFO - 2020-08-25 03:22:54 --> Helper loaded: my_helper
INFO - 2020-08-25 03:22:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:22:55 --> Controller Class Initialized
DEBUG - 2020-08-25 03:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-25 03:22:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:22:55 --> Final output sent to browser
DEBUG - 2020-08-25 03:22:55 --> Total execution time: 0.0539
INFO - 2020-08-25 03:24:40 --> Config Class Initialized
INFO - 2020-08-25 03:24:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:24:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:24:40 --> Utf8 Class Initialized
INFO - 2020-08-25 03:24:40 --> URI Class Initialized
INFO - 2020-08-25 03:24:40 --> Router Class Initialized
INFO - 2020-08-25 03:24:40 --> Output Class Initialized
INFO - 2020-08-25 03:24:40 --> Security Class Initialized
DEBUG - 2020-08-25 03:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:24:40 --> Input Class Initialized
INFO - 2020-08-25 03:24:40 --> Language Class Initialized
INFO - 2020-08-25 03:24:40 --> Language Class Initialized
INFO - 2020-08-25 03:24:40 --> Config Class Initialized
INFO - 2020-08-25 03:24:40 --> Loader Class Initialized
INFO - 2020-08-25 03:24:40 --> Helper loaded: url_helper
INFO - 2020-08-25 03:24:40 --> Helper loaded: file_helper
INFO - 2020-08-25 03:24:40 --> Helper loaded: form_helper
INFO - 2020-08-25 03:24:40 --> Helper loaded: my_helper
INFO - 2020-08-25 03:24:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:24:40 --> Controller Class Initialized
DEBUG - 2020-08-25 03:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:24:40 --> Final output sent to browser
DEBUG - 2020-08-25 03:24:40 --> Total execution time: 0.0628
INFO - 2020-08-25 03:24:47 --> Config Class Initialized
INFO - 2020-08-25 03:24:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:24:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:24:47 --> Utf8 Class Initialized
INFO - 2020-08-25 03:24:47 --> URI Class Initialized
INFO - 2020-08-25 03:24:47 --> Router Class Initialized
INFO - 2020-08-25 03:24:47 --> Output Class Initialized
INFO - 2020-08-25 03:24:47 --> Security Class Initialized
DEBUG - 2020-08-25 03:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:24:47 --> Input Class Initialized
INFO - 2020-08-25 03:24:47 --> Language Class Initialized
INFO - 2020-08-25 03:24:47 --> Language Class Initialized
INFO - 2020-08-25 03:24:47 --> Config Class Initialized
INFO - 2020-08-25 03:24:47 --> Loader Class Initialized
INFO - 2020-08-25 03:24:47 --> Helper loaded: url_helper
INFO - 2020-08-25 03:24:47 --> Helper loaded: file_helper
INFO - 2020-08-25 03:24:47 --> Helper loaded: form_helper
INFO - 2020-08-25 03:24:47 --> Helper loaded: my_helper
INFO - 2020-08-25 03:24:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:24:47 --> Controller Class Initialized
DEBUG - 2020-08-25 03:24:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-08-25 03:24:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:24:47 --> Final output sent to browser
DEBUG - 2020-08-25 03:24:47 --> Total execution time: 0.0746
INFO - 2020-08-25 03:24:47 --> Config Class Initialized
INFO - 2020-08-25 03:24:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:24:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:24:47 --> Utf8 Class Initialized
INFO - 2020-08-25 03:24:47 --> URI Class Initialized
INFO - 2020-08-25 03:24:47 --> Router Class Initialized
INFO - 2020-08-25 03:24:47 --> Output Class Initialized
INFO - 2020-08-25 03:24:47 --> Security Class Initialized
DEBUG - 2020-08-25 03:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:24:47 --> Input Class Initialized
INFO - 2020-08-25 03:24:47 --> Language Class Initialized
INFO - 2020-08-25 03:24:47 --> Language Class Initialized
INFO - 2020-08-25 03:24:47 --> Config Class Initialized
INFO - 2020-08-25 03:24:47 --> Loader Class Initialized
INFO - 2020-08-25 03:24:47 --> Helper loaded: url_helper
INFO - 2020-08-25 03:24:47 --> Helper loaded: file_helper
INFO - 2020-08-25 03:24:47 --> Helper loaded: form_helper
INFO - 2020-08-25 03:24:47 --> Helper loaded: my_helper
INFO - 2020-08-25 03:24:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:24:47 --> Controller Class Initialized
INFO - 2020-08-25 03:24:49 --> Config Class Initialized
INFO - 2020-08-25 03:24:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:24:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:24:49 --> Utf8 Class Initialized
INFO - 2020-08-25 03:24:49 --> URI Class Initialized
INFO - 2020-08-25 03:24:49 --> Router Class Initialized
INFO - 2020-08-25 03:24:49 --> Output Class Initialized
INFO - 2020-08-25 03:24:49 --> Security Class Initialized
DEBUG - 2020-08-25 03:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:24:49 --> Input Class Initialized
INFO - 2020-08-25 03:24:49 --> Language Class Initialized
INFO - 2020-08-25 03:24:49 --> Language Class Initialized
INFO - 2020-08-25 03:24:49 --> Config Class Initialized
INFO - 2020-08-25 03:24:49 --> Loader Class Initialized
INFO - 2020-08-25 03:24:49 --> Helper loaded: url_helper
INFO - 2020-08-25 03:24:49 --> Helper loaded: file_helper
INFO - 2020-08-25 03:24:49 --> Helper loaded: form_helper
INFO - 2020-08-25 03:24:49 --> Helper loaded: my_helper
INFO - 2020-08-25 03:24:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:24:49 --> Controller Class Initialized
INFO - 2020-08-25 03:24:49 --> Final output sent to browser
DEBUG - 2020-08-25 03:24:49 --> Total execution time: 0.0528
INFO - 2020-08-25 03:24:55 --> Config Class Initialized
INFO - 2020-08-25 03:24:55 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:24:55 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:24:55 --> Utf8 Class Initialized
INFO - 2020-08-25 03:24:55 --> URI Class Initialized
INFO - 2020-08-25 03:24:55 --> Router Class Initialized
INFO - 2020-08-25 03:24:55 --> Output Class Initialized
INFO - 2020-08-25 03:24:55 --> Security Class Initialized
DEBUG - 2020-08-25 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:24:55 --> Input Class Initialized
INFO - 2020-08-25 03:24:55 --> Language Class Initialized
INFO - 2020-08-25 03:24:55 --> Language Class Initialized
INFO - 2020-08-25 03:24:55 --> Config Class Initialized
INFO - 2020-08-25 03:24:55 --> Loader Class Initialized
INFO - 2020-08-25 03:24:55 --> Helper loaded: url_helper
INFO - 2020-08-25 03:24:55 --> Helper loaded: file_helper
INFO - 2020-08-25 03:24:55 --> Helper loaded: form_helper
INFO - 2020-08-25 03:24:55 --> Helper loaded: my_helper
INFO - 2020-08-25 03:24:55 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:24:55 --> Controller Class Initialized
INFO - 2020-08-25 03:24:55 --> Final output sent to browser
DEBUG - 2020-08-25 03:24:55 --> Total execution time: 0.0434
INFO - 2020-08-25 03:24:55 --> Config Class Initialized
INFO - 2020-08-25 03:24:55 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:24:55 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:24:55 --> Utf8 Class Initialized
INFO - 2020-08-25 03:24:55 --> URI Class Initialized
INFO - 2020-08-25 03:24:55 --> Router Class Initialized
INFO - 2020-08-25 03:24:55 --> Output Class Initialized
INFO - 2020-08-25 03:24:55 --> Security Class Initialized
DEBUG - 2020-08-25 03:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:24:55 --> Input Class Initialized
INFO - 2020-08-25 03:24:55 --> Language Class Initialized
INFO - 2020-08-25 03:24:55 --> Language Class Initialized
INFO - 2020-08-25 03:24:55 --> Config Class Initialized
INFO - 2020-08-25 03:24:55 --> Loader Class Initialized
INFO - 2020-08-25 03:24:55 --> Helper loaded: url_helper
INFO - 2020-08-25 03:24:55 --> Helper loaded: file_helper
INFO - 2020-08-25 03:24:55 --> Helper loaded: form_helper
INFO - 2020-08-25 03:24:55 --> Helper loaded: my_helper
INFO - 2020-08-25 03:24:55 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:24:55 --> Controller Class Initialized
INFO - 2020-08-25 03:25:07 --> Config Class Initialized
INFO - 2020-08-25 03:25:07 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:25:07 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:25:07 --> Utf8 Class Initialized
INFO - 2020-08-25 03:25:07 --> URI Class Initialized
INFO - 2020-08-25 03:25:07 --> Router Class Initialized
INFO - 2020-08-25 03:25:07 --> Output Class Initialized
INFO - 2020-08-25 03:25:07 --> Security Class Initialized
DEBUG - 2020-08-25 03:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:25:07 --> Input Class Initialized
INFO - 2020-08-25 03:25:07 --> Language Class Initialized
INFO - 2020-08-25 03:25:07 --> Language Class Initialized
INFO - 2020-08-25 03:25:07 --> Config Class Initialized
INFO - 2020-08-25 03:25:07 --> Loader Class Initialized
INFO - 2020-08-25 03:25:07 --> Helper loaded: url_helper
INFO - 2020-08-25 03:25:07 --> Helper loaded: file_helper
INFO - 2020-08-25 03:25:07 --> Helper loaded: form_helper
INFO - 2020-08-25 03:25:07 --> Helper loaded: my_helper
INFO - 2020-08-25 03:25:07 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:25:07 --> Controller Class Initialized
DEBUG - 2020-08-25 03:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 03:25:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:25:07 --> Final output sent to browser
DEBUG - 2020-08-25 03:25:07 --> Total execution time: 0.0499
INFO - 2020-08-25 03:25:07 --> Config Class Initialized
INFO - 2020-08-25 03:25:07 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:25:07 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:25:07 --> Utf8 Class Initialized
INFO - 2020-08-25 03:25:07 --> URI Class Initialized
INFO - 2020-08-25 03:25:07 --> Router Class Initialized
INFO - 2020-08-25 03:25:07 --> Output Class Initialized
INFO - 2020-08-25 03:25:07 --> Security Class Initialized
DEBUG - 2020-08-25 03:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:25:07 --> Input Class Initialized
INFO - 2020-08-25 03:25:07 --> Language Class Initialized
INFO - 2020-08-25 03:25:07 --> Language Class Initialized
INFO - 2020-08-25 03:25:07 --> Config Class Initialized
INFO - 2020-08-25 03:25:07 --> Loader Class Initialized
INFO - 2020-08-25 03:25:07 --> Helper loaded: url_helper
INFO - 2020-08-25 03:25:07 --> Helper loaded: file_helper
INFO - 2020-08-25 03:25:07 --> Helper loaded: form_helper
INFO - 2020-08-25 03:25:07 --> Helper loaded: my_helper
INFO - 2020-08-25 03:25:07 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:25:07 --> Controller Class Initialized
INFO - 2020-08-25 03:26:13 --> Config Class Initialized
INFO - 2020-08-25 03:26:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:13 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:13 --> URI Class Initialized
INFO - 2020-08-25 03:26:13 --> Router Class Initialized
INFO - 2020-08-25 03:26:13 --> Output Class Initialized
INFO - 2020-08-25 03:26:13 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:13 --> Input Class Initialized
INFO - 2020-08-25 03:26:13 --> Language Class Initialized
INFO - 2020-08-25 03:26:13 --> Language Class Initialized
INFO - 2020-08-25 03:26:13 --> Config Class Initialized
INFO - 2020-08-25 03:26:13 --> Loader Class Initialized
INFO - 2020-08-25 03:26:13 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:13 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:13 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:13 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:13 --> Controller Class Initialized
DEBUG - 2020-08-25 03:26:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 03:26:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:26:13 --> Final output sent to browser
DEBUG - 2020-08-25 03:26:13 --> Total execution time: 0.0500
INFO - 2020-08-25 03:26:13 --> Config Class Initialized
INFO - 2020-08-25 03:26:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:13 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:13 --> URI Class Initialized
INFO - 2020-08-25 03:26:13 --> Router Class Initialized
INFO - 2020-08-25 03:26:13 --> Output Class Initialized
INFO - 2020-08-25 03:26:13 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:13 --> Input Class Initialized
INFO - 2020-08-25 03:26:13 --> Language Class Initialized
INFO - 2020-08-25 03:26:13 --> Language Class Initialized
INFO - 2020-08-25 03:26:13 --> Config Class Initialized
INFO - 2020-08-25 03:26:13 --> Loader Class Initialized
INFO - 2020-08-25 03:26:13 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:13 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:13 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:13 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:13 --> Controller Class Initialized
INFO - 2020-08-25 03:26:17 --> Config Class Initialized
INFO - 2020-08-25 03:26:17 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:17 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:17 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:17 --> URI Class Initialized
INFO - 2020-08-25 03:26:17 --> Router Class Initialized
INFO - 2020-08-25 03:26:17 --> Output Class Initialized
INFO - 2020-08-25 03:26:17 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:17 --> Input Class Initialized
INFO - 2020-08-25 03:26:17 --> Language Class Initialized
INFO - 2020-08-25 03:26:17 --> Language Class Initialized
INFO - 2020-08-25 03:26:17 --> Config Class Initialized
INFO - 2020-08-25 03:26:17 --> Loader Class Initialized
INFO - 2020-08-25 03:26:17 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:17 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:17 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:17 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:17 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:17 --> Controller Class Initialized
INFO - 2020-08-25 03:26:18 --> Config Class Initialized
INFO - 2020-08-25 03:26:18 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:18 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:18 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:18 --> URI Class Initialized
INFO - 2020-08-25 03:26:18 --> Router Class Initialized
INFO - 2020-08-25 03:26:18 --> Output Class Initialized
INFO - 2020-08-25 03:26:18 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:18 --> Input Class Initialized
INFO - 2020-08-25 03:26:18 --> Language Class Initialized
INFO - 2020-08-25 03:26:18 --> Language Class Initialized
INFO - 2020-08-25 03:26:18 --> Config Class Initialized
INFO - 2020-08-25 03:26:18 --> Loader Class Initialized
INFO - 2020-08-25 03:26:18 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:18 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:18 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:18 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:18 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:18 --> Controller Class Initialized
INFO - 2020-08-25 03:26:19 --> Config Class Initialized
INFO - 2020-08-25 03:26:19 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:19 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:19 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:19 --> URI Class Initialized
INFO - 2020-08-25 03:26:19 --> Router Class Initialized
INFO - 2020-08-25 03:26:19 --> Output Class Initialized
INFO - 2020-08-25 03:26:19 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:19 --> Input Class Initialized
INFO - 2020-08-25 03:26:19 --> Language Class Initialized
INFO - 2020-08-25 03:26:19 --> Language Class Initialized
INFO - 2020-08-25 03:26:19 --> Config Class Initialized
INFO - 2020-08-25 03:26:19 --> Loader Class Initialized
INFO - 2020-08-25 03:26:19 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:19 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:19 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:19 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:19 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:19 --> Controller Class Initialized
INFO - 2020-08-25 03:26:19 --> Config Class Initialized
INFO - 2020-08-25 03:26:19 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:19 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:19 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:19 --> URI Class Initialized
INFO - 2020-08-25 03:26:19 --> Router Class Initialized
INFO - 2020-08-25 03:26:19 --> Output Class Initialized
INFO - 2020-08-25 03:26:19 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:19 --> Input Class Initialized
INFO - 2020-08-25 03:26:19 --> Language Class Initialized
INFO - 2020-08-25 03:26:19 --> Language Class Initialized
INFO - 2020-08-25 03:26:19 --> Config Class Initialized
INFO - 2020-08-25 03:26:19 --> Loader Class Initialized
INFO - 2020-08-25 03:26:19 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:19 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:19 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:19 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:19 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:19 --> Controller Class Initialized
INFO - 2020-08-25 03:26:20 --> Config Class Initialized
INFO - 2020-08-25 03:26:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:20 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:20 --> URI Class Initialized
INFO - 2020-08-25 03:26:20 --> Router Class Initialized
INFO - 2020-08-25 03:26:20 --> Output Class Initialized
INFO - 2020-08-25 03:26:20 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:20 --> Input Class Initialized
INFO - 2020-08-25 03:26:20 --> Language Class Initialized
INFO - 2020-08-25 03:26:20 --> Language Class Initialized
INFO - 2020-08-25 03:26:20 --> Config Class Initialized
INFO - 2020-08-25 03:26:20 --> Loader Class Initialized
INFO - 2020-08-25 03:26:20 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:20 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:20 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:20 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:20 --> Controller Class Initialized
INFO - 2020-08-25 03:26:21 --> Config Class Initialized
INFO - 2020-08-25 03:26:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:21 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:21 --> URI Class Initialized
INFO - 2020-08-25 03:26:21 --> Router Class Initialized
INFO - 2020-08-25 03:26:21 --> Output Class Initialized
INFO - 2020-08-25 03:26:21 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:21 --> Input Class Initialized
INFO - 2020-08-25 03:26:21 --> Language Class Initialized
INFO - 2020-08-25 03:26:21 --> Language Class Initialized
INFO - 2020-08-25 03:26:21 --> Config Class Initialized
INFO - 2020-08-25 03:26:21 --> Loader Class Initialized
INFO - 2020-08-25 03:26:21 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:21 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:21 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:21 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:21 --> Controller Class Initialized
INFO - 2020-08-25 03:26:21 --> Config Class Initialized
INFO - 2020-08-25 03:26:21 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:21 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:21 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:21 --> URI Class Initialized
INFO - 2020-08-25 03:26:21 --> Router Class Initialized
INFO - 2020-08-25 03:26:21 --> Output Class Initialized
INFO - 2020-08-25 03:26:21 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:21 --> Input Class Initialized
INFO - 2020-08-25 03:26:21 --> Language Class Initialized
INFO - 2020-08-25 03:26:21 --> Language Class Initialized
INFO - 2020-08-25 03:26:21 --> Config Class Initialized
INFO - 2020-08-25 03:26:21 --> Loader Class Initialized
INFO - 2020-08-25 03:26:21 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:21 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:21 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:21 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:21 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:21 --> Controller Class Initialized
INFO - 2020-08-25 03:26:22 --> Config Class Initialized
INFO - 2020-08-25 03:26:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:22 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:22 --> URI Class Initialized
INFO - 2020-08-25 03:26:22 --> Router Class Initialized
INFO - 2020-08-25 03:26:22 --> Output Class Initialized
INFO - 2020-08-25 03:26:22 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:22 --> Input Class Initialized
INFO - 2020-08-25 03:26:22 --> Language Class Initialized
INFO - 2020-08-25 03:26:22 --> Language Class Initialized
INFO - 2020-08-25 03:26:22 --> Config Class Initialized
INFO - 2020-08-25 03:26:22 --> Loader Class Initialized
INFO - 2020-08-25 03:26:22 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:22 --> Controller Class Initialized
INFO - 2020-08-25 03:26:22 --> Config Class Initialized
INFO - 2020-08-25 03:26:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:22 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:22 --> URI Class Initialized
INFO - 2020-08-25 03:26:22 --> Router Class Initialized
INFO - 2020-08-25 03:26:22 --> Output Class Initialized
INFO - 2020-08-25 03:26:22 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:22 --> Input Class Initialized
INFO - 2020-08-25 03:26:22 --> Language Class Initialized
INFO - 2020-08-25 03:26:22 --> Language Class Initialized
INFO - 2020-08-25 03:26:22 --> Config Class Initialized
INFO - 2020-08-25 03:26:22 --> Loader Class Initialized
INFO - 2020-08-25 03:26:22 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:22 --> Controller Class Initialized
INFO - 2020-08-25 03:26:22 --> Config Class Initialized
INFO - 2020-08-25 03:26:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:22 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:22 --> URI Class Initialized
INFO - 2020-08-25 03:26:22 --> Router Class Initialized
INFO - 2020-08-25 03:26:22 --> Output Class Initialized
INFO - 2020-08-25 03:26:22 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:22 --> Input Class Initialized
INFO - 2020-08-25 03:26:22 --> Language Class Initialized
INFO - 2020-08-25 03:26:22 --> Language Class Initialized
INFO - 2020-08-25 03:26:22 --> Config Class Initialized
INFO - 2020-08-25 03:26:22 --> Loader Class Initialized
INFO - 2020-08-25 03:26:22 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:22 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:23 --> Controller Class Initialized
INFO - 2020-08-25 03:26:23 --> Config Class Initialized
INFO - 2020-08-25 03:26:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:23 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:23 --> URI Class Initialized
INFO - 2020-08-25 03:26:23 --> Router Class Initialized
INFO - 2020-08-25 03:26:23 --> Output Class Initialized
INFO - 2020-08-25 03:26:23 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:23 --> Input Class Initialized
INFO - 2020-08-25 03:26:23 --> Language Class Initialized
INFO - 2020-08-25 03:26:23 --> Language Class Initialized
INFO - 2020-08-25 03:26:23 --> Config Class Initialized
INFO - 2020-08-25 03:26:23 --> Loader Class Initialized
INFO - 2020-08-25 03:26:23 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:23 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:23 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:23 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:23 --> Controller Class Initialized
INFO - 2020-08-25 03:26:23 --> Config Class Initialized
INFO - 2020-08-25 03:26:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:23 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:23 --> URI Class Initialized
INFO - 2020-08-25 03:26:23 --> Router Class Initialized
INFO - 2020-08-25 03:26:23 --> Output Class Initialized
INFO - 2020-08-25 03:26:23 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:23 --> Input Class Initialized
INFO - 2020-08-25 03:26:23 --> Language Class Initialized
INFO - 2020-08-25 03:26:23 --> Language Class Initialized
INFO - 2020-08-25 03:26:23 --> Config Class Initialized
INFO - 2020-08-25 03:26:23 --> Loader Class Initialized
INFO - 2020-08-25 03:26:23 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:23 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:23 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:23 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:23 --> Controller Class Initialized
INFO - 2020-08-25 03:26:27 --> Config Class Initialized
INFO - 2020-08-25 03:26:27 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:27 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:27 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:27 --> URI Class Initialized
INFO - 2020-08-25 03:26:27 --> Router Class Initialized
INFO - 2020-08-25 03:26:27 --> Output Class Initialized
INFO - 2020-08-25 03:26:27 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:27 --> Input Class Initialized
INFO - 2020-08-25 03:26:27 --> Language Class Initialized
INFO - 2020-08-25 03:26:27 --> Language Class Initialized
INFO - 2020-08-25 03:26:27 --> Config Class Initialized
INFO - 2020-08-25 03:26:27 --> Loader Class Initialized
INFO - 2020-08-25 03:26:27 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:27 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:27 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:27 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:27 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:27 --> Controller Class Initialized
INFO - 2020-08-25 03:26:27 --> Config Class Initialized
INFO - 2020-08-25 03:26:27 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:27 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:27 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:27 --> URI Class Initialized
INFO - 2020-08-25 03:26:27 --> Router Class Initialized
INFO - 2020-08-25 03:26:27 --> Output Class Initialized
INFO - 2020-08-25 03:26:27 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:27 --> Input Class Initialized
INFO - 2020-08-25 03:26:27 --> Language Class Initialized
INFO - 2020-08-25 03:26:27 --> Language Class Initialized
INFO - 2020-08-25 03:26:27 --> Config Class Initialized
INFO - 2020-08-25 03:26:27 --> Loader Class Initialized
INFO - 2020-08-25 03:26:27 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:27 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:27 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:27 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:27 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:27 --> Controller Class Initialized
INFO - 2020-08-25 03:26:28 --> Config Class Initialized
INFO - 2020-08-25 03:26:28 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:28 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:28 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:28 --> URI Class Initialized
INFO - 2020-08-25 03:26:28 --> Router Class Initialized
INFO - 2020-08-25 03:26:28 --> Output Class Initialized
INFO - 2020-08-25 03:26:28 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:28 --> Input Class Initialized
INFO - 2020-08-25 03:26:28 --> Language Class Initialized
INFO - 2020-08-25 03:26:28 --> Language Class Initialized
INFO - 2020-08-25 03:26:28 --> Config Class Initialized
INFO - 2020-08-25 03:26:28 --> Loader Class Initialized
INFO - 2020-08-25 03:26:28 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:28 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:28 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:28 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:28 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:28 --> Controller Class Initialized
INFO - 2020-08-25 03:26:28 --> Config Class Initialized
INFO - 2020-08-25 03:26:28 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:28 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:28 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:28 --> URI Class Initialized
INFO - 2020-08-25 03:26:28 --> Router Class Initialized
INFO - 2020-08-25 03:26:28 --> Output Class Initialized
INFO - 2020-08-25 03:26:28 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:28 --> Input Class Initialized
INFO - 2020-08-25 03:26:28 --> Language Class Initialized
INFO - 2020-08-25 03:26:28 --> Language Class Initialized
INFO - 2020-08-25 03:26:28 --> Config Class Initialized
INFO - 2020-08-25 03:26:28 --> Loader Class Initialized
INFO - 2020-08-25 03:26:28 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:28 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:28 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:28 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:28 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:28 --> Controller Class Initialized
INFO - 2020-08-25 03:26:30 --> Config Class Initialized
INFO - 2020-08-25 03:26:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:30 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:30 --> URI Class Initialized
INFO - 2020-08-25 03:26:30 --> Router Class Initialized
INFO - 2020-08-25 03:26:30 --> Output Class Initialized
INFO - 2020-08-25 03:26:30 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:30 --> Input Class Initialized
INFO - 2020-08-25 03:26:30 --> Language Class Initialized
INFO - 2020-08-25 03:26:30 --> Language Class Initialized
INFO - 2020-08-25 03:26:30 --> Config Class Initialized
INFO - 2020-08-25 03:26:30 --> Loader Class Initialized
INFO - 2020-08-25 03:26:30 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:30 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:30 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:30 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:30 --> Controller Class Initialized
INFO - 2020-08-25 03:26:30 --> Config Class Initialized
INFO - 2020-08-25 03:26:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:30 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:30 --> URI Class Initialized
INFO - 2020-08-25 03:26:30 --> Router Class Initialized
INFO - 2020-08-25 03:26:30 --> Output Class Initialized
INFO - 2020-08-25 03:26:30 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:30 --> Input Class Initialized
INFO - 2020-08-25 03:26:30 --> Language Class Initialized
INFO - 2020-08-25 03:26:30 --> Language Class Initialized
INFO - 2020-08-25 03:26:30 --> Config Class Initialized
INFO - 2020-08-25 03:26:30 --> Loader Class Initialized
INFO - 2020-08-25 03:26:30 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:30 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:30 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:30 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:30 --> Controller Class Initialized
INFO - 2020-08-25 03:26:31 --> Config Class Initialized
INFO - 2020-08-25 03:26:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:31 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:31 --> URI Class Initialized
INFO - 2020-08-25 03:26:31 --> Router Class Initialized
INFO - 2020-08-25 03:26:31 --> Output Class Initialized
INFO - 2020-08-25 03:26:31 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:31 --> Input Class Initialized
INFO - 2020-08-25 03:26:31 --> Language Class Initialized
INFO - 2020-08-25 03:26:31 --> Language Class Initialized
INFO - 2020-08-25 03:26:31 --> Config Class Initialized
INFO - 2020-08-25 03:26:31 --> Loader Class Initialized
INFO - 2020-08-25 03:26:31 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:31 --> Controller Class Initialized
INFO - 2020-08-25 03:26:31 --> Config Class Initialized
INFO - 2020-08-25 03:26:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:31 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:31 --> URI Class Initialized
INFO - 2020-08-25 03:26:31 --> Router Class Initialized
INFO - 2020-08-25 03:26:31 --> Output Class Initialized
INFO - 2020-08-25 03:26:31 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:31 --> Input Class Initialized
INFO - 2020-08-25 03:26:31 --> Language Class Initialized
INFO - 2020-08-25 03:26:31 --> Language Class Initialized
INFO - 2020-08-25 03:26:31 --> Config Class Initialized
INFO - 2020-08-25 03:26:31 --> Loader Class Initialized
INFO - 2020-08-25 03:26:31 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:31 --> Controller Class Initialized
INFO - 2020-08-25 03:26:31 --> Config Class Initialized
INFO - 2020-08-25 03:26:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:31 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:31 --> URI Class Initialized
INFO - 2020-08-25 03:26:31 --> Router Class Initialized
INFO - 2020-08-25 03:26:31 --> Output Class Initialized
INFO - 2020-08-25 03:26:31 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:31 --> Input Class Initialized
INFO - 2020-08-25 03:26:31 --> Language Class Initialized
INFO - 2020-08-25 03:26:31 --> Language Class Initialized
INFO - 2020-08-25 03:26:31 --> Config Class Initialized
INFO - 2020-08-25 03:26:31 --> Loader Class Initialized
INFO - 2020-08-25 03:26:31 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:31 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:31 --> Controller Class Initialized
INFO - 2020-08-25 03:26:32 --> Config Class Initialized
INFO - 2020-08-25 03:26:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:32 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:32 --> URI Class Initialized
INFO - 2020-08-25 03:26:32 --> Router Class Initialized
INFO - 2020-08-25 03:26:32 --> Output Class Initialized
INFO - 2020-08-25 03:26:32 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:32 --> Input Class Initialized
INFO - 2020-08-25 03:26:32 --> Language Class Initialized
INFO - 2020-08-25 03:26:32 --> Language Class Initialized
INFO - 2020-08-25 03:26:32 --> Config Class Initialized
INFO - 2020-08-25 03:26:32 --> Loader Class Initialized
INFO - 2020-08-25 03:26:32 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:32 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:32 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:32 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:32 --> Controller Class Initialized
INFO - 2020-08-25 03:26:32 --> Config Class Initialized
INFO - 2020-08-25 03:26:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:32 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:32 --> URI Class Initialized
INFO - 2020-08-25 03:26:32 --> Router Class Initialized
INFO - 2020-08-25 03:26:32 --> Output Class Initialized
INFO - 2020-08-25 03:26:32 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:32 --> Input Class Initialized
INFO - 2020-08-25 03:26:32 --> Language Class Initialized
INFO - 2020-08-25 03:26:32 --> Language Class Initialized
INFO - 2020-08-25 03:26:32 --> Config Class Initialized
INFO - 2020-08-25 03:26:32 --> Loader Class Initialized
INFO - 2020-08-25 03:26:32 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:32 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:32 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:32 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:32 --> Controller Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:33 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:33 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:33 --> URI Class Initialized
INFO - 2020-08-25 03:26:33 --> Router Class Initialized
INFO - 2020-08-25 03:26:33 --> Output Class Initialized
INFO - 2020-08-25 03:26:33 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:33 --> Input Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Loader Class Initialized
INFO - 2020-08-25 03:26:33 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:33 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:33 --> Controller Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:33 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:33 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:33 --> URI Class Initialized
INFO - 2020-08-25 03:26:33 --> Router Class Initialized
INFO - 2020-08-25 03:26:33 --> Output Class Initialized
INFO - 2020-08-25 03:26:33 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:33 --> Input Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Loader Class Initialized
INFO - 2020-08-25 03:26:33 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:33 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:33 --> Controller Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:33 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:33 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:33 --> URI Class Initialized
INFO - 2020-08-25 03:26:33 --> Router Class Initialized
INFO - 2020-08-25 03:26:33 --> Output Class Initialized
INFO - 2020-08-25 03:26:33 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:33 --> Input Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Loader Class Initialized
INFO - 2020-08-25 03:26:33 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:33 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:33 --> Controller Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:33 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:33 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:33 --> URI Class Initialized
INFO - 2020-08-25 03:26:33 --> Router Class Initialized
INFO - 2020-08-25 03:26:33 --> Output Class Initialized
INFO - 2020-08-25 03:26:33 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:33 --> Input Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Language Class Initialized
INFO - 2020-08-25 03:26:33 --> Config Class Initialized
INFO - 2020-08-25 03:26:33 --> Loader Class Initialized
INFO - 2020-08-25 03:26:33 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:33 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:33 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:33 --> Controller Class Initialized
INFO - 2020-08-25 03:26:34 --> Config Class Initialized
INFO - 2020-08-25 03:26:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:34 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:34 --> URI Class Initialized
INFO - 2020-08-25 03:26:34 --> Router Class Initialized
INFO - 2020-08-25 03:26:34 --> Output Class Initialized
INFO - 2020-08-25 03:26:34 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:34 --> Input Class Initialized
INFO - 2020-08-25 03:26:34 --> Language Class Initialized
INFO - 2020-08-25 03:26:34 --> Language Class Initialized
INFO - 2020-08-25 03:26:34 --> Config Class Initialized
INFO - 2020-08-25 03:26:34 --> Loader Class Initialized
INFO - 2020-08-25 03:26:34 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:34 --> Controller Class Initialized
INFO - 2020-08-25 03:26:34 --> Config Class Initialized
INFO - 2020-08-25 03:26:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:34 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:34 --> URI Class Initialized
INFO - 2020-08-25 03:26:34 --> Router Class Initialized
INFO - 2020-08-25 03:26:34 --> Output Class Initialized
INFO - 2020-08-25 03:26:34 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:34 --> Input Class Initialized
INFO - 2020-08-25 03:26:34 --> Language Class Initialized
INFO - 2020-08-25 03:26:34 --> Language Class Initialized
INFO - 2020-08-25 03:26:34 --> Config Class Initialized
INFO - 2020-08-25 03:26:34 --> Loader Class Initialized
INFO - 2020-08-25 03:26:34 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:34 --> Controller Class Initialized
INFO - 2020-08-25 03:26:34 --> Config Class Initialized
INFO - 2020-08-25 03:26:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:34 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:34 --> URI Class Initialized
INFO - 2020-08-25 03:26:34 --> Router Class Initialized
INFO - 2020-08-25 03:26:34 --> Output Class Initialized
INFO - 2020-08-25 03:26:34 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:34 --> Input Class Initialized
INFO - 2020-08-25 03:26:34 --> Language Class Initialized
INFO - 2020-08-25 03:26:34 --> Language Class Initialized
INFO - 2020-08-25 03:26:34 --> Config Class Initialized
INFO - 2020-08-25 03:26:34 --> Loader Class Initialized
INFO - 2020-08-25 03:26:34 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:34 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:34 --> Controller Class Initialized
INFO - 2020-08-25 03:26:35 --> Config Class Initialized
INFO - 2020-08-25 03:26:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:35 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:35 --> URI Class Initialized
INFO - 2020-08-25 03:26:35 --> Router Class Initialized
INFO - 2020-08-25 03:26:35 --> Output Class Initialized
INFO - 2020-08-25 03:26:35 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:35 --> Input Class Initialized
INFO - 2020-08-25 03:26:35 --> Language Class Initialized
INFO - 2020-08-25 03:26:35 --> Language Class Initialized
INFO - 2020-08-25 03:26:35 --> Config Class Initialized
INFO - 2020-08-25 03:26:35 --> Loader Class Initialized
INFO - 2020-08-25 03:26:35 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:35 --> Controller Class Initialized
INFO - 2020-08-25 03:26:35 --> Config Class Initialized
INFO - 2020-08-25 03:26:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:35 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:35 --> URI Class Initialized
INFO - 2020-08-25 03:26:35 --> Router Class Initialized
INFO - 2020-08-25 03:26:35 --> Output Class Initialized
INFO - 2020-08-25 03:26:35 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:35 --> Input Class Initialized
INFO - 2020-08-25 03:26:35 --> Language Class Initialized
INFO - 2020-08-25 03:26:35 --> Language Class Initialized
INFO - 2020-08-25 03:26:35 --> Config Class Initialized
INFO - 2020-08-25 03:26:35 --> Loader Class Initialized
INFO - 2020-08-25 03:26:35 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:35 --> Controller Class Initialized
INFO - 2020-08-25 03:26:35 --> Config Class Initialized
INFO - 2020-08-25 03:26:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:35 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:35 --> URI Class Initialized
INFO - 2020-08-25 03:26:35 --> Router Class Initialized
INFO - 2020-08-25 03:26:35 --> Output Class Initialized
INFO - 2020-08-25 03:26:35 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:35 --> Input Class Initialized
INFO - 2020-08-25 03:26:35 --> Language Class Initialized
INFO - 2020-08-25 03:26:35 --> Language Class Initialized
INFO - 2020-08-25 03:26:35 --> Config Class Initialized
INFO - 2020-08-25 03:26:35 --> Loader Class Initialized
INFO - 2020-08-25 03:26:35 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:35 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:35 --> Controller Class Initialized
INFO - 2020-08-25 03:26:36 --> Config Class Initialized
INFO - 2020-08-25 03:26:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:36 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:36 --> URI Class Initialized
INFO - 2020-08-25 03:26:36 --> Router Class Initialized
INFO - 2020-08-25 03:26:36 --> Output Class Initialized
INFO - 2020-08-25 03:26:36 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:36 --> Input Class Initialized
INFO - 2020-08-25 03:26:36 --> Language Class Initialized
INFO - 2020-08-25 03:26:36 --> Language Class Initialized
INFO - 2020-08-25 03:26:36 --> Config Class Initialized
INFO - 2020-08-25 03:26:36 --> Loader Class Initialized
INFO - 2020-08-25 03:26:36 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:36 --> Controller Class Initialized
INFO - 2020-08-25 03:26:36 --> Config Class Initialized
INFO - 2020-08-25 03:26:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:36 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:36 --> URI Class Initialized
INFO - 2020-08-25 03:26:36 --> Router Class Initialized
INFO - 2020-08-25 03:26:36 --> Output Class Initialized
INFO - 2020-08-25 03:26:36 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:36 --> Input Class Initialized
INFO - 2020-08-25 03:26:36 --> Language Class Initialized
INFO - 2020-08-25 03:26:36 --> Language Class Initialized
INFO - 2020-08-25 03:26:36 --> Config Class Initialized
INFO - 2020-08-25 03:26:36 --> Loader Class Initialized
INFO - 2020-08-25 03:26:36 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:36 --> Controller Class Initialized
INFO - 2020-08-25 03:26:36 --> Config Class Initialized
INFO - 2020-08-25 03:26:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:36 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:36 --> URI Class Initialized
INFO - 2020-08-25 03:26:36 --> Router Class Initialized
INFO - 2020-08-25 03:26:36 --> Output Class Initialized
INFO - 2020-08-25 03:26:36 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:36 --> Input Class Initialized
INFO - 2020-08-25 03:26:36 --> Language Class Initialized
INFO - 2020-08-25 03:26:36 --> Language Class Initialized
INFO - 2020-08-25 03:26:36 --> Config Class Initialized
INFO - 2020-08-25 03:26:36 --> Loader Class Initialized
INFO - 2020-08-25 03:26:36 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:36 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:36 --> Controller Class Initialized
INFO - 2020-08-25 03:26:37 --> Config Class Initialized
INFO - 2020-08-25 03:26:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:37 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:37 --> URI Class Initialized
INFO - 2020-08-25 03:26:37 --> Router Class Initialized
INFO - 2020-08-25 03:26:37 --> Output Class Initialized
INFO - 2020-08-25 03:26:37 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:37 --> Input Class Initialized
INFO - 2020-08-25 03:26:37 --> Language Class Initialized
INFO - 2020-08-25 03:26:37 --> Language Class Initialized
INFO - 2020-08-25 03:26:37 --> Config Class Initialized
INFO - 2020-08-25 03:26:37 --> Loader Class Initialized
INFO - 2020-08-25 03:26:37 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:37 --> Controller Class Initialized
INFO - 2020-08-25 03:26:37 --> Config Class Initialized
INFO - 2020-08-25 03:26:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:37 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:37 --> URI Class Initialized
INFO - 2020-08-25 03:26:37 --> Router Class Initialized
INFO - 2020-08-25 03:26:37 --> Output Class Initialized
INFO - 2020-08-25 03:26:37 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:37 --> Input Class Initialized
INFO - 2020-08-25 03:26:37 --> Language Class Initialized
INFO - 2020-08-25 03:26:37 --> Language Class Initialized
INFO - 2020-08-25 03:26:37 --> Config Class Initialized
INFO - 2020-08-25 03:26:37 --> Loader Class Initialized
INFO - 2020-08-25 03:26:37 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:37 --> Controller Class Initialized
INFO - 2020-08-25 03:26:37 --> Config Class Initialized
INFO - 2020-08-25 03:26:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:37 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:37 --> URI Class Initialized
INFO - 2020-08-25 03:26:37 --> Router Class Initialized
INFO - 2020-08-25 03:26:37 --> Output Class Initialized
INFO - 2020-08-25 03:26:37 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:37 --> Input Class Initialized
INFO - 2020-08-25 03:26:37 --> Language Class Initialized
INFO - 2020-08-25 03:26:37 --> Language Class Initialized
INFO - 2020-08-25 03:26:37 --> Config Class Initialized
INFO - 2020-08-25 03:26:37 --> Loader Class Initialized
INFO - 2020-08-25 03:26:37 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:37 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:37 --> Controller Class Initialized
INFO - 2020-08-25 03:26:38 --> Config Class Initialized
INFO - 2020-08-25 03:26:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:38 --> URI Class Initialized
INFO - 2020-08-25 03:26:38 --> Router Class Initialized
INFO - 2020-08-25 03:26:38 --> Output Class Initialized
INFO - 2020-08-25 03:26:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:38 --> Input Class Initialized
INFO - 2020-08-25 03:26:38 --> Language Class Initialized
INFO - 2020-08-25 03:26:38 --> Language Class Initialized
INFO - 2020-08-25 03:26:38 --> Config Class Initialized
INFO - 2020-08-25 03:26:38 --> Loader Class Initialized
INFO - 2020-08-25 03:26:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:38 --> Controller Class Initialized
INFO - 2020-08-25 03:26:38 --> Config Class Initialized
INFO - 2020-08-25 03:26:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:38 --> URI Class Initialized
INFO - 2020-08-25 03:26:38 --> Router Class Initialized
INFO - 2020-08-25 03:26:38 --> Output Class Initialized
INFO - 2020-08-25 03:26:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:38 --> Input Class Initialized
INFO - 2020-08-25 03:26:38 --> Language Class Initialized
INFO - 2020-08-25 03:26:38 --> Language Class Initialized
INFO - 2020-08-25 03:26:38 --> Config Class Initialized
INFO - 2020-08-25 03:26:38 --> Loader Class Initialized
INFO - 2020-08-25 03:26:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:38 --> Controller Class Initialized
INFO - 2020-08-25 03:26:38 --> Config Class Initialized
INFO - 2020-08-25 03:26:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:38 --> URI Class Initialized
INFO - 2020-08-25 03:26:38 --> Router Class Initialized
INFO - 2020-08-25 03:26:38 --> Output Class Initialized
INFO - 2020-08-25 03:26:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:38 --> Input Class Initialized
INFO - 2020-08-25 03:26:38 --> Language Class Initialized
INFO - 2020-08-25 03:26:38 --> Language Class Initialized
INFO - 2020-08-25 03:26:38 --> Config Class Initialized
INFO - 2020-08-25 03:26:38 --> Loader Class Initialized
INFO - 2020-08-25 03:26:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:38 --> Controller Class Initialized
INFO - 2020-08-25 03:26:39 --> Config Class Initialized
INFO - 2020-08-25 03:26:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:39 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:39 --> URI Class Initialized
INFO - 2020-08-25 03:26:39 --> Router Class Initialized
INFO - 2020-08-25 03:26:39 --> Output Class Initialized
INFO - 2020-08-25 03:26:39 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:39 --> Input Class Initialized
INFO - 2020-08-25 03:26:39 --> Language Class Initialized
INFO - 2020-08-25 03:26:39 --> Language Class Initialized
INFO - 2020-08-25 03:26:39 --> Config Class Initialized
INFO - 2020-08-25 03:26:39 --> Loader Class Initialized
INFO - 2020-08-25 03:26:39 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:39 --> Controller Class Initialized
INFO - 2020-08-25 03:26:39 --> Config Class Initialized
INFO - 2020-08-25 03:26:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:39 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:39 --> URI Class Initialized
INFO - 2020-08-25 03:26:39 --> Router Class Initialized
INFO - 2020-08-25 03:26:39 --> Output Class Initialized
INFO - 2020-08-25 03:26:39 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:39 --> Input Class Initialized
INFO - 2020-08-25 03:26:39 --> Language Class Initialized
INFO - 2020-08-25 03:26:39 --> Language Class Initialized
INFO - 2020-08-25 03:26:39 --> Config Class Initialized
INFO - 2020-08-25 03:26:39 --> Loader Class Initialized
INFO - 2020-08-25 03:26:39 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:39 --> Controller Class Initialized
INFO - 2020-08-25 03:26:39 --> Config Class Initialized
INFO - 2020-08-25 03:26:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:39 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:39 --> URI Class Initialized
INFO - 2020-08-25 03:26:39 --> Router Class Initialized
INFO - 2020-08-25 03:26:39 --> Output Class Initialized
INFO - 2020-08-25 03:26:39 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:39 --> Input Class Initialized
INFO - 2020-08-25 03:26:39 --> Language Class Initialized
INFO - 2020-08-25 03:26:39 --> Language Class Initialized
INFO - 2020-08-25 03:26:39 --> Config Class Initialized
INFO - 2020-08-25 03:26:39 --> Loader Class Initialized
INFO - 2020-08-25 03:26:39 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:39 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:39 --> Controller Class Initialized
INFO - 2020-08-25 03:26:40 --> Config Class Initialized
INFO - 2020-08-25 03:26:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:40 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:40 --> URI Class Initialized
INFO - 2020-08-25 03:26:40 --> Router Class Initialized
INFO - 2020-08-25 03:26:40 --> Output Class Initialized
INFO - 2020-08-25 03:26:40 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:40 --> Input Class Initialized
INFO - 2020-08-25 03:26:40 --> Language Class Initialized
INFO - 2020-08-25 03:26:40 --> Language Class Initialized
INFO - 2020-08-25 03:26:40 --> Config Class Initialized
INFO - 2020-08-25 03:26:40 --> Loader Class Initialized
INFO - 2020-08-25 03:26:40 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:40 --> Controller Class Initialized
INFO - 2020-08-25 03:26:40 --> Config Class Initialized
INFO - 2020-08-25 03:26:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:40 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:40 --> URI Class Initialized
INFO - 2020-08-25 03:26:40 --> Router Class Initialized
INFO - 2020-08-25 03:26:40 --> Output Class Initialized
INFO - 2020-08-25 03:26:40 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:40 --> Input Class Initialized
INFO - 2020-08-25 03:26:40 --> Language Class Initialized
INFO - 2020-08-25 03:26:40 --> Language Class Initialized
INFO - 2020-08-25 03:26:40 --> Config Class Initialized
INFO - 2020-08-25 03:26:40 --> Loader Class Initialized
INFO - 2020-08-25 03:26:40 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:40 --> Controller Class Initialized
INFO - 2020-08-25 03:26:40 --> Config Class Initialized
INFO - 2020-08-25 03:26:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:40 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:40 --> URI Class Initialized
INFO - 2020-08-25 03:26:40 --> Router Class Initialized
INFO - 2020-08-25 03:26:40 --> Output Class Initialized
INFO - 2020-08-25 03:26:40 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:40 --> Input Class Initialized
INFO - 2020-08-25 03:26:40 --> Language Class Initialized
INFO - 2020-08-25 03:26:40 --> Language Class Initialized
INFO - 2020-08-25 03:26:40 --> Config Class Initialized
INFO - 2020-08-25 03:26:40 --> Loader Class Initialized
INFO - 2020-08-25 03:26:40 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:40 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:40 --> Controller Class Initialized
INFO - 2020-08-25 03:26:41 --> Config Class Initialized
INFO - 2020-08-25 03:26:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:41 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:41 --> URI Class Initialized
INFO - 2020-08-25 03:26:41 --> Router Class Initialized
INFO - 2020-08-25 03:26:41 --> Output Class Initialized
INFO - 2020-08-25 03:26:41 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:41 --> Input Class Initialized
INFO - 2020-08-25 03:26:41 --> Language Class Initialized
INFO - 2020-08-25 03:26:41 --> Language Class Initialized
INFO - 2020-08-25 03:26:41 --> Config Class Initialized
INFO - 2020-08-25 03:26:41 --> Loader Class Initialized
INFO - 2020-08-25 03:26:41 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:41 --> Controller Class Initialized
INFO - 2020-08-25 03:26:41 --> Config Class Initialized
INFO - 2020-08-25 03:26:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:41 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:41 --> URI Class Initialized
INFO - 2020-08-25 03:26:41 --> Router Class Initialized
INFO - 2020-08-25 03:26:41 --> Output Class Initialized
INFO - 2020-08-25 03:26:41 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:41 --> Input Class Initialized
INFO - 2020-08-25 03:26:41 --> Language Class Initialized
INFO - 2020-08-25 03:26:41 --> Language Class Initialized
INFO - 2020-08-25 03:26:41 --> Config Class Initialized
INFO - 2020-08-25 03:26:41 --> Loader Class Initialized
INFO - 2020-08-25 03:26:41 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:41 --> Controller Class Initialized
INFO - 2020-08-25 03:26:41 --> Config Class Initialized
INFO - 2020-08-25 03:26:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:41 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:41 --> URI Class Initialized
INFO - 2020-08-25 03:26:41 --> Router Class Initialized
INFO - 2020-08-25 03:26:41 --> Output Class Initialized
INFO - 2020-08-25 03:26:41 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:41 --> Input Class Initialized
INFO - 2020-08-25 03:26:41 --> Language Class Initialized
INFO - 2020-08-25 03:26:41 --> Language Class Initialized
INFO - 2020-08-25 03:26:41 --> Config Class Initialized
INFO - 2020-08-25 03:26:41 --> Loader Class Initialized
INFO - 2020-08-25 03:26:41 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:41 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:41 --> Controller Class Initialized
INFO - 2020-08-25 03:26:42 --> Config Class Initialized
INFO - 2020-08-25 03:26:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:42 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:42 --> URI Class Initialized
INFO - 2020-08-25 03:26:42 --> Router Class Initialized
INFO - 2020-08-25 03:26:42 --> Output Class Initialized
INFO - 2020-08-25 03:26:42 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:42 --> Input Class Initialized
INFO - 2020-08-25 03:26:42 --> Language Class Initialized
INFO - 2020-08-25 03:26:42 --> Language Class Initialized
INFO - 2020-08-25 03:26:42 --> Config Class Initialized
INFO - 2020-08-25 03:26:42 --> Loader Class Initialized
INFO - 2020-08-25 03:26:42 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:42 --> Controller Class Initialized
INFO - 2020-08-25 03:26:42 --> Config Class Initialized
INFO - 2020-08-25 03:26:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:42 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:42 --> URI Class Initialized
INFO - 2020-08-25 03:26:42 --> Router Class Initialized
INFO - 2020-08-25 03:26:42 --> Output Class Initialized
INFO - 2020-08-25 03:26:42 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:42 --> Input Class Initialized
INFO - 2020-08-25 03:26:42 --> Language Class Initialized
INFO - 2020-08-25 03:26:42 --> Language Class Initialized
INFO - 2020-08-25 03:26:42 --> Config Class Initialized
INFO - 2020-08-25 03:26:42 --> Loader Class Initialized
INFO - 2020-08-25 03:26:42 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:42 --> Controller Class Initialized
INFO - 2020-08-25 03:26:42 --> Config Class Initialized
INFO - 2020-08-25 03:26:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:42 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:42 --> URI Class Initialized
INFO - 2020-08-25 03:26:42 --> Router Class Initialized
INFO - 2020-08-25 03:26:42 --> Output Class Initialized
INFO - 2020-08-25 03:26:42 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:42 --> Input Class Initialized
INFO - 2020-08-25 03:26:42 --> Language Class Initialized
INFO - 2020-08-25 03:26:42 --> Language Class Initialized
INFO - 2020-08-25 03:26:42 --> Config Class Initialized
INFO - 2020-08-25 03:26:42 --> Loader Class Initialized
INFO - 2020-08-25 03:26:42 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:42 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:42 --> Controller Class Initialized
INFO - 2020-08-25 03:26:43 --> Config Class Initialized
INFO - 2020-08-25 03:26:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:43 --> URI Class Initialized
INFO - 2020-08-25 03:26:43 --> Router Class Initialized
INFO - 2020-08-25 03:26:43 --> Output Class Initialized
INFO - 2020-08-25 03:26:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:43 --> Input Class Initialized
INFO - 2020-08-25 03:26:43 --> Language Class Initialized
INFO - 2020-08-25 03:26:43 --> Language Class Initialized
INFO - 2020-08-25 03:26:43 --> Config Class Initialized
INFO - 2020-08-25 03:26:43 --> Loader Class Initialized
INFO - 2020-08-25 03:26:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:43 --> Controller Class Initialized
INFO - 2020-08-25 03:26:43 --> Config Class Initialized
INFO - 2020-08-25 03:26:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:43 --> URI Class Initialized
INFO - 2020-08-25 03:26:43 --> Router Class Initialized
INFO - 2020-08-25 03:26:43 --> Output Class Initialized
INFO - 2020-08-25 03:26:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:43 --> Input Class Initialized
INFO - 2020-08-25 03:26:43 --> Language Class Initialized
INFO - 2020-08-25 03:26:43 --> Language Class Initialized
INFO - 2020-08-25 03:26:43 --> Config Class Initialized
INFO - 2020-08-25 03:26:43 --> Loader Class Initialized
INFO - 2020-08-25 03:26:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:43 --> Controller Class Initialized
INFO - 2020-08-25 03:26:43 --> Config Class Initialized
INFO - 2020-08-25 03:26:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:43 --> URI Class Initialized
INFO - 2020-08-25 03:26:43 --> Router Class Initialized
INFO - 2020-08-25 03:26:43 --> Output Class Initialized
INFO - 2020-08-25 03:26:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:43 --> Input Class Initialized
INFO - 2020-08-25 03:26:43 --> Language Class Initialized
INFO - 2020-08-25 03:26:43 --> Language Class Initialized
INFO - 2020-08-25 03:26:43 --> Config Class Initialized
INFO - 2020-08-25 03:26:43 --> Loader Class Initialized
INFO - 2020-08-25 03:26:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:43 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:43 --> Controller Class Initialized
INFO - 2020-08-25 03:26:44 --> Config Class Initialized
INFO - 2020-08-25 03:26:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:44 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:44 --> URI Class Initialized
INFO - 2020-08-25 03:26:44 --> Router Class Initialized
INFO - 2020-08-25 03:26:44 --> Output Class Initialized
INFO - 2020-08-25 03:26:44 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:44 --> Input Class Initialized
INFO - 2020-08-25 03:26:44 --> Language Class Initialized
INFO - 2020-08-25 03:26:44 --> Language Class Initialized
INFO - 2020-08-25 03:26:44 --> Config Class Initialized
INFO - 2020-08-25 03:26:44 --> Loader Class Initialized
INFO - 2020-08-25 03:26:44 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:44 --> Controller Class Initialized
INFO - 2020-08-25 03:26:44 --> Config Class Initialized
INFO - 2020-08-25 03:26:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:44 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:44 --> URI Class Initialized
INFO - 2020-08-25 03:26:44 --> Router Class Initialized
INFO - 2020-08-25 03:26:44 --> Output Class Initialized
INFO - 2020-08-25 03:26:44 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:44 --> Input Class Initialized
INFO - 2020-08-25 03:26:44 --> Language Class Initialized
INFO - 2020-08-25 03:26:44 --> Language Class Initialized
INFO - 2020-08-25 03:26:44 --> Config Class Initialized
INFO - 2020-08-25 03:26:44 --> Loader Class Initialized
INFO - 2020-08-25 03:26:44 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:44 --> Controller Class Initialized
INFO - 2020-08-25 03:26:44 --> Config Class Initialized
INFO - 2020-08-25 03:26:44 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:44 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:44 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:44 --> URI Class Initialized
INFO - 2020-08-25 03:26:44 --> Router Class Initialized
INFO - 2020-08-25 03:26:44 --> Output Class Initialized
INFO - 2020-08-25 03:26:44 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:44 --> Input Class Initialized
INFO - 2020-08-25 03:26:44 --> Language Class Initialized
INFO - 2020-08-25 03:26:44 --> Language Class Initialized
INFO - 2020-08-25 03:26:44 --> Config Class Initialized
INFO - 2020-08-25 03:26:44 --> Loader Class Initialized
INFO - 2020-08-25 03:26:44 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:44 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:44 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:44 --> Controller Class Initialized
INFO - 2020-08-25 03:26:45 --> Config Class Initialized
INFO - 2020-08-25 03:26:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:45 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:45 --> URI Class Initialized
INFO - 2020-08-25 03:26:45 --> Router Class Initialized
INFO - 2020-08-25 03:26:45 --> Output Class Initialized
INFO - 2020-08-25 03:26:45 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:45 --> Input Class Initialized
INFO - 2020-08-25 03:26:45 --> Language Class Initialized
INFO - 2020-08-25 03:26:45 --> Language Class Initialized
INFO - 2020-08-25 03:26:45 --> Config Class Initialized
INFO - 2020-08-25 03:26:45 --> Loader Class Initialized
INFO - 2020-08-25 03:26:45 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:45 --> Controller Class Initialized
INFO - 2020-08-25 03:26:45 --> Config Class Initialized
INFO - 2020-08-25 03:26:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:45 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:45 --> URI Class Initialized
INFO - 2020-08-25 03:26:45 --> Router Class Initialized
INFO - 2020-08-25 03:26:45 --> Output Class Initialized
INFO - 2020-08-25 03:26:45 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:45 --> Input Class Initialized
INFO - 2020-08-25 03:26:45 --> Language Class Initialized
INFO - 2020-08-25 03:26:45 --> Language Class Initialized
INFO - 2020-08-25 03:26:45 --> Config Class Initialized
INFO - 2020-08-25 03:26:45 --> Loader Class Initialized
INFO - 2020-08-25 03:26:45 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:45 --> Controller Class Initialized
INFO - 2020-08-25 03:26:45 --> Config Class Initialized
INFO - 2020-08-25 03:26:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:45 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:45 --> URI Class Initialized
INFO - 2020-08-25 03:26:45 --> Router Class Initialized
INFO - 2020-08-25 03:26:45 --> Output Class Initialized
INFO - 2020-08-25 03:26:45 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:45 --> Input Class Initialized
INFO - 2020-08-25 03:26:45 --> Language Class Initialized
INFO - 2020-08-25 03:26:45 --> Language Class Initialized
INFO - 2020-08-25 03:26:45 --> Config Class Initialized
INFO - 2020-08-25 03:26:45 --> Loader Class Initialized
INFO - 2020-08-25 03:26:45 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:45 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:45 --> Controller Class Initialized
INFO - 2020-08-25 03:26:46 --> Config Class Initialized
INFO - 2020-08-25 03:26:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:46 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:46 --> URI Class Initialized
INFO - 2020-08-25 03:26:46 --> Router Class Initialized
INFO - 2020-08-25 03:26:46 --> Output Class Initialized
INFO - 2020-08-25 03:26:46 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:46 --> Input Class Initialized
INFO - 2020-08-25 03:26:46 --> Language Class Initialized
INFO - 2020-08-25 03:26:46 --> Language Class Initialized
INFO - 2020-08-25 03:26:46 --> Config Class Initialized
INFO - 2020-08-25 03:26:46 --> Loader Class Initialized
INFO - 2020-08-25 03:26:46 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:46 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:46 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:46 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:46 --> Controller Class Initialized
INFO - 2020-08-25 03:26:47 --> Config Class Initialized
INFO - 2020-08-25 03:26:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:47 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:47 --> URI Class Initialized
INFO - 2020-08-25 03:26:47 --> Router Class Initialized
INFO - 2020-08-25 03:26:47 --> Output Class Initialized
INFO - 2020-08-25 03:26:47 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:47 --> Input Class Initialized
INFO - 2020-08-25 03:26:47 --> Language Class Initialized
INFO - 2020-08-25 03:26:47 --> Language Class Initialized
INFO - 2020-08-25 03:26:47 --> Config Class Initialized
INFO - 2020-08-25 03:26:47 --> Loader Class Initialized
INFO - 2020-08-25 03:26:47 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:47 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:47 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:47 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:47 --> Controller Class Initialized
INFO - 2020-08-25 03:26:49 --> Config Class Initialized
INFO - 2020-08-25 03:26:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:49 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:49 --> URI Class Initialized
INFO - 2020-08-25 03:26:49 --> Router Class Initialized
INFO - 2020-08-25 03:26:49 --> Output Class Initialized
INFO - 2020-08-25 03:26:49 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:49 --> Input Class Initialized
INFO - 2020-08-25 03:26:49 --> Language Class Initialized
INFO - 2020-08-25 03:26:49 --> Language Class Initialized
INFO - 2020-08-25 03:26:49 --> Config Class Initialized
INFO - 2020-08-25 03:26:49 --> Loader Class Initialized
INFO - 2020-08-25 03:26:49 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:49 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:49 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:49 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:49 --> Controller Class Initialized
INFO - 2020-08-25 03:26:50 --> Config Class Initialized
INFO - 2020-08-25 03:26:50 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:26:50 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:26:50 --> Utf8 Class Initialized
INFO - 2020-08-25 03:26:50 --> URI Class Initialized
INFO - 2020-08-25 03:26:50 --> Router Class Initialized
INFO - 2020-08-25 03:26:50 --> Output Class Initialized
INFO - 2020-08-25 03:26:50 --> Security Class Initialized
DEBUG - 2020-08-25 03:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:26:50 --> Input Class Initialized
INFO - 2020-08-25 03:26:50 --> Language Class Initialized
INFO - 2020-08-25 03:26:50 --> Language Class Initialized
INFO - 2020-08-25 03:26:50 --> Config Class Initialized
INFO - 2020-08-25 03:26:50 --> Loader Class Initialized
INFO - 2020-08-25 03:26:50 --> Helper loaded: url_helper
INFO - 2020-08-25 03:26:50 --> Helper loaded: file_helper
INFO - 2020-08-25 03:26:50 --> Helper loaded: form_helper
INFO - 2020-08-25 03:26:50 --> Helper loaded: my_helper
INFO - 2020-08-25 03:26:50 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:26:50 --> Controller Class Initialized
INFO - 2020-08-25 03:27:07 --> Config Class Initialized
INFO - 2020-08-25 03:27:07 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:07 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:07 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:07 --> URI Class Initialized
INFO - 2020-08-25 03:27:07 --> Router Class Initialized
INFO - 2020-08-25 03:27:07 --> Output Class Initialized
INFO - 2020-08-25 03:27:07 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:07 --> Input Class Initialized
INFO - 2020-08-25 03:27:07 --> Language Class Initialized
INFO - 2020-08-25 03:27:07 --> Language Class Initialized
INFO - 2020-08-25 03:27:07 --> Config Class Initialized
INFO - 2020-08-25 03:27:07 --> Loader Class Initialized
INFO - 2020-08-25 03:27:07 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:07 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:07 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:07 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:07 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:07 --> Controller Class Initialized
INFO - 2020-08-25 03:27:29 --> Config Class Initialized
INFO - 2020-08-25 03:27:29 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:29 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:29 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:29 --> URI Class Initialized
INFO - 2020-08-25 03:27:29 --> Router Class Initialized
INFO - 2020-08-25 03:27:29 --> Output Class Initialized
INFO - 2020-08-25 03:27:29 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:29 --> Input Class Initialized
INFO - 2020-08-25 03:27:29 --> Language Class Initialized
INFO - 2020-08-25 03:27:29 --> Language Class Initialized
INFO - 2020-08-25 03:27:29 --> Config Class Initialized
INFO - 2020-08-25 03:27:29 --> Loader Class Initialized
INFO - 2020-08-25 03:27:29 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:29 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:29 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:29 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:29 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:29 --> Controller Class Initialized
DEBUG - 2020-08-25 03:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-08-25 03:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:27:29 --> Final output sent to browser
DEBUG - 2020-08-25 03:27:29 --> Total execution time: 0.0819
INFO - 2020-08-25 03:27:29 --> Config Class Initialized
INFO - 2020-08-25 03:27:29 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:29 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:29 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:29 --> URI Class Initialized
INFO - 2020-08-25 03:27:29 --> Router Class Initialized
INFO - 2020-08-25 03:27:29 --> Output Class Initialized
INFO - 2020-08-25 03:27:29 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:29 --> Input Class Initialized
INFO - 2020-08-25 03:27:29 --> Language Class Initialized
INFO - 2020-08-25 03:27:29 --> Language Class Initialized
INFO - 2020-08-25 03:27:29 --> Config Class Initialized
INFO - 2020-08-25 03:27:29 --> Loader Class Initialized
INFO - 2020-08-25 03:27:29 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:29 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:29 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:29 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:29 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:29 --> Controller Class Initialized
INFO - 2020-08-25 03:27:31 --> Config Class Initialized
INFO - 2020-08-25 03:27:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:31 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:31 --> URI Class Initialized
INFO - 2020-08-25 03:27:31 --> Router Class Initialized
INFO - 2020-08-25 03:27:31 --> Output Class Initialized
INFO - 2020-08-25 03:27:31 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:31 --> Input Class Initialized
INFO - 2020-08-25 03:27:31 --> Language Class Initialized
INFO - 2020-08-25 03:27:31 --> Language Class Initialized
INFO - 2020-08-25 03:27:31 --> Config Class Initialized
INFO - 2020-08-25 03:27:31 --> Loader Class Initialized
INFO - 2020-08-25 03:27:31 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:31 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:31 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:31 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:31 --> Controller Class Initialized
INFO - 2020-08-25 03:27:34 --> Config Class Initialized
INFO - 2020-08-25 03:27:34 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:34 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:34 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:34 --> URI Class Initialized
INFO - 2020-08-25 03:27:34 --> Router Class Initialized
INFO - 2020-08-25 03:27:34 --> Output Class Initialized
INFO - 2020-08-25 03:27:34 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:34 --> Input Class Initialized
INFO - 2020-08-25 03:27:34 --> Language Class Initialized
INFO - 2020-08-25 03:27:34 --> Language Class Initialized
INFO - 2020-08-25 03:27:34 --> Config Class Initialized
INFO - 2020-08-25 03:27:34 --> Loader Class Initialized
INFO - 2020-08-25 03:27:34 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:34 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:34 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:34 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:34 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:34 --> Controller Class Initialized
INFO - 2020-08-25 03:27:34 --> Final output sent to browser
DEBUG - 2020-08-25 03:27:34 --> Total execution time: 0.0503
INFO - 2020-08-25 03:27:45 --> Config Class Initialized
INFO - 2020-08-25 03:27:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:45 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:45 --> URI Class Initialized
INFO - 2020-08-25 03:27:45 --> Router Class Initialized
INFO - 2020-08-25 03:27:45 --> Output Class Initialized
INFO - 2020-08-25 03:27:45 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:45 --> Input Class Initialized
INFO - 2020-08-25 03:27:45 --> Language Class Initialized
INFO - 2020-08-25 03:27:45 --> Language Class Initialized
INFO - 2020-08-25 03:27:45 --> Config Class Initialized
INFO - 2020-08-25 03:27:45 --> Loader Class Initialized
INFO - 2020-08-25 03:27:45 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:45 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:45 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:45 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:45 --> Controller Class Initialized
INFO - 2020-08-25 03:27:45 --> Final output sent to browser
DEBUG - 2020-08-25 03:27:45 --> Total execution time: 0.0509
INFO - 2020-08-25 03:27:45 --> Config Class Initialized
INFO - 2020-08-25 03:27:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:45 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:45 --> URI Class Initialized
INFO - 2020-08-25 03:27:45 --> Router Class Initialized
INFO - 2020-08-25 03:27:45 --> Output Class Initialized
INFO - 2020-08-25 03:27:45 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:45 --> Input Class Initialized
INFO - 2020-08-25 03:27:45 --> Language Class Initialized
INFO - 2020-08-25 03:27:45 --> Language Class Initialized
INFO - 2020-08-25 03:27:45 --> Config Class Initialized
INFO - 2020-08-25 03:27:45 --> Loader Class Initialized
INFO - 2020-08-25 03:27:45 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:45 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:45 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:45 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:45 --> Controller Class Initialized
INFO - 2020-08-25 03:27:48 --> Config Class Initialized
INFO - 2020-08-25 03:27:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:48 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:48 --> URI Class Initialized
INFO - 2020-08-25 03:27:48 --> Router Class Initialized
INFO - 2020-08-25 03:27:48 --> Output Class Initialized
INFO - 2020-08-25 03:27:48 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:48 --> Input Class Initialized
INFO - 2020-08-25 03:27:48 --> Language Class Initialized
INFO - 2020-08-25 03:27:48 --> Language Class Initialized
INFO - 2020-08-25 03:27:48 --> Config Class Initialized
INFO - 2020-08-25 03:27:48 --> Loader Class Initialized
INFO - 2020-08-25 03:27:48 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:48 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:48 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:48 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:48 --> Controller Class Initialized
DEBUG - 2020-08-25 03:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:27:48 --> Final output sent to browser
DEBUG - 2020-08-25 03:27:48 --> Total execution time: 0.0642
INFO - 2020-08-25 03:27:54 --> Config Class Initialized
INFO - 2020-08-25 03:27:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:27:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:27:54 --> Utf8 Class Initialized
INFO - 2020-08-25 03:27:54 --> URI Class Initialized
INFO - 2020-08-25 03:27:54 --> Router Class Initialized
INFO - 2020-08-25 03:27:54 --> Output Class Initialized
INFO - 2020-08-25 03:27:54 --> Security Class Initialized
DEBUG - 2020-08-25 03:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:27:54 --> Input Class Initialized
INFO - 2020-08-25 03:27:54 --> Language Class Initialized
INFO - 2020-08-25 03:27:54 --> Language Class Initialized
INFO - 2020-08-25 03:27:54 --> Config Class Initialized
INFO - 2020-08-25 03:27:54 --> Loader Class Initialized
INFO - 2020-08-25 03:27:54 --> Helper loaded: url_helper
INFO - 2020-08-25 03:27:54 --> Helper loaded: file_helper
INFO - 2020-08-25 03:27:54 --> Helper loaded: form_helper
INFO - 2020-08-25 03:27:54 --> Helper loaded: my_helper
INFO - 2020-08-25 03:27:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:27:54 --> Controller Class Initialized
DEBUG - 2020-08-25 03:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-25 03:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:27:54 --> Final output sent to browser
DEBUG - 2020-08-25 03:27:54 --> Total execution time: 0.0522
INFO - 2020-08-25 03:28:03 --> Config Class Initialized
INFO - 2020-08-25 03:28:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:28:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:28:03 --> Utf8 Class Initialized
INFO - 2020-08-25 03:28:03 --> URI Class Initialized
INFO - 2020-08-25 03:28:03 --> Router Class Initialized
INFO - 2020-08-25 03:28:03 --> Output Class Initialized
INFO - 2020-08-25 03:28:03 --> Security Class Initialized
DEBUG - 2020-08-25 03:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:28:03 --> Input Class Initialized
INFO - 2020-08-25 03:28:03 --> Language Class Initialized
INFO - 2020-08-25 03:28:03 --> Language Class Initialized
INFO - 2020-08-25 03:28:03 --> Config Class Initialized
INFO - 2020-08-25 03:28:03 --> Loader Class Initialized
INFO - 2020-08-25 03:28:03 --> Helper loaded: url_helper
INFO - 2020-08-25 03:28:03 --> Helper loaded: file_helper
INFO - 2020-08-25 03:28:03 --> Helper loaded: form_helper
INFO - 2020-08-25 03:28:03 --> Helper loaded: my_helper
INFO - 2020-08-25 03:28:03 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:28:03 --> Controller Class Initialized
INFO - 2020-08-25 03:28:03 --> Config Class Initialized
INFO - 2020-08-25 03:28:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:28:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:28:03 --> Utf8 Class Initialized
INFO - 2020-08-25 03:28:03 --> URI Class Initialized
INFO - 2020-08-25 03:28:03 --> Router Class Initialized
INFO - 2020-08-25 03:28:03 --> Output Class Initialized
INFO - 2020-08-25 03:28:03 --> Security Class Initialized
DEBUG - 2020-08-25 03:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:28:03 --> Input Class Initialized
INFO - 2020-08-25 03:28:03 --> Language Class Initialized
INFO - 2020-08-25 03:28:03 --> Language Class Initialized
INFO - 2020-08-25 03:28:03 --> Config Class Initialized
INFO - 2020-08-25 03:28:03 --> Loader Class Initialized
INFO - 2020-08-25 03:28:03 --> Helper loaded: url_helper
INFO - 2020-08-25 03:28:03 --> Helper loaded: file_helper
INFO - 2020-08-25 03:28:03 --> Helper loaded: form_helper
INFO - 2020-08-25 03:28:03 --> Helper loaded: my_helper
INFO - 2020-08-25 03:28:03 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:28:03 --> Controller Class Initialized
DEBUG - 2020-08-25 03:28:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:28:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:28:03 --> Final output sent to browser
DEBUG - 2020-08-25 03:28:03 --> Total execution time: 0.0628
INFO - 2020-08-25 03:28:19 --> Config Class Initialized
INFO - 2020-08-25 03:28:19 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:28:19 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:28:19 --> Utf8 Class Initialized
INFO - 2020-08-25 03:28:19 --> URI Class Initialized
INFO - 2020-08-25 03:28:19 --> Router Class Initialized
INFO - 2020-08-25 03:28:19 --> Output Class Initialized
INFO - 2020-08-25 03:28:19 --> Security Class Initialized
DEBUG - 2020-08-25 03:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:28:19 --> Input Class Initialized
INFO - 2020-08-25 03:28:19 --> Language Class Initialized
INFO - 2020-08-25 03:28:19 --> Language Class Initialized
INFO - 2020-08-25 03:28:19 --> Config Class Initialized
INFO - 2020-08-25 03:28:19 --> Loader Class Initialized
INFO - 2020-08-25 03:28:19 --> Helper loaded: url_helper
INFO - 2020-08-25 03:28:19 --> Helper loaded: file_helper
INFO - 2020-08-25 03:28:19 --> Helper loaded: form_helper
INFO - 2020-08-25 03:28:19 --> Helper loaded: my_helper
INFO - 2020-08-25 03:28:19 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:28:19 --> Controller Class Initialized
DEBUG - 2020-08-25 03:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:28:19 --> Final output sent to browser
DEBUG - 2020-08-25 03:28:19 --> Total execution time: 0.0524
INFO - 2020-08-25 03:28:29 --> Config Class Initialized
INFO - 2020-08-25 03:28:29 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:28:29 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:28:29 --> Utf8 Class Initialized
INFO - 2020-08-25 03:28:29 --> URI Class Initialized
INFO - 2020-08-25 03:28:29 --> Router Class Initialized
INFO - 2020-08-25 03:28:29 --> Output Class Initialized
INFO - 2020-08-25 03:28:29 --> Security Class Initialized
DEBUG - 2020-08-25 03:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:28:29 --> Input Class Initialized
INFO - 2020-08-25 03:28:29 --> Language Class Initialized
INFO - 2020-08-25 03:28:29 --> Language Class Initialized
INFO - 2020-08-25 03:28:29 --> Config Class Initialized
INFO - 2020-08-25 03:28:29 --> Loader Class Initialized
INFO - 2020-08-25 03:28:29 --> Helper loaded: url_helper
INFO - 2020-08-25 03:28:29 --> Helper loaded: file_helper
INFO - 2020-08-25 03:28:29 --> Helper loaded: form_helper
INFO - 2020-08-25 03:28:29 --> Helper loaded: my_helper
INFO - 2020-08-25 03:28:29 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:28:29 --> Controller Class Initialized
DEBUG - 2020-08-25 03:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-25 03:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:28:29 --> Final output sent to browser
DEBUG - 2020-08-25 03:28:29 --> Total execution time: 0.0447
INFO - 2020-08-25 03:28:40 --> Config Class Initialized
INFO - 2020-08-25 03:28:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:28:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:28:40 --> Utf8 Class Initialized
INFO - 2020-08-25 03:28:40 --> URI Class Initialized
INFO - 2020-08-25 03:28:40 --> Router Class Initialized
INFO - 2020-08-25 03:28:40 --> Output Class Initialized
INFO - 2020-08-25 03:28:40 --> Security Class Initialized
DEBUG - 2020-08-25 03:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:28:40 --> Input Class Initialized
INFO - 2020-08-25 03:28:40 --> Language Class Initialized
INFO - 2020-08-25 03:28:40 --> Language Class Initialized
INFO - 2020-08-25 03:28:40 --> Config Class Initialized
INFO - 2020-08-25 03:28:40 --> Loader Class Initialized
INFO - 2020-08-25 03:28:40 --> Helper loaded: url_helper
INFO - 2020-08-25 03:28:40 --> Helper loaded: file_helper
INFO - 2020-08-25 03:28:40 --> Helper loaded: form_helper
INFO - 2020-08-25 03:28:40 --> Helper loaded: my_helper
INFO - 2020-08-25 03:28:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:28:40 --> Controller Class Initialized
DEBUG - 2020-08-25 03:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:28:40 --> Final output sent to browser
DEBUG - 2020-08-25 03:28:40 --> Total execution time: 0.0635
INFO - 2020-08-25 03:29:30 --> Config Class Initialized
INFO - 2020-08-25 03:29:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:29:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:29:30 --> Utf8 Class Initialized
INFO - 2020-08-25 03:29:30 --> URI Class Initialized
INFO - 2020-08-25 03:29:30 --> Router Class Initialized
INFO - 2020-08-25 03:29:30 --> Output Class Initialized
INFO - 2020-08-25 03:29:30 --> Security Class Initialized
DEBUG - 2020-08-25 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:29:30 --> Input Class Initialized
INFO - 2020-08-25 03:29:30 --> Language Class Initialized
INFO - 2020-08-25 03:29:30 --> Language Class Initialized
INFO - 2020-08-25 03:29:30 --> Config Class Initialized
INFO - 2020-08-25 03:29:30 --> Loader Class Initialized
INFO - 2020-08-25 03:29:30 --> Helper loaded: url_helper
INFO - 2020-08-25 03:29:30 --> Helper loaded: file_helper
INFO - 2020-08-25 03:29:30 --> Helper loaded: form_helper
INFO - 2020-08-25 03:29:30 --> Helper loaded: my_helper
INFO - 2020-08-25 03:29:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:29:30 --> Controller Class Initialized
DEBUG - 2020-08-25 03:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 03:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:29:30 --> Final output sent to browser
DEBUG - 2020-08-25 03:29:30 --> Total execution time: 0.0503
INFO - 2020-08-25 03:29:30 --> Config Class Initialized
INFO - 2020-08-25 03:29:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:29:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:29:30 --> Utf8 Class Initialized
INFO - 2020-08-25 03:29:30 --> URI Class Initialized
INFO - 2020-08-25 03:29:30 --> Router Class Initialized
INFO - 2020-08-25 03:29:30 --> Output Class Initialized
INFO - 2020-08-25 03:29:30 --> Security Class Initialized
DEBUG - 2020-08-25 03:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:29:30 --> Input Class Initialized
INFO - 2020-08-25 03:29:30 --> Language Class Initialized
INFO - 2020-08-25 03:29:30 --> Language Class Initialized
INFO - 2020-08-25 03:29:30 --> Config Class Initialized
INFO - 2020-08-25 03:29:30 --> Loader Class Initialized
INFO - 2020-08-25 03:29:30 --> Helper loaded: url_helper
INFO - 2020-08-25 03:29:30 --> Helper loaded: file_helper
INFO - 2020-08-25 03:29:30 --> Helper loaded: form_helper
INFO - 2020-08-25 03:29:30 --> Helper loaded: my_helper
INFO - 2020-08-25 03:29:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:29:30 --> Controller Class Initialized
INFO - 2020-08-25 03:29:38 --> Config Class Initialized
INFO - 2020-08-25 03:29:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:29:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:29:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:29:38 --> URI Class Initialized
INFO - 2020-08-25 03:29:38 --> Router Class Initialized
INFO - 2020-08-25 03:29:38 --> Output Class Initialized
INFO - 2020-08-25 03:29:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:29:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:29:38 --> Input Class Initialized
INFO - 2020-08-25 03:29:38 --> Language Class Initialized
INFO - 2020-08-25 03:29:38 --> Language Class Initialized
INFO - 2020-08-25 03:29:38 --> Config Class Initialized
INFO - 2020-08-25 03:29:38 --> Loader Class Initialized
INFO - 2020-08-25 03:29:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:29:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:29:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:29:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:29:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:29:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:29:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:29:38 --> Controller Class Initialized
INFO - 2020-08-25 03:31:42 --> Config Class Initialized
INFO - 2020-08-25 03:31:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:31:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:31:42 --> Utf8 Class Initialized
INFO - 2020-08-25 03:31:42 --> URI Class Initialized
INFO - 2020-08-25 03:31:42 --> Router Class Initialized
INFO - 2020-08-25 03:31:42 --> Output Class Initialized
INFO - 2020-08-25 03:31:42 --> Security Class Initialized
DEBUG - 2020-08-25 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:31:42 --> Input Class Initialized
INFO - 2020-08-25 03:31:42 --> Language Class Initialized
INFO - 2020-08-25 03:31:42 --> Language Class Initialized
INFO - 2020-08-25 03:31:42 --> Config Class Initialized
INFO - 2020-08-25 03:31:42 --> Loader Class Initialized
INFO - 2020-08-25 03:31:42 --> Helper loaded: url_helper
INFO - 2020-08-25 03:31:42 --> Helper loaded: file_helper
INFO - 2020-08-25 03:31:42 --> Helper loaded: form_helper
INFO - 2020-08-25 03:31:42 --> Helper loaded: my_helper
INFO - 2020-08-25 03:31:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:31:42 --> Controller Class Initialized
INFO - 2020-08-25 03:31:42 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:31:42 --> Config Class Initialized
INFO - 2020-08-25 03:31:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:31:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:31:42 --> Utf8 Class Initialized
INFO - 2020-08-25 03:31:42 --> URI Class Initialized
INFO - 2020-08-25 03:31:42 --> Router Class Initialized
INFO - 2020-08-25 03:31:42 --> Output Class Initialized
INFO - 2020-08-25 03:31:42 --> Security Class Initialized
DEBUG - 2020-08-25 03:31:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:31:42 --> Input Class Initialized
INFO - 2020-08-25 03:31:42 --> Language Class Initialized
INFO - 2020-08-25 03:31:42 --> Language Class Initialized
INFO - 2020-08-25 03:31:42 --> Config Class Initialized
INFO - 2020-08-25 03:31:42 --> Loader Class Initialized
INFO - 2020-08-25 03:31:42 --> Helper loaded: url_helper
INFO - 2020-08-25 03:31:42 --> Helper loaded: file_helper
INFO - 2020-08-25 03:31:42 --> Helper loaded: form_helper
INFO - 2020-08-25 03:31:42 --> Helper loaded: my_helper
INFO - 2020-08-25 03:31:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:31:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:31:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:31:42 --> Controller Class Initialized
DEBUG - 2020-08-25 03:31:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 03:31:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:31:42 --> Final output sent to browser
DEBUG - 2020-08-25 03:31:42 --> Total execution time: 0.0403
INFO - 2020-08-25 03:31:46 --> Config Class Initialized
INFO - 2020-08-25 03:31:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:31:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:31:46 --> Utf8 Class Initialized
INFO - 2020-08-25 03:31:46 --> URI Class Initialized
INFO - 2020-08-25 03:31:46 --> Router Class Initialized
INFO - 2020-08-25 03:31:46 --> Output Class Initialized
INFO - 2020-08-25 03:31:46 --> Security Class Initialized
DEBUG - 2020-08-25 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:31:46 --> Input Class Initialized
INFO - 2020-08-25 03:31:46 --> Language Class Initialized
INFO - 2020-08-25 03:31:46 --> Language Class Initialized
INFO - 2020-08-25 03:31:46 --> Config Class Initialized
INFO - 2020-08-25 03:31:46 --> Loader Class Initialized
INFO - 2020-08-25 03:31:46 --> Helper loaded: url_helper
INFO - 2020-08-25 03:31:46 --> Helper loaded: file_helper
INFO - 2020-08-25 03:31:46 --> Helper loaded: form_helper
INFO - 2020-08-25 03:31:46 --> Helper loaded: my_helper
INFO - 2020-08-25 03:31:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:31:46 --> Controller Class Initialized
INFO - 2020-08-25 03:31:46 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:31:46 --> Final output sent to browser
DEBUG - 2020-08-25 03:31:46 --> Total execution time: 0.0476
INFO - 2020-08-25 03:31:46 --> Config Class Initialized
INFO - 2020-08-25 03:31:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:31:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:31:46 --> Utf8 Class Initialized
INFO - 2020-08-25 03:31:46 --> URI Class Initialized
INFO - 2020-08-25 03:31:46 --> Router Class Initialized
INFO - 2020-08-25 03:31:46 --> Output Class Initialized
INFO - 2020-08-25 03:31:46 --> Security Class Initialized
DEBUG - 2020-08-25 03:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:31:46 --> Input Class Initialized
INFO - 2020-08-25 03:31:46 --> Language Class Initialized
INFO - 2020-08-25 03:31:46 --> Language Class Initialized
INFO - 2020-08-25 03:31:46 --> Config Class Initialized
INFO - 2020-08-25 03:31:46 --> Loader Class Initialized
INFO - 2020-08-25 03:31:46 --> Helper loaded: url_helper
INFO - 2020-08-25 03:31:46 --> Helper loaded: file_helper
INFO - 2020-08-25 03:31:46 --> Helper loaded: form_helper
INFO - 2020-08-25 03:31:46 --> Helper loaded: my_helper
INFO - 2020-08-25 03:31:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:31:46 --> Controller Class Initialized
DEBUG - 2020-08-25 03:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 03:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:31:47 --> Final output sent to browser
DEBUG - 2020-08-25 03:31:47 --> Total execution time: 0.6365
INFO - 2020-08-25 03:31:48 --> Config Class Initialized
INFO - 2020-08-25 03:31:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:31:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:31:48 --> Utf8 Class Initialized
INFO - 2020-08-25 03:31:48 --> URI Class Initialized
INFO - 2020-08-25 03:31:48 --> Router Class Initialized
INFO - 2020-08-25 03:31:48 --> Output Class Initialized
INFO - 2020-08-25 03:31:48 --> Security Class Initialized
DEBUG - 2020-08-25 03:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:31:48 --> Input Class Initialized
INFO - 2020-08-25 03:31:48 --> Language Class Initialized
INFO - 2020-08-25 03:31:48 --> Language Class Initialized
INFO - 2020-08-25 03:31:48 --> Config Class Initialized
INFO - 2020-08-25 03:31:48 --> Loader Class Initialized
INFO - 2020-08-25 03:31:48 --> Helper loaded: url_helper
INFO - 2020-08-25 03:31:48 --> Helper loaded: file_helper
INFO - 2020-08-25 03:31:48 --> Helper loaded: form_helper
INFO - 2020-08-25 03:31:48 --> Helper loaded: my_helper
INFO - 2020-08-25 03:31:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:31:48 --> Controller Class Initialized
DEBUG - 2020-08-25 03:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-25 03:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:31:48 --> Final output sent to browser
DEBUG - 2020-08-25 03:31:48 --> Total execution time: 0.0545
INFO - 2020-08-25 03:33:06 --> Config Class Initialized
INFO - 2020-08-25 03:33:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:06 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:06 --> URI Class Initialized
INFO - 2020-08-25 03:33:06 --> Router Class Initialized
INFO - 2020-08-25 03:33:06 --> Output Class Initialized
INFO - 2020-08-25 03:33:06 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:06 --> Input Class Initialized
INFO - 2020-08-25 03:33:06 --> Language Class Initialized
INFO - 2020-08-25 03:33:06 --> Language Class Initialized
INFO - 2020-08-25 03:33:06 --> Config Class Initialized
INFO - 2020-08-25 03:33:06 --> Loader Class Initialized
INFO - 2020-08-25 03:33:06 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:06 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:06 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:06 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:06 --> Controller Class Initialized
DEBUG - 2020-08-25 03:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-25 03:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:33:06 --> Final output sent to browser
DEBUG - 2020-08-25 03:33:06 --> Total execution time: 0.0413
INFO - 2020-08-25 03:33:11 --> Config Class Initialized
INFO - 2020-08-25 03:33:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:11 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:11 --> URI Class Initialized
INFO - 2020-08-25 03:33:11 --> Router Class Initialized
INFO - 2020-08-25 03:33:11 --> Output Class Initialized
INFO - 2020-08-25 03:33:11 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:11 --> Input Class Initialized
INFO - 2020-08-25 03:33:11 --> Language Class Initialized
INFO - 2020-08-25 03:33:11 --> Language Class Initialized
INFO - 2020-08-25 03:33:11 --> Config Class Initialized
INFO - 2020-08-25 03:33:11 --> Loader Class Initialized
INFO - 2020-08-25 03:33:11 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:11 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:11 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:11 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:11 --> Controller Class Initialized
INFO - 2020-08-25 03:33:11 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:33:11 --> Config Class Initialized
INFO - 2020-08-25 03:33:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:11 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:11 --> URI Class Initialized
INFO - 2020-08-25 03:33:11 --> Router Class Initialized
INFO - 2020-08-25 03:33:11 --> Output Class Initialized
INFO - 2020-08-25 03:33:11 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:11 --> Input Class Initialized
INFO - 2020-08-25 03:33:11 --> Language Class Initialized
INFO - 2020-08-25 03:33:11 --> Language Class Initialized
INFO - 2020-08-25 03:33:11 --> Config Class Initialized
INFO - 2020-08-25 03:33:11 --> Loader Class Initialized
INFO - 2020-08-25 03:33:11 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:11 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:11 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:11 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:11 --> Controller Class Initialized
DEBUG - 2020-08-25 03:33:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 03:33:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:33:11 --> Final output sent to browser
DEBUG - 2020-08-25 03:33:11 --> Total execution time: 0.0486
INFO - 2020-08-25 03:33:16 --> Config Class Initialized
INFO - 2020-08-25 03:33:16 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:16 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:16 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:16 --> URI Class Initialized
INFO - 2020-08-25 03:33:16 --> Router Class Initialized
INFO - 2020-08-25 03:33:16 --> Output Class Initialized
INFO - 2020-08-25 03:33:16 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:16 --> Input Class Initialized
INFO - 2020-08-25 03:33:16 --> Language Class Initialized
INFO - 2020-08-25 03:33:16 --> Language Class Initialized
INFO - 2020-08-25 03:33:16 --> Config Class Initialized
INFO - 2020-08-25 03:33:16 --> Loader Class Initialized
INFO - 2020-08-25 03:33:16 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:16 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:16 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:16 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:16 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:16 --> Controller Class Initialized
INFO - 2020-08-25 03:33:16 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:33:16 --> Final output sent to browser
DEBUG - 2020-08-25 03:33:16 --> Total execution time: 0.0510
INFO - 2020-08-25 03:33:16 --> Config Class Initialized
INFO - 2020-08-25 03:33:16 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:16 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:16 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:16 --> URI Class Initialized
INFO - 2020-08-25 03:33:16 --> Router Class Initialized
INFO - 2020-08-25 03:33:16 --> Output Class Initialized
INFO - 2020-08-25 03:33:16 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:16 --> Input Class Initialized
INFO - 2020-08-25 03:33:16 --> Language Class Initialized
INFO - 2020-08-25 03:33:16 --> Language Class Initialized
INFO - 2020-08-25 03:33:16 --> Config Class Initialized
INFO - 2020-08-25 03:33:16 --> Loader Class Initialized
INFO - 2020-08-25 03:33:16 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:16 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:16 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:16 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:16 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:16 --> Controller Class Initialized
DEBUG - 2020-08-25 03:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 03:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:33:16 --> Final output sent to browser
DEBUG - 2020-08-25 03:33:16 --> Total execution time: 0.6112
INFO - 2020-08-25 03:33:20 --> Config Class Initialized
INFO - 2020-08-25 03:33:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:20 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:20 --> URI Class Initialized
INFO - 2020-08-25 03:33:20 --> Router Class Initialized
INFO - 2020-08-25 03:33:20 --> Output Class Initialized
INFO - 2020-08-25 03:33:20 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:20 --> Input Class Initialized
INFO - 2020-08-25 03:33:20 --> Language Class Initialized
INFO - 2020-08-25 03:33:20 --> Language Class Initialized
INFO - 2020-08-25 03:33:20 --> Config Class Initialized
INFO - 2020-08-25 03:33:20 --> Loader Class Initialized
INFO - 2020-08-25 03:33:20 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:20 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:20 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:20 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:20 --> Controller Class Initialized
DEBUG - 2020-08-25 03:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-08-25 03:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:33:20 --> Final output sent to browser
DEBUG - 2020-08-25 03:33:20 --> Total execution time: 0.0398
INFO - 2020-08-25 03:33:20 --> Config Class Initialized
INFO - 2020-08-25 03:33:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:20 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:20 --> URI Class Initialized
INFO - 2020-08-25 03:33:20 --> Router Class Initialized
INFO - 2020-08-25 03:33:20 --> Output Class Initialized
INFO - 2020-08-25 03:33:20 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:20 --> Input Class Initialized
INFO - 2020-08-25 03:33:20 --> Language Class Initialized
INFO - 2020-08-25 03:33:20 --> Language Class Initialized
INFO - 2020-08-25 03:33:20 --> Config Class Initialized
INFO - 2020-08-25 03:33:20 --> Loader Class Initialized
INFO - 2020-08-25 03:33:20 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:20 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:20 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:20 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:20 --> Controller Class Initialized
INFO - 2020-08-25 03:33:22 --> Config Class Initialized
INFO - 2020-08-25 03:33:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:22 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:22 --> URI Class Initialized
INFO - 2020-08-25 03:33:22 --> Router Class Initialized
INFO - 2020-08-25 03:33:22 --> Output Class Initialized
INFO - 2020-08-25 03:33:22 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:22 --> Input Class Initialized
INFO - 2020-08-25 03:33:22 --> Language Class Initialized
INFO - 2020-08-25 03:33:22 --> Language Class Initialized
INFO - 2020-08-25 03:33:22 --> Config Class Initialized
INFO - 2020-08-25 03:33:22 --> Loader Class Initialized
INFO - 2020-08-25 03:33:22 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:22 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:22 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:22 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:22 --> Controller Class Initialized
INFO - 2020-08-25 03:33:35 --> Config Class Initialized
INFO - 2020-08-25 03:33:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:33:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:33:35 --> Utf8 Class Initialized
INFO - 2020-08-25 03:33:35 --> URI Class Initialized
INFO - 2020-08-25 03:33:35 --> Router Class Initialized
INFO - 2020-08-25 03:33:35 --> Output Class Initialized
INFO - 2020-08-25 03:33:35 --> Security Class Initialized
DEBUG - 2020-08-25 03:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:33:35 --> Input Class Initialized
INFO - 2020-08-25 03:33:35 --> Language Class Initialized
INFO - 2020-08-25 03:33:35 --> Language Class Initialized
INFO - 2020-08-25 03:33:35 --> Config Class Initialized
INFO - 2020-08-25 03:33:35 --> Loader Class Initialized
INFO - 2020-08-25 03:33:35 --> Helper loaded: url_helper
INFO - 2020-08-25 03:33:35 --> Helper loaded: file_helper
INFO - 2020-08-25 03:33:35 --> Helper loaded: form_helper
INFO - 2020-08-25 03:33:35 --> Helper loaded: my_helper
INFO - 2020-08-25 03:33:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:33:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:33:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:33:35 --> Controller Class Initialized
DEBUG - 2020-08-25 03:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:33:35 --> Final output sent to browser
DEBUG - 2020-08-25 03:33:35 --> Total execution time: 0.0639
INFO - 2020-08-25 03:34:35 --> Config Class Initialized
INFO - 2020-08-25 03:34:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:34:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:34:35 --> Utf8 Class Initialized
INFO - 2020-08-25 03:34:35 --> URI Class Initialized
INFO - 2020-08-25 03:34:35 --> Router Class Initialized
INFO - 2020-08-25 03:34:35 --> Output Class Initialized
INFO - 2020-08-25 03:34:35 --> Security Class Initialized
DEBUG - 2020-08-25 03:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:34:35 --> Input Class Initialized
INFO - 2020-08-25 03:34:35 --> Language Class Initialized
INFO - 2020-08-25 03:34:35 --> Language Class Initialized
INFO - 2020-08-25 03:34:35 --> Config Class Initialized
INFO - 2020-08-25 03:34:35 --> Loader Class Initialized
INFO - 2020-08-25 03:34:35 --> Helper loaded: url_helper
INFO - 2020-08-25 03:34:35 --> Helper loaded: file_helper
INFO - 2020-08-25 03:34:35 --> Helper loaded: form_helper
INFO - 2020-08-25 03:34:35 --> Helper loaded: my_helper
INFO - 2020-08-25 03:34:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:34:35 --> Controller Class Initialized
INFO - 2020-08-25 03:34:35 --> Final output sent to browser
DEBUG - 2020-08-25 03:34:35 --> Total execution time: 0.1141
INFO - 2020-08-25 03:34:46 --> Config Class Initialized
INFO - 2020-08-25 03:34:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:34:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:34:46 --> Utf8 Class Initialized
INFO - 2020-08-25 03:34:46 --> URI Class Initialized
INFO - 2020-08-25 03:34:46 --> Router Class Initialized
INFO - 2020-08-25 03:34:46 --> Output Class Initialized
INFO - 2020-08-25 03:34:46 --> Security Class Initialized
DEBUG - 2020-08-25 03:34:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:34:46 --> Input Class Initialized
INFO - 2020-08-25 03:34:46 --> Language Class Initialized
INFO - 2020-08-25 03:34:46 --> Language Class Initialized
INFO - 2020-08-25 03:34:46 --> Config Class Initialized
INFO - 2020-08-25 03:34:46 --> Loader Class Initialized
INFO - 2020-08-25 03:34:46 --> Helper loaded: url_helper
INFO - 2020-08-25 03:34:46 --> Helper loaded: file_helper
INFO - 2020-08-25 03:34:46 --> Helper loaded: form_helper
INFO - 2020-08-25 03:34:46 --> Helper loaded: my_helper
INFO - 2020-08-25 03:34:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:34:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:34:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:34:46 --> Controller Class Initialized
DEBUG - 2020-08-25 03:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-08-25 03:34:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:34:46 --> Final output sent to browser
DEBUG - 2020-08-25 03:34:46 --> Total execution time: 0.0697
INFO - 2020-08-25 03:36:05 --> Config Class Initialized
INFO - 2020-08-25 03:36:05 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:36:05 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:36:05 --> Utf8 Class Initialized
INFO - 2020-08-25 03:36:05 --> URI Class Initialized
INFO - 2020-08-25 03:36:05 --> Router Class Initialized
INFO - 2020-08-25 03:36:05 --> Output Class Initialized
INFO - 2020-08-25 03:36:05 --> Security Class Initialized
DEBUG - 2020-08-25 03:36:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:36:05 --> Input Class Initialized
INFO - 2020-08-25 03:36:05 --> Language Class Initialized
INFO - 2020-08-25 03:36:05 --> Language Class Initialized
INFO - 2020-08-25 03:36:05 --> Config Class Initialized
INFO - 2020-08-25 03:36:05 --> Loader Class Initialized
INFO - 2020-08-25 03:36:05 --> Helper loaded: url_helper
INFO - 2020-08-25 03:36:05 --> Helper loaded: file_helper
INFO - 2020-08-25 03:36:05 --> Helper loaded: form_helper
INFO - 2020-08-25 03:36:05 --> Helper loaded: my_helper
INFO - 2020-08-25 03:36:05 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:36:05 --> Controller Class Initialized
DEBUG - 2020-08-25 03:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-08-25 03:36:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:36:05 --> Final output sent to browser
DEBUG - 2020-08-25 03:36:05 --> Total execution time: 0.0511
INFO - 2020-08-25 03:36:38 --> Config Class Initialized
INFO - 2020-08-25 03:36:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:36:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:36:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:36:38 --> URI Class Initialized
INFO - 2020-08-25 03:36:38 --> Router Class Initialized
INFO - 2020-08-25 03:36:38 --> Output Class Initialized
INFO - 2020-08-25 03:36:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:36:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:36:38 --> Input Class Initialized
INFO - 2020-08-25 03:36:38 --> Language Class Initialized
INFO - 2020-08-25 03:36:38 --> Language Class Initialized
INFO - 2020-08-25 03:36:38 --> Config Class Initialized
INFO - 2020-08-25 03:36:38 --> Loader Class Initialized
INFO - 2020-08-25 03:36:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:36:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:36:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:36:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:36:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:36:38 --> Controller Class Initialized
DEBUG - 2020-08-25 03:36:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-08-25 03:36:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:36:38 --> Final output sent to browser
DEBUG - 2020-08-25 03:36:38 --> Total execution time: 0.0662
INFO - 2020-08-25 03:37:12 --> Config Class Initialized
INFO - 2020-08-25 03:37:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:37:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:37:12 --> Utf8 Class Initialized
INFO - 2020-08-25 03:37:12 --> URI Class Initialized
INFO - 2020-08-25 03:37:12 --> Router Class Initialized
INFO - 2020-08-25 03:37:12 --> Output Class Initialized
INFO - 2020-08-25 03:37:12 --> Security Class Initialized
DEBUG - 2020-08-25 03:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:37:12 --> Input Class Initialized
INFO - 2020-08-25 03:37:12 --> Language Class Initialized
INFO - 2020-08-25 03:37:12 --> Language Class Initialized
INFO - 2020-08-25 03:37:12 --> Config Class Initialized
INFO - 2020-08-25 03:37:12 --> Loader Class Initialized
INFO - 2020-08-25 03:37:12 --> Helper loaded: url_helper
INFO - 2020-08-25 03:37:12 --> Helper loaded: file_helper
INFO - 2020-08-25 03:37:12 --> Helper loaded: form_helper
INFO - 2020-08-25 03:37:12 --> Helper loaded: my_helper
INFO - 2020-08-25 03:37:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:37:12 --> Controller Class Initialized
DEBUG - 2020-08-25 03:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2020-08-25 03:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:37:12 --> Final output sent to browser
DEBUG - 2020-08-25 03:37:12 --> Total execution time: 0.0739
INFO - 2020-08-25 03:38:00 --> Config Class Initialized
INFO - 2020-08-25 03:38:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:38:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:38:00 --> Utf8 Class Initialized
INFO - 2020-08-25 03:38:00 --> URI Class Initialized
INFO - 2020-08-25 03:38:00 --> Router Class Initialized
INFO - 2020-08-25 03:38:00 --> Output Class Initialized
INFO - 2020-08-25 03:38:00 --> Security Class Initialized
DEBUG - 2020-08-25 03:38:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:38:00 --> Input Class Initialized
INFO - 2020-08-25 03:38:00 --> Language Class Initialized
INFO - 2020-08-25 03:38:00 --> Language Class Initialized
INFO - 2020-08-25 03:38:00 --> Config Class Initialized
INFO - 2020-08-25 03:38:00 --> Loader Class Initialized
INFO - 2020-08-25 03:38:00 --> Helper loaded: url_helper
INFO - 2020-08-25 03:38:00 --> Helper loaded: file_helper
INFO - 2020-08-25 03:38:00 --> Helper loaded: form_helper
INFO - 2020-08-25 03:38:00 --> Helper loaded: my_helper
INFO - 2020-08-25 03:38:00 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:38:00 --> Controller Class Initialized
DEBUG - 2020-08-25 03:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:38:00 --> Final output sent to browser
DEBUG - 2020-08-25 03:38:00 --> Total execution time: 0.0636
INFO - 2020-08-25 03:38:10 --> Config Class Initialized
INFO - 2020-08-25 03:38:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:38:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:38:10 --> Utf8 Class Initialized
INFO - 2020-08-25 03:38:10 --> URI Class Initialized
INFO - 2020-08-25 03:38:10 --> Router Class Initialized
INFO - 2020-08-25 03:38:10 --> Output Class Initialized
INFO - 2020-08-25 03:38:10 --> Security Class Initialized
DEBUG - 2020-08-25 03:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:38:10 --> Input Class Initialized
INFO - 2020-08-25 03:38:10 --> Language Class Initialized
INFO - 2020-08-25 03:38:10 --> Language Class Initialized
INFO - 2020-08-25 03:38:10 --> Config Class Initialized
INFO - 2020-08-25 03:38:10 --> Loader Class Initialized
INFO - 2020-08-25 03:38:10 --> Helper loaded: url_helper
INFO - 2020-08-25 03:38:10 --> Helper loaded: file_helper
INFO - 2020-08-25 03:38:10 --> Helper loaded: form_helper
INFO - 2020-08-25 03:38:10 --> Helper loaded: my_helper
INFO - 2020-08-25 03:38:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:38:10 --> Controller Class Initialized
INFO - 2020-08-25 03:38:10 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:38:10 --> Config Class Initialized
INFO - 2020-08-25 03:38:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:38:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:38:10 --> Utf8 Class Initialized
INFO - 2020-08-25 03:38:10 --> URI Class Initialized
INFO - 2020-08-25 03:38:10 --> Router Class Initialized
INFO - 2020-08-25 03:38:10 --> Output Class Initialized
INFO - 2020-08-25 03:38:10 --> Security Class Initialized
DEBUG - 2020-08-25 03:38:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:38:10 --> Input Class Initialized
INFO - 2020-08-25 03:38:10 --> Language Class Initialized
INFO - 2020-08-25 03:38:10 --> Language Class Initialized
INFO - 2020-08-25 03:38:10 --> Config Class Initialized
INFO - 2020-08-25 03:38:10 --> Loader Class Initialized
INFO - 2020-08-25 03:38:10 --> Helper loaded: url_helper
INFO - 2020-08-25 03:38:10 --> Helper loaded: file_helper
INFO - 2020-08-25 03:38:10 --> Helper loaded: form_helper
INFO - 2020-08-25 03:38:10 --> Helper loaded: my_helper
INFO - 2020-08-25 03:38:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:38:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:38:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:38:10 --> Controller Class Initialized
DEBUG - 2020-08-25 03:38:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 03:38:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:38:10 --> Final output sent to browser
DEBUG - 2020-08-25 03:38:10 --> Total execution time: 0.0493
INFO - 2020-08-25 03:38:30 --> Config Class Initialized
INFO - 2020-08-25 03:38:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:38:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:38:30 --> Utf8 Class Initialized
INFO - 2020-08-25 03:38:30 --> URI Class Initialized
INFO - 2020-08-25 03:38:30 --> Router Class Initialized
INFO - 2020-08-25 03:38:30 --> Output Class Initialized
INFO - 2020-08-25 03:38:30 --> Security Class Initialized
DEBUG - 2020-08-25 03:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:38:30 --> Input Class Initialized
INFO - 2020-08-25 03:38:30 --> Language Class Initialized
INFO - 2020-08-25 03:38:30 --> Language Class Initialized
INFO - 2020-08-25 03:38:30 --> Config Class Initialized
INFO - 2020-08-25 03:38:30 --> Loader Class Initialized
INFO - 2020-08-25 03:38:30 --> Helper loaded: url_helper
INFO - 2020-08-25 03:38:30 --> Helper loaded: file_helper
INFO - 2020-08-25 03:38:30 --> Helper loaded: form_helper
INFO - 2020-08-25 03:38:30 --> Helper loaded: my_helper
INFO - 2020-08-25 03:38:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:38:30 --> Controller Class Initialized
DEBUG - 2020-08-25 03:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-25 03:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:38:30 --> Final output sent to browser
DEBUG - 2020-08-25 03:38:30 --> Total execution time: 0.0435
INFO - 2020-08-25 03:39:02 --> Config Class Initialized
INFO - 2020-08-25 03:39:02 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:39:02 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:39:02 --> Utf8 Class Initialized
INFO - 2020-08-25 03:39:02 --> URI Class Initialized
INFO - 2020-08-25 03:39:02 --> Router Class Initialized
INFO - 2020-08-25 03:39:02 --> Output Class Initialized
INFO - 2020-08-25 03:39:02 --> Security Class Initialized
DEBUG - 2020-08-25 03:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:39:02 --> Input Class Initialized
INFO - 2020-08-25 03:39:02 --> Language Class Initialized
INFO - 2020-08-25 03:39:02 --> Language Class Initialized
INFO - 2020-08-25 03:39:02 --> Config Class Initialized
INFO - 2020-08-25 03:39:02 --> Loader Class Initialized
INFO - 2020-08-25 03:39:02 --> Helper loaded: url_helper
INFO - 2020-08-25 03:39:02 --> Helper loaded: file_helper
INFO - 2020-08-25 03:39:02 --> Helper loaded: form_helper
INFO - 2020-08-25 03:39:02 --> Helper loaded: my_helper
INFO - 2020-08-25 03:39:02 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:39:02 --> Controller Class Initialized
INFO - 2020-08-25 03:39:02 --> Config Class Initialized
INFO - 2020-08-25 03:39:02 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:39:02 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:39:02 --> Utf8 Class Initialized
INFO - 2020-08-25 03:39:02 --> URI Class Initialized
INFO - 2020-08-25 03:39:02 --> Router Class Initialized
INFO - 2020-08-25 03:39:02 --> Output Class Initialized
INFO - 2020-08-25 03:39:02 --> Security Class Initialized
DEBUG - 2020-08-25 03:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:39:02 --> Input Class Initialized
INFO - 2020-08-25 03:39:02 --> Language Class Initialized
INFO - 2020-08-25 03:39:02 --> Language Class Initialized
INFO - 2020-08-25 03:39:02 --> Config Class Initialized
INFO - 2020-08-25 03:39:02 --> Loader Class Initialized
INFO - 2020-08-25 03:39:02 --> Helper loaded: url_helper
INFO - 2020-08-25 03:39:02 --> Helper loaded: file_helper
INFO - 2020-08-25 03:39:02 --> Helper loaded: form_helper
INFO - 2020-08-25 03:39:02 --> Helper loaded: my_helper
INFO - 2020-08-25 03:39:02 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:39:02 --> Controller Class Initialized
DEBUG - 2020-08-25 03:39:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:39:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:39:02 --> Final output sent to browser
DEBUG - 2020-08-25 03:39:02 --> Total execution time: 0.0523
INFO - 2020-08-25 03:39:11 --> Config Class Initialized
INFO - 2020-08-25 03:39:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:39:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:39:11 --> Utf8 Class Initialized
INFO - 2020-08-25 03:39:11 --> URI Class Initialized
INFO - 2020-08-25 03:39:11 --> Router Class Initialized
INFO - 2020-08-25 03:39:11 --> Output Class Initialized
INFO - 2020-08-25 03:39:11 --> Security Class Initialized
DEBUG - 2020-08-25 03:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:39:11 --> Input Class Initialized
INFO - 2020-08-25 03:39:11 --> Language Class Initialized
INFO - 2020-08-25 03:39:11 --> Language Class Initialized
INFO - 2020-08-25 03:39:11 --> Config Class Initialized
INFO - 2020-08-25 03:39:11 --> Loader Class Initialized
INFO - 2020-08-25 03:39:11 --> Helper loaded: url_helper
INFO - 2020-08-25 03:39:11 --> Helper loaded: file_helper
INFO - 2020-08-25 03:39:11 --> Helper loaded: form_helper
INFO - 2020-08-25 03:39:11 --> Helper loaded: my_helper
INFO - 2020-08-25 03:39:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:39:11 --> Controller Class Initialized
DEBUG - 2020-08-25 03:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-08-25 03:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:39:11 --> Final output sent to browser
DEBUG - 2020-08-25 03:39:11 --> Total execution time: 0.0435
INFO - 2020-08-25 03:39:17 --> Config Class Initialized
INFO - 2020-08-25 03:39:17 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:39:17 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:39:17 --> Utf8 Class Initialized
INFO - 2020-08-25 03:39:17 --> URI Class Initialized
INFO - 2020-08-25 03:39:17 --> Router Class Initialized
INFO - 2020-08-25 03:39:17 --> Output Class Initialized
INFO - 2020-08-25 03:39:17 --> Security Class Initialized
DEBUG - 2020-08-25 03:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:39:17 --> Input Class Initialized
INFO - 2020-08-25 03:39:17 --> Language Class Initialized
INFO - 2020-08-25 03:39:17 --> Language Class Initialized
INFO - 2020-08-25 03:39:17 --> Config Class Initialized
INFO - 2020-08-25 03:39:17 --> Loader Class Initialized
INFO - 2020-08-25 03:39:17 --> Helper loaded: url_helper
INFO - 2020-08-25 03:39:17 --> Helper loaded: file_helper
INFO - 2020-08-25 03:39:17 --> Helper loaded: form_helper
INFO - 2020-08-25 03:39:17 --> Helper loaded: my_helper
INFO - 2020-08-25 03:39:17 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:39:17 --> Controller Class Initialized
INFO - 2020-08-25 03:39:17 --> Config Class Initialized
INFO - 2020-08-25 03:39:17 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:39:17 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:39:17 --> Utf8 Class Initialized
INFO - 2020-08-25 03:39:17 --> URI Class Initialized
INFO - 2020-08-25 03:39:17 --> Router Class Initialized
INFO - 2020-08-25 03:39:17 --> Output Class Initialized
INFO - 2020-08-25 03:39:17 --> Security Class Initialized
DEBUG - 2020-08-25 03:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:39:17 --> Input Class Initialized
INFO - 2020-08-25 03:39:17 --> Language Class Initialized
INFO - 2020-08-25 03:39:17 --> Language Class Initialized
INFO - 2020-08-25 03:39:17 --> Config Class Initialized
INFO - 2020-08-25 03:39:17 --> Loader Class Initialized
INFO - 2020-08-25 03:39:17 --> Helper loaded: url_helper
INFO - 2020-08-25 03:39:17 --> Helper loaded: file_helper
INFO - 2020-08-25 03:39:17 --> Helper loaded: form_helper
INFO - 2020-08-25 03:39:17 --> Helper loaded: my_helper
INFO - 2020-08-25 03:39:17 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:39:17 --> Controller Class Initialized
DEBUG - 2020-08-25 03:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-08-25 03:39:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:39:17 --> Final output sent to browser
DEBUG - 2020-08-25 03:39:17 --> Total execution time: 0.0618
INFO - 2020-08-25 03:41:00 --> Config Class Initialized
INFO - 2020-08-25 03:41:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:00 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:00 --> URI Class Initialized
INFO - 2020-08-25 03:41:00 --> Router Class Initialized
INFO - 2020-08-25 03:41:00 --> Output Class Initialized
INFO - 2020-08-25 03:41:00 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:00 --> Input Class Initialized
INFO - 2020-08-25 03:41:00 --> Language Class Initialized
INFO - 2020-08-25 03:41:00 --> Language Class Initialized
INFO - 2020-08-25 03:41:00 --> Config Class Initialized
INFO - 2020-08-25 03:41:00 --> Loader Class Initialized
INFO - 2020-08-25 03:41:00 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:00 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:00 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:00 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:00 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:00 --> Controller Class Initialized
DEBUG - 2020-08-25 03:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-08-25 03:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:41:00 --> Final output sent to browser
DEBUG - 2020-08-25 03:41:00 --> Total execution time: 0.0849
INFO - 2020-08-25 03:41:00 --> Config Class Initialized
INFO - 2020-08-25 03:41:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:00 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:00 --> URI Class Initialized
INFO - 2020-08-25 03:41:01 --> Router Class Initialized
INFO - 2020-08-25 03:41:01 --> Output Class Initialized
INFO - 2020-08-25 03:41:01 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:01 --> Input Class Initialized
INFO - 2020-08-25 03:41:01 --> Language Class Initialized
INFO - 2020-08-25 03:41:01 --> Language Class Initialized
INFO - 2020-08-25 03:41:01 --> Config Class Initialized
INFO - 2020-08-25 03:41:01 --> Loader Class Initialized
INFO - 2020-08-25 03:41:01 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:01 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:01 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:01 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:01 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:01 --> Controller Class Initialized
INFO - 2020-08-25 03:41:02 --> Config Class Initialized
INFO - 2020-08-25 03:41:02 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:02 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:02 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:02 --> URI Class Initialized
INFO - 2020-08-25 03:41:02 --> Router Class Initialized
INFO - 2020-08-25 03:41:02 --> Output Class Initialized
INFO - 2020-08-25 03:41:02 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:02 --> Input Class Initialized
INFO - 2020-08-25 03:41:02 --> Language Class Initialized
INFO - 2020-08-25 03:41:02 --> Language Class Initialized
INFO - 2020-08-25 03:41:02 --> Config Class Initialized
INFO - 2020-08-25 03:41:02 --> Loader Class Initialized
INFO - 2020-08-25 03:41:02 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:02 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:02 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:02 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:02 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:02 --> Controller Class Initialized
INFO - 2020-08-25 03:41:02 --> Final output sent to browser
DEBUG - 2020-08-25 03:41:02 --> Total execution time: 0.0509
INFO - 2020-08-25 03:41:12 --> Config Class Initialized
INFO - 2020-08-25 03:41:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:12 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:12 --> URI Class Initialized
INFO - 2020-08-25 03:41:12 --> Router Class Initialized
INFO - 2020-08-25 03:41:12 --> Output Class Initialized
INFO - 2020-08-25 03:41:12 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:12 --> Input Class Initialized
INFO - 2020-08-25 03:41:12 --> Language Class Initialized
INFO - 2020-08-25 03:41:12 --> Language Class Initialized
INFO - 2020-08-25 03:41:12 --> Config Class Initialized
INFO - 2020-08-25 03:41:12 --> Loader Class Initialized
INFO - 2020-08-25 03:41:12 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:12 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:12 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:12 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:12 --> Controller Class Initialized
DEBUG - 2020-08-25 03:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-08-25 03:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:41:12 --> Final output sent to browser
DEBUG - 2020-08-25 03:41:12 --> Total execution time: 0.0791
INFO - 2020-08-25 03:41:12 --> Config Class Initialized
INFO - 2020-08-25 03:41:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:12 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:12 --> URI Class Initialized
INFO - 2020-08-25 03:41:12 --> Router Class Initialized
INFO - 2020-08-25 03:41:12 --> Output Class Initialized
INFO - 2020-08-25 03:41:12 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:12 --> Input Class Initialized
INFO - 2020-08-25 03:41:12 --> Language Class Initialized
INFO - 2020-08-25 03:41:12 --> Language Class Initialized
INFO - 2020-08-25 03:41:12 --> Config Class Initialized
INFO - 2020-08-25 03:41:12 --> Loader Class Initialized
INFO - 2020-08-25 03:41:12 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:12 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:12 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:12 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:12 --> Controller Class Initialized
INFO - 2020-08-25 03:41:13 --> Config Class Initialized
INFO - 2020-08-25 03:41:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:13 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:13 --> URI Class Initialized
INFO - 2020-08-25 03:41:13 --> Router Class Initialized
INFO - 2020-08-25 03:41:13 --> Output Class Initialized
INFO - 2020-08-25 03:41:13 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:13 --> Input Class Initialized
INFO - 2020-08-25 03:41:13 --> Language Class Initialized
INFO - 2020-08-25 03:41:13 --> Language Class Initialized
INFO - 2020-08-25 03:41:13 --> Config Class Initialized
INFO - 2020-08-25 03:41:13 --> Loader Class Initialized
INFO - 2020-08-25 03:41:13 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:13 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:13 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:13 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:13 --> Controller Class Initialized
INFO - 2020-08-25 03:41:13 --> Final output sent to browser
DEBUG - 2020-08-25 03:41:13 --> Total execution time: 0.0502
INFO - 2020-08-25 03:41:28 --> Config Class Initialized
INFO - 2020-08-25 03:41:28 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:28 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:28 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:28 --> URI Class Initialized
INFO - 2020-08-25 03:41:28 --> Router Class Initialized
INFO - 2020-08-25 03:41:28 --> Output Class Initialized
INFO - 2020-08-25 03:41:28 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:28 --> Input Class Initialized
INFO - 2020-08-25 03:41:28 --> Language Class Initialized
INFO - 2020-08-25 03:41:28 --> Language Class Initialized
INFO - 2020-08-25 03:41:28 --> Config Class Initialized
INFO - 2020-08-25 03:41:28 --> Loader Class Initialized
INFO - 2020-08-25 03:41:28 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:28 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:28 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:28 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:28 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:28 --> Controller Class Initialized
INFO - 2020-08-25 03:41:28 --> Final output sent to browser
DEBUG - 2020-08-25 03:41:28 --> Total execution time: 0.0401
INFO - 2020-08-25 03:41:56 --> Config Class Initialized
INFO - 2020-08-25 03:41:56 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:56 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:56 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:56 --> URI Class Initialized
INFO - 2020-08-25 03:41:56 --> Router Class Initialized
INFO - 2020-08-25 03:41:56 --> Output Class Initialized
INFO - 2020-08-25 03:41:56 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:56 --> Input Class Initialized
INFO - 2020-08-25 03:41:56 --> Language Class Initialized
INFO - 2020-08-25 03:41:56 --> Language Class Initialized
INFO - 2020-08-25 03:41:56 --> Config Class Initialized
INFO - 2020-08-25 03:41:56 --> Loader Class Initialized
INFO - 2020-08-25 03:41:56 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:56 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:56 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:56 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:56 --> Controller Class Initialized
INFO - 2020-08-25 03:41:56 --> Final output sent to browser
DEBUG - 2020-08-25 03:41:56 --> Total execution time: 0.0515
INFO - 2020-08-25 03:41:56 --> Config Class Initialized
INFO - 2020-08-25 03:41:56 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:56 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:56 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:56 --> URI Class Initialized
INFO - 2020-08-25 03:41:56 --> Router Class Initialized
INFO - 2020-08-25 03:41:56 --> Output Class Initialized
INFO - 2020-08-25 03:41:56 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:56 --> Input Class Initialized
INFO - 2020-08-25 03:41:56 --> Language Class Initialized
INFO - 2020-08-25 03:41:56 --> Language Class Initialized
INFO - 2020-08-25 03:41:56 --> Config Class Initialized
INFO - 2020-08-25 03:41:56 --> Loader Class Initialized
INFO - 2020-08-25 03:41:56 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:56 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:56 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:56 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:56 --> Controller Class Initialized
INFO - 2020-08-25 03:41:59 --> Config Class Initialized
INFO - 2020-08-25 03:41:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:41:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:41:59 --> Utf8 Class Initialized
INFO - 2020-08-25 03:41:59 --> URI Class Initialized
INFO - 2020-08-25 03:41:59 --> Router Class Initialized
INFO - 2020-08-25 03:41:59 --> Output Class Initialized
INFO - 2020-08-25 03:41:59 --> Security Class Initialized
DEBUG - 2020-08-25 03:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:41:59 --> Input Class Initialized
INFO - 2020-08-25 03:41:59 --> Language Class Initialized
INFO - 2020-08-25 03:41:59 --> Language Class Initialized
INFO - 2020-08-25 03:41:59 --> Config Class Initialized
INFO - 2020-08-25 03:41:59 --> Loader Class Initialized
INFO - 2020-08-25 03:41:59 --> Helper loaded: url_helper
INFO - 2020-08-25 03:41:59 --> Helper loaded: file_helper
INFO - 2020-08-25 03:41:59 --> Helper loaded: form_helper
INFO - 2020-08-25 03:41:59 --> Helper loaded: my_helper
INFO - 2020-08-25 03:41:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:41:59 --> Controller Class Initialized
INFO - 2020-08-25 03:42:08 --> Config Class Initialized
INFO - 2020-08-25 03:42:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:08 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:08 --> URI Class Initialized
INFO - 2020-08-25 03:42:08 --> Router Class Initialized
INFO - 2020-08-25 03:42:08 --> Output Class Initialized
INFO - 2020-08-25 03:42:08 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:08 --> Input Class Initialized
INFO - 2020-08-25 03:42:08 --> Language Class Initialized
INFO - 2020-08-25 03:42:08 --> Language Class Initialized
INFO - 2020-08-25 03:42:08 --> Config Class Initialized
INFO - 2020-08-25 03:42:08 --> Loader Class Initialized
INFO - 2020-08-25 03:42:08 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:08 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:08 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:08 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:08 --> Controller Class Initialized
INFO - 2020-08-25 03:42:08 --> Final output sent to browser
DEBUG - 2020-08-25 03:42:08 --> Total execution time: 0.0411
INFO - 2020-08-25 03:42:08 --> Config Class Initialized
INFO - 2020-08-25 03:42:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:08 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:08 --> URI Class Initialized
INFO - 2020-08-25 03:42:08 --> Router Class Initialized
INFO - 2020-08-25 03:42:08 --> Output Class Initialized
INFO - 2020-08-25 03:42:08 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:08 --> Input Class Initialized
INFO - 2020-08-25 03:42:08 --> Language Class Initialized
INFO - 2020-08-25 03:42:08 --> Language Class Initialized
INFO - 2020-08-25 03:42:08 --> Config Class Initialized
INFO - 2020-08-25 03:42:08 --> Loader Class Initialized
INFO - 2020-08-25 03:42:08 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:08 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:08 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:08 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:08 --> Controller Class Initialized
INFO - 2020-08-25 03:42:10 --> Config Class Initialized
INFO - 2020-08-25 03:42:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:10 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:10 --> URI Class Initialized
INFO - 2020-08-25 03:42:10 --> Router Class Initialized
INFO - 2020-08-25 03:42:10 --> Output Class Initialized
INFO - 2020-08-25 03:42:10 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:10 --> Input Class Initialized
INFO - 2020-08-25 03:42:10 --> Language Class Initialized
INFO - 2020-08-25 03:42:10 --> Language Class Initialized
INFO - 2020-08-25 03:42:10 --> Config Class Initialized
INFO - 2020-08-25 03:42:10 --> Loader Class Initialized
INFO - 2020-08-25 03:42:10 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:10 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:10 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:10 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:10 --> Controller Class Initialized
INFO - 2020-08-25 03:42:23 --> Config Class Initialized
INFO - 2020-08-25 03:42:23 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:23 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:23 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:23 --> URI Class Initialized
INFO - 2020-08-25 03:42:23 --> Router Class Initialized
INFO - 2020-08-25 03:42:23 --> Output Class Initialized
INFO - 2020-08-25 03:42:23 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:23 --> Input Class Initialized
INFO - 2020-08-25 03:42:23 --> Language Class Initialized
INFO - 2020-08-25 03:42:23 --> Language Class Initialized
INFO - 2020-08-25 03:42:23 --> Config Class Initialized
INFO - 2020-08-25 03:42:23 --> Loader Class Initialized
INFO - 2020-08-25 03:42:23 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:23 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:23 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:23 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:23 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:23 --> Controller Class Initialized
DEBUG - 2020-08-25 03:42:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-08-25 03:42:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:42:23 --> Final output sent to browser
DEBUG - 2020-08-25 03:42:23 --> Total execution time: 0.0525
INFO - 2020-08-25 03:42:24 --> Config Class Initialized
INFO - 2020-08-25 03:42:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:24 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:24 --> URI Class Initialized
INFO - 2020-08-25 03:42:24 --> Router Class Initialized
INFO - 2020-08-25 03:42:24 --> Output Class Initialized
INFO - 2020-08-25 03:42:24 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:24 --> Input Class Initialized
INFO - 2020-08-25 03:42:24 --> Language Class Initialized
INFO - 2020-08-25 03:42:24 --> Language Class Initialized
INFO - 2020-08-25 03:42:24 --> Config Class Initialized
INFO - 2020-08-25 03:42:24 --> Loader Class Initialized
INFO - 2020-08-25 03:42:24 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:24 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:24 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:24 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:24 --> Controller Class Initialized
INFO - 2020-08-25 03:42:24 --> Config Class Initialized
INFO - 2020-08-25 03:42:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:24 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:24 --> URI Class Initialized
INFO - 2020-08-25 03:42:24 --> Router Class Initialized
INFO - 2020-08-25 03:42:24 --> Output Class Initialized
INFO - 2020-08-25 03:42:24 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:24 --> Input Class Initialized
INFO - 2020-08-25 03:42:24 --> Language Class Initialized
INFO - 2020-08-25 03:42:24 --> Language Class Initialized
INFO - 2020-08-25 03:42:24 --> Config Class Initialized
INFO - 2020-08-25 03:42:24 --> Loader Class Initialized
INFO - 2020-08-25 03:42:24 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:24 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:24 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:24 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:24 --> Controller Class Initialized
INFO - 2020-08-25 03:42:24 --> Final output sent to browser
DEBUG - 2020-08-25 03:42:24 --> Total execution time: 0.0415
INFO - 2020-08-25 03:42:40 --> Config Class Initialized
INFO - 2020-08-25 03:42:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:40 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:40 --> URI Class Initialized
INFO - 2020-08-25 03:42:40 --> Router Class Initialized
INFO - 2020-08-25 03:42:40 --> Output Class Initialized
INFO - 2020-08-25 03:42:40 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:40 --> Input Class Initialized
INFO - 2020-08-25 03:42:40 --> Language Class Initialized
INFO - 2020-08-25 03:42:40 --> Language Class Initialized
INFO - 2020-08-25 03:42:40 --> Config Class Initialized
INFO - 2020-08-25 03:42:40 --> Loader Class Initialized
INFO - 2020-08-25 03:42:40 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:40 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:40 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:40 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:40 --> Controller Class Initialized
INFO - 2020-08-25 03:42:40 --> Final output sent to browser
DEBUG - 2020-08-25 03:42:40 --> Total execution time: 0.0506
INFO - 2020-08-25 03:42:42 --> Config Class Initialized
INFO - 2020-08-25 03:42:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:42 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:42 --> URI Class Initialized
INFO - 2020-08-25 03:42:42 --> Router Class Initialized
INFO - 2020-08-25 03:42:42 --> Output Class Initialized
INFO - 2020-08-25 03:42:42 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:42 --> Input Class Initialized
INFO - 2020-08-25 03:42:42 --> Language Class Initialized
INFO - 2020-08-25 03:42:42 --> Language Class Initialized
INFO - 2020-08-25 03:42:42 --> Config Class Initialized
INFO - 2020-08-25 03:42:42 --> Loader Class Initialized
INFO - 2020-08-25 03:42:42 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:42 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:42 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:42 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:42 --> Controller Class Initialized
INFO - 2020-08-25 03:42:42 --> Final output sent to browser
DEBUG - 2020-08-25 03:42:42 --> Total execution time: 0.0509
INFO - 2020-08-25 03:42:47 --> Config Class Initialized
INFO - 2020-08-25 03:42:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:47 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:47 --> URI Class Initialized
INFO - 2020-08-25 03:42:47 --> Router Class Initialized
INFO - 2020-08-25 03:42:47 --> Output Class Initialized
INFO - 2020-08-25 03:42:47 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:47 --> Input Class Initialized
INFO - 2020-08-25 03:42:47 --> Language Class Initialized
INFO - 2020-08-25 03:42:47 --> Language Class Initialized
INFO - 2020-08-25 03:42:47 --> Config Class Initialized
INFO - 2020-08-25 03:42:47 --> Loader Class Initialized
INFO - 2020-08-25 03:42:47 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:47 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:47 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:47 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:47 --> Controller Class Initialized
INFO - 2020-08-25 03:42:47 --> Final output sent to browser
DEBUG - 2020-08-25 03:42:47 --> Total execution time: 0.0537
INFO - 2020-08-25 03:42:47 --> Config Class Initialized
INFO - 2020-08-25 03:42:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:47 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:47 --> URI Class Initialized
INFO - 2020-08-25 03:42:47 --> Router Class Initialized
INFO - 2020-08-25 03:42:47 --> Output Class Initialized
INFO - 2020-08-25 03:42:47 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:47 --> Input Class Initialized
INFO - 2020-08-25 03:42:47 --> Language Class Initialized
INFO - 2020-08-25 03:42:47 --> Language Class Initialized
INFO - 2020-08-25 03:42:47 --> Config Class Initialized
INFO - 2020-08-25 03:42:47 --> Loader Class Initialized
INFO - 2020-08-25 03:42:47 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:47 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:47 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:47 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:47 --> Controller Class Initialized
INFO - 2020-08-25 03:42:55 --> Config Class Initialized
INFO - 2020-08-25 03:42:55 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:55 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:55 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:55 --> URI Class Initialized
INFO - 2020-08-25 03:42:55 --> Router Class Initialized
INFO - 2020-08-25 03:42:55 --> Output Class Initialized
INFO - 2020-08-25 03:42:55 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:55 --> Input Class Initialized
INFO - 2020-08-25 03:42:55 --> Language Class Initialized
INFO - 2020-08-25 03:42:55 --> Language Class Initialized
INFO - 2020-08-25 03:42:55 --> Config Class Initialized
INFO - 2020-08-25 03:42:55 --> Loader Class Initialized
INFO - 2020-08-25 03:42:55 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:55 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:55 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:55 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:55 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:55 --> Controller Class Initialized
DEBUG - 2020-08-25 03:42:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-08-25 03:42:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:42:55 --> Final output sent to browser
DEBUG - 2020-08-25 03:42:55 --> Total execution time: 0.0496
INFO - 2020-08-25 03:42:55 --> Config Class Initialized
INFO - 2020-08-25 03:42:55 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:55 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:55 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:55 --> URI Class Initialized
INFO - 2020-08-25 03:42:55 --> Router Class Initialized
INFO - 2020-08-25 03:42:55 --> Output Class Initialized
INFO - 2020-08-25 03:42:56 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:56 --> Input Class Initialized
INFO - 2020-08-25 03:42:56 --> Language Class Initialized
INFO - 2020-08-25 03:42:56 --> Language Class Initialized
INFO - 2020-08-25 03:42:56 --> Config Class Initialized
INFO - 2020-08-25 03:42:56 --> Loader Class Initialized
INFO - 2020-08-25 03:42:56 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:56 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:56 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:56 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:56 --> Controller Class Initialized
INFO - 2020-08-25 03:42:59 --> Config Class Initialized
INFO - 2020-08-25 03:42:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:42:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:42:59 --> Utf8 Class Initialized
INFO - 2020-08-25 03:42:59 --> URI Class Initialized
INFO - 2020-08-25 03:42:59 --> Router Class Initialized
INFO - 2020-08-25 03:42:59 --> Output Class Initialized
INFO - 2020-08-25 03:42:59 --> Security Class Initialized
DEBUG - 2020-08-25 03:42:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:42:59 --> Input Class Initialized
INFO - 2020-08-25 03:42:59 --> Language Class Initialized
INFO - 2020-08-25 03:42:59 --> Language Class Initialized
INFO - 2020-08-25 03:42:59 --> Config Class Initialized
INFO - 2020-08-25 03:42:59 --> Loader Class Initialized
INFO - 2020-08-25 03:42:59 --> Helper loaded: url_helper
INFO - 2020-08-25 03:42:59 --> Helper loaded: file_helper
INFO - 2020-08-25 03:42:59 --> Helper loaded: form_helper
INFO - 2020-08-25 03:42:59 --> Helper loaded: my_helper
INFO - 2020-08-25 03:42:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:42:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:42:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:42:59 --> Controller Class Initialized
INFO - 2020-08-25 03:43:02 --> Config Class Initialized
INFO - 2020-08-25 03:43:02 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:02 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:02 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:02 --> URI Class Initialized
INFO - 2020-08-25 03:43:02 --> Router Class Initialized
INFO - 2020-08-25 03:43:02 --> Output Class Initialized
INFO - 2020-08-25 03:43:02 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:02 --> Input Class Initialized
INFO - 2020-08-25 03:43:02 --> Language Class Initialized
INFO - 2020-08-25 03:43:02 --> Language Class Initialized
INFO - 2020-08-25 03:43:02 --> Config Class Initialized
INFO - 2020-08-25 03:43:02 --> Loader Class Initialized
INFO - 2020-08-25 03:43:02 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:02 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:02 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:02 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:02 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:02 --> Controller Class Initialized
INFO - 2020-08-25 03:43:02 --> Final output sent to browser
DEBUG - 2020-08-25 03:43:02 --> Total execution time: 0.0498
INFO - 2020-08-25 03:43:08 --> Config Class Initialized
INFO - 2020-08-25 03:43:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:08 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:08 --> URI Class Initialized
INFO - 2020-08-25 03:43:08 --> Router Class Initialized
INFO - 2020-08-25 03:43:08 --> Output Class Initialized
INFO - 2020-08-25 03:43:08 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:08 --> Input Class Initialized
INFO - 2020-08-25 03:43:08 --> Language Class Initialized
INFO - 2020-08-25 03:43:08 --> Language Class Initialized
INFO - 2020-08-25 03:43:08 --> Config Class Initialized
INFO - 2020-08-25 03:43:08 --> Loader Class Initialized
INFO - 2020-08-25 03:43:08 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:08 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:08 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:08 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:08 --> Controller Class Initialized
INFO - 2020-08-25 03:43:08 --> Final output sent to browser
DEBUG - 2020-08-25 03:43:08 --> Total execution time: 0.0505
INFO - 2020-08-25 03:43:11 --> Config Class Initialized
INFO - 2020-08-25 03:43:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:11 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:11 --> URI Class Initialized
INFO - 2020-08-25 03:43:11 --> Router Class Initialized
INFO - 2020-08-25 03:43:11 --> Output Class Initialized
INFO - 2020-08-25 03:43:11 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:11 --> Input Class Initialized
INFO - 2020-08-25 03:43:11 --> Language Class Initialized
INFO - 2020-08-25 03:43:11 --> Language Class Initialized
INFO - 2020-08-25 03:43:11 --> Config Class Initialized
INFO - 2020-08-25 03:43:11 --> Loader Class Initialized
INFO - 2020-08-25 03:43:11 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:11 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:11 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:11 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:11 --> Controller Class Initialized
INFO - 2020-08-25 03:43:11 --> Final output sent to browser
DEBUG - 2020-08-25 03:43:11 --> Total execution time: 0.0404
INFO - 2020-08-25 03:43:11 --> Config Class Initialized
INFO - 2020-08-25 03:43:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:11 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:11 --> URI Class Initialized
INFO - 2020-08-25 03:43:11 --> Router Class Initialized
INFO - 2020-08-25 03:43:11 --> Output Class Initialized
INFO - 2020-08-25 03:43:11 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:11 --> Input Class Initialized
INFO - 2020-08-25 03:43:11 --> Language Class Initialized
INFO - 2020-08-25 03:43:11 --> Language Class Initialized
INFO - 2020-08-25 03:43:11 --> Config Class Initialized
INFO - 2020-08-25 03:43:11 --> Loader Class Initialized
INFO - 2020-08-25 03:43:11 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:11 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:11 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:11 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:11 --> Controller Class Initialized
INFO - 2020-08-25 03:43:13 --> Config Class Initialized
INFO - 2020-08-25 03:43:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:13 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:13 --> URI Class Initialized
INFO - 2020-08-25 03:43:13 --> Router Class Initialized
INFO - 2020-08-25 03:43:13 --> Output Class Initialized
INFO - 2020-08-25 03:43:13 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:13 --> Input Class Initialized
INFO - 2020-08-25 03:43:13 --> Language Class Initialized
INFO - 2020-08-25 03:43:13 --> Language Class Initialized
INFO - 2020-08-25 03:43:13 --> Config Class Initialized
INFO - 2020-08-25 03:43:13 --> Loader Class Initialized
INFO - 2020-08-25 03:43:13 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:13 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:13 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:13 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:13 --> Controller Class Initialized
INFO - 2020-08-25 03:43:45 --> Config Class Initialized
INFO - 2020-08-25 03:43:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:45 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:45 --> URI Class Initialized
INFO - 2020-08-25 03:43:45 --> Router Class Initialized
INFO - 2020-08-25 03:43:45 --> Output Class Initialized
INFO - 2020-08-25 03:43:45 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:45 --> Input Class Initialized
INFO - 2020-08-25 03:43:45 --> Language Class Initialized
INFO - 2020-08-25 03:43:45 --> Language Class Initialized
INFO - 2020-08-25 03:43:45 --> Config Class Initialized
INFO - 2020-08-25 03:43:45 --> Loader Class Initialized
INFO - 2020-08-25 03:43:45 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:45 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:45 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:45 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:45 --> Controller Class Initialized
INFO - 2020-08-25 03:43:45 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:43:46 --> Config Class Initialized
INFO - 2020-08-25 03:43:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:46 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:46 --> URI Class Initialized
INFO - 2020-08-25 03:43:46 --> Router Class Initialized
INFO - 2020-08-25 03:43:46 --> Output Class Initialized
INFO - 2020-08-25 03:43:46 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:46 --> Input Class Initialized
INFO - 2020-08-25 03:43:46 --> Language Class Initialized
INFO - 2020-08-25 03:43:46 --> Language Class Initialized
INFO - 2020-08-25 03:43:46 --> Config Class Initialized
INFO - 2020-08-25 03:43:46 --> Loader Class Initialized
INFO - 2020-08-25 03:43:46 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:46 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:46 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:46 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:46 --> Controller Class Initialized
DEBUG - 2020-08-25 03:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 03:43:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:43:46 --> Final output sent to browser
DEBUG - 2020-08-25 03:43:46 --> Total execution time: 0.0506
INFO - 2020-08-25 03:43:52 --> Config Class Initialized
INFO - 2020-08-25 03:43:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:52 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:52 --> URI Class Initialized
INFO - 2020-08-25 03:43:52 --> Router Class Initialized
INFO - 2020-08-25 03:43:52 --> Output Class Initialized
INFO - 2020-08-25 03:43:52 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:52 --> Input Class Initialized
INFO - 2020-08-25 03:43:52 --> Language Class Initialized
INFO - 2020-08-25 03:43:52 --> Language Class Initialized
INFO - 2020-08-25 03:43:52 --> Config Class Initialized
INFO - 2020-08-25 03:43:52 --> Loader Class Initialized
INFO - 2020-08-25 03:43:52 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:52 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:52 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:52 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:52 --> Controller Class Initialized
INFO - 2020-08-25 03:43:52 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:43:52 --> Final output sent to browser
DEBUG - 2020-08-25 03:43:52 --> Total execution time: 0.0414
INFO - 2020-08-25 03:43:52 --> Config Class Initialized
INFO - 2020-08-25 03:43:52 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:52 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:52 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:52 --> URI Class Initialized
INFO - 2020-08-25 03:43:52 --> Router Class Initialized
INFO - 2020-08-25 03:43:52 --> Output Class Initialized
INFO - 2020-08-25 03:43:52 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:52 --> Input Class Initialized
INFO - 2020-08-25 03:43:52 --> Language Class Initialized
INFO - 2020-08-25 03:43:52 --> Language Class Initialized
INFO - 2020-08-25 03:43:52 --> Config Class Initialized
INFO - 2020-08-25 03:43:52 --> Loader Class Initialized
INFO - 2020-08-25 03:43:52 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:52 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:52 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:52 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:52 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:52 --> Controller Class Initialized
DEBUG - 2020-08-25 03:43:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 03:43:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:43:52 --> Final output sent to browser
DEBUG - 2020-08-25 03:43:52 --> Total execution time: 0.6308
INFO - 2020-08-25 03:43:54 --> Config Class Initialized
INFO - 2020-08-25 03:43:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:43:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:43:54 --> Utf8 Class Initialized
INFO - 2020-08-25 03:43:54 --> URI Class Initialized
INFO - 2020-08-25 03:43:54 --> Router Class Initialized
INFO - 2020-08-25 03:43:54 --> Output Class Initialized
INFO - 2020-08-25 03:43:54 --> Security Class Initialized
DEBUG - 2020-08-25 03:43:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:43:54 --> Input Class Initialized
INFO - 2020-08-25 03:43:54 --> Language Class Initialized
INFO - 2020-08-25 03:43:54 --> Language Class Initialized
INFO - 2020-08-25 03:43:54 --> Config Class Initialized
INFO - 2020-08-25 03:43:54 --> Loader Class Initialized
INFO - 2020-08-25 03:43:54 --> Helper loaded: url_helper
INFO - 2020-08-25 03:43:54 --> Helper loaded: file_helper
INFO - 2020-08-25 03:43:54 --> Helper loaded: form_helper
INFO - 2020-08-25 03:43:54 --> Helper loaded: my_helper
INFO - 2020-08-25 03:43:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:43:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:43:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:43:54 --> Controller Class Initialized
DEBUG - 2020-08-25 03:43:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-08-25 03:43:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:43:54 --> Final output sent to browser
DEBUG - 2020-08-25 03:43:54 --> Total execution time: 0.1113
INFO - 2020-08-25 03:44:06 --> Config Class Initialized
INFO - 2020-08-25 03:44:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:07 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:07 --> URI Class Initialized
INFO - 2020-08-25 03:44:07 --> Router Class Initialized
INFO - 2020-08-25 03:44:07 --> Output Class Initialized
INFO - 2020-08-25 03:44:07 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:07 --> Input Class Initialized
INFO - 2020-08-25 03:44:07 --> Language Class Initialized
INFO - 2020-08-25 03:44:07 --> Language Class Initialized
INFO - 2020-08-25 03:44:07 --> Config Class Initialized
INFO - 2020-08-25 03:44:07 --> Loader Class Initialized
INFO - 2020-08-25 03:44:07 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:07 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:07 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:07 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:07 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:07 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-08-25 03:44:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:07 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:07 --> Total execution time: 0.0596
INFO - 2020-08-25 03:44:16 --> Config Class Initialized
INFO - 2020-08-25 03:44:16 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:16 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:16 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:16 --> URI Class Initialized
INFO - 2020-08-25 03:44:16 --> Router Class Initialized
INFO - 2020-08-25 03:44:16 --> Output Class Initialized
INFO - 2020-08-25 03:44:16 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:16 --> Input Class Initialized
INFO - 2020-08-25 03:44:16 --> Language Class Initialized
INFO - 2020-08-25 03:44:16 --> Language Class Initialized
INFO - 2020-08-25 03:44:16 --> Config Class Initialized
INFO - 2020-08-25 03:44:16 --> Loader Class Initialized
INFO - 2020-08-25 03:44:16 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:16 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:16 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:16 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:16 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:16 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-08-25 03:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:16 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:16 --> Total execution time: 0.0530
INFO - 2020-08-25 03:44:20 --> Config Class Initialized
INFO - 2020-08-25 03:44:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:20 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:20 --> URI Class Initialized
INFO - 2020-08-25 03:44:20 --> Router Class Initialized
INFO - 2020-08-25 03:44:20 --> Output Class Initialized
INFO - 2020-08-25 03:44:20 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:20 --> Input Class Initialized
INFO - 2020-08-25 03:44:20 --> Language Class Initialized
INFO - 2020-08-25 03:44:20 --> Language Class Initialized
INFO - 2020-08-25 03:44:20 --> Config Class Initialized
INFO - 2020-08-25 03:44:20 --> Loader Class Initialized
INFO - 2020-08-25 03:44:20 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:20 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:20 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:20 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:20 --> Controller Class Initialized
INFO - 2020-08-25 03:44:20 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:20 --> Total execution time: 0.0513
INFO - 2020-08-25 03:44:22 --> Config Class Initialized
INFO - 2020-08-25 03:44:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:22 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:22 --> URI Class Initialized
INFO - 2020-08-25 03:44:22 --> Router Class Initialized
INFO - 2020-08-25 03:44:22 --> Output Class Initialized
INFO - 2020-08-25 03:44:22 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:22 --> Input Class Initialized
INFO - 2020-08-25 03:44:22 --> Language Class Initialized
INFO - 2020-08-25 03:44:22 --> Language Class Initialized
INFO - 2020-08-25 03:44:22 --> Config Class Initialized
INFO - 2020-08-25 03:44:22 --> Loader Class Initialized
INFO - 2020-08-25 03:44:22 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:22 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:22 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:22 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:22 --> Controller Class Initialized
INFO - 2020-08-25 03:44:22 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:22 --> Total execution time: 0.1180
INFO - 2020-08-25 03:44:26 --> Config Class Initialized
INFO - 2020-08-25 03:44:26 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:26 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:26 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:26 --> URI Class Initialized
INFO - 2020-08-25 03:44:26 --> Router Class Initialized
INFO - 2020-08-25 03:44:26 --> Output Class Initialized
INFO - 2020-08-25 03:44:26 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:26 --> Input Class Initialized
INFO - 2020-08-25 03:44:26 --> Language Class Initialized
INFO - 2020-08-25 03:44:26 --> Language Class Initialized
INFO - 2020-08-25 03:44:26 --> Config Class Initialized
INFO - 2020-08-25 03:44:26 --> Loader Class Initialized
INFO - 2020-08-25 03:44:26 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:26 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:26 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:26 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:26 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:26 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-08-25 03:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:26 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:26 --> Total execution time: 0.0648
INFO - 2020-08-25 03:44:27 --> Config Class Initialized
INFO - 2020-08-25 03:44:27 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:27 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:27 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:27 --> URI Class Initialized
INFO - 2020-08-25 03:44:27 --> Router Class Initialized
INFO - 2020-08-25 03:44:27 --> Output Class Initialized
INFO - 2020-08-25 03:44:27 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:27 --> Input Class Initialized
INFO - 2020-08-25 03:44:27 --> Language Class Initialized
INFO - 2020-08-25 03:44:27 --> Language Class Initialized
INFO - 2020-08-25 03:44:27 --> Config Class Initialized
INFO - 2020-08-25 03:44:27 --> Loader Class Initialized
INFO - 2020-08-25 03:44:27 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:27 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:27 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:27 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:27 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:27 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2020-08-25 03:44:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:27 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:27 --> Total execution time: 0.0607
INFO - 2020-08-25 03:44:33 --> Config Class Initialized
INFO - 2020-08-25 03:44:33 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:33 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:33 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:33 --> URI Class Initialized
INFO - 2020-08-25 03:44:33 --> Router Class Initialized
INFO - 2020-08-25 03:44:33 --> Output Class Initialized
INFO - 2020-08-25 03:44:33 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:33 --> Input Class Initialized
INFO - 2020-08-25 03:44:33 --> Language Class Initialized
INFO - 2020-08-25 03:44:33 --> Language Class Initialized
INFO - 2020-08-25 03:44:33 --> Config Class Initialized
INFO - 2020-08-25 03:44:33 --> Loader Class Initialized
INFO - 2020-08-25 03:44:33 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:33 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:33 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:33 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:33 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:33 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2020-08-25 03:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:33 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:33 --> Total execution time: 0.0653
INFO - 2020-08-25 03:44:36 --> Config Class Initialized
INFO - 2020-08-25 03:44:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:36 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:36 --> URI Class Initialized
INFO - 2020-08-25 03:44:36 --> Router Class Initialized
INFO - 2020-08-25 03:44:36 --> Output Class Initialized
INFO - 2020-08-25 03:44:36 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:36 --> Input Class Initialized
INFO - 2020-08-25 03:44:36 --> Language Class Initialized
INFO - 2020-08-25 03:44:36 --> Language Class Initialized
INFO - 2020-08-25 03:44:36 --> Config Class Initialized
INFO - 2020-08-25 03:44:36 --> Loader Class Initialized
INFO - 2020-08-25 03:44:36 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:36 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:36 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:36 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:36 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-08-25 03:44:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:36 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:36 --> Total execution time: 0.0639
INFO - 2020-08-25 03:44:38 --> Config Class Initialized
INFO - 2020-08-25 03:44:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:38 --> URI Class Initialized
INFO - 2020-08-25 03:44:38 --> Router Class Initialized
INFO - 2020-08-25 03:44:38 --> Output Class Initialized
INFO - 2020-08-25 03:44:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:38 --> Input Class Initialized
INFO - 2020-08-25 03:44:38 --> Language Class Initialized
INFO - 2020-08-25 03:44:38 --> Language Class Initialized
INFO - 2020-08-25 03:44:38 --> Config Class Initialized
INFO - 2020-08-25 03:44:38 --> Loader Class Initialized
INFO - 2020-08-25 03:44:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:38 --> Controller Class Initialized
INFO - 2020-08-25 03:44:38 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:44:38 --> Config Class Initialized
INFO - 2020-08-25 03:44:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:38 --> URI Class Initialized
INFO - 2020-08-25 03:44:38 --> Router Class Initialized
INFO - 2020-08-25 03:44:38 --> Output Class Initialized
INFO - 2020-08-25 03:44:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:38 --> Input Class Initialized
INFO - 2020-08-25 03:44:38 --> Language Class Initialized
INFO - 2020-08-25 03:44:38 --> Language Class Initialized
INFO - 2020-08-25 03:44:38 --> Config Class Initialized
INFO - 2020-08-25 03:44:38 --> Loader Class Initialized
INFO - 2020-08-25 03:44:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:38 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 03:44:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:38 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:38 --> Total execution time: 0.0395
INFO - 2020-08-25 03:44:43 --> Config Class Initialized
INFO - 2020-08-25 03:44:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:43 --> URI Class Initialized
INFO - 2020-08-25 03:44:43 --> Router Class Initialized
INFO - 2020-08-25 03:44:43 --> Output Class Initialized
INFO - 2020-08-25 03:44:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:43 --> Input Class Initialized
INFO - 2020-08-25 03:44:43 --> Language Class Initialized
INFO - 2020-08-25 03:44:43 --> Language Class Initialized
INFO - 2020-08-25 03:44:43 --> Config Class Initialized
INFO - 2020-08-25 03:44:43 --> Loader Class Initialized
INFO - 2020-08-25 03:44:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:43 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:43 --> Controller Class Initialized
INFO - 2020-08-25 03:44:43 --> Helper loaded: cookie_helper
INFO - 2020-08-25 03:44:43 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:43 --> Total execution time: 0.0423
INFO - 2020-08-25 03:44:43 --> Config Class Initialized
INFO - 2020-08-25 03:44:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:44:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:44:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:44:43 --> URI Class Initialized
INFO - 2020-08-25 03:44:43 --> Router Class Initialized
INFO - 2020-08-25 03:44:43 --> Output Class Initialized
INFO - 2020-08-25 03:44:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:44:43 --> Input Class Initialized
INFO - 2020-08-25 03:44:43 --> Language Class Initialized
INFO - 2020-08-25 03:44:43 --> Language Class Initialized
INFO - 2020-08-25 03:44:43 --> Config Class Initialized
INFO - 2020-08-25 03:44:43 --> Loader Class Initialized
INFO - 2020-08-25 03:44:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:44:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:44:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:44:43 --> Helper loaded: my_helper
INFO - 2020-08-25 03:44:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:44:43 --> Controller Class Initialized
DEBUG - 2020-08-25 03:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 03:44:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:44:44 --> Final output sent to browser
DEBUG - 2020-08-25 03:44:44 --> Total execution time: 0.6471
INFO - 2020-08-25 03:46:42 --> Config Class Initialized
INFO - 2020-08-25 03:46:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:46:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:46:42 --> Utf8 Class Initialized
INFO - 2020-08-25 03:46:42 --> URI Class Initialized
INFO - 2020-08-25 03:46:42 --> Router Class Initialized
INFO - 2020-08-25 03:46:42 --> Output Class Initialized
INFO - 2020-08-25 03:46:42 --> Security Class Initialized
DEBUG - 2020-08-25 03:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:46:42 --> Input Class Initialized
INFO - 2020-08-25 03:46:42 --> Language Class Initialized
INFO - 2020-08-25 03:46:42 --> Language Class Initialized
INFO - 2020-08-25 03:46:42 --> Config Class Initialized
INFO - 2020-08-25 03:46:42 --> Loader Class Initialized
INFO - 2020-08-25 03:46:42 --> Helper loaded: url_helper
INFO - 2020-08-25 03:46:42 --> Helper loaded: file_helper
INFO - 2020-08-25 03:46:42 --> Helper loaded: form_helper
INFO - 2020-08-25 03:46:42 --> Helper loaded: my_helper
INFO - 2020-08-25 03:46:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:46:42 --> Controller Class Initialized
DEBUG - 2020-08-25 03:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-08-25 03:46:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:46:42 --> Final output sent to browser
DEBUG - 2020-08-25 03:46:42 --> Total execution time: 0.0646
INFO - 2020-08-25 03:46:43 --> Config Class Initialized
INFO - 2020-08-25 03:46:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:46:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:46:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:46:43 --> URI Class Initialized
INFO - 2020-08-25 03:46:43 --> Router Class Initialized
INFO - 2020-08-25 03:46:43 --> Output Class Initialized
INFO - 2020-08-25 03:46:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:46:43 --> Input Class Initialized
INFO - 2020-08-25 03:46:43 --> Language Class Initialized
INFO - 2020-08-25 03:46:43 --> Language Class Initialized
INFO - 2020-08-25 03:46:43 --> Config Class Initialized
INFO - 2020-08-25 03:46:43 --> Loader Class Initialized
INFO - 2020-08-25 03:46:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:46:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:46:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:46:43 --> Helper loaded: my_helper
INFO - 2020-08-25 03:46:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:46:43 --> Controller Class Initialized
DEBUG - 2020-08-25 03:46:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:46:44 --> Final output sent to browser
DEBUG - 2020-08-25 03:46:44 --> Total execution time: 0.2674
INFO - 2020-08-25 03:47:03 --> Config Class Initialized
INFO - 2020-08-25 03:47:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:47:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:47:03 --> Utf8 Class Initialized
INFO - 2020-08-25 03:47:03 --> URI Class Initialized
INFO - 2020-08-25 03:47:03 --> Router Class Initialized
INFO - 2020-08-25 03:47:03 --> Output Class Initialized
INFO - 2020-08-25 03:47:03 --> Security Class Initialized
DEBUG - 2020-08-25 03:47:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:47:03 --> Input Class Initialized
INFO - 2020-08-25 03:47:03 --> Language Class Initialized
INFO - 2020-08-25 03:47:03 --> Language Class Initialized
INFO - 2020-08-25 03:47:03 --> Config Class Initialized
INFO - 2020-08-25 03:47:03 --> Loader Class Initialized
INFO - 2020-08-25 03:47:03 --> Helper loaded: url_helper
INFO - 2020-08-25 03:47:03 --> Helper loaded: file_helper
INFO - 2020-08-25 03:47:03 --> Helper loaded: form_helper
INFO - 2020-08-25 03:47:04 --> Helper loaded: my_helper
INFO - 2020-08-25 03:47:04 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:47:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:47:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:47:04 --> Controller Class Initialized
DEBUG - 2020-08-25 03:47:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-08-25 03:47:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:47:04 --> Final output sent to browser
DEBUG - 2020-08-25 03:47:04 --> Total execution time: 0.0626
INFO - 2020-08-25 03:47:05 --> Config Class Initialized
INFO - 2020-08-25 03:47:05 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:47:05 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:47:05 --> Utf8 Class Initialized
INFO - 2020-08-25 03:47:05 --> URI Class Initialized
INFO - 2020-08-25 03:47:05 --> Router Class Initialized
INFO - 2020-08-25 03:47:05 --> Output Class Initialized
INFO - 2020-08-25 03:47:05 --> Security Class Initialized
DEBUG - 2020-08-25 03:47:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:47:05 --> Input Class Initialized
INFO - 2020-08-25 03:47:05 --> Language Class Initialized
INFO - 2020-08-25 03:47:05 --> Language Class Initialized
INFO - 2020-08-25 03:47:05 --> Config Class Initialized
INFO - 2020-08-25 03:47:05 --> Loader Class Initialized
INFO - 2020-08-25 03:47:05 --> Helper loaded: url_helper
INFO - 2020-08-25 03:47:05 --> Helper loaded: file_helper
INFO - 2020-08-25 03:47:05 --> Helper loaded: form_helper
INFO - 2020-08-25 03:47:05 --> Helper loaded: my_helper
INFO - 2020-08-25 03:47:05 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:47:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:47:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:47:05 --> Controller Class Initialized
DEBUG - 2020-08-25 03:47:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2020-08-25 03:47:06 --> Final output sent to browser
DEBUG - 2020-08-25 03:47:06 --> Total execution time: 0.2383
INFO - 2020-08-25 03:48:50 --> Config Class Initialized
INFO - 2020-08-25 03:48:50 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:48:50 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:48:50 --> Utf8 Class Initialized
INFO - 2020-08-25 03:48:50 --> URI Class Initialized
INFO - 2020-08-25 03:48:50 --> Router Class Initialized
INFO - 2020-08-25 03:48:50 --> Output Class Initialized
INFO - 2020-08-25 03:48:50 --> Security Class Initialized
DEBUG - 2020-08-25 03:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:48:50 --> Input Class Initialized
INFO - 2020-08-25 03:48:50 --> Language Class Initialized
INFO - 2020-08-25 03:48:50 --> Language Class Initialized
INFO - 2020-08-25 03:48:50 --> Config Class Initialized
INFO - 2020-08-25 03:48:50 --> Loader Class Initialized
INFO - 2020-08-25 03:48:50 --> Helper loaded: url_helper
INFO - 2020-08-25 03:48:50 --> Helper loaded: file_helper
INFO - 2020-08-25 03:48:50 --> Helper loaded: form_helper
INFO - 2020-08-25 03:48:50 --> Helper loaded: my_helper
INFO - 2020-08-25 03:48:50 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:48:50 --> Controller Class Initialized
DEBUG - 2020-08-25 03:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-08-25 03:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 03:48:50 --> Final output sent to browser
DEBUG - 2020-08-25 03:48:50 --> Total execution time: 0.0607
INFO - 2020-08-25 03:50:18 --> Config Class Initialized
INFO - 2020-08-25 03:50:18 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:18 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:18 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:18 --> URI Class Initialized
INFO - 2020-08-25 03:50:18 --> Router Class Initialized
INFO - 2020-08-25 03:50:18 --> Output Class Initialized
INFO - 2020-08-25 03:50:18 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:18 --> Input Class Initialized
INFO - 2020-08-25 03:50:18 --> Language Class Initialized
INFO - 2020-08-25 03:50:18 --> Language Class Initialized
INFO - 2020-08-25 03:50:18 --> Config Class Initialized
INFO - 2020-08-25 03:50:18 --> Loader Class Initialized
INFO - 2020-08-25 03:50:18 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:18 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:18 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:18 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:18 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:18 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:18 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:18 --> Total execution time: 0.1896
INFO - 2020-08-25 03:50:20 --> Config Class Initialized
INFO - 2020-08-25 03:50:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:20 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:20 --> URI Class Initialized
INFO - 2020-08-25 03:50:20 --> Router Class Initialized
INFO - 2020-08-25 03:50:20 --> Output Class Initialized
INFO - 2020-08-25 03:50:20 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:20 --> Input Class Initialized
INFO - 2020-08-25 03:50:20 --> Language Class Initialized
INFO - 2020-08-25 03:50:20 --> Language Class Initialized
INFO - 2020-08-25 03:50:20 --> Config Class Initialized
INFO - 2020-08-25 03:50:20 --> Loader Class Initialized
INFO - 2020-08-25 03:50:20 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:20 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:20 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:20 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:20 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:20 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:20 --> Total execution time: 0.1917
INFO - 2020-08-25 03:50:22 --> Config Class Initialized
INFO - 2020-08-25 03:50:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:22 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:22 --> URI Class Initialized
INFO - 2020-08-25 03:50:22 --> Router Class Initialized
INFO - 2020-08-25 03:50:22 --> Output Class Initialized
INFO - 2020-08-25 03:50:22 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:22 --> Input Class Initialized
INFO - 2020-08-25 03:50:22 --> Language Class Initialized
INFO - 2020-08-25 03:50:22 --> Language Class Initialized
INFO - 2020-08-25 03:50:22 --> Config Class Initialized
INFO - 2020-08-25 03:50:22 --> Loader Class Initialized
INFO - 2020-08-25 03:50:22 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:22 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:22 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:22 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:22 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:22 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:22 --> Total execution time: 0.1805
INFO - 2020-08-25 03:50:24 --> Config Class Initialized
INFO - 2020-08-25 03:50:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:24 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:24 --> URI Class Initialized
INFO - 2020-08-25 03:50:24 --> Router Class Initialized
INFO - 2020-08-25 03:50:24 --> Output Class Initialized
INFO - 2020-08-25 03:50:24 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:24 --> Input Class Initialized
INFO - 2020-08-25 03:50:24 --> Language Class Initialized
INFO - 2020-08-25 03:50:24 --> Language Class Initialized
INFO - 2020-08-25 03:50:24 --> Config Class Initialized
INFO - 2020-08-25 03:50:24 --> Loader Class Initialized
INFO - 2020-08-25 03:50:24 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:24 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:24 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:24 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:24 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:24 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:24 --> Total execution time: 0.1894
INFO - 2020-08-25 03:50:26 --> Config Class Initialized
INFO - 2020-08-25 03:50:26 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:26 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:26 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:26 --> URI Class Initialized
INFO - 2020-08-25 03:50:26 --> Router Class Initialized
INFO - 2020-08-25 03:50:26 --> Output Class Initialized
INFO - 2020-08-25 03:50:26 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:26 --> Input Class Initialized
INFO - 2020-08-25 03:50:26 --> Language Class Initialized
INFO - 2020-08-25 03:50:26 --> Language Class Initialized
INFO - 2020-08-25 03:50:26 --> Config Class Initialized
INFO - 2020-08-25 03:50:26 --> Loader Class Initialized
INFO - 2020-08-25 03:50:26 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:26 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:26 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:26 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:26 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:26 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:26 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:26 --> Total execution time: 0.1848
INFO - 2020-08-25 03:50:27 --> Config Class Initialized
INFO - 2020-08-25 03:50:27 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:27 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:27 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:27 --> URI Class Initialized
INFO - 2020-08-25 03:50:27 --> Router Class Initialized
INFO - 2020-08-25 03:50:27 --> Output Class Initialized
INFO - 2020-08-25 03:50:27 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:27 --> Input Class Initialized
INFO - 2020-08-25 03:50:27 --> Language Class Initialized
INFO - 2020-08-25 03:50:27 --> Language Class Initialized
INFO - 2020-08-25 03:50:27 --> Config Class Initialized
INFO - 2020-08-25 03:50:27 --> Loader Class Initialized
INFO - 2020-08-25 03:50:27 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:27 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:27 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:27 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:27 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:27 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:27 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:27 --> Total execution time: 0.1817
INFO - 2020-08-25 03:50:28 --> Config Class Initialized
INFO - 2020-08-25 03:50:28 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:28 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:28 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:28 --> URI Class Initialized
INFO - 2020-08-25 03:50:28 --> Router Class Initialized
INFO - 2020-08-25 03:50:28 --> Output Class Initialized
INFO - 2020-08-25 03:50:28 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:28 --> Input Class Initialized
INFO - 2020-08-25 03:50:28 --> Language Class Initialized
INFO - 2020-08-25 03:50:28 --> Language Class Initialized
INFO - 2020-08-25 03:50:28 --> Config Class Initialized
INFO - 2020-08-25 03:50:28 --> Loader Class Initialized
INFO - 2020-08-25 03:50:28 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:28 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:28 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:28 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:28 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:28 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:29 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:29 --> Total execution time: 0.2546
INFO - 2020-08-25 03:50:30 --> Config Class Initialized
INFO - 2020-08-25 03:50:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:30 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:30 --> URI Class Initialized
INFO - 2020-08-25 03:50:30 --> Router Class Initialized
INFO - 2020-08-25 03:50:30 --> Output Class Initialized
INFO - 2020-08-25 03:50:30 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:30 --> Input Class Initialized
INFO - 2020-08-25 03:50:30 --> Language Class Initialized
INFO - 2020-08-25 03:50:30 --> Language Class Initialized
INFO - 2020-08-25 03:50:30 --> Config Class Initialized
INFO - 2020-08-25 03:50:30 --> Loader Class Initialized
INFO - 2020-08-25 03:50:30 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:30 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:30 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:30 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:30 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:30 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:30 --> Total execution time: 0.1883
INFO - 2020-08-25 03:50:32 --> Config Class Initialized
INFO - 2020-08-25 03:50:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:32 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:32 --> URI Class Initialized
INFO - 2020-08-25 03:50:32 --> Router Class Initialized
INFO - 2020-08-25 03:50:32 --> Output Class Initialized
INFO - 2020-08-25 03:50:32 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:32 --> Input Class Initialized
INFO - 2020-08-25 03:50:32 --> Language Class Initialized
INFO - 2020-08-25 03:50:32 --> Language Class Initialized
INFO - 2020-08-25 03:50:32 --> Config Class Initialized
INFO - 2020-08-25 03:50:32 --> Loader Class Initialized
INFO - 2020-08-25 03:50:32 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:32 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:32 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:32 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:32 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:32 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:32 --> Total execution time: 0.2300
INFO - 2020-08-25 03:50:33 --> Config Class Initialized
INFO - 2020-08-25 03:50:33 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:33 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:33 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:33 --> URI Class Initialized
INFO - 2020-08-25 03:50:33 --> Router Class Initialized
INFO - 2020-08-25 03:50:33 --> Output Class Initialized
INFO - 2020-08-25 03:50:33 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:33 --> Input Class Initialized
INFO - 2020-08-25 03:50:33 --> Language Class Initialized
INFO - 2020-08-25 03:50:33 --> Language Class Initialized
INFO - 2020-08-25 03:50:33 --> Config Class Initialized
INFO - 2020-08-25 03:50:33 --> Loader Class Initialized
INFO - 2020-08-25 03:50:33 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:33 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:33 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:33 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:33 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:34 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:34 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:34 --> Total execution time: 0.1868
INFO - 2020-08-25 03:50:35 --> Config Class Initialized
INFO - 2020-08-25 03:50:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:35 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:35 --> URI Class Initialized
INFO - 2020-08-25 03:50:35 --> Router Class Initialized
INFO - 2020-08-25 03:50:35 --> Output Class Initialized
INFO - 2020-08-25 03:50:35 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:35 --> Input Class Initialized
INFO - 2020-08-25 03:50:35 --> Language Class Initialized
INFO - 2020-08-25 03:50:35 --> Language Class Initialized
INFO - 2020-08-25 03:50:35 --> Config Class Initialized
INFO - 2020-08-25 03:50:35 --> Loader Class Initialized
INFO - 2020-08-25 03:50:35 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:35 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:35 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:35 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:35 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:35 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:35 --> Total execution time: 0.2013
INFO - 2020-08-25 03:50:38 --> Config Class Initialized
INFO - 2020-08-25 03:50:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:38 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:38 --> URI Class Initialized
INFO - 2020-08-25 03:50:38 --> Router Class Initialized
INFO - 2020-08-25 03:50:38 --> Output Class Initialized
INFO - 2020-08-25 03:50:38 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:38 --> Input Class Initialized
INFO - 2020-08-25 03:50:38 --> Language Class Initialized
INFO - 2020-08-25 03:50:38 --> Language Class Initialized
INFO - 2020-08-25 03:50:38 --> Config Class Initialized
INFO - 2020-08-25 03:50:38 --> Loader Class Initialized
INFO - 2020-08-25 03:50:38 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:38 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:38 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:38 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:38 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:38 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:38 --> Total execution time: 0.1869
INFO - 2020-08-25 03:50:39 --> Config Class Initialized
INFO - 2020-08-25 03:50:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:39 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:39 --> URI Class Initialized
INFO - 2020-08-25 03:50:39 --> Router Class Initialized
INFO - 2020-08-25 03:50:39 --> Output Class Initialized
INFO - 2020-08-25 03:50:39 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:39 --> Input Class Initialized
INFO - 2020-08-25 03:50:39 --> Language Class Initialized
INFO - 2020-08-25 03:50:39 --> Language Class Initialized
INFO - 2020-08-25 03:50:39 --> Config Class Initialized
INFO - 2020-08-25 03:50:39 --> Loader Class Initialized
INFO - 2020-08-25 03:50:39 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:39 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:39 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:39 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:39 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:39 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:39 --> Total execution time: 0.1851
INFO - 2020-08-25 03:50:41 --> Config Class Initialized
INFO - 2020-08-25 03:50:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:41 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:41 --> URI Class Initialized
INFO - 2020-08-25 03:50:41 --> Router Class Initialized
INFO - 2020-08-25 03:50:41 --> Output Class Initialized
INFO - 2020-08-25 03:50:41 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:41 --> Input Class Initialized
INFO - 2020-08-25 03:50:41 --> Language Class Initialized
INFO - 2020-08-25 03:50:41 --> Language Class Initialized
INFO - 2020-08-25 03:50:41 --> Config Class Initialized
INFO - 2020-08-25 03:50:41 --> Loader Class Initialized
INFO - 2020-08-25 03:50:41 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:41 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:41 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:41 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:41 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:41 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:41 --> Total execution time: 0.1854
INFO - 2020-08-25 03:50:43 --> Config Class Initialized
INFO - 2020-08-25 03:50:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:43 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:43 --> URI Class Initialized
INFO - 2020-08-25 03:50:43 --> Router Class Initialized
INFO - 2020-08-25 03:50:43 --> Output Class Initialized
INFO - 2020-08-25 03:50:43 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:43 --> Input Class Initialized
INFO - 2020-08-25 03:50:43 --> Language Class Initialized
INFO - 2020-08-25 03:50:43 --> Language Class Initialized
INFO - 2020-08-25 03:50:43 --> Config Class Initialized
INFO - 2020-08-25 03:50:43 --> Loader Class Initialized
INFO - 2020-08-25 03:50:43 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:43 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:43 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:43 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:43 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:43 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:43 --> Total execution time: 0.1779
INFO - 2020-08-25 03:50:45 --> Config Class Initialized
INFO - 2020-08-25 03:50:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:45 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:45 --> URI Class Initialized
INFO - 2020-08-25 03:50:45 --> Router Class Initialized
INFO - 2020-08-25 03:50:45 --> Output Class Initialized
INFO - 2020-08-25 03:50:45 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:45 --> Input Class Initialized
INFO - 2020-08-25 03:50:45 --> Language Class Initialized
INFO - 2020-08-25 03:50:45 --> Language Class Initialized
INFO - 2020-08-25 03:50:45 --> Config Class Initialized
INFO - 2020-08-25 03:50:45 --> Loader Class Initialized
INFO - 2020-08-25 03:50:45 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:45 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:45 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:45 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:45 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:46 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:46 --> Total execution time: 0.2895
INFO - 2020-08-25 03:50:47 --> Config Class Initialized
INFO - 2020-08-25 03:50:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:47 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:47 --> URI Class Initialized
INFO - 2020-08-25 03:50:47 --> Router Class Initialized
INFO - 2020-08-25 03:50:47 --> Output Class Initialized
INFO - 2020-08-25 03:50:47 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:47 --> Input Class Initialized
INFO - 2020-08-25 03:50:47 --> Language Class Initialized
INFO - 2020-08-25 03:50:47 --> Language Class Initialized
INFO - 2020-08-25 03:50:47 --> Config Class Initialized
INFO - 2020-08-25 03:50:47 --> Loader Class Initialized
INFO - 2020-08-25 03:50:47 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:47 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:47 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:47 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:47 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:47 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:47 --> Total execution time: 0.1901
INFO - 2020-08-25 03:50:49 --> Config Class Initialized
INFO - 2020-08-25 03:50:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:49 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:49 --> URI Class Initialized
INFO - 2020-08-25 03:50:49 --> Router Class Initialized
INFO - 2020-08-25 03:50:49 --> Output Class Initialized
INFO - 2020-08-25 03:50:49 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:49 --> Input Class Initialized
INFO - 2020-08-25 03:50:49 --> Language Class Initialized
INFO - 2020-08-25 03:50:49 --> Language Class Initialized
INFO - 2020-08-25 03:50:49 --> Config Class Initialized
INFO - 2020-08-25 03:50:49 --> Loader Class Initialized
INFO - 2020-08-25 03:50:49 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:49 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:49 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:49 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:49 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:49 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:49 --> Total execution time: 0.1822
INFO - 2020-08-25 03:50:50 --> Config Class Initialized
INFO - 2020-08-25 03:50:50 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:50 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:50 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:50 --> URI Class Initialized
INFO - 2020-08-25 03:50:50 --> Router Class Initialized
INFO - 2020-08-25 03:50:50 --> Output Class Initialized
INFO - 2020-08-25 03:50:50 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:50 --> Input Class Initialized
INFO - 2020-08-25 03:50:50 --> Language Class Initialized
INFO - 2020-08-25 03:50:50 --> Language Class Initialized
INFO - 2020-08-25 03:50:50 --> Config Class Initialized
INFO - 2020-08-25 03:50:50 --> Loader Class Initialized
INFO - 2020-08-25 03:50:50 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:50 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:50 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:50 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:50 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:50 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:51 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:51 --> Total execution time: 0.2692
INFO - 2020-08-25 03:50:53 --> Config Class Initialized
INFO - 2020-08-25 03:50:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:53 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:53 --> URI Class Initialized
INFO - 2020-08-25 03:50:53 --> Router Class Initialized
INFO - 2020-08-25 03:50:53 --> Output Class Initialized
INFO - 2020-08-25 03:50:53 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:53 --> Input Class Initialized
INFO - 2020-08-25 03:50:53 --> Language Class Initialized
INFO - 2020-08-25 03:50:53 --> Language Class Initialized
INFO - 2020-08-25 03:50:53 --> Config Class Initialized
INFO - 2020-08-25 03:50:53 --> Loader Class Initialized
INFO - 2020-08-25 03:50:53 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:53 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:53 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:53 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:53 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:53 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:53 --> Total execution time: 0.1861
INFO - 2020-08-25 03:50:56 --> Config Class Initialized
INFO - 2020-08-25 03:50:56 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:56 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:56 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:56 --> URI Class Initialized
INFO - 2020-08-25 03:50:56 --> Router Class Initialized
INFO - 2020-08-25 03:50:56 --> Output Class Initialized
INFO - 2020-08-25 03:50:56 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:56 --> Input Class Initialized
INFO - 2020-08-25 03:50:56 --> Language Class Initialized
INFO - 2020-08-25 03:50:56 --> Language Class Initialized
INFO - 2020-08-25 03:50:56 --> Config Class Initialized
INFO - 2020-08-25 03:50:56 --> Loader Class Initialized
INFO - 2020-08-25 03:50:56 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:56 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:56 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:56 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:56 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:56 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:56 --> Total execution time: 0.1894
INFO - 2020-08-25 03:50:59 --> Config Class Initialized
INFO - 2020-08-25 03:50:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:50:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:50:59 --> Utf8 Class Initialized
INFO - 2020-08-25 03:50:59 --> URI Class Initialized
INFO - 2020-08-25 03:50:59 --> Router Class Initialized
INFO - 2020-08-25 03:50:59 --> Output Class Initialized
INFO - 2020-08-25 03:50:59 --> Security Class Initialized
DEBUG - 2020-08-25 03:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:50:59 --> Input Class Initialized
INFO - 2020-08-25 03:50:59 --> Language Class Initialized
INFO - 2020-08-25 03:50:59 --> Language Class Initialized
INFO - 2020-08-25 03:50:59 --> Config Class Initialized
INFO - 2020-08-25 03:50:59 --> Loader Class Initialized
INFO - 2020-08-25 03:50:59 --> Helper loaded: url_helper
INFO - 2020-08-25 03:50:59 --> Helper loaded: file_helper
INFO - 2020-08-25 03:50:59 --> Helper loaded: form_helper
INFO - 2020-08-25 03:50:59 --> Helper loaded: my_helper
INFO - 2020-08-25 03:50:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:50:59 --> Controller Class Initialized
DEBUG - 2020-08-25 03:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:50:59 --> Final output sent to browser
DEBUG - 2020-08-25 03:50:59 --> Total execution time: 0.1837
INFO - 2020-08-25 03:51:01 --> Config Class Initialized
INFO - 2020-08-25 03:51:01 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:01 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:01 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:01 --> URI Class Initialized
INFO - 2020-08-25 03:51:01 --> Router Class Initialized
INFO - 2020-08-25 03:51:01 --> Output Class Initialized
INFO - 2020-08-25 03:51:01 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:01 --> Input Class Initialized
INFO - 2020-08-25 03:51:01 --> Language Class Initialized
INFO - 2020-08-25 03:51:01 --> Language Class Initialized
INFO - 2020-08-25 03:51:01 --> Config Class Initialized
INFO - 2020-08-25 03:51:01 --> Loader Class Initialized
INFO - 2020-08-25 03:51:01 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:01 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:01 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:01 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:01 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:01 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:01 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:01 --> Total execution time: 0.1813
INFO - 2020-08-25 03:51:03 --> Config Class Initialized
INFO - 2020-08-25 03:51:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:03 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:03 --> URI Class Initialized
INFO - 2020-08-25 03:51:03 --> Router Class Initialized
INFO - 2020-08-25 03:51:03 --> Output Class Initialized
INFO - 2020-08-25 03:51:03 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:03 --> Input Class Initialized
INFO - 2020-08-25 03:51:03 --> Language Class Initialized
INFO - 2020-08-25 03:51:03 --> Language Class Initialized
INFO - 2020-08-25 03:51:03 --> Config Class Initialized
INFO - 2020-08-25 03:51:03 --> Loader Class Initialized
INFO - 2020-08-25 03:51:03 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:03 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:03 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:03 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:03 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:03 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:03 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:03 --> Total execution time: 0.1812
INFO - 2020-08-25 03:51:04 --> Config Class Initialized
INFO - 2020-08-25 03:51:04 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:04 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:04 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:04 --> URI Class Initialized
INFO - 2020-08-25 03:51:04 --> Router Class Initialized
INFO - 2020-08-25 03:51:04 --> Output Class Initialized
INFO - 2020-08-25 03:51:04 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:04 --> Input Class Initialized
INFO - 2020-08-25 03:51:04 --> Language Class Initialized
INFO - 2020-08-25 03:51:04 --> Language Class Initialized
INFO - 2020-08-25 03:51:04 --> Config Class Initialized
INFO - 2020-08-25 03:51:04 --> Loader Class Initialized
INFO - 2020-08-25 03:51:04 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:04 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:04 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:04 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:04 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:04 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:05 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:05 --> Total execution time: 0.2449
INFO - 2020-08-25 03:51:06 --> Config Class Initialized
INFO - 2020-08-25 03:51:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:06 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:06 --> URI Class Initialized
INFO - 2020-08-25 03:51:06 --> Router Class Initialized
INFO - 2020-08-25 03:51:06 --> Output Class Initialized
INFO - 2020-08-25 03:51:06 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:06 --> Input Class Initialized
INFO - 2020-08-25 03:51:06 --> Language Class Initialized
INFO - 2020-08-25 03:51:06 --> Language Class Initialized
INFO - 2020-08-25 03:51:06 --> Config Class Initialized
INFO - 2020-08-25 03:51:06 --> Loader Class Initialized
INFO - 2020-08-25 03:51:06 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:06 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:06 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:06 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:06 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:06 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:06 --> Total execution time: 0.1831
INFO - 2020-08-25 03:51:08 --> Config Class Initialized
INFO - 2020-08-25 03:51:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:08 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:08 --> URI Class Initialized
INFO - 2020-08-25 03:51:08 --> Router Class Initialized
INFO - 2020-08-25 03:51:08 --> Output Class Initialized
INFO - 2020-08-25 03:51:08 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:08 --> Input Class Initialized
INFO - 2020-08-25 03:51:08 --> Language Class Initialized
INFO - 2020-08-25 03:51:08 --> Language Class Initialized
INFO - 2020-08-25 03:51:08 --> Config Class Initialized
INFO - 2020-08-25 03:51:08 --> Loader Class Initialized
INFO - 2020-08-25 03:51:08 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:08 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:08 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:08 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:08 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:08 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:08 --> Total execution time: 0.1850
INFO - 2020-08-25 03:51:10 --> Config Class Initialized
INFO - 2020-08-25 03:51:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:10 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:10 --> URI Class Initialized
INFO - 2020-08-25 03:51:10 --> Router Class Initialized
INFO - 2020-08-25 03:51:10 --> Output Class Initialized
INFO - 2020-08-25 03:51:10 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:10 --> Input Class Initialized
INFO - 2020-08-25 03:51:10 --> Language Class Initialized
INFO - 2020-08-25 03:51:10 --> Language Class Initialized
INFO - 2020-08-25 03:51:10 --> Config Class Initialized
INFO - 2020-08-25 03:51:10 --> Loader Class Initialized
INFO - 2020-08-25 03:51:10 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:10 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:10 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:10 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:10 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:10 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:10 --> Total execution time: 0.1840
INFO - 2020-08-25 03:51:12 --> Config Class Initialized
INFO - 2020-08-25 03:51:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:12 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:12 --> URI Class Initialized
INFO - 2020-08-25 03:51:12 --> Router Class Initialized
INFO - 2020-08-25 03:51:12 --> Output Class Initialized
INFO - 2020-08-25 03:51:12 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:12 --> Input Class Initialized
INFO - 2020-08-25 03:51:12 --> Language Class Initialized
INFO - 2020-08-25 03:51:12 --> Language Class Initialized
INFO - 2020-08-25 03:51:12 --> Config Class Initialized
INFO - 2020-08-25 03:51:12 --> Loader Class Initialized
INFO - 2020-08-25 03:51:12 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:12 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:12 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:12 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:12 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:12 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:12 --> Total execution time: 0.1851
INFO - 2020-08-25 03:51:14 --> Config Class Initialized
INFO - 2020-08-25 03:51:14 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:14 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:14 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:14 --> URI Class Initialized
INFO - 2020-08-25 03:51:14 --> Router Class Initialized
INFO - 2020-08-25 03:51:14 --> Output Class Initialized
INFO - 2020-08-25 03:51:14 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:14 --> Input Class Initialized
INFO - 2020-08-25 03:51:14 --> Language Class Initialized
INFO - 2020-08-25 03:51:14 --> Language Class Initialized
INFO - 2020-08-25 03:51:14 --> Config Class Initialized
INFO - 2020-08-25 03:51:14 --> Loader Class Initialized
INFO - 2020-08-25 03:51:14 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:14 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:14 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:14 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:14 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:14 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:14 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:14 --> Total execution time: 0.1850
INFO - 2020-08-25 03:51:16 --> Config Class Initialized
INFO - 2020-08-25 03:51:16 --> Hooks Class Initialized
DEBUG - 2020-08-25 03:51:16 --> UTF-8 Support Enabled
INFO - 2020-08-25 03:51:16 --> Utf8 Class Initialized
INFO - 2020-08-25 03:51:16 --> URI Class Initialized
INFO - 2020-08-25 03:51:16 --> Router Class Initialized
INFO - 2020-08-25 03:51:16 --> Output Class Initialized
INFO - 2020-08-25 03:51:16 --> Security Class Initialized
DEBUG - 2020-08-25 03:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 03:51:16 --> Input Class Initialized
INFO - 2020-08-25 03:51:16 --> Language Class Initialized
INFO - 2020-08-25 03:51:16 --> Language Class Initialized
INFO - 2020-08-25 03:51:16 --> Config Class Initialized
INFO - 2020-08-25 03:51:16 --> Loader Class Initialized
INFO - 2020-08-25 03:51:16 --> Helper loaded: url_helper
INFO - 2020-08-25 03:51:16 --> Helper loaded: file_helper
INFO - 2020-08-25 03:51:16 --> Helper loaded: form_helper
INFO - 2020-08-25 03:51:16 --> Helper loaded: my_helper
INFO - 2020-08-25 03:51:16 --> Database Driver Class Initialized
DEBUG - 2020-08-25 03:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 03:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 03:51:16 --> Controller Class Initialized
DEBUG - 2020-08-25 03:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 03:51:16 --> Final output sent to browser
DEBUG - 2020-08-25 03:51:16 --> Total execution time: 0.1800
INFO - 2020-08-25 04:03:37 --> Config Class Initialized
INFO - 2020-08-25 04:03:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:37 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:37 --> URI Class Initialized
INFO - 2020-08-25 04:03:37 --> Router Class Initialized
INFO - 2020-08-25 04:03:37 --> Output Class Initialized
INFO - 2020-08-25 04:03:37 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:37 --> Input Class Initialized
INFO - 2020-08-25 04:03:37 --> Language Class Initialized
INFO - 2020-08-25 04:03:37 --> Language Class Initialized
INFO - 2020-08-25 04:03:37 --> Config Class Initialized
INFO - 2020-08-25 04:03:37 --> Loader Class Initialized
INFO - 2020-08-25 04:03:37 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:37 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:37 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:37 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:37 --> Controller Class Initialized
INFO - 2020-08-25 04:03:37 --> Helper loaded: cookie_helper
INFO - 2020-08-25 04:03:37 --> Config Class Initialized
INFO - 2020-08-25 04:03:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:37 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:37 --> URI Class Initialized
INFO - 2020-08-25 04:03:37 --> Router Class Initialized
INFO - 2020-08-25 04:03:37 --> Output Class Initialized
INFO - 2020-08-25 04:03:37 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:37 --> Input Class Initialized
INFO - 2020-08-25 04:03:37 --> Language Class Initialized
INFO - 2020-08-25 04:03:37 --> Language Class Initialized
INFO - 2020-08-25 04:03:37 --> Config Class Initialized
INFO - 2020-08-25 04:03:37 --> Loader Class Initialized
INFO - 2020-08-25 04:03:37 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:37 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:37 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:37 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:37 --> Controller Class Initialized
DEBUG - 2020-08-25 04:03:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 04:03:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:03:37 --> Final output sent to browser
DEBUG - 2020-08-25 04:03:37 --> Total execution time: 0.0477
INFO - 2020-08-25 04:03:42 --> Config Class Initialized
INFO - 2020-08-25 04:03:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:42 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:42 --> URI Class Initialized
INFO - 2020-08-25 04:03:42 --> Router Class Initialized
INFO - 2020-08-25 04:03:42 --> Output Class Initialized
INFO - 2020-08-25 04:03:42 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:42 --> Input Class Initialized
INFO - 2020-08-25 04:03:42 --> Language Class Initialized
INFO - 2020-08-25 04:03:42 --> Language Class Initialized
INFO - 2020-08-25 04:03:42 --> Config Class Initialized
INFO - 2020-08-25 04:03:42 --> Loader Class Initialized
INFO - 2020-08-25 04:03:42 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:42 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:42 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:42 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:42 --> Controller Class Initialized
INFO - 2020-08-25 04:03:42 --> Helper loaded: cookie_helper
INFO - 2020-08-25 04:03:42 --> Final output sent to browser
DEBUG - 2020-08-25 04:03:42 --> Total execution time: 0.0428
INFO - 2020-08-25 04:03:42 --> Config Class Initialized
INFO - 2020-08-25 04:03:42 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:42 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:42 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:42 --> URI Class Initialized
INFO - 2020-08-25 04:03:42 --> Router Class Initialized
INFO - 2020-08-25 04:03:42 --> Output Class Initialized
INFO - 2020-08-25 04:03:42 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:42 --> Input Class Initialized
INFO - 2020-08-25 04:03:42 --> Language Class Initialized
INFO - 2020-08-25 04:03:42 --> Language Class Initialized
INFO - 2020-08-25 04:03:42 --> Config Class Initialized
INFO - 2020-08-25 04:03:42 --> Loader Class Initialized
INFO - 2020-08-25 04:03:42 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:42 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:42 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:42 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:42 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:42 --> Controller Class Initialized
DEBUG - 2020-08-25 04:03:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 04:03:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:03:42 --> Final output sent to browser
DEBUG - 2020-08-25 04:03:42 --> Total execution time: 0.6482
INFO - 2020-08-25 04:03:45 --> Config Class Initialized
INFO - 2020-08-25 04:03:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:45 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:45 --> URI Class Initialized
INFO - 2020-08-25 04:03:45 --> Router Class Initialized
INFO - 2020-08-25 04:03:45 --> Output Class Initialized
INFO - 2020-08-25 04:03:45 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:45 --> Input Class Initialized
INFO - 2020-08-25 04:03:45 --> Language Class Initialized
INFO - 2020-08-25 04:03:45 --> Language Class Initialized
INFO - 2020-08-25 04:03:45 --> Config Class Initialized
INFO - 2020-08-25 04:03:45 --> Loader Class Initialized
INFO - 2020-08-25 04:03:45 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:45 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:45 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:45 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:45 --> Controller Class Initialized
DEBUG - 2020-08-25 04:03:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 04:03:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:03:45 --> Final output sent to browser
DEBUG - 2020-08-25 04:03:45 --> Total execution time: 0.0491
INFO - 2020-08-25 04:03:45 --> Config Class Initialized
INFO - 2020-08-25 04:03:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:45 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:45 --> URI Class Initialized
INFO - 2020-08-25 04:03:45 --> Router Class Initialized
INFO - 2020-08-25 04:03:45 --> Output Class Initialized
INFO - 2020-08-25 04:03:45 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:45 --> Input Class Initialized
INFO - 2020-08-25 04:03:45 --> Language Class Initialized
INFO - 2020-08-25 04:03:45 --> Language Class Initialized
INFO - 2020-08-25 04:03:45 --> Config Class Initialized
INFO - 2020-08-25 04:03:45 --> Loader Class Initialized
INFO - 2020-08-25 04:03:45 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:45 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:45 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:45 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:45 --> Controller Class Initialized
INFO - 2020-08-25 04:03:47 --> Config Class Initialized
INFO - 2020-08-25 04:03:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:47 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:47 --> URI Class Initialized
INFO - 2020-08-25 04:03:47 --> Router Class Initialized
INFO - 2020-08-25 04:03:47 --> Output Class Initialized
INFO - 2020-08-25 04:03:47 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:47 --> Input Class Initialized
INFO - 2020-08-25 04:03:47 --> Language Class Initialized
INFO - 2020-08-25 04:03:47 --> Language Class Initialized
INFO - 2020-08-25 04:03:47 --> Config Class Initialized
INFO - 2020-08-25 04:03:47 --> Loader Class Initialized
INFO - 2020-08-25 04:03:47 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:47 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:47 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:47 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:47 --> Controller Class Initialized
INFO - 2020-08-25 04:03:50 --> Config Class Initialized
INFO - 2020-08-25 04:03:50 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:50 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:50 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:50 --> URI Class Initialized
INFO - 2020-08-25 04:03:50 --> Router Class Initialized
INFO - 2020-08-25 04:03:50 --> Output Class Initialized
INFO - 2020-08-25 04:03:50 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:50 --> Input Class Initialized
INFO - 2020-08-25 04:03:50 --> Language Class Initialized
INFO - 2020-08-25 04:03:50 --> Language Class Initialized
INFO - 2020-08-25 04:03:50 --> Config Class Initialized
INFO - 2020-08-25 04:03:50 --> Loader Class Initialized
INFO - 2020-08-25 04:03:50 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:50 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:50 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:50 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:50 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:50 --> Controller Class Initialized
ERROR - 2020-08-25 04:03:50 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-08-25 04:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-25 04:03:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:03:50 --> Final output sent to browser
DEBUG - 2020-08-25 04:03:50 --> Total execution time: 0.0439
INFO - 2020-08-25 04:03:57 --> Config Class Initialized
INFO - 2020-08-25 04:03:57 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:57 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:57 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:57 --> URI Class Initialized
INFO - 2020-08-25 04:03:57 --> Router Class Initialized
INFO - 2020-08-25 04:03:57 --> Output Class Initialized
INFO - 2020-08-25 04:03:57 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:57 --> Input Class Initialized
INFO - 2020-08-25 04:03:57 --> Language Class Initialized
INFO - 2020-08-25 04:03:57 --> Language Class Initialized
INFO - 2020-08-25 04:03:57 --> Config Class Initialized
INFO - 2020-08-25 04:03:57 --> Loader Class Initialized
INFO - 2020-08-25 04:03:57 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:57 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:57 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:57 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:57 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:57 --> Controller Class Initialized
INFO - 2020-08-25 04:03:57 --> Upload Class Initialized
INFO - 2020-08-25 04:03:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-08-25 04:03:57 --> The upload path does not appear to be valid.
INFO - 2020-08-25 04:03:57 --> Config Class Initialized
INFO - 2020-08-25 04:03:57 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:57 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:57 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:57 --> URI Class Initialized
INFO - 2020-08-25 04:03:57 --> Router Class Initialized
INFO - 2020-08-25 04:03:57 --> Output Class Initialized
INFO - 2020-08-25 04:03:57 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:57 --> Input Class Initialized
INFO - 2020-08-25 04:03:57 --> Language Class Initialized
INFO - 2020-08-25 04:03:57 --> Language Class Initialized
INFO - 2020-08-25 04:03:57 --> Config Class Initialized
INFO - 2020-08-25 04:03:57 --> Loader Class Initialized
INFO - 2020-08-25 04:03:57 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:57 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:57 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:57 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:57 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:57 --> Controller Class Initialized
DEBUG - 2020-08-25 04:03:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 04:03:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:03:57 --> Final output sent to browser
DEBUG - 2020-08-25 04:03:57 --> Total execution time: 0.0386
INFO - 2020-08-25 04:03:58 --> Config Class Initialized
INFO - 2020-08-25 04:03:58 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:03:58 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:03:58 --> Utf8 Class Initialized
INFO - 2020-08-25 04:03:58 --> URI Class Initialized
INFO - 2020-08-25 04:03:58 --> Router Class Initialized
INFO - 2020-08-25 04:03:58 --> Output Class Initialized
INFO - 2020-08-25 04:03:58 --> Security Class Initialized
DEBUG - 2020-08-25 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:03:58 --> Input Class Initialized
INFO - 2020-08-25 04:03:58 --> Language Class Initialized
INFO - 2020-08-25 04:03:58 --> Language Class Initialized
INFO - 2020-08-25 04:03:58 --> Config Class Initialized
INFO - 2020-08-25 04:03:58 --> Loader Class Initialized
INFO - 2020-08-25 04:03:58 --> Helper loaded: url_helper
INFO - 2020-08-25 04:03:58 --> Helper loaded: file_helper
INFO - 2020-08-25 04:03:58 --> Helper loaded: form_helper
INFO - 2020-08-25 04:03:58 --> Helper loaded: my_helper
INFO - 2020-08-25 04:03:58 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:03:58 --> Controller Class Initialized
INFO - 2020-08-25 04:04:13 --> Config Class Initialized
INFO - 2020-08-25 04:04:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:04:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:04:13 --> Utf8 Class Initialized
INFO - 2020-08-25 04:04:13 --> URI Class Initialized
INFO - 2020-08-25 04:04:13 --> Router Class Initialized
INFO - 2020-08-25 04:04:13 --> Output Class Initialized
INFO - 2020-08-25 04:04:13 --> Security Class Initialized
DEBUG - 2020-08-25 04:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:04:13 --> Input Class Initialized
INFO - 2020-08-25 04:04:13 --> Language Class Initialized
INFO - 2020-08-25 04:04:13 --> Language Class Initialized
INFO - 2020-08-25 04:04:13 --> Config Class Initialized
INFO - 2020-08-25 04:04:13 --> Loader Class Initialized
INFO - 2020-08-25 04:04:13 --> Helper loaded: url_helper
INFO - 2020-08-25 04:04:13 --> Helper loaded: file_helper
INFO - 2020-08-25 04:04:13 --> Helper loaded: form_helper
INFO - 2020-08-25 04:04:13 --> Helper loaded: my_helper
INFO - 2020-08-25 04:04:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:04:13 --> Controller Class Initialized
INFO - 2020-08-25 04:04:13 --> Helper loaded: cookie_helper
INFO - 2020-08-25 04:04:13 --> Config Class Initialized
INFO - 2020-08-25 04:04:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:04:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:04:13 --> Utf8 Class Initialized
INFO - 2020-08-25 04:04:13 --> URI Class Initialized
INFO - 2020-08-25 04:04:13 --> Router Class Initialized
INFO - 2020-08-25 04:04:13 --> Output Class Initialized
INFO - 2020-08-25 04:04:13 --> Security Class Initialized
DEBUG - 2020-08-25 04:04:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:04:13 --> Input Class Initialized
INFO - 2020-08-25 04:04:13 --> Language Class Initialized
INFO - 2020-08-25 04:04:13 --> Language Class Initialized
INFO - 2020-08-25 04:04:13 --> Config Class Initialized
INFO - 2020-08-25 04:04:13 --> Loader Class Initialized
INFO - 2020-08-25 04:04:13 --> Helper loaded: url_helper
INFO - 2020-08-25 04:04:13 --> Helper loaded: file_helper
INFO - 2020-08-25 04:04:13 --> Helper loaded: form_helper
INFO - 2020-08-25 04:04:13 --> Helper loaded: my_helper
INFO - 2020-08-25 04:04:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:04:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:04:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:04:13 --> Controller Class Initialized
DEBUG - 2020-08-25 04:04:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 04:04:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:04:13 --> Final output sent to browser
DEBUG - 2020-08-25 04:04:13 --> Total execution time: 0.0393
INFO - 2020-08-25 04:05:24 --> Config Class Initialized
INFO - 2020-08-25 04:05:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:05:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:05:24 --> Utf8 Class Initialized
INFO - 2020-08-25 04:05:24 --> URI Class Initialized
INFO - 2020-08-25 04:05:24 --> Router Class Initialized
INFO - 2020-08-25 04:05:24 --> Output Class Initialized
INFO - 2020-08-25 04:05:24 --> Security Class Initialized
DEBUG - 2020-08-25 04:05:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:05:24 --> Input Class Initialized
INFO - 2020-08-25 04:05:24 --> Language Class Initialized
INFO - 2020-08-25 04:05:24 --> Language Class Initialized
INFO - 2020-08-25 04:05:24 --> Config Class Initialized
INFO - 2020-08-25 04:05:24 --> Loader Class Initialized
INFO - 2020-08-25 04:05:24 --> Helper loaded: url_helper
INFO - 2020-08-25 04:05:24 --> Helper loaded: file_helper
INFO - 2020-08-25 04:05:24 --> Helper loaded: form_helper
INFO - 2020-08-25 04:05:24 --> Helper loaded: my_helper
INFO - 2020-08-25 04:05:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:05:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:05:24 --> Controller Class Initialized
DEBUG - 2020-08-25 04:05:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 04:05:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:05:24 --> Final output sent to browser
DEBUG - 2020-08-25 04:05:24 --> Total execution time: 0.0446
INFO - 2020-08-25 04:05:36 --> Config Class Initialized
INFO - 2020-08-25 04:05:36 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:05:36 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:05:36 --> Utf8 Class Initialized
INFO - 2020-08-25 04:05:36 --> URI Class Initialized
INFO - 2020-08-25 04:05:36 --> Router Class Initialized
INFO - 2020-08-25 04:05:36 --> Output Class Initialized
INFO - 2020-08-25 04:05:36 --> Security Class Initialized
DEBUG - 2020-08-25 04:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:05:36 --> Input Class Initialized
INFO - 2020-08-25 04:05:36 --> Language Class Initialized
INFO - 2020-08-25 04:05:36 --> Language Class Initialized
INFO - 2020-08-25 04:05:36 --> Config Class Initialized
INFO - 2020-08-25 04:05:36 --> Loader Class Initialized
INFO - 2020-08-25 04:05:36 --> Helper loaded: url_helper
INFO - 2020-08-25 04:05:36 --> Helper loaded: file_helper
INFO - 2020-08-25 04:05:36 --> Helper loaded: form_helper
INFO - 2020-08-25 04:05:36 --> Helper loaded: my_helper
INFO - 2020-08-25 04:05:36 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:05:36 --> Controller Class Initialized
DEBUG - 2020-08-25 04:05:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 04:05:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:05:36 --> Final output sent to browser
DEBUG - 2020-08-25 04:05:36 --> Total execution time: 0.0433
INFO - 2020-08-25 04:05:56 --> Config Class Initialized
INFO - 2020-08-25 04:05:56 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:05:56 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:05:56 --> Utf8 Class Initialized
INFO - 2020-08-25 04:05:56 --> URI Class Initialized
INFO - 2020-08-25 04:05:56 --> Router Class Initialized
INFO - 2020-08-25 04:05:56 --> Output Class Initialized
INFO - 2020-08-25 04:05:56 --> Security Class Initialized
DEBUG - 2020-08-25 04:05:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:05:56 --> Input Class Initialized
INFO - 2020-08-25 04:05:56 --> Language Class Initialized
INFO - 2020-08-25 04:05:56 --> Language Class Initialized
INFO - 2020-08-25 04:05:56 --> Config Class Initialized
INFO - 2020-08-25 04:05:56 --> Loader Class Initialized
INFO - 2020-08-25 04:05:56 --> Helper loaded: url_helper
INFO - 2020-08-25 04:05:56 --> Helper loaded: file_helper
INFO - 2020-08-25 04:05:56 --> Helper loaded: form_helper
INFO - 2020-08-25 04:05:56 --> Helper loaded: my_helper
INFO - 2020-08-25 04:05:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:05:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:05:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:05:56 --> Controller Class Initialized
INFO - 2020-08-25 04:05:56 --> Helper loaded: cookie_helper
INFO - 2020-08-25 04:05:56 --> Final output sent to browser
DEBUG - 2020-08-25 04:05:56 --> Total execution time: 0.0489
INFO - 2020-08-25 04:05:59 --> Config Class Initialized
INFO - 2020-08-25 04:05:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:05:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:05:59 --> Utf8 Class Initialized
INFO - 2020-08-25 04:05:59 --> URI Class Initialized
INFO - 2020-08-25 04:05:59 --> Router Class Initialized
INFO - 2020-08-25 04:05:59 --> Output Class Initialized
INFO - 2020-08-25 04:05:59 --> Security Class Initialized
DEBUG - 2020-08-25 04:05:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:05:59 --> Input Class Initialized
INFO - 2020-08-25 04:05:59 --> Language Class Initialized
INFO - 2020-08-25 04:05:59 --> Language Class Initialized
INFO - 2020-08-25 04:05:59 --> Config Class Initialized
INFO - 2020-08-25 04:05:59 --> Loader Class Initialized
INFO - 2020-08-25 04:05:59 --> Helper loaded: url_helper
INFO - 2020-08-25 04:05:59 --> Helper loaded: file_helper
INFO - 2020-08-25 04:05:59 --> Helper loaded: form_helper
INFO - 2020-08-25 04:05:59 --> Helper loaded: my_helper
INFO - 2020-08-25 04:05:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:05:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:05:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:05:59 --> Controller Class Initialized
DEBUG - 2020-08-25 04:05:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 04:05:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:05:59 --> Final output sent to browser
DEBUG - 2020-08-25 04:05:59 --> Total execution time: 0.5775
INFO - 2020-08-25 04:06:18 --> Config Class Initialized
INFO - 2020-08-25 04:06:18 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:18 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:18 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:18 --> URI Class Initialized
INFO - 2020-08-25 04:06:18 --> Router Class Initialized
INFO - 2020-08-25 04:06:18 --> Output Class Initialized
INFO - 2020-08-25 04:06:18 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:18 --> Input Class Initialized
INFO - 2020-08-25 04:06:18 --> Language Class Initialized
INFO - 2020-08-25 04:06:18 --> Language Class Initialized
INFO - 2020-08-25 04:06:18 --> Config Class Initialized
INFO - 2020-08-25 04:06:18 --> Loader Class Initialized
INFO - 2020-08-25 04:06:18 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:18 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:18 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:18 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:18 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:18 --> Controller Class Initialized
DEBUG - 2020-08-25 04:06:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 04:06:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:06:18 --> Final output sent to browser
DEBUG - 2020-08-25 04:06:18 --> Total execution time: 0.0490
INFO - 2020-08-25 04:06:30 --> Config Class Initialized
INFO - 2020-08-25 04:06:30 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:30 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:30 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:30 --> URI Class Initialized
INFO - 2020-08-25 04:06:30 --> Router Class Initialized
INFO - 2020-08-25 04:06:30 --> Output Class Initialized
INFO - 2020-08-25 04:06:30 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:30 --> Input Class Initialized
INFO - 2020-08-25 04:06:30 --> Language Class Initialized
INFO - 2020-08-25 04:06:30 --> Language Class Initialized
INFO - 2020-08-25 04:06:30 --> Config Class Initialized
INFO - 2020-08-25 04:06:30 --> Loader Class Initialized
INFO - 2020-08-25 04:06:30 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:30 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:30 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:30 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:30 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:30 --> Controller Class Initialized
INFO - 2020-08-25 04:06:35 --> Config Class Initialized
INFO - 2020-08-25 04:06:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:35 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:35 --> URI Class Initialized
INFO - 2020-08-25 04:06:35 --> Router Class Initialized
INFO - 2020-08-25 04:06:35 --> Output Class Initialized
INFO - 2020-08-25 04:06:35 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:35 --> Input Class Initialized
INFO - 2020-08-25 04:06:35 --> Language Class Initialized
INFO - 2020-08-25 04:06:35 --> Language Class Initialized
INFO - 2020-08-25 04:06:35 --> Config Class Initialized
INFO - 2020-08-25 04:06:35 --> Loader Class Initialized
INFO - 2020-08-25 04:06:35 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:35 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:35 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:35 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:35 --> Controller Class Initialized
INFO - 2020-08-25 04:06:37 --> Config Class Initialized
INFO - 2020-08-25 04:06:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:37 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:37 --> URI Class Initialized
INFO - 2020-08-25 04:06:37 --> Router Class Initialized
INFO - 2020-08-25 04:06:37 --> Output Class Initialized
INFO - 2020-08-25 04:06:37 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:37 --> Input Class Initialized
INFO - 2020-08-25 04:06:37 --> Language Class Initialized
INFO - 2020-08-25 04:06:37 --> Language Class Initialized
INFO - 2020-08-25 04:06:37 --> Config Class Initialized
INFO - 2020-08-25 04:06:37 --> Loader Class Initialized
INFO - 2020-08-25 04:06:37 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:37 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:37 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:37 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:37 --> Controller Class Initialized
INFO - 2020-08-25 04:06:37 --> Config Class Initialized
INFO - 2020-08-25 04:06:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:37 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:37 --> URI Class Initialized
INFO - 2020-08-25 04:06:37 --> Router Class Initialized
INFO - 2020-08-25 04:06:37 --> Output Class Initialized
INFO - 2020-08-25 04:06:37 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:37 --> Input Class Initialized
INFO - 2020-08-25 04:06:37 --> Language Class Initialized
INFO - 2020-08-25 04:06:37 --> Language Class Initialized
INFO - 2020-08-25 04:06:37 --> Config Class Initialized
INFO - 2020-08-25 04:06:37 --> Loader Class Initialized
INFO - 2020-08-25 04:06:37 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:37 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:37 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:37 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:37 --> Controller Class Initialized
INFO - 2020-08-25 04:06:38 --> Config Class Initialized
INFO - 2020-08-25 04:06:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:38 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:38 --> URI Class Initialized
INFO - 2020-08-25 04:06:38 --> Router Class Initialized
INFO - 2020-08-25 04:06:38 --> Output Class Initialized
INFO - 2020-08-25 04:06:38 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:38 --> Input Class Initialized
INFO - 2020-08-25 04:06:38 --> Language Class Initialized
INFO - 2020-08-25 04:06:38 --> Language Class Initialized
INFO - 2020-08-25 04:06:38 --> Config Class Initialized
INFO - 2020-08-25 04:06:38 --> Loader Class Initialized
INFO - 2020-08-25 04:06:38 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:38 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:38 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:38 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:38 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:38 --> Controller Class Initialized
INFO - 2020-08-25 04:06:39 --> Config Class Initialized
INFO - 2020-08-25 04:06:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:39 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:39 --> URI Class Initialized
INFO - 2020-08-25 04:06:39 --> Router Class Initialized
INFO - 2020-08-25 04:06:39 --> Output Class Initialized
INFO - 2020-08-25 04:06:39 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:39 --> Input Class Initialized
INFO - 2020-08-25 04:06:39 --> Language Class Initialized
INFO - 2020-08-25 04:06:39 --> Language Class Initialized
INFO - 2020-08-25 04:06:39 --> Config Class Initialized
INFO - 2020-08-25 04:06:39 --> Loader Class Initialized
INFO - 2020-08-25 04:06:39 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:39 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:39 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:39 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:39 --> Controller Class Initialized
INFO - 2020-08-25 04:06:40 --> Config Class Initialized
INFO - 2020-08-25 04:06:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:40 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:40 --> URI Class Initialized
INFO - 2020-08-25 04:06:40 --> Router Class Initialized
INFO - 2020-08-25 04:06:40 --> Output Class Initialized
INFO - 2020-08-25 04:06:40 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:40 --> Input Class Initialized
INFO - 2020-08-25 04:06:40 --> Language Class Initialized
INFO - 2020-08-25 04:06:40 --> Language Class Initialized
INFO - 2020-08-25 04:06:40 --> Config Class Initialized
INFO - 2020-08-25 04:06:40 --> Loader Class Initialized
INFO - 2020-08-25 04:06:40 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:40 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:40 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:40 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:40 --> Controller Class Initialized
INFO - 2020-08-25 04:06:40 --> Config Class Initialized
INFO - 2020-08-25 04:06:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:40 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:40 --> URI Class Initialized
INFO - 2020-08-25 04:06:40 --> Router Class Initialized
INFO - 2020-08-25 04:06:40 --> Output Class Initialized
INFO - 2020-08-25 04:06:40 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:40 --> Input Class Initialized
INFO - 2020-08-25 04:06:40 --> Language Class Initialized
INFO - 2020-08-25 04:06:40 --> Language Class Initialized
INFO - 2020-08-25 04:06:40 --> Config Class Initialized
INFO - 2020-08-25 04:06:40 --> Loader Class Initialized
INFO - 2020-08-25 04:06:40 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:40 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:40 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:40 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:40 --> Controller Class Initialized
INFO - 2020-08-25 04:06:41 --> Config Class Initialized
INFO - 2020-08-25 04:06:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:41 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:41 --> URI Class Initialized
INFO - 2020-08-25 04:06:41 --> Router Class Initialized
INFO - 2020-08-25 04:06:41 --> Output Class Initialized
INFO - 2020-08-25 04:06:41 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:41 --> Input Class Initialized
INFO - 2020-08-25 04:06:41 --> Language Class Initialized
INFO - 2020-08-25 04:06:41 --> Language Class Initialized
INFO - 2020-08-25 04:06:41 --> Config Class Initialized
INFO - 2020-08-25 04:06:41 --> Loader Class Initialized
INFO - 2020-08-25 04:06:41 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:41 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:41 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:41 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:41 --> Controller Class Initialized
INFO - 2020-08-25 04:06:41 --> Config Class Initialized
INFO - 2020-08-25 04:06:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:41 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:41 --> URI Class Initialized
INFO - 2020-08-25 04:06:41 --> Router Class Initialized
INFO - 2020-08-25 04:06:41 --> Output Class Initialized
INFO - 2020-08-25 04:06:41 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:41 --> Input Class Initialized
INFO - 2020-08-25 04:06:41 --> Language Class Initialized
INFO - 2020-08-25 04:06:41 --> Language Class Initialized
INFO - 2020-08-25 04:06:41 --> Config Class Initialized
INFO - 2020-08-25 04:06:41 --> Loader Class Initialized
INFO - 2020-08-25 04:06:41 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:41 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:41 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:41 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:41 --> Controller Class Initialized
INFO - 2020-08-25 04:06:43 --> Config Class Initialized
INFO - 2020-08-25 04:06:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:43 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:43 --> URI Class Initialized
INFO - 2020-08-25 04:06:43 --> Router Class Initialized
INFO - 2020-08-25 04:06:43 --> Output Class Initialized
INFO - 2020-08-25 04:06:43 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:43 --> Input Class Initialized
INFO - 2020-08-25 04:06:43 --> Language Class Initialized
INFO - 2020-08-25 04:06:43 --> Language Class Initialized
INFO - 2020-08-25 04:06:43 --> Config Class Initialized
INFO - 2020-08-25 04:06:43 --> Loader Class Initialized
INFO - 2020-08-25 04:06:43 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:43 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:43 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:43 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:43 --> Controller Class Initialized
INFO - 2020-08-25 04:06:43 --> Config Class Initialized
INFO - 2020-08-25 04:06:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:43 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:43 --> URI Class Initialized
INFO - 2020-08-25 04:06:43 --> Router Class Initialized
INFO - 2020-08-25 04:06:43 --> Output Class Initialized
INFO - 2020-08-25 04:06:43 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:43 --> Input Class Initialized
INFO - 2020-08-25 04:06:43 --> Language Class Initialized
INFO - 2020-08-25 04:06:43 --> Language Class Initialized
INFO - 2020-08-25 04:06:43 --> Config Class Initialized
INFO - 2020-08-25 04:06:43 --> Loader Class Initialized
INFO - 2020-08-25 04:06:43 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:43 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:43 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:43 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:43 --> Controller Class Initialized
INFO - 2020-08-25 04:06:55 --> Config Class Initialized
INFO - 2020-08-25 04:06:55 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:06:55 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:06:55 --> Utf8 Class Initialized
INFO - 2020-08-25 04:06:55 --> URI Class Initialized
INFO - 2020-08-25 04:06:55 --> Router Class Initialized
INFO - 2020-08-25 04:06:55 --> Output Class Initialized
INFO - 2020-08-25 04:06:55 --> Security Class Initialized
DEBUG - 2020-08-25 04:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:06:55 --> Input Class Initialized
INFO - 2020-08-25 04:06:55 --> Language Class Initialized
INFO - 2020-08-25 04:06:55 --> Language Class Initialized
INFO - 2020-08-25 04:06:55 --> Config Class Initialized
INFO - 2020-08-25 04:06:55 --> Loader Class Initialized
INFO - 2020-08-25 04:06:55 --> Helper loaded: url_helper
INFO - 2020-08-25 04:06:55 --> Helper loaded: file_helper
INFO - 2020-08-25 04:06:55 --> Helper loaded: form_helper
INFO - 2020-08-25 04:06:55 --> Helper loaded: my_helper
INFO - 2020-08-25 04:06:55 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:06:55 --> Controller Class Initialized
INFO - 2020-08-25 04:07:02 --> Config Class Initialized
INFO - 2020-08-25 04:07:02 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:07:02 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:07:02 --> Utf8 Class Initialized
INFO - 2020-08-25 04:07:02 --> URI Class Initialized
INFO - 2020-08-25 04:07:02 --> Router Class Initialized
INFO - 2020-08-25 04:07:02 --> Output Class Initialized
INFO - 2020-08-25 04:07:02 --> Security Class Initialized
DEBUG - 2020-08-25 04:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:07:02 --> Input Class Initialized
INFO - 2020-08-25 04:07:02 --> Language Class Initialized
INFO - 2020-08-25 04:07:02 --> Language Class Initialized
INFO - 2020-08-25 04:07:02 --> Config Class Initialized
INFO - 2020-08-25 04:07:02 --> Loader Class Initialized
INFO - 2020-08-25 04:07:02 --> Helper loaded: url_helper
INFO - 2020-08-25 04:07:02 --> Helper loaded: file_helper
INFO - 2020-08-25 04:07:02 --> Helper loaded: form_helper
INFO - 2020-08-25 04:07:02 --> Helper loaded: my_helper
INFO - 2020-08-25 04:07:02 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:07:02 --> Controller Class Initialized
INFO - 2020-08-25 04:07:07 --> Config Class Initialized
INFO - 2020-08-25 04:07:07 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:07:07 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:07:07 --> Utf8 Class Initialized
INFO - 2020-08-25 04:07:07 --> URI Class Initialized
INFO - 2020-08-25 04:07:07 --> Router Class Initialized
INFO - 2020-08-25 04:07:07 --> Output Class Initialized
INFO - 2020-08-25 04:07:07 --> Security Class Initialized
DEBUG - 2020-08-25 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:07:07 --> Input Class Initialized
INFO - 2020-08-25 04:07:07 --> Language Class Initialized
INFO - 2020-08-25 04:07:07 --> Language Class Initialized
INFO - 2020-08-25 04:07:07 --> Config Class Initialized
INFO - 2020-08-25 04:07:07 --> Loader Class Initialized
INFO - 2020-08-25 04:07:07 --> Helper loaded: url_helper
INFO - 2020-08-25 04:07:07 --> Helper loaded: file_helper
INFO - 2020-08-25 04:07:07 --> Helper loaded: form_helper
INFO - 2020-08-25 04:07:07 --> Helper loaded: my_helper
INFO - 2020-08-25 04:07:07 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:07:07 --> Controller Class Initialized
ERROR - 2020-08-25 04:07:07 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-08-25 04:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-25 04:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:07:07 --> Final output sent to browser
DEBUG - 2020-08-25 04:07:07 --> Total execution time: 0.0480
INFO - 2020-08-25 04:07:07 --> Config Class Initialized
INFO - 2020-08-25 04:07:07 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:07:07 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:07:07 --> Utf8 Class Initialized
INFO - 2020-08-25 04:07:07 --> URI Class Initialized
INFO - 2020-08-25 04:07:07 --> Router Class Initialized
INFO - 2020-08-25 04:07:07 --> Output Class Initialized
INFO - 2020-08-25 04:07:07 --> Security Class Initialized
DEBUG - 2020-08-25 04:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:07:07 --> Input Class Initialized
INFO - 2020-08-25 04:07:07 --> Language Class Initialized
INFO - 2020-08-25 04:07:07 --> Language Class Initialized
INFO - 2020-08-25 04:07:07 --> Config Class Initialized
INFO - 2020-08-25 04:07:07 --> Loader Class Initialized
INFO - 2020-08-25 04:07:07 --> Helper loaded: url_helper
INFO - 2020-08-25 04:07:07 --> Helper loaded: file_helper
INFO - 2020-08-25 04:07:07 --> Helper loaded: form_helper
INFO - 2020-08-25 04:07:07 --> Helper loaded: my_helper
INFO - 2020-08-25 04:07:07 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:07:08 --> Controller Class Initialized
ERROR - 2020-08-25 04:07:08 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-08-25 04:07:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-25 04:07:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:07:08 --> Final output sent to browser
DEBUG - 2020-08-25 04:07:08 --> Total execution time: 0.0408
INFO - 2020-08-25 04:09:53 --> Config Class Initialized
INFO - 2020-08-25 04:09:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:09:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:09:53 --> Utf8 Class Initialized
INFO - 2020-08-25 04:09:53 --> URI Class Initialized
DEBUG - 2020-08-25 04:09:53 --> No URI present. Default controller set.
INFO - 2020-08-25 04:09:53 --> Router Class Initialized
INFO - 2020-08-25 04:09:53 --> Output Class Initialized
INFO - 2020-08-25 04:09:53 --> Security Class Initialized
DEBUG - 2020-08-25 04:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:09:53 --> Input Class Initialized
INFO - 2020-08-25 04:09:53 --> Language Class Initialized
INFO - 2020-08-25 04:09:53 --> Language Class Initialized
INFO - 2020-08-25 04:09:53 --> Config Class Initialized
INFO - 2020-08-25 04:09:53 --> Loader Class Initialized
INFO - 2020-08-25 04:09:53 --> Helper loaded: url_helper
INFO - 2020-08-25 04:09:53 --> Helper loaded: file_helper
INFO - 2020-08-25 04:09:53 --> Helper loaded: form_helper
INFO - 2020-08-25 04:09:53 --> Helper loaded: my_helper
INFO - 2020-08-25 04:09:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:09:53 --> Controller Class Initialized
INFO - 2020-08-25 04:09:53 --> Config Class Initialized
INFO - 2020-08-25 04:09:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:09:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:09:53 --> Utf8 Class Initialized
INFO - 2020-08-25 04:09:53 --> URI Class Initialized
INFO - 2020-08-25 04:09:53 --> Router Class Initialized
INFO - 2020-08-25 04:09:53 --> Output Class Initialized
INFO - 2020-08-25 04:09:53 --> Security Class Initialized
DEBUG - 2020-08-25 04:09:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:09:53 --> Input Class Initialized
INFO - 2020-08-25 04:09:53 --> Language Class Initialized
INFO - 2020-08-25 04:09:53 --> Language Class Initialized
INFO - 2020-08-25 04:09:53 --> Config Class Initialized
INFO - 2020-08-25 04:09:53 --> Loader Class Initialized
INFO - 2020-08-25 04:09:53 --> Helper loaded: url_helper
INFO - 2020-08-25 04:09:53 --> Helper loaded: file_helper
INFO - 2020-08-25 04:09:53 --> Helper loaded: form_helper
INFO - 2020-08-25 04:09:53 --> Helper loaded: my_helper
INFO - 2020-08-25 04:09:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:09:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:09:53 --> Controller Class Initialized
DEBUG - 2020-08-25 04:09:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-08-25 04:09:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:09:53 --> Final output sent to browser
DEBUG - 2020-08-25 04:09:53 --> Total execution time: 0.0973
INFO - 2020-08-25 04:10:31 --> Config Class Initialized
INFO - 2020-08-25 04:10:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:10:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:10:31 --> Utf8 Class Initialized
INFO - 2020-08-25 04:10:31 --> URI Class Initialized
INFO - 2020-08-25 04:10:31 --> Router Class Initialized
INFO - 2020-08-25 04:10:31 --> Output Class Initialized
INFO - 2020-08-25 04:10:31 --> Security Class Initialized
DEBUG - 2020-08-25 04:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:10:31 --> Input Class Initialized
INFO - 2020-08-25 04:10:31 --> Language Class Initialized
INFO - 2020-08-25 04:10:31 --> Language Class Initialized
INFO - 2020-08-25 04:10:31 --> Config Class Initialized
INFO - 2020-08-25 04:10:31 --> Loader Class Initialized
INFO - 2020-08-25 04:10:31 --> Helper loaded: url_helper
INFO - 2020-08-25 04:10:31 --> Helper loaded: file_helper
INFO - 2020-08-25 04:10:31 --> Helper loaded: form_helper
INFO - 2020-08-25 04:10:31 --> Helper loaded: my_helper
INFO - 2020-08-25 04:10:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:10:31 --> Controller Class Initialized
INFO - 2020-08-25 04:10:31 --> Upload Class Initialized
INFO - 2020-08-25 04:10:31 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-08-25 04:10:31 --> The upload path does not appear to be valid.
INFO - 2020-08-25 04:10:31 --> Config Class Initialized
INFO - 2020-08-25 04:10:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:10:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:10:31 --> Utf8 Class Initialized
INFO - 2020-08-25 04:10:31 --> URI Class Initialized
INFO - 2020-08-25 04:10:31 --> Router Class Initialized
INFO - 2020-08-25 04:10:31 --> Output Class Initialized
INFO - 2020-08-25 04:10:31 --> Security Class Initialized
DEBUG - 2020-08-25 04:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:10:31 --> Input Class Initialized
INFO - 2020-08-25 04:10:31 --> Language Class Initialized
INFO - 2020-08-25 04:10:31 --> Language Class Initialized
INFO - 2020-08-25 04:10:31 --> Config Class Initialized
INFO - 2020-08-25 04:10:31 --> Loader Class Initialized
INFO - 2020-08-25 04:10:31 --> Helper loaded: url_helper
INFO - 2020-08-25 04:10:31 --> Helper loaded: file_helper
INFO - 2020-08-25 04:10:31 --> Helper loaded: form_helper
INFO - 2020-08-25 04:10:31 --> Helper loaded: my_helper
INFO - 2020-08-25 04:10:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:10:31 --> Controller Class Initialized
DEBUG - 2020-08-25 04:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 04:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:10:31 --> Final output sent to browser
DEBUG - 2020-08-25 04:10:31 --> Total execution time: 0.0457
INFO - 2020-08-25 04:10:43 --> Config Class Initialized
INFO - 2020-08-25 04:10:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:10:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:10:43 --> Utf8 Class Initialized
INFO - 2020-08-25 04:10:43 --> URI Class Initialized
INFO - 2020-08-25 04:10:43 --> Router Class Initialized
INFO - 2020-08-25 04:10:43 --> Output Class Initialized
INFO - 2020-08-25 04:10:43 --> Security Class Initialized
DEBUG - 2020-08-25 04:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:10:43 --> Input Class Initialized
INFO - 2020-08-25 04:10:43 --> Language Class Initialized
INFO - 2020-08-25 04:10:43 --> Language Class Initialized
INFO - 2020-08-25 04:10:43 --> Config Class Initialized
INFO - 2020-08-25 04:10:43 --> Loader Class Initialized
INFO - 2020-08-25 04:10:43 --> Helper loaded: url_helper
INFO - 2020-08-25 04:10:43 --> Helper loaded: file_helper
INFO - 2020-08-25 04:10:43 --> Helper loaded: form_helper
INFO - 2020-08-25 04:10:43 --> Helper loaded: my_helper
INFO - 2020-08-25 04:10:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:10:43 --> Controller Class Initialized
INFO - 2020-08-25 04:10:59 --> Config Class Initialized
INFO - 2020-08-25 04:10:59 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:10:59 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:10:59 --> Utf8 Class Initialized
INFO - 2020-08-25 04:10:59 --> URI Class Initialized
INFO - 2020-08-25 04:10:59 --> Router Class Initialized
INFO - 2020-08-25 04:10:59 --> Output Class Initialized
INFO - 2020-08-25 04:10:59 --> Security Class Initialized
DEBUG - 2020-08-25 04:10:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:10:59 --> Input Class Initialized
INFO - 2020-08-25 04:10:59 --> Language Class Initialized
INFO - 2020-08-25 04:10:59 --> Language Class Initialized
INFO - 2020-08-25 04:10:59 --> Config Class Initialized
INFO - 2020-08-25 04:10:59 --> Loader Class Initialized
INFO - 2020-08-25 04:10:59 --> Helper loaded: url_helper
INFO - 2020-08-25 04:10:59 --> Helper loaded: file_helper
INFO - 2020-08-25 04:10:59 --> Helper loaded: form_helper
INFO - 2020-08-25 04:10:59 --> Helper loaded: my_helper
INFO - 2020-08-25 04:10:59 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:10:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:10:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:10:59 --> Controller Class Initialized
INFO - 2020-08-25 04:10:59 --> Helper loaded: cookie_helper
INFO - 2020-08-25 04:10:59 --> Final output sent to browser
DEBUG - 2020-08-25 04:10:59 --> Total execution time: 0.0497
INFO - 2020-08-25 04:11:03 --> Config Class Initialized
INFO - 2020-08-25 04:11:03 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:03 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:03 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:03 --> URI Class Initialized
INFO - 2020-08-25 04:11:03 --> Router Class Initialized
INFO - 2020-08-25 04:11:03 --> Output Class Initialized
INFO - 2020-08-25 04:11:03 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:03 --> Input Class Initialized
INFO - 2020-08-25 04:11:03 --> Language Class Initialized
INFO - 2020-08-25 04:11:03 --> Language Class Initialized
INFO - 2020-08-25 04:11:03 --> Config Class Initialized
INFO - 2020-08-25 04:11:03 --> Loader Class Initialized
INFO - 2020-08-25 04:11:03 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:03 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:03 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:03 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:03 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:03 --> Controller Class Initialized
INFO - 2020-08-25 04:11:04 --> Config Class Initialized
INFO - 2020-08-25 04:11:04 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:04 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:04 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:04 --> URI Class Initialized
INFO - 2020-08-25 04:11:04 --> Router Class Initialized
INFO - 2020-08-25 04:11:04 --> Output Class Initialized
INFO - 2020-08-25 04:11:04 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:04 --> Input Class Initialized
INFO - 2020-08-25 04:11:04 --> Language Class Initialized
INFO - 2020-08-25 04:11:04 --> Language Class Initialized
INFO - 2020-08-25 04:11:04 --> Config Class Initialized
INFO - 2020-08-25 04:11:04 --> Loader Class Initialized
INFO - 2020-08-25 04:11:04 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:04 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:04 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:04 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:04 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:04 --> Controller Class Initialized
INFO - 2020-08-25 04:11:06 --> Config Class Initialized
INFO - 2020-08-25 04:11:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:06 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:06 --> URI Class Initialized
INFO - 2020-08-25 04:11:06 --> Router Class Initialized
INFO - 2020-08-25 04:11:06 --> Output Class Initialized
INFO - 2020-08-25 04:11:06 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:06 --> Input Class Initialized
INFO - 2020-08-25 04:11:06 --> Language Class Initialized
INFO - 2020-08-25 04:11:06 --> Language Class Initialized
INFO - 2020-08-25 04:11:06 --> Config Class Initialized
INFO - 2020-08-25 04:11:06 --> Loader Class Initialized
INFO - 2020-08-25 04:11:06 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:06 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:06 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:06 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:06 --> Controller Class Initialized
DEBUG - 2020-08-25 04:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 04:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:11:06 --> Final output sent to browser
DEBUG - 2020-08-25 04:11:06 --> Total execution time: 0.5690
INFO - 2020-08-25 04:11:13 --> Config Class Initialized
INFO - 2020-08-25 04:11:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:13 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:13 --> URI Class Initialized
INFO - 2020-08-25 04:11:13 --> Router Class Initialized
INFO - 2020-08-25 04:11:13 --> Output Class Initialized
INFO - 2020-08-25 04:11:13 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:13 --> Input Class Initialized
INFO - 2020-08-25 04:11:13 --> Language Class Initialized
INFO - 2020-08-25 04:11:13 --> Language Class Initialized
INFO - 2020-08-25 04:11:13 --> Config Class Initialized
INFO - 2020-08-25 04:11:13 --> Loader Class Initialized
INFO - 2020-08-25 04:11:13 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:13 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:13 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:13 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:13 --> Controller Class Initialized
ERROR - 2020-08-25 04:11:13 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-08-25 04:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-25 04:11:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:11:13 --> Final output sent to browser
DEBUG - 2020-08-25 04:11:13 --> Total execution time: 0.0478
INFO - 2020-08-25 04:11:48 --> Config Class Initialized
INFO - 2020-08-25 04:11:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:48 --> URI Class Initialized
INFO - 2020-08-25 04:11:48 --> Router Class Initialized
INFO - 2020-08-25 04:11:48 --> Output Class Initialized
INFO - 2020-08-25 04:11:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:48 --> Input Class Initialized
INFO - 2020-08-25 04:11:48 --> Language Class Initialized
INFO - 2020-08-25 04:11:48 --> Language Class Initialized
INFO - 2020-08-25 04:11:48 --> Config Class Initialized
INFO - 2020-08-25 04:11:48 --> Loader Class Initialized
INFO - 2020-08-25 04:11:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:48 --> Controller Class Initialized
INFO - 2020-08-25 04:11:48 --> Helper loaded: cookie_helper
INFO - 2020-08-25 04:11:48 --> Final output sent to browser
DEBUG - 2020-08-25 04:11:48 --> Total execution time: 0.0412
INFO - 2020-08-25 04:11:48 --> Config Class Initialized
INFO - 2020-08-25 04:11:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:48 --> URI Class Initialized
INFO - 2020-08-25 04:11:48 --> Router Class Initialized
INFO - 2020-08-25 04:11:48 --> Output Class Initialized
INFO - 2020-08-25 04:11:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:48 --> Input Class Initialized
INFO - 2020-08-25 04:11:48 --> Language Class Initialized
INFO - 2020-08-25 04:11:48 --> Language Class Initialized
INFO - 2020-08-25 04:11:48 --> Config Class Initialized
INFO - 2020-08-25 04:11:48 --> Loader Class Initialized
INFO - 2020-08-25 04:11:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:48 --> Controller Class Initialized
DEBUG - 2020-08-25 04:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-08-25 04:11:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:11:49 --> Final output sent to browser
DEBUG - 2020-08-25 04:11:49 --> Total execution time: 0.6029
INFO - 2020-08-25 04:11:51 --> Config Class Initialized
INFO - 2020-08-25 04:11:51 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:51 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:51 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:51 --> URI Class Initialized
INFO - 2020-08-25 04:11:51 --> Router Class Initialized
INFO - 2020-08-25 04:11:51 --> Output Class Initialized
INFO - 2020-08-25 04:11:51 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:51 --> Input Class Initialized
INFO - 2020-08-25 04:11:51 --> Language Class Initialized
INFO - 2020-08-25 04:11:51 --> Language Class Initialized
INFO - 2020-08-25 04:11:51 --> Config Class Initialized
INFO - 2020-08-25 04:11:51 --> Loader Class Initialized
INFO - 2020-08-25 04:11:51 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:51 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:51 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:51 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:51 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:52 --> Controller Class Initialized
DEBUG - 2020-08-25 04:11:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2020-08-25 04:11:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:11:52 --> Final output sent to browser
DEBUG - 2020-08-25 04:11:52 --> Total execution time: 0.0583
INFO - 2020-08-25 04:11:53 --> Config Class Initialized
INFO - 2020-08-25 04:11:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:11:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:11:53 --> Utf8 Class Initialized
INFO - 2020-08-25 04:11:53 --> URI Class Initialized
INFO - 2020-08-25 04:11:53 --> Router Class Initialized
INFO - 2020-08-25 04:11:53 --> Output Class Initialized
INFO - 2020-08-25 04:11:53 --> Security Class Initialized
DEBUG - 2020-08-25 04:11:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:11:53 --> Input Class Initialized
INFO - 2020-08-25 04:11:53 --> Language Class Initialized
INFO - 2020-08-25 04:11:53 --> Language Class Initialized
INFO - 2020-08-25 04:11:53 --> Config Class Initialized
INFO - 2020-08-25 04:11:53 --> Loader Class Initialized
INFO - 2020-08-25 04:11:53 --> Helper loaded: url_helper
INFO - 2020-08-25 04:11:53 --> Helper loaded: file_helper
INFO - 2020-08-25 04:11:53 --> Helper loaded: form_helper
INFO - 2020-08-25 04:11:53 --> Helper loaded: my_helper
INFO - 2020-08-25 04:11:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:11:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:11:53 --> Controller Class Initialized
DEBUG - 2020-08-25 04:11:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tki.php
INFO - 2020-08-25 04:11:54 --> Final output sent to browser
DEBUG - 2020-08-25 04:11:54 --> Total execution time: 0.3102
INFO - 2020-08-25 04:12:08 --> Config Class Initialized
INFO - 2020-08-25 04:12:08 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:12:08 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:12:08 --> Utf8 Class Initialized
INFO - 2020-08-25 04:12:08 --> URI Class Initialized
INFO - 2020-08-25 04:12:08 --> Router Class Initialized
INFO - 2020-08-25 04:12:08 --> Output Class Initialized
INFO - 2020-08-25 04:12:08 --> Security Class Initialized
DEBUG - 2020-08-25 04:12:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:12:08 --> Input Class Initialized
INFO - 2020-08-25 04:12:08 --> Language Class Initialized
INFO - 2020-08-25 04:12:08 --> Language Class Initialized
INFO - 2020-08-25 04:12:08 --> Config Class Initialized
INFO - 2020-08-25 04:12:08 --> Loader Class Initialized
INFO - 2020-08-25 04:12:08 --> Helper loaded: url_helper
INFO - 2020-08-25 04:12:08 --> Helper loaded: file_helper
INFO - 2020-08-25 04:12:08 --> Helper loaded: form_helper
INFO - 2020-08-25 04:12:08 --> Helper loaded: my_helper
INFO - 2020-08-25 04:12:08 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:12:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:12:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:12:08 --> Controller Class Initialized
DEBUG - 2020-08-25 04:12:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-08-25 04:12:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:12:08 --> Final output sent to browser
DEBUG - 2020-08-25 04:12:08 --> Total execution time: 0.0525
INFO - 2020-08-25 04:12:51 --> Config Class Initialized
INFO - 2020-08-25 04:12:51 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:12:51 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:12:51 --> Utf8 Class Initialized
INFO - 2020-08-25 04:12:51 --> URI Class Initialized
INFO - 2020-08-25 04:12:51 --> Router Class Initialized
INFO - 2020-08-25 04:12:51 --> Output Class Initialized
INFO - 2020-08-25 04:12:51 --> Security Class Initialized
DEBUG - 2020-08-25 04:12:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:12:51 --> Input Class Initialized
INFO - 2020-08-25 04:12:51 --> Language Class Initialized
INFO - 2020-08-25 04:12:51 --> Language Class Initialized
INFO - 2020-08-25 04:12:51 --> Config Class Initialized
INFO - 2020-08-25 04:12:51 --> Loader Class Initialized
INFO - 2020-08-25 04:12:51 --> Helper loaded: url_helper
INFO - 2020-08-25 04:12:51 --> Helper loaded: file_helper
INFO - 2020-08-25 04:12:51 --> Helper loaded: form_helper
INFO - 2020-08-25 04:12:51 --> Helper loaded: my_helper
INFO - 2020-08-25 04:12:51 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:12:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:12:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:12:51 --> Controller Class Initialized
DEBUG - 2020-08-25 04:12:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-08-25 04:12:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:12:51 --> Final output sent to browser
DEBUG - 2020-08-25 04:12:51 --> Total execution time: 0.0525
INFO - 2020-08-25 04:12:53 --> Config Class Initialized
INFO - 2020-08-25 04:12:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:12:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:12:53 --> Utf8 Class Initialized
INFO - 2020-08-25 04:12:53 --> URI Class Initialized
INFO - 2020-08-25 04:12:53 --> Router Class Initialized
INFO - 2020-08-25 04:12:53 --> Output Class Initialized
INFO - 2020-08-25 04:12:53 --> Security Class Initialized
DEBUG - 2020-08-25 04:12:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:12:53 --> Input Class Initialized
INFO - 2020-08-25 04:12:53 --> Language Class Initialized
INFO - 2020-08-25 04:12:53 --> Language Class Initialized
INFO - 2020-08-25 04:12:53 --> Config Class Initialized
INFO - 2020-08-25 04:12:53 --> Loader Class Initialized
INFO - 2020-08-25 04:12:53 --> Helper loaded: url_helper
INFO - 2020-08-25 04:12:53 --> Helper loaded: file_helper
INFO - 2020-08-25 04:12:53 --> Helper loaded: form_helper
INFO - 2020-08-25 04:12:53 --> Helper loaded: my_helper
INFO - 2020-08-25 04:12:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:12:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:12:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:12:53 --> Controller Class Initialized
DEBUG - 2020-08-25 04:12:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:12:54 --> Final output sent to browser
DEBUG - 2020-08-25 04:12:54 --> Total execution time: 0.1973
INFO - 2020-08-25 04:13:32 --> Config Class Initialized
INFO - 2020-08-25 04:13:32 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:32 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:32 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:32 --> URI Class Initialized
INFO - 2020-08-25 04:13:32 --> Router Class Initialized
INFO - 2020-08-25 04:13:32 --> Output Class Initialized
INFO - 2020-08-25 04:13:32 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:32 --> Input Class Initialized
INFO - 2020-08-25 04:13:32 --> Language Class Initialized
INFO - 2020-08-25 04:13:32 --> Language Class Initialized
INFO - 2020-08-25 04:13:32 --> Config Class Initialized
INFO - 2020-08-25 04:13:32 --> Loader Class Initialized
INFO - 2020-08-25 04:13:32 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:32 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:32 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:32 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:32 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:32 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:32 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:32 --> Total execution time: 0.1923
INFO - 2020-08-25 04:13:35 --> Config Class Initialized
INFO - 2020-08-25 04:13:35 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:35 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:35 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:35 --> URI Class Initialized
INFO - 2020-08-25 04:13:35 --> Router Class Initialized
INFO - 2020-08-25 04:13:35 --> Output Class Initialized
INFO - 2020-08-25 04:13:35 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:35 --> Input Class Initialized
INFO - 2020-08-25 04:13:35 --> Language Class Initialized
INFO - 2020-08-25 04:13:35 --> Language Class Initialized
INFO - 2020-08-25 04:13:35 --> Config Class Initialized
INFO - 2020-08-25 04:13:35 --> Loader Class Initialized
INFO - 2020-08-25 04:13:35 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:35 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:35 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:35 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:35 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:35 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:35 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:35 --> Total execution time: 0.1883
INFO - 2020-08-25 04:13:37 --> Config Class Initialized
INFO - 2020-08-25 04:13:37 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:37 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:37 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:37 --> URI Class Initialized
INFO - 2020-08-25 04:13:37 --> Router Class Initialized
INFO - 2020-08-25 04:13:37 --> Output Class Initialized
INFO - 2020-08-25 04:13:37 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:37 --> Input Class Initialized
INFO - 2020-08-25 04:13:37 --> Language Class Initialized
INFO - 2020-08-25 04:13:37 --> Language Class Initialized
INFO - 2020-08-25 04:13:37 --> Config Class Initialized
INFO - 2020-08-25 04:13:37 --> Loader Class Initialized
INFO - 2020-08-25 04:13:37 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:37 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:37 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:37 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:37 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:37 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:37 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:37 --> Total execution time: 0.1838
INFO - 2020-08-25 04:13:39 --> Config Class Initialized
INFO - 2020-08-25 04:13:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:39 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:39 --> URI Class Initialized
INFO - 2020-08-25 04:13:39 --> Router Class Initialized
INFO - 2020-08-25 04:13:39 --> Output Class Initialized
INFO - 2020-08-25 04:13:39 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:39 --> Input Class Initialized
INFO - 2020-08-25 04:13:39 --> Language Class Initialized
INFO - 2020-08-25 04:13:39 --> Language Class Initialized
INFO - 2020-08-25 04:13:39 --> Config Class Initialized
INFO - 2020-08-25 04:13:39 --> Loader Class Initialized
INFO - 2020-08-25 04:13:39 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:39 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:39 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:39 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:39 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:39 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:39 --> Total execution time: 0.1858
INFO - 2020-08-25 04:13:40 --> Config Class Initialized
INFO - 2020-08-25 04:13:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:40 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:40 --> URI Class Initialized
INFO - 2020-08-25 04:13:40 --> Router Class Initialized
INFO - 2020-08-25 04:13:40 --> Output Class Initialized
INFO - 2020-08-25 04:13:40 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:40 --> Input Class Initialized
INFO - 2020-08-25 04:13:40 --> Language Class Initialized
INFO - 2020-08-25 04:13:40 --> Language Class Initialized
INFO - 2020-08-25 04:13:40 --> Config Class Initialized
INFO - 2020-08-25 04:13:40 --> Loader Class Initialized
INFO - 2020-08-25 04:13:40 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:40 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:40 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:40 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:40 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:40 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:40 --> Total execution time: 0.1833
INFO - 2020-08-25 04:13:43 --> Config Class Initialized
INFO - 2020-08-25 04:13:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:43 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:43 --> URI Class Initialized
INFO - 2020-08-25 04:13:43 --> Router Class Initialized
INFO - 2020-08-25 04:13:43 --> Output Class Initialized
INFO - 2020-08-25 04:13:43 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:43 --> Input Class Initialized
INFO - 2020-08-25 04:13:43 --> Language Class Initialized
INFO - 2020-08-25 04:13:43 --> Language Class Initialized
INFO - 2020-08-25 04:13:43 --> Config Class Initialized
INFO - 2020-08-25 04:13:43 --> Loader Class Initialized
INFO - 2020-08-25 04:13:43 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:43 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:43 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:43 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:43 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:43 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:43 --> Total execution time: 0.1856
INFO - 2020-08-25 04:13:45 --> Config Class Initialized
INFO - 2020-08-25 04:13:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:45 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:45 --> URI Class Initialized
INFO - 2020-08-25 04:13:45 --> Router Class Initialized
INFO - 2020-08-25 04:13:45 --> Output Class Initialized
INFO - 2020-08-25 04:13:45 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:45 --> Input Class Initialized
INFO - 2020-08-25 04:13:45 --> Language Class Initialized
INFO - 2020-08-25 04:13:45 --> Language Class Initialized
INFO - 2020-08-25 04:13:45 --> Config Class Initialized
INFO - 2020-08-25 04:13:45 --> Loader Class Initialized
INFO - 2020-08-25 04:13:45 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:45 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:45 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:45 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:45 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:45 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:45 --> Total execution time: 0.1923
INFO - 2020-08-25 04:13:46 --> Config Class Initialized
INFO - 2020-08-25 04:13:46 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:46 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:46 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:46 --> URI Class Initialized
INFO - 2020-08-25 04:13:46 --> Router Class Initialized
INFO - 2020-08-25 04:13:46 --> Output Class Initialized
INFO - 2020-08-25 04:13:46 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:46 --> Input Class Initialized
INFO - 2020-08-25 04:13:46 --> Language Class Initialized
INFO - 2020-08-25 04:13:46 --> Language Class Initialized
INFO - 2020-08-25 04:13:46 --> Config Class Initialized
INFO - 2020-08-25 04:13:46 --> Loader Class Initialized
INFO - 2020-08-25 04:13:46 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:46 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:46 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:46 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:46 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:46 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:46 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:46 --> Total execution time: 0.1885
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:48 --> URI Class Initialized
INFO - 2020-08-25 04:13:48 --> Router Class Initialized
INFO - 2020-08-25 04:13:48 --> Output Class Initialized
INFO - 2020-08-25 04:13:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:48 --> Input Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Loader Class Initialized
INFO - 2020-08-25 04:13:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:48 --> Controller Class Initialized
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:48 --> URI Class Initialized
INFO - 2020-08-25 04:13:48 --> Router Class Initialized
INFO - 2020-08-25 04:13:48 --> Output Class Initialized
INFO - 2020-08-25 04:13:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:48 --> Input Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Loader Class Initialized
INFO - 2020-08-25 04:13:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:48 --> Controller Class Initialized
INFO - 2020-08-25 04:13:48 --> Upload Class Initialized
INFO - 2020-08-25 04:13:48 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-08-25 04:13:48 --> The upload path does not appear to be valid.
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:48 --> URI Class Initialized
INFO - 2020-08-25 04:13:48 --> Router Class Initialized
INFO - 2020-08-25 04:13:48 --> Output Class Initialized
INFO - 2020-08-25 04:13:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:48 --> Input Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Loader Class Initialized
INFO - 2020-08-25 04:13:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:48 --> Controller Class Initialized
INFO - 2020-08-25 04:13:48 --> Upload Class Initialized
INFO - 2020-08-25 04:13:48 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-08-25 04:13:48 --> The upload path does not appear to be valid.
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:48 --> URI Class Initialized
DEBUG - 2020-08-25 04:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:48 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:48 --> Total execution time: 0.1883
INFO - 2020-08-25 04:13:48 --> Router Class Initialized
INFO - 2020-08-25 04:13:48 --> Output Class Initialized
INFO - 2020-08-25 04:13:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:48 --> Input Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Language Class Initialized
INFO - 2020-08-25 04:13:48 --> Config Class Initialized
INFO - 2020-08-25 04:13:48 --> Loader Class Initialized
INFO - 2020-08-25 04:13:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:48 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-08-25 04:13:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:13:48 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:48 --> Total execution time: 0.0644
INFO - 2020-08-25 04:13:49 --> Config Class Initialized
INFO - 2020-08-25 04:13:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:49 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:49 --> URI Class Initialized
INFO - 2020-08-25 04:13:49 --> Router Class Initialized
INFO - 2020-08-25 04:13:49 --> Output Class Initialized
INFO - 2020-08-25 04:13:49 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:49 --> Input Class Initialized
INFO - 2020-08-25 04:13:49 --> Language Class Initialized
INFO - 2020-08-25 04:13:49 --> Language Class Initialized
INFO - 2020-08-25 04:13:49 --> Config Class Initialized
INFO - 2020-08-25 04:13:49 --> Loader Class Initialized
INFO - 2020-08-25 04:13:49 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:49 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:49 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:49 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:49 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:50 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:50 --> Total execution time: 0.2943
INFO - 2020-08-25 04:13:51 --> Config Class Initialized
INFO - 2020-08-25 04:13:51 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:51 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:51 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:51 --> URI Class Initialized
INFO - 2020-08-25 04:13:51 --> Router Class Initialized
INFO - 2020-08-25 04:13:51 --> Output Class Initialized
INFO - 2020-08-25 04:13:51 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:51 --> Input Class Initialized
INFO - 2020-08-25 04:13:51 --> Language Class Initialized
INFO - 2020-08-25 04:13:51 --> Language Class Initialized
INFO - 2020-08-25 04:13:51 --> Config Class Initialized
INFO - 2020-08-25 04:13:51 --> Loader Class Initialized
INFO - 2020-08-25 04:13:51 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:51 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:51 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:51 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:51 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:51 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:51 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:51 --> Total execution time: 0.1856
INFO - 2020-08-25 04:13:53 --> Config Class Initialized
INFO - 2020-08-25 04:13:53 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:53 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:53 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:53 --> URI Class Initialized
INFO - 2020-08-25 04:13:53 --> Router Class Initialized
INFO - 2020-08-25 04:13:53 --> Output Class Initialized
INFO - 2020-08-25 04:13:53 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:53 --> Input Class Initialized
INFO - 2020-08-25 04:13:53 --> Language Class Initialized
INFO - 2020-08-25 04:13:53 --> Language Class Initialized
INFO - 2020-08-25 04:13:53 --> Config Class Initialized
INFO - 2020-08-25 04:13:53 --> Loader Class Initialized
INFO - 2020-08-25 04:13:53 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:53 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:53 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:53 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:53 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:53 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:53 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:53 --> Total execution time: 0.1987
INFO - 2020-08-25 04:13:54 --> Config Class Initialized
INFO - 2020-08-25 04:13:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:54 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:54 --> URI Class Initialized
INFO - 2020-08-25 04:13:54 --> Router Class Initialized
INFO - 2020-08-25 04:13:54 --> Output Class Initialized
INFO - 2020-08-25 04:13:54 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:54 --> Input Class Initialized
INFO - 2020-08-25 04:13:54 --> Language Class Initialized
INFO - 2020-08-25 04:13:55 --> Language Class Initialized
INFO - 2020-08-25 04:13:55 --> Config Class Initialized
INFO - 2020-08-25 04:13:55 --> Loader Class Initialized
INFO - 2020-08-25 04:13:55 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:55 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:55 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:55 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:55 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:55 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:55 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:55 --> Total execution time: 0.2126
INFO - 2020-08-25 04:13:56 --> Config Class Initialized
INFO - 2020-08-25 04:13:56 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:56 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:56 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:56 --> URI Class Initialized
INFO - 2020-08-25 04:13:56 --> Router Class Initialized
INFO - 2020-08-25 04:13:56 --> Output Class Initialized
INFO - 2020-08-25 04:13:56 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:56 --> Input Class Initialized
INFO - 2020-08-25 04:13:56 --> Language Class Initialized
INFO - 2020-08-25 04:13:56 --> Language Class Initialized
INFO - 2020-08-25 04:13:56 --> Config Class Initialized
INFO - 2020-08-25 04:13:56 --> Loader Class Initialized
INFO - 2020-08-25 04:13:56 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:56 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:56 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:56 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:56 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:56 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:56 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:56 --> Total execution time: 0.1865
INFO - 2020-08-25 04:13:58 --> Config Class Initialized
INFO - 2020-08-25 04:13:58 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:13:58 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:13:58 --> Utf8 Class Initialized
INFO - 2020-08-25 04:13:58 --> URI Class Initialized
INFO - 2020-08-25 04:13:58 --> Router Class Initialized
INFO - 2020-08-25 04:13:58 --> Output Class Initialized
INFO - 2020-08-25 04:13:58 --> Security Class Initialized
DEBUG - 2020-08-25 04:13:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:13:58 --> Input Class Initialized
INFO - 2020-08-25 04:13:58 --> Language Class Initialized
INFO - 2020-08-25 04:13:58 --> Language Class Initialized
INFO - 2020-08-25 04:13:58 --> Config Class Initialized
INFO - 2020-08-25 04:13:58 --> Loader Class Initialized
INFO - 2020-08-25 04:13:58 --> Helper loaded: url_helper
INFO - 2020-08-25 04:13:58 --> Helper loaded: file_helper
INFO - 2020-08-25 04:13:58 --> Helper loaded: form_helper
INFO - 2020-08-25 04:13:58 --> Helper loaded: my_helper
INFO - 2020-08-25 04:13:58 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:13:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:13:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:13:58 --> Controller Class Initialized
DEBUG - 2020-08-25 04:13:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:13:59 --> Final output sent to browser
DEBUG - 2020-08-25 04:13:59 --> Total execution time: 0.2483
INFO - 2020-08-25 04:14:00 --> Config Class Initialized
INFO - 2020-08-25 04:14:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:00 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:00 --> URI Class Initialized
INFO - 2020-08-25 04:14:00 --> Router Class Initialized
INFO - 2020-08-25 04:14:00 --> Output Class Initialized
INFO - 2020-08-25 04:14:00 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:00 --> Input Class Initialized
INFO - 2020-08-25 04:14:00 --> Language Class Initialized
INFO - 2020-08-25 04:14:00 --> Language Class Initialized
INFO - 2020-08-25 04:14:00 --> Config Class Initialized
INFO - 2020-08-25 04:14:00 --> Loader Class Initialized
INFO - 2020-08-25 04:14:00 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:00 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:00 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:00 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:00 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:00 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:00 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:00 --> Total execution time: 0.1929
INFO - 2020-08-25 04:14:00 --> Config Class Initialized
INFO - 2020-08-25 04:14:00 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:00 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:00 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:00 --> URI Class Initialized
INFO - 2020-08-25 04:14:00 --> Router Class Initialized
INFO - 2020-08-25 04:14:00 --> Output Class Initialized
INFO - 2020-08-25 04:14:00 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:00 --> Input Class Initialized
INFO - 2020-08-25 04:14:00 --> Language Class Initialized
INFO - 2020-08-25 04:14:00 --> Language Class Initialized
INFO - 2020-08-25 04:14:00 --> Config Class Initialized
INFO - 2020-08-25 04:14:00 --> Loader Class Initialized
INFO - 2020-08-25 04:14:00 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:00 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:00 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:00 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:00 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:00 --> Controller Class Initialized
INFO - 2020-08-25 04:14:01 --> Config Class Initialized
INFO - 2020-08-25 04:14:01 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:01 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:01 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:01 --> URI Class Initialized
INFO - 2020-08-25 04:14:01 --> Router Class Initialized
INFO - 2020-08-25 04:14:01 --> Output Class Initialized
INFO - 2020-08-25 04:14:01 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:01 --> Input Class Initialized
INFO - 2020-08-25 04:14:01 --> Language Class Initialized
INFO - 2020-08-25 04:14:01 --> Language Class Initialized
INFO - 2020-08-25 04:14:01 --> Config Class Initialized
INFO - 2020-08-25 04:14:01 --> Loader Class Initialized
INFO - 2020-08-25 04:14:01 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:01 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:01 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:01 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:01 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:01 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:01 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:01 --> Total execution time: 0.1960
INFO - 2020-08-25 04:14:04 --> Config Class Initialized
INFO - 2020-08-25 04:14:04 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:04 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:04 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:04 --> URI Class Initialized
INFO - 2020-08-25 04:14:04 --> Router Class Initialized
INFO - 2020-08-25 04:14:04 --> Output Class Initialized
INFO - 2020-08-25 04:14:04 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:04 --> Input Class Initialized
INFO - 2020-08-25 04:14:04 --> Language Class Initialized
INFO - 2020-08-25 04:14:04 --> Language Class Initialized
INFO - 2020-08-25 04:14:04 --> Config Class Initialized
INFO - 2020-08-25 04:14:04 --> Loader Class Initialized
INFO - 2020-08-25 04:14:04 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:04 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:04 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:04 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:04 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:04 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:04 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:04 --> Total execution time: 0.1977
INFO - 2020-08-25 04:14:05 --> Config Class Initialized
INFO - 2020-08-25 04:14:05 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:05 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:05 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:05 --> URI Class Initialized
INFO - 2020-08-25 04:14:05 --> Router Class Initialized
INFO - 2020-08-25 04:14:05 --> Output Class Initialized
INFO - 2020-08-25 04:14:05 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:05 --> Input Class Initialized
INFO - 2020-08-25 04:14:05 --> Language Class Initialized
INFO - 2020-08-25 04:14:05 --> Language Class Initialized
INFO - 2020-08-25 04:14:05 --> Config Class Initialized
INFO - 2020-08-25 04:14:05 --> Loader Class Initialized
INFO - 2020-08-25 04:14:05 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:05 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:05 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:05 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:05 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:05 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:05 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:05 --> Total execution time: 0.1889
INFO - 2020-08-25 04:14:06 --> Config Class Initialized
INFO - 2020-08-25 04:14:06 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:06 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:06 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:06 --> URI Class Initialized
INFO - 2020-08-25 04:14:06 --> Router Class Initialized
INFO - 2020-08-25 04:14:06 --> Output Class Initialized
INFO - 2020-08-25 04:14:06 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:06 --> Input Class Initialized
INFO - 2020-08-25 04:14:06 --> Language Class Initialized
INFO - 2020-08-25 04:14:06 --> Language Class Initialized
INFO - 2020-08-25 04:14:06 --> Config Class Initialized
INFO - 2020-08-25 04:14:06 --> Loader Class Initialized
INFO - 2020-08-25 04:14:06 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:06 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:06 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:06 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:06 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:06 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:07 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:07 --> Total execution time: 0.2122
INFO - 2020-08-25 04:14:09 --> Config Class Initialized
INFO - 2020-08-25 04:14:09 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:09 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:09 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:09 --> URI Class Initialized
INFO - 2020-08-25 04:14:09 --> Router Class Initialized
INFO - 2020-08-25 04:14:09 --> Output Class Initialized
INFO - 2020-08-25 04:14:09 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:09 --> Input Class Initialized
INFO - 2020-08-25 04:14:09 --> Language Class Initialized
INFO - 2020-08-25 04:14:09 --> Language Class Initialized
INFO - 2020-08-25 04:14:09 --> Config Class Initialized
INFO - 2020-08-25 04:14:09 --> Loader Class Initialized
INFO - 2020-08-25 04:14:09 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:09 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:09 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:09 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:09 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:09 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:09 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:09 --> Total execution time: 0.1996
INFO - 2020-08-25 04:14:10 --> Config Class Initialized
INFO - 2020-08-25 04:14:10 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:10 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:10 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:10 --> URI Class Initialized
INFO - 2020-08-25 04:14:10 --> Router Class Initialized
INFO - 2020-08-25 04:14:10 --> Output Class Initialized
INFO - 2020-08-25 04:14:10 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:10 --> Input Class Initialized
INFO - 2020-08-25 04:14:10 --> Language Class Initialized
INFO - 2020-08-25 04:14:10 --> Language Class Initialized
INFO - 2020-08-25 04:14:10 --> Config Class Initialized
INFO - 2020-08-25 04:14:10 --> Loader Class Initialized
INFO - 2020-08-25 04:14:10 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:10 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:10 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:10 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:10 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:10 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:11 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:11 --> Total execution time: 0.2634
INFO - 2020-08-25 04:14:11 --> Config Class Initialized
INFO - 2020-08-25 04:14:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:11 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:11 --> URI Class Initialized
INFO - 2020-08-25 04:14:11 --> Router Class Initialized
INFO - 2020-08-25 04:14:11 --> Output Class Initialized
INFO - 2020-08-25 04:14:11 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:11 --> Input Class Initialized
INFO - 2020-08-25 04:14:11 --> Language Class Initialized
INFO - 2020-08-25 04:14:11 --> Language Class Initialized
INFO - 2020-08-25 04:14:11 --> Config Class Initialized
INFO - 2020-08-25 04:14:11 --> Loader Class Initialized
INFO - 2020-08-25 04:14:11 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:11 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:11 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:11 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:11 --> Controller Class Initialized
INFO - 2020-08-25 04:14:11 --> Config Class Initialized
INFO - 2020-08-25 04:14:11 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:11 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:11 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:11 --> URI Class Initialized
INFO - 2020-08-25 04:14:11 --> Router Class Initialized
INFO - 2020-08-25 04:14:11 --> Output Class Initialized
INFO - 2020-08-25 04:14:11 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:11 --> Input Class Initialized
INFO - 2020-08-25 04:14:11 --> Language Class Initialized
INFO - 2020-08-25 04:14:11 --> Language Class Initialized
INFO - 2020-08-25 04:14:11 --> Config Class Initialized
INFO - 2020-08-25 04:14:11 --> Loader Class Initialized
INFO - 2020-08-25 04:14:11 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:11 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:11 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:11 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:11 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:11 --> Controller Class Initialized
INFO - 2020-08-25 04:14:12 --> Config Class Initialized
INFO - 2020-08-25 04:14:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:12 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:12 --> URI Class Initialized
INFO - 2020-08-25 04:14:12 --> Router Class Initialized
INFO - 2020-08-25 04:14:12 --> Output Class Initialized
INFO - 2020-08-25 04:14:12 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:12 --> Input Class Initialized
INFO - 2020-08-25 04:14:12 --> Language Class Initialized
INFO - 2020-08-25 04:14:12 --> Language Class Initialized
INFO - 2020-08-25 04:14:12 --> Config Class Initialized
INFO - 2020-08-25 04:14:12 --> Loader Class Initialized
INFO - 2020-08-25 04:14:12 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:12 --> Controller Class Initialized
INFO - 2020-08-25 04:14:12 --> Config Class Initialized
INFO - 2020-08-25 04:14:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:12 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:12 --> URI Class Initialized
INFO - 2020-08-25 04:14:12 --> Router Class Initialized
INFO - 2020-08-25 04:14:12 --> Output Class Initialized
INFO - 2020-08-25 04:14:12 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:12 --> Input Class Initialized
INFO - 2020-08-25 04:14:12 --> Language Class Initialized
INFO - 2020-08-25 04:14:12 --> Language Class Initialized
INFO - 2020-08-25 04:14:12 --> Config Class Initialized
INFO - 2020-08-25 04:14:12 --> Loader Class Initialized
INFO - 2020-08-25 04:14:12 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:12 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:12 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:12 --> Total execution time: 0.1950
INFO - 2020-08-25 04:14:12 --> Config Class Initialized
INFO - 2020-08-25 04:14:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:12 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:12 --> URI Class Initialized
INFO - 2020-08-25 04:14:12 --> Router Class Initialized
INFO - 2020-08-25 04:14:12 --> Output Class Initialized
INFO - 2020-08-25 04:14:12 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:12 --> Input Class Initialized
INFO - 2020-08-25 04:14:12 --> Language Class Initialized
INFO - 2020-08-25 04:14:12 --> Language Class Initialized
INFO - 2020-08-25 04:14:12 --> Config Class Initialized
INFO - 2020-08-25 04:14:12 --> Loader Class Initialized
INFO - 2020-08-25 04:14:12 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:12 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:12 --> Controller Class Initialized
INFO - 2020-08-25 04:14:13 --> Config Class Initialized
INFO - 2020-08-25 04:14:13 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:13 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:13 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:13 --> URI Class Initialized
INFO - 2020-08-25 04:14:13 --> Router Class Initialized
INFO - 2020-08-25 04:14:13 --> Output Class Initialized
INFO - 2020-08-25 04:14:13 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:13 --> Input Class Initialized
INFO - 2020-08-25 04:14:13 --> Language Class Initialized
INFO - 2020-08-25 04:14:13 --> Language Class Initialized
INFO - 2020-08-25 04:14:13 --> Config Class Initialized
INFO - 2020-08-25 04:14:13 --> Loader Class Initialized
INFO - 2020-08-25 04:14:13 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:13 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:13 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:13 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:13 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:13 --> Controller Class Initialized
INFO - 2020-08-25 04:14:14 --> Config Class Initialized
INFO - 2020-08-25 04:14:14 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:14 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:14 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:14 --> URI Class Initialized
INFO - 2020-08-25 04:14:14 --> Router Class Initialized
INFO - 2020-08-25 04:14:14 --> Output Class Initialized
INFO - 2020-08-25 04:14:14 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:14 --> Input Class Initialized
INFO - 2020-08-25 04:14:14 --> Language Class Initialized
INFO - 2020-08-25 04:14:14 --> Language Class Initialized
INFO - 2020-08-25 04:14:14 --> Config Class Initialized
INFO - 2020-08-25 04:14:14 --> Loader Class Initialized
INFO - 2020-08-25 04:14:14 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:14 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:14 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:14 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:14 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:14 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:14 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:14 --> Total execution time: 0.1959
INFO - 2020-08-25 04:14:15 --> Config Class Initialized
INFO - 2020-08-25 04:14:15 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:15 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:15 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:15 --> URI Class Initialized
INFO - 2020-08-25 04:14:15 --> Router Class Initialized
INFO - 2020-08-25 04:14:15 --> Output Class Initialized
INFO - 2020-08-25 04:14:15 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:15 --> Input Class Initialized
INFO - 2020-08-25 04:14:15 --> Language Class Initialized
INFO - 2020-08-25 04:14:15 --> Language Class Initialized
INFO - 2020-08-25 04:14:15 --> Config Class Initialized
INFO - 2020-08-25 04:14:15 --> Loader Class Initialized
INFO - 2020-08-25 04:14:15 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:15 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:15 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:15 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:15 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:15 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:15 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:15 --> Total execution time: 0.1898
INFO - 2020-08-25 04:14:18 --> Config Class Initialized
INFO - 2020-08-25 04:14:18 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:18 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:18 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:18 --> URI Class Initialized
INFO - 2020-08-25 04:14:18 --> Router Class Initialized
INFO - 2020-08-25 04:14:18 --> Output Class Initialized
INFO - 2020-08-25 04:14:18 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:18 --> Input Class Initialized
INFO - 2020-08-25 04:14:18 --> Language Class Initialized
INFO - 2020-08-25 04:14:18 --> Language Class Initialized
INFO - 2020-08-25 04:14:18 --> Config Class Initialized
INFO - 2020-08-25 04:14:18 --> Loader Class Initialized
INFO - 2020-08-25 04:14:18 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:18 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:18 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:18 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:18 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:18 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:18 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:18 --> Total execution time: 0.1964
INFO - 2020-08-25 04:14:19 --> Config Class Initialized
INFO - 2020-08-25 04:14:19 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:19 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:19 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:19 --> URI Class Initialized
INFO - 2020-08-25 04:14:19 --> Router Class Initialized
INFO - 2020-08-25 04:14:19 --> Output Class Initialized
INFO - 2020-08-25 04:14:19 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:19 --> Input Class Initialized
INFO - 2020-08-25 04:14:19 --> Language Class Initialized
INFO - 2020-08-25 04:14:19 --> Language Class Initialized
INFO - 2020-08-25 04:14:19 --> Config Class Initialized
INFO - 2020-08-25 04:14:19 --> Loader Class Initialized
INFO - 2020-08-25 04:14:19 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:19 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:19 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:19 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:19 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:19 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:19 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:19 --> Total execution time: 0.1904
INFO - 2020-08-25 04:14:20 --> Config Class Initialized
INFO - 2020-08-25 04:14:20 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:20 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:20 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:20 --> URI Class Initialized
INFO - 2020-08-25 04:14:20 --> Router Class Initialized
INFO - 2020-08-25 04:14:20 --> Output Class Initialized
INFO - 2020-08-25 04:14:20 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:20 --> Input Class Initialized
INFO - 2020-08-25 04:14:20 --> Language Class Initialized
INFO - 2020-08-25 04:14:20 --> Language Class Initialized
INFO - 2020-08-25 04:14:20 --> Config Class Initialized
INFO - 2020-08-25 04:14:20 --> Loader Class Initialized
INFO - 2020-08-25 04:14:20 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:20 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:20 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:20 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:20 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:20 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:20 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:20 --> Total execution time: 0.1875
INFO - 2020-08-25 04:14:22 --> Config Class Initialized
INFO - 2020-08-25 04:14:22 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:22 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:22 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:22 --> URI Class Initialized
INFO - 2020-08-25 04:14:22 --> Router Class Initialized
INFO - 2020-08-25 04:14:22 --> Output Class Initialized
INFO - 2020-08-25 04:14:22 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:22 --> Input Class Initialized
INFO - 2020-08-25 04:14:22 --> Language Class Initialized
INFO - 2020-08-25 04:14:22 --> Language Class Initialized
INFO - 2020-08-25 04:14:22 --> Config Class Initialized
INFO - 2020-08-25 04:14:22 --> Loader Class Initialized
INFO - 2020-08-25 04:14:22 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:22 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:22 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:22 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:22 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:22 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:22 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:22 --> Total execution time: 0.1900
INFO - 2020-08-25 04:14:24 --> Config Class Initialized
INFO - 2020-08-25 04:14:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:24 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:24 --> URI Class Initialized
INFO - 2020-08-25 04:14:24 --> Router Class Initialized
INFO - 2020-08-25 04:14:24 --> Output Class Initialized
INFO - 2020-08-25 04:14:24 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:24 --> Input Class Initialized
INFO - 2020-08-25 04:14:24 --> Language Class Initialized
INFO - 2020-08-25 04:14:24 --> Language Class Initialized
INFO - 2020-08-25 04:14:24 --> Config Class Initialized
INFO - 2020-08-25 04:14:24 --> Loader Class Initialized
INFO - 2020-08-25 04:14:24 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:24 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:24 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:24 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:24 --> Controller Class Initialized
DEBUG - 2020-08-25 04:14:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tki.php
INFO - 2020-08-25 04:14:24 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:24 --> Total execution time: 0.1955
INFO - 2020-08-25 04:14:38 --> Config Class Initialized
INFO - 2020-08-25 04:14:38 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:38 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:38 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:38 --> URI Class Initialized
INFO - 2020-08-25 04:14:38 --> Router Class Initialized
INFO - 2020-08-25 04:14:38 --> Output Class Initialized
INFO - 2020-08-25 04:14:38 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:38 --> Input Class Initialized
INFO - 2020-08-25 04:14:38 --> Language Class Initialized
INFO - 2020-08-25 04:14:38 --> Language Class Initialized
INFO - 2020-08-25 04:14:38 --> Config Class Initialized
INFO - 2020-08-25 04:14:38 --> Loader Class Initialized
INFO - 2020-08-25 04:14:38 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:38 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:38 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:38 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:39 --> Controller Class Initialized
INFO - 2020-08-25 04:14:39 --> Config Class Initialized
INFO - 2020-08-25 04:14:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:39 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:39 --> URI Class Initialized
INFO - 2020-08-25 04:14:39 --> Router Class Initialized
INFO - 2020-08-25 04:14:39 --> Output Class Initialized
INFO - 2020-08-25 04:14:39 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:39 --> Input Class Initialized
INFO - 2020-08-25 04:14:39 --> Language Class Initialized
INFO - 2020-08-25 04:14:39 --> Language Class Initialized
INFO - 2020-08-25 04:14:39 --> Config Class Initialized
INFO - 2020-08-25 04:14:39 --> Loader Class Initialized
INFO - 2020-08-25 04:14:39 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:39 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:39 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:39 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:39 --> Controller Class Initialized
INFO - 2020-08-25 04:14:39 --> Config Class Initialized
INFO - 2020-08-25 04:14:39 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:39 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:39 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:39 --> URI Class Initialized
INFO - 2020-08-25 04:14:39 --> Router Class Initialized
INFO - 2020-08-25 04:14:39 --> Output Class Initialized
INFO - 2020-08-25 04:14:39 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:39 --> Input Class Initialized
INFO - 2020-08-25 04:14:39 --> Language Class Initialized
INFO - 2020-08-25 04:14:39 --> Language Class Initialized
INFO - 2020-08-25 04:14:39 --> Config Class Initialized
INFO - 2020-08-25 04:14:39 --> Loader Class Initialized
INFO - 2020-08-25 04:14:39 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:39 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:39 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:39 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:39 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:39 --> Controller Class Initialized
INFO - 2020-08-25 04:14:40 --> Config Class Initialized
INFO - 2020-08-25 04:14:40 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:40 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:40 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:40 --> URI Class Initialized
INFO - 2020-08-25 04:14:40 --> Router Class Initialized
INFO - 2020-08-25 04:14:40 --> Output Class Initialized
INFO - 2020-08-25 04:14:40 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:40 --> Input Class Initialized
INFO - 2020-08-25 04:14:40 --> Language Class Initialized
INFO - 2020-08-25 04:14:40 --> Language Class Initialized
INFO - 2020-08-25 04:14:40 --> Config Class Initialized
INFO - 2020-08-25 04:14:40 --> Loader Class Initialized
INFO - 2020-08-25 04:14:40 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:40 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:40 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:40 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:40 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:40 --> Controller Class Initialized
INFO - 2020-08-25 04:14:41 --> Config Class Initialized
INFO - 2020-08-25 04:14:41 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:41 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:41 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:41 --> URI Class Initialized
INFO - 2020-08-25 04:14:41 --> Router Class Initialized
INFO - 2020-08-25 04:14:41 --> Output Class Initialized
INFO - 2020-08-25 04:14:41 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:41 --> Input Class Initialized
INFO - 2020-08-25 04:14:41 --> Language Class Initialized
INFO - 2020-08-25 04:14:41 --> Language Class Initialized
INFO - 2020-08-25 04:14:41 --> Config Class Initialized
INFO - 2020-08-25 04:14:41 --> Loader Class Initialized
INFO - 2020-08-25 04:14:41 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:41 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:41 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:41 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:41 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:41 --> Controller Class Initialized
INFO - 2020-08-25 04:14:43 --> Config Class Initialized
INFO - 2020-08-25 04:14:43 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:43 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:43 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:43 --> URI Class Initialized
INFO - 2020-08-25 04:14:43 --> Router Class Initialized
INFO - 2020-08-25 04:14:43 --> Output Class Initialized
INFO - 2020-08-25 04:14:43 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:43 --> Input Class Initialized
INFO - 2020-08-25 04:14:43 --> Language Class Initialized
INFO - 2020-08-25 04:14:43 --> Language Class Initialized
INFO - 2020-08-25 04:14:43 --> Config Class Initialized
INFO - 2020-08-25 04:14:43 --> Loader Class Initialized
INFO - 2020-08-25 04:14:43 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:43 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:43 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:43 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:43 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:43 --> Controller Class Initialized
INFO - 2020-08-25 04:14:45 --> Config Class Initialized
INFO - 2020-08-25 04:14:45 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:45 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:45 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:45 --> URI Class Initialized
INFO - 2020-08-25 04:14:45 --> Router Class Initialized
INFO - 2020-08-25 04:14:45 --> Output Class Initialized
INFO - 2020-08-25 04:14:45 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:45 --> Input Class Initialized
INFO - 2020-08-25 04:14:45 --> Language Class Initialized
INFO - 2020-08-25 04:14:45 --> Language Class Initialized
INFO - 2020-08-25 04:14:45 --> Config Class Initialized
INFO - 2020-08-25 04:14:45 --> Loader Class Initialized
INFO - 2020-08-25 04:14:45 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:45 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:45 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:45 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:45 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:45 --> Controller Class Initialized
INFO - 2020-08-25 04:14:47 --> Config Class Initialized
INFO - 2020-08-25 04:14:47 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:47 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:47 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:47 --> URI Class Initialized
INFO - 2020-08-25 04:14:47 --> Router Class Initialized
INFO - 2020-08-25 04:14:47 --> Output Class Initialized
INFO - 2020-08-25 04:14:47 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:47 --> Input Class Initialized
INFO - 2020-08-25 04:14:47 --> Language Class Initialized
INFO - 2020-08-25 04:14:47 --> Language Class Initialized
INFO - 2020-08-25 04:14:47 --> Config Class Initialized
INFO - 2020-08-25 04:14:47 --> Loader Class Initialized
INFO - 2020-08-25 04:14:47 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:47 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:47 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:47 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:47 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:47 --> Controller Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:48 --> URI Class Initialized
INFO - 2020-08-25 04:14:48 --> Router Class Initialized
INFO - 2020-08-25 04:14:48 --> Output Class Initialized
INFO - 2020-08-25 04:14:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:48 --> Input Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Loader Class Initialized
INFO - 2020-08-25 04:14:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:48 --> Controller Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:48 --> URI Class Initialized
INFO - 2020-08-25 04:14:48 --> Router Class Initialized
INFO - 2020-08-25 04:14:48 --> Output Class Initialized
INFO - 2020-08-25 04:14:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:48 --> Input Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Loader Class Initialized
INFO - 2020-08-25 04:14:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:48 --> Controller Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:48 --> URI Class Initialized
INFO - 2020-08-25 04:14:48 --> Router Class Initialized
INFO - 2020-08-25 04:14:48 --> Output Class Initialized
INFO - 2020-08-25 04:14:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:48 --> Input Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Loader Class Initialized
INFO - 2020-08-25 04:14:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:48 --> Controller Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:48 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:48 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:48 --> URI Class Initialized
INFO - 2020-08-25 04:14:48 --> Router Class Initialized
INFO - 2020-08-25 04:14:48 --> Output Class Initialized
INFO - 2020-08-25 04:14:48 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:48 --> Input Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Language Class Initialized
INFO - 2020-08-25 04:14:48 --> Config Class Initialized
INFO - 2020-08-25 04:14:48 --> Loader Class Initialized
INFO - 2020-08-25 04:14:48 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:48 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:48 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:48 --> Controller Class Initialized
INFO - 2020-08-25 04:14:49 --> Config Class Initialized
INFO - 2020-08-25 04:14:49 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:49 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:49 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:49 --> URI Class Initialized
INFO - 2020-08-25 04:14:49 --> Router Class Initialized
INFO - 2020-08-25 04:14:49 --> Output Class Initialized
INFO - 2020-08-25 04:14:49 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:49 --> Input Class Initialized
INFO - 2020-08-25 04:14:49 --> Language Class Initialized
INFO - 2020-08-25 04:14:49 --> Language Class Initialized
INFO - 2020-08-25 04:14:49 --> Config Class Initialized
INFO - 2020-08-25 04:14:49 --> Loader Class Initialized
INFO - 2020-08-25 04:14:49 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:49 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:49 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:49 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:49 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:49 --> Controller Class Initialized
INFO - 2020-08-25 04:14:54 --> Config Class Initialized
INFO - 2020-08-25 04:14:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:54 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:54 --> URI Class Initialized
INFO - 2020-08-25 04:14:54 --> Router Class Initialized
INFO - 2020-08-25 04:14:54 --> Output Class Initialized
INFO - 2020-08-25 04:14:54 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:54 --> Input Class Initialized
INFO - 2020-08-25 04:14:54 --> Language Class Initialized
INFO - 2020-08-25 04:14:54 --> Language Class Initialized
INFO - 2020-08-25 04:14:54 --> Config Class Initialized
INFO - 2020-08-25 04:14:54 --> Loader Class Initialized
INFO - 2020-08-25 04:14:54 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:54 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:54 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:54 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:54 --> Controller Class Initialized
INFO - 2020-08-25 04:14:54 --> Config Class Initialized
INFO - 2020-08-25 04:14:54 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:54 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:54 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:54 --> URI Class Initialized
INFO - 2020-08-25 04:14:54 --> Router Class Initialized
INFO - 2020-08-25 04:14:54 --> Output Class Initialized
INFO - 2020-08-25 04:14:54 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:54 --> Input Class Initialized
INFO - 2020-08-25 04:14:54 --> Language Class Initialized
INFO - 2020-08-25 04:14:54 --> Language Class Initialized
INFO - 2020-08-25 04:14:54 --> Config Class Initialized
INFO - 2020-08-25 04:14:54 --> Loader Class Initialized
INFO - 2020-08-25 04:14:54 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:54 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:54 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:54 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:54 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:54 --> Controller Class Initialized
INFO - 2020-08-25 04:14:55 --> Config Class Initialized
INFO - 2020-08-25 04:14:55 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:55 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:55 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:55 --> URI Class Initialized
INFO - 2020-08-25 04:14:55 --> Router Class Initialized
INFO - 2020-08-25 04:14:55 --> Output Class Initialized
INFO - 2020-08-25 04:14:55 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:55 --> Input Class Initialized
INFO - 2020-08-25 04:14:55 --> Language Class Initialized
INFO - 2020-08-25 04:14:55 --> Language Class Initialized
INFO - 2020-08-25 04:14:55 --> Config Class Initialized
INFO - 2020-08-25 04:14:55 --> Loader Class Initialized
INFO - 2020-08-25 04:14:55 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:55 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:55 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:55 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:55 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:55 --> Controller Class Initialized
INFO - 2020-08-25 04:14:58 --> Config Class Initialized
INFO - 2020-08-25 04:14:58 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:14:58 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:14:58 --> Utf8 Class Initialized
INFO - 2020-08-25 04:14:58 --> URI Class Initialized
INFO - 2020-08-25 04:14:58 --> Router Class Initialized
INFO - 2020-08-25 04:14:58 --> Output Class Initialized
INFO - 2020-08-25 04:14:58 --> Security Class Initialized
DEBUG - 2020-08-25 04:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:14:58 --> Input Class Initialized
INFO - 2020-08-25 04:14:58 --> Language Class Initialized
INFO - 2020-08-25 04:14:58 --> Language Class Initialized
INFO - 2020-08-25 04:14:58 --> Config Class Initialized
INFO - 2020-08-25 04:14:58 --> Loader Class Initialized
INFO - 2020-08-25 04:14:58 --> Helper loaded: url_helper
INFO - 2020-08-25 04:14:58 --> Helper loaded: file_helper
INFO - 2020-08-25 04:14:58 --> Helper loaded: form_helper
INFO - 2020-08-25 04:14:58 --> Helper loaded: my_helper
INFO - 2020-08-25 04:14:58 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:14:58 --> Controller Class Initialized
ERROR - 2020-08-25 04:14:58 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 241
DEBUG - 2020-08-25 04:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-08-25 04:14:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:14:58 --> Final output sent to browser
DEBUG - 2020-08-25 04:14:58 --> Total execution time: 0.0478
INFO - 2020-08-25 04:15:12 --> Config Class Initialized
INFO - 2020-08-25 04:15:12 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:15:12 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:15:12 --> Utf8 Class Initialized
INFO - 2020-08-25 04:15:12 --> URI Class Initialized
INFO - 2020-08-25 04:15:12 --> Router Class Initialized
INFO - 2020-08-25 04:15:12 --> Output Class Initialized
INFO - 2020-08-25 04:15:12 --> Security Class Initialized
DEBUG - 2020-08-25 04:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:15:12 --> Input Class Initialized
INFO - 2020-08-25 04:15:12 --> Language Class Initialized
INFO - 2020-08-25 04:15:12 --> Language Class Initialized
INFO - 2020-08-25 04:15:12 --> Config Class Initialized
INFO - 2020-08-25 04:15:12 --> Loader Class Initialized
INFO - 2020-08-25 04:15:12 --> Helper loaded: url_helper
INFO - 2020-08-25 04:15:12 --> Helper loaded: file_helper
INFO - 2020-08-25 04:15:12 --> Helper loaded: form_helper
INFO - 2020-08-25 04:15:12 --> Helper loaded: my_helper
INFO - 2020-08-25 04:15:12 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:15:12 --> Controller Class Initialized
DEBUG - 2020-08-25 04:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-08-25 04:15:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-08-25 04:15:12 --> Final output sent to browser
DEBUG - 2020-08-25 04:15:12 --> Total execution time: 0.0563
INFO - 2020-08-25 04:15:24 --> Config Class Initialized
INFO - 2020-08-25 04:15:24 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:15:24 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:15:24 --> Utf8 Class Initialized
INFO - 2020-08-25 04:15:24 --> URI Class Initialized
INFO - 2020-08-25 04:15:24 --> Router Class Initialized
INFO - 2020-08-25 04:15:24 --> Output Class Initialized
INFO - 2020-08-25 04:15:24 --> Security Class Initialized
DEBUG - 2020-08-25 04:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:15:24 --> Input Class Initialized
INFO - 2020-08-25 04:15:24 --> Language Class Initialized
INFO - 2020-08-25 04:15:24 --> Language Class Initialized
INFO - 2020-08-25 04:15:24 --> Config Class Initialized
INFO - 2020-08-25 04:15:24 --> Loader Class Initialized
INFO - 2020-08-25 04:15:24 --> Helper loaded: url_helper
INFO - 2020-08-25 04:15:24 --> Helper loaded: file_helper
INFO - 2020-08-25 04:15:24 --> Helper loaded: form_helper
INFO - 2020-08-25 04:15:24 --> Helper loaded: my_helper
INFO - 2020-08-25 04:15:24 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:15:24 --> Controller Class Initialized
INFO - 2020-08-25 04:15:31 --> Config Class Initialized
INFO - 2020-08-25 04:15:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:15:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:15:31 --> Utf8 Class Initialized
INFO - 2020-08-25 04:15:31 --> URI Class Initialized
INFO - 2020-08-25 04:15:31 --> Router Class Initialized
INFO - 2020-08-25 04:15:31 --> Output Class Initialized
INFO - 2020-08-25 04:15:31 --> Security Class Initialized
DEBUG - 2020-08-25 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:15:31 --> Input Class Initialized
INFO - 2020-08-25 04:15:31 --> Language Class Initialized
INFO - 2020-08-25 04:15:31 --> Language Class Initialized
INFO - 2020-08-25 04:15:31 --> Config Class Initialized
INFO - 2020-08-25 04:15:31 --> Loader Class Initialized
INFO - 2020-08-25 04:15:31 --> Helper loaded: url_helper
INFO - 2020-08-25 04:15:31 --> Helper loaded: file_helper
INFO - 2020-08-25 04:15:31 --> Helper loaded: form_helper
INFO - 2020-08-25 04:15:31 --> Helper loaded: my_helper
INFO - 2020-08-25 04:15:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:15:31 --> Controller Class Initialized
INFO - 2020-08-25 04:15:31 --> Final output sent to browser
DEBUG - 2020-08-25 04:15:31 --> Total execution time: 0.0507
INFO - 2020-08-25 04:15:31 --> Config Class Initialized
INFO - 2020-08-25 04:15:31 --> Hooks Class Initialized
DEBUG - 2020-08-25 04:15:31 --> UTF-8 Support Enabled
INFO - 2020-08-25 04:15:31 --> Utf8 Class Initialized
INFO - 2020-08-25 04:15:31 --> URI Class Initialized
INFO - 2020-08-25 04:15:31 --> Router Class Initialized
INFO - 2020-08-25 04:15:31 --> Output Class Initialized
INFO - 2020-08-25 04:15:31 --> Security Class Initialized
DEBUG - 2020-08-25 04:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-08-25 04:15:31 --> Input Class Initialized
INFO - 2020-08-25 04:15:31 --> Language Class Initialized
INFO - 2020-08-25 04:15:31 --> Language Class Initialized
INFO - 2020-08-25 04:15:31 --> Config Class Initialized
INFO - 2020-08-25 04:15:31 --> Loader Class Initialized
INFO - 2020-08-25 04:15:31 --> Helper loaded: url_helper
INFO - 2020-08-25 04:15:31 --> Helper loaded: file_helper
INFO - 2020-08-25 04:15:31 --> Helper loaded: form_helper
INFO - 2020-08-25 04:15:31 --> Helper loaded: my_helper
INFO - 2020-08-25 04:15:31 --> Database Driver Class Initialized
DEBUG - 2020-08-25 04:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-08-25 04:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-08-25 04:15:31 --> Controller Class Initialized
INFO - 2020-08-25 04:15:31 --> Final output sent to browser
DEBUG - 2020-08-25 04:15:31 --> Total execution time: 0.0549
