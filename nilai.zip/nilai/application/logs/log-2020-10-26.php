<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-26 01:03:43 --> Config Class Initialized
INFO - 2020-10-26 01:03:43 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:03:43 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:03:43 --> Utf8 Class Initialized
INFO - 2020-10-26 01:03:43 --> URI Class Initialized
DEBUG - 2020-10-26 01:03:43 --> No URI present. Default controller set.
INFO - 2020-10-26 01:03:43 --> Router Class Initialized
INFO - 2020-10-26 01:03:43 --> Output Class Initialized
INFO - 2020-10-26 01:03:43 --> Security Class Initialized
DEBUG - 2020-10-26 01:03:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:03:43 --> Input Class Initialized
INFO - 2020-10-26 01:03:43 --> Language Class Initialized
INFO - 2020-10-26 01:03:43 --> Language Class Initialized
INFO - 2020-10-26 01:03:43 --> Config Class Initialized
INFO - 2020-10-26 01:03:43 --> Loader Class Initialized
INFO - 2020-10-26 01:03:43 --> Helper loaded: url_helper
INFO - 2020-10-26 01:03:43 --> Helper loaded: file_helper
INFO - 2020-10-26 01:03:43 --> Helper loaded: form_helper
INFO - 2020-10-26 01:03:43 --> Helper loaded: my_helper
INFO - 2020-10-26 01:03:43 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:03:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:03:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:03:43 --> Controller Class Initialized
INFO - 2020-10-26 01:03:43 --> Config Class Initialized
INFO - 2020-10-26 01:03:43 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:03:43 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:03:43 --> Utf8 Class Initialized
INFO - 2020-10-26 01:03:43 --> URI Class Initialized
INFO - 2020-10-26 01:03:43 --> Router Class Initialized
INFO - 2020-10-26 01:03:44 --> Output Class Initialized
INFO - 2020-10-26 01:03:44 --> Security Class Initialized
DEBUG - 2020-10-26 01:03:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:03:44 --> Input Class Initialized
INFO - 2020-10-26 01:03:44 --> Language Class Initialized
INFO - 2020-10-26 01:03:44 --> Language Class Initialized
INFO - 2020-10-26 01:03:44 --> Config Class Initialized
INFO - 2020-10-26 01:03:44 --> Loader Class Initialized
INFO - 2020-10-26 01:03:44 --> Helper loaded: url_helper
INFO - 2020-10-26 01:03:44 --> Helper loaded: file_helper
INFO - 2020-10-26 01:03:44 --> Helper loaded: form_helper
INFO - 2020-10-26 01:03:44 --> Helper loaded: my_helper
INFO - 2020-10-26 01:03:44 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:03:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:03:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:03:44 --> Controller Class Initialized
DEBUG - 2020-10-26 01:03:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 01:03:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:03:44 --> Final output sent to browser
DEBUG - 2020-10-26 01:03:44 --> Total execution time: 0.2704
INFO - 2020-10-26 01:04:14 --> Config Class Initialized
INFO - 2020-10-26 01:04:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:04:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:04:14 --> Utf8 Class Initialized
INFO - 2020-10-26 01:04:14 --> URI Class Initialized
INFO - 2020-10-26 01:04:14 --> Router Class Initialized
INFO - 2020-10-26 01:04:14 --> Output Class Initialized
INFO - 2020-10-26 01:04:14 --> Security Class Initialized
DEBUG - 2020-10-26 01:04:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:04:14 --> Input Class Initialized
INFO - 2020-10-26 01:04:14 --> Language Class Initialized
INFO - 2020-10-26 01:04:14 --> Language Class Initialized
INFO - 2020-10-26 01:04:14 --> Config Class Initialized
INFO - 2020-10-26 01:04:14 --> Loader Class Initialized
INFO - 2020-10-26 01:04:14 --> Helper loaded: url_helper
INFO - 2020-10-26 01:04:14 --> Helper loaded: file_helper
INFO - 2020-10-26 01:04:14 --> Helper loaded: form_helper
INFO - 2020-10-26 01:04:14 --> Helper loaded: my_helper
INFO - 2020-10-26 01:04:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:04:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:04:14 --> Controller Class Initialized
INFO - 2020-10-26 01:04:14 --> Helper loaded: cookie_helper
INFO - 2020-10-26 01:04:14 --> Final output sent to browser
DEBUG - 2020-10-26 01:04:14 --> Total execution time: 0.5902
INFO - 2020-10-26 01:04:16 --> Config Class Initialized
INFO - 2020-10-26 01:04:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:04:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:04:16 --> Utf8 Class Initialized
INFO - 2020-10-26 01:04:16 --> URI Class Initialized
INFO - 2020-10-26 01:04:16 --> Router Class Initialized
INFO - 2020-10-26 01:04:16 --> Output Class Initialized
INFO - 2020-10-26 01:04:16 --> Security Class Initialized
DEBUG - 2020-10-26 01:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:04:16 --> Input Class Initialized
INFO - 2020-10-26 01:04:16 --> Language Class Initialized
INFO - 2020-10-26 01:04:16 --> Language Class Initialized
INFO - 2020-10-26 01:04:16 --> Config Class Initialized
INFO - 2020-10-26 01:04:16 --> Loader Class Initialized
INFO - 2020-10-26 01:04:16 --> Helper loaded: url_helper
INFO - 2020-10-26 01:04:16 --> Helper loaded: file_helper
INFO - 2020-10-26 01:04:16 --> Helper loaded: form_helper
INFO - 2020-10-26 01:04:16 --> Helper loaded: my_helper
INFO - 2020-10-26 01:04:16 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:04:16 --> Controller Class Initialized
DEBUG - 2020-10-26 01:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 01:04:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:04:16 --> Final output sent to browser
DEBUG - 2020-10-26 01:04:16 --> Total execution time: 0.4929
INFO - 2020-10-26 01:07:07 --> Config Class Initialized
INFO - 2020-10-26 01:07:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:07 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:07 --> URI Class Initialized
INFO - 2020-10-26 01:07:07 --> Router Class Initialized
INFO - 2020-10-26 01:07:07 --> Output Class Initialized
INFO - 2020-10-26 01:07:07 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:07 --> Input Class Initialized
INFO - 2020-10-26 01:07:07 --> Language Class Initialized
INFO - 2020-10-26 01:07:07 --> Language Class Initialized
INFO - 2020-10-26 01:07:07 --> Config Class Initialized
INFO - 2020-10-26 01:07:07 --> Loader Class Initialized
INFO - 2020-10-26 01:07:07 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:07 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:07 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:07 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:07 --> Controller Class Initialized
INFO - 2020-10-26 01:07:07 --> Helper loaded: cookie_helper
INFO - 2020-10-26 01:07:07 --> Config Class Initialized
INFO - 2020-10-26 01:07:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:07 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:07 --> URI Class Initialized
INFO - 2020-10-26 01:07:07 --> Router Class Initialized
INFO - 2020-10-26 01:07:07 --> Output Class Initialized
INFO - 2020-10-26 01:07:07 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:07 --> Input Class Initialized
INFO - 2020-10-26 01:07:07 --> Language Class Initialized
INFO - 2020-10-26 01:07:07 --> Language Class Initialized
INFO - 2020-10-26 01:07:07 --> Config Class Initialized
INFO - 2020-10-26 01:07:07 --> Loader Class Initialized
INFO - 2020-10-26 01:07:07 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:07 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:07 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:07 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:07 --> Controller Class Initialized
DEBUG - 2020-10-26 01:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 01:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:07:07 --> Final output sent to browser
DEBUG - 2020-10-26 01:07:07 --> Total execution time: 0.1873
INFO - 2020-10-26 01:07:18 --> Config Class Initialized
INFO - 2020-10-26 01:07:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:18 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:18 --> URI Class Initialized
INFO - 2020-10-26 01:07:18 --> Router Class Initialized
INFO - 2020-10-26 01:07:18 --> Output Class Initialized
INFO - 2020-10-26 01:07:18 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:18 --> Input Class Initialized
INFO - 2020-10-26 01:07:18 --> Language Class Initialized
INFO - 2020-10-26 01:07:18 --> Language Class Initialized
INFO - 2020-10-26 01:07:18 --> Config Class Initialized
INFO - 2020-10-26 01:07:18 --> Loader Class Initialized
INFO - 2020-10-26 01:07:18 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:18 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:18 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:18 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:18 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:19 --> Controller Class Initialized
INFO - 2020-10-26 01:07:19 --> Helper loaded: cookie_helper
INFO - 2020-10-26 01:07:19 --> Final output sent to browser
DEBUG - 2020-10-26 01:07:19 --> Total execution time: 0.1719
INFO - 2020-10-26 01:07:20 --> Config Class Initialized
INFO - 2020-10-26 01:07:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:20 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:20 --> URI Class Initialized
INFO - 2020-10-26 01:07:20 --> Router Class Initialized
INFO - 2020-10-26 01:07:20 --> Output Class Initialized
INFO - 2020-10-26 01:07:20 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:20 --> Input Class Initialized
INFO - 2020-10-26 01:07:20 --> Language Class Initialized
INFO - 2020-10-26 01:07:20 --> Language Class Initialized
INFO - 2020-10-26 01:07:20 --> Config Class Initialized
INFO - 2020-10-26 01:07:20 --> Loader Class Initialized
INFO - 2020-10-26 01:07:20 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:20 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:20 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:20 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:20 --> Controller Class Initialized
DEBUG - 2020-10-26 01:07:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 01:07:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:07:20 --> Final output sent to browser
DEBUG - 2020-10-26 01:07:20 --> Total execution time: 0.2005
INFO - 2020-10-26 01:07:23 --> Config Class Initialized
INFO - 2020-10-26 01:07:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:23 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:23 --> URI Class Initialized
INFO - 2020-10-26 01:07:23 --> Router Class Initialized
INFO - 2020-10-26 01:07:23 --> Output Class Initialized
INFO - 2020-10-26 01:07:23 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:23 --> Input Class Initialized
INFO - 2020-10-26 01:07:23 --> Language Class Initialized
INFO - 2020-10-26 01:07:23 --> Language Class Initialized
INFO - 2020-10-26 01:07:23 --> Config Class Initialized
INFO - 2020-10-26 01:07:23 --> Loader Class Initialized
INFO - 2020-10-26 01:07:23 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:23 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:23 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:23 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:23 --> Controller Class Initialized
DEBUG - 2020-10-26 01:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 01:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:07:23 --> Final output sent to browser
DEBUG - 2020-10-26 01:07:23 --> Total execution time: 0.2171
INFO - 2020-10-26 01:07:23 --> Config Class Initialized
INFO - 2020-10-26 01:07:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:23 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:23 --> URI Class Initialized
INFO - 2020-10-26 01:07:23 --> Router Class Initialized
INFO - 2020-10-26 01:07:23 --> Output Class Initialized
INFO - 2020-10-26 01:07:23 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:23 --> Input Class Initialized
INFO - 2020-10-26 01:07:23 --> Language Class Initialized
INFO - 2020-10-26 01:07:23 --> Language Class Initialized
INFO - 2020-10-26 01:07:23 --> Config Class Initialized
INFO - 2020-10-26 01:07:23 --> Loader Class Initialized
INFO - 2020-10-26 01:07:23 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:23 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:23 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:24 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:24 --> Controller Class Initialized
INFO - 2020-10-26 01:07:56 --> Config Class Initialized
INFO - 2020-10-26 01:07:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:56 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:56 --> URI Class Initialized
INFO - 2020-10-26 01:07:56 --> Router Class Initialized
INFO - 2020-10-26 01:07:56 --> Output Class Initialized
INFO - 2020-10-26 01:07:56 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:56 --> Input Class Initialized
INFO - 2020-10-26 01:07:56 --> Language Class Initialized
INFO - 2020-10-26 01:07:56 --> Language Class Initialized
INFO - 2020-10-26 01:07:56 --> Config Class Initialized
INFO - 2020-10-26 01:07:56 --> Loader Class Initialized
INFO - 2020-10-26 01:07:56 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:56 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:56 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:56 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:56 --> Controller Class Initialized
INFO - 2020-10-26 01:07:56 --> Helper loaded: cookie_helper
INFO - 2020-10-26 01:07:56 --> Config Class Initialized
INFO - 2020-10-26 01:07:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:07:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:07:56 --> Utf8 Class Initialized
INFO - 2020-10-26 01:07:56 --> URI Class Initialized
INFO - 2020-10-26 01:07:56 --> Router Class Initialized
INFO - 2020-10-26 01:07:56 --> Output Class Initialized
INFO - 2020-10-26 01:07:56 --> Security Class Initialized
DEBUG - 2020-10-26 01:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:07:56 --> Input Class Initialized
INFO - 2020-10-26 01:07:56 --> Language Class Initialized
INFO - 2020-10-26 01:07:56 --> Language Class Initialized
INFO - 2020-10-26 01:07:56 --> Config Class Initialized
INFO - 2020-10-26 01:07:56 --> Loader Class Initialized
INFO - 2020-10-26 01:07:56 --> Helper loaded: url_helper
INFO - 2020-10-26 01:07:56 --> Helper loaded: file_helper
INFO - 2020-10-26 01:07:56 --> Helper loaded: form_helper
INFO - 2020-10-26 01:07:56 --> Helper loaded: my_helper
INFO - 2020-10-26 01:07:57 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:07:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:07:57 --> Controller Class Initialized
DEBUG - 2020-10-26 01:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 01:07:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:07:57 --> Final output sent to browser
DEBUG - 2020-10-26 01:07:57 --> Total execution time: 0.1617
INFO - 2020-10-26 01:08:04 --> Config Class Initialized
INFO - 2020-10-26 01:08:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:08:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:08:04 --> Utf8 Class Initialized
INFO - 2020-10-26 01:08:04 --> URI Class Initialized
INFO - 2020-10-26 01:08:04 --> Router Class Initialized
INFO - 2020-10-26 01:08:04 --> Output Class Initialized
INFO - 2020-10-26 01:08:04 --> Security Class Initialized
DEBUG - 2020-10-26 01:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:08:04 --> Input Class Initialized
INFO - 2020-10-26 01:08:04 --> Language Class Initialized
INFO - 2020-10-26 01:08:04 --> Language Class Initialized
INFO - 2020-10-26 01:08:04 --> Config Class Initialized
INFO - 2020-10-26 01:08:04 --> Loader Class Initialized
INFO - 2020-10-26 01:08:04 --> Helper loaded: url_helper
INFO - 2020-10-26 01:08:04 --> Helper loaded: file_helper
INFO - 2020-10-26 01:08:04 --> Helper loaded: form_helper
INFO - 2020-10-26 01:08:04 --> Helper loaded: my_helper
INFO - 2020-10-26 01:08:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:08:05 --> Controller Class Initialized
INFO - 2020-10-26 01:08:05 --> Helper loaded: cookie_helper
INFO - 2020-10-26 01:08:05 --> Final output sent to browser
DEBUG - 2020-10-26 01:08:05 --> Total execution time: 0.2259
INFO - 2020-10-26 01:08:06 --> Config Class Initialized
INFO - 2020-10-26 01:08:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:08:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:08:06 --> Utf8 Class Initialized
INFO - 2020-10-26 01:08:06 --> URI Class Initialized
INFO - 2020-10-26 01:08:06 --> Router Class Initialized
INFO - 2020-10-26 01:08:06 --> Output Class Initialized
INFO - 2020-10-26 01:08:06 --> Security Class Initialized
DEBUG - 2020-10-26 01:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:08:06 --> Input Class Initialized
INFO - 2020-10-26 01:08:06 --> Language Class Initialized
INFO - 2020-10-26 01:08:06 --> Language Class Initialized
INFO - 2020-10-26 01:08:06 --> Config Class Initialized
INFO - 2020-10-26 01:08:06 --> Loader Class Initialized
INFO - 2020-10-26 01:08:06 --> Helper loaded: url_helper
INFO - 2020-10-26 01:08:06 --> Helper loaded: file_helper
INFO - 2020-10-26 01:08:06 --> Helper loaded: form_helper
INFO - 2020-10-26 01:08:06 --> Helper loaded: my_helper
INFO - 2020-10-26 01:08:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:08:06 --> Controller Class Initialized
DEBUG - 2020-10-26 01:08:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 01:08:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:08:06 --> Final output sent to browser
DEBUG - 2020-10-26 01:08:06 --> Total execution time: 0.2175
INFO - 2020-10-26 01:08:14 --> Config Class Initialized
INFO - 2020-10-26 01:08:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:08:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:08:14 --> Utf8 Class Initialized
INFO - 2020-10-26 01:08:14 --> URI Class Initialized
INFO - 2020-10-26 01:08:14 --> Router Class Initialized
INFO - 2020-10-26 01:08:14 --> Output Class Initialized
INFO - 2020-10-26 01:08:14 --> Security Class Initialized
DEBUG - 2020-10-26 01:08:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:08:14 --> Input Class Initialized
INFO - 2020-10-26 01:08:14 --> Language Class Initialized
INFO - 2020-10-26 01:08:14 --> Language Class Initialized
INFO - 2020-10-26 01:08:14 --> Config Class Initialized
INFO - 2020-10-26 01:08:14 --> Loader Class Initialized
INFO - 2020-10-26 01:08:14 --> Helper loaded: url_helper
INFO - 2020-10-26 01:08:14 --> Helper loaded: file_helper
INFO - 2020-10-26 01:08:14 --> Helper loaded: form_helper
INFO - 2020-10-26 01:08:14 --> Helper loaded: my_helper
INFO - 2020-10-26 01:08:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:08:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:08:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:08:14 --> Controller Class Initialized
DEBUG - 2020-10-26 01:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-26 01:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:08:15 --> Final output sent to browser
DEBUG - 2020-10-26 01:08:15 --> Total execution time: 0.3398
INFO - 2020-10-26 01:08:26 --> Config Class Initialized
INFO - 2020-10-26 01:08:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:08:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:08:26 --> Utf8 Class Initialized
INFO - 2020-10-26 01:08:26 --> URI Class Initialized
INFO - 2020-10-26 01:08:26 --> Router Class Initialized
INFO - 2020-10-26 01:08:26 --> Output Class Initialized
INFO - 2020-10-26 01:08:26 --> Security Class Initialized
DEBUG - 2020-10-26 01:08:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:08:26 --> Input Class Initialized
INFO - 2020-10-26 01:08:26 --> Language Class Initialized
INFO - 2020-10-26 01:08:26 --> Language Class Initialized
INFO - 2020-10-26 01:08:26 --> Config Class Initialized
INFO - 2020-10-26 01:08:26 --> Loader Class Initialized
INFO - 2020-10-26 01:08:26 --> Helper loaded: url_helper
INFO - 2020-10-26 01:08:26 --> Helper loaded: file_helper
INFO - 2020-10-26 01:08:26 --> Helper loaded: form_helper
INFO - 2020-10-26 01:08:26 --> Helper loaded: my_helper
INFO - 2020-10-26 01:08:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:08:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:08:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:08:26 --> Controller Class Initialized
DEBUG - 2020-10-26 01:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-26 01:08:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:08:26 --> Final output sent to browser
DEBUG - 2020-10-26 01:08:26 --> Total execution time: 0.3299
INFO - 2020-10-26 01:08:38 --> Config Class Initialized
INFO - 2020-10-26 01:08:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:08:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:08:38 --> Utf8 Class Initialized
INFO - 2020-10-26 01:08:38 --> URI Class Initialized
DEBUG - 2020-10-26 01:08:38 --> No URI present. Default controller set.
INFO - 2020-10-26 01:08:38 --> Router Class Initialized
INFO - 2020-10-26 01:08:38 --> Output Class Initialized
INFO - 2020-10-26 01:08:38 --> Security Class Initialized
DEBUG - 2020-10-26 01:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:08:38 --> Input Class Initialized
INFO - 2020-10-26 01:08:38 --> Language Class Initialized
INFO - 2020-10-26 01:08:38 --> Language Class Initialized
INFO - 2020-10-26 01:08:38 --> Config Class Initialized
INFO - 2020-10-26 01:08:38 --> Loader Class Initialized
INFO - 2020-10-26 01:08:38 --> Helper loaded: url_helper
INFO - 2020-10-26 01:08:38 --> Helper loaded: file_helper
INFO - 2020-10-26 01:08:38 --> Helper loaded: form_helper
INFO - 2020-10-26 01:08:38 --> Helper loaded: my_helper
INFO - 2020-10-26 01:08:38 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:08:38 --> Controller Class Initialized
DEBUG - 2020-10-26 01:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 01:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:08:38 --> Final output sent to browser
DEBUG - 2020-10-26 01:08:38 --> Total execution time: 0.1848
INFO - 2020-10-26 01:08:39 --> Config Class Initialized
INFO - 2020-10-26 01:08:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:08:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:08:39 --> Utf8 Class Initialized
INFO - 2020-10-26 01:08:39 --> URI Class Initialized
INFO - 2020-10-26 01:08:39 --> Router Class Initialized
INFO - 2020-10-26 01:08:39 --> Output Class Initialized
INFO - 2020-10-26 01:08:39 --> Security Class Initialized
DEBUG - 2020-10-26 01:08:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:08:39 --> Input Class Initialized
INFO - 2020-10-26 01:08:39 --> Language Class Initialized
INFO - 2020-10-26 01:08:39 --> Language Class Initialized
INFO - 2020-10-26 01:08:39 --> Config Class Initialized
INFO - 2020-10-26 01:08:39 --> Loader Class Initialized
INFO - 2020-10-26 01:08:39 --> Helper loaded: url_helper
INFO - 2020-10-26 01:08:39 --> Helper loaded: file_helper
INFO - 2020-10-26 01:08:39 --> Helper loaded: form_helper
INFO - 2020-10-26 01:08:39 --> Helper loaded: my_helper
INFO - 2020-10-26 01:08:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:08:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:08:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:08:39 --> Controller Class Initialized
DEBUG - 2020-10-26 01:08:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 01:08:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:08:39 --> Final output sent to browser
DEBUG - 2020-10-26 01:08:39 --> Total execution time: 0.3183
INFO - 2020-10-26 01:09:06 --> Config Class Initialized
INFO - 2020-10-26 01:09:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:09:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:09:06 --> Utf8 Class Initialized
INFO - 2020-10-26 01:09:06 --> URI Class Initialized
INFO - 2020-10-26 01:09:06 --> Router Class Initialized
INFO - 2020-10-26 01:09:06 --> Output Class Initialized
INFO - 2020-10-26 01:09:06 --> Security Class Initialized
DEBUG - 2020-10-26 01:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:09:06 --> Input Class Initialized
INFO - 2020-10-26 01:09:06 --> Language Class Initialized
INFO - 2020-10-26 01:09:06 --> Language Class Initialized
INFO - 2020-10-26 01:09:06 --> Config Class Initialized
INFO - 2020-10-26 01:09:06 --> Loader Class Initialized
INFO - 2020-10-26 01:09:06 --> Helper loaded: url_helper
INFO - 2020-10-26 01:09:06 --> Helper loaded: file_helper
INFO - 2020-10-26 01:09:06 --> Helper loaded: form_helper
INFO - 2020-10-26 01:09:06 --> Helper loaded: my_helper
INFO - 2020-10-26 01:09:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:09:06 --> Controller Class Initialized
DEBUG - 2020-10-26 01:09:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 01:09:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:09:06 --> Final output sent to browser
DEBUG - 2020-10-26 01:09:06 --> Total execution time: 0.3165
INFO - 2020-10-26 01:09:17 --> Config Class Initialized
INFO - 2020-10-26 01:09:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:09:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:09:17 --> Utf8 Class Initialized
INFO - 2020-10-26 01:09:17 --> URI Class Initialized
INFO - 2020-10-26 01:09:17 --> Router Class Initialized
INFO - 2020-10-26 01:09:17 --> Output Class Initialized
INFO - 2020-10-26 01:09:17 --> Security Class Initialized
DEBUG - 2020-10-26 01:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:09:17 --> Input Class Initialized
INFO - 2020-10-26 01:09:17 --> Language Class Initialized
INFO - 2020-10-26 01:09:17 --> Language Class Initialized
INFO - 2020-10-26 01:09:17 --> Config Class Initialized
INFO - 2020-10-26 01:09:17 --> Loader Class Initialized
INFO - 2020-10-26 01:09:17 --> Helper loaded: url_helper
INFO - 2020-10-26 01:09:17 --> Helper loaded: file_helper
INFO - 2020-10-26 01:09:17 --> Helper loaded: form_helper
INFO - 2020-10-26 01:09:17 --> Helper loaded: my_helper
INFO - 2020-10-26 01:09:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:09:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:09:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:09:17 --> Controller Class Initialized
INFO - 2020-10-26 01:09:41 --> Config Class Initialized
INFO - 2020-10-26 01:09:41 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:09:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:09:41 --> Utf8 Class Initialized
INFO - 2020-10-26 01:09:41 --> URI Class Initialized
INFO - 2020-10-26 01:09:41 --> Router Class Initialized
INFO - 2020-10-26 01:09:41 --> Output Class Initialized
INFO - 2020-10-26 01:09:41 --> Security Class Initialized
DEBUG - 2020-10-26 01:09:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:09:41 --> Input Class Initialized
INFO - 2020-10-26 01:09:41 --> Language Class Initialized
INFO - 2020-10-26 01:09:41 --> Language Class Initialized
INFO - 2020-10-26 01:09:41 --> Config Class Initialized
INFO - 2020-10-26 01:09:41 --> Loader Class Initialized
INFO - 2020-10-26 01:09:41 --> Helper loaded: url_helper
INFO - 2020-10-26 01:09:41 --> Helper loaded: file_helper
INFO - 2020-10-26 01:09:41 --> Helper loaded: form_helper
INFO - 2020-10-26 01:09:41 --> Helper loaded: my_helper
INFO - 2020-10-26 01:09:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:09:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:09:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:09:41 --> Controller Class Initialized
INFO - 2020-10-26 01:10:36 --> Config Class Initialized
INFO - 2020-10-26 01:10:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:10:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:10:36 --> Utf8 Class Initialized
INFO - 2020-10-26 01:10:36 --> URI Class Initialized
INFO - 2020-10-26 01:10:36 --> Router Class Initialized
INFO - 2020-10-26 01:10:36 --> Output Class Initialized
INFO - 2020-10-26 01:10:36 --> Security Class Initialized
DEBUG - 2020-10-26 01:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:10:36 --> Input Class Initialized
INFO - 2020-10-26 01:10:36 --> Language Class Initialized
INFO - 2020-10-26 01:10:36 --> Language Class Initialized
INFO - 2020-10-26 01:10:36 --> Config Class Initialized
INFO - 2020-10-26 01:10:36 --> Loader Class Initialized
INFO - 2020-10-26 01:10:36 --> Helper loaded: url_helper
INFO - 2020-10-26 01:10:36 --> Helper loaded: file_helper
INFO - 2020-10-26 01:10:36 --> Helper loaded: form_helper
INFO - 2020-10-26 01:10:36 --> Helper loaded: my_helper
INFO - 2020-10-26 01:10:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:10:36 --> Controller Class Initialized
INFO - 2020-10-26 01:10:36 --> Final output sent to browser
DEBUG - 2020-10-26 01:10:36 --> Total execution time: 0.2350
INFO - 2020-10-26 01:18:01 --> Config Class Initialized
INFO - 2020-10-26 01:18:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:18:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:18:01 --> Utf8 Class Initialized
INFO - 2020-10-26 01:18:01 --> URI Class Initialized
INFO - 2020-10-26 01:18:01 --> Router Class Initialized
INFO - 2020-10-26 01:18:01 --> Output Class Initialized
INFO - 2020-10-26 01:18:01 --> Security Class Initialized
DEBUG - 2020-10-26 01:18:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:18:01 --> Input Class Initialized
INFO - 2020-10-26 01:18:01 --> Language Class Initialized
INFO - 2020-10-26 01:18:01 --> Language Class Initialized
INFO - 2020-10-26 01:18:01 --> Config Class Initialized
INFO - 2020-10-26 01:18:01 --> Loader Class Initialized
INFO - 2020-10-26 01:18:01 --> Helper loaded: url_helper
INFO - 2020-10-26 01:18:01 --> Helper loaded: file_helper
INFO - 2020-10-26 01:18:01 --> Helper loaded: form_helper
INFO - 2020-10-26 01:18:01 --> Helper loaded: my_helper
INFO - 2020-10-26 01:18:01 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:18:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:18:01 --> Controller Class Initialized
INFO - 2020-10-26 01:25:35 --> Config Class Initialized
INFO - 2020-10-26 01:25:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:25:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:25:35 --> Utf8 Class Initialized
INFO - 2020-10-26 01:25:35 --> URI Class Initialized
INFO - 2020-10-26 01:25:35 --> Router Class Initialized
INFO - 2020-10-26 01:25:35 --> Output Class Initialized
INFO - 2020-10-26 01:25:35 --> Security Class Initialized
DEBUG - 2020-10-26 01:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:25:35 --> Input Class Initialized
INFO - 2020-10-26 01:25:35 --> Language Class Initialized
INFO - 2020-10-26 01:25:35 --> Language Class Initialized
INFO - 2020-10-26 01:25:35 --> Config Class Initialized
INFO - 2020-10-26 01:25:35 --> Loader Class Initialized
INFO - 2020-10-26 01:25:35 --> Helper loaded: url_helper
INFO - 2020-10-26 01:25:35 --> Helper loaded: file_helper
INFO - 2020-10-26 01:25:35 --> Helper loaded: form_helper
INFO - 2020-10-26 01:25:35 --> Helper loaded: my_helper
INFO - 2020-10-26 01:25:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:25:35 --> Controller Class Initialized
DEBUG - 2020-10-26 01:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:25:35 --> Final output sent to browser
DEBUG - 2020-10-26 01:25:35 --> Total execution time: 0.1781
INFO - 2020-10-26 01:25:44 --> Config Class Initialized
INFO - 2020-10-26 01:25:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:25:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:25:44 --> Utf8 Class Initialized
INFO - 2020-10-26 01:25:44 --> URI Class Initialized
INFO - 2020-10-26 01:25:44 --> Router Class Initialized
INFO - 2020-10-26 01:25:44 --> Output Class Initialized
INFO - 2020-10-26 01:25:44 --> Security Class Initialized
DEBUG - 2020-10-26 01:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:25:44 --> Input Class Initialized
INFO - 2020-10-26 01:25:44 --> Language Class Initialized
INFO - 2020-10-26 01:25:44 --> Language Class Initialized
INFO - 2020-10-26 01:25:44 --> Config Class Initialized
INFO - 2020-10-26 01:25:44 --> Loader Class Initialized
INFO - 2020-10-26 01:25:44 --> Helper loaded: url_helper
INFO - 2020-10-26 01:25:44 --> Helper loaded: file_helper
INFO - 2020-10-26 01:25:44 --> Helper loaded: form_helper
INFO - 2020-10-26 01:25:44 --> Helper loaded: my_helper
INFO - 2020-10-26 01:25:44 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:25:44 --> Controller Class Initialized
ERROR - 2020-10-26 01:25:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:25:44 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:27:51 --> Config Class Initialized
INFO - 2020-10-26 01:27:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:27:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:27:51 --> Utf8 Class Initialized
INFO - 2020-10-26 01:27:51 --> URI Class Initialized
INFO - 2020-10-26 01:27:51 --> Router Class Initialized
INFO - 2020-10-26 01:27:51 --> Output Class Initialized
INFO - 2020-10-26 01:27:51 --> Security Class Initialized
DEBUG - 2020-10-26 01:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:27:51 --> Input Class Initialized
INFO - 2020-10-26 01:27:51 --> Language Class Initialized
INFO - 2020-10-26 01:27:51 --> Language Class Initialized
INFO - 2020-10-26 01:27:51 --> Config Class Initialized
INFO - 2020-10-26 01:27:51 --> Loader Class Initialized
INFO - 2020-10-26 01:27:51 --> Helper loaded: url_helper
INFO - 2020-10-26 01:27:51 --> Helper loaded: file_helper
INFO - 2020-10-26 01:27:51 --> Helper loaded: form_helper
INFO - 2020-10-26 01:27:51 --> Helper loaded: my_helper
INFO - 2020-10-26 01:27:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:27:51 --> Controller Class Initialized
DEBUG - 2020-10-26 01:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:27:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:27:51 --> Final output sent to browser
DEBUG - 2020-10-26 01:27:51 --> Total execution time: 0.2825
INFO - 2020-10-26 01:27:54 --> Config Class Initialized
INFO - 2020-10-26 01:27:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:27:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:27:54 --> Utf8 Class Initialized
INFO - 2020-10-26 01:27:54 --> URI Class Initialized
INFO - 2020-10-26 01:27:54 --> Router Class Initialized
INFO - 2020-10-26 01:27:54 --> Output Class Initialized
INFO - 2020-10-26 01:27:54 --> Security Class Initialized
DEBUG - 2020-10-26 01:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:27:54 --> Input Class Initialized
INFO - 2020-10-26 01:27:54 --> Language Class Initialized
INFO - 2020-10-26 01:27:54 --> Language Class Initialized
INFO - 2020-10-26 01:27:54 --> Config Class Initialized
INFO - 2020-10-26 01:27:54 --> Loader Class Initialized
INFO - 2020-10-26 01:27:54 --> Helper loaded: url_helper
INFO - 2020-10-26 01:27:54 --> Helper loaded: file_helper
INFO - 2020-10-26 01:27:54 --> Helper loaded: form_helper
INFO - 2020-10-26 01:27:54 --> Helper loaded: my_helper
INFO - 2020-10-26 01:27:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:27:54 --> Controller Class Initialized
DEBUG - 2020-10-26 01:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:27:54 --> Final output sent to browser
DEBUG - 2020-10-26 01:27:54 --> Total execution time: 0.2320
INFO - 2020-10-26 01:28:05 --> Config Class Initialized
INFO - 2020-10-26 01:28:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:28:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:28:05 --> Utf8 Class Initialized
INFO - 2020-10-26 01:28:05 --> URI Class Initialized
INFO - 2020-10-26 01:28:05 --> Router Class Initialized
INFO - 2020-10-26 01:28:05 --> Output Class Initialized
INFO - 2020-10-26 01:28:05 --> Security Class Initialized
DEBUG - 2020-10-26 01:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:28:05 --> Input Class Initialized
INFO - 2020-10-26 01:28:05 --> Language Class Initialized
INFO - 2020-10-26 01:28:05 --> Language Class Initialized
INFO - 2020-10-26 01:28:05 --> Config Class Initialized
INFO - 2020-10-26 01:28:05 --> Loader Class Initialized
INFO - 2020-10-26 01:28:05 --> Helper loaded: url_helper
INFO - 2020-10-26 01:28:05 --> Helper loaded: file_helper
INFO - 2020-10-26 01:28:05 --> Helper loaded: form_helper
INFO - 2020-10-26 01:28:05 --> Helper loaded: my_helper
INFO - 2020-10-26 01:28:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:28:05 --> Controller Class Initialized
ERROR - 2020-10-26 01:28:05 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:28:05 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:38:46 --> Config Class Initialized
INFO - 2020-10-26 01:38:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:38:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:38:46 --> Utf8 Class Initialized
INFO - 2020-10-26 01:38:46 --> URI Class Initialized
INFO - 2020-10-26 01:38:46 --> Router Class Initialized
INFO - 2020-10-26 01:38:46 --> Output Class Initialized
INFO - 2020-10-26 01:38:46 --> Security Class Initialized
DEBUG - 2020-10-26 01:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:38:46 --> Input Class Initialized
INFO - 2020-10-26 01:38:46 --> Language Class Initialized
INFO - 2020-10-26 01:38:46 --> Language Class Initialized
INFO - 2020-10-26 01:38:46 --> Config Class Initialized
INFO - 2020-10-26 01:38:46 --> Loader Class Initialized
INFO - 2020-10-26 01:38:46 --> Helper loaded: url_helper
INFO - 2020-10-26 01:38:46 --> Helper loaded: file_helper
INFO - 2020-10-26 01:38:46 --> Helper loaded: form_helper
INFO - 2020-10-26 01:38:46 --> Helper loaded: my_helper
INFO - 2020-10-26 01:38:46 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:38:46 --> Controller Class Initialized
ERROR - 2020-10-26 01:38:46 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:38:46 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:41:09 --> Config Class Initialized
INFO - 2020-10-26 01:41:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:41:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:41:09 --> Utf8 Class Initialized
INFO - 2020-10-26 01:41:09 --> URI Class Initialized
INFO - 2020-10-26 01:41:09 --> Router Class Initialized
INFO - 2020-10-26 01:41:09 --> Output Class Initialized
INFO - 2020-10-26 01:41:09 --> Security Class Initialized
DEBUG - 2020-10-26 01:41:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:41:09 --> Input Class Initialized
INFO - 2020-10-26 01:41:09 --> Language Class Initialized
INFO - 2020-10-26 01:41:09 --> Language Class Initialized
INFO - 2020-10-26 01:41:09 --> Config Class Initialized
INFO - 2020-10-26 01:41:09 --> Loader Class Initialized
INFO - 2020-10-26 01:41:09 --> Helper loaded: url_helper
INFO - 2020-10-26 01:41:09 --> Helper loaded: file_helper
INFO - 2020-10-26 01:41:09 --> Helper loaded: form_helper
INFO - 2020-10-26 01:41:09 --> Helper loaded: my_helper
INFO - 2020-10-26 01:41:09 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:41:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:41:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:41:09 --> Controller Class Initialized
DEBUG - 2020-10-26 01:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:41:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:41:09 --> Final output sent to browser
DEBUG - 2020-10-26 01:41:09 --> Total execution time: 0.1983
INFO - 2020-10-26 01:41:13 --> Config Class Initialized
INFO - 2020-10-26 01:41:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:41:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:41:13 --> Utf8 Class Initialized
INFO - 2020-10-26 01:41:13 --> URI Class Initialized
INFO - 2020-10-26 01:41:13 --> Router Class Initialized
INFO - 2020-10-26 01:41:13 --> Output Class Initialized
INFO - 2020-10-26 01:41:13 --> Security Class Initialized
DEBUG - 2020-10-26 01:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:41:13 --> Input Class Initialized
INFO - 2020-10-26 01:41:13 --> Language Class Initialized
INFO - 2020-10-26 01:41:13 --> Language Class Initialized
INFO - 2020-10-26 01:41:13 --> Config Class Initialized
INFO - 2020-10-26 01:41:13 --> Loader Class Initialized
INFO - 2020-10-26 01:41:13 --> Helper loaded: url_helper
INFO - 2020-10-26 01:41:13 --> Helper loaded: file_helper
INFO - 2020-10-26 01:41:13 --> Helper loaded: form_helper
INFO - 2020-10-26 01:41:13 --> Helper loaded: my_helper
INFO - 2020-10-26 01:41:13 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:41:13 --> Controller Class Initialized
DEBUG - 2020-10-26 01:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 01:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:41:13 --> Final output sent to browser
DEBUG - 2020-10-26 01:41:13 --> Total execution time: 0.1975
INFO - 2020-10-26 01:41:20 --> Config Class Initialized
INFO - 2020-10-26 01:41:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:41:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:41:20 --> Utf8 Class Initialized
INFO - 2020-10-26 01:41:20 --> URI Class Initialized
INFO - 2020-10-26 01:41:20 --> Router Class Initialized
INFO - 2020-10-26 01:41:20 --> Output Class Initialized
INFO - 2020-10-26 01:41:20 --> Security Class Initialized
DEBUG - 2020-10-26 01:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:41:20 --> Input Class Initialized
INFO - 2020-10-26 01:41:20 --> Language Class Initialized
INFO - 2020-10-26 01:41:20 --> Language Class Initialized
INFO - 2020-10-26 01:41:20 --> Config Class Initialized
INFO - 2020-10-26 01:41:20 --> Loader Class Initialized
INFO - 2020-10-26 01:41:20 --> Helper loaded: url_helper
INFO - 2020-10-26 01:41:20 --> Helper loaded: file_helper
INFO - 2020-10-26 01:41:20 --> Helper loaded: form_helper
INFO - 2020-10-26 01:41:20 --> Helper loaded: my_helper
INFO - 2020-10-26 01:41:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:41:20 --> Controller Class Initialized
INFO - 2020-10-26 01:41:30 --> Config Class Initialized
INFO - 2020-10-26 01:41:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:41:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:41:30 --> Utf8 Class Initialized
INFO - 2020-10-26 01:41:30 --> URI Class Initialized
INFO - 2020-10-26 01:41:30 --> Router Class Initialized
INFO - 2020-10-26 01:41:30 --> Output Class Initialized
INFO - 2020-10-26 01:41:30 --> Security Class Initialized
DEBUG - 2020-10-26 01:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:41:30 --> Input Class Initialized
INFO - 2020-10-26 01:41:30 --> Language Class Initialized
INFO - 2020-10-26 01:41:30 --> Language Class Initialized
INFO - 2020-10-26 01:41:30 --> Config Class Initialized
INFO - 2020-10-26 01:41:30 --> Loader Class Initialized
INFO - 2020-10-26 01:41:30 --> Helper loaded: url_helper
INFO - 2020-10-26 01:41:30 --> Helper loaded: file_helper
INFO - 2020-10-26 01:41:30 --> Helper loaded: form_helper
INFO - 2020-10-26 01:41:30 --> Helper loaded: my_helper
INFO - 2020-10-26 01:41:30 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:41:30 --> Controller Class Initialized
DEBUG - 2020-10-26 01:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-10-26 01:41:30 --> Final output sent to browser
DEBUG - 2020-10-26 01:41:30 --> Total execution time: 0.1884
INFO - 2020-10-26 01:45:05 --> Config Class Initialized
INFO - 2020-10-26 01:45:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:45:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:45:05 --> Utf8 Class Initialized
INFO - 2020-10-26 01:45:05 --> URI Class Initialized
INFO - 2020-10-26 01:45:06 --> Router Class Initialized
INFO - 2020-10-26 01:45:06 --> Output Class Initialized
INFO - 2020-10-26 01:45:06 --> Security Class Initialized
DEBUG - 2020-10-26 01:45:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:45:06 --> Input Class Initialized
INFO - 2020-10-26 01:45:06 --> Language Class Initialized
INFO - 2020-10-26 01:45:06 --> Language Class Initialized
INFO - 2020-10-26 01:45:06 --> Config Class Initialized
INFO - 2020-10-26 01:45:06 --> Loader Class Initialized
INFO - 2020-10-26 01:45:06 --> Helper loaded: url_helper
INFO - 2020-10-26 01:45:06 --> Helper loaded: file_helper
INFO - 2020-10-26 01:45:06 --> Helper loaded: form_helper
INFO - 2020-10-26 01:45:06 --> Helper loaded: my_helper
INFO - 2020-10-26 01:45:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:45:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:45:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:45:06 --> Controller Class Initialized
DEBUG - 2020-10-26 01:45:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:45:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:45:06 --> Final output sent to browser
DEBUG - 2020-10-26 01:45:06 --> Total execution time: 0.2192
INFO - 2020-10-26 01:45:17 --> Config Class Initialized
INFO - 2020-10-26 01:45:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:45:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:45:17 --> Utf8 Class Initialized
INFO - 2020-10-26 01:45:17 --> URI Class Initialized
INFO - 2020-10-26 01:45:17 --> Router Class Initialized
INFO - 2020-10-26 01:45:17 --> Output Class Initialized
INFO - 2020-10-26 01:45:17 --> Security Class Initialized
DEBUG - 2020-10-26 01:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:45:17 --> Input Class Initialized
INFO - 2020-10-26 01:45:17 --> Language Class Initialized
INFO - 2020-10-26 01:45:17 --> Language Class Initialized
INFO - 2020-10-26 01:45:17 --> Config Class Initialized
INFO - 2020-10-26 01:45:17 --> Loader Class Initialized
INFO - 2020-10-26 01:45:17 --> Helper loaded: url_helper
INFO - 2020-10-26 01:45:17 --> Helper loaded: file_helper
INFO - 2020-10-26 01:45:17 --> Helper loaded: form_helper
INFO - 2020-10-26 01:45:17 --> Helper loaded: my_helper
INFO - 2020-10-26 01:45:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:45:17 --> Controller Class Initialized
ERROR - 2020-10-26 01:45:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:45:17 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:47:43 --> Config Class Initialized
INFO - 2020-10-26 01:47:43 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:47:43 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:47:43 --> Utf8 Class Initialized
INFO - 2020-10-26 01:47:43 --> URI Class Initialized
INFO - 2020-10-26 01:47:43 --> Router Class Initialized
INFO - 2020-10-26 01:47:43 --> Output Class Initialized
INFO - 2020-10-26 01:47:43 --> Security Class Initialized
DEBUG - 2020-10-26 01:47:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:47:43 --> Input Class Initialized
INFO - 2020-10-26 01:47:43 --> Language Class Initialized
INFO - 2020-10-26 01:47:43 --> Language Class Initialized
INFO - 2020-10-26 01:47:43 --> Config Class Initialized
INFO - 2020-10-26 01:47:43 --> Loader Class Initialized
INFO - 2020-10-26 01:47:43 --> Helper loaded: url_helper
INFO - 2020-10-26 01:47:43 --> Helper loaded: file_helper
INFO - 2020-10-26 01:47:43 --> Helper loaded: form_helper
INFO - 2020-10-26 01:47:43 --> Helper loaded: my_helper
INFO - 2020-10-26 01:47:43 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:47:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:47:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:47:43 --> Controller Class Initialized
DEBUG - 2020-10-26 01:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:47:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:47:43 --> Final output sent to browser
DEBUG - 2020-10-26 01:47:43 --> Total execution time: 0.2083
INFO - 2020-10-26 01:47:56 --> Config Class Initialized
INFO - 2020-10-26 01:47:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:47:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:47:56 --> Utf8 Class Initialized
INFO - 2020-10-26 01:47:56 --> URI Class Initialized
INFO - 2020-10-26 01:47:56 --> Router Class Initialized
INFO - 2020-10-26 01:47:56 --> Output Class Initialized
INFO - 2020-10-26 01:47:56 --> Security Class Initialized
DEBUG - 2020-10-26 01:47:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:47:56 --> Input Class Initialized
INFO - 2020-10-26 01:47:56 --> Language Class Initialized
INFO - 2020-10-26 01:47:56 --> Language Class Initialized
INFO - 2020-10-26 01:47:56 --> Config Class Initialized
INFO - 2020-10-26 01:47:56 --> Loader Class Initialized
INFO - 2020-10-26 01:47:56 --> Helper loaded: url_helper
INFO - 2020-10-26 01:47:56 --> Helper loaded: file_helper
INFO - 2020-10-26 01:47:56 --> Helper loaded: form_helper
INFO - 2020-10-26 01:47:56 --> Helper loaded: my_helper
INFO - 2020-10-26 01:47:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:47:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:47:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:47:56 --> Controller Class Initialized
DEBUG - 2020-10-26 01:47:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:47:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:47:56 --> Final output sent to browser
DEBUG - 2020-10-26 01:47:56 --> Total execution time: 0.1924
INFO - 2020-10-26 01:48:00 --> Config Class Initialized
INFO - 2020-10-26 01:48:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:48:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:48:00 --> Utf8 Class Initialized
INFO - 2020-10-26 01:48:00 --> URI Class Initialized
INFO - 2020-10-26 01:48:00 --> Router Class Initialized
INFO - 2020-10-26 01:48:00 --> Output Class Initialized
INFO - 2020-10-26 01:48:00 --> Security Class Initialized
DEBUG - 2020-10-26 01:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:48:00 --> Input Class Initialized
INFO - 2020-10-26 01:48:00 --> Language Class Initialized
INFO - 2020-10-26 01:48:00 --> Language Class Initialized
INFO - 2020-10-26 01:48:00 --> Config Class Initialized
INFO - 2020-10-26 01:48:00 --> Loader Class Initialized
INFO - 2020-10-26 01:48:00 --> Helper loaded: url_helper
INFO - 2020-10-26 01:48:00 --> Helper loaded: file_helper
INFO - 2020-10-26 01:48:00 --> Helper loaded: form_helper
INFO - 2020-10-26 01:48:00 --> Helper loaded: my_helper
INFO - 2020-10-26 01:48:00 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:48:00 --> Controller Class Initialized
ERROR - 2020-10-26 01:48:00 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: INSERT INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:48:00 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:55:43 --> Config Class Initialized
INFO - 2020-10-26 01:55:43 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:55:43 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:55:43 --> Utf8 Class Initialized
INFO - 2020-10-26 01:55:43 --> URI Class Initialized
INFO - 2020-10-26 01:55:43 --> Router Class Initialized
INFO - 2020-10-26 01:55:43 --> Output Class Initialized
INFO - 2020-10-26 01:55:43 --> Security Class Initialized
DEBUG - 2020-10-26 01:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:55:43 --> Input Class Initialized
INFO - 2020-10-26 01:55:43 --> Language Class Initialized
INFO - 2020-10-26 01:55:43 --> Language Class Initialized
INFO - 2020-10-26 01:55:43 --> Config Class Initialized
INFO - 2020-10-26 01:55:43 --> Loader Class Initialized
INFO - 2020-10-26 01:55:43 --> Helper loaded: url_helper
INFO - 2020-10-26 01:55:43 --> Helper loaded: file_helper
INFO - 2020-10-26 01:55:43 --> Helper loaded: form_helper
INFO - 2020-10-26 01:55:43 --> Helper loaded: my_helper
INFO - 2020-10-26 01:55:43 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:55:43 --> Controller Class Initialized
ERROR - 2020-10-26 01:55:43 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:55:43 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:55:47 --> Config Class Initialized
INFO - 2020-10-26 01:55:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:55:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:55:47 --> Utf8 Class Initialized
INFO - 2020-10-26 01:55:47 --> URI Class Initialized
INFO - 2020-10-26 01:55:47 --> Router Class Initialized
INFO - 2020-10-26 01:55:47 --> Output Class Initialized
INFO - 2020-10-26 01:55:47 --> Security Class Initialized
DEBUG - 2020-10-26 01:55:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:55:47 --> Input Class Initialized
INFO - 2020-10-26 01:55:47 --> Language Class Initialized
INFO - 2020-10-26 01:55:47 --> Language Class Initialized
INFO - 2020-10-26 01:55:47 --> Config Class Initialized
INFO - 2020-10-26 01:55:47 --> Loader Class Initialized
INFO - 2020-10-26 01:55:47 --> Helper loaded: url_helper
INFO - 2020-10-26 01:55:47 --> Helper loaded: file_helper
INFO - 2020-10-26 01:55:47 --> Helper loaded: form_helper
INFO - 2020-10-26 01:55:47 --> Helper loaded: my_helper
INFO - 2020-10-26 01:55:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:55:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:55:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:55:47 --> Controller Class Initialized
DEBUG - 2020-10-26 01:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:55:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:55:47 --> Final output sent to browser
DEBUG - 2020-10-26 01:55:47 --> Total execution time: 0.2228
INFO - 2020-10-26 01:55:48 --> Config Class Initialized
INFO - 2020-10-26 01:55:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:55:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:55:48 --> Utf8 Class Initialized
INFO - 2020-10-26 01:55:48 --> URI Class Initialized
INFO - 2020-10-26 01:55:48 --> Router Class Initialized
INFO - 2020-10-26 01:55:48 --> Output Class Initialized
INFO - 2020-10-26 01:55:48 --> Security Class Initialized
DEBUG - 2020-10-26 01:55:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:55:48 --> Input Class Initialized
INFO - 2020-10-26 01:55:48 --> Language Class Initialized
INFO - 2020-10-26 01:55:48 --> Language Class Initialized
INFO - 2020-10-26 01:55:48 --> Config Class Initialized
INFO - 2020-10-26 01:55:48 --> Loader Class Initialized
INFO - 2020-10-26 01:55:48 --> Helper loaded: url_helper
INFO - 2020-10-26 01:55:48 --> Helper loaded: file_helper
INFO - 2020-10-26 01:55:48 --> Helper loaded: form_helper
INFO - 2020-10-26 01:55:48 --> Helper loaded: my_helper
INFO - 2020-10-26 01:55:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:55:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:55:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:55:48 --> Controller Class Initialized
DEBUG - 2020-10-26 01:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 01:55:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:55:48 --> Final output sent to browser
DEBUG - 2020-10-26 01:55:48 --> Total execution time: 0.2114
INFO - 2020-10-26 01:55:49 --> Config Class Initialized
INFO - 2020-10-26 01:55:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:55:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:55:49 --> Utf8 Class Initialized
INFO - 2020-10-26 01:55:49 --> URI Class Initialized
INFO - 2020-10-26 01:55:49 --> Router Class Initialized
INFO - 2020-10-26 01:55:49 --> Output Class Initialized
INFO - 2020-10-26 01:55:49 --> Security Class Initialized
DEBUG - 2020-10-26 01:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:55:49 --> Input Class Initialized
INFO - 2020-10-26 01:55:49 --> Language Class Initialized
INFO - 2020-10-26 01:55:49 --> Language Class Initialized
INFO - 2020-10-26 01:55:49 --> Config Class Initialized
INFO - 2020-10-26 01:55:49 --> Loader Class Initialized
INFO - 2020-10-26 01:55:49 --> Helper loaded: url_helper
INFO - 2020-10-26 01:55:49 --> Helper loaded: file_helper
INFO - 2020-10-26 01:55:49 --> Helper loaded: form_helper
INFO - 2020-10-26 01:55:49 --> Helper loaded: my_helper
INFO - 2020-10-26 01:55:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:55:49 --> Controller Class Initialized
INFO - 2020-10-26 01:55:50 --> Config Class Initialized
INFO - 2020-10-26 01:55:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:55:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:55:50 --> Utf8 Class Initialized
INFO - 2020-10-26 01:55:50 --> URI Class Initialized
INFO - 2020-10-26 01:55:50 --> Router Class Initialized
INFO - 2020-10-26 01:55:50 --> Output Class Initialized
INFO - 2020-10-26 01:55:50 --> Security Class Initialized
DEBUG - 2020-10-26 01:55:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:55:50 --> Input Class Initialized
INFO - 2020-10-26 01:55:50 --> Language Class Initialized
INFO - 2020-10-26 01:55:50 --> Language Class Initialized
INFO - 2020-10-26 01:55:50 --> Config Class Initialized
INFO - 2020-10-26 01:55:50 --> Loader Class Initialized
INFO - 2020-10-26 01:55:50 --> Helper loaded: url_helper
INFO - 2020-10-26 01:55:50 --> Helper loaded: file_helper
INFO - 2020-10-26 01:55:50 --> Helper loaded: form_helper
INFO - 2020-10-26 01:55:50 --> Helper loaded: my_helper
INFO - 2020-10-26 01:55:50 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:55:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:55:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:55:50 --> Controller Class Initialized
DEBUG - 2020-10-26 01:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:55:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:55:50 --> Final output sent to browser
DEBUG - 2020-10-26 01:55:50 --> Total execution time: 0.2720
INFO - 2020-10-26 01:55:55 --> Config Class Initialized
INFO - 2020-10-26 01:55:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:55:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:55:55 --> Utf8 Class Initialized
INFO - 2020-10-26 01:55:55 --> URI Class Initialized
INFO - 2020-10-26 01:55:55 --> Router Class Initialized
INFO - 2020-10-26 01:55:55 --> Output Class Initialized
INFO - 2020-10-26 01:55:55 --> Security Class Initialized
DEBUG - 2020-10-26 01:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:55:55 --> Input Class Initialized
INFO - 2020-10-26 01:55:55 --> Language Class Initialized
INFO - 2020-10-26 01:55:55 --> Language Class Initialized
INFO - 2020-10-26 01:55:55 --> Config Class Initialized
INFO - 2020-10-26 01:55:55 --> Loader Class Initialized
INFO - 2020-10-26 01:55:55 --> Helper loaded: url_helper
INFO - 2020-10-26 01:55:55 --> Helper loaded: file_helper
INFO - 2020-10-26 01:55:55 --> Helper loaded: form_helper
INFO - 2020-10-26 01:55:55 --> Helper loaded: my_helper
INFO - 2020-10-26 01:55:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:55:55 --> Controller Class Initialized
ERROR - 2020-10-26 01:55:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:55:55 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:58:23 --> Config Class Initialized
INFO - 2020-10-26 01:58:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:58:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:58:23 --> Utf8 Class Initialized
INFO - 2020-10-26 01:58:23 --> URI Class Initialized
INFO - 2020-10-26 01:58:23 --> Router Class Initialized
INFO - 2020-10-26 01:58:23 --> Output Class Initialized
INFO - 2020-10-26 01:58:23 --> Security Class Initialized
DEBUG - 2020-10-26 01:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:58:23 --> Input Class Initialized
INFO - 2020-10-26 01:58:23 --> Language Class Initialized
INFO - 2020-10-26 01:58:23 --> Language Class Initialized
INFO - 2020-10-26 01:58:23 --> Config Class Initialized
INFO - 2020-10-26 01:58:23 --> Loader Class Initialized
INFO - 2020-10-26 01:58:23 --> Helper loaded: url_helper
INFO - 2020-10-26 01:58:23 --> Helper loaded: file_helper
INFO - 2020-10-26 01:58:23 --> Helper loaded: form_helper
INFO - 2020-10-26 01:58:23 --> Helper loaded: my_helper
INFO - 2020-10-26 01:58:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:58:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:58:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:58:23 --> Controller Class Initialized
ERROR - 2020-10-26 01:58:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:58:23 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:58:26 --> Config Class Initialized
INFO - 2020-10-26 01:58:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:58:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:58:26 --> Utf8 Class Initialized
INFO - 2020-10-26 01:58:26 --> URI Class Initialized
INFO - 2020-10-26 01:58:26 --> Router Class Initialized
INFO - 2020-10-26 01:58:26 --> Output Class Initialized
INFO - 2020-10-26 01:58:26 --> Security Class Initialized
DEBUG - 2020-10-26 01:58:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:58:26 --> Input Class Initialized
INFO - 2020-10-26 01:58:26 --> Language Class Initialized
INFO - 2020-10-26 01:58:26 --> Language Class Initialized
INFO - 2020-10-26 01:58:26 --> Config Class Initialized
INFO - 2020-10-26 01:58:26 --> Loader Class Initialized
INFO - 2020-10-26 01:58:26 --> Helper loaded: url_helper
INFO - 2020-10-26 01:58:26 --> Helper loaded: file_helper
INFO - 2020-10-26 01:58:26 --> Helper loaded: form_helper
INFO - 2020-10-26 01:58:26 --> Helper loaded: my_helper
INFO - 2020-10-26 01:58:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:58:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:58:26 --> Controller Class Initialized
DEBUG - 2020-10-26 01:58:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:58:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:58:26 --> Final output sent to browser
DEBUG - 2020-10-26 01:58:26 --> Total execution time: 0.2741
INFO - 2020-10-26 01:58:27 --> Config Class Initialized
INFO - 2020-10-26 01:58:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:58:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:58:27 --> Utf8 Class Initialized
INFO - 2020-10-26 01:58:27 --> URI Class Initialized
INFO - 2020-10-26 01:58:27 --> Router Class Initialized
INFO - 2020-10-26 01:58:27 --> Output Class Initialized
INFO - 2020-10-26 01:58:27 --> Security Class Initialized
DEBUG - 2020-10-26 01:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:58:27 --> Input Class Initialized
INFO - 2020-10-26 01:58:27 --> Language Class Initialized
INFO - 2020-10-26 01:58:27 --> Language Class Initialized
INFO - 2020-10-26 01:58:27 --> Config Class Initialized
INFO - 2020-10-26 01:58:27 --> Loader Class Initialized
INFO - 2020-10-26 01:58:27 --> Helper loaded: url_helper
INFO - 2020-10-26 01:58:27 --> Helper loaded: file_helper
INFO - 2020-10-26 01:58:27 --> Helper loaded: form_helper
INFO - 2020-10-26 01:58:27 --> Helper loaded: my_helper
INFO - 2020-10-26 01:58:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:58:27 --> Controller Class Initialized
DEBUG - 2020-10-26 01:58:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 01:58:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:58:27 --> Final output sent to browser
DEBUG - 2020-10-26 01:58:27 --> Total execution time: 0.2138
INFO - 2020-10-26 01:58:27 --> Config Class Initialized
INFO - 2020-10-26 01:58:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:58:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:58:27 --> Utf8 Class Initialized
INFO - 2020-10-26 01:58:27 --> URI Class Initialized
INFO - 2020-10-26 01:58:27 --> Router Class Initialized
INFO - 2020-10-26 01:58:27 --> Output Class Initialized
INFO - 2020-10-26 01:58:27 --> Security Class Initialized
DEBUG - 2020-10-26 01:58:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:58:27 --> Input Class Initialized
INFO - 2020-10-26 01:58:27 --> Language Class Initialized
INFO - 2020-10-26 01:58:27 --> Language Class Initialized
INFO - 2020-10-26 01:58:27 --> Config Class Initialized
INFO - 2020-10-26 01:58:27 --> Loader Class Initialized
INFO - 2020-10-26 01:58:27 --> Helper loaded: url_helper
INFO - 2020-10-26 01:58:27 --> Helper loaded: file_helper
INFO - 2020-10-26 01:58:27 --> Helper loaded: form_helper
INFO - 2020-10-26 01:58:27 --> Helper loaded: my_helper
INFO - 2020-10-26 01:58:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:58:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:58:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:58:27 --> Controller Class Initialized
INFO - 2020-10-26 01:58:29 --> Config Class Initialized
INFO - 2020-10-26 01:58:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:58:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:58:29 --> Utf8 Class Initialized
INFO - 2020-10-26 01:58:29 --> URI Class Initialized
INFO - 2020-10-26 01:58:29 --> Router Class Initialized
INFO - 2020-10-26 01:58:29 --> Output Class Initialized
INFO - 2020-10-26 01:58:29 --> Security Class Initialized
DEBUG - 2020-10-26 01:58:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:58:29 --> Input Class Initialized
INFO - 2020-10-26 01:58:29 --> Language Class Initialized
INFO - 2020-10-26 01:58:29 --> Language Class Initialized
INFO - 2020-10-26 01:58:29 --> Config Class Initialized
INFO - 2020-10-26 01:58:29 --> Loader Class Initialized
INFO - 2020-10-26 01:58:29 --> Helper loaded: url_helper
INFO - 2020-10-26 01:58:29 --> Helper loaded: file_helper
INFO - 2020-10-26 01:58:29 --> Helper loaded: form_helper
INFO - 2020-10-26 01:58:29 --> Helper loaded: my_helper
INFO - 2020-10-26 01:58:29 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:58:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:58:29 --> Controller Class Initialized
DEBUG - 2020-10-26 01:58:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:58:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:58:29 --> Final output sent to browser
DEBUG - 2020-10-26 01:58:29 --> Total execution time: 0.1817
INFO - 2020-10-26 01:58:33 --> Config Class Initialized
INFO - 2020-10-26 01:58:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:58:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:58:33 --> Utf8 Class Initialized
INFO - 2020-10-26 01:58:33 --> URI Class Initialized
INFO - 2020-10-26 01:58:33 --> Router Class Initialized
INFO - 2020-10-26 01:58:33 --> Output Class Initialized
INFO - 2020-10-26 01:58:33 --> Security Class Initialized
DEBUG - 2020-10-26 01:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:58:33 --> Input Class Initialized
INFO - 2020-10-26 01:58:33 --> Language Class Initialized
INFO - 2020-10-26 01:58:33 --> Language Class Initialized
INFO - 2020-10-26 01:58:33 --> Config Class Initialized
INFO - 2020-10-26 01:58:33 --> Loader Class Initialized
INFO - 2020-10-26 01:58:33 --> Helper loaded: url_helper
INFO - 2020-10-26 01:58:33 --> Helper loaded: file_helper
INFO - 2020-10-26 01:58:33 --> Helper loaded: form_helper
INFO - 2020-10-26 01:58:33 --> Helper loaded: my_helper
INFO - 2020-10-26 01:58:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:58:33 --> Controller Class Initialized
ERROR - 2020-10-26 01:58:33 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:58:33 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 01:59:15 --> Config Class Initialized
INFO - 2020-10-26 01:59:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:59:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:59:15 --> Utf8 Class Initialized
INFO - 2020-10-26 01:59:15 --> URI Class Initialized
INFO - 2020-10-26 01:59:15 --> Router Class Initialized
INFO - 2020-10-26 01:59:15 --> Output Class Initialized
INFO - 2020-10-26 01:59:15 --> Security Class Initialized
DEBUG - 2020-10-26 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:59:15 --> Input Class Initialized
INFO - 2020-10-26 01:59:15 --> Language Class Initialized
INFO - 2020-10-26 01:59:15 --> Language Class Initialized
INFO - 2020-10-26 01:59:15 --> Config Class Initialized
INFO - 2020-10-26 01:59:15 --> Loader Class Initialized
INFO - 2020-10-26 01:59:15 --> Helper loaded: url_helper
INFO - 2020-10-26 01:59:15 --> Helper loaded: file_helper
INFO - 2020-10-26 01:59:15 --> Helper loaded: form_helper
INFO - 2020-10-26 01:59:15 --> Helper loaded: my_helper
INFO - 2020-10-26 01:59:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:59:15 --> Controller Class Initialized
DEBUG - 2020-10-26 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:59:15 --> Final output sent to browser
DEBUG - 2020-10-26 01:59:15 --> Total execution time: 0.2015
INFO - 2020-10-26 01:59:15 --> Config Class Initialized
INFO - 2020-10-26 01:59:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:59:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:59:15 --> Utf8 Class Initialized
INFO - 2020-10-26 01:59:15 --> URI Class Initialized
INFO - 2020-10-26 01:59:15 --> Router Class Initialized
INFO - 2020-10-26 01:59:15 --> Output Class Initialized
INFO - 2020-10-26 01:59:15 --> Security Class Initialized
DEBUG - 2020-10-26 01:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:59:15 --> Input Class Initialized
INFO - 2020-10-26 01:59:15 --> Language Class Initialized
INFO - 2020-10-26 01:59:15 --> Language Class Initialized
INFO - 2020-10-26 01:59:15 --> Config Class Initialized
INFO - 2020-10-26 01:59:15 --> Loader Class Initialized
INFO - 2020-10-26 01:59:15 --> Helper loaded: url_helper
INFO - 2020-10-26 01:59:15 --> Helper loaded: file_helper
INFO - 2020-10-26 01:59:15 --> Helper loaded: form_helper
INFO - 2020-10-26 01:59:15 --> Helper loaded: my_helper
INFO - 2020-10-26 01:59:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:59:15 --> Controller Class Initialized
DEBUG - 2020-10-26 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 01:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:59:16 --> Final output sent to browser
DEBUG - 2020-10-26 01:59:16 --> Total execution time: 0.2162
INFO - 2020-10-26 01:59:26 --> Config Class Initialized
INFO - 2020-10-26 01:59:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:59:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:59:26 --> Utf8 Class Initialized
INFO - 2020-10-26 01:59:26 --> URI Class Initialized
INFO - 2020-10-26 01:59:26 --> Router Class Initialized
INFO - 2020-10-26 01:59:26 --> Output Class Initialized
INFO - 2020-10-26 01:59:26 --> Security Class Initialized
DEBUG - 2020-10-26 01:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:59:26 --> Input Class Initialized
INFO - 2020-10-26 01:59:26 --> Language Class Initialized
INFO - 2020-10-26 01:59:26 --> Language Class Initialized
INFO - 2020-10-26 01:59:26 --> Config Class Initialized
INFO - 2020-10-26 01:59:26 --> Loader Class Initialized
INFO - 2020-10-26 01:59:26 --> Helper loaded: url_helper
INFO - 2020-10-26 01:59:26 --> Helper loaded: file_helper
INFO - 2020-10-26 01:59:26 --> Helper loaded: form_helper
INFO - 2020-10-26 01:59:26 --> Helper loaded: my_helper
INFO - 2020-10-26 01:59:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:59:26 --> Controller Class Initialized
INFO - 2020-10-26 01:59:34 --> Config Class Initialized
INFO - 2020-10-26 01:59:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:59:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:59:34 --> Utf8 Class Initialized
INFO - 2020-10-26 01:59:34 --> URI Class Initialized
INFO - 2020-10-26 01:59:34 --> Router Class Initialized
INFO - 2020-10-26 01:59:34 --> Output Class Initialized
INFO - 2020-10-26 01:59:34 --> Security Class Initialized
DEBUG - 2020-10-26 01:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:59:34 --> Input Class Initialized
INFO - 2020-10-26 01:59:34 --> Language Class Initialized
INFO - 2020-10-26 01:59:34 --> Language Class Initialized
INFO - 2020-10-26 01:59:34 --> Config Class Initialized
INFO - 2020-10-26 01:59:34 --> Loader Class Initialized
INFO - 2020-10-26 01:59:34 --> Helper loaded: url_helper
INFO - 2020-10-26 01:59:34 --> Helper loaded: file_helper
INFO - 2020-10-26 01:59:34 --> Helper loaded: form_helper
INFO - 2020-10-26 01:59:34 --> Helper loaded: my_helper
INFO - 2020-10-26 01:59:34 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:59:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:59:34 --> Controller Class Initialized
DEBUG - 2020-10-26 01:59:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 01:59:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 01:59:34 --> Final output sent to browser
DEBUG - 2020-10-26 01:59:34 --> Total execution time: 0.1964
INFO - 2020-10-26 01:59:44 --> Config Class Initialized
INFO - 2020-10-26 01:59:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 01:59:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 01:59:44 --> Utf8 Class Initialized
INFO - 2020-10-26 01:59:44 --> URI Class Initialized
INFO - 2020-10-26 01:59:44 --> Router Class Initialized
INFO - 2020-10-26 01:59:44 --> Output Class Initialized
INFO - 2020-10-26 01:59:44 --> Security Class Initialized
DEBUG - 2020-10-26 01:59:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 01:59:44 --> Input Class Initialized
INFO - 2020-10-26 01:59:44 --> Language Class Initialized
INFO - 2020-10-26 01:59:44 --> Language Class Initialized
INFO - 2020-10-26 01:59:44 --> Config Class Initialized
INFO - 2020-10-26 01:59:44 --> Loader Class Initialized
INFO - 2020-10-26 01:59:44 --> Helper loaded: url_helper
INFO - 2020-10-26 01:59:44 --> Helper loaded: file_helper
INFO - 2020-10-26 01:59:44 --> Helper loaded: form_helper
INFO - 2020-10-26 01:59:44 --> Helper loaded: my_helper
INFO - 2020-10-26 01:59:44 --> Database Driver Class Initialized
DEBUG - 2020-10-26 01:59:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 01:59:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 01:59:44 --> Controller Class Initialized
ERROR - 2020-10-26 01:59:45 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 01:59:45 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 02:01:01 --> Config Class Initialized
INFO - 2020-10-26 02:01:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:01 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:01 --> URI Class Initialized
INFO - 2020-10-26 02:01:01 --> Router Class Initialized
INFO - 2020-10-26 02:01:01 --> Output Class Initialized
INFO - 2020-10-26 02:01:01 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:01 --> Input Class Initialized
INFO - 2020-10-26 02:01:01 --> Language Class Initialized
INFO - 2020-10-26 02:01:01 --> Language Class Initialized
INFO - 2020-10-26 02:01:01 --> Config Class Initialized
INFO - 2020-10-26 02:01:01 --> Loader Class Initialized
INFO - 2020-10-26 02:01:01 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:01 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:01 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:01 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:01 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:01 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 02:01:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:01 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:01 --> Total execution time: 0.2203
INFO - 2020-10-26 02:01:07 --> Config Class Initialized
INFO - 2020-10-26 02:01:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:07 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:07 --> URI Class Initialized
INFO - 2020-10-26 02:01:07 --> Router Class Initialized
INFO - 2020-10-26 02:01:07 --> Output Class Initialized
INFO - 2020-10-26 02:01:07 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:07 --> Input Class Initialized
INFO - 2020-10-26 02:01:07 --> Language Class Initialized
INFO - 2020-10-26 02:01:07 --> Language Class Initialized
INFO - 2020-10-26 02:01:07 --> Config Class Initialized
INFO - 2020-10-26 02:01:07 --> Loader Class Initialized
INFO - 2020-10-26 02:01:07 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:07 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:07 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:07 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:07 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 02:01:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:07 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:07 --> Total execution time: 0.2133
INFO - 2020-10-26 02:01:07 --> Config Class Initialized
INFO - 2020-10-26 02:01:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:07 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:07 --> URI Class Initialized
INFO - 2020-10-26 02:01:07 --> Router Class Initialized
INFO - 2020-10-26 02:01:07 --> Output Class Initialized
INFO - 2020-10-26 02:01:07 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:07 --> Input Class Initialized
INFO - 2020-10-26 02:01:07 --> Language Class Initialized
INFO - 2020-10-26 02:01:07 --> Language Class Initialized
INFO - 2020-10-26 02:01:07 --> Config Class Initialized
INFO - 2020-10-26 02:01:07 --> Loader Class Initialized
INFO - 2020-10-26 02:01:07 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:07 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:07 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:07 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:07 --> Controller Class Initialized
INFO - 2020-10-26 02:01:19 --> Config Class Initialized
INFO - 2020-10-26 02:01:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:19 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:19 --> URI Class Initialized
INFO - 2020-10-26 02:01:19 --> Router Class Initialized
INFO - 2020-10-26 02:01:19 --> Output Class Initialized
INFO - 2020-10-26 02:01:19 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:19 --> Input Class Initialized
INFO - 2020-10-26 02:01:19 --> Language Class Initialized
INFO - 2020-10-26 02:01:19 --> Language Class Initialized
INFO - 2020-10-26 02:01:19 --> Config Class Initialized
INFO - 2020-10-26 02:01:19 --> Loader Class Initialized
INFO - 2020-10-26 02:01:19 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:19 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:19 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:19 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:19 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:19 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-26 02:01:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:19 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:19 --> Total execution time: 0.2022
INFO - 2020-10-26 02:01:33 --> Config Class Initialized
INFO - 2020-10-26 02:01:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:33 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:33 --> URI Class Initialized
INFO - 2020-10-26 02:01:33 --> Router Class Initialized
INFO - 2020-10-26 02:01:33 --> Output Class Initialized
INFO - 2020-10-26 02:01:33 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:33 --> Input Class Initialized
INFO - 2020-10-26 02:01:33 --> Language Class Initialized
INFO - 2020-10-26 02:01:33 --> Language Class Initialized
INFO - 2020-10-26 02:01:33 --> Config Class Initialized
INFO - 2020-10-26 02:01:33 --> Loader Class Initialized
INFO - 2020-10-26 02:01:33 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:33 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:33 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:33 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:33 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-26 02:01:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:33 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:33 --> Total execution time: 0.3165
INFO - 2020-10-26 02:01:35 --> Config Class Initialized
INFO - 2020-10-26 02:01:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:35 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:35 --> URI Class Initialized
INFO - 2020-10-26 02:01:35 --> Router Class Initialized
INFO - 2020-10-26 02:01:36 --> Output Class Initialized
INFO - 2020-10-26 02:01:36 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:36 --> Input Class Initialized
INFO - 2020-10-26 02:01:36 --> Language Class Initialized
INFO - 2020-10-26 02:01:36 --> Language Class Initialized
INFO - 2020-10-26 02:01:36 --> Config Class Initialized
INFO - 2020-10-26 02:01:36 --> Loader Class Initialized
INFO - 2020-10-26 02:01:36 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:36 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:36 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:36 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:36 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-10-26 02:01:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:36 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:36 --> Total execution time: 0.2979
INFO - 2020-10-26 02:01:38 --> Config Class Initialized
INFO - 2020-10-26 02:01:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:38 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:38 --> URI Class Initialized
INFO - 2020-10-26 02:01:38 --> Router Class Initialized
INFO - 2020-10-26 02:01:38 --> Output Class Initialized
INFO - 2020-10-26 02:01:38 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:38 --> Input Class Initialized
INFO - 2020-10-26 02:01:38 --> Language Class Initialized
INFO - 2020-10-26 02:01:38 --> Language Class Initialized
INFO - 2020-10-26 02:01:38 --> Config Class Initialized
INFO - 2020-10-26 02:01:38 --> Loader Class Initialized
INFO - 2020-10-26 02:01:38 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:38 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:38 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:38 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:38 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:38 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-10-26 02:01:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:38 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:38 --> Total execution time: 0.2407
INFO - 2020-10-26 02:01:40 --> Config Class Initialized
INFO - 2020-10-26 02:01:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:41 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:41 --> URI Class Initialized
INFO - 2020-10-26 02:01:41 --> Router Class Initialized
INFO - 2020-10-26 02:01:41 --> Output Class Initialized
INFO - 2020-10-26 02:01:41 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:41 --> Input Class Initialized
INFO - 2020-10-26 02:01:41 --> Language Class Initialized
INFO - 2020-10-26 02:01:41 --> Language Class Initialized
INFO - 2020-10-26 02:01:41 --> Config Class Initialized
INFO - 2020-10-26 02:01:41 --> Loader Class Initialized
INFO - 2020-10-26 02:01:41 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:41 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:41 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:41 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:41 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-10-26 02:01:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:41 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:41 --> Total execution time: 0.2245
INFO - 2020-10-26 02:01:47 --> Config Class Initialized
INFO - 2020-10-26 02:01:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:47 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:47 --> URI Class Initialized
INFO - 2020-10-26 02:01:47 --> Router Class Initialized
INFO - 2020-10-26 02:01:47 --> Output Class Initialized
INFO - 2020-10-26 02:01:47 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:47 --> Input Class Initialized
INFO - 2020-10-26 02:01:47 --> Language Class Initialized
INFO - 2020-10-26 02:01:47 --> Language Class Initialized
INFO - 2020-10-26 02:01:47 --> Config Class Initialized
INFO - 2020-10-26 02:01:47 --> Loader Class Initialized
INFO - 2020-10-26 02:01:47 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:47 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:47 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:47 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:47 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-26 02:01:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:47 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:47 --> Total execution time: 0.1971
INFO - 2020-10-26 02:01:56 --> Config Class Initialized
INFO - 2020-10-26 02:01:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:56 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:56 --> URI Class Initialized
INFO - 2020-10-26 02:01:56 --> Router Class Initialized
INFO - 2020-10-26 02:01:56 --> Output Class Initialized
INFO - 2020-10-26 02:01:56 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:56 --> Input Class Initialized
INFO - 2020-10-26 02:01:56 --> Language Class Initialized
INFO - 2020-10-26 02:01:56 --> Language Class Initialized
INFO - 2020-10-26 02:01:56 --> Config Class Initialized
INFO - 2020-10-26 02:01:56 --> Loader Class Initialized
INFO - 2020-10-26 02:01:56 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:56 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:56 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:56 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:56 --> Controller Class Initialized
INFO - 2020-10-26 02:01:56 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:01:56 --> Config Class Initialized
INFO - 2020-10-26 02:01:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:01:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:01:56 --> Utf8 Class Initialized
INFO - 2020-10-26 02:01:56 --> URI Class Initialized
INFO - 2020-10-26 02:01:56 --> Router Class Initialized
INFO - 2020-10-26 02:01:56 --> Output Class Initialized
INFO - 2020-10-26 02:01:56 --> Security Class Initialized
DEBUG - 2020-10-26 02:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:01:56 --> Input Class Initialized
INFO - 2020-10-26 02:01:56 --> Language Class Initialized
INFO - 2020-10-26 02:01:56 --> Language Class Initialized
INFO - 2020-10-26 02:01:56 --> Config Class Initialized
INFO - 2020-10-26 02:01:56 --> Loader Class Initialized
INFO - 2020-10-26 02:01:56 --> Helper loaded: url_helper
INFO - 2020-10-26 02:01:56 --> Helper loaded: file_helper
INFO - 2020-10-26 02:01:56 --> Helper loaded: form_helper
INFO - 2020-10-26 02:01:56 --> Helper loaded: my_helper
INFO - 2020-10-26 02:01:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:01:56 --> Controller Class Initialized
DEBUG - 2020-10-26 02:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 02:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:01:56 --> Final output sent to browser
DEBUG - 2020-10-26 02:01:56 --> Total execution time: 0.1962
INFO - 2020-10-26 02:02:03 --> Config Class Initialized
INFO - 2020-10-26 02:02:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:03 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:03 --> URI Class Initialized
INFO - 2020-10-26 02:02:03 --> Router Class Initialized
INFO - 2020-10-26 02:02:03 --> Output Class Initialized
INFO - 2020-10-26 02:02:03 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:03 --> Input Class Initialized
INFO - 2020-10-26 02:02:03 --> Language Class Initialized
INFO - 2020-10-26 02:02:03 --> Language Class Initialized
INFO - 2020-10-26 02:02:03 --> Config Class Initialized
INFO - 2020-10-26 02:02:03 --> Loader Class Initialized
INFO - 2020-10-26 02:02:03 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:03 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:03 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:03 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:03 --> Controller Class Initialized
INFO - 2020-10-26 02:02:03 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:02:03 --> Final output sent to browser
DEBUG - 2020-10-26 02:02:03 --> Total execution time: 0.2005
INFO - 2020-10-26 02:02:04 --> Config Class Initialized
INFO - 2020-10-26 02:02:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:05 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:05 --> URI Class Initialized
INFO - 2020-10-26 02:02:05 --> Router Class Initialized
INFO - 2020-10-26 02:02:05 --> Output Class Initialized
INFO - 2020-10-26 02:02:05 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:05 --> Input Class Initialized
INFO - 2020-10-26 02:02:05 --> Language Class Initialized
INFO - 2020-10-26 02:02:05 --> Language Class Initialized
INFO - 2020-10-26 02:02:05 --> Config Class Initialized
INFO - 2020-10-26 02:02:05 --> Loader Class Initialized
INFO - 2020-10-26 02:02:05 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:05 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:05 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:05 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:05 --> Controller Class Initialized
DEBUG - 2020-10-26 02:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 02:02:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:02:05 --> Final output sent to browser
DEBUG - 2020-10-26 02:02:05 --> Total execution time: 0.2380
INFO - 2020-10-26 02:02:13 --> Config Class Initialized
INFO - 2020-10-26 02:02:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:13 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:13 --> URI Class Initialized
INFO - 2020-10-26 02:02:13 --> Router Class Initialized
INFO - 2020-10-26 02:02:13 --> Output Class Initialized
INFO - 2020-10-26 02:02:13 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:13 --> Input Class Initialized
INFO - 2020-10-26 02:02:13 --> Language Class Initialized
INFO - 2020-10-26 02:02:13 --> Language Class Initialized
INFO - 2020-10-26 02:02:13 --> Config Class Initialized
INFO - 2020-10-26 02:02:13 --> Loader Class Initialized
INFO - 2020-10-26 02:02:13 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:13 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:13 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:13 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:13 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:13 --> Controller Class Initialized
DEBUG - 2020-10-26 02:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-26 02:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:02:13 --> Final output sent to browser
DEBUG - 2020-10-26 02:02:13 --> Total execution time: 0.2269
INFO - 2020-10-26 02:02:14 --> Config Class Initialized
INFO - 2020-10-26 02:02:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:14 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:14 --> URI Class Initialized
INFO - 2020-10-26 02:02:14 --> Router Class Initialized
INFO - 2020-10-26 02:02:14 --> Output Class Initialized
INFO - 2020-10-26 02:02:14 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:14 --> Input Class Initialized
INFO - 2020-10-26 02:02:14 --> Language Class Initialized
INFO - 2020-10-26 02:02:14 --> Language Class Initialized
INFO - 2020-10-26 02:02:14 --> Config Class Initialized
INFO - 2020-10-26 02:02:14 --> Loader Class Initialized
INFO - 2020-10-26 02:02:14 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:14 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:14 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:14 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:14 --> Controller Class Initialized
INFO - 2020-10-26 02:02:20 --> Config Class Initialized
INFO - 2020-10-26 02:02:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:20 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:20 --> URI Class Initialized
INFO - 2020-10-26 02:02:20 --> Router Class Initialized
INFO - 2020-10-26 02:02:20 --> Output Class Initialized
INFO - 2020-10-26 02:02:20 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:20 --> Input Class Initialized
INFO - 2020-10-26 02:02:20 --> Language Class Initialized
INFO - 2020-10-26 02:02:20 --> Language Class Initialized
INFO - 2020-10-26 02:02:20 --> Config Class Initialized
INFO - 2020-10-26 02:02:20 --> Loader Class Initialized
INFO - 2020-10-26 02:02:20 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:20 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:20 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:20 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:20 --> Controller Class Initialized
DEBUG - 2020-10-26 02:02:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 02:02:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:02:20 --> Final output sent to browser
DEBUG - 2020-10-26 02:02:20 --> Total execution time: 0.2270
INFO - 2020-10-26 02:02:20 --> Config Class Initialized
INFO - 2020-10-26 02:02:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:20 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:20 --> URI Class Initialized
INFO - 2020-10-26 02:02:20 --> Router Class Initialized
INFO - 2020-10-26 02:02:20 --> Output Class Initialized
INFO - 2020-10-26 02:02:20 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:20 --> Input Class Initialized
INFO - 2020-10-26 02:02:20 --> Language Class Initialized
INFO - 2020-10-26 02:02:20 --> Language Class Initialized
INFO - 2020-10-26 02:02:20 --> Config Class Initialized
INFO - 2020-10-26 02:02:20 --> Loader Class Initialized
INFO - 2020-10-26 02:02:20 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:20 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:20 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:20 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:21 --> Controller Class Initialized
INFO - 2020-10-26 02:02:27 --> Config Class Initialized
INFO - 2020-10-26 02:02:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:27 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:27 --> URI Class Initialized
INFO - 2020-10-26 02:02:27 --> Router Class Initialized
INFO - 2020-10-26 02:02:27 --> Output Class Initialized
INFO - 2020-10-26 02:02:27 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:27 --> Input Class Initialized
INFO - 2020-10-26 02:02:27 --> Language Class Initialized
INFO - 2020-10-26 02:02:27 --> Language Class Initialized
INFO - 2020-10-26 02:02:27 --> Config Class Initialized
INFO - 2020-10-26 02:02:27 --> Loader Class Initialized
INFO - 2020-10-26 02:02:27 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:27 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:27 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:27 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:27 --> Controller Class Initialized
DEBUG - 2020-10-26 02:02:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 02:02:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:02:27 --> Final output sent to browser
DEBUG - 2020-10-26 02:02:27 --> Total execution time: 0.3273
INFO - 2020-10-26 02:02:34 --> Config Class Initialized
INFO - 2020-10-26 02:02:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:34 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:34 --> URI Class Initialized
INFO - 2020-10-26 02:02:34 --> Router Class Initialized
INFO - 2020-10-26 02:02:34 --> Output Class Initialized
INFO - 2020-10-26 02:02:34 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:34 --> Input Class Initialized
INFO - 2020-10-26 02:02:34 --> Language Class Initialized
INFO - 2020-10-26 02:02:34 --> Language Class Initialized
INFO - 2020-10-26 02:02:34 --> Config Class Initialized
INFO - 2020-10-26 02:02:34 --> Loader Class Initialized
INFO - 2020-10-26 02:02:34 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:34 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:34 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:34 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:34 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:34 --> Controller Class Initialized
DEBUG - 2020-10-26 02:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 02:02:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:02:34 --> Final output sent to browser
DEBUG - 2020-10-26 02:02:34 --> Total execution time: 0.2100
INFO - 2020-10-26 02:02:34 --> Config Class Initialized
INFO - 2020-10-26 02:02:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:34 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:34 --> URI Class Initialized
INFO - 2020-10-26 02:02:34 --> Router Class Initialized
INFO - 2020-10-26 02:02:34 --> Output Class Initialized
INFO - 2020-10-26 02:02:34 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:34 --> Input Class Initialized
INFO - 2020-10-26 02:02:34 --> Language Class Initialized
INFO - 2020-10-26 02:02:34 --> Language Class Initialized
INFO - 2020-10-26 02:02:34 --> Config Class Initialized
INFO - 2020-10-26 02:02:34 --> Loader Class Initialized
INFO - 2020-10-26 02:02:34 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:34 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:34 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:34 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:34 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:34 --> Controller Class Initialized
INFO - 2020-10-26 02:02:36 --> Config Class Initialized
INFO - 2020-10-26 02:02:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:02:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:02:36 --> Utf8 Class Initialized
INFO - 2020-10-26 02:02:36 --> URI Class Initialized
INFO - 2020-10-26 02:02:36 --> Router Class Initialized
INFO - 2020-10-26 02:02:36 --> Output Class Initialized
INFO - 2020-10-26 02:02:36 --> Security Class Initialized
DEBUG - 2020-10-26 02:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:02:36 --> Input Class Initialized
INFO - 2020-10-26 02:02:36 --> Language Class Initialized
INFO - 2020-10-26 02:02:36 --> Language Class Initialized
INFO - 2020-10-26 02:02:36 --> Config Class Initialized
INFO - 2020-10-26 02:02:36 --> Loader Class Initialized
INFO - 2020-10-26 02:02:36 --> Helper loaded: url_helper
INFO - 2020-10-26 02:02:36 --> Helper loaded: file_helper
INFO - 2020-10-26 02:02:36 --> Helper loaded: form_helper
INFO - 2020-10-26 02:02:36 --> Helper loaded: my_helper
INFO - 2020-10-26 02:02:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:02:36 --> Controller Class Initialized
DEBUG - 2020-10-26 02:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-10-26 02:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:02:36 --> Final output sent to browser
DEBUG - 2020-10-26 02:02:36 --> Total execution time: 0.2336
INFO - 2020-10-26 02:09:45 --> Config Class Initialized
INFO - 2020-10-26 02:09:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:09:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:09:45 --> Utf8 Class Initialized
INFO - 2020-10-26 02:09:45 --> URI Class Initialized
INFO - 2020-10-26 02:09:45 --> Router Class Initialized
INFO - 2020-10-26 02:09:45 --> Output Class Initialized
INFO - 2020-10-26 02:09:45 --> Security Class Initialized
DEBUG - 2020-10-26 02:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:09:45 --> Input Class Initialized
INFO - 2020-10-26 02:09:45 --> Language Class Initialized
INFO - 2020-10-26 02:09:45 --> Language Class Initialized
INFO - 2020-10-26 02:09:45 --> Config Class Initialized
INFO - 2020-10-26 02:09:45 --> Loader Class Initialized
INFO - 2020-10-26 02:09:45 --> Helper loaded: url_helper
INFO - 2020-10-26 02:09:45 --> Helper loaded: file_helper
INFO - 2020-10-26 02:09:45 --> Helper loaded: form_helper
INFO - 2020-10-26 02:09:45 --> Helper loaded: my_helper
INFO - 2020-10-26 02:09:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:09:45 --> Controller Class Initialized
INFO - 2020-10-26 02:09:45 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:09:45 --> Config Class Initialized
INFO - 2020-10-26 02:09:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:09:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:09:45 --> Utf8 Class Initialized
INFO - 2020-10-26 02:09:45 --> URI Class Initialized
INFO - 2020-10-26 02:09:45 --> Router Class Initialized
INFO - 2020-10-26 02:09:45 --> Output Class Initialized
INFO - 2020-10-26 02:09:45 --> Security Class Initialized
DEBUG - 2020-10-26 02:09:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:09:45 --> Input Class Initialized
INFO - 2020-10-26 02:09:45 --> Language Class Initialized
INFO - 2020-10-26 02:09:45 --> Language Class Initialized
INFO - 2020-10-26 02:09:45 --> Config Class Initialized
INFO - 2020-10-26 02:09:45 --> Loader Class Initialized
INFO - 2020-10-26 02:09:45 --> Helper loaded: url_helper
INFO - 2020-10-26 02:09:45 --> Helper loaded: file_helper
INFO - 2020-10-26 02:09:45 --> Helper loaded: form_helper
INFO - 2020-10-26 02:09:45 --> Helper loaded: my_helper
INFO - 2020-10-26 02:09:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:09:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:09:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:09:45 --> Controller Class Initialized
DEBUG - 2020-10-26 02:09:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 02:09:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:09:45 --> Final output sent to browser
DEBUG - 2020-10-26 02:09:45 --> Total execution time: 0.1777
INFO - 2020-10-26 02:10:20 --> Config Class Initialized
INFO - 2020-10-26 02:10:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:10:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:10:20 --> Utf8 Class Initialized
INFO - 2020-10-26 02:10:20 --> URI Class Initialized
INFO - 2020-10-26 02:10:20 --> Router Class Initialized
INFO - 2020-10-26 02:10:20 --> Output Class Initialized
INFO - 2020-10-26 02:10:20 --> Security Class Initialized
DEBUG - 2020-10-26 02:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:10:20 --> Input Class Initialized
INFO - 2020-10-26 02:10:20 --> Language Class Initialized
INFO - 2020-10-26 02:10:20 --> Language Class Initialized
INFO - 2020-10-26 02:10:20 --> Config Class Initialized
INFO - 2020-10-26 02:10:20 --> Loader Class Initialized
INFO - 2020-10-26 02:10:20 --> Helper loaded: url_helper
INFO - 2020-10-26 02:10:20 --> Helper loaded: file_helper
INFO - 2020-10-26 02:10:20 --> Helper loaded: form_helper
INFO - 2020-10-26 02:10:20 --> Helper loaded: my_helper
INFO - 2020-10-26 02:10:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:10:20 --> Controller Class Initialized
INFO - 2020-10-26 02:10:20 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:10:20 --> Final output sent to browser
DEBUG - 2020-10-26 02:10:20 --> Total execution time: 0.2321
INFO - 2020-10-26 02:10:22 --> Config Class Initialized
INFO - 2020-10-26 02:10:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:10:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:10:22 --> Utf8 Class Initialized
INFO - 2020-10-26 02:10:22 --> URI Class Initialized
INFO - 2020-10-26 02:10:22 --> Router Class Initialized
INFO - 2020-10-26 02:10:22 --> Output Class Initialized
INFO - 2020-10-26 02:10:22 --> Security Class Initialized
DEBUG - 2020-10-26 02:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:10:22 --> Input Class Initialized
INFO - 2020-10-26 02:10:22 --> Language Class Initialized
INFO - 2020-10-26 02:10:22 --> Language Class Initialized
INFO - 2020-10-26 02:10:22 --> Config Class Initialized
INFO - 2020-10-26 02:10:22 --> Loader Class Initialized
INFO - 2020-10-26 02:10:22 --> Helper loaded: url_helper
INFO - 2020-10-26 02:10:22 --> Helper loaded: file_helper
INFO - 2020-10-26 02:10:22 --> Helper loaded: form_helper
INFO - 2020-10-26 02:10:22 --> Helper loaded: my_helper
INFO - 2020-10-26 02:10:22 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:10:22 --> Controller Class Initialized
DEBUG - 2020-10-26 02:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 02:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:10:22 --> Final output sent to browser
DEBUG - 2020-10-26 02:10:22 --> Total execution time: 0.2228
INFO - 2020-10-26 02:10:36 --> Config Class Initialized
INFO - 2020-10-26 02:10:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:10:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:10:36 --> Utf8 Class Initialized
INFO - 2020-10-26 02:10:36 --> URI Class Initialized
INFO - 2020-10-26 02:10:36 --> Router Class Initialized
INFO - 2020-10-26 02:10:36 --> Output Class Initialized
INFO - 2020-10-26 02:10:36 --> Security Class Initialized
DEBUG - 2020-10-26 02:10:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:10:36 --> Input Class Initialized
INFO - 2020-10-26 02:10:36 --> Language Class Initialized
INFO - 2020-10-26 02:10:36 --> Language Class Initialized
INFO - 2020-10-26 02:10:36 --> Config Class Initialized
INFO - 2020-10-26 02:10:36 --> Loader Class Initialized
INFO - 2020-10-26 02:10:36 --> Helper loaded: url_helper
INFO - 2020-10-26 02:10:36 --> Helper loaded: file_helper
INFO - 2020-10-26 02:10:36 --> Helper loaded: form_helper
INFO - 2020-10-26 02:10:36 --> Helper loaded: my_helper
INFO - 2020-10-26 02:10:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:10:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:10:36 --> Controller Class Initialized
DEBUG - 2020-10-26 02:10:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 02:10:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:10:36 --> Final output sent to browser
DEBUG - 2020-10-26 02:10:36 --> Total execution time: 0.2500
INFO - 2020-10-26 02:10:38 --> Config Class Initialized
INFO - 2020-10-26 02:10:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:10:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:10:38 --> Utf8 Class Initialized
INFO - 2020-10-26 02:10:38 --> URI Class Initialized
INFO - 2020-10-26 02:10:38 --> Router Class Initialized
INFO - 2020-10-26 02:10:38 --> Output Class Initialized
INFO - 2020-10-26 02:10:38 --> Security Class Initialized
DEBUG - 2020-10-26 02:10:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:10:38 --> Input Class Initialized
INFO - 2020-10-26 02:10:38 --> Language Class Initialized
INFO - 2020-10-26 02:10:38 --> Language Class Initialized
INFO - 2020-10-26 02:10:38 --> Config Class Initialized
INFO - 2020-10-26 02:10:38 --> Loader Class Initialized
INFO - 2020-10-26 02:10:38 --> Helper loaded: url_helper
INFO - 2020-10-26 02:10:38 --> Helper loaded: file_helper
INFO - 2020-10-26 02:10:38 --> Helper loaded: form_helper
INFO - 2020-10-26 02:10:38 --> Helper loaded: my_helper
INFO - 2020-10-26 02:10:38 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:10:39 --> Controller Class Initialized
DEBUG - 2020-10-26 02:10:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 02:10:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:10:39 --> Final output sent to browser
DEBUG - 2020-10-26 02:10:39 --> Total execution time: 0.2027
INFO - 2020-10-26 02:10:39 --> Config Class Initialized
INFO - 2020-10-26 02:10:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:10:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:10:39 --> Utf8 Class Initialized
INFO - 2020-10-26 02:10:39 --> URI Class Initialized
INFO - 2020-10-26 02:10:39 --> Router Class Initialized
INFO - 2020-10-26 02:10:39 --> Output Class Initialized
INFO - 2020-10-26 02:10:39 --> Security Class Initialized
DEBUG - 2020-10-26 02:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:10:39 --> Input Class Initialized
INFO - 2020-10-26 02:10:39 --> Language Class Initialized
INFO - 2020-10-26 02:10:39 --> Language Class Initialized
INFO - 2020-10-26 02:10:39 --> Config Class Initialized
INFO - 2020-10-26 02:10:39 --> Loader Class Initialized
INFO - 2020-10-26 02:10:39 --> Helper loaded: url_helper
INFO - 2020-10-26 02:10:39 --> Helper loaded: file_helper
INFO - 2020-10-26 02:10:39 --> Helper loaded: form_helper
INFO - 2020-10-26 02:10:39 --> Helper loaded: my_helper
INFO - 2020-10-26 02:10:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:10:39 --> Controller Class Initialized
INFO - 2020-10-26 02:20:12 --> Config Class Initialized
INFO - 2020-10-26 02:20:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:20:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:20:12 --> Utf8 Class Initialized
INFO - 2020-10-26 02:20:12 --> URI Class Initialized
INFO - 2020-10-26 02:20:12 --> Router Class Initialized
INFO - 2020-10-26 02:20:12 --> Output Class Initialized
INFO - 2020-10-26 02:20:12 --> Security Class Initialized
DEBUG - 2020-10-26 02:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:20:12 --> Input Class Initialized
INFO - 2020-10-26 02:20:12 --> Language Class Initialized
INFO - 2020-10-26 02:20:12 --> Language Class Initialized
INFO - 2020-10-26 02:20:12 --> Config Class Initialized
INFO - 2020-10-26 02:20:12 --> Loader Class Initialized
INFO - 2020-10-26 02:20:12 --> Helper loaded: url_helper
INFO - 2020-10-26 02:20:12 --> Helper loaded: file_helper
INFO - 2020-10-26 02:20:12 --> Helper loaded: form_helper
INFO - 2020-10-26 02:20:12 --> Helper loaded: my_helper
INFO - 2020-10-26 02:20:12 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:20:12 --> Controller Class Initialized
DEBUG - 2020-10-26 02:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 02:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:20:12 --> Final output sent to browser
DEBUG - 2020-10-26 02:20:12 --> Total execution time: 0.2092
INFO - 2020-10-26 02:20:18 --> Config Class Initialized
INFO - 2020-10-26 02:20:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:20:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:20:18 --> Utf8 Class Initialized
INFO - 2020-10-26 02:20:18 --> URI Class Initialized
INFO - 2020-10-26 02:20:18 --> Router Class Initialized
INFO - 2020-10-26 02:20:18 --> Output Class Initialized
INFO - 2020-10-26 02:20:18 --> Security Class Initialized
DEBUG - 2020-10-26 02:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:20:18 --> Input Class Initialized
INFO - 2020-10-26 02:20:18 --> Language Class Initialized
INFO - 2020-10-26 02:20:18 --> Language Class Initialized
INFO - 2020-10-26 02:20:18 --> Config Class Initialized
INFO - 2020-10-26 02:20:18 --> Loader Class Initialized
INFO - 2020-10-26 02:20:18 --> Helper loaded: url_helper
INFO - 2020-10-26 02:20:18 --> Helper loaded: file_helper
INFO - 2020-10-26 02:20:18 --> Helper loaded: form_helper
INFO - 2020-10-26 02:20:18 --> Helper loaded: my_helper
INFO - 2020-10-26 02:20:18 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:20:18 --> Controller Class Initialized
INFO - 2020-10-26 02:20:19 --> Config Class Initialized
INFO - 2020-10-26 02:20:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:20:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:20:20 --> Utf8 Class Initialized
INFO - 2020-10-26 02:20:20 --> URI Class Initialized
INFO - 2020-10-26 02:20:20 --> Router Class Initialized
INFO - 2020-10-26 02:20:20 --> Output Class Initialized
INFO - 2020-10-26 02:20:20 --> Security Class Initialized
DEBUG - 2020-10-26 02:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:20:20 --> Input Class Initialized
INFO - 2020-10-26 02:20:20 --> Language Class Initialized
INFO - 2020-10-26 02:20:20 --> Language Class Initialized
INFO - 2020-10-26 02:20:20 --> Config Class Initialized
INFO - 2020-10-26 02:20:20 --> Loader Class Initialized
INFO - 2020-10-26 02:20:20 --> Helper loaded: url_helper
INFO - 2020-10-26 02:20:20 --> Helper loaded: file_helper
INFO - 2020-10-26 02:20:20 --> Helper loaded: form_helper
INFO - 2020-10-26 02:20:20 --> Helper loaded: my_helper
INFO - 2020-10-26 02:20:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:20:20 --> Controller Class Initialized
INFO - 2020-10-26 02:24:07 --> Config Class Initialized
INFO - 2020-10-26 02:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:24:07 --> Utf8 Class Initialized
INFO - 2020-10-26 02:24:07 --> URI Class Initialized
INFO - 2020-10-26 02:24:07 --> Router Class Initialized
INFO - 2020-10-26 02:24:07 --> Output Class Initialized
INFO - 2020-10-26 02:24:07 --> Security Class Initialized
DEBUG - 2020-10-26 02:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:24:07 --> Input Class Initialized
INFO - 2020-10-26 02:24:07 --> Language Class Initialized
INFO - 2020-10-26 02:24:07 --> Language Class Initialized
INFO - 2020-10-26 02:24:07 --> Config Class Initialized
INFO - 2020-10-26 02:24:07 --> Loader Class Initialized
INFO - 2020-10-26 02:24:07 --> Helper loaded: url_helper
INFO - 2020-10-26 02:24:07 --> Helper loaded: file_helper
INFO - 2020-10-26 02:24:07 --> Helper loaded: form_helper
INFO - 2020-10-26 02:24:07 --> Helper loaded: my_helper
INFO - 2020-10-26 02:24:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:24:07 --> Controller Class Initialized
DEBUG - 2020-10-26 02:24:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 02:24:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:24:07 --> Final output sent to browser
DEBUG - 2020-10-26 02:24:07 --> Total execution time: 0.2141
INFO - 2020-10-26 02:24:12 --> Config Class Initialized
INFO - 2020-10-26 02:24:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:24:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:24:12 --> Utf8 Class Initialized
INFO - 2020-10-26 02:24:12 --> URI Class Initialized
INFO - 2020-10-26 02:24:12 --> Router Class Initialized
INFO - 2020-10-26 02:24:12 --> Output Class Initialized
INFO - 2020-10-26 02:24:12 --> Security Class Initialized
DEBUG - 2020-10-26 02:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:24:12 --> Input Class Initialized
INFO - 2020-10-26 02:24:12 --> Language Class Initialized
INFO - 2020-10-26 02:24:12 --> Language Class Initialized
INFO - 2020-10-26 02:24:12 --> Config Class Initialized
INFO - 2020-10-26 02:24:12 --> Loader Class Initialized
INFO - 2020-10-26 02:24:12 --> Helper loaded: url_helper
INFO - 2020-10-26 02:24:12 --> Helper loaded: file_helper
INFO - 2020-10-26 02:24:12 --> Helper loaded: form_helper
INFO - 2020-10-26 02:24:12 --> Helper loaded: my_helper
INFO - 2020-10-26 02:24:12 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:24:12 --> Controller Class Initialized
ERROR - 2020-10-26 02:24:12 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' at line 1 - Invalid query: REPLACE INTO t_nilai (tasm, jenis, id_guru_mapel, id_mapel_kd, id_siswa, nilai) VALUES ;
INFO - 2020-10-26 02:24:12 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 02:28:36 --> Config Class Initialized
INFO - 2020-10-26 02:28:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:28:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:28:36 --> Utf8 Class Initialized
INFO - 2020-10-26 02:28:36 --> URI Class Initialized
INFO - 2020-10-26 02:28:36 --> Router Class Initialized
INFO - 2020-10-26 02:28:36 --> Output Class Initialized
INFO - 2020-10-26 02:28:36 --> Security Class Initialized
DEBUG - 2020-10-26 02:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:28:36 --> Input Class Initialized
INFO - 2020-10-26 02:28:36 --> Language Class Initialized
INFO - 2020-10-26 02:28:36 --> Language Class Initialized
INFO - 2020-10-26 02:28:36 --> Config Class Initialized
INFO - 2020-10-26 02:28:36 --> Loader Class Initialized
INFO - 2020-10-26 02:28:36 --> Helper loaded: url_helper
INFO - 2020-10-26 02:28:36 --> Helper loaded: file_helper
INFO - 2020-10-26 02:28:36 --> Helper loaded: form_helper
INFO - 2020-10-26 02:28:36 --> Helper loaded: my_helper
INFO - 2020-10-26 02:28:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:28:36 --> Controller Class Initialized
DEBUG - 2020-10-26 02:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-10-26 02:28:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:28:36 --> Final output sent to browser
DEBUG - 2020-10-26 02:28:36 --> Total execution time: 0.2153
INFO - 2020-10-26 02:28:36 --> Config Class Initialized
INFO - 2020-10-26 02:28:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:28:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:28:36 --> Utf8 Class Initialized
INFO - 2020-10-26 02:28:36 --> URI Class Initialized
INFO - 2020-10-26 02:28:36 --> Router Class Initialized
INFO - 2020-10-26 02:28:36 --> Output Class Initialized
INFO - 2020-10-26 02:28:36 --> Security Class Initialized
DEBUG - 2020-10-26 02:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:28:36 --> Input Class Initialized
INFO - 2020-10-26 02:28:36 --> Language Class Initialized
INFO - 2020-10-26 02:28:36 --> Language Class Initialized
INFO - 2020-10-26 02:28:36 --> Config Class Initialized
INFO - 2020-10-26 02:28:36 --> Loader Class Initialized
INFO - 2020-10-26 02:28:36 --> Helper loaded: url_helper
INFO - 2020-10-26 02:28:36 --> Helper loaded: file_helper
INFO - 2020-10-26 02:28:36 --> Helper loaded: form_helper
INFO - 2020-10-26 02:28:36 --> Helper loaded: my_helper
INFO - 2020-10-26 02:28:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:28:37 --> Controller Class Initialized
DEBUG - 2020-10-26 02:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 02:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:28:37 --> Final output sent to browser
DEBUG - 2020-10-26 02:28:37 --> Total execution time: 0.2197
INFO - 2020-10-26 02:28:37 --> Config Class Initialized
INFO - 2020-10-26 02:28:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:28:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:28:37 --> Utf8 Class Initialized
INFO - 2020-10-26 02:28:37 --> URI Class Initialized
INFO - 2020-10-26 02:28:37 --> Router Class Initialized
INFO - 2020-10-26 02:28:37 --> Output Class Initialized
INFO - 2020-10-26 02:28:37 --> Security Class Initialized
DEBUG - 2020-10-26 02:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:28:37 --> Input Class Initialized
INFO - 2020-10-26 02:28:37 --> Language Class Initialized
INFO - 2020-10-26 02:28:37 --> Language Class Initialized
INFO - 2020-10-26 02:28:37 --> Config Class Initialized
INFO - 2020-10-26 02:28:37 --> Loader Class Initialized
INFO - 2020-10-26 02:28:37 --> Helper loaded: url_helper
INFO - 2020-10-26 02:28:37 --> Helper loaded: file_helper
INFO - 2020-10-26 02:28:37 --> Helper loaded: form_helper
INFO - 2020-10-26 02:28:37 --> Helper loaded: my_helper
INFO - 2020-10-26 02:28:37 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:28:37 --> Controller Class Initialized
INFO - 2020-10-26 02:28:39 --> Config Class Initialized
INFO - 2020-10-26 02:28:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:28:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:28:39 --> Utf8 Class Initialized
INFO - 2020-10-26 02:28:39 --> URI Class Initialized
INFO - 2020-10-26 02:28:39 --> Router Class Initialized
INFO - 2020-10-26 02:28:39 --> Output Class Initialized
INFO - 2020-10-26 02:28:39 --> Security Class Initialized
DEBUG - 2020-10-26 02:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:28:39 --> Input Class Initialized
INFO - 2020-10-26 02:28:39 --> Language Class Initialized
INFO - 2020-10-26 02:28:39 --> Language Class Initialized
INFO - 2020-10-26 02:28:39 --> Config Class Initialized
INFO - 2020-10-26 02:28:39 --> Loader Class Initialized
INFO - 2020-10-26 02:28:39 --> Helper loaded: url_helper
INFO - 2020-10-26 02:28:39 --> Helper loaded: file_helper
INFO - 2020-10-26 02:28:39 --> Helper loaded: form_helper
INFO - 2020-10-26 02:28:39 --> Helper loaded: my_helper
INFO - 2020-10-26 02:28:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:28:39 --> Controller Class Initialized
INFO - 2020-10-26 02:29:15 --> Config Class Initialized
INFO - 2020-10-26 02:29:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:29:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:29:15 --> Utf8 Class Initialized
INFO - 2020-10-26 02:29:15 --> URI Class Initialized
INFO - 2020-10-26 02:29:15 --> Router Class Initialized
INFO - 2020-10-26 02:29:15 --> Output Class Initialized
INFO - 2020-10-26 02:29:15 --> Security Class Initialized
DEBUG - 2020-10-26 02:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:29:15 --> Input Class Initialized
INFO - 2020-10-26 02:29:15 --> Language Class Initialized
INFO - 2020-10-26 02:29:15 --> Language Class Initialized
INFO - 2020-10-26 02:29:15 --> Config Class Initialized
INFO - 2020-10-26 02:29:15 --> Loader Class Initialized
INFO - 2020-10-26 02:29:15 --> Helper loaded: url_helper
INFO - 2020-10-26 02:29:15 --> Helper loaded: file_helper
INFO - 2020-10-26 02:29:15 --> Helper loaded: form_helper
INFO - 2020-10-26 02:29:15 --> Helper loaded: my_helper
INFO - 2020-10-26 02:29:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:29:15 --> Controller Class Initialized
INFO - 2020-10-26 02:30:15 --> Config Class Initialized
INFO - 2020-10-26 02:30:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:30:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:30:15 --> Utf8 Class Initialized
INFO - 2020-10-26 02:30:15 --> URI Class Initialized
INFO - 2020-10-26 02:30:15 --> Router Class Initialized
INFO - 2020-10-26 02:30:15 --> Output Class Initialized
INFO - 2020-10-26 02:30:15 --> Security Class Initialized
DEBUG - 2020-10-26 02:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:30:15 --> Input Class Initialized
INFO - 2020-10-26 02:30:15 --> Language Class Initialized
INFO - 2020-10-26 02:30:15 --> Language Class Initialized
INFO - 2020-10-26 02:30:15 --> Config Class Initialized
INFO - 2020-10-26 02:30:15 --> Loader Class Initialized
INFO - 2020-10-26 02:30:15 --> Helper loaded: url_helper
INFO - 2020-10-26 02:30:15 --> Helper loaded: file_helper
INFO - 2020-10-26 02:30:15 --> Helper loaded: form_helper
INFO - 2020-10-26 02:30:15 --> Helper loaded: my_helper
INFO - 2020-10-26 02:30:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:30:15 --> Controller Class Initialized
INFO - 2020-10-26 02:30:15 --> Final output sent to browser
DEBUG - 2020-10-26 02:30:15 --> Total execution time: 0.1921
INFO - 2020-10-26 02:30:35 --> Config Class Initialized
INFO - 2020-10-26 02:30:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:30:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:30:35 --> Utf8 Class Initialized
INFO - 2020-10-26 02:30:35 --> URI Class Initialized
INFO - 2020-10-26 02:30:35 --> Router Class Initialized
INFO - 2020-10-26 02:30:35 --> Output Class Initialized
INFO - 2020-10-26 02:30:35 --> Security Class Initialized
DEBUG - 2020-10-26 02:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:30:35 --> Input Class Initialized
INFO - 2020-10-26 02:30:35 --> Language Class Initialized
INFO - 2020-10-26 02:30:35 --> Language Class Initialized
INFO - 2020-10-26 02:30:35 --> Config Class Initialized
INFO - 2020-10-26 02:30:35 --> Loader Class Initialized
INFO - 2020-10-26 02:30:35 --> Helper loaded: url_helper
INFO - 2020-10-26 02:30:35 --> Helper loaded: file_helper
INFO - 2020-10-26 02:30:35 --> Helper loaded: form_helper
INFO - 2020-10-26 02:30:35 --> Helper loaded: my_helper
INFO - 2020-10-26 02:30:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:30:35 --> Controller Class Initialized
INFO - 2020-10-26 02:30:35 --> Final output sent to browser
DEBUG - 2020-10-26 02:30:35 --> Total execution time: 0.1945
INFO - 2020-10-26 02:31:37 --> Config Class Initialized
INFO - 2020-10-26 02:31:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:37 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:37 --> URI Class Initialized
INFO - 2020-10-26 02:31:37 --> Router Class Initialized
INFO - 2020-10-26 02:31:37 --> Output Class Initialized
INFO - 2020-10-26 02:31:37 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:37 --> Input Class Initialized
INFO - 2020-10-26 02:31:37 --> Language Class Initialized
INFO - 2020-10-26 02:31:37 --> Language Class Initialized
INFO - 2020-10-26 02:31:37 --> Config Class Initialized
INFO - 2020-10-26 02:31:37 --> Loader Class Initialized
INFO - 2020-10-26 02:31:37 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:37 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:37 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:37 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:37 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:37 --> Controller Class Initialized
INFO - 2020-10-26 02:31:37 --> Final output sent to browser
DEBUG - 2020-10-26 02:31:37 --> Total execution time: 0.1963
INFO - 2020-10-26 02:31:46 --> Config Class Initialized
INFO - 2020-10-26 02:31:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:46 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:46 --> URI Class Initialized
INFO - 2020-10-26 02:31:46 --> Router Class Initialized
INFO - 2020-10-26 02:31:46 --> Output Class Initialized
INFO - 2020-10-26 02:31:46 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:46 --> Input Class Initialized
INFO - 2020-10-26 02:31:46 --> Language Class Initialized
INFO - 2020-10-26 02:31:46 --> Language Class Initialized
INFO - 2020-10-26 02:31:46 --> Config Class Initialized
INFO - 2020-10-26 02:31:46 --> Loader Class Initialized
INFO - 2020-10-26 02:31:46 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:46 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:46 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:46 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:46 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:46 --> Controller Class Initialized
INFO - 2020-10-26 02:31:46 --> Final output sent to browser
DEBUG - 2020-10-26 02:31:46 --> Total execution time: 0.2368
INFO - 2020-10-26 02:31:46 --> Config Class Initialized
INFO - 2020-10-26 02:31:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:46 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:46 --> URI Class Initialized
INFO - 2020-10-26 02:31:46 --> Router Class Initialized
INFO - 2020-10-26 02:31:46 --> Output Class Initialized
INFO - 2020-10-26 02:31:46 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:46 --> Input Class Initialized
INFO - 2020-10-26 02:31:46 --> Language Class Initialized
INFO - 2020-10-26 02:31:46 --> Language Class Initialized
INFO - 2020-10-26 02:31:46 --> Config Class Initialized
INFO - 2020-10-26 02:31:46 --> Loader Class Initialized
INFO - 2020-10-26 02:31:46 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:46 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:46 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:46 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:46 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:46 --> Controller Class Initialized
INFO - 2020-10-26 02:31:48 --> Config Class Initialized
INFO - 2020-10-26 02:31:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:48 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:48 --> URI Class Initialized
INFO - 2020-10-26 02:31:48 --> Router Class Initialized
INFO - 2020-10-26 02:31:48 --> Output Class Initialized
INFO - 2020-10-26 02:31:48 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:48 --> Input Class Initialized
INFO - 2020-10-26 02:31:48 --> Language Class Initialized
INFO - 2020-10-26 02:31:48 --> Language Class Initialized
INFO - 2020-10-26 02:31:48 --> Config Class Initialized
INFO - 2020-10-26 02:31:48 --> Loader Class Initialized
INFO - 2020-10-26 02:31:48 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:48 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:48 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:48 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:48 --> Controller Class Initialized
INFO - 2020-10-26 02:31:48 --> Final output sent to browser
DEBUG - 2020-10-26 02:31:48 --> Total execution time: 0.1914
INFO - 2020-10-26 02:31:52 --> Config Class Initialized
INFO - 2020-10-26 02:31:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:52 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:52 --> URI Class Initialized
INFO - 2020-10-26 02:31:52 --> Router Class Initialized
INFO - 2020-10-26 02:31:52 --> Output Class Initialized
INFO - 2020-10-26 02:31:52 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:52 --> Input Class Initialized
INFO - 2020-10-26 02:31:52 --> Language Class Initialized
INFO - 2020-10-26 02:31:52 --> Language Class Initialized
INFO - 2020-10-26 02:31:52 --> Config Class Initialized
INFO - 2020-10-26 02:31:52 --> Loader Class Initialized
INFO - 2020-10-26 02:31:52 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:52 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:52 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:52 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:52 --> Controller Class Initialized
INFO - 2020-10-26 02:31:52 --> Final output sent to browser
DEBUG - 2020-10-26 02:31:52 --> Total execution time: 0.2381
INFO - 2020-10-26 02:31:52 --> Config Class Initialized
INFO - 2020-10-26 02:31:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:52 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:52 --> URI Class Initialized
INFO - 2020-10-26 02:31:52 --> Router Class Initialized
INFO - 2020-10-26 02:31:52 --> Output Class Initialized
INFO - 2020-10-26 02:31:52 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:52 --> Input Class Initialized
INFO - 2020-10-26 02:31:52 --> Language Class Initialized
INFO - 2020-10-26 02:31:52 --> Language Class Initialized
INFO - 2020-10-26 02:31:52 --> Config Class Initialized
INFO - 2020-10-26 02:31:52 --> Loader Class Initialized
INFO - 2020-10-26 02:31:52 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:52 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:52 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:52 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:52 --> Controller Class Initialized
INFO - 2020-10-26 02:31:53 --> Config Class Initialized
INFO - 2020-10-26 02:31:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:53 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:53 --> URI Class Initialized
INFO - 2020-10-26 02:31:53 --> Router Class Initialized
INFO - 2020-10-26 02:31:53 --> Output Class Initialized
INFO - 2020-10-26 02:31:53 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:54 --> Input Class Initialized
INFO - 2020-10-26 02:31:54 --> Language Class Initialized
INFO - 2020-10-26 02:31:54 --> Language Class Initialized
INFO - 2020-10-26 02:31:54 --> Config Class Initialized
INFO - 2020-10-26 02:31:54 --> Loader Class Initialized
INFO - 2020-10-26 02:31:54 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:54 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:54 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:54 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:54 --> Controller Class Initialized
INFO - 2020-10-26 02:31:54 --> Final output sent to browser
DEBUG - 2020-10-26 02:31:54 --> Total execution time: 0.2020
INFO - 2020-10-26 02:31:55 --> Config Class Initialized
INFO - 2020-10-26 02:31:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:55 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:56 --> URI Class Initialized
INFO - 2020-10-26 02:31:56 --> Router Class Initialized
INFO - 2020-10-26 02:31:56 --> Output Class Initialized
INFO - 2020-10-26 02:31:56 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:56 --> Input Class Initialized
INFO - 2020-10-26 02:31:56 --> Language Class Initialized
INFO - 2020-10-26 02:31:56 --> Language Class Initialized
INFO - 2020-10-26 02:31:56 --> Config Class Initialized
INFO - 2020-10-26 02:31:56 --> Loader Class Initialized
INFO - 2020-10-26 02:31:56 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:56 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:56 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:56 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:56 --> Controller Class Initialized
INFO - 2020-10-26 02:31:56 --> Final output sent to browser
DEBUG - 2020-10-26 02:31:56 --> Total execution time: 0.2425
INFO - 2020-10-26 02:31:56 --> Config Class Initialized
INFO - 2020-10-26 02:31:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:56 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:56 --> URI Class Initialized
INFO - 2020-10-26 02:31:56 --> Router Class Initialized
INFO - 2020-10-26 02:31:56 --> Output Class Initialized
INFO - 2020-10-26 02:31:56 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:56 --> Input Class Initialized
INFO - 2020-10-26 02:31:56 --> Language Class Initialized
INFO - 2020-10-26 02:31:56 --> Language Class Initialized
INFO - 2020-10-26 02:31:56 --> Config Class Initialized
INFO - 2020-10-26 02:31:56 --> Loader Class Initialized
INFO - 2020-10-26 02:31:56 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:56 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:56 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:56 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:56 --> Controller Class Initialized
INFO - 2020-10-26 02:31:57 --> Config Class Initialized
INFO - 2020-10-26 02:31:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:31:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:31:57 --> Utf8 Class Initialized
INFO - 2020-10-26 02:31:57 --> URI Class Initialized
INFO - 2020-10-26 02:31:57 --> Router Class Initialized
INFO - 2020-10-26 02:31:57 --> Output Class Initialized
INFO - 2020-10-26 02:31:57 --> Security Class Initialized
DEBUG - 2020-10-26 02:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:31:57 --> Input Class Initialized
INFO - 2020-10-26 02:31:57 --> Language Class Initialized
INFO - 2020-10-26 02:31:57 --> Language Class Initialized
INFO - 2020-10-26 02:31:57 --> Config Class Initialized
INFO - 2020-10-26 02:31:58 --> Loader Class Initialized
INFO - 2020-10-26 02:31:58 --> Helper loaded: url_helper
INFO - 2020-10-26 02:31:58 --> Helper loaded: file_helper
INFO - 2020-10-26 02:31:58 --> Helper loaded: form_helper
INFO - 2020-10-26 02:31:58 --> Helper loaded: my_helper
INFO - 2020-10-26 02:31:58 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:31:58 --> Controller Class Initialized
INFO - 2020-10-26 02:31:58 --> Final output sent to browser
DEBUG - 2020-10-26 02:31:58 --> Total execution time: 0.1834
INFO - 2020-10-26 02:32:03 --> Config Class Initialized
INFO - 2020-10-26 02:32:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:03 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:03 --> URI Class Initialized
INFO - 2020-10-26 02:32:03 --> Router Class Initialized
INFO - 2020-10-26 02:32:03 --> Output Class Initialized
INFO - 2020-10-26 02:32:03 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:03 --> Input Class Initialized
INFO - 2020-10-26 02:32:03 --> Language Class Initialized
INFO - 2020-10-26 02:32:03 --> Language Class Initialized
INFO - 2020-10-26 02:32:03 --> Config Class Initialized
INFO - 2020-10-26 02:32:03 --> Loader Class Initialized
INFO - 2020-10-26 02:32:03 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:03 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:03 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:03 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:03 --> Controller Class Initialized
INFO - 2020-10-26 02:32:03 --> Final output sent to browser
DEBUG - 2020-10-26 02:32:03 --> Total execution time: 0.2473
INFO - 2020-10-26 02:32:03 --> Config Class Initialized
INFO - 2020-10-26 02:32:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:04 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:04 --> URI Class Initialized
INFO - 2020-10-26 02:32:04 --> Router Class Initialized
INFO - 2020-10-26 02:32:04 --> Output Class Initialized
INFO - 2020-10-26 02:32:04 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:04 --> Input Class Initialized
INFO - 2020-10-26 02:32:04 --> Language Class Initialized
INFO - 2020-10-26 02:32:04 --> Language Class Initialized
INFO - 2020-10-26 02:32:04 --> Config Class Initialized
INFO - 2020-10-26 02:32:04 --> Loader Class Initialized
INFO - 2020-10-26 02:32:04 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:04 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:04 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:04 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:04 --> Controller Class Initialized
INFO - 2020-10-26 02:32:14 --> Config Class Initialized
INFO - 2020-10-26 02:32:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:15 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:15 --> URI Class Initialized
INFO - 2020-10-26 02:32:15 --> Router Class Initialized
INFO - 2020-10-26 02:32:15 --> Output Class Initialized
INFO - 2020-10-26 02:32:15 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:15 --> Input Class Initialized
INFO - 2020-10-26 02:32:15 --> Language Class Initialized
INFO - 2020-10-26 02:32:15 --> Language Class Initialized
INFO - 2020-10-26 02:32:15 --> Config Class Initialized
INFO - 2020-10-26 02:32:15 --> Loader Class Initialized
INFO - 2020-10-26 02:32:15 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:15 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:15 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:15 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:15 --> Controller Class Initialized
DEBUG - 2020-10-26 02:32:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-10-26 02:32:15 --> Final output sent to browser
DEBUG - 2020-10-26 02:32:15 --> Total execution time: 0.2161
INFO - 2020-10-26 02:32:22 --> Config Class Initialized
INFO - 2020-10-26 02:32:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:22 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:22 --> URI Class Initialized
INFO - 2020-10-26 02:32:22 --> Router Class Initialized
INFO - 2020-10-26 02:32:22 --> Output Class Initialized
INFO - 2020-10-26 02:32:22 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:22 --> Input Class Initialized
INFO - 2020-10-26 02:32:22 --> Language Class Initialized
INFO - 2020-10-26 02:32:22 --> Language Class Initialized
INFO - 2020-10-26 02:32:22 --> Config Class Initialized
INFO - 2020-10-26 02:32:22 --> Loader Class Initialized
INFO - 2020-10-26 02:32:22 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:22 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:22 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:22 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:22 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:22 --> Controller Class Initialized
INFO - 2020-10-26 02:32:22 --> Final output sent to browser
DEBUG - 2020-10-26 02:32:22 --> Total execution time: 0.1973
INFO - 2020-10-26 02:32:29 --> Config Class Initialized
INFO - 2020-10-26 02:32:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:29 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:29 --> URI Class Initialized
INFO - 2020-10-26 02:32:29 --> Router Class Initialized
INFO - 2020-10-26 02:32:29 --> Output Class Initialized
INFO - 2020-10-26 02:32:29 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:29 --> Input Class Initialized
INFO - 2020-10-26 02:32:29 --> Language Class Initialized
INFO - 2020-10-26 02:32:29 --> Language Class Initialized
INFO - 2020-10-26 02:32:29 --> Config Class Initialized
INFO - 2020-10-26 02:32:29 --> Loader Class Initialized
INFO - 2020-10-26 02:32:29 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:29 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:29 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:29 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:29 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:29 --> Controller Class Initialized
ERROR - 2020-10-26 02:32:29 --> Severity: Notice --> Undefined index: nilai C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 847
ERROR - 2020-10-26 02:32:29 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\n_pengetahuan\controllers\N_pengetahuan.php 847
INFO - 2020-10-26 02:32:29 --> Final output sent to browser
DEBUG - 2020-10-26 02:32:29 --> Total execution time: 0.3411
INFO - 2020-10-26 02:32:41 --> Config Class Initialized
INFO - 2020-10-26 02:32:41 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:41 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:41 --> URI Class Initialized
INFO - 2020-10-26 02:32:41 --> Router Class Initialized
INFO - 2020-10-26 02:32:41 --> Output Class Initialized
INFO - 2020-10-26 02:32:41 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:41 --> Input Class Initialized
INFO - 2020-10-26 02:32:41 --> Language Class Initialized
INFO - 2020-10-26 02:32:41 --> Language Class Initialized
INFO - 2020-10-26 02:32:41 --> Config Class Initialized
INFO - 2020-10-26 02:32:41 --> Loader Class Initialized
INFO - 2020-10-26 02:32:41 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:41 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:41 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:41 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:41 --> Controller Class Initialized
INFO - 2020-10-26 02:32:41 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:32:41 --> Config Class Initialized
INFO - 2020-10-26 02:32:41 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:41 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:41 --> URI Class Initialized
INFO - 2020-10-26 02:32:41 --> Router Class Initialized
INFO - 2020-10-26 02:32:41 --> Output Class Initialized
INFO - 2020-10-26 02:32:41 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:41 --> Input Class Initialized
INFO - 2020-10-26 02:32:41 --> Language Class Initialized
INFO - 2020-10-26 02:32:41 --> Language Class Initialized
INFO - 2020-10-26 02:32:41 --> Config Class Initialized
INFO - 2020-10-26 02:32:41 --> Loader Class Initialized
INFO - 2020-10-26 02:32:41 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:41 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:41 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:41 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:41 --> Controller Class Initialized
DEBUG - 2020-10-26 02:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 02:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:32:41 --> Final output sent to browser
DEBUG - 2020-10-26 02:32:41 --> Total execution time: 0.2006
INFO - 2020-10-26 02:32:52 --> Config Class Initialized
INFO - 2020-10-26 02:32:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:52 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:52 --> URI Class Initialized
INFO - 2020-10-26 02:32:52 --> Router Class Initialized
INFO - 2020-10-26 02:32:52 --> Output Class Initialized
INFO - 2020-10-26 02:32:52 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:52 --> Input Class Initialized
INFO - 2020-10-26 02:32:52 --> Language Class Initialized
INFO - 2020-10-26 02:32:52 --> Language Class Initialized
INFO - 2020-10-26 02:32:52 --> Config Class Initialized
INFO - 2020-10-26 02:32:52 --> Loader Class Initialized
INFO - 2020-10-26 02:32:52 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:52 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:52 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:52 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:52 --> Controller Class Initialized
INFO - 2020-10-26 02:32:52 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:32:52 --> Final output sent to browser
DEBUG - 2020-10-26 02:32:52 --> Total execution time: 0.2159
INFO - 2020-10-26 02:32:53 --> Config Class Initialized
INFO - 2020-10-26 02:32:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:32:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:32:53 --> Utf8 Class Initialized
INFO - 2020-10-26 02:32:53 --> URI Class Initialized
INFO - 2020-10-26 02:32:53 --> Router Class Initialized
INFO - 2020-10-26 02:32:53 --> Output Class Initialized
INFO - 2020-10-26 02:32:53 --> Security Class Initialized
DEBUG - 2020-10-26 02:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:32:53 --> Input Class Initialized
INFO - 2020-10-26 02:32:53 --> Language Class Initialized
INFO - 2020-10-26 02:32:53 --> Language Class Initialized
INFO - 2020-10-26 02:32:53 --> Config Class Initialized
INFO - 2020-10-26 02:32:53 --> Loader Class Initialized
INFO - 2020-10-26 02:32:53 --> Helper loaded: url_helper
INFO - 2020-10-26 02:32:53 --> Helper loaded: file_helper
INFO - 2020-10-26 02:32:53 --> Helper loaded: form_helper
INFO - 2020-10-26 02:32:53 --> Helper loaded: my_helper
INFO - 2020-10-26 02:32:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:32:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:32:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:32:53 --> Controller Class Initialized
DEBUG - 2020-10-26 02:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 02:32:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:32:53 --> Final output sent to browser
DEBUG - 2020-10-26 02:32:53 --> Total execution time: 0.2453
INFO - 2020-10-26 02:45:17 --> Config Class Initialized
INFO - 2020-10-26 02:45:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:17 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:17 --> URI Class Initialized
INFO - 2020-10-26 02:45:17 --> Router Class Initialized
INFO - 2020-10-26 02:45:17 --> Output Class Initialized
INFO - 2020-10-26 02:45:17 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:17 --> Input Class Initialized
INFO - 2020-10-26 02:45:17 --> Language Class Initialized
INFO - 2020-10-26 02:45:17 --> Language Class Initialized
INFO - 2020-10-26 02:45:17 --> Config Class Initialized
INFO - 2020-10-26 02:45:17 --> Loader Class Initialized
INFO - 2020-10-26 02:45:17 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:17 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:17 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:17 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:17 --> Controller Class Initialized
INFO - 2020-10-26 02:45:17 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:45:17 --> Config Class Initialized
INFO - 2020-10-26 02:45:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:17 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:17 --> URI Class Initialized
INFO - 2020-10-26 02:45:17 --> Router Class Initialized
INFO - 2020-10-26 02:45:17 --> Output Class Initialized
INFO - 2020-10-26 02:45:17 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:17 --> Input Class Initialized
INFO - 2020-10-26 02:45:17 --> Language Class Initialized
INFO - 2020-10-26 02:45:17 --> Language Class Initialized
INFO - 2020-10-26 02:45:17 --> Config Class Initialized
INFO - 2020-10-26 02:45:17 --> Loader Class Initialized
INFO - 2020-10-26 02:45:17 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:17 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:17 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:17 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:17 --> Controller Class Initialized
DEBUG - 2020-10-26 02:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 02:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:45:17 --> Final output sent to browser
DEBUG - 2020-10-26 02:45:17 --> Total execution time: 0.2421
INFO - 2020-10-26 02:45:24 --> Config Class Initialized
INFO - 2020-10-26 02:45:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:24 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:24 --> URI Class Initialized
INFO - 2020-10-26 02:45:24 --> Router Class Initialized
INFO - 2020-10-26 02:45:24 --> Output Class Initialized
INFO - 2020-10-26 02:45:24 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:24 --> Input Class Initialized
INFO - 2020-10-26 02:45:24 --> Language Class Initialized
INFO - 2020-10-26 02:45:24 --> Language Class Initialized
INFO - 2020-10-26 02:45:24 --> Config Class Initialized
INFO - 2020-10-26 02:45:24 --> Loader Class Initialized
INFO - 2020-10-26 02:45:24 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:24 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:24 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:24 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:24 --> Controller Class Initialized
INFO - 2020-10-26 02:45:24 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:45:24 --> Final output sent to browser
DEBUG - 2020-10-26 02:45:24 --> Total execution time: 0.2271
INFO - 2020-10-26 02:45:26 --> Config Class Initialized
INFO - 2020-10-26 02:45:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:26 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:26 --> URI Class Initialized
INFO - 2020-10-26 02:45:26 --> Router Class Initialized
INFO - 2020-10-26 02:45:26 --> Output Class Initialized
INFO - 2020-10-26 02:45:26 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:26 --> Input Class Initialized
INFO - 2020-10-26 02:45:26 --> Language Class Initialized
INFO - 2020-10-26 02:45:26 --> Language Class Initialized
INFO - 2020-10-26 02:45:26 --> Config Class Initialized
INFO - 2020-10-26 02:45:26 --> Loader Class Initialized
INFO - 2020-10-26 02:45:26 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:26 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:26 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:26 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:26 --> Controller Class Initialized
DEBUG - 2020-10-26 02:45:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 02:45:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:45:26 --> Final output sent to browser
DEBUG - 2020-10-26 02:45:27 --> Total execution time: 0.2753
INFO - 2020-10-26 02:45:40 --> Config Class Initialized
INFO - 2020-10-26 02:45:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:40 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:40 --> URI Class Initialized
INFO - 2020-10-26 02:45:40 --> Router Class Initialized
INFO - 2020-10-26 02:45:40 --> Output Class Initialized
INFO - 2020-10-26 02:45:40 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:40 --> Input Class Initialized
INFO - 2020-10-26 02:45:40 --> Language Class Initialized
INFO - 2020-10-26 02:45:40 --> Language Class Initialized
INFO - 2020-10-26 02:45:40 --> Config Class Initialized
INFO - 2020-10-26 02:45:40 --> Loader Class Initialized
INFO - 2020-10-26 02:45:40 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:40 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:40 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:41 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:41 --> Controller Class Initialized
DEBUG - 2020-10-26 02:45:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 02:45:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:45:41 --> Final output sent to browser
DEBUG - 2020-10-26 02:45:41 --> Total execution time: 0.2546
INFO - 2020-10-26 02:45:42 --> Config Class Initialized
INFO - 2020-10-26 02:45:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:42 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:42 --> URI Class Initialized
INFO - 2020-10-26 02:45:42 --> Router Class Initialized
INFO - 2020-10-26 02:45:42 --> Output Class Initialized
INFO - 2020-10-26 02:45:42 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:42 --> Input Class Initialized
INFO - 2020-10-26 02:45:42 --> Language Class Initialized
INFO - 2020-10-26 02:45:42 --> Language Class Initialized
INFO - 2020-10-26 02:45:42 --> Config Class Initialized
INFO - 2020-10-26 02:45:42 --> Loader Class Initialized
INFO - 2020-10-26 02:45:42 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:42 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:42 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:42 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:42 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:43 --> Controller Class Initialized
DEBUG - 2020-10-26 02:45:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-26 02:45:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:45:43 --> Final output sent to browser
DEBUG - 2020-10-26 02:45:43 --> Total execution time: 0.2839
INFO - 2020-10-26 02:45:45 --> Config Class Initialized
INFO - 2020-10-26 02:45:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:45 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:45 --> URI Class Initialized
INFO - 2020-10-26 02:45:45 --> Router Class Initialized
INFO - 2020-10-26 02:45:45 --> Output Class Initialized
INFO - 2020-10-26 02:45:45 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:45 --> Input Class Initialized
INFO - 2020-10-26 02:45:45 --> Language Class Initialized
INFO - 2020-10-26 02:45:45 --> Language Class Initialized
INFO - 2020-10-26 02:45:45 --> Config Class Initialized
INFO - 2020-10-26 02:45:45 --> Loader Class Initialized
INFO - 2020-10-26 02:45:45 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:45 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:45 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:45 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:45 --> Controller Class Initialized
INFO - 2020-10-26 02:45:48 --> Config Class Initialized
INFO - 2020-10-26 02:45:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:48 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:48 --> URI Class Initialized
INFO - 2020-10-26 02:45:48 --> Router Class Initialized
INFO - 2020-10-26 02:45:48 --> Output Class Initialized
INFO - 2020-10-26 02:45:48 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:48 --> Input Class Initialized
INFO - 2020-10-26 02:45:48 --> Language Class Initialized
INFO - 2020-10-26 02:45:48 --> Language Class Initialized
INFO - 2020-10-26 02:45:48 --> Config Class Initialized
INFO - 2020-10-26 02:45:48 --> Loader Class Initialized
INFO - 2020-10-26 02:45:48 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:48 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:48 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:48 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:48 --> Controller Class Initialized
DEBUG - 2020-10-26 02:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-26 02:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:45:48 --> Final output sent to browser
DEBUG - 2020-10-26 02:45:48 --> Total execution time: 0.2408
INFO - 2020-10-26 02:45:52 --> Config Class Initialized
INFO - 2020-10-26 02:45:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:45:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:45:52 --> Utf8 Class Initialized
INFO - 2020-10-26 02:45:52 --> URI Class Initialized
INFO - 2020-10-26 02:45:52 --> Router Class Initialized
INFO - 2020-10-26 02:45:52 --> Output Class Initialized
INFO - 2020-10-26 02:45:52 --> Security Class Initialized
DEBUG - 2020-10-26 02:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:45:52 --> Input Class Initialized
INFO - 2020-10-26 02:45:52 --> Language Class Initialized
INFO - 2020-10-26 02:45:52 --> Language Class Initialized
INFO - 2020-10-26 02:45:52 --> Config Class Initialized
INFO - 2020-10-26 02:45:52 --> Loader Class Initialized
INFO - 2020-10-26 02:45:52 --> Helper loaded: url_helper
INFO - 2020-10-26 02:45:52 --> Helper loaded: file_helper
INFO - 2020-10-26 02:45:52 --> Helper loaded: form_helper
INFO - 2020-10-26 02:45:52 --> Helper loaded: my_helper
INFO - 2020-10-26 02:45:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:45:52 --> Controller Class Initialized
INFO - 2020-10-26 02:45:52 --> Final output sent to browser
DEBUG - 2020-10-26 02:45:52 --> Total execution time: 0.2361
INFO - 2020-10-26 02:46:04 --> Config Class Initialized
INFO - 2020-10-26 02:46:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:04 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:04 --> URI Class Initialized
INFO - 2020-10-26 02:46:04 --> Router Class Initialized
INFO - 2020-10-26 02:46:04 --> Output Class Initialized
INFO - 2020-10-26 02:46:04 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:04 --> Input Class Initialized
INFO - 2020-10-26 02:46:04 --> Language Class Initialized
INFO - 2020-10-26 02:46:04 --> Language Class Initialized
INFO - 2020-10-26 02:46:04 --> Config Class Initialized
INFO - 2020-10-26 02:46:04 --> Loader Class Initialized
INFO - 2020-10-26 02:46:04 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:04 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:04 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:04 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:04 --> Controller Class Initialized
INFO - 2020-10-26 02:46:04 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:04 --> Total execution time: 0.2680
INFO - 2020-10-26 02:46:04 --> Config Class Initialized
INFO - 2020-10-26 02:46:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:05 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:05 --> URI Class Initialized
INFO - 2020-10-26 02:46:05 --> Router Class Initialized
INFO - 2020-10-26 02:46:05 --> Output Class Initialized
INFO - 2020-10-26 02:46:05 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:05 --> Input Class Initialized
INFO - 2020-10-26 02:46:05 --> Language Class Initialized
INFO - 2020-10-26 02:46:05 --> Language Class Initialized
INFO - 2020-10-26 02:46:05 --> Config Class Initialized
INFO - 2020-10-26 02:46:05 --> Loader Class Initialized
INFO - 2020-10-26 02:46:05 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:05 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:05 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:05 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:05 --> Controller Class Initialized
DEBUG - 2020-10-26 02:46:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-26 02:46:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:46:05 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:05 --> Total execution time: 0.2596
INFO - 2020-10-26 02:46:06 --> Config Class Initialized
INFO - 2020-10-26 02:46:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:06 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:06 --> URI Class Initialized
INFO - 2020-10-26 02:46:06 --> Router Class Initialized
INFO - 2020-10-26 02:46:06 --> Output Class Initialized
INFO - 2020-10-26 02:46:06 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:06 --> Input Class Initialized
INFO - 2020-10-26 02:46:06 --> Language Class Initialized
INFO - 2020-10-26 02:46:06 --> Language Class Initialized
INFO - 2020-10-26 02:46:06 --> Config Class Initialized
INFO - 2020-10-26 02:46:06 --> Loader Class Initialized
INFO - 2020-10-26 02:46:06 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:06 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:06 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:06 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:06 --> Controller Class Initialized
INFO - 2020-10-26 02:46:09 --> Config Class Initialized
INFO - 2020-10-26 02:46:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:09 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:09 --> URI Class Initialized
INFO - 2020-10-26 02:46:09 --> Router Class Initialized
INFO - 2020-10-26 02:46:09 --> Output Class Initialized
INFO - 2020-10-26 02:46:09 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:09 --> Input Class Initialized
INFO - 2020-10-26 02:46:09 --> Language Class Initialized
INFO - 2020-10-26 02:46:09 --> Language Class Initialized
INFO - 2020-10-26 02:46:09 --> Config Class Initialized
INFO - 2020-10-26 02:46:09 --> Loader Class Initialized
INFO - 2020-10-26 02:46:09 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:09 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:09 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:09 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:09 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:09 --> Controller Class Initialized
DEBUG - 2020-10-26 02:46:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-26 02:46:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:46:09 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:09 --> Total execution time: 0.2584
INFO - 2020-10-26 02:46:10 --> Config Class Initialized
INFO - 2020-10-26 02:46:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:10 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:10 --> URI Class Initialized
INFO - 2020-10-26 02:46:10 --> Router Class Initialized
INFO - 2020-10-26 02:46:10 --> Output Class Initialized
INFO - 2020-10-26 02:46:10 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:10 --> Input Class Initialized
INFO - 2020-10-26 02:46:10 --> Language Class Initialized
INFO - 2020-10-26 02:46:10 --> Language Class Initialized
INFO - 2020-10-26 02:46:10 --> Config Class Initialized
INFO - 2020-10-26 02:46:10 --> Loader Class Initialized
INFO - 2020-10-26 02:46:10 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:10 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:10 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:10 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:10 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:10 --> Controller Class Initialized
INFO - 2020-10-26 02:46:10 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:10 --> Total execution time: 0.2290
INFO - 2020-10-26 02:46:20 --> Config Class Initialized
INFO - 2020-10-26 02:46:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:20 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:20 --> URI Class Initialized
INFO - 2020-10-26 02:46:20 --> Router Class Initialized
INFO - 2020-10-26 02:46:20 --> Output Class Initialized
INFO - 2020-10-26 02:46:20 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:20 --> Input Class Initialized
INFO - 2020-10-26 02:46:20 --> Language Class Initialized
INFO - 2020-10-26 02:46:20 --> Language Class Initialized
INFO - 2020-10-26 02:46:20 --> Config Class Initialized
INFO - 2020-10-26 02:46:20 --> Loader Class Initialized
INFO - 2020-10-26 02:46:20 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:20 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:20 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:20 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:20 --> Controller Class Initialized
INFO - 2020-10-26 02:46:20 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:20 --> Total execution time: 0.2259
INFO - 2020-10-26 02:46:27 --> Config Class Initialized
INFO - 2020-10-26 02:46:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:27 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:27 --> URI Class Initialized
INFO - 2020-10-26 02:46:27 --> Router Class Initialized
INFO - 2020-10-26 02:46:27 --> Output Class Initialized
INFO - 2020-10-26 02:46:27 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:27 --> Input Class Initialized
INFO - 2020-10-26 02:46:27 --> Language Class Initialized
INFO - 2020-10-26 02:46:27 --> Language Class Initialized
INFO - 2020-10-26 02:46:27 --> Config Class Initialized
INFO - 2020-10-26 02:46:27 --> Loader Class Initialized
INFO - 2020-10-26 02:46:27 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:27 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:27 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:27 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:27 --> Controller Class Initialized
INFO - 2020-10-26 02:46:27 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:27 --> Total execution time: 0.2618
INFO - 2020-10-26 02:46:27 --> Config Class Initialized
INFO - 2020-10-26 02:46:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:27 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:27 --> URI Class Initialized
INFO - 2020-10-26 02:46:27 --> Router Class Initialized
INFO - 2020-10-26 02:46:27 --> Output Class Initialized
INFO - 2020-10-26 02:46:27 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:27 --> Input Class Initialized
INFO - 2020-10-26 02:46:27 --> Language Class Initialized
INFO - 2020-10-26 02:46:27 --> Language Class Initialized
INFO - 2020-10-26 02:46:27 --> Config Class Initialized
INFO - 2020-10-26 02:46:27 --> Loader Class Initialized
INFO - 2020-10-26 02:46:27 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:27 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:27 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:27 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:27 --> Controller Class Initialized
DEBUG - 2020-10-26 02:46:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-26 02:46:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:46:27 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:27 --> Total execution time: 0.2436
INFO - 2020-10-26 02:46:34 --> Config Class Initialized
INFO - 2020-10-26 02:46:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:34 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:34 --> URI Class Initialized
INFO - 2020-10-26 02:46:34 --> Router Class Initialized
INFO - 2020-10-26 02:46:34 --> Output Class Initialized
INFO - 2020-10-26 02:46:34 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:34 --> Input Class Initialized
INFO - 2020-10-26 02:46:34 --> Language Class Initialized
INFO - 2020-10-26 02:46:34 --> Language Class Initialized
INFO - 2020-10-26 02:46:34 --> Config Class Initialized
INFO - 2020-10-26 02:46:35 --> Loader Class Initialized
INFO - 2020-10-26 02:46:35 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:35 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:35 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:35 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:35 --> Controller Class Initialized
INFO - 2020-10-26 02:46:36 --> Config Class Initialized
INFO - 2020-10-26 02:46:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:36 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:36 --> URI Class Initialized
INFO - 2020-10-26 02:46:36 --> Router Class Initialized
INFO - 2020-10-26 02:46:36 --> Output Class Initialized
INFO - 2020-10-26 02:46:36 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:36 --> Input Class Initialized
INFO - 2020-10-26 02:46:36 --> Language Class Initialized
INFO - 2020-10-26 02:46:36 --> Language Class Initialized
INFO - 2020-10-26 02:46:36 --> Config Class Initialized
INFO - 2020-10-26 02:46:36 --> Loader Class Initialized
INFO - 2020-10-26 02:46:36 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:36 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:36 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:36 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:36 --> Controller Class Initialized
DEBUG - 2020-10-26 02:46:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-26 02:46:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:46:36 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:36 --> Total execution time: 0.2383
INFO - 2020-10-26 02:46:41 --> Config Class Initialized
INFO - 2020-10-26 02:46:41 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:41 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:41 --> URI Class Initialized
INFO - 2020-10-26 02:46:41 --> Router Class Initialized
INFO - 2020-10-26 02:46:41 --> Output Class Initialized
INFO - 2020-10-26 02:46:41 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:41 --> Input Class Initialized
INFO - 2020-10-26 02:46:41 --> Language Class Initialized
INFO - 2020-10-26 02:46:41 --> Language Class Initialized
INFO - 2020-10-26 02:46:41 --> Config Class Initialized
INFO - 2020-10-26 02:46:41 --> Loader Class Initialized
INFO - 2020-10-26 02:46:41 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:41 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:41 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:41 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:41 --> Controller Class Initialized
DEBUG - 2020-10-26 02:46:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2020-10-26 02:46:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:46:41 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:41 --> Total execution time: 0.2566
INFO - 2020-10-26 02:46:44 --> Config Class Initialized
INFO - 2020-10-26 02:46:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:46:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:46:44 --> Utf8 Class Initialized
INFO - 2020-10-26 02:46:44 --> URI Class Initialized
INFO - 2020-10-26 02:46:44 --> Router Class Initialized
INFO - 2020-10-26 02:46:45 --> Output Class Initialized
INFO - 2020-10-26 02:46:45 --> Security Class Initialized
DEBUG - 2020-10-26 02:46:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:46:45 --> Input Class Initialized
INFO - 2020-10-26 02:46:45 --> Language Class Initialized
INFO - 2020-10-26 02:46:45 --> Language Class Initialized
INFO - 2020-10-26 02:46:45 --> Config Class Initialized
INFO - 2020-10-26 02:46:45 --> Loader Class Initialized
INFO - 2020-10-26 02:46:45 --> Helper loaded: url_helper
INFO - 2020-10-26 02:46:45 --> Helper loaded: file_helper
INFO - 2020-10-26 02:46:45 --> Helper loaded: form_helper
INFO - 2020-10-26 02:46:45 --> Helper loaded: my_helper
INFO - 2020-10-26 02:46:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:46:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:46:45 --> Controller Class Initialized
DEBUG - 2020-10-26 02:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-10-26 02:46:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:46:45 --> Final output sent to browser
DEBUG - 2020-10-26 02:46:45 --> Total execution time: 0.2473
INFO - 2020-10-26 02:48:59 --> Config Class Initialized
INFO - 2020-10-26 02:48:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:48:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:48:59 --> Utf8 Class Initialized
INFO - 2020-10-26 02:48:59 --> URI Class Initialized
INFO - 2020-10-26 02:48:59 --> Router Class Initialized
INFO - 2020-10-26 02:48:59 --> Output Class Initialized
INFO - 2020-10-26 02:48:59 --> Security Class Initialized
DEBUG - 2020-10-26 02:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:48:59 --> Input Class Initialized
INFO - 2020-10-26 02:48:59 --> Language Class Initialized
INFO - 2020-10-26 02:48:59 --> Language Class Initialized
INFO - 2020-10-26 02:48:59 --> Config Class Initialized
INFO - 2020-10-26 02:48:59 --> Loader Class Initialized
INFO - 2020-10-26 02:48:59 --> Helper loaded: url_helper
INFO - 2020-10-26 02:48:59 --> Helper loaded: file_helper
INFO - 2020-10-26 02:48:59 --> Helper loaded: form_helper
INFO - 2020-10-26 02:48:59 --> Helper loaded: my_helper
INFO - 2020-10-26 02:48:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:48:59 --> Controller Class Initialized
INFO - 2020-10-26 02:48:59 --> Final output sent to browser
DEBUG - 2020-10-26 02:48:59 --> Total execution time: 0.2069
INFO - 2020-10-26 02:49:20 --> Config Class Initialized
INFO - 2020-10-26 02:49:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:20 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:20 --> URI Class Initialized
INFO - 2020-10-26 02:49:20 --> Router Class Initialized
INFO - 2020-10-26 02:49:20 --> Output Class Initialized
INFO - 2020-10-26 02:49:20 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:20 --> Input Class Initialized
INFO - 2020-10-26 02:49:20 --> Language Class Initialized
INFO - 2020-10-26 02:49:20 --> Language Class Initialized
INFO - 2020-10-26 02:49:20 --> Config Class Initialized
INFO - 2020-10-26 02:49:20 --> Loader Class Initialized
INFO - 2020-10-26 02:49:20 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:20 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:20 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:20 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:20 --> Controller Class Initialized
DEBUG - 2020-10-26 02:49:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 02:49:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:49:20 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:20 --> Total execution time: 0.2210
INFO - 2020-10-26 02:49:21 --> Config Class Initialized
INFO - 2020-10-26 02:49:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:22 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:22 --> URI Class Initialized
INFO - 2020-10-26 02:49:22 --> Router Class Initialized
INFO - 2020-10-26 02:49:22 --> Output Class Initialized
INFO - 2020-10-26 02:49:22 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:22 --> Input Class Initialized
INFO - 2020-10-26 02:49:22 --> Language Class Initialized
INFO - 2020-10-26 02:49:22 --> Language Class Initialized
INFO - 2020-10-26 02:49:22 --> Config Class Initialized
INFO - 2020-10-26 02:49:22 --> Loader Class Initialized
INFO - 2020-10-26 02:49:22 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:22 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:22 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:22 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:22 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:22 --> Controller Class Initialized
DEBUG - 2020-10-26 02:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 02:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:49:22 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:22 --> Total execution time: 0.2404
INFO - 2020-10-26 02:49:22 --> Config Class Initialized
INFO - 2020-10-26 02:49:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:22 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:22 --> URI Class Initialized
INFO - 2020-10-26 02:49:22 --> Router Class Initialized
INFO - 2020-10-26 02:49:22 --> Output Class Initialized
INFO - 2020-10-26 02:49:22 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:22 --> Input Class Initialized
INFO - 2020-10-26 02:49:22 --> Language Class Initialized
INFO - 2020-10-26 02:49:22 --> Language Class Initialized
INFO - 2020-10-26 02:49:22 --> Config Class Initialized
INFO - 2020-10-26 02:49:22 --> Loader Class Initialized
INFO - 2020-10-26 02:49:22 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:22 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:22 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:22 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:22 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:22 --> Controller Class Initialized
INFO - 2020-10-26 02:49:23 --> Config Class Initialized
INFO - 2020-10-26 02:49:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:23 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:23 --> URI Class Initialized
INFO - 2020-10-26 02:49:23 --> Router Class Initialized
INFO - 2020-10-26 02:49:23 --> Output Class Initialized
INFO - 2020-10-26 02:49:24 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:24 --> Input Class Initialized
INFO - 2020-10-26 02:49:24 --> Language Class Initialized
INFO - 2020-10-26 02:49:24 --> Language Class Initialized
INFO - 2020-10-26 02:49:24 --> Config Class Initialized
INFO - 2020-10-26 02:49:24 --> Loader Class Initialized
INFO - 2020-10-26 02:49:24 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:24 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:24 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:24 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:24 --> Controller Class Initialized
INFO - 2020-10-26 02:49:24 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:24 --> Total execution time: 0.2107
INFO - 2020-10-26 02:49:25 --> Config Class Initialized
INFO - 2020-10-26 02:49:25 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:25 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:25 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:25 --> URI Class Initialized
INFO - 2020-10-26 02:49:25 --> Router Class Initialized
INFO - 2020-10-26 02:49:25 --> Output Class Initialized
INFO - 2020-10-26 02:49:25 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:25 --> Input Class Initialized
INFO - 2020-10-26 02:49:25 --> Language Class Initialized
INFO - 2020-10-26 02:49:25 --> Language Class Initialized
INFO - 2020-10-26 02:49:25 --> Config Class Initialized
INFO - 2020-10-26 02:49:25 --> Loader Class Initialized
INFO - 2020-10-26 02:49:25 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:25 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:25 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:25 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:25 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:25 --> Controller Class Initialized
INFO - 2020-10-26 02:49:25 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:25 --> Total execution time: 0.1938
INFO - 2020-10-26 02:49:26 --> Config Class Initialized
INFO - 2020-10-26 02:49:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:26 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:26 --> URI Class Initialized
INFO - 2020-10-26 02:49:26 --> Router Class Initialized
INFO - 2020-10-26 02:49:26 --> Output Class Initialized
INFO - 2020-10-26 02:49:26 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:26 --> Input Class Initialized
INFO - 2020-10-26 02:49:26 --> Language Class Initialized
INFO - 2020-10-26 02:49:26 --> Language Class Initialized
INFO - 2020-10-26 02:49:26 --> Config Class Initialized
INFO - 2020-10-26 02:49:26 --> Loader Class Initialized
INFO - 2020-10-26 02:49:26 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:26 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:26 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:26 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:26 --> Controller Class Initialized
INFO - 2020-10-26 02:49:26 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:26 --> Total execution time: 0.1986
INFO - 2020-10-26 02:49:27 --> Config Class Initialized
INFO - 2020-10-26 02:49:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:27 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:27 --> URI Class Initialized
INFO - 2020-10-26 02:49:27 --> Router Class Initialized
INFO - 2020-10-26 02:49:27 --> Output Class Initialized
INFO - 2020-10-26 02:49:27 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:27 --> Input Class Initialized
INFO - 2020-10-26 02:49:27 --> Language Class Initialized
INFO - 2020-10-26 02:49:27 --> Language Class Initialized
INFO - 2020-10-26 02:49:27 --> Config Class Initialized
INFO - 2020-10-26 02:49:27 --> Loader Class Initialized
INFO - 2020-10-26 02:49:27 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:27 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:27 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:27 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:27 --> Controller Class Initialized
INFO - 2020-10-26 02:49:27 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:27 --> Total execution time: 0.1995
INFO - 2020-10-26 02:49:27 --> Config Class Initialized
INFO - 2020-10-26 02:49:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:27 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:27 --> URI Class Initialized
INFO - 2020-10-26 02:49:27 --> Router Class Initialized
INFO - 2020-10-26 02:49:27 --> Output Class Initialized
INFO - 2020-10-26 02:49:27 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:27 --> Input Class Initialized
INFO - 2020-10-26 02:49:27 --> Language Class Initialized
INFO - 2020-10-26 02:49:27 --> Language Class Initialized
INFO - 2020-10-26 02:49:27 --> Config Class Initialized
INFO - 2020-10-26 02:49:27 --> Loader Class Initialized
INFO - 2020-10-26 02:49:27 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:27 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:27 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:27 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:27 --> Controller Class Initialized
INFO - 2020-10-26 02:49:27 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:27 --> Total execution time: 0.1985
INFO - 2020-10-26 02:49:31 --> Config Class Initialized
INFO - 2020-10-26 02:49:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:31 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:31 --> URI Class Initialized
INFO - 2020-10-26 02:49:31 --> Router Class Initialized
INFO - 2020-10-26 02:49:31 --> Output Class Initialized
INFO - 2020-10-26 02:49:31 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:32 --> Input Class Initialized
INFO - 2020-10-26 02:49:32 --> Language Class Initialized
INFO - 2020-10-26 02:49:32 --> Language Class Initialized
INFO - 2020-10-26 02:49:32 --> Config Class Initialized
INFO - 2020-10-26 02:49:32 --> Loader Class Initialized
INFO - 2020-10-26 02:49:32 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:32 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:32 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:32 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:32 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:32 --> Controller Class Initialized
INFO - 2020-10-26 02:49:32 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:49:32 --> Config Class Initialized
INFO - 2020-10-26 02:49:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:32 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:32 --> URI Class Initialized
INFO - 2020-10-26 02:49:32 --> Router Class Initialized
INFO - 2020-10-26 02:49:32 --> Output Class Initialized
INFO - 2020-10-26 02:49:32 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:32 --> Input Class Initialized
INFO - 2020-10-26 02:49:32 --> Language Class Initialized
INFO - 2020-10-26 02:49:32 --> Language Class Initialized
INFO - 2020-10-26 02:49:32 --> Config Class Initialized
INFO - 2020-10-26 02:49:32 --> Loader Class Initialized
INFO - 2020-10-26 02:49:32 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:32 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:32 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:32 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:32 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:32 --> Controller Class Initialized
DEBUG - 2020-10-26 02:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 02:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:49:32 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:32 --> Total execution time: 0.2358
INFO - 2020-10-26 02:49:38 --> Config Class Initialized
INFO - 2020-10-26 02:49:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:38 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:38 --> URI Class Initialized
INFO - 2020-10-26 02:49:38 --> Router Class Initialized
INFO - 2020-10-26 02:49:38 --> Output Class Initialized
INFO - 2020-10-26 02:49:38 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:38 --> Input Class Initialized
INFO - 2020-10-26 02:49:38 --> Language Class Initialized
INFO - 2020-10-26 02:49:39 --> Language Class Initialized
INFO - 2020-10-26 02:49:39 --> Config Class Initialized
INFO - 2020-10-26 02:49:39 --> Loader Class Initialized
INFO - 2020-10-26 02:49:39 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:39 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:39 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:39 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:39 --> Controller Class Initialized
INFO - 2020-10-26 02:49:39 --> Helper loaded: cookie_helper
INFO - 2020-10-26 02:49:39 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:39 --> Total execution time: 0.2239
INFO - 2020-10-26 02:49:40 --> Config Class Initialized
INFO - 2020-10-26 02:49:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 02:49:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 02:49:40 --> Utf8 Class Initialized
INFO - 2020-10-26 02:49:40 --> URI Class Initialized
INFO - 2020-10-26 02:49:40 --> Router Class Initialized
INFO - 2020-10-26 02:49:40 --> Output Class Initialized
INFO - 2020-10-26 02:49:40 --> Security Class Initialized
DEBUG - 2020-10-26 02:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 02:49:40 --> Input Class Initialized
INFO - 2020-10-26 02:49:40 --> Language Class Initialized
INFO - 2020-10-26 02:49:40 --> Language Class Initialized
INFO - 2020-10-26 02:49:40 --> Config Class Initialized
INFO - 2020-10-26 02:49:40 --> Loader Class Initialized
INFO - 2020-10-26 02:49:40 --> Helper loaded: url_helper
INFO - 2020-10-26 02:49:40 --> Helper loaded: file_helper
INFO - 2020-10-26 02:49:40 --> Helper loaded: form_helper
INFO - 2020-10-26 02:49:40 --> Helper loaded: my_helper
INFO - 2020-10-26 02:49:40 --> Database Driver Class Initialized
DEBUG - 2020-10-26 02:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 02:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 02:49:40 --> Controller Class Initialized
DEBUG - 2020-10-26 02:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 02:49:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 02:49:40 --> Final output sent to browser
DEBUG - 2020-10-26 02:49:40 --> Total execution time: 0.2611
INFO - 2020-10-26 03:06:26 --> Config Class Initialized
INFO - 2020-10-26 03:06:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:26 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:26 --> URI Class Initialized
DEBUG - 2020-10-26 03:06:26 --> No URI present. Default controller set.
INFO - 2020-10-26 03:06:26 --> Router Class Initialized
INFO - 2020-10-26 03:06:26 --> Output Class Initialized
INFO - 2020-10-26 03:06:26 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:26 --> Input Class Initialized
INFO - 2020-10-26 03:06:26 --> Language Class Initialized
INFO - 2020-10-26 03:06:26 --> Language Class Initialized
INFO - 2020-10-26 03:06:26 --> Config Class Initialized
INFO - 2020-10-26 03:06:26 --> Loader Class Initialized
INFO - 2020-10-26 03:06:26 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:26 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:26 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:26 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:26 --> Controller Class Initialized
DEBUG - 2020-10-26 03:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 03:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:06:26 --> Final output sent to browser
DEBUG - 2020-10-26 03:06:26 --> Total execution time: 0.2294
INFO - 2020-10-26 03:06:28 --> Config Class Initialized
INFO - 2020-10-26 03:06:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:28 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:28 --> URI Class Initialized
DEBUG - 2020-10-26 03:06:28 --> No URI present. Default controller set.
INFO - 2020-10-26 03:06:28 --> Router Class Initialized
INFO - 2020-10-26 03:06:28 --> Output Class Initialized
INFO - 2020-10-26 03:06:28 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:28 --> Input Class Initialized
INFO - 2020-10-26 03:06:28 --> Language Class Initialized
INFO - 2020-10-26 03:06:28 --> Language Class Initialized
INFO - 2020-10-26 03:06:28 --> Config Class Initialized
INFO - 2020-10-26 03:06:28 --> Loader Class Initialized
INFO - 2020-10-26 03:06:28 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:28 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:28 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:28 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:28 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:28 --> Controller Class Initialized
DEBUG - 2020-10-26 03:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 03:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:06:28 --> Final output sent to browser
DEBUG - 2020-10-26 03:06:28 --> Total execution time: 0.2267
INFO - 2020-10-26 03:06:29 --> Config Class Initialized
INFO - 2020-10-26 03:06:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:29 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:29 --> URI Class Initialized
INFO - 2020-10-26 03:06:29 --> Router Class Initialized
INFO - 2020-10-26 03:06:29 --> Output Class Initialized
INFO - 2020-10-26 03:06:29 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:29 --> Input Class Initialized
INFO - 2020-10-26 03:06:29 --> Language Class Initialized
INFO - 2020-10-26 03:06:29 --> Language Class Initialized
INFO - 2020-10-26 03:06:29 --> Config Class Initialized
INFO - 2020-10-26 03:06:29 --> Loader Class Initialized
INFO - 2020-10-26 03:06:29 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:29 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:29 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:29 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:29 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:29 --> Controller Class Initialized
DEBUG - 2020-10-26 03:06:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-26 03:06:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:06:29 --> Final output sent to browser
DEBUG - 2020-10-26 03:06:29 --> Total execution time: 0.2291
INFO - 2020-10-26 03:06:29 --> Config Class Initialized
INFO - 2020-10-26 03:06:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:29 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:29 --> URI Class Initialized
INFO - 2020-10-26 03:06:29 --> Router Class Initialized
INFO - 2020-10-26 03:06:29 --> Output Class Initialized
INFO - 2020-10-26 03:06:30 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:30 --> Input Class Initialized
INFO - 2020-10-26 03:06:30 --> Language Class Initialized
INFO - 2020-10-26 03:06:30 --> Language Class Initialized
INFO - 2020-10-26 03:06:30 --> Config Class Initialized
INFO - 2020-10-26 03:06:30 --> Loader Class Initialized
INFO - 2020-10-26 03:06:30 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:30 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:30 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:30 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:30 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:30 --> Controller Class Initialized
INFO - 2020-10-26 03:06:31 --> Config Class Initialized
INFO - 2020-10-26 03:06:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:31 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:31 --> URI Class Initialized
INFO - 2020-10-26 03:06:31 --> Router Class Initialized
INFO - 2020-10-26 03:06:31 --> Output Class Initialized
INFO - 2020-10-26 03:06:31 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:31 --> Input Class Initialized
INFO - 2020-10-26 03:06:31 --> Language Class Initialized
INFO - 2020-10-26 03:06:31 --> Language Class Initialized
INFO - 2020-10-26 03:06:31 --> Config Class Initialized
INFO - 2020-10-26 03:06:31 --> Loader Class Initialized
INFO - 2020-10-26 03:06:31 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:31 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:31 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:31 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:31 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:31 --> Controller Class Initialized
DEBUG - 2020-10-26 03:06:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 03:06:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:06:32 --> Final output sent to browser
DEBUG - 2020-10-26 03:06:32 --> Total execution time: 0.2390
INFO - 2020-10-26 03:06:32 --> Config Class Initialized
INFO - 2020-10-26 03:06:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:32 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:32 --> URI Class Initialized
INFO - 2020-10-26 03:06:32 --> Router Class Initialized
INFO - 2020-10-26 03:06:32 --> Output Class Initialized
INFO - 2020-10-26 03:06:32 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:32 --> Input Class Initialized
INFO - 2020-10-26 03:06:32 --> Language Class Initialized
INFO - 2020-10-26 03:06:32 --> Language Class Initialized
INFO - 2020-10-26 03:06:32 --> Config Class Initialized
INFO - 2020-10-26 03:06:32 --> Loader Class Initialized
INFO - 2020-10-26 03:06:32 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:32 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:32 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:32 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:32 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:32 --> Controller Class Initialized
INFO - 2020-10-26 03:06:33 --> Config Class Initialized
INFO - 2020-10-26 03:06:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:33 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:33 --> URI Class Initialized
INFO - 2020-10-26 03:06:33 --> Router Class Initialized
INFO - 2020-10-26 03:06:33 --> Output Class Initialized
INFO - 2020-10-26 03:06:33 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:33 --> Input Class Initialized
INFO - 2020-10-26 03:06:33 --> Language Class Initialized
INFO - 2020-10-26 03:06:33 --> Language Class Initialized
INFO - 2020-10-26 03:06:33 --> Config Class Initialized
INFO - 2020-10-26 03:06:33 --> Loader Class Initialized
INFO - 2020-10-26 03:06:33 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:33 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:33 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:33 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:33 --> Controller Class Initialized
DEBUG - 2020-10-26 03:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 03:06:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:06:33 --> Final output sent to browser
DEBUG - 2020-10-26 03:06:33 --> Total execution time: 0.2714
INFO - 2020-10-26 03:06:33 --> Config Class Initialized
INFO - 2020-10-26 03:06:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:33 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:33 --> URI Class Initialized
INFO - 2020-10-26 03:06:33 --> Router Class Initialized
INFO - 2020-10-26 03:06:33 --> Output Class Initialized
INFO - 2020-10-26 03:06:33 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:33 --> Input Class Initialized
INFO - 2020-10-26 03:06:33 --> Language Class Initialized
INFO - 2020-10-26 03:06:33 --> Language Class Initialized
INFO - 2020-10-26 03:06:33 --> Config Class Initialized
INFO - 2020-10-26 03:06:33 --> Loader Class Initialized
INFO - 2020-10-26 03:06:33 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:33 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:33 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:33 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:33 --> Controller Class Initialized
INFO - 2020-10-26 03:06:49 --> Config Class Initialized
INFO - 2020-10-26 03:06:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:49 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:49 --> URI Class Initialized
INFO - 2020-10-26 03:06:49 --> Router Class Initialized
INFO - 2020-10-26 03:06:49 --> Output Class Initialized
INFO - 2020-10-26 03:06:49 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:49 --> Input Class Initialized
INFO - 2020-10-26 03:06:49 --> Language Class Initialized
INFO - 2020-10-26 03:06:49 --> Language Class Initialized
INFO - 2020-10-26 03:06:49 --> Config Class Initialized
INFO - 2020-10-26 03:06:49 --> Loader Class Initialized
INFO - 2020-10-26 03:06:49 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:49 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:49 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:49 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:49 --> Controller Class Initialized
DEBUG - 2020-10-26 03:06:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 03:06:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:06:49 --> Final output sent to browser
DEBUG - 2020-10-26 03:06:49 --> Total execution time: 0.2352
INFO - 2020-10-26 03:06:49 --> Config Class Initialized
INFO - 2020-10-26 03:06:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:06:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:06:49 --> Utf8 Class Initialized
INFO - 2020-10-26 03:06:49 --> URI Class Initialized
INFO - 2020-10-26 03:06:49 --> Router Class Initialized
INFO - 2020-10-26 03:06:49 --> Output Class Initialized
INFO - 2020-10-26 03:06:49 --> Security Class Initialized
DEBUG - 2020-10-26 03:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:06:49 --> Input Class Initialized
INFO - 2020-10-26 03:06:49 --> Language Class Initialized
INFO - 2020-10-26 03:06:49 --> Language Class Initialized
INFO - 2020-10-26 03:06:49 --> Config Class Initialized
INFO - 2020-10-26 03:06:49 --> Loader Class Initialized
INFO - 2020-10-26 03:06:49 --> Helper loaded: url_helper
INFO - 2020-10-26 03:06:49 --> Helper loaded: file_helper
INFO - 2020-10-26 03:06:49 --> Helper loaded: form_helper
INFO - 2020-10-26 03:06:49 --> Helper loaded: my_helper
INFO - 2020-10-26 03:06:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:06:49 --> Controller Class Initialized
INFO - 2020-10-26 03:07:08 --> Config Class Initialized
INFO - 2020-10-26 03:07:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:08 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:08 --> URI Class Initialized
INFO - 2020-10-26 03:07:08 --> Router Class Initialized
INFO - 2020-10-26 03:07:08 --> Output Class Initialized
INFO - 2020-10-26 03:07:08 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:08 --> Input Class Initialized
INFO - 2020-10-26 03:07:08 --> Language Class Initialized
INFO - 2020-10-26 03:07:08 --> Language Class Initialized
INFO - 2020-10-26 03:07:08 --> Config Class Initialized
INFO - 2020-10-26 03:07:08 --> Loader Class Initialized
INFO - 2020-10-26 03:07:08 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:08 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:08 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:08 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:08 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:08 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-26 03:07:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:08 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:08 --> Total execution time: 0.2856
INFO - 2020-10-26 03:07:09 --> Config Class Initialized
INFO - 2020-10-26 03:07:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:09 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:09 --> URI Class Initialized
INFO - 2020-10-26 03:07:09 --> Router Class Initialized
INFO - 2020-10-26 03:07:09 --> Output Class Initialized
INFO - 2020-10-26 03:07:09 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:09 --> Input Class Initialized
INFO - 2020-10-26 03:07:09 --> Language Class Initialized
INFO - 2020-10-26 03:07:09 --> Language Class Initialized
INFO - 2020-10-26 03:07:09 --> Config Class Initialized
INFO - 2020-10-26 03:07:09 --> Loader Class Initialized
INFO - 2020-10-26 03:07:09 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:09 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:09 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:09 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:09 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:09 --> Controller Class Initialized
INFO - 2020-10-26 03:07:13 --> Config Class Initialized
INFO - 2020-10-26 03:07:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:13 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:13 --> URI Class Initialized
INFO - 2020-10-26 03:07:13 --> Router Class Initialized
INFO - 2020-10-26 03:07:13 --> Output Class Initialized
INFO - 2020-10-26 03:07:13 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:13 --> Input Class Initialized
INFO - 2020-10-26 03:07:13 --> Language Class Initialized
INFO - 2020-10-26 03:07:13 --> Language Class Initialized
INFO - 2020-10-26 03:07:13 --> Config Class Initialized
INFO - 2020-10-26 03:07:13 --> Loader Class Initialized
INFO - 2020-10-26 03:07:13 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:13 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:13 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:13 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:13 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:13 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 03:07:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:13 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:13 --> Total execution time: 0.2687
INFO - 2020-10-26 03:07:13 --> Config Class Initialized
INFO - 2020-10-26 03:07:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:13 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:13 --> URI Class Initialized
INFO - 2020-10-26 03:07:13 --> Router Class Initialized
INFO - 2020-10-26 03:07:13 --> Output Class Initialized
INFO - 2020-10-26 03:07:13 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:13 --> Input Class Initialized
INFO - 2020-10-26 03:07:13 --> Language Class Initialized
INFO - 2020-10-26 03:07:13 --> Language Class Initialized
INFO - 2020-10-26 03:07:13 --> Config Class Initialized
INFO - 2020-10-26 03:07:13 --> Loader Class Initialized
INFO - 2020-10-26 03:07:13 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:13 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:13 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:13 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:13 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:13 --> Controller Class Initialized
INFO - 2020-10-26 03:07:16 --> Config Class Initialized
INFO - 2020-10-26 03:07:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:16 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:16 --> URI Class Initialized
INFO - 2020-10-26 03:07:16 --> Router Class Initialized
INFO - 2020-10-26 03:07:16 --> Output Class Initialized
INFO - 2020-10-26 03:07:16 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:16 --> Input Class Initialized
INFO - 2020-10-26 03:07:16 --> Language Class Initialized
INFO - 2020-10-26 03:07:16 --> Language Class Initialized
INFO - 2020-10-26 03:07:16 --> Config Class Initialized
INFO - 2020-10-26 03:07:16 --> Loader Class Initialized
INFO - 2020-10-26 03:07:16 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:16 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:16 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:16 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:16 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:16 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:07:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:16 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:16 --> Total execution time: 0.2307
INFO - 2020-10-26 03:07:28 --> Config Class Initialized
INFO - 2020-10-26 03:07:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:28 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:28 --> URI Class Initialized
INFO - 2020-10-26 03:07:28 --> Router Class Initialized
INFO - 2020-10-26 03:07:28 --> Output Class Initialized
INFO - 2020-10-26 03:07:28 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:28 --> Input Class Initialized
INFO - 2020-10-26 03:07:28 --> Language Class Initialized
INFO - 2020-10-26 03:07:28 --> Language Class Initialized
INFO - 2020-10-26 03:07:28 --> Config Class Initialized
INFO - 2020-10-26 03:07:28 --> Loader Class Initialized
INFO - 2020-10-26 03:07:28 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:28 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:28 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:28 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:28 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:28 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:07:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:28 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:28 --> Total execution time: 0.2405
INFO - 2020-10-26 03:07:28 --> Config Class Initialized
INFO - 2020-10-26 03:07:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:28 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:28 --> URI Class Initialized
INFO - 2020-10-26 03:07:28 --> Router Class Initialized
INFO - 2020-10-26 03:07:28 --> Output Class Initialized
INFO - 2020-10-26 03:07:28 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:28 --> Input Class Initialized
INFO - 2020-10-26 03:07:28 --> Language Class Initialized
INFO - 2020-10-26 03:07:28 --> Language Class Initialized
INFO - 2020-10-26 03:07:28 --> Config Class Initialized
INFO - 2020-10-26 03:07:28 --> Loader Class Initialized
INFO - 2020-10-26 03:07:28 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:28 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:28 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:28 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:28 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:28 --> Controller Class Initialized
INFO - 2020-10-26 03:07:34 --> Config Class Initialized
INFO - 2020-10-26 03:07:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:34 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:34 --> URI Class Initialized
INFO - 2020-10-26 03:07:34 --> Router Class Initialized
INFO - 2020-10-26 03:07:34 --> Output Class Initialized
INFO - 2020-10-26 03:07:34 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:34 --> Input Class Initialized
INFO - 2020-10-26 03:07:34 --> Language Class Initialized
INFO - 2020-10-26 03:07:34 --> Language Class Initialized
INFO - 2020-10-26 03:07:34 --> Config Class Initialized
INFO - 2020-10-26 03:07:34 --> Loader Class Initialized
INFO - 2020-10-26 03:07:34 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:35 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:35 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:35 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:35 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-26 03:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:35 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:35 --> Total execution time: 0.3030
INFO - 2020-10-26 03:07:35 --> Config Class Initialized
INFO - 2020-10-26 03:07:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:35 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:35 --> URI Class Initialized
INFO - 2020-10-26 03:07:35 --> Router Class Initialized
INFO - 2020-10-26 03:07:35 --> Output Class Initialized
INFO - 2020-10-26 03:07:35 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:35 --> Input Class Initialized
INFO - 2020-10-26 03:07:35 --> Language Class Initialized
INFO - 2020-10-26 03:07:35 --> Language Class Initialized
INFO - 2020-10-26 03:07:35 --> Config Class Initialized
INFO - 2020-10-26 03:07:35 --> Loader Class Initialized
INFO - 2020-10-26 03:07:35 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:35 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:35 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:35 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:35 --> Controller Class Initialized
INFO - 2020-10-26 03:07:36 --> Config Class Initialized
INFO - 2020-10-26 03:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:36 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:36 --> URI Class Initialized
INFO - 2020-10-26 03:07:36 --> Router Class Initialized
INFO - 2020-10-26 03:07:37 --> Output Class Initialized
INFO - 2020-10-26 03:07:37 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:37 --> Input Class Initialized
INFO - 2020-10-26 03:07:37 --> Language Class Initialized
INFO - 2020-10-26 03:07:37 --> Language Class Initialized
INFO - 2020-10-26 03:07:37 --> Config Class Initialized
INFO - 2020-10-26 03:07:37 --> Loader Class Initialized
INFO - 2020-10-26 03:07:37 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:37 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:37 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:37 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:37 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:37 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-10-26 03:07:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:37 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:37 --> Total execution time: 0.2404
INFO - 2020-10-26 03:07:51 --> Config Class Initialized
INFO - 2020-10-26 03:07:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:51 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:51 --> URI Class Initialized
DEBUG - 2020-10-26 03:07:51 --> No URI present. Default controller set.
INFO - 2020-10-26 03:07:51 --> Router Class Initialized
INFO - 2020-10-26 03:07:51 --> Output Class Initialized
INFO - 2020-10-26 03:07:51 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:51 --> Input Class Initialized
INFO - 2020-10-26 03:07:51 --> Language Class Initialized
INFO - 2020-10-26 03:07:51 --> Language Class Initialized
INFO - 2020-10-26 03:07:51 --> Config Class Initialized
INFO - 2020-10-26 03:07:51 --> Loader Class Initialized
INFO - 2020-10-26 03:07:51 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:51 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:51 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:51 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:51 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 03:07:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:51 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:51 --> Total execution time: 0.2407
INFO - 2020-10-26 03:07:58 --> Config Class Initialized
INFO - 2020-10-26 03:07:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:58 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:58 --> URI Class Initialized
INFO - 2020-10-26 03:07:58 --> Router Class Initialized
INFO - 2020-10-26 03:07:58 --> Output Class Initialized
INFO - 2020-10-26 03:07:58 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:58 --> Input Class Initialized
INFO - 2020-10-26 03:07:58 --> Language Class Initialized
INFO - 2020-10-26 03:07:58 --> Language Class Initialized
INFO - 2020-10-26 03:07:58 --> Config Class Initialized
INFO - 2020-10-26 03:07:58 --> Loader Class Initialized
INFO - 2020-10-26 03:07:58 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:58 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:58 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:58 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:58 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:58 --> Controller Class Initialized
DEBUG - 2020-10-26 03:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-26 03:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:07:58 --> Final output sent to browser
DEBUG - 2020-10-26 03:07:58 --> Total execution time: 0.2321
INFO - 2020-10-26 03:07:58 --> Config Class Initialized
INFO - 2020-10-26 03:07:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:07:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:07:58 --> Utf8 Class Initialized
INFO - 2020-10-26 03:07:58 --> URI Class Initialized
INFO - 2020-10-26 03:07:58 --> Router Class Initialized
INFO - 2020-10-26 03:07:58 --> Output Class Initialized
INFO - 2020-10-26 03:07:58 --> Security Class Initialized
DEBUG - 2020-10-26 03:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:07:58 --> Input Class Initialized
INFO - 2020-10-26 03:07:58 --> Language Class Initialized
INFO - 2020-10-26 03:07:58 --> Language Class Initialized
INFO - 2020-10-26 03:07:58 --> Config Class Initialized
INFO - 2020-10-26 03:07:58 --> Loader Class Initialized
INFO - 2020-10-26 03:07:58 --> Helper loaded: url_helper
INFO - 2020-10-26 03:07:58 --> Helper loaded: file_helper
INFO - 2020-10-26 03:07:58 --> Helper loaded: form_helper
INFO - 2020-10-26 03:07:59 --> Helper loaded: my_helper
INFO - 2020-10-26 03:07:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:07:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:07:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:07:59 --> Controller Class Initialized
INFO - 2020-10-26 03:08:00 --> Config Class Initialized
INFO - 2020-10-26 03:08:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:08:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:08:00 --> Utf8 Class Initialized
INFO - 2020-10-26 03:08:00 --> URI Class Initialized
INFO - 2020-10-26 03:08:00 --> Router Class Initialized
INFO - 2020-10-26 03:08:00 --> Output Class Initialized
INFO - 2020-10-26 03:08:00 --> Security Class Initialized
DEBUG - 2020-10-26 03:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:08:00 --> Input Class Initialized
INFO - 2020-10-26 03:08:00 --> Language Class Initialized
INFO - 2020-10-26 03:08:00 --> Language Class Initialized
INFO - 2020-10-26 03:08:00 --> Config Class Initialized
INFO - 2020-10-26 03:08:00 --> Loader Class Initialized
INFO - 2020-10-26 03:08:00 --> Helper loaded: url_helper
INFO - 2020-10-26 03:08:00 --> Helper loaded: file_helper
INFO - 2020-10-26 03:08:00 --> Helper loaded: form_helper
INFO - 2020-10-26 03:08:00 --> Helper loaded: my_helper
INFO - 2020-10-26 03:08:00 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:08:00 --> Controller Class Initialized
DEBUG - 2020-10-26 03:08:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-26 03:08:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:08:00 --> Final output sent to browser
DEBUG - 2020-10-26 03:08:00 --> Total execution time: 0.2830
INFO - 2020-10-26 03:08:00 --> Config Class Initialized
INFO - 2020-10-26 03:08:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:08:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:08:00 --> Utf8 Class Initialized
INFO - 2020-10-26 03:08:00 --> URI Class Initialized
INFO - 2020-10-26 03:08:00 --> Router Class Initialized
INFO - 2020-10-26 03:08:00 --> Output Class Initialized
INFO - 2020-10-26 03:08:00 --> Security Class Initialized
DEBUG - 2020-10-26 03:08:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:08:00 --> Input Class Initialized
INFO - 2020-10-26 03:08:00 --> Language Class Initialized
INFO - 2020-10-26 03:08:00 --> Language Class Initialized
INFO - 2020-10-26 03:08:00 --> Config Class Initialized
INFO - 2020-10-26 03:08:00 --> Loader Class Initialized
INFO - 2020-10-26 03:08:00 --> Helper loaded: url_helper
INFO - 2020-10-26 03:08:00 --> Helper loaded: file_helper
INFO - 2020-10-26 03:08:00 --> Helper loaded: form_helper
INFO - 2020-10-26 03:08:00 --> Helper loaded: my_helper
INFO - 2020-10-26 03:08:00 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:08:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:08:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:08:00 --> Controller Class Initialized
INFO - 2020-10-26 03:08:02 --> Config Class Initialized
INFO - 2020-10-26 03:08:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:08:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:08:02 --> Utf8 Class Initialized
INFO - 2020-10-26 03:08:02 --> URI Class Initialized
INFO - 2020-10-26 03:08:02 --> Router Class Initialized
INFO - 2020-10-26 03:08:02 --> Output Class Initialized
INFO - 2020-10-26 03:08:02 --> Security Class Initialized
DEBUG - 2020-10-26 03:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:08:02 --> Input Class Initialized
INFO - 2020-10-26 03:08:02 --> Language Class Initialized
INFO - 2020-10-26 03:08:02 --> Language Class Initialized
INFO - 2020-10-26 03:08:02 --> Config Class Initialized
INFO - 2020-10-26 03:08:02 --> Loader Class Initialized
INFO - 2020-10-26 03:08:02 --> Helper loaded: url_helper
INFO - 2020-10-26 03:08:03 --> Helper loaded: file_helper
INFO - 2020-10-26 03:08:03 --> Helper loaded: form_helper
INFO - 2020-10-26 03:08:03 --> Helper loaded: my_helper
INFO - 2020-10-26 03:08:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:08:03 --> Controller Class Initialized
INFO - 2020-10-26 03:08:03 --> Final output sent to browser
DEBUG - 2020-10-26 03:08:03 --> Total execution time: 0.2298
INFO - 2020-10-26 03:09:37 --> Config Class Initialized
INFO - 2020-10-26 03:09:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:09:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:09:37 --> Utf8 Class Initialized
INFO - 2020-10-26 03:09:37 --> URI Class Initialized
INFO - 2020-10-26 03:09:37 --> Router Class Initialized
INFO - 2020-10-26 03:09:37 --> Output Class Initialized
INFO - 2020-10-26 03:09:37 --> Security Class Initialized
DEBUG - 2020-10-26 03:09:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:09:37 --> Input Class Initialized
INFO - 2020-10-26 03:09:37 --> Language Class Initialized
INFO - 2020-10-26 03:09:37 --> Language Class Initialized
INFO - 2020-10-26 03:09:37 --> Config Class Initialized
INFO - 2020-10-26 03:09:37 --> Loader Class Initialized
INFO - 2020-10-26 03:09:37 --> Helper loaded: url_helper
INFO - 2020-10-26 03:09:37 --> Helper loaded: file_helper
INFO - 2020-10-26 03:09:37 --> Helper loaded: form_helper
INFO - 2020-10-26 03:09:37 --> Helper loaded: my_helper
INFO - 2020-10-26 03:09:37 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:09:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:09:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:09:37 --> Controller Class Initialized
INFO - 2020-10-26 03:09:37 --> Final output sent to browser
DEBUG - 2020-10-26 03:09:37 --> Total execution time: 0.2745
INFO - 2020-10-26 03:09:37 --> Config Class Initialized
INFO - 2020-10-26 03:09:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:09:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:09:37 --> Utf8 Class Initialized
INFO - 2020-10-26 03:09:37 --> URI Class Initialized
INFO - 2020-10-26 03:09:37 --> Router Class Initialized
INFO - 2020-10-26 03:09:38 --> Output Class Initialized
INFO - 2020-10-26 03:09:38 --> Security Class Initialized
DEBUG - 2020-10-26 03:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:09:38 --> Input Class Initialized
INFO - 2020-10-26 03:09:38 --> Language Class Initialized
INFO - 2020-10-26 03:09:38 --> Language Class Initialized
INFO - 2020-10-26 03:09:38 --> Config Class Initialized
INFO - 2020-10-26 03:09:38 --> Loader Class Initialized
INFO - 2020-10-26 03:09:38 --> Helper loaded: url_helper
INFO - 2020-10-26 03:09:38 --> Helper loaded: file_helper
INFO - 2020-10-26 03:09:38 --> Helper loaded: form_helper
INFO - 2020-10-26 03:09:38 --> Helper loaded: my_helper
INFO - 2020-10-26 03:09:38 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:09:38 --> Controller Class Initialized
INFO - 2020-10-26 03:09:47 --> Config Class Initialized
INFO - 2020-10-26 03:09:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:09:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:09:47 --> Utf8 Class Initialized
INFO - 2020-10-26 03:09:47 --> URI Class Initialized
INFO - 2020-10-26 03:09:47 --> Router Class Initialized
INFO - 2020-10-26 03:09:47 --> Output Class Initialized
INFO - 2020-10-26 03:09:47 --> Security Class Initialized
DEBUG - 2020-10-26 03:09:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:09:47 --> Input Class Initialized
INFO - 2020-10-26 03:09:47 --> Language Class Initialized
INFO - 2020-10-26 03:09:47 --> Language Class Initialized
INFO - 2020-10-26 03:09:47 --> Config Class Initialized
INFO - 2020-10-26 03:09:47 --> Loader Class Initialized
INFO - 2020-10-26 03:09:47 --> Helper loaded: url_helper
INFO - 2020-10-26 03:09:47 --> Helper loaded: file_helper
INFO - 2020-10-26 03:09:47 --> Helper loaded: form_helper
INFO - 2020-10-26 03:09:47 --> Helper loaded: my_helper
INFO - 2020-10-26 03:09:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:09:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:09:47 --> Controller Class Initialized
INFO - 2020-10-26 03:09:47 --> Final output sent to browser
DEBUG - 2020-10-26 03:09:47 --> Total execution time: 0.2216
INFO - 2020-10-26 03:10:42 --> Config Class Initialized
INFO - 2020-10-26 03:10:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:10:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:10:42 --> Utf8 Class Initialized
INFO - 2020-10-26 03:10:42 --> URI Class Initialized
INFO - 2020-10-26 03:10:42 --> Router Class Initialized
INFO - 2020-10-26 03:10:42 --> Output Class Initialized
INFO - 2020-10-26 03:10:42 --> Security Class Initialized
DEBUG - 2020-10-26 03:10:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:10:42 --> Input Class Initialized
INFO - 2020-10-26 03:10:42 --> Language Class Initialized
INFO - 2020-10-26 03:10:42 --> Language Class Initialized
INFO - 2020-10-26 03:10:42 --> Config Class Initialized
INFO - 2020-10-26 03:10:42 --> Loader Class Initialized
INFO - 2020-10-26 03:10:42 --> Helper loaded: url_helper
INFO - 2020-10-26 03:10:42 --> Helper loaded: file_helper
INFO - 2020-10-26 03:10:42 --> Helper loaded: form_helper
INFO - 2020-10-26 03:10:42 --> Helper loaded: my_helper
INFO - 2020-10-26 03:10:42 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:10:43 --> Controller Class Initialized
INFO - 2020-10-26 03:10:43 --> Final output sent to browser
DEBUG - 2020-10-26 03:10:43 --> Total execution time: 0.2223
INFO - 2020-10-26 03:11:06 --> Config Class Initialized
INFO - 2020-10-26 03:11:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:11:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:11:06 --> Utf8 Class Initialized
INFO - 2020-10-26 03:11:06 --> URI Class Initialized
INFO - 2020-10-26 03:11:06 --> Router Class Initialized
INFO - 2020-10-26 03:11:07 --> Output Class Initialized
INFO - 2020-10-26 03:11:07 --> Security Class Initialized
DEBUG - 2020-10-26 03:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:11:07 --> Input Class Initialized
INFO - 2020-10-26 03:11:07 --> Language Class Initialized
INFO - 2020-10-26 03:11:07 --> Language Class Initialized
INFO - 2020-10-26 03:11:07 --> Config Class Initialized
INFO - 2020-10-26 03:11:07 --> Loader Class Initialized
INFO - 2020-10-26 03:11:07 --> Helper loaded: url_helper
INFO - 2020-10-26 03:11:07 --> Helper loaded: file_helper
INFO - 2020-10-26 03:11:07 --> Helper loaded: form_helper
INFO - 2020-10-26 03:11:07 --> Helper loaded: my_helper
INFO - 2020-10-26 03:11:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:11:07 --> Controller Class Initialized
DEBUG - 2020-10-26 03:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 03:11:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:11:07 --> Final output sent to browser
DEBUG - 2020-10-26 03:11:07 --> Total execution time: 0.2452
INFO - 2020-10-26 03:11:07 --> Config Class Initialized
INFO - 2020-10-26 03:11:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:11:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:11:07 --> Utf8 Class Initialized
INFO - 2020-10-26 03:11:07 --> URI Class Initialized
INFO - 2020-10-26 03:11:07 --> Router Class Initialized
INFO - 2020-10-26 03:11:07 --> Output Class Initialized
INFO - 2020-10-26 03:11:07 --> Security Class Initialized
DEBUG - 2020-10-26 03:11:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:11:07 --> Input Class Initialized
INFO - 2020-10-26 03:11:07 --> Language Class Initialized
INFO - 2020-10-26 03:11:07 --> Language Class Initialized
INFO - 2020-10-26 03:11:07 --> Config Class Initialized
INFO - 2020-10-26 03:11:07 --> Loader Class Initialized
INFO - 2020-10-26 03:11:07 --> Helper loaded: url_helper
INFO - 2020-10-26 03:11:07 --> Helper loaded: file_helper
INFO - 2020-10-26 03:11:07 --> Helper loaded: form_helper
INFO - 2020-10-26 03:11:07 --> Helper loaded: my_helper
INFO - 2020-10-26 03:11:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:11:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:11:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:11:07 --> Controller Class Initialized
INFO - 2020-10-26 03:11:17 --> Config Class Initialized
INFO - 2020-10-26 03:11:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:11:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:11:17 --> Utf8 Class Initialized
INFO - 2020-10-26 03:11:17 --> URI Class Initialized
INFO - 2020-10-26 03:11:17 --> Router Class Initialized
INFO - 2020-10-26 03:11:17 --> Output Class Initialized
INFO - 2020-10-26 03:11:17 --> Security Class Initialized
DEBUG - 2020-10-26 03:11:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:11:17 --> Input Class Initialized
INFO - 2020-10-26 03:11:17 --> Language Class Initialized
INFO - 2020-10-26 03:11:17 --> Language Class Initialized
INFO - 2020-10-26 03:11:17 --> Config Class Initialized
INFO - 2020-10-26 03:11:17 --> Loader Class Initialized
INFO - 2020-10-26 03:11:17 --> Helper loaded: url_helper
INFO - 2020-10-26 03:11:17 --> Helper loaded: file_helper
INFO - 2020-10-26 03:11:17 --> Helper loaded: form_helper
INFO - 2020-10-26 03:11:17 --> Helper loaded: my_helper
INFO - 2020-10-26 03:11:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:11:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:11:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:11:17 --> Controller Class Initialized
ERROR - 2020-10-26 03:11:17 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-26 03:11:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-26 03:11:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:11:17 --> Final output sent to browser
DEBUG - 2020-10-26 03:11:17 --> Total execution time: 0.2674
INFO - 2020-10-26 03:15:04 --> Config Class Initialized
INFO - 2020-10-26 03:15:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:04 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:04 --> URI Class Initialized
INFO - 2020-10-26 03:15:04 --> Router Class Initialized
INFO - 2020-10-26 03:15:04 --> Output Class Initialized
INFO - 2020-10-26 03:15:04 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:04 --> Input Class Initialized
INFO - 2020-10-26 03:15:05 --> Language Class Initialized
INFO - 2020-10-26 03:15:05 --> Language Class Initialized
INFO - 2020-10-26 03:15:05 --> Config Class Initialized
INFO - 2020-10-26 03:15:05 --> Loader Class Initialized
INFO - 2020-10-26 03:15:05 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:05 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:05 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:05 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:05 --> Controller Class Initialized
INFO - 2020-10-26 03:15:06 --> Upload Class Initialized
INFO - 2020-10-26 03:15:06 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-10-26 03:15:06 --> The upload path does not appear to be valid.
INFO - 2020-10-26 03:15:06 --> Config Class Initialized
INFO - 2020-10-26 03:15:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:06 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:06 --> URI Class Initialized
INFO - 2020-10-26 03:15:06 --> Router Class Initialized
INFO - 2020-10-26 03:15:06 --> Output Class Initialized
INFO - 2020-10-26 03:15:06 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:06 --> Input Class Initialized
INFO - 2020-10-26 03:15:06 --> Language Class Initialized
INFO - 2020-10-26 03:15:06 --> Language Class Initialized
INFO - 2020-10-26 03:15:06 --> Config Class Initialized
INFO - 2020-10-26 03:15:06 --> Loader Class Initialized
INFO - 2020-10-26 03:15:06 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:06 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:06 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:06 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:06 --> Controller Class Initialized
DEBUG - 2020-10-26 03:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 03:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:15:06 --> Final output sent to browser
DEBUG - 2020-10-26 03:15:07 --> Total execution time: 0.2765
INFO - 2020-10-26 03:15:07 --> Config Class Initialized
INFO - 2020-10-26 03:15:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:07 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:07 --> URI Class Initialized
INFO - 2020-10-26 03:15:07 --> Router Class Initialized
INFO - 2020-10-26 03:15:07 --> Output Class Initialized
INFO - 2020-10-26 03:15:07 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:07 --> Input Class Initialized
INFO - 2020-10-26 03:15:07 --> Language Class Initialized
INFO - 2020-10-26 03:15:07 --> Language Class Initialized
INFO - 2020-10-26 03:15:07 --> Config Class Initialized
INFO - 2020-10-26 03:15:07 --> Loader Class Initialized
INFO - 2020-10-26 03:15:07 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:07 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:07 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:07 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:07 --> Controller Class Initialized
INFO - 2020-10-26 03:15:14 --> Config Class Initialized
INFO - 2020-10-26 03:15:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:14 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:14 --> URI Class Initialized
INFO - 2020-10-26 03:15:14 --> Router Class Initialized
INFO - 2020-10-26 03:15:14 --> Output Class Initialized
INFO - 2020-10-26 03:15:14 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:14 --> Input Class Initialized
INFO - 2020-10-26 03:15:14 --> Language Class Initialized
INFO - 2020-10-26 03:15:14 --> Language Class Initialized
INFO - 2020-10-26 03:15:14 --> Config Class Initialized
INFO - 2020-10-26 03:15:14 --> Loader Class Initialized
INFO - 2020-10-26 03:15:14 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:14 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:15 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:15 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:15 --> Controller Class Initialized
DEBUG - 2020-10-26 03:15:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 03:15:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:15:15 --> Final output sent to browser
DEBUG - 2020-10-26 03:15:15 --> Total execution time: 0.2391
INFO - 2020-10-26 03:15:15 --> Config Class Initialized
INFO - 2020-10-26 03:15:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:15 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:15 --> URI Class Initialized
INFO - 2020-10-26 03:15:15 --> Router Class Initialized
INFO - 2020-10-26 03:15:15 --> Output Class Initialized
INFO - 2020-10-26 03:15:15 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:15 --> Input Class Initialized
INFO - 2020-10-26 03:15:15 --> Language Class Initialized
INFO - 2020-10-26 03:15:15 --> Language Class Initialized
INFO - 2020-10-26 03:15:15 --> Config Class Initialized
INFO - 2020-10-26 03:15:15 --> Loader Class Initialized
INFO - 2020-10-26 03:15:15 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:15 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:15 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:15 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:15 --> Controller Class Initialized
INFO - 2020-10-26 03:15:19 --> Config Class Initialized
INFO - 2020-10-26 03:15:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:19 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:19 --> URI Class Initialized
INFO - 2020-10-26 03:15:19 --> Router Class Initialized
INFO - 2020-10-26 03:15:19 --> Output Class Initialized
INFO - 2020-10-26 03:15:19 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:19 --> Input Class Initialized
INFO - 2020-10-26 03:15:19 --> Language Class Initialized
INFO - 2020-10-26 03:15:19 --> Language Class Initialized
INFO - 2020-10-26 03:15:19 --> Config Class Initialized
INFO - 2020-10-26 03:15:19 --> Loader Class Initialized
INFO - 2020-10-26 03:15:19 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:19 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:19 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:19 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:19 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:19 --> Controller Class Initialized
INFO - 2020-10-26 03:15:19 --> Final output sent to browser
DEBUG - 2020-10-26 03:15:19 --> Total execution time: 0.2263
INFO - 2020-10-26 03:15:54 --> Config Class Initialized
INFO - 2020-10-26 03:15:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:54 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:54 --> URI Class Initialized
INFO - 2020-10-26 03:15:54 --> Router Class Initialized
INFO - 2020-10-26 03:15:54 --> Output Class Initialized
INFO - 2020-10-26 03:15:54 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:54 --> Input Class Initialized
INFO - 2020-10-26 03:15:54 --> Language Class Initialized
INFO - 2020-10-26 03:15:54 --> Language Class Initialized
INFO - 2020-10-26 03:15:54 --> Config Class Initialized
INFO - 2020-10-26 03:15:54 --> Loader Class Initialized
INFO - 2020-10-26 03:15:54 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:54 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:54 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:54 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:54 --> Controller Class Initialized
INFO - 2020-10-26 03:15:54 --> Final output sent to browser
DEBUG - 2020-10-26 03:15:54 --> Total execution time: 0.2669
INFO - 2020-10-26 03:15:54 --> Config Class Initialized
INFO - 2020-10-26 03:15:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:15:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:15:54 --> Utf8 Class Initialized
INFO - 2020-10-26 03:15:54 --> URI Class Initialized
INFO - 2020-10-26 03:15:54 --> Router Class Initialized
INFO - 2020-10-26 03:15:54 --> Output Class Initialized
INFO - 2020-10-26 03:15:54 --> Security Class Initialized
DEBUG - 2020-10-26 03:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:15:54 --> Input Class Initialized
INFO - 2020-10-26 03:15:54 --> Language Class Initialized
INFO - 2020-10-26 03:15:54 --> Language Class Initialized
INFO - 2020-10-26 03:15:54 --> Config Class Initialized
INFO - 2020-10-26 03:15:54 --> Loader Class Initialized
INFO - 2020-10-26 03:15:54 --> Helper loaded: url_helper
INFO - 2020-10-26 03:15:54 --> Helper loaded: file_helper
INFO - 2020-10-26 03:15:54 --> Helper loaded: form_helper
INFO - 2020-10-26 03:15:54 --> Helper loaded: my_helper
INFO - 2020-10-26 03:15:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:15:54 --> Controller Class Initialized
INFO - 2020-10-26 03:16:02 --> Config Class Initialized
INFO - 2020-10-26 03:16:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:03 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:03 --> URI Class Initialized
INFO - 2020-10-26 03:16:03 --> Router Class Initialized
INFO - 2020-10-26 03:16:03 --> Output Class Initialized
INFO - 2020-10-26 03:16:03 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:03 --> Input Class Initialized
INFO - 2020-10-26 03:16:03 --> Language Class Initialized
INFO - 2020-10-26 03:16:03 --> Language Class Initialized
INFO - 2020-10-26 03:16:03 --> Config Class Initialized
INFO - 2020-10-26 03:16:03 --> Loader Class Initialized
INFO - 2020-10-26 03:16:03 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:03 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:03 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:03 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:03 --> Controller Class Initialized
DEBUG - 2020-10-26 03:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 03:16:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:16:03 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:03 --> Total execution time: 0.2535
INFO - 2020-10-26 03:16:03 --> Config Class Initialized
INFO - 2020-10-26 03:16:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:03 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:03 --> URI Class Initialized
INFO - 2020-10-26 03:16:03 --> Router Class Initialized
INFO - 2020-10-26 03:16:03 --> Output Class Initialized
INFO - 2020-10-26 03:16:03 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:03 --> Input Class Initialized
INFO - 2020-10-26 03:16:03 --> Language Class Initialized
INFO - 2020-10-26 03:16:03 --> Language Class Initialized
INFO - 2020-10-26 03:16:03 --> Config Class Initialized
INFO - 2020-10-26 03:16:03 --> Loader Class Initialized
INFO - 2020-10-26 03:16:03 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:03 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:03 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:03 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:03 --> Controller Class Initialized
INFO - 2020-10-26 03:16:05 --> Config Class Initialized
INFO - 2020-10-26 03:16:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:05 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:05 --> URI Class Initialized
INFO - 2020-10-26 03:16:05 --> Router Class Initialized
INFO - 2020-10-26 03:16:05 --> Output Class Initialized
INFO - 2020-10-26 03:16:05 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:05 --> Input Class Initialized
INFO - 2020-10-26 03:16:05 --> Language Class Initialized
INFO - 2020-10-26 03:16:05 --> Language Class Initialized
INFO - 2020-10-26 03:16:05 --> Config Class Initialized
INFO - 2020-10-26 03:16:05 --> Loader Class Initialized
INFO - 2020-10-26 03:16:05 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:05 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:05 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:05 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:05 --> Controller Class Initialized
INFO - 2020-10-26 03:16:05 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:05 --> Total execution time: 0.2305
INFO - 2020-10-26 03:16:42 --> Config Class Initialized
INFO - 2020-10-26 03:16:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:42 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:42 --> URI Class Initialized
INFO - 2020-10-26 03:16:42 --> Router Class Initialized
INFO - 2020-10-26 03:16:42 --> Output Class Initialized
INFO - 2020-10-26 03:16:42 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:42 --> Input Class Initialized
INFO - 2020-10-26 03:16:42 --> Language Class Initialized
INFO - 2020-10-26 03:16:42 --> Language Class Initialized
INFO - 2020-10-26 03:16:42 --> Config Class Initialized
INFO - 2020-10-26 03:16:42 --> Loader Class Initialized
INFO - 2020-10-26 03:16:42 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:42 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:42 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:42 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:42 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:42 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:42 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:42 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:42 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:42 --> Total execution time: 0.3029
INFO - 2020-10-26 03:16:46 --> Config Class Initialized
INFO - 2020-10-26 03:16:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:46 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:46 --> URI Class Initialized
INFO - 2020-10-26 03:16:46 --> Router Class Initialized
INFO - 2020-10-26 03:16:46 --> Output Class Initialized
INFO - 2020-10-26 03:16:46 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:46 --> Input Class Initialized
INFO - 2020-10-26 03:16:46 --> Language Class Initialized
INFO - 2020-10-26 03:16:46 --> Language Class Initialized
INFO - 2020-10-26 03:16:46 --> Config Class Initialized
INFO - 2020-10-26 03:16:46 --> Loader Class Initialized
INFO - 2020-10-26 03:16:46 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:46 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:46 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:46 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:46 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:46 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:46 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:46 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:46 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:46 --> Total execution time: 0.2877
INFO - 2020-10-26 03:16:47 --> Config Class Initialized
INFO - 2020-10-26 03:16:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:47 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:47 --> URI Class Initialized
INFO - 2020-10-26 03:16:47 --> Router Class Initialized
INFO - 2020-10-26 03:16:47 --> Output Class Initialized
INFO - 2020-10-26 03:16:47 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:47 --> Input Class Initialized
INFO - 2020-10-26 03:16:47 --> Language Class Initialized
INFO - 2020-10-26 03:16:47 --> Language Class Initialized
INFO - 2020-10-26 03:16:47 --> Config Class Initialized
INFO - 2020-10-26 03:16:47 --> Loader Class Initialized
INFO - 2020-10-26 03:16:47 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:47 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:47 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:47 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:47 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:47 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:47 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:47 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:47 --> Total execution time: 0.2989
INFO - 2020-10-26 03:16:50 --> Config Class Initialized
INFO - 2020-10-26 03:16:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:50 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:50 --> URI Class Initialized
INFO - 2020-10-26 03:16:50 --> Router Class Initialized
INFO - 2020-10-26 03:16:50 --> Output Class Initialized
INFO - 2020-10-26 03:16:50 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:50 --> Input Class Initialized
INFO - 2020-10-26 03:16:50 --> Language Class Initialized
INFO - 2020-10-26 03:16:50 --> Language Class Initialized
INFO - 2020-10-26 03:16:50 --> Config Class Initialized
INFO - 2020-10-26 03:16:50 --> Loader Class Initialized
INFO - 2020-10-26 03:16:50 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:50 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:50 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:50 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:50 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:50 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:50 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:50 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:51 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:51 --> Total execution time: 0.2870
INFO - 2020-10-26 03:16:51 --> Config Class Initialized
INFO - 2020-10-26 03:16:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:51 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:51 --> URI Class Initialized
INFO - 2020-10-26 03:16:51 --> Router Class Initialized
INFO - 2020-10-26 03:16:51 --> Output Class Initialized
INFO - 2020-10-26 03:16:51 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:51 --> Input Class Initialized
INFO - 2020-10-26 03:16:51 --> Language Class Initialized
INFO - 2020-10-26 03:16:51 --> Language Class Initialized
INFO - 2020-10-26 03:16:51 --> Config Class Initialized
INFO - 2020-10-26 03:16:51 --> Loader Class Initialized
INFO - 2020-10-26 03:16:51 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:51 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:51 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:51 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:51 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:51 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:51 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:51 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:51 --> Total execution time: 0.2660
INFO - 2020-10-26 03:16:51 --> Config Class Initialized
INFO - 2020-10-26 03:16:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:51 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:51 --> URI Class Initialized
INFO - 2020-10-26 03:16:51 --> Router Class Initialized
INFO - 2020-10-26 03:16:51 --> Output Class Initialized
INFO - 2020-10-26 03:16:51 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:51 --> Input Class Initialized
INFO - 2020-10-26 03:16:51 --> Language Class Initialized
INFO - 2020-10-26 03:16:51 --> Language Class Initialized
INFO - 2020-10-26 03:16:51 --> Config Class Initialized
INFO - 2020-10-26 03:16:51 --> Loader Class Initialized
INFO - 2020-10-26 03:16:51 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:51 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:51 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:51 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:51 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:51 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:51 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:51 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:51 --> Total execution time: 0.3001
INFO - 2020-10-26 03:16:51 --> Config Class Initialized
INFO - 2020-10-26 03:16:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:51 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:51 --> URI Class Initialized
INFO - 2020-10-26 03:16:51 --> Router Class Initialized
INFO - 2020-10-26 03:16:51 --> Output Class Initialized
INFO - 2020-10-26 03:16:51 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:51 --> Input Class Initialized
INFO - 2020-10-26 03:16:51 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Config Class Initialized
INFO - 2020-10-26 03:16:52 --> Loader Class Initialized
INFO - 2020-10-26 03:16:52 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:52 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:52 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:52 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:52 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:52 --> Total execution time: 0.3355
INFO - 2020-10-26 03:16:52 --> Config Class Initialized
INFO - 2020-10-26 03:16:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:52 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:52 --> URI Class Initialized
INFO - 2020-10-26 03:16:52 --> Router Class Initialized
INFO - 2020-10-26 03:16:52 --> Output Class Initialized
INFO - 2020-10-26 03:16:52 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:52 --> Input Class Initialized
INFO - 2020-10-26 03:16:52 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Config Class Initialized
INFO - 2020-10-26 03:16:52 --> Loader Class Initialized
INFO - 2020-10-26 03:16:52 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:52 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:52 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:52 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:52 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:52 --> Total execution time: 0.2690
INFO - 2020-10-26 03:16:52 --> Config Class Initialized
INFO - 2020-10-26 03:16:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:52 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:52 --> URI Class Initialized
INFO - 2020-10-26 03:16:52 --> Router Class Initialized
INFO - 2020-10-26 03:16:52 --> Output Class Initialized
INFO - 2020-10-26 03:16:52 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:52 --> Input Class Initialized
INFO - 2020-10-26 03:16:52 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Config Class Initialized
INFO - 2020-10-26 03:16:52 --> Loader Class Initialized
INFO - 2020-10-26 03:16:52 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:52 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:52 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:52 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:52 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:52 --> Total execution time: 0.2736
INFO - 2020-10-26 03:16:52 --> Config Class Initialized
INFO - 2020-10-26 03:16:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:52 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:52 --> URI Class Initialized
INFO - 2020-10-26 03:16:52 --> Router Class Initialized
INFO - 2020-10-26 03:16:52 --> Output Class Initialized
INFO - 2020-10-26 03:16:52 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:52 --> Input Class Initialized
INFO - 2020-10-26 03:16:52 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Language Class Initialized
INFO - 2020-10-26 03:16:52 --> Config Class Initialized
INFO - 2020-10-26 03:16:52 --> Loader Class Initialized
INFO - 2020-10-26 03:16:52 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:52 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:53 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:53 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:53 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:53 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:53 --> Total execution time: 0.2754
INFO - 2020-10-26 03:16:53 --> Config Class Initialized
INFO - 2020-10-26 03:16:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:53 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:53 --> URI Class Initialized
INFO - 2020-10-26 03:16:53 --> Router Class Initialized
INFO - 2020-10-26 03:16:53 --> Output Class Initialized
INFO - 2020-10-26 03:16:53 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:53 --> Input Class Initialized
INFO - 2020-10-26 03:16:53 --> Language Class Initialized
INFO - 2020-10-26 03:16:53 --> Language Class Initialized
INFO - 2020-10-26 03:16:53 --> Config Class Initialized
INFO - 2020-10-26 03:16:53 --> Loader Class Initialized
INFO - 2020-10-26 03:16:53 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:53 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:53 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:53 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:53 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:53 --> Total execution time: 0.2732
INFO - 2020-10-26 03:16:53 --> Config Class Initialized
INFO - 2020-10-26 03:16:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:53 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:53 --> URI Class Initialized
INFO - 2020-10-26 03:16:53 --> Router Class Initialized
INFO - 2020-10-26 03:16:53 --> Output Class Initialized
INFO - 2020-10-26 03:16:53 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:53 --> Input Class Initialized
INFO - 2020-10-26 03:16:53 --> Language Class Initialized
INFO - 2020-10-26 03:16:53 --> Language Class Initialized
INFO - 2020-10-26 03:16:53 --> Config Class Initialized
INFO - 2020-10-26 03:16:53 --> Loader Class Initialized
INFO - 2020-10-26 03:16:53 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:53 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:53 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:53 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:53 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:53 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:53 --> Total execution time: 0.2995
INFO - 2020-10-26 03:16:54 --> Config Class Initialized
INFO - 2020-10-26 03:16:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:54 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:54 --> URI Class Initialized
INFO - 2020-10-26 03:16:54 --> Router Class Initialized
INFO - 2020-10-26 03:16:54 --> Output Class Initialized
INFO - 2020-10-26 03:16:54 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:54 --> Input Class Initialized
INFO - 2020-10-26 03:16:54 --> Language Class Initialized
INFO - 2020-10-26 03:16:54 --> Language Class Initialized
INFO - 2020-10-26 03:16:54 --> Config Class Initialized
INFO - 2020-10-26 03:16:54 --> Loader Class Initialized
INFO - 2020-10-26 03:16:54 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:54 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:54 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:54 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:54 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:54 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:54 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:54 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:54 --> Total execution time: 0.2821
INFO - 2020-10-26 03:16:54 --> Config Class Initialized
INFO - 2020-10-26 03:16:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:54 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:54 --> URI Class Initialized
INFO - 2020-10-26 03:16:54 --> Router Class Initialized
INFO - 2020-10-26 03:16:54 --> Output Class Initialized
INFO - 2020-10-26 03:16:54 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:54 --> Input Class Initialized
INFO - 2020-10-26 03:16:54 --> Language Class Initialized
INFO - 2020-10-26 03:16:54 --> Language Class Initialized
INFO - 2020-10-26 03:16:54 --> Config Class Initialized
INFO - 2020-10-26 03:16:54 --> Loader Class Initialized
INFO - 2020-10-26 03:16:54 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:54 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:54 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:54 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:54 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:54 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:54 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:54 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:54 --> Total execution time: 0.2741
INFO - 2020-10-26 03:16:54 --> Config Class Initialized
INFO - 2020-10-26 03:16:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:55 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:55 --> URI Class Initialized
INFO - 2020-10-26 03:16:55 --> Router Class Initialized
INFO - 2020-10-26 03:16:55 --> Output Class Initialized
INFO - 2020-10-26 03:16:55 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:55 --> Input Class Initialized
INFO - 2020-10-26 03:16:55 --> Language Class Initialized
INFO - 2020-10-26 03:16:55 --> Language Class Initialized
INFO - 2020-10-26 03:16:55 --> Config Class Initialized
INFO - 2020-10-26 03:16:55 --> Loader Class Initialized
INFO - 2020-10-26 03:16:55 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:55 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:55 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:55 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:55 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:55 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:55 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:55 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:55 --> Total execution time: 0.3132
INFO - 2020-10-26 03:16:55 --> Config Class Initialized
INFO - 2020-10-26 03:16:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:55 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:55 --> URI Class Initialized
INFO - 2020-10-26 03:16:55 --> Router Class Initialized
INFO - 2020-10-26 03:16:55 --> Output Class Initialized
INFO - 2020-10-26 03:16:55 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:55 --> Input Class Initialized
INFO - 2020-10-26 03:16:55 --> Language Class Initialized
INFO - 2020-10-26 03:16:55 --> Language Class Initialized
INFO - 2020-10-26 03:16:55 --> Config Class Initialized
INFO - 2020-10-26 03:16:55 --> Loader Class Initialized
INFO - 2020-10-26 03:16:55 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:55 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:55 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:55 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:55 --> Controller Class Initialized
ERROR - 2020-10-26 03:16:55 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 03:16:55 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 03:16:55 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:55 --> Total execution time: 0.2701
INFO - 2020-10-26 03:16:59 --> Config Class Initialized
INFO - 2020-10-26 03:16:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:59 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:59 --> URI Class Initialized
INFO - 2020-10-26 03:16:59 --> Router Class Initialized
INFO - 2020-10-26 03:16:59 --> Output Class Initialized
INFO - 2020-10-26 03:16:59 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:59 --> Input Class Initialized
INFO - 2020-10-26 03:16:59 --> Language Class Initialized
INFO - 2020-10-26 03:16:59 --> Language Class Initialized
INFO - 2020-10-26 03:16:59 --> Config Class Initialized
INFO - 2020-10-26 03:16:59 --> Loader Class Initialized
INFO - 2020-10-26 03:16:59 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:59 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:59 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:59 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:59 --> Controller Class Initialized
DEBUG - 2020-10-26 03:16:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-26 03:16:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:16:59 --> Final output sent to browser
DEBUG - 2020-10-26 03:16:59 --> Total execution time: 0.2566
INFO - 2020-10-26 03:16:59 --> Config Class Initialized
INFO - 2020-10-26 03:16:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:16:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:16:59 --> Utf8 Class Initialized
INFO - 2020-10-26 03:16:59 --> URI Class Initialized
INFO - 2020-10-26 03:16:59 --> Router Class Initialized
INFO - 2020-10-26 03:16:59 --> Output Class Initialized
INFO - 2020-10-26 03:16:59 --> Security Class Initialized
DEBUG - 2020-10-26 03:16:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:16:59 --> Input Class Initialized
INFO - 2020-10-26 03:16:59 --> Language Class Initialized
INFO - 2020-10-26 03:16:59 --> Language Class Initialized
INFO - 2020-10-26 03:16:59 --> Config Class Initialized
INFO - 2020-10-26 03:16:59 --> Loader Class Initialized
INFO - 2020-10-26 03:16:59 --> Helper loaded: url_helper
INFO - 2020-10-26 03:16:59 --> Helper loaded: file_helper
INFO - 2020-10-26 03:16:59 --> Helper loaded: form_helper
INFO - 2020-10-26 03:16:59 --> Helper loaded: my_helper
INFO - 2020-10-26 03:16:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:16:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:16:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:16:59 --> Controller Class Initialized
INFO - 2020-10-26 03:17:01 --> Config Class Initialized
INFO - 2020-10-26 03:17:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:01 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:01 --> URI Class Initialized
INFO - 2020-10-26 03:17:01 --> Router Class Initialized
INFO - 2020-10-26 03:17:01 --> Output Class Initialized
INFO - 2020-10-26 03:17:01 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:01 --> Input Class Initialized
INFO - 2020-10-26 03:17:01 --> Language Class Initialized
INFO - 2020-10-26 03:17:01 --> Language Class Initialized
INFO - 2020-10-26 03:17:01 --> Config Class Initialized
INFO - 2020-10-26 03:17:01 --> Loader Class Initialized
INFO - 2020-10-26 03:17:01 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:01 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:01 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:01 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:01 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:01 --> Controller Class Initialized
INFO - 2020-10-26 03:17:01 --> Final output sent to browser
DEBUG - 2020-10-26 03:17:01 --> Total execution time: 0.2355
INFO - 2020-10-26 03:17:13 --> Config Class Initialized
INFO - 2020-10-26 03:17:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:13 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:13 --> URI Class Initialized
INFO - 2020-10-26 03:17:13 --> Router Class Initialized
INFO - 2020-10-26 03:17:13 --> Output Class Initialized
INFO - 2020-10-26 03:17:13 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:13 --> Input Class Initialized
INFO - 2020-10-26 03:17:13 --> Language Class Initialized
INFO - 2020-10-26 03:17:13 --> Language Class Initialized
INFO - 2020-10-26 03:17:13 --> Config Class Initialized
INFO - 2020-10-26 03:17:13 --> Loader Class Initialized
INFO - 2020-10-26 03:17:13 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:13 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:13 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:13 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:13 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:13 --> Controller Class Initialized
INFO - 2020-10-26 03:17:13 --> Final output sent to browser
DEBUG - 2020-10-26 03:17:13 --> Total execution time: 0.2639
INFO - 2020-10-26 03:17:13 --> Config Class Initialized
INFO - 2020-10-26 03:17:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:14 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:14 --> URI Class Initialized
INFO - 2020-10-26 03:17:14 --> Router Class Initialized
INFO - 2020-10-26 03:17:14 --> Output Class Initialized
INFO - 2020-10-26 03:17:14 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:14 --> Input Class Initialized
INFO - 2020-10-26 03:17:14 --> Language Class Initialized
INFO - 2020-10-26 03:17:14 --> Language Class Initialized
INFO - 2020-10-26 03:17:14 --> Config Class Initialized
INFO - 2020-10-26 03:17:14 --> Loader Class Initialized
INFO - 2020-10-26 03:17:14 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:14 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:14 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:14 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:14 --> Controller Class Initialized
INFO - 2020-10-26 03:17:18 --> Config Class Initialized
INFO - 2020-10-26 03:17:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:18 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:18 --> URI Class Initialized
INFO - 2020-10-26 03:17:18 --> Router Class Initialized
INFO - 2020-10-26 03:17:18 --> Output Class Initialized
INFO - 2020-10-26 03:17:18 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:18 --> Input Class Initialized
INFO - 2020-10-26 03:17:18 --> Language Class Initialized
INFO - 2020-10-26 03:17:18 --> Language Class Initialized
INFO - 2020-10-26 03:17:18 --> Config Class Initialized
INFO - 2020-10-26 03:17:18 --> Loader Class Initialized
INFO - 2020-10-26 03:17:18 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:18 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:18 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:18 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:18 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:18 --> Controller Class Initialized
DEBUG - 2020-10-26 03:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 03:17:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:17:18 --> Final output sent to browser
DEBUG - 2020-10-26 03:17:18 --> Total execution time: 0.2655
INFO - 2020-10-26 03:17:18 --> Config Class Initialized
INFO - 2020-10-26 03:17:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:18 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:18 --> URI Class Initialized
INFO - 2020-10-26 03:17:18 --> Router Class Initialized
INFO - 2020-10-26 03:17:18 --> Output Class Initialized
INFO - 2020-10-26 03:17:18 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:18 --> Input Class Initialized
INFO - 2020-10-26 03:17:18 --> Language Class Initialized
INFO - 2020-10-26 03:17:18 --> Language Class Initialized
INFO - 2020-10-26 03:17:18 --> Config Class Initialized
INFO - 2020-10-26 03:17:18 --> Loader Class Initialized
INFO - 2020-10-26 03:17:18 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:18 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:18 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:18 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:18 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:18 --> Controller Class Initialized
INFO - 2020-10-26 03:17:22 --> Config Class Initialized
INFO - 2020-10-26 03:17:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:22 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:22 --> URI Class Initialized
INFO - 2020-10-26 03:17:22 --> Router Class Initialized
INFO - 2020-10-26 03:17:22 --> Output Class Initialized
INFO - 2020-10-26 03:17:22 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:22 --> Input Class Initialized
INFO - 2020-10-26 03:17:22 --> Language Class Initialized
INFO - 2020-10-26 03:17:23 --> Language Class Initialized
INFO - 2020-10-26 03:17:23 --> Config Class Initialized
INFO - 2020-10-26 03:17:23 --> Loader Class Initialized
INFO - 2020-10-26 03:17:23 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:23 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:23 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:23 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:23 --> Controller Class Initialized
INFO - 2020-10-26 03:17:23 --> Final output sent to browser
DEBUG - 2020-10-26 03:17:23 --> Total execution time: 0.2582
INFO - 2020-10-26 03:17:32 --> Config Class Initialized
INFO - 2020-10-26 03:17:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:32 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:32 --> URI Class Initialized
INFO - 2020-10-26 03:17:33 --> Router Class Initialized
INFO - 2020-10-26 03:17:33 --> Output Class Initialized
INFO - 2020-10-26 03:17:33 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:33 --> Input Class Initialized
INFO - 2020-10-26 03:17:33 --> Language Class Initialized
INFO - 2020-10-26 03:17:33 --> Language Class Initialized
INFO - 2020-10-26 03:17:33 --> Config Class Initialized
INFO - 2020-10-26 03:17:33 --> Loader Class Initialized
INFO - 2020-10-26 03:17:33 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:33 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:33 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:33 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:33 --> Controller Class Initialized
DEBUG - 2020-10-26 03:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:17:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:17:33 --> Final output sent to browser
DEBUG - 2020-10-26 03:17:33 --> Total execution time: 0.2704
INFO - 2020-10-26 03:17:35 --> Config Class Initialized
INFO - 2020-10-26 03:17:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:17:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:17:35 --> Utf8 Class Initialized
INFO - 2020-10-26 03:17:35 --> URI Class Initialized
INFO - 2020-10-26 03:17:35 --> Router Class Initialized
INFO - 2020-10-26 03:17:35 --> Output Class Initialized
INFO - 2020-10-26 03:17:35 --> Security Class Initialized
DEBUG - 2020-10-26 03:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:17:35 --> Input Class Initialized
INFO - 2020-10-26 03:17:35 --> Language Class Initialized
INFO - 2020-10-26 03:17:35 --> Language Class Initialized
INFO - 2020-10-26 03:17:35 --> Config Class Initialized
INFO - 2020-10-26 03:17:35 --> Loader Class Initialized
INFO - 2020-10-26 03:17:35 --> Helper loaded: url_helper
INFO - 2020-10-26 03:17:35 --> Helper loaded: file_helper
INFO - 2020-10-26 03:17:35 --> Helper loaded: form_helper
INFO - 2020-10-26 03:17:35 --> Helper loaded: my_helper
INFO - 2020-10-26 03:17:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:17:35 --> Controller Class Initialized
DEBUG - 2020-10-26 03:17:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-26 03:17:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:17:35 --> Final output sent to browser
DEBUG - 2020-10-26 03:17:35 --> Total execution time: 0.3582
INFO - 2020-10-26 03:18:06 --> Config Class Initialized
INFO - 2020-10-26 03:18:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:18:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:18:06 --> Utf8 Class Initialized
INFO - 2020-10-26 03:18:06 --> URI Class Initialized
INFO - 2020-10-26 03:18:06 --> Router Class Initialized
INFO - 2020-10-26 03:18:06 --> Output Class Initialized
INFO - 2020-10-26 03:18:06 --> Security Class Initialized
DEBUG - 2020-10-26 03:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:18:06 --> Input Class Initialized
INFO - 2020-10-26 03:18:06 --> Language Class Initialized
INFO - 2020-10-26 03:18:06 --> Language Class Initialized
INFO - 2020-10-26 03:18:06 --> Config Class Initialized
INFO - 2020-10-26 03:18:06 --> Loader Class Initialized
INFO - 2020-10-26 03:18:06 --> Helper loaded: url_helper
INFO - 2020-10-26 03:18:06 --> Helper loaded: file_helper
INFO - 2020-10-26 03:18:06 --> Helper loaded: form_helper
INFO - 2020-10-26 03:18:06 --> Helper loaded: my_helper
INFO - 2020-10-26 03:18:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:18:06 --> Controller Class Initialized
INFO - 2020-10-26 03:18:06 --> Config Class Initialized
INFO - 2020-10-26 03:18:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:18:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:18:06 --> Utf8 Class Initialized
INFO - 2020-10-26 03:18:06 --> URI Class Initialized
INFO - 2020-10-26 03:18:06 --> Router Class Initialized
INFO - 2020-10-26 03:18:06 --> Output Class Initialized
INFO - 2020-10-26 03:18:06 --> Security Class Initialized
DEBUG - 2020-10-26 03:18:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:18:06 --> Input Class Initialized
INFO - 2020-10-26 03:18:06 --> Language Class Initialized
INFO - 2020-10-26 03:18:06 --> Language Class Initialized
INFO - 2020-10-26 03:18:06 --> Config Class Initialized
INFO - 2020-10-26 03:18:06 --> Loader Class Initialized
INFO - 2020-10-26 03:18:06 --> Helper loaded: url_helper
INFO - 2020-10-26 03:18:06 --> Helper loaded: file_helper
INFO - 2020-10-26 03:18:06 --> Helper loaded: form_helper
INFO - 2020-10-26 03:18:06 --> Helper loaded: my_helper
INFO - 2020-10-26 03:18:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:18:06 --> Controller Class Initialized
DEBUG - 2020-10-26 03:18:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:18:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:18:06 --> Final output sent to browser
DEBUG - 2020-10-26 03:18:06 --> Total execution time: 0.2743
INFO - 2020-10-26 03:18:22 --> Config Class Initialized
INFO - 2020-10-26 03:18:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:18:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:18:22 --> Utf8 Class Initialized
INFO - 2020-10-26 03:18:22 --> URI Class Initialized
INFO - 2020-10-26 03:18:22 --> Router Class Initialized
INFO - 2020-10-26 03:18:23 --> Output Class Initialized
INFO - 2020-10-26 03:18:23 --> Security Class Initialized
DEBUG - 2020-10-26 03:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:18:23 --> Input Class Initialized
INFO - 2020-10-26 03:18:23 --> Language Class Initialized
INFO - 2020-10-26 03:18:23 --> Language Class Initialized
INFO - 2020-10-26 03:18:23 --> Config Class Initialized
INFO - 2020-10-26 03:18:23 --> Loader Class Initialized
INFO - 2020-10-26 03:18:23 --> Helper loaded: url_helper
INFO - 2020-10-26 03:18:23 --> Helper loaded: file_helper
INFO - 2020-10-26 03:18:23 --> Helper loaded: form_helper
INFO - 2020-10-26 03:18:23 --> Helper loaded: my_helper
INFO - 2020-10-26 03:18:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:18:23 --> Controller Class Initialized
DEBUG - 2020-10-26 03:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:18:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:18:23 --> Final output sent to browser
DEBUG - 2020-10-26 03:18:23 --> Total execution time: 0.2664
INFO - 2020-10-26 03:18:23 --> Config Class Initialized
INFO - 2020-10-26 03:18:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:18:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:18:23 --> Utf8 Class Initialized
INFO - 2020-10-26 03:18:23 --> URI Class Initialized
INFO - 2020-10-26 03:18:23 --> Router Class Initialized
INFO - 2020-10-26 03:18:23 --> Output Class Initialized
INFO - 2020-10-26 03:18:23 --> Security Class Initialized
DEBUG - 2020-10-26 03:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:18:23 --> Input Class Initialized
INFO - 2020-10-26 03:18:23 --> Language Class Initialized
INFO - 2020-10-26 03:18:23 --> Language Class Initialized
INFO - 2020-10-26 03:18:23 --> Config Class Initialized
INFO - 2020-10-26 03:18:23 --> Loader Class Initialized
INFO - 2020-10-26 03:18:23 --> Helper loaded: url_helper
INFO - 2020-10-26 03:18:23 --> Helper loaded: file_helper
INFO - 2020-10-26 03:18:23 --> Helper loaded: form_helper
INFO - 2020-10-26 03:18:23 --> Helper loaded: my_helper
INFO - 2020-10-26 03:18:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:18:23 --> Controller Class Initialized
INFO - 2020-10-26 03:18:25 --> Config Class Initialized
INFO - 2020-10-26 03:18:25 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:18:25 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:18:25 --> Utf8 Class Initialized
INFO - 2020-10-26 03:18:25 --> URI Class Initialized
INFO - 2020-10-26 03:18:25 --> Router Class Initialized
INFO - 2020-10-26 03:18:25 --> Output Class Initialized
INFO - 2020-10-26 03:18:25 --> Security Class Initialized
DEBUG - 2020-10-26 03:18:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:18:25 --> Input Class Initialized
INFO - 2020-10-26 03:18:25 --> Language Class Initialized
INFO - 2020-10-26 03:18:25 --> Language Class Initialized
INFO - 2020-10-26 03:18:25 --> Config Class Initialized
INFO - 2020-10-26 03:18:25 --> Loader Class Initialized
INFO - 2020-10-26 03:18:25 --> Helper loaded: url_helper
INFO - 2020-10-26 03:18:25 --> Helper loaded: file_helper
INFO - 2020-10-26 03:18:25 --> Helper loaded: form_helper
INFO - 2020-10-26 03:18:25 --> Helper loaded: my_helper
INFO - 2020-10-26 03:18:25 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:18:25 --> Controller Class Initialized
DEBUG - 2020-10-26 03:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-10-26 03:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:18:25 --> Final output sent to browser
DEBUG - 2020-10-26 03:18:25 --> Total execution time: 0.2622
INFO - 2020-10-26 03:19:13 --> Config Class Initialized
INFO - 2020-10-26 03:19:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:13 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:13 --> URI Class Initialized
INFO - 2020-10-26 03:19:13 --> Router Class Initialized
INFO - 2020-10-26 03:19:13 --> Output Class Initialized
INFO - 2020-10-26 03:19:13 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:13 --> Input Class Initialized
INFO - 2020-10-26 03:19:13 --> Language Class Initialized
INFO - 2020-10-26 03:19:13 --> Language Class Initialized
INFO - 2020-10-26 03:19:13 --> Config Class Initialized
INFO - 2020-10-26 03:19:13 --> Loader Class Initialized
INFO - 2020-10-26 03:19:13 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:13 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:13 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:13 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:13 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:13 --> Controller Class Initialized
INFO - 2020-10-26 03:19:13 --> Config Class Initialized
INFO - 2020-10-26 03:19:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:13 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:13 --> URI Class Initialized
INFO - 2020-10-26 03:19:14 --> Router Class Initialized
INFO - 2020-10-26 03:19:14 --> Output Class Initialized
INFO - 2020-10-26 03:19:14 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:14 --> Input Class Initialized
INFO - 2020-10-26 03:19:14 --> Language Class Initialized
INFO - 2020-10-26 03:19:14 --> Language Class Initialized
INFO - 2020-10-26 03:19:14 --> Config Class Initialized
INFO - 2020-10-26 03:19:14 --> Loader Class Initialized
INFO - 2020-10-26 03:19:14 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:14 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:14 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:14 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:14 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:19:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:14 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:14 --> Total execution time: 0.2702
INFO - 2020-10-26 03:19:14 --> Config Class Initialized
INFO - 2020-10-26 03:19:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:14 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:14 --> URI Class Initialized
INFO - 2020-10-26 03:19:14 --> Router Class Initialized
INFO - 2020-10-26 03:19:14 --> Output Class Initialized
INFO - 2020-10-26 03:19:14 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:14 --> Input Class Initialized
INFO - 2020-10-26 03:19:14 --> Language Class Initialized
INFO - 2020-10-26 03:19:14 --> Language Class Initialized
INFO - 2020-10-26 03:19:14 --> Config Class Initialized
INFO - 2020-10-26 03:19:14 --> Loader Class Initialized
INFO - 2020-10-26 03:19:14 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:14 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:14 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:14 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:14 --> Controller Class Initialized
INFO - 2020-10-26 03:19:21 --> Config Class Initialized
INFO - 2020-10-26 03:19:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:21 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:21 --> URI Class Initialized
INFO - 2020-10-26 03:19:21 --> Router Class Initialized
INFO - 2020-10-26 03:19:21 --> Output Class Initialized
INFO - 2020-10-26 03:19:21 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:21 --> Input Class Initialized
INFO - 2020-10-26 03:19:21 --> Language Class Initialized
INFO - 2020-10-26 03:19:21 --> Language Class Initialized
INFO - 2020-10-26 03:19:21 --> Config Class Initialized
INFO - 2020-10-26 03:19:21 --> Loader Class Initialized
INFO - 2020-10-26 03:19:21 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:21 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:21 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:21 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:21 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:21 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:19:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:21 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:21 --> Total execution time: 0.2656
INFO - 2020-10-26 03:19:24 --> Config Class Initialized
INFO - 2020-10-26 03:19:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:24 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:24 --> URI Class Initialized
INFO - 2020-10-26 03:19:24 --> Router Class Initialized
INFO - 2020-10-26 03:19:24 --> Output Class Initialized
INFO - 2020-10-26 03:19:24 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:24 --> Input Class Initialized
INFO - 2020-10-26 03:19:24 --> Language Class Initialized
INFO - 2020-10-26 03:19:24 --> Language Class Initialized
INFO - 2020-10-26 03:19:24 --> Config Class Initialized
INFO - 2020-10-26 03:19:24 --> Loader Class Initialized
INFO - 2020-10-26 03:19:24 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:24 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:24 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:24 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:24 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-26 03:19:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:24 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:24 --> Total execution time: 0.2928
INFO - 2020-10-26 03:19:24 --> Config Class Initialized
INFO - 2020-10-26 03:19:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:24 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:24 --> URI Class Initialized
INFO - 2020-10-26 03:19:24 --> Router Class Initialized
INFO - 2020-10-26 03:19:24 --> Output Class Initialized
INFO - 2020-10-26 03:19:24 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:24 --> Input Class Initialized
INFO - 2020-10-26 03:19:24 --> Language Class Initialized
INFO - 2020-10-26 03:19:24 --> Language Class Initialized
INFO - 2020-10-26 03:19:24 --> Config Class Initialized
INFO - 2020-10-26 03:19:24 --> Loader Class Initialized
INFO - 2020-10-26 03:19:24 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:24 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:24 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:24 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:24 --> Controller Class Initialized
INFO - 2020-10-26 03:19:27 --> Config Class Initialized
INFO - 2020-10-26 03:19:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:27 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:27 --> URI Class Initialized
INFO - 2020-10-26 03:19:27 --> Router Class Initialized
INFO - 2020-10-26 03:19:27 --> Output Class Initialized
INFO - 2020-10-26 03:19:27 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:27 --> Input Class Initialized
INFO - 2020-10-26 03:19:27 --> Language Class Initialized
INFO - 2020-10-26 03:19:27 --> Language Class Initialized
INFO - 2020-10-26 03:19:27 --> Config Class Initialized
INFO - 2020-10-26 03:19:27 --> Loader Class Initialized
INFO - 2020-10-26 03:19:27 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:27 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:27 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:28 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:28 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:28 --> Controller Class Initialized
INFO - 2020-10-26 03:19:28 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:28 --> Total execution time: 0.2298
INFO - 2020-10-26 03:19:44 --> Config Class Initialized
INFO - 2020-10-26 03:19:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:44 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:44 --> URI Class Initialized
INFO - 2020-10-26 03:19:44 --> Router Class Initialized
INFO - 2020-10-26 03:19:44 --> Output Class Initialized
INFO - 2020-10-26 03:19:44 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:44 --> Input Class Initialized
INFO - 2020-10-26 03:19:44 --> Language Class Initialized
INFO - 2020-10-26 03:19:44 --> Language Class Initialized
INFO - 2020-10-26 03:19:44 --> Config Class Initialized
INFO - 2020-10-26 03:19:44 --> Loader Class Initialized
INFO - 2020-10-26 03:19:44 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:44 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:44 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:44 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:44 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:44 --> Controller Class Initialized
INFO - 2020-10-26 03:19:44 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:44 --> Total execution time: 0.2953
INFO - 2020-10-26 03:19:44 --> Config Class Initialized
INFO - 2020-10-26 03:19:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:44 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:44 --> URI Class Initialized
INFO - 2020-10-26 03:19:44 --> Router Class Initialized
INFO - 2020-10-26 03:19:44 --> Output Class Initialized
INFO - 2020-10-26 03:19:44 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:44 --> Input Class Initialized
INFO - 2020-10-26 03:19:44 --> Language Class Initialized
INFO - 2020-10-26 03:19:44 --> Language Class Initialized
INFO - 2020-10-26 03:19:44 --> Config Class Initialized
INFO - 2020-10-26 03:19:44 --> Loader Class Initialized
INFO - 2020-10-26 03:19:44 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:44 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:44 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:44 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:44 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:44 --> Controller Class Initialized
INFO - 2020-10-26 03:19:46 --> Config Class Initialized
INFO - 2020-10-26 03:19:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:46 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:46 --> URI Class Initialized
INFO - 2020-10-26 03:19:46 --> Router Class Initialized
INFO - 2020-10-26 03:19:46 --> Output Class Initialized
INFO - 2020-10-26 03:19:46 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:46 --> Input Class Initialized
INFO - 2020-10-26 03:19:46 --> Language Class Initialized
INFO - 2020-10-26 03:19:46 --> Language Class Initialized
INFO - 2020-10-26 03:19:46 --> Config Class Initialized
INFO - 2020-10-26 03:19:46 --> Loader Class Initialized
INFO - 2020-10-26 03:19:46 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:46 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:46 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:46 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:46 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:46 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_ubah_password.php
DEBUG - 2020-10-26 03:19:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:46 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:46 --> Total execution time: 0.2755
INFO - 2020-10-26 03:19:47 --> Config Class Initialized
INFO - 2020-10-26 03:19:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:47 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:47 --> URI Class Initialized
INFO - 2020-10-26 03:19:47 --> Router Class Initialized
INFO - 2020-10-26 03:19:47 --> Output Class Initialized
INFO - 2020-10-26 03:19:47 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:47 --> Input Class Initialized
INFO - 2020-10-26 03:19:47 --> Language Class Initialized
INFO - 2020-10-26 03:19:47 --> Language Class Initialized
INFO - 2020-10-26 03:19:47 --> Config Class Initialized
INFO - 2020-10-26 03:19:47 --> Loader Class Initialized
INFO - 2020-10-26 03:19:47 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:47 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:47 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:47 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:47 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-26 03:19:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:47 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:47 --> Total execution time: 0.2795
INFO - 2020-10-26 03:19:47 --> Config Class Initialized
INFO - 2020-10-26 03:19:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:47 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:47 --> URI Class Initialized
INFO - 2020-10-26 03:19:47 --> Router Class Initialized
INFO - 2020-10-26 03:19:47 --> Output Class Initialized
INFO - 2020-10-26 03:19:48 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:48 --> Input Class Initialized
INFO - 2020-10-26 03:19:48 --> Language Class Initialized
INFO - 2020-10-26 03:19:48 --> Language Class Initialized
INFO - 2020-10-26 03:19:48 --> Config Class Initialized
INFO - 2020-10-26 03:19:48 --> Loader Class Initialized
INFO - 2020-10-26 03:19:48 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:48 --> Controller Class Initialized
INFO - 2020-10-26 03:19:48 --> Config Class Initialized
INFO - 2020-10-26 03:19:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:48 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:48 --> URI Class Initialized
INFO - 2020-10-26 03:19:48 --> Router Class Initialized
INFO - 2020-10-26 03:19:48 --> Output Class Initialized
INFO - 2020-10-26 03:19:48 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:48 --> Input Class Initialized
INFO - 2020-10-26 03:19:48 --> Language Class Initialized
INFO - 2020-10-26 03:19:48 --> Language Class Initialized
INFO - 2020-10-26 03:19:48 --> Config Class Initialized
INFO - 2020-10-26 03:19:48 --> Loader Class Initialized
INFO - 2020-10-26 03:19:48 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:48 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:19:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:48 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:48 --> Total execution time: 0.2655
INFO - 2020-10-26 03:19:48 --> Config Class Initialized
INFO - 2020-10-26 03:19:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:48 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:48 --> URI Class Initialized
INFO - 2020-10-26 03:19:48 --> Router Class Initialized
INFO - 2020-10-26 03:19:48 --> Output Class Initialized
INFO - 2020-10-26 03:19:48 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:48 --> Input Class Initialized
INFO - 2020-10-26 03:19:48 --> Language Class Initialized
INFO - 2020-10-26 03:19:48 --> Language Class Initialized
INFO - 2020-10-26 03:19:48 --> Config Class Initialized
INFO - 2020-10-26 03:19:48 --> Loader Class Initialized
INFO - 2020-10-26 03:19:48 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:48 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:48 --> Controller Class Initialized
INFO - 2020-10-26 03:19:49 --> Config Class Initialized
INFO - 2020-10-26 03:19:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:49 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:49 --> URI Class Initialized
INFO - 2020-10-26 03:19:49 --> Router Class Initialized
INFO - 2020-10-26 03:19:49 --> Output Class Initialized
INFO - 2020-10-26 03:19:49 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:49 --> Input Class Initialized
INFO - 2020-10-26 03:19:49 --> Language Class Initialized
INFO - 2020-10-26 03:19:49 --> Language Class Initialized
INFO - 2020-10-26 03:19:49 --> Config Class Initialized
INFO - 2020-10-26 03:19:49 --> Loader Class Initialized
INFO - 2020-10-26 03:19:49 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:49 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:49 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:49 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:49 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:19:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:49 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:49 --> Total execution time: 0.2580
INFO - 2020-10-26 03:19:50 --> Config Class Initialized
INFO - 2020-10-26 03:19:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:50 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:50 --> URI Class Initialized
INFO - 2020-10-26 03:19:50 --> Router Class Initialized
INFO - 2020-10-26 03:19:50 --> Output Class Initialized
INFO - 2020-10-26 03:19:50 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:50 --> Input Class Initialized
INFO - 2020-10-26 03:19:50 --> Language Class Initialized
INFO - 2020-10-26 03:19:50 --> Language Class Initialized
INFO - 2020-10-26 03:19:50 --> Config Class Initialized
INFO - 2020-10-26 03:19:50 --> Loader Class Initialized
INFO - 2020-10-26 03:19:50 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:50 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:50 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:50 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:50 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:50 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:19:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:50 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:50 --> Total execution time: 0.2614
INFO - 2020-10-26 03:19:50 --> Config Class Initialized
INFO - 2020-10-26 03:19:50 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:50 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:50 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:50 --> URI Class Initialized
INFO - 2020-10-26 03:19:50 --> Router Class Initialized
INFO - 2020-10-26 03:19:50 --> Output Class Initialized
INFO - 2020-10-26 03:19:50 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:50 --> Input Class Initialized
INFO - 2020-10-26 03:19:50 --> Language Class Initialized
INFO - 2020-10-26 03:19:50 --> Language Class Initialized
INFO - 2020-10-26 03:19:50 --> Config Class Initialized
INFO - 2020-10-26 03:19:50 --> Loader Class Initialized
INFO - 2020-10-26 03:19:50 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:50 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:51 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:51 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:51 --> Controller Class Initialized
INFO - 2020-10-26 03:19:51 --> Config Class Initialized
INFO - 2020-10-26 03:19:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:51 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:51 --> URI Class Initialized
INFO - 2020-10-26 03:19:51 --> Router Class Initialized
INFO - 2020-10-26 03:19:51 --> Output Class Initialized
INFO - 2020-10-26 03:19:51 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:51 --> Input Class Initialized
INFO - 2020-10-26 03:19:51 --> Language Class Initialized
INFO - 2020-10-26 03:19:51 --> Language Class Initialized
INFO - 2020-10-26 03:19:51 --> Config Class Initialized
INFO - 2020-10-26 03:19:51 --> Loader Class Initialized
INFO - 2020-10-26 03:19:51 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:51 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:51 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:51 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:51 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:19:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:51 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:51 --> Total execution time: 0.2616
INFO - 2020-10-26 03:19:55 --> Config Class Initialized
INFO - 2020-10-26 03:19:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:19:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:19:55 --> Utf8 Class Initialized
INFO - 2020-10-26 03:19:55 --> URI Class Initialized
INFO - 2020-10-26 03:19:55 --> Router Class Initialized
INFO - 2020-10-26 03:19:55 --> Output Class Initialized
INFO - 2020-10-26 03:19:55 --> Security Class Initialized
DEBUG - 2020-10-26 03:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:19:55 --> Input Class Initialized
INFO - 2020-10-26 03:19:55 --> Language Class Initialized
INFO - 2020-10-26 03:19:55 --> Language Class Initialized
INFO - 2020-10-26 03:19:55 --> Config Class Initialized
INFO - 2020-10-26 03:19:55 --> Loader Class Initialized
INFO - 2020-10-26 03:19:55 --> Helper loaded: url_helper
INFO - 2020-10-26 03:19:55 --> Helper loaded: file_helper
INFO - 2020-10-26 03:19:55 --> Helper loaded: form_helper
INFO - 2020-10-26 03:19:55 --> Helper loaded: my_helper
INFO - 2020-10-26 03:19:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:19:55 --> Controller Class Initialized
DEBUG - 2020-10-26 03:19:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:19:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:19:55 --> Final output sent to browser
DEBUG - 2020-10-26 03:19:55 --> Total execution time: 0.2722
INFO - 2020-10-26 03:20:01 --> Config Class Initialized
INFO - 2020-10-26 03:20:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:01 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:01 --> URI Class Initialized
INFO - 2020-10-26 03:20:01 --> Router Class Initialized
INFO - 2020-10-26 03:20:01 --> Output Class Initialized
INFO - 2020-10-26 03:20:01 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:01 --> Input Class Initialized
INFO - 2020-10-26 03:20:01 --> Language Class Initialized
INFO - 2020-10-26 03:20:01 --> Language Class Initialized
INFO - 2020-10-26 03:20:01 --> Config Class Initialized
INFO - 2020-10-26 03:20:01 --> Loader Class Initialized
INFO - 2020-10-26 03:20:01 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:01 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:01 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:01 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:01 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:01 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 03:20:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:01 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:01 --> Total execution time: 0.2855
INFO - 2020-10-26 03:20:02 --> Config Class Initialized
INFO - 2020-10-26 03:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:02 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:02 --> URI Class Initialized
INFO - 2020-10-26 03:20:02 --> Router Class Initialized
INFO - 2020-10-26 03:20:02 --> Output Class Initialized
INFO - 2020-10-26 03:20:02 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:02 --> Input Class Initialized
INFO - 2020-10-26 03:20:02 --> Language Class Initialized
INFO - 2020-10-26 03:20:02 --> Language Class Initialized
INFO - 2020-10-26 03:20:02 --> Config Class Initialized
INFO - 2020-10-26 03:20:02 --> Loader Class Initialized
INFO - 2020-10-26 03:20:02 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:02 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:02 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:02 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:02 --> Total execution time: 0.2729
INFO - 2020-10-26 03:20:02 --> Config Class Initialized
INFO - 2020-10-26 03:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:02 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:02 --> URI Class Initialized
INFO - 2020-10-26 03:20:02 --> Router Class Initialized
INFO - 2020-10-26 03:20:02 --> Output Class Initialized
INFO - 2020-10-26 03:20:02 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:02 --> Input Class Initialized
INFO - 2020-10-26 03:20:02 --> Language Class Initialized
INFO - 2020-10-26 03:20:02 --> Language Class Initialized
INFO - 2020-10-26 03:20:02 --> Config Class Initialized
INFO - 2020-10-26 03:20:02 --> Loader Class Initialized
INFO - 2020-10-26 03:20:02 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:02 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:02 --> Controller Class Initialized
INFO - 2020-10-26 03:20:02 --> Config Class Initialized
INFO - 2020-10-26 03:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:02 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:02 --> URI Class Initialized
INFO - 2020-10-26 03:20:02 --> Router Class Initialized
INFO - 2020-10-26 03:20:02 --> Output Class Initialized
INFO - 2020-10-26 03:20:02 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:02 --> Input Class Initialized
INFO - 2020-10-26 03:20:02 --> Language Class Initialized
INFO - 2020-10-26 03:20:02 --> Language Class Initialized
INFO - 2020-10-26 03:20:02 --> Config Class Initialized
INFO - 2020-10-26 03:20:02 --> Loader Class Initialized
INFO - 2020-10-26 03:20:02 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:02 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:02 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:02 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:20:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:02 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:02 --> Total execution time: 0.2564
INFO - 2020-10-26 03:20:02 --> Config Class Initialized
INFO - 2020-10-26 03:20:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:02 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:02 --> URI Class Initialized
INFO - 2020-10-26 03:20:03 --> Router Class Initialized
INFO - 2020-10-26 03:20:03 --> Output Class Initialized
INFO - 2020-10-26 03:20:03 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:03 --> Input Class Initialized
INFO - 2020-10-26 03:20:03 --> Language Class Initialized
INFO - 2020-10-26 03:20:03 --> Language Class Initialized
INFO - 2020-10-26 03:20:03 --> Config Class Initialized
INFO - 2020-10-26 03:20:03 --> Loader Class Initialized
INFO - 2020-10-26 03:20:03 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:03 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:03 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:03 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:03 --> Controller Class Initialized
INFO - 2020-10-26 03:20:04 --> Config Class Initialized
INFO - 2020-10-26 03:20:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:04 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:04 --> URI Class Initialized
INFO - 2020-10-26 03:20:04 --> Router Class Initialized
INFO - 2020-10-26 03:20:04 --> Output Class Initialized
INFO - 2020-10-26 03:20:04 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:04 --> Input Class Initialized
INFO - 2020-10-26 03:20:04 --> Language Class Initialized
INFO - 2020-10-26 03:20:04 --> Language Class Initialized
INFO - 2020-10-26 03:20:04 --> Config Class Initialized
INFO - 2020-10-26 03:20:04 --> Loader Class Initialized
INFO - 2020-10-26 03:20:04 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:04 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:04 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:04 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:04 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 03:20:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:04 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:04 --> Total execution time: 0.2685
INFO - 2020-10-26 03:20:04 --> Config Class Initialized
INFO - 2020-10-26 03:20:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:04 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:04 --> URI Class Initialized
INFO - 2020-10-26 03:20:04 --> Router Class Initialized
INFO - 2020-10-26 03:20:04 --> Output Class Initialized
INFO - 2020-10-26 03:20:04 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:04 --> Input Class Initialized
INFO - 2020-10-26 03:20:04 --> Language Class Initialized
INFO - 2020-10-26 03:20:04 --> Language Class Initialized
INFO - 2020-10-26 03:20:04 --> Config Class Initialized
INFO - 2020-10-26 03:20:04 --> Loader Class Initialized
INFO - 2020-10-26 03:20:04 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:04 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:04 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:04 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:04 --> Controller Class Initialized
INFO - 2020-10-26 03:20:09 --> Config Class Initialized
INFO - 2020-10-26 03:20:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:09 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:09 --> URI Class Initialized
INFO - 2020-10-26 03:20:09 --> Router Class Initialized
INFO - 2020-10-26 03:20:09 --> Output Class Initialized
INFO - 2020-10-26 03:20:09 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:09 --> Input Class Initialized
INFO - 2020-10-26 03:20:09 --> Language Class Initialized
INFO - 2020-10-26 03:20:09 --> Language Class Initialized
INFO - 2020-10-26 03:20:09 --> Config Class Initialized
INFO - 2020-10-26 03:20:09 --> Loader Class Initialized
INFO - 2020-10-26 03:20:09 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:09 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:09 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:09 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:09 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:09 --> Controller Class Initialized
INFO - 2020-10-26 03:20:15 --> Config Class Initialized
INFO - 2020-10-26 03:20:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:15 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:15 --> URI Class Initialized
INFO - 2020-10-26 03:20:15 --> Router Class Initialized
INFO - 2020-10-26 03:20:15 --> Output Class Initialized
INFO - 2020-10-26 03:20:15 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:15 --> Input Class Initialized
INFO - 2020-10-26 03:20:15 --> Language Class Initialized
INFO - 2020-10-26 03:20:15 --> Language Class Initialized
INFO - 2020-10-26 03:20:15 --> Config Class Initialized
INFO - 2020-10-26 03:20:15 --> Loader Class Initialized
INFO - 2020-10-26 03:20:15 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:15 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:15 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:15 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:16 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 03:20:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:16 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:16 --> Total execution time: 0.2828
INFO - 2020-10-26 03:20:16 --> Config Class Initialized
INFO - 2020-10-26 03:20:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:16 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:16 --> URI Class Initialized
INFO - 2020-10-26 03:20:16 --> Router Class Initialized
INFO - 2020-10-26 03:20:16 --> Output Class Initialized
INFO - 2020-10-26 03:20:16 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:16 --> Input Class Initialized
INFO - 2020-10-26 03:20:16 --> Language Class Initialized
INFO - 2020-10-26 03:20:16 --> Language Class Initialized
INFO - 2020-10-26 03:20:16 --> Config Class Initialized
INFO - 2020-10-26 03:20:16 --> Loader Class Initialized
INFO - 2020-10-26 03:20:16 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:16 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:16 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:16 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:16 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:16 --> Controller Class Initialized
INFO - 2020-10-26 03:20:17 --> Config Class Initialized
INFO - 2020-10-26 03:20:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:17 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:17 --> URI Class Initialized
INFO - 2020-10-26 03:20:17 --> Router Class Initialized
INFO - 2020-10-26 03:20:17 --> Output Class Initialized
INFO - 2020-10-26 03:20:17 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:17 --> Input Class Initialized
INFO - 2020-10-26 03:20:17 --> Language Class Initialized
INFO - 2020-10-26 03:20:17 --> Language Class Initialized
INFO - 2020-10-26 03:20:17 --> Config Class Initialized
INFO - 2020-10-26 03:20:17 --> Loader Class Initialized
INFO - 2020-10-26 03:20:17 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:17 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:17 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:17 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:17 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 03:20:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:17 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:17 --> Total execution time: 0.2615
INFO - 2020-10-26 03:20:17 --> Config Class Initialized
INFO - 2020-10-26 03:20:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:17 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:17 --> URI Class Initialized
INFO - 2020-10-26 03:20:17 --> Router Class Initialized
INFO - 2020-10-26 03:20:18 --> Output Class Initialized
INFO - 2020-10-26 03:20:18 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:18 --> Input Class Initialized
INFO - 2020-10-26 03:20:18 --> Language Class Initialized
INFO - 2020-10-26 03:20:18 --> Language Class Initialized
INFO - 2020-10-26 03:20:18 --> Config Class Initialized
INFO - 2020-10-26 03:20:18 --> Loader Class Initialized
INFO - 2020-10-26 03:20:18 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:18 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:18 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:18 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:18 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:18 --> Controller Class Initialized
INFO - 2020-10-26 03:20:20 --> Config Class Initialized
INFO - 2020-10-26 03:20:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:20 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:20 --> URI Class Initialized
INFO - 2020-10-26 03:20:20 --> Router Class Initialized
INFO - 2020-10-26 03:20:20 --> Output Class Initialized
INFO - 2020-10-26 03:20:20 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:20 --> Input Class Initialized
INFO - 2020-10-26 03:20:20 --> Language Class Initialized
INFO - 2020-10-26 03:20:20 --> Language Class Initialized
INFO - 2020-10-26 03:20:20 --> Config Class Initialized
INFO - 2020-10-26 03:20:20 --> Loader Class Initialized
INFO - 2020-10-26 03:20:20 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:20 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:20 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:20 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:20 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 03:20:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:20 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:20 --> Total execution time: 0.2670
INFO - 2020-10-26 03:20:20 --> Config Class Initialized
INFO - 2020-10-26 03:20:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:20 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:20 --> URI Class Initialized
INFO - 2020-10-26 03:20:20 --> Router Class Initialized
INFO - 2020-10-26 03:20:20 --> Output Class Initialized
INFO - 2020-10-26 03:20:20 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:20 --> Input Class Initialized
INFO - 2020-10-26 03:20:20 --> Language Class Initialized
INFO - 2020-10-26 03:20:20 --> Language Class Initialized
INFO - 2020-10-26 03:20:20 --> Config Class Initialized
INFO - 2020-10-26 03:20:20 --> Loader Class Initialized
INFO - 2020-10-26 03:20:20 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:20 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:20 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:20 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:20 --> Controller Class Initialized
INFO - 2020-10-26 03:20:23 --> Config Class Initialized
INFO - 2020-10-26 03:20:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:23 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:23 --> URI Class Initialized
INFO - 2020-10-26 03:20:23 --> Router Class Initialized
INFO - 2020-10-26 03:20:23 --> Output Class Initialized
INFO - 2020-10-26 03:20:23 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:23 --> Input Class Initialized
INFO - 2020-10-26 03:20:23 --> Language Class Initialized
INFO - 2020-10-26 03:20:23 --> Language Class Initialized
INFO - 2020-10-26 03:20:23 --> Config Class Initialized
INFO - 2020-10-26 03:20:23 --> Loader Class Initialized
INFO - 2020-10-26 03:20:23 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:23 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:24 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 03:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:24 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:24 --> Total execution time: 0.2849
INFO - 2020-10-26 03:20:24 --> Config Class Initialized
INFO - 2020-10-26 03:20:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:24 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:24 --> URI Class Initialized
INFO - 2020-10-26 03:20:24 --> Router Class Initialized
INFO - 2020-10-26 03:20:24 --> Output Class Initialized
INFO - 2020-10-26 03:20:24 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:24 --> Input Class Initialized
INFO - 2020-10-26 03:20:24 --> Language Class Initialized
INFO - 2020-10-26 03:20:24 --> Language Class Initialized
INFO - 2020-10-26 03:20:24 --> Config Class Initialized
INFO - 2020-10-26 03:20:24 --> Loader Class Initialized
INFO - 2020-10-26 03:20:24 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:24 --> Controller Class Initialized
INFO - 2020-10-26 03:20:24 --> Config Class Initialized
INFO - 2020-10-26 03:20:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:24 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:24 --> URI Class Initialized
INFO - 2020-10-26 03:20:24 --> Router Class Initialized
INFO - 2020-10-26 03:20:24 --> Output Class Initialized
INFO - 2020-10-26 03:20:24 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:24 --> Input Class Initialized
INFO - 2020-10-26 03:20:24 --> Language Class Initialized
INFO - 2020-10-26 03:20:24 --> Language Class Initialized
INFO - 2020-10-26 03:20:24 --> Config Class Initialized
INFO - 2020-10-26 03:20:24 --> Loader Class Initialized
INFO - 2020-10-26 03:20:24 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:24 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:24 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 03:20:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:24 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:24 --> Total execution time: 0.2815
INFO - 2020-10-26 03:20:24 --> Config Class Initialized
INFO - 2020-10-26 03:20:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:25 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:25 --> URI Class Initialized
INFO - 2020-10-26 03:20:25 --> Router Class Initialized
INFO - 2020-10-26 03:20:25 --> Output Class Initialized
INFO - 2020-10-26 03:20:25 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:25 --> Input Class Initialized
INFO - 2020-10-26 03:20:25 --> Language Class Initialized
INFO - 2020-10-26 03:20:25 --> Language Class Initialized
INFO - 2020-10-26 03:20:25 --> Config Class Initialized
INFO - 2020-10-26 03:20:25 --> Loader Class Initialized
INFO - 2020-10-26 03:20:25 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:25 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:25 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:25 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:25 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:25 --> Controller Class Initialized
INFO - 2020-10-26 03:20:37 --> Config Class Initialized
INFO - 2020-10-26 03:20:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:37 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:37 --> URI Class Initialized
INFO - 2020-10-26 03:20:37 --> Router Class Initialized
INFO - 2020-10-26 03:20:37 --> Output Class Initialized
INFO - 2020-10-26 03:20:37 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:37 --> Input Class Initialized
INFO - 2020-10-26 03:20:37 --> Language Class Initialized
INFO - 2020-10-26 03:20:37 --> Language Class Initialized
INFO - 2020-10-26 03:20:37 --> Config Class Initialized
INFO - 2020-10-26 03:20:37 --> Loader Class Initialized
INFO - 2020-10-26 03:20:37 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:37 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:37 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:37 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:37 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:37 --> Controller Class Initialized
INFO - 2020-10-26 03:20:37 --> Helper loaded: cookie_helper
INFO - 2020-10-26 03:20:37 --> Config Class Initialized
INFO - 2020-10-26 03:20:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:37 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:37 --> URI Class Initialized
INFO - 2020-10-26 03:20:37 --> Router Class Initialized
INFO - 2020-10-26 03:20:37 --> Output Class Initialized
INFO - 2020-10-26 03:20:37 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:38 --> Input Class Initialized
INFO - 2020-10-26 03:20:38 --> Language Class Initialized
INFO - 2020-10-26 03:20:38 --> Language Class Initialized
INFO - 2020-10-26 03:20:38 --> Config Class Initialized
INFO - 2020-10-26 03:20:38 --> Loader Class Initialized
INFO - 2020-10-26 03:20:38 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:38 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:38 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:38 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:38 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:38 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 03:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:38 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:38 --> Total execution time: 0.2635
INFO - 2020-10-26 03:20:49 --> Config Class Initialized
INFO - 2020-10-26 03:20:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:49 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:49 --> URI Class Initialized
INFO - 2020-10-26 03:20:49 --> Router Class Initialized
INFO - 2020-10-26 03:20:49 --> Output Class Initialized
INFO - 2020-10-26 03:20:49 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:49 --> Input Class Initialized
INFO - 2020-10-26 03:20:49 --> Language Class Initialized
INFO - 2020-10-26 03:20:49 --> Language Class Initialized
INFO - 2020-10-26 03:20:49 --> Config Class Initialized
INFO - 2020-10-26 03:20:49 --> Loader Class Initialized
INFO - 2020-10-26 03:20:49 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:49 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:49 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:49 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:50 --> Controller Class Initialized
INFO - 2020-10-26 03:20:50 --> Helper loaded: cookie_helper
INFO - 2020-10-26 03:20:50 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:50 --> Total execution time: 0.2626
INFO - 2020-10-26 03:20:54 --> Config Class Initialized
INFO - 2020-10-26 03:20:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:20:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:20:54 --> Utf8 Class Initialized
INFO - 2020-10-26 03:20:54 --> URI Class Initialized
INFO - 2020-10-26 03:20:54 --> Router Class Initialized
INFO - 2020-10-26 03:20:54 --> Output Class Initialized
INFO - 2020-10-26 03:20:54 --> Security Class Initialized
DEBUG - 2020-10-26 03:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:20:54 --> Input Class Initialized
INFO - 2020-10-26 03:20:54 --> Language Class Initialized
INFO - 2020-10-26 03:20:54 --> Language Class Initialized
INFO - 2020-10-26 03:20:54 --> Config Class Initialized
INFO - 2020-10-26 03:20:54 --> Loader Class Initialized
INFO - 2020-10-26 03:20:54 --> Helper loaded: url_helper
INFO - 2020-10-26 03:20:54 --> Helper loaded: file_helper
INFO - 2020-10-26 03:20:54 --> Helper loaded: form_helper
INFO - 2020-10-26 03:20:54 --> Helper loaded: my_helper
INFO - 2020-10-26 03:20:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:20:54 --> Controller Class Initialized
DEBUG - 2020-10-26 03:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 03:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:20:54 --> Final output sent to browser
DEBUG - 2020-10-26 03:20:54 --> Total execution time: 0.3019
INFO - 2020-10-26 03:21:01 --> Config Class Initialized
INFO - 2020-10-26 03:21:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:01 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:01 --> URI Class Initialized
INFO - 2020-10-26 03:21:01 --> Router Class Initialized
INFO - 2020-10-26 03:21:01 --> Output Class Initialized
INFO - 2020-10-26 03:21:01 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:02 --> Input Class Initialized
INFO - 2020-10-26 03:21:02 --> Language Class Initialized
INFO - 2020-10-26 03:21:02 --> Language Class Initialized
INFO - 2020-10-26 03:21:02 --> Config Class Initialized
INFO - 2020-10-26 03:21:02 --> Loader Class Initialized
INFO - 2020-10-26 03:21:02 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:02 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:02 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:02 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:02 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:02 --> Controller Class Initialized
DEBUG - 2020-10-26 03:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:21:02 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:02 --> Total execution time: 0.2779
INFO - 2020-10-26 03:21:37 --> Config Class Initialized
INFO - 2020-10-26 03:21:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:38 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:38 --> URI Class Initialized
INFO - 2020-10-26 03:21:38 --> Router Class Initialized
INFO - 2020-10-26 03:21:38 --> Output Class Initialized
INFO - 2020-10-26 03:21:38 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:38 --> Input Class Initialized
INFO - 2020-10-26 03:21:38 --> Language Class Initialized
INFO - 2020-10-26 03:21:38 --> Language Class Initialized
INFO - 2020-10-26 03:21:38 --> Config Class Initialized
INFO - 2020-10-26 03:21:38 --> Loader Class Initialized
INFO - 2020-10-26 03:21:38 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:38 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:38 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:38 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:38 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:38 --> Controller Class Initialized
DEBUG - 2020-10-26 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:21:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:21:38 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:38 --> Total execution time: 0.3056
INFO - 2020-10-26 03:21:39 --> Config Class Initialized
INFO - 2020-10-26 03:21:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:39 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:39 --> URI Class Initialized
DEBUG - 2020-10-26 03:21:39 --> No URI present. Default controller set.
INFO - 2020-10-26 03:21:39 --> Router Class Initialized
INFO - 2020-10-26 03:21:39 --> Output Class Initialized
INFO - 2020-10-26 03:21:39 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:39 --> Input Class Initialized
INFO - 2020-10-26 03:21:39 --> Language Class Initialized
INFO - 2020-10-26 03:21:39 --> Language Class Initialized
INFO - 2020-10-26 03:21:39 --> Config Class Initialized
INFO - 2020-10-26 03:21:39 --> Loader Class Initialized
INFO - 2020-10-26 03:21:39 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:39 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:39 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:39 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:39 --> Controller Class Initialized
DEBUG - 2020-10-26 03:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 03:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:21:39 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:40 --> Total execution time: 0.2785
INFO - 2020-10-26 03:21:41 --> Config Class Initialized
INFO - 2020-10-26 03:21:41 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:41 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:41 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:41 --> URI Class Initialized
INFO - 2020-10-26 03:21:41 --> Router Class Initialized
INFO - 2020-10-26 03:21:41 --> Output Class Initialized
INFO - 2020-10-26 03:21:41 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:41 --> Input Class Initialized
INFO - 2020-10-26 03:21:41 --> Language Class Initialized
INFO - 2020-10-26 03:21:41 --> Language Class Initialized
INFO - 2020-10-26 03:21:41 --> Config Class Initialized
INFO - 2020-10-26 03:21:41 --> Loader Class Initialized
INFO - 2020-10-26 03:21:41 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:41 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:41 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:41 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:41 --> Controller Class Initialized
DEBUG - 2020-10-26 03:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:21:41 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:41 --> Total execution time: 0.2791
INFO - 2020-10-26 03:21:45 --> Config Class Initialized
INFO - 2020-10-26 03:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:45 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:45 --> URI Class Initialized
INFO - 2020-10-26 03:21:45 --> Router Class Initialized
INFO - 2020-10-26 03:21:45 --> Output Class Initialized
INFO - 2020-10-26 03:21:45 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:45 --> Input Class Initialized
INFO - 2020-10-26 03:21:45 --> Language Class Initialized
INFO - 2020-10-26 03:21:45 --> Language Class Initialized
INFO - 2020-10-26 03:21:45 --> Config Class Initialized
INFO - 2020-10-26 03:21:45 --> Loader Class Initialized
INFO - 2020-10-26 03:21:45 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:45 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:45 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:45 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:45 --> Controller Class Initialized
DEBUG - 2020-10-26 03:21:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 03:21:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:21:45 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:45 --> Total execution time: 0.2785
INFO - 2020-10-26 03:21:45 --> Config Class Initialized
INFO - 2020-10-26 03:21:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:45 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:45 --> URI Class Initialized
INFO - 2020-10-26 03:21:45 --> Router Class Initialized
INFO - 2020-10-26 03:21:45 --> Output Class Initialized
INFO - 2020-10-26 03:21:45 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:45 --> Input Class Initialized
INFO - 2020-10-26 03:21:45 --> Language Class Initialized
INFO - 2020-10-26 03:21:45 --> Language Class Initialized
INFO - 2020-10-26 03:21:45 --> Config Class Initialized
INFO - 2020-10-26 03:21:45 --> Loader Class Initialized
INFO - 2020-10-26 03:21:45 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:45 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:45 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:45 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:45 --> Controller Class Initialized
INFO - 2020-10-26 03:21:47 --> Config Class Initialized
INFO - 2020-10-26 03:21:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:47 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:47 --> URI Class Initialized
INFO - 2020-10-26 03:21:47 --> Router Class Initialized
INFO - 2020-10-26 03:21:47 --> Output Class Initialized
INFO - 2020-10-26 03:21:47 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:47 --> Input Class Initialized
INFO - 2020-10-26 03:21:47 --> Language Class Initialized
INFO - 2020-10-26 03:21:47 --> Language Class Initialized
INFO - 2020-10-26 03:21:47 --> Config Class Initialized
INFO - 2020-10-26 03:21:47 --> Loader Class Initialized
INFO - 2020-10-26 03:21:47 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:47 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:47 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:47 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:47 --> Controller Class Initialized
INFO - 2020-10-26 03:21:47 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:47 --> Total execution time: 0.2425
INFO - 2020-10-26 03:21:52 --> Config Class Initialized
INFO - 2020-10-26 03:21:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:52 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:52 --> URI Class Initialized
INFO - 2020-10-26 03:21:52 --> Router Class Initialized
INFO - 2020-10-26 03:21:52 --> Output Class Initialized
INFO - 2020-10-26 03:21:52 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:52 --> Input Class Initialized
INFO - 2020-10-26 03:21:52 --> Language Class Initialized
INFO - 2020-10-26 03:21:52 --> Language Class Initialized
INFO - 2020-10-26 03:21:52 --> Config Class Initialized
INFO - 2020-10-26 03:21:52 --> Loader Class Initialized
INFO - 2020-10-26 03:21:52 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:52 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:52 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:52 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:52 --> Controller Class Initialized
DEBUG - 2020-10-26 03:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:21:52 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:52 --> Total execution time: 0.2924
INFO - 2020-10-26 03:21:59 --> Config Class Initialized
INFO - 2020-10-26 03:21:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:59 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:59 --> URI Class Initialized
INFO - 2020-10-26 03:21:59 --> Router Class Initialized
INFO - 2020-10-26 03:21:59 --> Output Class Initialized
INFO - 2020-10-26 03:21:59 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:59 --> Input Class Initialized
INFO - 2020-10-26 03:21:59 --> Language Class Initialized
INFO - 2020-10-26 03:21:59 --> Language Class Initialized
INFO - 2020-10-26 03:21:59 --> Config Class Initialized
INFO - 2020-10-26 03:21:59 --> Loader Class Initialized
INFO - 2020-10-26 03:21:59 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:59 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:59 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:59 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:21:59 --> Controller Class Initialized
DEBUG - 2020-10-26 03:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 03:21:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:21:59 --> Final output sent to browser
DEBUG - 2020-10-26 03:21:59 --> Total execution time: 0.2826
INFO - 2020-10-26 03:21:59 --> Config Class Initialized
INFO - 2020-10-26 03:21:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:21:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:21:59 --> Utf8 Class Initialized
INFO - 2020-10-26 03:21:59 --> URI Class Initialized
INFO - 2020-10-26 03:21:59 --> Router Class Initialized
INFO - 2020-10-26 03:21:59 --> Output Class Initialized
INFO - 2020-10-26 03:21:59 --> Security Class Initialized
DEBUG - 2020-10-26 03:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:21:59 --> Input Class Initialized
INFO - 2020-10-26 03:21:59 --> Language Class Initialized
INFO - 2020-10-26 03:21:59 --> Language Class Initialized
INFO - 2020-10-26 03:21:59 --> Config Class Initialized
INFO - 2020-10-26 03:21:59 --> Loader Class Initialized
INFO - 2020-10-26 03:21:59 --> Helper loaded: url_helper
INFO - 2020-10-26 03:21:59 --> Helper loaded: file_helper
INFO - 2020-10-26 03:21:59 --> Helper loaded: form_helper
INFO - 2020-10-26 03:21:59 --> Helper loaded: my_helper
INFO - 2020-10-26 03:21:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:00 --> Controller Class Initialized
INFO - 2020-10-26 03:22:05 --> Config Class Initialized
INFO - 2020-10-26 03:22:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:05 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:05 --> URI Class Initialized
INFO - 2020-10-26 03:22:05 --> Router Class Initialized
INFO - 2020-10-26 03:22:05 --> Output Class Initialized
INFO - 2020-10-26 03:22:05 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:05 --> Input Class Initialized
INFO - 2020-10-26 03:22:05 --> Language Class Initialized
INFO - 2020-10-26 03:22:05 --> Language Class Initialized
INFO - 2020-10-26 03:22:05 --> Config Class Initialized
INFO - 2020-10-26 03:22:05 --> Loader Class Initialized
INFO - 2020-10-26 03:22:05 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:05 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:05 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:06 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:06 --> Controller Class Initialized
INFO - 2020-10-26 03:22:06 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:06 --> Total execution time: 0.2324
INFO - 2020-10-26 03:22:14 --> Config Class Initialized
INFO - 2020-10-26 03:22:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:14 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:14 --> URI Class Initialized
INFO - 2020-10-26 03:22:14 --> Router Class Initialized
INFO - 2020-10-26 03:22:14 --> Output Class Initialized
INFO - 2020-10-26 03:22:14 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:14 --> Input Class Initialized
INFO - 2020-10-26 03:22:14 --> Language Class Initialized
INFO - 2020-10-26 03:22:14 --> Language Class Initialized
INFO - 2020-10-26 03:22:14 --> Config Class Initialized
INFO - 2020-10-26 03:22:14 --> Loader Class Initialized
INFO - 2020-10-26 03:22:14 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:14 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:14 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:14 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:14 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:14 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:14 --> Total execution time: 0.2779
INFO - 2020-10-26 03:22:16 --> Config Class Initialized
INFO - 2020-10-26 03:22:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:16 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:16 --> URI Class Initialized
INFO - 2020-10-26 03:22:16 --> Router Class Initialized
INFO - 2020-10-26 03:22:16 --> Output Class Initialized
INFO - 2020-10-26 03:22:16 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:16 --> Input Class Initialized
INFO - 2020-10-26 03:22:16 --> Language Class Initialized
INFO - 2020-10-26 03:22:16 --> Language Class Initialized
INFO - 2020-10-26 03:22:16 --> Config Class Initialized
INFO - 2020-10-26 03:22:16 --> Loader Class Initialized
INFO - 2020-10-26 03:22:16 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:17 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:17 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:17 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:17 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-26 03:22:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:17 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:17 --> Total execution time: 0.2804
INFO - 2020-10-26 03:22:21 --> Config Class Initialized
INFO - 2020-10-26 03:22:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:21 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:21 --> URI Class Initialized
INFO - 2020-10-26 03:22:21 --> Router Class Initialized
INFO - 2020-10-26 03:22:21 --> Output Class Initialized
INFO - 2020-10-26 03:22:21 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:21 --> Input Class Initialized
INFO - 2020-10-26 03:22:21 --> Language Class Initialized
INFO - 2020-10-26 03:22:21 --> Language Class Initialized
INFO - 2020-10-26 03:22:21 --> Config Class Initialized
INFO - 2020-10-26 03:22:21 --> Loader Class Initialized
INFO - 2020-10-26 03:22:21 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:21 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:21 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:21 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:21 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:21 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-26 03:22:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:21 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:21 --> Total execution time: 0.3107
INFO - 2020-10-26 03:22:22 --> Config Class Initialized
INFO - 2020-10-26 03:22:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:22 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:22 --> URI Class Initialized
INFO - 2020-10-26 03:22:22 --> Router Class Initialized
INFO - 2020-10-26 03:22:22 --> Output Class Initialized
INFO - 2020-10-26 03:22:22 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:22 --> Input Class Initialized
INFO - 2020-10-26 03:22:22 --> Language Class Initialized
INFO - 2020-10-26 03:22:22 --> Language Class Initialized
INFO - 2020-10-26 03:22:22 --> Config Class Initialized
INFO - 2020-10-26 03:22:22 --> Loader Class Initialized
INFO - 2020-10-26 03:22:22 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:22 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:22 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:22 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:22 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:22 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-10-26 03:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:22 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:22 --> Total execution time: 0.2999
INFO - 2020-10-26 03:22:26 --> Config Class Initialized
INFO - 2020-10-26 03:22:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:26 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:26 --> URI Class Initialized
INFO - 2020-10-26 03:22:26 --> Router Class Initialized
INFO - 2020-10-26 03:22:26 --> Output Class Initialized
INFO - 2020-10-26 03:22:26 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:26 --> Input Class Initialized
INFO - 2020-10-26 03:22:26 --> Language Class Initialized
INFO - 2020-10-26 03:22:26 --> Language Class Initialized
INFO - 2020-10-26 03:22:26 --> Config Class Initialized
INFO - 2020-10-26 03:22:26 --> Loader Class Initialized
INFO - 2020-10-26 03:22:26 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:26 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:26 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:26 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:26 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-10-26 03:22:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:26 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:26 --> Total execution time: 0.2872
INFO - 2020-10-26 03:22:27 --> Config Class Initialized
INFO - 2020-10-26 03:22:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:27 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:27 --> URI Class Initialized
INFO - 2020-10-26 03:22:27 --> Router Class Initialized
INFO - 2020-10-26 03:22:27 --> Output Class Initialized
INFO - 2020-10-26 03:22:27 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:27 --> Input Class Initialized
INFO - 2020-10-26 03:22:27 --> Language Class Initialized
INFO - 2020-10-26 03:22:27 --> Language Class Initialized
INFO - 2020-10-26 03:22:27 --> Config Class Initialized
INFO - 2020-10-26 03:22:27 --> Loader Class Initialized
INFO - 2020-10-26 03:22:27 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:27 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:27 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:27 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:27 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-10-26 03:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:27 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:27 --> Total execution time: 0.3027
INFO - 2020-10-26 03:22:30 --> Config Class Initialized
INFO - 2020-10-26 03:22:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:30 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:30 --> URI Class Initialized
INFO - 2020-10-26 03:22:30 --> Router Class Initialized
INFO - 2020-10-26 03:22:30 --> Output Class Initialized
INFO - 2020-10-26 03:22:30 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:30 --> Input Class Initialized
INFO - 2020-10-26 03:22:30 --> Language Class Initialized
INFO - 2020-10-26 03:22:30 --> Language Class Initialized
INFO - 2020-10-26 03:22:30 --> Config Class Initialized
INFO - 2020-10-26 03:22:30 --> Loader Class Initialized
INFO - 2020-10-26 03:22:30 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:30 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:30 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:30 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:30 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:30 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:22:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:30 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:30 --> Total execution time: 0.3155
INFO - 2020-10-26 03:22:32 --> Config Class Initialized
INFO - 2020-10-26 03:22:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:33 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:33 --> URI Class Initialized
INFO - 2020-10-26 03:22:33 --> Router Class Initialized
INFO - 2020-10-26 03:22:33 --> Output Class Initialized
INFO - 2020-10-26 03:22:33 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:33 --> Input Class Initialized
INFO - 2020-10-26 03:22:33 --> Language Class Initialized
INFO - 2020-10-26 03:22:33 --> Language Class Initialized
INFO - 2020-10-26 03:22:33 --> Config Class Initialized
INFO - 2020-10-26 03:22:33 --> Loader Class Initialized
INFO - 2020-10-26 03:22:33 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:33 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:33 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:33 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:33 --> Controller Class Initialized
DEBUG - 2020-10-26 03:22:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 03:22:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:22:33 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:33 --> Total execution time: 0.3006
INFO - 2020-10-26 03:22:33 --> Config Class Initialized
INFO - 2020-10-26 03:22:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:33 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:33 --> URI Class Initialized
INFO - 2020-10-26 03:22:33 --> Router Class Initialized
INFO - 2020-10-26 03:22:33 --> Output Class Initialized
INFO - 2020-10-26 03:22:33 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:33 --> Input Class Initialized
INFO - 2020-10-26 03:22:33 --> Language Class Initialized
INFO - 2020-10-26 03:22:33 --> Language Class Initialized
INFO - 2020-10-26 03:22:33 --> Config Class Initialized
INFO - 2020-10-26 03:22:33 --> Loader Class Initialized
INFO - 2020-10-26 03:22:33 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:33 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:33 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:33 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:33 --> Controller Class Initialized
INFO - 2020-10-26 03:22:34 --> Config Class Initialized
INFO - 2020-10-26 03:22:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:34 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:34 --> URI Class Initialized
INFO - 2020-10-26 03:22:34 --> Router Class Initialized
INFO - 2020-10-26 03:22:34 --> Output Class Initialized
INFO - 2020-10-26 03:22:34 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:34 --> Input Class Initialized
INFO - 2020-10-26 03:22:34 --> Language Class Initialized
INFO - 2020-10-26 03:22:34 --> Language Class Initialized
INFO - 2020-10-26 03:22:34 --> Config Class Initialized
INFO - 2020-10-26 03:22:34 --> Loader Class Initialized
INFO - 2020-10-26 03:22:35 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:35 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:35 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:35 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:35 --> Controller Class Initialized
INFO - 2020-10-26 03:22:35 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:35 --> Total execution time: 0.2793
INFO - 2020-10-26 03:22:53 --> Config Class Initialized
INFO - 2020-10-26 03:22:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:53 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:53 --> URI Class Initialized
INFO - 2020-10-26 03:22:53 --> Router Class Initialized
INFO - 2020-10-26 03:22:53 --> Output Class Initialized
INFO - 2020-10-26 03:22:53 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:53 --> Input Class Initialized
INFO - 2020-10-26 03:22:53 --> Language Class Initialized
INFO - 2020-10-26 03:22:53 --> Language Class Initialized
INFO - 2020-10-26 03:22:53 --> Config Class Initialized
INFO - 2020-10-26 03:22:53 --> Loader Class Initialized
INFO - 2020-10-26 03:22:53 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:53 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:53 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:53 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:53 --> Controller Class Initialized
INFO - 2020-10-26 03:22:53 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:53 --> Total execution time: 0.3092
INFO - 2020-10-26 03:22:53 --> Config Class Initialized
INFO - 2020-10-26 03:22:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:53 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:53 --> URI Class Initialized
INFO - 2020-10-26 03:22:53 --> Router Class Initialized
INFO - 2020-10-26 03:22:53 --> Output Class Initialized
INFO - 2020-10-26 03:22:53 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:53 --> Input Class Initialized
INFO - 2020-10-26 03:22:53 --> Language Class Initialized
INFO - 2020-10-26 03:22:53 --> Language Class Initialized
INFO - 2020-10-26 03:22:53 --> Config Class Initialized
INFO - 2020-10-26 03:22:53 --> Loader Class Initialized
INFO - 2020-10-26 03:22:53 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:53 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:53 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:53 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:53 --> Controller Class Initialized
INFO - 2020-10-26 03:22:55 --> Config Class Initialized
INFO - 2020-10-26 03:22:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:22:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:22:55 --> Utf8 Class Initialized
INFO - 2020-10-26 03:22:55 --> URI Class Initialized
INFO - 2020-10-26 03:22:55 --> Router Class Initialized
INFO - 2020-10-26 03:22:55 --> Output Class Initialized
INFO - 2020-10-26 03:22:55 --> Security Class Initialized
DEBUG - 2020-10-26 03:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:22:55 --> Input Class Initialized
INFO - 2020-10-26 03:22:55 --> Language Class Initialized
INFO - 2020-10-26 03:22:55 --> Language Class Initialized
INFO - 2020-10-26 03:22:55 --> Config Class Initialized
INFO - 2020-10-26 03:22:55 --> Loader Class Initialized
INFO - 2020-10-26 03:22:55 --> Helper loaded: url_helper
INFO - 2020-10-26 03:22:55 --> Helper loaded: file_helper
INFO - 2020-10-26 03:22:55 --> Helper loaded: form_helper
INFO - 2020-10-26 03:22:55 --> Helper loaded: my_helper
INFO - 2020-10-26 03:22:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:22:55 --> Controller Class Initialized
INFO - 2020-10-26 03:22:55 --> Final output sent to browser
DEBUG - 2020-10-26 03:22:55 --> Total execution time: 0.2390
INFO - 2020-10-26 03:23:01 --> Config Class Initialized
INFO - 2020-10-26 03:23:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:01 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:01 --> URI Class Initialized
INFO - 2020-10-26 03:23:01 --> Router Class Initialized
INFO - 2020-10-26 03:23:01 --> Output Class Initialized
INFO - 2020-10-26 03:23:01 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:01 --> Input Class Initialized
INFO - 2020-10-26 03:23:01 --> Language Class Initialized
INFO - 2020-10-26 03:23:01 --> Language Class Initialized
INFO - 2020-10-26 03:23:01 --> Config Class Initialized
INFO - 2020-10-26 03:23:01 --> Loader Class Initialized
INFO - 2020-10-26 03:23:01 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:01 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:01 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:01 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:01 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:01 --> Controller Class Initialized
INFO - 2020-10-26 03:23:01 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:01 --> Total execution time: 0.2630
INFO - 2020-10-26 03:23:03 --> Config Class Initialized
INFO - 2020-10-26 03:23:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:03 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:03 --> URI Class Initialized
INFO - 2020-10-26 03:23:03 --> Router Class Initialized
INFO - 2020-10-26 03:23:04 --> Output Class Initialized
INFO - 2020-10-26 03:23:04 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:04 --> Input Class Initialized
INFO - 2020-10-26 03:23:04 --> Language Class Initialized
INFO - 2020-10-26 03:23:04 --> Language Class Initialized
INFO - 2020-10-26 03:23:04 --> Config Class Initialized
INFO - 2020-10-26 03:23:04 --> Loader Class Initialized
INFO - 2020-10-26 03:23:04 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:04 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:04 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:04 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:04 --> Controller Class Initialized
INFO - 2020-10-26 03:23:04 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:04 --> Total execution time: 0.2498
INFO - 2020-10-26 03:23:04 --> Config Class Initialized
INFO - 2020-10-26 03:23:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:04 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:04 --> URI Class Initialized
INFO - 2020-10-26 03:23:04 --> Router Class Initialized
INFO - 2020-10-26 03:23:04 --> Output Class Initialized
INFO - 2020-10-26 03:23:04 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:04 --> Input Class Initialized
INFO - 2020-10-26 03:23:04 --> Language Class Initialized
INFO - 2020-10-26 03:23:04 --> Language Class Initialized
INFO - 2020-10-26 03:23:04 --> Config Class Initialized
INFO - 2020-10-26 03:23:04 --> Loader Class Initialized
INFO - 2020-10-26 03:23:04 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:04 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:04 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:04 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:04 --> Controller Class Initialized
INFO - 2020-10-26 03:23:04 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:04 --> Total execution time: 0.2398
INFO - 2020-10-26 03:23:14 --> Config Class Initialized
INFO - 2020-10-26 03:23:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:14 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:14 --> URI Class Initialized
INFO - 2020-10-26 03:23:14 --> Router Class Initialized
INFO - 2020-10-26 03:23:14 --> Output Class Initialized
INFO - 2020-10-26 03:23:14 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:14 --> Input Class Initialized
INFO - 2020-10-26 03:23:14 --> Language Class Initialized
INFO - 2020-10-26 03:23:14 --> Language Class Initialized
INFO - 2020-10-26 03:23:14 --> Config Class Initialized
INFO - 2020-10-26 03:23:14 --> Loader Class Initialized
INFO - 2020-10-26 03:23:14 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:15 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:15 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:15 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:15 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:23:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:15 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:15 --> Total execution time: 0.2748
INFO - 2020-10-26 03:23:19 --> Config Class Initialized
INFO - 2020-10-26 03:23:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:19 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:19 --> URI Class Initialized
INFO - 2020-10-26 03:23:19 --> Router Class Initialized
INFO - 2020-10-26 03:23:19 --> Output Class Initialized
INFO - 2020-10-26 03:23:19 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:19 --> Input Class Initialized
INFO - 2020-10-26 03:23:19 --> Language Class Initialized
INFO - 2020-10-26 03:23:19 --> Language Class Initialized
INFO - 2020-10-26 03:23:19 --> Config Class Initialized
INFO - 2020-10-26 03:23:19 --> Loader Class Initialized
INFO - 2020-10-26 03:23:19 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:19 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:19 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:19 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:19 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:19 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-26 03:23:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:19 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:19 --> Total execution time: 0.2909
INFO - 2020-10-26 03:23:23 --> Config Class Initialized
INFO - 2020-10-26 03:23:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:23 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:23 --> URI Class Initialized
INFO - 2020-10-26 03:23:23 --> Router Class Initialized
INFO - 2020-10-26 03:23:23 --> Output Class Initialized
INFO - 2020-10-26 03:23:23 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:23 --> Input Class Initialized
INFO - 2020-10-26 03:23:23 --> Language Class Initialized
INFO - 2020-10-26 03:23:23 --> Language Class Initialized
INFO - 2020-10-26 03:23:23 --> Config Class Initialized
INFO - 2020-10-26 03:23:23 --> Loader Class Initialized
INFO - 2020-10-26 03:23:23 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:23 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:23 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:23 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:23 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-10-26 03:23:23 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:23 --> Total execution time: 0.2792
INFO - 2020-10-26 03:23:28 --> Config Class Initialized
INFO - 2020-10-26 03:23:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:28 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:29 --> URI Class Initialized
INFO - 2020-10-26 03:23:29 --> Router Class Initialized
INFO - 2020-10-26 03:23:29 --> Output Class Initialized
INFO - 2020-10-26 03:23:29 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:29 --> Input Class Initialized
INFO - 2020-10-26 03:23:29 --> Language Class Initialized
INFO - 2020-10-26 03:23:29 --> Language Class Initialized
INFO - 2020-10-26 03:23:29 --> Config Class Initialized
INFO - 2020-10-26 03:23:29 --> Loader Class Initialized
INFO - 2020-10-26 03:23:29 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:29 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:29 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:29 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:29 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:29 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-10-26 03:23:29 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:29 --> Total execution time: 0.3140
INFO - 2020-10-26 03:23:39 --> Config Class Initialized
INFO - 2020-10-26 03:23:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:39 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:39 --> URI Class Initialized
INFO - 2020-10-26 03:23:39 --> Router Class Initialized
INFO - 2020-10-26 03:23:39 --> Output Class Initialized
INFO - 2020-10-26 03:23:39 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:39 --> Input Class Initialized
INFO - 2020-10-26 03:23:39 --> Language Class Initialized
INFO - 2020-10-26 03:23:39 --> Language Class Initialized
INFO - 2020-10-26 03:23:39 --> Config Class Initialized
INFO - 2020-10-26 03:23:39 --> Loader Class Initialized
INFO - 2020-10-26 03:23:39 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:39 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:39 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:39 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:39 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-26 03:23:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:39 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:39 --> Total execution time: 0.2766
INFO - 2020-10-26 03:23:42 --> Config Class Initialized
INFO - 2020-10-26 03:23:42 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:42 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:42 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:42 --> URI Class Initialized
INFO - 2020-10-26 03:23:42 --> Router Class Initialized
INFO - 2020-10-26 03:23:42 --> Output Class Initialized
INFO - 2020-10-26 03:23:42 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:42 --> Input Class Initialized
INFO - 2020-10-26 03:23:42 --> Language Class Initialized
INFO - 2020-10-26 03:23:42 --> Language Class Initialized
INFO - 2020-10-26 03:23:42 --> Config Class Initialized
INFO - 2020-10-26 03:23:42 --> Loader Class Initialized
INFO - 2020-10-26 03:23:42 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:42 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:42 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:42 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:42 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-10-26 03:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:42 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:42 --> Total execution time: 0.2793
INFO - 2020-10-26 03:23:44 --> Config Class Initialized
INFO - 2020-10-26 03:23:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:44 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:44 --> URI Class Initialized
INFO - 2020-10-26 03:23:44 --> Router Class Initialized
INFO - 2020-10-26 03:23:44 --> Output Class Initialized
INFO - 2020-10-26 03:23:44 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:44 --> Input Class Initialized
INFO - 2020-10-26 03:23:44 --> Language Class Initialized
INFO - 2020-10-26 03:23:44 --> Language Class Initialized
INFO - 2020-10-26 03:23:44 --> Config Class Initialized
INFO - 2020-10-26 03:23:44 --> Loader Class Initialized
INFO - 2020-10-26 03:23:44 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:44 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:44 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:44 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:44 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:44 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-10-26 03:23:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:44 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:44 --> Total execution time: 0.2931
INFO - 2020-10-26 03:23:47 --> Config Class Initialized
INFO - 2020-10-26 03:23:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:47 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:47 --> URI Class Initialized
INFO - 2020-10-26 03:23:47 --> Router Class Initialized
INFO - 2020-10-26 03:23:47 --> Output Class Initialized
INFO - 2020-10-26 03:23:47 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:47 --> Input Class Initialized
INFO - 2020-10-26 03:23:47 --> Language Class Initialized
INFO - 2020-10-26 03:23:47 --> Language Class Initialized
INFO - 2020-10-26 03:23:47 --> Config Class Initialized
INFO - 2020-10-26 03:23:47 --> Loader Class Initialized
INFO - 2020-10-26 03:23:47 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:47 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:47 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:47 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:47 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-10-26 03:23:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:47 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:47 --> Total execution time: 0.3346
INFO - 2020-10-26 03:23:49 --> Config Class Initialized
INFO - 2020-10-26 03:23:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:49 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:49 --> URI Class Initialized
INFO - 2020-10-26 03:23:49 --> Router Class Initialized
INFO - 2020-10-26 03:23:49 --> Output Class Initialized
INFO - 2020-10-26 03:23:49 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:49 --> Input Class Initialized
INFO - 2020-10-26 03:23:49 --> Language Class Initialized
INFO - 2020-10-26 03:23:49 --> Language Class Initialized
INFO - 2020-10-26 03:23:49 --> Config Class Initialized
INFO - 2020-10-26 03:23:49 --> Loader Class Initialized
INFO - 2020-10-26 03:23:49 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:49 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:49 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:49 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:49 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-10-26 03:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:49 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:49 --> Total execution time: 0.3069
INFO - 2020-10-26 03:23:51 --> Config Class Initialized
INFO - 2020-10-26 03:23:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:52 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:52 --> URI Class Initialized
INFO - 2020-10-26 03:23:52 --> Router Class Initialized
INFO - 2020-10-26 03:23:52 --> Output Class Initialized
INFO - 2020-10-26 03:23:52 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:52 --> Input Class Initialized
INFO - 2020-10-26 03:23:52 --> Language Class Initialized
INFO - 2020-10-26 03:23:52 --> Language Class Initialized
INFO - 2020-10-26 03:23:52 --> Config Class Initialized
INFO - 2020-10-26 03:23:52 --> Loader Class Initialized
INFO - 2020-10-26 03:23:52 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:52 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:52 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:52 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:52 --> Controller Class Initialized
INFO - 2020-10-26 03:23:52 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:52 --> Total execution time: 0.2525
INFO - 2020-10-26 03:23:54 --> Config Class Initialized
INFO - 2020-10-26 03:23:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:54 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:55 --> URI Class Initialized
INFO - 2020-10-26 03:23:55 --> Router Class Initialized
INFO - 2020-10-26 03:23:55 --> Output Class Initialized
INFO - 2020-10-26 03:23:55 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:55 --> Input Class Initialized
INFO - 2020-10-26 03:23:55 --> Language Class Initialized
INFO - 2020-10-26 03:23:55 --> Language Class Initialized
INFO - 2020-10-26 03:23:55 --> Config Class Initialized
INFO - 2020-10-26 03:23:55 --> Loader Class Initialized
INFO - 2020-10-26 03:23:55 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:55 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:55 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:55 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:55 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-10-26 03:23:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:55 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:55 --> Total execution time: 0.3214
INFO - 2020-10-26 03:23:55 --> Config Class Initialized
INFO - 2020-10-26 03:23:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:56 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:56 --> URI Class Initialized
INFO - 2020-10-26 03:23:56 --> Router Class Initialized
INFO - 2020-10-26 03:23:56 --> Output Class Initialized
INFO - 2020-10-26 03:23:56 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:56 --> Input Class Initialized
INFO - 2020-10-26 03:23:56 --> Language Class Initialized
INFO - 2020-10-26 03:23:56 --> Language Class Initialized
INFO - 2020-10-26 03:23:56 --> Config Class Initialized
INFO - 2020-10-26 03:23:56 --> Loader Class Initialized
INFO - 2020-10-26 03:23:56 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:56 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:56 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:56 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:56 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-10-26 03:23:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:56 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:56 --> Total execution time: 0.3068
INFO - 2020-10-26 03:23:56 --> Config Class Initialized
INFO - 2020-10-26 03:23:56 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:56 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:56 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:56 --> URI Class Initialized
INFO - 2020-10-26 03:23:56 --> Router Class Initialized
INFO - 2020-10-26 03:23:56 --> Output Class Initialized
INFO - 2020-10-26 03:23:56 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:56 --> Input Class Initialized
INFO - 2020-10-26 03:23:56 --> Language Class Initialized
INFO - 2020-10-26 03:23:56 --> Language Class Initialized
INFO - 2020-10-26 03:23:56 --> Config Class Initialized
INFO - 2020-10-26 03:23:56 --> Loader Class Initialized
INFO - 2020-10-26 03:23:56 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:56 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:56 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:56 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:56 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:56 --> Controller Class Initialized
INFO - 2020-10-26 03:23:57 --> Config Class Initialized
INFO - 2020-10-26 03:23:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:57 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:57 --> URI Class Initialized
INFO - 2020-10-26 03:23:57 --> Router Class Initialized
INFO - 2020-10-26 03:23:57 --> Output Class Initialized
INFO - 2020-10-26 03:23:57 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:57 --> Input Class Initialized
INFO - 2020-10-26 03:23:57 --> Language Class Initialized
INFO - 2020-10-26 03:23:57 --> Language Class Initialized
INFO - 2020-10-26 03:23:57 --> Config Class Initialized
INFO - 2020-10-26 03:23:57 --> Loader Class Initialized
INFO - 2020-10-26 03:23:57 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:57 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:57 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:57 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:57 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:57 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-10-26 03:23:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:57 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:57 --> Total execution time: 0.3843
INFO - 2020-10-26 03:23:58 --> Config Class Initialized
INFO - 2020-10-26 03:23:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:23:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:23:58 --> Utf8 Class Initialized
INFO - 2020-10-26 03:23:58 --> URI Class Initialized
INFO - 2020-10-26 03:23:58 --> Router Class Initialized
INFO - 2020-10-26 03:23:58 --> Output Class Initialized
INFO - 2020-10-26 03:23:58 --> Security Class Initialized
DEBUG - 2020-10-26 03:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:23:58 --> Input Class Initialized
INFO - 2020-10-26 03:23:58 --> Language Class Initialized
INFO - 2020-10-26 03:23:58 --> Language Class Initialized
INFO - 2020-10-26 03:23:58 --> Config Class Initialized
INFO - 2020-10-26 03:23:58 --> Loader Class Initialized
INFO - 2020-10-26 03:23:58 --> Helper loaded: url_helper
INFO - 2020-10-26 03:23:58 --> Helper loaded: file_helper
INFO - 2020-10-26 03:23:58 --> Helper loaded: form_helper
INFO - 2020-10-26 03:23:58 --> Helper loaded: my_helper
INFO - 2020-10-26 03:23:58 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:23:58 --> Controller Class Initialized
DEBUG - 2020-10-26 03:23:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-26 03:23:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:23:58 --> Final output sent to browser
DEBUG - 2020-10-26 03:23:58 --> Total execution time: 0.2969
INFO - 2020-10-26 03:24:02 --> Config Class Initialized
INFO - 2020-10-26 03:24:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:24:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:24:02 --> Utf8 Class Initialized
INFO - 2020-10-26 03:24:02 --> URI Class Initialized
INFO - 2020-10-26 03:24:02 --> Router Class Initialized
INFO - 2020-10-26 03:24:02 --> Output Class Initialized
INFO - 2020-10-26 03:24:02 --> Security Class Initialized
DEBUG - 2020-10-26 03:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:24:02 --> Input Class Initialized
INFO - 2020-10-26 03:24:02 --> Language Class Initialized
INFO - 2020-10-26 03:24:02 --> Language Class Initialized
INFO - 2020-10-26 03:24:02 --> Config Class Initialized
INFO - 2020-10-26 03:24:02 --> Loader Class Initialized
INFO - 2020-10-26 03:24:02 --> Helper loaded: url_helper
INFO - 2020-10-26 03:24:02 --> Helper loaded: file_helper
INFO - 2020-10-26 03:24:02 --> Helper loaded: form_helper
INFO - 2020-10-26 03:24:02 --> Helper loaded: my_helper
INFO - 2020-10-26 03:24:02 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:24:02 --> Controller Class Initialized
DEBUG - 2020-10-26 03:24:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-26 03:24:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:24:02 --> Final output sent to browser
DEBUG - 2020-10-26 03:24:02 --> Total execution time: 0.2897
INFO - 2020-10-26 03:24:05 --> Config Class Initialized
INFO - 2020-10-26 03:24:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:24:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:24:05 --> Utf8 Class Initialized
INFO - 2020-10-26 03:24:05 --> URI Class Initialized
INFO - 2020-10-26 03:24:05 --> Router Class Initialized
INFO - 2020-10-26 03:24:05 --> Output Class Initialized
INFO - 2020-10-26 03:24:05 --> Security Class Initialized
DEBUG - 2020-10-26 03:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:24:05 --> Input Class Initialized
INFO - 2020-10-26 03:24:05 --> Language Class Initialized
INFO - 2020-10-26 03:24:05 --> Language Class Initialized
INFO - 2020-10-26 03:24:05 --> Config Class Initialized
INFO - 2020-10-26 03:24:05 --> Loader Class Initialized
INFO - 2020-10-26 03:24:05 --> Helper loaded: url_helper
INFO - 2020-10-26 03:24:05 --> Helper loaded: file_helper
INFO - 2020-10-26 03:24:05 --> Helper loaded: form_helper
INFO - 2020-10-26 03:24:05 --> Helper loaded: my_helper
INFO - 2020-10-26 03:24:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:24:05 --> Controller Class Initialized
DEBUG - 2020-10-26 03:24:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-26 03:24:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 03:24:05 --> Final output sent to browser
DEBUG - 2020-10-26 03:24:05 --> Total execution time: 0.3131
INFO - 2020-10-26 03:24:05 --> Config Class Initialized
INFO - 2020-10-26 03:24:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:24:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:24:05 --> Utf8 Class Initialized
INFO - 2020-10-26 03:24:05 --> URI Class Initialized
INFO - 2020-10-26 03:24:05 --> Router Class Initialized
INFO - 2020-10-26 03:24:05 --> Output Class Initialized
INFO - 2020-10-26 03:24:05 --> Security Class Initialized
DEBUG - 2020-10-26 03:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:24:05 --> Input Class Initialized
INFO - 2020-10-26 03:24:05 --> Language Class Initialized
INFO - 2020-10-26 03:24:05 --> Language Class Initialized
INFO - 2020-10-26 03:24:05 --> Config Class Initialized
INFO - 2020-10-26 03:24:05 --> Loader Class Initialized
INFO - 2020-10-26 03:24:05 --> Helper loaded: url_helper
INFO - 2020-10-26 03:24:05 --> Helper loaded: file_helper
INFO - 2020-10-26 03:24:05 --> Helper loaded: form_helper
INFO - 2020-10-26 03:24:05 --> Helper loaded: my_helper
INFO - 2020-10-26 03:24:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:24:06 --> Controller Class Initialized
INFO - 2020-10-26 03:24:09 --> Config Class Initialized
INFO - 2020-10-26 03:24:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 03:24:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 03:24:09 --> Utf8 Class Initialized
INFO - 2020-10-26 03:24:09 --> URI Class Initialized
INFO - 2020-10-26 03:24:09 --> Router Class Initialized
INFO - 2020-10-26 03:24:09 --> Output Class Initialized
INFO - 2020-10-26 03:24:09 --> Security Class Initialized
DEBUG - 2020-10-26 03:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 03:24:09 --> Input Class Initialized
INFO - 2020-10-26 03:24:09 --> Language Class Initialized
INFO - 2020-10-26 03:24:09 --> Language Class Initialized
INFO - 2020-10-26 03:24:09 --> Config Class Initialized
INFO - 2020-10-26 03:24:09 --> Loader Class Initialized
INFO - 2020-10-26 03:24:09 --> Helper loaded: url_helper
INFO - 2020-10-26 03:24:09 --> Helper loaded: file_helper
INFO - 2020-10-26 03:24:09 --> Helper loaded: form_helper
INFO - 2020-10-26 03:24:09 --> Helper loaded: my_helper
INFO - 2020-10-26 03:24:09 --> Database Driver Class Initialized
DEBUG - 2020-10-26 03:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 03:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 03:24:09 --> Controller Class Initialized
INFO - 2020-10-26 03:24:09 --> Final output sent to browser
DEBUG - 2020-10-26 03:24:09 --> Total execution time: 0.2579
INFO - 2020-10-26 05:28:32 --> Config Class Initialized
INFO - 2020-10-26 05:28:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:32 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:32 --> URI Class Initialized
INFO - 2020-10-26 05:28:32 --> Router Class Initialized
INFO - 2020-10-26 05:28:32 --> Output Class Initialized
INFO - 2020-10-26 05:28:32 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:32 --> Input Class Initialized
INFO - 2020-10-26 05:28:32 --> Language Class Initialized
INFO - 2020-10-26 05:28:32 --> Language Class Initialized
INFO - 2020-10-26 05:28:32 --> Config Class Initialized
INFO - 2020-10-26 05:28:32 --> Loader Class Initialized
INFO - 2020-10-26 05:28:32 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:32 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:32 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:32 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:32 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:32 --> Controller Class Initialized
INFO - 2020-10-26 05:28:32 --> Helper loaded: cookie_helper
INFO - 2020-10-26 05:28:32 --> Config Class Initialized
INFO - 2020-10-26 05:28:32 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:32 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:32 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:32 --> URI Class Initialized
INFO - 2020-10-26 05:28:32 --> Router Class Initialized
INFO - 2020-10-26 05:28:32 --> Output Class Initialized
INFO - 2020-10-26 05:28:32 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:32 --> Input Class Initialized
INFO - 2020-10-26 05:28:32 --> Language Class Initialized
INFO - 2020-10-26 05:28:32 --> Language Class Initialized
INFO - 2020-10-26 05:28:32 --> Config Class Initialized
INFO - 2020-10-26 05:28:32 --> Loader Class Initialized
INFO - 2020-10-26 05:28:32 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:32 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:32 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:32 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:32 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:32 --> Controller Class Initialized
DEBUG - 2020-10-26 05:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-26 05:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:28:32 --> Final output sent to browser
DEBUG - 2020-10-26 05:28:32 --> Total execution time: 0.2966
INFO - 2020-10-26 05:28:38 --> Config Class Initialized
INFO - 2020-10-26 05:28:38 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:38 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:38 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:38 --> URI Class Initialized
INFO - 2020-10-26 05:28:38 --> Router Class Initialized
INFO - 2020-10-26 05:28:39 --> Output Class Initialized
INFO - 2020-10-26 05:28:39 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:39 --> Input Class Initialized
INFO - 2020-10-26 05:28:39 --> Language Class Initialized
INFO - 2020-10-26 05:28:39 --> Language Class Initialized
INFO - 2020-10-26 05:28:39 --> Config Class Initialized
INFO - 2020-10-26 05:28:39 --> Loader Class Initialized
INFO - 2020-10-26 05:28:39 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:39 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:39 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:39 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:39 --> Controller Class Initialized
INFO - 2020-10-26 05:28:39 --> Helper loaded: cookie_helper
INFO - 2020-10-26 05:28:39 --> Final output sent to browser
DEBUG - 2020-10-26 05:28:39 --> Total execution time: 0.2888
INFO - 2020-10-26 05:28:40 --> Config Class Initialized
INFO - 2020-10-26 05:28:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:40 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:40 --> URI Class Initialized
INFO - 2020-10-26 05:28:40 --> Router Class Initialized
INFO - 2020-10-26 05:28:40 --> Output Class Initialized
INFO - 2020-10-26 05:28:40 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:40 --> Input Class Initialized
INFO - 2020-10-26 05:28:40 --> Language Class Initialized
INFO - 2020-10-26 05:28:40 --> Language Class Initialized
INFO - 2020-10-26 05:28:40 --> Config Class Initialized
INFO - 2020-10-26 05:28:40 --> Loader Class Initialized
INFO - 2020-10-26 05:28:40 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:40 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:40 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:40 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:40 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:40 --> Controller Class Initialized
DEBUG - 2020-10-26 05:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-26 05:28:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:28:40 --> Final output sent to browser
DEBUG - 2020-10-26 05:28:40 --> Total execution time: 0.3225
INFO - 2020-10-26 05:28:44 --> Config Class Initialized
INFO - 2020-10-26 05:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:44 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:44 --> URI Class Initialized
INFO - 2020-10-26 05:28:44 --> Router Class Initialized
INFO - 2020-10-26 05:28:44 --> Output Class Initialized
INFO - 2020-10-26 05:28:44 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:44 --> Input Class Initialized
INFO - 2020-10-26 05:28:44 --> Language Class Initialized
INFO - 2020-10-26 05:28:44 --> Language Class Initialized
INFO - 2020-10-26 05:28:44 --> Config Class Initialized
INFO - 2020-10-26 05:28:44 --> Loader Class Initialized
INFO - 2020-10-26 05:28:44 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:44 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:44 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:44 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:44 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:44 --> Controller Class Initialized
DEBUG - 2020-10-26 05:28:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 05:28:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:28:44 --> Final output sent to browser
DEBUG - 2020-10-26 05:28:44 --> Total execution time: 0.3026
INFO - 2020-10-26 05:28:44 --> Config Class Initialized
INFO - 2020-10-26 05:28:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:44 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:44 --> URI Class Initialized
INFO - 2020-10-26 05:28:45 --> Router Class Initialized
INFO - 2020-10-26 05:28:45 --> Output Class Initialized
INFO - 2020-10-26 05:28:45 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:45 --> Input Class Initialized
INFO - 2020-10-26 05:28:45 --> Language Class Initialized
INFO - 2020-10-26 05:28:45 --> Language Class Initialized
INFO - 2020-10-26 05:28:45 --> Config Class Initialized
INFO - 2020-10-26 05:28:45 --> Loader Class Initialized
INFO - 2020-10-26 05:28:45 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:45 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:45 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:45 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:45 --> Controller Class Initialized
INFO - 2020-10-26 05:28:48 --> Config Class Initialized
INFO - 2020-10-26 05:28:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:48 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:48 --> URI Class Initialized
INFO - 2020-10-26 05:28:48 --> Router Class Initialized
INFO - 2020-10-26 05:28:48 --> Output Class Initialized
INFO - 2020-10-26 05:28:48 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:48 --> Input Class Initialized
INFO - 2020-10-26 05:28:48 --> Language Class Initialized
INFO - 2020-10-26 05:28:48 --> Language Class Initialized
INFO - 2020-10-26 05:28:48 --> Config Class Initialized
INFO - 2020-10-26 05:28:48 --> Loader Class Initialized
INFO - 2020-10-26 05:28:48 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:48 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:48 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:48 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:48 --> Controller Class Initialized
DEBUG - 2020-10-26 05:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 05:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:28:48 --> Final output sent to browser
DEBUG - 2020-10-26 05:28:48 --> Total execution time: 0.3006
INFO - 2020-10-26 05:28:48 --> Config Class Initialized
INFO - 2020-10-26 05:28:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:49 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:49 --> URI Class Initialized
INFO - 2020-10-26 05:28:49 --> Router Class Initialized
INFO - 2020-10-26 05:28:49 --> Output Class Initialized
INFO - 2020-10-26 05:28:49 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:49 --> Input Class Initialized
INFO - 2020-10-26 05:28:49 --> Language Class Initialized
INFO - 2020-10-26 05:28:49 --> Language Class Initialized
INFO - 2020-10-26 05:28:49 --> Config Class Initialized
INFO - 2020-10-26 05:28:49 --> Loader Class Initialized
INFO - 2020-10-26 05:28:49 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:49 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:49 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:49 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:49 --> Controller Class Initialized
INFO - 2020-10-26 05:28:54 --> Config Class Initialized
INFO - 2020-10-26 05:28:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:54 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:54 --> URI Class Initialized
INFO - 2020-10-26 05:28:54 --> Router Class Initialized
INFO - 2020-10-26 05:28:54 --> Output Class Initialized
INFO - 2020-10-26 05:28:54 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:54 --> Input Class Initialized
INFO - 2020-10-26 05:28:54 --> Language Class Initialized
INFO - 2020-10-26 05:28:54 --> Language Class Initialized
INFO - 2020-10-26 05:28:54 --> Config Class Initialized
INFO - 2020-10-26 05:28:54 --> Loader Class Initialized
INFO - 2020-10-26 05:28:54 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:54 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:54 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:54 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:54 --> Controller Class Initialized
DEBUG - 2020-10-26 05:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 05:28:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:28:54 --> Final output sent to browser
DEBUG - 2020-10-26 05:28:54 --> Total execution time: 0.3148
INFO - 2020-10-26 05:28:54 --> Config Class Initialized
INFO - 2020-10-26 05:28:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:28:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:28:54 --> Utf8 Class Initialized
INFO - 2020-10-26 05:28:54 --> URI Class Initialized
INFO - 2020-10-26 05:28:54 --> Router Class Initialized
INFO - 2020-10-26 05:28:54 --> Output Class Initialized
INFO - 2020-10-26 05:28:54 --> Security Class Initialized
DEBUG - 2020-10-26 05:28:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:28:54 --> Input Class Initialized
INFO - 2020-10-26 05:28:54 --> Language Class Initialized
INFO - 2020-10-26 05:28:54 --> Language Class Initialized
INFO - 2020-10-26 05:28:54 --> Config Class Initialized
INFO - 2020-10-26 05:28:54 --> Loader Class Initialized
INFO - 2020-10-26 05:28:54 --> Helper loaded: url_helper
INFO - 2020-10-26 05:28:54 --> Helper loaded: file_helper
INFO - 2020-10-26 05:28:54 --> Helper loaded: form_helper
INFO - 2020-10-26 05:28:54 --> Helper loaded: my_helper
INFO - 2020-10-26 05:28:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:28:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:28:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:28:54 --> Controller Class Initialized
INFO - 2020-10-26 05:29:10 --> Config Class Initialized
INFO - 2020-10-26 05:29:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:10 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:10 --> URI Class Initialized
INFO - 2020-10-26 05:29:10 --> Router Class Initialized
INFO - 2020-10-26 05:29:10 --> Output Class Initialized
INFO - 2020-10-26 05:29:10 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:10 --> Input Class Initialized
INFO - 2020-10-26 05:29:10 --> Language Class Initialized
INFO - 2020-10-26 05:29:10 --> Language Class Initialized
INFO - 2020-10-26 05:29:10 --> Config Class Initialized
INFO - 2020-10-26 05:29:10 --> Loader Class Initialized
INFO - 2020-10-26 05:29:10 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:10 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:10 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:10 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:10 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:10 --> Controller Class Initialized
DEBUG - 2020-10-26 05:29:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 05:29:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:29:10 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:10 --> Total execution time: 0.2995
INFO - 2020-10-26 05:29:10 --> Config Class Initialized
INFO - 2020-10-26 05:29:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:10 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:10 --> URI Class Initialized
INFO - 2020-10-26 05:29:10 --> Router Class Initialized
INFO - 2020-10-26 05:29:10 --> Output Class Initialized
INFO - 2020-10-26 05:29:10 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:10 --> Input Class Initialized
INFO - 2020-10-26 05:29:10 --> Language Class Initialized
INFO - 2020-10-26 05:29:10 --> Language Class Initialized
INFO - 2020-10-26 05:29:10 --> Config Class Initialized
INFO - 2020-10-26 05:29:10 --> Loader Class Initialized
INFO - 2020-10-26 05:29:10 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:10 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:10 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:11 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:11 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:11 --> Controller Class Initialized
INFO - 2020-10-26 05:29:15 --> Config Class Initialized
INFO - 2020-10-26 05:29:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:15 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:15 --> URI Class Initialized
INFO - 2020-10-26 05:29:15 --> Router Class Initialized
INFO - 2020-10-26 05:29:15 --> Output Class Initialized
INFO - 2020-10-26 05:29:15 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:15 --> Input Class Initialized
INFO - 2020-10-26 05:29:15 --> Language Class Initialized
INFO - 2020-10-26 05:29:15 --> Language Class Initialized
INFO - 2020-10-26 05:29:15 --> Config Class Initialized
INFO - 2020-10-26 05:29:15 --> Loader Class Initialized
INFO - 2020-10-26 05:29:15 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:15 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:15 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:15 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:15 --> Controller Class Initialized
DEBUG - 2020-10-26 05:29:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 05:29:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:29:15 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:15 --> Total execution time: 0.3063
INFO - 2020-10-26 05:29:16 --> Config Class Initialized
INFO - 2020-10-26 05:29:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:16 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:16 --> URI Class Initialized
INFO - 2020-10-26 05:29:16 --> Router Class Initialized
INFO - 2020-10-26 05:29:16 --> Output Class Initialized
INFO - 2020-10-26 05:29:16 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:16 --> Input Class Initialized
INFO - 2020-10-26 05:29:16 --> Language Class Initialized
INFO - 2020-10-26 05:29:16 --> Language Class Initialized
INFO - 2020-10-26 05:29:16 --> Config Class Initialized
INFO - 2020-10-26 05:29:16 --> Loader Class Initialized
INFO - 2020-10-26 05:29:16 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:16 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:16 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:16 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:16 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:16 --> Controller Class Initialized
INFO - 2020-10-26 05:29:23 --> Config Class Initialized
INFO - 2020-10-26 05:29:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:23 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:23 --> URI Class Initialized
INFO - 2020-10-26 05:29:23 --> Router Class Initialized
INFO - 2020-10-26 05:29:23 --> Output Class Initialized
INFO - 2020-10-26 05:29:23 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:23 --> Input Class Initialized
INFO - 2020-10-26 05:29:23 --> Language Class Initialized
INFO - 2020-10-26 05:29:23 --> Language Class Initialized
INFO - 2020-10-26 05:29:23 --> Config Class Initialized
INFO - 2020-10-26 05:29:23 --> Loader Class Initialized
INFO - 2020-10-26 05:29:23 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:23 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:23 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:23 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:23 --> Controller Class Initialized
ERROR - 2020-10-26 05:29:23 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-10-26 05:29:23 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 05:29:26 --> Config Class Initialized
INFO - 2020-10-26 05:29:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:26 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:26 --> URI Class Initialized
INFO - 2020-10-26 05:29:26 --> Router Class Initialized
INFO - 2020-10-26 05:29:26 --> Output Class Initialized
INFO - 2020-10-26 05:29:26 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:26 --> Input Class Initialized
INFO - 2020-10-26 05:29:26 --> Language Class Initialized
INFO - 2020-10-26 05:29:26 --> Language Class Initialized
INFO - 2020-10-26 05:29:26 --> Config Class Initialized
INFO - 2020-10-26 05:29:27 --> Loader Class Initialized
INFO - 2020-10-26 05:29:27 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:27 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:27 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:27 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:27 --> Controller Class Initialized
ERROR - 2020-10-26 05:29:27 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '9'
INFO - 2020-10-26 05:29:27 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-26 05:29:30 --> Config Class Initialized
INFO - 2020-10-26 05:29:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:30 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:30 --> URI Class Initialized
INFO - 2020-10-26 05:29:30 --> Router Class Initialized
INFO - 2020-10-26 05:29:30 --> Output Class Initialized
INFO - 2020-10-26 05:29:30 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:30 --> Input Class Initialized
INFO - 2020-10-26 05:29:30 --> Language Class Initialized
INFO - 2020-10-26 05:29:30 --> Language Class Initialized
INFO - 2020-10-26 05:29:30 --> Config Class Initialized
INFO - 2020-10-26 05:29:30 --> Loader Class Initialized
INFO - 2020-10-26 05:29:30 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:30 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:30 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:30 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:30 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:30 --> Controller Class Initialized
DEBUG - 2020-10-26 05:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 05:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:29:30 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:30 --> Total execution time: 0.3054
INFO - 2020-10-26 05:29:35 --> Config Class Initialized
INFO - 2020-10-26 05:29:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:35 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:35 --> URI Class Initialized
INFO - 2020-10-26 05:29:35 --> Router Class Initialized
INFO - 2020-10-26 05:29:35 --> Output Class Initialized
INFO - 2020-10-26 05:29:35 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:35 --> Input Class Initialized
INFO - 2020-10-26 05:29:35 --> Language Class Initialized
INFO - 2020-10-26 05:29:35 --> Language Class Initialized
INFO - 2020-10-26 05:29:35 --> Config Class Initialized
INFO - 2020-10-26 05:29:35 --> Loader Class Initialized
INFO - 2020-10-26 05:29:35 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:35 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:35 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:35 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:35 --> Controller Class Initialized
DEBUG - 2020-10-26 05:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-26 05:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:29:35 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:35 --> Total execution time: 0.2961
INFO - 2020-10-26 05:29:35 --> Config Class Initialized
INFO - 2020-10-26 05:29:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:35 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:35 --> URI Class Initialized
INFO - 2020-10-26 05:29:35 --> Router Class Initialized
INFO - 2020-10-26 05:29:35 --> Output Class Initialized
INFO - 2020-10-26 05:29:35 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:35 --> Input Class Initialized
INFO - 2020-10-26 05:29:35 --> Language Class Initialized
INFO - 2020-10-26 05:29:36 --> Language Class Initialized
INFO - 2020-10-26 05:29:36 --> Config Class Initialized
INFO - 2020-10-26 05:29:36 --> Loader Class Initialized
INFO - 2020-10-26 05:29:36 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:36 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:36 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:36 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:36 --> Controller Class Initialized
INFO - 2020-10-26 05:29:37 --> Config Class Initialized
INFO - 2020-10-26 05:29:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:37 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:37 --> URI Class Initialized
INFO - 2020-10-26 05:29:37 --> Router Class Initialized
INFO - 2020-10-26 05:29:37 --> Output Class Initialized
INFO - 2020-10-26 05:29:37 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:37 --> Input Class Initialized
INFO - 2020-10-26 05:29:37 --> Language Class Initialized
INFO - 2020-10-26 05:29:37 --> Language Class Initialized
INFO - 2020-10-26 05:29:37 --> Config Class Initialized
INFO - 2020-10-26 05:29:37 --> Loader Class Initialized
INFO - 2020-10-26 05:29:37 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:37 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:37 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:37 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:37 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:37 --> Controller Class Initialized
DEBUG - 2020-10-26 05:29:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 05:29:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:29:37 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:37 --> Total execution time: 0.2936
INFO - 2020-10-26 05:29:37 --> Config Class Initialized
INFO - 2020-10-26 05:29:37 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:37 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:37 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:37 --> URI Class Initialized
INFO - 2020-10-26 05:29:37 --> Router Class Initialized
INFO - 2020-10-26 05:29:37 --> Output Class Initialized
INFO - 2020-10-26 05:29:37 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:37 --> Input Class Initialized
INFO - 2020-10-26 05:29:37 --> Language Class Initialized
INFO - 2020-10-26 05:29:37 --> Language Class Initialized
INFO - 2020-10-26 05:29:37 --> Config Class Initialized
INFO - 2020-10-26 05:29:37 --> Loader Class Initialized
INFO - 2020-10-26 05:29:37 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:37 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:37 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:37 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:37 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:37 --> Controller Class Initialized
INFO - 2020-10-26 05:29:40 --> Config Class Initialized
INFO - 2020-10-26 05:29:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:40 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:40 --> URI Class Initialized
INFO - 2020-10-26 05:29:40 --> Router Class Initialized
INFO - 2020-10-26 05:29:40 --> Output Class Initialized
INFO - 2020-10-26 05:29:40 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:40 --> Input Class Initialized
INFO - 2020-10-26 05:29:40 --> Language Class Initialized
INFO - 2020-10-26 05:29:40 --> Language Class Initialized
INFO - 2020-10-26 05:29:40 --> Config Class Initialized
INFO - 2020-10-26 05:29:40 --> Loader Class Initialized
INFO - 2020-10-26 05:29:40 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:40 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:40 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:40 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:40 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:40 --> Controller Class Initialized
INFO - 2020-10-26 05:29:40 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:40 --> Total execution time: 0.3679
INFO - 2020-10-26 05:29:40 --> Config Class Initialized
INFO - 2020-10-26 05:29:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:40 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:40 --> URI Class Initialized
INFO - 2020-10-26 05:29:40 --> Router Class Initialized
INFO - 2020-10-26 05:29:40 --> Output Class Initialized
INFO - 2020-10-26 05:29:40 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:40 --> Input Class Initialized
INFO - 2020-10-26 05:29:40 --> Language Class Initialized
INFO - 2020-10-26 05:29:40 --> Language Class Initialized
INFO - 2020-10-26 05:29:40 --> Config Class Initialized
INFO - 2020-10-26 05:29:40 --> Loader Class Initialized
INFO - 2020-10-26 05:29:40 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:40 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:41 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:41 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:41 --> Controller Class Initialized
INFO - 2020-10-26 05:29:43 --> Config Class Initialized
INFO - 2020-10-26 05:29:43 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:43 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:43 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:43 --> URI Class Initialized
INFO - 2020-10-26 05:29:43 --> Router Class Initialized
INFO - 2020-10-26 05:29:43 --> Output Class Initialized
INFO - 2020-10-26 05:29:43 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:43 --> Input Class Initialized
INFO - 2020-10-26 05:29:43 --> Language Class Initialized
INFO - 2020-10-26 05:29:43 --> Language Class Initialized
INFO - 2020-10-26 05:29:43 --> Config Class Initialized
INFO - 2020-10-26 05:29:43 --> Loader Class Initialized
INFO - 2020-10-26 05:29:43 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:43 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:43 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:43 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:43 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:43 --> Controller Class Initialized
INFO - 2020-10-26 05:29:43 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:43 --> Total execution time: 0.3396
INFO - 2020-10-26 05:29:43 --> Config Class Initialized
INFO - 2020-10-26 05:29:43 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:43 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:43 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:43 --> URI Class Initialized
INFO - 2020-10-26 05:29:43 --> Router Class Initialized
INFO - 2020-10-26 05:29:43 --> Output Class Initialized
INFO - 2020-10-26 05:29:43 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:43 --> Input Class Initialized
INFO - 2020-10-26 05:29:43 --> Language Class Initialized
INFO - 2020-10-26 05:29:43 --> Language Class Initialized
INFO - 2020-10-26 05:29:43 --> Config Class Initialized
INFO - 2020-10-26 05:29:43 --> Loader Class Initialized
INFO - 2020-10-26 05:29:43 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:43 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:43 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:43 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:43 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:43 --> Controller Class Initialized
INFO - 2020-10-26 05:29:45 --> Config Class Initialized
INFO - 2020-10-26 05:29:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:45 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:45 --> URI Class Initialized
INFO - 2020-10-26 05:29:45 --> Router Class Initialized
INFO - 2020-10-26 05:29:45 --> Output Class Initialized
INFO - 2020-10-26 05:29:45 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:45 --> Input Class Initialized
INFO - 2020-10-26 05:29:45 --> Language Class Initialized
INFO - 2020-10-26 05:29:45 --> Language Class Initialized
INFO - 2020-10-26 05:29:45 --> Config Class Initialized
INFO - 2020-10-26 05:29:45 --> Loader Class Initialized
INFO - 2020-10-26 05:29:45 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:45 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:45 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:45 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:45 --> Controller Class Initialized
INFO - 2020-10-26 05:29:45 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:45 --> Total execution time: 0.3607
INFO - 2020-10-26 05:29:45 --> Config Class Initialized
INFO - 2020-10-26 05:29:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:45 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:45 --> URI Class Initialized
INFO - 2020-10-26 05:29:45 --> Router Class Initialized
INFO - 2020-10-26 05:29:45 --> Output Class Initialized
INFO - 2020-10-26 05:29:45 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:45 --> Input Class Initialized
INFO - 2020-10-26 05:29:45 --> Language Class Initialized
INFO - 2020-10-26 05:29:45 --> Language Class Initialized
INFO - 2020-10-26 05:29:45 --> Config Class Initialized
INFO - 2020-10-26 05:29:45 --> Loader Class Initialized
INFO - 2020-10-26 05:29:45 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:45 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:45 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:45 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:45 --> Controller Class Initialized
INFO - 2020-10-26 05:29:46 --> Config Class Initialized
INFO - 2020-10-26 05:29:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:47 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:47 --> URI Class Initialized
INFO - 2020-10-26 05:29:47 --> Router Class Initialized
INFO - 2020-10-26 05:29:47 --> Output Class Initialized
INFO - 2020-10-26 05:29:47 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:47 --> Input Class Initialized
INFO - 2020-10-26 05:29:47 --> Language Class Initialized
INFO - 2020-10-26 05:29:47 --> Language Class Initialized
INFO - 2020-10-26 05:29:47 --> Config Class Initialized
INFO - 2020-10-26 05:29:47 --> Loader Class Initialized
INFO - 2020-10-26 05:29:47 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:47 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:47 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:47 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:47 --> Controller Class Initialized
INFO - 2020-10-26 05:29:47 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:47 --> Total execution time: 0.3427
INFO - 2020-10-26 05:29:47 --> Config Class Initialized
INFO - 2020-10-26 05:29:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:47 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:47 --> URI Class Initialized
INFO - 2020-10-26 05:29:47 --> Router Class Initialized
INFO - 2020-10-26 05:29:47 --> Output Class Initialized
INFO - 2020-10-26 05:29:47 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:47 --> Input Class Initialized
INFO - 2020-10-26 05:29:47 --> Language Class Initialized
INFO - 2020-10-26 05:29:47 --> Language Class Initialized
INFO - 2020-10-26 05:29:47 --> Config Class Initialized
INFO - 2020-10-26 05:29:47 --> Loader Class Initialized
INFO - 2020-10-26 05:29:47 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:47 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:47 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:47 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:47 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:47 --> Controller Class Initialized
INFO - 2020-10-26 05:29:48 --> Config Class Initialized
INFO - 2020-10-26 05:29:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:49 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:49 --> URI Class Initialized
INFO - 2020-10-26 05:29:49 --> Router Class Initialized
INFO - 2020-10-26 05:29:49 --> Output Class Initialized
INFO - 2020-10-26 05:29:49 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:49 --> Input Class Initialized
INFO - 2020-10-26 05:29:49 --> Language Class Initialized
INFO - 2020-10-26 05:29:49 --> Language Class Initialized
INFO - 2020-10-26 05:29:49 --> Config Class Initialized
INFO - 2020-10-26 05:29:49 --> Loader Class Initialized
INFO - 2020-10-26 05:29:49 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:49 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:49 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:49 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:49 --> Controller Class Initialized
INFO - 2020-10-26 05:29:49 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:49 --> Total execution time: 0.3238
INFO - 2020-10-26 05:29:49 --> Config Class Initialized
INFO - 2020-10-26 05:29:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:49 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:49 --> URI Class Initialized
INFO - 2020-10-26 05:29:49 --> Router Class Initialized
INFO - 2020-10-26 05:29:49 --> Output Class Initialized
INFO - 2020-10-26 05:29:49 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:49 --> Input Class Initialized
INFO - 2020-10-26 05:29:49 --> Language Class Initialized
INFO - 2020-10-26 05:29:49 --> Language Class Initialized
INFO - 2020-10-26 05:29:49 --> Config Class Initialized
INFO - 2020-10-26 05:29:49 --> Loader Class Initialized
INFO - 2020-10-26 05:29:49 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:49 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:49 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:49 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:49 --> Controller Class Initialized
INFO - 2020-10-26 05:29:51 --> Config Class Initialized
INFO - 2020-10-26 05:29:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:51 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:51 --> URI Class Initialized
INFO - 2020-10-26 05:29:51 --> Router Class Initialized
INFO - 2020-10-26 05:29:51 --> Output Class Initialized
INFO - 2020-10-26 05:29:51 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:51 --> Input Class Initialized
INFO - 2020-10-26 05:29:51 --> Language Class Initialized
INFO - 2020-10-26 05:29:51 --> Language Class Initialized
INFO - 2020-10-26 05:29:51 --> Config Class Initialized
INFO - 2020-10-26 05:29:51 --> Loader Class Initialized
INFO - 2020-10-26 05:29:51 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:51 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:51 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:51 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:51 --> Controller Class Initialized
INFO - 2020-10-26 05:29:51 --> Final output sent to browser
DEBUG - 2020-10-26 05:29:51 --> Total execution time: 0.3362
INFO - 2020-10-26 05:29:51 --> Config Class Initialized
INFO - 2020-10-26 05:29:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:29:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:29:51 --> Utf8 Class Initialized
INFO - 2020-10-26 05:29:51 --> URI Class Initialized
INFO - 2020-10-26 05:29:51 --> Router Class Initialized
INFO - 2020-10-26 05:29:51 --> Output Class Initialized
INFO - 2020-10-26 05:29:51 --> Security Class Initialized
DEBUG - 2020-10-26 05:29:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:29:51 --> Input Class Initialized
INFO - 2020-10-26 05:29:51 --> Language Class Initialized
INFO - 2020-10-26 05:29:51 --> Language Class Initialized
INFO - 2020-10-26 05:29:51 --> Config Class Initialized
INFO - 2020-10-26 05:29:51 --> Loader Class Initialized
INFO - 2020-10-26 05:29:51 --> Helper loaded: url_helper
INFO - 2020-10-26 05:29:51 --> Helper loaded: file_helper
INFO - 2020-10-26 05:29:51 --> Helper loaded: form_helper
INFO - 2020-10-26 05:29:51 --> Helper loaded: my_helper
INFO - 2020-10-26 05:29:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:29:51 --> Controller Class Initialized
INFO - 2020-10-26 05:31:10 --> Config Class Initialized
INFO - 2020-10-26 05:31:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:31:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:31:10 --> Utf8 Class Initialized
INFO - 2020-10-26 05:31:10 --> URI Class Initialized
INFO - 2020-10-26 05:31:10 --> Router Class Initialized
INFO - 2020-10-26 05:31:10 --> Output Class Initialized
INFO - 2020-10-26 05:31:10 --> Security Class Initialized
DEBUG - 2020-10-26 05:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:31:10 --> Input Class Initialized
INFO - 2020-10-26 05:31:10 --> Language Class Initialized
INFO - 2020-10-26 05:31:10 --> Language Class Initialized
INFO - 2020-10-26 05:31:10 --> Config Class Initialized
INFO - 2020-10-26 05:31:10 --> Loader Class Initialized
INFO - 2020-10-26 05:31:10 --> Helper loaded: url_helper
INFO - 2020-10-26 05:31:10 --> Helper loaded: file_helper
INFO - 2020-10-26 05:31:10 --> Helper loaded: form_helper
INFO - 2020-10-26 05:31:10 --> Helper loaded: my_helper
INFO - 2020-10-26 05:31:10 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:31:10 --> Controller Class Initialized
DEBUG - 2020-10-26 05:31:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 05:31:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:31:10 --> Final output sent to browser
DEBUG - 2020-10-26 05:31:10 --> Total execution time: 0.3441
INFO - 2020-10-26 05:31:10 --> Config Class Initialized
INFO - 2020-10-26 05:31:10 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:31:10 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:31:10 --> Utf8 Class Initialized
INFO - 2020-10-26 05:31:10 --> URI Class Initialized
INFO - 2020-10-26 05:31:10 --> Router Class Initialized
INFO - 2020-10-26 05:31:10 --> Output Class Initialized
INFO - 2020-10-26 05:31:10 --> Security Class Initialized
DEBUG - 2020-10-26 05:31:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:31:10 --> Input Class Initialized
INFO - 2020-10-26 05:31:10 --> Language Class Initialized
INFO - 2020-10-26 05:31:10 --> Language Class Initialized
INFO - 2020-10-26 05:31:10 --> Config Class Initialized
INFO - 2020-10-26 05:31:10 --> Loader Class Initialized
INFO - 2020-10-26 05:31:10 --> Helper loaded: url_helper
INFO - 2020-10-26 05:31:10 --> Helper loaded: file_helper
INFO - 2020-10-26 05:31:10 --> Helper loaded: form_helper
INFO - 2020-10-26 05:31:10 --> Helper loaded: my_helper
INFO - 2020-10-26 05:31:10 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:31:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:31:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:31:10 --> Controller Class Initialized
INFO - 2020-10-26 05:32:47 --> Config Class Initialized
INFO - 2020-10-26 05:32:47 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:32:47 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:32:47 --> Utf8 Class Initialized
INFO - 2020-10-26 05:32:47 --> URI Class Initialized
INFO - 2020-10-26 05:32:47 --> Router Class Initialized
INFO - 2020-10-26 05:32:47 --> Output Class Initialized
INFO - 2020-10-26 05:32:47 --> Security Class Initialized
DEBUG - 2020-10-26 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:32:48 --> Input Class Initialized
INFO - 2020-10-26 05:32:48 --> Language Class Initialized
INFO - 2020-10-26 05:32:48 --> Language Class Initialized
INFO - 2020-10-26 05:32:48 --> Config Class Initialized
INFO - 2020-10-26 05:32:48 --> Loader Class Initialized
INFO - 2020-10-26 05:32:48 --> Helper loaded: url_helper
INFO - 2020-10-26 05:32:48 --> Helper loaded: file_helper
INFO - 2020-10-26 05:32:48 --> Helper loaded: form_helper
INFO - 2020-10-26 05:32:48 --> Helper loaded: my_helper
INFO - 2020-10-26 05:32:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:32:48 --> Controller Class Initialized
DEBUG - 2020-10-26 05:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 05:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 05:32:48 --> Final output sent to browser
DEBUG - 2020-10-26 05:32:48 --> Total execution time: 0.3066
INFO - 2020-10-26 05:32:48 --> Config Class Initialized
INFO - 2020-10-26 05:32:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:32:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:32:48 --> Utf8 Class Initialized
INFO - 2020-10-26 05:32:48 --> URI Class Initialized
INFO - 2020-10-26 05:32:48 --> Router Class Initialized
INFO - 2020-10-26 05:32:48 --> Output Class Initialized
INFO - 2020-10-26 05:32:48 --> Security Class Initialized
DEBUG - 2020-10-26 05:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:32:48 --> Input Class Initialized
INFO - 2020-10-26 05:32:48 --> Language Class Initialized
INFO - 2020-10-26 05:32:48 --> Language Class Initialized
INFO - 2020-10-26 05:32:48 --> Config Class Initialized
INFO - 2020-10-26 05:32:48 --> Loader Class Initialized
INFO - 2020-10-26 05:32:48 --> Helper loaded: url_helper
INFO - 2020-10-26 05:32:48 --> Helper loaded: file_helper
INFO - 2020-10-26 05:32:48 --> Helper loaded: form_helper
INFO - 2020-10-26 05:32:48 --> Helper loaded: my_helper
INFO - 2020-10-26 05:32:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:32:48 --> Controller Class Initialized
INFO - 2020-10-26 05:32:51 --> Config Class Initialized
INFO - 2020-10-26 05:32:51 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:32:51 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:32:51 --> Utf8 Class Initialized
INFO - 2020-10-26 05:32:51 --> URI Class Initialized
INFO - 2020-10-26 05:32:51 --> Router Class Initialized
INFO - 2020-10-26 05:32:51 --> Output Class Initialized
INFO - 2020-10-26 05:32:51 --> Security Class Initialized
DEBUG - 2020-10-26 05:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:32:51 --> Input Class Initialized
INFO - 2020-10-26 05:32:51 --> Language Class Initialized
INFO - 2020-10-26 05:32:51 --> Language Class Initialized
INFO - 2020-10-26 05:32:51 --> Config Class Initialized
INFO - 2020-10-26 05:32:51 --> Loader Class Initialized
INFO - 2020-10-26 05:32:51 --> Helper loaded: url_helper
INFO - 2020-10-26 05:32:51 --> Helper loaded: file_helper
INFO - 2020-10-26 05:32:51 --> Helper loaded: form_helper
INFO - 2020-10-26 05:32:51 --> Helper loaded: my_helper
INFO - 2020-10-26 05:32:51 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:32:52 --> Controller Class Initialized
INFO - 2020-10-26 05:32:52 --> Final output sent to browser
DEBUG - 2020-10-26 05:32:52 --> Total execution time: 0.3576
INFO - 2020-10-26 05:32:52 --> Config Class Initialized
INFO - 2020-10-26 05:32:52 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:32:52 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:32:52 --> Utf8 Class Initialized
INFO - 2020-10-26 05:32:52 --> URI Class Initialized
INFO - 2020-10-26 05:32:52 --> Router Class Initialized
INFO - 2020-10-26 05:32:52 --> Output Class Initialized
INFO - 2020-10-26 05:32:52 --> Security Class Initialized
DEBUG - 2020-10-26 05:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:32:52 --> Input Class Initialized
INFO - 2020-10-26 05:32:52 --> Language Class Initialized
INFO - 2020-10-26 05:32:52 --> Language Class Initialized
INFO - 2020-10-26 05:32:52 --> Config Class Initialized
INFO - 2020-10-26 05:32:52 --> Loader Class Initialized
INFO - 2020-10-26 05:32:52 --> Helper loaded: url_helper
INFO - 2020-10-26 05:32:52 --> Helper loaded: file_helper
INFO - 2020-10-26 05:32:52 --> Helper loaded: form_helper
INFO - 2020-10-26 05:32:52 --> Helper loaded: my_helper
INFO - 2020-10-26 05:32:52 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:32:52 --> Controller Class Initialized
INFO - 2020-10-26 05:32:53 --> Config Class Initialized
INFO - 2020-10-26 05:32:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 05:32:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 05:32:53 --> Utf8 Class Initialized
INFO - 2020-10-26 05:32:53 --> URI Class Initialized
INFO - 2020-10-26 05:32:53 --> Router Class Initialized
INFO - 2020-10-26 05:32:53 --> Output Class Initialized
INFO - 2020-10-26 05:32:53 --> Security Class Initialized
DEBUG - 2020-10-26 05:32:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 05:32:53 --> Input Class Initialized
INFO - 2020-10-26 05:32:53 --> Language Class Initialized
INFO - 2020-10-26 05:32:53 --> Language Class Initialized
INFO - 2020-10-26 05:32:53 --> Config Class Initialized
INFO - 2020-10-26 05:32:53 --> Loader Class Initialized
INFO - 2020-10-26 05:32:53 --> Helper loaded: url_helper
INFO - 2020-10-26 05:32:54 --> Helper loaded: file_helper
INFO - 2020-10-26 05:32:54 --> Helper loaded: form_helper
INFO - 2020-10-26 05:32:54 --> Helper loaded: my_helper
INFO - 2020-10-26 05:32:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 05:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 05:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 05:32:54 --> Controller Class Initialized
INFO - 2020-10-26 05:32:54 --> Final output sent to browser
DEBUG - 2020-10-26 05:32:54 --> Total execution time: 0.2791
INFO - 2020-10-26 07:48:57 --> Config Class Initialized
INFO - 2020-10-26 07:48:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:48:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:48:57 --> Utf8 Class Initialized
INFO - 2020-10-26 07:48:57 --> URI Class Initialized
INFO - 2020-10-26 07:48:57 --> Router Class Initialized
INFO - 2020-10-26 07:48:57 --> Output Class Initialized
INFO - 2020-10-26 07:48:57 --> Security Class Initialized
DEBUG - 2020-10-26 07:48:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:48:57 --> Input Class Initialized
INFO - 2020-10-26 07:48:57 --> Language Class Initialized
INFO - 2020-10-26 07:48:57 --> Language Class Initialized
INFO - 2020-10-26 07:48:57 --> Config Class Initialized
INFO - 2020-10-26 07:48:57 --> Loader Class Initialized
INFO - 2020-10-26 07:48:57 --> Helper loaded: url_helper
INFO - 2020-10-26 07:48:57 --> Helper loaded: file_helper
INFO - 2020-10-26 07:48:57 --> Helper loaded: form_helper
INFO - 2020-10-26 07:48:57 --> Helper loaded: my_helper
INFO - 2020-10-26 07:48:57 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:48:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:48:57 --> Controller Class Initialized
DEBUG - 2020-10-26 07:48:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 07:48:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:48:57 --> Final output sent to browser
DEBUG - 2020-10-26 07:48:57 --> Total execution time: 0.3021
INFO - 2020-10-26 07:48:58 --> Config Class Initialized
INFO - 2020-10-26 07:48:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:48:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:48:58 --> Utf8 Class Initialized
INFO - 2020-10-26 07:48:58 --> URI Class Initialized
INFO - 2020-10-26 07:48:58 --> Router Class Initialized
INFO - 2020-10-26 07:48:58 --> Output Class Initialized
INFO - 2020-10-26 07:48:58 --> Security Class Initialized
DEBUG - 2020-10-26 07:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:48:58 --> Input Class Initialized
INFO - 2020-10-26 07:48:58 --> Language Class Initialized
INFO - 2020-10-26 07:48:58 --> Language Class Initialized
INFO - 2020-10-26 07:48:58 --> Config Class Initialized
INFO - 2020-10-26 07:48:58 --> Loader Class Initialized
INFO - 2020-10-26 07:48:58 --> Helper loaded: url_helper
INFO - 2020-10-26 07:48:58 --> Helper loaded: file_helper
INFO - 2020-10-26 07:48:58 --> Helper loaded: form_helper
INFO - 2020-10-26 07:48:58 --> Helper loaded: my_helper
INFO - 2020-10-26 07:48:58 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:48:58 --> Controller Class Initialized
INFO - 2020-10-26 07:48:59 --> Config Class Initialized
INFO - 2020-10-26 07:48:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:48:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:48:59 --> Utf8 Class Initialized
INFO - 2020-10-26 07:48:59 --> URI Class Initialized
INFO - 2020-10-26 07:48:59 --> Router Class Initialized
INFO - 2020-10-26 07:48:59 --> Output Class Initialized
INFO - 2020-10-26 07:48:59 --> Security Class Initialized
DEBUG - 2020-10-26 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:48:59 --> Input Class Initialized
INFO - 2020-10-26 07:48:59 --> Language Class Initialized
INFO - 2020-10-26 07:48:59 --> Language Class Initialized
INFO - 2020-10-26 07:48:59 --> Config Class Initialized
INFO - 2020-10-26 07:48:59 --> Loader Class Initialized
INFO - 2020-10-26 07:48:59 --> Helper loaded: url_helper
INFO - 2020-10-26 07:48:59 --> Helper loaded: file_helper
INFO - 2020-10-26 07:48:59 --> Helper loaded: form_helper
INFO - 2020-10-26 07:48:59 --> Helper loaded: my_helper
INFO - 2020-10-26 07:48:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:48:59 --> Controller Class Initialized
DEBUG - 2020-10-26 07:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 07:48:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:48:59 --> Final output sent to browser
DEBUG - 2020-10-26 07:48:59 --> Total execution time: 0.3153
INFO - 2020-10-26 07:48:59 --> Config Class Initialized
INFO - 2020-10-26 07:48:59 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:48:59 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:48:59 --> Utf8 Class Initialized
INFO - 2020-10-26 07:48:59 --> URI Class Initialized
INFO - 2020-10-26 07:48:59 --> Router Class Initialized
INFO - 2020-10-26 07:48:59 --> Output Class Initialized
INFO - 2020-10-26 07:48:59 --> Security Class Initialized
DEBUG - 2020-10-26 07:48:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:48:59 --> Input Class Initialized
INFO - 2020-10-26 07:48:59 --> Language Class Initialized
INFO - 2020-10-26 07:48:59 --> Language Class Initialized
INFO - 2020-10-26 07:48:59 --> Config Class Initialized
INFO - 2020-10-26 07:48:59 --> Loader Class Initialized
INFO - 2020-10-26 07:48:59 --> Helper loaded: url_helper
INFO - 2020-10-26 07:48:59 --> Helper loaded: file_helper
INFO - 2020-10-26 07:48:59 --> Helper loaded: form_helper
INFO - 2020-10-26 07:48:59 --> Helper loaded: my_helper
INFO - 2020-10-26 07:48:59 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:48:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:48:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:48:59 --> Controller Class Initialized
INFO - 2020-10-26 07:49:02 --> Config Class Initialized
INFO - 2020-10-26 07:49:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:02 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:02 --> URI Class Initialized
INFO - 2020-10-26 07:49:02 --> Router Class Initialized
INFO - 2020-10-26 07:49:02 --> Output Class Initialized
INFO - 2020-10-26 07:49:02 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:02 --> Input Class Initialized
INFO - 2020-10-26 07:49:02 --> Language Class Initialized
INFO - 2020-10-26 07:49:02 --> Language Class Initialized
INFO - 2020-10-26 07:49:02 --> Config Class Initialized
INFO - 2020-10-26 07:49:02 --> Loader Class Initialized
INFO - 2020-10-26 07:49:02 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:02 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:02 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:02 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:02 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:02 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-26 07:49:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:02 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:02 --> Total execution time: 0.3108
INFO - 2020-10-26 07:49:02 --> Config Class Initialized
INFO - 2020-10-26 07:49:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:02 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:02 --> URI Class Initialized
INFO - 2020-10-26 07:49:02 --> Router Class Initialized
INFO - 2020-10-26 07:49:02 --> Output Class Initialized
INFO - 2020-10-26 07:49:02 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:02 --> Input Class Initialized
INFO - 2020-10-26 07:49:02 --> Language Class Initialized
INFO - 2020-10-26 07:49:02 --> Language Class Initialized
INFO - 2020-10-26 07:49:02 --> Config Class Initialized
INFO - 2020-10-26 07:49:02 --> Loader Class Initialized
INFO - 2020-10-26 07:49:03 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:03 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:03 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:03 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:03 --> Controller Class Initialized
INFO - 2020-10-26 07:49:04 --> Config Class Initialized
INFO - 2020-10-26 07:49:04 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:04 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:04 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:04 --> URI Class Initialized
INFO - 2020-10-26 07:49:04 --> Router Class Initialized
INFO - 2020-10-26 07:49:04 --> Output Class Initialized
INFO - 2020-10-26 07:49:04 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:04 --> Input Class Initialized
INFO - 2020-10-26 07:49:04 --> Language Class Initialized
INFO - 2020-10-26 07:49:04 --> Language Class Initialized
INFO - 2020-10-26 07:49:04 --> Config Class Initialized
INFO - 2020-10-26 07:49:04 --> Loader Class Initialized
INFO - 2020-10-26 07:49:04 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:04 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:04 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:04 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:04 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 07:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:05 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:05 --> Total execution time: 0.3062
INFO - 2020-10-26 07:49:05 --> Config Class Initialized
INFO - 2020-10-26 07:49:05 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:05 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:05 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:05 --> URI Class Initialized
INFO - 2020-10-26 07:49:05 --> Router Class Initialized
INFO - 2020-10-26 07:49:05 --> Output Class Initialized
INFO - 2020-10-26 07:49:05 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:05 --> Input Class Initialized
INFO - 2020-10-26 07:49:05 --> Language Class Initialized
INFO - 2020-10-26 07:49:05 --> Language Class Initialized
INFO - 2020-10-26 07:49:05 --> Config Class Initialized
INFO - 2020-10-26 07:49:05 --> Loader Class Initialized
INFO - 2020-10-26 07:49:05 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:05 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:05 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:05 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:05 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:05 --> Controller Class Initialized
INFO - 2020-10-26 07:49:08 --> Config Class Initialized
INFO - 2020-10-26 07:49:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:08 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:08 --> URI Class Initialized
INFO - 2020-10-26 07:49:08 --> Router Class Initialized
INFO - 2020-10-26 07:49:08 --> Output Class Initialized
INFO - 2020-10-26 07:49:08 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:08 --> Input Class Initialized
INFO - 2020-10-26 07:49:08 --> Language Class Initialized
INFO - 2020-10-26 07:49:08 --> Language Class Initialized
INFO - 2020-10-26 07:49:08 --> Config Class Initialized
INFO - 2020-10-26 07:49:08 --> Loader Class Initialized
INFO - 2020-10-26 07:49:08 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:08 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:08 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:09 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:09 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:09 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 07:49:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:09 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:09 --> Total execution time: 0.3090
INFO - 2020-10-26 07:49:11 --> Config Class Initialized
INFO - 2020-10-26 07:49:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:11 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:11 --> URI Class Initialized
INFO - 2020-10-26 07:49:11 --> Router Class Initialized
INFO - 2020-10-26 07:49:11 --> Output Class Initialized
INFO - 2020-10-26 07:49:11 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:11 --> Input Class Initialized
INFO - 2020-10-26 07:49:11 --> Language Class Initialized
INFO - 2020-10-26 07:49:11 --> Language Class Initialized
INFO - 2020-10-26 07:49:11 --> Config Class Initialized
INFO - 2020-10-26 07:49:11 --> Loader Class Initialized
INFO - 2020-10-26 07:49:11 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:11 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:11 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:11 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:11 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:11 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 07:49:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:11 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:11 --> Total execution time: 0.3214
INFO - 2020-10-26 07:49:11 --> Config Class Initialized
INFO - 2020-10-26 07:49:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:11 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:11 --> URI Class Initialized
INFO - 2020-10-26 07:49:11 --> Router Class Initialized
INFO - 2020-10-26 07:49:11 --> Output Class Initialized
INFO - 2020-10-26 07:49:11 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:11 --> Input Class Initialized
INFO - 2020-10-26 07:49:11 --> Language Class Initialized
INFO - 2020-10-26 07:49:11 --> Language Class Initialized
INFO - 2020-10-26 07:49:11 --> Config Class Initialized
INFO - 2020-10-26 07:49:11 --> Loader Class Initialized
INFO - 2020-10-26 07:49:11 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:11 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:11 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:11 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:11 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:11 --> Controller Class Initialized
INFO - 2020-10-26 07:49:13 --> Config Class Initialized
INFO - 2020-10-26 07:49:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:13 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:13 --> URI Class Initialized
INFO - 2020-10-26 07:49:13 --> Router Class Initialized
INFO - 2020-10-26 07:49:13 --> Output Class Initialized
INFO - 2020-10-26 07:49:13 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:13 --> Input Class Initialized
INFO - 2020-10-26 07:49:13 --> Language Class Initialized
INFO - 2020-10-26 07:49:13 --> Language Class Initialized
INFO - 2020-10-26 07:49:13 --> Config Class Initialized
INFO - 2020-10-26 07:49:13 --> Loader Class Initialized
INFO - 2020-10-26 07:49:13 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:13 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:13 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:13 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:13 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:13 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-26 07:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:14 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:14 --> Total execution time: 0.3170
INFO - 2020-10-26 07:49:14 --> Config Class Initialized
INFO - 2020-10-26 07:49:14 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:14 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:14 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:14 --> URI Class Initialized
INFO - 2020-10-26 07:49:14 --> Router Class Initialized
INFO - 2020-10-26 07:49:14 --> Output Class Initialized
INFO - 2020-10-26 07:49:14 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:14 --> Input Class Initialized
INFO - 2020-10-26 07:49:14 --> Language Class Initialized
INFO - 2020-10-26 07:49:14 --> Language Class Initialized
INFO - 2020-10-26 07:49:14 --> Config Class Initialized
INFO - 2020-10-26 07:49:14 --> Loader Class Initialized
INFO - 2020-10-26 07:49:14 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:14 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:14 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:14 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:14 --> Controller Class Initialized
INFO - 2020-10-26 07:49:15 --> Config Class Initialized
INFO - 2020-10-26 07:49:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:15 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:15 --> URI Class Initialized
INFO - 2020-10-26 07:49:15 --> Router Class Initialized
INFO - 2020-10-26 07:49:15 --> Output Class Initialized
INFO - 2020-10-26 07:49:15 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:15 --> Input Class Initialized
INFO - 2020-10-26 07:49:15 --> Language Class Initialized
INFO - 2020-10-26 07:49:15 --> Language Class Initialized
INFO - 2020-10-26 07:49:15 --> Config Class Initialized
INFO - 2020-10-26 07:49:15 --> Loader Class Initialized
INFO - 2020-10-26 07:49:15 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:15 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:15 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:15 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:15 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 07:49:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:15 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:15 --> Total execution time: 0.3154
INFO - 2020-10-26 07:49:16 --> Config Class Initialized
INFO - 2020-10-26 07:49:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:16 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:16 --> URI Class Initialized
INFO - 2020-10-26 07:49:16 --> Router Class Initialized
INFO - 2020-10-26 07:49:16 --> Output Class Initialized
INFO - 2020-10-26 07:49:16 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:17 --> Input Class Initialized
INFO - 2020-10-26 07:49:17 --> Language Class Initialized
INFO - 2020-10-26 07:49:17 --> Language Class Initialized
INFO - 2020-10-26 07:49:17 --> Config Class Initialized
INFO - 2020-10-26 07:49:17 --> Loader Class Initialized
INFO - 2020-10-26 07:49:17 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:17 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:17 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:17 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:17 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 07:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:17 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:17 --> Total execution time: 0.2979
INFO - 2020-10-26 07:49:17 --> Config Class Initialized
INFO - 2020-10-26 07:49:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:17 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:17 --> URI Class Initialized
INFO - 2020-10-26 07:49:17 --> Router Class Initialized
INFO - 2020-10-26 07:49:17 --> Output Class Initialized
INFO - 2020-10-26 07:49:17 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:17 --> Input Class Initialized
INFO - 2020-10-26 07:49:17 --> Language Class Initialized
INFO - 2020-10-26 07:49:17 --> Language Class Initialized
INFO - 2020-10-26 07:49:17 --> Config Class Initialized
INFO - 2020-10-26 07:49:17 --> Loader Class Initialized
INFO - 2020-10-26 07:49:17 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:17 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:17 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:17 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:17 --> Controller Class Initialized
INFO - 2020-10-26 07:49:53 --> Config Class Initialized
INFO - 2020-10-26 07:49:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:53 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:53 --> URI Class Initialized
INFO - 2020-10-26 07:49:53 --> Router Class Initialized
INFO - 2020-10-26 07:49:53 --> Output Class Initialized
INFO - 2020-10-26 07:49:53 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:53 --> Input Class Initialized
INFO - 2020-10-26 07:49:53 --> Language Class Initialized
INFO - 2020-10-26 07:49:53 --> Language Class Initialized
INFO - 2020-10-26 07:49:53 --> Config Class Initialized
INFO - 2020-10-26 07:49:53 --> Loader Class Initialized
INFO - 2020-10-26 07:49:53 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:53 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:53 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:53 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:53 --> Controller Class Initialized
DEBUG - 2020-10-26 07:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 07:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:49:53 --> Final output sent to browser
DEBUG - 2020-10-26 07:49:53 --> Total execution time: 0.3207
INFO - 2020-10-26 07:49:53 --> Config Class Initialized
INFO - 2020-10-26 07:49:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:49:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:49:53 --> Utf8 Class Initialized
INFO - 2020-10-26 07:49:53 --> URI Class Initialized
INFO - 2020-10-26 07:49:53 --> Router Class Initialized
INFO - 2020-10-26 07:49:53 --> Output Class Initialized
INFO - 2020-10-26 07:49:53 --> Security Class Initialized
DEBUG - 2020-10-26 07:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:49:53 --> Input Class Initialized
INFO - 2020-10-26 07:49:53 --> Language Class Initialized
INFO - 2020-10-26 07:49:53 --> Language Class Initialized
INFO - 2020-10-26 07:49:53 --> Config Class Initialized
INFO - 2020-10-26 07:49:53 --> Loader Class Initialized
INFO - 2020-10-26 07:49:53 --> Helper loaded: url_helper
INFO - 2020-10-26 07:49:53 --> Helper loaded: file_helper
INFO - 2020-10-26 07:49:53 --> Helper loaded: form_helper
INFO - 2020-10-26 07:49:53 --> Helper loaded: my_helper
INFO - 2020-10-26 07:49:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:49:53 --> Controller Class Initialized
INFO - 2020-10-26 07:50:24 --> Config Class Initialized
INFO - 2020-10-26 07:50:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:50:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:50:24 --> Utf8 Class Initialized
INFO - 2020-10-26 07:50:24 --> URI Class Initialized
INFO - 2020-10-26 07:50:24 --> Router Class Initialized
INFO - 2020-10-26 07:50:24 --> Output Class Initialized
INFO - 2020-10-26 07:50:24 --> Security Class Initialized
DEBUG - 2020-10-26 07:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:50:24 --> Input Class Initialized
INFO - 2020-10-26 07:50:24 --> Language Class Initialized
INFO - 2020-10-26 07:50:24 --> Language Class Initialized
INFO - 2020-10-26 07:50:24 --> Config Class Initialized
INFO - 2020-10-26 07:50:24 --> Loader Class Initialized
INFO - 2020-10-26 07:50:24 --> Helper loaded: url_helper
INFO - 2020-10-26 07:50:24 --> Helper loaded: file_helper
INFO - 2020-10-26 07:50:24 --> Helper loaded: form_helper
INFO - 2020-10-26 07:50:24 --> Helper loaded: my_helper
INFO - 2020-10-26 07:50:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:50:24 --> Controller Class Initialized
INFO - 2020-10-26 07:50:24 --> Final output sent to browser
DEBUG - 2020-10-26 07:50:24 --> Total execution time: 0.2994
INFO - 2020-10-26 07:50:57 --> Config Class Initialized
INFO - 2020-10-26 07:50:57 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:50:57 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:50:57 --> Utf8 Class Initialized
INFO - 2020-10-26 07:50:57 --> URI Class Initialized
INFO - 2020-10-26 07:50:57 --> Router Class Initialized
INFO - 2020-10-26 07:50:57 --> Output Class Initialized
INFO - 2020-10-26 07:50:57 --> Security Class Initialized
DEBUG - 2020-10-26 07:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:50:57 --> Input Class Initialized
INFO - 2020-10-26 07:50:57 --> Language Class Initialized
INFO - 2020-10-26 07:50:57 --> Language Class Initialized
INFO - 2020-10-26 07:50:57 --> Config Class Initialized
INFO - 2020-10-26 07:50:57 --> Loader Class Initialized
INFO - 2020-10-26 07:50:57 --> Helper loaded: url_helper
INFO - 2020-10-26 07:50:57 --> Helper loaded: file_helper
INFO - 2020-10-26 07:50:57 --> Helper loaded: form_helper
INFO - 2020-10-26 07:50:57 --> Helper loaded: my_helper
INFO - 2020-10-26 07:50:57 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:50:57 --> Controller Class Initialized
INFO - 2020-10-26 07:50:57 --> Final output sent to browser
DEBUG - 2020-10-26 07:50:57 --> Total execution time: 0.3054
INFO - 2020-10-26 07:51:03 --> Config Class Initialized
INFO - 2020-10-26 07:51:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:51:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:51:03 --> Utf8 Class Initialized
INFO - 2020-10-26 07:51:03 --> URI Class Initialized
INFO - 2020-10-26 07:51:03 --> Router Class Initialized
INFO - 2020-10-26 07:51:03 --> Output Class Initialized
INFO - 2020-10-26 07:51:03 --> Security Class Initialized
DEBUG - 2020-10-26 07:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:51:03 --> Input Class Initialized
INFO - 2020-10-26 07:51:03 --> Language Class Initialized
INFO - 2020-10-26 07:51:03 --> Language Class Initialized
INFO - 2020-10-26 07:51:03 --> Config Class Initialized
INFO - 2020-10-26 07:51:03 --> Loader Class Initialized
INFO - 2020-10-26 07:51:04 --> Helper loaded: url_helper
INFO - 2020-10-26 07:51:04 --> Helper loaded: file_helper
INFO - 2020-10-26 07:51:04 --> Helper loaded: form_helper
INFO - 2020-10-26 07:51:04 --> Helper loaded: my_helper
INFO - 2020-10-26 07:51:04 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:51:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:51:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:51:04 --> Controller Class Initialized
INFO - 2020-10-26 07:51:04 --> Final output sent to browser
DEBUG - 2020-10-26 07:51:04 --> Total execution time: 0.2980
INFO - 2020-10-26 07:56:12 --> Config Class Initialized
INFO - 2020-10-26 07:56:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:12 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:12 --> URI Class Initialized
INFO - 2020-10-26 07:56:12 --> Router Class Initialized
INFO - 2020-10-26 07:56:12 --> Output Class Initialized
INFO - 2020-10-26 07:56:12 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:12 --> Input Class Initialized
INFO - 2020-10-26 07:56:12 --> Language Class Initialized
INFO - 2020-10-26 07:56:12 --> Language Class Initialized
INFO - 2020-10-26 07:56:12 --> Config Class Initialized
INFO - 2020-10-26 07:56:12 --> Loader Class Initialized
INFO - 2020-10-26 07:56:12 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:12 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:12 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:12 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:12 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:12 --> Controller Class Initialized
DEBUG - 2020-10-26 07:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 07:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:56:12 --> Final output sent to browser
DEBUG - 2020-10-26 07:56:12 --> Total execution time: 0.3202
INFO - 2020-10-26 07:56:12 --> Config Class Initialized
INFO - 2020-10-26 07:56:12 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:12 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:12 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:12 --> URI Class Initialized
INFO - 2020-10-26 07:56:12 --> Router Class Initialized
INFO - 2020-10-26 07:56:12 --> Output Class Initialized
INFO - 2020-10-26 07:56:12 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:12 --> Input Class Initialized
INFO - 2020-10-26 07:56:12 --> Language Class Initialized
INFO - 2020-10-26 07:56:12 --> Language Class Initialized
INFO - 2020-10-26 07:56:12 --> Config Class Initialized
INFO - 2020-10-26 07:56:12 --> Loader Class Initialized
INFO - 2020-10-26 07:56:12 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:12 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:12 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:12 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:12 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:12 --> Controller Class Initialized
INFO - 2020-10-26 07:56:13 --> Config Class Initialized
INFO - 2020-10-26 07:56:13 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:13 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:13 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:13 --> URI Class Initialized
INFO - 2020-10-26 07:56:13 --> Router Class Initialized
INFO - 2020-10-26 07:56:13 --> Output Class Initialized
INFO - 2020-10-26 07:56:13 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:13 --> Input Class Initialized
INFO - 2020-10-26 07:56:13 --> Language Class Initialized
INFO - 2020-10-26 07:56:13 --> Language Class Initialized
INFO - 2020-10-26 07:56:13 --> Config Class Initialized
INFO - 2020-10-26 07:56:13 --> Loader Class Initialized
INFO - 2020-10-26 07:56:13 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:14 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:14 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:14 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:14 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:14 --> Controller Class Initialized
DEBUG - 2020-10-26 07:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 07:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:56:14 --> Final output sent to browser
DEBUG - 2020-10-26 07:56:14 --> Total execution time: 0.3189
INFO - 2020-10-26 07:56:16 --> Config Class Initialized
INFO - 2020-10-26 07:56:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:16 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:16 --> URI Class Initialized
INFO - 2020-10-26 07:56:16 --> Router Class Initialized
INFO - 2020-10-26 07:56:16 --> Output Class Initialized
INFO - 2020-10-26 07:56:16 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:16 --> Input Class Initialized
INFO - 2020-10-26 07:56:16 --> Language Class Initialized
INFO - 2020-10-26 07:56:16 --> Language Class Initialized
INFO - 2020-10-26 07:56:16 --> Config Class Initialized
INFO - 2020-10-26 07:56:16 --> Loader Class Initialized
INFO - 2020-10-26 07:56:16 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:16 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:16 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:16 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:16 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:16 --> Controller Class Initialized
DEBUG - 2020-10-26 07:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 07:56:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:56:16 --> Final output sent to browser
DEBUG - 2020-10-26 07:56:16 --> Total execution time: 0.3310
INFO - 2020-10-26 07:56:16 --> Config Class Initialized
INFO - 2020-10-26 07:56:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:16 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:16 --> URI Class Initialized
INFO - 2020-10-26 07:56:16 --> Router Class Initialized
INFO - 2020-10-26 07:56:16 --> Output Class Initialized
INFO - 2020-10-26 07:56:16 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:16 --> Input Class Initialized
INFO - 2020-10-26 07:56:16 --> Language Class Initialized
INFO - 2020-10-26 07:56:17 --> Language Class Initialized
INFO - 2020-10-26 07:56:17 --> Config Class Initialized
INFO - 2020-10-26 07:56:17 --> Loader Class Initialized
INFO - 2020-10-26 07:56:17 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:17 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:17 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:17 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:17 --> Controller Class Initialized
INFO - 2020-10-26 07:56:19 --> Config Class Initialized
INFO - 2020-10-26 07:56:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:19 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:19 --> URI Class Initialized
INFO - 2020-10-26 07:56:19 --> Router Class Initialized
INFO - 2020-10-26 07:56:19 --> Output Class Initialized
INFO - 2020-10-26 07:56:19 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:19 --> Input Class Initialized
INFO - 2020-10-26 07:56:19 --> Language Class Initialized
INFO - 2020-10-26 07:56:19 --> Language Class Initialized
INFO - 2020-10-26 07:56:19 --> Config Class Initialized
INFO - 2020-10-26 07:56:19 --> Loader Class Initialized
INFO - 2020-10-26 07:56:19 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:19 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:19 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:19 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:19 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:19 --> Controller Class Initialized
DEBUG - 2020-10-26 07:56:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-26 07:56:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:56:19 --> Final output sent to browser
DEBUG - 2020-10-26 07:56:19 --> Total execution time: 0.3079
INFO - 2020-10-26 07:56:19 --> Config Class Initialized
INFO - 2020-10-26 07:56:19 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:19 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:19 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:19 --> URI Class Initialized
INFO - 2020-10-26 07:56:19 --> Router Class Initialized
INFO - 2020-10-26 07:56:19 --> Output Class Initialized
INFO - 2020-10-26 07:56:19 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:19 --> Input Class Initialized
INFO - 2020-10-26 07:56:19 --> Language Class Initialized
INFO - 2020-10-26 07:56:19 --> Language Class Initialized
INFO - 2020-10-26 07:56:19 --> Config Class Initialized
INFO - 2020-10-26 07:56:19 --> Loader Class Initialized
INFO - 2020-10-26 07:56:19 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:19 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:19 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:19 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:19 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:19 --> Controller Class Initialized
INFO - 2020-10-26 07:56:20 --> Config Class Initialized
INFO - 2020-10-26 07:56:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:20 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:20 --> URI Class Initialized
INFO - 2020-10-26 07:56:20 --> Router Class Initialized
INFO - 2020-10-26 07:56:20 --> Output Class Initialized
INFO - 2020-10-26 07:56:20 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:20 --> Input Class Initialized
INFO - 2020-10-26 07:56:20 --> Language Class Initialized
INFO - 2020-10-26 07:56:20 --> Language Class Initialized
INFO - 2020-10-26 07:56:20 --> Config Class Initialized
INFO - 2020-10-26 07:56:20 --> Loader Class Initialized
INFO - 2020-10-26 07:56:20 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:20 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:20 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:20 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:20 --> Controller Class Initialized
DEBUG - 2020-10-26 07:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 07:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:56:20 --> Final output sent to browser
DEBUG - 2020-10-26 07:56:20 --> Total execution time: 0.3171
INFO - 2020-10-26 07:56:20 --> Config Class Initialized
INFO - 2020-10-26 07:56:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:20 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:20 --> URI Class Initialized
INFO - 2020-10-26 07:56:20 --> Router Class Initialized
INFO - 2020-10-26 07:56:20 --> Output Class Initialized
INFO - 2020-10-26 07:56:20 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:20 --> Input Class Initialized
INFO - 2020-10-26 07:56:20 --> Language Class Initialized
INFO - 2020-10-26 07:56:20 --> Language Class Initialized
INFO - 2020-10-26 07:56:20 --> Config Class Initialized
INFO - 2020-10-26 07:56:20 --> Loader Class Initialized
INFO - 2020-10-26 07:56:20 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:20 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:20 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:20 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:20 --> Controller Class Initialized
INFO - 2020-10-26 07:56:22 --> Config Class Initialized
INFO - 2020-10-26 07:56:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 07:56:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 07:56:22 --> Utf8 Class Initialized
INFO - 2020-10-26 07:56:22 --> URI Class Initialized
INFO - 2020-10-26 07:56:23 --> Router Class Initialized
INFO - 2020-10-26 07:56:23 --> Output Class Initialized
INFO - 2020-10-26 07:56:23 --> Security Class Initialized
DEBUG - 2020-10-26 07:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 07:56:23 --> Input Class Initialized
INFO - 2020-10-26 07:56:23 --> Language Class Initialized
INFO - 2020-10-26 07:56:23 --> Language Class Initialized
INFO - 2020-10-26 07:56:23 --> Config Class Initialized
INFO - 2020-10-26 07:56:23 --> Loader Class Initialized
INFO - 2020-10-26 07:56:23 --> Helper loaded: url_helper
INFO - 2020-10-26 07:56:23 --> Helper loaded: file_helper
INFO - 2020-10-26 07:56:23 --> Helper loaded: form_helper
INFO - 2020-10-26 07:56:23 --> Helper loaded: my_helper
INFO - 2020-10-26 07:56:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 07:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 07:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 07:56:23 --> Controller Class Initialized
DEBUG - 2020-10-26 07:56:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 07:56:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 07:56:23 --> Final output sent to browser
DEBUG - 2020-10-26 07:56:23 --> Total execution time: 0.3146
INFO - 2020-10-26 08:02:15 --> Config Class Initialized
INFO - 2020-10-26 08:02:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:02:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:02:15 --> Utf8 Class Initialized
INFO - 2020-10-26 08:02:15 --> URI Class Initialized
INFO - 2020-10-26 08:02:15 --> Router Class Initialized
INFO - 2020-10-26 08:02:15 --> Output Class Initialized
INFO - 2020-10-26 08:02:15 --> Security Class Initialized
DEBUG - 2020-10-26 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:02:15 --> Input Class Initialized
INFO - 2020-10-26 08:02:15 --> Language Class Initialized
INFO - 2020-10-26 08:02:15 --> Language Class Initialized
INFO - 2020-10-26 08:02:15 --> Config Class Initialized
INFO - 2020-10-26 08:02:15 --> Loader Class Initialized
INFO - 2020-10-26 08:02:15 --> Helper loaded: url_helper
INFO - 2020-10-26 08:02:15 --> Helper loaded: file_helper
INFO - 2020-10-26 08:02:15 --> Helper loaded: form_helper
INFO - 2020-10-26 08:02:15 --> Helper loaded: my_helper
INFO - 2020-10-26 08:02:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:02:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:02:15 --> Controller Class Initialized
DEBUG - 2020-10-26 08:02:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 08:02:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:02:15 --> Final output sent to browser
DEBUG - 2020-10-26 08:02:15 --> Total execution time: 0.3294
INFO - 2020-10-26 08:02:15 --> Config Class Initialized
INFO - 2020-10-26 08:02:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:02:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:02:15 --> Utf8 Class Initialized
INFO - 2020-10-26 08:02:15 --> URI Class Initialized
INFO - 2020-10-26 08:02:15 --> Router Class Initialized
INFO - 2020-10-26 08:02:15 --> Output Class Initialized
INFO - 2020-10-26 08:02:15 --> Security Class Initialized
DEBUG - 2020-10-26 08:02:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:02:15 --> Input Class Initialized
INFO - 2020-10-26 08:02:15 --> Language Class Initialized
INFO - 2020-10-26 08:02:15 --> Language Class Initialized
INFO - 2020-10-26 08:02:15 --> Config Class Initialized
INFO - 2020-10-26 08:02:15 --> Loader Class Initialized
INFO - 2020-10-26 08:02:16 --> Helper loaded: url_helper
INFO - 2020-10-26 08:02:16 --> Helper loaded: file_helper
INFO - 2020-10-26 08:02:16 --> Helper loaded: form_helper
INFO - 2020-10-26 08:02:16 --> Helper loaded: my_helper
INFO - 2020-10-26 08:02:16 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:02:16 --> Controller Class Initialized
INFO - 2020-10-26 08:02:16 --> Config Class Initialized
INFO - 2020-10-26 08:02:16 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:02:16 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:02:16 --> Utf8 Class Initialized
INFO - 2020-10-26 08:02:16 --> URI Class Initialized
INFO - 2020-10-26 08:02:16 --> Router Class Initialized
INFO - 2020-10-26 08:02:16 --> Output Class Initialized
INFO - 2020-10-26 08:02:16 --> Security Class Initialized
DEBUG - 2020-10-26 08:02:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:02:16 --> Input Class Initialized
INFO - 2020-10-26 08:02:16 --> Language Class Initialized
INFO - 2020-10-26 08:02:16 --> Language Class Initialized
INFO - 2020-10-26 08:02:16 --> Config Class Initialized
INFO - 2020-10-26 08:02:16 --> Loader Class Initialized
INFO - 2020-10-26 08:02:16 --> Helper loaded: url_helper
INFO - 2020-10-26 08:02:16 --> Helper loaded: file_helper
INFO - 2020-10-26 08:02:16 --> Helper loaded: form_helper
INFO - 2020-10-26 08:02:16 --> Helper loaded: my_helper
INFO - 2020-10-26 08:02:16 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:02:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:02:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:02:16 --> Controller Class Initialized
INFO - 2020-10-26 08:02:16 --> Final output sent to browser
DEBUG - 2020-10-26 08:02:16 --> Total execution time: 0.3004
INFO - 2020-10-26 08:02:44 --> Config Class Initialized
INFO - 2020-10-26 08:02:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:02:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:02:44 --> Utf8 Class Initialized
INFO - 2020-10-26 08:02:44 --> URI Class Initialized
INFO - 2020-10-26 08:02:44 --> Router Class Initialized
INFO - 2020-10-26 08:02:44 --> Output Class Initialized
INFO - 2020-10-26 08:02:44 --> Security Class Initialized
DEBUG - 2020-10-26 08:02:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:02:44 --> Input Class Initialized
INFO - 2020-10-26 08:02:44 --> Language Class Initialized
INFO - 2020-10-26 08:02:45 --> Language Class Initialized
INFO - 2020-10-26 08:02:45 --> Config Class Initialized
INFO - 2020-10-26 08:02:45 --> Loader Class Initialized
INFO - 2020-10-26 08:02:45 --> Helper loaded: url_helper
INFO - 2020-10-26 08:02:45 --> Helper loaded: file_helper
INFO - 2020-10-26 08:02:45 --> Helper loaded: form_helper
INFO - 2020-10-26 08:02:45 --> Helper loaded: my_helper
INFO - 2020-10-26 08:02:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:02:45 --> Controller Class Initialized
DEBUG - 2020-10-26 08:02:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 08:02:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:02:45 --> Final output sent to browser
DEBUG - 2020-10-26 08:02:45 --> Total execution time: 0.3491
INFO - 2020-10-26 08:02:45 --> Config Class Initialized
INFO - 2020-10-26 08:02:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:02:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:02:45 --> Utf8 Class Initialized
INFO - 2020-10-26 08:02:45 --> URI Class Initialized
INFO - 2020-10-26 08:02:45 --> Router Class Initialized
INFO - 2020-10-26 08:02:45 --> Output Class Initialized
INFO - 2020-10-26 08:02:45 --> Security Class Initialized
DEBUG - 2020-10-26 08:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:02:45 --> Input Class Initialized
INFO - 2020-10-26 08:02:45 --> Language Class Initialized
INFO - 2020-10-26 08:02:45 --> Language Class Initialized
INFO - 2020-10-26 08:02:45 --> Config Class Initialized
INFO - 2020-10-26 08:02:45 --> Loader Class Initialized
INFO - 2020-10-26 08:02:45 --> Helper loaded: url_helper
INFO - 2020-10-26 08:02:45 --> Helper loaded: file_helper
INFO - 2020-10-26 08:02:45 --> Helper loaded: form_helper
INFO - 2020-10-26 08:02:45 --> Helper loaded: my_helper
INFO - 2020-10-26 08:02:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:02:45 --> Controller Class Initialized
INFO - 2020-10-26 08:02:46 --> Config Class Initialized
INFO - 2020-10-26 08:02:46 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:02:46 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:02:46 --> Utf8 Class Initialized
INFO - 2020-10-26 08:02:46 --> URI Class Initialized
INFO - 2020-10-26 08:02:46 --> Router Class Initialized
INFO - 2020-10-26 08:02:46 --> Output Class Initialized
INFO - 2020-10-26 08:02:46 --> Security Class Initialized
DEBUG - 2020-10-26 08:02:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:02:46 --> Input Class Initialized
INFO - 2020-10-26 08:02:46 --> Language Class Initialized
INFO - 2020-10-26 08:02:46 --> Language Class Initialized
INFO - 2020-10-26 08:02:46 --> Config Class Initialized
INFO - 2020-10-26 08:02:46 --> Loader Class Initialized
INFO - 2020-10-26 08:02:46 --> Helper loaded: url_helper
INFO - 2020-10-26 08:02:46 --> Helper loaded: file_helper
INFO - 2020-10-26 08:02:46 --> Helper loaded: form_helper
INFO - 2020-10-26 08:02:46 --> Helper loaded: my_helper
INFO - 2020-10-26 08:02:46 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:02:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:02:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:02:46 --> Controller Class Initialized
INFO - 2020-10-26 08:02:46 --> Final output sent to browser
DEBUG - 2020-10-26 08:02:46 --> Total execution time: 0.3014
INFO - 2020-10-26 08:05:53 --> Config Class Initialized
INFO - 2020-10-26 08:05:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:05:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:05:53 --> Utf8 Class Initialized
INFO - 2020-10-26 08:05:53 --> URI Class Initialized
INFO - 2020-10-26 08:05:53 --> Router Class Initialized
INFO - 2020-10-26 08:05:53 --> Output Class Initialized
INFO - 2020-10-26 08:05:53 --> Security Class Initialized
DEBUG - 2020-10-26 08:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:05:54 --> Input Class Initialized
INFO - 2020-10-26 08:05:54 --> Language Class Initialized
INFO - 2020-10-26 08:05:54 --> Language Class Initialized
INFO - 2020-10-26 08:05:54 --> Config Class Initialized
INFO - 2020-10-26 08:05:54 --> Loader Class Initialized
INFO - 2020-10-26 08:05:54 --> Helper loaded: url_helper
INFO - 2020-10-26 08:05:54 --> Helper loaded: file_helper
INFO - 2020-10-26 08:05:54 --> Helper loaded: form_helper
INFO - 2020-10-26 08:05:54 --> Helper loaded: my_helper
INFO - 2020-10-26 08:05:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:05:54 --> Controller Class Initialized
DEBUG - 2020-10-26 08:05:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 08:05:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:05:54 --> Final output sent to browser
DEBUG - 2020-10-26 08:05:54 --> Total execution time: 0.3351
INFO - 2020-10-26 08:05:54 --> Config Class Initialized
INFO - 2020-10-26 08:05:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:05:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:05:54 --> Utf8 Class Initialized
INFO - 2020-10-26 08:05:54 --> URI Class Initialized
INFO - 2020-10-26 08:05:54 --> Router Class Initialized
INFO - 2020-10-26 08:05:54 --> Output Class Initialized
INFO - 2020-10-26 08:05:54 --> Security Class Initialized
DEBUG - 2020-10-26 08:05:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:05:54 --> Input Class Initialized
INFO - 2020-10-26 08:05:54 --> Language Class Initialized
INFO - 2020-10-26 08:05:54 --> Language Class Initialized
INFO - 2020-10-26 08:05:54 --> Config Class Initialized
INFO - 2020-10-26 08:05:54 --> Loader Class Initialized
INFO - 2020-10-26 08:05:54 --> Helper loaded: url_helper
INFO - 2020-10-26 08:05:54 --> Helper loaded: file_helper
INFO - 2020-10-26 08:05:54 --> Helper loaded: form_helper
INFO - 2020-10-26 08:05:54 --> Helper loaded: my_helper
INFO - 2020-10-26 08:05:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:05:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:05:54 --> Controller Class Initialized
INFO - 2020-10-26 08:05:55 --> Config Class Initialized
INFO - 2020-10-26 08:05:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:05:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:05:55 --> Utf8 Class Initialized
INFO - 2020-10-26 08:05:55 --> URI Class Initialized
INFO - 2020-10-26 08:05:55 --> Router Class Initialized
INFO - 2020-10-26 08:05:55 --> Output Class Initialized
INFO - 2020-10-26 08:05:55 --> Security Class Initialized
DEBUG - 2020-10-26 08:05:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:05:55 --> Input Class Initialized
INFO - 2020-10-26 08:05:55 --> Language Class Initialized
INFO - 2020-10-26 08:05:55 --> Language Class Initialized
INFO - 2020-10-26 08:05:55 --> Config Class Initialized
INFO - 2020-10-26 08:05:55 --> Loader Class Initialized
INFO - 2020-10-26 08:05:55 --> Helper loaded: url_helper
INFO - 2020-10-26 08:05:55 --> Helper loaded: file_helper
INFO - 2020-10-26 08:05:55 --> Helper loaded: form_helper
INFO - 2020-10-26 08:05:55 --> Helper loaded: my_helper
INFO - 2020-10-26 08:05:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:05:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:05:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:05:55 --> Controller Class Initialized
INFO - 2020-10-26 08:05:55 --> Final output sent to browser
DEBUG - 2020-10-26 08:05:55 --> Total execution time: 0.2863
INFO - 2020-10-26 08:06:15 --> Config Class Initialized
INFO - 2020-10-26 08:06:15 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:15 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:15 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:15 --> URI Class Initialized
INFO - 2020-10-26 08:06:15 --> Router Class Initialized
INFO - 2020-10-26 08:06:15 --> Output Class Initialized
INFO - 2020-10-26 08:06:15 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:15 --> Input Class Initialized
INFO - 2020-10-26 08:06:15 --> Language Class Initialized
INFO - 2020-10-26 08:06:15 --> Language Class Initialized
INFO - 2020-10-26 08:06:15 --> Config Class Initialized
INFO - 2020-10-26 08:06:15 --> Loader Class Initialized
INFO - 2020-10-26 08:06:15 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:15 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:15 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:15 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:15 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:15 --> Controller Class Initialized
ERROR - 2020-10-26 08:06:15 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-26 08:06:15 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-26 08:06:15 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:15 --> Total execution time: 0.3672
INFO - 2020-10-26 08:06:17 --> Config Class Initialized
INFO - 2020-10-26 08:06:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:17 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:17 --> URI Class Initialized
INFO - 2020-10-26 08:06:17 --> Router Class Initialized
INFO - 2020-10-26 08:06:17 --> Output Class Initialized
INFO - 2020-10-26 08:06:17 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:17 --> Input Class Initialized
INFO - 2020-10-26 08:06:17 --> Language Class Initialized
INFO - 2020-10-26 08:06:17 --> Language Class Initialized
INFO - 2020-10-26 08:06:17 --> Config Class Initialized
INFO - 2020-10-26 08:06:17 --> Loader Class Initialized
INFO - 2020-10-26 08:06:17 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:17 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:17 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:17 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:17 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 08:06:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:17 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:17 --> Total execution time: 0.3211
INFO - 2020-10-26 08:06:17 --> Config Class Initialized
INFO - 2020-10-26 08:06:17 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:17 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:17 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:17 --> URI Class Initialized
INFO - 2020-10-26 08:06:17 --> Router Class Initialized
INFO - 2020-10-26 08:06:17 --> Output Class Initialized
INFO - 2020-10-26 08:06:17 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:17 --> Input Class Initialized
INFO - 2020-10-26 08:06:17 --> Language Class Initialized
INFO - 2020-10-26 08:06:17 --> Language Class Initialized
INFO - 2020-10-26 08:06:17 --> Config Class Initialized
INFO - 2020-10-26 08:06:17 --> Loader Class Initialized
INFO - 2020-10-26 08:06:17 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:17 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:17 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:17 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:17 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:17 --> Controller Class Initialized
INFO - 2020-10-26 08:06:26 --> Config Class Initialized
INFO - 2020-10-26 08:06:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:26 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:26 --> URI Class Initialized
INFO - 2020-10-26 08:06:26 --> Router Class Initialized
INFO - 2020-10-26 08:06:26 --> Output Class Initialized
INFO - 2020-10-26 08:06:26 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:26 --> Input Class Initialized
INFO - 2020-10-26 08:06:26 --> Language Class Initialized
INFO - 2020-10-26 08:06:26 --> Language Class Initialized
INFO - 2020-10-26 08:06:26 --> Config Class Initialized
INFO - 2020-10-26 08:06:26 --> Loader Class Initialized
INFO - 2020-10-26 08:06:26 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:26 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:26 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:26 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:26 --> Controller Class Initialized
INFO - 2020-10-26 08:06:28 --> Config Class Initialized
INFO - 2020-10-26 08:06:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:28 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:28 --> URI Class Initialized
INFO - 2020-10-26 08:06:28 --> Router Class Initialized
INFO - 2020-10-26 08:06:28 --> Output Class Initialized
INFO - 2020-10-26 08:06:28 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:28 --> Input Class Initialized
INFO - 2020-10-26 08:06:28 --> Language Class Initialized
INFO - 2020-10-26 08:06:28 --> Language Class Initialized
INFO - 2020-10-26 08:06:28 --> Config Class Initialized
INFO - 2020-10-26 08:06:28 --> Loader Class Initialized
INFO - 2020-10-26 08:06:28 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:28 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:28 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:28 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:28 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:28 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 08:06:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:28 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:28 --> Total execution time: 0.3326
INFO - 2020-10-26 08:06:28 --> Config Class Initialized
INFO - 2020-10-26 08:06:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:28 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:28 --> URI Class Initialized
INFO - 2020-10-26 08:06:28 --> Router Class Initialized
INFO - 2020-10-26 08:06:28 --> Output Class Initialized
INFO - 2020-10-26 08:06:28 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:28 --> Input Class Initialized
INFO - 2020-10-26 08:06:28 --> Language Class Initialized
INFO - 2020-10-26 08:06:28 --> Language Class Initialized
INFO - 2020-10-26 08:06:28 --> Config Class Initialized
INFO - 2020-10-26 08:06:28 --> Loader Class Initialized
INFO - 2020-10-26 08:06:29 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:29 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:29 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:29 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:29 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:29 --> Controller Class Initialized
INFO - 2020-10-26 08:06:30 --> Config Class Initialized
INFO - 2020-10-26 08:06:30 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:30 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:30 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:30 --> URI Class Initialized
INFO - 2020-10-26 08:06:30 --> Router Class Initialized
INFO - 2020-10-26 08:06:30 --> Output Class Initialized
INFO - 2020-10-26 08:06:30 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:30 --> Input Class Initialized
INFO - 2020-10-26 08:06:30 --> Language Class Initialized
INFO - 2020-10-26 08:06:30 --> Language Class Initialized
INFO - 2020-10-26 08:06:30 --> Config Class Initialized
INFO - 2020-10-26 08:06:30 --> Loader Class Initialized
INFO - 2020-10-26 08:06:30 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:30 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:30 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:30 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:30 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:30 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:06:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:30 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:30 --> Total execution time: 0.3319
INFO - 2020-10-26 08:06:31 --> Config Class Initialized
INFO - 2020-10-26 08:06:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:31 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:31 --> URI Class Initialized
INFO - 2020-10-26 08:06:31 --> Router Class Initialized
INFO - 2020-10-26 08:06:31 --> Output Class Initialized
INFO - 2020-10-26 08:06:31 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:31 --> Input Class Initialized
INFO - 2020-10-26 08:06:31 --> Language Class Initialized
INFO - 2020-10-26 08:06:31 --> Language Class Initialized
INFO - 2020-10-26 08:06:31 --> Config Class Initialized
INFO - 2020-10-26 08:06:31 --> Loader Class Initialized
INFO - 2020-10-26 08:06:31 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:31 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:31 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:31 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:31 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:31 --> Controller Class Initialized
INFO - 2020-10-26 08:06:35 --> Config Class Initialized
INFO - 2020-10-26 08:06:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:35 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:35 --> URI Class Initialized
INFO - 2020-10-26 08:06:35 --> Router Class Initialized
INFO - 2020-10-26 08:06:35 --> Output Class Initialized
INFO - 2020-10-26 08:06:35 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:35 --> Input Class Initialized
INFO - 2020-10-26 08:06:35 --> Language Class Initialized
INFO - 2020-10-26 08:06:35 --> Language Class Initialized
INFO - 2020-10-26 08:06:35 --> Config Class Initialized
INFO - 2020-10-26 08:06:35 --> Loader Class Initialized
INFO - 2020-10-26 08:06:35 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:35 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:35 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:35 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:35 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-26 08:06:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:35 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:35 --> Total execution time: 0.3249
INFO - 2020-10-26 08:06:35 --> Config Class Initialized
INFO - 2020-10-26 08:06:35 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:35 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:35 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:35 --> URI Class Initialized
INFO - 2020-10-26 08:06:35 --> Router Class Initialized
INFO - 2020-10-26 08:06:35 --> Output Class Initialized
INFO - 2020-10-26 08:06:35 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:35 --> Input Class Initialized
INFO - 2020-10-26 08:06:35 --> Language Class Initialized
INFO - 2020-10-26 08:06:35 --> Language Class Initialized
INFO - 2020-10-26 08:06:35 --> Config Class Initialized
INFO - 2020-10-26 08:06:35 --> Loader Class Initialized
INFO - 2020-10-26 08:06:35 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:35 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:35 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:35 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:35 --> Controller Class Initialized
INFO - 2020-10-26 08:06:39 --> Config Class Initialized
INFO - 2020-10-26 08:06:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:39 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:39 --> URI Class Initialized
INFO - 2020-10-26 08:06:39 --> Router Class Initialized
INFO - 2020-10-26 08:06:39 --> Output Class Initialized
INFO - 2020-10-26 08:06:39 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:39 --> Input Class Initialized
INFO - 2020-10-26 08:06:39 --> Language Class Initialized
INFO - 2020-10-26 08:06:39 --> Language Class Initialized
INFO - 2020-10-26 08:06:39 --> Config Class Initialized
INFO - 2020-10-26 08:06:39 --> Loader Class Initialized
INFO - 2020-10-26 08:06:39 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:39 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:39 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:39 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:39 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:39 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 08:06:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:39 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:39 --> Total execution time: 0.3253
INFO - 2020-10-26 08:06:39 --> Config Class Initialized
INFO - 2020-10-26 08:06:39 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:39 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:39 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:39 --> URI Class Initialized
INFO - 2020-10-26 08:06:39 --> Router Class Initialized
INFO - 2020-10-26 08:06:39 --> Output Class Initialized
INFO - 2020-10-26 08:06:39 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:39 --> Input Class Initialized
INFO - 2020-10-26 08:06:39 --> Language Class Initialized
INFO - 2020-10-26 08:06:39 --> Language Class Initialized
INFO - 2020-10-26 08:06:39 --> Config Class Initialized
INFO - 2020-10-26 08:06:39 --> Loader Class Initialized
INFO - 2020-10-26 08:06:39 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:40 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:40 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:40 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:40 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:40 --> Controller Class Initialized
INFO - 2020-10-26 08:06:45 --> Config Class Initialized
INFO - 2020-10-26 08:06:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:45 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:45 --> URI Class Initialized
INFO - 2020-10-26 08:06:45 --> Router Class Initialized
INFO - 2020-10-26 08:06:45 --> Output Class Initialized
INFO - 2020-10-26 08:06:45 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:45 --> Input Class Initialized
INFO - 2020-10-26 08:06:45 --> Language Class Initialized
INFO - 2020-10-26 08:06:45 --> Language Class Initialized
INFO - 2020-10-26 08:06:45 --> Config Class Initialized
INFO - 2020-10-26 08:06:45 --> Loader Class Initialized
INFO - 2020-10-26 08:06:45 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:45 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:45 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:45 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:45 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-10-26 08:06:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:45 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:45 --> Total execution time: 0.3333
INFO - 2020-10-26 08:06:48 --> Config Class Initialized
INFO - 2020-10-26 08:06:48 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:48 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:48 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:48 --> URI Class Initialized
INFO - 2020-10-26 08:06:48 --> Router Class Initialized
INFO - 2020-10-26 08:06:48 --> Output Class Initialized
INFO - 2020-10-26 08:06:48 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:48 --> Input Class Initialized
INFO - 2020-10-26 08:06:48 --> Language Class Initialized
INFO - 2020-10-26 08:06:48 --> Language Class Initialized
INFO - 2020-10-26 08:06:48 --> Config Class Initialized
INFO - 2020-10-26 08:06:48 --> Loader Class Initialized
INFO - 2020-10-26 08:06:48 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:48 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:48 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:48 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:48 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:48 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-26 08:06:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:48 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:48 --> Total execution time: 0.3427
INFO - 2020-10-26 08:06:49 --> Config Class Initialized
INFO - 2020-10-26 08:06:49 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:49 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:49 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:49 --> URI Class Initialized
INFO - 2020-10-26 08:06:49 --> Router Class Initialized
INFO - 2020-10-26 08:06:49 --> Output Class Initialized
INFO - 2020-10-26 08:06:49 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:49 --> Input Class Initialized
INFO - 2020-10-26 08:06:49 --> Language Class Initialized
INFO - 2020-10-26 08:06:49 --> Language Class Initialized
INFO - 2020-10-26 08:06:49 --> Config Class Initialized
INFO - 2020-10-26 08:06:49 --> Loader Class Initialized
INFO - 2020-10-26 08:06:49 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:49 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:49 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:49 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:49 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:49 --> Controller Class Initialized
INFO - 2020-10-26 08:06:53 --> Config Class Initialized
INFO - 2020-10-26 08:06:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:53 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:53 --> URI Class Initialized
INFO - 2020-10-26 08:06:53 --> Router Class Initialized
INFO - 2020-10-26 08:06:53 --> Output Class Initialized
INFO - 2020-10-26 08:06:53 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:53 --> Input Class Initialized
INFO - 2020-10-26 08:06:53 --> Language Class Initialized
INFO - 2020-10-26 08:06:53 --> Language Class Initialized
INFO - 2020-10-26 08:06:53 --> Config Class Initialized
INFO - 2020-10-26 08:06:53 --> Loader Class Initialized
INFO - 2020-10-26 08:06:53 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:53 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:53 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:53 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:53 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:53 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 08:06:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:53 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:53 --> Total execution time: 0.3187
INFO - 2020-10-26 08:06:53 --> Config Class Initialized
INFO - 2020-10-26 08:06:53 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:53 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:53 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:53 --> URI Class Initialized
INFO - 2020-10-26 08:06:53 --> Router Class Initialized
INFO - 2020-10-26 08:06:53 --> Output Class Initialized
INFO - 2020-10-26 08:06:53 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:53 --> Input Class Initialized
INFO - 2020-10-26 08:06:53 --> Language Class Initialized
INFO - 2020-10-26 08:06:54 --> Language Class Initialized
INFO - 2020-10-26 08:06:54 --> Config Class Initialized
INFO - 2020-10-26 08:06:54 --> Loader Class Initialized
INFO - 2020-10-26 08:06:54 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:54 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:54 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:54 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:54 --> Controller Class Initialized
INFO - 2020-10-26 08:06:55 --> Config Class Initialized
INFO - 2020-10-26 08:06:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:55 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:55 --> URI Class Initialized
INFO - 2020-10-26 08:06:55 --> Router Class Initialized
INFO - 2020-10-26 08:06:55 --> Output Class Initialized
INFO - 2020-10-26 08:06:55 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:55 --> Input Class Initialized
INFO - 2020-10-26 08:06:55 --> Language Class Initialized
INFO - 2020-10-26 08:06:55 --> Language Class Initialized
INFO - 2020-10-26 08:06:55 --> Config Class Initialized
INFO - 2020-10-26 08:06:55 --> Loader Class Initialized
INFO - 2020-10-26 08:06:55 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:55 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:55 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:55 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:55 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-26 08:06:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:55 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:55 --> Total execution time: 0.3189
INFO - 2020-10-26 08:06:55 --> Config Class Initialized
INFO - 2020-10-26 08:06:55 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:55 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:55 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:55 --> URI Class Initialized
INFO - 2020-10-26 08:06:55 --> Router Class Initialized
INFO - 2020-10-26 08:06:55 --> Output Class Initialized
INFO - 2020-10-26 08:06:55 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:55 --> Input Class Initialized
INFO - 2020-10-26 08:06:55 --> Language Class Initialized
INFO - 2020-10-26 08:06:55 --> Language Class Initialized
INFO - 2020-10-26 08:06:55 --> Config Class Initialized
INFO - 2020-10-26 08:06:55 --> Loader Class Initialized
INFO - 2020-10-26 08:06:55 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:55 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:55 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:55 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:55 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:55 --> Controller Class Initialized
INFO - 2020-10-26 08:06:58 --> Config Class Initialized
INFO - 2020-10-26 08:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:58 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:58 --> URI Class Initialized
INFO - 2020-10-26 08:06:58 --> Router Class Initialized
INFO - 2020-10-26 08:06:58 --> Output Class Initialized
INFO - 2020-10-26 08:06:58 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:58 --> Input Class Initialized
INFO - 2020-10-26 08:06:58 --> Language Class Initialized
INFO - 2020-10-26 08:06:58 --> Language Class Initialized
INFO - 2020-10-26 08:06:58 --> Config Class Initialized
INFO - 2020-10-26 08:06:58 --> Loader Class Initialized
INFO - 2020-10-26 08:06:58 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:58 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:58 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:58 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:58 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:58 --> Controller Class Initialized
DEBUG - 2020-10-26 08:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-26 08:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:06:58 --> Final output sent to browser
DEBUG - 2020-10-26 08:06:58 --> Total execution time: 0.3330
INFO - 2020-10-26 08:06:58 --> Config Class Initialized
INFO - 2020-10-26 08:06:58 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:06:58 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:06:58 --> Utf8 Class Initialized
INFO - 2020-10-26 08:06:58 --> URI Class Initialized
INFO - 2020-10-26 08:06:58 --> Router Class Initialized
INFO - 2020-10-26 08:06:58 --> Output Class Initialized
INFO - 2020-10-26 08:06:58 --> Security Class Initialized
DEBUG - 2020-10-26 08:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:06:58 --> Input Class Initialized
INFO - 2020-10-26 08:06:58 --> Language Class Initialized
INFO - 2020-10-26 08:06:58 --> Language Class Initialized
INFO - 2020-10-26 08:06:58 --> Config Class Initialized
INFO - 2020-10-26 08:06:58 --> Loader Class Initialized
INFO - 2020-10-26 08:06:58 --> Helper loaded: url_helper
INFO - 2020-10-26 08:06:58 --> Helper loaded: file_helper
INFO - 2020-10-26 08:06:58 --> Helper loaded: form_helper
INFO - 2020-10-26 08:06:58 --> Helper loaded: my_helper
INFO - 2020-10-26 08:06:58 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:06:58 --> Controller Class Initialized
INFO - 2020-10-26 08:07:00 --> Config Class Initialized
INFO - 2020-10-26 08:07:00 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:07:00 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:07:00 --> Utf8 Class Initialized
INFO - 2020-10-26 08:07:00 --> URI Class Initialized
INFO - 2020-10-26 08:07:00 --> Router Class Initialized
INFO - 2020-10-26 08:07:00 --> Output Class Initialized
INFO - 2020-10-26 08:07:00 --> Security Class Initialized
DEBUG - 2020-10-26 08:07:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:07:00 --> Input Class Initialized
INFO - 2020-10-26 08:07:00 --> Language Class Initialized
INFO - 2020-10-26 08:07:00 --> Language Class Initialized
INFO - 2020-10-26 08:07:00 --> Config Class Initialized
INFO - 2020-10-26 08:07:00 --> Loader Class Initialized
INFO - 2020-10-26 08:07:00 --> Helper loaded: url_helper
INFO - 2020-10-26 08:07:00 --> Helper loaded: file_helper
INFO - 2020-10-26 08:07:00 --> Helper loaded: form_helper
INFO - 2020-10-26 08:07:01 --> Helper loaded: my_helper
INFO - 2020-10-26 08:07:01 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:07:01 --> Controller Class Initialized
DEBUG - 2020-10-26 08:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:07:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:07:01 --> Final output sent to browser
DEBUG - 2020-10-26 08:07:01 --> Total execution time: 0.3362
INFO - 2020-10-26 08:07:01 --> Config Class Initialized
INFO - 2020-10-26 08:07:01 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:07:01 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:07:01 --> Utf8 Class Initialized
INFO - 2020-10-26 08:07:01 --> URI Class Initialized
INFO - 2020-10-26 08:07:01 --> Router Class Initialized
INFO - 2020-10-26 08:07:01 --> Output Class Initialized
INFO - 2020-10-26 08:07:01 --> Security Class Initialized
DEBUG - 2020-10-26 08:07:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:07:01 --> Input Class Initialized
INFO - 2020-10-26 08:07:01 --> Language Class Initialized
INFO - 2020-10-26 08:07:01 --> Language Class Initialized
INFO - 2020-10-26 08:07:01 --> Config Class Initialized
INFO - 2020-10-26 08:07:01 --> Loader Class Initialized
INFO - 2020-10-26 08:07:01 --> Helper loaded: url_helper
INFO - 2020-10-26 08:07:01 --> Helper loaded: file_helper
INFO - 2020-10-26 08:07:01 --> Helper loaded: form_helper
INFO - 2020-10-26 08:07:01 --> Helper loaded: my_helper
INFO - 2020-10-26 08:07:01 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:07:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:07:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:07:01 --> Controller Class Initialized
INFO - 2020-10-26 08:07:06 --> Config Class Initialized
INFO - 2020-10-26 08:07:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:07:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:07:06 --> Utf8 Class Initialized
INFO - 2020-10-26 08:07:06 --> URI Class Initialized
INFO - 2020-10-26 08:07:06 --> Router Class Initialized
INFO - 2020-10-26 08:07:06 --> Output Class Initialized
INFO - 2020-10-26 08:07:06 --> Security Class Initialized
DEBUG - 2020-10-26 08:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:07:06 --> Input Class Initialized
INFO - 2020-10-26 08:07:06 --> Language Class Initialized
INFO - 2020-10-26 08:07:06 --> Language Class Initialized
INFO - 2020-10-26 08:07:06 --> Config Class Initialized
INFO - 2020-10-26 08:07:06 --> Loader Class Initialized
INFO - 2020-10-26 08:07:06 --> Helper loaded: url_helper
INFO - 2020-10-26 08:07:06 --> Helper loaded: file_helper
INFO - 2020-10-26 08:07:06 --> Helper loaded: form_helper
INFO - 2020-10-26 08:07:06 --> Helper loaded: my_helper
INFO - 2020-10-26 08:07:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:07:06 --> Controller Class Initialized
DEBUG - 2020-10-26 08:07:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 08:07:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:07:06 --> Final output sent to browser
DEBUG - 2020-10-26 08:07:07 --> Total execution time: 0.3511
INFO - 2020-10-26 08:07:07 --> Config Class Initialized
INFO - 2020-10-26 08:07:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:07:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:07:07 --> Utf8 Class Initialized
INFO - 2020-10-26 08:07:07 --> URI Class Initialized
INFO - 2020-10-26 08:07:07 --> Router Class Initialized
INFO - 2020-10-26 08:07:07 --> Output Class Initialized
INFO - 2020-10-26 08:07:07 --> Security Class Initialized
DEBUG - 2020-10-26 08:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:07:07 --> Input Class Initialized
INFO - 2020-10-26 08:07:07 --> Language Class Initialized
INFO - 2020-10-26 08:07:07 --> Language Class Initialized
INFO - 2020-10-26 08:07:07 --> Config Class Initialized
INFO - 2020-10-26 08:07:07 --> Loader Class Initialized
INFO - 2020-10-26 08:07:07 --> Helper loaded: url_helper
INFO - 2020-10-26 08:07:07 --> Helper loaded: file_helper
INFO - 2020-10-26 08:07:07 --> Helper loaded: form_helper
INFO - 2020-10-26 08:07:07 --> Helper loaded: my_helper
INFO - 2020-10-26 08:07:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:07:07 --> Controller Class Initialized
INFO - 2020-10-26 08:07:11 --> Config Class Initialized
INFO - 2020-10-26 08:07:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:07:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:07:11 --> Utf8 Class Initialized
INFO - 2020-10-26 08:07:11 --> URI Class Initialized
INFO - 2020-10-26 08:07:11 --> Router Class Initialized
INFO - 2020-10-26 08:07:11 --> Output Class Initialized
INFO - 2020-10-26 08:07:11 --> Security Class Initialized
DEBUG - 2020-10-26 08:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:07:11 --> Input Class Initialized
INFO - 2020-10-26 08:07:11 --> Language Class Initialized
INFO - 2020-10-26 08:07:11 --> Language Class Initialized
INFO - 2020-10-26 08:07:11 --> Config Class Initialized
INFO - 2020-10-26 08:07:11 --> Loader Class Initialized
INFO - 2020-10-26 08:07:11 --> Helper loaded: url_helper
INFO - 2020-10-26 08:07:11 --> Helper loaded: file_helper
INFO - 2020-10-26 08:07:11 --> Helper loaded: form_helper
INFO - 2020-10-26 08:07:11 --> Helper loaded: my_helper
INFO - 2020-10-26 08:07:11 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:07:11 --> Controller Class Initialized
DEBUG - 2020-10-26 08:07:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:07:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:07:11 --> Final output sent to browser
DEBUG - 2020-10-26 08:07:11 --> Total execution time: 0.3523
INFO - 2020-10-26 08:07:11 --> Config Class Initialized
INFO - 2020-10-26 08:07:11 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:07:11 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:07:11 --> Utf8 Class Initialized
INFO - 2020-10-26 08:07:11 --> URI Class Initialized
INFO - 2020-10-26 08:07:11 --> Router Class Initialized
INFO - 2020-10-26 08:07:11 --> Output Class Initialized
INFO - 2020-10-26 08:07:11 --> Security Class Initialized
DEBUG - 2020-10-26 08:07:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:07:11 --> Input Class Initialized
INFO - 2020-10-26 08:07:11 --> Language Class Initialized
INFO - 2020-10-26 08:07:11 --> Language Class Initialized
INFO - 2020-10-26 08:07:11 --> Config Class Initialized
INFO - 2020-10-26 08:07:11 --> Loader Class Initialized
INFO - 2020-10-26 08:07:11 --> Helper loaded: url_helper
INFO - 2020-10-26 08:07:11 --> Helper loaded: file_helper
INFO - 2020-10-26 08:07:11 --> Helper loaded: form_helper
INFO - 2020-10-26 08:07:11 --> Helper loaded: my_helper
INFO - 2020-10-26 08:07:11 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:07:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:07:11 --> Controller Class Initialized
INFO - 2020-10-26 08:07:36 --> Config Class Initialized
INFO - 2020-10-26 08:07:36 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:07:36 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:07:36 --> Utf8 Class Initialized
INFO - 2020-10-26 08:07:36 --> URI Class Initialized
INFO - 2020-10-26 08:07:36 --> Router Class Initialized
INFO - 2020-10-26 08:07:36 --> Output Class Initialized
INFO - 2020-10-26 08:07:36 --> Security Class Initialized
DEBUG - 2020-10-26 08:07:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:07:36 --> Input Class Initialized
INFO - 2020-10-26 08:07:36 --> Language Class Initialized
INFO - 2020-10-26 08:07:36 --> Language Class Initialized
INFO - 2020-10-26 08:07:36 --> Config Class Initialized
INFO - 2020-10-26 08:07:36 --> Loader Class Initialized
INFO - 2020-10-26 08:07:36 --> Helper loaded: url_helper
INFO - 2020-10-26 08:07:36 --> Helper loaded: file_helper
INFO - 2020-10-26 08:07:36 --> Helper loaded: form_helper
INFO - 2020-10-26 08:07:36 --> Helper loaded: my_helper
INFO - 2020-10-26 08:07:36 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:07:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:07:36 --> Controller Class Initialized
INFO - 2020-10-26 08:07:36 --> Final output sent to browser
DEBUG - 2020-10-26 08:07:36 --> Total execution time: 0.3126
INFO - 2020-10-26 08:08:02 --> Config Class Initialized
INFO - 2020-10-26 08:08:02 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:02 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:02 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:02 --> URI Class Initialized
INFO - 2020-10-26 08:08:02 --> Router Class Initialized
INFO - 2020-10-26 08:08:02 --> Output Class Initialized
INFO - 2020-10-26 08:08:02 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:02 --> Input Class Initialized
INFO - 2020-10-26 08:08:02 --> Language Class Initialized
INFO - 2020-10-26 08:08:02 --> Language Class Initialized
INFO - 2020-10-26 08:08:02 --> Config Class Initialized
INFO - 2020-10-26 08:08:02 --> Loader Class Initialized
INFO - 2020-10-26 08:08:02 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:02 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:02 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:02 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:02 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:03 --> Controller Class Initialized
DEBUG - 2020-10-26 08:08:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:08:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:08:03 --> Final output sent to browser
DEBUG - 2020-10-26 08:08:03 --> Total execution time: 0.3513
INFO - 2020-10-26 08:08:03 --> Config Class Initialized
INFO - 2020-10-26 08:08:03 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:03 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:03 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:03 --> URI Class Initialized
INFO - 2020-10-26 08:08:03 --> Router Class Initialized
INFO - 2020-10-26 08:08:03 --> Output Class Initialized
INFO - 2020-10-26 08:08:03 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:03 --> Input Class Initialized
INFO - 2020-10-26 08:08:03 --> Language Class Initialized
INFO - 2020-10-26 08:08:03 --> Language Class Initialized
INFO - 2020-10-26 08:08:03 --> Config Class Initialized
INFO - 2020-10-26 08:08:03 --> Loader Class Initialized
INFO - 2020-10-26 08:08:03 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:03 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:03 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:03 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:03 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:03 --> Controller Class Initialized
INFO - 2020-10-26 08:08:06 --> Config Class Initialized
INFO - 2020-10-26 08:08:06 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:06 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:06 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:06 --> URI Class Initialized
INFO - 2020-10-26 08:08:06 --> Router Class Initialized
INFO - 2020-10-26 08:08:06 --> Output Class Initialized
INFO - 2020-10-26 08:08:06 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:06 --> Input Class Initialized
INFO - 2020-10-26 08:08:06 --> Language Class Initialized
INFO - 2020-10-26 08:08:06 --> Language Class Initialized
INFO - 2020-10-26 08:08:06 --> Config Class Initialized
INFO - 2020-10-26 08:08:06 --> Loader Class Initialized
INFO - 2020-10-26 08:08:06 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:06 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:06 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:06 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:06 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:06 --> Controller Class Initialized
INFO - 2020-10-26 08:08:06 --> Final output sent to browser
DEBUG - 2020-10-26 08:08:06 --> Total execution time: 0.3111
INFO - 2020-10-26 08:08:19 --> Config Class Initialized
INFO - 2020-10-26 08:08:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:20 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:20 --> URI Class Initialized
INFO - 2020-10-26 08:08:20 --> Router Class Initialized
INFO - 2020-10-26 08:08:20 --> Output Class Initialized
INFO - 2020-10-26 08:08:20 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:20 --> Input Class Initialized
INFO - 2020-10-26 08:08:20 --> Language Class Initialized
INFO - 2020-10-26 08:08:20 --> Language Class Initialized
INFO - 2020-10-26 08:08:20 --> Config Class Initialized
INFO - 2020-10-26 08:08:20 --> Loader Class Initialized
INFO - 2020-10-26 08:08:20 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:20 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:20 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:20 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:20 --> Controller Class Initialized
DEBUG - 2020-10-26 08:08:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:08:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:08:20 --> Final output sent to browser
DEBUG - 2020-10-26 08:08:20 --> Total execution time: 0.3412
INFO - 2020-10-26 08:08:20 --> Config Class Initialized
INFO - 2020-10-26 08:08:20 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:20 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:20 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:20 --> URI Class Initialized
INFO - 2020-10-26 08:08:20 --> Router Class Initialized
INFO - 2020-10-26 08:08:20 --> Output Class Initialized
INFO - 2020-10-26 08:08:20 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:20 --> Input Class Initialized
INFO - 2020-10-26 08:08:20 --> Language Class Initialized
INFO - 2020-10-26 08:08:20 --> Language Class Initialized
INFO - 2020-10-26 08:08:20 --> Config Class Initialized
INFO - 2020-10-26 08:08:20 --> Loader Class Initialized
INFO - 2020-10-26 08:08:20 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:20 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:20 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:20 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:20 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:20 --> Controller Class Initialized
INFO - 2020-10-26 08:08:21 --> Config Class Initialized
INFO - 2020-10-26 08:08:21 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:21 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:21 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:21 --> URI Class Initialized
INFO - 2020-10-26 08:08:21 --> Router Class Initialized
INFO - 2020-10-26 08:08:21 --> Output Class Initialized
INFO - 2020-10-26 08:08:21 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:21 --> Input Class Initialized
INFO - 2020-10-26 08:08:21 --> Language Class Initialized
INFO - 2020-10-26 08:08:21 --> Language Class Initialized
INFO - 2020-10-26 08:08:21 --> Config Class Initialized
INFO - 2020-10-26 08:08:21 --> Loader Class Initialized
INFO - 2020-10-26 08:08:21 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:21 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:21 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:21 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:21 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:21 --> Controller Class Initialized
DEBUG - 2020-10-26 08:08:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-26 08:08:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:08:22 --> Final output sent to browser
DEBUG - 2020-10-26 08:08:22 --> Total execution time: 0.3265
INFO - 2020-10-26 08:08:22 --> Config Class Initialized
INFO - 2020-10-26 08:08:22 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:22 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:22 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:22 --> URI Class Initialized
INFO - 2020-10-26 08:08:22 --> Router Class Initialized
INFO - 2020-10-26 08:08:22 --> Output Class Initialized
INFO - 2020-10-26 08:08:22 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:22 --> Input Class Initialized
INFO - 2020-10-26 08:08:22 --> Language Class Initialized
INFO - 2020-10-26 08:08:22 --> Language Class Initialized
INFO - 2020-10-26 08:08:22 --> Config Class Initialized
INFO - 2020-10-26 08:08:22 --> Loader Class Initialized
INFO - 2020-10-26 08:08:22 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:22 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:22 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:22 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:22 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:22 --> Controller Class Initialized
INFO - 2020-10-26 08:08:23 --> Config Class Initialized
INFO - 2020-10-26 08:08:23 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:23 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:23 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:23 --> URI Class Initialized
INFO - 2020-10-26 08:08:23 --> Router Class Initialized
INFO - 2020-10-26 08:08:23 --> Output Class Initialized
INFO - 2020-10-26 08:08:23 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:23 --> Input Class Initialized
INFO - 2020-10-26 08:08:23 --> Language Class Initialized
INFO - 2020-10-26 08:08:23 --> Language Class Initialized
INFO - 2020-10-26 08:08:23 --> Config Class Initialized
INFO - 2020-10-26 08:08:23 --> Loader Class Initialized
INFO - 2020-10-26 08:08:23 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:23 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:23 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:23 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:23 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:24 --> Controller Class Initialized
DEBUG - 2020-10-26 08:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:08:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:08:24 --> Final output sent to browser
DEBUG - 2020-10-26 08:08:24 --> Total execution time: 0.3794
INFO - 2020-10-26 08:08:24 --> Config Class Initialized
INFO - 2020-10-26 08:08:24 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:08:24 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:08:24 --> Utf8 Class Initialized
INFO - 2020-10-26 08:08:24 --> URI Class Initialized
INFO - 2020-10-26 08:08:24 --> Router Class Initialized
INFO - 2020-10-26 08:08:24 --> Output Class Initialized
INFO - 2020-10-26 08:08:24 --> Security Class Initialized
DEBUG - 2020-10-26 08:08:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:08:24 --> Input Class Initialized
INFO - 2020-10-26 08:08:24 --> Language Class Initialized
INFO - 2020-10-26 08:08:24 --> Language Class Initialized
INFO - 2020-10-26 08:08:24 --> Config Class Initialized
INFO - 2020-10-26 08:08:24 --> Loader Class Initialized
INFO - 2020-10-26 08:08:24 --> Helper loaded: url_helper
INFO - 2020-10-26 08:08:24 --> Helper loaded: file_helper
INFO - 2020-10-26 08:08:24 --> Helper loaded: form_helper
INFO - 2020-10-26 08:08:24 --> Helper loaded: my_helper
INFO - 2020-10-26 08:08:24 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:08:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:08:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:08:24 --> Controller Class Initialized
INFO - 2020-10-26 08:09:08 --> Config Class Initialized
INFO - 2020-10-26 08:09:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:09:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:09:08 --> Utf8 Class Initialized
INFO - 2020-10-26 08:09:08 --> URI Class Initialized
INFO - 2020-10-26 08:09:08 --> Router Class Initialized
INFO - 2020-10-26 08:09:08 --> Output Class Initialized
INFO - 2020-10-26 08:09:08 --> Security Class Initialized
DEBUG - 2020-10-26 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:09:08 --> Input Class Initialized
INFO - 2020-10-26 08:09:08 --> Language Class Initialized
INFO - 2020-10-26 08:09:08 --> Language Class Initialized
INFO - 2020-10-26 08:09:08 --> Config Class Initialized
INFO - 2020-10-26 08:09:08 --> Loader Class Initialized
INFO - 2020-10-26 08:09:08 --> Helper loaded: url_helper
INFO - 2020-10-26 08:09:08 --> Helper loaded: file_helper
INFO - 2020-10-26 08:09:08 --> Helper loaded: form_helper
INFO - 2020-10-26 08:09:08 --> Helper loaded: my_helper
INFO - 2020-10-26 08:09:08 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:09:08 --> Controller Class Initialized
DEBUG - 2020-10-26 08:09:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:09:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:09:08 --> Final output sent to browser
DEBUG - 2020-10-26 08:09:08 --> Total execution time: 0.3589
INFO - 2020-10-26 08:09:08 --> Config Class Initialized
INFO - 2020-10-26 08:09:08 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:09:08 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:09:08 --> Utf8 Class Initialized
INFO - 2020-10-26 08:09:08 --> URI Class Initialized
INFO - 2020-10-26 08:09:08 --> Router Class Initialized
INFO - 2020-10-26 08:09:08 --> Output Class Initialized
INFO - 2020-10-26 08:09:08 --> Security Class Initialized
DEBUG - 2020-10-26 08:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:09:08 --> Input Class Initialized
INFO - 2020-10-26 08:09:08 --> Language Class Initialized
INFO - 2020-10-26 08:09:08 --> Language Class Initialized
INFO - 2020-10-26 08:09:08 --> Config Class Initialized
INFO - 2020-10-26 08:09:08 --> Loader Class Initialized
INFO - 2020-10-26 08:09:08 --> Helper loaded: url_helper
INFO - 2020-10-26 08:09:08 --> Helper loaded: file_helper
INFO - 2020-10-26 08:09:08 --> Helper loaded: form_helper
INFO - 2020-10-26 08:09:08 --> Helper loaded: my_helper
INFO - 2020-10-26 08:09:08 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:09:08 --> Controller Class Initialized
INFO - 2020-10-26 08:09:18 --> Config Class Initialized
INFO - 2020-10-26 08:09:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:09:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:09:18 --> Utf8 Class Initialized
INFO - 2020-10-26 08:09:18 --> URI Class Initialized
INFO - 2020-10-26 08:09:18 --> Router Class Initialized
INFO - 2020-10-26 08:09:18 --> Output Class Initialized
INFO - 2020-10-26 08:09:18 --> Security Class Initialized
DEBUG - 2020-10-26 08:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:09:18 --> Input Class Initialized
INFO - 2020-10-26 08:09:18 --> Language Class Initialized
INFO - 2020-10-26 08:09:18 --> Language Class Initialized
INFO - 2020-10-26 08:09:18 --> Config Class Initialized
INFO - 2020-10-26 08:09:18 --> Loader Class Initialized
INFO - 2020-10-26 08:09:18 --> Helper loaded: url_helper
INFO - 2020-10-26 08:09:18 --> Helper loaded: file_helper
INFO - 2020-10-26 08:09:18 --> Helper loaded: form_helper
INFO - 2020-10-26 08:09:18 --> Helper loaded: my_helper
INFO - 2020-10-26 08:09:18 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:09:18 --> Controller Class Initialized
DEBUG - 2020-10-26 08:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:09:18 --> Final output sent to browser
DEBUG - 2020-10-26 08:09:18 --> Total execution time: 0.3560
INFO - 2020-10-26 08:09:18 --> Config Class Initialized
INFO - 2020-10-26 08:09:18 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:09:18 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:09:18 --> Utf8 Class Initialized
INFO - 2020-10-26 08:09:18 --> URI Class Initialized
INFO - 2020-10-26 08:09:18 --> Router Class Initialized
INFO - 2020-10-26 08:09:18 --> Output Class Initialized
INFO - 2020-10-26 08:09:18 --> Security Class Initialized
DEBUG - 2020-10-26 08:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:09:19 --> Input Class Initialized
INFO - 2020-10-26 08:09:19 --> Language Class Initialized
INFO - 2020-10-26 08:09:19 --> Language Class Initialized
INFO - 2020-10-26 08:09:19 --> Config Class Initialized
INFO - 2020-10-26 08:09:19 --> Loader Class Initialized
INFO - 2020-10-26 08:09:19 --> Helper loaded: url_helper
INFO - 2020-10-26 08:09:19 --> Helper loaded: file_helper
INFO - 2020-10-26 08:09:19 --> Helper loaded: form_helper
INFO - 2020-10-26 08:09:19 --> Helper loaded: my_helper
INFO - 2020-10-26 08:09:19 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:09:19 --> Controller Class Initialized
INFO - 2020-10-26 08:10:07 --> Config Class Initialized
INFO - 2020-10-26 08:10:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:07 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:07 --> URI Class Initialized
INFO - 2020-10-26 08:10:07 --> Router Class Initialized
INFO - 2020-10-26 08:10:07 --> Output Class Initialized
INFO - 2020-10-26 08:10:07 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:07 --> Input Class Initialized
INFO - 2020-10-26 08:10:07 --> Language Class Initialized
INFO - 2020-10-26 08:10:07 --> Language Class Initialized
INFO - 2020-10-26 08:10:07 --> Config Class Initialized
INFO - 2020-10-26 08:10:07 --> Loader Class Initialized
INFO - 2020-10-26 08:10:07 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:07 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:07 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:07 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:07 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:07 --> Controller Class Initialized
DEBUG - 2020-10-26 08:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:10:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:10:07 --> Final output sent to browser
DEBUG - 2020-10-26 08:10:07 --> Total execution time: 0.3568
INFO - 2020-10-26 08:10:07 --> Config Class Initialized
INFO - 2020-10-26 08:10:07 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:07 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:07 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:07 --> URI Class Initialized
INFO - 2020-10-26 08:10:07 --> Router Class Initialized
INFO - 2020-10-26 08:10:07 --> Output Class Initialized
INFO - 2020-10-26 08:10:07 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:07 --> Input Class Initialized
INFO - 2020-10-26 08:10:07 --> Language Class Initialized
INFO - 2020-10-26 08:10:07 --> Language Class Initialized
INFO - 2020-10-26 08:10:07 --> Config Class Initialized
INFO - 2020-10-26 08:10:07 --> Loader Class Initialized
INFO - 2020-10-26 08:10:08 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:08 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:08 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:08 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:08 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:08 --> Controller Class Initialized
INFO - 2020-10-26 08:10:09 --> Config Class Initialized
INFO - 2020-10-26 08:10:09 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:09 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:09 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:09 --> URI Class Initialized
INFO - 2020-10-26 08:10:09 --> Router Class Initialized
INFO - 2020-10-26 08:10:09 --> Output Class Initialized
INFO - 2020-10-26 08:10:09 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:09 --> Input Class Initialized
INFO - 2020-10-26 08:10:09 --> Language Class Initialized
INFO - 2020-10-26 08:10:09 --> Language Class Initialized
INFO - 2020-10-26 08:10:09 --> Config Class Initialized
INFO - 2020-10-26 08:10:09 --> Loader Class Initialized
INFO - 2020-10-26 08:10:09 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:09 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:09 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:09 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:09 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:09 --> Controller Class Initialized
INFO - 2020-10-26 08:10:09 --> Final output sent to browser
DEBUG - 2020-10-26 08:10:09 --> Total execution time: 0.3080
INFO - 2020-10-26 08:10:27 --> Config Class Initialized
INFO - 2020-10-26 08:10:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:27 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:27 --> URI Class Initialized
INFO - 2020-10-26 08:10:27 --> Router Class Initialized
INFO - 2020-10-26 08:10:27 --> Output Class Initialized
INFO - 2020-10-26 08:10:27 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:27 --> Input Class Initialized
INFO - 2020-10-26 08:10:27 --> Language Class Initialized
INFO - 2020-10-26 08:10:27 --> Language Class Initialized
INFO - 2020-10-26 08:10:27 --> Config Class Initialized
INFO - 2020-10-26 08:10:27 --> Loader Class Initialized
INFO - 2020-10-26 08:10:27 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:27 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:27 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:27 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:27 --> Controller Class Initialized
DEBUG - 2020-10-26 08:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-26 08:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:10:27 --> Final output sent to browser
DEBUG - 2020-10-26 08:10:27 --> Total execution time: 0.3497
INFO - 2020-10-26 08:10:27 --> Config Class Initialized
INFO - 2020-10-26 08:10:27 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:27 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:27 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:27 --> URI Class Initialized
INFO - 2020-10-26 08:10:27 --> Router Class Initialized
INFO - 2020-10-26 08:10:27 --> Output Class Initialized
INFO - 2020-10-26 08:10:27 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:27 --> Input Class Initialized
INFO - 2020-10-26 08:10:27 --> Language Class Initialized
INFO - 2020-10-26 08:10:27 --> Language Class Initialized
INFO - 2020-10-26 08:10:27 --> Config Class Initialized
INFO - 2020-10-26 08:10:27 --> Loader Class Initialized
INFO - 2020-10-26 08:10:27 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:27 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:27 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:27 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:27 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:27 --> Controller Class Initialized
INFO - 2020-10-26 08:10:29 --> Config Class Initialized
INFO - 2020-10-26 08:10:29 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:29 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:29 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:29 --> URI Class Initialized
INFO - 2020-10-26 08:10:29 --> Router Class Initialized
INFO - 2020-10-26 08:10:29 --> Output Class Initialized
INFO - 2020-10-26 08:10:29 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:29 --> Input Class Initialized
INFO - 2020-10-26 08:10:29 --> Language Class Initialized
INFO - 2020-10-26 08:10:29 --> Language Class Initialized
INFO - 2020-10-26 08:10:29 --> Config Class Initialized
INFO - 2020-10-26 08:10:29 --> Loader Class Initialized
INFO - 2020-10-26 08:10:29 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:29 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:29 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:29 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:29 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:29 --> Controller Class Initialized
INFO - 2020-10-26 08:10:29 --> Final output sent to browser
DEBUG - 2020-10-26 08:10:29 --> Total execution time: 0.3145
INFO - 2020-10-26 08:10:33 --> Config Class Initialized
INFO - 2020-10-26 08:10:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:33 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:33 --> URI Class Initialized
INFO - 2020-10-26 08:10:33 --> Router Class Initialized
INFO - 2020-10-26 08:10:33 --> Output Class Initialized
INFO - 2020-10-26 08:10:33 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:33 --> Input Class Initialized
INFO - 2020-10-26 08:10:33 --> Language Class Initialized
INFO - 2020-10-26 08:10:33 --> Language Class Initialized
INFO - 2020-10-26 08:10:33 --> Config Class Initialized
INFO - 2020-10-26 08:10:33 --> Loader Class Initialized
INFO - 2020-10-26 08:10:33 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:33 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:33 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:33 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:33 --> Controller Class Initialized
DEBUG - 2020-10-26 08:10:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-26 08:10:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:10:33 --> Final output sent to browser
DEBUG - 2020-10-26 08:10:33 --> Total execution time: 0.3313
INFO - 2020-10-26 08:10:33 --> Config Class Initialized
INFO - 2020-10-26 08:10:33 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:33 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:33 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:33 --> URI Class Initialized
INFO - 2020-10-26 08:10:33 --> Router Class Initialized
INFO - 2020-10-26 08:10:33 --> Output Class Initialized
INFO - 2020-10-26 08:10:33 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:33 --> Input Class Initialized
INFO - 2020-10-26 08:10:33 --> Language Class Initialized
INFO - 2020-10-26 08:10:33 --> Language Class Initialized
INFO - 2020-10-26 08:10:33 --> Config Class Initialized
INFO - 2020-10-26 08:10:33 --> Loader Class Initialized
INFO - 2020-10-26 08:10:33 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:33 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:33 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:33 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:33 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:33 --> Controller Class Initialized
INFO - 2020-10-26 08:10:34 --> Config Class Initialized
INFO - 2020-10-26 08:10:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:34 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:34 --> URI Class Initialized
INFO - 2020-10-26 08:10:34 --> Router Class Initialized
INFO - 2020-10-26 08:10:34 --> Output Class Initialized
INFO - 2020-10-26 08:10:34 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:34 --> Input Class Initialized
INFO - 2020-10-26 08:10:34 --> Language Class Initialized
INFO - 2020-10-26 08:10:34 --> Language Class Initialized
INFO - 2020-10-26 08:10:34 --> Config Class Initialized
INFO - 2020-10-26 08:10:34 --> Loader Class Initialized
INFO - 2020-10-26 08:10:34 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:34 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:34 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:34 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:34 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:34 --> Controller Class Initialized
DEBUG - 2020-10-26 08:10:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 08:10:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:10:34 --> Final output sent to browser
DEBUG - 2020-10-26 08:10:34 --> Total execution time: 0.3539
INFO - 2020-10-26 08:10:34 --> Config Class Initialized
INFO - 2020-10-26 08:10:34 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:10:34 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:10:34 --> Utf8 Class Initialized
INFO - 2020-10-26 08:10:35 --> URI Class Initialized
INFO - 2020-10-26 08:10:35 --> Router Class Initialized
INFO - 2020-10-26 08:10:35 --> Output Class Initialized
INFO - 2020-10-26 08:10:35 --> Security Class Initialized
DEBUG - 2020-10-26 08:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:10:35 --> Input Class Initialized
INFO - 2020-10-26 08:10:35 --> Language Class Initialized
INFO - 2020-10-26 08:10:35 --> Language Class Initialized
INFO - 2020-10-26 08:10:35 --> Config Class Initialized
INFO - 2020-10-26 08:10:35 --> Loader Class Initialized
INFO - 2020-10-26 08:10:35 --> Helper loaded: url_helper
INFO - 2020-10-26 08:10:35 --> Helper loaded: file_helper
INFO - 2020-10-26 08:10:35 --> Helper loaded: form_helper
INFO - 2020-10-26 08:10:35 --> Helper loaded: my_helper
INFO - 2020-10-26 08:10:35 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:10:35 --> Controller Class Initialized
INFO - 2020-10-26 08:11:28 --> Config Class Initialized
INFO - 2020-10-26 08:11:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:11:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:11:28 --> Utf8 Class Initialized
INFO - 2020-10-26 08:11:28 --> URI Class Initialized
INFO - 2020-10-26 08:11:28 --> Router Class Initialized
INFO - 2020-10-26 08:11:28 --> Output Class Initialized
INFO - 2020-10-26 08:11:28 --> Security Class Initialized
DEBUG - 2020-10-26 08:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:11:28 --> Input Class Initialized
INFO - 2020-10-26 08:11:28 --> Language Class Initialized
INFO - 2020-10-26 08:11:28 --> Language Class Initialized
INFO - 2020-10-26 08:11:28 --> Config Class Initialized
INFO - 2020-10-26 08:11:28 --> Loader Class Initialized
INFO - 2020-10-26 08:11:28 --> Helper loaded: url_helper
INFO - 2020-10-26 08:11:28 --> Helper loaded: file_helper
INFO - 2020-10-26 08:11:28 --> Helper loaded: form_helper
INFO - 2020-10-26 08:11:28 --> Helper loaded: my_helper
INFO - 2020-10-26 08:11:28 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:11:28 --> Controller Class Initialized
DEBUG - 2020-10-26 08:11:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 08:11:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:11:28 --> Final output sent to browser
DEBUG - 2020-10-26 08:11:28 --> Total execution time: 0.3529
INFO - 2020-10-26 08:11:28 --> Config Class Initialized
INFO - 2020-10-26 08:11:28 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:11:28 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:11:28 --> Utf8 Class Initialized
INFO - 2020-10-26 08:11:28 --> URI Class Initialized
INFO - 2020-10-26 08:11:28 --> Router Class Initialized
INFO - 2020-10-26 08:11:28 --> Output Class Initialized
INFO - 2020-10-26 08:11:28 --> Security Class Initialized
DEBUG - 2020-10-26 08:11:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:11:28 --> Input Class Initialized
INFO - 2020-10-26 08:11:28 --> Language Class Initialized
INFO - 2020-10-26 08:11:28 --> Language Class Initialized
INFO - 2020-10-26 08:11:28 --> Config Class Initialized
INFO - 2020-10-26 08:11:28 --> Loader Class Initialized
INFO - 2020-10-26 08:11:28 --> Helper loaded: url_helper
INFO - 2020-10-26 08:11:28 --> Helper loaded: file_helper
INFO - 2020-10-26 08:11:28 --> Helper loaded: form_helper
INFO - 2020-10-26 08:11:28 --> Helper loaded: my_helper
INFO - 2020-10-26 08:11:28 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:11:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:11:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:11:28 --> Controller Class Initialized
INFO - 2020-10-26 08:11:44 --> Config Class Initialized
INFO - 2020-10-26 08:11:44 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:11:44 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:11:44 --> Utf8 Class Initialized
INFO - 2020-10-26 08:11:45 --> URI Class Initialized
INFO - 2020-10-26 08:11:45 --> Router Class Initialized
INFO - 2020-10-26 08:11:45 --> Output Class Initialized
INFO - 2020-10-26 08:11:45 --> Security Class Initialized
DEBUG - 2020-10-26 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:11:45 --> Input Class Initialized
INFO - 2020-10-26 08:11:45 --> Language Class Initialized
INFO - 2020-10-26 08:11:45 --> Language Class Initialized
INFO - 2020-10-26 08:11:45 --> Config Class Initialized
INFO - 2020-10-26 08:11:45 --> Loader Class Initialized
INFO - 2020-10-26 08:11:45 --> Helper loaded: url_helper
INFO - 2020-10-26 08:11:45 --> Helper loaded: file_helper
INFO - 2020-10-26 08:11:45 --> Helper loaded: form_helper
INFO - 2020-10-26 08:11:45 --> Helper loaded: my_helper
INFO - 2020-10-26 08:11:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:11:45 --> Controller Class Initialized
DEBUG - 2020-10-26 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-26 08:11:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:11:45 --> Final output sent to browser
DEBUG - 2020-10-26 08:11:45 --> Total execution time: 0.3619
INFO - 2020-10-26 08:11:45 --> Config Class Initialized
INFO - 2020-10-26 08:11:45 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:11:45 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:11:45 --> Utf8 Class Initialized
INFO - 2020-10-26 08:11:45 --> URI Class Initialized
INFO - 2020-10-26 08:11:45 --> Router Class Initialized
INFO - 2020-10-26 08:11:45 --> Output Class Initialized
INFO - 2020-10-26 08:11:45 --> Security Class Initialized
DEBUG - 2020-10-26 08:11:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:11:45 --> Input Class Initialized
INFO - 2020-10-26 08:11:45 --> Language Class Initialized
INFO - 2020-10-26 08:11:45 --> Language Class Initialized
INFO - 2020-10-26 08:11:45 --> Config Class Initialized
INFO - 2020-10-26 08:11:45 --> Loader Class Initialized
INFO - 2020-10-26 08:11:45 --> Helper loaded: url_helper
INFO - 2020-10-26 08:11:45 --> Helper loaded: file_helper
INFO - 2020-10-26 08:11:45 --> Helper loaded: form_helper
INFO - 2020-10-26 08:11:45 --> Helper loaded: my_helper
INFO - 2020-10-26 08:11:45 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:11:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:11:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:11:45 --> Controller Class Initialized
INFO - 2020-10-26 08:11:54 --> Config Class Initialized
INFO - 2020-10-26 08:11:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:11:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:11:54 --> Utf8 Class Initialized
INFO - 2020-10-26 08:11:54 --> URI Class Initialized
INFO - 2020-10-26 08:11:54 --> Router Class Initialized
INFO - 2020-10-26 08:11:54 --> Output Class Initialized
INFO - 2020-10-26 08:11:54 --> Security Class Initialized
DEBUG - 2020-10-26 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:11:54 --> Input Class Initialized
INFO - 2020-10-26 08:11:54 --> Language Class Initialized
INFO - 2020-10-26 08:11:54 --> Language Class Initialized
INFO - 2020-10-26 08:11:54 --> Config Class Initialized
INFO - 2020-10-26 08:11:54 --> Loader Class Initialized
INFO - 2020-10-26 08:11:54 --> Helper loaded: url_helper
INFO - 2020-10-26 08:11:54 --> Helper loaded: file_helper
INFO - 2020-10-26 08:11:54 --> Helper loaded: form_helper
INFO - 2020-10-26 08:11:54 --> Helper loaded: my_helper
INFO - 2020-10-26 08:11:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:11:54 --> Controller Class Initialized
INFO - 2020-10-26 08:11:54 --> Final output sent to browser
DEBUG - 2020-10-26 08:11:54 --> Total execution time: 0.3840
INFO - 2020-10-26 08:11:54 --> Config Class Initialized
INFO - 2020-10-26 08:11:54 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:11:54 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:11:54 --> Utf8 Class Initialized
INFO - 2020-10-26 08:11:54 --> URI Class Initialized
INFO - 2020-10-26 08:11:54 --> Router Class Initialized
INFO - 2020-10-26 08:11:54 --> Output Class Initialized
INFO - 2020-10-26 08:11:54 --> Security Class Initialized
DEBUG - 2020-10-26 08:11:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:11:54 --> Input Class Initialized
INFO - 2020-10-26 08:11:54 --> Language Class Initialized
INFO - 2020-10-26 08:11:54 --> Language Class Initialized
INFO - 2020-10-26 08:11:54 --> Config Class Initialized
INFO - 2020-10-26 08:11:54 --> Loader Class Initialized
INFO - 2020-10-26 08:11:54 --> Helper loaded: url_helper
INFO - 2020-10-26 08:11:54 --> Helper loaded: file_helper
INFO - 2020-10-26 08:11:54 --> Helper loaded: form_helper
INFO - 2020-10-26 08:11:54 --> Helper loaded: my_helper
INFO - 2020-10-26 08:11:54 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:11:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:11:54 --> Controller Class Initialized
INFO - 2020-10-26 08:12:26 --> Config Class Initialized
INFO - 2020-10-26 08:12:26 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:12:26 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:12:26 --> Utf8 Class Initialized
INFO - 2020-10-26 08:12:26 --> URI Class Initialized
INFO - 2020-10-26 08:12:26 --> Router Class Initialized
INFO - 2020-10-26 08:12:26 --> Output Class Initialized
INFO - 2020-10-26 08:12:26 --> Security Class Initialized
DEBUG - 2020-10-26 08:12:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:12:26 --> Input Class Initialized
INFO - 2020-10-26 08:12:26 --> Language Class Initialized
INFO - 2020-10-26 08:12:26 --> Language Class Initialized
INFO - 2020-10-26 08:12:26 --> Config Class Initialized
INFO - 2020-10-26 08:12:26 --> Loader Class Initialized
INFO - 2020-10-26 08:12:26 --> Helper loaded: url_helper
INFO - 2020-10-26 08:12:26 --> Helper loaded: file_helper
INFO - 2020-10-26 08:12:26 --> Helper loaded: form_helper
INFO - 2020-10-26 08:12:26 --> Helper loaded: my_helper
INFO - 2020-10-26 08:12:26 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:12:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:12:26 --> Controller Class Initialized
DEBUG - 2020-10-26 08:12:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 08:12:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:12:26 --> Final output sent to browser
DEBUG - 2020-10-26 08:12:26 --> Total execution time: 0.3448
INFO - 2020-10-26 08:13:31 --> Config Class Initialized
INFO - 2020-10-26 08:13:31 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:13:31 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:13:31 --> Utf8 Class Initialized
INFO - 2020-10-26 08:13:31 --> URI Class Initialized
INFO - 2020-10-26 08:13:31 --> Router Class Initialized
INFO - 2020-10-26 08:13:31 --> Output Class Initialized
INFO - 2020-10-26 08:13:31 --> Security Class Initialized
DEBUG - 2020-10-26 08:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:13:31 --> Input Class Initialized
INFO - 2020-10-26 08:13:31 --> Language Class Initialized
INFO - 2020-10-26 08:13:31 --> Language Class Initialized
INFO - 2020-10-26 08:13:31 --> Config Class Initialized
INFO - 2020-10-26 08:13:31 --> Loader Class Initialized
INFO - 2020-10-26 08:13:31 --> Helper loaded: url_helper
INFO - 2020-10-26 08:13:31 --> Helper loaded: file_helper
INFO - 2020-10-26 08:13:31 --> Helper loaded: form_helper
INFO - 2020-10-26 08:13:31 --> Helper loaded: my_helper
INFO - 2020-10-26 08:13:31 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:13:31 --> Controller Class Initialized
DEBUG - 2020-10-26 08:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-26 08:13:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:13:31 --> Final output sent to browser
DEBUG - 2020-10-26 08:13:31 --> Total execution time: 0.3704
INFO - 2020-10-26 08:13:40 --> Config Class Initialized
INFO - 2020-10-26 08:13:40 --> Hooks Class Initialized
DEBUG - 2020-10-26 08:13:40 --> UTF-8 Support Enabled
INFO - 2020-10-26 08:13:40 --> Utf8 Class Initialized
INFO - 2020-10-26 08:13:40 --> URI Class Initialized
INFO - 2020-10-26 08:13:40 --> Router Class Initialized
INFO - 2020-10-26 08:13:40 --> Output Class Initialized
INFO - 2020-10-26 08:13:41 --> Security Class Initialized
DEBUG - 2020-10-26 08:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-26 08:13:41 --> Input Class Initialized
INFO - 2020-10-26 08:13:41 --> Language Class Initialized
INFO - 2020-10-26 08:13:41 --> Language Class Initialized
INFO - 2020-10-26 08:13:41 --> Config Class Initialized
INFO - 2020-10-26 08:13:41 --> Loader Class Initialized
INFO - 2020-10-26 08:13:41 --> Helper loaded: url_helper
INFO - 2020-10-26 08:13:41 --> Helper loaded: file_helper
INFO - 2020-10-26 08:13:41 --> Helper loaded: form_helper
INFO - 2020-10-26 08:13:41 --> Helper loaded: my_helper
INFO - 2020-10-26 08:13:41 --> Database Driver Class Initialized
DEBUG - 2020-10-26 08:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-26 08:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-26 08:13:41 --> Controller Class Initialized
DEBUG - 2020-10-26 08:13:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-26 08:13:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-26 08:13:41 --> Final output sent to browser
DEBUG - 2020-10-26 08:13:41 --> Total execution time: 0.3688
