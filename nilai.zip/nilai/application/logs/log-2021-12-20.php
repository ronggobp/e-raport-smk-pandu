<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-20 04:44:08 --> Config Class Initialized
INFO - 2021-12-20 04:44:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:44:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:44:08 --> Utf8 Class Initialized
INFO - 2021-12-20 04:44:08 --> URI Class Initialized
DEBUG - 2021-12-20 04:44:08 --> No URI present. Default controller set.
INFO - 2021-12-20 04:44:08 --> Router Class Initialized
INFO - 2021-12-20 04:44:08 --> Output Class Initialized
INFO - 2021-12-20 04:44:08 --> Security Class Initialized
DEBUG - 2021-12-20 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:44:08 --> Input Class Initialized
INFO - 2021-12-20 04:44:08 --> Language Class Initialized
INFO - 2021-12-20 04:44:08 --> Language Class Initialized
INFO - 2021-12-20 04:44:08 --> Config Class Initialized
INFO - 2021-12-20 04:44:08 --> Loader Class Initialized
INFO - 2021-12-20 04:44:08 --> Helper loaded: url_helper
INFO - 2021-12-20 04:44:08 --> Helper loaded: file_helper
INFO - 2021-12-20 04:44:08 --> Helper loaded: form_helper
INFO - 2021-12-20 04:44:08 --> Helper loaded: my_helper
INFO - 2021-12-20 04:44:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:44:08 --> Controller Class Initialized
INFO - 2021-12-20 04:44:08 --> Config Class Initialized
INFO - 2021-12-20 04:44:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:44:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:44:08 --> Utf8 Class Initialized
INFO - 2021-12-20 04:44:08 --> URI Class Initialized
INFO - 2021-12-20 04:44:08 --> Router Class Initialized
INFO - 2021-12-20 04:44:08 --> Output Class Initialized
INFO - 2021-12-20 04:44:08 --> Security Class Initialized
DEBUG - 2021-12-20 04:44:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:44:08 --> Input Class Initialized
INFO - 2021-12-20 04:44:08 --> Language Class Initialized
INFO - 2021-12-20 04:44:08 --> Language Class Initialized
INFO - 2021-12-20 04:44:08 --> Config Class Initialized
INFO - 2021-12-20 04:44:08 --> Loader Class Initialized
INFO - 2021-12-20 04:44:08 --> Helper loaded: url_helper
INFO - 2021-12-20 04:44:08 --> Helper loaded: file_helper
INFO - 2021-12-20 04:44:08 --> Helper loaded: form_helper
INFO - 2021-12-20 04:44:08 --> Helper loaded: my_helper
INFO - 2021-12-20 04:44:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:44:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:44:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:44:08 --> Controller Class Initialized
DEBUG - 2021-12-20 04:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 04:44:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 04:44:08 --> Final output sent to browser
DEBUG - 2021-12-20 04:44:08 --> Total execution time: 0.0420
INFO - 2021-12-20 04:44:13 --> Config Class Initialized
INFO - 2021-12-20 04:44:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:44:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:44:13 --> Utf8 Class Initialized
INFO - 2021-12-20 04:44:13 --> URI Class Initialized
INFO - 2021-12-20 04:44:13 --> Router Class Initialized
INFO - 2021-12-20 04:44:13 --> Output Class Initialized
INFO - 2021-12-20 04:44:13 --> Security Class Initialized
DEBUG - 2021-12-20 04:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:44:13 --> Input Class Initialized
INFO - 2021-12-20 04:44:13 --> Language Class Initialized
INFO - 2021-12-20 04:44:13 --> Language Class Initialized
INFO - 2021-12-20 04:44:13 --> Config Class Initialized
INFO - 2021-12-20 04:44:13 --> Loader Class Initialized
INFO - 2021-12-20 04:44:13 --> Helper loaded: url_helper
INFO - 2021-12-20 04:44:13 --> Helper loaded: file_helper
INFO - 2021-12-20 04:44:13 --> Helper loaded: form_helper
INFO - 2021-12-20 04:44:13 --> Helper loaded: my_helper
INFO - 2021-12-20 04:44:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:44:13 --> Controller Class Initialized
INFO - 2021-12-20 04:44:13 --> Helper loaded: cookie_helper
INFO - 2021-12-20 04:44:13 --> Final output sent to browser
DEBUG - 2021-12-20 04:44:13 --> Total execution time: 0.0592
INFO - 2021-12-20 04:44:14 --> Config Class Initialized
INFO - 2021-12-20 04:44:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:44:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:44:14 --> Utf8 Class Initialized
INFO - 2021-12-20 04:44:14 --> URI Class Initialized
INFO - 2021-12-20 04:44:14 --> Router Class Initialized
INFO - 2021-12-20 04:44:14 --> Output Class Initialized
INFO - 2021-12-20 04:44:14 --> Security Class Initialized
DEBUG - 2021-12-20 04:44:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:44:14 --> Input Class Initialized
INFO - 2021-12-20 04:44:14 --> Language Class Initialized
INFO - 2021-12-20 04:44:14 --> Language Class Initialized
INFO - 2021-12-20 04:44:14 --> Config Class Initialized
INFO - 2021-12-20 04:44:14 --> Loader Class Initialized
INFO - 2021-12-20 04:44:14 --> Helper loaded: url_helper
INFO - 2021-12-20 04:44:14 --> Helper loaded: file_helper
INFO - 2021-12-20 04:44:14 --> Helper loaded: form_helper
INFO - 2021-12-20 04:44:14 --> Helper loaded: my_helper
INFO - 2021-12-20 04:44:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:44:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:44:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:44:14 --> Controller Class Initialized
DEBUG - 2021-12-20 04:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 04:44:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 04:44:14 --> Final output sent to browser
DEBUG - 2021-12-20 04:44:14 --> Total execution time: 0.2160
INFO - 2021-12-20 04:44:26 --> Config Class Initialized
INFO - 2021-12-20 04:44:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:44:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:44:26 --> Utf8 Class Initialized
INFO - 2021-12-20 04:44:26 --> URI Class Initialized
INFO - 2021-12-20 04:44:26 --> Router Class Initialized
INFO - 2021-12-20 04:44:26 --> Output Class Initialized
INFO - 2021-12-20 04:44:26 --> Security Class Initialized
DEBUG - 2021-12-20 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:44:26 --> Input Class Initialized
INFO - 2021-12-20 04:44:26 --> Language Class Initialized
INFO - 2021-12-20 04:44:26 --> Language Class Initialized
INFO - 2021-12-20 04:44:26 --> Config Class Initialized
INFO - 2021-12-20 04:44:26 --> Loader Class Initialized
INFO - 2021-12-20 04:44:26 --> Helper loaded: url_helper
INFO - 2021-12-20 04:44:26 --> Helper loaded: file_helper
INFO - 2021-12-20 04:44:26 --> Helper loaded: form_helper
INFO - 2021-12-20 04:44:26 --> Helper loaded: my_helper
INFO - 2021-12-20 04:44:26 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:44:26 --> Controller Class Initialized
DEBUG - 2021-12-20 04:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-20 04:44:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 04:44:26 --> Final output sent to browser
DEBUG - 2021-12-20 04:44:26 --> Total execution time: 0.0300
INFO - 2021-12-20 04:44:26 --> Config Class Initialized
INFO - 2021-12-20 04:44:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:44:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:44:26 --> Utf8 Class Initialized
INFO - 2021-12-20 04:44:26 --> URI Class Initialized
INFO - 2021-12-20 04:44:26 --> Router Class Initialized
INFO - 2021-12-20 04:44:26 --> Output Class Initialized
INFO - 2021-12-20 04:44:26 --> Security Class Initialized
DEBUG - 2021-12-20 04:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:44:26 --> Input Class Initialized
INFO - 2021-12-20 04:44:26 --> Language Class Initialized
INFO - 2021-12-20 04:44:26 --> Language Class Initialized
INFO - 2021-12-20 04:44:26 --> Config Class Initialized
INFO - 2021-12-20 04:44:26 --> Loader Class Initialized
INFO - 2021-12-20 04:44:26 --> Helper loaded: url_helper
INFO - 2021-12-20 04:44:26 --> Helper loaded: file_helper
INFO - 2021-12-20 04:44:26 --> Helper loaded: form_helper
INFO - 2021-12-20 04:44:26 --> Helper loaded: my_helper
INFO - 2021-12-20 04:44:26 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:44:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:44:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:44:26 --> Controller Class Initialized
INFO - 2021-12-20 04:45:21 --> Config Class Initialized
INFO - 2021-12-20 04:45:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:45:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:45:21 --> Utf8 Class Initialized
INFO - 2021-12-20 04:45:21 --> URI Class Initialized
INFO - 2021-12-20 04:45:21 --> Router Class Initialized
INFO - 2021-12-20 04:45:21 --> Output Class Initialized
INFO - 2021-12-20 04:45:21 --> Security Class Initialized
DEBUG - 2021-12-20 04:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:45:21 --> Input Class Initialized
INFO - 2021-12-20 04:45:21 --> Language Class Initialized
INFO - 2021-12-20 04:45:21 --> Language Class Initialized
INFO - 2021-12-20 04:45:21 --> Config Class Initialized
INFO - 2021-12-20 04:45:21 --> Loader Class Initialized
INFO - 2021-12-20 04:45:21 --> Helper loaded: url_helper
INFO - 2021-12-20 04:45:21 --> Helper loaded: file_helper
INFO - 2021-12-20 04:45:21 --> Helper loaded: form_helper
INFO - 2021-12-20 04:45:21 --> Helper loaded: my_helper
INFO - 2021-12-20 04:45:21 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:45:21 --> Controller Class Initialized
INFO - 2021-12-20 04:46:10 --> Config Class Initialized
INFO - 2021-12-20 04:46:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:46:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:46:10 --> Utf8 Class Initialized
INFO - 2021-12-20 04:46:11 --> URI Class Initialized
INFO - 2021-12-20 04:46:11 --> Router Class Initialized
INFO - 2021-12-20 04:46:11 --> Output Class Initialized
INFO - 2021-12-20 04:46:11 --> Security Class Initialized
DEBUG - 2021-12-20 04:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:46:11 --> Input Class Initialized
INFO - 2021-12-20 04:46:11 --> Language Class Initialized
INFO - 2021-12-20 04:46:11 --> Language Class Initialized
INFO - 2021-12-20 04:46:11 --> Config Class Initialized
INFO - 2021-12-20 04:46:11 --> Loader Class Initialized
INFO - 2021-12-20 04:46:11 --> Helper loaded: url_helper
INFO - 2021-12-20 04:46:11 --> Helper loaded: file_helper
INFO - 2021-12-20 04:46:11 --> Helper loaded: form_helper
INFO - 2021-12-20 04:46:11 --> Helper loaded: my_helper
INFO - 2021-12-20 04:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:46:11 --> Controller Class Initialized
DEBUG - 2021-12-20 04:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-20 04:46:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 04:46:11 --> Final output sent to browser
DEBUG - 2021-12-20 04:46:11 --> Total execution time: 0.0470
INFO - 2021-12-20 04:46:11 --> Config Class Initialized
INFO - 2021-12-20 04:46:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:46:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:46:11 --> Utf8 Class Initialized
INFO - 2021-12-20 04:46:11 --> URI Class Initialized
INFO - 2021-12-20 04:46:11 --> Router Class Initialized
INFO - 2021-12-20 04:46:11 --> Output Class Initialized
INFO - 2021-12-20 04:46:11 --> Security Class Initialized
DEBUG - 2021-12-20 04:46:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:46:11 --> Input Class Initialized
INFO - 2021-12-20 04:46:11 --> Language Class Initialized
INFO - 2021-12-20 04:46:11 --> Language Class Initialized
INFO - 2021-12-20 04:46:11 --> Config Class Initialized
INFO - 2021-12-20 04:46:11 --> Loader Class Initialized
INFO - 2021-12-20 04:46:11 --> Helper loaded: url_helper
INFO - 2021-12-20 04:46:11 --> Helper loaded: file_helper
INFO - 2021-12-20 04:46:11 --> Helper loaded: form_helper
INFO - 2021-12-20 04:46:11 --> Helper loaded: my_helper
INFO - 2021-12-20 04:46:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:46:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:46:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:46:11 --> Controller Class Initialized
INFO - 2021-12-20 04:46:19 --> Config Class Initialized
INFO - 2021-12-20 04:46:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 04:46:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 04:46:19 --> Utf8 Class Initialized
INFO - 2021-12-20 04:46:19 --> URI Class Initialized
INFO - 2021-12-20 04:46:19 --> Router Class Initialized
INFO - 2021-12-20 04:46:19 --> Output Class Initialized
INFO - 2021-12-20 04:46:19 --> Security Class Initialized
DEBUG - 2021-12-20 04:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 04:46:19 --> Input Class Initialized
INFO - 2021-12-20 04:46:19 --> Language Class Initialized
INFO - 2021-12-20 04:46:19 --> Language Class Initialized
INFO - 2021-12-20 04:46:19 --> Config Class Initialized
INFO - 2021-12-20 04:46:19 --> Loader Class Initialized
INFO - 2021-12-20 04:46:19 --> Helper loaded: url_helper
INFO - 2021-12-20 04:46:19 --> Helper loaded: file_helper
INFO - 2021-12-20 04:46:19 --> Helper loaded: form_helper
INFO - 2021-12-20 04:46:19 --> Helper loaded: my_helper
INFO - 2021-12-20 04:46:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 04:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 04:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 04:46:19 --> Controller Class Initialized
INFO - 2021-12-20 04:46:19 --> Final output sent to browser
DEBUG - 2021-12-20 04:46:19 --> Total execution time: 0.0450
INFO - 2021-12-20 06:29:29 --> Config Class Initialized
INFO - 2021-12-20 06:29:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:29:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:29:29 --> Utf8 Class Initialized
INFO - 2021-12-20 06:29:29 --> URI Class Initialized
DEBUG - 2021-12-20 06:29:29 --> No URI present. Default controller set.
INFO - 2021-12-20 06:29:29 --> Router Class Initialized
INFO - 2021-12-20 06:29:29 --> Output Class Initialized
INFO - 2021-12-20 06:29:29 --> Security Class Initialized
DEBUG - 2021-12-20 06:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:29:29 --> Input Class Initialized
INFO - 2021-12-20 06:29:29 --> Language Class Initialized
INFO - 2021-12-20 06:29:29 --> Language Class Initialized
INFO - 2021-12-20 06:29:29 --> Config Class Initialized
INFO - 2021-12-20 06:29:29 --> Loader Class Initialized
INFO - 2021-12-20 06:29:29 --> Helper loaded: url_helper
INFO - 2021-12-20 06:29:29 --> Helper loaded: file_helper
INFO - 2021-12-20 06:29:29 --> Helper loaded: form_helper
INFO - 2021-12-20 06:29:29 --> Helper loaded: my_helper
INFO - 2021-12-20 06:29:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:29:29 --> Controller Class Initialized
INFO - 2021-12-20 06:29:29 --> Config Class Initialized
INFO - 2021-12-20 06:29:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 06:29:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 06:29:29 --> Utf8 Class Initialized
INFO - 2021-12-20 06:29:29 --> URI Class Initialized
INFO - 2021-12-20 06:29:29 --> Router Class Initialized
INFO - 2021-12-20 06:29:29 --> Output Class Initialized
INFO - 2021-12-20 06:29:29 --> Security Class Initialized
DEBUG - 2021-12-20 06:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 06:29:29 --> Input Class Initialized
INFO - 2021-12-20 06:29:29 --> Language Class Initialized
INFO - 2021-12-20 06:29:29 --> Language Class Initialized
INFO - 2021-12-20 06:29:29 --> Config Class Initialized
INFO - 2021-12-20 06:29:29 --> Loader Class Initialized
INFO - 2021-12-20 06:29:29 --> Helper loaded: url_helper
INFO - 2021-12-20 06:29:29 --> Helper loaded: file_helper
INFO - 2021-12-20 06:29:29 --> Helper loaded: form_helper
INFO - 2021-12-20 06:29:29 --> Helper loaded: my_helper
INFO - 2021-12-20 06:29:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 06:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 06:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 06:29:29 --> Controller Class Initialized
DEBUG - 2021-12-20 06:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 06:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 06:29:29 --> Final output sent to browser
DEBUG - 2021-12-20 06:29:29 --> Total execution time: 0.0390
INFO - 2021-12-20 07:50:13 --> Config Class Initialized
INFO - 2021-12-20 07:50:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 07:50:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 07:50:13 --> Utf8 Class Initialized
INFO - 2021-12-20 07:50:13 --> URI Class Initialized
DEBUG - 2021-12-20 07:50:13 --> No URI present. Default controller set.
INFO - 2021-12-20 07:50:13 --> Router Class Initialized
INFO - 2021-12-20 07:50:13 --> Output Class Initialized
INFO - 2021-12-20 07:50:13 --> Security Class Initialized
DEBUG - 2021-12-20 07:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 07:50:13 --> Input Class Initialized
INFO - 2021-12-20 07:50:13 --> Language Class Initialized
INFO - 2021-12-20 07:50:13 --> Language Class Initialized
INFO - 2021-12-20 07:50:13 --> Config Class Initialized
INFO - 2021-12-20 07:50:13 --> Loader Class Initialized
INFO - 2021-12-20 07:50:13 --> Helper loaded: url_helper
INFO - 2021-12-20 07:50:13 --> Helper loaded: file_helper
INFO - 2021-12-20 07:50:13 --> Helper loaded: form_helper
INFO - 2021-12-20 07:50:13 --> Helper loaded: my_helper
INFO - 2021-12-20 07:50:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 07:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 07:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 07:50:13 --> Controller Class Initialized
INFO - 2021-12-20 07:50:13 --> Config Class Initialized
INFO - 2021-12-20 07:50:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 07:50:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 07:50:13 --> Utf8 Class Initialized
INFO - 2021-12-20 07:50:13 --> URI Class Initialized
INFO - 2021-12-20 07:50:13 --> Router Class Initialized
INFO - 2021-12-20 07:50:13 --> Output Class Initialized
INFO - 2021-12-20 07:50:13 --> Security Class Initialized
DEBUG - 2021-12-20 07:50:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 07:50:13 --> Input Class Initialized
INFO - 2021-12-20 07:50:13 --> Language Class Initialized
INFO - 2021-12-20 07:50:13 --> Language Class Initialized
INFO - 2021-12-20 07:50:13 --> Config Class Initialized
INFO - 2021-12-20 07:50:13 --> Loader Class Initialized
INFO - 2021-12-20 07:50:13 --> Helper loaded: url_helper
INFO - 2021-12-20 07:50:13 --> Helper loaded: file_helper
INFO - 2021-12-20 07:50:13 --> Helper loaded: form_helper
INFO - 2021-12-20 07:50:13 --> Helper loaded: my_helper
INFO - 2021-12-20 07:50:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 07:50:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 07:50:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 07:50:13 --> Controller Class Initialized
DEBUG - 2021-12-20 07:50:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 07:50:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 07:50:13 --> Final output sent to browser
DEBUG - 2021-12-20 07:50:13 --> Total execution time: 0.0370
INFO - 2021-12-20 07:50:19 --> Config Class Initialized
INFO - 2021-12-20 07:50:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 07:50:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 07:50:19 --> Utf8 Class Initialized
INFO - 2021-12-20 07:50:19 --> URI Class Initialized
INFO - 2021-12-20 07:50:19 --> Router Class Initialized
INFO - 2021-12-20 07:50:19 --> Output Class Initialized
INFO - 2021-12-20 07:50:19 --> Security Class Initialized
DEBUG - 2021-12-20 07:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 07:50:19 --> Input Class Initialized
INFO - 2021-12-20 07:50:19 --> Language Class Initialized
INFO - 2021-12-20 07:50:19 --> Language Class Initialized
INFO - 2021-12-20 07:50:19 --> Config Class Initialized
INFO - 2021-12-20 07:50:19 --> Loader Class Initialized
INFO - 2021-12-20 07:50:19 --> Helper loaded: url_helper
INFO - 2021-12-20 07:50:19 --> Helper loaded: file_helper
INFO - 2021-12-20 07:50:19 --> Helper loaded: form_helper
INFO - 2021-12-20 07:50:19 --> Helper loaded: my_helper
INFO - 2021-12-20 07:50:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 07:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 07:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 07:50:19 --> Controller Class Initialized
INFO - 2021-12-20 07:50:19 --> Helper loaded: cookie_helper
INFO - 2021-12-20 07:50:19 --> Final output sent to browser
DEBUG - 2021-12-20 07:50:19 --> Total execution time: 0.0450
INFO - 2021-12-20 07:50:19 --> Config Class Initialized
INFO - 2021-12-20 07:50:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 07:50:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 07:50:19 --> Utf8 Class Initialized
INFO - 2021-12-20 07:50:19 --> URI Class Initialized
INFO - 2021-12-20 07:50:19 --> Router Class Initialized
INFO - 2021-12-20 07:50:19 --> Output Class Initialized
INFO - 2021-12-20 07:50:19 --> Security Class Initialized
DEBUG - 2021-12-20 07:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 07:50:19 --> Input Class Initialized
INFO - 2021-12-20 07:50:19 --> Language Class Initialized
INFO - 2021-12-20 07:50:19 --> Language Class Initialized
INFO - 2021-12-20 07:50:19 --> Config Class Initialized
INFO - 2021-12-20 07:50:19 --> Loader Class Initialized
INFO - 2021-12-20 07:50:19 --> Helper loaded: url_helper
INFO - 2021-12-20 07:50:19 --> Helper loaded: file_helper
INFO - 2021-12-20 07:50:19 --> Helper loaded: form_helper
INFO - 2021-12-20 07:50:19 --> Helper loaded: my_helper
INFO - 2021-12-20 07:50:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 07:50:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 07:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 07:50:19 --> Controller Class Initialized
DEBUG - 2021-12-20 07:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 07:50:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 07:50:19 --> Final output sent to browser
DEBUG - 2021-12-20 07:50:19 --> Total execution time: 0.1860
INFO - 2021-12-20 07:50:22 --> Config Class Initialized
INFO - 2021-12-20 07:50:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 07:50:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 07:50:22 --> Utf8 Class Initialized
INFO - 2021-12-20 07:50:22 --> URI Class Initialized
INFO - 2021-12-20 07:50:22 --> Router Class Initialized
INFO - 2021-12-20 07:50:22 --> Output Class Initialized
INFO - 2021-12-20 07:50:22 --> Security Class Initialized
DEBUG - 2021-12-20 07:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 07:50:22 --> Input Class Initialized
INFO - 2021-12-20 07:50:22 --> Language Class Initialized
INFO - 2021-12-20 07:50:22 --> Language Class Initialized
INFO - 2021-12-20 07:50:22 --> Config Class Initialized
INFO - 2021-12-20 07:50:22 --> Loader Class Initialized
INFO - 2021-12-20 07:50:22 --> Helper loaded: url_helper
INFO - 2021-12-20 07:50:22 --> Helper loaded: file_helper
INFO - 2021-12-20 07:50:22 --> Helper loaded: form_helper
INFO - 2021-12-20 07:50:22 --> Helper loaded: my_helper
INFO - 2021-12-20 07:50:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 07:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 07:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 07:50:22 --> Controller Class Initialized
DEBUG - 2021-12-20 07:50:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 07:50:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 07:50:22 --> Final output sent to browser
DEBUG - 2021-12-20 07:50:22 --> Total execution time: 0.0650
INFO - 2021-12-20 07:50:22 --> Config Class Initialized
INFO - 2021-12-20 07:50:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 07:50:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 07:50:22 --> Utf8 Class Initialized
INFO - 2021-12-20 07:50:22 --> URI Class Initialized
INFO - 2021-12-20 07:50:22 --> Router Class Initialized
INFO - 2021-12-20 07:50:22 --> Output Class Initialized
INFO - 2021-12-20 07:50:22 --> Security Class Initialized
DEBUG - 2021-12-20 07:50:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 07:50:22 --> Input Class Initialized
INFO - 2021-12-20 07:50:22 --> Language Class Initialized
INFO - 2021-12-20 07:50:22 --> Language Class Initialized
INFO - 2021-12-20 07:50:22 --> Config Class Initialized
INFO - 2021-12-20 07:50:22 --> Loader Class Initialized
INFO - 2021-12-20 07:50:22 --> Helper loaded: url_helper
INFO - 2021-12-20 07:50:22 --> Helper loaded: file_helper
INFO - 2021-12-20 07:50:22 --> Helper loaded: form_helper
INFO - 2021-12-20 07:50:22 --> Helper loaded: my_helper
INFO - 2021-12-20 07:50:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 07:50:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 07:50:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 07:50:22 --> Controller Class Initialized
INFO - 2021-12-20 07:50:50 --> Config Class Initialized
INFO - 2021-12-20 07:50:50 --> Hooks Class Initialized
DEBUG - 2021-12-20 07:50:50 --> UTF-8 Support Enabled
INFO - 2021-12-20 07:50:50 --> Utf8 Class Initialized
INFO - 2021-12-20 07:50:50 --> URI Class Initialized
INFO - 2021-12-20 07:50:50 --> Router Class Initialized
INFO - 2021-12-20 07:50:50 --> Output Class Initialized
INFO - 2021-12-20 07:50:50 --> Security Class Initialized
DEBUG - 2021-12-20 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 07:50:50 --> Input Class Initialized
INFO - 2021-12-20 07:50:50 --> Language Class Initialized
INFO - 2021-12-20 07:50:50 --> Language Class Initialized
INFO - 2021-12-20 07:50:50 --> Config Class Initialized
INFO - 2021-12-20 07:50:50 --> Loader Class Initialized
INFO - 2021-12-20 07:50:50 --> Helper loaded: url_helper
INFO - 2021-12-20 07:50:50 --> Helper loaded: file_helper
INFO - 2021-12-20 07:50:50 --> Helper loaded: form_helper
INFO - 2021-12-20 07:50:50 --> Helper loaded: my_helper
INFO - 2021-12-20 07:50:50 --> Database Driver Class Initialized
DEBUG - 2021-12-20 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 07:50:50 --> Controller Class Initialized
INFO - 2021-12-20 08:09:29 --> Config Class Initialized
INFO - 2021-12-20 08:09:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:09:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:09:29 --> Utf8 Class Initialized
INFO - 2021-12-20 08:09:29 --> URI Class Initialized
INFO - 2021-12-20 08:09:29 --> Router Class Initialized
INFO - 2021-12-20 08:09:29 --> Output Class Initialized
INFO - 2021-12-20 08:09:29 --> Security Class Initialized
DEBUG - 2021-12-20 08:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:09:29 --> Input Class Initialized
INFO - 2021-12-20 08:09:29 --> Language Class Initialized
INFO - 2021-12-20 08:09:29 --> Language Class Initialized
INFO - 2021-12-20 08:09:29 --> Config Class Initialized
INFO - 2021-12-20 08:09:29 --> Loader Class Initialized
INFO - 2021-12-20 08:09:29 --> Helper loaded: url_helper
INFO - 2021-12-20 08:09:29 --> Helper loaded: file_helper
INFO - 2021-12-20 08:09:29 --> Helper loaded: form_helper
INFO - 2021-12-20 08:09:29 --> Helper loaded: my_helper
INFO - 2021-12-20 08:09:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:09:29 --> Controller Class Initialized
ERROR - 2021-12-20 08:09:29 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-20 08:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-20 08:09:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:09:29 --> Final output sent to browser
DEBUG - 2021-12-20 08:09:29 --> Total execution time: 0.0300
INFO - 2021-12-20 08:10:14 --> Config Class Initialized
INFO - 2021-12-20 08:10:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:14 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:14 --> URI Class Initialized
INFO - 2021-12-20 08:10:14 --> Router Class Initialized
INFO - 2021-12-20 08:10:14 --> Output Class Initialized
INFO - 2021-12-20 08:10:14 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:14 --> Input Class Initialized
INFO - 2021-12-20 08:10:14 --> Language Class Initialized
INFO - 2021-12-20 08:10:14 --> Language Class Initialized
INFO - 2021-12-20 08:10:14 --> Config Class Initialized
INFO - 2021-12-20 08:10:14 --> Loader Class Initialized
INFO - 2021-12-20 08:10:14 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:14 --> Controller Class Initialized
INFO - 2021-12-20 08:10:14 --> Upload Class Initialized
INFO - 2021-12-20 08:10:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-12-20 08:10:14 --> The upload path does not appear to be valid.
INFO - 2021-12-20 08:10:14 --> Config Class Initialized
INFO - 2021-12-20 08:10:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:14 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:14 --> URI Class Initialized
INFO - 2021-12-20 08:10:14 --> Router Class Initialized
INFO - 2021-12-20 08:10:14 --> Output Class Initialized
INFO - 2021-12-20 08:10:14 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:14 --> Input Class Initialized
INFO - 2021-12-20 08:10:14 --> Language Class Initialized
INFO - 2021-12-20 08:10:14 --> Language Class Initialized
INFO - 2021-12-20 08:10:14 --> Config Class Initialized
INFO - 2021-12-20 08:10:14 --> Loader Class Initialized
INFO - 2021-12-20 08:10:14 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:14 --> Controller Class Initialized
DEBUG - 2021-12-20 08:10:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 08:10:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:10:14 --> Final output sent to browser
DEBUG - 2021-12-20 08:10:14 --> Total execution time: 0.0300
INFO - 2021-12-20 08:10:14 --> Config Class Initialized
INFO - 2021-12-20 08:10:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:14 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:14 --> URI Class Initialized
INFO - 2021-12-20 08:10:14 --> Router Class Initialized
INFO - 2021-12-20 08:10:14 --> Output Class Initialized
INFO - 2021-12-20 08:10:14 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:14 --> Input Class Initialized
INFO - 2021-12-20 08:10:14 --> Language Class Initialized
INFO - 2021-12-20 08:10:14 --> Language Class Initialized
INFO - 2021-12-20 08:10:14 --> Config Class Initialized
INFO - 2021-12-20 08:10:14 --> Loader Class Initialized
INFO - 2021-12-20 08:10:14 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:14 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:14 --> Controller Class Initialized
INFO - 2021-12-20 08:10:20 --> Config Class Initialized
INFO - 2021-12-20 08:10:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:20 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:20 --> URI Class Initialized
INFO - 2021-12-20 08:10:20 --> Router Class Initialized
INFO - 2021-12-20 08:10:20 --> Output Class Initialized
INFO - 2021-12-20 08:10:20 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:20 --> Input Class Initialized
INFO - 2021-12-20 08:10:20 --> Language Class Initialized
INFO - 2021-12-20 08:10:20 --> Language Class Initialized
INFO - 2021-12-20 08:10:20 --> Config Class Initialized
INFO - 2021-12-20 08:10:20 --> Loader Class Initialized
INFO - 2021-12-20 08:10:20 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:20 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:20 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:20 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:20 --> Controller Class Initialized
DEBUG - 2021-12-20 08:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:10:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:10:20 --> Final output sent to browser
DEBUG - 2021-12-20 08:10:20 --> Total execution time: 0.0700
INFO - 2021-12-20 08:10:22 --> Config Class Initialized
INFO - 2021-12-20 08:10:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:22 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:22 --> URI Class Initialized
INFO - 2021-12-20 08:10:22 --> Router Class Initialized
INFO - 2021-12-20 08:10:22 --> Output Class Initialized
INFO - 2021-12-20 08:10:22 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:22 --> Input Class Initialized
INFO - 2021-12-20 08:10:22 --> Language Class Initialized
INFO - 2021-12-20 08:10:22 --> Language Class Initialized
INFO - 2021-12-20 08:10:22 --> Config Class Initialized
INFO - 2021-12-20 08:10:22 --> Loader Class Initialized
INFO - 2021-12-20 08:10:22 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:22 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:22 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:22 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:22 --> Controller Class Initialized
DEBUG - 2021-12-20 08:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-20 08:10:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:10:22 --> Final output sent to browser
DEBUG - 2021-12-20 08:10:22 --> Total execution time: 0.0425
INFO - 2021-12-20 08:10:22 --> Config Class Initialized
INFO - 2021-12-20 08:10:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:22 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:22 --> URI Class Initialized
INFO - 2021-12-20 08:10:22 --> Router Class Initialized
INFO - 2021-12-20 08:10:22 --> Output Class Initialized
INFO - 2021-12-20 08:10:22 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:22 --> Input Class Initialized
INFO - 2021-12-20 08:10:22 --> Language Class Initialized
INFO - 2021-12-20 08:10:22 --> Language Class Initialized
INFO - 2021-12-20 08:10:22 --> Config Class Initialized
INFO - 2021-12-20 08:10:22 --> Loader Class Initialized
INFO - 2021-12-20 08:10:22 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:22 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:22 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:22 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:22 --> Controller Class Initialized
INFO - 2021-12-20 08:10:27 --> Config Class Initialized
INFO - 2021-12-20 08:10:27 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:27 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:27 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:27 --> URI Class Initialized
INFO - 2021-12-20 08:10:27 --> Router Class Initialized
INFO - 2021-12-20 08:10:27 --> Output Class Initialized
INFO - 2021-12-20 08:10:27 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:27 --> Input Class Initialized
INFO - 2021-12-20 08:10:27 --> Language Class Initialized
INFO - 2021-12-20 08:10:27 --> Language Class Initialized
INFO - 2021-12-20 08:10:27 --> Config Class Initialized
INFO - 2021-12-20 08:10:27 --> Loader Class Initialized
INFO - 2021-12-20 08:10:27 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:27 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:27 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:27 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:27 --> Controller Class Initialized
DEBUG - 2021-12-20 08:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:10:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:10:27 --> Final output sent to browser
DEBUG - 2021-12-20 08:10:27 --> Total execution time: 0.0575
INFO - 2021-12-20 08:10:35 --> Config Class Initialized
INFO - 2021-12-20 08:10:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:35 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:35 --> URI Class Initialized
INFO - 2021-12-20 08:10:35 --> Router Class Initialized
INFO - 2021-12-20 08:10:35 --> Output Class Initialized
INFO - 2021-12-20 08:10:35 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:35 --> Input Class Initialized
INFO - 2021-12-20 08:10:35 --> Language Class Initialized
INFO - 2021-12-20 08:10:35 --> Language Class Initialized
INFO - 2021-12-20 08:10:35 --> Config Class Initialized
INFO - 2021-12-20 08:10:35 --> Loader Class Initialized
INFO - 2021-12-20 08:10:35 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:35 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:35 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:35 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:35 --> Controller Class Initialized
DEBUG - 2021-12-20 08:10:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:10:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:10:35 --> Final output sent to browser
DEBUG - 2021-12-20 08:10:35 --> Total execution time: 0.0350
INFO - 2021-12-20 08:10:43 --> Config Class Initialized
INFO - 2021-12-20 08:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:43 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:43 --> URI Class Initialized
INFO - 2021-12-20 08:10:43 --> Router Class Initialized
INFO - 2021-12-20 08:10:43 --> Output Class Initialized
INFO - 2021-12-20 08:10:43 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:43 --> Input Class Initialized
INFO - 2021-12-20 08:10:43 --> Language Class Initialized
INFO - 2021-12-20 08:10:43 --> Language Class Initialized
INFO - 2021-12-20 08:10:43 --> Config Class Initialized
INFO - 2021-12-20 08:10:43 --> Loader Class Initialized
INFO - 2021-12-20 08:10:43 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:43 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:43 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:43 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:43 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:43 --> Controller Class Initialized
DEBUG - 2021-12-20 08:10:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-20 08:10:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:10:43 --> Final output sent to browser
DEBUG - 2021-12-20 08:10:43 --> Total execution time: 0.0450
INFO - 2021-12-20 08:10:43 --> Config Class Initialized
INFO - 2021-12-20 08:10:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:43 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:43 --> URI Class Initialized
INFO - 2021-12-20 08:10:43 --> Router Class Initialized
INFO - 2021-12-20 08:10:43 --> Output Class Initialized
INFO - 2021-12-20 08:10:43 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:43 --> Input Class Initialized
INFO - 2021-12-20 08:10:43 --> Language Class Initialized
INFO - 2021-12-20 08:10:43 --> Language Class Initialized
INFO - 2021-12-20 08:10:43 --> Config Class Initialized
INFO - 2021-12-20 08:10:43 --> Loader Class Initialized
INFO - 2021-12-20 08:10:43 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:43 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:43 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:43 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:43 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:43 --> Controller Class Initialized
INFO - 2021-12-20 08:10:44 --> Config Class Initialized
INFO - 2021-12-20 08:10:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:44 --> URI Class Initialized
INFO - 2021-12-20 08:10:44 --> Router Class Initialized
INFO - 2021-12-20 08:10:44 --> Output Class Initialized
INFO - 2021-12-20 08:10:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:44 --> Input Class Initialized
INFO - 2021-12-20 08:10:44 --> Language Class Initialized
INFO - 2021-12-20 08:10:44 --> Language Class Initialized
INFO - 2021-12-20 08:10:44 --> Config Class Initialized
INFO - 2021-12-20 08:10:44 --> Loader Class Initialized
INFO - 2021-12-20 08:10:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:44 --> Controller Class Initialized
DEBUG - 2021-12-20 08:10:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 08:10:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:10:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:10:44 --> Total execution time: 0.0350
INFO - 2021-12-20 08:10:44 --> Config Class Initialized
INFO - 2021-12-20 08:10:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:10:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:10:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:10:44 --> URI Class Initialized
INFO - 2021-12-20 08:10:44 --> Router Class Initialized
INFO - 2021-12-20 08:10:44 --> Output Class Initialized
INFO - 2021-12-20 08:10:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:10:44 --> Input Class Initialized
INFO - 2021-12-20 08:10:44 --> Language Class Initialized
INFO - 2021-12-20 08:10:44 --> Language Class Initialized
INFO - 2021-12-20 08:10:44 --> Config Class Initialized
INFO - 2021-12-20 08:10:44 --> Loader Class Initialized
INFO - 2021-12-20 08:10:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:10:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:10:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:10:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:10:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:10:44 --> Controller Class Initialized
INFO - 2021-12-20 08:21:27 --> Config Class Initialized
INFO - 2021-12-20 08:21:27 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:27 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:27 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:27 --> URI Class Initialized
DEBUG - 2021-12-20 08:21:27 --> No URI present. Default controller set.
INFO - 2021-12-20 08:21:27 --> Router Class Initialized
INFO - 2021-12-20 08:21:27 --> Output Class Initialized
INFO - 2021-12-20 08:21:27 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:27 --> Input Class Initialized
INFO - 2021-12-20 08:21:27 --> Language Class Initialized
INFO - 2021-12-20 08:21:27 --> Language Class Initialized
INFO - 2021-12-20 08:21:27 --> Config Class Initialized
INFO - 2021-12-20 08:21:27 --> Loader Class Initialized
INFO - 2021-12-20 08:21:27 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:27 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:27 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:27 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:27 --> Controller Class Initialized
DEBUG - 2021-12-20 08:21:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 08:21:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:21:27 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:27 --> Total execution time: 0.2200
INFO - 2021-12-20 08:21:30 --> Config Class Initialized
INFO - 2021-12-20 08:21:30 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:30 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:30 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:30 --> URI Class Initialized
INFO - 2021-12-20 08:21:30 --> Router Class Initialized
INFO - 2021-12-20 08:21:30 --> Output Class Initialized
INFO - 2021-12-20 08:21:30 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:30 --> Input Class Initialized
INFO - 2021-12-20 08:21:30 --> Language Class Initialized
INFO - 2021-12-20 08:21:30 --> Language Class Initialized
INFO - 2021-12-20 08:21:30 --> Config Class Initialized
INFO - 2021-12-20 08:21:30 --> Loader Class Initialized
INFO - 2021-12-20 08:21:30 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:30 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:30 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:30 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:30 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:30 --> Controller Class Initialized
DEBUG - 2021-12-20 08:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:21:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:21:30 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:30 --> Total execution time: 0.0600
INFO - 2021-12-20 08:21:42 --> Config Class Initialized
INFO - 2021-12-20 08:21:42 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:42 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:42 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:42 --> URI Class Initialized
INFO - 2021-12-20 08:21:42 --> Router Class Initialized
INFO - 2021-12-20 08:21:42 --> Output Class Initialized
INFO - 2021-12-20 08:21:42 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:42 --> Input Class Initialized
INFO - 2021-12-20 08:21:42 --> Language Class Initialized
INFO - 2021-12-20 08:21:42 --> Language Class Initialized
INFO - 2021-12-20 08:21:42 --> Config Class Initialized
INFO - 2021-12-20 08:21:42 --> Loader Class Initialized
INFO - 2021-12-20 08:21:42 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:42 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:42 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:42 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:42 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:42 --> Controller Class Initialized
INFO - 2021-12-20 08:21:42 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:42 --> Total execution time: 0.0525
INFO - 2021-12-20 08:21:44 --> Config Class Initialized
INFO - 2021-12-20 08:21:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:44 --> URI Class Initialized
INFO - 2021-12-20 08:21:44 --> Router Class Initialized
INFO - 2021-12-20 08:21:44 --> Output Class Initialized
INFO - 2021-12-20 08:21:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:44 --> Input Class Initialized
INFO - 2021-12-20 08:21:44 --> Language Class Initialized
INFO - 2021-12-20 08:21:44 --> Language Class Initialized
INFO - 2021-12-20 08:21:44 --> Config Class Initialized
INFO - 2021-12-20 08:21:44 --> Loader Class Initialized
INFO - 2021-12-20 08:21:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:44 --> Controller Class Initialized
INFO - 2021-12-20 08:21:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:44 --> Total execution time: 0.0400
INFO - 2021-12-20 08:21:45 --> Config Class Initialized
INFO - 2021-12-20 08:21:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:45 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:45 --> URI Class Initialized
INFO - 2021-12-20 08:21:45 --> Router Class Initialized
INFO - 2021-12-20 08:21:45 --> Output Class Initialized
INFO - 2021-12-20 08:21:45 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:45 --> Input Class Initialized
INFO - 2021-12-20 08:21:45 --> Language Class Initialized
INFO - 2021-12-20 08:21:45 --> Language Class Initialized
INFO - 2021-12-20 08:21:45 --> Config Class Initialized
INFO - 2021-12-20 08:21:45 --> Loader Class Initialized
INFO - 2021-12-20 08:21:45 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:45 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:45 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:45 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:45 --> Controller Class Initialized
INFO - 2021-12-20 08:21:45 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:45 --> Total execution time: 0.0375
INFO - 2021-12-20 08:21:46 --> Config Class Initialized
INFO - 2021-12-20 08:21:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:46 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:46 --> URI Class Initialized
INFO - 2021-12-20 08:21:46 --> Router Class Initialized
INFO - 2021-12-20 08:21:46 --> Output Class Initialized
INFO - 2021-12-20 08:21:46 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:46 --> Input Class Initialized
INFO - 2021-12-20 08:21:46 --> Language Class Initialized
INFO - 2021-12-20 08:21:46 --> Language Class Initialized
INFO - 2021-12-20 08:21:46 --> Config Class Initialized
INFO - 2021-12-20 08:21:46 --> Loader Class Initialized
INFO - 2021-12-20 08:21:46 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:46 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:46 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:46 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:46 --> Controller Class Initialized
INFO - 2021-12-20 08:21:46 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:46 --> Total execution time: 0.0300
INFO - 2021-12-20 08:21:47 --> Config Class Initialized
INFO - 2021-12-20 08:21:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:47 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:47 --> URI Class Initialized
INFO - 2021-12-20 08:21:47 --> Router Class Initialized
INFO - 2021-12-20 08:21:47 --> Output Class Initialized
INFO - 2021-12-20 08:21:47 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:47 --> Input Class Initialized
INFO - 2021-12-20 08:21:47 --> Language Class Initialized
INFO - 2021-12-20 08:21:47 --> Language Class Initialized
INFO - 2021-12-20 08:21:47 --> Config Class Initialized
INFO - 2021-12-20 08:21:47 --> Loader Class Initialized
INFO - 2021-12-20 08:21:47 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:47 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:47 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:47 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:47 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:47 --> Controller Class Initialized
INFO - 2021-12-20 08:21:47 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:47 --> Total execution time: 0.0300
INFO - 2021-12-20 08:21:47 --> Config Class Initialized
INFO - 2021-12-20 08:21:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:47 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:47 --> URI Class Initialized
INFO - 2021-12-20 08:21:47 --> Router Class Initialized
INFO - 2021-12-20 08:21:47 --> Output Class Initialized
INFO - 2021-12-20 08:21:47 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:47 --> Input Class Initialized
INFO - 2021-12-20 08:21:47 --> Language Class Initialized
INFO - 2021-12-20 08:21:47 --> Language Class Initialized
INFO - 2021-12-20 08:21:47 --> Config Class Initialized
INFO - 2021-12-20 08:21:47 --> Loader Class Initialized
INFO - 2021-12-20 08:21:47 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:47 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:47 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:47 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:47 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:47 --> Controller Class Initialized
INFO - 2021-12-20 08:21:47 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:47 --> Total execution time: 0.0450
INFO - 2021-12-20 08:21:50 --> Config Class Initialized
INFO - 2021-12-20 08:21:50 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:50 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:50 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:50 --> URI Class Initialized
INFO - 2021-12-20 08:21:50 --> Router Class Initialized
INFO - 2021-12-20 08:21:50 --> Output Class Initialized
INFO - 2021-12-20 08:21:50 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:50 --> Input Class Initialized
INFO - 2021-12-20 08:21:50 --> Language Class Initialized
INFO - 2021-12-20 08:21:50 --> Language Class Initialized
INFO - 2021-12-20 08:21:50 --> Config Class Initialized
INFO - 2021-12-20 08:21:50 --> Loader Class Initialized
INFO - 2021-12-20 08:21:50 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:50 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:50 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:50 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:50 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:50 --> Controller Class Initialized
INFO - 2021-12-20 08:21:50 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:50 --> Total execution time: 0.0400
INFO - 2021-12-20 08:21:51 --> Config Class Initialized
INFO - 2021-12-20 08:21:51 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:51 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:51 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:51 --> URI Class Initialized
INFO - 2021-12-20 08:21:51 --> Router Class Initialized
INFO - 2021-12-20 08:21:51 --> Output Class Initialized
INFO - 2021-12-20 08:21:51 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:51 --> Input Class Initialized
INFO - 2021-12-20 08:21:51 --> Language Class Initialized
INFO - 2021-12-20 08:21:51 --> Language Class Initialized
INFO - 2021-12-20 08:21:51 --> Config Class Initialized
INFO - 2021-12-20 08:21:51 --> Loader Class Initialized
INFO - 2021-12-20 08:21:51 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:51 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:51 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:51 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:51 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:51 --> Controller Class Initialized
INFO - 2021-12-20 08:21:51 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:51 --> Total execution time: 0.0450
INFO - 2021-12-20 08:21:51 --> Config Class Initialized
INFO - 2021-12-20 08:21:51 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:51 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:51 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:51 --> URI Class Initialized
INFO - 2021-12-20 08:21:51 --> Router Class Initialized
INFO - 2021-12-20 08:21:51 --> Output Class Initialized
INFO - 2021-12-20 08:21:51 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:51 --> Input Class Initialized
INFO - 2021-12-20 08:21:51 --> Language Class Initialized
INFO - 2021-12-20 08:21:51 --> Language Class Initialized
INFO - 2021-12-20 08:21:51 --> Config Class Initialized
INFO - 2021-12-20 08:21:51 --> Loader Class Initialized
INFO - 2021-12-20 08:21:51 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:51 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:51 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:51 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:51 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:52 --> Controller Class Initialized
INFO - 2021-12-20 08:21:52 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:52 --> Total execution time: 0.0425
INFO - 2021-12-20 08:21:52 --> Config Class Initialized
INFO - 2021-12-20 08:21:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:52 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:52 --> URI Class Initialized
INFO - 2021-12-20 08:21:52 --> Router Class Initialized
INFO - 2021-12-20 08:21:52 --> Output Class Initialized
INFO - 2021-12-20 08:21:52 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:52 --> Input Class Initialized
INFO - 2021-12-20 08:21:52 --> Language Class Initialized
INFO - 2021-12-20 08:21:52 --> Language Class Initialized
INFO - 2021-12-20 08:21:52 --> Config Class Initialized
INFO - 2021-12-20 08:21:52 --> Loader Class Initialized
INFO - 2021-12-20 08:21:52 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:52 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:52 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:52 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:52 --> Controller Class Initialized
INFO - 2021-12-20 08:21:52 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:52 --> Total execution time: 0.0450
INFO - 2021-12-20 08:21:53 --> Config Class Initialized
INFO - 2021-12-20 08:21:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:53 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:53 --> URI Class Initialized
INFO - 2021-12-20 08:21:53 --> Router Class Initialized
INFO - 2021-12-20 08:21:53 --> Output Class Initialized
INFO - 2021-12-20 08:21:53 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:53 --> Input Class Initialized
INFO - 2021-12-20 08:21:53 --> Language Class Initialized
INFO - 2021-12-20 08:21:53 --> Language Class Initialized
INFO - 2021-12-20 08:21:53 --> Config Class Initialized
INFO - 2021-12-20 08:21:53 --> Loader Class Initialized
INFO - 2021-12-20 08:21:53 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:53 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:53 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:53 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:53 --> Controller Class Initialized
INFO - 2021-12-20 08:21:53 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:53 --> Total execution time: 0.0425
INFO - 2021-12-20 08:21:56 --> Config Class Initialized
INFO - 2021-12-20 08:21:56 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:56 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:56 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:56 --> URI Class Initialized
INFO - 2021-12-20 08:21:56 --> Router Class Initialized
INFO - 2021-12-20 08:21:56 --> Output Class Initialized
INFO - 2021-12-20 08:21:56 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:56 --> Input Class Initialized
INFO - 2021-12-20 08:21:56 --> Language Class Initialized
INFO - 2021-12-20 08:21:56 --> Language Class Initialized
INFO - 2021-12-20 08:21:56 --> Config Class Initialized
INFO - 2021-12-20 08:21:56 --> Loader Class Initialized
INFO - 2021-12-20 08:21:56 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:56 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:56 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:56 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:56 --> Controller Class Initialized
INFO - 2021-12-20 08:21:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:56 --> Total execution time: 0.0400
INFO - 2021-12-20 08:21:57 --> Config Class Initialized
INFO - 2021-12-20 08:21:57 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:57 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:57 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:57 --> URI Class Initialized
INFO - 2021-12-20 08:21:57 --> Router Class Initialized
INFO - 2021-12-20 08:21:57 --> Output Class Initialized
INFO - 2021-12-20 08:21:57 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:57 --> Input Class Initialized
INFO - 2021-12-20 08:21:57 --> Language Class Initialized
INFO - 2021-12-20 08:21:57 --> Language Class Initialized
INFO - 2021-12-20 08:21:57 --> Config Class Initialized
INFO - 2021-12-20 08:21:57 --> Loader Class Initialized
INFO - 2021-12-20 08:21:57 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:57 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:57 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:57 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:57 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:57 --> Controller Class Initialized
INFO - 2021-12-20 08:21:57 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:57 --> Total execution time: 0.0400
INFO - 2021-12-20 08:21:57 --> Config Class Initialized
INFO - 2021-12-20 08:21:57 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:57 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:57 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:57 --> URI Class Initialized
INFO - 2021-12-20 08:21:57 --> Router Class Initialized
INFO - 2021-12-20 08:21:57 --> Output Class Initialized
INFO - 2021-12-20 08:21:57 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:57 --> Input Class Initialized
INFO - 2021-12-20 08:21:57 --> Language Class Initialized
INFO - 2021-12-20 08:21:57 --> Language Class Initialized
INFO - 2021-12-20 08:21:57 --> Config Class Initialized
INFO - 2021-12-20 08:21:57 --> Loader Class Initialized
INFO - 2021-12-20 08:21:57 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:57 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:57 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:57 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:57 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:57 --> Controller Class Initialized
INFO - 2021-12-20 08:21:57 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:57 --> Total execution time: 0.0300
INFO - 2021-12-20 08:21:58 --> Config Class Initialized
INFO - 2021-12-20 08:21:58 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:58 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:58 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:58 --> URI Class Initialized
INFO - 2021-12-20 08:21:58 --> Router Class Initialized
INFO - 2021-12-20 08:21:58 --> Output Class Initialized
INFO - 2021-12-20 08:21:58 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:58 --> Input Class Initialized
INFO - 2021-12-20 08:21:58 --> Language Class Initialized
INFO - 2021-12-20 08:21:58 --> Language Class Initialized
INFO - 2021-12-20 08:21:58 --> Config Class Initialized
INFO - 2021-12-20 08:21:58 --> Loader Class Initialized
INFO - 2021-12-20 08:21:58 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:58 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:58 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:58 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:58 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:58 --> Controller Class Initialized
INFO - 2021-12-20 08:21:58 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:58 --> Total execution time: 0.0400
INFO - 2021-12-20 08:21:59 --> Config Class Initialized
INFO - 2021-12-20 08:21:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:21:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:21:59 --> Utf8 Class Initialized
INFO - 2021-12-20 08:21:59 --> URI Class Initialized
INFO - 2021-12-20 08:21:59 --> Router Class Initialized
INFO - 2021-12-20 08:21:59 --> Output Class Initialized
INFO - 2021-12-20 08:21:59 --> Security Class Initialized
DEBUG - 2021-12-20 08:21:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:21:59 --> Input Class Initialized
INFO - 2021-12-20 08:21:59 --> Language Class Initialized
INFO - 2021-12-20 08:21:59 --> Language Class Initialized
INFO - 2021-12-20 08:21:59 --> Config Class Initialized
INFO - 2021-12-20 08:21:59 --> Loader Class Initialized
INFO - 2021-12-20 08:21:59 --> Helper loaded: url_helper
INFO - 2021-12-20 08:21:59 --> Helper loaded: file_helper
INFO - 2021-12-20 08:21:59 --> Helper loaded: form_helper
INFO - 2021-12-20 08:21:59 --> Helper loaded: my_helper
INFO - 2021-12-20 08:21:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:21:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:21:59 --> Controller Class Initialized
INFO - 2021-12-20 08:21:59 --> Final output sent to browser
DEBUG - 2021-12-20 08:21:59 --> Total execution time: 0.0400
INFO - 2021-12-20 08:22:00 --> Config Class Initialized
INFO - 2021-12-20 08:22:00 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:00 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:00 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:00 --> URI Class Initialized
INFO - 2021-12-20 08:22:00 --> Router Class Initialized
INFO - 2021-12-20 08:22:00 --> Output Class Initialized
INFO - 2021-12-20 08:22:00 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:00 --> Input Class Initialized
INFO - 2021-12-20 08:22:00 --> Language Class Initialized
INFO - 2021-12-20 08:22:00 --> Language Class Initialized
INFO - 2021-12-20 08:22:00 --> Config Class Initialized
INFO - 2021-12-20 08:22:00 --> Loader Class Initialized
INFO - 2021-12-20 08:22:00 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:00 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:00 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:00 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:00 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:00 --> Controller Class Initialized
INFO - 2021-12-20 08:22:00 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:00 --> Total execution time: 0.0300
INFO - 2021-12-20 08:22:01 --> Config Class Initialized
INFO - 2021-12-20 08:22:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:01 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:01 --> URI Class Initialized
INFO - 2021-12-20 08:22:01 --> Router Class Initialized
INFO - 2021-12-20 08:22:01 --> Output Class Initialized
INFO - 2021-12-20 08:22:01 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:01 --> Input Class Initialized
INFO - 2021-12-20 08:22:01 --> Language Class Initialized
INFO - 2021-12-20 08:22:01 --> Language Class Initialized
INFO - 2021-12-20 08:22:01 --> Config Class Initialized
INFO - 2021-12-20 08:22:01 --> Loader Class Initialized
INFO - 2021-12-20 08:22:01 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:01 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:01 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:01 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:01 --> Controller Class Initialized
INFO - 2021-12-20 08:22:01 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:01 --> Total execution time: 0.0300
INFO - 2021-12-20 08:22:03 --> Config Class Initialized
INFO - 2021-12-20 08:22:03 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:03 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:03 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:03 --> URI Class Initialized
INFO - 2021-12-20 08:22:03 --> Router Class Initialized
INFO - 2021-12-20 08:22:03 --> Output Class Initialized
INFO - 2021-12-20 08:22:03 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:03 --> Input Class Initialized
INFO - 2021-12-20 08:22:03 --> Language Class Initialized
INFO - 2021-12-20 08:22:03 --> Language Class Initialized
INFO - 2021-12-20 08:22:03 --> Config Class Initialized
INFO - 2021-12-20 08:22:03 --> Loader Class Initialized
INFO - 2021-12-20 08:22:03 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:03 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:03 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:03 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:03 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:03 --> Controller Class Initialized
INFO - 2021-12-20 08:22:03 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:03 --> Total execution time: 0.0300
INFO - 2021-12-20 08:22:04 --> Config Class Initialized
INFO - 2021-12-20 08:22:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:04 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:04 --> URI Class Initialized
INFO - 2021-12-20 08:22:04 --> Router Class Initialized
INFO - 2021-12-20 08:22:04 --> Output Class Initialized
INFO - 2021-12-20 08:22:04 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:04 --> Input Class Initialized
INFO - 2021-12-20 08:22:04 --> Language Class Initialized
INFO - 2021-12-20 08:22:04 --> Language Class Initialized
INFO - 2021-12-20 08:22:04 --> Config Class Initialized
INFO - 2021-12-20 08:22:04 --> Loader Class Initialized
INFO - 2021-12-20 08:22:04 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:04 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:04 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:04 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:04 --> Controller Class Initialized
INFO - 2021-12-20 08:22:04 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:04 --> Total execution time: 0.0300
INFO - 2021-12-20 08:22:05 --> Config Class Initialized
INFO - 2021-12-20 08:22:05 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:05 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:05 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:05 --> URI Class Initialized
INFO - 2021-12-20 08:22:05 --> Router Class Initialized
INFO - 2021-12-20 08:22:05 --> Output Class Initialized
INFO - 2021-12-20 08:22:05 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:05 --> Input Class Initialized
INFO - 2021-12-20 08:22:05 --> Language Class Initialized
INFO - 2021-12-20 08:22:05 --> Language Class Initialized
INFO - 2021-12-20 08:22:05 --> Config Class Initialized
INFO - 2021-12-20 08:22:05 --> Loader Class Initialized
INFO - 2021-12-20 08:22:05 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:05 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:05 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:05 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:05 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:05 --> Controller Class Initialized
DEBUG - 2021-12-20 08:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:22:05 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:05 --> Total execution time: 0.0500
INFO - 2021-12-20 08:22:08 --> Config Class Initialized
INFO - 2021-12-20 08:22:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:08 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:08 --> URI Class Initialized
INFO - 2021-12-20 08:22:08 --> Router Class Initialized
INFO - 2021-12-20 08:22:08 --> Output Class Initialized
INFO - 2021-12-20 08:22:08 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:08 --> Input Class Initialized
INFO - 2021-12-20 08:22:08 --> Language Class Initialized
INFO - 2021-12-20 08:22:08 --> Language Class Initialized
INFO - 2021-12-20 08:22:08 --> Config Class Initialized
INFO - 2021-12-20 08:22:08 --> Loader Class Initialized
INFO - 2021-12-20 08:22:08 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:08 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:08 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:08 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:08 --> Controller Class Initialized
INFO - 2021-12-20 08:22:08 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:08 --> Total execution time: 0.0410
INFO - 2021-12-20 08:22:09 --> Config Class Initialized
INFO - 2021-12-20 08:22:09 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:09 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:09 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:09 --> URI Class Initialized
INFO - 2021-12-20 08:22:09 --> Router Class Initialized
INFO - 2021-12-20 08:22:09 --> Output Class Initialized
INFO - 2021-12-20 08:22:09 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:09 --> Input Class Initialized
INFO - 2021-12-20 08:22:09 --> Language Class Initialized
INFO - 2021-12-20 08:22:09 --> Language Class Initialized
INFO - 2021-12-20 08:22:09 --> Config Class Initialized
INFO - 2021-12-20 08:22:09 --> Loader Class Initialized
INFO - 2021-12-20 08:22:09 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:09 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:09 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:09 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:09 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:09 --> Controller Class Initialized
INFO - 2021-12-20 08:22:09 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:09 --> Total execution time: 0.0430
INFO - 2021-12-20 08:22:11 --> Config Class Initialized
INFO - 2021-12-20 08:22:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:11 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:11 --> URI Class Initialized
INFO - 2021-12-20 08:22:11 --> Router Class Initialized
INFO - 2021-12-20 08:22:11 --> Output Class Initialized
INFO - 2021-12-20 08:22:11 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:11 --> Input Class Initialized
INFO - 2021-12-20 08:22:11 --> Language Class Initialized
INFO - 2021-12-20 08:22:11 --> Language Class Initialized
INFO - 2021-12-20 08:22:11 --> Config Class Initialized
INFO - 2021-12-20 08:22:11 --> Loader Class Initialized
INFO - 2021-12-20 08:22:11 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:11 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:11 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:11 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:11 --> Controller Class Initialized
INFO - 2021-12-20 08:22:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:11 --> Total execution time: 0.0430
INFO - 2021-12-20 08:22:23 --> Config Class Initialized
INFO - 2021-12-20 08:22:23 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:23 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:23 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:23 --> URI Class Initialized
INFO - 2021-12-20 08:22:23 --> Router Class Initialized
INFO - 2021-12-20 08:22:23 --> Output Class Initialized
INFO - 2021-12-20 08:22:23 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:23 --> Input Class Initialized
INFO - 2021-12-20 08:22:23 --> Language Class Initialized
INFO - 2021-12-20 08:22:23 --> Language Class Initialized
INFO - 2021-12-20 08:22:23 --> Config Class Initialized
INFO - 2021-12-20 08:22:23 --> Loader Class Initialized
INFO - 2021-12-20 08:22:23 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:23 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:23 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:23 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:23 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:23 --> Controller Class Initialized
DEBUG - 2021-12-20 08:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:22:23 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:23 --> Total execution time: 0.0570
INFO - 2021-12-20 08:22:28 --> Config Class Initialized
INFO - 2021-12-20 08:22:28 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:28 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:28 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:28 --> URI Class Initialized
INFO - 2021-12-20 08:22:28 --> Router Class Initialized
INFO - 2021-12-20 08:22:28 --> Output Class Initialized
INFO - 2021-12-20 08:22:28 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:28 --> Input Class Initialized
INFO - 2021-12-20 08:22:28 --> Language Class Initialized
INFO - 2021-12-20 08:22:28 --> Language Class Initialized
INFO - 2021-12-20 08:22:28 --> Config Class Initialized
INFO - 2021-12-20 08:22:28 --> Loader Class Initialized
INFO - 2021-12-20 08:22:28 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:28 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:28 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:28 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:28 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:28 --> Controller Class Initialized
DEBUG - 2021-12-20 08:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:22:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:22:28 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:28 --> Total execution time: 0.0550
INFO - 2021-12-20 08:22:31 --> Config Class Initialized
INFO - 2021-12-20 08:22:31 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:22:31 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:22:31 --> Utf8 Class Initialized
INFO - 2021-12-20 08:22:31 --> URI Class Initialized
INFO - 2021-12-20 08:22:31 --> Router Class Initialized
INFO - 2021-12-20 08:22:31 --> Output Class Initialized
INFO - 2021-12-20 08:22:31 --> Security Class Initialized
DEBUG - 2021-12-20 08:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:22:31 --> Input Class Initialized
INFO - 2021-12-20 08:22:31 --> Language Class Initialized
INFO - 2021-12-20 08:22:31 --> Language Class Initialized
INFO - 2021-12-20 08:22:31 --> Config Class Initialized
INFO - 2021-12-20 08:22:31 --> Loader Class Initialized
INFO - 2021-12-20 08:22:31 --> Helper loaded: url_helper
INFO - 2021-12-20 08:22:31 --> Helper loaded: file_helper
INFO - 2021-12-20 08:22:31 --> Helper loaded: form_helper
INFO - 2021-12-20 08:22:31 --> Helper loaded: my_helper
INFO - 2021-12-20 08:22:31 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:22:31 --> Controller Class Initialized
DEBUG - 2021-12-20 08:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:22:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:22:31 --> Final output sent to browser
DEBUG - 2021-12-20 08:22:31 --> Total execution time: 0.0570
INFO - 2021-12-20 08:23:08 --> Config Class Initialized
INFO - 2021-12-20 08:23:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:08 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:08 --> URI Class Initialized
INFO - 2021-12-20 08:23:08 --> Router Class Initialized
INFO - 2021-12-20 08:23:08 --> Output Class Initialized
INFO - 2021-12-20 08:23:08 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:08 --> Input Class Initialized
INFO - 2021-12-20 08:23:08 --> Language Class Initialized
INFO - 2021-12-20 08:23:08 --> Language Class Initialized
INFO - 2021-12-20 08:23:08 --> Config Class Initialized
INFO - 2021-12-20 08:23:08 --> Loader Class Initialized
INFO - 2021-12-20 08:23:08 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:08 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:08 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:08 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:08 --> Controller Class Initialized
DEBUG - 2021-12-20 08:23:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:23:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:23:08 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:08 --> Total execution time: 0.0600
INFO - 2021-12-20 08:23:11 --> Config Class Initialized
INFO - 2021-12-20 08:23:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:11 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:11 --> URI Class Initialized
INFO - 2021-12-20 08:23:11 --> Router Class Initialized
INFO - 2021-12-20 08:23:11 --> Output Class Initialized
INFO - 2021-12-20 08:23:11 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:11 --> Input Class Initialized
INFO - 2021-12-20 08:23:11 --> Language Class Initialized
INFO - 2021-12-20 08:23:11 --> Language Class Initialized
INFO - 2021-12-20 08:23:11 --> Config Class Initialized
INFO - 2021-12-20 08:23:11 --> Loader Class Initialized
INFO - 2021-12-20 08:23:11 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:11 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:11 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:11 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:11 --> Controller Class Initialized
DEBUG - 2021-12-20 08:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:23:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:11 --> Total execution time: 0.0470
INFO - 2021-12-20 08:23:13 --> Config Class Initialized
INFO - 2021-12-20 08:23:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:13 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:13 --> URI Class Initialized
INFO - 2021-12-20 08:23:13 --> Router Class Initialized
INFO - 2021-12-20 08:23:13 --> Output Class Initialized
INFO - 2021-12-20 08:23:13 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:13 --> Input Class Initialized
INFO - 2021-12-20 08:23:13 --> Language Class Initialized
INFO - 2021-12-20 08:23:13 --> Language Class Initialized
INFO - 2021-12-20 08:23:13 --> Config Class Initialized
INFO - 2021-12-20 08:23:13 --> Loader Class Initialized
INFO - 2021-12-20 08:23:13 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:13 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:13 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:13 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:13 --> Controller Class Initialized
DEBUG - 2021-12-20 08:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:23:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:23:13 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:13 --> Total execution time: 0.0530
INFO - 2021-12-20 08:23:19 --> Config Class Initialized
INFO - 2021-12-20 08:23:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:19 --> URI Class Initialized
INFO - 2021-12-20 08:23:19 --> Router Class Initialized
INFO - 2021-12-20 08:23:19 --> Output Class Initialized
INFO - 2021-12-20 08:23:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:19 --> Input Class Initialized
INFO - 2021-12-20 08:23:19 --> Language Class Initialized
INFO - 2021-12-20 08:23:19 --> Language Class Initialized
INFO - 2021-12-20 08:23:19 --> Config Class Initialized
INFO - 2021-12-20 08:23:19 --> Loader Class Initialized
INFO - 2021-12-20 08:23:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:19 --> Controller Class Initialized
DEBUG - 2021-12-20 08:23:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:23:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:23:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:19 --> Total execution time: 0.0500
INFO - 2021-12-20 08:23:38 --> Config Class Initialized
INFO - 2021-12-20 08:23:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:38 --> URI Class Initialized
DEBUG - 2021-12-20 08:23:38 --> No URI present. Default controller set.
INFO - 2021-12-20 08:23:38 --> Router Class Initialized
INFO - 2021-12-20 08:23:38 --> Output Class Initialized
INFO - 2021-12-20 08:23:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:38 --> Input Class Initialized
INFO - 2021-12-20 08:23:38 --> Language Class Initialized
INFO - 2021-12-20 08:23:38 --> Language Class Initialized
INFO - 2021-12-20 08:23:38 --> Config Class Initialized
INFO - 2021-12-20 08:23:38 --> Loader Class Initialized
INFO - 2021-12-20 08:23:38 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:38 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:38 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:38 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:38 --> Controller Class Initialized
INFO - 2021-12-20 08:23:38 --> Config Class Initialized
INFO - 2021-12-20 08:23:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:38 --> URI Class Initialized
INFO - 2021-12-20 08:23:38 --> Router Class Initialized
INFO - 2021-12-20 08:23:38 --> Output Class Initialized
INFO - 2021-12-20 08:23:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:38 --> Input Class Initialized
INFO - 2021-12-20 08:23:38 --> Language Class Initialized
INFO - 2021-12-20 08:23:38 --> Language Class Initialized
INFO - 2021-12-20 08:23:38 --> Config Class Initialized
INFO - 2021-12-20 08:23:38 --> Loader Class Initialized
INFO - 2021-12-20 08:23:38 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:38 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:38 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:38 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:38 --> Controller Class Initialized
DEBUG - 2021-12-20 08:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 08:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:23:38 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:38 --> Total execution time: 0.0360
INFO - 2021-12-20 08:23:43 --> Config Class Initialized
INFO - 2021-12-20 08:23:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:43 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:43 --> URI Class Initialized
INFO - 2021-12-20 08:23:43 --> Router Class Initialized
INFO - 2021-12-20 08:23:43 --> Output Class Initialized
INFO - 2021-12-20 08:23:43 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:43 --> Input Class Initialized
INFO - 2021-12-20 08:23:43 --> Language Class Initialized
INFO - 2021-12-20 08:23:43 --> Language Class Initialized
INFO - 2021-12-20 08:23:43 --> Config Class Initialized
INFO - 2021-12-20 08:23:43 --> Loader Class Initialized
INFO - 2021-12-20 08:23:43 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:43 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:43 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:43 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:43 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:43 --> Controller Class Initialized
INFO - 2021-12-20 08:23:43 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:43 --> Total execution time: 0.0590
INFO - 2021-12-20 08:23:46 --> Config Class Initialized
INFO - 2021-12-20 08:23:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:46 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:46 --> URI Class Initialized
INFO - 2021-12-20 08:23:46 --> Router Class Initialized
INFO - 2021-12-20 08:23:46 --> Output Class Initialized
INFO - 2021-12-20 08:23:46 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:46 --> Input Class Initialized
INFO - 2021-12-20 08:23:46 --> Language Class Initialized
INFO - 2021-12-20 08:23:46 --> Language Class Initialized
INFO - 2021-12-20 08:23:46 --> Config Class Initialized
INFO - 2021-12-20 08:23:46 --> Loader Class Initialized
INFO - 2021-12-20 08:23:46 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:46 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:46 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:46 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:46 --> Controller Class Initialized
INFO - 2021-12-20 08:23:46 --> Helper loaded: cookie_helper
INFO - 2021-12-20 08:23:46 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:46 --> Total execution time: 0.0460
INFO - 2021-12-20 08:23:47 --> Config Class Initialized
INFO - 2021-12-20 08:23:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:47 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:47 --> URI Class Initialized
INFO - 2021-12-20 08:23:47 --> Router Class Initialized
INFO - 2021-12-20 08:23:47 --> Output Class Initialized
INFO - 2021-12-20 08:23:47 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:47 --> Input Class Initialized
INFO - 2021-12-20 08:23:47 --> Language Class Initialized
INFO - 2021-12-20 08:23:47 --> Language Class Initialized
INFO - 2021-12-20 08:23:47 --> Config Class Initialized
INFO - 2021-12-20 08:23:47 --> Loader Class Initialized
INFO - 2021-12-20 08:23:47 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:47 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:47 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:47 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:47 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:47 --> Controller Class Initialized
DEBUG - 2021-12-20 08:23:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 08:23:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:23:47 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:47 --> Total execution time: 0.1650
INFO - 2021-12-20 08:23:49 --> Config Class Initialized
INFO - 2021-12-20 08:23:49 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:49 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:49 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:49 --> URI Class Initialized
INFO - 2021-12-20 08:23:49 --> Router Class Initialized
INFO - 2021-12-20 08:23:49 --> Output Class Initialized
INFO - 2021-12-20 08:23:49 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:49 --> Input Class Initialized
INFO - 2021-12-20 08:23:49 --> Language Class Initialized
INFO - 2021-12-20 08:23:49 --> Language Class Initialized
INFO - 2021-12-20 08:23:49 --> Config Class Initialized
INFO - 2021-12-20 08:23:49 --> Loader Class Initialized
INFO - 2021-12-20 08:23:49 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:49 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:49 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:49 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:49 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:49 --> Controller Class Initialized
DEBUG - 2021-12-20 08:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:23:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:23:49 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:49 --> Total execution time: 0.0680
INFO - 2021-12-20 08:23:54 --> Config Class Initialized
INFO - 2021-12-20 08:23:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:54 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:54 --> URI Class Initialized
INFO - 2021-12-20 08:23:54 --> Router Class Initialized
INFO - 2021-12-20 08:23:54 --> Output Class Initialized
INFO - 2021-12-20 08:23:54 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:54 --> Input Class Initialized
INFO - 2021-12-20 08:23:54 --> Language Class Initialized
INFO - 2021-12-20 08:23:54 --> Language Class Initialized
INFO - 2021-12-20 08:23:54 --> Config Class Initialized
INFO - 2021-12-20 08:23:54 --> Loader Class Initialized
INFO - 2021-12-20 08:23:54 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:54 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:54 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:54 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:54 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:54 --> Controller Class Initialized
INFO - 2021-12-20 08:23:54 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:54 --> Total execution time: 0.0580
INFO - 2021-12-20 08:23:56 --> Config Class Initialized
INFO - 2021-12-20 08:23:56 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:56 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:56 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:56 --> URI Class Initialized
INFO - 2021-12-20 08:23:56 --> Router Class Initialized
INFO - 2021-12-20 08:23:56 --> Output Class Initialized
INFO - 2021-12-20 08:23:56 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:56 --> Input Class Initialized
INFO - 2021-12-20 08:23:56 --> Language Class Initialized
INFO - 2021-12-20 08:23:56 --> Language Class Initialized
INFO - 2021-12-20 08:23:56 --> Config Class Initialized
INFO - 2021-12-20 08:23:56 --> Loader Class Initialized
INFO - 2021-12-20 08:23:56 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:56 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:56 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:56 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:56 --> Controller Class Initialized
INFO - 2021-12-20 08:23:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:56 --> Total execution time: 0.0500
INFO - 2021-12-20 08:23:56 --> Config Class Initialized
INFO - 2021-12-20 08:23:56 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:56 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:56 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:56 --> URI Class Initialized
INFO - 2021-12-20 08:23:56 --> Router Class Initialized
INFO - 2021-12-20 08:23:56 --> Output Class Initialized
INFO - 2021-12-20 08:23:56 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:56 --> Input Class Initialized
INFO - 2021-12-20 08:23:56 --> Language Class Initialized
INFO - 2021-12-20 08:23:56 --> Language Class Initialized
INFO - 2021-12-20 08:23:56 --> Config Class Initialized
INFO - 2021-12-20 08:23:56 --> Loader Class Initialized
INFO - 2021-12-20 08:23:56 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:56 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:56 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:56 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:56 --> Controller Class Initialized
INFO - 2021-12-20 08:23:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:56 --> Total execution time: 0.0550
INFO - 2021-12-20 08:23:57 --> Config Class Initialized
INFO - 2021-12-20 08:23:57 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:57 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:57 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:57 --> URI Class Initialized
INFO - 2021-12-20 08:23:57 --> Router Class Initialized
INFO - 2021-12-20 08:23:57 --> Output Class Initialized
INFO - 2021-12-20 08:23:57 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:57 --> Input Class Initialized
INFO - 2021-12-20 08:23:57 --> Language Class Initialized
INFO - 2021-12-20 08:23:57 --> Language Class Initialized
INFO - 2021-12-20 08:23:57 --> Config Class Initialized
INFO - 2021-12-20 08:23:57 --> Loader Class Initialized
INFO - 2021-12-20 08:23:57 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:57 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:57 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:57 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:57 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:57 --> Controller Class Initialized
INFO - 2021-12-20 08:23:57 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:57 --> Total execution time: 0.1120
INFO - 2021-12-20 08:23:58 --> Config Class Initialized
INFO - 2021-12-20 08:23:58 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:58 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:58 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:58 --> URI Class Initialized
INFO - 2021-12-20 08:23:58 --> Router Class Initialized
INFO - 2021-12-20 08:23:58 --> Output Class Initialized
INFO - 2021-12-20 08:23:58 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:58 --> Input Class Initialized
INFO - 2021-12-20 08:23:58 --> Language Class Initialized
INFO - 2021-12-20 08:23:58 --> Language Class Initialized
INFO - 2021-12-20 08:23:58 --> Config Class Initialized
INFO - 2021-12-20 08:23:58 --> Loader Class Initialized
INFO - 2021-12-20 08:23:58 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:58 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:58 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:58 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:58 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:58 --> Controller Class Initialized
INFO - 2021-12-20 08:23:58 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:58 --> Total execution time: 0.0510
INFO - 2021-12-20 08:23:59 --> Config Class Initialized
INFO - 2021-12-20 08:23:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:23:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:23:59 --> Utf8 Class Initialized
INFO - 2021-12-20 08:23:59 --> URI Class Initialized
INFO - 2021-12-20 08:23:59 --> Router Class Initialized
INFO - 2021-12-20 08:23:59 --> Output Class Initialized
INFO - 2021-12-20 08:23:59 --> Security Class Initialized
DEBUG - 2021-12-20 08:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:23:59 --> Input Class Initialized
INFO - 2021-12-20 08:23:59 --> Language Class Initialized
INFO - 2021-12-20 08:23:59 --> Language Class Initialized
INFO - 2021-12-20 08:23:59 --> Config Class Initialized
INFO - 2021-12-20 08:23:59 --> Loader Class Initialized
INFO - 2021-12-20 08:23:59 --> Helper loaded: url_helper
INFO - 2021-12-20 08:23:59 --> Helper loaded: file_helper
INFO - 2021-12-20 08:23:59 --> Helper loaded: form_helper
INFO - 2021-12-20 08:23:59 --> Helper loaded: my_helper
INFO - 2021-12-20 08:23:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:23:59 --> Controller Class Initialized
INFO - 2021-12-20 08:23:59 --> Final output sent to browser
DEBUG - 2021-12-20 08:23:59 --> Total execution time: 0.0570
INFO - 2021-12-20 08:24:02 --> Config Class Initialized
INFO - 2021-12-20 08:24:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:02 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:02 --> URI Class Initialized
INFO - 2021-12-20 08:24:02 --> Router Class Initialized
INFO - 2021-12-20 08:24:02 --> Output Class Initialized
INFO - 2021-12-20 08:24:02 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:02 --> Input Class Initialized
INFO - 2021-12-20 08:24:02 --> Language Class Initialized
INFO - 2021-12-20 08:24:02 --> Language Class Initialized
INFO - 2021-12-20 08:24:02 --> Config Class Initialized
INFO - 2021-12-20 08:24:02 --> Loader Class Initialized
INFO - 2021-12-20 08:24:02 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:02 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:02 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:02 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:02 --> Controller Class Initialized
INFO - 2021-12-20 08:24:02 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:02 --> Total execution time: 0.0480
INFO - 2021-12-20 08:24:03 --> Config Class Initialized
INFO - 2021-12-20 08:24:03 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:03 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:03 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:03 --> URI Class Initialized
INFO - 2021-12-20 08:24:03 --> Router Class Initialized
INFO - 2021-12-20 08:24:03 --> Output Class Initialized
INFO - 2021-12-20 08:24:03 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:03 --> Input Class Initialized
INFO - 2021-12-20 08:24:03 --> Language Class Initialized
INFO - 2021-12-20 08:24:03 --> Language Class Initialized
INFO - 2021-12-20 08:24:03 --> Config Class Initialized
INFO - 2021-12-20 08:24:03 --> Loader Class Initialized
INFO - 2021-12-20 08:24:03 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:03 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:03 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:03 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:03 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:03 --> Controller Class Initialized
INFO - 2021-12-20 08:24:03 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:03 --> Total execution time: 0.0520
INFO - 2021-12-20 08:24:05 --> Config Class Initialized
INFO - 2021-12-20 08:24:05 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:05 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:05 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:05 --> URI Class Initialized
INFO - 2021-12-20 08:24:05 --> Router Class Initialized
INFO - 2021-12-20 08:24:05 --> Output Class Initialized
INFO - 2021-12-20 08:24:05 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:05 --> Input Class Initialized
INFO - 2021-12-20 08:24:05 --> Language Class Initialized
INFO - 2021-12-20 08:24:05 --> Language Class Initialized
INFO - 2021-12-20 08:24:05 --> Config Class Initialized
INFO - 2021-12-20 08:24:05 --> Loader Class Initialized
INFO - 2021-12-20 08:24:05 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:05 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:05 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:05 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:05 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:05 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:05 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:05 --> Total execution time: 0.0560
INFO - 2021-12-20 08:24:06 --> Config Class Initialized
INFO - 2021-12-20 08:24:06 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:06 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:06 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:06 --> URI Class Initialized
INFO - 2021-12-20 08:24:06 --> Router Class Initialized
INFO - 2021-12-20 08:24:06 --> Output Class Initialized
INFO - 2021-12-20 08:24:06 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:06 --> Input Class Initialized
INFO - 2021-12-20 08:24:06 --> Language Class Initialized
INFO - 2021-12-20 08:24:06 --> Language Class Initialized
INFO - 2021-12-20 08:24:06 --> Config Class Initialized
INFO - 2021-12-20 08:24:06 --> Loader Class Initialized
INFO - 2021-12-20 08:24:06 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:06 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:06 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:06 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:06 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:06 --> Controller Class Initialized
INFO - 2021-12-20 08:24:06 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:06 --> Total execution time: 0.0480
INFO - 2021-12-20 08:24:07 --> Config Class Initialized
INFO - 2021-12-20 08:24:07 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:07 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:07 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:07 --> URI Class Initialized
INFO - 2021-12-20 08:24:07 --> Router Class Initialized
INFO - 2021-12-20 08:24:07 --> Output Class Initialized
INFO - 2021-12-20 08:24:07 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:07 --> Input Class Initialized
INFO - 2021-12-20 08:24:07 --> Language Class Initialized
INFO - 2021-12-20 08:24:07 --> Language Class Initialized
INFO - 2021-12-20 08:24:07 --> Config Class Initialized
INFO - 2021-12-20 08:24:07 --> Loader Class Initialized
INFO - 2021-12-20 08:24:07 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:07 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:07 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:07 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:07 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:07 --> Controller Class Initialized
INFO - 2021-12-20 08:24:07 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:07 --> Total execution time: 0.0520
INFO - 2021-12-20 08:24:08 --> Config Class Initialized
INFO - 2021-12-20 08:24:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:08 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:08 --> URI Class Initialized
INFO - 2021-12-20 08:24:08 --> Router Class Initialized
INFO - 2021-12-20 08:24:08 --> Output Class Initialized
INFO - 2021-12-20 08:24:08 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:08 --> Input Class Initialized
INFO - 2021-12-20 08:24:08 --> Language Class Initialized
INFO - 2021-12-20 08:24:08 --> Language Class Initialized
INFO - 2021-12-20 08:24:08 --> Config Class Initialized
INFO - 2021-12-20 08:24:08 --> Loader Class Initialized
INFO - 2021-12-20 08:24:08 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:08 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:08 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:08 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:08 --> Controller Class Initialized
INFO - 2021-12-20 08:24:08 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:08 --> Total execution time: 0.0680
INFO - 2021-12-20 08:24:09 --> Config Class Initialized
INFO - 2021-12-20 08:24:09 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:09 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:09 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:09 --> URI Class Initialized
INFO - 2021-12-20 08:24:09 --> Router Class Initialized
INFO - 2021-12-20 08:24:09 --> Output Class Initialized
INFO - 2021-12-20 08:24:09 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:09 --> Input Class Initialized
INFO - 2021-12-20 08:24:09 --> Language Class Initialized
INFO - 2021-12-20 08:24:09 --> Language Class Initialized
INFO - 2021-12-20 08:24:09 --> Config Class Initialized
INFO - 2021-12-20 08:24:09 --> Loader Class Initialized
INFO - 2021-12-20 08:24:09 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:09 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:09 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:09 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:09 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:09 --> Controller Class Initialized
INFO - 2021-12-20 08:24:09 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:09 --> Total execution time: 0.0490
INFO - 2021-12-20 08:24:10 --> Config Class Initialized
INFO - 2021-12-20 08:24:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:11 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:11 --> URI Class Initialized
INFO - 2021-12-20 08:24:11 --> Router Class Initialized
INFO - 2021-12-20 08:24:11 --> Output Class Initialized
INFO - 2021-12-20 08:24:11 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:11 --> Input Class Initialized
INFO - 2021-12-20 08:24:11 --> Language Class Initialized
INFO - 2021-12-20 08:24:11 --> Language Class Initialized
INFO - 2021-12-20 08:24:11 --> Config Class Initialized
INFO - 2021-12-20 08:24:11 --> Loader Class Initialized
INFO - 2021-12-20 08:24:11 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:11 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:11 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:11 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:11 --> Controller Class Initialized
INFO - 2021-12-20 08:24:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:11 --> Total execution time: 0.0450
INFO - 2021-12-20 08:24:13 --> Config Class Initialized
INFO - 2021-12-20 08:24:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:13 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:13 --> URI Class Initialized
INFO - 2021-12-20 08:24:13 --> Router Class Initialized
INFO - 2021-12-20 08:24:13 --> Output Class Initialized
INFO - 2021-12-20 08:24:13 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:13 --> Input Class Initialized
INFO - 2021-12-20 08:24:13 --> Language Class Initialized
INFO - 2021-12-20 08:24:13 --> Language Class Initialized
INFO - 2021-12-20 08:24:13 --> Config Class Initialized
INFO - 2021-12-20 08:24:13 --> Loader Class Initialized
INFO - 2021-12-20 08:24:13 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:13 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:13 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:13 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:13 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:13 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:13 --> Total execution time: 0.0600
INFO - 2021-12-20 08:24:14 --> Config Class Initialized
INFO - 2021-12-20 08:24:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:14 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:14 --> URI Class Initialized
INFO - 2021-12-20 08:24:14 --> Router Class Initialized
INFO - 2021-12-20 08:24:14 --> Output Class Initialized
INFO - 2021-12-20 08:24:14 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:14 --> Input Class Initialized
INFO - 2021-12-20 08:24:14 --> Language Class Initialized
INFO - 2021-12-20 08:24:14 --> Language Class Initialized
INFO - 2021-12-20 08:24:14 --> Config Class Initialized
INFO - 2021-12-20 08:24:14 --> Loader Class Initialized
INFO - 2021-12-20 08:24:14 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:14 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:14 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:14 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:14 --> Controller Class Initialized
INFO - 2021-12-20 08:24:14 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:14 --> Total execution time: 0.0490
INFO - 2021-12-20 08:24:15 --> Config Class Initialized
INFO - 2021-12-20 08:24:15 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:15 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:15 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:15 --> URI Class Initialized
INFO - 2021-12-20 08:24:15 --> Router Class Initialized
INFO - 2021-12-20 08:24:15 --> Output Class Initialized
INFO - 2021-12-20 08:24:15 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:15 --> Input Class Initialized
INFO - 2021-12-20 08:24:15 --> Language Class Initialized
INFO - 2021-12-20 08:24:15 --> Language Class Initialized
INFO - 2021-12-20 08:24:15 --> Config Class Initialized
INFO - 2021-12-20 08:24:15 --> Loader Class Initialized
INFO - 2021-12-20 08:24:15 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:15 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:15 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:15 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:15 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:15 --> Controller Class Initialized
INFO - 2021-12-20 08:24:15 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:15 --> Total execution time: 0.0530
INFO - 2021-12-20 08:24:16 --> Config Class Initialized
INFO - 2021-12-20 08:24:16 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:16 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:16 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:16 --> URI Class Initialized
INFO - 2021-12-20 08:24:16 --> Router Class Initialized
INFO - 2021-12-20 08:24:16 --> Output Class Initialized
INFO - 2021-12-20 08:24:16 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:16 --> Input Class Initialized
INFO - 2021-12-20 08:24:16 --> Language Class Initialized
INFO - 2021-12-20 08:24:16 --> Language Class Initialized
INFO - 2021-12-20 08:24:16 --> Config Class Initialized
INFO - 2021-12-20 08:24:16 --> Loader Class Initialized
INFO - 2021-12-20 08:24:16 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:16 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:16 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:16 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:16 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:16 --> Controller Class Initialized
INFO - 2021-12-20 08:24:16 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:16 --> Total execution time: 0.0500
INFO - 2021-12-20 08:24:18 --> Config Class Initialized
INFO - 2021-12-20 08:24:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:18 --> URI Class Initialized
INFO - 2021-12-20 08:24:18 --> Router Class Initialized
INFO - 2021-12-20 08:24:18 --> Output Class Initialized
INFO - 2021-12-20 08:24:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:18 --> Input Class Initialized
INFO - 2021-12-20 08:24:18 --> Language Class Initialized
INFO - 2021-12-20 08:24:18 --> Language Class Initialized
INFO - 2021-12-20 08:24:18 --> Config Class Initialized
INFO - 2021-12-20 08:24:18 --> Loader Class Initialized
INFO - 2021-12-20 08:24:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:18 --> Controller Class Initialized
INFO - 2021-12-20 08:24:18 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:18 --> Total execution time: 0.0620
INFO - 2021-12-20 08:24:18 --> Config Class Initialized
INFO - 2021-12-20 08:24:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:18 --> URI Class Initialized
INFO - 2021-12-20 08:24:18 --> Router Class Initialized
INFO - 2021-12-20 08:24:18 --> Output Class Initialized
INFO - 2021-12-20 08:24:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:18 --> Input Class Initialized
INFO - 2021-12-20 08:24:18 --> Language Class Initialized
INFO - 2021-12-20 08:24:18 --> Language Class Initialized
INFO - 2021-12-20 08:24:18 --> Config Class Initialized
INFO - 2021-12-20 08:24:18 --> Loader Class Initialized
INFO - 2021-12-20 08:24:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:18 --> Controller Class Initialized
INFO - 2021-12-20 08:24:18 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:18 --> Total execution time: 0.0370
INFO - 2021-12-20 08:24:19 --> Config Class Initialized
INFO - 2021-12-20 08:24:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:19 --> URI Class Initialized
INFO - 2021-12-20 08:24:19 --> Router Class Initialized
INFO - 2021-12-20 08:24:19 --> Output Class Initialized
INFO - 2021-12-20 08:24:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:19 --> Input Class Initialized
INFO - 2021-12-20 08:24:19 --> Language Class Initialized
INFO - 2021-12-20 08:24:19 --> Language Class Initialized
INFO - 2021-12-20 08:24:19 --> Config Class Initialized
INFO - 2021-12-20 08:24:19 --> Loader Class Initialized
INFO - 2021-12-20 08:24:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:19 --> Controller Class Initialized
INFO - 2021-12-20 08:24:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:19 --> Total execution time: 0.0510
INFO - 2021-12-20 08:24:21 --> Config Class Initialized
INFO - 2021-12-20 08:24:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:21 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:21 --> URI Class Initialized
INFO - 2021-12-20 08:24:21 --> Router Class Initialized
INFO - 2021-12-20 08:24:21 --> Output Class Initialized
INFO - 2021-12-20 08:24:21 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:21 --> Input Class Initialized
INFO - 2021-12-20 08:24:21 --> Language Class Initialized
INFO - 2021-12-20 08:24:21 --> Language Class Initialized
INFO - 2021-12-20 08:24:21 --> Config Class Initialized
INFO - 2021-12-20 08:24:21 --> Loader Class Initialized
INFO - 2021-12-20 08:24:21 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:21 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:21 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:21 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:21 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:21 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:21 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:21 --> Total execution time: 0.0670
INFO - 2021-12-20 08:24:22 --> Config Class Initialized
INFO - 2021-12-20 08:24:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:22 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:22 --> URI Class Initialized
INFO - 2021-12-20 08:24:22 --> Router Class Initialized
INFO - 2021-12-20 08:24:22 --> Output Class Initialized
INFO - 2021-12-20 08:24:22 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:22 --> Input Class Initialized
INFO - 2021-12-20 08:24:22 --> Language Class Initialized
INFO - 2021-12-20 08:24:22 --> Language Class Initialized
INFO - 2021-12-20 08:24:22 --> Config Class Initialized
INFO - 2021-12-20 08:24:22 --> Loader Class Initialized
INFO - 2021-12-20 08:24:22 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:22 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:22 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:22 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:22 --> Controller Class Initialized
INFO - 2021-12-20 08:24:22 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:22 --> Total execution time: 0.0590
INFO - 2021-12-20 08:24:23 --> Config Class Initialized
INFO - 2021-12-20 08:24:23 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:23 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:23 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:23 --> URI Class Initialized
INFO - 2021-12-20 08:24:23 --> Router Class Initialized
INFO - 2021-12-20 08:24:23 --> Output Class Initialized
INFO - 2021-12-20 08:24:23 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:23 --> Input Class Initialized
INFO - 2021-12-20 08:24:23 --> Language Class Initialized
INFO - 2021-12-20 08:24:23 --> Language Class Initialized
INFO - 2021-12-20 08:24:23 --> Config Class Initialized
INFO - 2021-12-20 08:24:23 --> Loader Class Initialized
INFO - 2021-12-20 08:24:23 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:23 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:23 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:23 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:23 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:23 --> Controller Class Initialized
INFO - 2021-12-20 08:24:23 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:23 --> Total execution time: 0.0540
INFO - 2021-12-20 08:24:24 --> Config Class Initialized
INFO - 2021-12-20 08:24:24 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:24 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:24 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:24 --> URI Class Initialized
INFO - 2021-12-20 08:24:24 --> Router Class Initialized
INFO - 2021-12-20 08:24:24 --> Output Class Initialized
INFO - 2021-12-20 08:24:24 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:24 --> Input Class Initialized
INFO - 2021-12-20 08:24:24 --> Language Class Initialized
INFO - 2021-12-20 08:24:24 --> Language Class Initialized
INFO - 2021-12-20 08:24:24 --> Config Class Initialized
INFO - 2021-12-20 08:24:24 --> Loader Class Initialized
INFO - 2021-12-20 08:24:24 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:24 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:24 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:24 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:24 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:24 --> Controller Class Initialized
INFO - 2021-12-20 08:24:24 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:24 --> Total execution time: 0.0560
INFO - 2021-12-20 08:24:25 --> Config Class Initialized
INFO - 2021-12-20 08:24:25 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:25 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:25 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:25 --> URI Class Initialized
INFO - 2021-12-20 08:24:25 --> Router Class Initialized
INFO - 2021-12-20 08:24:25 --> Output Class Initialized
INFO - 2021-12-20 08:24:25 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:25 --> Input Class Initialized
INFO - 2021-12-20 08:24:25 --> Language Class Initialized
INFO - 2021-12-20 08:24:25 --> Language Class Initialized
INFO - 2021-12-20 08:24:25 --> Config Class Initialized
INFO - 2021-12-20 08:24:25 --> Loader Class Initialized
INFO - 2021-12-20 08:24:25 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:25 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:25 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:25 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:25 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:25 --> Controller Class Initialized
INFO - 2021-12-20 08:24:25 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:25 --> Total execution time: 0.0560
INFO - 2021-12-20 08:24:26 --> Config Class Initialized
INFO - 2021-12-20 08:24:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:26 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:26 --> URI Class Initialized
INFO - 2021-12-20 08:24:26 --> Router Class Initialized
INFO - 2021-12-20 08:24:26 --> Output Class Initialized
INFO - 2021-12-20 08:24:26 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:26 --> Input Class Initialized
INFO - 2021-12-20 08:24:26 --> Language Class Initialized
INFO - 2021-12-20 08:24:26 --> Language Class Initialized
INFO - 2021-12-20 08:24:26 --> Config Class Initialized
INFO - 2021-12-20 08:24:26 --> Loader Class Initialized
INFO - 2021-12-20 08:24:26 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:26 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:26 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:26 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:26 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:26 --> Controller Class Initialized
INFO - 2021-12-20 08:24:26 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:26 --> Total execution time: 0.0490
INFO - 2021-12-20 08:24:27 --> Config Class Initialized
INFO - 2021-12-20 08:24:27 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:27 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:27 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:27 --> URI Class Initialized
INFO - 2021-12-20 08:24:27 --> Router Class Initialized
INFO - 2021-12-20 08:24:27 --> Output Class Initialized
INFO - 2021-12-20 08:24:27 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:27 --> Input Class Initialized
INFO - 2021-12-20 08:24:27 --> Language Class Initialized
INFO - 2021-12-20 08:24:27 --> Language Class Initialized
INFO - 2021-12-20 08:24:27 --> Config Class Initialized
INFO - 2021-12-20 08:24:27 --> Loader Class Initialized
INFO - 2021-12-20 08:24:27 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:27 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:27 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:27 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:27 --> Controller Class Initialized
INFO - 2021-12-20 08:24:27 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:27 --> Total execution time: 0.0500
INFO - 2021-12-20 08:24:31 --> Config Class Initialized
INFO - 2021-12-20 08:24:31 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:31 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:31 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:31 --> URI Class Initialized
INFO - 2021-12-20 08:24:31 --> Router Class Initialized
INFO - 2021-12-20 08:24:31 --> Output Class Initialized
INFO - 2021-12-20 08:24:31 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:31 --> Input Class Initialized
INFO - 2021-12-20 08:24:31 --> Language Class Initialized
INFO - 2021-12-20 08:24:31 --> Language Class Initialized
INFO - 2021-12-20 08:24:31 --> Config Class Initialized
INFO - 2021-12-20 08:24:31 --> Loader Class Initialized
INFO - 2021-12-20 08:24:31 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:31 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:31 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:31 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:31 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:31 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:31 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:31 --> Total execution time: 0.0690
INFO - 2021-12-20 08:24:32 --> Config Class Initialized
INFO - 2021-12-20 08:24:32 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:32 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:32 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:32 --> URI Class Initialized
INFO - 2021-12-20 08:24:32 --> Router Class Initialized
INFO - 2021-12-20 08:24:32 --> Output Class Initialized
INFO - 2021-12-20 08:24:32 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:32 --> Input Class Initialized
INFO - 2021-12-20 08:24:32 --> Language Class Initialized
INFO - 2021-12-20 08:24:32 --> Language Class Initialized
INFO - 2021-12-20 08:24:32 --> Config Class Initialized
INFO - 2021-12-20 08:24:32 --> Loader Class Initialized
INFO - 2021-12-20 08:24:32 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:32 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:32 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:32 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:32 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:32 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:32 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:32 --> Total execution time: 0.0630
INFO - 2021-12-20 08:24:34 --> Config Class Initialized
INFO - 2021-12-20 08:24:34 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:34 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:34 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:34 --> URI Class Initialized
INFO - 2021-12-20 08:24:34 --> Router Class Initialized
INFO - 2021-12-20 08:24:34 --> Output Class Initialized
INFO - 2021-12-20 08:24:34 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:34 --> Input Class Initialized
INFO - 2021-12-20 08:24:34 --> Language Class Initialized
INFO - 2021-12-20 08:24:34 --> Language Class Initialized
INFO - 2021-12-20 08:24:34 --> Config Class Initialized
INFO - 2021-12-20 08:24:34 --> Loader Class Initialized
INFO - 2021-12-20 08:24:34 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:34 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:34 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:34 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:34 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:34 --> Controller Class Initialized
INFO - 2021-12-20 08:24:34 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:34 --> Total execution time: 0.0580
INFO - 2021-12-20 08:24:34 --> Config Class Initialized
INFO - 2021-12-20 08:24:34 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:34 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:34 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:34 --> URI Class Initialized
INFO - 2021-12-20 08:24:34 --> Router Class Initialized
INFO - 2021-12-20 08:24:35 --> Output Class Initialized
INFO - 2021-12-20 08:24:35 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:35 --> Input Class Initialized
INFO - 2021-12-20 08:24:35 --> Language Class Initialized
INFO - 2021-12-20 08:24:35 --> Language Class Initialized
INFO - 2021-12-20 08:24:35 --> Config Class Initialized
INFO - 2021-12-20 08:24:35 --> Loader Class Initialized
INFO - 2021-12-20 08:24:35 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:35 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:35 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:35 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:35 --> Controller Class Initialized
INFO - 2021-12-20 08:24:35 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:35 --> Total execution time: 0.0500
INFO - 2021-12-20 08:24:36 --> Config Class Initialized
INFO - 2021-12-20 08:24:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:36 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:36 --> URI Class Initialized
INFO - 2021-12-20 08:24:36 --> Router Class Initialized
INFO - 2021-12-20 08:24:36 --> Output Class Initialized
INFO - 2021-12-20 08:24:36 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:36 --> Input Class Initialized
INFO - 2021-12-20 08:24:36 --> Language Class Initialized
INFO - 2021-12-20 08:24:36 --> Language Class Initialized
INFO - 2021-12-20 08:24:36 --> Config Class Initialized
INFO - 2021-12-20 08:24:36 --> Loader Class Initialized
INFO - 2021-12-20 08:24:36 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:36 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:36 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:36 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:36 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:36 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:36 --> Total execution time: 0.0670
INFO - 2021-12-20 08:24:38 --> Config Class Initialized
INFO - 2021-12-20 08:24:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:38 --> URI Class Initialized
INFO - 2021-12-20 08:24:38 --> Router Class Initialized
INFO - 2021-12-20 08:24:38 --> Output Class Initialized
INFO - 2021-12-20 08:24:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:38 --> Input Class Initialized
INFO - 2021-12-20 08:24:38 --> Language Class Initialized
INFO - 2021-12-20 08:24:38 --> Language Class Initialized
INFO - 2021-12-20 08:24:38 --> Config Class Initialized
INFO - 2021-12-20 08:24:38 --> Loader Class Initialized
INFO - 2021-12-20 08:24:38 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:38 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:38 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:38 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:38 --> Controller Class Initialized
INFO - 2021-12-20 08:24:38 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:38 --> Total execution time: 0.0520
INFO - 2021-12-20 08:24:39 --> Config Class Initialized
INFO - 2021-12-20 08:24:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:39 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:39 --> URI Class Initialized
INFO - 2021-12-20 08:24:39 --> Router Class Initialized
INFO - 2021-12-20 08:24:39 --> Output Class Initialized
INFO - 2021-12-20 08:24:39 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:39 --> Input Class Initialized
INFO - 2021-12-20 08:24:39 --> Language Class Initialized
INFO - 2021-12-20 08:24:39 --> Language Class Initialized
INFO - 2021-12-20 08:24:39 --> Config Class Initialized
INFO - 2021-12-20 08:24:39 --> Loader Class Initialized
INFO - 2021-12-20 08:24:39 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:39 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:39 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:39 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:39 --> Controller Class Initialized
INFO - 2021-12-20 08:24:39 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:39 --> Total execution time: 0.0460
INFO - 2021-12-20 08:24:39 --> Config Class Initialized
INFO - 2021-12-20 08:24:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:40 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:40 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:40 --> URI Class Initialized
INFO - 2021-12-20 08:24:40 --> Router Class Initialized
INFO - 2021-12-20 08:24:40 --> Output Class Initialized
INFO - 2021-12-20 08:24:40 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:40 --> Input Class Initialized
INFO - 2021-12-20 08:24:40 --> Language Class Initialized
INFO - 2021-12-20 08:24:40 --> Language Class Initialized
INFO - 2021-12-20 08:24:40 --> Config Class Initialized
INFO - 2021-12-20 08:24:40 --> Loader Class Initialized
INFO - 2021-12-20 08:24:40 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:40 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:40 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:40 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:40 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:40 --> Controller Class Initialized
INFO - 2021-12-20 08:24:40 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:40 --> Total execution time: 0.0400
INFO - 2021-12-20 08:24:40 --> Config Class Initialized
INFO - 2021-12-20 08:24:40 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:40 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:40 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:40 --> URI Class Initialized
INFO - 2021-12-20 08:24:40 --> Router Class Initialized
INFO - 2021-12-20 08:24:40 --> Output Class Initialized
INFO - 2021-12-20 08:24:40 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:40 --> Input Class Initialized
INFO - 2021-12-20 08:24:40 --> Language Class Initialized
INFO - 2021-12-20 08:24:40 --> Language Class Initialized
INFO - 2021-12-20 08:24:40 --> Config Class Initialized
INFO - 2021-12-20 08:24:40 --> Loader Class Initialized
INFO - 2021-12-20 08:24:40 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:40 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:40 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:40 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:40 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:40 --> Controller Class Initialized
INFO - 2021-12-20 08:24:40 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:40 --> Total execution time: 0.0510
INFO - 2021-12-20 08:24:41 --> Config Class Initialized
INFO - 2021-12-20 08:24:41 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:41 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:41 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:41 --> URI Class Initialized
INFO - 2021-12-20 08:24:41 --> Router Class Initialized
INFO - 2021-12-20 08:24:41 --> Output Class Initialized
INFO - 2021-12-20 08:24:41 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:41 --> Input Class Initialized
INFO - 2021-12-20 08:24:41 --> Language Class Initialized
INFO - 2021-12-20 08:24:41 --> Language Class Initialized
INFO - 2021-12-20 08:24:41 --> Config Class Initialized
INFO - 2021-12-20 08:24:41 --> Loader Class Initialized
INFO - 2021-12-20 08:24:41 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:41 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:41 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:41 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:41 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:41 --> Controller Class Initialized
INFO - 2021-12-20 08:24:41 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:41 --> Total execution time: 0.0600
INFO - 2021-12-20 08:24:42 --> Config Class Initialized
INFO - 2021-12-20 08:24:42 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:42 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:42 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:42 --> URI Class Initialized
INFO - 2021-12-20 08:24:42 --> Router Class Initialized
INFO - 2021-12-20 08:24:42 --> Output Class Initialized
INFO - 2021-12-20 08:24:42 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:42 --> Input Class Initialized
INFO - 2021-12-20 08:24:42 --> Language Class Initialized
INFO - 2021-12-20 08:24:42 --> Language Class Initialized
INFO - 2021-12-20 08:24:42 --> Config Class Initialized
INFO - 2021-12-20 08:24:42 --> Loader Class Initialized
INFO - 2021-12-20 08:24:42 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:42 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:42 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:42 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:42 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:42 --> Controller Class Initialized
INFO - 2021-12-20 08:24:42 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:42 --> Total execution time: 0.0460
INFO - 2021-12-20 08:24:45 --> Config Class Initialized
INFO - 2021-12-20 08:24:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:45 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:45 --> URI Class Initialized
INFO - 2021-12-20 08:24:45 --> Router Class Initialized
INFO - 2021-12-20 08:24:45 --> Output Class Initialized
INFO - 2021-12-20 08:24:45 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:45 --> Input Class Initialized
INFO - 2021-12-20 08:24:45 --> Language Class Initialized
INFO - 2021-12-20 08:24:45 --> Language Class Initialized
INFO - 2021-12-20 08:24:45 --> Config Class Initialized
INFO - 2021-12-20 08:24:45 --> Loader Class Initialized
INFO - 2021-12-20 08:24:45 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:45 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:45 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:45 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:46 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:46 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:46 --> Total execution time: 0.0530
INFO - 2021-12-20 08:24:47 --> Config Class Initialized
INFO - 2021-12-20 08:24:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:47 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:47 --> URI Class Initialized
INFO - 2021-12-20 08:24:47 --> Router Class Initialized
INFO - 2021-12-20 08:24:47 --> Output Class Initialized
INFO - 2021-12-20 08:24:47 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:47 --> Input Class Initialized
INFO - 2021-12-20 08:24:47 --> Language Class Initialized
INFO - 2021-12-20 08:24:47 --> Language Class Initialized
INFO - 2021-12-20 08:24:47 --> Config Class Initialized
INFO - 2021-12-20 08:24:47 --> Loader Class Initialized
INFO - 2021-12-20 08:24:47 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:47 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:47 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:47 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:47 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:47 --> Controller Class Initialized
INFO - 2021-12-20 08:24:47 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:47 --> Total execution time: 0.0490
INFO - 2021-12-20 08:24:48 --> Config Class Initialized
INFO - 2021-12-20 08:24:48 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:48 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:48 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:48 --> URI Class Initialized
INFO - 2021-12-20 08:24:48 --> Router Class Initialized
INFO - 2021-12-20 08:24:48 --> Output Class Initialized
INFO - 2021-12-20 08:24:48 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:48 --> Input Class Initialized
INFO - 2021-12-20 08:24:48 --> Language Class Initialized
INFO - 2021-12-20 08:24:48 --> Language Class Initialized
INFO - 2021-12-20 08:24:48 --> Config Class Initialized
INFO - 2021-12-20 08:24:48 --> Loader Class Initialized
INFO - 2021-12-20 08:24:48 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:48 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:48 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:48 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:48 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:48 --> Controller Class Initialized
INFO - 2021-12-20 08:24:48 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:48 --> Total execution time: 0.0560
INFO - 2021-12-20 08:24:49 --> Config Class Initialized
INFO - 2021-12-20 08:24:49 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:49 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:49 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:49 --> URI Class Initialized
INFO - 2021-12-20 08:24:49 --> Router Class Initialized
INFO - 2021-12-20 08:24:49 --> Output Class Initialized
INFO - 2021-12-20 08:24:49 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:49 --> Input Class Initialized
INFO - 2021-12-20 08:24:49 --> Language Class Initialized
INFO - 2021-12-20 08:24:49 --> Language Class Initialized
INFO - 2021-12-20 08:24:49 --> Config Class Initialized
INFO - 2021-12-20 08:24:49 --> Loader Class Initialized
INFO - 2021-12-20 08:24:49 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:49 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:49 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:49 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:49 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:49 --> Controller Class Initialized
INFO - 2021-12-20 08:24:49 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:49 --> Total execution time: 0.0560
INFO - 2021-12-20 08:24:50 --> Config Class Initialized
INFO - 2021-12-20 08:24:50 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:50 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:50 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:50 --> URI Class Initialized
INFO - 2021-12-20 08:24:50 --> Router Class Initialized
INFO - 2021-12-20 08:24:50 --> Output Class Initialized
INFO - 2021-12-20 08:24:50 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:50 --> Input Class Initialized
INFO - 2021-12-20 08:24:50 --> Language Class Initialized
INFO - 2021-12-20 08:24:50 --> Language Class Initialized
INFO - 2021-12-20 08:24:50 --> Config Class Initialized
INFO - 2021-12-20 08:24:50 --> Loader Class Initialized
INFO - 2021-12-20 08:24:50 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:50 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:50 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:50 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:50 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:50 --> Controller Class Initialized
INFO - 2021-12-20 08:24:50 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:50 --> Total execution time: 0.0620
INFO - 2021-12-20 08:24:50 --> Config Class Initialized
INFO - 2021-12-20 08:24:50 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:50 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:50 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:50 --> URI Class Initialized
INFO - 2021-12-20 08:24:50 --> Router Class Initialized
INFO - 2021-12-20 08:24:50 --> Output Class Initialized
INFO - 2021-12-20 08:24:50 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:50 --> Input Class Initialized
INFO - 2021-12-20 08:24:50 --> Language Class Initialized
INFO - 2021-12-20 08:24:50 --> Language Class Initialized
INFO - 2021-12-20 08:24:50 --> Config Class Initialized
INFO - 2021-12-20 08:24:50 --> Loader Class Initialized
INFO - 2021-12-20 08:24:50 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:50 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:50 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:50 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:50 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:50 --> Controller Class Initialized
INFO - 2021-12-20 08:24:50 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:50 --> Total execution time: 0.0470
INFO - 2021-12-20 08:24:53 --> Config Class Initialized
INFO - 2021-12-20 08:24:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:53 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:53 --> URI Class Initialized
INFO - 2021-12-20 08:24:53 --> Router Class Initialized
INFO - 2021-12-20 08:24:53 --> Output Class Initialized
INFO - 2021-12-20 08:24:53 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:53 --> Input Class Initialized
INFO - 2021-12-20 08:24:53 --> Language Class Initialized
INFO - 2021-12-20 08:24:53 --> Language Class Initialized
INFO - 2021-12-20 08:24:53 --> Config Class Initialized
INFO - 2021-12-20 08:24:53 --> Loader Class Initialized
INFO - 2021-12-20 08:24:53 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:53 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:53 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:53 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:53 --> Controller Class Initialized
DEBUG - 2021-12-20 08:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:24:53 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:53 --> Total execution time: 0.0640
INFO - 2021-12-20 08:24:56 --> Config Class Initialized
INFO - 2021-12-20 08:24:56 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:56 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:56 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:56 --> URI Class Initialized
INFO - 2021-12-20 08:24:56 --> Router Class Initialized
INFO - 2021-12-20 08:24:56 --> Output Class Initialized
INFO - 2021-12-20 08:24:56 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:56 --> Input Class Initialized
INFO - 2021-12-20 08:24:56 --> Language Class Initialized
INFO - 2021-12-20 08:24:56 --> Language Class Initialized
INFO - 2021-12-20 08:24:56 --> Config Class Initialized
INFO - 2021-12-20 08:24:56 --> Loader Class Initialized
INFO - 2021-12-20 08:24:56 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:56 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:56 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:56 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:56 --> Controller Class Initialized
INFO - 2021-12-20 08:24:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:56 --> Total execution time: 0.0470
INFO - 2021-12-20 08:24:57 --> Config Class Initialized
INFO - 2021-12-20 08:24:57 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:57 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:57 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:57 --> URI Class Initialized
INFO - 2021-12-20 08:24:57 --> Router Class Initialized
INFO - 2021-12-20 08:24:57 --> Output Class Initialized
INFO - 2021-12-20 08:24:57 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:57 --> Input Class Initialized
INFO - 2021-12-20 08:24:57 --> Language Class Initialized
INFO - 2021-12-20 08:24:57 --> Language Class Initialized
INFO - 2021-12-20 08:24:57 --> Config Class Initialized
INFO - 2021-12-20 08:24:57 --> Loader Class Initialized
INFO - 2021-12-20 08:24:57 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:57 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:57 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:57 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:57 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:57 --> Controller Class Initialized
INFO - 2021-12-20 08:24:57 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:57 --> Total execution time: 0.0470
INFO - 2021-12-20 08:24:57 --> Config Class Initialized
INFO - 2021-12-20 08:24:57 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:57 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:57 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:57 --> URI Class Initialized
INFO - 2021-12-20 08:24:57 --> Router Class Initialized
INFO - 2021-12-20 08:24:57 --> Output Class Initialized
INFO - 2021-12-20 08:24:57 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:57 --> Input Class Initialized
INFO - 2021-12-20 08:24:57 --> Language Class Initialized
INFO - 2021-12-20 08:24:57 --> Language Class Initialized
INFO - 2021-12-20 08:24:57 --> Config Class Initialized
INFO - 2021-12-20 08:24:57 --> Loader Class Initialized
INFO - 2021-12-20 08:24:57 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:57 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:57 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:57 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:57 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:57 --> Controller Class Initialized
INFO - 2021-12-20 08:24:57 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:57 --> Total execution time: 0.0480
INFO - 2021-12-20 08:24:58 --> Config Class Initialized
INFO - 2021-12-20 08:24:58 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:58 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:58 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:58 --> URI Class Initialized
INFO - 2021-12-20 08:24:58 --> Router Class Initialized
INFO - 2021-12-20 08:24:58 --> Output Class Initialized
INFO - 2021-12-20 08:24:58 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:58 --> Input Class Initialized
INFO - 2021-12-20 08:24:58 --> Language Class Initialized
INFO - 2021-12-20 08:24:58 --> Language Class Initialized
INFO - 2021-12-20 08:24:58 --> Config Class Initialized
INFO - 2021-12-20 08:24:58 --> Loader Class Initialized
INFO - 2021-12-20 08:24:58 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:58 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:58 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:58 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:58 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:58 --> Controller Class Initialized
INFO - 2021-12-20 08:24:58 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:58 --> Total execution time: 0.0640
INFO - 2021-12-20 08:24:59 --> Config Class Initialized
INFO - 2021-12-20 08:24:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:24:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:24:59 --> Utf8 Class Initialized
INFO - 2021-12-20 08:24:59 --> URI Class Initialized
INFO - 2021-12-20 08:24:59 --> Router Class Initialized
INFO - 2021-12-20 08:24:59 --> Output Class Initialized
INFO - 2021-12-20 08:24:59 --> Security Class Initialized
DEBUG - 2021-12-20 08:24:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:24:59 --> Input Class Initialized
INFO - 2021-12-20 08:24:59 --> Language Class Initialized
INFO - 2021-12-20 08:24:59 --> Language Class Initialized
INFO - 2021-12-20 08:24:59 --> Config Class Initialized
INFO - 2021-12-20 08:24:59 --> Loader Class Initialized
INFO - 2021-12-20 08:24:59 --> Helper loaded: url_helper
INFO - 2021-12-20 08:24:59 --> Helper loaded: file_helper
INFO - 2021-12-20 08:24:59 --> Helper loaded: form_helper
INFO - 2021-12-20 08:24:59 --> Helper loaded: my_helper
INFO - 2021-12-20 08:24:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:24:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:24:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:24:59 --> Controller Class Initialized
INFO - 2021-12-20 08:24:59 --> Final output sent to browser
DEBUG - 2021-12-20 08:24:59 --> Total execution time: 0.0480
INFO - 2021-12-20 08:25:00 --> Config Class Initialized
INFO - 2021-12-20 08:25:00 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:00 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:00 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:00 --> URI Class Initialized
INFO - 2021-12-20 08:25:00 --> Router Class Initialized
INFO - 2021-12-20 08:25:00 --> Output Class Initialized
INFO - 2021-12-20 08:25:00 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:00 --> Input Class Initialized
INFO - 2021-12-20 08:25:00 --> Language Class Initialized
INFO - 2021-12-20 08:25:00 --> Language Class Initialized
INFO - 2021-12-20 08:25:00 --> Config Class Initialized
INFO - 2021-12-20 08:25:00 --> Loader Class Initialized
INFO - 2021-12-20 08:25:00 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:00 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:00 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:00 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:00 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:00 --> Controller Class Initialized
INFO - 2021-12-20 08:25:00 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:00 --> Total execution time: 0.0510
INFO - 2021-12-20 08:25:02 --> Config Class Initialized
INFO - 2021-12-20 08:25:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:02 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:02 --> URI Class Initialized
INFO - 2021-12-20 08:25:02 --> Router Class Initialized
INFO - 2021-12-20 08:25:02 --> Output Class Initialized
INFO - 2021-12-20 08:25:02 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:02 --> Input Class Initialized
INFO - 2021-12-20 08:25:02 --> Language Class Initialized
INFO - 2021-12-20 08:25:02 --> Language Class Initialized
INFO - 2021-12-20 08:25:02 --> Config Class Initialized
INFO - 2021-12-20 08:25:02 --> Loader Class Initialized
INFO - 2021-12-20 08:25:02 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:02 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:02 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:02 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:02 --> Controller Class Initialized
INFO - 2021-12-20 08:25:02 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:02 --> Total execution time: 0.0430
INFO - 2021-12-20 08:25:03 --> Config Class Initialized
INFO - 2021-12-20 08:25:03 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:03 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:03 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:03 --> URI Class Initialized
INFO - 2021-12-20 08:25:03 --> Router Class Initialized
INFO - 2021-12-20 08:25:03 --> Output Class Initialized
INFO - 2021-12-20 08:25:03 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:03 --> Input Class Initialized
INFO - 2021-12-20 08:25:03 --> Language Class Initialized
INFO - 2021-12-20 08:25:03 --> Language Class Initialized
INFO - 2021-12-20 08:25:03 --> Config Class Initialized
INFO - 2021-12-20 08:25:03 --> Loader Class Initialized
INFO - 2021-12-20 08:25:03 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:03 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:03 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:03 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:03 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:03 --> Controller Class Initialized
INFO - 2021-12-20 08:25:03 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:03 --> Total execution time: 0.0510
INFO - 2021-12-20 08:25:04 --> Config Class Initialized
INFO - 2021-12-20 08:25:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:04 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:04 --> URI Class Initialized
INFO - 2021-12-20 08:25:04 --> Router Class Initialized
INFO - 2021-12-20 08:25:04 --> Output Class Initialized
INFO - 2021-12-20 08:25:04 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:04 --> Input Class Initialized
INFO - 2021-12-20 08:25:04 --> Language Class Initialized
INFO - 2021-12-20 08:25:04 --> Language Class Initialized
INFO - 2021-12-20 08:25:04 --> Config Class Initialized
INFO - 2021-12-20 08:25:04 --> Loader Class Initialized
INFO - 2021-12-20 08:25:04 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:04 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:04 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:04 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:04 --> Controller Class Initialized
INFO - 2021-12-20 08:25:04 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:04 --> Total execution time: 0.0550
INFO - 2021-12-20 08:25:06 --> Config Class Initialized
INFO - 2021-12-20 08:25:06 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:06 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:06 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:06 --> URI Class Initialized
INFO - 2021-12-20 08:25:06 --> Router Class Initialized
INFO - 2021-12-20 08:25:06 --> Output Class Initialized
INFO - 2021-12-20 08:25:06 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:06 --> Input Class Initialized
INFO - 2021-12-20 08:25:06 --> Language Class Initialized
INFO - 2021-12-20 08:25:06 --> Language Class Initialized
INFO - 2021-12-20 08:25:06 --> Config Class Initialized
INFO - 2021-12-20 08:25:06 --> Loader Class Initialized
INFO - 2021-12-20 08:25:06 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:06 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:06 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:06 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:06 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:06 --> Controller Class Initialized
INFO - 2021-12-20 08:25:06 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:06 --> Total execution time: 0.0520
INFO - 2021-12-20 08:25:07 --> Config Class Initialized
INFO - 2021-12-20 08:25:07 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:07 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:07 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:07 --> URI Class Initialized
INFO - 2021-12-20 08:25:07 --> Router Class Initialized
INFO - 2021-12-20 08:25:07 --> Output Class Initialized
INFO - 2021-12-20 08:25:07 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:07 --> Input Class Initialized
INFO - 2021-12-20 08:25:07 --> Language Class Initialized
INFO - 2021-12-20 08:25:07 --> Language Class Initialized
INFO - 2021-12-20 08:25:07 --> Config Class Initialized
INFO - 2021-12-20 08:25:07 --> Loader Class Initialized
INFO - 2021-12-20 08:25:07 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:07 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:07 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:07 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:07 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:07 --> Controller Class Initialized
INFO - 2021-12-20 08:25:07 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:07 --> Total execution time: 0.0470
INFO - 2021-12-20 08:25:09 --> Config Class Initialized
INFO - 2021-12-20 08:25:09 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:09 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:09 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:09 --> URI Class Initialized
INFO - 2021-12-20 08:25:09 --> Router Class Initialized
INFO - 2021-12-20 08:25:09 --> Output Class Initialized
INFO - 2021-12-20 08:25:09 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:09 --> Input Class Initialized
INFO - 2021-12-20 08:25:09 --> Language Class Initialized
INFO - 2021-12-20 08:25:09 --> Language Class Initialized
INFO - 2021-12-20 08:25:09 --> Config Class Initialized
INFO - 2021-12-20 08:25:09 --> Loader Class Initialized
INFO - 2021-12-20 08:25:09 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:09 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:09 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:09 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:09 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:09 --> Controller Class Initialized
INFO - 2021-12-20 08:25:09 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:09 --> Total execution time: 0.0420
INFO - 2021-12-20 08:25:10 --> Config Class Initialized
INFO - 2021-12-20 08:25:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:10 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:10 --> URI Class Initialized
INFO - 2021-12-20 08:25:10 --> Router Class Initialized
INFO - 2021-12-20 08:25:10 --> Output Class Initialized
INFO - 2021-12-20 08:25:10 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:10 --> Input Class Initialized
INFO - 2021-12-20 08:25:10 --> Language Class Initialized
INFO - 2021-12-20 08:25:10 --> Language Class Initialized
INFO - 2021-12-20 08:25:10 --> Config Class Initialized
INFO - 2021-12-20 08:25:10 --> Loader Class Initialized
INFO - 2021-12-20 08:25:10 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:10 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:10 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:10 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:10 --> Controller Class Initialized
DEBUG - 2021-12-20 08:25:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:25:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:25:10 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:10 --> Total execution time: 0.0580
INFO - 2021-12-20 08:25:13 --> Config Class Initialized
INFO - 2021-12-20 08:25:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:13 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:13 --> URI Class Initialized
INFO - 2021-12-20 08:25:13 --> Router Class Initialized
INFO - 2021-12-20 08:25:13 --> Output Class Initialized
INFO - 2021-12-20 08:25:13 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:13 --> Input Class Initialized
INFO - 2021-12-20 08:25:13 --> Language Class Initialized
INFO - 2021-12-20 08:25:13 --> Language Class Initialized
INFO - 2021-12-20 08:25:13 --> Config Class Initialized
INFO - 2021-12-20 08:25:13 --> Loader Class Initialized
INFO - 2021-12-20 08:25:13 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:13 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:13 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:13 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:13 --> Controller Class Initialized
INFO - 2021-12-20 08:25:13 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:13 --> Total execution time: 0.0470
INFO - 2021-12-20 08:25:14 --> Config Class Initialized
INFO - 2021-12-20 08:25:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:14 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:14 --> URI Class Initialized
INFO - 2021-12-20 08:25:14 --> Router Class Initialized
INFO - 2021-12-20 08:25:14 --> Output Class Initialized
INFO - 2021-12-20 08:25:14 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:14 --> Input Class Initialized
INFO - 2021-12-20 08:25:14 --> Language Class Initialized
INFO - 2021-12-20 08:25:14 --> Language Class Initialized
INFO - 2021-12-20 08:25:14 --> Config Class Initialized
INFO - 2021-12-20 08:25:14 --> Loader Class Initialized
INFO - 2021-12-20 08:25:14 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:14 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:14 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:14 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:14 --> Controller Class Initialized
INFO - 2021-12-20 08:25:14 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:14 --> Total execution time: 0.0550
INFO - 2021-12-20 08:25:15 --> Config Class Initialized
INFO - 2021-12-20 08:25:15 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:15 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:15 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:15 --> URI Class Initialized
INFO - 2021-12-20 08:25:15 --> Router Class Initialized
INFO - 2021-12-20 08:25:15 --> Output Class Initialized
INFO - 2021-12-20 08:25:15 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:15 --> Input Class Initialized
INFO - 2021-12-20 08:25:15 --> Language Class Initialized
INFO - 2021-12-20 08:25:15 --> Language Class Initialized
INFO - 2021-12-20 08:25:15 --> Config Class Initialized
INFO - 2021-12-20 08:25:15 --> Loader Class Initialized
INFO - 2021-12-20 08:25:15 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:15 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:15 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:15 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:15 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:15 --> Controller Class Initialized
INFO - 2021-12-20 08:25:15 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:15 --> Total execution time: 0.0480
INFO - 2021-12-20 08:25:16 --> Config Class Initialized
INFO - 2021-12-20 08:25:16 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:16 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:16 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:16 --> URI Class Initialized
INFO - 2021-12-20 08:25:16 --> Router Class Initialized
INFO - 2021-12-20 08:25:16 --> Output Class Initialized
INFO - 2021-12-20 08:25:16 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:16 --> Input Class Initialized
INFO - 2021-12-20 08:25:16 --> Language Class Initialized
INFO - 2021-12-20 08:25:16 --> Language Class Initialized
INFO - 2021-12-20 08:25:16 --> Config Class Initialized
INFO - 2021-12-20 08:25:16 --> Loader Class Initialized
INFO - 2021-12-20 08:25:16 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:16 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:16 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:16 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:16 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:16 --> Controller Class Initialized
INFO - 2021-12-20 08:25:16 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:16 --> Total execution time: 0.0520
INFO - 2021-12-20 08:25:17 --> Config Class Initialized
INFO - 2021-12-20 08:25:17 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:17 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:17 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:17 --> URI Class Initialized
INFO - 2021-12-20 08:25:17 --> Router Class Initialized
INFO - 2021-12-20 08:25:17 --> Output Class Initialized
INFO - 2021-12-20 08:25:17 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:17 --> Input Class Initialized
INFO - 2021-12-20 08:25:17 --> Language Class Initialized
INFO - 2021-12-20 08:25:17 --> Language Class Initialized
INFO - 2021-12-20 08:25:17 --> Config Class Initialized
INFO - 2021-12-20 08:25:17 --> Loader Class Initialized
INFO - 2021-12-20 08:25:17 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:17 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:17 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:17 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:17 --> Controller Class Initialized
INFO - 2021-12-20 08:25:17 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:17 --> Total execution time: 0.0490
INFO - 2021-12-20 08:25:18 --> Config Class Initialized
INFO - 2021-12-20 08:25:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:18 --> URI Class Initialized
INFO - 2021-12-20 08:25:18 --> Router Class Initialized
INFO - 2021-12-20 08:25:18 --> Output Class Initialized
INFO - 2021-12-20 08:25:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:18 --> Input Class Initialized
INFO - 2021-12-20 08:25:18 --> Language Class Initialized
INFO - 2021-12-20 08:25:18 --> Language Class Initialized
INFO - 2021-12-20 08:25:18 --> Config Class Initialized
INFO - 2021-12-20 08:25:18 --> Loader Class Initialized
INFO - 2021-12-20 08:25:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:18 --> Controller Class Initialized
INFO - 2021-12-20 08:25:18 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:18 --> Total execution time: 0.0500
INFO - 2021-12-20 08:25:19 --> Config Class Initialized
INFO - 2021-12-20 08:25:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:19 --> URI Class Initialized
INFO - 2021-12-20 08:25:19 --> Router Class Initialized
INFO - 2021-12-20 08:25:19 --> Output Class Initialized
INFO - 2021-12-20 08:25:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:19 --> Input Class Initialized
INFO - 2021-12-20 08:25:19 --> Language Class Initialized
INFO - 2021-12-20 08:25:19 --> Language Class Initialized
INFO - 2021-12-20 08:25:19 --> Config Class Initialized
INFO - 2021-12-20 08:25:19 --> Loader Class Initialized
INFO - 2021-12-20 08:25:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:19 --> Controller Class Initialized
INFO - 2021-12-20 08:25:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:19 --> Total execution time: 0.0450
INFO - 2021-12-20 08:25:20 --> Config Class Initialized
INFO - 2021-12-20 08:25:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:20 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:20 --> URI Class Initialized
INFO - 2021-12-20 08:25:20 --> Router Class Initialized
INFO - 2021-12-20 08:25:20 --> Output Class Initialized
INFO - 2021-12-20 08:25:20 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:20 --> Input Class Initialized
INFO - 2021-12-20 08:25:20 --> Language Class Initialized
INFO - 2021-12-20 08:25:20 --> Language Class Initialized
INFO - 2021-12-20 08:25:20 --> Config Class Initialized
INFO - 2021-12-20 08:25:20 --> Loader Class Initialized
INFO - 2021-12-20 08:25:20 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:20 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:20 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:20 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:20 --> Controller Class Initialized
INFO - 2021-12-20 08:25:20 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:20 --> Total execution time: 0.0460
INFO - 2021-12-20 08:25:22 --> Config Class Initialized
INFO - 2021-12-20 08:25:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:22 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:22 --> URI Class Initialized
INFO - 2021-12-20 08:25:22 --> Router Class Initialized
INFO - 2021-12-20 08:25:22 --> Output Class Initialized
INFO - 2021-12-20 08:25:22 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:22 --> Input Class Initialized
INFO - 2021-12-20 08:25:22 --> Language Class Initialized
INFO - 2021-12-20 08:25:22 --> Language Class Initialized
INFO - 2021-12-20 08:25:22 --> Config Class Initialized
INFO - 2021-12-20 08:25:22 --> Loader Class Initialized
INFO - 2021-12-20 08:25:22 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:22 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:22 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:22 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:22 --> Controller Class Initialized
INFO - 2021-12-20 08:25:22 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:22 --> Total execution time: 0.0390
INFO - 2021-12-20 08:25:22 --> Config Class Initialized
INFO - 2021-12-20 08:25:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:22 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:22 --> URI Class Initialized
INFO - 2021-12-20 08:25:22 --> Router Class Initialized
INFO - 2021-12-20 08:25:22 --> Output Class Initialized
INFO - 2021-12-20 08:25:22 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:22 --> Input Class Initialized
INFO - 2021-12-20 08:25:22 --> Language Class Initialized
INFO - 2021-12-20 08:25:22 --> Language Class Initialized
INFO - 2021-12-20 08:25:22 --> Config Class Initialized
INFO - 2021-12-20 08:25:22 --> Loader Class Initialized
INFO - 2021-12-20 08:25:22 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:22 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:22 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:22 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:22 --> Controller Class Initialized
INFO - 2021-12-20 08:25:23 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:23 --> Total execution time: 0.0570
INFO - 2021-12-20 08:25:24 --> Config Class Initialized
INFO - 2021-12-20 08:25:24 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:24 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:24 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:24 --> URI Class Initialized
INFO - 2021-12-20 08:25:24 --> Router Class Initialized
INFO - 2021-12-20 08:25:24 --> Output Class Initialized
INFO - 2021-12-20 08:25:24 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:24 --> Input Class Initialized
INFO - 2021-12-20 08:25:24 --> Language Class Initialized
INFO - 2021-12-20 08:25:24 --> Language Class Initialized
INFO - 2021-12-20 08:25:24 --> Config Class Initialized
INFO - 2021-12-20 08:25:24 --> Loader Class Initialized
INFO - 2021-12-20 08:25:24 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:24 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:24 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:24 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:24 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:24 --> Controller Class Initialized
INFO - 2021-12-20 08:25:24 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:24 --> Total execution time: 0.0560
INFO - 2021-12-20 08:25:25 --> Config Class Initialized
INFO - 2021-12-20 08:25:25 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:25 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:25 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:25 --> URI Class Initialized
INFO - 2021-12-20 08:25:25 --> Router Class Initialized
INFO - 2021-12-20 08:25:25 --> Output Class Initialized
INFO - 2021-12-20 08:25:25 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:25 --> Input Class Initialized
INFO - 2021-12-20 08:25:25 --> Language Class Initialized
INFO - 2021-12-20 08:25:25 --> Language Class Initialized
INFO - 2021-12-20 08:25:25 --> Config Class Initialized
INFO - 2021-12-20 08:25:25 --> Loader Class Initialized
INFO - 2021-12-20 08:25:25 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:25 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:25 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:25 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:25 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:25 --> Controller Class Initialized
INFO - 2021-12-20 08:25:25 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:25 --> Total execution time: 0.0500
INFO - 2021-12-20 08:25:26 --> Config Class Initialized
INFO - 2021-12-20 08:25:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:26 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:26 --> URI Class Initialized
INFO - 2021-12-20 08:25:26 --> Router Class Initialized
INFO - 2021-12-20 08:25:26 --> Output Class Initialized
INFO - 2021-12-20 08:25:26 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:26 --> Input Class Initialized
INFO - 2021-12-20 08:25:26 --> Language Class Initialized
INFO - 2021-12-20 08:25:26 --> Language Class Initialized
INFO - 2021-12-20 08:25:26 --> Config Class Initialized
INFO - 2021-12-20 08:25:26 --> Loader Class Initialized
INFO - 2021-12-20 08:25:26 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:26 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:26 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:26 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:26 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:26 --> Controller Class Initialized
DEBUG - 2021-12-20 08:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:25:26 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:26 --> Total execution time: 0.0750
INFO - 2021-12-20 08:25:34 --> Config Class Initialized
INFO - 2021-12-20 08:25:34 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:34 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:34 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:34 --> URI Class Initialized
INFO - 2021-12-20 08:25:34 --> Router Class Initialized
INFO - 2021-12-20 08:25:34 --> Output Class Initialized
INFO - 2021-12-20 08:25:34 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:34 --> Input Class Initialized
INFO - 2021-12-20 08:25:34 --> Language Class Initialized
INFO - 2021-12-20 08:25:34 --> Language Class Initialized
INFO - 2021-12-20 08:25:34 --> Config Class Initialized
INFO - 2021-12-20 08:25:34 --> Loader Class Initialized
INFO - 2021-12-20 08:25:34 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:34 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:34 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:34 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:34 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:34 --> Controller Class Initialized
INFO - 2021-12-20 08:25:34 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:34 --> Total execution time: 0.0630
INFO - 2021-12-20 08:25:35 --> Config Class Initialized
INFO - 2021-12-20 08:25:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:35 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:35 --> URI Class Initialized
INFO - 2021-12-20 08:25:35 --> Router Class Initialized
INFO - 2021-12-20 08:25:35 --> Output Class Initialized
INFO - 2021-12-20 08:25:35 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:35 --> Input Class Initialized
INFO - 2021-12-20 08:25:35 --> Language Class Initialized
INFO - 2021-12-20 08:25:35 --> Language Class Initialized
INFO - 2021-12-20 08:25:35 --> Config Class Initialized
INFO - 2021-12-20 08:25:35 --> Loader Class Initialized
INFO - 2021-12-20 08:25:35 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:35 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:35 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:35 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:35 --> Controller Class Initialized
INFO - 2021-12-20 08:25:35 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:35 --> Total execution time: 0.0470
INFO - 2021-12-20 08:25:36 --> Config Class Initialized
INFO - 2021-12-20 08:25:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:36 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:36 --> URI Class Initialized
INFO - 2021-12-20 08:25:36 --> Router Class Initialized
INFO - 2021-12-20 08:25:36 --> Output Class Initialized
INFO - 2021-12-20 08:25:36 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:36 --> Input Class Initialized
INFO - 2021-12-20 08:25:36 --> Language Class Initialized
INFO - 2021-12-20 08:25:36 --> Language Class Initialized
INFO - 2021-12-20 08:25:36 --> Config Class Initialized
INFO - 2021-12-20 08:25:36 --> Loader Class Initialized
INFO - 2021-12-20 08:25:36 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:36 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:36 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:36 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:36 --> Controller Class Initialized
INFO - 2021-12-20 08:25:36 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:36 --> Total execution time: 0.0500
INFO - 2021-12-20 08:25:36 --> Config Class Initialized
INFO - 2021-12-20 08:25:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:36 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:36 --> URI Class Initialized
INFO - 2021-12-20 08:25:36 --> Router Class Initialized
INFO - 2021-12-20 08:25:36 --> Output Class Initialized
INFO - 2021-12-20 08:25:37 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:37 --> Input Class Initialized
INFO - 2021-12-20 08:25:37 --> Language Class Initialized
INFO - 2021-12-20 08:25:37 --> Language Class Initialized
INFO - 2021-12-20 08:25:37 --> Config Class Initialized
INFO - 2021-12-20 08:25:37 --> Loader Class Initialized
INFO - 2021-12-20 08:25:37 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:37 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:37 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:37 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:37 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:37 --> Controller Class Initialized
INFO - 2021-12-20 08:25:37 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:37 --> Total execution time: 0.0520
INFO - 2021-12-20 08:25:37 --> Config Class Initialized
INFO - 2021-12-20 08:25:37 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:37 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:37 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:37 --> URI Class Initialized
INFO - 2021-12-20 08:25:37 --> Router Class Initialized
INFO - 2021-12-20 08:25:37 --> Output Class Initialized
INFO - 2021-12-20 08:25:37 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:37 --> Input Class Initialized
INFO - 2021-12-20 08:25:37 --> Language Class Initialized
INFO - 2021-12-20 08:25:37 --> Language Class Initialized
INFO - 2021-12-20 08:25:37 --> Config Class Initialized
INFO - 2021-12-20 08:25:37 --> Loader Class Initialized
INFO - 2021-12-20 08:25:37 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:37 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:37 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:37 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:37 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:37 --> Controller Class Initialized
INFO - 2021-12-20 08:25:37 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:37 --> Total execution time: 0.0620
INFO - 2021-12-20 08:25:38 --> Config Class Initialized
INFO - 2021-12-20 08:25:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:38 --> URI Class Initialized
INFO - 2021-12-20 08:25:38 --> Router Class Initialized
INFO - 2021-12-20 08:25:38 --> Output Class Initialized
INFO - 2021-12-20 08:25:39 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:39 --> Input Class Initialized
INFO - 2021-12-20 08:25:39 --> Language Class Initialized
INFO - 2021-12-20 08:25:39 --> Language Class Initialized
INFO - 2021-12-20 08:25:39 --> Config Class Initialized
INFO - 2021-12-20 08:25:39 --> Loader Class Initialized
INFO - 2021-12-20 08:25:39 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:39 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:39 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:39 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:39 --> Controller Class Initialized
INFO - 2021-12-20 08:25:39 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:39 --> Total execution time: 0.0610
INFO - 2021-12-20 08:25:41 --> Config Class Initialized
INFO - 2021-12-20 08:25:41 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:41 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:41 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:41 --> URI Class Initialized
INFO - 2021-12-20 08:25:41 --> Router Class Initialized
INFO - 2021-12-20 08:25:41 --> Output Class Initialized
INFO - 2021-12-20 08:25:41 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:41 --> Input Class Initialized
INFO - 2021-12-20 08:25:41 --> Language Class Initialized
INFO - 2021-12-20 08:25:41 --> Language Class Initialized
INFO - 2021-12-20 08:25:41 --> Config Class Initialized
INFO - 2021-12-20 08:25:41 --> Loader Class Initialized
INFO - 2021-12-20 08:25:41 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:41 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:41 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:41 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:41 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:41 --> Controller Class Initialized
INFO - 2021-12-20 08:25:41 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:41 --> Total execution time: 0.0490
INFO - 2021-12-20 08:25:42 --> Config Class Initialized
INFO - 2021-12-20 08:25:42 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:42 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:42 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:42 --> URI Class Initialized
INFO - 2021-12-20 08:25:42 --> Router Class Initialized
INFO - 2021-12-20 08:25:42 --> Output Class Initialized
INFO - 2021-12-20 08:25:42 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:42 --> Input Class Initialized
INFO - 2021-12-20 08:25:42 --> Language Class Initialized
INFO - 2021-12-20 08:25:42 --> Language Class Initialized
INFO - 2021-12-20 08:25:42 --> Config Class Initialized
INFO - 2021-12-20 08:25:42 --> Loader Class Initialized
INFO - 2021-12-20 08:25:42 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:42 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:42 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:42 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:42 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:42 --> Controller Class Initialized
INFO - 2021-12-20 08:25:42 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:42 --> Total execution time: 0.0380
INFO - 2021-12-20 08:25:44 --> Config Class Initialized
INFO - 2021-12-20 08:25:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:44 --> URI Class Initialized
INFO - 2021-12-20 08:25:44 --> Router Class Initialized
INFO - 2021-12-20 08:25:44 --> Output Class Initialized
INFO - 2021-12-20 08:25:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:44 --> Input Class Initialized
INFO - 2021-12-20 08:25:44 --> Language Class Initialized
INFO - 2021-12-20 08:25:44 --> Language Class Initialized
INFO - 2021-12-20 08:25:44 --> Config Class Initialized
INFO - 2021-12-20 08:25:44 --> Loader Class Initialized
INFO - 2021-12-20 08:25:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:44 --> Controller Class Initialized
INFO - 2021-12-20 08:25:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:44 --> Total execution time: 0.0560
INFO - 2021-12-20 08:25:44 --> Config Class Initialized
INFO - 2021-12-20 08:25:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:44 --> URI Class Initialized
INFO - 2021-12-20 08:25:44 --> Router Class Initialized
INFO - 2021-12-20 08:25:44 --> Output Class Initialized
INFO - 2021-12-20 08:25:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:44 --> Input Class Initialized
INFO - 2021-12-20 08:25:44 --> Language Class Initialized
INFO - 2021-12-20 08:25:44 --> Language Class Initialized
INFO - 2021-12-20 08:25:44 --> Config Class Initialized
INFO - 2021-12-20 08:25:44 --> Loader Class Initialized
INFO - 2021-12-20 08:25:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:44 --> Controller Class Initialized
INFO - 2021-12-20 08:25:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:44 --> Total execution time: 0.0570
INFO - 2021-12-20 08:25:45 --> Config Class Initialized
INFO - 2021-12-20 08:25:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:45 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:45 --> URI Class Initialized
INFO - 2021-12-20 08:25:45 --> Router Class Initialized
INFO - 2021-12-20 08:25:45 --> Output Class Initialized
INFO - 2021-12-20 08:25:45 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:45 --> Input Class Initialized
INFO - 2021-12-20 08:25:45 --> Language Class Initialized
INFO - 2021-12-20 08:25:45 --> Language Class Initialized
INFO - 2021-12-20 08:25:45 --> Config Class Initialized
INFO - 2021-12-20 08:25:45 --> Loader Class Initialized
INFO - 2021-12-20 08:25:45 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:45 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:45 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:45 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:45 --> Controller Class Initialized
INFO - 2021-12-20 08:25:45 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:45 --> Total execution time: 0.0430
INFO - 2021-12-20 08:25:46 --> Config Class Initialized
INFO - 2021-12-20 08:25:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:46 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:46 --> URI Class Initialized
INFO - 2021-12-20 08:25:46 --> Router Class Initialized
INFO - 2021-12-20 08:25:46 --> Output Class Initialized
INFO - 2021-12-20 08:25:46 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:46 --> Input Class Initialized
INFO - 2021-12-20 08:25:46 --> Language Class Initialized
INFO - 2021-12-20 08:25:46 --> Language Class Initialized
INFO - 2021-12-20 08:25:46 --> Config Class Initialized
INFO - 2021-12-20 08:25:46 --> Loader Class Initialized
INFO - 2021-12-20 08:25:46 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:46 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:46 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:46 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:46 --> Controller Class Initialized
INFO - 2021-12-20 08:25:46 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:46 --> Total execution time: 0.0470
INFO - 2021-12-20 08:25:48 --> Config Class Initialized
INFO - 2021-12-20 08:25:48 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:48 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:48 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:48 --> URI Class Initialized
INFO - 2021-12-20 08:25:48 --> Router Class Initialized
INFO - 2021-12-20 08:25:48 --> Output Class Initialized
INFO - 2021-12-20 08:25:48 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:48 --> Input Class Initialized
INFO - 2021-12-20 08:25:48 --> Language Class Initialized
INFO - 2021-12-20 08:25:48 --> Language Class Initialized
INFO - 2021-12-20 08:25:48 --> Config Class Initialized
INFO - 2021-12-20 08:25:48 --> Loader Class Initialized
INFO - 2021-12-20 08:25:48 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:48 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:48 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:48 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:48 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:48 --> Controller Class Initialized
INFO - 2021-12-20 08:25:48 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:48 --> Total execution time: 0.0600
INFO - 2021-12-20 08:25:49 --> Config Class Initialized
INFO - 2021-12-20 08:25:49 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:49 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:49 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:49 --> URI Class Initialized
INFO - 2021-12-20 08:25:49 --> Router Class Initialized
INFO - 2021-12-20 08:25:49 --> Output Class Initialized
INFO - 2021-12-20 08:25:49 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:49 --> Input Class Initialized
INFO - 2021-12-20 08:25:49 --> Language Class Initialized
INFO - 2021-12-20 08:25:49 --> Language Class Initialized
INFO - 2021-12-20 08:25:49 --> Config Class Initialized
INFO - 2021-12-20 08:25:49 --> Loader Class Initialized
INFO - 2021-12-20 08:25:49 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:49 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:49 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:49 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:49 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:49 --> Controller Class Initialized
INFO - 2021-12-20 08:25:49 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:49 --> Total execution time: 0.0570
INFO - 2021-12-20 08:25:50 --> Config Class Initialized
INFO - 2021-12-20 08:25:50 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:50 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:50 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:50 --> URI Class Initialized
INFO - 2021-12-20 08:25:50 --> Router Class Initialized
INFO - 2021-12-20 08:25:50 --> Output Class Initialized
INFO - 2021-12-20 08:25:50 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:50 --> Input Class Initialized
INFO - 2021-12-20 08:25:50 --> Language Class Initialized
INFO - 2021-12-20 08:25:50 --> Language Class Initialized
INFO - 2021-12-20 08:25:50 --> Config Class Initialized
INFO - 2021-12-20 08:25:50 --> Loader Class Initialized
INFO - 2021-12-20 08:25:50 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:50 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:50 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:50 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:50 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:50 --> Controller Class Initialized
INFO - 2021-12-20 08:25:50 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:50 --> Total execution time: 0.0520
INFO - 2021-12-20 08:25:51 --> Config Class Initialized
INFO - 2021-12-20 08:25:51 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:51 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:51 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:51 --> URI Class Initialized
INFO - 2021-12-20 08:25:51 --> Router Class Initialized
INFO - 2021-12-20 08:25:51 --> Output Class Initialized
INFO - 2021-12-20 08:25:51 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:51 --> Input Class Initialized
INFO - 2021-12-20 08:25:51 --> Language Class Initialized
INFO - 2021-12-20 08:25:51 --> Language Class Initialized
INFO - 2021-12-20 08:25:51 --> Config Class Initialized
INFO - 2021-12-20 08:25:51 --> Loader Class Initialized
INFO - 2021-12-20 08:25:51 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:51 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:51 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:51 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:51 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:51 --> Controller Class Initialized
INFO - 2021-12-20 08:25:51 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:51 --> Total execution time: 0.0530
INFO - 2021-12-20 08:25:52 --> Config Class Initialized
INFO - 2021-12-20 08:25:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:52 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:52 --> URI Class Initialized
INFO - 2021-12-20 08:25:52 --> Router Class Initialized
INFO - 2021-12-20 08:25:52 --> Output Class Initialized
INFO - 2021-12-20 08:25:52 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:52 --> Input Class Initialized
INFO - 2021-12-20 08:25:52 --> Language Class Initialized
INFO - 2021-12-20 08:25:52 --> Language Class Initialized
INFO - 2021-12-20 08:25:52 --> Config Class Initialized
INFO - 2021-12-20 08:25:52 --> Loader Class Initialized
INFO - 2021-12-20 08:25:52 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:52 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:52 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:52 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:52 --> Controller Class Initialized
INFO - 2021-12-20 08:25:52 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:52 --> Total execution time: 0.0420
INFO - 2021-12-20 08:25:53 --> Config Class Initialized
INFO - 2021-12-20 08:25:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:53 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:53 --> URI Class Initialized
INFO - 2021-12-20 08:25:53 --> Router Class Initialized
INFO - 2021-12-20 08:25:53 --> Output Class Initialized
INFO - 2021-12-20 08:25:53 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:53 --> Input Class Initialized
INFO - 2021-12-20 08:25:53 --> Language Class Initialized
INFO - 2021-12-20 08:25:53 --> Language Class Initialized
INFO - 2021-12-20 08:25:53 --> Config Class Initialized
INFO - 2021-12-20 08:25:53 --> Loader Class Initialized
INFO - 2021-12-20 08:25:53 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:53 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:53 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:53 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:53 --> Controller Class Initialized
DEBUG - 2021-12-20 08:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:25:53 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:53 --> Total execution time: 0.0840
INFO - 2021-12-20 08:25:57 --> Config Class Initialized
INFO - 2021-12-20 08:25:57 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:57 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:57 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:57 --> URI Class Initialized
INFO - 2021-12-20 08:25:57 --> Router Class Initialized
INFO - 2021-12-20 08:25:57 --> Output Class Initialized
INFO - 2021-12-20 08:25:57 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:57 --> Input Class Initialized
INFO - 2021-12-20 08:25:57 --> Language Class Initialized
INFO - 2021-12-20 08:25:57 --> Language Class Initialized
INFO - 2021-12-20 08:25:57 --> Config Class Initialized
INFO - 2021-12-20 08:25:57 --> Loader Class Initialized
INFO - 2021-12-20 08:25:57 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:57 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:57 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:57 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:57 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:57 --> Controller Class Initialized
INFO - 2021-12-20 08:25:57 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:57 --> Total execution time: 0.0480
INFO - 2021-12-20 08:25:58 --> Config Class Initialized
INFO - 2021-12-20 08:25:58 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:58 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:58 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:58 --> URI Class Initialized
INFO - 2021-12-20 08:25:58 --> Router Class Initialized
INFO - 2021-12-20 08:25:58 --> Output Class Initialized
INFO - 2021-12-20 08:25:58 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:58 --> Input Class Initialized
INFO - 2021-12-20 08:25:58 --> Language Class Initialized
INFO - 2021-12-20 08:25:58 --> Language Class Initialized
INFO - 2021-12-20 08:25:58 --> Config Class Initialized
INFO - 2021-12-20 08:25:58 --> Loader Class Initialized
INFO - 2021-12-20 08:25:58 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:58 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:58 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:58 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:58 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:58 --> Controller Class Initialized
INFO - 2021-12-20 08:25:58 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:58 --> Total execution time: 0.0570
INFO - 2021-12-20 08:25:59 --> Config Class Initialized
INFO - 2021-12-20 08:25:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:25:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:25:59 --> Utf8 Class Initialized
INFO - 2021-12-20 08:25:59 --> URI Class Initialized
INFO - 2021-12-20 08:25:59 --> Router Class Initialized
INFO - 2021-12-20 08:25:59 --> Output Class Initialized
INFO - 2021-12-20 08:25:59 --> Security Class Initialized
DEBUG - 2021-12-20 08:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:25:59 --> Input Class Initialized
INFO - 2021-12-20 08:25:59 --> Language Class Initialized
INFO - 2021-12-20 08:25:59 --> Language Class Initialized
INFO - 2021-12-20 08:25:59 --> Config Class Initialized
INFO - 2021-12-20 08:25:59 --> Loader Class Initialized
INFO - 2021-12-20 08:25:59 --> Helper loaded: url_helper
INFO - 2021-12-20 08:25:59 --> Helper loaded: file_helper
INFO - 2021-12-20 08:25:59 --> Helper loaded: form_helper
INFO - 2021-12-20 08:25:59 --> Helper loaded: my_helper
INFO - 2021-12-20 08:25:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:25:59 --> Controller Class Initialized
INFO - 2021-12-20 08:25:59 --> Final output sent to browser
DEBUG - 2021-12-20 08:25:59 --> Total execution time: 0.0480
INFO - 2021-12-20 08:26:00 --> Config Class Initialized
INFO - 2021-12-20 08:26:00 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:00 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:00 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:00 --> URI Class Initialized
INFO - 2021-12-20 08:26:00 --> Router Class Initialized
INFO - 2021-12-20 08:26:00 --> Output Class Initialized
INFO - 2021-12-20 08:26:00 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:00 --> Input Class Initialized
INFO - 2021-12-20 08:26:00 --> Language Class Initialized
INFO - 2021-12-20 08:26:00 --> Language Class Initialized
INFO - 2021-12-20 08:26:00 --> Config Class Initialized
INFO - 2021-12-20 08:26:00 --> Loader Class Initialized
INFO - 2021-12-20 08:26:00 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:00 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:00 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:00 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:00 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:00 --> Controller Class Initialized
INFO - 2021-12-20 08:26:00 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:00 --> Total execution time: 0.0520
INFO - 2021-12-20 08:26:01 --> Config Class Initialized
INFO - 2021-12-20 08:26:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:01 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:01 --> URI Class Initialized
INFO - 2021-12-20 08:26:01 --> Router Class Initialized
INFO - 2021-12-20 08:26:01 --> Output Class Initialized
INFO - 2021-12-20 08:26:01 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:01 --> Input Class Initialized
INFO - 2021-12-20 08:26:01 --> Language Class Initialized
INFO - 2021-12-20 08:26:01 --> Language Class Initialized
INFO - 2021-12-20 08:26:01 --> Config Class Initialized
INFO - 2021-12-20 08:26:01 --> Loader Class Initialized
INFO - 2021-12-20 08:26:01 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:01 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:01 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:01 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:01 --> Controller Class Initialized
INFO - 2021-12-20 08:26:01 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:01 --> Total execution time: 0.0550
INFO - 2021-12-20 08:26:01 --> Config Class Initialized
INFO - 2021-12-20 08:26:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:01 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:01 --> URI Class Initialized
INFO - 2021-12-20 08:26:01 --> Router Class Initialized
INFO - 2021-12-20 08:26:01 --> Output Class Initialized
INFO - 2021-12-20 08:26:01 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:01 --> Input Class Initialized
INFO - 2021-12-20 08:26:01 --> Language Class Initialized
INFO - 2021-12-20 08:26:01 --> Language Class Initialized
INFO - 2021-12-20 08:26:01 --> Config Class Initialized
INFO - 2021-12-20 08:26:01 --> Loader Class Initialized
INFO - 2021-12-20 08:26:01 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:01 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:01 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:01 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:01 --> Controller Class Initialized
INFO - 2021-12-20 08:26:01 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:01 --> Total execution time: 0.0540
INFO - 2021-12-20 08:26:02 --> Config Class Initialized
INFO - 2021-12-20 08:26:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:02 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:02 --> URI Class Initialized
INFO - 2021-12-20 08:26:02 --> Router Class Initialized
INFO - 2021-12-20 08:26:02 --> Output Class Initialized
INFO - 2021-12-20 08:26:02 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:02 --> Input Class Initialized
INFO - 2021-12-20 08:26:02 --> Language Class Initialized
INFO - 2021-12-20 08:26:02 --> Language Class Initialized
INFO - 2021-12-20 08:26:02 --> Config Class Initialized
INFO - 2021-12-20 08:26:02 --> Loader Class Initialized
INFO - 2021-12-20 08:26:02 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:02 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:02 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:02 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:02 --> Controller Class Initialized
INFO - 2021-12-20 08:26:02 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:02 --> Total execution time: 0.0500
INFO - 2021-12-20 08:26:04 --> Config Class Initialized
INFO - 2021-12-20 08:26:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:04 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:04 --> URI Class Initialized
INFO - 2021-12-20 08:26:04 --> Router Class Initialized
INFO - 2021-12-20 08:26:04 --> Output Class Initialized
INFO - 2021-12-20 08:26:04 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:04 --> Input Class Initialized
INFO - 2021-12-20 08:26:04 --> Language Class Initialized
INFO - 2021-12-20 08:26:04 --> Language Class Initialized
INFO - 2021-12-20 08:26:04 --> Config Class Initialized
INFO - 2021-12-20 08:26:04 --> Loader Class Initialized
INFO - 2021-12-20 08:26:04 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:04 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:04 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:04 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:04 --> Controller Class Initialized
INFO - 2021-12-20 08:26:04 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:04 --> Total execution time: 0.0560
INFO - 2021-12-20 08:26:05 --> Config Class Initialized
INFO - 2021-12-20 08:26:05 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:05 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:05 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:05 --> URI Class Initialized
INFO - 2021-12-20 08:26:05 --> Router Class Initialized
INFO - 2021-12-20 08:26:05 --> Output Class Initialized
INFO - 2021-12-20 08:26:05 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:05 --> Input Class Initialized
INFO - 2021-12-20 08:26:05 --> Language Class Initialized
INFO - 2021-12-20 08:26:05 --> Language Class Initialized
INFO - 2021-12-20 08:26:05 --> Config Class Initialized
INFO - 2021-12-20 08:26:05 --> Loader Class Initialized
INFO - 2021-12-20 08:26:05 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:05 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:05 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:05 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:05 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:05 --> Controller Class Initialized
INFO - 2021-12-20 08:26:05 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:05 --> Total execution time: 0.0610
INFO - 2021-12-20 08:26:06 --> Config Class Initialized
INFO - 2021-12-20 08:26:06 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:06 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:06 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:06 --> URI Class Initialized
INFO - 2021-12-20 08:26:06 --> Router Class Initialized
INFO - 2021-12-20 08:26:06 --> Output Class Initialized
INFO - 2021-12-20 08:26:06 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:06 --> Input Class Initialized
INFO - 2021-12-20 08:26:06 --> Language Class Initialized
INFO - 2021-12-20 08:26:06 --> Language Class Initialized
INFO - 2021-12-20 08:26:06 --> Config Class Initialized
INFO - 2021-12-20 08:26:06 --> Loader Class Initialized
INFO - 2021-12-20 08:26:06 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:06 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:06 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:06 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:06 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:06 --> Controller Class Initialized
INFO - 2021-12-20 08:26:06 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:06 --> Total execution time: 0.0460
INFO - 2021-12-20 08:26:07 --> Config Class Initialized
INFO - 2021-12-20 08:26:07 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:07 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:07 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:07 --> URI Class Initialized
INFO - 2021-12-20 08:26:07 --> Router Class Initialized
INFO - 2021-12-20 08:26:07 --> Output Class Initialized
INFO - 2021-12-20 08:26:07 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:07 --> Input Class Initialized
INFO - 2021-12-20 08:26:07 --> Language Class Initialized
INFO - 2021-12-20 08:26:07 --> Language Class Initialized
INFO - 2021-12-20 08:26:07 --> Config Class Initialized
INFO - 2021-12-20 08:26:07 --> Loader Class Initialized
INFO - 2021-12-20 08:26:07 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:07 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:07 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:07 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:07 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:07 --> Controller Class Initialized
INFO - 2021-12-20 08:26:07 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:07 --> Total execution time: 0.0500
INFO - 2021-12-20 08:26:08 --> Config Class Initialized
INFO - 2021-12-20 08:26:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:08 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:08 --> URI Class Initialized
INFO - 2021-12-20 08:26:08 --> Router Class Initialized
INFO - 2021-12-20 08:26:08 --> Output Class Initialized
INFO - 2021-12-20 08:26:08 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:08 --> Input Class Initialized
INFO - 2021-12-20 08:26:08 --> Language Class Initialized
INFO - 2021-12-20 08:26:08 --> Language Class Initialized
INFO - 2021-12-20 08:26:08 --> Config Class Initialized
INFO - 2021-12-20 08:26:08 --> Loader Class Initialized
INFO - 2021-12-20 08:26:08 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:08 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:08 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:08 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:08 --> Controller Class Initialized
INFO - 2021-12-20 08:26:08 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:08 --> Total execution time: 0.0440
INFO - 2021-12-20 08:26:09 --> Config Class Initialized
INFO - 2021-12-20 08:26:09 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:09 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:09 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:09 --> URI Class Initialized
INFO - 2021-12-20 08:26:09 --> Router Class Initialized
INFO - 2021-12-20 08:26:09 --> Output Class Initialized
INFO - 2021-12-20 08:26:09 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:09 --> Input Class Initialized
INFO - 2021-12-20 08:26:09 --> Language Class Initialized
INFO - 2021-12-20 08:26:09 --> Language Class Initialized
INFO - 2021-12-20 08:26:09 --> Config Class Initialized
INFO - 2021-12-20 08:26:09 --> Loader Class Initialized
INFO - 2021-12-20 08:26:09 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:09 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:09 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:09 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:09 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:09 --> Controller Class Initialized
INFO - 2021-12-20 08:26:09 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:09 --> Total execution time: 0.0550
INFO - 2021-12-20 08:26:10 --> Config Class Initialized
INFO - 2021-12-20 08:26:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:10 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:10 --> URI Class Initialized
INFO - 2021-12-20 08:26:10 --> Router Class Initialized
INFO - 2021-12-20 08:26:10 --> Output Class Initialized
INFO - 2021-12-20 08:26:10 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:10 --> Input Class Initialized
INFO - 2021-12-20 08:26:10 --> Language Class Initialized
INFO - 2021-12-20 08:26:10 --> Language Class Initialized
INFO - 2021-12-20 08:26:10 --> Config Class Initialized
INFO - 2021-12-20 08:26:10 --> Loader Class Initialized
INFO - 2021-12-20 08:26:10 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:10 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:10 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:10 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:11 --> Controller Class Initialized
INFO - 2021-12-20 08:26:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:11 --> Total execution time: 0.0580
INFO - 2021-12-20 08:26:11 --> Config Class Initialized
INFO - 2021-12-20 08:26:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:11 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:11 --> URI Class Initialized
INFO - 2021-12-20 08:26:11 --> Router Class Initialized
INFO - 2021-12-20 08:26:11 --> Output Class Initialized
INFO - 2021-12-20 08:26:11 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:11 --> Input Class Initialized
INFO - 2021-12-20 08:26:11 --> Language Class Initialized
INFO - 2021-12-20 08:26:11 --> Language Class Initialized
INFO - 2021-12-20 08:26:11 --> Config Class Initialized
INFO - 2021-12-20 08:26:11 --> Loader Class Initialized
INFO - 2021-12-20 08:26:11 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:11 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:11 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:11 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:11 --> Controller Class Initialized
INFO - 2021-12-20 08:26:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:11 --> Total execution time: 0.0560
INFO - 2021-12-20 08:26:12 --> Config Class Initialized
INFO - 2021-12-20 08:26:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:12 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:12 --> URI Class Initialized
INFO - 2021-12-20 08:26:12 --> Router Class Initialized
INFO - 2021-12-20 08:26:12 --> Output Class Initialized
INFO - 2021-12-20 08:26:12 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:12 --> Input Class Initialized
INFO - 2021-12-20 08:26:12 --> Language Class Initialized
INFO - 2021-12-20 08:26:12 --> Language Class Initialized
INFO - 2021-12-20 08:26:12 --> Config Class Initialized
INFO - 2021-12-20 08:26:12 --> Loader Class Initialized
INFO - 2021-12-20 08:26:12 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:12 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:12 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:12 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:12 --> Controller Class Initialized
INFO - 2021-12-20 08:26:12 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:12 --> Total execution time: 0.0590
INFO - 2021-12-20 08:26:14 --> Config Class Initialized
INFO - 2021-12-20 08:26:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:14 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:14 --> URI Class Initialized
INFO - 2021-12-20 08:26:14 --> Router Class Initialized
INFO - 2021-12-20 08:26:14 --> Output Class Initialized
INFO - 2021-12-20 08:26:14 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:14 --> Input Class Initialized
INFO - 2021-12-20 08:26:14 --> Language Class Initialized
INFO - 2021-12-20 08:26:14 --> Language Class Initialized
INFO - 2021-12-20 08:26:14 --> Config Class Initialized
INFO - 2021-12-20 08:26:14 --> Loader Class Initialized
INFO - 2021-12-20 08:26:14 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:14 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:14 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:14 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:14 --> Controller Class Initialized
INFO - 2021-12-20 08:26:14 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:14 --> Total execution time: 0.0480
INFO - 2021-12-20 08:26:15 --> Config Class Initialized
INFO - 2021-12-20 08:26:15 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:15 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:15 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:15 --> URI Class Initialized
INFO - 2021-12-20 08:26:15 --> Router Class Initialized
INFO - 2021-12-20 08:26:15 --> Output Class Initialized
INFO - 2021-12-20 08:26:15 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:15 --> Input Class Initialized
INFO - 2021-12-20 08:26:15 --> Language Class Initialized
INFO - 2021-12-20 08:26:15 --> Language Class Initialized
INFO - 2021-12-20 08:26:15 --> Config Class Initialized
INFO - 2021-12-20 08:26:15 --> Loader Class Initialized
INFO - 2021-12-20 08:26:15 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:15 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:15 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:15 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:15 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:15 --> Controller Class Initialized
INFO - 2021-12-20 08:26:15 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:15 --> Total execution time: 0.0620
INFO - 2021-12-20 08:26:18 --> Config Class Initialized
INFO - 2021-12-20 08:26:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:18 --> URI Class Initialized
INFO - 2021-12-20 08:26:18 --> Router Class Initialized
INFO - 2021-12-20 08:26:18 --> Output Class Initialized
INFO - 2021-12-20 08:26:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:18 --> Input Class Initialized
INFO - 2021-12-20 08:26:18 --> Language Class Initialized
INFO - 2021-12-20 08:26:18 --> Language Class Initialized
INFO - 2021-12-20 08:26:18 --> Config Class Initialized
INFO - 2021-12-20 08:26:18 --> Loader Class Initialized
INFO - 2021-12-20 08:26:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:18 --> Controller Class Initialized
INFO - 2021-12-20 08:26:18 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:18 --> Total execution time: 0.0410
INFO - 2021-12-20 08:26:18 --> Config Class Initialized
INFO - 2021-12-20 08:26:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:18 --> URI Class Initialized
INFO - 2021-12-20 08:26:18 --> Router Class Initialized
INFO - 2021-12-20 08:26:18 --> Output Class Initialized
INFO - 2021-12-20 08:26:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:18 --> Input Class Initialized
INFO - 2021-12-20 08:26:18 --> Language Class Initialized
INFO - 2021-12-20 08:26:18 --> Language Class Initialized
INFO - 2021-12-20 08:26:18 --> Config Class Initialized
INFO - 2021-12-20 08:26:18 --> Loader Class Initialized
INFO - 2021-12-20 08:26:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:18 --> Controller Class Initialized
INFO - 2021-12-20 08:26:18 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:18 --> Total execution time: 0.0510
INFO - 2021-12-20 08:26:19 --> Config Class Initialized
INFO - 2021-12-20 08:26:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:19 --> URI Class Initialized
INFO - 2021-12-20 08:26:19 --> Router Class Initialized
INFO - 2021-12-20 08:26:19 --> Output Class Initialized
INFO - 2021-12-20 08:26:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:19 --> Input Class Initialized
INFO - 2021-12-20 08:26:19 --> Language Class Initialized
INFO - 2021-12-20 08:26:19 --> Language Class Initialized
INFO - 2021-12-20 08:26:19 --> Config Class Initialized
INFO - 2021-12-20 08:26:19 --> Loader Class Initialized
INFO - 2021-12-20 08:26:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:19 --> Controller Class Initialized
INFO - 2021-12-20 08:26:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:19 --> Total execution time: 0.0500
INFO - 2021-12-20 08:26:20 --> Config Class Initialized
INFO - 2021-12-20 08:26:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:20 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:20 --> URI Class Initialized
INFO - 2021-12-20 08:26:20 --> Router Class Initialized
INFO - 2021-12-20 08:26:20 --> Output Class Initialized
INFO - 2021-12-20 08:26:20 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:20 --> Input Class Initialized
INFO - 2021-12-20 08:26:20 --> Language Class Initialized
INFO - 2021-12-20 08:26:20 --> Language Class Initialized
INFO - 2021-12-20 08:26:20 --> Config Class Initialized
INFO - 2021-12-20 08:26:20 --> Loader Class Initialized
INFO - 2021-12-20 08:26:20 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:20 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:20 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:20 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:20 --> Controller Class Initialized
INFO - 2021-12-20 08:26:20 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:20 --> Total execution time: 0.0590
INFO - 2021-12-20 08:26:21 --> Config Class Initialized
INFO - 2021-12-20 08:26:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:21 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:21 --> URI Class Initialized
INFO - 2021-12-20 08:26:21 --> Router Class Initialized
INFO - 2021-12-20 08:26:21 --> Output Class Initialized
INFO - 2021-12-20 08:26:21 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:21 --> Input Class Initialized
INFO - 2021-12-20 08:26:21 --> Language Class Initialized
INFO - 2021-12-20 08:26:21 --> Language Class Initialized
INFO - 2021-12-20 08:26:21 --> Config Class Initialized
INFO - 2021-12-20 08:26:21 --> Loader Class Initialized
INFO - 2021-12-20 08:26:21 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:21 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:21 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:21 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:21 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:21 --> Controller Class Initialized
INFO - 2021-12-20 08:26:21 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:21 --> Total execution time: 0.0420
INFO - 2021-12-20 08:26:23 --> Config Class Initialized
INFO - 2021-12-20 08:26:23 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:23 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:23 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:23 --> URI Class Initialized
INFO - 2021-12-20 08:26:23 --> Router Class Initialized
INFO - 2021-12-20 08:26:23 --> Output Class Initialized
INFO - 2021-12-20 08:26:23 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:23 --> Input Class Initialized
INFO - 2021-12-20 08:26:23 --> Language Class Initialized
INFO - 2021-12-20 08:26:23 --> Language Class Initialized
INFO - 2021-12-20 08:26:23 --> Config Class Initialized
INFO - 2021-12-20 08:26:23 --> Loader Class Initialized
INFO - 2021-12-20 08:26:23 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:23 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:23 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:23 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:23 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:23 --> Controller Class Initialized
DEBUG - 2021-12-20 08:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:26:23 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:23 --> Total execution time: 0.0510
INFO - 2021-12-20 08:26:25 --> Config Class Initialized
INFO - 2021-12-20 08:26:25 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:25 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:25 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:25 --> URI Class Initialized
INFO - 2021-12-20 08:26:25 --> Router Class Initialized
INFO - 2021-12-20 08:26:25 --> Output Class Initialized
INFO - 2021-12-20 08:26:25 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:25 --> Input Class Initialized
INFO - 2021-12-20 08:26:25 --> Language Class Initialized
INFO - 2021-12-20 08:26:25 --> Language Class Initialized
INFO - 2021-12-20 08:26:25 --> Config Class Initialized
INFO - 2021-12-20 08:26:25 --> Loader Class Initialized
INFO - 2021-12-20 08:26:25 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:25 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:25 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:25 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:25 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:25 --> Controller Class Initialized
INFO - 2021-12-20 08:26:25 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:25 --> Total execution time: 0.0500
INFO - 2021-12-20 08:26:26 --> Config Class Initialized
INFO - 2021-12-20 08:26:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:26 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:26 --> URI Class Initialized
INFO - 2021-12-20 08:26:26 --> Router Class Initialized
INFO - 2021-12-20 08:26:26 --> Output Class Initialized
INFO - 2021-12-20 08:26:26 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:26 --> Input Class Initialized
INFO - 2021-12-20 08:26:26 --> Language Class Initialized
INFO - 2021-12-20 08:26:26 --> Language Class Initialized
INFO - 2021-12-20 08:26:26 --> Config Class Initialized
INFO - 2021-12-20 08:26:26 --> Loader Class Initialized
INFO - 2021-12-20 08:26:26 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:26 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:26 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:26 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:26 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:26 --> Controller Class Initialized
INFO - 2021-12-20 08:26:26 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:26 --> Total execution time: 0.0500
INFO - 2021-12-20 08:26:27 --> Config Class Initialized
INFO - 2021-12-20 08:26:27 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:27 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:27 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:27 --> URI Class Initialized
INFO - 2021-12-20 08:26:27 --> Router Class Initialized
INFO - 2021-12-20 08:26:27 --> Output Class Initialized
INFO - 2021-12-20 08:26:27 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:27 --> Input Class Initialized
INFO - 2021-12-20 08:26:27 --> Language Class Initialized
INFO - 2021-12-20 08:26:27 --> Language Class Initialized
INFO - 2021-12-20 08:26:27 --> Config Class Initialized
INFO - 2021-12-20 08:26:27 --> Loader Class Initialized
INFO - 2021-12-20 08:26:27 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:27 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:27 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:27 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:27 --> Controller Class Initialized
INFO - 2021-12-20 08:26:27 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:27 --> Total execution time: 0.0550
INFO - 2021-12-20 08:26:28 --> Config Class Initialized
INFO - 2021-12-20 08:26:28 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:28 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:28 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:28 --> URI Class Initialized
INFO - 2021-12-20 08:26:28 --> Router Class Initialized
INFO - 2021-12-20 08:26:28 --> Output Class Initialized
INFO - 2021-12-20 08:26:28 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:28 --> Input Class Initialized
INFO - 2021-12-20 08:26:28 --> Language Class Initialized
INFO - 2021-12-20 08:26:28 --> Language Class Initialized
INFO - 2021-12-20 08:26:28 --> Config Class Initialized
INFO - 2021-12-20 08:26:28 --> Loader Class Initialized
INFO - 2021-12-20 08:26:28 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:28 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:28 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:28 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:28 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:28 --> Controller Class Initialized
INFO - 2021-12-20 08:26:28 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:28 --> Total execution time: 0.0490
INFO - 2021-12-20 08:26:29 --> Config Class Initialized
INFO - 2021-12-20 08:26:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:29 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:29 --> URI Class Initialized
INFO - 2021-12-20 08:26:29 --> Router Class Initialized
INFO - 2021-12-20 08:26:29 --> Output Class Initialized
INFO - 2021-12-20 08:26:29 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:29 --> Input Class Initialized
INFO - 2021-12-20 08:26:29 --> Language Class Initialized
INFO - 2021-12-20 08:26:29 --> Language Class Initialized
INFO - 2021-12-20 08:26:29 --> Config Class Initialized
INFO - 2021-12-20 08:26:29 --> Loader Class Initialized
INFO - 2021-12-20 08:26:29 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:29 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:29 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:29 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:29 --> Controller Class Initialized
INFO - 2021-12-20 08:26:29 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:29 --> Total execution time: 0.0490
INFO - 2021-12-20 08:26:30 --> Config Class Initialized
INFO - 2021-12-20 08:26:30 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:30 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:30 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:30 --> URI Class Initialized
INFO - 2021-12-20 08:26:30 --> Router Class Initialized
INFO - 2021-12-20 08:26:30 --> Output Class Initialized
INFO - 2021-12-20 08:26:30 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:30 --> Input Class Initialized
INFO - 2021-12-20 08:26:30 --> Language Class Initialized
INFO - 2021-12-20 08:26:30 --> Language Class Initialized
INFO - 2021-12-20 08:26:30 --> Config Class Initialized
INFO - 2021-12-20 08:26:30 --> Loader Class Initialized
INFO - 2021-12-20 08:26:30 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:30 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:30 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:30 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:30 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:30 --> Controller Class Initialized
INFO - 2021-12-20 08:26:30 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:30 --> Total execution time: 0.0480
INFO - 2021-12-20 08:26:30 --> Config Class Initialized
INFO - 2021-12-20 08:26:30 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:30 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:30 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:30 --> URI Class Initialized
INFO - 2021-12-20 08:26:30 --> Router Class Initialized
INFO - 2021-12-20 08:26:30 --> Output Class Initialized
INFO - 2021-12-20 08:26:30 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:30 --> Input Class Initialized
INFO - 2021-12-20 08:26:30 --> Language Class Initialized
INFO - 2021-12-20 08:26:30 --> Language Class Initialized
INFO - 2021-12-20 08:26:30 --> Config Class Initialized
INFO - 2021-12-20 08:26:30 --> Loader Class Initialized
INFO - 2021-12-20 08:26:30 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:30 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:30 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:30 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:30 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:31 --> Controller Class Initialized
INFO - 2021-12-20 08:26:31 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:31 --> Total execution time: 0.0450
INFO - 2021-12-20 08:26:33 --> Config Class Initialized
INFO - 2021-12-20 08:26:33 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:33 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:33 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:33 --> URI Class Initialized
INFO - 2021-12-20 08:26:33 --> Router Class Initialized
INFO - 2021-12-20 08:26:33 --> Output Class Initialized
INFO - 2021-12-20 08:26:33 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:33 --> Input Class Initialized
INFO - 2021-12-20 08:26:33 --> Language Class Initialized
INFO - 2021-12-20 08:26:33 --> Language Class Initialized
INFO - 2021-12-20 08:26:33 --> Config Class Initialized
INFO - 2021-12-20 08:26:33 --> Loader Class Initialized
INFO - 2021-12-20 08:26:33 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:33 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:33 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:33 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:33 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:33 --> Controller Class Initialized
INFO - 2021-12-20 08:26:33 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:33 --> Total execution time: 0.0520
INFO - 2021-12-20 08:26:35 --> Config Class Initialized
INFO - 2021-12-20 08:26:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:35 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:35 --> URI Class Initialized
INFO - 2021-12-20 08:26:35 --> Router Class Initialized
INFO - 2021-12-20 08:26:35 --> Output Class Initialized
INFO - 2021-12-20 08:26:35 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:35 --> Input Class Initialized
INFO - 2021-12-20 08:26:35 --> Language Class Initialized
INFO - 2021-12-20 08:26:35 --> Language Class Initialized
INFO - 2021-12-20 08:26:35 --> Config Class Initialized
INFO - 2021-12-20 08:26:35 --> Loader Class Initialized
INFO - 2021-12-20 08:26:35 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:35 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:35 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:35 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:35 --> Controller Class Initialized
INFO - 2021-12-20 08:26:35 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:35 --> Total execution time: 0.0610
INFO - 2021-12-20 08:26:36 --> Config Class Initialized
INFO - 2021-12-20 08:26:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:36 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:36 --> URI Class Initialized
INFO - 2021-12-20 08:26:36 --> Router Class Initialized
INFO - 2021-12-20 08:26:36 --> Output Class Initialized
INFO - 2021-12-20 08:26:36 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:36 --> Input Class Initialized
INFO - 2021-12-20 08:26:36 --> Language Class Initialized
INFO - 2021-12-20 08:26:36 --> Language Class Initialized
INFO - 2021-12-20 08:26:36 --> Config Class Initialized
INFO - 2021-12-20 08:26:36 --> Loader Class Initialized
INFO - 2021-12-20 08:26:36 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:36 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:36 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:36 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:36 --> Controller Class Initialized
INFO - 2021-12-20 08:26:36 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:36 --> Total execution time: 0.0600
INFO - 2021-12-20 08:26:38 --> Config Class Initialized
INFO - 2021-12-20 08:26:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:38 --> URI Class Initialized
INFO - 2021-12-20 08:26:38 --> Router Class Initialized
INFO - 2021-12-20 08:26:38 --> Output Class Initialized
INFO - 2021-12-20 08:26:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:38 --> Input Class Initialized
INFO - 2021-12-20 08:26:38 --> Language Class Initialized
INFO - 2021-12-20 08:26:38 --> Language Class Initialized
INFO - 2021-12-20 08:26:38 --> Config Class Initialized
INFO - 2021-12-20 08:26:38 --> Loader Class Initialized
INFO - 2021-12-20 08:26:38 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:38 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:38 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:38 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:38 --> Controller Class Initialized
INFO - 2021-12-20 08:26:38 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:38 --> Total execution time: 0.0490
INFO - 2021-12-20 08:26:38 --> Config Class Initialized
INFO - 2021-12-20 08:26:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:38 --> URI Class Initialized
INFO - 2021-12-20 08:26:38 --> Router Class Initialized
INFO - 2021-12-20 08:26:38 --> Output Class Initialized
INFO - 2021-12-20 08:26:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:38 --> Input Class Initialized
INFO - 2021-12-20 08:26:38 --> Language Class Initialized
INFO - 2021-12-20 08:26:38 --> Language Class Initialized
INFO - 2021-12-20 08:26:38 --> Config Class Initialized
INFO - 2021-12-20 08:26:38 --> Loader Class Initialized
INFO - 2021-12-20 08:26:39 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:39 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:39 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:39 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:39 --> Controller Class Initialized
INFO - 2021-12-20 08:26:39 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:39 --> Total execution time: 0.0450
INFO - 2021-12-20 08:26:39 --> Config Class Initialized
INFO - 2021-12-20 08:26:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:39 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:39 --> URI Class Initialized
INFO - 2021-12-20 08:26:39 --> Router Class Initialized
INFO - 2021-12-20 08:26:39 --> Output Class Initialized
INFO - 2021-12-20 08:26:39 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:39 --> Input Class Initialized
INFO - 2021-12-20 08:26:39 --> Language Class Initialized
INFO - 2021-12-20 08:26:39 --> Language Class Initialized
INFO - 2021-12-20 08:26:39 --> Config Class Initialized
INFO - 2021-12-20 08:26:39 --> Loader Class Initialized
INFO - 2021-12-20 08:26:39 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:39 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:39 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:39 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:39 --> Controller Class Initialized
INFO - 2021-12-20 08:26:39 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:39 --> Total execution time: 0.0570
INFO - 2021-12-20 08:26:41 --> Config Class Initialized
INFO - 2021-12-20 08:26:41 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:41 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:41 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:41 --> URI Class Initialized
INFO - 2021-12-20 08:26:41 --> Router Class Initialized
INFO - 2021-12-20 08:26:41 --> Output Class Initialized
INFO - 2021-12-20 08:26:41 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:41 --> Input Class Initialized
INFO - 2021-12-20 08:26:41 --> Language Class Initialized
INFO - 2021-12-20 08:26:41 --> Language Class Initialized
INFO - 2021-12-20 08:26:41 --> Config Class Initialized
INFO - 2021-12-20 08:26:41 --> Loader Class Initialized
INFO - 2021-12-20 08:26:41 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:41 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:41 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:41 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:41 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:41 --> Controller Class Initialized
INFO - 2021-12-20 08:26:41 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:41 --> Total execution time: 0.0440
INFO - 2021-12-20 08:26:42 --> Config Class Initialized
INFO - 2021-12-20 08:26:42 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:42 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:42 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:42 --> URI Class Initialized
INFO - 2021-12-20 08:26:42 --> Router Class Initialized
INFO - 2021-12-20 08:26:42 --> Output Class Initialized
INFO - 2021-12-20 08:26:42 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:42 --> Input Class Initialized
INFO - 2021-12-20 08:26:42 --> Language Class Initialized
INFO - 2021-12-20 08:26:42 --> Language Class Initialized
INFO - 2021-12-20 08:26:42 --> Config Class Initialized
INFO - 2021-12-20 08:26:42 --> Loader Class Initialized
INFO - 2021-12-20 08:26:42 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:42 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:42 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:42 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:42 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:42 --> Controller Class Initialized
INFO - 2021-12-20 08:26:42 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:42 --> Total execution time: 0.0460
INFO - 2021-12-20 08:26:42 --> Config Class Initialized
INFO - 2021-12-20 08:26:42 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:42 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:42 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:42 --> URI Class Initialized
INFO - 2021-12-20 08:26:42 --> Router Class Initialized
INFO - 2021-12-20 08:26:42 --> Output Class Initialized
INFO - 2021-12-20 08:26:42 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:42 --> Input Class Initialized
INFO - 2021-12-20 08:26:42 --> Language Class Initialized
INFO - 2021-12-20 08:26:42 --> Language Class Initialized
INFO - 2021-12-20 08:26:42 --> Config Class Initialized
INFO - 2021-12-20 08:26:42 --> Loader Class Initialized
INFO - 2021-12-20 08:26:42 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:42 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:42 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:42 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:42 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:42 --> Controller Class Initialized
INFO - 2021-12-20 08:26:42 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:42 --> Total execution time: 0.0650
INFO - 2021-12-20 08:26:45 --> Config Class Initialized
INFO - 2021-12-20 08:26:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:45 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:45 --> URI Class Initialized
INFO - 2021-12-20 08:26:45 --> Router Class Initialized
INFO - 2021-12-20 08:26:45 --> Output Class Initialized
INFO - 2021-12-20 08:26:45 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:45 --> Input Class Initialized
INFO - 2021-12-20 08:26:45 --> Language Class Initialized
INFO - 2021-12-20 08:26:45 --> Language Class Initialized
INFO - 2021-12-20 08:26:45 --> Config Class Initialized
INFO - 2021-12-20 08:26:45 --> Loader Class Initialized
INFO - 2021-12-20 08:26:45 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:45 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:45 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:45 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:45 --> Controller Class Initialized
DEBUG - 2021-12-20 08:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:26:45 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:45 --> Total execution time: 0.0700
INFO - 2021-12-20 08:26:47 --> Config Class Initialized
INFO - 2021-12-20 08:26:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:47 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:47 --> URI Class Initialized
INFO - 2021-12-20 08:26:47 --> Router Class Initialized
INFO - 2021-12-20 08:26:47 --> Output Class Initialized
INFO - 2021-12-20 08:26:47 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:47 --> Input Class Initialized
INFO - 2021-12-20 08:26:47 --> Language Class Initialized
INFO - 2021-12-20 08:26:47 --> Language Class Initialized
INFO - 2021-12-20 08:26:47 --> Config Class Initialized
INFO - 2021-12-20 08:26:47 --> Loader Class Initialized
INFO - 2021-12-20 08:26:47 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:47 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:47 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:47 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:47 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:47 --> Controller Class Initialized
INFO - 2021-12-20 08:26:47 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:47 --> Total execution time: 0.0570
INFO - 2021-12-20 08:26:48 --> Config Class Initialized
INFO - 2021-12-20 08:26:48 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:48 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:48 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:48 --> URI Class Initialized
INFO - 2021-12-20 08:26:48 --> Router Class Initialized
INFO - 2021-12-20 08:26:48 --> Output Class Initialized
INFO - 2021-12-20 08:26:48 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:48 --> Input Class Initialized
INFO - 2021-12-20 08:26:48 --> Language Class Initialized
INFO - 2021-12-20 08:26:48 --> Language Class Initialized
INFO - 2021-12-20 08:26:48 --> Config Class Initialized
INFO - 2021-12-20 08:26:48 --> Loader Class Initialized
INFO - 2021-12-20 08:26:48 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:48 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:48 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:48 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:48 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:48 --> Controller Class Initialized
INFO - 2021-12-20 08:26:48 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:48 --> Total execution time: 0.0480
INFO - 2021-12-20 08:26:49 --> Config Class Initialized
INFO - 2021-12-20 08:26:49 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:49 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:49 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:49 --> URI Class Initialized
INFO - 2021-12-20 08:26:49 --> Router Class Initialized
INFO - 2021-12-20 08:26:49 --> Output Class Initialized
INFO - 2021-12-20 08:26:49 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:49 --> Input Class Initialized
INFO - 2021-12-20 08:26:49 --> Language Class Initialized
INFO - 2021-12-20 08:26:49 --> Language Class Initialized
INFO - 2021-12-20 08:26:49 --> Config Class Initialized
INFO - 2021-12-20 08:26:49 --> Loader Class Initialized
INFO - 2021-12-20 08:26:49 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:49 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:49 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:49 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:49 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:49 --> Controller Class Initialized
INFO - 2021-12-20 08:26:49 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:49 --> Total execution time: 0.0460
INFO - 2021-12-20 08:26:49 --> Config Class Initialized
INFO - 2021-12-20 08:26:49 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:49 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:49 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:49 --> URI Class Initialized
INFO - 2021-12-20 08:26:49 --> Router Class Initialized
INFO - 2021-12-20 08:26:49 --> Output Class Initialized
INFO - 2021-12-20 08:26:49 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:49 --> Input Class Initialized
INFO - 2021-12-20 08:26:49 --> Language Class Initialized
INFO - 2021-12-20 08:26:49 --> Language Class Initialized
INFO - 2021-12-20 08:26:49 --> Config Class Initialized
INFO - 2021-12-20 08:26:49 --> Loader Class Initialized
INFO - 2021-12-20 08:26:49 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:49 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:49 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:49 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:49 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:49 --> Controller Class Initialized
INFO - 2021-12-20 08:26:49 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:49 --> Total execution time: 0.0530
INFO - 2021-12-20 08:26:51 --> Config Class Initialized
INFO - 2021-12-20 08:26:51 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:51 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:51 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:51 --> URI Class Initialized
INFO - 2021-12-20 08:26:51 --> Router Class Initialized
INFO - 2021-12-20 08:26:51 --> Output Class Initialized
INFO - 2021-12-20 08:26:51 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:51 --> Input Class Initialized
INFO - 2021-12-20 08:26:51 --> Language Class Initialized
INFO - 2021-12-20 08:26:51 --> Language Class Initialized
INFO - 2021-12-20 08:26:51 --> Config Class Initialized
INFO - 2021-12-20 08:26:51 --> Loader Class Initialized
INFO - 2021-12-20 08:26:51 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:51 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:51 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:51 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:51 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:51 --> Controller Class Initialized
INFO - 2021-12-20 08:26:51 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:51 --> Total execution time: 0.0510
INFO - 2021-12-20 08:26:52 --> Config Class Initialized
INFO - 2021-12-20 08:26:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:52 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:52 --> URI Class Initialized
INFO - 2021-12-20 08:26:52 --> Router Class Initialized
INFO - 2021-12-20 08:26:52 --> Output Class Initialized
INFO - 2021-12-20 08:26:52 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:52 --> Input Class Initialized
INFO - 2021-12-20 08:26:52 --> Language Class Initialized
INFO - 2021-12-20 08:26:52 --> Language Class Initialized
INFO - 2021-12-20 08:26:52 --> Config Class Initialized
INFO - 2021-12-20 08:26:52 --> Loader Class Initialized
INFO - 2021-12-20 08:26:52 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:52 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:52 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:52 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:52 --> Controller Class Initialized
INFO - 2021-12-20 08:26:52 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:52 --> Total execution time: 0.0530
INFO - 2021-12-20 08:26:54 --> Config Class Initialized
INFO - 2021-12-20 08:26:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:54 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:54 --> URI Class Initialized
INFO - 2021-12-20 08:26:54 --> Router Class Initialized
INFO - 2021-12-20 08:26:54 --> Output Class Initialized
INFO - 2021-12-20 08:26:54 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:54 --> Input Class Initialized
INFO - 2021-12-20 08:26:54 --> Language Class Initialized
INFO - 2021-12-20 08:26:54 --> Language Class Initialized
INFO - 2021-12-20 08:26:54 --> Config Class Initialized
INFO - 2021-12-20 08:26:54 --> Loader Class Initialized
INFO - 2021-12-20 08:26:54 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:54 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:54 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:54 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:54 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:54 --> Controller Class Initialized
INFO - 2021-12-20 08:26:54 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:54 --> Total execution time: 0.0540
INFO - 2021-12-20 08:26:54 --> Config Class Initialized
INFO - 2021-12-20 08:26:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:54 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:54 --> URI Class Initialized
INFO - 2021-12-20 08:26:54 --> Router Class Initialized
INFO - 2021-12-20 08:26:54 --> Output Class Initialized
INFO - 2021-12-20 08:26:54 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:54 --> Input Class Initialized
INFO - 2021-12-20 08:26:54 --> Language Class Initialized
INFO - 2021-12-20 08:26:54 --> Language Class Initialized
INFO - 2021-12-20 08:26:54 --> Config Class Initialized
INFO - 2021-12-20 08:26:54 --> Loader Class Initialized
INFO - 2021-12-20 08:26:54 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:54 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:54 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:54 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:54 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:54 --> Controller Class Initialized
INFO - 2021-12-20 08:26:54 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:54 --> Total execution time: 0.0490
INFO - 2021-12-20 08:26:55 --> Config Class Initialized
INFO - 2021-12-20 08:26:55 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:55 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:55 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:55 --> URI Class Initialized
INFO - 2021-12-20 08:26:55 --> Router Class Initialized
INFO - 2021-12-20 08:26:55 --> Output Class Initialized
INFO - 2021-12-20 08:26:55 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:55 --> Input Class Initialized
INFO - 2021-12-20 08:26:55 --> Language Class Initialized
INFO - 2021-12-20 08:26:55 --> Language Class Initialized
INFO - 2021-12-20 08:26:55 --> Config Class Initialized
INFO - 2021-12-20 08:26:55 --> Loader Class Initialized
INFO - 2021-12-20 08:26:55 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:55 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:55 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:55 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:55 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:55 --> Controller Class Initialized
INFO - 2021-12-20 08:26:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:56 --> Total execution time: 0.0540
INFO - 2021-12-20 08:26:56 --> Config Class Initialized
INFO - 2021-12-20 08:26:56 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:26:56 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:26:56 --> Utf8 Class Initialized
INFO - 2021-12-20 08:26:56 --> URI Class Initialized
INFO - 2021-12-20 08:26:56 --> Router Class Initialized
INFO - 2021-12-20 08:26:56 --> Output Class Initialized
INFO - 2021-12-20 08:26:56 --> Security Class Initialized
DEBUG - 2021-12-20 08:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:26:56 --> Input Class Initialized
INFO - 2021-12-20 08:26:56 --> Language Class Initialized
INFO - 2021-12-20 08:26:56 --> Language Class Initialized
INFO - 2021-12-20 08:26:56 --> Config Class Initialized
INFO - 2021-12-20 08:26:56 --> Loader Class Initialized
INFO - 2021-12-20 08:26:56 --> Helper loaded: url_helper
INFO - 2021-12-20 08:26:56 --> Helper loaded: file_helper
INFO - 2021-12-20 08:26:56 --> Helper loaded: form_helper
INFO - 2021-12-20 08:26:56 --> Helper loaded: my_helper
INFO - 2021-12-20 08:26:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:26:56 --> Controller Class Initialized
INFO - 2021-12-20 08:26:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:26:56 --> Total execution time: 0.0470
INFO - 2021-12-20 08:27:01 --> Config Class Initialized
INFO - 2021-12-20 08:27:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:01 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:01 --> URI Class Initialized
INFO - 2021-12-20 08:27:01 --> Router Class Initialized
INFO - 2021-12-20 08:27:01 --> Output Class Initialized
INFO - 2021-12-20 08:27:01 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:01 --> Input Class Initialized
INFO - 2021-12-20 08:27:01 --> Language Class Initialized
INFO - 2021-12-20 08:27:01 --> Language Class Initialized
INFO - 2021-12-20 08:27:01 --> Config Class Initialized
INFO - 2021-12-20 08:27:01 --> Loader Class Initialized
INFO - 2021-12-20 08:27:01 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:01 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:01 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:01 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:01 --> Controller Class Initialized
DEBUG - 2021-12-20 08:27:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:27:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:27:01 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:01 --> Total execution time: 0.0550
INFO - 2021-12-20 08:27:07 --> Config Class Initialized
INFO - 2021-12-20 08:27:07 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:07 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:07 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:07 --> URI Class Initialized
INFO - 2021-12-20 08:27:07 --> Router Class Initialized
INFO - 2021-12-20 08:27:07 --> Output Class Initialized
INFO - 2021-12-20 08:27:07 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:07 --> Input Class Initialized
INFO - 2021-12-20 08:27:07 --> Language Class Initialized
INFO - 2021-12-20 08:27:07 --> Language Class Initialized
INFO - 2021-12-20 08:27:07 --> Config Class Initialized
INFO - 2021-12-20 08:27:07 --> Loader Class Initialized
INFO - 2021-12-20 08:27:07 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:07 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:07 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:07 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:07 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:07 --> Controller Class Initialized
INFO - 2021-12-20 08:27:07 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:07 --> Total execution time: 0.0810
INFO - 2021-12-20 08:27:07 --> Config Class Initialized
INFO - 2021-12-20 08:27:07 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:07 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:07 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:07 --> URI Class Initialized
INFO - 2021-12-20 08:27:07 --> Router Class Initialized
INFO - 2021-12-20 08:27:07 --> Output Class Initialized
INFO - 2021-12-20 08:27:07 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:07 --> Input Class Initialized
INFO - 2021-12-20 08:27:07 --> Language Class Initialized
INFO - 2021-12-20 08:27:07 --> Language Class Initialized
INFO - 2021-12-20 08:27:07 --> Config Class Initialized
INFO - 2021-12-20 08:27:07 --> Loader Class Initialized
INFO - 2021-12-20 08:27:07 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:07 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:07 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:07 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:07 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:07 --> Controller Class Initialized
INFO - 2021-12-20 08:27:07 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:07 --> Total execution time: 0.0660
INFO - 2021-12-20 08:27:08 --> Config Class Initialized
INFO - 2021-12-20 08:27:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:08 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:08 --> URI Class Initialized
INFO - 2021-12-20 08:27:08 --> Router Class Initialized
INFO - 2021-12-20 08:27:08 --> Output Class Initialized
INFO - 2021-12-20 08:27:08 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:08 --> Input Class Initialized
INFO - 2021-12-20 08:27:08 --> Language Class Initialized
INFO - 2021-12-20 08:27:08 --> Language Class Initialized
INFO - 2021-12-20 08:27:08 --> Config Class Initialized
INFO - 2021-12-20 08:27:08 --> Loader Class Initialized
INFO - 2021-12-20 08:27:08 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:08 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:08 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:08 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:08 --> Controller Class Initialized
INFO - 2021-12-20 08:27:08 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:08 --> Total execution time: 0.0640
INFO - 2021-12-20 08:27:09 --> Config Class Initialized
INFO - 2021-12-20 08:27:09 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:09 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:09 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:09 --> URI Class Initialized
INFO - 2021-12-20 08:27:09 --> Router Class Initialized
INFO - 2021-12-20 08:27:09 --> Output Class Initialized
INFO - 2021-12-20 08:27:09 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:09 --> Input Class Initialized
INFO - 2021-12-20 08:27:09 --> Language Class Initialized
INFO - 2021-12-20 08:27:09 --> Language Class Initialized
INFO - 2021-12-20 08:27:09 --> Config Class Initialized
INFO - 2021-12-20 08:27:09 --> Loader Class Initialized
INFO - 2021-12-20 08:27:09 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:09 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:09 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:09 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:09 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:09 --> Controller Class Initialized
INFO - 2021-12-20 08:27:09 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:09 --> Total execution time: 0.0780
INFO - 2021-12-20 08:27:10 --> Config Class Initialized
INFO - 2021-12-20 08:27:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:10 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:10 --> URI Class Initialized
INFO - 2021-12-20 08:27:10 --> Router Class Initialized
INFO - 2021-12-20 08:27:10 --> Output Class Initialized
INFO - 2021-12-20 08:27:10 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:10 --> Input Class Initialized
INFO - 2021-12-20 08:27:10 --> Language Class Initialized
INFO - 2021-12-20 08:27:10 --> Language Class Initialized
INFO - 2021-12-20 08:27:10 --> Config Class Initialized
INFO - 2021-12-20 08:27:10 --> Loader Class Initialized
INFO - 2021-12-20 08:27:10 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:10 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:10 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:10 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:10 --> Controller Class Initialized
INFO - 2021-12-20 08:27:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:11 --> Total execution time: 0.0750
INFO - 2021-12-20 08:27:11 --> Config Class Initialized
INFO - 2021-12-20 08:27:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:11 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:11 --> URI Class Initialized
INFO - 2021-12-20 08:27:11 --> Router Class Initialized
INFO - 2021-12-20 08:27:11 --> Output Class Initialized
INFO - 2021-12-20 08:27:11 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:11 --> Input Class Initialized
INFO - 2021-12-20 08:27:11 --> Language Class Initialized
INFO - 2021-12-20 08:27:11 --> Language Class Initialized
INFO - 2021-12-20 08:27:11 --> Config Class Initialized
INFO - 2021-12-20 08:27:11 --> Loader Class Initialized
INFO - 2021-12-20 08:27:11 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:11 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:11 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:11 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:11 --> Controller Class Initialized
INFO - 2021-12-20 08:27:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:11 --> Total execution time: 0.0660
INFO - 2021-12-20 08:27:12 --> Config Class Initialized
INFO - 2021-12-20 08:27:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:12 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:12 --> URI Class Initialized
INFO - 2021-12-20 08:27:12 --> Router Class Initialized
INFO - 2021-12-20 08:27:12 --> Output Class Initialized
INFO - 2021-12-20 08:27:12 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:12 --> Input Class Initialized
INFO - 2021-12-20 08:27:12 --> Language Class Initialized
INFO - 2021-12-20 08:27:12 --> Language Class Initialized
INFO - 2021-12-20 08:27:12 --> Config Class Initialized
INFO - 2021-12-20 08:27:12 --> Loader Class Initialized
INFO - 2021-12-20 08:27:12 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:12 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:12 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:12 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:12 --> Controller Class Initialized
INFO - 2021-12-20 08:27:12 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:12 --> Total execution time: 0.0610
INFO - 2021-12-20 08:27:13 --> Config Class Initialized
INFO - 2021-12-20 08:27:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:13 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:13 --> URI Class Initialized
INFO - 2021-12-20 08:27:13 --> Router Class Initialized
INFO - 2021-12-20 08:27:13 --> Output Class Initialized
INFO - 2021-12-20 08:27:13 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:13 --> Input Class Initialized
INFO - 2021-12-20 08:27:13 --> Language Class Initialized
INFO - 2021-12-20 08:27:13 --> Language Class Initialized
INFO - 2021-12-20 08:27:13 --> Config Class Initialized
INFO - 2021-12-20 08:27:13 --> Loader Class Initialized
INFO - 2021-12-20 08:27:13 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:13 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:13 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:13 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:13 --> Controller Class Initialized
INFO - 2021-12-20 08:27:13 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:13 --> Total execution time: 0.0600
INFO - 2021-12-20 08:27:14 --> Config Class Initialized
INFO - 2021-12-20 08:27:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:14 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:14 --> URI Class Initialized
INFO - 2021-12-20 08:27:14 --> Router Class Initialized
INFO - 2021-12-20 08:27:14 --> Output Class Initialized
INFO - 2021-12-20 08:27:14 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:14 --> Input Class Initialized
INFO - 2021-12-20 08:27:14 --> Language Class Initialized
INFO - 2021-12-20 08:27:14 --> Language Class Initialized
INFO - 2021-12-20 08:27:14 --> Config Class Initialized
INFO - 2021-12-20 08:27:14 --> Loader Class Initialized
INFO - 2021-12-20 08:27:14 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:14 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:14 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:14 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:14 --> Controller Class Initialized
INFO - 2021-12-20 08:27:14 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:14 --> Total execution time: 0.0810
INFO - 2021-12-20 08:27:15 --> Config Class Initialized
INFO - 2021-12-20 08:27:15 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:15 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:15 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:15 --> URI Class Initialized
INFO - 2021-12-20 08:27:15 --> Router Class Initialized
INFO - 2021-12-20 08:27:15 --> Output Class Initialized
INFO - 2021-12-20 08:27:15 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:15 --> Input Class Initialized
INFO - 2021-12-20 08:27:15 --> Language Class Initialized
INFO - 2021-12-20 08:27:15 --> Language Class Initialized
INFO - 2021-12-20 08:27:15 --> Config Class Initialized
INFO - 2021-12-20 08:27:15 --> Loader Class Initialized
INFO - 2021-12-20 08:27:15 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:15 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:15 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:15 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:15 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:15 --> Controller Class Initialized
INFO - 2021-12-20 08:27:15 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:15 --> Total execution time: 0.0720
INFO - 2021-12-20 08:27:17 --> Config Class Initialized
INFO - 2021-12-20 08:27:17 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:17 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:17 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:17 --> URI Class Initialized
INFO - 2021-12-20 08:27:17 --> Router Class Initialized
INFO - 2021-12-20 08:27:17 --> Output Class Initialized
INFO - 2021-12-20 08:27:17 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:17 --> Input Class Initialized
INFO - 2021-12-20 08:27:17 --> Language Class Initialized
INFO - 2021-12-20 08:27:17 --> Language Class Initialized
INFO - 2021-12-20 08:27:17 --> Config Class Initialized
INFO - 2021-12-20 08:27:17 --> Loader Class Initialized
INFO - 2021-12-20 08:27:17 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:17 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:17 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:17 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:17 --> Controller Class Initialized
INFO - 2021-12-20 08:27:17 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:17 --> Total execution time: 0.0620
INFO - 2021-12-20 08:27:18 --> Config Class Initialized
INFO - 2021-12-20 08:27:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:18 --> URI Class Initialized
INFO - 2021-12-20 08:27:18 --> Router Class Initialized
INFO - 2021-12-20 08:27:18 --> Output Class Initialized
INFO - 2021-12-20 08:27:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:18 --> Input Class Initialized
INFO - 2021-12-20 08:27:18 --> Language Class Initialized
INFO - 2021-12-20 08:27:18 --> Language Class Initialized
INFO - 2021-12-20 08:27:18 --> Config Class Initialized
INFO - 2021-12-20 08:27:18 --> Loader Class Initialized
INFO - 2021-12-20 08:27:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:18 --> Controller Class Initialized
INFO - 2021-12-20 08:27:18 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:18 --> Total execution time: 0.0700
INFO - 2021-12-20 08:27:18 --> Config Class Initialized
INFO - 2021-12-20 08:27:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:18 --> URI Class Initialized
INFO - 2021-12-20 08:27:18 --> Router Class Initialized
INFO - 2021-12-20 08:27:18 --> Output Class Initialized
INFO - 2021-12-20 08:27:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:18 --> Input Class Initialized
INFO - 2021-12-20 08:27:18 --> Language Class Initialized
INFO - 2021-12-20 08:27:18 --> Language Class Initialized
INFO - 2021-12-20 08:27:18 --> Config Class Initialized
INFO - 2021-12-20 08:27:18 --> Loader Class Initialized
INFO - 2021-12-20 08:27:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:19 --> Controller Class Initialized
INFO - 2021-12-20 08:27:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:19 --> Total execution time: 0.0710
INFO - 2021-12-20 08:27:20 --> Config Class Initialized
INFO - 2021-12-20 08:27:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:20 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:20 --> URI Class Initialized
INFO - 2021-12-20 08:27:20 --> Router Class Initialized
INFO - 2021-12-20 08:27:20 --> Output Class Initialized
INFO - 2021-12-20 08:27:20 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:20 --> Input Class Initialized
INFO - 2021-12-20 08:27:20 --> Language Class Initialized
INFO - 2021-12-20 08:27:20 --> Language Class Initialized
INFO - 2021-12-20 08:27:20 --> Config Class Initialized
INFO - 2021-12-20 08:27:20 --> Loader Class Initialized
INFO - 2021-12-20 08:27:20 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:20 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:20 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:20 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:20 --> Controller Class Initialized
DEBUG - 2021-12-20 08:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:27:20 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:20 --> Total execution time: 0.0560
INFO - 2021-12-20 08:27:25 --> Config Class Initialized
INFO - 2021-12-20 08:27:25 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:25 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:25 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:25 --> URI Class Initialized
INFO - 2021-12-20 08:27:25 --> Router Class Initialized
INFO - 2021-12-20 08:27:25 --> Output Class Initialized
INFO - 2021-12-20 08:27:25 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:25 --> Input Class Initialized
INFO - 2021-12-20 08:27:25 --> Language Class Initialized
INFO - 2021-12-20 08:27:25 --> Language Class Initialized
INFO - 2021-12-20 08:27:25 --> Config Class Initialized
INFO - 2021-12-20 08:27:25 --> Loader Class Initialized
INFO - 2021-12-20 08:27:25 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:25 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:25 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:25 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:25 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:25 --> Controller Class Initialized
INFO - 2021-12-20 08:27:25 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:25 --> Total execution time: 0.0550
INFO - 2021-12-20 08:27:26 --> Config Class Initialized
INFO - 2021-12-20 08:27:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:26 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:26 --> URI Class Initialized
INFO - 2021-12-20 08:27:26 --> Router Class Initialized
INFO - 2021-12-20 08:27:26 --> Output Class Initialized
INFO - 2021-12-20 08:27:26 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:26 --> Input Class Initialized
INFO - 2021-12-20 08:27:26 --> Language Class Initialized
INFO - 2021-12-20 08:27:26 --> Language Class Initialized
INFO - 2021-12-20 08:27:26 --> Config Class Initialized
INFO - 2021-12-20 08:27:26 --> Loader Class Initialized
INFO - 2021-12-20 08:27:26 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:26 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:26 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:26 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:26 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:26 --> Controller Class Initialized
INFO - 2021-12-20 08:27:26 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:26 --> Total execution time: 0.0470
INFO - 2021-12-20 08:27:27 --> Config Class Initialized
INFO - 2021-12-20 08:27:27 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:27 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:27 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:27 --> URI Class Initialized
INFO - 2021-12-20 08:27:27 --> Router Class Initialized
INFO - 2021-12-20 08:27:27 --> Output Class Initialized
INFO - 2021-12-20 08:27:27 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:27 --> Input Class Initialized
INFO - 2021-12-20 08:27:27 --> Language Class Initialized
INFO - 2021-12-20 08:27:27 --> Language Class Initialized
INFO - 2021-12-20 08:27:27 --> Config Class Initialized
INFO - 2021-12-20 08:27:27 --> Loader Class Initialized
INFO - 2021-12-20 08:27:27 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:27 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:27 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:27 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:27 --> Controller Class Initialized
INFO - 2021-12-20 08:27:27 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:27 --> Total execution time: 0.0460
INFO - 2021-12-20 08:27:28 --> Config Class Initialized
INFO - 2021-12-20 08:27:28 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:28 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:28 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:28 --> URI Class Initialized
INFO - 2021-12-20 08:27:28 --> Router Class Initialized
INFO - 2021-12-20 08:27:28 --> Output Class Initialized
INFO - 2021-12-20 08:27:28 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:28 --> Input Class Initialized
INFO - 2021-12-20 08:27:28 --> Language Class Initialized
INFO - 2021-12-20 08:27:28 --> Language Class Initialized
INFO - 2021-12-20 08:27:28 --> Config Class Initialized
INFO - 2021-12-20 08:27:28 --> Loader Class Initialized
INFO - 2021-12-20 08:27:28 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:28 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:28 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:28 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:28 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:28 --> Controller Class Initialized
INFO - 2021-12-20 08:27:28 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:28 --> Total execution time: 0.0550
INFO - 2021-12-20 08:27:29 --> Config Class Initialized
INFO - 2021-12-20 08:27:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:29 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:29 --> URI Class Initialized
INFO - 2021-12-20 08:27:29 --> Router Class Initialized
INFO - 2021-12-20 08:27:29 --> Output Class Initialized
INFO - 2021-12-20 08:27:29 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:29 --> Input Class Initialized
INFO - 2021-12-20 08:27:29 --> Language Class Initialized
INFO - 2021-12-20 08:27:29 --> Language Class Initialized
INFO - 2021-12-20 08:27:29 --> Config Class Initialized
INFO - 2021-12-20 08:27:29 --> Loader Class Initialized
INFO - 2021-12-20 08:27:29 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:29 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:29 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:29 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:29 --> Controller Class Initialized
INFO - 2021-12-20 08:27:29 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:29 --> Total execution time: 0.0520
INFO - 2021-12-20 08:27:29 --> Config Class Initialized
INFO - 2021-12-20 08:27:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:29 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:29 --> URI Class Initialized
INFO - 2021-12-20 08:27:29 --> Router Class Initialized
INFO - 2021-12-20 08:27:29 --> Output Class Initialized
INFO - 2021-12-20 08:27:29 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:29 --> Input Class Initialized
INFO - 2021-12-20 08:27:29 --> Language Class Initialized
INFO - 2021-12-20 08:27:29 --> Language Class Initialized
INFO - 2021-12-20 08:27:29 --> Config Class Initialized
INFO - 2021-12-20 08:27:29 --> Loader Class Initialized
INFO - 2021-12-20 08:27:29 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:29 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:29 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:29 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:29 --> Controller Class Initialized
INFO - 2021-12-20 08:27:29 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:29 --> Total execution time: 0.0530
INFO - 2021-12-20 08:27:30 --> Config Class Initialized
INFO - 2021-12-20 08:27:30 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:30 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:30 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:30 --> URI Class Initialized
INFO - 2021-12-20 08:27:30 --> Router Class Initialized
INFO - 2021-12-20 08:27:30 --> Output Class Initialized
INFO - 2021-12-20 08:27:30 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:30 --> Input Class Initialized
INFO - 2021-12-20 08:27:30 --> Language Class Initialized
INFO - 2021-12-20 08:27:30 --> Language Class Initialized
INFO - 2021-12-20 08:27:30 --> Config Class Initialized
INFO - 2021-12-20 08:27:30 --> Loader Class Initialized
INFO - 2021-12-20 08:27:30 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:30 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:30 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:30 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:30 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:30 --> Controller Class Initialized
INFO - 2021-12-20 08:27:30 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:30 --> Total execution time: 0.0530
INFO - 2021-12-20 08:27:32 --> Config Class Initialized
INFO - 2021-12-20 08:27:32 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:32 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:32 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:32 --> URI Class Initialized
INFO - 2021-12-20 08:27:32 --> Router Class Initialized
INFO - 2021-12-20 08:27:32 --> Output Class Initialized
INFO - 2021-12-20 08:27:32 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:32 --> Input Class Initialized
INFO - 2021-12-20 08:27:32 --> Language Class Initialized
INFO - 2021-12-20 08:27:32 --> Language Class Initialized
INFO - 2021-12-20 08:27:32 --> Config Class Initialized
INFO - 2021-12-20 08:27:32 --> Loader Class Initialized
INFO - 2021-12-20 08:27:32 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:32 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:32 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:32 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:32 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:32 --> Controller Class Initialized
INFO - 2021-12-20 08:27:32 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:32 --> Total execution time: 0.0530
INFO - 2021-12-20 08:27:33 --> Config Class Initialized
INFO - 2021-12-20 08:27:33 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:33 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:33 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:33 --> URI Class Initialized
INFO - 2021-12-20 08:27:33 --> Router Class Initialized
INFO - 2021-12-20 08:27:33 --> Output Class Initialized
INFO - 2021-12-20 08:27:33 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:33 --> Input Class Initialized
INFO - 2021-12-20 08:27:33 --> Language Class Initialized
INFO - 2021-12-20 08:27:33 --> Language Class Initialized
INFO - 2021-12-20 08:27:33 --> Config Class Initialized
INFO - 2021-12-20 08:27:33 --> Loader Class Initialized
INFO - 2021-12-20 08:27:33 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:33 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:33 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:33 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:33 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:33 --> Controller Class Initialized
INFO - 2021-12-20 08:27:33 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:33 --> Total execution time: 0.0370
INFO - 2021-12-20 08:27:35 --> Config Class Initialized
INFO - 2021-12-20 08:27:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:35 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:35 --> URI Class Initialized
INFO - 2021-12-20 08:27:35 --> Router Class Initialized
INFO - 2021-12-20 08:27:35 --> Output Class Initialized
INFO - 2021-12-20 08:27:35 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:35 --> Input Class Initialized
INFO - 2021-12-20 08:27:35 --> Language Class Initialized
INFO - 2021-12-20 08:27:35 --> Language Class Initialized
INFO - 2021-12-20 08:27:35 --> Config Class Initialized
INFO - 2021-12-20 08:27:35 --> Loader Class Initialized
INFO - 2021-12-20 08:27:35 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:35 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:35 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:35 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:35 --> Controller Class Initialized
INFO - 2021-12-20 08:27:35 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:35 --> Total execution time: 0.0470
INFO - 2021-12-20 08:27:36 --> Config Class Initialized
INFO - 2021-12-20 08:27:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:36 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:36 --> URI Class Initialized
INFO - 2021-12-20 08:27:36 --> Router Class Initialized
INFO - 2021-12-20 08:27:36 --> Output Class Initialized
INFO - 2021-12-20 08:27:36 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:36 --> Input Class Initialized
INFO - 2021-12-20 08:27:36 --> Language Class Initialized
INFO - 2021-12-20 08:27:36 --> Language Class Initialized
INFO - 2021-12-20 08:27:36 --> Config Class Initialized
INFO - 2021-12-20 08:27:36 --> Loader Class Initialized
INFO - 2021-12-20 08:27:36 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:36 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:36 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:36 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:36 --> Controller Class Initialized
INFO - 2021-12-20 08:27:36 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:36 --> Total execution time: 0.0490
INFO - 2021-12-20 08:27:37 --> Config Class Initialized
INFO - 2021-12-20 08:27:37 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:37 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:37 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:37 --> URI Class Initialized
INFO - 2021-12-20 08:27:37 --> Router Class Initialized
INFO - 2021-12-20 08:27:37 --> Output Class Initialized
INFO - 2021-12-20 08:27:37 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:37 --> Input Class Initialized
INFO - 2021-12-20 08:27:37 --> Language Class Initialized
INFO - 2021-12-20 08:27:37 --> Language Class Initialized
INFO - 2021-12-20 08:27:37 --> Config Class Initialized
INFO - 2021-12-20 08:27:37 --> Loader Class Initialized
INFO - 2021-12-20 08:27:37 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:37 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:37 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:37 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:37 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:37 --> Controller Class Initialized
INFO - 2021-12-20 08:27:37 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:37 --> Total execution time: 0.0390
INFO - 2021-12-20 08:27:38 --> Config Class Initialized
INFO - 2021-12-20 08:27:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:38 --> URI Class Initialized
INFO - 2021-12-20 08:27:38 --> Router Class Initialized
INFO - 2021-12-20 08:27:38 --> Output Class Initialized
INFO - 2021-12-20 08:27:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:38 --> Input Class Initialized
INFO - 2021-12-20 08:27:38 --> Language Class Initialized
INFO - 2021-12-20 08:27:38 --> Language Class Initialized
INFO - 2021-12-20 08:27:38 --> Config Class Initialized
INFO - 2021-12-20 08:27:38 --> Loader Class Initialized
INFO - 2021-12-20 08:27:38 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:38 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:38 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:38 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:38 --> Controller Class Initialized
INFO - 2021-12-20 08:27:38 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:38 --> Total execution time: 0.0430
INFO - 2021-12-20 08:27:39 --> Config Class Initialized
INFO - 2021-12-20 08:27:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:39 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:39 --> URI Class Initialized
INFO - 2021-12-20 08:27:39 --> Router Class Initialized
INFO - 2021-12-20 08:27:39 --> Output Class Initialized
INFO - 2021-12-20 08:27:39 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:39 --> Input Class Initialized
INFO - 2021-12-20 08:27:39 --> Language Class Initialized
INFO - 2021-12-20 08:27:39 --> Language Class Initialized
INFO - 2021-12-20 08:27:39 --> Config Class Initialized
INFO - 2021-12-20 08:27:39 --> Loader Class Initialized
INFO - 2021-12-20 08:27:39 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:39 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:39 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:39 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:39 --> Controller Class Initialized
DEBUG - 2021-12-20 08:27:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:27:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:27:39 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:39 --> Total execution time: 0.0650
INFO - 2021-12-20 08:27:44 --> Config Class Initialized
INFO - 2021-12-20 08:27:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:44 --> URI Class Initialized
INFO - 2021-12-20 08:27:44 --> Router Class Initialized
INFO - 2021-12-20 08:27:44 --> Output Class Initialized
INFO - 2021-12-20 08:27:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:44 --> Input Class Initialized
INFO - 2021-12-20 08:27:44 --> Language Class Initialized
INFO - 2021-12-20 08:27:44 --> Language Class Initialized
INFO - 2021-12-20 08:27:44 --> Config Class Initialized
INFO - 2021-12-20 08:27:44 --> Loader Class Initialized
INFO - 2021-12-20 08:27:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:44 --> Controller Class Initialized
INFO - 2021-12-20 08:27:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:44 --> Total execution time: 0.0530
INFO - 2021-12-20 08:27:45 --> Config Class Initialized
INFO - 2021-12-20 08:27:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:45 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:45 --> URI Class Initialized
INFO - 2021-12-20 08:27:45 --> Router Class Initialized
INFO - 2021-12-20 08:27:45 --> Output Class Initialized
INFO - 2021-12-20 08:27:45 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:45 --> Input Class Initialized
INFO - 2021-12-20 08:27:45 --> Language Class Initialized
INFO - 2021-12-20 08:27:45 --> Language Class Initialized
INFO - 2021-12-20 08:27:45 --> Config Class Initialized
INFO - 2021-12-20 08:27:45 --> Loader Class Initialized
INFO - 2021-12-20 08:27:45 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:45 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:45 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:45 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:45 --> Controller Class Initialized
INFO - 2021-12-20 08:27:45 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:45 --> Total execution time: 0.0500
INFO - 2021-12-20 08:27:45 --> Config Class Initialized
INFO - 2021-12-20 08:27:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:45 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:45 --> URI Class Initialized
INFO - 2021-12-20 08:27:45 --> Router Class Initialized
INFO - 2021-12-20 08:27:45 --> Output Class Initialized
INFO - 2021-12-20 08:27:45 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:45 --> Input Class Initialized
INFO - 2021-12-20 08:27:45 --> Language Class Initialized
INFO - 2021-12-20 08:27:45 --> Language Class Initialized
INFO - 2021-12-20 08:27:45 --> Config Class Initialized
INFO - 2021-12-20 08:27:45 --> Loader Class Initialized
INFO - 2021-12-20 08:27:45 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:45 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:45 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:45 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:45 --> Controller Class Initialized
INFO - 2021-12-20 08:27:45 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:45 --> Total execution time: 0.0510
INFO - 2021-12-20 08:27:46 --> Config Class Initialized
INFO - 2021-12-20 08:27:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:46 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:46 --> URI Class Initialized
INFO - 2021-12-20 08:27:46 --> Router Class Initialized
INFO - 2021-12-20 08:27:46 --> Output Class Initialized
INFO - 2021-12-20 08:27:46 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:46 --> Input Class Initialized
INFO - 2021-12-20 08:27:46 --> Language Class Initialized
INFO - 2021-12-20 08:27:46 --> Language Class Initialized
INFO - 2021-12-20 08:27:46 --> Config Class Initialized
INFO - 2021-12-20 08:27:46 --> Loader Class Initialized
INFO - 2021-12-20 08:27:46 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:46 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:46 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:46 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:46 --> Controller Class Initialized
INFO - 2021-12-20 08:27:46 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:46 --> Total execution time: 0.0600
INFO - 2021-12-20 08:27:47 --> Config Class Initialized
INFO - 2021-12-20 08:27:47 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:47 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:47 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:47 --> URI Class Initialized
INFO - 2021-12-20 08:27:47 --> Router Class Initialized
INFO - 2021-12-20 08:27:47 --> Output Class Initialized
INFO - 2021-12-20 08:27:47 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:47 --> Input Class Initialized
INFO - 2021-12-20 08:27:47 --> Language Class Initialized
INFO - 2021-12-20 08:27:47 --> Language Class Initialized
INFO - 2021-12-20 08:27:47 --> Config Class Initialized
INFO - 2021-12-20 08:27:47 --> Loader Class Initialized
INFO - 2021-12-20 08:27:47 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:47 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:47 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:47 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:47 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:47 --> Controller Class Initialized
INFO - 2021-12-20 08:27:47 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:47 --> Total execution time: 0.0610
INFO - 2021-12-20 08:27:49 --> Config Class Initialized
INFO - 2021-12-20 08:27:49 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:49 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:49 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:49 --> URI Class Initialized
INFO - 2021-12-20 08:27:49 --> Router Class Initialized
INFO - 2021-12-20 08:27:49 --> Output Class Initialized
INFO - 2021-12-20 08:27:49 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:49 --> Input Class Initialized
INFO - 2021-12-20 08:27:49 --> Language Class Initialized
INFO - 2021-12-20 08:27:49 --> Language Class Initialized
INFO - 2021-12-20 08:27:49 --> Config Class Initialized
INFO - 2021-12-20 08:27:49 --> Loader Class Initialized
INFO - 2021-12-20 08:27:49 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:49 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:49 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:49 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:49 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:49 --> Controller Class Initialized
INFO - 2021-12-20 08:27:49 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:49 --> Total execution time: 0.0460
INFO - 2021-12-20 08:27:56 --> Config Class Initialized
INFO - 2021-12-20 08:27:56 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:56 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:56 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:56 --> URI Class Initialized
INFO - 2021-12-20 08:27:56 --> Router Class Initialized
INFO - 2021-12-20 08:27:56 --> Output Class Initialized
INFO - 2021-12-20 08:27:56 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:56 --> Input Class Initialized
INFO - 2021-12-20 08:27:56 --> Language Class Initialized
INFO - 2021-12-20 08:27:56 --> Language Class Initialized
INFO - 2021-12-20 08:27:56 --> Config Class Initialized
INFO - 2021-12-20 08:27:56 --> Loader Class Initialized
INFO - 2021-12-20 08:27:56 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:56 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:56 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:56 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:56 --> Controller Class Initialized
INFO - 2021-12-20 08:27:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:56 --> Total execution time: 0.0500
INFO - 2021-12-20 08:27:57 --> Config Class Initialized
INFO - 2021-12-20 08:27:57 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:57 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:57 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:57 --> URI Class Initialized
INFO - 2021-12-20 08:27:57 --> Router Class Initialized
INFO - 2021-12-20 08:27:57 --> Output Class Initialized
INFO - 2021-12-20 08:27:57 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:57 --> Input Class Initialized
INFO - 2021-12-20 08:27:57 --> Language Class Initialized
INFO - 2021-12-20 08:27:57 --> Language Class Initialized
INFO - 2021-12-20 08:27:57 --> Config Class Initialized
INFO - 2021-12-20 08:27:57 --> Loader Class Initialized
INFO - 2021-12-20 08:27:57 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:57 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:57 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:57 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:57 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:57 --> Controller Class Initialized
INFO - 2021-12-20 08:27:57 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:57 --> Total execution time: 0.0600
INFO - 2021-12-20 08:27:58 --> Config Class Initialized
INFO - 2021-12-20 08:27:58 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:58 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:58 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:58 --> URI Class Initialized
INFO - 2021-12-20 08:27:58 --> Router Class Initialized
INFO - 2021-12-20 08:27:58 --> Output Class Initialized
INFO - 2021-12-20 08:27:58 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:58 --> Input Class Initialized
INFO - 2021-12-20 08:27:58 --> Language Class Initialized
INFO - 2021-12-20 08:27:58 --> Language Class Initialized
INFO - 2021-12-20 08:27:58 --> Config Class Initialized
INFO - 2021-12-20 08:27:58 --> Loader Class Initialized
INFO - 2021-12-20 08:27:58 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:58 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:58 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:58 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:58 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:58 --> Controller Class Initialized
INFO - 2021-12-20 08:27:58 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:58 --> Total execution time: 0.0560
INFO - 2021-12-20 08:27:59 --> Config Class Initialized
INFO - 2021-12-20 08:27:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:59 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:59 --> URI Class Initialized
INFO - 2021-12-20 08:27:59 --> Router Class Initialized
INFO - 2021-12-20 08:27:59 --> Output Class Initialized
INFO - 2021-12-20 08:27:59 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:59 --> Input Class Initialized
INFO - 2021-12-20 08:27:59 --> Language Class Initialized
INFO - 2021-12-20 08:27:59 --> Language Class Initialized
INFO - 2021-12-20 08:27:59 --> Config Class Initialized
INFO - 2021-12-20 08:27:59 --> Loader Class Initialized
INFO - 2021-12-20 08:27:59 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:59 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:59 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:59 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:59 --> Controller Class Initialized
INFO - 2021-12-20 08:27:59 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:59 --> Total execution time: 0.0540
INFO - 2021-12-20 08:27:59 --> Config Class Initialized
INFO - 2021-12-20 08:27:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:27:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:27:59 --> Utf8 Class Initialized
INFO - 2021-12-20 08:27:59 --> URI Class Initialized
INFO - 2021-12-20 08:27:59 --> Router Class Initialized
INFO - 2021-12-20 08:27:59 --> Output Class Initialized
INFO - 2021-12-20 08:27:59 --> Security Class Initialized
DEBUG - 2021-12-20 08:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:27:59 --> Input Class Initialized
INFO - 2021-12-20 08:27:59 --> Language Class Initialized
INFO - 2021-12-20 08:27:59 --> Language Class Initialized
INFO - 2021-12-20 08:27:59 --> Config Class Initialized
INFO - 2021-12-20 08:27:59 --> Loader Class Initialized
INFO - 2021-12-20 08:27:59 --> Helper loaded: url_helper
INFO - 2021-12-20 08:27:59 --> Helper loaded: file_helper
INFO - 2021-12-20 08:27:59 --> Helper loaded: form_helper
INFO - 2021-12-20 08:27:59 --> Helper loaded: my_helper
INFO - 2021-12-20 08:27:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:27:59 --> Controller Class Initialized
INFO - 2021-12-20 08:27:59 --> Final output sent to browser
DEBUG - 2021-12-20 08:27:59 --> Total execution time: 0.0510
INFO - 2021-12-20 08:28:02 --> Config Class Initialized
INFO - 2021-12-20 08:28:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:02 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:02 --> URI Class Initialized
INFO - 2021-12-20 08:28:02 --> Router Class Initialized
INFO - 2021-12-20 08:28:02 --> Output Class Initialized
INFO - 2021-12-20 08:28:02 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:02 --> Input Class Initialized
INFO - 2021-12-20 08:28:02 --> Language Class Initialized
INFO - 2021-12-20 08:28:02 --> Language Class Initialized
INFO - 2021-12-20 08:28:02 --> Config Class Initialized
INFO - 2021-12-20 08:28:02 --> Loader Class Initialized
INFO - 2021-12-20 08:28:02 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:02 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:02 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:02 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:02 --> Controller Class Initialized
INFO - 2021-12-20 08:28:02 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:02 --> Total execution time: 0.0540
INFO - 2021-12-20 08:28:03 --> Config Class Initialized
INFO - 2021-12-20 08:28:03 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:03 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:03 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:03 --> URI Class Initialized
INFO - 2021-12-20 08:28:03 --> Router Class Initialized
INFO - 2021-12-20 08:28:03 --> Output Class Initialized
INFO - 2021-12-20 08:28:03 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:03 --> Input Class Initialized
INFO - 2021-12-20 08:28:03 --> Language Class Initialized
INFO - 2021-12-20 08:28:03 --> Language Class Initialized
INFO - 2021-12-20 08:28:03 --> Config Class Initialized
INFO - 2021-12-20 08:28:03 --> Loader Class Initialized
INFO - 2021-12-20 08:28:03 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:03 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:03 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:03 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:03 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:03 --> Controller Class Initialized
INFO - 2021-12-20 08:28:03 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:03 --> Total execution time: 0.0620
INFO - 2021-12-20 08:28:04 --> Config Class Initialized
INFO - 2021-12-20 08:28:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:04 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:04 --> URI Class Initialized
INFO - 2021-12-20 08:28:04 --> Router Class Initialized
INFO - 2021-12-20 08:28:04 --> Output Class Initialized
INFO - 2021-12-20 08:28:04 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:04 --> Input Class Initialized
INFO - 2021-12-20 08:28:05 --> Language Class Initialized
INFO - 2021-12-20 08:28:05 --> Language Class Initialized
INFO - 2021-12-20 08:28:05 --> Config Class Initialized
INFO - 2021-12-20 08:28:05 --> Loader Class Initialized
INFO - 2021-12-20 08:28:05 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:05 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:05 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:05 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:05 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:05 --> Controller Class Initialized
INFO - 2021-12-20 08:28:05 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:05 --> Total execution time: 0.0510
INFO - 2021-12-20 08:28:10 --> Config Class Initialized
INFO - 2021-12-20 08:28:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:10 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:10 --> URI Class Initialized
INFO - 2021-12-20 08:28:10 --> Router Class Initialized
INFO - 2021-12-20 08:28:10 --> Output Class Initialized
INFO - 2021-12-20 08:28:10 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:10 --> Input Class Initialized
INFO - 2021-12-20 08:28:10 --> Language Class Initialized
INFO - 2021-12-20 08:28:10 --> Language Class Initialized
INFO - 2021-12-20 08:28:10 --> Config Class Initialized
INFO - 2021-12-20 08:28:10 --> Loader Class Initialized
INFO - 2021-12-20 08:28:10 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:10 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:10 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:10 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:10 --> Controller Class Initialized
INFO - 2021-12-20 08:28:10 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:10 --> Total execution time: 0.0520
INFO - 2021-12-20 08:28:10 --> Config Class Initialized
INFO - 2021-12-20 08:28:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:10 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:10 --> URI Class Initialized
INFO - 2021-12-20 08:28:10 --> Router Class Initialized
INFO - 2021-12-20 08:28:10 --> Output Class Initialized
INFO - 2021-12-20 08:28:10 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:10 --> Input Class Initialized
INFO - 2021-12-20 08:28:10 --> Language Class Initialized
INFO - 2021-12-20 08:28:10 --> Language Class Initialized
INFO - 2021-12-20 08:28:10 --> Config Class Initialized
INFO - 2021-12-20 08:28:10 --> Loader Class Initialized
INFO - 2021-12-20 08:28:10 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:10 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:10 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:10 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:10 --> Controller Class Initialized
INFO - 2021-12-20 08:28:10 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:10 --> Total execution time: 0.0560
INFO - 2021-12-20 08:28:11 --> Config Class Initialized
INFO - 2021-12-20 08:28:11 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:11 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:11 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:11 --> URI Class Initialized
INFO - 2021-12-20 08:28:11 --> Router Class Initialized
INFO - 2021-12-20 08:28:11 --> Output Class Initialized
INFO - 2021-12-20 08:28:11 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:11 --> Input Class Initialized
INFO - 2021-12-20 08:28:11 --> Language Class Initialized
INFO - 2021-12-20 08:28:11 --> Language Class Initialized
INFO - 2021-12-20 08:28:11 --> Config Class Initialized
INFO - 2021-12-20 08:28:11 --> Loader Class Initialized
INFO - 2021-12-20 08:28:11 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:11 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:11 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:11 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:11 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:11 --> Controller Class Initialized
INFO - 2021-12-20 08:28:11 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:11 --> Total execution time: 0.0500
INFO - 2021-12-20 08:28:12 --> Config Class Initialized
INFO - 2021-12-20 08:28:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:12 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:12 --> URI Class Initialized
INFO - 2021-12-20 08:28:12 --> Router Class Initialized
INFO - 2021-12-20 08:28:12 --> Output Class Initialized
INFO - 2021-12-20 08:28:12 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:12 --> Input Class Initialized
INFO - 2021-12-20 08:28:12 --> Language Class Initialized
INFO - 2021-12-20 08:28:12 --> Language Class Initialized
INFO - 2021-12-20 08:28:12 --> Config Class Initialized
INFO - 2021-12-20 08:28:12 --> Loader Class Initialized
INFO - 2021-12-20 08:28:12 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:12 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:12 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:12 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:12 --> Controller Class Initialized
INFO - 2021-12-20 08:28:12 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:12 --> Total execution time: 0.0510
INFO - 2021-12-20 08:28:12 --> Config Class Initialized
INFO - 2021-12-20 08:28:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:12 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:12 --> URI Class Initialized
INFO - 2021-12-20 08:28:12 --> Router Class Initialized
INFO - 2021-12-20 08:28:12 --> Output Class Initialized
INFO - 2021-12-20 08:28:12 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:12 --> Input Class Initialized
INFO - 2021-12-20 08:28:12 --> Language Class Initialized
INFO - 2021-12-20 08:28:12 --> Language Class Initialized
INFO - 2021-12-20 08:28:12 --> Config Class Initialized
INFO - 2021-12-20 08:28:12 --> Loader Class Initialized
INFO - 2021-12-20 08:28:12 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:12 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:12 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:12 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:12 --> Controller Class Initialized
INFO - 2021-12-20 08:28:12 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:12 --> Total execution time: 0.0490
INFO - 2021-12-20 08:28:13 --> Config Class Initialized
INFO - 2021-12-20 08:28:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:13 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:13 --> URI Class Initialized
INFO - 2021-12-20 08:28:13 --> Router Class Initialized
INFO - 2021-12-20 08:28:13 --> Output Class Initialized
INFO - 2021-12-20 08:28:13 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:13 --> Input Class Initialized
INFO - 2021-12-20 08:28:13 --> Language Class Initialized
INFO - 2021-12-20 08:28:13 --> Language Class Initialized
INFO - 2021-12-20 08:28:13 --> Config Class Initialized
INFO - 2021-12-20 08:28:13 --> Loader Class Initialized
INFO - 2021-12-20 08:28:13 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:13 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:13 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:13 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:13 --> Controller Class Initialized
INFO - 2021-12-20 08:28:13 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:13 --> Total execution time: 0.0480
INFO - 2021-12-20 08:28:16 --> Config Class Initialized
INFO - 2021-12-20 08:28:16 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:16 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:16 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:16 --> URI Class Initialized
INFO - 2021-12-20 08:28:16 --> Router Class Initialized
INFO - 2021-12-20 08:28:16 --> Output Class Initialized
INFO - 2021-12-20 08:28:16 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:16 --> Input Class Initialized
INFO - 2021-12-20 08:28:16 --> Language Class Initialized
INFO - 2021-12-20 08:28:16 --> Language Class Initialized
INFO - 2021-12-20 08:28:16 --> Config Class Initialized
INFO - 2021-12-20 08:28:16 --> Loader Class Initialized
INFO - 2021-12-20 08:28:16 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:16 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:16 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:16 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:16 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:16 --> Controller Class Initialized
INFO - 2021-12-20 08:28:16 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:16 --> Total execution time: 0.0540
INFO - 2021-12-20 08:28:17 --> Config Class Initialized
INFO - 2021-12-20 08:28:17 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:17 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:17 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:17 --> URI Class Initialized
INFO - 2021-12-20 08:28:17 --> Router Class Initialized
INFO - 2021-12-20 08:28:17 --> Output Class Initialized
INFO - 2021-12-20 08:28:17 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:17 --> Input Class Initialized
INFO - 2021-12-20 08:28:17 --> Language Class Initialized
INFO - 2021-12-20 08:28:17 --> Language Class Initialized
INFO - 2021-12-20 08:28:17 --> Config Class Initialized
INFO - 2021-12-20 08:28:17 --> Loader Class Initialized
INFO - 2021-12-20 08:28:17 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:17 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:17 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:17 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:17 --> Controller Class Initialized
INFO - 2021-12-20 08:28:17 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:17 --> Total execution time: 0.0520
INFO - 2021-12-20 08:28:18 --> Config Class Initialized
INFO - 2021-12-20 08:28:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:18 --> URI Class Initialized
INFO - 2021-12-20 08:28:18 --> Router Class Initialized
INFO - 2021-12-20 08:28:18 --> Output Class Initialized
INFO - 2021-12-20 08:28:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:18 --> Input Class Initialized
INFO - 2021-12-20 08:28:18 --> Language Class Initialized
INFO - 2021-12-20 08:28:18 --> Language Class Initialized
INFO - 2021-12-20 08:28:18 --> Config Class Initialized
INFO - 2021-12-20 08:28:18 --> Loader Class Initialized
INFO - 2021-12-20 08:28:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:19 --> Controller Class Initialized
INFO - 2021-12-20 08:28:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:19 --> Total execution time: 0.0560
INFO - 2021-12-20 08:28:19 --> Config Class Initialized
INFO - 2021-12-20 08:28:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:19 --> URI Class Initialized
INFO - 2021-12-20 08:28:19 --> Router Class Initialized
INFO - 2021-12-20 08:28:19 --> Output Class Initialized
INFO - 2021-12-20 08:28:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:19 --> Input Class Initialized
INFO - 2021-12-20 08:28:19 --> Language Class Initialized
INFO - 2021-12-20 08:28:19 --> Language Class Initialized
INFO - 2021-12-20 08:28:19 --> Config Class Initialized
INFO - 2021-12-20 08:28:19 --> Loader Class Initialized
INFO - 2021-12-20 08:28:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:19 --> Controller Class Initialized
INFO - 2021-12-20 08:28:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:19 --> Total execution time: 0.0540
INFO - 2021-12-20 08:28:20 --> Config Class Initialized
INFO - 2021-12-20 08:28:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:20 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:20 --> URI Class Initialized
INFO - 2021-12-20 08:28:20 --> Router Class Initialized
INFO - 2021-12-20 08:28:20 --> Output Class Initialized
INFO - 2021-12-20 08:28:20 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:20 --> Input Class Initialized
INFO - 2021-12-20 08:28:20 --> Language Class Initialized
INFO - 2021-12-20 08:28:20 --> Language Class Initialized
INFO - 2021-12-20 08:28:20 --> Config Class Initialized
INFO - 2021-12-20 08:28:20 --> Loader Class Initialized
INFO - 2021-12-20 08:28:20 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:20 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:20 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:20 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:20 --> Controller Class Initialized
INFO - 2021-12-20 08:28:20 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:20 --> Total execution time: 0.0470
INFO - 2021-12-20 08:28:21 --> Config Class Initialized
INFO - 2021-12-20 08:28:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:21 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:21 --> URI Class Initialized
INFO - 2021-12-20 08:28:21 --> Router Class Initialized
INFO - 2021-12-20 08:28:21 --> Output Class Initialized
INFO - 2021-12-20 08:28:21 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:21 --> Input Class Initialized
INFO - 2021-12-20 08:28:21 --> Language Class Initialized
INFO - 2021-12-20 08:28:21 --> Language Class Initialized
INFO - 2021-12-20 08:28:21 --> Config Class Initialized
INFO - 2021-12-20 08:28:21 --> Loader Class Initialized
INFO - 2021-12-20 08:28:21 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:21 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:21 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:21 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:21 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:21 --> Controller Class Initialized
INFO - 2021-12-20 08:28:21 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:21 --> Total execution time: 0.0470
INFO - 2021-12-20 08:28:22 --> Config Class Initialized
INFO - 2021-12-20 08:28:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:22 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:22 --> URI Class Initialized
INFO - 2021-12-20 08:28:22 --> Router Class Initialized
INFO - 2021-12-20 08:28:22 --> Output Class Initialized
INFO - 2021-12-20 08:28:22 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:22 --> Input Class Initialized
INFO - 2021-12-20 08:28:22 --> Language Class Initialized
INFO - 2021-12-20 08:28:22 --> Language Class Initialized
INFO - 2021-12-20 08:28:22 --> Config Class Initialized
INFO - 2021-12-20 08:28:22 --> Loader Class Initialized
INFO - 2021-12-20 08:28:22 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:22 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:22 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:22 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:22 --> Controller Class Initialized
INFO - 2021-12-20 08:28:22 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:22 --> Total execution time: 0.0530
INFO - 2021-12-20 08:28:26 --> Config Class Initialized
INFO - 2021-12-20 08:28:26 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:26 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:26 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:26 --> URI Class Initialized
INFO - 2021-12-20 08:28:26 --> Router Class Initialized
INFO - 2021-12-20 08:28:26 --> Output Class Initialized
INFO - 2021-12-20 08:28:26 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:26 --> Input Class Initialized
INFO - 2021-12-20 08:28:26 --> Language Class Initialized
INFO - 2021-12-20 08:28:26 --> Language Class Initialized
INFO - 2021-12-20 08:28:26 --> Config Class Initialized
INFO - 2021-12-20 08:28:26 --> Loader Class Initialized
INFO - 2021-12-20 08:28:26 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:26 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:26 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:26 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:26 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:26 --> Controller Class Initialized
INFO - 2021-12-20 08:28:26 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:26 --> Total execution time: 0.0480
INFO - 2021-12-20 08:28:27 --> Config Class Initialized
INFO - 2021-12-20 08:28:27 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:27 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:27 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:27 --> URI Class Initialized
INFO - 2021-12-20 08:28:27 --> Router Class Initialized
INFO - 2021-12-20 08:28:27 --> Output Class Initialized
INFO - 2021-12-20 08:28:27 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:27 --> Input Class Initialized
INFO - 2021-12-20 08:28:27 --> Language Class Initialized
INFO - 2021-12-20 08:28:27 --> Language Class Initialized
INFO - 2021-12-20 08:28:27 --> Config Class Initialized
INFO - 2021-12-20 08:28:27 --> Loader Class Initialized
INFO - 2021-12-20 08:28:27 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:27 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:27 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:27 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:27 --> Controller Class Initialized
INFO - 2021-12-20 08:28:27 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:27 --> Total execution time: 0.0410
INFO - 2021-12-20 08:28:29 --> Config Class Initialized
INFO - 2021-12-20 08:28:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:29 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:29 --> URI Class Initialized
INFO - 2021-12-20 08:28:29 --> Router Class Initialized
INFO - 2021-12-20 08:28:29 --> Output Class Initialized
INFO - 2021-12-20 08:28:29 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:29 --> Input Class Initialized
INFO - 2021-12-20 08:28:29 --> Language Class Initialized
INFO - 2021-12-20 08:28:29 --> Language Class Initialized
INFO - 2021-12-20 08:28:29 --> Config Class Initialized
INFO - 2021-12-20 08:28:29 --> Loader Class Initialized
INFO - 2021-12-20 08:28:29 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:29 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:29 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:29 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:29 --> Controller Class Initialized
DEBUG - 2021-12-20 08:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:28:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:28:29 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:29 --> Total execution time: 0.0630
INFO - 2021-12-20 08:28:34 --> Config Class Initialized
INFO - 2021-12-20 08:28:34 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:34 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:34 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:34 --> URI Class Initialized
INFO - 2021-12-20 08:28:34 --> Router Class Initialized
INFO - 2021-12-20 08:28:34 --> Output Class Initialized
INFO - 2021-12-20 08:28:34 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:34 --> Input Class Initialized
INFO - 2021-12-20 08:28:34 --> Language Class Initialized
INFO - 2021-12-20 08:28:34 --> Language Class Initialized
INFO - 2021-12-20 08:28:34 --> Config Class Initialized
INFO - 2021-12-20 08:28:34 --> Loader Class Initialized
INFO - 2021-12-20 08:28:34 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:34 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:34 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:34 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:34 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:34 --> Controller Class Initialized
INFO - 2021-12-20 08:28:34 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:34 --> Total execution time: 0.0560
INFO - 2021-12-20 08:28:35 --> Config Class Initialized
INFO - 2021-12-20 08:28:35 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:35 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:35 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:35 --> URI Class Initialized
INFO - 2021-12-20 08:28:35 --> Router Class Initialized
INFO - 2021-12-20 08:28:35 --> Output Class Initialized
INFO - 2021-12-20 08:28:35 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:35 --> Input Class Initialized
INFO - 2021-12-20 08:28:35 --> Language Class Initialized
INFO - 2021-12-20 08:28:35 --> Language Class Initialized
INFO - 2021-12-20 08:28:35 --> Config Class Initialized
INFO - 2021-12-20 08:28:35 --> Loader Class Initialized
INFO - 2021-12-20 08:28:35 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:35 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:35 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:35 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:35 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:35 --> Controller Class Initialized
INFO - 2021-12-20 08:28:35 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:35 --> Total execution time: 0.0480
INFO - 2021-12-20 08:28:36 --> Config Class Initialized
INFO - 2021-12-20 08:28:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:36 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:36 --> URI Class Initialized
INFO - 2021-12-20 08:28:36 --> Router Class Initialized
INFO - 2021-12-20 08:28:36 --> Output Class Initialized
INFO - 2021-12-20 08:28:36 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:36 --> Input Class Initialized
INFO - 2021-12-20 08:28:36 --> Language Class Initialized
INFO - 2021-12-20 08:28:36 --> Language Class Initialized
INFO - 2021-12-20 08:28:36 --> Config Class Initialized
INFO - 2021-12-20 08:28:36 --> Loader Class Initialized
INFO - 2021-12-20 08:28:36 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:36 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:36 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:36 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:36 --> Controller Class Initialized
INFO - 2021-12-20 08:28:36 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:36 --> Total execution time: 0.0620
INFO - 2021-12-20 08:28:37 --> Config Class Initialized
INFO - 2021-12-20 08:28:37 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:37 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:37 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:37 --> URI Class Initialized
INFO - 2021-12-20 08:28:37 --> Router Class Initialized
INFO - 2021-12-20 08:28:37 --> Output Class Initialized
INFO - 2021-12-20 08:28:37 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:37 --> Input Class Initialized
INFO - 2021-12-20 08:28:37 --> Language Class Initialized
INFO - 2021-12-20 08:28:37 --> Language Class Initialized
INFO - 2021-12-20 08:28:37 --> Config Class Initialized
INFO - 2021-12-20 08:28:37 --> Loader Class Initialized
INFO - 2021-12-20 08:28:37 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:37 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:37 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:37 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:37 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:37 --> Controller Class Initialized
INFO - 2021-12-20 08:28:37 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:37 --> Total execution time: 0.0510
INFO - 2021-12-20 08:28:37 --> Config Class Initialized
INFO - 2021-12-20 08:28:37 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:37 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:37 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:37 --> URI Class Initialized
INFO - 2021-12-20 08:28:37 --> Router Class Initialized
INFO - 2021-12-20 08:28:37 --> Output Class Initialized
INFO - 2021-12-20 08:28:37 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:37 --> Input Class Initialized
INFO - 2021-12-20 08:28:37 --> Language Class Initialized
INFO - 2021-12-20 08:28:37 --> Language Class Initialized
INFO - 2021-12-20 08:28:37 --> Config Class Initialized
INFO - 2021-12-20 08:28:37 --> Loader Class Initialized
INFO - 2021-12-20 08:28:37 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:37 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:37 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:37 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:37 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:37 --> Controller Class Initialized
INFO - 2021-12-20 08:28:37 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:37 --> Total execution time: 0.0530
INFO - 2021-12-20 08:28:38 --> Config Class Initialized
INFO - 2021-12-20 08:28:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:38 --> URI Class Initialized
INFO - 2021-12-20 08:28:38 --> Router Class Initialized
INFO - 2021-12-20 08:28:38 --> Output Class Initialized
INFO - 2021-12-20 08:28:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:38 --> Input Class Initialized
INFO - 2021-12-20 08:28:38 --> Language Class Initialized
INFO - 2021-12-20 08:28:38 --> Language Class Initialized
INFO - 2021-12-20 08:28:38 --> Config Class Initialized
INFO - 2021-12-20 08:28:38 --> Loader Class Initialized
INFO - 2021-12-20 08:28:38 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:38 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:38 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:38 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:38 --> Controller Class Initialized
INFO - 2021-12-20 08:28:38 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:38 --> Total execution time: 0.0550
INFO - 2021-12-20 08:28:44 --> Config Class Initialized
INFO - 2021-12-20 08:28:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:44 --> URI Class Initialized
INFO - 2021-12-20 08:28:44 --> Router Class Initialized
INFO - 2021-12-20 08:28:44 --> Output Class Initialized
INFO - 2021-12-20 08:28:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:44 --> Input Class Initialized
INFO - 2021-12-20 08:28:44 --> Language Class Initialized
INFO - 2021-12-20 08:28:44 --> Language Class Initialized
INFO - 2021-12-20 08:28:44 --> Config Class Initialized
INFO - 2021-12-20 08:28:44 --> Loader Class Initialized
INFO - 2021-12-20 08:28:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:44 --> Controller Class Initialized
INFO - 2021-12-20 08:28:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:44 --> Total execution time: 0.0520
INFO - 2021-12-20 08:28:44 --> Config Class Initialized
INFO - 2021-12-20 08:28:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:44 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:44 --> URI Class Initialized
INFO - 2021-12-20 08:28:44 --> Router Class Initialized
INFO - 2021-12-20 08:28:44 --> Output Class Initialized
INFO - 2021-12-20 08:28:44 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:44 --> Input Class Initialized
INFO - 2021-12-20 08:28:44 --> Language Class Initialized
INFO - 2021-12-20 08:28:44 --> Language Class Initialized
INFO - 2021-12-20 08:28:44 --> Config Class Initialized
INFO - 2021-12-20 08:28:44 --> Loader Class Initialized
INFO - 2021-12-20 08:28:44 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:44 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:44 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:44 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:44 --> Controller Class Initialized
INFO - 2021-12-20 08:28:44 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:44 --> Total execution time: 0.0520
INFO - 2021-12-20 08:28:46 --> Config Class Initialized
INFO - 2021-12-20 08:28:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:46 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:46 --> URI Class Initialized
INFO - 2021-12-20 08:28:46 --> Router Class Initialized
INFO - 2021-12-20 08:28:46 --> Output Class Initialized
INFO - 2021-12-20 08:28:46 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:46 --> Input Class Initialized
INFO - 2021-12-20 08:28:46 --> Language Class Initialized
INFO - 2021-12-20 08:28:46 --> Language Class Initialized
INFO - 2021-12-20 08:28:46 --> Config Class Initialized
INFO - 2021-12-20 08:28:46 --> Loader Class Initialized
INFO - 2021-12-20 08:28:46 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:46 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:46 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:46 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:46 --> Controller Class Initialized
INFO - 2021-12-20 08:28:46 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:46 --> Total execution time: 0.0570
INFO - 2021-12-20 08:28:48 --> Config Class Initialized
INFO - 2021-12-20 08:28:48 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:28:48 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:28:48 --> Utf8 Class Initialized
INFO - 2021-12-20 08:28:48 --> URI Class Initialized
INFO - 2021-12-20 08:28:48 --> Router Class Initialized
INFO - 2021-12-20 08:28:48 --> Output Class Initialized
INFO - 2021-12-20 08:28:48 --> Security Class Initialized
DEBUG - 2021-12-20 08:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:28:48 --> Input Class Initialized
INFO - 2021-12-20 08:28:48 --> Language Class Initialized
INFO - 2021-12-20 08:28:48 --> Language Class Initialized
INFO - 2021-12-20 08:28:48 --> Config Class Initialized
INFO - 2021-12-20 08:28:48 --> Loader Class Initialized
INFO - 2021-12-20 08:28:48 --> Helper loaded: url_helper
INFO - 2021-12-20 08:28:48 --> Helper loaded: file_helper
INFO - 2021-12-20 08:28:48 --> Helper loaded: form_helper
INFO - 2021-12-20 08:28:48 --> Helper loaded: my_helper
INFO - 2021-12-20 08:28:48 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:28:48 --> Controller Class Initialized
DEBUG - 2021-12-20 08:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:28:48 --> Final output sent to browser
DEBUG - 2021-12-20 08:28:48 --> Total execution time: 0.0580
INFO - 2021-12-20 08:40:52 --> Config Class Initialized
INFO - 2021-12-20 08:40:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:40:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:40:52 --> Utf8 Class Initialized
INFO - 2021-12-20 08:40:52 --> URI Class Initialized
INFO - 2021-12-20 08:40:52 --> Router Class Initialized
INFO - 2021-12-20 08:40:52 --> Output Class Initialized
INFO - 2021-12-20 08:40:52 --> Security Class Initialized
DEBUG - 2021-12-20 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:40:52 --> Input Class Initialized
INFO - 2021-12-20 08:40:52 --> Language Class Initialized
INFO - 2021-12-20 08:40:52 --> Language Class Initialized
INFO - 2021-12-20 08:40:52 --> Config Class Initialized
INFO - 2021-12-20 08:40:52 --> Loader Class Initialized
INFO - 2021-12-20 08:40:52 --> Helper loaded: url_helper
INFO - 2021-12-20 08:40:52 --> Helper loaded: file_helper
INFO - 2021-12-20 08:40:52 --> Helper loaded: form_helper
INFO - 2021-12-20 08:40:52 --> Helper loaded: my_helper
INFO - 2021-12-20 08:40:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:40:52 --> Controller Class Initialized
DEBUG - 2021-12-20 08:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 08:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:40:52 --> Final output sent to browser
DEBUG - 2021-12-20 08:40:52 --> Total execution time: 0.0490
INFO - 2021-12-20 08:40:53 --> Config Class Initialized
INFO - 2021-12-20 08:40:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:40:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:40:53 --> Utf8 Class Initialized
INFO - 2021-12-20 08:40:53 --> URI Class Initialized
INFO - 2021-12-20 08:40:53 --> Router Class Initialized
INFO - 2021-12-20 08:40:53 --> Output Class Initialized
INFO - 2021-12-20 08:40:53 --> Security Class Initialized
DEBUG - 2021-12-20 08:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:40:53 --> Input Class Initialized
INFO - 2021-12-20 08:40:53 --> Language Class Initialized
INFO - 2021-12-20 08:40:53 --> Language Class Initialized
INFO - 2021-12-20 08:40:53 --> Config Class Initialized
INFO - 2021-12-20 08:40:53 --> Loader Class Initialized
INFO - 2021-12-20 08:40:53 --> Helper loaded: url_helper
INFO - 2021-12-20 08:40:53 --> Helper loaded: file_helper
INFO - 2021-12-20 08:40:53 --> Helper loaded: form_helper
INFO - 2021-12-20 08:40:53 --> Helper loaded: my_helper
INFO - 2021-12-20 08:40:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:40:53 --> Controller Class Initialized
INFO - 2021-12-20 08:40:55 --> Config Class Initialized
INFO - 2021-12-20 08:40:55 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:40:55 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:40:55 --> Utf8 Class Initialized
INFO - 2021-12-20 08:40:55 --> URI Class Initialized
INFO - 2021-12-20 08:40:55 --> Router Class Initialized
INFO - 2021-12-20 08:40:55 --> Output Class Initialized
INFO - 2021-12-20 08:40:55 --> Security Class Initialized
DEBUG - 2021-12-20 08:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:40:56 --> Input Class Initialized
INFO - 2021-12-20 08:40:56 --> Language Class Initialized
INFO - 2021-12-20 08:40:56 --> Language Class Initialized
INFO - 2021-12-20 08:40:56 --> Config Class Initialized
INFO - 2021-12-20 08:40:56 --> Loader Class Initialized
INFO - 2021-12-20 08:40:56 --> Helper loaded: url_helper
INFO - 2021-12-20 08:40:56 --> Helper loaded: file_helper
INFO - 2021-12-20 08:40:56 --> Helper loaded: form_helper
INFO - 2021-12-20 08:40:56 --> Helper loaded: my_helper
INFO - 2021-12-20 08:40:56 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:40:56 --> Controller Class Initialized
DEBUG - 2021-12-20 08:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:40:56 --> Final output sent to browser
DEBUG - 2021-12-20 08:40:56 --> Total execution time: 0.1330
INFO - 2021-12-20 08:40:59 --> Config Class Initialized
INFO - 2021-12-20 08:40:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:40:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:40:59 --> Utf8 Class Initialized
INFO - 2021-12-20 08:40:59 --> URI Class Initialized
INFO - 2021-12-20 08:40:59 --> Router Class Initialized
INFO - 2021-12-20 08:40:59 --> Output Class Initialized
INFO - 2021-12-20 08:40:59 --> Security Class Initialized
DEBUG - 2021-12-20 08:40:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:40:59 --> Input Class Initialized
INFO - 2021-12-20 08:40:59 --> Language Class Initialized
INFO - 2021-12-20 08:40:59 --> Language Class Initialized
INFO - 2021-12-20 08:40:59 --> Config Class Initialized
INFO - 2021-12-20 08:40:59 --> Loader Class Initialized
INFO - 2021-12-20 08:40:59 --> Helper loaded: url_helper
INFO - 2021-12-20 08:40:59 --> Helper loaded: file_helper
INFO - 2021-12-20 08:40:59 --> Helper loaded: form_helper
INFO - 2021-12-20 08:40:59 --> Helper loaded: my_helper
INFO - 2021-12-20 08:41:00 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:41:00 --> Controller Class Initialized
DEBUG - 2021-12-20 08:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-12-20 08:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:41:00 --> Final output sent to browser
DEBUG - 2021-12-20 08:41:00 --> Total execution time: 0.0550
INFO - 2021-12-20 08:41:00 --> Config Class Initialized
INFO - 2021-12-20 08:41:00 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:41:00 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:41:00 --> Utf8 Class Initialized
INFO - 2021-12-20 08:41:00 --> URI Class Initialized
INFO - 2021-12-20 08:41:00 --> Router Class Initialized
INFO - 2021-12-20 08:41:00 --> Output Class Initialized
INFO - 2021-12-20 08:41:00 --> Security Class Initialized
DEBUG - 2021-12-20 08:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:41:00 --> Input Class Initialized
INFO - 2021-12-20 08:41:00 --> Language Class Initialized
INFO - 2021-12-20 08:41:00 --> Language Class Initialized
INFO - 2021-12-20 08:41:00 --> Config Class Initialized
INFO - 2021-12-20 08:41:00 --> Loader Class Initialized
INFO - 2021-12-20 08:41:00 --> Helper loaded: url_helper
INFO - 2021-12-20 08:41:00 --> Helper loaded: file_helper
INFO - 2021-12-20 08:41:00 --> Helper loaded: form_helper
INFO - 2021-12-20 08:41:00 --> Helper loaded: my_helper
INFO - 2021-12-20 08:41:00 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:41:00 --> Controller Class Initialized
INFO - 2021-12-20 08:41:19 --> Config Class Initialized
INFO - 2021-12-20 08:41:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:41:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:41:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:41:19 --> URI Class Initialized
INFO - 2021-12-20 08:41:19 --> Router Class Initialized
INFO - 2021-12-20 08:41:19 --> Output Class Initialized
INFO - 2021-12-20 08:41:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:41:19 --> Input Class Initialized
INFO - 2021-12-20 08:41:19 --> Language Class Initialized
INFO - 2021-12-20 08:41:19 --> Language Class Initialized
INFO - 2021-12-20 08:41:19 --> Config Class Initialized
INFO - 2021-12-20 08:41:19 --> Loader Class Initialized
INFO - 2021-12-20 08:41:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:41:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:41:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:41:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:41:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:41:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:41:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:41:19 --> Controller Class Initialized
DEBUG - 2021-12-20 08:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:41:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:41:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:41:19 --> Total execution time: 0.0560
INFO - 2021-12-20 08:41:20 --> Config Class Initialized
INFO - 2021-12-20 08:41:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:41:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:41:20 --> Utf8 Class Initialized
INFO - 2021-12-20 08:41:20 --> URI Class Initialized
INFO - 2021-12-20 08:41:20 --> Router Class Initialized
INFO - 2021-12-20 08:41:20 --> Output Class Initialized
INFO - 2021-12-20 08:41:20 --> Security Class Initialized
DEBUG - 2021-12-20 08:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:41:20 --> Input Class Initialized
INFO - 2021-12-20 08:41:20 --> Language Class Initialized
INFO - 2021-12-20 08:41:20 --> Language Class Initialized
INFO - 2021-12-20 08:41:20 --> Config Class Initialized
INFO - 2021-12-20 08:41:20 --> Loader Class Initialized
INFO - 2021-12-20 08:41:20 --> Helper loaded: url_helper
INFO - 2021-12-20 08:41:20 --> Helper loaded: file_helper
INFO - 2021-12-20 08:41:20 --> Helper loaded: form_helper
INFO - 2021-12-20 08:41:20 --> Helper loaded: my_helper
INFO - 2021-12-20 08:41:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:41:20 --> Controller Class Initialized
DEBUG - 2021-12-20 08:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-20 08:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:41:20 --> Final output sent to browser
DEBUG - 2021-12-20 08:41:20 --> Total execution time: 0.0420
INFO - 2021-12-20 08:41:20 --> Config Class Initialized
INFO - 2021-12-20 08:41:20 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:41:20 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:41:20 --> Utf8 Class Initialized
INFO - 2021-12-20 08:41:20 --> URI Class Initialized
INFO - 2021-12-20 08:41:20 --> Router Class Initialized
INFO - 2021-12-20 08:41:20 --> Output Class Initialized
INFO - 2021-12-20 08:41:20 --> Security Class Initialized
DEBUG - 2021-12-20 08:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:41:20 --> Input Class Initialized
INFO - 2021-12-20 08:41:20 --> Language Class Initialized
INFO - 2021-12-20 08:41:20 --> Language Class Initialized
INFO - 2021-12-20 08:41:20 --> Config Class Initialized
INFO - 2021-12-20 08:41:20 --> Loader Class Initialized
INFO - 2021-12-20 08:41:20 --> Helper loaded: url_helper
INFO - 2021-12-20 08:41:20 --> Helper loaded: file_helper
INFO - 2021-12-20 08:41:20 --> Helper loaded: form_helper
INFO - 2021-12-20 08:41:20 --> Helper loaded: my_helper
INFO - 2021-12-20 08:41:20 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:41:20 --> Controller Class Initialized
INFO - 2021-12-20 08:44:33 --> Config Class Initialized
INFO - 2021-12-20 08:44:33 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:44:33 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:44:33 --> Utf8 Class Initialized
INFO - 2021-12-20 08:44:33 --> URI Class Initialized
INFO - 2021-12-20 08:44:33 --> Router Class Initialized
INFO - 2021-12-20 08:44:33 --> Output Class Initialized
INFO - 2021-12-20 08:44:33 --> Security Class Initialized
DEBUG - 2021-12-20 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:44:33 --> Input Class Initialized
INFO - 2021-12-20 08:44:33 --> Language Class Initialized
INFO - 2021-12-20 08:44:33 --> Language Class Initialized
INFO - 2021-12-20 08:44:33 --> Config Class Initialized
INFO - 2021-12-20 08:44:33 --> Loader Class Initialized
INFO - 2021-12-20 08:44:33 --> Helper loaded: url_helper
INFO - 2021-12-20 08:44:33 --> Helper loaded: file_helper
INFO - 2021-12-20 08:44:33 --> Helper loaded: form_helper
INFO - 2021-12-20 08:44:33 --> Helper loaded: my_helper
INFO - 2021-12-20 08:44:33 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:44:33 --> Controller Class Initialized
DEBUG - 2021-12-20 08:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-20 08:44:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:44:33 --> Final output sent to browser
DEBUG - 2021-12-20 08:44:33 --> Total execution time: 0.0420
INFO - 2021-12-20 08:44:33 --> Config Class Initialized
INFO - 2021-12-20 08:44:33 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:44:33 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:44:33 --> Utf8 Class Initialized
INFO - 2021-12-20 08:44:33 --> URI Class Initialized
INFO - 2021-12-20 08:44:33 --> Router Class Initialized
INFO - 2021-12-20 08:44:33 --> Output Class Initialized
INFO - 2021-12-20 08:44:33 --> Security Class Initialized
DEBUG - 2021-12-20 08:44:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:44:33 --> Input Class Initialized
INFO - 2021-12-20 08:44:33 --> Language Class Initialized
INFO - 2021-12-20 08:44:33 --> Language Class Initialized
INFO - 2021-12-20 08:44:33 --> Config Class Initialized
INFO - 2021-12-20 08:44:33 --> Loader Class Initialized
INFO - 2021-12-20 08:44:33 --> Helper loaded: url_helper
INFO - 2021-12-20 08:44:33 --> Helper loaded: file_helper
INFO - 2021-12-20 08:44:33 --> Helper loaded: form_helper
INFO - 2021-12-20 08:44:33 --> Helper loaded: my_helper
INFO - 2021-12-20 08:44:33 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:44:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:44:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:44:33 --> Controller Class Initialized
INFO - 2021-12-20 08:45:16 --> Config Class Initialized
INFO - 2021-12-20 08:45:16 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:45:16 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:45:16 --> Utf8 Class Initialized
INFO - 2021-12-20 08:45:16 --> URI Class Initialized
INFO - 2021-12-20 08:45:16 --> Router Class Initialized
INFO - 2021-12-20 08:45:16 --> Output Class Initialized
INFO - 2021-12-20 08:45:16 --> Security Class Initialized
DEBUG - 2021-12-20 08:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:45:17 --> Input Class Initialized
INFO - 2021-12-20 08:45:17 --> Language Class Initialized
INFO - 2021-12-20 08:45:17 --> Language Class Initialized
INFO - 2021-12-20 08:45:17 --> Config Class Initialized
INFO - 2021-12-20 08:45:17 --> Loader Class Initialized
INFO - 2021-12-20 08:45:17 --> Helper loaded: url_helper
INFO - 2021-12-20 08:45:17 --> Helper loaded: file_helper
INFO - 2021-12-20 08:45:17 --> Helper loaded: form_helper
INFO - 2021-12-20 08:45:17 --> Helper loaded: my_helper
INFO - 2021-12-20 08:45:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:45:17 --> Controller Class Initialized
DEBUG - 2021-12-20 08:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-20 08:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:45:17 --> Final output sent to browser
DEBUG - 2021-12-20 08:45:17 --> Total execution time: 0.0450
INFO - 2021-12-20 08:45:17 --> Config Class Initialized
INFO - 2021-12-20 08:45:17 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:45:17 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:45:17 --> Utf8 Class Initialized
INFO - 2021-12-20 08:45:17 --> URI Class Initialized
INFO - 2021-12-20 08:45:17 --> Router Class Initialized
INFO - 2021-12-20 08:45:17 --> Output Class Initialized
INFO - 2021-12-20 08:45:17 --> Security Class Initialized
DEBUG - 2021-12-20 08:45:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:45:17 --> Input Class Initialized
INFO - 2021-12-20 08:45:17 --> Language Class Initialized
INFO - 2021-12-20 08:45:17 --> Language Class Initialized
INFO - 2021-12-20 08:45:17 --> Config Class Initialized
INFO - 2021-12-20 08:45:17 --> Loader Class Initialized
INFO - 2021-12-20 08:45:17 --> Helper loaded: url_helper
INFO - 2021-12-20 08:45:17 --> Helper loaded: file_helper
INFO - 2021-12-20 08:45:17 --> Helper loaded: form_helper
INFO - 2021-12-20 08:45:17 --> Helper loaded: my_helper
INFO - 2021-12-20 08:45:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:45:17 --> Controller Class Initialized
INFO - 2021-12-20 08:45:18 --> Config Class Initialized
INFO - 2021-12-20 08:45:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:45:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:45:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:45:18 --> URI Class Initialized
INFO - 2021-12-20 08:45:18 --> Router Class Initialized
INFO - 2021-12-20 08:45:18 --> Output Class Initialized
INFO - 2021-12-20 08:45:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:45:18 --> Input Class Initialized
INFO - 2021-12-20 08:45:18 --> Language Class Initialized
INFO - 2021-12-20 08:45:18 --> Language Class Initialized
INFO - 2021-12-20 08:45:18 --> Config Class Initialized
INFO - 2021-12-20 08:45:18 --> Loader Class Initialized
INFO - 2021-12-20 08:45:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:45:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:45:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:45:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:45:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:45:18 --> Controller Class Initialized
DEBUG - 2021-12-20 08:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 08:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:45:18 --> Final output sent to browser
DEBUG - 2021-12-20 08:45:18 --> Total execution time: 0.0530
INFO - 2021-12-20 08:45:18 --> Config Class Initialized
INFO - 2021-12-20 08:45:18 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:45:18 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:45:18 --> Utf8 Class Initialized
INFO - 2021-12-20 08:45:18 --> URI Class Initialized
INFO - 2021-12-20 08:45:18 --> Router Class Initialized
INFO - 2021-12-20 08:45:18 --> Output Class Initialized
INFO - 2021-12-20 08:45:18 --> Security Class Initialized
DEBUG - 2021-12-20 08:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:45:18 --> Input Class Initialized
INFO - 2021-12-20 08:45:18 --> Language Class Initialized
INFO - 2021-12-20 08:45:18 --> Language Class Initialized
INFO - 2021-12-20 08:45:18 --> Config Class Initialized
INFO - 2021-12-20 08:45:18 --> Loader Class Initialized
INFO - 2021-12-20 08:45:18 --> Helper loaded: url_helper
INFO - 2021-12-20 08:45:18 --> Helper loaded: file_helper
INFO - 2021-12-20 08:45:18 --> Helper loaded: form_helper
INFO - 2021-12-20 08:45:18 --> Helper loaded: my_helper
INFO - 2021-12-20 08:45:18 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:45:18 --> Controller Class Initialized
INFO - 2021-12-20 08:46:19 --> Config Class Initialized
INFO - 2021-12-20 08:46:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:46:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:46:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:46:19 --> URI Class Initialized
INFO - 2021-12-20 08:46:19 --> Router Class Initialized
INFO - 2021-12-20 08:46:19 --> Output Class Initialized
INFO - 2021-12-20 08:46:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:46:19 --> Input Class Initialized
INFO - 2021-12-20 08:46:19 --> Language Class Initialized
INFO - 2021-12-20 08:46:19 --> Language Class Initialized
INFO - 2021-12-20 08:46:19 --> Config Class Initialized
INFO - 2021-12-20 08:46:19 --> Loader Class Initialized
INFO - 2021-12-20 08:46:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:46:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:46:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:46:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:46:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:46:19 --> Controller Class Initialized
DEBUG - 2021-12-20 08:46:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-20 08:46:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:46:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:46:19 --> Total execution time: 0.0410
INFO - 2021-12-20 08:46:19 --> Config Class Initialized
INFO - 2021-12-20 08:46:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:46:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:46:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:46:19 --> URI Class Initialized
INFO - 2021-12-20 08:46:19 --> Router Class Initialized
INFO - 2021-12-20 08:46:19 --> Output Class Initialized
INFO - 2021-12-20 08:46:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:46:19 --> Input Class Initialized
INFO - 2021-12-20 08:46:19 --> Language Class Initialized
INFO - 2021-12-20 08:46:19 --> Language Class Initialized
INFO - 2021-12-20 08:46:19 --> Config Class Initialized
INFO - 2021-12-20 08:46:19 --> Loader Class Initialized
INFO - 2021-12-20 08:46:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:46:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:46:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:46:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:46:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:46:19 --> Controller Class Initialized
INFO - 2021-12-20 08:46:21 --> Config Class Initialized
INFO - 2021-12-20 08:46:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:46:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:46:21 --> Utf8 Class Initialized
INFO - 2021-12-20 08:46:21 --> URI Class Initialized
INFO - 2021-12-20 08:46:21 --> Router Class Initialized
INFO - 2021-12-20 08:46:21 --> Output Class Initialized
INFO - 2021-12-20 08:46:21 --> Security Class Initialized
DEBUG - 2021-12-20 08:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:46:21 --> Input Class Initialized
INFO - 2021-12-20 08:46:21 --> Language Class Initialized
INFO - 2021-12-20 08:46:21 --> Language Class Initialized
INFO - 2021-12-20 08:46:21 --> Config Class Initialized
INFO - 2021-12-20 08:46:21 --> Loader Class Initialized
INFO - 2021-12-20 08:46:21 --> Helper loaded: url_helper
INFO - 2021-12-20 08:46:21 --> Helper loaded: file_helper
INFO - 2021-12-20 08:46:21 --> Helper loaded: form_helper
INFO - 2021-12-20 08:46:21 --> Helper loaded: my_helper
INFO - 2021-12-20 08:46:21 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:46:21 --> Controller Class Initialized
DEBUG - 2021-12-20 08:46:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:46:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:46:21 --> Final output sent to browser
DEBUG - 2021-12-20 08:46:21 --> Total execution time: 0.0710
INFO - 2021-12-20 08:48:28 --> Config Class Initialized
INFO - 2021-12-20 08:48:28 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:48:28 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:48:28 --> Utf8 Class Initialized
INFO - 2021-12-20 08:48:28 --> URI Class Initialized
INFO - 2021-12-20 08:48:28 --> Router Class Initialized
INFO - 2021-12-20 08:48:28 --> Output Class Initialized
INFO - 2021-12-20 08:48:28 --> Security Class Initialized
DEBUG - 2021-12-20 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:48:28 --> Input Class Initialized
INFO - 2021-12-20 08:48:28 --> Language Class Initialized
INFO - 2021-12-20 08:48:28 --> Language Class Initialized
INFO - 2021-12-20 08:48:28 --> Config Class Initialized
INFO - 2021-12-20 08:48:28 --> Loader Class Initialized
INFO - 2021-12-20 08:48:28 --> Helper loaded: url_helper
INFO - 2021-12-20 08:48:28 --> Helper loaded: file_helper
INFO - 2021-12-20 08:48:28 --> Helper loaded: form_helper
INFO - 2021-12-20 08:48:28 --> Helper loaded: my_helper
INFO - 2021-12-20 08:48:28 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:48:28 --> Controller Class Initialized
DEBUG - 2021-12-20 08:48:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 08:48:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:48:28 --> Final output sent to browser
DEBUG - 2021-12-20 08:48:28 --> Total execution time: 0.0490
INFO - 2021-12-20 08:48:28 --> Config Class Initialized
INFO - 2021-12-20 08:48:28 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:48:28 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:48:28 --> Utf8 Class Initialized
INFO - 2021-12-20 08:48:28 --> URI Class Initialized
INFO - 2021-12-20 08:48:28 --> Router Class Initialized
INFO - 2021-12-20 08:48:28 --> Output Class Initialized
INFO - 2021-12-20 08:48:28 --> Security Class Initialized
DEBUG - 2021-12-20 08:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:48:28 --> Input Class Initialized
INFO - 2021-12-20 08:48:28 --> Language Class Initialized
INFO - 2021-12-20 08:48:28 --> Language Class Initialized
INFO - 2021-12-20 08:48:28 --> Config Class Initialized
INFO - 2021-12-20 08:48:28 --> Loader Class Initialized
INFO - 2021-12-20 08:48:28 --> Helper loaded: url_helper
INFO - 2021-12-20 08:48:28 --> Helper loaded: file_helper
INFO - 2021-12-20 08:48:28 --> Helper loaded: form_helper
INFO - 2021-12-20 08:48:28 --> Helper loaded: my_helper
INFO - 2021-12-20 08:48:28 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:48:28 --> Controller Class Initialized
INFO - 2021-12-20 08:51:52 --> Config Class Initialized
INFO - 2021-12-20 08:51:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:51:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:51:52 --> Utf8 Class Initialized
INFO - 2021-12-20 08:51:52 --> URI Class Initialized
INFO - 2021-12-20 08:51:52 --> Router Class Initialized
INFO - 2021-12-20 08:51:52 --> Output Class Initialized
INFO - 2021-12-20 08:51:52 --> Security Class Initialized
DEBUG - 2021-12-20 08:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:51:52 --> Input Class Initialized
INFO - 2021-12-20 08:51:52 --> Language Class Initialized
INFO - 2021-12-20 08:51:52 --> Language Class Initialized
INFO - 2021-12-20 08:51:52 --> Config Class Initialized
INFO - 2021-12-20 08:51:52 --> Loader Class Initialized
INFO - 2021-12-20 08:51:52 --> Helper loaded: url_helper
INFO - 2021-12-20 08:51:52 --> Helper loaded: file_helper
INFO - 2021-12-20 08:51:52 --> Helper loaded: form_helper
INFO - 2021-12-20 08:51:52 --> Helper loaded: my_helper
INFO - 2021-12-20 08:51:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:51:52 --> Controller Class Initialized
DEBUG - 2021-12-20 08:51:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 08:51:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:51:52 --> Final output sent to browser
DEBUG - 2021-12-20 08:51:52 --> Total execution time: 0.0640
INFO - 2021-12-20 08:51:52 --> Config Class Initialized
INFO - 2021-12-20 08:51:52 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:51:52 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:51:52 --> Utf8 Class Initialized
INFO - 2021-12-20 08:51:52 --> URI Class Initialized
INFO - 2021-12-20 08:51:52 --> Router Class Initialized
INFO - 2021-12-20 08:51:52 --> Output Class Initialized
INFO - 2021-12-20 08:51:52 --> Security Class Initialized
DEBUG - 2021-12-20 08:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:51:52 --> Input Class Initialized
INFO - 2021-12-20 08:51:52 --> Language Class Initialized
INFO - 2021-12-20 08:51:52 --> Language Class Initialized
INFO - 2021-12-20 08:51:52 --> Config Class Initialized
INFO - 2021-12-20 08:51:52 --> Loader Class Initialized
INFO - 2021-12-20 08:51:52 --> Helper loaded: url_helper
INFO - 2021-12-20 08:51:52 --> Helper loaded: file_helper
INFO - 2021-12-20 08:51:52 --> Helper loaded: form_helper
INFO - 2021-12-20 08:51:52 --> Helper loaded: my_helper
INFO - 2021-12-20 08:51:52 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:51:52 --> Controller Class Initialized
INFO - 2021-12-20 08:51:53 --> Config Class Initialized
INFO - 2021-12-20 08:51:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:51:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:51:53 --> Utf8 Class Initialized
INFO - 2021-12-20 08:51:53 --> URI Class Initialized
INFO - 2021-12-20 08:51:53 --> Router Class Initialized
INFO - 2021-12-20 08:51:53 --> Output Class Initialized
INFO - 2021-12-20 08:51:53 --> Security Class Initialized
DEBUG - 2021-12-20 08:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:51:53 --> Input Class Initialized
INFO - 2021-12-20 08:51:53 --> Language Class Initialized
INFO - 2021-12-20 08:51:53 --> Language Class Initialized
INFO - 2021-12-20 08:51:53 --> Config Class Initialized
INFO - 2021-12-20 08:51:53 --> Loader Class Initialized
INFO - 2021-12-20 08:51:53 --> Helper loaded: url_helper
INFO - 2021-12-20 08:51:53 --> Helper loaded: file_helper
INFO - 2021-12-20 08:51:53 --> Helper loaded: form_helper
INFO - 2021-12-20 08:51:53 --> Helper loaded: my_helper
INFO - 2021-12-20 08:51:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:51:53 --> Controller Class Initialized
DEBUG - 2021-12-20 08:51:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 08:51:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:51:53 --> Final output sent to browser
DEBUG - 2021-12-20 08:51:53 --> Total execution time: 0.0480
INFO - 2021-12-20 08:51:53 --> Config Class Initialized
INFO - 2021-12-20 08:51:53 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:51:53 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:51:53 --> Utf8 Class Initialized
INFO - 2021-12-20 08:51:53 --> URI Class Initialized
INFO - 2021-12-20 08:51:53 --> Router Class Initialized
INFO - 2021-12-20 08:51:53 --> Output Class Initialized
INFO - 2021-12-20 08:51:53 --> Security Class Initialized
DEBUG - 2021-12-20 08:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:51:53 --> Input Class Initialized
INFO - 2021-12-20 08:51:53 --> Language Class Initialized
INFO - 2021-12-20 08:51:53 --> Language Class Initialized
INFO - 2021-12-20 08:51:53 --> Config Class Initialized
INFO - 2021-12-20 08:51:53 --> Loader Class Initialized
INFO - 2021-12-20 08:51:53 --> Helper loaded: url_helper
INFO - 2021-12-20 08:51:53 --> Helper loaded: file_helper
INFO - 2021-12-20 08:51:53 --> Helper loaded: form_helper
INFO - 2021-12-20 08:51:53 --> Helper loaded: my_helper
INFO - 2021-12-20 08:51:53 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:51:53 --> Controller Class Initialized
INFO - 2021-12-20 08:52:19 --> Config Class Initialized
INFO - 2021-12-20 08:52:19 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:52:19 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:52:19 --> Utf8 Class Initialized
INFO - 2021-12-20 08:52:19 --> URI Class Initialized
INFO - 2021-12-20 08:52:19 --> Router Class Initialized
INFO - 2021-12-20 08:52:19 --> Output Class Initialized
INFO - 2021-12-20 08:52:19 --> Security Class Initialized
DEBUG - 2021-12-20 08:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:52:19 --> Input Class Initialized
INFO - 2021-12-20 08:52:19 --> Language Class Initialized
INFO - 2021-12-20 08:52:19 --> Language Class Initialized
INFO - 2021-12-20 08:52:19 --> Config Class Initialized
INFO - 2021-12-20 08:52:19 --> Loader Class Initialized
INFO - 2021-12-20 08:52:19 --> Helper loaded: url_helper
INFO - 2021-12-20 08:52:19 --> Helper loaded: file_helper
INFO - 2021-12-20 08:52:19 --> Helper loaded: form_helper
INFO - 2021-12-20 08:52:19 --> Helper loaded: my_helper
INFO - 2021-12-20 08:52:19 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:52:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:52:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:52:19 --> Controller Class Initialized
DEBUG - 2021-12-20 08:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-12-20 08:52:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:52:19 --> Final output sent to browser
DEBUG - 2021-12-20 08:52:19 --> Total execution time: 0.0720
INFO - 2021-12-20 08:52:27 --> Config Class Initialized
INFO - 2021-12-20 08:52:27 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:52:27 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:52:27 --> Utf8 Class Initialized
INFO - 2021-12-20 08:52:27 --> URI Class Initialized
INFO - 2021-12-20 08:52:27 --> Router Class Initialized
INFO - 2021-12-20 08:52:27 --> Output Class Initialized
INFO - 2021-12-20 08:52:27 --> Security Class Initialized
DEBUG - 2021-12-20 08:52:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:52:27 --> Input Class Initialized
INFO - 2021-12-20 08:52:27 --> Language Class Initialized
INFO - 2021-12-20 08:52:27 --> Language Class Initialized
INFO - 2021-12-20 08:52:27 --> Config Class Initialized
INFO - 2021-12-20 08:52:27 --> Loader Class Initialized
INFO - 2021-12-20 08:52:27 --> Helper loaded: url_helper
INFO - 2021-12-20 08:52:27 --> Helper loaded: file_helper
INFO - 2021-12-20 08:52:27 --> Helper loaded: form_helper
INFO - 2021-12-20 08:52:27 --> Helper loaded: my_helper
INFO - 2021-12-20 08:52:27 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:52:27 --> Controller Class Initialized
INFO - 2021-12-20 08:52:30 --> Config Class Initialized
INFO - 2021-12-20 08:52:30 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:52:30 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:52:30 --> Utf8 Class Initialized
INFO - 2021-12-20 08:52:30 --> URI Class Initialized
INFO - 2021-12-20 08:52:30 --> Router Class Initialized
INFO - 2021-12-20 08:52:30 --> Output Class Initialized
INFO - 2021-12-20 08:52:30 --> Security Class Initialized
DEBUG - 2021-12-20 08:52:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:52:30 --> Input Class Initialized
INFO - 2021-12-20 08:52:30 --> Language Class Initialized
INFO - 2021-12-20 08:52:30 --> Language Class Initialized
INFO - 2021-12-20 08:52:30 --> Config Class Initialized
INFO - 2021-12-20 08:52:30 --> Loader Class Initialized
INFO - 2021-12-20 08:52:30 --> Helper loaded: url_helper
INFO - 2021-12-20 08:52:30 --> Helper loaded: file_helper
INFO - 2021-12-20 08:52:30 --> Helper loaded: form_helper
INFO - 2021-12-20 08:52:30 --> Helper loaded: my_helper
INFO - 2021-12-20 08:52:30 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:52:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:52:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:52:30 --> Controller Class Initialized
DEBUG - 2021-12-20 08:52:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2021-12-20 08:52:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:52:30 --> Final output sent to browser
DEBUG - 2021-12-20 08:52:30 --> Total execution time: 0.0360
INFO - 2021-12-20 08:52:38 --> Config Class Initialized
INFO - 2021-12-20 08:52:38 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:52:38 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:52:38 --> Utf8 Class Initialized
INFO - 2021-12-20 08:52:38 --> URI Class Initialized
INFO - 2021-12-20 08:52:38 --> Router Class Initialized
INFO - 2021-12-20 08:52:38 --> Output Class Initialized
INFO - 2021-12-20 08:52:38 --> Security Class Initialized
DEBUG - 2021-12-20 08:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:52:38 --> Input Class Initialized
INFO - 2021-12-20 08:52:38 --> Language Class Initialized
INFO - 2021-12-20 08:52:38 --> Language Class Initialized
INFO - 2021-12-20 08:52:38 --> Config Class Initialized
INFO - 2021-12-20 08:52:38 --> Loader Class Initialized
INFO - 2021-12-20 08:52:38 --> Helper loaded: url_helper
INFO - 2021-12-20 08:52:38 --> Helper loaded: file_helper
INFO - 2021-12-20 08:52:38 --> Helper loaded: form_helper
INFO - 2021-12-20 08:52:38 --> Helper loaded: my_helper
INFO - 2021-12-20 08:52:38 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:52:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:52:39 --> Controller Class Initialized
DEBUG - 2021-12-20 08:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:52:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:52:39 --> Final output sent to browser
DEBUG - 2021-12-20 08:52:39 --> Total execution time: 0.0640
INFO - 2021-12-20 08:52:41 --> Config Class Initialized
INFO - 2021-12-20 08:52:41 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:52:41 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:52:41 --> Utf8 Class Initialized
INFO - 2021-12-20 08:52:41 --> URI Class Initialized
INFO - 2021-12-20 08:52:41 --> Router Class Initialized
INFO - 2021-12-20 08:52:41 --> Output Class Initialized
INFO - 2021-12-20 08:52:41 --> Security Class Initialized
DEBUG - 2021-12-20 08:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:52:41 --> Input Class Initialized
INFO - 2021-12-20 08:52:41 --> Language Class Initialized
INFO - 2021-12-20 08:52:41 --> Language Class Initialized
INFO - 2021-12-20 08:52:41 --> Config Class Initialized
INFO - 2021-12-20 08:52:41 --> Loader Class Initialized
INFO - 2021-12-20 08:52:41 --> Helper loaded: url_helper
INFO - 2021-12-20 08:52:41 --> Helper loaded: file_helper
INFO - 2021-12-20 08:52:41 --> Helper loaded: form_helper
INFO - 2021-12-20 08:52:41 --> Helper loaded: my_helper
INFO - 2021-12-20 08:52:41 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:52:41 --> Controller Class Initialized
DEBUG - 2021-12-20 08:52:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:52:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:52:41 --> Final output sent to browser
DEBUG - 2021-12-20 08:52:41 --> Total execution time: 0.0520
INFO - 2021-12-20 08:53:55 --> Config Class Initialized
INFO - 2021-12-20 08:53:55 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:53:55 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:53:55 --> Utf8 Class Initialized
INFO - 2021-12-20 08:53:55 --> URI Class Initialized
INFO - 2021-12-20 08:53:55 --> Router Class Initialized
INFO - 2021-12-20 08:53:55 --> Output Class Initialized
INFO - 2021-12-20 08:53:55 --> Security Class Initialized
DEBUG - 2021-12-20 08:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:53:55 --> Input Class Initialized
INFO - 2021-12-20 08:53:55 --> Language Class Initialized
INFO - 2021-12-20 08:53:55 --> Language Class Initialized
INFO - 2021-12-20 08:53:55 --> Config Class Initialized
INFO - 2021-12-20 08:53:55 --> Loader Class Initialized
INFO - 2021-12-20 08:53:55 --> Helper loaded: url_helper
INFO - 2021-12-20 08:53:55 --> Helper loaded: file_helper
INFO - 2021-12-20 08:53:55 --> Helper loaded: form_helper
INFO - 2021-12-20 08:53:55 --> Helper loaded: my_helper
INFO - 2021-12-20 08:53:55 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:53:55 --> Controller Class Initialized
INFO - 2021-12-20 08:53:55 --> Config Class Initialized
INFO - 2021-12-20 08:53:55 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:53:55 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:53:55 --> Utf8 Class Initialized
INFO - 2021-12-20 08:53:55 --> URI Class Initialized
INFO - 2021-12-20 08:53:55 --> Router Class Initialized
INFO - 2021-12-20 08:53:55 --> Output Class Initialized
INFO - 2021-12-20 08:53:55 --> Security Class Initialized
DEBUG - 2021-12-20 08:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:53:55 --> Input Class Initialized
INFO - 2021-12-20 08:53:55 --> Language Class Initialized
INFO - 2021-12-20 08:53:55 --> Language Class Initialized
INFO - 2021-12-20 08:53:55 --> Config Class Initialized
INFO - 2021-12-20 08:53:55 --> Loader Class Initialized
INFO - 2021-12-20 08:53:55 --> Helper loaded: url_helper
INFO - 2021-12-20 08:53:55 --> Helper loaded: file_helper
INFO - 2021-12-20 08:53:55 --> Helper loaded: form_helper
INFO - 2021-12-20 08:53:55 --> Helper loaded: my_helper
INFO - 2021-12-20 08:53:55 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:53:55 --> Controller Class Initialized
DEBUG - 2021-12-20 08:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:53:55 --> Final output sent to browser
DEBUG - 2021-12-20 08:53:55 --> Total execution time: 0.0450
INFO - 2021-12-20 08:54:06 --> Config Class Initialized
INFO - 2021-12-20 08:54:06 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:54:06 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:54:06 --> Utf8 Class Initialized
INFO - 2021-12-20 08:54:06 --> URI Class Initialized
INFO - 2021-12-20 08:54:06 --> Router Class Initialized
INFO - 2021-12-20 08:54:06 --> Output Class Initialized
INFO - 2021-12-20 08:54:06 --> Security Class Initialized
DEBUG - 2021-12-20 08:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:54:06 --> Input Class Initialized
INFO - 2021-12-20 08:54:06 --> Language Class Initialized
INFO - 2021-12-20 08:54:06 --> Language Class Initialized
INFO - 2021-12-20 08:54:06 --> Config Class Initialized
INFO - 2021-12-20 08:54:06 --> Loader Class Initialized
INFO - 2021-12-20 08:54:06 --> Helper loaded: url_helper
INFO - 2021-12-20 08:54:06 --> Helper loaded: file_helper
INFO - 2021-12-20 08:54:06 --> Helper loaded: form_helper
INFO - 2021-12-20 08:54:06 --> Helper loaded: my_helper
INFO - 2021-12-20 08:54:06 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:54:06 --> Controller Class Initialized
DEBUG - 2021-12-20 08:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:54:06 --> Final output sent to browser
DEBUG - 2021-12-20 08:54:06 --> Total execution time: 0.0520
INFO - 2021-12-20 08:54:54 --> Config Class Initialized
INFO - 2021-12-20 08:54:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:54:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:54:54 --> Utf8 Class Initialized
INFO - 2021-12-20 08:54:54 --> URI Class Initialized
INFO - 2021-12-20 08:54:54 --> Router Class Initialized
INFO - 2021-12-20 08:54:54 --> Output Class Initialized
INFO - 2021-12-20 08:54:54 --> Security Class Initialized
DEBUG - 2021-12-20 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:54:54 --> Input Class Initialized
INFO - 2021-12-20 08:54:54 --> Language Class Initialized
INFO - 2021-12-20 08:54:54 --> Language Class Initialized
INFO - 2021-12-20 08:54:54 --> Config Class Initialized
INFO - 2021-12-20 08:54:54 --> Loader Class Initialized
INFO - 2021-12-20 08:54:54 --> Helper loaded: url_helper
INFO - 2021-12-20 08:54:54 --> Helper loaded: file_helper
INFO - 2021-12-20 08:54:54 --> Helper loaded: form_helper
INFO - 2021-12-20 08:54:54 --> Helper loaded: my_helper
INFO - 2021-12-20 08:54:54 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:54:54 --> Controller Class Initialized
INFO - 2021-12-20 08:54:54 --> Config Class Initialized
INFO - 2021-12-20 08:54:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:54:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:54:54 --> Utf8 Class Initialized
INFO - 2021-12-20 08:54:54 --> URI Class Initialized
INFO - 2021-12-20 08:54:54 --> Router Class Initialized
INFO - 2021-12-20 08:54:54 --> Output Class Initialized
INFO - 2021-12-20 08:54:54 --> Security Class Initialized
DEBUG - 2021-12-20 08:54:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:54:54 --> Input Class Initialized
INFO - 2021-12-20 08:54:54 --> Language Class Initialized
INFO - 2021-12-20 08:54:54 --> Language Class Initialized
INFO - 2021-12-20 08:54:54 --> Config Class Initialized
INFO - 2021-12-20 08:54:54 --> Loader Class Initialized
INFO - 2021-12-20 08:54:54 --> Helper loaded: url_helper
INFO - 2021-12-20 08:54:54 --> Helper loaded: file_helper
INFO - 2021-12-20 08:54:54 --> Helper loaded: form_helper
INFO - 2021-12-20 08:54:54 --> Helper loaded: my_helper
INFO - 2021-12-20 08:54:54 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:54:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:54:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:54:54 --> Controller Class Initialized
DEBUG - 2021-12-20 08:54:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:54:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:54:54 --> Final output sent to browser
DEBUG - 2021-12-20 08:54:54 --> Total execution time: 0.0470
INFO - 2021-12-20 08:55:04 --> Config Class Initialized
INFO - 2021-12-20 08:55:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:55:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:55:04 --> Utf8 Class Initialized
INFO - 2021-12-20 08:55:04 --> URI Class Initialized
INFO - 2021-12-20 08:55:04 --> Router Class Initialized
INFO - 2021-12-20 08:55:04 --> Output Class Initialized
INFO - 2021-12-20 08:55:04 --> Security Class Initialized
DEBUG - 2021-12-20 08:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:55:04 --> Input Class Initialized
INFO - 2021-12-20 08:55:04 --> Language Class Initialized
INFO - 2021-12-20 08:55:04 --> Language Class Initialized
INFO - 2021-12-20 08:55:04 --> Config Class Initialized
INFO - 2021-12-20 08:55:04 --> Loader Class Initialized
INFO - 2021-12-20 08:55:04 --> Helper loaded: url_helper
INFO - 2021-12-20 08:55:04 --> Helper loaded: file_helper
INFO - 2021-12-20 08:55:04 --> Helper loaded: form_helper
INFO - 2021-12-20 08:55:04 --> Helper loaded: my_helper
INFO - 2021-12-20 08:55:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:55:04 --> Controller Class Initialized
DEBUG - 2021-12-20 08:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:55:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:55:04 --> Final output sent to browser
DEBUG - 2021-12-20 08:55:04 --> Total execution time: 0.0560
INFO - 2021-12-20 08:55:31 --> Config Class Initialized
INFO - 2021-12-20 08:55:31 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:55:31 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:55:31 --> Utf8 Class Initialized
INFO - 2021-12-20 08:55:31 --> URI Class Initialized
INFO - 2021-12-20 08:55:31 --> Router Class Initialized
INFO - 2021-12-20 08:55:31 --> Output Class Initialized
INFO - 2021-12-20 08:55:31 --> Security Class Initialized
DEBUG - 2021-12-20 08:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:55:31 --> Input Class Initialized
INFO - 2021-12-20 08:55:31 --> Language Class Initialized
INFO - 2021-12-20 08:55:31 --> Language Class Initialized
INFO - 2021-12-20 08:55:31 --> Config Class Initialized
INFO - 2021-12-20 08:55:31 --> Loader Class Initialized
INFO - 2021-12-20 08:55:31 --> Helper loaded: url_helper
INFO - 2021-12-20 08:55:31 --> Helper loaded: file_helper
INFO - 2021-12-20 08:55:31 --> Helper loaded: form_helper
INFO - 2021-12-20 08:55:31 --> Helper loaded: my_helper
INFO - 2021-12-20 08:55:31 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:55:31 --> Controller Class Initialized
INFO - 2021-12-20 08:55:31 --> Config Class Initialized
INFO - 2021-12-20 08:55:31 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:55:31 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:55:31 --> Utf8 Class Initialized
INFO - 2021-12-20 08:55:31 --> URI Class Initialized
INFO - 2021-12-20 08:55:31 --> Router Class Initialized
INFO - 2021-12-20 08:55:31 --> Output Class Initialized
INFO - 2021-12-20 08:55:31 --> Security Class Initialized
DEBUG - 2021-12-20 08:55:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:55:31 --> Input Class Initialized
INFO - 2021-12-20 08:55:31 --> Language Class Initialized
INFO - 2021-12-20 08:55:31 --> Language Class Initialized
INFO - 2021-12-20 08:55:31 --> Config Class Initialized
INFO - 2021-12-20 08:55:31 --> Loader Class Initialized
INFO - 2021-12-20 08:55:31 --> Helper loaded: url_helper
INFO - 2021-12-20 08:55:31 --> Helper loaded: file_helper
INFO - 2021-12-20 08:55:31 --> Helper loaded: form_helper
INFO - 2021-12-20 08:55:31 --> Helper loaded: my_helper
INFO - 2021-12-20 08:55:31 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:55:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:55:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:55:31 --> Controller Class Initialized
DEBUG - 2021-12-20 08:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:55:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:55:31 --> Final output sent to browser
DEBUG - 2021-12-20 08:55:31 --> Total execution time: 0.0450
INFO - 2021-12-20 08:55:36 --> Config Class Initialized
INFO - 2021-12-20 08:55:36 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:55:36 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:55:36 --> Utf8 Class Initialized
INFO - 2021-12-20 08:55:36 --> URI Class Initialized
INFO - 2021-12-20 08:55:36 --> Router Class Initialized
INFO - 2021-12-20 08:55:36 --> Output Class Initialized
INFO - 2021-12-20 08:55:36 --> Security Class Initialized
DEBUG - 2021-12-20 08:55:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:55:36 --> Input Class Initialized
INFO - 2021-12-20 08:55:36 --> Language Class Initialized
INFO - 2021-12-20 08:55:36 --> Language Class Initialized
INFO - 2021-12-20 08:55:36 --> Config Class Initialized
INFO - 2021-12-20 08:55:36 --> Loader Class Initialized
INFO - 2021-12-20 08:55:36 --> Helper loaded: url_helper
INFO - 2021-12-20 08:55:36 --> Helper loaded: file_helper
INFO - 2021-12-20 08:55:36 --> Helper loaded: form_helper
INFO - 2021-12-20 08:55:36 --> Helper loaded: my_helper
INFO - 2021-12-20 08:55:36 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:55:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:55:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:55:36 --> Controller Class Initialized
DEBUG - 2021-12-20 08:55:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:55:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:55:36 --> Final output sent to browser
DEBUG - 2021-12-20 08:55:36 --> Total execution time: 0.0500
INFO - 2021-12-20 08:56:04 --> Config Class Initialized
INFO - 2021-12-20 08:56:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:56:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:56:04 --> Utf8 Class Initialized
INFO - 2021-12-20 08:56:04 --> URI Class Initialized
INFO - 2021-12-20 08:56:04 --> Router Class Initialized
INFO - 2021-12-20 08:56:04 --> Output Class Initialized
INFO - 2021-12-20 08:56:04 --> Security Class Initialized
DEBUG - 2021-12-20 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:56:04 --> Input Class Initialized
INFO - 2021-12-20 08:56:04 --> Language Class Initialized
INFO - 2021-12-20 08:56:04 --> Language Class Initialized
INFO - 2021-12-20 08:56:04 --> Config Class Initialized
INFO - 2021-12-20 08:56:04 --> Loader Class Initialized
INFO - 2021-12-20 08:56:04 --> Helper loaded: url_helper
INFO - 2021-12-20 08:56:04 --> Helper loaded: file_helper
INFO - 2021-12-20 08:56:04 --> Helper loaded: form_helper
INFO - 2021-12-20 08:56:04 --> Helper loaded: my_helper
INFO - 2021-12-20 08:56:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:56:04 --> Controller Class Initialized
INFO - 2021-12-20 08:56:04 --> Config Class Initialized
INFO - 2021-12-20 08:56:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:56:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:56:04 --> Utf8 Class Initialized
INFO - 2021-12-20 08:56:04 --> URI Class Initialized
INFO - 2021-12-20 08:56:04 --> Router Class Initialized
INFO - 2021-12-20 08:56:04 --> Output Class Initialized
INFO - 2021-12-20 08:56:04 --> Security Class Initialized
DEBUG - 2021-12-20 08:56:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:56:04 --> Input Class Initialized
INFO - 2021-12-20 08:56:04 --> Language Class Initialized
INFO - 2021-12-20 08:56:04 --> Language Class Initialized
INFO - 2021-12-20 08:56:04 --> Config Class Initialized
INFO - 2021-12-20 08:56:04 --> Loader Class Initialized
INFO - 2021-12-20 08:56:04 --> Helper loaded: url_helper
INFO - 2021-12-20 08:56:04 --> Helper loaded: file_helper
INFO - 2021-12-20 08:56:04 --> Helper loaded: form_helper
INFO - 2021-12-20 08:56:04 --> Helper loaded: my_helper
INFO - 2021-12-20 08:56:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:56:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:56:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:56:04 --> Controller Class Initialized
DEBUG - 2021-12-20 08:56:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:56:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:56:04 --> Final output sent to browser
DEBUG - 2021-12-20 08:56:04 --> Total execution time: 0.0480
INFO - 2021-12-20 08:56:12 --> Config Class Initialized
INFO - 2021-12-20 08:56:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:56:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:56:12 --> Utf8 Class Initialized
INFO - 2021-12-20 08:56:12 --> URI Class Initialized
INFO - 2021-12-20 08:56:12 --> Router Class Initialized
INFO - 2021-12-20 08:56:12 --> Output Class Initialized
INFO - 2021-12-20 08:56:12 --> Security Class Initialized
DEBUG - 2021-12-20 08:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:56:12 --> Input Class Initialized
INFO - 2021-12-20 08:56:12 --> Language Class Initialized
INFO - 2021-12-20 08:56:12 --> Language Class Initialized
INFO - 2021-12-20 08:56:12 --> Config Class Initialized
INFO - 2021-12-20 08:56:12 --> Loader Class Initialized
INFO - 2021-12-20 08:56:12 --> Helper loaded: url_helper
INFO - 2021-12-20 08:56:12 --> Helper loaded: file_helper
INFO - 2021-12-20 08:56:12 --> Helper loaded: form_helper
INFO - 2021-12-20 08:56:12 --> Helper loaded: my_helper
INFO - 2021-12-20 08:56:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:56:12 --> Controller Class Initialized
DEBUG - 2021-12-20 08:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:56:12 --> Final output sent to browser
DEBUG - 2021-12-20 08:56:12 --> Total execution time: 0.0500
INFO - 2021-12-20 08:56:39 --> Config Class Initialized
INFO - 2021-12-20 08:56:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:56:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:56:39 --> Utf8 Class Initialized
INFO - 2021-12-20 08:56:39 --> URI Class Initialized
INFO - 2021-12-20 08:56:39 --> Router Class Initialized
INFO - 2021-12-20 08:56:39 --> Output Class Initialized
INFO - 2021-12-20 08:56:39 --> Security Class Initialized
DEBUG - 2021-12-20 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:56:39 --> Input Class Initialized
INFO - 2021-12-20 08:56:39 --> Language Class Initialized
INFO - 2021-12-20 08:56:39 --> Language Class Initialized
INFO - 2021-12-20 08:56:39 --> Config Class Initialized
INFO - 2021-12-20 08:56:39 --> Loader Class Initialized
INFO - 2021-12-20 08:56:39 --> Helper loaded: url_helper
INFO - 2021-12-20 08:56:39 --> Helper loaded: file_helper
INFO - 2021-12-20 08:56:39 --> Helper loaded: form_helper
INFO - 2021-12-20 08:56:39 --> Helper loaded: my_helper
INFO - 2021-12-20 08:56:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:56:39 --> Controller Class Initialized
INFO - 2021-12-20 08:56:39 --> Config Class Initialized
INFO - 2021-12-20 08:56:39 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:56:39 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:56:39 --> Utf8 Class Initialized
INFO - 2021-12-20 08:56:39 --> URI Class Initialized
INFO - 2021-12-20 08:56:39 --> Router Class Initialized
INFO - 2021-12-20 08:56:39 --> Output Class Initialized
INFO - 2021-12-20 08:56:39 --> Security Class Initialized
DEBUG - 2021-12-20 08:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:56:39 --> Input Class Initialized
INFO - 2021-12-20 08:56:39 --> Language Class Initialized
INFO - 2021-12-20 08:56:39 --> Language Class Initialized
INFO - 2021-12-20 08:56:39 --> Config Class Initialized
INFO - 2021-12-20 08:56:39 --> Loader Class Initialized
INFO - 2021-12-20 08:56:39 --> Helper loaded: url_helper
INFO - 2021-12-20 08:56:39 --> Helper loaded: file_helper
INFO - 2021-12-20 08:56:39 --> Helper loaded: form_helper
INFO - 2021-12-20 08:56:39 --> Helper loaded: my_helper
INFO - 2021-12-20 08:56:39 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:56:39 --> Controller Class Initialized
DEBUG - 2021-12-20 08:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:56:39 --> Final output sent to browser
DEBUG - 2021-12-20 08:56:39 --> Total execution time: 0.0530
INFO - 2021-12-20 08:56:49 --> Config Class Initialized
INFO - 2021-12-20 08:56:49 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:56:49 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:56:49 --> Utf8 Class Initialized
INFO - 2021-12-20 08:56:49 --> URI Class Initialized
INFO - 2021-12-20 08:56:49 --> Router Class Initialized
INFO - 2021-12-20 08:56:49 --> Output Class Initialized
INFO - 2021-12-20 08:56:49 --> Security Class Initialized
DEBUG - 2021-12-20 08:56:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:56:49 --> Input Class Initialized
INFO - 2021-12-20 08:56:49 --> Language Class Initialized
INFO - 2021-12-20 08:56:49 --> Language Class Initialized
INFO - 2021-12-20 08:56:49 --> Config Class Initialized
INFO - 2021-12-20 08:56:49 --> Loader Class Initialized
INFO - 2021-12-20 08:56:49 --> Helper loaded: url_helper
INFO - 2021-12-20 08:56:49 --> Helper loaded: file_helper
INFO - 2021-12-20 08:56:49 --> Helper loaded: form_helper
INFO - 2021-12-20 08:56:49 --> Helper loaded: my_helper
INFO - 2021-12-20 08:56:49 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:56:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:56:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:56:49 --> Controller Class Initialized
DEBUG - 2021-12-20 08:56:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:56:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:56:49 --> Final output sent to browser
DEBUG - 2021-12-20 08:56:49 --> Total execution time: 0.0530
INFO - 2021-12-20 08:57:15 --> Config Class Initialized
INFO - 2021-12-20 08:57:15 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:57:15 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:57:15 --> Utf8 Class Initialized
INFO - 2021-12-20 08:57:15 --> URI Class Initialized
INFO - 2021-12-20 08:57:15 --> Router Class Initialized
INFO - 2021-12-20 08:57:15 --> Output Class Initialized
INFO - 2021-12-20 08:57:15 --> Security Class Initialized
DEBUG - 2021-12-20 08:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:57:15 --> Input Class Initialized
INFO - 2021-12-20 08:57:15 --> Language Class Initialized
INFO - 2021-12-20 08:57:15 --> Language Class Initialized
INFO - 2021-12-20 08:57:15 --> Config Class Initialized
INFO - 2021-12-20 08:57:15 --> Loader Class Initialized
INFO - 2021-12-20 08:57:15 --> Helper loaded: url_helper
INFO - 2021-12-20 08:57:15 --> Helper loaded: file_helper
INFO - 2021-12-20 08:57:15 --> Helper loaded: form_helper
INFO - 2021-12-20 08:57:15 --> Helper loaded: my_helper
INFO - 2021-12-20 08:57:15 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:57:15 --> Controller Class Initialized
INFO - 2021-12-20 08:57:15 --> Config Class Initialized
INFO - 2021-12-20 08:57:15 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:57:15 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:57:15 --> Utf8 Class Initialized
INFO - 2021-12-20 08:57:15 --> URI Class Initialized
INFO - 2021-12-20 08:57:15 --> Router Class Initialized
INFO - 2021-12-20 08:57:15 --> Output Class Initialized
INFO - 2021-12-20 08:57:15 --> Security Class Initialized
DEBUG - 2021-12-20 08:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:57:15 --> Input Class Initialized
INFO - 2021-12-20 08:57:15 --> Language Class Initialized
INFO - 2021-12-20 08:57:15 --> Language Class Initialized
INFO - 2021-12-20 08:57:15 --> Config Class Initialized
INFO - 2021-12-20 08:57:15 --> Loader Class Initialized
INFO - 2021-12-20 08:57:15 --> Helper loaded: url_helper
INFO - 2021-12-20 08:57:15 --> Helper loaded: file_helper
INFO - 2021-12-20 08:57:15 --> Helper loaded: form_helper
INFO - 2021-12-20 08:57:15 --> Helper loaded: my_helper
INFO - 2021-12-20 08:57:15 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:57:15 --> Controller Class Initialized
DEBUG - 2021-12-20 08:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:57:15 --> Final output sent to browser
DEBUG - 2021-12-20 08:57:15 --> Total execution time: 0.0430
INFO - 2021-12-20 08:57:23 --> Config Class Initialized
INFO - 2021-12-20 08:57:23 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:57:23 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:57:23 --> Utf8 Class Initialized
INFO - 2021-12-20 08:57:23 --> URI Class Initialized
INFO - 2021-12-20 08:57:23 --> Router Class Initialized
INFO - 2021-12-20 08:57:23 --> Output Class Initialized
INFO - 2021-12-20 08:57:23 --> Security Class Initialized
DEBUG - 2021-12-20 08:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:57:23 --> Input Class Initialized
INFO - 2021-12-20 08:57:23 --> Language Class Initialized
INFO - 2021-12-20 08:57:23 --> Language Class Initialized
INFO - 2021-12-20 08:57:23 --> Config Class Initialized
INFO - 2021-12-20 08:57:23 --> Loader Class Initialized
INFO - 2021-12-20 08:57:23 --> Helper loaded: url_helper
INFO - 2021-12-20 08:57:23 --> Helper loaded: file_helper
INFO - 2021-12-20 08:57:23 --> Helper loaded: form_helper
INFO - 2021-12-20 08:57:23 --> Helper loaded: my_helper
INFO - 2021-12-20 08:57:23 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:57:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:57:23 --> Controller Class Initialized
DEBUG - 2021-12-20 08:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:57:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:57:23 --> Final output sent to browser
DEBUG - 2021-12-20 08:57:23 --> Total execution time: 0.0490
INFO - 2021-12-20 08:58:02 --> Config Class Initialized
INFO - 2021-12-20 08:58:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:58:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:58:02 --> Utf8 Class Initialized
INFO - 2021-12-20 08:58:02 --> URI Class Initialized
INFO - 2021-12-20 08:58:02 --> Router Class Initialized
INFO - 2021-12-20 08:58:02 --> Output Class Initialized
INFO - 2021-12-20 08:58:02 --> Security Class Initialized
DEBUG - 2021-12-20 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:58:02 --> Input Class Initialized
INFO - 2021-12-20 08:58:02 --> Language Class Initialized
INFO - 2021-12-20 08:58:02 --> Language Class Initialized
INFO - 2021-12-20 08:58:02 --> Config Class Initialized
INFO - 2021-12-20 08:58:02 --> Loader Class Initialized
INFO - 2021-12-20 08:58:02 --> Helper loaded: url_helper
INFO - 2021-12-20 08:58:02 --> Helper loaded: file_helper
INFO - 2021-12-20 08:58:02 --> Helper loaded: form_helper
INFO - 2021-12-20 08:58:02 --> Helper loaded: my_helper
INFO - 2021-12-20 08:58:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:58:02 --> Controller Class Initialized
INFO - 2021-12-20 08:58:02 --> Config Class Initialized
INFO - 2021-12-20 08:58:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:58:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:58:02 --> Utf8 Class Initialized
INFO - 2021-12-20 08:58:02 --> URI Class Initialized
INFO - 2021-12-20 08:58:02 --> Router Class Initialized
INFO - 2021-12-20 08:58:02 --> Output Class Initialized
INFO - 2021-12-20 08:58:02 --> Security Class Initialized
DEBUG - 2021-12-20 08:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:58:02 --> Input Class Initialized
INFO - 2021-12-20 08:58:02 --> Language Class Initialized
INFO - 2021-12-20 08:58:02 --> Language Class Initialized
INFO - 2021-12-20 08:58:02 --> Config Class Initialized
INFO - 2021-12-20 08:58:02 --> Loader Class Initialized
INFO - 2021-12-20 08:58:02 --> Helper loaded: url_helper
INFO - 2021-12-20 08:58:02 --> Helper loaded: file_helper
INFO - 2021-12-20 08:58:02 --> Helper loaded: form_helper
INFO - 2021-12-20 08:58:02 --> Helper loaded: my_helper
INFO - 2021-12-20 08:58:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:58:02 --> Controller Class Initialized
DEBUG - 2021-12-20 08:58:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:58:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:58:02 --> Final output sent to browser
DEBUG - 2021-12-20 08:58:02 --> Total execution time: 0.0380
INFO - 2021-12-20 08:58:10 --> Config Class Initialized
INFO - 2021-12-20 08:58:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:58:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:58:10 --> Utf8 Class Initialized
INFO - 2021-12-20 08:58:10 --> URI Class Initialized
INFO - 2021-12-20 08:58:10 --> Router Class Initialized
INFO - 2021-12-20 08:58:10 --> Output Class Initialized
INFO - 2021-12-20 08:58:10 --> Security Class Initialized
DEBUG - 2021-12-20 08:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:58:10 --> Input Class Initialized
INFO - 2021-12-20 08:58:10 --> Language Class Initialized
INFO - 2021-12-20 08:58:10 --> Language Class Initialized
INFO - 2021-12-20 08:58:10 --> Config Class Initialized
INFO - 2021-12-20 08:58:10 --> Loader Class Initialized
INFO - 2021-12-20 08:58:10 --> Helper loaded: url_helper
INFO - 2021-12-20 08:58:10 --> Helper loaded: file_helper
INFO - 2021-12-20 08:58:10 --> Helper loaded: form_helper
INFO - 2021-12-20 08:58:10 --> Helper loaded: my_helper
INFO - 2021-12-20 08:58:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:58:10 --> Controller Class Initialized
DEBUG - 2021-12-20 08:58:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 08:58:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:58:10 --> Final output sent to browser
DEBUG - 2021-12-20 08:58:10 --> Total execution time: 0.0500
INFO - 2021-12-20 08:58:33 --> Config Class Initialized
INFO - 2021-12-20 08:58:33 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:58:33 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:58:33 --> Utf8 Class Initialized
INFO - 2021-12-20 08:58:33 --> URI Class Initialized
INFO - 2021-12-20 08:58:33 --> Router Class Initialized
INFO - 2021-12-20 08:58:33 --> Output Class Initialized
INFO - 2021-12-20 08:58:33 --> Security Class Initialized
DEBUG - 2021-12-20 08:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:58:33 --> Input Class Initialized
INFO - 2021-12-20 08:58:33 --> Language Class Initialized
INFO - 2021-12-20 08:58:33 --> Language Class Initialized
INFO - 2021-12-20 08:58:33 --> Config Class Initialized
INFO - 2021-12-20 08:58:33 --> Loader Class Initialized
INFO - 2021-12-20 08:58:33 --> Helper loaded: url_helper
INFO - 2021-12-20 08:58:33 --> Helper loaded: file_helper
INFO - 2021-12-20 08:58:33 --> Helper loaded: form_helper
INFO - 2021-12-20 08:58:33 --> Helper loaded: my_helper
INFO - 2021-12-20 08:58:33 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:58:33 --> Controller Class Initialized
INFO - 2021-12-20 08:58:33 --> Config Class Initialized
INFO - 2021-12-20 08:58:33 --> Hooks Class Initialized
DEBUG - 2021-12-20 08:58:33 --> UTF-8 Support Enabled
INFO - 2021-12-20 08:58:33 --> Utf8 Class Initialized
INFO - 2021-12-20 08:58:33 --> URI Class Initialized
INFO - 2021-12-20 08:58:33 --> Router Class Initialized
INFO - 2021-12-20 08:58:33 --> Output Class Initialized
INFO - 2021-12-20 08:58:33 --> Security Class Initialized
DEBUG - 2021-12-20 08:58:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 08:58:33 --> Input Class Initialized
INFO - 2021-12-20 08:58:33 --> Language Class Initialized
INFO - 2021-12-20 08:58:33 --> Language Class Initialized
INFO - 2021-12-20 08:58:33 --> Config Class Initialized
INFO - 2021-12-20 08:58:33 --> Loader Class Initialized
INFO - 2021-12-20 08:58:33 --> Helper loaded: url_helper
INFO - 2021-12-20 08:58:33 --> Helper loaded: file_helper
INFO - 2021-12-20 08:58:33 --> Helper loaded: form_helper
INFO - 2021-12-20 08:58:33 --> Helper loaded: my_helper
INFO - 2021-12-20 08:58:33 --> Database Driver Class Initialized
DEBUG - 2021-12-20 08:58:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 08:58:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 08:58:33 --> Controller Class Initialized
DEBUG - 2021-12-20 08:58:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 08:58:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 08:58:33 --> Final output sent to browser
DEBUG - 2021-12-20 08:58:33 --> Total execution time: 0.0490
INFO - 2021-12-20 09:00:37 --> Config Class Initialized
INFO - 2021-12-20 09:00:37 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:00:37 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:00:37 --> Utf8 Class Initialized
INFO - 2021-12-20 09:00:37 --> URI Class Initialized
INFO - 2021-12-20 09:00:37 --> Router Class Initialized
INFO - 2021-12-20 09:00:37 --> Output Class Initialized
INFO - 2021-12-20 09:00:37 --> Security Class Initialized
DEBUG - 2021-12-20 09:00:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:00:37 --> Input Class Initialized
INFO - 2021-12-20 09:00:37 --> Language Class Initialized
INFO - 2021-12-20 09:00:37 --> Language Class Initialized
INFO - 2021-12-20 09:00:37 --> Config Class Initialized
INFO - 2021-12-20 09:00:37 --> Loader Class Initialized
INFO - 2021-12-20 09:00:37 --> Helper loaded: url_helper
INFO - 2021-12-20 09:00:37 --> Helper loaded: file_helper
INFO - 2021-12-20 09:00:37 --> Helper loaded: form_helper
INFO - 2021-12-20 09:00:37 --> Helper loaded: my_helper
INFO - 2021-12-20 09:00:37 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:00:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:00:37 --> Controller Class Initialized
DEBUG - 2021-12-20 09:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 09:00:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:00:37 --> Final output sent to browser
DEBUG - 2021-12-20 09:00:37 --> Total execution time: 0.0420
INFO - 2021-12-20 09:02:01 --> Config Class Initialized
INFO - 2021-12-20 09:02:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:02:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:02:01 --> Utf8 Class Initialized
INFO - 2021-12-20 09:02:01 --> URI Class Initialized
INFO - 2021-12-20 09:02:01 --> Router Class Initialized
INFO - 2021-12-20 09:02:01 --> Output Class Initialized
INFO - 2021-12-20 09:02:01 --> Security Class Initialized
DEBUG - 2021-12-20 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:02:01 --> Input Class Initialized
INFO - 2021-12-20 09:02:01 --> Language Class Initialized
INFO - 2021-12-20 09:02:01 --> Language Class Initialized
INFO - 2021-12-20 09:02:01 --> Config Class Initialized
INFO - 2021-12-20 09:02:01 --> Loader Class Initialized
INFO - 2021-12-20 09:02:01 --> Helper loaded: url_helper
INFO - 2021-12-20 09:02:01 --> Helper loaded: file_helper
INFO - 2021-12-20 09:02:01 --> Helper loaded: form_helper
INFO - 2021-12-20 09:02:01 --> Helper loaded: my_helper
INFO - 2021-12-20 09:02:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:02:01 --> Controller Class Initialized
INFO - 2021-12-20 09:02:01 --> Config Class Initialized
INFO - 2021-12-20 09:02:01 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:02:01 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:02:01 --> Utf8 Class Initialized
INFO - 2021-12-20 09:02:01 --> URI Class Initialized
INFO - 2021-12-20 09:02:01 --> Router Class Initialized
INFO - 2021-12-20 09:02:01 --> Output Class Initialized
INFO - 2021-12-20 09:02:01 --> Security Class Initialized
DEBUG - 2021-12-20 09:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:02:01 --> Input Class Initialized
INFO - 2021-12-20 09:02:01 --> Language Class Initialized
INFO - 2021-12-20 09:02:01 --> Language Class Initialized
INFO - 2021-12-20 09:02:01 --> Config Class Initialized
INFO - 2021-12-20 09:02:01 --> Loader Class Initialized
INFO - 2021-12-20 09:02:01 --> Helper loaded: url_helper
INFO - 2021-12-20 09:02:01 --> Helper loaded: file_helper
INFO - 2021-12-20 09:02:01 --> Helper loaded: form_helper
INFO - 2021-12-20 09:02:01 --> Helper loaded: my_helper
INFO - 2021-12-20 09:02:01 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:02:01 --> Controller Class Initialized
DEBUG - 2021-12-20 09:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 09:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:02:01 --> Final output sent to browser
DEBUG - 2021-12-20 09:02:01 --> Total execution time: 0.0470
INFO - 2021-12-20 09:02:04 --> Config Class Initialized
INFO - 2021-12-20 09:02:04 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:02:04 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:02:04 --> Utf8 Class Initialized
INFO - 2021-12-20 09:02:04 --> URI Class Initialized
INFO - 2021-12-20 09:02:04 --> Router Class Initialized
INFO - 2021-12-20 09:02:04 --> Output Class Initialized
INFO - 2021-12-20 09:02:04 --> Security Class Initialized
DEBUG - 2021-12-20 09:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:02:04 --> Input Class Initialized
INFO - 2021-12-20 09:02:04 --> Language Class Initialized
INFO - 2021-12-20 09:02:04 --> Language Class Initialized
INFO - 2021-12-20 09:02:04 --> Config Class Initialized
INFO - 2021-12-20 09:02:04 --> Loader Class Initialized
INFO - 2021-12-20 09:02:04 --> Helper loaded: url_helper
INFO - 2021-12-20 09:02:04 --> Helper loaded: file_helper
INFO - 2021-12-20 09:02:04 --> Helper loaded: form_helper
INFO - 2021-12-20 09:02:04 --> Helper loaded: my_helper
INFO - 2021-12-20 09:02:04 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:02:04 --> Controller Class Initialized
DEBUG - 2021-12-20 09:02:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 09:02:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:02:04 --> Final output sent to browser
DEBUG - 2021-12-20 09:02:04 --> Total execution time: 0.0560
INFO - 2021-12-20 09:03:10 --> Config Class Initialized
INFO - 2021-12-20 09:03:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:03:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:03:10 --> Utf8 Class Initialized
INFO - 2021-12-20 09:03:10 --> URI Class Initialized
INFO - 2021-12-20 09:03:10 --> Router Class Initialized
INFO - 2021-12-20 09:03:10 --> Output Class Initialized
INFO - 2021-12-20 09:03:10 --> Security Class Initialized
DEBUG - 2021-12-20 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:03:10 --> Input Class Initialized
INFO - 2021-12-20 09:03:10 --> Language Class Initialized
INFO - 2021-12-20 09:03:10 --> Language Class Initialized
INFO - 2021-12-20 09:03:10 --> Config Class Initialized
INFO - 2021-12-20 09:03:10 --> Loader Class Initialized
INFO - 2021-12-20 09:03:10 --> Helper loaded: url_helper
INFO - 2021-12-20 09:03:10 --> Helper loaded: file_helper
INFO - 2021-12-20 09:03:10 --> Helper loaded: form_helper
INFO - 2021-12-20 09:03:10 --> Helper loaded: my_helper
INFO - 2021-12-20 09:03:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:03:10 --> Controller Class Initialized
INFO - 2021-12-20 09:03:10 --> Config Class Initialized
INFO - 2021-12-20 09:03:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:03:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:03:10 --> Utf8 Class Initialized
INFO - 2021-12-20 09:03:10 --> URI Class Initialized
INFO - 2021-12-20 09:03:10 --> Router Class Initialized
INFO - 2021-12-20 09:03:10 --> Output Class Initialized
INFO - 2021-12-20 09:03:10 --> Security Class Initialized
DEBUG - 2021-12-20 09:03:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:03:10 --> Input Class Initialized
INFO - 2021-12-20 09:03:10 --> Language Class Initialized
INFO - 2021-12-20 09:03:10 --> Language Class Initialized
INFO - 2021-12-20 09:03:10 --> Config Class Initialized
INFO - 2021-12-20 09:03:10 --> Loader Class Initialized
INFO - 2021-12-20 09:03:10 --> Helper loaded: url_helper
INFO - 2021-12-20 09:03:10 --> Helper loaded: file_helper
INFO - 2021-12-20 09:03:10 --> Helper loaded: form_helper
INFO - 2021-12-20 09:03:10 --> Helper loaded: my_helper
INFO - 2021-12-20 09:03:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:03:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:03:10 --> Controller Class Initialized
DEBUG - 2021-12-20 09:03:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 09:03:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:03:10 --> Final output sent to browser
DEBUG - 2021-12-20 09:03:10 --> Total execution time: 0.0460
INFO - 2021-12-20 09:03:12 --> Config Class Initialized
INFO - 2021-12-20 09:03:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:03:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:03:12 --> Utf8 Class Initialized
INFO - 2021-12-20 09:03:12 --> URI Class Initialized
INFO - 2021-12-20 09:03:12 --> Router Class Initialized
INFO - 2021-12-20 09:03:12 --> Output Class Initialized
INFO - 2021-12-20 09:03:12 --> Security Class Initialized
DEBUG - 2021-12-20 09:03:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:03:12 --> Input Class Initialized
INFO - 2021-12-20 09:03:12 --> Language Class Initialized
INFO - 2021-12-20 09:03:12 --> Language Class Initialized
INFO - 2021-12-20 09:03:12 --> Config Class Initialized
INFO - 2021-12-20 09:03:12 --> Loader Class Initialized
INFO - 2021-12-20 09:03:12 --> Helper loaded: url_helper
INFO - 2021-12-20 09:03:12 --> Helper loaded: file_helper
INFO - 2021-12-20 09:03:12 --> Helper loaded: form_helper
INFO - 2021-12-20 09:03:12 --> Helper loaded: my_helper
INFO - 2021-12-20 09:03:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:03:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:03:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:03:12 --> Controller Class Initialized
DEBUG - 2021-12-20 09:03:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 09:03:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:03:12 --> Final output sent to browser
DEBUG - 2021-12-20 09:03:12 --> Total execution time: 0.0500
INFO - 2021-12-20 09:04:21 --> Config Class Initialized
INFO - 2021-12-20 09:04:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:04:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:04:21 --> Utf8 Class Initialized
INFO - 2021-12-20 09:04:21 --> URI Class Initialized
INFO - 2021-12-20 09:04:21 --> Router Class Initialized
INFO - 2021-12-20 09:04:21 --> Output Class Initialized
INFO - 2021-12-20 09:04:21 --> Security Class Initialized
DEBUG - 2021-12-20 09:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:04:21 --> Input Class Initialized
INFO - 2021-12-20 09:04:21 --> Language Class Initialized
INFO - 2021-12-20 09:04:21 --> Language Class Initialized
INFO - 2021-12-20 09:04:21 --> Config Class Initialized
INFO - 2021-12-20 09:04:21 --> Loader Class Initialized
INFO - 2021-12-20 09:04:21 --> Helper loaded: url_helper
INFO - 2021-12-20 09:04:21 --> Helper loaded: file_helper
INFO - 2021-12-20 09:04:21 --> Helper loaded: form_helper
INFO - 2021-12-20 09:04:21 --> Helper loaded: my_helper
INFO - 2021-12-20 09:04:21 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:04:21 --> Controller Class Initialized
INFO - 2021-12-20 09:04:21 --> Config Class Initialized
INFO - 2021-12-20 09:04:21 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:04:21 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:04:21 --> Utf8 Class Initialized
INFO - 2021-12-20 09:04:21 --> URI Class Initialized
INFO - 2021-12-20 09:04:21 --> Router Class Initialized
INFO - 2021-12-20 09:04:21 --> Output Class Initialized
INFO - 2021-12-20 09:04:21 --> Security Class Initialized
DEBUG - 2021-12-20 09:04:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:04:21 --> Input Class Initialized
INFO - 2021-12-20 09:04:21 --> Language Class Initialized
INFO - 2021-12-20 09:04:21 --> Language Class Initialized
INFO - 2021-12-20 09:04:21 --> Config Class Initialized
INFO - 2021-12-20 09:04:21 --> Loader Class Initialized
INFO - 2021-12-20 09:04:21 --> Helper loaded: url_helper
INFO - 2021-12-20 09:04:21 --> Helper loaded: file_helper
INFO - 2021-12-20 09:04:21 --> Helper loaded: form_helper
INFO - 2021-12-20 09:04:21 --> Helper loaded: my_helper
INFO - 2021-12-20 09:04:21 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:04:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:04:21 --> Controller Class Initialized
DEBUG - 2021-12-20 09:04:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 09:04:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:04:21 --> Final output sent to browser
DEBUG - 2021-12-20 09:04:21 --> Total execution time: 0.0460
INFO - 2021-12-20 09:04:23 --> Config Class Initialized
INFO - 2021-12-20 09:04:23 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:04:23 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:04:23 --> Utf8 Class Initialized
INFO - 2021-12-20 09:04:23 --> URI Class Initialized
INFO - 2021-12-20 09:04:23 --> Router Class Initialized
INFO - 2021-12-20 09:04:23 --> Output Class Initialized
INFO - 2021-12-20 09:04:23 --> Security Class Initialized
DEBUG - 2021-12-20 09:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:04:23 --> Input Class Initialized
INFO - 2021-12-20 09:04:23 --> Language Class Initialized
INFO - 2021-12-20 09:04:23 --> Language Class Initialized
INFO - 2021-12-20 09:04:23 --> Config Class Initialized
INFO - 2021-12-20 09:04:23 --> Loader Class Initialized
INFO - 2021-12-20 09:04:23 --> Helper loaded: url_helper
INFO - 2021-12-20 09:04:23 --> Helper loaded: file_helper
INFO - 2021-12-20 09:04:23 --> Helper loaded: form_helper
INFO - 2021-12-20 09:04:23 --> Helper loaded: my_helper
INFO - 2021-12-20 09:04:23 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:04:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:04:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:04:23 --> Controller Class Initialized
DEBUG - 2021-12-20 09:04:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-20 09:04:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:04:23 --> Final output sent to browser
DEBUG - 2021-12-20 09:04:23 --> Total execution time: 0.0420
INFO - 2021-12-20 09:05:45 --> Config Class Initialized
INFO - 2021-12-20 09:05:45 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:05:45 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:05:45 --> Utf8 Class Initialized
INFO - 2021-12-20 09:05:45 --> URI Class Initialized
INFO - 2021-12-20 09:05:45 --> Router Class Initialized
INFO - 2021-12-20 09:05:45 --> Output Class Initialized
INFO - 2021-12-20 09:05:45 --> Security Class Initialized
DEBUG - 2021-12-20 09:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:05:45 --> Input Class Initialized
INFO - 2021-12-20 09:05:45 --> Language Class Initialized
INFO - 2021-12-20 09:05:45 --> Language Class Initialized
INFO - 2021-12-20 09:05:45 --> Config Class Initialized
INFO - 2021-12-20 09:05:45 --> Loader Class Initialized
INFO - 2021-12-20 09:05:45 --> Helper loaded: url_helper
INFO - 2021-12-20 09:05:45 --> Helper loaded: file_helper
INFO - 2021-12-20 09:05:45 --> Helper loaded: form_helper
INFO - 2021-12-20 09:05:45 --> Helper loaded: my_helper
INFO - 2021-12-20 09:05:45 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:05:45 --> Controller Class Initialized
INFO - 2021-12-20 09:05:46 --> Config Class Initialized
INFO - 2021-12-20 09:05:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:05:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:05:46 --> Utf8 Class Initialized
INFO - 2021-12-20 09:05:46 --> URI Class Initialized
INFO - 2021-12-20 09:05:46 --> Router Class Initialized
INFO - 2021-12-20 09:05:46 --> Output Class Initialized
INFO - 2021-12-20 09:05:46 --> Security Class Initialized
DEBUG - 2021-12-20 09:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:05:46 --> Input Class Initialized
INFO - 2021-12-20 09:05:46 --> Language Class Initialized
INFO - 2021-12-20 09:05:46 --> Language Class Initialized
INFO - 2021-12-20 09:05:46 --> Config Class Initialized
INFO - 2021-12-20 09:05:46 --> Loader Class Initialized
INFO - 2021-12-20 09:05:46 --> Helper loaded: url_helper
INFO - 2021-12-20 09:05:46 --> Helper loaded: file_helper
INFO - 2021-12-20 09:05:46 --> Helper loaded: form_helper
INFO - 2021-12-20 09:05:46 --> Helper loaded: my_helper
INFO - 2021-12-20 09:05:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:05:46 --> Controller Class Initialized
DEBUG - 2021-12-20 09:05:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 09:05:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:05:46 --> Final output sent to browser
DEBUG - 2021-12-20 09:05:46 --> Total execution time: 0.0460
INFO - 2021-12-20 09:27:59 --> Config Class Initialized
INFO - 2021-12-20 09:27:59 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:27:59 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:27:59 --> Utf8 Class Initialized
INFO - 2021-12-20 09:27:59 --> URI Class Initialized
DEBUG - 2021-12-20 09:27:59 --> No URI present. Default controller set.
INFO - 2021-12-20 09:27:59 --> Router Class Initialized
INFO - 2021-12-20 09:27:59 --> Output Class Initialized
INFO - 2021-12-20 09:27:59 --> Security Class Initialized
DEBUG - 2021-12-20 09:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:27:59 --> Input Class Initialized
INFO - 2021-12-20 09:27:59 --> Language Class Initialized
INFO - 2021-12-20 09:27:59 --> Language Class Initialized
INFO - 2021-12-20 09:27:59 --> Config Class Initialized
INFO - 2021-12-20 09:27:59 --> Loader Class Initialized
INFO - 2021-12-20 09:27:59 --> Helper loaded: url_helper
INFO - 2021-12-20 09:27:59 --> Helper loaded: file_helper
INFO - 2021-12-20 09:27:59 --> Helper loaded: form_helper
INFO - 2021-12-20 09:27:59 --> Helper loaded: my_helper
INFO - 2021-12-20 09:27:59 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:27:59 --> Controller Class Initialized
INFO - 2021-12-20 09:31:44 --> Config Class Initialized
INFO - 2021-12-20 09:31:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:31:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:31:44 --> Utf8 Class Initialized
INFO - 2021-12-20 09:31:44 --> URI Class Initialized
DEBUG - 2021-12-20 09:31:44 --> No URI present. Default controller set.
INFO - 2021-12-20 09:31:44 --> Router Class Initialized
INFO - 2021-12-20 09:31:44 --> Output Class Initialized
INFO - 2021-12-20 09:31:44 --> Security Class Initialized
DEBUG - 2021-12-20 09:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:31:44 --> Input Class Initialized
INFO - 2021-12-20 09:31:44 --> Language Class Initialized
INFO - 2021-12-20 09:31:44 --> Language Class Initialized
INFO - 2021-12-20 09:31:44 --> Config Class Initialized
INFO - 2021-12-20 09:31:44 --> Loader Class Initialized
INFO - 2021-12-20 09:31:44 --> Helper loaded: url_helper
INFO - 2021-12-20 09:31:44 --> Helper loaded: file_helper
INFO - 2021-12-20 09:31:44 --> Helper loaded: form_helper
INFO - 2021-12-20 09:31:44 --> Helper loaded: my_helper
INFO - 2021-12-20 09:31:44 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:31:44 --> Controller Class Initialized
INFO - 2021-12-20 09:31:44 --> Config Class Initialized
INFO - 2021-12-20 09:31:44 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:31:44 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:31:44 --> Utf8 Class Initialized
INFO - 2021-12-20 09:31:44 --> URI Class Initialized
INFO - 2021-12-20 09:31:44 --> Router Class Initialized
INFO - 2021-12-20 09:31:44 --> Output Class Initialized
INFO - 2021-12-20 09:31:44 --> Security Class Initialized
DEBUG - 2021-12-20 09:31:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:31:44 --> Input Class Initialized
INFO - 2021-12-20 09:31:44 --> Language Class Initialized
ERROR - 2021-12-20 09:31:44 --> 404 Page Not Found: /index
INFO - 2021-12-20 09:32:06 --> Config Class Initialized
INFO - 2021-12-20 09:32:06 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:32:06 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:32:06 --> Utf8 Class Initialized
INFO - 2021-12-20 09:32:06 --> URI Class Initialized
DEBUG - 2021-12-20 09:32:06 --> No URI present. Default controller set.
INFO - 2021-12-20 09:32:06 --> Router Class Initialized
INFO - 2021-12-20 09:32:06 --> Output Class Initialized
INFO - 2021-12-20 09:32:06 --> Security Class Initialized
DEBUG - 2021-12-20 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:32:06 --> Input Class Initialized
INFO - 2021-12-20 09:32:06 --> Language Class Initialized
INFO - 2021-12-20 09:32:06 --> Language Class Initialized
INFO - 2021-12-20 09:32:06 --> Config Class Initialized
INFO - 2021-12-20 09:32:06 --> Loader Class Initialized
INFO - 2021-12-20 09:32:06 --> Helper loaded: url_helper
INFO - 2021-12-20 09:32:06 --> Helper loaded: file_helper
INFO - 2021-12-20 09:32:06 --> Helper loaded: form_helper
INFO - 2021-12-20 09:32:06 --> Helper loaded: my_helper
INFO - 2021-12-20 09:32:06 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:32:06 --> Controller Class Initialized
INFO - 2021-12-20 09:32:06 --> Config Class Initialized
INFO - 2021-12-20 09:32:06 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:32:06 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:32:06 --> Utf8 Class Initialized
INFO - 2021-12-20 09:32:06 --> URI Class Initialized
INFO - 2021-12-20 09:32:06 --> Router Class Initialized
INFO - 2021-12-20 09:32:06 --> Output Class Initialized
INFO - 2021-12-20 09:32:06 --> Security Class Initialized
DEBUG - 2021-12-20 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:32:06 --> Input Class Initialized
INFO - 2021-12-20 09:32:06 --> Language Class Initialized
INFO - 2021-12-20 09:32:06 --> Language Class Initialized
INFO - 2021-12-20 09:32:06 --> Config Class Initialized
INFO - 2021-12-20 09:32:06 --> Loader Class Initialized
INFO - 2021-12-20 09:32:06 --> Helper loaded: url_helper
INFO - 2021-12-20 09:32:06 --> Helper loaded: file_helper
INFO - 2021-12-20 09:32:06 --> Helper loaded: form_helper
INFO - 2021-12-20 09:32:06 --> Helper loaded: my_helper
INFO - 2021-12-20 09:32:06 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:32:06 --> Controller Class Initialized
DEBUG - 2021-12-20 09:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 09:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:32:06 --> Final output sent to browser
DEBUG - 2021-12-20 09:32:06 --> Total execution time: 0.0380
INFO - 2021-12-20 09:35:24 --> Config Class Initialized
INFO - 2021-12-20 09:35:24 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:35:24 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:35:24 --> Utf8 Class Initialized
INFO - 2021-12-20 09:35:24 --> URI Class Initialized
INFO - 2021-12-20 09:35:24 --> Router Class Initialized
INFO - 2021-12-20 09:35:24 --> Output Class Initialized
INFO - 2021-12-20 09:35:24 --> Security Class Initialized
DEBUG - 2021-12-20 09:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:35:24 --> Input Class Initialized
INFO - 2021-12-20 09:35:24 --> Language Class Initialized
INFO - 2021-12-20 09:35:24 --> Language Class Initialized
INFO - 2021-12-20 09:35:24 --> Config Class Initialized
INFO - 2021-12-20 09:35:24 --> Loader Class Initialized
INFO - 2021-12-20 09:35:24 --> Helper loaded: url_helper
INFO - 2021-12-20 09:35:24 --> Helper loaded: file_helper
INFO - 2021-12-20 09:35:24 --> Helper loaded: form_helper
INFO - 2021-12-20 09:35:24 --> Helper loaded: my_helper
INFO - 2021-12-20 09:35:24 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:35:24 --> Controller Class Initialized
DEBUG - 2021-12-20 09:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 09:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:35:24 --> Final output sent to browser
DEBUG - 2021-12-20 09:35:24 --> Total execution time: 0.0510
INFO - 2021-12-20 09:35:42 --> Config Class Initialized
INFO - 2021-12-20 09:35:42 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:35:42 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:35:42 --> Utf8 Class Initialized
INFO - 2021-12-20 09:35:42 --> URI Class Initialized
INFO - 2021-12-20 09:35:42 --> Router Class Initialized
INFO - 2021-12-20 09:35:42 --> Output Class Initialized
INFO - 2021-12-20 09:35:42 --> Security Class Initialized
DEBUG - 2021-12-20 09:35:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:35:42 --> Input Class Initialized
INFO - 2021-12-20 09:35:42 --> Language Class Initialized
INFO - 2021-12-20 09:35:42 --> Language Class Initialized
INFO - 2021-12-20 09:35:42 --> Config Class Initialized
INFO - 2021-12-20 09:35:42 --> Loader Class Initialized
INFO - 2021-12-20 09:35:42 --> Helper loaded: url_helper
INFO - 2021-12-20 09:35:42 --> Helper loaded: file_helper
INFO - 2021-12-20 09:35:42 --> Helper loaded: form_helper
INFO - 2021-12-20 09:35:42 --> Helper loaded: my_helper
INFO - 2021-12-20 09:35:42 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:35:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:35:42 --> Controller Class Initialized
DEBUG - 2021-12-20 09:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 09:35:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:35:42 --> Final output sent to browser
DEBUG - 2021-12-20 09:35:42 --> Total execution time: 0.0470
INFO - 2021-12-20 09:36:37 --> Config Class Initialized
INFO - 2021-12-20 09:36:37 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:36:37 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:36:37 --> Utf8 Class Initialized
INFO - 2021-12-20 09:36:37 --> URI Class Initialized
INFO - 2021-12-20 09:36:37 --> Router Class Initialized
INFO - 2021-12-20 09:36:37 --> Output Class Initialized
INFO - 2021-12-20 09:36:37 --> Security Class Initialized
DEBUG - 2021-12-20 09:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:36:37 --> Input Class Initialized
INFO - 2021-12-20 09:36:37 --> Language Class Initialized
INFO - 2021-12-20 09:36:37 --> Language Class Initialized
INFO - 2021-12-20 09:36:37 --> Config Class Initialized
INFO - 2021-12-20 09:36:37 --> Loader Class Initialized
INFO - 2021-12-20 09:36:37 --> Helper loaded: url_helper
INFO - 2021-12-20 09:36:37 --> Helper loaded: file_helper
INFO - 2021-12-20 09:36:37 --> Helper loaded: form_helper
INFO - 2021-12-20 09:36:37 --> Helper loaded: my_helper
INFO - 2021-12-20 09:36:37 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:36:37 --> Controller Class Initialized
DEBUG - 2021-12-20 09:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 09:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:36:37 --> Final output sent to browser
DEBUG - 2021-12-20 09:36:37 --> Total execution time: 0.0520
INFO - 2021-12-20 09:36:46 --> Config Class Initialized
INFO - 2021-12-20 09:36:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:36:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:36:46 --> Utf8 Class Initialized
INFO - 2021-12-20 09:36:46 --> URI Class Initialized
INFO - 2021-12-20 09:36:46 --> Router Class Initialized
INFO - 2021-12-20 09:36:46 --> Output Class Initialized
INFO - 2021-12-20 09:36:46 --> Security Class Initialized
DEBUG - 2021-12-20 09:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:36:46 --> Input Class Initialized
INFO - 2021-12-20 09:36:46 --> Language Class Initialized
INFO - 2021-12-20 09:36:46 --> Language Class Initialized
INFO - 2021-12-20 09:36:46 --> Config Class Initialized
INFO - 2021-12-20 09:36:46 --> Loader Class Initialized
INFO - 2021-12-20 09:36:46 --> Helper loaded: url_helper
INFO - 2021-12-20 09:36:46 --> Helper loaded: file_helper
INFO - 2021-12-20 09:36:46 --> Helper loaded: form_helper
INFO - 2021-12-20 09:36:46 --> Helper loaded: my_helper
INFO - 2021-12-20 09:36:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:36:46 --> Controller Class Initialized
INFO - 2021-12-20 09:36:46 --> Helper loaded: cookie_helper
INFO - 2021-12-20 09:36:46 --> Final output sent to browser
DEBUG - 2021-12-20 09:36:46 --> Total execution time: 0.0560
INFO - 2021-12-20 09:36:46 --> Config Class Initialized
INFO - 2021-12-20 09:36:46 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:36:46 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:36:46 --> Utf8 Class Initialized
INFO - 2021-12-20 09:36:46 --> URI Class Initialized
INFO - 2021-12-20 09:36:46 --> Router Class Initialized
INFO - 2021-12-20 09:36:46 --> Output Class Initialized
INFO - 2021-12-20 09:36:46 --> Security Class Initialized
DEBUG - 2021-12-20 09:36:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:36:46 --> Input Class Initialized
INFO - 2021-12-20 09:36:46 --> Language Class Initialized
INFO - 2021-12-20 09:36:46 --> Language Class Initialized
INFO - 2021-12-20 09:36:46 --> Config Class Initialized
INFO - 2021-12-20 09:36:46 --> Loader Class Initialized
INFO - 2021-12-20 09:36:46 --> Helper loaded: url_helper
INFO - 2021-12-20 09:36:46 --> Helper loaded: file_helper
INFO - 2021-12-20 09:36:46 --> Helper loaded: form_helper
INFO - 2021-12-20 09:36:46 --> Helper loaded: my_helper
INFO - 2021-12-20 09:36:46 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:36:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:36:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:36:46 --> Controller Class Initialized
DEBUG - 2021-12-20 09:36:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 09:36:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:36:46 --> Final output sent to browser
DEBUG - 2021-12-20 09:36:46 --> Total execution time: 0.2230
INFO - 2021-12-20 09:36:54 --> Config Class Initialized
INFO - 2021-12-20 09:36:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:36:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:36:54 --> Utf8 Class Initialized
INFO - 2021-12-20 09:36:54 --> URI Class Initialized
INFO - 2021-12-20 09:36:54 --> Router Class Initialized
INFO - 2021-12-20 09:36:54 --> Output Class Initialized
INFO - 2021-12-20 09:36:54 --> Security Class Initialized
DEBUG - 2021-12-20 09:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:36:54 --> Input Class Initialized
INFO - 2021-12-20 09:36:54 --> Language Class Initialized
INFO - 2021-12-20 09:36:54 --> Language Class Initialized
INFO - 2021-12-20 09:36:54 --> Config Class Initialized
INFO - 2021-12-20 09:36:54 --> Loader Class Initialized
INFO - 2021-12-20 09:36:54 --> Helper loaded: url_helper
INFO - 2021-12-20 09:36:54 --> Helper loaded: file_helper
INFO - 2021-12-20 09:36:54 --> Helper loaded: form_helper
INFO - 2021-12-20 09:36:54 --> Helper loaded: my_helper
INFO - 2021-12-20 09:36:54 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:36:54 --> Controller Class Initialized
DEBUG - 2021-12-20 09:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-20 09:36:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:36:54 --> Final output sent to browser
DEBUG - 2021-12-20 09:36:54 --> Total execution time: 0.0620
INFO - 2021-12-20 09:40:13 --> Config Class Initialized
INFO - 2021-12-20 09:40:13 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:13 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:13 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:13 --> URI Class Initialized
INFO - 2021-12-20 09:40:13 --> Router Class Initialized
INFO - 2021-12-20 09:40:13 --> Output Class Initialized
INFO - 2021-12-20 09:40:13 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:13 --> Input Class Initialized
INFO - 2021-12-20 09:40:13 --> Language Class Initialized
INFO - 2021-12-20 09:40:13 --> Language Class Initialized
INFO - 2021-12-20 09:40:13 --> Config Class Initialized
INFO - 2021-12-20 09:40:13 --> Loader Class Initialized
INFO - 2021-12-20 09:40:13 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:13 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:13 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:13 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:13 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:13 --> Controller Class Initialized
DEBUG - 2021-12-20 09:40:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 09:40:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:40:13 --> Final output sent to browser
DEBUG - 2021-12-20 09:40:13 --> Total execution time: 0.0480
INFO - 2021-12-20 09:40:14 --> Config Class Initialized
INFO - 2021-12-20 09:40:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:14 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:14 --> URI Class Initialized
INFO - 2021-12-20 09:40:14 --> Router Class Initialized
INFO - 2021-12-20 09:40:14 --> Output Class Initialized
INFO - 2021-12-20 09:40:14 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:14 --> Input Class Initialized
INFO - 2021-12-20 09:40:14 --> Language Class Initialized
INFO - 2021-12-20 09:40:14 --> Language Class Initialized
INFO - 2021-12-20 09:40:14 --> Config Class Initialized
INFO - 2021-12-20 09:40:14 --> Loader Class Initialized
INFO - 2021-12-20 09:40:14 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:14 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:14 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:14 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:14 --> Controller Class Initialized
DEBUG - 2021-12-20 09:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 09:40:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:40:14 --> Final output sent to browser
DEBUG - 2021-12-20 09:40:14 --> Total execution time: 0.0430
INFO - 2021-12-20 09:40:14 --> Config Class Initialized
INFO - 2021-12-20 09:40:14 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:14 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:14 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:14 --> URI Class Initialized
INFO - 2021-12-20 09:40:14 --> Router Class Initialized
INFO - 2021-12-20 09:40:14 --> Output Class Initialized
INFO - 2021-12-20 09:40:14 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:14 --> Input Class Initialized
INFO - 2021-12-20 09:40:14 --> Language Class Initialized
INFO - 2021-12-20 09:40:14 --> Language Class Initialized
INFO - 2021-12-20 09:40:14 --> Config Class Initialized
INFO - 2021-12-20 09:40:14 --> Loader Class Initialized
INFO - 2021-12-20 09:40:14 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:14 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:14 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:14 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:14 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:14 --> Controller Class Initialized
INFO - 2021-12-20 09:40:17 --> Config Class Initialized
INFO - 2021-12-20 09:40:17 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:17 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:17 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:17 --> URI Class Initialized
DEBUG - 2021-12-20 09:40:17 --> No URI present. Default controller set.
INFO - 2021-12-20 09:40:17 --> Router Class Initialized
INFO - 2021-12-20 09:40:17 --> Output Class Initialized
INFO - 2021-12-20 09:40:17 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:17 --> Input Class Initialized
INFO - 2021-12-20 09:40:17 --> Language Class Initialized
INFO - 2021-12-20 09:40:17 --> Language Class Initialized
INFO - 2021-12-20 09:40:17 --> Config Class Initialized
INFO - 2021-12-20 09:40:17 --> Loader Class Initialized
INFO - 2021-12-20 09:40:17 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:17 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:17 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:17 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:17 --> Controller Class Initialized
INFO - 2021-12-20 09:40:17 --> Config Class Initialized
INFO - 2021-12-20 09:40:17 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:17 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:17 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:17 --> URI Class Initialized
INFO - 2021-12-20 09:40:17 --> Router Class Initialized
INFO - 2021-12-20 09:40:17 --> Output Class Initialized
INFO - 2021-12-20 09:40:17 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:17 --> Input Class Initialized
INFO - 2021-12-20 09:40:17 --> Language Class Initialized
INFO - 2021-12-20 09:40:17 --> Language Class Initialized
INFO - 2021-12-20 09:40:17 --> Config Class Initialized
INFO - 2021-12-20 09:40:17 --> Loader Class Initialized
INFO - 2021-12-20 09:40:17 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:17 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:17 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:17 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:17 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:17 --> Controller Class Initialized
DEBUG - 2021-12-20 09:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 09:40:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:40:17 --> Final output sent to browser
DEBUG - 2021-12-20 09:40:17 --> Total execution time: 0.0370
INFO - 2021-12-20 09:40:22 --> Config Class Initialized
INFO - 2021-12-20 09:40:22 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:22 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:22 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:22 --> URI Class Initialized
INFO - 2021-12-20 09:40:22 --> Router Class Initialized
INFO - 2021-12-20 09:40:22 --> Output Class Initialized
INFO - 2021-12-20 09:40:22 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:22 --> Input Class Initialized
INFO - 2021-12-20 09:40:22 --> Language Class Initialized
INFO - 2021-12-20 09:40:22 --> Language Class Initialized
INFO - 2021-12-20 09:40:22 --> Config Class Initialized
INFO - 2021-12-20 09:40:22 --> Loader Class Initialized
INFO - 2021-12-20 09:40:22 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:22 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:22 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:22 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:22 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:22 --> Controller Class Initialized
INFO - 2021-12-20 09:40:22 --> Helper loaded: cookie_helper
INFO - 2021-12-20 09:40:22 --> Final output sent to browser
DEBUG - 2021-12-20 09:40:22 --> Total execution time: 0.0500
INFO - 2021-12-20 09:40:22 --> Config Class Initialized
INFO - 2021-12-20 09:40:23 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:23 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:23 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:23 --> URI Class Initialized
INFO - 2021-12-20 09:40:23 --> Router Class Initialized
INFO - 2021-12-20 09:40:23 --> Output Class Initialized
INFO - 2021-12-20 09:40:23 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:23 --> Input Class Initialized
INFO - 2021-12-20 09:40:23 --> Language Class Initialized
INFO - 2021-12-20 09:40:23 --> Language Class Initialized
INFO - 2021-12-20 09:40:23 --> Config Class Initialized
INFO - 2021-12-20 09:40:23 --> Loader Class Initialized
INFO - 2021-12-20 09:40:23 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:23 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:23 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:23 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:23 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:23 --> Controller Class Initialized
DEBUG - 2021-12-20 09:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 09:40:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:40:23 --> Final output sent to browser
DEBUG - 2021-12-20 09:40:23 --> Total execution time: 0.1220
INFO - 2021-12-20 09:40:24 --> Config Class Initialized
INFO - 2021-12-20 09:40:24 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:24 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:24 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:24 --> URI Class Initialized
INFO - 2021-12-20 09:40:24 --> Router Class Initialized
INFO - 2021-12-20 09:40:24 --> Output Class Initialized
INFO - 2021-12-20 09:40:24 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:24 --> Input Class Initialized
INFO - 2021-12-20 09:40:24 --> Language Class Initialized
INFO - 2021-12-20 09:40:24 --> Language Class Initialized
INFO - 2021-12-20 09:40:24 --> Config Class Initialized
INFO - 2021-12-20 09:40:24 --> Loader Class Initialized
INFO - 2021-12-20 09:40:24 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:24 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:24 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:24 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:24 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:24 --> Controller Class Initialized
DEBUG - 2021-12-20 09:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-20 09:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:40:24 --> Final output sent to browser
DEBUG - 2021-12-20 09:40:24 --> Total execution time: 0.0440
INFO - 2021-12-20 09:40:24 --> Config Class Initialized
INFO - 2021-12-20 09:40:24 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:24 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:24 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:24 --> URI Class Initialized
INFO - 2021-12-20 09:40:24 --> Router Class Initialized
INFO - 2021-12-20 09:40:24 --> Output Class Initialized
INFO - 2021-12-20 09:40:24 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:24 --> Input Class Initialized
INFO - 2021-12-20 09:40:24 --> Language Class Initialized
INFO - 2021-12-20 09:40:24 --> Language Class Initialized
INFO - 2021-12-20 09:40:24 --> Config Class Initialized
INFO - 2021-12-20 09:40:24 --> Loader Class Initialized
INFO - 2021-12-20 09:40:24 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:24 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:24 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:24 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:24 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:24 --> Controller Class Initialized
INFO - 2021-12-20 09:40:29 --> Config Class Initialized
INFO - 2021-12-20 09:40:29 --> Hooks Class Initialized
DEBUG - 2021-12-20 09:40:29 --> UTF-8 Support Enabled
INFO - 2021-12-20 09:40:29 --> Utf8 Class Initialized
INFO - 2021-12-20 09:40:29 --> URI Class Initialized
INFO - 2021-12-20 09:40:29 --> Router Class Initialized
INFO - 2021-12-20 09:40:29 --> Output Class Initialized
INFO - 2021-12-20 09:40:29 --> Security Class Initialized
DEBUG - 2021-12-20 09:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 09:40:29 --> Input Class Initialized
INFO - 2021-12-20 09:40:29 --> Language Class Initialized
INFO - 2021-12-20 09:40:29 --> Language Class Initialized
INFO - 2021-12-20 09:40:29 --> Config Class Initialized
INFO - 2021-12-20 09:40:29 --> Loader Class Initialized
INFO - 2021-12-20 09:40:29 --> Helper loaded: url_helper
INFO - 2021-12-20 09:40:29 --> Helper loaded: file_helper
INFO - 2021-12-20 09:40:29 --> Helper loaded: form_helper
INFO - 2021-12-20 09:40:29 --> Helper loaded: my_helper
INFO - 2021-12-20 09:40:29 --> Database Driver Class Initialized
DEBUG - 2021-12-20 09:40:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 09:40:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 09:40:29 --> Controller Class Initialized
DEBUG - 2021-12-20 09:40:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 09:40:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 09:40:29 --> Final output sent to browser
DEBUG - 2021-12-20 09:40:29 --> Total execution time: 0.0630
INFO - 2021-12-20 10:14:41 --> Config Class Initialized
INFO - 2021-12-20 10:14:41 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:14:41 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:14:41 --> Utf8 Class Initialized
INFO - 2021-12-20 10:14:41 --> URI Class Initialized
INFO - 2021-12-20 10:14:41 --> Router Class Initialized
INFO - 2021-12-20 10:14:41 --> Output Class Initialized
INFO - 2021-12-20 10:14:41 --> Security Class Initialized
DEBUG - 2021-12-20 10:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:14:41 --> Input Class Initialized
INFO - 2021-12-20 10:14:41 --> Language Class Initialized
INFO - 2021-12-20 10:14:41 --> Language Class Initialized
INFO - 2021-12-20 10:14:41 --> Config Class Initialized
INFO - 2021-12-20 10:14:41 --> Loader Class Initialized
INFO - 2021-12-20 10:14:41 --> Helper loaded: url_helper
INFO - 2021-12-20 10:14:41 --> Helper loaded: file_helper
INFO - 2021-12-20 10:14:41 --> Helper loaded: form_helper
INFO - 2021-12-20 10:14:41 --> Helper loaded: my_helper
INFO - 2021-12-20 10:14:41 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:14:41 --> Controller Class Initialized
INFO - 2021-12-20 10:14:42 --> Helper loaded: cookie_helper
INFO - 2021-12-20 10:14:42 --> Config Class Initialized
INFO - 2021-12-20 10:14:42 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:14:42 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:14:42 --> Utf8 Class Initialized
INFO - 2021-12-20 10:14:42 --> URI Class Initialized
INFO - 2021-12-20 10:14:42 --> Router Class Initialized
INFO - 2021-12-20 10:14:42 --> Output Class Initialized
INFO - 2021-12-20 10:14:42 --> Security Class Initialized
DEBUG - 2021-12-20 10:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:14:42 --> Input Class Initialized
INFO - 2021-12-20 10:14:42 --> Language Class Initialized
INFO - 2021-12-20 10:14:42 --> Language Class Initialized
INFO - 2021-12-20 10:14:42 --> Config Class Initialized
INFO - 2021-12-20 10:14:42 --> Loader Class Initialized
INFO - 2021-12-20 10:14:42 --> Helper loaded: url_helper
INFO - 2021-12-20 10:14:42 --> Helper loaded: file_helper
INFO - 2021-12-20 10:14:42 --> Helper loaded: form_helper
INFO - 2021-12-20 10:14:42 --> Helper loaded: my_helper
INFO - 2021-12-20 10:14:42 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:14:42 --> Controller Class Initialized
DEBUG - 2021-12-20 10:14:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 10:14:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:14:42 --> Final output sent to browser
DEBUG - 2021-12-20 10:14:42 --> Total execution time: 0.0550
INFO - 2021-12-20 10:14:43 --> Config Class Initialized
INFO - 2021-12-20 10:14:43 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:14:43 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:14:43 --> Utf8 Class Initialized
INFO - 2021-12-20 10:14:43 --> URI Class Initialized
INFO - 2021-12-20 10:14:43 --> Router Class Initialized
INFO - 2021-12-20 10:14:43 --> Output Class Initialized
INFO - 2021-12-20 10:14:43 --> Security Class Initialized
DEBUG - 2021-12-20 10:14:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:14:43 --> Input Class Initialized
INFO - 2021-12-20 10:14:43 --> Language Class Initialized
INFO - 2021-12-20 10:14:43 --> Language Class Initialized
INFO - 2021-12-20 10:14:43 --> Config Class Initialized
INFO - 2021-12-20 10:14:43 --> Loader Class Initialized
INFO - 2021-12-20 10:14:43 --> Helper loaded: url_helper
INFO - 2021-12-20 10:14:43 --> Helper loaded: file_helper
INFO - 2021-12-20 10:14:43 --> Helper loaded: form_helper
INFO - 2021-12-20 10:14:43 --> Helper loaded: my_helper
INFO - 2021-12-20 10:14:43 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:14:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:14:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:14:43 --> Controller Class Initialized
DEBUG - 2021-12-20 10:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 10:14:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:14:43 --> Final output sent to browser
DEBUG - 2021-12-20 10:14:43 --> Total execution time: 0.0530
INFO - 2021-12-20 10:14:48 --> Config Class Initialized
INFO - 2021-12-20 10:14:48 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:14:48 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:14:48 --> Utf8 Class Initialized
INFO - 2021-12-20 10:14:48 --> URI Class Initialized
INFO - 2021-12-20 10:14:48 --> Router Class Initialized
INFO - 2021-12-20 10:14:48 --> Output Class Initialized
INFO - 2021-12-20 10:14:48 --> Security Class Initialized
DEBUG - 2021-12-20 10:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:14:48 --> Input Class Initialized
INFO - 2021-12-20 10:14:48 --> Language Class Initialized
INFO - 2021-12-20 10:14:48 --> Language Class Initialized
INFO - 2021-12-20 10:14:48 --> Config Class Initialized
INFO - 2021-12-20 10:14:48 --> Loader Class Initialized
INFO - 2021-12-20 10:14:48 --> Helper loaded: url_helper
INFO - 2021-12-20 10:14:48 --> Helper loaded: file_helper
INFO - 2021-12-20 10:14:48 --> Helper loaded: form_helper
INFO - 2021-12-20 10:14:48 --> Helper loaded: my_helper
INFO - 2021-12-20 10:14:48 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:14:48 --> Controller Class Initialized
INFO - 2021-12-20 10:14:48 --> Helper loaded: cookie_helper
INFO - 2021-12-20 10:14:48 --> Final output sent to browser
DEBUG - 2021-12-20 10:14:48 --> Total execution time: 0.0480
INFO - 2021-12-20 10:14:48 --> Config Class Initialized
INFO - 2021-12-20 10:14:48 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:14:48 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:14:48 --> Utf8 Class Initialized
INFO - 2021-12-20 10:14:48 --> URI Class Initialized
INFO - 2021-12-20 10:14:48 --> Router Class Initialized
INFO - 2021-12-20 10:14:48 --> Output Class Initialized
INFO - 2021-12-20 10:14:48 --> Security Class Initialized
DEBUG - 2021-12-20 10:14:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:14:48 --> Input Class Initialized
INFO - 2021-12-20 10:14:48 --> Language Class Initialized
INFO - 2021-12-20 10:14:48 --> Language Class Initialized
INFO - 2021-12-20 10:14:48 --> Config Class Initialized
INFO - 2021-12-20 10:14:48 --> Loader Class Initialized
INFO - 2021-12-20 10:14:48 --> Helper loaded: url_helper
INFO - 2021-12-20 10:14:48 --> Helper loaded: file_helper
INFO - 2021-12-20 10:14:48 --> Helper loaded: form_helper
INFO - 2021-12-20 10:14:48 --> Helper loaded: my_helper
INFO - 2021-12-20 10:14:48 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:14:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:14:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:14:48 --> Controller Class Initialized
DEBUG - 2021-12-20 10:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 10:14:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:14:48 --> Final output sent to browser
DEBUG - 2021-12-20 10:14:48 --> Total execution time: 0.1350
INFO - 2021-12-20 10:14:54 --> Config Class Initialized
INFO - 2021-12-20 10:14:54 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:14:54 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:14:54 --> Utf8 Class Initialized
INFO - 2021-12-20 10:14:54 --> URI Class Initialized
INFO - 2021-12-20 10:14:54 --> Router Class Initialized
INFO - 2021-12-20 10:14:54 --> Output Class Initialized
INFO - 2021-12-20 10:14:54 --> Security Class Initialized
DEBUG - 2021-12-20 10:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:14:54 --> Input Class Initialized
INFO - 2021-12-20 10:14:54 --> Language Class Initialized
INFO - 2021-12-20 10:14:54 --> Language Class Initialized
INFO - 2021-12-20 10:14:54 --> Config Class Initialized
INFO - 2021-12-20 10:14:54 --> Loader Class Initialized
INFO - 2021-12-20 10:14:54 --> Helper loaded: url_helper
INFO - 2021-12-20 10:14:54 --> Helper loaded: file_helper
INFO - 2021-12-20 10:14:54 --> Helper loaded: form_helper
INFO - 2021-12-20 10:14:54 --> Helper loaded: my_helper
INFO - 2021-12-20 10:14:54 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:14:54 --> Controller Class Initialized
DEBUG - 2021-12-20 10:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-20 10:14:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:14:54 --> Final output sent to browser
DEBUG - 2021-12-20 10:14:54 --> Total execution time: 0.0670
INFO - 2021-12-20 10:15:02 --> Config Class Initialized
INFO - 2021-12-20 10:15:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:02 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:02 --> URI Class Initialized
INFO - 2021-12-20 10:15:02 --> Router Class Initialized
INFO - 2021-12-20 10:15:02 --> Output Class Initialized
INFO - 2021-12-20 10:15:02 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:02 --> Input Class Initialized
INFO - 2021-12-20 10:15:02 --> Language Class Initialized
INFO - 2021-12-20 10:15:02 --> Language Class Initialized
INFO - 2021-12-20 10:15:02 --> Config Class Initialized
INFO - 2021-12-20 10:15:02 --> Loader Class Initialized
INFO - 2021-12-20 10:15:02 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:02 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:02 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:02 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:02 --> Controller Class Initialized
INFO - 2021-12-20 10:15:02 --> Helper loaded: cookie_helper
INFO - 2021-12-20 10:15:02 --> Config Class Initialized
INFO - 2021-12-20 10:15:02 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:02 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:02 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:02 --> URI Class Initialized
INFO - 2021-12-20 10:15:02 --> Router Class Initialized
INFO - 2021-12-20 10:15:02 --> Output Class Initialized
INFO - 2021-12-20 10:15:02 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:02 --> Input Class Initialized
INFO - 2021-12-20 10:15:02 --> Language Class Initialized
INFO - 2021-12-20 10:15:02 --> Language Class Initialized
INFO - 2021-12-20 10:15:02 --> Config Class Initialized
INFO - 2021-12-20 10:15:02 --> Loader Class Initialized
INFO - 2021-12-20 10:15:02 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:02 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:02 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:02 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:02 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:02 --> Controller Class Initialized
DEBUG - 2021-12-20 10:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-20 10:15:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:15:02 --> Final output sent to browser
DEBUG - 2021-12-20 10:15:02 --> Total execution time: 0.0350
INFO - 2021-12-20 10:15:05 --> Config Class Initialized
INFO - 2021-12-20 10:15:05 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:05 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:05 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:05 --> URI Class Initialized
INFO - 2021-12-20 10:15:05 --> Router Class Initialized
INFO - 2021-12-20 10:15:05 --> Output Class Initialized
INFO - 2021-12-20 10:15:05 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:05 --> Input Class Initialized
INFO - 2021-12-20 10:15:05 --> Language Class Initialized
INFO - 2021-12-20 10:15:05 --> Language Class Initialized
INFO - 2021-12-20 10:15:05 --> Config Class Initialized
INFO - 2021-12-20 10:15:05 --> Loader Class Initialized
INFO - 2021-12-20 10:15:05 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:05 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:05 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:05 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:05 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:05 --> Controller Class Initialized
INFO - 2021-12-20 10:15:05 --> Helper loaded: cookie_helper
INFO - 2021-12-20 10:15:05 --> Final output sent to browser
DEBUG - 2021-12-20 10:15:05 --> Total execution time: 0.0480
INFO - 2021-12-20 10:15:05 --> Config Class Initialized
INFO - 2021-12-20 10:15:05 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:05 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:05 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:05 --> URI Class Initialized
INFO - 2021-12-20 10:15:05 --> Router Class Initialized
INFO - 2021-12-20 10:15:05 --> Output Class Initialized
INFO - 2021-12-20 10:15:05 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:05 --> Input Class Initialized
INFO - 2021-12-20 10:15:05 --> Language Class Initialized
INFO - 2021-12-20 10:15:05 --> Language Class Initialized
INFO - 2021-12-20 10:15:05 --> Config Class Initialized
INFO - 2021-12-20 10:15:05 --> Loader Class Initialized
INFO - 2021-12-20 10:15:05 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:05 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:05 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:05 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:05 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:05 --> Controller Class Initialized
DEBUG - 2021-12-20 10:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-20 10:15:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:15:06 --> Final output sent to browser
DEBUG - 2021-12-20 10:15:06 --> Total execution time: 0.1370
INFO - 2021-12-20 10:15:07 --> Config Class Initialized
INFO - 2021-12-20 10:15:07 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:07 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:07 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:07 --> URI Class Initialized
INFO - 2021-12-20 10:15:07 --> Router Class Initialized
INFO - 2021-12-20 10:15:07 --> Output Class Initialized
INFO - 2021-12-20 10:15:07 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:07 --> Input Class Initialized
INFO - 2021-12-20 10:15:07 --> Language Class Initialized
INFO - 2021-12-20 10:15:07 --> Language Class Initialized
INFO - 2021-12-20 10:15:07 --> Config Class Initialized
INFO - 2021-12-20 10:15:07 --> Loader Class Initialized
INFO - 2021-12-20 10:15:07 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:07 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:07 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:07 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:07 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:07 --> Controller Class Initialized
DEBUG - 2021-12-20 10:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-20 10:15:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:15:07 --> Final output sent to browser
DEBUG - 2021-12-20 10:15:07 --> Total execution time: 0.0510
INFO - 2021-12-20 10:15:08 --> Config Class Initialized
INFO - 2021-12-20 10:15:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:08 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:08 --> URI Class Initialized
INFO - 2021-12-20 10:15:08 --> Router Class Initialized
INFO - 2021-12-20 10:15:08 --> Output Class Initialized
INFO - 2021-12-20 10:15:08 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:08 --> Input Class Initialized
INFO - 2021-12-20 10:15:08 --> Language Class Initialized
INFO - 2021-12-20 10:15:08 --> Language Class Initialized
INFO - 2021-12-20 10:15:08 --> Config Class Initialized
INFO - 2021-12-20 10:15:08 --> Loader Class Initialized
INFO - 2021-12-20 10:15:08 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:08 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:08 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:08 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:08 --> Controller Class Initialized
DEBUG - 2021-12-20 10:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-12-20 10:15:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-20 10:15:08 --> Final output sent to browser
DEBUG - 2021-12-20 10:15:08 --> Total execution time: 0.0630
INFO - 2021-12-20 10:15:08 --> Config Class Initialized
INFO - 2021-12-20 10:15:08 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:08 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:08 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:08 --> URI Class Initialized
INFO - 2021-12-20 10:15:08 --> Router Class Initialized
INFO - 2021-12-20 10:15:08 --> Output Class Initialized
INFO - 2021-12-20 10:15:08 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:08 --> Input Class Initialized
INFO - 2021-12-20 10:15:08 --> Language Class Initialized
INFO - 2021-12-20 10:15:08 --> Language Class Initialized
INFO - 2021-12-20 10:15:08 --> Config Class Initialized
INFO - 2021-12-20 10:15:08 --> Loader Class Initialized
INFO - 2021-12-20 10:15:08 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:08 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:08 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:08 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:08 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:08 --> Controller Class Initialized
INFO - 2021-12-20 10:15:10 --> Config Class Initialized
INFO - 2021-12-20 10:15:10 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:10 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:10 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:10 --> URI Class Initialized
INFO - 2021-12-20 10:15:10 --> Router Class Initialized
INFO - 2021-12-20 10:15:10 --> Output Class Initialized
INFO - 2021-12-20 10:15:10 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:10 --> Input Class Initialized
INFO - 2021-12-20 10:15:10 --> Language Class Initialized
INFO - 2021-12-20 10:15:10 --> Language Class Initialized
INFO - 2021-12-20 10:15:10 --> Config Class Initialized
INFO - 2021-12-20 10:15:10 --> Loader Class Initialized
INFO - 2021-12-20 10:15:10 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:10 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:10 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:10 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:10 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:10 --> Controller Class Initialized
INFO - 2021-12-20 10:15:10 --> Final output sent to browser
DEBUG - 2021-12-20 10:15:10 --> Total execution time: 0.0450
INFO - 2021-12-20 10:15:12 --> Config Class Initialized
INFO - 2021-12-20 10:15:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:12 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:12 --> URI Class Initialized
INFO - 2021-12-20 10:15:12 --> Router Class Initialized
INFO - 2021-12-20 10:15:12 --> Output Class Initialized
INFO - 2021-12-20 10:15:12 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:12 --> Input Class Initialized
INFO - 2021-12-20 10:15:12 --> Language Class Initialized
INFO - 2021-12-20 10:15:12 --> Language Class Initialized
INFO - 2021-12-20 10:15:12 --> Config Class Initialized
INFO - 2021-12-20 10:15:12 --> Loader Class Initialized
INFO - 2021-12-20 10:15:12 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:12 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:12 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:12 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:12 --> Controller Class Initialized
INFO - 2021-12-20 10:15:12 --> Final output sent to browser
DEBUG - 2021-12-20 10:15:12 --> Total execution time: 0.0520
INFO - 2021-12-20 10:15:12 --> Config Class Initialized
INFO - 2021-12-20 10:15:12 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:12 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:12 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:12 --> URI Class Initialized
INFO - 2021-12-20 10:15:12 --> Router Class Initialized
INFO - 2021-12-20 10:15:12 --> Output Class Initialized
INFO - 2021-12-20 10:15:12 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:12 --> Input Class Initialized
INFO - 2021-12-20 10:15:12 --> Language Class Initialized
INFO - 2021-12-20 10:15:12 --> Language Class Initialized
INFO - 2021-12-20 10:15:12 --> Config Class Initialized
INFO - 2021-12-20 10:15:12 --> Loader Class Initialized
INFO - 2021-12-20 10:15:12 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:12 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:12 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:12 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:12 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:12 --> Controller Class Initialized
INFO - 2021-12-20 10:15:16 --> Config Class Initialized
INFO - 2021-12-20 10:15:16 --> Hooks Class Initialized
DEBUG - 2021-12-20 10:15:16 --> UTF-8 Support Enabled
INFO - 2021-12-20 10:15:16 --> Utf8 Class Initialized
INFO - 2021-12-20 10:15:16 --> URI Class Initialized
INFO - 2021-12-20 10:15:16 --> Router Class Initialized
INFO - 2021-12-20 10:15:16 --> Output Class Initialized
INFO - 2021-12-20 10:15:16 --> Security Class Initialized
DEBUG - 2021-12-20 10:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-20 10:15:16 --> Input Class Initialized
INFO - 2021-12-20 10:15:16 --> Language Class Initialized
INFO - 2021-12-20 10:15:16 --> Language Class Initialized
INFO - 2021-12-20 10:15:16 --> Config Class Initialized
INFO - 2021-12-20 10:15:16 --> Loader Class Initialized
INFO - 2021-12-20 10:15:16 --> Helper loaded: url_helper
INFO - 2021-12-20 10:15:16 --> Helper loaded: file_helper
INFO - 2021-12-20 10:15:16 --> Helper loaded: form_helper
INFO - 2021-12-20 10:15:16 --> Helper loaded: my_helper
INFO - 2021-12-20 10:15:16 --> Database Driver Class Initialized
DEBUG - 2021-12-20 10:15:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-20 10:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-20 10:15:16 --> Controller Class Initialized
