<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-06-18 03:04:19 --> Config Class Initialized
INFO - 2022-06-18 03:04:19 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:04:19 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:04:19 --> Utf8 Class Initialized
INFO - 2022-06-18 03:04:19 --> URI Class Initialized
DEBUG - 2022-06-18 03:04:19 --> No URI present. Default controller set.
INFO - 2022-06-18 03:04:19 --> Router Class Initialized
INFO - 2022-06-18 03:04:19 --> Output Class Initialized
INFO - 2022-06-18 03:04:19 --> Security Class Initialized
DEBUG - 2022-06-18 03:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:04:19 --> Input Class Initialized
INFO - 2022-06-18 03:04:19 --> Language Class Initialized
INFO - 2022-06-18 03:04:19 --> Language Class Initialized
INFO - 2022-06-18 03:04:19 --> Config Class Initialized
INFO - 2022-06-18 03:04:19 --> Loader Class Initialized
INFO - 2022-06-18 03:04:19 --> Helper loaded: url_helper
INFO - 2022-06-18 03:04:19 --> Helper loaded: file_helper
INFO - 2022-06-18 03:04:19 --> Helper loaded: form_helper
INFO - 2022-06-18 03:04:19 --> Helper loaded: my_helper
INFO - 2022-06-18 03:04:19 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:04:19 --> Controller Class Initialized
INFO - 2022-06-18 03:04:19 --> Config Class Initialized
INFO - 2022-06-18 03:04:19 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:04:19 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:04:19 --> Utf8 Class Initialized
INFO - 2022-06-18 03:04:19 --> URI Class Initialized
INFO - 2022-06-18 03:04:19 --> Router Class Initialized
INFO - 2022-06-18 03:04:19 --> Output Class Initialized
INFO - 2022-06-18 03:04:19 --> Security Class Initialized
DEBUG - 2022-06-18 03:04:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:04:19 --> Input Class Initialized
INFO - 2022-06-18 03:04:19 --> Language Class Initialized
INFO - 2022-06-18 03:04:19 --> Language Class Initialized
INFO - 2022-06-18 03:04:19 --> Config Class Initialized
INFO - 2022-06-18 03:04:19 --> Loader Class Initialized
INFO - 2022-06-18 03:04:19 --> Helper loaded: url_helper
INFO - 2022-06-18 03:04:19 --> Helper loaded: file_helper
INFO - 2022-06-18 03:04:19 --> Helper loaded: form_helper
INFO - 2022-06-18 03:04:19 --> Helper loaded: my_helper
INFO - 2022-06-18 03:04:19 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:04:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:04:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:04:19 --> Controller Class Initialized
DEBUG - 2022-06-18 03:04:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 03:04:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:04:19 --> Final output sent to browser
DEBUG - 2022-06-18 03:04:19 --> Total execution time: 0.0493
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:04:53 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:04:53 --> Utf8 Class Initialized
INFO - 2022-06-18 03:04:53 --> URI Class Initialized
DEBUG - 2022-06-18 03:04:53 --> No URI present. Default controller set.
INFO - 2022-06-18 03:04:53 --> Router Class Initialized
INFO - 2022-06-18 03:04:53 --> Output Class Initialized
INFO - 2022-06-18 03:04:53 --> Security Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:04:53 --> Input Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Loader Class Initialized
INFO - 2022-06-18 03:04:53 --> Helper loaded: url_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: file_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: form_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: my_helper
INFO - 2022-06-18 03:04:53 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:04:53 --> Controller Class Initialized
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:04:53 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:04:53 --> Utf8 Class Initialized
INFO - 2022-06-18 03:04:53 --> URI Class Initialized
INFO - 2022-06-18 03:04:53 --> Router Class Initialized
INFO - 2022-06-18 03:04:53 --> Output Class Initialized
INFO - 2022-06-18 03:04:53 --> Security Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:04:53 --> Input Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Loader Class Initialized
INFO - 2022-06-18 03:04:53 --> Helper loaded: url_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: file_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: form_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: my_helper
INFO - 2022-06-18 03:04:53 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:04:53 --> Controller Class Initialized
DEBUG - 2022-06-18 03:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 03:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:04:53 --> Final output sent to browser
DEBUG - 2022-06-18 03:04:53 --> Total execution time: 0.0498
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:04:53 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:04:53 --> Utf8 Class Initialized
INFO - 2022-06-18 03:04:53 --> URI Class Initialized
DEBUG - 2022-06-18 03:04:53 --> No URI present. Default controller set.
INFO - 2022-06-18 03:04:53 --> Router Class Initialized
INFO - 2022-06-18 03:04:53 --> Output Class Initialized
INFO - 2022-06-18 03:04:53 --> Security Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:04:53 --> Input Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Loader Class Initialized
INFO - 2022-06-18 03:04:53 --> Helper loaded: url_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: file_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: form_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: my_helper
INFO - 2022-06-18 03:04:53 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:04:53 --> Controller Class Initialized
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:04:53 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:04:53 --> Utf8 Class Initialized
INFO - 2022-06-18 03:04:53 --> URI Class Initialized
INFO - 2022-06-18 03:04:53 --> Router Class Initialized
INFO - 2022-06-18 03:04:53 --> Output Class Initialized
INFO - 2022-06-18 03:04:53 --> Security Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:04:53 --> Input Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Language Class Initialized
INFO - 2022-06-18 03:04:53 --> Config Class Initialized
INFO - 2022-06-18 03:04:53 --> Loader Class Initialized
INFO - 2022-06-18 03:04:53 --> Helper loaded: url_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: file_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: form_helper
INFO - 2022-06-18 03:04:53 --> Helper loaded: my_helper
INFO - 2022-06-18 03:04:53 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:04:53 --> Controller Class Initialized
DEBUG - 2022-06-18 03:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 03:04:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:04:53 --> Final output sent to browser
DEBUG - 2022-06-18 03:04:53 --> Total execution time: 0.0384
INFO - 2022-06-18 03:05:01 --> Config Class Initialized
INFO - 2022-06-18 03:05:01 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:05:01 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:05:01 --> Utf8 Class Initialized
INFO - 2022-06-18 03:05:01 --> URI Class Initialized
INFO - 2022-06-18 03:05:01 --> Router Class Initialized
INFO - 2022-06-18 03:05:01 --> Output Class Initialized
INFO - 2022-06-18 03:05:01 --> Security Class Initialized
DEBUG - 2022-06-18 03:05:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:05:01 --> Input Class Initialized
INFO - 2022-06-18 03:05:01 --> Language Class Initialized
INFO - 2022-06-18 03:05:01 --> Language Class Initialized
INFO - 2022-06-18 03:05:01 --> Config Class Initialized
INFO - 2022-06-18 03:05:01 --> Loader Class Initialized
INFO - 2022-06-18 03:05:01 --> Helper loaded: url_helper
INFO - 2022-06-18 03:05:01 --> Helper loaded: file_helper
INFO - 2022-06-18 03:05:01 --> Helper loaded: form_helper
INFO - 2022-06-18 03:05:01 --> Helper loaded: my_helper
INFO - 2022-06-18 03:05:01 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:05:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:05:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:05:01 --> Controller Class Initialized
INFO - 2022-06-18 03:05:01 --> Helper loaded: cookie_helper
INFO - 2022-06-18 03:05:01 --> Final output sent to browser
DEBUG - 2022-06-18 03:05:01 --> Total execution time: 0.0483
INFO - 2022-06-18 03:05:05 --> Config Class Initialized
INFO - 2022-06-18 03:05:05 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:05:05 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:05:05 --> Utf8 Class Initialized
INFO - 2022-06-18 03:05:05 --> URI Class Initialized
INFO - 2022-06-18 03:05:05 --> Router Class Initialized
INFO - 2022-06-18 03:05:05 --> Output Class Initialized
INFO - 2022-06-18 03:05:05 --> Security Class Initialized
DEBUG - 2022-06-18 03:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:05:05 --> Input Class Initialized
INFO - 2022-06-18 03:05:05 --> Language Class Initialized
INFO - 2022-06-18 03:05:05 --> Language Class Initialized
INFO - 2022-06-18 03:05:05 --> Config Class Initialized
INFO - 2022-06-18 03:05:05 --> Loader Class Initialized
INFO - 2022-06-18 03:05:05 --> Helper loaded: url_helper
INFO - 2022-06-18 03:05:05 --> Helper loaded: file_helper
INFO - 2022-06-18 03:05:05 --> Helper loaded: form_helper
INFO - 2022-06-18 03:05:05 --> Helper loaded: my_helper
INFO - 2022-06-18 03:05:05 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:05:05 --> Controller Class Initialized
DEBUG - 2022-06-18 03:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-18 03:05:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:05:05 --> Final output sent to browser
DEBUG - 2022-06-18 03:05:05 --> Total execution time: 0.1170
INFO - 2022-06-18 03:05:29 --> Config Class Initialized
INFO - 2022-06-18 03:05:29 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:05:29 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:05:29 --> Utf8 Class Initialized
INFO - 2022-06-18 03:05:29 --> URI Class Initialized
INFO - 2022-06-18 03:05:29 --> Router Class Initialized
INFO - 2022-06-18 03:05:29 --> Output Class Initialized
INFO - 2022-06-18 03:05:29 --> Security Class Initialized
DEBUG - 2022-06-18 03:05:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:05:29 --> Input Class Initialized
INFO - 2022-06-18 03:05:29 --> Language Class Initialized
INFO - 2022-06-18 03:05:29 --> Language Class Initialized
INFO - 2022-06-18 03:05:29 --> Config Class Initialized
INFO - 2022-06-18 03:05:29 --> Loader Class Initialized
INFO - 2022-06-18 03:05:29 --> Helper loaded: url_helper
INFO - 2022-06-18 03:05:29 --> Helper loaded: file_helper
INFO - 2022-06-18 03:05:29 --> Helper loaded: form_helper
INFO - 2022-06-18 03:05:29 --> Helper loaded: my_helper
INFO - 2022-06-18 03:05:29 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:05:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:05:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:05:29 --> Controller Class Initialized
INFO - 2022-06-18 03:05:29 --> Helper loaded: cookie_helper
INFO - 2022-06-18 03:05:29 --> Final output sent to browser
DEBUG - 2022-06-18 03:05:29 --> Total execution time: 0.0428
INFO - 2022-06-18 03:05:33 --> Config Class Initialized
INFO - 2022-06-18 03:05:33 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:05:33 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:05:33 --> Utf8 Class Initialized
INFO - 2022-06-18 03:05:33 --> URI Class Initialized
INFO - 2022-06-18 03:05:33 --> Router Class Initialized
INFO - 2022-06-18 03:05:33 --> Output Class Initialized
INFO - 2022-06-18 03:05:33 --> Security Class Initialized
DEBUG - 2022-06-18 03:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:05:33 --> Input Class Initialized
INFO - 2022-06-18 03:05:33 --> Language Class Initialized
INFO - 2022-06-18 03:05:33 --> Language Class Initialized
INFO - 2022-06-18 03:05:33 --> Config Class Initialized
INFO - 2022-06-18 03:05:33 --> Loader Class Initialized
INFO - 2022-06-18 03:05:33 --> Helper loaded: url_helper
INFO - 2022-06-18 03:05:33 --> Helper loaded: file_helper
INFO - 2022-06-18 03:05:33 --> Helper loaded: form_helper
INFO - 2022-06-18 03:05:33 --> Helper loaded: my_helper
INFO - 2022-06-18 03:05:33 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:05:33 --> Controller Class Initialized
DEBUG - 2022-06-18 03:05:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-18 03:05:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:05:33 --> Final output sent to browser
DEBUG - 2022-06-18 03:05:33 --> Total execution time: 0.1013
INFO - 2022-06-18 03:05:37 --> Config Class Initialized
INFO - 2022-06-18 03:05:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:05:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:05:37 --> Utf8 Class Initialized
INFO - 2022-06-18 03:05:37 --> URI Class Initialized
INFO - 2022-06-18 03:05:37 --> Router Class Initialized
INFO - 2022-06-18 03:05:37 --> Output Class Initialized
INFO - 2022-06-18 03:05:37 --> Security Class Initialized
DEBUG - 2022-06-18 03:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:05:37 --> Input Class Initialized
INFO - 2022-06-18 03:05:37 --> Language Class Initialized
INFO - 2022-06-18 03:05:37 --> Language Class Initialized
INFO - 2022-06-18 03:05:37 --> Config Class Initialized
INFO - 2022-06-18 03:05:37 --> Loader Class Initialized
INFO - 2022-06-18 03:05:37 --> Helper loaded: url_helper
INFO - 2022-06-18 03:05:37 --> Helper loaded: file_helper
INFO - 2022-06-18 03:05:37 --> Helper loaded: form_helper
INFO - 2022-06-18 03:05:37 --> Helper loaded: my_helper
INFO - 2022-06-18 03:05:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:05:37 --> Controller Class Initialized
DEBUG - 2022-06-18 03:05:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-18 03:05:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:05:37 --> Final output sent to browser
DEBUG - 2022-06-18 03:05:37 --> Total execution time: 0.0531
INFO - 2022-06-18 03:05:44 --> Config Class Initialized
INFO - 2022-06-18 03:05:44 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:05:44 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:05:44 --> Utf8 Class Initialized
INFO - 2022-06-18 03:05:44 --> URI Class Initialized
INFO - 2022-06-18 03:05:44 --> Router Class Initialized
INFO - 2022-06-18 03:05:44 --> Output Class Initialized
INFO - 2022-06-18 03:05:44 --> Security Class Initialized
DEBUG - 2022-06-18 03:05:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:05:44 --> Input Class Initialized
INFO - 2022-06-18 03:05:44 --> Language Class Initialized
INFO - 2022-06-18 03:05:44 --> Language Class Initialized
INFO - 2022-06-18 03:05:44 --> Config Class Initialized
INFO - 2022-06-18 03:05:44 --> Loader Class Initialized
INFO - 2022-06-18 03:05:44 --> Helper loaded: url_helper
INFO - 2022-06-18 03:05:44 --> Helper loaded: file_helper
INFO - 2022-06-18 03:05:44 --> Helper loaded: form_helper
INFO - 2022-06-18 03:05:44 --> Helper loaded: my_helper
INFO - 2022-06-18 03:05:44 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:05:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:05:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:05:44 --> Controller Class Initialized
DEBUG - 2022-06-18 03:05:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 03:05:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:05:44 --> Final output sent to browser
DEBUG - 2022-06-18 03:05:44 --> Total execution time: 0.0571
INFO - 2022-06-18 03:05:45 --> Config Class Initialized
INFO - 2022-06-18 03:05:45 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:05:45 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:05:45 --> Utf8 Class Initialized
INFO - 2022-06-18 03:05:45 --> URI Class Initialized
INFO - 2022-06-18 03:05:45 --> Router Class Initialized
INFO - 2022-06-18 03:05:45 --> Output Class Initialized
INFO - 2022-06-18 03:05:45 --> Security Class Initialized
DEBUG - 2022-06-18 03:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:05:45 --> Input Class Initialized
INFO - 2022-06-18 03:05:45 --> Language Class Initialized
INFO - 2022-06-18 03:05:45 --> Language Class Initialized
INFO - 2022-06-18 03:05:45 --> Config Class Initialized
INFO - 2022-06-18 03:05:45 --> Loader Class Initialized
INFO - 2022-06-18 03:05:45 --> Helper loaded: url_helper
INFO - 2022-06-18 03:05:45 --> Helper loaded: file_helper
INFO - 2022-06-18 03:05:45 --> Helper loaded: form_helper
INFO - 2022-06-18 03:05:45 --> Helper loaded: my_helper
INFO - 2022-06-18 03:05:45 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:05:45 --> Controller Class Initialized
INFO - 2022-06-18 03:06:03 --> Config Class Initialized
INFO - 2022-06-18 03:06:03 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:06:03 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:06:03 --> Utf8 Class Initialized
INFO - 2022-06-18 03:06:03 --> URI Class Initialized
INFO - 2022-06-18 03:06:03 --> Router Class Initialized
INFO - 2022-06-18 03:06:03 --> Output Class Initialized
INFO - 2022-06-18 03:06:03 --> Security Class Initialized
DEBUG - 2022-06-18 03:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:06:03 --> Input Class Initialized
INFO - 2022-06-18 03:06:03 --> Language Class Initialized
INFO - 2022-06-18 03:06:03 --> Language Class Initialized
INFO - 2022-06-18 03:06:03 --> Config Class Initialized
INFO - 2022-06-18 03:06:03 --> Loader Class Initialized
INFO - 2022-06-18 03:06:03 --> Helper loaded: url_helper
INFO - 2022-06-18 03:06:03 --> Helper loaded: file_helper
INFO - 2022-06-18 03:06:03 --> Helper loaded: form_helper
INFO - 2022-06-18 03:06:03 --> Helper loaded: my_helper
INFO - 2022-06-18 03:06:03 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:06:03 --> Controller Class Initialized
INFO - 2022-06-18 03:06:03 --> Final output sent to browser
DEBUG - 2022-06-18 03:06:03 --> Total execution time: 0.0388
INFO - 2022-06-18 03:06:19 --> Config Class Initialized
INFO - 2022-06-18 03:06:19 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:06:19 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:06:19 --> Utf8 Class Initialized
INFO - 2022-06-18 03:06:19 --> URI Class Initialized
INFO - 2022-06-18 03:06:19 --> Router Class Initialized
INFO - 2022-06-18 03:06:19 --> Output Class Initialized
INFO - 2022-06-18 03:06:19 --> Security Class Initialized
DEBUG - 2022-06-18 03:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:06:19 --> Input Class Initialized
INFO - 2022-06-18 03:06:19 --> Language Class Initialized
INFO - 2022-06-18 03:06:19 --> Language Class Initialized
INFO - 2022-06-18 03:06:19 --> Config Class Initialized
INFO - 2022-06-18 03:06:19 --> Loader Class Initialized
INFO - 2022-06-18 03:06:19 --> Helper loaded: url_helper
INFO - 2022-06-18 03:06:19 --> Helper loaded: file_helper
INFO - 2022-06-18 03:06:19 --> Helper loaded: form_helper
INFO - 2022-06-18 03:06:19 --> Helper loaded: my_helper
INFO - 2022-06-18 03:06:19 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:06:19 --> Controller Class Initialized
INFO - 2022-06-18 03:06:19 --> Final output sent to browser
DEBUG - 2022-06-18 03:06:19 --> Total execution time: 0.0483
INFO - 2022-06-18 03:06:19 --> Config Class Initialized
INFO - 2022-06-18 03:06:19 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:06:19 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:06:19 --> Utf8 Class Initialized
INFO - 2022-06-18 03:06:19 --> URI Class Initialized
INFO - 2022-06-18 03:06:19 --> Router Class Initialized
INFO - 2022-06-18 03:06:19 --> Output Class Initialized
INFO - 2022-06-18 03:06:19 --> Security Class Initialized
DEBUG - 2022-06-18 03:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:06:19 --> Input Class Initialized
INFO - 2022-06-18 03:06:19 --> Language Class Initialized
INFO - 2022-06-18 03:06:19 --> Language Class Initialized
INFO - 2022-06-18 03:06:19 --> Config Class Initialized
INFO - 2022-06-18 03:06:19 --> Loader Class Initialized
INFO - 2022-06-18 03:06:19 --> Helper loaded: url_helper
INFO - 2022-06-18 03:06:19 --> Helper loaded: file_helper
INFO - 2022-06-18 03:06:19 --> Helper loaded: form_helper
INFO - 2022-06-18 03:06:19 --> Helper loaded: my_helper
INFO - 2022-06-18 03:06:19 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:06:19 --> Controller Class Initialized
INFO - 2022-06-18 03:06:24 --> Config Class Initialized
INFO - 2022-06-18 03:06:24 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:06:24 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:06:24 --> Utf8 Class Initialized
INFO - 2022-06-18 03:06:24 --> URI Class Initialized
INFO - 2022-06-18 03:06:24 --> Router Class Initialized
INFO - 2022-06-18 03:06:24 --> Output Class Initialized
INFO - 2022-06-18 03:06:24 --> Security Class Initialized
DEBUG - 2022-06-18 03:06:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:06:24 --> Input Class Initialized
INFO - 2022-06-18 03:06:24 --> Language Class Initialized
INFO - 2022-06-18 03:06:24 --> Language Class Initialized
INFO - 2022-06-18 03:06:24 --> Config Class Initialized
INFO - 2022-06-18 03:06:24 --> Loader Class Initialized
INFO - 2022-06-18 03:06:24 --> Helper loaded: url_helper
INFO - 2022-06-18 03:06:24 --> Helper loaded: file_helper
INFO - 2022-06-18 03:06:24 --> Helper loaded: form_helper
INFO - 2022-06-18 03:06:24 --> Helper loaded: my_helper
INFO - 2022-06-18 03:06:24 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:06:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:06:24 --> Controller Class Initialized
INFO - 2022-06-18 03:06:24 --> Final output sent to browser
DEBUG - 2022-06-18 03:06:24 --> Total execution time: 0.0461
INFO - 2022-06-18 03:07:15 --> Config Class Initialized
INFO - 2022-06-18 03:07:15 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:15 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:15 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:15 --> URI Class Initialized
INFO - 2022-06-18 03:07:15 --> Router Class Initialized
INFO - 2022-06-18 03:07:15 --> Output Class Initialized
INFO - 2022-06-18 03:07:15 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:15 --> Input Class Initialized
INFO - 2022-06-18 03:07:15 --> Language Class Initialized
INFO - 2022-06-18 03:07:15 --> Language Class Initialized
INFO - 2022-06-18 03:07:15 --> Config Class Initialized
INFO - 2022-06-18 03:07:15 --> Loader Class Initialized
INFO - 2022-06-18 03:07:15 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:15 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:15 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:15 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:15 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:15 --> Controller Class Initialized
DEBUG - 2022-06-18 03:07:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-18 03:07:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:07:15 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:15 --> Total execution time: 0.0433
INFO - 2022-06-18 03:07:21 --> Config Class Initialized
INFO - 2022-06-18 03:07:21 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:21 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:21 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:21 --> URI Class Initialized
INFO - 2022-06-18 03:07:21 --> Router Class Initialized
INFO - 2022-06-18 03:07:21 --> Output Class Initialized
INFO - 2022-06-18 03:07:21 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:21 --> Input Class Initialized
INFO - 2022-06-18 03:07:21 --> Language Class Initialized
INFO - 2022-06-18 03:07:21 --> Language Class Initialized
INFO - 2022-06-18 03:07:21 --> Config Class Initialized
INFO - 2022-06-18 03:07:21 --> Loader Class Initialized
INFO - 2022-06-18 03:07:21 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:21 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:21 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:21 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:21 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:21 --> Controller Class Initialized
DEBUG - 2022-06-18 03:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 03:07:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:07:21 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:21 --> Total execution time: 0.0490
INFO - 2022-06-18 03:07:25 --> Config Class Initialized
INFO - 2022-06-18 03:07:25 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:25 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:25 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:25 --> URI Class Initialized
INFO - 2022-06-18 03:07:25 --> Router Class Initialized
INFO - 2022-06-18 03:07:25 --> Output Class Initialized
INFO - 2022-06-18 03:07:25 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:25 --> Input Class Initialized
INFO - 2022-06-18 03:07:25 --> Language Class Initialized
INFO - 2022-06-18 03:07:25 --> Language Class Initialized
INFO - 2022-06-18 03:07:25 --> Config Class Initialized
INFO - 2022-06-18 03:07:25 --> Loader Class Initialized
INFO - 2022-06-18 03:07:25 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:25 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:25 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:25 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:25 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:25 --> Controller Class Initialized
INFO - 2022-06-18 03:07:25 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:25 --> Total execution time: 0.0475
INFO - 2022-06-18 03:07:44 --> Config Class Initialized
INFO - 2022-06-18 03:07:44 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:44 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:44 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:44 --> URI Class Initialized
INFO - 2022-06-18 03:07:44 --> Router Class Initialized
INFO - 2022-06-18 03:07:44 --> Output Class Initialized
INFO - 2022-06-18 03:07:44 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:44 --> Input Class Initialized
INFO - 2022-06-18 03:07:44 --> Language Class Initialized
INFO - 2022-06-18 03:07:44 --> Language Class Initialized
INFO - 2022-06-18 03:07:44 --> Config Class Initialized
INFO - 2022-06-18 03:07:44 --> Loader Class Initialized
INFO - 2022-06-18 03:07:44 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:44 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:44 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:44 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:44 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:44 --> Controller Class Initialized
INFO - 2022-06-18 03:07:44 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:44 --> Total execution time: 0.0540
INFO - 2022-06-18 03:07:44 --> Config Class Initialized
INFO - 2022-06-18 03:07:44 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:44 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:44 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:44 --> URI Class Initialized
INFO - 2022-06-18 03:07:44 --> Router Class Initialized
INFO - 2022-06-18 03:07:44 --> Output Class Initialized
INFO - 2022-06-18 03:07:44 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:44 --> Input Class Initialized
INFO - 2022-06-18 03:07:44 --> Language Class Initialized
INFO - 2022-06-18 03:07:44 --> Language Class Initialized
INFO - 2022-06-18 03:07:44 --> Config Class Initialized
INFO - 2022-06-18 03:07:44 --> Loader Class Initialized
INFO - 2022-06-18 03:07:44 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:44 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:44 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:44 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:44 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:44 --> Controller Class Initialized
DEBUG - 2022-06-18 03:07:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 03:07:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:07:44 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:44 --> Total execution time: 0.0510
INFO - 2022-06-18 03:07:48 --> Config Class Initialized
INFO - 2022-06-18 03:07:48 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:48 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:48 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:48 --> URI Class Initialized
INFO - 2022-06-18 03:07:48 --> Router Class Initialized
INFO - 2022-06-18 03:07:48 --> Output Class Initialized
INFO - 2022-06-18 03:07:48 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:48 --> Input Class Initialized
INFO - 2022-06-18 03:07:48 --> Language Class Initialized
INFO - 2022-06-18 03:07:48 --> Language Class Initialized
INFO - 2022-06-18 03:07:48 --> Config Class Initialized
INFO - 2022-06-18 03:07:48 --> Loader Class Initialized
INFO - 2022-06-18 03:07:48 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:48 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:48 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:48 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:48 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:48 --> Controller Class Initialized
INFO - 2022-06-18 03:07:48 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:48 --> Total execution time: 0.0490
INFO - 2022-06-18 03:07:55 --> Config Class Initialized
INFO - 2022-06-18 03:07:55 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:55 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:55 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:55 --> URI Class Initialized
INFO - 2022-06-18 03:07:55 --> Router Class Initialized
INFO - 2022-06-18 03:07:55 --> Output Class Initialized
INFO - 2022-06-18 03:07:55 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:55 --> Input Class Initialized
INFO - 2022-06-18 03:07:55 --> Language Class Initialized
INFO - 2022-06-18 03:07:55 --> Language Class Initialized
INFO - 2022-06-18 03:07:55 --> Config Class Initialized
INFO - 2022-06-18 03:07:55 --> Loader Class Initialized
INFO - 2022-06-18 03:07:55 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:55 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:55 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:55 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:55 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:55 --> Controller Class Initialized
INFO - 2022-06-18 03:07:55 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:55 --> Total execution time: 0.0391
INFO - 2022-06-18 03:07:55 --> Config Class Initialized
INFO - 2022-06-18 03:07:55 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:07:55 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:07:55 --> Utf8 Class Initialized
INFO - 2022-06-18 03:07:55 --> URI Class Initialized
INFO - 2022-06-18 03:07:55 --> Router Class Initialized
INFO - 2022-06-18 03:07:55 --> Output Class Initialized
INFO - 2022-06-18 03:07:55 --> Security Class Initialized
DEBUG - 2022-06-18 03:07:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:07:55 --> Input Class Initialized
INFO - 2022-06-18 03:07:55 --> Language Class Initialized
INFO - 2022-06-18 03:07:55 --> Language Class Initialized
INFO - 2022-06-18 03:07:55 --> Config Class Initialized
INFO - 2022-06-18 03:07:55 --> Loader Class Initialized
INFO - 2022-06-18 03:07:55 --> Helper loaded: url_helper
INFO - 2022-06-18 03:07:55 --> Helper loaded: file_helper
INFO - 2022-06-18 03:07:55 --> Helper loaded: form_helper
INFO - 2022-06-18 03:07:55 --> Helper loaded: my_helper
INFO - 2022-06-18 03:07:55 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:07:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:07:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:07:55 --> Controller Class Initialized
DEBUG - 2022-06-18 03:07:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 03:07:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:07:55 --> Final output sent to browser
DEBUG - 2022-06-18 03:07:55 --> Total execution time: 0.0397
INFO - 2022-06-18 03:08:07 --> Config Class Initialized
INFO - 2022-06-18 03:08:07 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:07 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:07 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:07 --> URI Class Initialized
INFO - 2022-06-18 03:08:07 --> Router Class Initialized
INFO - 2022-06-18 03:08:07 --> Output Class Initialized
INFO - 2022-06-18 03:08:07 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:07 --> Input Class Initialized
INFO - 2022-06-18 03:08:07 --> Language Class Initialized
INFO - 2022-06-18 03:08:07 --> Language Class Initialized
INFO - 2022-06-18 03:08:07 --> Config Class Initialized
INFO - 2022-06-18 03:08:07 --> Loader Class Initialized
INFO - 2022-06-18 03:08:07 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:07 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:07 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:07 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:07 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:07 --> Controller Class Initialized
INFO - 2022-06-18 03:08:07 --> Helper loaded: cookie_helper
INFO - 2022-06-18 03:08:07 --> Config Class Initialized
INFO - 2022-06-18 03:08:07 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:07 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:07 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:07 --> URI Class Initialized
INFO - 2022-06-18 03:08:07 --> Router Class Initialized
INFO - 2022-06-18 03:08:07 --> Output Class Initialized
INFO - 2022-06-18 03:08:07 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:07 --> Input Class Initialized
INFO - 2022-06-18 03:08:07 --> Language Class Initialized
INFO - 2022-06-18 03:08:07 --> Language Class Initialized
INFO - 2022-06-18 03:08:07 --> Config Class Initialized
INFO - 2022-06-18 03:08:07 --> Loader Class Initialized
INFO - 2022-06-18 03:08:07 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:07 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:07 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:07 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:07 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:07 --> Controller Class Initialized
DEBUG - 2022-06-18 03:08:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 03:08:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:08:07 --> Final output sent to browser
DEBUG - 2022-06-18 03:08:07 --> Total execution time: 0.0378
INFO - 2022-06-18 03:08:19 --> Config Class Initialized
INFO - 2022-06-18 03:08:19 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:19 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:19 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:19 --> URI Class Initialized
INFO - 2022-06-18 03:08:19 --> Router Class Initialized
INFO - 2022-06-18 03:08:19 --> Output Class Initialized
INFO - 2022-06-18 03:08:19 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:19 --> Input Class Initialized
INFO - 2022-06-18 03:08:19 --> Language Class Initialized
INFO - 2022-06-18 03:08:19 --> Language Class Initialized
INFO - 2022-06-18 03:08:19 --> Config Class Initialized
INFO - 2022-06-18 03:08:19 --> Loader Class Initialized
INFO - 2022-06-18 03:08:19 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:19 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:19 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:19 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:19 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:19 --> Controller Class Initialized
INFO - 2022-06-18 03:08:19 --> Helper loaded: cookie_helper
INFO - 2022-06-18 03:08:19 --> Final output sent to browser
DEBUG - 2022-06-18 03:08:19 --> Total execution time: 0.0534
INFO - 2022-06-18 03:08:29 --> Config Class Initialized
INFO - 2022-06-18 03:08:29 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:29 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:29 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:29 --> URI Class Initialized
INFO - 2022-06-18 03:08:29 --> Router Class Initialized
INFO - 2022-06-18 03:08:29 --> Output Class Initialized
INFO - 2022-06-18 03:08:29 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:29 --> Input Class Initialized
INFO - 2022-06-18 03:08:29 --> Language Class Initialized
INFO - 2022-06-18 03:08:29 --> Language Class Initialized
INFO - 2022-06-18 03:08:29 --> Config Class Initialized
INFO - 2022-06-18 03:08:29 --> Loader Class Initialized
INFO - 2022-06-18 03:08:29 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:29 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:29 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:29 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:29 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:29 --> Controller Class Initialized
DEBUG - 2022-06-18 03:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-18 03:08:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:08:29 --> Final output sent to browser
DEBUG - 2022-06-18 03:08:29 --> Total execution time: 0.0971
INFO - 2022-06-18 03:08:34 --> Config Class Initialized
INFO - 2022-06-18 03:08:34 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:34 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:34 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:34 --> URI Class Initialized
INFO - 2022-06-18 03:08:34 --> Router Class Initialized
INFO - 2022-06-18 03:08:34 --> Output Class Initialized
INFO - 2022-06-18 03:08:34 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:34 --> Input Class Initialized
INFO - 2022-06-18 03:08:34 --> Language Class Initialized
INFO - 2022-06-18 03:08:34 --> Language Class Initialized
INFO - 2022-06-18 03:08:34 --> Config Class Initialized
INFO - 2022-06-18 03:08:34 --> Loader Class Initialized
INFO - 2022-06-18 03:08:34 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:34 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:34 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:34 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:34 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:34 --> Controller Class Initialized
DEBUG - 2022-06-18 03:08:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-18 03:08:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:08:34 --> Final output sent to browser
DEBUG - 2022-06-18 03:08:34 --> Total execution time: 0.0402
INFO - 2022-06-18 03:08:38 --> Config Class Initialized
INFO - 2022-06-18 03:08:38 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:38 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:38 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:38 --> URI Class Initialized
INFO - 2022-06-18 03:08:38 --> Router Class Initialized
INFO - 2022-06-18 03:08:38 --> Output Class Initialized
INFO - 2022-06-18 03:08:38 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:38 --> Input Class Initialized
INFO - 2022-06-18 03:08:38 --> Language Class Initialized
INFO - 2022-06-18 03:08:38 --> Language Class Initialized
INFO - 2022-06-18 03:08:38 --> Config Class Initialized
INFO - 2022-06-18 03:08:38 --> Loader Class Initialized
INFO - 2022-06-18 03:08:38 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:38 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:38 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:38 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:38 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:38 --> Controller Class Initialized
DEBUG - 2022-06-18 03:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 03:08:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:08:38 --> Final output sent to browser
DEBUG - 2022-06-18 03:08:38 --> Total execution time: 0.0460
INFO - 2022-06-18 03:08:38 --> Config Class Initialized
INFO - 2022-06-18 03:08:38 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:38 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:38 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:38 --> URI Class Initialized
INFO - 2022-06-18 03:08:38 --> Router Class Initialized
INFO - 2022-06-18 03:08:38 --> Output Class Initialized
INFO - 2022-06-18 03:08:38 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:38 --> Input Class Initialized
INFO - 2022-06-18 03:08:38 --> Language Class Initialized
INFO - 2022-06-18 03:08:38 --> Language Class Initialized
INFO - 2022-06-18 03:08:38 --> Config Class Initialized
INFO - 2022-06-18 03:08:38 --> Loader Class Initialized
INFO - 2022-06-18 03:08:38 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:38 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:38 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:38 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:38 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:38 --> Controller Class Initialized
INFO - 2022-06-18 03:08:41 --> Config Class Initialized
INFO - 2022-06-18 03:08:41 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:41 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:41 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:41 --> URI Class Initialized
INFO - 2022-06-18 03:08:41 --> Router Class Initialized
INFO - 2022-06-18 03:08:41 --> Output Class Initialized
INFO - 2022-06-18 03:08:41 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:41 --> Input Class Initialized
INFO - 2022-06-18 03:08:41 --> Language Class Initialized
INFO - 2022-06-18 03:08:41 --> Language Class Initialized
INFO - 2022-06-18 03:08:41 --> Config Class Initialized
INFO - 2022-06-18 03:08:41 --> Loader Class Initialized
INFO - 2022-06-18 03:08:41 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:41 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:41 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:41 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:41 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:41 --> Controller Class Initialized
INFO - 2022-06-18 03:08:41 --> Final output sent to browser
DEBUG - 2022-06-18 03:08:41 --> Total execution time: 0.0507
INFO - 2022-06-18 03:08:50 --> Config Class Initialized
INFO - 2022-06-18 03:08:50 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:50 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:50 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:50 --> URI Class Initialized
INFO - 2022-06-18 03:08:50 --> Router Class Initialized
INFO - 2022-06-18 03:08:50 --> Output Class Initialized
INFO - 2022-06-18 03:08:50 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:50 --> Input Class Initialized
INFO - 2022-06-18 03:08:50 --> Language Class Initialized
INFO - 2022-06-18 03:08:50 --> Language Class Initialized
INFO - 2022-06-18 03:08:50 --> Config Class Initialized
INFO - 2022-06-18 03:08:50 --> Loader Class Initialized
INFO - 2022-06-18 03:08:50 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:50 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:50 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:50 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:50 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:50 --> Controller Class Initialized
INFO - 2022-06-18 03:08:50 --> Final output sent to browser
DEBUG - 2022-06-18 03:08:50 --> Total execution time: 0.0518
INFO - 2022-06-18 03:08:50 --> Config Class Initialized
INFO - 2022-06-18 03:08:50 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:08:50 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:08:50 --> Utf8 Class Initialized
INFO - 2022-06-18 03:08:50 --> URI Class Initialized
INFO - 2022-06-18 03:08:50 --> Router Class Initialized
INFO - 2022-06-18 03:08:50 --> Output Class Initialized
INFO - 2022-06-18 03:08:50 --> Security Class Initialized
DEBUG - 2022-06-18 03:08:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:08:50 --> Input Class Initialized
INFO - 2022-06-18 03:08:50 --> Language Class Initialized
INFO - 2022-06-18 03:08:50 --> Language Class Initialized
INFO - 2022-06-18 03:08:50 --> Config Class Initialized
INFO - 2022-06-18 03:08:50 --> Loader Class Initialized
INFO - 2022-06-18 03:08:50 --> Helper loaded: url_helper
INFO - 2022-06-18 03:08:50 --> Helper loaded: file_helper
INFO - 2022-06-18 03:08:50 --> Helper loaded: form_helper
INFO - 2022-06-18 03:08:50 --> Helper loaded: my_helper
INFO - 2022-06-18 03:08:50 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:08:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:08:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:08:50 --> Controller Class Initialized
INFO - 2022-06-18 03:09:02 --> Config Class Initialized
INFO - 2022-06-18 03:09:02 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:09:02 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:09:02 --> Utf8 Class Initialized
INFO - 2022-06-18 03:09:02 --> URI Class Initialized
INFO - 2022-06-18 03:09:02 --> Router Class Initialized
INFO - 2022-06-18 03:09:02 --> Output Class Initialized
INFO - 2022-06-18 03:09:02 --> Security Class Initialized
DEBUG - 2022-06-18 03:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:09:02 --> Input Class Initialized
INFO - 2022-06-18 03:09:02 --> Language Class Initialized
INFO - 2022-06-18 03:09:02 --> Language Class Initialized
INFO - 2022-06-18 03:09:02 --> Config Class Initialized
INFO - 2022-06-18 03:09:02 --> Loader Class Initialized
INFO - 2022-06-18 03:09:02 --> Helper loaded: url_helper
INFO - 2022-06-18 03:09:02 --> Helper loaded: file_helper
INFO - 2022-06-18 03:09:02 --> Helper loaded: form_helper
INFO - 2022-06-18 03:09:02 --> Helper loaded: my_helper
INFO - 2022-06-18 03:09:02 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:09:02 --> Controller Class Initialized
DEBUG - 2022-06-18 03:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-18 03:09:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:09:02 --> Final output sent to browser
DEBUG - 2022-06-18 03:09:02 --> Total execution time: 0.0411
INFO - 2022-06-18 03:09:04 --> Config Class Initialized
INFO - 2022-06-18 03:09:04 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:09:04 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:09:04 --> Utf8 Class Initialized
INFO - 2022-06-18 03:09:04 --> URI Class Initialized
INFO - 2022-06-18 03:09:04 --> Router Class Initialized
INFO - 2022-06-18 03:09:04 --> Output Class Initialized
INFO - 2022-06-18 03:09:04 --> Security Class Initialized
DEBUG - 2022-06-18 03:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:09:04 --> Input Class Initialized
INFO - 2022-06-18 03:09:04 --> Language Class Initialized
INFO - 2022-06-18 03:09:04 --> Language Class Initialized
INFO - 2022-06-18 03:09:04 --> Config Class Initialized
INFO - 2022-06-18 03:09:04 --> Loader Class Initialized
INFO - 2022-06-18 03:09:04 --> Helper loaded: url_helper
INFO - 2022-06-18 03:09:04 --> Helper loaded: file_helper
INFO - 2022-06-18 03:09:04 --> Helper loaded: form_helper
INFO - 2022-06-18 03:09:04 --> Helper loaded: my_helper
INFO - 2022-06-18 03:09:04 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:09:04 --> Controller Class Initialized
DEBUG - 2022-06-18 03:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 03:09:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:09:04 --> Final output sent to browser
DEBUG - 2022-06-18 03:09:04 --> Total execution time: 0.0442
INFO - 2022-06-18 03:09:06 --> Config Class Initialized
INFO - 2022-06-18 03:09:06 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:09:06 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:09:06 --> Utf8 Class Initialized
INFO - 2022-06-18 03:09:06 --> URI Class Initialized
INFO - 2022-06-18 03:09:06 --> Router Class Initialized
INFO - 2022-06-18 03:09:06 --> Output Class Initialized
INFO - 2022-06-18 03:09:06 --> Security Class Initialized
DEBUG - 2022-06-18 03:09:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:09:06 --> Input Class Initialized
INFO - 2022-06-18 03:09:06 --> Language Class Initialized
INFO - 2022-06-18 03:09:06 --> Language Class Initialized
INFO - 2022-06-18 03:09:06 --> Config Class Initialized
INFO - 2022-06-18 03:09:06 --> Loader Class Initialized
INFO - 2022-06-18 03:09:06 --> Helper loaded: url_helper
INFO - 2022-06-18 03:09:06 --> Helper loaded: file_helper
INFO - 2022-06-18 03:09:06 --> Helper loaded: form_helper
INFO - 2022-06-18 03:09:06 --> Helper loaded: my_helper
INFO - 2022-06-18 03:09:06 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:09:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:09:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:09:06 --> Controller Class Initialized
INFO - 2022-06-18 03:09:06 --> Final output sent to browser
DEBUG - 2022-06-18 03:09:06 --> Total execution time: 0.0494
INFO - 2022-06-18 03:13:45 --> Config Class Initialized
INFO - 2022-06-18 03:13:45 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:13:45 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:13:45 --> Utf8 Class Initialized
INFO - 2022-06-18 03:13:45 --> URI Class Initialized
INFO - 2022-06-18 03:13:45 --> Router Class Initialized
INFO - 2022-06-18 03:13:45 --> Output Class Initialized
INFO - 2022-06-18 03:13:45 --> Security Class Initialized
DEBUG - 2022-06-18 03:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:13:45 --> Input Class Initialized
INFO - 2022-06-18 03:13:45 --> Language Class Initialized
INFO - 2022-06-18 03:13:45 --> Language Class Initialized
INFO - 2022-06-18 03:13:45 --> Config Class Initialized
INFO - 2022-06-18 03:13:45 --> Loader Class Initialized
INFO - 2022-06-18 03:13:45 --> Helper loaded: url_helper
INFO - 2022-06-18 03:13:45 --> Helper loaded: file_helper
INFO - 2022-06-18 03:13:45 --> Helper loaded: form_helper
INFO - 2022-06-18 03:13:45 --> Helper loaded: my_helper
INFO - 2022-06-18 03:13:45 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:13:45 --> Controller Class Initialized
INFO - 2022-06-18 03:13:45 --> Final output sent to browser
DEBUG - 2022-06-18 03:13:45 --> Total execution time: 0.0436
INFO - 2022-06-18 03:13:45 --> Config Class Initialized
INFO - 2022-06-18 03:13:45 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:13:45 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:13:45 --> Utf8 Class Initialized
INFO - 2022-06-18 03:13:45 --> URI Class Initialized
INFO - 2022-06-18 03:13:45 --> Router Class Initialized
INFO - 2022-06-18 03:13:45 --> Output Class Initialized
INFO - 2022-06-18 03:13:45 --> Security Class Initialized
DEBUG - 2022-06-18 03:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:13:45 --> Input Class Initialized
INFO - 2022-06-18 03:13:45 --> Language Class Initialized
INFO - 2022-06-18 03:13:45 --> Language Class Initialized
INFO - 2022-06-18 03:13:45 --> Config Class Initialized
INFO - 2022-06-18 03:13:45 --> Loader Class Initialized
INFO - 2022-06-18 03:13:45 --> Helper loaded: url_helper
INFO - 2022-06-18 03:13:45 --> Helper loaded: file_helper
INFO - 2022-06-18 03:13:45 --> Helper loaded: form_helper
INFO - 2022-06-18 03:13:45 --> Helper loaded: my_helper
INFO - 2022-06-18 03:13:45 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:13:45 --> Controller Class Initialized
DEBUG - 2022-06-18 03:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 03:13:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:13:45 --> Final output sent to browser
DEBUG - 2022-06-18 03:13:45 --> Total execution time: 0.0499
INFO - 2022-06-18 03:14:11 --> Config Class Initialized
INFO - 2022-06-18 03:14:11 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:14:11 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:14:11 --> Utf8 Class Initialized
INFO - 2022-06-18 03:14:11 --> URI Class Initialized
INFO - 2022-06-18 03:14:11 --> Router Class Initialized
INFO - 2022-06-18 03:14:11 --> Output Class Initialized
INFO - 2022-06-18 03:14:11 --> Security Class Initialized
DEBUG - 2022-06-18 03:14:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:14:11 --> Input Class Initialized
INFO - 2022-06-18 03:14:11 --> Language Class Initialized
INFO - 2022-06-18 03:14:11 --> Language Class Initialized
INFO - 2022-06-18 03:14:11 --> Config Class Initialized
INFO - 2022-06-18 03:14:11 --> Loader Class Initialized
INFO - 2022-06-18 03:14:11 --> Helper loaded: url_helper
INFO - 2022-06-18 03:14:11 --> Helper loaded: file_helper
INFO - 2022-06-18 03:14:11 --> Helper loaded: form_helper
INFO - 2022-06-18 03:14:11 --> Helper loaded: my_helper
INFO - 2022-06-18 03:14:11 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:14:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:14:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:14:11 --> Controller Class Initialized
DEBUG - 2022-06-18 03:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-18 03:14:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:14:11 --> Final output sent to browser
DEBUG - 2022-06-18 03:14:11 --> Total execution time: 0.0519
INFO - 2022-06-18 03:14:26 --> Config Class Initialized
INFO - 2022-06-18 03:14:26 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:14:26 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:14:26 --> Utf8 Class Initialized
INFO - 2022-06-18 03:14:26 --> URI Class Initialized
INFO - 2022-06-18 03:14:26 --> Router Class Initialized
INFO - 2022-06-18 03:14:26 --> Output Class Initialized
INFO - 2022-06-18 03:14:26 --> Security Class Initialized
DEBUG - 2022-06-18 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:14:26 --> Input Class Initialized
INFO - 2022-06-18 03:14:26 --> Language Class Initialized
INFO - 2022-06-18 03:14:26 --> Language Class Initialized
INFO - 2022-06-18 03:14:26 --> Config Class Initialized
INFO - 2022-06-18 03:14:26 --> Loader Class Initialized
INFO - 2022-06-18 03:14:26 --> Helper loaded: url_helper
INFO - 2022-06-18 03:14:26 --> Helper loaded: file_helper
INFO - 2022-06-18 03:14:26 --> Helper loaded: form_helper
INFO - 2022-06-18 03:14:26 --> Helper loaded: my_helper
INFO - 2022-06-18 03:14:26 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:14:26 --> Controller Class Initialized
INFO - 2022-06-18 03:14:26 --> Helper loaded: cookie_helper
INFO - 2022-06-18 03:14:26 --> Config Class Initialized
INFO - 2022-06-18 03:14:26 --> Hooks Class Initialized
DEBUG - 2022-06-18 03:14:26 --> UTF-8 Support Enabled
INFO - 2022-06-18 03:14:26 --> Utf8 Class Initialized
INFO - 2022-06-18 03:14:26 --> URI Class Initialized
INFO - 2022-06-18 03:14:26 --> Router Class Initialized
INFO - 2022-06-18 03:14:26 --> Output Class Initialized
INFO - 2022-06-18 03:14:26 --> Security Class Initialized
DEBUG - 2022-06-18 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 03:14:26 --> Input Class Initialized
INFO - 2022-06-18 03:14:26 --> Language Class Initialized
INFO - 2022-06-18 03:14:26 --> Language Class Initialized
INFO - 2022-06-18 03:14:26 --> Config Class Initialized
INFO - 2022-06-18 03:14:26 --> Loader Class Initialized
INFO - 2022-06-18 03:14:26 --> Helper loaded: url_helper
INFO - 2022-06-18 03:14:26 --> Helper loaded: file_helper
INFO - 2022-06-18 03:14:26 --> Helper loaded: form_helper
INFO - 2022-06-18 03:14:26 --> Helper loaded: my_helper
INFO - 2022-06-18 03:14:26 --> Database Driver Class Initialized
DEBUG - 2022-06-18 03:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 03:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 03:14:26 --> Controller Class Initialized
DEBUG - 2022-06-18 03:14:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 03:14:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 03:14:26 --> Final output sent to browser
DEBUG - 2022-06-18 03:14:26 --> Total execution time: 0.0523
INFO - 2022-06-18 06:26:37 --> Config Class Initialized
INFO - 2022-06-18 06:26:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:26:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:26:37 --> Utf8 Class Initialized
INFO - 2022-06-18 06:26:37 --> URI Class Initialized
DEBUG - 2022-06-18 06:26:37 --> No URI present. Default controller set.
INFO - 2022-06-18 06:26:37 --> Router Class Initialized
INFO - 2022-06-18 06:26:37 --> Output Class Initialized
INFO - 2022-06-18 06:26:37 --> Security Class Initialized
DEBUG - 2022-06-18 06:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:26:37 --> Input Class Initialized
INFO - 2022-06-18 06:26:37 --> Language Class Initialized
INFO - 2022-06-18 06:26:37 --> Language Class Initialized
INFO - 2022-06-18 06:26:37 --> Config Class Initialized
INFO - 2022-06-18 06:26:37 --> Loader Class Initialized
INFO - 2022-06-18 06:26:37 --> Helper loaded: url_helper
INFO - 2022-06-18 06:26:37 --> Helper loaded: file_helper
INFO - 2022-06-18 06:26:37 --> Helper loaded: form_helper
INFO - 2022-06-18 06:26:37 --> Helper loaded: my_helper
INFO - 2022-06-18 06:26:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:26:37 --> Controller Class Initialized
INFO - 2022-06-18 06:26:37 --> Config Class Initialized
INFO - 2022-06-18 06:26:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:26:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:26:37 --> Utf8 Class Initialized
INFO - 2022-06-18 06:26:37 --> URI Class Initialized
INFO - 2022-06-18 06:26:37 --> Router Class Initialized
INFO - 2022-06-18 06:26:37 --> Output Class Initialized
INFO - 2022-06-18 06:26:37 --> Security Class Initialized
DEBUG - 2022-06-18 06:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:26:37 --> Input Class Initialized
INFO - 2022-06-18 06:26:37 --> Language Class Initialized
INFO - 2022-06-18 06:26:37 --> Language Class Initialized
INFO - 2022-06-18 06:26:37 --> Config Class Initialized
INFO - 2022-06-18 06:26:37 --> Loader Class Initialized
INFO - 2022-06-18 06:26:37 --> Helper loaded: url_helper
INFO - 2022-06-18 06:26:37 --> Helper loaded: file_helper
INFO - 2022-06-18 06:26:37 --> Helper loaded: form_helper
INFO - 2022-06-18 06:26:37 --> Helper loaded: my_helper
INFO - 2022-06-18 06:26:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:26:37 --> Controller Class Initialized
DEBUG - 2022-06-18 06:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 06:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:26:37 --> Final output sent to browser
DEBUG - 2022-06-18 06:26:37 --> Total execution time: 0.0415
INFO - 2022-06-18 06:26:38 --> Config Class Initialized
INFO - 2022-06-18 06:26:38 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:26:38 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:26:38 --> Utf8 Class Initialized
INFO - 2022-06-18 06:26:38 --> URI Class Initialized
DEBUG - 2022-06-18 06:26:38 --> No URI present. Default controller set.
INFO - 2022-06-18 06:26:38 --> Router Class Initialized
INFO - 2022-06-18 06:26:38 --> Output Class Initialized
INFO - 2022-06-18 06:26:38 --> Security Class Initialized
DEBUG - 2022-06-18 06:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:26:38 --> Input Class Initialized
INFO - 2022-06-18 06:26:38 --> Language Class Initialized
INFO - 2022-06-18 06:26:38 --> Language Class Initialized
INFO - 2022-06-18 06:26:38 --> Config Class Initialized
INFO - 2022-06-18 06:26:38 --> Loader Class Initialized
INFO - 2022-06-18 06:26:38 --> Helper loaded: url_helper
INFO - 2022-06-18 06:26:38 --> Helper loaded: file_helper
INFO - 2022-06-18 06:26:38 --> Helper loaded: form_helper
INFO - 2022-06-18 06:26:38 --> Helper loaded: my_helper
INFO - 2022-06-18 06:26:38 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:26:38 --> Controller Class Initialized
INFO - 2022-06-18 06:26:38 --> Config Class Initialized
INFO - 2022-06-18 06:26:38 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:26:38 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:26:38 --> Utf8 Class Initialized
INFO - 2022-06-18 06:26:38 --> URI Class Initialized
INFO - 2022-06-18 06:26:38 --> Router Class Initialized
INFO - 2022-06-18 06:26:38 --> Output Class Initialized
INFO - 2022-06-18 06:26:38 --> Security Class Initialized
DEBUG - 2022-06-18 06:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:26:38 --> Input Class Initialized
INFO - 2022-06-18 06:26:38 --> Language Class Initialized
INFO - 2022-06-18 06:26:38 --> Language Class Initialized
INFO - 2022-06-18 06:26:38 --> Config Class Initialized
INFO - 2022-06-18 06:26:38 --> Loader Class Initialized
INFO - 2022-06-18 06:26:38 --> Helper loaded: url_helper
INFO - 2022-06-18 06:26:38 --> Helper loaded: file_helper
INFO - 2022-06-18 06:26:38 --> Helper loaded: form_helper
INFO - 2022-06-18 06:26:38 --> Helper loaded: my_helper
INFO - 2022-06-18 06:26:38 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:26:38 --> Controller Class Initialized
DEBUG - 2022-06-18 06:26:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 06:26:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:26:38 --> Final output sent to browser
DEBUG - 2022-06-18 06:26:38 --> Total execution time: 0.0445
INFO - 2022-06-18 06:26:47 --> Config Class Initialized
INFO - 2022-06-18 06:26:47 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:26:47 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:26:47 --> Utf8 Class Initialized
INFO - 2022-06-18 06:26:47 --> URI Class Initialized
INFO - 2022-06-18 06:26:47 --> Router Class Initialized
INFO - 2022-06-18 06:26:47 --> Output Class Initialized
INFO - 2022-06-18 06:26:47 --> Security Class Initialized
DEBUG - 2022-06-18 06:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:26:47 --> Input Class Initialized
INFO - 2022-06-18 06:26:47 --> Language Class Initialized
INFO - 2022-06-18 06:26:47 --> Language Class Initialized
INFO - 2022-06-18 06:26:47 --> Config Class Initialized
INFO - 2022-06-18 06:26:47 --> Loader Class Initialized
INFO - 2022-06-18 06:26:47 --> Helper loaded: url_helper
INFO - 2022-06-18 06:26:47 --> Helper loaded: file_helper
INFO - 2022-06-18 06:26:47 --> Helper loaded: form_helper
INFO - 2022-06-18 06:26:47 --> Helper loaded: my_helper
INFO - 2022-06-18 06:26:47 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:26:47 --> Controller Class Initialized
INFO - 2022-06-18 06:26:47 --> Helper loaded: cookie_helper
INFO - 2022-06-18 06:26:47 --> Final output sent to browser
DEBUG - 2022-06-18 06:26:47 --> Total execution time: 0.0528
INFO - 2022-06-18 06:26:47 --> Config Class Initialized
INFO - 2022-06-18 06:26:47 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:26:47 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:26:47 --> Utf8 Class Initialized
INFO - 2022-06-18 06:26:47 --> URI Class Initialized
INFO - 2022-06-18 06:26:47 --> Router Class Initialized
INFO - 2022-06-18 06:26:47 --> Output Class Initialized
INFO - 2022-06-18 06:26:47 --> Security Class Initialized
DEBUG - 2022-06-18 06:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:26:47 --> Input Class Initialized
INFO - 2022-06-18 06:26:47 --> Language Class Initialized
INFO - 2022-06-18 06:26:47 --> Language Class Initialized
INFO - 2022-06-18 06:26:47 --> Config Class Initialized
INFO - 2022-06-18 06:26:47 --> Loader Class Initialized
INFO - 2022-06-18 06:26:47 --> Helper loaded: url_helper
INFO - 2022-06-18 06:26:47 --> Helper loaded: file_helper
INFO - 2022-06-18 06:26:47 --> Helper loaded: form_helper
INFO - 2022-06-18 06:26:47 --> Helper loaded: my_helper
INFO - 2022-06-18 06:26:47 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:26:47 --> Controller Class Initialized
DEBUG - 2022-06-18 06:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-18 06:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:26:47 --> Final output sent to browser
DEBUG - 2022-06-18 06:26:47 --> Total execution time: 0.0990
INFO - 2022-06-18 06:27:09 --> Config Class Initialized
INFO - 2022-06-18 06:27:09 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:09 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:09 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:09 --> URI Class Initialized
INFO - 2022-06-18 06:27:09 --> Router Class Initialized
INFO - 2022-06-18 06:27:09 --> Output Class Initialized
INFO - 2022-06-18 06:27:09 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:09 --> Input Class Initialized
INFO - 2022-06-18 06:27:09 --> Language Class Initialized
INFO - 2022-06-18 06:27:09 --> Language Class Initialized
INFO - 2022-06-18 06:27:09 --> Config Class Initialized
INFO - 2022-06-18 06:27:09 --> Loader Class Initialized
INFO - 2022-06-18 06:27:09 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:09 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:09 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:09 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:09 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:09 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-18 06:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:09 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:09 --> Total execution time: 0.0420
INFO - 2022-06-18 06:27:19 --> Config Class Initialized
INFO - 2022-06-18 06:27:19 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:19 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:19 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:19 --> URI Class Initialized
INFO - 2022-06-18 06:27:19 --> Router Class Initialized
INFO - 2022-06-18 06:27:19 --> Output Class Initialized
INFO - 2022-06-18 06:27:19 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:19 --> Input Class Initialized
INFO - 2022-06-18 06:27:19 --> Language Class Initialized
INFO - 2022-06-18 06:27:19 --> Language Class Initialized
INFO - 2022-06-18 06:27:19 --> Config Class Initialized
INFO - 2022-06-18 06:27:19 --> Loader Class Initialized
INFO - 2022-06-18 06:27:19 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:19 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:19 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:19 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:19 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:19 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:27:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:19 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:19 --> Total execution time: 0.0468
INFO - 2022-06-18 06:27:19 --> Config Class Initialized
INFO - 2022-06-18 06:27:19 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:19 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:19 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:19 --> URI Class Initialized
INFO - 2022-06-18 06:27:19 --> Router Class Initialized
INFO - 2022-06-18 06:27:19 --> Output Class Initialized
INFO - 2022-06-18 06:27:19 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:19 --> Input Class Initialized
INFO - 2022-06-18 06:27:19 --> Language Class Initialized
INFO - 2022-06-18 06:27:19 --> Language Class Initialized
INFO - 2022-06-18 06:27:19 --> Config Class Initialized
INFO - 2022-06-18 06:27:19 --> Loader Class Initialized
INFO - 2022-06-18 06:27:19 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:19 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:19 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:19 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:19 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:19 --> Controller Class Initialized
INFO - 2022-06-18 06:27:20 --> Config Class Initialized
INFO - 2022-06-18 06:27:20 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:20 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:20 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:20 --> URI Class Initialized
INFO - 2022-06-18 06:27:20 --> Router Class Initialized
INFO - 2022-06-18 06:27:20 --> Output Class Initialized
INFO - 2022-06-18 06:27:20 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:20 --> Input Class Initialized
INFO - 2022-06-18 06:27:20 --> Language Class Initialized
INFO - 2022-06-18 06:27:20 --> Language Class Initialized
INFO - 2022-06-18 06:27:20 --> Config Class Initialized
INFO - 2022-06-18 06:27:20 --> Loader Class Initialized
INFO - 2022-06-18 06:27:20 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:20 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:20 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:20 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:20 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:20 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:20 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:20 --> Total execution time: 0.0505
INFO - 2022-06-18 06:27:25 --> Config Class Initialized
INFO - 2022-06-18 06:27:25 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:25 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:25 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:25 --> URI Class Initialized
INFO - 2022-06-18 06:27:25 --> Router Class Initialized
INFO - 2022-06-18 06:27:25 --> Output Class Initialized
INFO - 2022-06-18 06:27:25 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:25 --> Input Class Initialized
INFO - 2022-06-18 06:27:25 --> Language Class Initialized
INFO - 2022-06-18 06:27:25 --> Language Class Initialized
INFO - 2022-06-18 06:27:25 --> Config Class Initialized
INFO - 2022-06-18 06:27:25 --> Loader Class Initialized
INFO - 2022-06-18 06:27:25 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:25 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:25 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:25 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:25 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:25 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:25 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:25 --> Total execution time: 0.0501
INFO - 2022-06-18 06:27:26 --> Config Class Initialized
INFO - 2022-06-18 06:27:26 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:26 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:26 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:26 --> URI Class Initialized
INFO - 2022-06-18 06:27:26 --> Router Class Initialized
INFO - 2022-06-18 06:27:26 --> Output Class Initialized
INFO - 2022-06-18 06:27:26 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:26 --> Input Class Initialized
INFO - 2022-06-18 06:27:26 --> Language Class Initialized
INFO - 2022-06-18 06:27:26 --> Language Class Initialized
INFO - 2022-06-18 06:27:26 --> Config Class Initialized
INFO - 2022-06-18 06:27:26 --> Loader Class Initialized
INFO - 2022-06-18 06:27:26 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:26 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:26 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:26 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:26 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:26 --> Controller Class Initialized
INFO - 2022-06-18 06:27:26 --> Config Class Initialized
INFO - 2022-06-18 06:27:26 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:26 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:26 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:26 --> URI Class Initialized
INFO - 2022-06-18 06:27:26 --> Router Class Initialized
INFO - 2022-06-18 06:27:26 --> Output Class Initialized
INFO - 2022-06-18 06:27:26 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:26 --> Input Class Initialized
INFO - 2022-06-18 06:27:26 --> Language Class Initialized
INFO - 2022-06-18 06:27:26 --> Language Class Initialized
INFO - 2022-06-18 06:27:26 --> Config Class Initialized
INFO - 2022-06-18 06:27:26 --> Loader Class Initialized
INFO - 2022-06-18 06:27:26 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:26 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:26 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:26 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:26 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:27 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:27:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:27 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:27 --> Total execution time: 0.0494
INFO - 2022-06-18 06:27:28 --> Config Class Initialized
INFO - 2022-06-18 06:27:28 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:28 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:28 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:28 --> URI Class Initialized
INFO - 2022-06-18 06:27:28 --> Router Class Initialized
INFO - 2022-06-18 06:27:28 --> Output Class Initialized
INFO - 2022-06-18 06:27:28 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:28 --> Input Class Initialized
INFO - 2022-06-18 06:27:28 --> Language Class Initialized
INFO - 2022-06-18 06:27:28 --> Language Class Initialized
INFO - 2022-06-18 06:27:28 --> Config Class Initialized
INFO - 2022-06-18 06:27:28 --> Loader Class Initialized
INFO - 2022-06-18 06:27:28 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:28 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:28 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:28 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:28 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:28 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:28 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:28 --> Total execution time: 0.0478
INFO - 2022-06-18 06:27:29 --> Config Class Initialized
INFO - 2022-06-18 06:27:29 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:29 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:29 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:29 --> URI Class Initialized
INFO - 2022-06-18 06:27:29 --> Router Class Initialized
INFO - 2022-06-18 06:27:29 --> Output Class Initialized
INFO - 2022-06-18 06:27:29 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:29 --> Input Class Initialized
INFO - 2022-06-18 06:27:29 --> Language Class Initialized
INFO - 2022-06-18 06:27:29 --> Language Class Initialized
INFO - 2022-06-18 06:27:29 --> Config Class Initialized
INFO - 2022-06-18 06:27:29 --> Loader Class Initialized
INFO - 2022-06-18 06:27:29 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:29 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:29 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:29 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:29 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:29 --> Controller Class Initialized
INFO - 2022-06-18 06:27:30 --> Config Class Initialized
INFO - 2022-06-18 06:27:30 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:30 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:30 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:30 --> URI Class Initialized
INFO - 2022-06-18 06:27:30 --> Router Class Initialized
INFO - 2022-06-18 06:27:30 --> Output Class Initialized
INFO - 2022-06-18 06:27:30 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:30 --> Input Class Initialized
INFO - 2022-06-18 06:27:30 --> Language Class Initialized
INFO - 2022-06-18 06:27:30 --> Language Class Initialized
INFO - 2022-06-18 06:27:30 --> Config Class Initialized
INFO - 2022-06-18 06:27:30 --> Loader Class Initialized
INFO - 2022-06-18 06:27:30 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:30 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:30 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:30 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:30 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:30 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:30 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:30 --> Total execution time: 0.0476
INFO - 2022-06-18 06:27:33 --> Config Class Initialized
INFO - 2022-06-18 06:27:33 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:33 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:33 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:33 --> URI Class Initialized
INFO - 2022-06-18 06:27:33 --> Router Class Initialized
INFO - 2022-06-18 06:27:33 --> Output Class Initialized
INFO - 2022-06-18 06:27:33 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:33 --> Input Class Initialized
INFO - 2022-06-18 06:27:33 --> Language Class Initialized
INFO - 2022-06-18 06:27:33 --> Language Class Initialized
INFO - 2022-06-18 06:27:33 --> Config Class Initialized
INFO - 2022-06-18 06:27:33 --> Loader Class Initialized
INFO - 2022-06-18 06:27:33 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:33 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:33 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:33 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:33 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:33 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:33 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:33 --> Total execution time: 0.0464
INFO - 2022-06-18 06:27:33 --> Config Class Initialized
INFO - 2022-06-18 06:27:33 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:33 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:33 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:33 --> URI Class Initialized
INFO - 2022-06-18 06:27:33 --> Router Class Initialized
INFO - 2022-06-18 06:27:33 --> Output Class Initialized
INFO - 2022-06-18 06:27:33 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:33 --> Input Class Initialized
INFO - 2022-06-18 06:27:33 --> Language Class Initialized
INFO - 2022-06-18 06:27:33 --> Language Class Initialized
INFO - 2022-06-18 06:27:33 --> Config Class Initialized
INFO - 2022-06-18 06:27:33 --> Loader Class Initialized
INFO - 2022-06-18 06:27:33 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:33 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:33 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:33 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:33 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:33 --> Controller Class Initialized
INFO - 2022-06-18 06:27:34 --> Config Class Initialized
INFO - 2022-06-18 06:27:34 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:34 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:34 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:34 --> URI Class Initialized
INFO - 2022-06-18 06:27:34 --> Router Class Initialized
INFO - 2022-06-18 06:27:34 --> Output Class Initialized
INFO - 2022-06-18 06:27:34 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:34 --> Input Class Initialized
INFO - 2022-06-18 06:27:34 --> Language Class Initialized
INFO - 2022-06-18 06:27:34 --> Language Class Initialized
INFO - 2022-06-18 06:27:34 --> Config Class Initialized
INFO - 2022-06-18 06:27:34 --> Loader Class Initialized
INFO - 2022-06-18 06:27:34 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:34 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:34 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:34 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:34 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:34 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:27:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:34 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:34 --> Total execution time: 0.0481
INFO - 2022-06-18 06:27:36 --> Config Class Initialized
INFO - 2022-06-18 06:27:36 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:36 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:36 --> URI Class Initialized
INFO - 2022-06-18 06:27:36 --> Router Class Initialized
INFO - 2022-06-18 06:27:36 --> Output Class Initialized
INFO - 2022-06-18 06:27:36 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:36 --> Input Class Initialized
INFO - 2022-06-18 06:27:36 --> Language Class Initialized
INFO - 2022-06-18 06:27:36 --> Language Class Initialized
INFO - 2022-06-18 06:27:36 --> Config Class Initialized
INFO - 2022-06-18 06:27:36 --> Loader Class Initialized
INFO - 2022-06-18 06:27:36 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:36 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:36 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:36 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:36 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:36 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:36 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:36 --> Total execution time: 0.0527
INFO - 2022-06-18 06:27:36 --> Config Class Initialized
INFO - 2022-06-18 06:27:36 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:36 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:36 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:36 --> URI Class Initialized
INFO - 2022-06-18 06:27:36 --> Router Class Initialized
INFO - 2022-06-18 06:27:36 --> Output Class Initialized
INFO - 2022-06-18 06:27:36 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:36 --> Input Class Initialized
INFO - 2022-06-18 06:27:36 --> Language Class Initialized
INFO - 2022-06-18 06:27:36 --> Language Class Initialized
INFO - 2022-06-18 06:27:36 --> Config Class Initialized
INFO - 2022-06-18 06:27:36 --> Loader Class Initialized
INFO - 2022-06-18 06:27:36 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:36 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:36 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:36 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:36 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:36 --> Controller Class Initialized
INFO - 2022-06-18 06:27:37 --> Config Class Initialized
INFO - 2022-06-18 06:27:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:37 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:37 --> URI Class Initialized
INFO - 2022-06-18 06:27:37 --> Router Class Initialized
INFO - 2022-06-18 06:27:37 --> Output Class Initialized
INFO - 2022-06-18 06:27:37 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:37 --> Input Class Initialized
INFO - 2022-06-18 06:27:37 --> Language Class Initialized
INFO - 2022-06-18 06:27:37 --> Language Class Initialized
INFO - 2022-06-18 06:27:37 --> Config Class Initialized
INFO - 2022-06-18 06:27:37 --> Loader Class Initialized
INFO - 2022-06-18 06:27:37 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:37 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:37 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:37 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:37 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:27:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:37 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:37 --> Total execution time: 0.0444
INFO - 2022-06-18 06:27:40 --> Config Class Initialized
INFO - 2022-06-18 06:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:40 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:40 --> URI Class Initialized
INFO - 2022-06-18 06:27:40 --> Router Class Initialized
INFO - 2022-06-18 06:27:40 --> Output Class Initialized
INFO - 2022-06-18 06:27:40 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:40 --> Input Class Initialized
INFO - 2022-06-18 06:27:40 --> Language Class Initialized
INFO - 2022-06-18 06:27:40 --> Language Class Initialized
INFO - 2022-06-18 06:27:40 --> Config Class Initialized
INFO - 2022-06-18 06:27:40 --> Loader Class Initialized
INFO - 2022-06-18 06:27:40 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:40 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:40 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:40 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:40 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:40 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:27:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:40 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:40 --> Total execution time: 0.0454
INFO - 2022-06-18 06:27:40 --> Config Class Initialized
INFO - 2022-06-18 06:27:40 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:40 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:40 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:40 --> URI Class Initialized
INFO - 2022-06-18 06:27:40 --> Router Class Initialized
INFO - 2022-06-18 06:27:40 --> Output Class Initialized
INFO - 2022-06-18 06:27:40 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:40 --> Input Class Initialized
INFO - 2022-06-18 06:27:40 --> Language Class Initialized
INFO - 2022-06-18 06:27:40 --> Language Class Initialized
INFO - 2022-06-18 06:27:40 --> Config Class Initialized
INFO - 2022-06-18 06:27:40 --> Loader Class Initialized
INFO - 2022-06-18 06:27:40 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:40 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:40 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:40 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:40 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:40 --> Controller Class Initialized
INFO - 2022-06-18 06:27:41 --> Config Class Initialized
INFO - 2022-06-18 06:27:41 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:41 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:41 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:41 --> URI Class Initialized
INFO - 2022-06-18 06:27:41 --> Router Class Initialized
INFO - 2022-06-18 06:27:41 --> Output Class Initialized
INFO - 2022-06-18 06:27:41 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:41 --> Input Class Initialized
INFO - 2022-06-18 06:27:41 --> Language Class Initialized
INFO - 2022-06-18 06:27:41 --> Language Class Initialized
INFO - 2022-06-18 06:27:41 --> Config Class Initialized
INFO - 2022-06-18 06:27:41 --> Loader Class Initialized
INFO - 2022-06-18 06:27:41 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:41 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:41 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:41 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:41 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:41 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:27:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:41 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:41 --> Total execution time: 0.0478
INFO - 2022-06-18 06:27:43 --> Config Class Initialized
INFO - 2022-06-18 06:27:43 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:43 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:43 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:43 --> URI Class Initialized
INFO - 2022-06-18 06:27:43 --> Router Class Initialized
INFO - 2022-06-18 06:27:43 --> Output Class Initialized
INFO - 2022-06-18 06:27:43 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:43 --> Input Class Initialized
INFO - 2022-06-18 06:27:43 --> Language Class Initialized
INFO - 2022-06-18 06:27:43 --> Language Class Initialized
INFO - 2022-06-18 06:27:43 --> Config Class Initialized
INFO - 2022-06-18 06:27:43 --> Loader Class Initialized
INFO - 2022-06-18 06:27:43 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:43 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:43 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:43 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:43 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:43 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:43 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:43 --> Total execution time: 0.0459
INFO - 2022-06-18 06:27:43 --> Config Class Initialized
INFO - 2022-06-18 06:27:43 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:43 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:43 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:43 --> URI Class Initialized
INFO - 2022-06-18 06:27:43 --> Router Class Initialized
INFO - 2022-06-18 06:27:43 --> Output Class Initialized
INFO - 2022-06-18 06:27:43 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:43 --> Input Class Initialized
INFO - 2022-06-18 06:27:43 --> Language Class Initialized
INFO - 2022-06-18 06:27:43 --> Language Class Initialized
INFO - 2022-06-18 06:27:43 --> Config Class Initialized
INFO - 2022-06-18 06:27:43 --> Loader Class Initialized
INFO - 2022-06-18 06:27:43 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:43 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:43 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:43 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:43 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:43 --> Controller Class Initialized
INFO - 2022-06-18 06:27:45 --> Config Class Initialized
INFO - 2022-06-18 06:27:45 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:45 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:45 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:45 --> URI Class Initialized
INFO - 2022-06-18 06:27:45 --> Router Class Initialized
INFO - 2022-06-18 06:27:45 --> Output Class Initialized
INFO - 2022-06-18 06:27:45 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:45 --> Input Class Initialized
INFO - 2022-06-18 06:27:45 --> Language Class Initialized
INFO - 2022-06-18 06:27:45 --> Language Class Initialized
INFO - 2022-06-18 06:27:45 --> Config Class Initialized
INFO - 2022-06-18 06:27:45 --> Loader Class Initialized
INFO - 2022-06-18 06:27:45 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:45 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:45 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:45 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:45 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:45 --> Controller Class Initialized
DEBUG - 2022-06-18 06:27:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:27:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:27:45 --> Final output sent to browser
DEBUG - 2022-06-18 06:27:45 --> Total execution time: 0.0475
INFO - 2022-06-18 06:27:48 --> Config Class Initialized
INFO - 2022-06-18 06:27:48 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:48 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:48 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:48 --> URI Class Initialized
INFO - 2022-06-18 06:27:48 --> Router Class Initialized
INFO - 2022-06-18 06:27:48 --> Output Class Initialized
INFO - 2022-06-18 06:27:48 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:48 --> Input Class Initialized
INFO - 2022-06-18 06:27:48 --> Language Class Initialized
INFO - 2022-06-18 06:27:48 --> Language Class Initialized
INFO - 2022-06-18 06:27:48 --> Config Class Initialized
INFO - 2022-06-18 06:27:48 --> Loader Class Initialized
INFO - 2022-06-18 06:27:48 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:48 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:48 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:48 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:48 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:48 --> Controller Class Initialized
INFO - 2022-06-18 06:27:51 --> Config Class Initialized
INFO - 2022-06-18 06:27:51 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:51 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:51 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:51 --> URI Class Initialized
INFO - 2022-06-18 06:27:51 --> Router Class Initialized
INFO - 2022-06-18 06:27:51 --> Output Class Initialized
INFO - 2022-06-18 06:27:51 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:51 --> Input Class Initialized
INFO - 2022-06-18 06:27:51 --> Language Class Initialized
INFO - 2022-06-18 06:27:51 --> Language Class Initialized
INFO - 2022-06-18 06:27:51 --> Config Class Initialized
INFO - 2022-06-18 06:27:51 --> Loader Class Initialized
INFO - 2022-06-18 06:27:51 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:51 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:51 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:51 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:51 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:51 --> Controller Class Initialized
INFO - 2022-06-18 06:27:53 --> Config Class Initialized
INFO - 2022-06-18 06:27:53 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:53 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:53 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:53 --> URI Class Initialized
INFO - 2022-06-18 06:27:53 --> Router Class Initialized
INFO - 2022-06-18 06:27:53 --> Output Class Initialized
INFO - 2022-06-18 06:27:53 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:53 --> Input Class Initialized
INFO - 2022-06-18 06:27:53 --> Language Class Initialized
INFO - 2022-06-18 06:27:53 --> Language Class Initialized
INFO - 2022-06-18 06:27:53 --> Config Class Initialized
INFO - 2022-06-18 06:27:53 --> Loader Class Initialized
INFO - 2022-06-18 06:27:53 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:53 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:53 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:53 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:53 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:53 --> Controller Class Initialized
INFO - 2022-06-18 06:27:55 --> Config Class Initialized
INFO - 2022-06-18 06:27:55 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:55 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:55 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:55 --> URI Class Initialized
INFO - 2022-06-18 06:27:55 --> Router Class Initialized
INFO - 2022-06-18 06:27:55 --> Output Class Initialized
INFO - 2022-06-18 06:27:55 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:55 --> Input Class Initialized
INFO - 2022-06-18 06:27:55 --> Language Class Initialized
INFO - 2022-06-18 06:27:55 --> Language Class Initialized
INFO - 2022-06-18 06:27:55 --> Config Class Initialized
INFO - 2022-06-18 06:27:55 --> Loader Class Initialized
INFO - 2022-06-18 06:27:55 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:55 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:55 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:55 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:55 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:55 --> Controller Class Initialized
INFO - 2022-06-18 06:27:57 --> Config Class Initialized
INFO - 2022-06-18 06:27:57 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:57 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:57 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:57 --> URI Class Initialized
INFO - 2022-06-18 06:27:57 --> Router Class Initialized
INFO - 2022-06-18 06:27:57 --> Output Class Initialized
INFO - 2022-06-18 06:27:57 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:57 --> Input Class Initialized
INFO - 2022-06-18 06:27:57 --> Language Class Initialized
INFO - 2022-06-18 06:27:57 --> Language Class Initialized
INFO - 2022-06-18 06:27:57 --> Config Class Initialized
INFO - 2022-06-18 06:27:57 --> Loader Class Initialized
INFO - 2022-06-18 06:27:57 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:57 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:57 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:57 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:57 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:57 --> Controller Class Initialized
INFO - 2022-06-18 06:27:59 --> Config Class Initialized
INFO - 2022-06-18 06:27:59 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:27:59 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:27:59 --> Utf8 Class Initialized
INFO - 2022-06-18 06:27:59 --> URI Class Initialized
INFO - 2022-06-18 06:27:59 --> Router Class Initialized
INFO - 2022-06-18 06:27:59 --> Output Class Initialized
INFO - 2022-06-18 06:27:59 --> Security Class Initialized
DEBUG - 2022-06-18 06:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:27:59 --> Input Class Initialized
INFO - 2022-06-18 06:27:59 --> Language Class Initialized
INFO - 2022-06-18 06:27:59 --> Language Class Initialized
INFO - 2022-06-18 06:27:59 --> Config Class Initialized
INFO - 2022-06-18 06:27:59 --> Loader Class Initialized
INFO - 2022-06-18 06:27:59 --> Helper loaded: url_helper
INFO - 2022-06-18 06:27:59 --> Helper loaded: file_helper
INFO - 2022-06-18 06:27:59 --> Helper loaded: form_helper
INFO - 2022-06-18 06:27:59 --> Helper loaded: my_helper
INFO - 2022-06-18 06:27:59 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:27:59 --> Controller Class Initialized
INFO - 2022-06-18 06:28:08 --> Config Class Initialized
INFO - 2022-06-18 06:28:08 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:08 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:08 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:08 --> URI Class Initialized
INFO - 2022-06-18 06:28:08 --> Router Class Initialized
INFO - 2022-06-18 06:28:08 --> Output Class Initialized
INFO - 2022-06-18 06:28:08 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:08 --> Input Class Initialized
INFO - 2022-06-18 06:28:08 --> Language Class Initialized
INFO - 2022-06-18 06:28:08 --> Language Class Initialized
INFO - 2022-06-18 06:28:08 --> Config Class Initialized
INFO - 2022-06-18 06:28:08 --> Loader Class Initialized
INFO - 2022-06-18 06:28:08 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:08 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:08 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:08 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:08 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:08 --> Controller Class Initialized
INFO - 2022-06-18 06:28:09 --> Config Class Initialized
INFO - 2022-06-18 06:28:09 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:09 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:09 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:09 --> URI Class Initialized
INFO - 2022-06-18 06:28:09 --> Router Class Initialized
INFO - 2022-06-18 06:28:09 --> Output Class Initialized
INFO - 2022-06-18 06:28:09 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:09 --> Input Class Initialized
INFO - 2022-06-18 06:28:09 --> Language Class Initialized
INFO - 2022-06-18 06:28:09 --> Language Class Initialized
INFO - 2022-06-18 06:28:09 --> Config Class Initialized
INFO - 2022-06-18 06:28:09 --> Loader Class Initialized
INFO - 2022-06-18 06:28:10 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:10 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:10 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:10 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:10 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:10 --> Controller Class Initialized
INFO - 2022-06-18 06:28:12 --> Config Class Initialized
INFO - 2022-06-18 06:28:12 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:12 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:12 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:12 --> URI Class Initialized
INFO - 2022-06-18 06:28:12 --> Router Class Initialized
INFO - 2022-06-18 06:28:12 --> Output Class Initialized
INFO - 2022-06-18 06:28:12 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:12 --> Input Class Initialized
INFO - 2022-06-18 06:28:12 --> Language Class Initialized
INFO - 2022-06-18 06:28:12 --> Language Class Initialized
INFO - 2022-06-18 06:28:12 --> Config Class Initialized
INFO - 2022-06-18 06:28:12 --> Loader Class Initialized
INFO - 2022-06-18 06:28:12 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:12 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:12 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:12 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:12 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:12 --> Controller Class Initialized
INFO - 2022-06-18 06:28:14 --> Config Class Initialized
INFO - 2022-06-18 06:28:14 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:14 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:14 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:14 --> URI Class Initialized
INFO - 2022-06-18 06:28:14 --> Router Class Initialized
INFO - 2022-06-18 06:28:14 --> Output Class Initialized
INFO - 2022-06-18 06:28:14 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:14 --> Input Class Initialized
INFO - 2022-06-18 06:28:14 --> Language Class Initialized
INFO - 2022-06-18 06:28:14 --> Language Class Initialized
INFO - 2022-06-18 06:28:14 --> Config Class Initialized
INFO - 2022-06-18 06:28:14 --> Loader Class Initialized
INFO - 2022-06-18 06:28:14 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:14 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:14 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:14 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:14 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:14 --> Controller Class Initialized
INFO - 2022-06-18 06:28:16 --> Config Class Initialized
INFO - 2022-06-18 06:28:16 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:16 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:16 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:16 --> URI Class Initialized
INFO - 2022-06-18 06:28:16 --> Router Class Initialized
INFO - 2022-06-18 06:28:16 --> Output Class Initialized
INFO - 2022-06-18 06:28:16 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:16 --> Input Class Initialized
INFO - 2022-06-18 06:28:16 --> Language Class Initialized
INFO - 2022-06-18 06:28:16 --> Language Class Initialized
INFO - 2022-06-18 06:28:16 --> Config Class Initialized
INFO - 2022-06-18 06:28:16 --> Loader Class Initialized
INFO - 2022-06-18 06:28:16 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:16 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:16 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:16 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:16 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:16 --> Controller Class Initialized
INFO - 2022-06-18 06:28:24 --> Config Class Initialized
INFO - 2022-06-18 06:28:24 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:24 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:24 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:24 --> URI Class Initialized
INFO - 2022-06-18 06:28:24 --> Router Class Initialized
INFO - 2022-06-18 06:28:24 --> Output Class Initialized
INFO - 2022-06-18 06:28:24 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:24 --> Input Class Initialized
INFO - 2022-06-18 06:28:24 --> Language Class Initialized
INFO - 2022-06-18 06:28:24 --> Language Class Initialized
INFO - 2022-06-18 06:28:24 --> Config Class Initialized
INFO - 2022-06-18 06:28:24 --> Loader Class Initialized
INFO - 2022-06-18 06:28:24 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:24 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:24 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:24 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:24 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:24 --> Controller Class Initialized
INFO - 2022-06-18 06:28:26 --> Config Class Initialized
INFO - 2022-06-18 06:28:26 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:26 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:26 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:26 --> URI Class Initialized
INFO - 2022-06-18 06:28:26 --> Router Class Initialized
INFO - 2022-06-18 06:28:26 --> Output Class Initialized
INFO - 2022-06-18 06:28:26 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:26 --> Input Class Initialized
INFO - 2022-06-18 06:28:26 --> Language Class Initialized
INFO - 2022-06-18 06:28:26 --> Language Class Initialized
INFO - 2022-06-18 06:28:26 --> Config Class Initialized
INFO - 2022-06-18 06:28:26 --> Loader Class Initialized
INFO - 2022-06-18 06:28:26 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:26 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:26 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:26 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:26 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:26 --> Controller Class Initialized
INFO - 2022-06-18 06:28:28 --> Config Class Initialized
INFO - 2022-06-18 06:28:28 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:28:28 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:28:28 --> Utf8 Class Initialized
INFO - 2022-06-18 06:28:28 --> URI Class Initialized
INFO - 2022-06-18 06:28:28 --> Router Class Initialized
INFO - 2022-06-18 06:28:28 --> Output Class Initialized
INFO - 2022-06-18 06:28:28 --> Security Class Initialized
DEBUG - 2022-06-18 06:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:28:28 --> Input Class Initialized
INFO - 2022-06-18 06:28:28 --> Language Class Initialized
INFO - 2022-06-18 06:28:28 --> Language Class Initialized
INFO - 2022-06-18 06:28:28 --> Config Class Initialized
INFO - 2022-06-18 06:28:28 --> Loader Class Initialized
INFO - 2022-06-18 06:28:28 --> Helper loaded: url_helper
INFO - 2022-06-18 06:28:28 --> Helper loaded: file_helper
INFO - 2022-06-18 06:28:28 --> Helper loaded: form_helper
INFO - 2022-06-18 06:28:28 --> Helper loaded: my_helper
INFO - 2022-06-18 06:28:28 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:28:28 --> Controller Class Initialized
INFO - 2022-06-18 06:29:46 --> Config Class Initialized
INFO - 2022-06-18 06:29:46 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:29:46 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:29:46 --> Utf8 Class Initialized
INFO - 2022-06-18 06:29:46 --> URI Class Initialized
INFO - 2022-06-18 06:29:46 --> Router Class Initialized
INFO - 2022-06-18 06:29:46 --> Output Class Initialized
INFO - 2022-06-18 06:29:46 --> Security Class Initialized
DEBUG - 2022-06-18 06:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:29:46 --> Input Class Initialized
INFO - 2022-06-18 06:29:46 --> Language Class Initialized
INFO - 2022-06-18 06:29:46 --> Language Class Initialized
INFO - 2022-06-18 06:29:46 --> Config Class Initialized
INFO - 2022-06-18 06:29:46 --> Loader Class Initialized
INFO - 2022-06-18 06:29:46 --> Helper loaded: url_helper
INFO - 2022-06-18 06:29:46 --> Helper loaded: file_helper
INFO - 2022-06-18 06:29:46 --> Helper loaded: form_helper
INFO - 2022-06-18 06:29:46 --> Helper loaded: my_helper
INFO - 2022-06-18 06:29:46 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:29:46 --> Controller Class Initialized
INFO - 2022-06-18 06:29:46 --> Helper loaded: cookie_helper
INFO - 2022-06-18 06:29:46 --> Config Class Initialized
INFO - 2022-06-18 06:29:46 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:29:46 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:29:46 --> Utf8 Class Initialized
INFO - 2022-06-18 06:29:46 --> URI Class Initialized
INFO - 2022-06-18 06:29:46 --> Router Class Initialized
INFO - 2022-06-18 06:29:46 --> Output Class Initialized
INFO - 2022-06-18 06:29:46 --> Security Class Initialized
DEBUG - 2022-06-18 06:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:29:46 --> Input Class Initialized
INFO - 2022-06-18 06:29:46 --> Language Class Initialized
INFO - 2022-06-18 06:29:46 --> Language Class Initialized
INFO - 2022-06-18 06:29:46 --> Config Class Initialized
INFO - 2022-06-18 06:29:46 --> Loader Class Initialized
INFO - 2022-06-18 06:29:46 --> Helper loaded: url_helper
INFO - 2022-06-18 06:29:46 --> Helper loaded: file_helper
INFO - 2022-06-18 06:29:46 --> Helper loaded: form_helper
INFO - 2022-06-18 06:29:46 --> Helper loaded: my_helper
INFO - 2022-06-18 06:29:46 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:29:46 --> Controller Class Initialized
DEBUG - 2022-06-18 06:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 06:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:29:46 --> Final output sent to browser
DEBUG - 2022-06-18 06:29:46 --> Total execution time: 0.0404
INFO - 2022-06-18 06:29:50 --> Config Class Initialized
INFO - 2022-06-18 06:29:50 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:29:50 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:29:50 --> Utf8 Class Initialized
INFO - 2022-06-18 06:29:50 --> URI Class Initialized
INFO - 2022-06-18 06:29:50 --> Router Class Initialized
INFO - 2022-06-18 06:29:50 --> Output Class Initialized
INFO - 2022-06-18 06:29:50 --> Security Class Initialized
DEBUG - 2022-06-18 06:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:29:50 --> Input Class Initialized
INFO - 2022-06-18 06:29:50 --> Language Class Initialized
INFO - 2022-06-18 06:29:50 --> Language Class Initialized
INFO - 2022-06-18 06:29:50 --> Config Class Initialized
INFO - 2022-06-18 06:29:50 --> Loader Class Initialized
INFO - 2022-06-18 06:29:50 --> Helper loaded: url_helper
INFO - 2022-06-18 06:29:50 --> Helper loaded: file_helper
INFO - 2022-06-18 06:29:50 --> Helper loaded: form_helper
INFO - 2022-06-18 06:29:50 --> Helper loaded: my_helper
INFO - 2022-06-18 06:29:50 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:29:50 --> Controller Class Initialized
INFO - 2022-06-18 06:29:50 --> Final output sent to browser
DEBUG - 2022-06-18 06:29:50 --> Total execution time: 0.0518
INFO - 2022-06-18 06:29:54 --> Config Class Initialized
INFO - 2022-06-18 06:29:54 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:29:54 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:29:54 --> Utf8 Class Initialized
INFO - 2022-06-18 06:29:54 --> URI Class Initialized
INFO - 2022-06-18 06:29:54 --> Router Class Initialized
INFO - 2022-06-18 06:29:54 --> Output Class Initialized
INFO - 2022-06-18 06:29:54 --> Security Class Initialized
DEBUG - 2022-06-18 06:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:29:54 --> Input Class Initialized
INFO - 2022-06-18 06:29:54 --> Language Class Initialized
INFO - 2022-06-18 06:29:54 --> Language Class Initialized
INFO - 2022-06-18 06:29:54 --> Config Class Initialized
INFO - 2022-06-18 06:29:54 --> Loader Class Initialized
INFO - 2022-06-18 06:29:54 --> Helper loaded: url_helper
INFO - 2022-06-18 06:29:54 --> Helper loaded: file_helper
INFO - 2022-06-18 06:29:54 --> Helper loaded: form_helper
INFO - 2022-06-18 06:29:54 --> Helper loaded: my_helper
INFO - 2022-06-18 06:29:54 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:29:54 --> Controller Class Initialized
INFO - 2022-06-18 06:29:54 --> Helper loaded: cookie_helper
INFO - 2022-06-18 06:29:54 --> Final output sent to browser
DEBUG - 2022-06-18 06:29:54 --> Total execution time: 0.0425
INFO - 2022-06-18 06:29:54 --> Config Class Initialized
INFO - 2022-06-18 06:29:54 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:29:54 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:29:54 --> Utf8 Class Initialized
INFO - 2022-06-18 06:29:54 --> URI Class Initialized
INFO - 2022-06-18 06:29:54 --> Router Class Initialized
INFO - 2022-06-18 06:29:54 --> Output Class Initialized
INFO - 2022-06-18 06:29:54 --> Security Class Initialized
DEBUG - 2022-06-18 06:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:29:54 --> Input Class Initialized
INFO - 2022-06-18 06:29:54 --> Language Class Initialized
INFO - 2022-06-18 06:29:54 --> Language Class Initialized
INFO - 2022-06-18 06:29:54 --> Config Class Initialized
INFO - 2022-06-18 06:29:54 --> Loader Class Initialized
INFO - 2022-06-18 06:29:54 --> Helper loaded: url_helper
INFO - 2022-06-18 06:29:54 --> Helper loaded: file_helper
INFO - 2022-06-18 06:29:54 --> Helper loaded: form_helper
INFO - 2022-06-18 06:29:54 --> Helper loaded: my_helper
INFO - 2022-06-18 06:29:54 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:29:54 --> Controller Class Initialized
DEBUG - 2022-06-18 06:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-06-18 06:29:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:29:54 --> Final output sent to browser
DEBUG - 2022-06-18 06:29:54 --> Total execution time: 0.1075
INFO - 2022-06-18 06:29:56 --> Config Class Initialized
INFO - 2022-06-18 06:29:56 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:29:56 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:29:56 --> Utf8 Class Initialized
INFO - 2022-06-18 06:29:56 --> URI Class Initialized
INFO - 2022-06-18 06:29:56 --> Router Class Initialized
INFO - 2022-06-18 06:29:56 --> Output Class Initialized
INFO - 2022-06-18 06:29:56 --> Security Class Initialized
DEBUG - 2022-06-18 06:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:29:56 --> Input Class Initialized
INFO - 2022-06-18 06:29:56 --> Language Class Initialized
INFO - 2022-06-18 06:29:56 --> Language Class Initialized
INFO - 2022-06-18 06:29:56 --> Config Class Initialized
INFO - 2022-06-18 06:29:56 --> Loader Class Initialized
INFO - 2022-06-18 06:29:56 --> Helper loaded: url_helper
INFO - 2022-06-18 06:29:56 --> Helper loaded: file_helper
INFO - 2022-06-18 06:29:56 --> Helper loaded: form_helper
INFO - 2022-06-18 06:29:56 --> Helper loaded: my_helper
INFO - 2022-06-18 06:29:56 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:29:56 --> Controller Class Initialized
DEBUG - 2022-06-18 06:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2022-06-18 06:29:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:29:56 --> Final output sent to browser
DEBUG - 2022-06-18 06:29:56 --> Total execution time: 0.0426
INFO - 2022-06-18 06:30:09 --> Config Class Initialized
INFO - 2022-06-18 06:30:09 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:09 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:09 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:09 --> URI Class Initialized
INFO - 2022-06-18 06:30:09 --> Router Class Initialized
INFO - 2022-06-18 06:30:09 --> Output Class Initialized
INFO - 2022-06-18 06:30:09 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:09 --> Input Class Initialized
INFO - 2022-06-18 06:30:09 --> Language Class Initialized
INFO - 2022-06-18 06:30:09 --> Language Class Initialized
INFO - 2022-06-18 06:30:09 --> Config Class Initialized
INFO - 2022-06-18 06:30:09 --> Loader Class Initialized
INFO - 2022-06-18 06:30:09 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:09 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:09 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:09 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:09 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:09 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:30:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:09 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:09 --> Total execution time: 0.0452
INFO - 2022-06-18 06:30:09 --> Config Class Initialized
INFO - 2022-06-18 06:30:09 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:09 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:09 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:09 --> URI Class Initialized
INFO - 2022-06-18 06:30:09 --> Router Class Initialized
INFO - 2022-06-18 06:30:09 --> Output Class Initialized
INFO - 2022-06-18 06:30:09 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:09 --> Input Class Initialized
INFO - 2022-06-18 06:30:09 --> Language Class Initialized
INFO - 2022-06-18 06:30:09 --> Language Class Initialized
INFO - 2022-06-18 06:30:09 --> Config Class Initialized
INFO - 2022-06-18 06:30:09 --> Loader Class Initialized
INFO - 2022-06-18 06:30:09 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:09 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:09 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:09 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:09 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:09 --> Controller Class Initialized
INFO - 2022-06-18 06:30:10 --> Config Class Initialized
INFO - 2022-06-18 06:30:10 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:10 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:10 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:10 --> URI Class Initialized
INFO - 2022-06-18 06:30:10 --> Router Class Initialized
INFO - 2022-06-18 06:30:10 --> Output Class Initialized
INFO - 2022-06-18 06:30:10 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:10 --> Input Class Initialized
INFO - 2022-06-18 06:30:10 --> Language Class Initialized
INFO - 2022-06-18 06:30:10 --> Language Class Initialized
INFO - 2022-06-18 06:30:10 --> Config Class Initialized
INFO - 2022-06-18 06:30:10 --> Loader Class Initialized
INFO - 2022-06-18 06:30:10 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:10 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:10 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:10 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:10 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:10 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:10 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:10 --> Total execution time: 0.0441
INFO - 2022-06-18 06:30:16 --> Config Class Initialized
INFO - 2022-06-18 06:30:16 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:16 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:16 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:16 --> URI Class Initialized
INFO - 2022-06-18 06:30:16 --> Router Class Initialized
INFO - 2022-06-18 06:30:16 --> Output Class Initialized
INFO - 2022-06-18 06:30:16 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:16 --> Input Class Initialized
INFO - 2022-06-18 06:30:16 --> Language Class Initialized
INFO - 2022-06-18 06:30:16 --> Language Class Initialized
INFO - 2022-06-18 06:30:16 --> Config Class Initialized
INFO - 2022-06-18 06:30:16 --> Loader Class Initialized
INFO - 2022-06-18 06:30:16 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:16 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:16 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:16 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:16 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:16 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:16 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:16 --> Total execution time: 0.0482
INFO - 2022-06-18 06:30:16 --> Config Class Initialized
INFO - 2022-06-18 06:30:16 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:16 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:16 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:16 --> URI Class Initialized
INFO - 2022-06-18 06:30:16 --> Router Class Initialized
INFO - 2022-06-18 06:30:16 --> Output Class Initialized
INFO - 2022-06-18 06:30:16 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:16 --> Input Class Initialized
INFO - 2022-06-18 06:30:16 --> Language Class Initialized
INFO - 2022-06-18 06:30:16 --> Language Class Initialized
INFO - 2022-06-18 06:30:16 --> Config Class Initialized
INFO - 2022-06-18 06:30:16 --> Loader Class Initialized
INFO - 2022-06-18 06:30:16 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:16 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:16 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:16 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:16 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:16 --> Controller Class Initialized
INFO - 2022-06-18 06:30:18 --> Config Class Initialized
INFO - 2022-06-18 06:30:18 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:18 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:18 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:18 --> URI Class Initialized
INFO - 2022-06-18 06:30:18 --> Router Class Initialized
INFO - 2022-06-18 06:30:18 --> Output Class Initialized
INFO - 2022-06-18 06:30:18 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:18 --> Input Class Initialized
INFO - 2022-06-18 06:30:18 --> Language Class Initialized
INFO - 2022-06-18 06:30:18 --> Language Class Initialized
INFO - 2022-06-18 06:30:18 --> Config Class Initialized
INFO - 2022-06-18 06:30:18 --> Loader Class Initialized
INFO - 2022-06-18 06:30:18 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:18 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:18 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:18 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:18 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:18 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:30:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:18 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:18 --> Total execution time: 0.0457
INFO - 2022-06-18 06:30:23 --> Config Class Initialized
INFO - 2022-06-18 06:30:23 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:23 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:23 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:23 --> URI Class Initialized
INFO - 2022-06-18 06:30:23 --> Router Class Initialized
INFO - 2022-06-18 06:30:23 --> Output Class Initialized
INFO - 2022-06-18 06:30:23 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:23 --> Input Class Initialized
INFO - 2022-06-18 06:30:23 --> Language Class Initialized
INFO - 2022-06-18 06:30:23 --> Language Class Initialized
INFO - 2022-06-18 06:30:23 --> Config Class Initialized
INFO - 2022-06-18 06:30:23 --> Loader Class Initialized
INFO - 2022-06-18 06:30:23 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:23 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:23 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:23 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:23 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:23 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:30:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:23 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:23 --> Total execution time: 0.0477
INFO - 2022-06-18 06:30:23 --> Config Class Initialized
INFO - 2022-06-18 06:30:23 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:23 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:23 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:23 --> URI Class Initialized
INFO - 2022-06-18 06:30:23 --> Router Class Initialized
INFO - 2022-06-18 06:30:23 --> Output Class Initialized
INFO - 2022-06-18 06:30:23 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:23 --> Input Class Initialized
INFO - 2022-06-18 06:30:23 --> Language Class Initialized
INFO - 2022-06-18 06:30:23 --> Language Class Initialized
INFO - 2022-06-18 06:30:23 --> Config Class Initialized
INFO - 2022-06-18 06:30:23 --> Loader Class Initialized
INFO - 2022-06-18 06:30:23 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:23 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:23 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:23 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:23 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:23 --> Controller Class Initialized
INFO - 2022-06-18 06:30:25 --> Config Class Initialized
INFO - 2022-06-18 06:30:25 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:25 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:25 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:25 --> URI Class Initialized
INFO - 2022-06-18 06:30:25 --> Router Class Initialized
INFO - 2022-06-18 06:30:25 --> Output Class Initialized
INFO - 2022-06-18 06:30:25 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:25 --> Input Class Initialized
INFO - 2022-06-18 06:30:25 --> Language Class Initialized
INFO - 2022-06-18 06:30:25 --> Language Class Initialized
INFO - 2022-06-18 06:30:25 --> Config Class Initialized
INFO - 2022-06-18 06:30:25 --> Loader Class Initialized
INFO - 2022-06-18 06:30:25 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:25 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:25 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:25 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:25 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:25 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:30:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:25 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:25 --> Total execution time: 0.0475
INFO - 2022-06-18 06:30:34 --> Config Class Initialized
INFO - 2022-06-18 06:30:34 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:34 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:34 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:34 --> URI Class Initialized
INFO - 2022-06-18 06:30:34 --> Router Class Initialized
INFO - 2022-06-18 06:30:34 --> Output Class Initialized
INFO - 2022-06-18 06:30:34 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:34 --> Input Class Initialized
INFO - 2022-06-18 06:30:34 --> Language Class Initialized
INFO - 2022-06-18 06:30:34 --> Language Class Initialized
INFO - 2022-06-18 06:30:34 --> Config Class Initialized
INFO - 2022-06-18 06:30:34 --> Loader Class Initialized
INFO - 2022-06-18 06:30:34 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:34 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:34 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:34 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:34 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:34 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:30:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:34 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:34 --> Total execution time: 0.0458
INFO - 2022-06-18 06:30:34 --> Config Class Initialized
INFO - 2022-06-18 06:30:34 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:34 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:34 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:34 --> URI Class Initialized
INFO - 2022-06-18 06:30:34 --> Router Class Initialized
INFO - 2022-06-18 06:30:34 --> Output Class Initialized
INFO - 2022-06-18 06:30:34 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:34 --> Input Class Initialized
INFO - 2022-06-18 06:30:34 --> Language Class Initialized
INFO - 2022-06-18 06:30:34 --> Language Class Initialized
INFO - 2022-06-18 06:30:34 --> Config Class Initialized
INFO - 2022-06-18 06:30:34 --> Loader Class Initialized
INFO - 2022-06-18 06:30:34 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:34 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:34 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:34 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:34 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:34 --> Controller Class Initialized
INFO - 2022-06-18 06:30:35 --> Config Class Initialized
INFO - 2022-06-18 06:30:35 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:35 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:35 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:35 --> URI Class Initialized
INFO - 2022-06-18 06:30:35 --> Router Class Initialized
INFO - 2022-06-18 06:30:35 --> Output Class Initialized
INFO - 2022-06-18 06:30:35 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:35 --> Input Class Initialized
INFO - 2022-06-18 06:30:35 --> Language Class Initialized
INFO - 2022-06-18 06:30:35 --> Language Class Initialized
INFO - 2022-06-18 06:30:35 --> Config Class Initialized
INFO - 2022-06-18 06:30:35 --> Loader Class Initialized
INFO - 2022-06-18 06:30:35 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:35 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:35 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:35 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:35 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:35 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:30:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:35 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:35 --> Total execution time: 0.0465
INFO - 2022-06-18 06:30:37 --> Config Class Initialized
INFO - 2022-06-18 06:30:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:37 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:37 --> URI Class Initialized
INFO - 2022-06-18 06:30:37 --> Router Class Initialized
INFO - 2022-06-18 06:30:37 --> Output Class Initialized
INFO - 2022-06-18 06:30:37 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:37 --> Input Class Initialized
INFO - 2022-06-18 06:30:37 --> Language Class Initialized
INFO - 2022-06-18 06:30:37 --> Language Class Initialized
INFO - 2022-06-18 06:30:37 --> Config Class Initialized
INFO - 2022-06-18 06:30:37 --> Loader Class Initialized
INFO - 2022-06-18 06:30:37 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:37 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:37 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:37 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:37 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2022-06-18 06:30:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:37 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:37 --> Total execution time: 0.0460
INFO - 2022-06-18 06:30:37 --> Config Class Initialized
INFO - 2022-06-18 06:30:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:37 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:37 --> URI Class Initialized
INFO - 2022-06-18 06:30:37 --> Router Class Initialized
INFO - 2022-06-18 06:30:37 --> Output Class Initialized
INFO - 2022-06-18 06:30:37 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:37 --> Input Class Initialized
INFO - 2022-06-18 06:30:37 --> Language Class Initialized
INFO - 2022-06-18 06:30:37 --> Language Class Initialized
INFO - 2022-06-18 06:30:37 --> Config Class Initialized
INFO - 2022-06-18 06:30:37 --> Loader Class Initialized
INFO - 2022-06-18 06:30:37 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:37 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:37 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:37 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:37 --> Controller Class Initialized
INFO - 2022-06-18 06:30:39 --> Config Class Initialized
INFO - 2022-06-18 06:30:39 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:39 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:39 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:39 --> URI Class Initialized
INFO - 2022-06-18 06:30:39 --> Router Class Initialized
INFO - 2022-06-18 06:30:39 --> Output Class Initialized
INFO - 2022-06-18 06:30:39 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:39 --> Input Class Initialized
INFO - 2022-06-18 06:30:39 --> Language Class Initialized
INFO - 2022-06-18 06:30:39 --> Language Class Initialized
INFO - 2022-06-18 06:30:39 --> Config Class Initialized
INFO - 2022-06-18 06:30:39 --> Loader Class Initialized
INFO - 2022-06-18 06:30:39 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:39 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:39 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:39 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:39 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:39 --> Controller Class Initialized
DEBUG - 2022-06-18 06:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2022-06-18 06:30:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 06:30:39 --> Final output sent to browser
DEBUG - 2022-06-18 06:30:39 --> Total execution time: 0.0468
INFO - 2022-06-18 06:30:41 --> Config Class Initialized
INFO - 2022-06-18 06:30:41 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:41 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:41 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:41 --> URI Class Initialized
INFO - 2022-06-18 06:30:41 --> Router Class Initialized
INFO - 2022-06-18 06:30:41 --> Output Class Initialized
INFO - 2022-06-18 06:30:41 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:41 --> Input Class Initialized
INFO - 2022-06-18 06:30:41 --> Language Class Initialized
INFO - 2022-06-18 06:30:41 --> Language Class Initialized
INFO - 2022-06-18 06:30:41 --> Config Class Initialized
INFO - 2022-06-18 06:30:41 --> Loader Class Initialized
INFO - 2022-06-18 06:30:41 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:41 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:41 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:41 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:41 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:41 --> Controller Class Initialized
INFO - 2022-06-18 06:30:43 --> Config Class Initialized
INFO - 2022-06-18 06:30:43 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:43 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:43 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:43 --> URI Class Initialized
INFO - 2022-06-18 06:30:43 --> Router Class Initialized
INFO - 2022-06-18 06:30:43 --> Output Class Initialized
INFO - 2022-06-18 06:30:43 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:43 --> Input Class Initialized
INFO - 2022-06-18 06:30:43 --> Language Class Initialized
INFO - 2022-06-18 06:30:43 --> Language Class Initialized
INFO - 2022-06-18 06:30:43 --> Config Class Initialized
INFO - 2022-06-18 06:30:43 --> Loader Class Initialized
INFO - 2022-06-18 06:30:43 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:43 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:43 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:43 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:43 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:43 --> Controller Class Initialized
INFO - 2022-06-18 06:30:45 --> Config Class Initialized
INFO - 2022-06-18 06:30:45 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:45 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:45 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:45 --> URI Class Initialized
INFO - 2022-06-18 06:30:45 --> Router Class Initialized
INFO - 2022-06-18 06:30:45 --> Output Class Initialized
INFO - 2022-06-18 06:30:45 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:45 --> Input Class Initialized
INFO - 2022-06-18 06:30:45 --> Language Class Initialized
INFO - 2022-06-18 06:30:45 --> Language Class Initialized
INFO - 2022-06-18 06:30:45 --> Config Class Initialized
INFO - 2022-06-18 06:30:45 --> Loader Class Initialized
INFO - 2022-06-18 06:30:45 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:45 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:45 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:45 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:45 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:45 --> Controller Class Initialized
INFO - 2022-06-18 06:30:47 --> Config Class Initialized
INFO - 2022-06-18 06:30:47 --> Hooks Class Initialized
DEBUG - 2022-06-18 06:30:47 --> UTF-8 Support Enabled
INFO - 2022-06-18 06:30:47 --> Utf8 Class Initialized
INFO - 2022-06-18 06:30:47 --> URI Class Initialized
INFO - 2022-06-18 06:30:47 --> Router Class Initialized
INFO - 2022-06-18 06:30:47 --> Output Class Initialized
INFO - 2022-06-18 06:30:47 --> Security Class Initialized
DEBUG - 2022-06-18 06:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 06:30:47 --> Input Class Initialized
INFO - 2022-06-18 06:30:47 --> Language Class Initialized
INFO - 2022-06-18 06:30:47 --> Language Class Initialized
INFO - 2022-06-18 06:30:47 --> Config Class Initialized
INFO - 2022-06-18 06:30:47 --> Loader Class Initialized
INFO - 2022-06-18 06:30:47 --> Helper loaded: url_helper
INFO - 2022-06-18 06:30:47 --> Helper loaded: file_helper
INFO - 2022-06-18 06:30:47 --> Helper loaded: form_helper
INFO - 2022-06-18 06:30:47 --> Helper loaded: my_helper
INFO - 2022-06-18 06:30:47 --> Database Driver Class Initialized
DEBUG - 2022-06-18 06:30:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 06:30:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 06:30:47 --> Controller Class Initialized
INFO - 2022-06-18 07:11:58 --> Config Class Initialized
INFO - 2022-06-18 07:11:58 --> Hooks Class Initialized
DEBUG - 2022-06-18 07:11:58 --> UTF-8 Support Enabled
INFO - 2022-06-18 07:11:58 --> Utf8 Class Initialized
INFO - 2022-06-18 07:11:58 --> URI Class Initialized
DEBUG - 2022-06-18 07:11:58 --> No URI present. Default controller set.
INFO - 2022-06-18 07:11:58 --> Router Class Initialized
INFO - 2022-06-18 07:11:58 --> Output Class Initialized
INFO - 2022-06-18 07:11:58 --> Security Class Initialized
DEBUG - 2022-06-18 07:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 07:11:58 --> Input Class Initialized
INFO - 2022-06-18 07:11:58 --> Language Class Initialized
INFO - 2022-06-18 07:11:58 --> Language Class Initialized
INFO - 2022-06-18 07:11:58 --> Config Class Initialized
INFO - 2022-06-18 07:11:58 --> Loader Class Initialized
INFO - 2022-06-18 07:11:58 --> Helper loaded: url_helper
INFO - 2022-06-18 07:11:58 --> Helper loaded: file_helper
INFO - 2022-06-18 07:11:58 --> Helper loaded: form_helper
INFO - 2022-06-18 07:11:58 --> Helper loaded: my_helper
INFO - 2022-06-18 07:11:58 --> Database Driver Class Initialized
DEBUG - 2022-06-18 07:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 07:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 07:11:58 --> Controller Class Initialized
INFO - 2022-06-18 07:11:58 --> Config Class Initialized
INFO - 2022-06-18 07:11:58 --> Hooks Class Initialized
DEBUG - 2022-06-18 07:11:58 --> UTF-8 Support Enabled
INFO - 2022-06-18 07:11:58 --> Utf8 Class Initialized
INFO - 2022-06-18 07:11:58 --> URI Class Initialized
INFO - 2022-06-18 07:11:58 --> Router Class Initialized
INFO - 2022-06-18 07:11:58 --> Output Class Initialized
INFO - 2022-06-18 07:11:58 --> Security Class Initialized
DEBUG - 2022-06-18 07:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 07:11:58 --> Input Class Initialized
INFO - 2022-06-18 07:11:58 --> Language Class Initialized
INFO - 2022-06-18 07:11:59 --> Language Class Initialized
INFO - 2022-06-18 07:11:59 --> Config Class Initialized
INFO - 2022-06-18 07:11:59 --> Loader Class Initialized
INFO - 2022-06-18 07:11:59 --> Helper loaded: url_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: file_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: form_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: my_helper
INFO - 2022-06-18 07:11:59 --> Database Driver Class Initialized
DEBUG - 2022-06-18 07:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 07:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 07:11:59 --> Controller Class Initialized
DEBUG - 2022-06-18 07:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 07:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 07:11:59 --> Final output sent to browser
DEBUG - 2022-06-18 07:11:59 --> Total execution time: 0.0385
INFO - 2022-06-18 07:11:59 --> Config Class Initialized
INFO - 2022-06-18 07:11:59 --> Hooks Class Initialized
DEBUG - 2022-06-18 07:11:59 --> UTF-8 Support Enabled
INFO - 2022-06-18 07:11:59 --> Utf8 Class Initialized
INFO - 2022-06-18 07:11:59 --> URI Class Initialized
DEBUG - 2022-06-18 07:11:59 --> No URI present. Default controller set.
INFO - 2022-06-18 07:11:59 --> Router Class Initialized
INFO - 2022-06-18 07:11:59 --> Output Class Initialized
INFO - 2022-06-18 07:11:59 --> Security Class Initialized
DEBUG - 2022-06-18 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 07:11:59 --> Input Class Initialized
INFO - 2022-06-18 07:11:59 --> Language Class Initialized
INFO - 2022-06-18 07:11:59 --> Language Class Initialized
INFO - 2022-06-18 07:11:59 --> Config Class Initialized
INFO - 2022-06-18 07:11:59 --> Loader Class Initialized
INFO - 2022-06-18 07:11:59 --> Helper loaded: url_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: file_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: form_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: my_helper
INFO - 2022-06-18 07:11:59 --> Database Driver Class Initialized
DEBUG - 2022-06-18 07:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 07:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 07:11:59 --> Controller Class Initialized
INFO - 2022-06-18 07:11:59 --> Config Class Initialized
INFO - 2022-06-18 07:11:59 --> Hooks Class Initialized
DEBUG - 2022-06-18 07:11:59 --> UTF-8 Support Enabled
INFO - 2022-06-18 07:11:59 --> Utf8 Class Initialized
INFO - 2022-06-18 07:11:59 --> URI Class Initialized
INFO - 2022-06-18 07:11:59 --> Router Class Initialized
INFO - 2022-06-18 07:11:59 --> Output Class Initialized
INFO - 2022-06-18 07:11:59 --> Security Class Initialized
DEBUG - 2022-06-18 07:11:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 07:11:59 --> Input Class Initialized
INFO - 2022-06-18 07:11:59 --> Language Class Initialized
INFO - 2022-06-18 07:11:59 --> Language Class Initialized
INFO - 2022-06-18 07:11:59 --> Config Class Initialized
INFO - 2022-06-18 07:11:59 --> Loader Class Initialized
INFO - 2022-06-18 07:11:59 --> Helper loaded: url_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: file_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: form_helper
INFO - 2022-06-18 07:11:59 --> Helper loaded: my_helper
INFO - 2022-06-18 07:11:59 --> Database Driver Class Initialized
DEBUG - 2022-06-18 07:11:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 07:11:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 07:11:59 --> Controller Class Initialized
DEBUG - 2022-06-18 07:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 07:11:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 07:11:59 --> Final output sent to browser
DEBUG - 2022-06-18 07:11:59 --> Total execution time: 0.0489
INFO - 2022-06-18 07:13:28 --> Config Class Initialized
INFO - 2022-06-18 07:13:28 --> Hooks Class Initialized
DEBUG - 2022-06-18 07:13:28 --> UTF-8 Support Enabled
INFO - 2022-06-18 07:13:28 --> Utf8 Class Initialized
INFO - 2022-06-18 07:13:28 --> URI Class Initialized
INFO - 2022-06-18 07:13:28 --> Router Class Initialized
INFO - 2022-06-18 07:13:28 --> Output Class Initialized
INFO - 2022-06-18 07:13:28 --> Security Class Initialized
DEBUG - 2022-06-18 07:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 07:13:28 --> Input Class Initialized
INFO - 2022-06-18 07:13:28 --> Language Class Initialized
INFO - 2022-06-18 07:13:28 --> Language Class Initialized
INFO - 2022-06-18 07:13:28 --> Config Class Initialized
INFO - 2022-06-18 07:13:28 --> Loader Class Initialized
INFO - 2022-06-18 07:13:28 --> Helper loaded: url_helper
INFO - 2022-06-18 07:13:28 --> Helper loaded: file_helper
INFO - 2022-06-18 07:13:28 --> Helper loaded: form_helper
INFO - 2022-06-18 07:13:28 --> Helper loaded: my_helper
INFO - 2022-06-18 07:13:28 --> Database Driver Class Initialized
DEBUG - 2022-06-18 07:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 07:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 07:13:28 --> Controller Class Initialized
INFO - 2022-06-18 07:13:28 --> Final output sent to browser
DEBUG - 2022-06-18 07:13:28 --> Total execution time: 0.0392
INFO - 2022-06-18 07:20:37 --> Config Class Initialized
INFO - 2022-06-18 07:20:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 07:20:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 07:20:37 --> Utf8 Class Initialized
INFO - 2022-06-18 07:20:37 --> URI Class Initialized
DEBUG - 2022-06-18 07:20:37 --> No URI present. Default controller set.
INFO - 2022-06-18 07:20:37 --> Router Class Initialized
INFO - 2022-06-18 07:20:37 --> Output Class Initialized
INFO - 2022-06-18 07:20:37 --> Security Class Initialized
DEBUG - 2022-06-18 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 07:20:37 --> Input Class Initialized
INFO - 2022-06-18 07:20:37 --> Language Class Initialized
INFO - 2022-06-18 07:20:37 --> Language Class Initialized
INFO - 2022-06-18 07:20:37 --> Config Class Initialized
INFO - 2022-06-18 07:20:37 --> Loader Class Initialized
INFO - 2022-06-18 07:20:37 --> Helper loaded: url_helper
INFO - 2022-06-18 07:20:37 --> Helper loaded: file_helper
INFO - 2022-06-18 07:20:37 --> Helper loaded: form_helper
INFO - 2022-06-18 07:20:37 --> Helper loaded: my_helper
INFO - 2022-06-18 07:20:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 07:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 07:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 07:20:37 --> Controller Class Initialized
INFO - 2022-06-18 07:20:37 --> Config Class Initialized
INFO - 2022-06-18 07:20:37 --> Hooks Class Initialized
DEBUG - 2022-06-18 07:20:37 --> UTF-8 Support Enabled
INFO - 2022-06-18 07:20:37 --> Utf8 Class Initialized
INFO - 2022-06-18 07:20:37 --> URI Class Initialized
INFO - 2022-06-18 07:20:37 --> Router Class Initialized
INFO - 2022-06-18 07:20:37 --> Output Class Initialized
INFO - 2022-06-18 07:20:37 --> Security Class Initialized
DEBUG - 2022-06-18 07:20:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-06-18 07:20:37 --> Input Class Initialized
INFO - 2022-06-18 07:20:37 --> Language Class Initialized
INFO - 2022-06-18 07:20:37 --> Language Class Initialized
INFO - 2022-06-18 07:20:37 --> Config Class Initialized
INFO - 2022-06-18 07:20:37 --> Loader Class Initialized
INFO - 2022-06-18 07:20:37 --> Helper loaded: url_helper
INFO - 2022-06-18 07:20:37 --> Helper loaded: file_helper
INFO - 2022-06-18 07:20:37 --> Helper loaded: form_helper
INFO - 2022-06-18 07:20:37 --> Helper loaded: my_helper
INFO - 2022-06-18 07:20:37 --> Database Driver Class Initialized
DEBUG - 2022-06-18 07:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-06-18 07:20:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-06-18 07:20:37 --> Controller Class Initialized
DEBUG - 2022-06-18 07:20:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-06-18 07:20:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-06-18 07:20:37 --> Final output sent to browser
DEBUG - 2022-06-18 07:20:37 --> Total execution time: 0.0388
