<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-21 03:11:07 --> Config Class Initialized
INFO - 2022-03-21 03:11:07 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:11:08 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:11:08 --> Utf8 Class Initialized
INFO - 2022-03-21 03:11:08 --> URI Class Initialized
DEBUG - 2022-03-21 03:11:08 --> No URI present. Default controller set.
INFO - 2022-03-21 03:11:08 --> Router Class Initialized
INFO - 2022-03-21 03:11:08 --> Output Class Initialized
INFO - 2022-03-21 03:11:08 --> Security Class Initialized
DEBUG - 2022-03-21 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:11:08 --> Input Class Initialized
INFO - 2022-03-21 03:11:08 --> Language Class Initialized
INFO - 2022-03-21 03:11:08 --> Language Class Initialized
INFO - 2022-03-21 03:11:08 --> Config Class Initialized
INFO - 2022-03-21 03:11:08 --> Loader Class Initialized
INFO - 2022-03-21 03:11:08 --> Helper loaded: url_helper
INFO - 2022-03-21 03:11:08 --> Helper loaded: file_helper
INFO - 2022-03-21 03:11:08 --> Helper loaded: form_helper
INFO - 2022-03-21 03:11:08 --> Helper loaded: my_helper
INFO - 2022-03-21 03:11:08 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:11:08 --> Controller Class Initialized
INFO - 2022-03-21 03:11:08 --> Config Class Initialized
INFO - 2022-03-21 03:11:08 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:11:08 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:11:08 --> Utf8 Class Initialized
INFO - 2022-03-21 03:11:08 --> URI Class Initialized
INFO - 2022-03-21 03:11:08 --> Router Class Initialized
INFO - 2022-03-21 03:11:08 --> Output Class Initialized
INFO - 2022-03-21 03:11:08 --> Security Class Initialized
DEBUG - 2022-03-21 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:11:08 --> Input Class Initialized
INFO - 2022-03-21 03:11:08 --> Language Class Initialized
INFO - 2022-03-21 03:11:08 --> Language Class Initialized
INFO - 2022-03-21 03:11:08 --> Config Class Initialized
INFO - 2022-03-21 03:11:08 --> Loader Class Initialized
INFO - 2022-03-21 03:11:08 --> Helper loaded: url_helper
INFO - 2022-03-21 03:11:08 --> Helper loaded: file_helper
INFO - 2022-03-21 03:11:08 --> Helper loaded: form_helper
INFO - 2022-03-21 03:11:08 --> Helper loaded: my_helper
INFO - 2022-03-21 03:11:08 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:11:08 --> Controller Class Initialized
DEBUG - 2022-03-21 03:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-03-21 03:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 03:11:08 --> Final output sent to browser
DEBUG - 2022-03-21 03:11:08 --> Total execution time: 0.1126
INFO - 2022-03-21 03:49:39 --> Config Class Initialized
INFO - 2022-03-21 03:49:39 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:49:39 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:49:39 --> Utf8 Class Initialized
INFO - 2022-03-21 03:49:39 --> URI Class Initialized
INFO - 2022-03-21 03:49:39 --> Router Class Initialized
INFO - 2022-03-21 03:49:39 --> Output Class Initialized
INFO - 2022-03-21 03:49:39 --> Security Class Initialized
DEBUG - 2022-03-21 03:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:49:39 --> Input Class Initialized
INFO - 2022-03-21 03:49:39 --> Language Class Initialized
INFO - 2022-03-21 03:49:39 --> Language Class Initialized
INFO - 2022-03-21 03:49:39 --> Config Class Initialized
INFO - 2022-03-21 03:49:39 --> Loader Class Initialized
INFO - 2022-03-21 03:49:39 --> Helper loaded: url_helper
INFO - 2022-03-21 03:49:39 --> Helper loaded: file_helper
INFO - 2022-03-21 03:49:39 --> Helper loaded: form_helper
INFO - 2022-03-21 03:49:39 --> Helper loaded: my_helper
INFO - 2022-03-21 03:49:39 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:49:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:49:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:49:39 --> Controller Class Initialized
INFO - 2022-03-21 03:49:39 --> Helper loaded: cookie_helper
INFO - 2022-03-21 03:49:39 --> Final output sent to browser
DEBUG - 2022-03-21 03:49:39 --> Total execution time: 0.1955
INFO - 2022-03-21 03:49:40 --> Config Class Initialized
INFO - 2022-03-21 03:49:40 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:49:40 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:49:40 --> Utf8 Class Initialized
INFO - 2022-03-21 03:49:40 --> URI Class Initialized
INFO - 2022-03-21 03:49:40 --> Router Class Initialized
INFO - 2022-03-21 03:49:40 --> Output Class Initialized
INFO - 2022-03-21 03:49:40 --> Security Class Initialized
DEBUG - 2022-03-21 03:49:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:49:40 --> Input Class Initialized
INFO - 2022-03-21 03:49:40 --> Language Class Initialized
INFO - 2022-03-21 03:49:40 --> Language Class Initialized
INFO - 2022-03-21 03:49:40 --> Config Class Initialized
INFO - 2022-03-21 03:49:40 --> Loader Class Initialized
INFO - 2022-03-21 03:49:40 --> Helper loaded: url_helper
INFO - 2022-03-21 03:49:40 --> Helper loaded: file_helper
INFO - 2022-03-21 03:49:40 --> Helper loaded: form_helper
INFO - 2022-03-21 03:49:40 --> Helper loaded: my_helper
INFO - 2022-03-21 03:49:40 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:49:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:49:40 --> Controller Class Initialized
DEBUG - 2022-03-21 03:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-03-21 03:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 03:49:41 --> Final output sent to browser
DEBUG - 2022-03-21 03:49:41 --> Total execution time: 1.6662
INFO - 2022-03-21 03:49:43 --> Config Class Initialized
INFO - 2022-03-21 03:49:43 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:49:43 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:49:43 --> Utf8 Class Initialized
INFO - 2022-03-21 03:49:43 --> URI Class Initialized
INFO - 2022-03-21 03:49:43 --> Router Class Initialized
INFO - 2022-03-21 03:49:43 --> Output Class Initialized
INFO - 2022-03-21 03:49:43 --> Security Class Initialized
DEBUG - 2022-03-21 03:49:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:49:43 --> Input Class Initialized
INFO - 2022-03-21 03:49:43 --> Language Class Initialized
INFO - 2022-03-21 03:49:43 --> Language Class Initialized
INFO - 2022-03-21 03:49:43 --> Config Class Initialized
INFO - 2022-03-21 03:49:43 --> Loader Class Initialized
INFO - 2022-03-21 03:49:43 --> Helper loaded: url_helper
INFO - 2022-03-21 03:49:43 --> Helper loaded: file_helper
INFO - 2022-03-21 03:49:43 --> Helper loaded: form_helper
INFO - 2022-03-21 03:49:43 --> Helper loaded: my_helper
INFO - 2022-03-21 03:49:43 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:49:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:49:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:49:43 --> Controller Class Initialized
ERROR - 2022-03-21 03:49:43 --> Query error: Unknown column 'a.mitra' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.mitra, a.lokasi, a.lama, a.keterangan
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2021','23',b.id)
                                                    WHERE c.id_kelas = '23' AND a.ta = '20211'
INFO - 2022-03-21 03:49:43 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-21 03:50:14 --> Config Class Initialized
INFO - 2022-03-21 03:50:14 --> Hooks Class Initialized
DEBUG - 2022-03-21 03:50:14 --> UTF-8 Support Enabled
INFO - 2022-03-21 03:50:14 --> Utf8 Class Initialized
INFO - 2022-03-21 03:50:14 --> URI Class Initialized
INFO - 2022-03-21 03:50:14 --> Router Class Initialized
INFO - 2022-03-21 03:50:14 --> Output Class Initialized
INFO - 2022-03-21 03:50:14 --> Security Class Initialized
DEBUG - 2022-03-21 03:50:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 03:50:14 --> Input Class Initialized
INFO - 2022-03-21 03:50:14 --> Language Class Initialized
INFO - 2022-03-21 03:50:14 --> Language Class Initialized
INFO - 2022-03-21 03:50:14 --> Config Class Initialized
INFO - 2022-03-21 03:50:14 --> Loader Class Initialized
INFO - 2022-03-21 03:50:14 --> Helper loaded: url_helper
INFO - 2022-03-21 03:50:14 --> Helper loaded: file_helper
INFO - 2022-03-21 03:50:14 --> Helper loaded: form_helper
INFO - 2022-03-21 03:50:14 --> Helper loaded: my_helper
INFO - 2022-03-21 03:50:14 --> Database Driver Class Initialized
DEBUG - 2022-03-21 03:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 03:50:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 03:50:14 --> Controller Class Initialized
DEBUG - 2022-03-21 03:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-03-21 03:50:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 03:50:15 --> Final output sent to browser
DEBUG - 2022-03-21 03:50:15 --> Total execution time: 1.1200
INFO - 2022-03-21 04:26:55 --> Config Class Initialized
INFO - 2022-03-21 04:26:55 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:26:55 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:26:55 --> Utf8 Class Initialized
INFO - 2022-03-21 04:26:55 --> URI Class Initialized
INFO - 2022-03-21 04:26:55 --> Router Class Initialized
INFO - 2022-03-21 04:26:55 --> Output Class Initialized
INFO - 2022-03-21 04:26:55 --> Security Class Initialized
DEBUG - 2022-03-21 04:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:26:55 --> Input Class Initialized
INFO - 2022-03-21 04:26:55 --> Language Class Initialized
INFO - 2022-03-21 04:26:55 --> Language Class Initialized
INFO - 2022-03-21 04:26:55 --> Config Class Initialized
INFO - 2022-03-21 04:26:55 --> Loader Class Initialized
INFO - 2022-03-21 04:26:55 --> Helper loaded: url_helper
INFO - 2022-03-21 04:26:55 --> Helper loaded: file_helper
INFO - 2022-03-21 04:26:55 --> Helper loaded: form_helper
INFO - 2022-03-21 04:26:55 --> Helper loaded: my_helper
INFO - 2022-03-21 04:26:55 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:26:55 --> Controller Class Initialized
DEBUG - 2022-03-21 04:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2022-03-21 04:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 04:26:55 --> Final output sent to browser
DEBUG - 2022-03-21 04:26:55 --> Total execution time: 0.1312
INFO - 2022-03-21 04:26:58 --> Config Class Initialized
INFO - 2022-03-21 04:26:58 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:26:58 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:26:58 --> Utf8 Class Initialized
INFO - 2022-03-21 04:26:58 --> URI Class Initialized
INFO - 2022-03-21 04:26:58 --> Router Class Initialized
INFO - 2022-03-21 04:26:58 --> Output Class Initialized
INFO - 2022-03-21 04:26:58 --> Security Class Initialized
DEBUG - 2022-03-21 04:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:26:58 --> Input Class Initialized
INFO - 2022-03-21 04:26:58 --> Language Class Initialized
INFO - 2022-03-21 04:26:58 --> Language Class Initialized
INFO - 2022-03-21 04:26:58 --> Config Class Initialized
INFO - 2022-03-21 04:26:58 --> Loader Class Initialized
INFO - 2022-03-21 04:26:58 --> Helper loaded: url_helper
INFO - 2022-03-21 04:26:58 --> Helper loaded: file_helper
INFO - 2022-03-21 04:26:58 --> Helper loaded: form_helper
INFO - 2022-03-21 04:26:58 --> Helper loaded: my_helper
INFO - 2022-03-21 04:26:58 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:26:58 --> Controller Class Initialized
DEBUG - 2022-03-21 04:26:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2022-03-21 04:26:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 04:26:58 --> Final output sent to browser
DEBUG - 2022-03-21 04:26:58 --> Total execution time: 0.1265
INFO - 2022-03-21 04:26:59 --> Config Class Initialized
INFO - 2022-03-21 04:26:59 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:26:59 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:26:59 --> Utf8 Class Initialized
INFO - 2022-03-21 04:26:59 --> URI Class Initialized
INFO - 2022-03-21 04:26:59 --> Router Class Initialized
INFO - 2022-03-21 04:26:59 --> Output Class Initialized
INFO - 2022-03-21 04:26:59 --> Security Class Initialized
DEBUG - 2022-03-21 04:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:26:59 --> Input Class Initialized
INFO - 2022-03-21 04:26:59 --> Language Class Initialized
INFO - 2022-03-21 04:26:59 --> Language Class Initialized
INFO - 2022-03-21 04:26:59 --> Config Class Initialized
INFO - 2022-03-21 04:26:59 --> Loader Class Initialized
INFO - 2022-03-21 04:26:59 --> Helper loaded: url_helper
INFO - 2022-03-21 04:26:59 --> Helper loaded: file_helper
INFO - 2022-03-21 04:27:00 --> Helper loaded: form_helper
INFO - 2022-03-21 04:27:00 --> Helper loaded: my_helper
INFO - 2022-03-21 04:27:00 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:27:00 --> Controller Class Initialized
DEBUG - 2022-03-21 04:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-03-21 04:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 04:27:00 --> Final output sent to browser
DEBUG - 2022-03-21 04:27:00 --> Total execution time: 0.1281
INFO - 2022-03-21 04:27:01 --> Config Class Initialized
INFO - 2022-03-21 04:27:01 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:27:01 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:27:01 --> Utf8 Class Initialized
INFO - 2022-03-21 04:27:01 --> URI Class Initialized
INFO - 2022-03-21 04:27:01 --> Router Class Initialized
INFO - 2022-03-21 04:27:01 --> Output Class Initialized
INFO - 2022-03-21 04:27:01 --> Security Class Initialized
DEBUG - 2022-03-21 04:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:27:01 --> Input Class Initialized
INFO - 2022-03-21 04:27:01 --> Language Class Initialized
INFO - 2022-03-21 04:27:01 --> Language Class Initialized
INFO - 2022-03-21 04:27:01 --> Config Class Initialized
INFO - 2022-03-21 04:27:01 --> Loader Class Initialized
INFO - 2022-03-21 04:27:01 --> Helper loaded: url_helper
INFO - 2022-03-21 04:27:01 --> Helper loaded: file_helper
INFO - 2022-03-21 04:27:01 --> Helper loaded: form_helper
INFO - 2022-03-21 04:27:01 --> Helper loaded: my_helper
INFO - 2022-03-21 04:27:01 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:27:01 --> Controller Class Initialized
ERROR - 2022-03-21 04:27:01 --> Query error: Unknown column 'a.mitra' in 'field list' - Invalid query: SELECT 
                                                    a.*, b.nama, a.mitra, a.lokasi, a.lama, a.keterangan
                                                    FROM t_nilai_ekstra a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2021','23',b.id)
                                                    WHERE c.id_kelas = '23' AND a.ta = '20211'
INFO - 2022-03-21 04:27:01 --> Language file loaded: language/english/db_lang.php
INFO - 2022-03-21 04:27:02 --> Config Class Initialized
INFO - 2022-03-21 04:27:02 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:27:02 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:27:02 --> Utf8 Class Initialized
INFO - 2022-03-21 04:27:02 --> URI Class Initialized
INFO - 2022-03-21 04:27:02 --> Router Class Initialized
INFO - 2022-03-21 04:27:02 --> Output Class Initialized
INFO - 2022-03-21 04:27:02 --> Security Class Initialized
DEBUG - 2022-03-21 04:27:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:27:02 --> Input Class Initialized
INFO - 2022-03-21 04:27:02 --> Language Class Initialized
INFO - 2022-03-21 04:27:02 --> Language Class Initialized
INFO - 2022-03-21 04:27:02 --> Config Class Initialized
INFO - 2022-03-21 04:27:02 --> Loader Class Initialized
INFO - 2022-03-21 04:27:02 --> Helper loaded: url_helper
INFO - 2022-03-21 04:27:02 --> Helper loaded: file_helper
INFO - 2022-03-21 04:27:02 --> Helper loaded: form_helper
INFO - 2022-03-21 04:27:02 --> Helper loaded: my_helper
INFO - 2022-03-21 04:27:02 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:27:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:27:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:27:02 --> Controller Class Initialized
DEBUG - 2022-03-21 04:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2022-03-21 04:27:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 04:27:02 --> Final output sent to browser
DEBUG - 2022-03-21 04:27:02 --> Total execution time: 0.0553
INFO - 2022-03-21 04:27:03 --> Config Class Initialized
INFO - 2022-03-21 04:27:03 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:27:03 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:27:03 --> Utf8 Class Initialized
INFO - 2022-03-21 04:27:03 --> URI Class Initialized
INFO - 2022-03-21 04:27:03 --> Router Class Initialized
INFO - 2022-03-21 04:27:03 --> Output Class Initialized
INFO - 2022-03-21 04:27:03 --> Security Class Initialized
DEBUG - 2022-03-21 04:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:27:03 --> Input Class Initialized
INFO - 2022-03-21 04:27:03 --> Language Class Initialized
INFO - 2022-03-21 04:27:03 --> Language Class Initialized
INFO - 2022-03-21 04:27:03 --> Config Class Initialized
INFO - 2022-03-21 04:27:03 --> Loader Class Initialized
INFO - 2022-03-21 04:27:03 --> Helper loaded: url_helper
INFO - 2022-03-21 04:27:03 --> Helper loaded: file_helper
INFO - 2022-03-21 04:27:03 --> Helper loaded: form_helper
INFO - 2022-03-21 04:27:03 --> Helper loaded: my_helper
INFO - 2022-03-21 04:27:03 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:27:03 --> Controller Class Initialized
DEBUG - 2022-03-21 04:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2022-03-21 04:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 04:27:03 --> Final output sent to browser
DEBUG - 2022-03-21 04:27:03 --> Total execution time: 0.1159
INFO - 2022-03-21 04:27:05 --> Config Class Initialized
INFO - 2022-03-21 04:27:05 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:27:05 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:27:05 --> Utf8 Class Initialized
INFO - 2022-03-21 04:27:05 --> URI Class Initialized
INFO - 2022-03-21 04:27:05 --> Router Class Initialized
INFO - 2022-03-21 04:27:05 --> Output Class Initialized
INFO - 2022-03-21 04:27:05 --> Security Class Initialized
DEBUG - 2022-03-21 04:27:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:27:05 --> Input Class Initialized
INFO - 2022-03-21 04:27:05 --> Language Class Initialized
INFO - 2022-03-21 04:27:05 --> Language Class Initialized
INFO - 2022-03-21 04:27:05 --> Config Class Initialized
INFO - 2022-03-21 04:27:05 --> Loader Class Initialized
INFO - 2022-03-21 04:27:05 --> Helper loaded: url_helper
INFO - 2022-03-21 04:27:05 --> Helper loaded: file_helper
INFO - 2022-03-21 04:27:05 --> Helper loaded: form_helper
INFO - 2022-03-21 04:27:05 --> Helper loaded: my_helper
INFO - 2022-03-21 04:27:05 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:27:05 --> Controller Class Initialized
DEBUG - 2022-03-21 04:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2022-03-21 04:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 04:27:05 --> Final output sent to browser
DEBUG - 2022-03-21 04:27:05 --> Total execution time: 0.1869
INFO - 2022-03-21 04:27:24 --> Config Class Initialized
INFO - 2022-03-21 04:27:24 --> Hooks Class Initialized
DEBUG - 2022-03-21 04:27:24 --> UTF-8 Support Enabled
INFO - 2022-03-21 04:27:24 --> Utf8 Class Initialized
INFO - 2022-03-21 04:27:24 --> URI Class Initialized
INFO - 2022-03-21 04:27:24 --> Router Class Initialized
INFO - 2022-03-21 04:27:24 --> Output Class Initialized
INFO - 2022-03-21 04:27:24 --> Security Class Initialized
DEBUG - 2022-03-21 04:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-21 04:27:24 --> Input Class Initialized
INFO - 2022-03-21 04:27:24 --> Language Class Initialized
INFO - 2022-03-21 04:27:24 --> Language Class Initialized
INFO - 2022-03-21 04:27:24 --> Config Class Initialized
INFO - 2022-03-21 04:27:24 --> Loader Class Initialized
INFO - 2022-03-21 04:27:24 --> Helper loaded: url_helper
INFO - 2022-03-21 04:27:24 --> Helper loaded: file_helper
INFO - 2022-03-21 04:27:24 --> Helper loaded: form_helper
INFO - 2022-03-21 04:27:24 --> Helper loaded: my_helper
INFO - 2022-03-21 04:27:24 --> Database Driver Class Initialized
DEBUG - 2022-03-21 04:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-21 04:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-21 04:27:24 --> Controller Class Initialized
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: mitra C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 38
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lokasi C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 41
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: lama C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 45
ERROR - 2022-03-21 04:27:24 --> Severity: Notice --> Undefined index: keterangan C:\xampp\htdocs\nilai\application\modules\n_ekstra\views\list.php 50
DEBUG - 2022-03-21 04:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2022-03-21 04:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-21 04:27:24 --> Final output sent to browser
DEBUG - 2022-03-21 04:27:24 --> Total execution time: 0.2399
