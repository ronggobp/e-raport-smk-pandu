<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-15 03:25:41 --> Config Class Initialized
INFO - 2020-12-15 03:25:41 --> Hooks Class Initialized
DEBUG - 2020-12-15 03:25:41 --> UTF-8 Support Enabled
INFO - 2020-12-15 03:25:41 --> Utf8 Class Initialized
INFO - 2020-12-15 03:25:41 --> URI Class Initialized
DEBUG - 2020-12-15 03:25:41 --> No URI present. Default controller set.
INFO - 2020-12-15 03:25:41 --> Router Class Initialized
INFO - 2020-12-15 03:25:42 --> Output Class Initialized
INFO - 2020-12-15 03:25:42 --> Security Class Initialized
DEBUG - 2020-12-15 03:25:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 03:25:42 --> Input Class Initialized
INFO - 2020-12-15 03:25:42 --> Language Class Initialized
INFO - 2020-12-15 03:25:42 --> Language Class Initialized
INFO - 2020-12-15 03:25:42 --> Config Class Initialized
INFO - 2020-12-15 03:25:42 --> Loader Class Initialized
INFO - 2020-12-15 03:25:42 --> Helper loaded: url_helper
INFO - 2020-12-15 03:25:42 --> Helper loaded: file_helper
INFO - 2020-12-15 03:25:42 --> Helper loaded: form_helper
INFO - 2020-12-15 03:25:42 --> Helper loaded: my_helper
INFO - 2020-12-15 03:25:42 --> Database Driver Class Initialized
DEBUG - 2020-12-15 03:25:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 03:25:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 03:25:42 --> Controller Class Initialized
INFO - 2020-12-15 03:25:43 --> Config Class Initialized
INFO - 2020-12-15 03:25:43 --> Hooks Class Initialized
DEBUG - 2020-12-15 03:25:43 --> UTF-8 Support Enabled
INFO - 2020-12-15 03:25:43 --> Utf8 Class Initialized
INFO - 2020-12-15 03:25:43 --> URI Class Initialized
INFO - 2020-12-15 03:25:43 --> Router Class Initialized
INFO - 2020-12-15 03:25:43 --> Output Class Initialized
INFO - 2020-12-15 03:25:43 --> Security Class Initialized
DEBUG - 2020-12-15 03:25:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 03:25:43 --> Input Class Initialized
INFO - 2020-12-15 03:25:43 --> Language Class Initialized
INFO - 2020-12-15 03:25:43 --> Language Class Initialized
INFO - 2020-12-15 03:25:43 --> Config Class Initialized
INFO - 2020-12-15 03:25:43 --> Loader Class Initialized
INFO - 2020-12-15 03:25:43 --> Helper loaded: url_helper
INFO - 2020-12-15 03:25:43 --> Helper loaded: file_helper
INFO - 2020-12-15 03:25:43 --> Helper loaded: form_helper
INFO - 2020-12-15 03:25:43 --> Helper loaded: my_helper
INFO - 2020-12-15 03:25:43 --> Database Driver Class Initialized
DEBUG - 2020-12-15 03:25:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 03:25:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 03:25:43 --> Controller Class Initialized
DEBUG - 2020-12-15 03:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-15 03:25:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-15 03:25:43 --> Final output sent to browser
DEBUG - 2020-12-15 03:25:43 --> Total execution time: 0.5111
INFO - 2020-12-15 03:26:14 --> Config Class Initialized
INFO - 2020-12-15 03:26:14 --> Hooks Class Initialized
DEBUG - 2020-12-15 03:26:14 --> UTF-8 Support Enabled
INFO - 2020-12-15 03:26:14 --> Utf8 Class Initialized
INFO - 2020-12-15 03:26:14 --> URI Class Initialized
INFO - 2020-12-15 03:26:14 --> Router Class Initialized
INFO - 2020-12-15 03:26:14 --> Output Class Initialized
INFO - 2020-12-15 03:26:14 --> Security Class Initialized
DEBUG - 2020-12-15 03:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 03:26:14 --> Input Class Initialized
INFO - 2020-12-15 03:26:14 --> Language Class Initialized
INFO - 2020-12-15 03:26:14 --> Language Class Initialized
INFO - 2020-12-15 03:26:14 --> Config Class Initialized
INFO - 2020-12-15 03:26:14 --> Loader Class Initialized
INFO - 2020-12-15 03:26:14 --> Helper loaded: url_helper
INFO - 2020-12-15 03:26:14 --> Helper loaded: file_helper
INFO - 2020-12-15 03:26:14 --> Helper loaded: form_helper
INFO - 2020-12-15 03:26:14 --> Helper loaded: my_helper
INFO - 2020-12-15 03:26:14 --> Database Driver Class Initialized
DEBUG - 2020-12-15 03:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 03:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 03:26:14 --> Controller Class Initialized
INFO - 2020-12-15 03:26:14 --> Helper loaded: cookie_helper
INFO - 2020-12-15 03:26:14 --> Final output sent to browser
DEBUG - 2020-12-15 03:26:14 --> Total execution time: 0.2623
INFO - 2020-12-15 03:26:15 --> Config Class Initialized
INFO - 2020-12-15 03:26:15 --> Hooks Class Initialized
DEBUG - 2020-12-15 03:26:15 --> UTF-8 Support Enabled
INFO - 2020-12-15 03:26:15 --> Utf8 Class Initialized
INFO - 2020-12-15 03:26:15 --> URI Class Initialized
INFO - 2020-12-15 03:26:15 --> Router Class Initialized
INFO - 2020-12-15 03:26:15 --> Output Class Initialized
INFO - 2020-12-15 03:26:15 --> Security Class Initialized
DEBUG - 2020-12-15 03:26:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 03:26:15 --> Input Class Initialized
INFO - 2020-12-15 03:26:15 --> Language Class Initialized
INFO - 2020-12-15 03:26:15 --> Language Class Initialized
INFO - 2020-12-15 03:26:15 --> Config Class Initialized
INFO - 2020-12-15 03:26:15 --> Loader Class Initialized
INFO - 2020-12-15 03:26:15 --> Helper loaded: url_helper
INFO - 2020-12-15 03:26:15 --> Helper loaded: file_helper
INFO - 2020-12-15 03:26:15 --> Helper loaded: form_helper
INFO - 2020-12-15 03:26:15 --> Helper loaded: my_helper
INFO - 2020-12-15 03:26:15 --> Database Driver Class Initialized
DEBUG - 2020-12-15 03:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 03:26:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 03:26:15 --> Controller Class Initialized
DEBUG - 2020-12-15 03:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-15 03:26:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-15 03:26:15 --> Final output sent to browser
DEBUG - 2020-12-15 03:26:15 --> Total execution time: 0.2861
INFO - 2020-12-15 03:26:21 --> Config Class Initialized
INFO - 2020-12-15 03:26:21 --> Hooks Class Initialized
DEBUG - 2020-12-15 03:26:21 --> UTF-8 Support Enabled
INFO - 2020-12-15 03:26:21 --> Utf8 Class Initialized
INFO - 2020-12-15 03:26:21 --> URI Class Initialized
INFO - 2020-12-15 03:26:21 --> Router Class Initialized
INFO - 2020-12-15 03:26:21 --> Output Class Initialized
INFO - 2020-12-15 03:26:21 --> Security Class Initialized
DEBUG - 2020-12-15 03:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 03:26:21 --> Input Class Initialized
INFO - 2020-12-15 03:26:21 --> Language Class Initialized
INFO - 2020-12-15 03:26:21 --> Language Class Initialized
INFO - 2020-12-15 03:26:21 --> Config Class Initialized
INFO - 2020-12-15 03:26:21 --> Loader Class Initialized
INFO - 2020-12-15 03:26:21 --> Helper loaded: url_helper
INFO - 2020-12-15 03:26:21 --> Helper loaded: file_helper
INFO - 2020-12-15 03:26:21 --> Helper loaded: form_helper
INFO - 2020-12-15 03:26:21 --> Helper loaded: my_helper
INFO - 2020-12-15 03:26:21 --> Database Driver Class Initialized
DEBUG - 2020-12-15 03:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 03:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 03:26:21 --> Controller Class Initialized
DEBUG - 2020-12-15 03:26:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-15 03:26:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-15 03:26:21 --> Final output sent to browser
DEBUG - 2020-12-15 03:26:21 --> Total execution time: 0.2395
INFO - 2020-12-15 03:26:22 --> Config Class Initialized
INFO - 2020-12-15 03:26:22 --> Hooks Class Initialized
DEBUG - 2020-12-15 03:26:22 --> UTF-8 Support Enabled
INFO - 2020-12-15 03:26:22 --> Utf8 Class Initialized
INFO - 2020-12-15 03:26:22 --> URI Class Initialized
INFO - 2020-12-15 03:26:22 --> Router Class Initialized
INFO - 2020-12-15 03:26:22 --> Output Class Initialized
INFO - 2020-12-15 03:26:22 --> Security Class Initialized
DEBUG - 2020-12-15 03:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 03:26:22 --> Input Class Initialized
INFO - 2020-12-15 03:26:22 --> Language Class Initialized
INFO - 2020-12-15 03:26:22 --> Language Class Initialized
INFO - 2020-12-15 03:26:22 --> Config Class Initialized
INFO - 2020-12-15 03:26:22 --> Loader Class Initialized
INFO - 2020-12-15 03:26:22 --> Helper loaded: url_helper
INFO - 2020-12-15 03:26:22 --> Helper loaded: file_helper
INFO - 2020-12-15 03:26:22 --> Helper loaded: form_helper
INFO - 2020-12-15 03:26:22 --> Helper loaded: my_helper
INFO - 2020-12-15 03:26:22 --> Database Driver Class Initialized
DEBUG - 2020-12-15 03:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 03:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 03:26:22 --> Controller Class Initialized
DEBUG - 2020-12-15 03:26:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-12-15 03:26:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-15 03:26:22 --> Final output sent to browser
DEBUG - 2020-12-15 03:26:22 --> Total execution time: 0.2826
INFO - 2020-12-15 03:26:24 --> Config Class Initialized
INFO - 2020-12-15 03:26:24 --> Hooks Class Initialized
DEBUG - 2020-12-15 03:26:25 --> UTF-8 Support Enabled
INFO - 2020-12-15 03:26:25 --> Utf8 Class Initialized
INFO - 2020-12-15 03:26:25 --> URI Class Initialized
INFO - 2020-12-15 03:26:25 --> Router Class Initialized
INFO - 2020-12-15 03:26:25 --> Output Class Initialized
INFO - 2020-12-15 03:26:25 --> Security Class Initialized
DEBUG - 2020-12-15 03:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 03:26:25 --> Input Class Initialized
INFO - 2020-12-15 03:26:25 --> Language Class Initialized
INFO - 2020-12-15 03:26:25 --> Language Class Initialized
INFO - 2020-12-15 03:26:25 --> Config Class Initialized
INFO - 2020-12-15 03:26:25 --> Loader Class Initialized
INFO - 2020-12-15 03:26:25 --> Helper loaded: url_helper
INFO - 2020-12-15 03:26:25 --> Helper loaded: file_helper
INFO - 2020-12-15 03:26:25 --> Helper loaded: form_helper
INFO - 2020-12-15 03:26:25 --> Helper loaded: my_helper
INFO - 2020-12-15 03:26:25 --> Database Driver Class Initialized
DEBUG - 2020-12-15 03:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 03:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 03:26:25 --> Controller Class Initialized
ERROR - 2020-12-15 03:26:25 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-15 04:00:20 --> Config Class Initialized
INFO - 2020-12-15 04:00:20 --> Hooks Class Initialized
DEBUG - 2020-12-15 04:00:20 --> UTF-8 Support Enabled
INFO - 2020-12-15 04:00:20 --> Utf8 Class Initialized
INFO - 2020-12-15 04:00:20 --> URI Class Initialized
INFO - 2020-12-15 04:00:20 --> Router Class Initialized
INFO - 2020-12-15 04:00:20 --> Output Class Initialized
INFO - 2020-12-15 04:00:20 --> Security Class Initialized
DEBUG - 2020-12-15 04:00:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 04:00:20 --> Input Class Initialized
INFO - 2020-12-15 04:00:20 --> Language Class Initialized
INFO - 2020-12-15 04:00:20 --> Language Class Initialized
INFO - 2020-12-15 04:00:20 --> Config Class Initialized
INFO - 2020-12-15 04:00:20 --> Loader Class Initialized
INFO - 2020-12-15 04:00:20 --> Helper loaded: url_helper
INFO - 2020-12-15 04:00:20 --> Helper loaded: file_helper
INFO - 2020-12-15 04:00:21 --> Helper loaded: form_helper
INFO - 2020-12-15 04:00:21 --> Helper loaded: my_helper
INFO - 2020-12-15 04:00:21 --> Database Driver Class Initialized
DEBUG - 2020-12-15 04:00:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 04:00:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 04:00:21 --> Controller Class Initialized
ERROR - 2020-12-15 04:00:21 --> Severity: Parsing Error --> syntax error, unexpected end of file C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 84
INFO - 2020-12-15 07:46:39 --> Config Class Initialized
INFO - 2020-12-15 07:46:39 --> Hooks Class Initialized
DEBUG - 2020-12-15 07:46:39 --> UTF-8 Support Enabled
INFO - 2020-12-15 07:46:39 --> Utf8 Class Initialized
INFO - 2020-12-15 07:46:39 --> URI Class Initialized
DEBUG - 2020-12-15 07:46:39 --> No URI present. Default controller set.
INFO - 2020-12-15 07:46:39 --> Router Class Initialized
INFO - 2020-12-15 07:46:39 --> Output Class Initialized
INFO - 2020-12-15 07:46:39 --> Security Class Initialized
DEBUG - 2020-12-15 07:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 07:46:39 --> Input Class Initialized
INFO - 2020-12-15 07:46:39 --> Language Class Initialized
INFO - 2020-12-15 07:46:39 --> Language Class Initialized
INFO - 2020-12-15 07:46:39 --> Config Class Initialized
INFO - 2020-12-15 07:46:39 --> Loader Class Initialized
INFO - 2020-12-15 07:46:39 --> Helper loaded: url_helper
INFO - 2020-12-15 07:46:39 --> Helper loaded: file_helper
INFO - 2020-12-15 07:46:39 --> Helper loaded: form_helper
INFO - 2020-12-15 07:46:39 --> Helper loaded: my_helper
INFO - 2020-12-15 07:46:39 --> Database Driver Class Initialized
DEBUG - 2020-12-15 07:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 07:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 07:46:39 --> Controller Class Initialized
INFO - 2020-12-15 07:46:39 --> Config Class Initialized
INFO - 2020-12-15 07:46:39 --> Hooks Class Initialized
DEBUG - 2020-12-15 07:46:39 --> UTF-8 Support Enabled
INFO - 2020-12-15 07:46:39 --> Utf8 Class Initialized
INFO - 2020-12-15 07:46:39 --> URI Class Initialized
INFO - 2020-12-15 07:46:39 --> Router Class Initialized
INFO - 2020-12-15 07:46:39 --> Output Class Initialized
INFO - 2020-12-15 07:46:39 --> Security Class Initialized
DEBUG - 2020-12-15 07:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-15 07:46:39 --> Input Class Initialized
INFO - 2020-12-15 07:46:39 --> Language Class Initialized
INFO - 2020-12-15 07:46:39 --> Language Class Initialized
INFO - 2020-12-15 07:46:39 --> Config Class Initialized
INFO - 2020-12-15 07:46:39 --> Loader Class Initialized
INFO - 2020-12-15 07:46:39 --> Helper loaded: url_helper
INFO - 2020-12-15 07:46:39 --> Helper loaded: file_helper
INFO - 2020-12-15 07:46:39 --> Helper loaded: form_helper
INFO - 2020-12-15 07:46:39 --> Helper loaded: my_helper
INFO - 2020-12-15 07:46:39 --> Database Driver Class Initialized
DEBUG - 2020-12-15 07:46:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-15 07:46:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-15 07:46:39 --> Controller Class Initialized
DEBUG - 2020-12-15 07:46:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-15 07:46:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-15 07:46:39 --> Final output sent to browser
DEBUG - 2020-12-15 07:46:39 --> Total execution time: 0.1983
