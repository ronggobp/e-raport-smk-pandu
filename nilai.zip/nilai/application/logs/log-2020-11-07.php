<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-07 01:09:07 --> Config Class Initialized
INFO - 2020-11-07 01:09:07 --> Hooks Class Initialized
DEBUG - 2020-11-07 01:09:07 --> UTF-8 Support Enabled
INFO - 2020-11-07 01:09:07 --> Utf8 Class Initialized
INFO - 2020-11-07 01:09:07 --> URI Class Initialized
DEBUG - 2020-11-07 01:09:07 --> No URI present. Default controller set.
INFO - 2020-11-07 01:09:08 --> Router Class Initialized
INFO - 2020-11-07 01:09:08 --> Output Class Initialized
INFO - 2020-11-07 01:09:08 --> Security Class Initialized
DEBUG - 2020-11-07 01:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 01:09:08 --> Input Class Initialized
INFO - 2020-11-07 01:09:08 --> Language Class Initialized
INFO - 2020-11-07 01:09:08 --> Language Class Initialized
INFO - 2020-11-07 01:09:08 --> Config Class Initialized
INFO - 2020-11-07 01:09:08 --> Loader Class Initialized
INFO - 2020-11-07 01:09:08 --> Helper loaded: url_helper
INFO - 2020-11-07 01:09:08 --> Helper loaded: file_helper
INFO - 2020-11-07 01:09:08 --> Helper loaded: form_helper
INFO - 2020-11-07 01:09:08 --> Helper loaded: my_helper
INFO - 2020-11-07 01:09:08 --> Database Driver Class Initialized
DEBUG - 2020-11-07 01:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-07 01:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-07 01:09:08 --> Controller Class Initialized
INFO - 2020-11-07 01:09:08 --> Config Class Initialized
INFO - 2020-11-07 01:09:08 --> Hooks Class Initialized
DEBUG - 2020-11-07 01:09:09 --> UTF-8 Support Enabled
INFO - 2020-11-07 01:09:09 --> Utf8 Class Initialized
INFO - 2020-11-07 01:09:09 --> URI Class Initialized
INFO - 2020-11-07 01:09:09 --> Router Class Initialized
INFO - 2020-11-07 01:09:09 --> Output Class Initialized
INFO - 2020-11-07 01:09:09 --> Security Class Initialized
DEBUG - 2020-11-07 01:09:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 01:09:09 --> Input Class Initialized
INFO - 2020-11-07 01:09:09 --> Language Class Initialized
INFO - 2020-11-07 01:09:09 --> Language Class Initialized
INFO - 2020-11-07 01:09:09 --> Config Class Initialized
INFO - 2020-11-07 01:09:09 --> Loader Class Initialized
INFO - 2020-11-07 01:09:09 --> Helper loaded: url_helper
INFO - 2020-11-07 01:09:09 --> Helper loaded: file_helper
INFO - 2020-11-07 01:09:09 --> Helper loaded: form_helper
INFO - 2020-11-07 01:09:09 --> Helper loaded: my_helper
INFO - 2020-11-07 01:09:09 --> Database Driver Class Initialized
DEBUG - 2020-11-07 01:09:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-07 01:09:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-07 01:09:09 --> Controller Class Initialized
DEBUG - 2020-11-07 01:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-07 01:09:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-07 01:09:09 --> Final output sent to browser
DEBUG - 2020-11-07 01:09:09 --> Total execution time: 0.4478
INFO - 2020-11-07 01:09:18 --> Config Class Initialized
INFO - 2020-11-07 01:09:18 --> Hooks Class Initialized
DEBUG - 2020-11-07 01:09:18 --> UTF-8 Support Enabled
INFO - 2020-11-07 01:09:18 --> Utf8 Class Initialized
INFO - 2020-11-07 01:09:18 --> URI Class Initialized
INFO - 2020-11-07 01:09:18 --> Router Class Initialized
INFO - 2020-11-07 01:09:18 --> Output Class Initialized
INFO - 2020-11-07 01:09:18 --> Security Class Initialized
DEBUG - 2020-11-07 01:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 01:09:18 --> Input Class Initialized
INFO - 2020-11-07 01:09:18 --> Language Class Initialized
INFO - 2020-11-07 01:09:18 --> Language Class Initialized
INFO - 2020-11-07 01:09:18 --> Config Class Initialized
INFO - 2020-11-07 01:09:18 --> Loader Class Initialized
INFO - 2020-11-07 01:09:18 --> Helper loaded: url_helper
INFO - 2020-11-07 01:09:18 --> Helper loaded: file_helper
INFO - 2020-11-07 01:09:18 --> Helper loaded: form_helper
INFO - 2020-11-07 01:09:18 --> Helper loaded: my_helper
INFO - 2020-11-07 01:09:18 --> Database Driver Class Initialized
DEBUG - 2020-11-07 01:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-07 01:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-07 01:09:18 --> Controller Class Initialized
INFO - 2020-11-07 01:09:18 --> Helper loaded: cookie_helper
INFO - 2020-11-07 01:09:18 --> Final output sent to browser
DEBUG - 2020-11-07 01:09:18 --> Total execution time: 0.5033
INFO - 2020-11-07 01:09:20 --> Config Class Initialized
INFO - 2020-11-07 01:09:20 --> Hooks Class Initialized
DEBUG - 2020-11-07 01:09:20 --> UTF-8 Support Enabled
INFO - 2020-11-07 01:09:20 --> Utf8 Class Initialized
INFO - 2020-11-07 01:09:20 --> URI Class Initialized
INFO - 2020-11-07 01:09:20 --> Router Class Initialized
INFO - 2020-11-07 01:09:20 --> Output Class Initialized
INFO - 2020-11-07 01:09:20 --> Security Class Initialized
DEBUG - 2020-11-07 01:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-07 01:09:20 --> Input Class Initialized
INFO - 2020-11-07 01:09:20 --> Language Class Initialized
INFO - 2020-11-07 01:09:20 --> Language Class Initialized
INFO - 2020-11-07 01:09:20 --> Config Class Initialized
INFO - 2020-11-07 01:09:20 --> Loader Class Initialized
INFO - 2020-11-07 01:09:20 --> Helper loaded: url_helper
INFO - 2020-11-07 01:09:20 --> Helper loaded: file_helper
INFO - 2020-11-07 01:09:20 --> Helper loaded: form_helper
INFO - 2020-11-07 01:09:20 --> Helper loaded: my_helper
INFO - 2020-11-07 01:09:20 --> Database Driver Class Initialized
DEBUG - 2020-11-07 01:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-07 01:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-07 01:09:20 --> Controller Class Initialized
DEBUG - 2020-11-07 01:09:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-07 01:09:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-07 01:09:20 --> Final output sent to browser
DEBUG - 2020-11-07 01:09:20 --> Total execution time: 0.7429
