<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-20 01:59:19 --> Config Class Initialized
INFO - 2021-01-20 01:59:19 --> Hooks Class Initialized
DEBUG - 2021-01-20 01:59:19 --> UTF-8 Support Enabled
INFO - 2021-01-20 01:59:19 --> Utf8 Class Initialized
INFO - 2021-01-20 01:59:19 --> URI Class Initialized
DEBUG - 2021-01-20 01:59:19 --> No URI present. Default controller set.
INFO - 2021-01-20 01:59:20 --> Router Class Initialized
INFO - 2021-01-20 01:59:20 --> Output Class Initialized
INFO - 2021-01-20 01:59:20 --> Security Class Initialized
DEBUG - 2021-01-20 01:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-20 01:59:20 --> Input Class Initialized
INFO - 2021-01-20 01:59:20 --> Language Class Initialized
INFO - 2021-01-20 01:59:20 --> Language Class Initialized
INFO - 2021-01-20 01:59:20 --> Config Class Initialized
INFO - 2021-01-20 01:59:20 --> Loader Class Initialized
INFO - 2021-01-20 01:59:20 --> Helper loaded: url_helper
INFO - 2021-01-20 01:59:20 --> Helper loaded: file_helper
INFO - 2021-01-20 01:59:20 --> Helper loaded: form_helper
INFO - 2021-01-20 01:59:20 --> Helper loaded: my_helper
INFO - 2021-01-20 01:59:20 --> Database Driver Class Initialized
DEBUG - 2021-01-20 01:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-20 01:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-20 01:59:20 --> Controller Class Initialized
INFO - 2021-01-20 01:59:20 --> Config Class Initialized
INFO - 2021-01-20 01:59:20 --> Hooks Class Initialized
DEBUG - 2021-01-20 01:59:20 --> UTF-8 Support Enabled
INFO - 2021-01-20 01:59:20 --> Utf8 Class Initialized
INFO - 2021-01-20 01:59:20 --> URI Class Initialized
INFO - 2021-01-20 01:59:20 --> Router Class Initialized
INFO - 2021-01-20 01:59:20 --> Output Class Initialized
INFO - 2021-01-20 01:59:20 --> Security Class Initialized
DEBUG - 2021-01-20 01:59:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-20 01:59:21 --> Input Class Initialized
INFO - 2021-01-20 01:59:21 --> Language Class Initialized
INFO - 2021-01-20 01:59:21 --> Language Class Initialized
INFO - 2021-01-20 01:59:21 --> Config Class Initialized
INFO - 2021-01-20 01:59:21 --> Loader Class Initialized
INFO - 2021-01-20 01:59:21 --> Helper loaded: url_helper
INFO - 2021-01-20 01:59:21 --> Helper loaded: file_helper
INFO - 2021-01-20 01:59:21 --> Helper loaded: form_helper
INFO - 2021-01-20 01:59:21 --> Helper loaded: my_helper
INFO - 2021-01-20 01:59:21 --> Database Driver Class Initialized
DEBUG - 2021-01-20 01:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-20 01:59:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-20 01:59:21 --> Controller Class Initialized
DEBUG - 2021-01-20 01:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-20 01:59:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-20 01:59:21 --> Final output sent to browser
DEBUG - 2021-01-20 01:59:21 --> Total execution time: 0.3522
INFO - 2021-01-20 02:01:12 --> Config Class Initialized
INFO - 2021-01-20 02:01:12 --> Hooks Class Initialized
DEBUG - 2021-01-20 02:01:12 --> UTF-8 Support Enabled
INFO - 2021-01-20 02:01:12 --> Utf8 Class Initialized
INFO - 2021-01-20 02:01:12 --> URI Class Initialized
INFO - 2021-01-20 02:01:12 --> Router Class Initialized
INFO - 2021-01-20 02:01:12 --> Output Class Initialized
INFO - 2021-01-20 02:01:12 --> Security Class Initialized
DEBUG - 2021-01-20 02:01:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-20 02:01:12 --> Input Class Initialized
INFO - 2021-01-20 02:01:12 --> Language Class Initialized
INFO - 2021-01-20 02:01:12 --> Language Class Initialized
INFO - 2021-01-20 02:01:12 --> Config Class Initialized
INFO - 2021-01-20 02:01:12 --> Loader Class Initialized
INFO - 2021-01-20 02:01:13 --> Helper loaded: url_helper
INFO - 2021-01-20 02:01:13 --> Helper loaded: file_helper
INFO - 2021-01-20 02:01:13 --> Helper loaded: form_helper
INFO - 2021-01-20 02:01:13 --> Helper loaded: my_helper
INFO - 2021-01-20 02:01:13 --> Database Driver Class Initialized
DEBUG - 2021-01-20 02:01:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-20 02:01:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-20 02:01:13 --> Controller Class Initialized
INFO - 2021-01-20 02:01:13 --> Helper loaded: cookie_helper
INFO - 2021-01-20 02:01:13 --> Final output sent to browser
DEBUG - 2021-01-20 02:01:13 --> Total execution time: 0.6701
INFO - 2021-01-20 02:01:13 --> Config Class Initialized
INFO - 2021-01-20 02:01:13 --> Hooks Class Initialized
DEBUG - 2021-01-20 02:01:13 --> UTF-8 Support Enabled
INFO - 2021-01-20 02:01:13 --> Utf8 Class Initialized
INFO - 2021-01-20 02:01:13 --> URI Class Initialized
INFO - 2021-01-20 02:01:13 --> Router Class Initialized
INFO - 2021-01-20 02:01:13 --> Output Class Initialized
INFO - 2021-01-20 02:01:13 --> Security Class Initialized
DEBUG - 2021-01-20 02:01:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-20 02:01:13 --> Input Class Initialized
INFO - 2021-01-20 02:01:14 --> Language Class Initialized
INFO - 2021-01-20 02:01:14 --> Language Class Initialized
INFO - 2021-01-20 02:01:14 --> Config Class Initialized
INFO - 2021-01-20 02:01:14 --> Loader Class Initialized
INFO - 2021-01-20 02:01:14 --> Helper loaded: url_helper
INFO - 2021-01-20 02:01:14 --> Helper loaded: file_helper
INFO - 2021-01-20 02:01:14 --> Helper loaded: form_helper
INFO - 2021-01-20 02:01:14 --> Helper loaded: my_helper
INFO - 2021-01-20 02:01:14 --> Database Driver Class Initialized
DEBUG - 2021-01-20 02:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-20 02:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-20 02:01:14 --> Controller Class Initialized
DEBUG - 2021-01-20 02:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-20 02:01:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-20 02:01:14 --> Final output sent to browser
DEBUG - 2021-01-20 02:01:14 --> Total execution time: 0.7503
INFO - 2021-01-20 02:01:15 --> Config Class Initialized
INFO - 2021-01-20 02:01:15 --> Hooks Class Initialized
DEBUG - 2021-01-20 02:01:15 --> UTF-8 Support Enabled
INFO - 2021-01-20 02:01:15 --> Utf8 Class Initialized
INFO - 2021-01-20 02:01:15 --> URI Class Initialized
INFO - 2021-01-20 02:01:15 --> Router Class Initialized
INFO - 2021-01-20 02:01:15 --> Output Class Initialized
INFO - 2021-01-20 02:01:15 --> Security Class Initialized
DEBUG - 2021-01-20 02:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-20 02:01:15 --> Input Class Initialized
INFO - 2021-01-20 02:01:15 --> Language Class Initialized
INFO - 2021-01-20 02:01:16 --> Language Class Initialized
INFO - 2021-01-20 02:01:16 --> Config Class Initialized
INFO - 2021-01-20 02:01:16 --> Loader Class Initialized
INFO - 2021-01-20 02:01:16 --> Helper loaded: url_helper
INFO - 2021-01-20 02:01:16 --> Helper loaded: file_helper
INFO - 2021-01-20 02:01:16 --> Helper loaded: form_helper
INFO - 2021-01-20 02:01:16 --> Helper loaded: my_helper
INFO - 2021-01-20 02:01:16 --> Database Driver Class Initialized
DEBUG - 2021-01-20 02:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-20 02:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-20 02:01:16 --> Controller Class Initialized
DEBUG - 2021-01-20 02:01:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-20 02:01:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-20 02:01:16 --> Final output sent to browser
DEBUG - 2021-01-20 02:01:16 --> Total execution time: 0.4436
INFO - 2021-01-20 02:01:18 --> Config Class Initialized
INFO - 2021-01-20 02:01:18 --> Hooks Class Initialized
DEBUG - 2021-01-20 02:01:18 --> UTF-8 Support Enabled
INFO - 2021-01-20 02:01:18 --> Utf8 Class Initialized
INFO - 2021-01-20 02:01:18 --> URI Class Initialized
INFO - 2021-01-20 02:01:18 --> Router Class Initialized
INFO - 2021-01-20 02:01:18 --> Output Class Initialized
INFO - 2021-01-20 02:01:18 --> Security Class Initialized
DEBUG - 2021-01-20 02:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-20 02:01:18 --> Input Class Initialized
INFO - 2021-01-20 02:01:18 --> Language Class Initialized
INFO - 2021-01-20 02:01:18 --> Language Class Initialized
INFO - 2021-01-20 02:01:18 --> Config Class Initialized
INFO - 2021-01-20 02:01:18 --> Loader Class Initialized
INFO - 2021-01-20 02:01:18 --> Helper loaded: url_helper
INFO - 2021-01-20 02:01:18 --> Helper loaded: file_helper
INFO - 2021-01-20 02:01:18 --> Helper loaded: form_helper
INFO - 2021-01-20 02:01:18 --> Helper loaded: my_helper
INFO - 2021-01-20 02:01:18 --> Database Driver Class Initialized
DEBUG - 2021-01-20 02:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-20 02:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-20 02:01:18 --> Controller Class Initialized
DEBUG - 2021-01-20 02:01:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-01-20 02:01:18 --> Final output sent to browser
DEBUG - 2021-01-20 02:01:18 --> Total execution time: 0.5788
