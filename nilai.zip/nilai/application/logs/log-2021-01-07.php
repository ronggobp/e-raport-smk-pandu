<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-07 01:12:42 --> Config Class Initialized
INFO - 2021-01-07 01:12:42 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:12:42 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:12:42 --> Utf8 Class Initialized
INFO - 2021-01-07 01:12:42 --> URI Class Initialized
DEBUG - 2021-01-07 01:12:42 --> No URI present. Default controller set.
INFO - 2021-01-07 01:12:42 --> Router Class Initialized
INFO - 2021-01-07 01:12:42 --> Output Class Initialized
INFO - 2021-01-07 01:12:42 --> Security Class Initialized
DEBUG - 2021-01-07 01:12:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:12:42 --> Input Class Initialized
INFO - 2021-01-07 01:12:42 --> Language Class Initialized
INFO - 2021-01-07 01:12:42 --> Language Class Initialized
INFO - 2021-01-07 01:12:42 --> Config Class Initialized
INFO - 2021-01-07 01:12:42 --> Loader Class Initialized
INFO - 2021-01-07 01:12:42 --> Helper loaded: url_helper
INFO - 2021-01-07 01:12:42 --> Helper loaded: file_helper
INFO - 2021-01-07 01:12:42 --> Helper loaded: form_helper
INFO - 2021-01-07 01:12:43 --> Helper loaded: my_helper
INFO - 2021-01-07 01:12:43 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:12:43 --> Controller Class Initialized
INFO - 2021-01-07 01:12:43 --> Config Class Initialized
INFO - 2021-01-07 01:12:43 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:12:43 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:12:43 --> Utf8 Class Initialized
INFO - 2021-01-07 01:12:43 --> URI Class Initialized
INFO - 2021-01-07 01:12:43 --> Router Class Initialized
INFO - 2021-01-07 01:12:43 --> Output Class Initialized
INFO - 2021-01-07 01:12:43 --> Security Class Initialized
DEBUG - 2021-01-07 01:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:12:43 --> Input Class Initialized
INFO - 2021-01-07 01:12:43 --> Language Class Initialized
INFO - 2021-01-07 01:12:43 --> Language Class Initialized
INFO - 2021-01-07 01:12:43 --> Config Class Initialized
INFO - 2021-01-07 01:12:43 --> Loader Class Initialized
INFO - 2021-01-07 01:12:43 --> Helper loaded: url_helper
INFO - 2021-01-07 01:12:43 --> Helper loaded: file_helper
INFO - 2021-01-07 01:12:43 --> Helper loaded: form_helper
INFO - 2021-01-07 01:12:43 --> Helper loaded: my_helper
INFO - 2021-01-07 01:12:43 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:12:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:12:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:12:43 --> Controller Class Initialized
DEBUG - 2021-01-07 01:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 01:12:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:12:43 --> Final output sent to browser
DEBUG - 2021-01-07 01:12:44 --> Total execution time: 0.7727
INFO - 2021-01-07 01:18:16 --> Config Class Initialized
INFO - 2021-01-07 01:18:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:18:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:18:16 --> Utf8 Class Initialized
INFO - 2021-01-07 01:18:16 --> URI Class Initialized
INFO - 2021-01-07 01:18:17 --> Router Class Initialized
INFO - 2021-01-07 01:18:17 --> Output Class Initialized
INFO - 2021-01-07 01:18:17 --> Security Class Initialized
DEBUG - 2021-01-07 01:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:18:17 --> Input Class Initialized
INFO - 2021-01-07 01:18:17 --> Language Class Initialized
INFO - 2021-01-07 01:18:17 --> Language Class Initialized
INFO - 2021-01-07 01:18:17 --> Config Class Initialized
INFO - 2021-01-07 01:18:17 --> Loader Class Initialized
INFO - 2021-01-07 01:18:17 --> Helper loaded: url_helper
INFO - 2021-01-07 01:18:17 --> Helper loaded: file_helper
INFO - 2021-01-07 01:18:17 --> Helper loaded: form_helper
INFO - 2021-01-07 01:18:17 --> Helper loaded: my_helper
INFO - 2021-01-07 01:18:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:18:17 --> Controller Class Initialized
INFO - 2021-01-07 01:18:17 --> Helper loaded: cookie_helper
INFO - 2021-01-07 01:18:17 --> Final output sent to browser
DEBUG - 2021-01-07 01:18:17 --> Total execution time: 0.9871
INFO - 2021-01-07 01:18:18 --> Config Class Initialized
INFO - 2021-01-07 01:18:18 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:18:18 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:18:18 --> Utf8 Class Initialized
INFO - 2021-01-07 01:18:18 --> URI Class Initialized
INFO - 2021-01-07 01:18:18 --> Router Class Initialized
INFO - 2021-01-07 01:18:18 --> Output Class Initialized
INFO - 2021-01-07 01:18:18 --> Security Class Initialized
DEBUG - 2021-01-07 01:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:18:18 --> Input Class Initialized
INFO - 2021-01-07 01:18:18 --> Language Class Initialized
INFO - 2021-01-07 01:18:18 --> Language Class Initialized
INFO - 2021-01-07 01:18:18 --> Config Class Initialized
INFO - 2021-01-07 01:18:18 --> Loader Class Initialized
INFO - 2021-01-07 01:18:18 --> Helper loaded: url_helper
INFO - 2021-01-07 01:18:18 --> Helper loaded: file_helper
INFO - 2021-01-07 01:18:18 --> Helper loaded: form_helper
INFO - 2021-01-07 01:18:18 --> Helper loaded: my_helper
INFO - 2021-01-07 01:18:18 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:18:19 --> Controller Class Initialized
DEBUG - 2021-01-07 01:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 01:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:18:19 --> Final output sent to browser
DEBUG - 2021-01-07 01:18:19 --> Total execution time: 0.8331
INFO - 2021-01-07 01:18:21 --> Config Class Initialized
INFO - 2021-01-07 01:18:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:18:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:18:21 --> Utf8 Class Initialized
INFO - 2021-01-07 01:18:21 --> URI Class Initialized
INFO - 2021-01-07 01:18:21 --> Router Class Initialized
INFO - 2021-01-07 01:18:21 --> Output Class Initialized
INFO - 2021-01-07 01:18:21 --> Security Class Initialized
DEBUG - 2021-01-07 01:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:18:21 --> Input Class Initialized
INFO - 2021-01-07 01:18:21 --> Language Class Initialized
INFO - 2021-01-07 01:18:21 --> Language Class Initialized
INFO - 2021-01-07 01:18:21 --> Config Class Initialized
INFO - 2021-01-07 01:18:21 --> Loader Class Initialized
INFO - 2021-01-07 01:18:21 --> Helper loaded: url_helper
INFO - 2021-01-07 01:18:21 --> Helper loaded: file_helper
INFO - 2021-01-07 01:18:21 --> Helper loaded: form_helper
INFO - 2021-01-07 01:18:21 --> Helper loaded: my_helper
INFO - 2021-01-07 01:18:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:18:21 --> Controller Class Initialized
DEBUG - 2021-01-07 01:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-07 01:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:18:22 --> Final output sent to browser
DEBUG - 2021-01-07 01:18:22 --> Total execution time: 0.6773
INFO - 2021-01-07 01:18:23 --> Config Class Initialized
INFO - 2021-01-07 01:18:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:18:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:18:23 --> Utf8 Class Initialized
INFO - 2021-01-07 01:18:23 --> URI Class Initialized
INFO - 2021-01-07 01:18:23 --> Router Class Initialized
INFO - 2021-01-07 01:18:23 --> Output Class Initialized
INFO - 2021-01-07 01:18:23 --> Security Class Initialized
DEBUG - 2021-01-07 01:18:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:18:23 --> Input Class Initialized
INFO - 2021-01-07 01:18:23 --> Language Class Initialized
INFO - 2021-01-07 01:18:23 --> Language Class Initialized
INFO - 2021-01-07 01:18:23 --> Config Class Initialized
INFO - 2021-01-07 01:18:23 --> Loader Class Initialized
INFO - 2021-01-07 01:18:23 --> Helper loaded: url_helper
INFO - 2021-01-07 01:18:23 --> Helper loaded: file_helper
INFO - 2021-01-07 01:18:23 --> Helper loaded: form_helper
INFO - 2021-01-07 01:18:23 --> Helper loaded: my_helper
INFO - 2021-01-07 01:18:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:18:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:18:23 --> Controller Class Initialized
DEBUG - 2021-01-07 01:18:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 01:18:24 --> Final output sent to browser
DEBUG - 2021-01-07 01:18:24 --> Total execution time: 0.6774
INFO - 2021-01-07 01:18:43 --> Config Class Initialized
INFO - 2021-01-07 01:18:43 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:18:43 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:18:43 --> Utf8 Class Initialized
INFO - 2021-01-07 01:18:43 --> URI Class Initialized
INFO - 2021-01-07 01:18:43 --> Router Class Initialized
INFO - 2021-01-07 01:18:43 --> Output Class Initialized
INFO - 2021-01-07 01:18:43 --> Security Class Initialized
DEBUG - 2021-01-07 01:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:18:43 --> Input Class Initialized
INFO - 2021-01-07 01:18:43 --> Language Class Initialized
INFO - 2021-01-07 01:18:44 --> Language Class Initialized
INFO - 2021-01-07 01:18:44 --> Config Class Initialized
INFO - 2021-01-07 01:18:44 --> Loader Class Initialized
INFO - 2021-01-07 01:18:44 --> Helper loaded: url_helper
INFO - 2021-01-07 01:18:44 --> Helper loaded: file_helper
INFO - 2021-01-07 01:18:44 --> Helper loaded: form_helper
INFO - 2021-01-07 01:18:44 --> Helper loaded: my_helper
INFO - 2021-01-07 01:18:44 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:18:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:18:44 --> Controller Class Initialized
INFO - 2021-01-07 01:18:44 --> Helper loaded: cookie_helper
INFO - 2021-01-07 01:18:44 --> Config Class Initialized
INFO - 2021-01-07 01:18:44 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:18:44 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:18:44 --> Utf8 Class Initialized
INFO - 2021-01-07 01:18:44 --> URI Class Initialized
INFO - 2021-01-07 01:18:44 --> Router Class Initialized
INFO - 2021-01-07 01:18:44 --> Output Class Initialized
INFO - 2021-01-07 01:18:44 --> Security Class Initialized
DEBUG - 2021-01-07 01:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:18:44 --> Input Class Initialized
INFO - 2021-01-07 01:18:44 --> Language Class Initialized
INFO - 2021-01-07 01:18:45 --> Language Class Initialized
INFO - 2021-01-07 01:18:45 --> Config Class Initialized
INFO - 2021-01-07 01:18:45 --> Loader Class Initialized
INFO - 2021-01-07 01:18:45 --> Helper loaded: url_helper
INFO - 2021-01-07 01:18:45 --> Helper loaded: file_helper
INFO - 2021-01-07 01:18:45 --> Helper loaded: form_helper
INFO - 2021-01-07 01:18:45 --> Helper loaded: my_helper
INFO - 2021-01-07 01:18:45 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:18:45 --> Controller Class Initialized
DEBUG - 2021-01-07 01:18:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 01:18:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:18:45 --> Final output sent to browser
DEBUG - 2021-01-07 01:18:45 --> Total execution time: 0.9363
INFO - 2021-01-07 01:18:59 --> Config Class Initialized
INFO - 2021-01-07 01:18:59 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:18:59 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:18:59 --> Utf8 Class Initialized
INFO - 2021-01-07 01:18:59 --> URI Class Initialized
INFO - 2021-01-07 01:19:00 --> Router Class Initialized
INFO - 2021-01-07 01:19:00 --> Output Class Initialized
INFO - 2021-01-07 01:19:00 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:00 --> Input Class Initialized
INFO - 2021-01-07 01:19:00 --> Language Class Initialized
INFO - 2021-01-07 01:19:00 --> Language Class Initialized
INFO - 2021-01-07 01:19:00 --> Config Class Initialized
INFO - 2021-01-07 01:19:00 --> Loader Class Initialized
INFO - 2021-01-07 01:19:00 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:00 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:00 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:00 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:00 --> Controller Class Initialized
INFO - 2021-01-07 01:19:00 --> Helper loaded: cookie_helper
INFO - 2021-01-07 01:19:00 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:00 --> Total execution time: 0.8341
INFO - 2021-01-07 01:19:01 --> Config Class Initialized
INFO - 2021-01-07 01:19:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:01 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:01 --> URI Class Initialized
INFO - 2021-01-07 01:19:01 --> Router Class Initialized
INFO - 2021-01-07 01:19:01 --> Output Class Initialized
INFO - 2021-01-07 01:19:01 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:01 --> Input Class Initialized
INFO - 2021-01-07 01:19:01 --> Language Class Initialized
INFO - 2021-01-07 01:19:01 --> Language Class Initialized
INFO - 2021-01-07 01:19:01 --> Config Class Initialized
INFO - 2021-01-07 01:19:01 --> Loader Class Initialized
INFO - 2021-01-07 01:19:01 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:01 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:01 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:01 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:02 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 01:19:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:19:02 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:02 --> Total execution time: 0.8479
INFO - 2021-01-07 01:19:06 --> Config Class Initialized
INFO - 2021-01-07 01:19:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:06 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:06 --> URI Class Initialized
INFO - 2021-01-07 01:19:06 --> Router Class Initialized
INFO - 2021-01-07 01:19:06 --> Output Class Initialized
INFO - 2021-01-07 01:19:06 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:06 --> Input Class Initialized
INFO - 2021-01-07 01:19:06 --> Language Class Initialized
INFO - 2021-01-07 01:19:06 --> Language Class Initialized
INFO - 2021-01-07 01:19:06 --> Config Class Initialized
INFO - 2021-01-07 01:19:06 --> Loader Class Initialized
INFO - 2021-01-07 01:19:06 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:06 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:06 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:06 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:06 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 01:19:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:19:06 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:06 --> Total execution time: 0.7223
INFO - 2021-01-07 01:19:07 --> Config Class Initialized
INFO - 2021-01-07 01:19:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:07 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:07 --> URI Class Initialized
INFO - 2021-01-07 01:19:07 --> Router Class Initialized
INFO - 2021-01-07 01:19:08 --> Output Class Initialized
INFO - 2021-01-07 01:19:08 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:08 --> Input Class Initialized
INFO - 2021-01-07 01:19:08 --> Language Class Initialized
INFO - 2021-01-07 01:19:08 --> Language Class Initialized
INFO - 2021-01-07 01:19:08 --> Config Class Initialized
INFO - 2021-01-07 01:19:08 --> Loader Class Initialized
INFO - 2021-01-07 01:19:08 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:08 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:08 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:08 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:08 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 01:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:19:08 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:08 --> Total execution time: 0.8467
INFO - 2021-01-07 01:19:08 --> Config Class Initialized
INFO - 2021-01-07 01:19:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:08 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:08 --> URI Class Initialized
INFO - 2021-01-07 01:19:09 --> Router Class Initialized
INFO - 2021-01-07 01:19:09 --> Output Class Initialized
INFO - 2021-01-07 01:19:09 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:09 --> Input Class Initialized
INFO - 2021-01-07 01:19:09 --> Language Class Initialized
INFO - 2021-01-07 01:19:09 --> Language Class Initialized
INFO - 2021-01-07 01:19:09 --> Config Class Initialized
INFO - 2021-01-07 01:19:09 --> Loader Class Initialized
INFO - 2021-01-07 01:19:09 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:09 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:09 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:09 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:09 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:09 --> Controller Class Initialized
INFO - 2021-01-07 01:19:11 --> Config Class Initialized
INFO - 2021-01-07 01:19:11 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:11 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:11 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:11 --> URI Class Initialized
INFO - 2021-01-07 01:19:11 --> Router Class Initialized
INFO - 2021-01-07 01:19:11 --> Output Class Initialized
INFO - 2021-01-07 01:19:11 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:12 --> Input Class Initialized
INFO - 2021-01-07 01:19:12 --> Language Class Initialized
INFO - 2021-01-07 01:19:12 --> Language Class Initialized
INFO - 2021-01-07 01:19:12 --> Config Class Initialized
INFO - 2021-01-07 01:19:12 --> Loader Class Initialized
INFO - 2021-01-07 01:19:12 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:12 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:12 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:12 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:12 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:12 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 01:19:12 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:12 --> Total execution time: 0.8526
INFO - 2021-01-07 01:19:13 --> Config Class Initialized
INFO - 2021-01-07 01:19:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:13 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:13 --> URI Class Initialized
INFO - 2021-01-07 01:19:13 --> Router Class Initialized
INFO - 2021-01-07 01:19:13 --> Output Class Initialized
INFO - 2021-01-07 01:19:13 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:13 --> Input Class Initialized
INFO - 2021-01-07 01:19:13 --> Language Class Initialized
INFO - 2021-01-07 01:19:13 --> Language Class Initialized
INFO - 2021-01-07 01:19:13 --> Config Class Initialized
INFO - 2021-01-07 01:19:13 --> Loader Class Initialized
INFO - 2021-01-07 01:19:13 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:13 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:13 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:13 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:13 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 01:19:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:19:13 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:13 --> Total execution time: 0.6824
INFO - 2021-01-07 01:19:14 --> Config Class Initialized
INFO - 2021-01-07 01:19:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:14 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:14 --> URI Class Initialized
INFO - 2021-01-07 01:19:14 --> Router Class Initialized
INFO - 2021-01-07 01:19:15 --> Output Class Initialized
INFO - 2021-01-07 01:19:15 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:15 --> Input Class Initialized
INFO - 2021-01-07 01:19:15 --> Language Class Initialized
INFO - 2021-01-07 01:19:15 --> Language Class Initialized
INFO - 2021-01-07 01:19:15 --> Config Class Initialized
INFO - 2021-01-07 01:19:15 --> Loader Class Initialized
INFO - 2021-01-07 01:19:15 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:15 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:15 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:15 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:15 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:15 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 01:19:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:19:15 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:15 --> Total execution time: 0.8338
INFO - 2021-01-07 01:19:20 --> Config Class Initialized
INFO - 2021-01-07 01:19:20 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:20 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:20 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:20 --> URI Class Initialized
INFO - 2021-01-07 01:19:20 --> Router Class Initialized
INFO - 2021-01-07 01:19:20 --> Output Class Initialized
INFO - 2021-01-07 01:19:20 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:20 --> Input Class Initialized
INFO - 2021-01-07 01:19:20 --> Language Class Initialized
INFO - 2021-01-07 01:19:20 --> Language Class Initialized
INFO - 2021-01-07 01:19:20 --> Config Class Initialized
INFO - 2021-01-07 01:19:20 --> Loader Class Initialized
INFO - 2021-01-07 01:19:20 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:20 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:20 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:20 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:20 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:20 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 01:19:20 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:21 --> Total execution time: 0.8118
INFO - 2021-01-07 01:19:43 --> Config Class Initialized
INFO - 2021-01-07 01:19:43 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:43 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:43 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:43 --> URI Class Initialized
INFO - 2021-01-07 01:19:43 --> Router Class Initialized
INFO - 2021-01-07 01:19:43 --> Output Class Initialized
INFO - 2021-01-07 01:19:43 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:43 --> Input Class Initialized
INFO - 2021-01-07 01:19:43 --> Language Class Initialized
INFO - 2021-01-07 01:19:43 --> Language Class Initialized
INFO - 2021-01-07 01:19:43 --> Config Class Initialized
INFO - 2021-01-07 01:19:43 --> Loader Class Initialized
INFO - 2021-01-07 01:19:43 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:43 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:43 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:43 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:43 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:44 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 01:19:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:19:44 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:44 --> Total execution time: 0.7567
INFO - 2021-01-07 01:19:45 --> Config Class Initialized
INFO - 2021-01-07 01:19:45 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:45 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:45 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:45 --> URI Class Initialized
INFO - 2021-01-07 01:19:45 --> Router Class Initialized
INFO - 2021-01-07 01:19:45 --> Output Class Initialized
INFO - 2021-01-07 01:19:45 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:45 --> Input Class Initialized
INFO - 2021-01-07 01:19:45 --> Language Class Initialized
INFO - 2021-01-07 01:19:45 --> Language Class Initialized
INFO - 2021-01-07 01:19:45 --> Config Class Initialized
INFO - 2021-01-07 01:19:45 --> Loader Class Initialized
INFO - 2021-01-07 01:19:45 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:45 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:45 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:45 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:45 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:45 --> Controller Class Initialized
DEBUG - 2021-01-07 01:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 01:19:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 01:19:45 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:46 --> Total execution time: 0.7841
INFO - 2021-01-07 01:19:46 --> Config Class Initialized
INFO - 2021-01-07 01:19:46 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:46 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:46 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:46 --> URI Class Initialized
INFO - 2021-01-07 01:19:46 --> Router Class Initialized
INFO - 2021-01-07 01:19:46 --> Output Class Initialized
INFO - 2021-01-07 01:19:46 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:46 --> Input Class Initialized
INFO - 2021-01-07 01:19:46 --> Language Class Initialized
INFO - 2021-01-07 01:19:46 --> Language Class Initialized
INFO - 2021-01-07 01:19:46 --> Config Class Initialized
INFO - 2021-01-07 01:19:46 --> Loader Class Initialized
INFO - 2021-01-07 01:19:46 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:46 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:46 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:46 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:46 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:46 --> Controller Class Initialized
INFO - 2021-01-07 01:19:47 --> Config Class Initialized
INFO - 2021-01-07 01:19:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:47 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:47 --> URI Class Initialized
INFO - 2021-01-07 01:19:47 --> Router Class Initialized
INFO - 2021-01-07 01:19:47 --> Output Class Initialized
INFO - 2021-01-07 01:19:47 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:47 --> Input Class Initialized
INFO - 2021-01-07 01:19:47 --> Language Class Initialized
INFO - 2021-01-07 01:19:47 --> Language Class Initialized
INFO - 2021-01-07 01:19:47 --> Config Class Initialized
INFO - 2021-01-07 01:19:47 --> Loader Class Initialized
INFO - 2021-01-07 01:19:47 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:47 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:47 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:47 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:48 --> Controller Class Initialized
INFO - 2021-01-07 01:19:48 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:48 --> Total execution time: 0.6223
INFO - 2021-01-07 01:19:57 --> Config Class Initialized
INFO - 2021-01-07 01:19:57 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:19:57 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:19:57 --> Utf8 Class Initialized
INFO - 2021-01-07 01:19:57 --> URI Class Initialized
INFO - 2021-01-07 01:19:57 --> Router Class Initialized
INFO - 2021-01-07 01:19:57 --> Output Class Initialized
INFO - 2021-01-07 01:19:57 --> Security Class Initialized
DEBUG - 2021-01-07 01:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:19:57 --> Input Class Initialized
INFO - 2021-01-07 01:19:57 --> Language Class Initialized
INFO - 2021-01-07 01:19:57 --> Language Class Initialized
INFO - 2021-01-07 01:19:58 --> Config Class Initialized
INFO - 2021-01-07 01:19:58 --> Loader Class Initialized
INFO - 2021-01-07 01:19:58 --> Helper loaded: url_helper
INFO - 2021-01-07 01:19:58 --> Helper loaded: file_helper
INFO - 2021-01-07 01:19:58 --> Helper loaded: form_helper
INFO - 2021-01-07 01:19:58 --> Helper loaded: my_helper
INFO - 2021-01-07 01:19:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:19:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:19:58 --> Controller Class Initialized
INFO - 2021-01-07 01:19:58 --> Final output sent to browser
DEBUG - 2021-01-07 01:19:58 --> Total execution time: 0.7789
INFO - 2021-01-07 01:20:01 --> Config Class Initialized
INFO - 2021-01-07 01:20:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:20:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:20:01 --> Utf8 Class Initialized
INFO - 2021-01-07 01:20:01 --> URI Class Initialized
INFO - 2021-01-07 01:20:01 --> Router Class Initialized
INFO - 2021-01-07 01:20:01 --> Output Class Initialized
INFO - 2021-01-07 01:20:01 --> Security Class Initialized
DEBUG - 2021-01-07 01:20:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:20:01 --> Input Class Initialized
INFO - 2021-01-07 01:20:01 --> Language Class Initialized
INFO - 2021-01-07 01:20:01 --> Language Class Initialized
INFO - 2021-01-07 01:20:01 --> Config Class Initialized
INFO - 2021-01-07 01:20:01 --> Loader Class Initialized
INFO - 2021-01-07 01:20:01 --> Helper loaded: url_helper
INFO - 2021-01-07 01:20:01 --> Helper loaded: file_helper
INFO - 2021-01-07 01:20:01 --> Helper loaded: form_helper
INFO - 2021-01-07 01:20:01 --> Helper loaded: my_helper
INFO - 2021-01-07 01:20:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:20:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:20:01 --> Controller Class Initialized
INFO - 2021-01-07 01:20:02 --> Final output sent to browser
DEBUG - 2021-01-07 01:20:02 --> Total execution time: 0.7533
INFO - 2021-01-07 01:20:05 --> Config Class Initialized
INFO - 2021-01-07 01:20:05 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:20:05 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:20:05 --> Utf8 Class Initialized
INFO - 2021-01-07 01:20:05 --> URI Class Initialized
INFO - 2021-01-07 01:20:05 --> Router Class Initialized
INFO - 2021-01-07 01:20:05 --> Output Class Initialized
INFO - 2021-01-07 01:20:05 --> Security Class Initialized
DEBUG - 2021-01-07 01:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:20:05 --> Input Class Initialized
INFO - 2021-01-07 01:20:05 --> Language Class Initialized
INFO - 2021-01-07 01:20:05 --> Language Class Initialized
INFO - 2021-01-07 01:20:05 --> Config Class Initialized
INFO - 2021-01-07 01:20:05 --> Loader Class Initialized
INFO - 2021-01-07 01:20:05 --> Helper loaded: url_helper
INFO - 2021-01-07 01:20:05 --> Helper loaded: file_helper
INFO - 2021-01-07 01:20:05 --> Helper loaded: form_helper
INFO - 2021-01-07 01:20:05 --> Helper loaded: my_helper
INFO - 2021-01-07 01:20:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:20:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:20:06 --> Controller Class Initialized
INFO - 2021-01-07 01:20:06 --> Final output sent to browser
DEBUG - 2021-01-07 01:20:06 --> Total execution time: 0.7491
INFO - 2021-01-07 01:20:09 --> Config Class Initialized
INFO - 2021-01-07 01:20:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:20:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:20:09 --> Utf8 Class Initialized
INFO - 2021-01-07 01:20:09 --> URI Class Initialized
INFO - 2021-01-07 01:20:09 --> Router Class Initialized
INFO - 2021-01-07 01:20:09 --> Output Class Initialized
INFO - 2021-01-07 01:20:09 --> Security Class Initialized
DEBUG - 2021-01-07 01:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:20:09 --> Input Class Initialized
INFO - 2021-01-07 01:20:09 --> Language Class Initialized
INFO - 2021-01-07 01:20:09 --> Language Class Initialized
INFO - 2021-01-07 01:20:09 --> Config Class Initialized
INFO - 2021-01-07 01:20:09 --> Loader Class Initialized
INFO - 2021-01-07 01:20:09 --> Helper loaded: url_helper
INFO - 2021-01-07 01:20:09 --> Helper loaded: file_helper
INFO - 2021-01-07 01:20:10 --> Helper loaded: form_helper
INFO - 2021-01-07 01:20:10 --> Helper loaded: my_helper
INFO - 2021-01-07 01:20:10 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:20:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:20:10 --> Controller Class Initialized
DEBUG - 2021-01-07 01:20:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 01:20:10 --> Final output sent to browser
DEBUG - 2021-01-07 01:20:10 --> Total execution time: 0.8678
INFO - 2021-01-07 01:20:55 --> Config Class Initialized
INFO - 2021-01-07 01:20:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:20:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:20:55 --> Utf8 Class Initialized
INFO - 2021-01-07 01:20:55 --> URI Class Initialized
INFO - 2021-01-07 01:20:55 --> Router Class Initialized
INFO - 2021-01-07 01:20:55 --> Output Class Initialized
INFO - 2021-01-07 01:20:55 --> Security Class Initialized
DEBUG - 2021-01-07 01:20:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:20:55 --> Input Class Initialized
INFO - 2021-01-07 01:20:55 --> Language Class Initialized
INFO - 2021-01-07 01:20:55 --> Language Class Initialized
INFO - 2021-01-07 01:20:55 --> Config Class Initialized
INFO - 2021-01-07 01:20:55 --> Loader Class Initialized
INFO - 2021-01-07 01:20:56 --> Helper loaded: url_helper
INFO - 2021-01-07 01:20:56 --> Helper loaded: file_helper
INFO - 2021-01-07 01:20:56 --> Helper loaded: form_helper
INFO - 2021-01-07 01:20:56 --> Helper loaded: my_helper
INFO - 2021-01-07 01:20:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:20:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:20:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:20:56 --> Controller Class Initialized
INFO - 2021-01-07 01:20:56 --> Final output sent to browser
DEBUG - 2021-01-07 01:20:56 --> Total execution time: 0.9150
INFO - 2021-01-07 01:20:59 --> Config Class Initialized
INFO - 2021-01-07 01:20:59 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:20:59 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:20:59 --> Utf8 Class Initialized
INFO - 2021-01-07 01:20:59 --> URI Class Initialized
INFO - 2021-01-07 01:20:59 --> Router Class Initialized
INFO - 2021-01-07 01:20:59 --> Output Class Initialized
INFO - 2021-01-07 01:20:59 --> Security Class Initialized
DEBUG - 2021-01-07 01:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:20:59 --> Input Class Initialized
INFO - 2021-01-07 01:21:00 --> Language Class Initialized
INFO - 2021-01-07 01:21:00 --> Language Class Initialized
INFO - 2021-01-07 01:21:00 --> Config Class Initialized
INFO - 2021-01-07 01:21:00 --> Loader Class Initialized
INFO - 2021-01-07 01:21:00 --> Helper loaded: url_helper
INFO - 2021-01-07 01:21:00 --> Helper loaded: file_helper
INFO - 2021-01-07 01:21:00 --> Helper loaded: form_helper
INFO - 2021-01-07 01:21:00 --> Helper loaded: my_helper
INFO - 2021-01-07 01:21:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:21:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:21:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:21:00 --> Controller Class Initialized
DEBUG - 2021-01-07 01:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 01:21:00 --> Final output sent to browser
DEBUG - 2021-01-07 01:21:00 --> Total execution time: 0.7367
INFO - 2021-01-07 01:21:07 --> Config Class Initialized
INFO - 2021-01-07 01:21:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:21:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:21:07 --> Utf8 Class Initialized
INFO - 2021-01-07 01:21:07 --> URI Class Initialized
INFO - 2021-01-07 01:21:07 --> Router Class Initialized
INFO - 2021-01-07 01:21:07 --> Output Class Initialized
INFO - 2021-01-07 01:21:07 --> Security Class Initialized
DEBUG - 2021-01-07 01:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:21:07 --> Input Class Initialized
INFO - 2021-01-07 01:21:07 --> Language Class Initialized
INFO - 2021-01-07 01:21:07 --> Language Class Initialized
INFO - 2021-01-07 01:21:07 --> Config Class Initialized
INFO - 2021-01-07 01:21:07 --> Loader Class Initialized
INFO - 2021-01-07 01:21:07 --> Helper loaded: url_helper
INFO - 2021-01-07 01:21:07 --> Helper loaded: file_helper
INFO - 2021-01-07 01:21:07 --> Helper loaded: form_helper
INFO - 2021-01-07 01:21:07 --> Helper loaded: my_helper
INFO - 2021-01-07 01:21:07 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:21:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:21:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:21:07 --> Controller Class Initialized
INFO - 2021-01-07 01:21:07 --> Final output sent to browser
DEBUG - 2021-01-07 01:21:07 --> Total execution time: 0.6218
INFO - 2021-01-07 01:21:14 --> Config Class Initialized
INFO - 2021-01-07 01:21:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:21:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:21:14 --> Utf8 Class Initialized
INFO - 2021-01-07 01:21:14 --> URI Class Initialized
INFO - 2021-01-07 01:21:14 --> Router Class Initialized
INFO - 2021-01-07 01:21:14 --> Output Class Initialized
INFO - 2021-01-07 01:21:14 --> Security Class Initialized
DEBUG - 2021-01-07 01:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:21:14 --> Input Class Initialized
INFO - 2021-01-07 01:21:15 --> Language Class Initialized
INFO - 2021-01-07 01:21:15 --> Language Class Initialized
INFO - 2021-01-07 01:21:15 --> Config Class Initialized
INFO - 2021-01-07 01:21:15 --> Loader Class Initialized
INFO - 2021-01-07 01:21:15 --> Helper loaded: url_helper
INFO - 2021-01-07 01:21:15 --> Helper loaded: file_helper
INFO - 2021-01-07 01:21:15 --> Helper loaded: form_helper
INFO - 2021-01-07 01:21:15 --> Helper loaded: my_helper
INFO - 2021-01-07 01:21:15 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:21:15 --> Controller Class Initialized
INFO - 2021-01-07 01:21:15 --> Final output sent to browser
DEBUG - 2021-01-07 01:21:15 --> Total execution time: 0.8584
INFO - 2021-01-07 01:21:19 --> Config Class Initialized
INFO - 2021-01-07 01:21:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:21:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:21:19 --> Utf8 Class Initialized
INFO - 2021-01-07 01:21:19 --> URI Class Initialized
INFO - 2021-01-07 01:21:19 --> Router Class Initialized
INFO - 2021-01-07 01:21:19 --> Output Class Initialized
INFO - 2021-01-07 01:21:19 --> Security Class Initialized
DEBUG - 2021-01-07 01:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:21:19 --> Input Class Initialized
INFO - 2021-01-07 01:21:19 --> Language Class Initialized
INFO - 2021-01-07 01:21:20 --> Language Class Initialized
INFO - 2021-01-07 01:21:20 --> Config Class Initialized
INFO - 2021-01-07 01:21:20 --> Loader Class Initialized
INFO - 2021-01-07 01:21:20 --> Helper loaded: url_helper
INFO - 2021-01-07 01:21:20 --> Helper loaded: file_helper
INFO - 2021-01-07 01:21:20 --> Helper loaded: form_helper
INFO - 2021-01-07 01:21:20 --> Helper loaded: my_helper
INFO - 2021-01-07 01:21:20 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:21:20 --> Controller Class Initialized
DEBUG - 2021-01-07 01:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 01:21:20 --> Final output sent to browser
DEBUG - 2021-01-07 01:21:20 --> Total execution time: 0.8500
INFO - 2021-01-07 01:21:26 --> Config Class Initialized
INFO - 2021-01-07 01:21:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 01:21:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 01:21:26 --> Utf8 Class Initialized
INFO - 2021-01-07 01:21:26 --> URI Class Initialized
INFO - 2021-01-07 01:21:26 --> Router Class Initialized
INFO - 2021-01-07 01:21:26 --> Output Class Initialized
INFO - 2021-01-07 01:21:26 --> Security Class Initialized
DEBUG - 2021-01-07 01:21:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 01:21:26 --> Input Class Initialized
INFO - 2021-01-07 01:21:26 --> Language Class Initialized
INFO - 2021-01-07 01:21:26 --> Language Class Initialized
INFO - 2021-01-07 01:21:26 --> Config Class Initialized
INFO - 2021-01-07 01:21:26 --> Loader Class Initialized
INFO - 2021-01-07 01:21:26 --> Helper loaded: url_helper
INFO - 2021-01-07 01:21:26 --> Helper loaded: file_helper
INFO - 2021-01-07 01:21:26 --> Helper loaded: form_helper
INFO - 2021-01-07 01:21:26 --> Helper loaded: my_helper
INFO - 2021-01-07 01:21:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 01:21:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 01:21:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 01:21:26 --> Controller Class Initialized
DEBUG - 2021-01-07 01:21:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 01:21:26 --> Final output sent to browser
DEBUG - 2021-01-07 01:21:27 --> Total execution time: 0.9124
INFO - 2021-01-07 02:06:35 --> Config Class Initialized
INFO - 2021-01-07 02:06:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:06:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:06:35 --> Utf8 Class Initialized
INFO - 2021-01-07 02:06:35 --> URI Class Initialized
INFO - 2021-01-07 02:06:35 --> Router Class Initialized
INFO - 2021-01-07 02:06:35 --> Output Class Initialized
INFO - 2021-01-07 02:06:35 --> Security Class Initialized
DEBUG - 2021-01-07 02:06:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:06:35 --> Input Class Initialized
INFO - 2021-01-07 02:06:35 --> Language Class Initialized
INFO - 2021-01-07 02:06:35 --> Language Class Initialized
INFO - 2021-01-07 02:06:35 --> Config Class Initialized
INFO - 2021-01-07 02:06:35 --> Loader Class Initialized
INFO - 2021-01-07 02:06:35 --> Helper loaded: url_helper
INFO - 2021-01-07 02:06:35 --> Helper loaded: file_helper
INFO - 2021-01-07 02:06:35 --> Helper loaded: form_helper
INFO - 2021-01-07 02:06:35 --> Helper loaded: my_helper
INFO - 2021-01-07 02:06:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:06:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:06:36 --> Controller Class Initialized
DEBUG - 2021-01-07 02:06:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:06:36 --> Final output sent to browser
DEBUG - 2021-01-07 02:06:36 --> Total execution time: 0.3346
INFO - 2021-01-07 02:07:23 --> Config Class Initialized
INFO - 2021-01-07 02:07:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:07:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:07:23 --> Utf8 Class Initialized
INFO - 2021-01-07 02:07:23 --> URI Class Initialized
INFO - 2021-01-07 02:07:23 --> Router Class Initialized
INFO - 2021-01-07 02:07:23 --> Output Class Initialized
INFO - 2021-01-07 02:07:23 --> Security Class Initialized
DEBUG - 2021-01-07 02:07:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:07:23 --> Input Class Initialized
INFO - 2021-01-07 02:07:23 --> Language Class Initialized
INFO - 2021-01-07 02:07:23 --> Language Class Initialized
INFO - 2021-01-07 02:07:23 --> Config Class Initialized
INFO - 2021-01-07 02:07:23 --> Loader Class Initialized
INFO - 2021-01-07 02:07:23 --> Helper loaded: url_helper
INFO - 2021-01-07 02:07:23 --> Helper loaded: file_helper
INFO - 2021-01-07 02:07:23 --> Helper loaded: form_helper
INFO - 2021-01-07 02:07:23 --> Helper loaded: my_helper
INFO - 2021-01-07 02:07:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:07:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:07:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:07:23 --> Controller Class Initialized
DEBUG - 2021-01-07 02:07:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:07:23 --> Final output sent to browser
DEBUG - 2021-01-07 02:07:23 --> Total execution time: 0.3121
INFO - 2021-01-07 02:07:26 --> Config Class Initialized
INFO - 2021-01-07 02:07:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:07:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:07:26 --> Utf8 Class Initialized
INFO - 2021-01-07 02:07:26 --> URI Class Initialized
INFO - 2021-01-07 02:07:26 --> Router Class Initialized
INFO - 2021-01-07 02:07:26 --> Output Class Initialized
INFO - 2021-01-07 02:07:26 --> Security Class Initialized
DEBUG - 2021-01-07 02:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:07:26 --> Input Class Initialized
INFO - 2021-01-07 02:07:26 --> Language Class Initialized
INFO - 2021-01-07 02:07:26 --> Language Class Initialized
INFO - 2021-01-07 02:07:26 --> Config Class Initialized
INFO - 2021-01-07 02:07:26 --> Loader Class Initialized
INFO - 2021-01-07 02:07:26 --> Helper loaded: url_helper
INFO - 2021-01-07 02:07:26 --> Helper loaded: file_helper
INFO - 2021-01-07 02:07:26 --> Helper loaded: form_helper
INFO - 2021-01-07 02:07:26 --> Helper loaded: my_helper
INFO - 2021-01-07 02:07:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:07:26 --> Controller Class Initialized
DEBUG - 2021-01-07 02:07:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:07:26 --> Final output sent to browser
DEBUG - 2021-01-07 02:07:26 --> Total execution time: 0.2460
INFO - 2021-01-07 02:08:07 --> Config Class Initialized
INFO - 2021-01-07 02:08:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:08:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:08:07 --> Utf8 Class Initialized
INFO - 2021-01-07 02:08:07 --> URI Class Initialized
INFO - 2021-01-07 02:08:07 --> Router Class Initialized
INFO - 2021-01-07 02:08:07 --> Output Class Initialized
INFO - 2021-01-07 02:08:07 --> Security Class Initialized
DEBUG - 2021-01-07 02:08:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:08:07 --> Input Class Initialized
INFO - 2021-01-07 02:08:07 --> Language Class Initialized
INFO - 2021-01-07 02:08:07 --> Language Class Initialized
INFO - 2021-01-07 02:08:07 --> Config Class Initialized
INFO - 2021-01-07 02:08:07 --> Loader Class Initialized
INFO - 2021-01-07 02:08:07 --> Helper loaded: url_helper
INFO - 2021-01-07 02:08:07 --> Helper loaded: file_helper
INFO - 2021-01-07 02:08:07 --> Helper loaded: form_helper
INFO - 2021-01-07 02:08:07 --> Helper loaded: my_helper
INFO - 2021-01-07 02:08:07 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:08:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:08:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:08:08 --> Controller Class Initialized
DEBUG - 2021-01-07 02:08:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:08:08 --> Final output sent to browser
DEBUG - 2021-01-07 02:08:08 --> Total execution time: 0.3241
INFO - 2021-01-07 02:08:14 --> Config Class Initialized
INFO - 2021-01-07 02:08:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:08:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:08:14 --> Utf8 Class Initialized
INFO - 2021-01-07 02:08:14 --> URI Class Initialized
INFO - 2021-01-07 02:08:14 --> Router Class Initialized
INFO - 2021-01-07 02:08:14 --> Output Class Initialized
INFO - 2021-01-07 02:08:14 --> Security Class Initialized
DEBUG - 2021-01-07 02:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:08:15 --> Input Class Initialized
INFO - 2021-01-07 02:08:15 --> Language Class Initialized
INFO - 2021-01-07 02:08:15 --> Language Class Initialized
INFO - 2021-01-07 02:08:15 --> Config Class Initialized
INFO - 2021-01-07 02:08:15 --> Loader Class Initialized
INFO - 2021-01-07 02:08:15 --> Helper loaded: url_helper
INFO - 2021-01-07 02:08:15 --> Helper loaded: file_helper
INFO - 2021-01-07 02:08:15 --> Helper loaded: form_helper
INFO - 2021-01-07 02:08:15 --> Helper loaded: my_helper
INFO - 2021-01-07 02:08:15 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:08:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:08:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:08:15 --> Controller Class Initialized
DEBUG - 2021-01-07 02:08:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:08:15 --> Final output sent to browser
DEBUG - 2021-01-07 02:08:15 --> Total execution time: 0.3502
INFO - 2021-01-07 02:15:22 --> Config Class Initialized
INFO - 2021-01-07 02:15:22 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:15:22 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:15:22 --> Utf8 Class Initialized
INFO - 2021-01-07 02:15:22 --> URI Class Initialized
INFO - 2021-01-07 02:15:22 --> Router Class Initialized
INFO - 2021-01-07 02:15:22 --> Output Class Initialized
INFO - 2021-01-07 02:15:22 --> Security Class Initialized
DEBUG - 2021-01-07 02:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:15:22 --> Input Class Initialized
INFO - 2021-01-07 02:15:22 --> Language Class Initialized
INFO - 2021-01-07 02:15:22 --> Language Class Initialized
INFO - 2021-01-07 02:15:22 --> Config Class Initialized
INFO - 2021-01-07 02:15:22 --> Loader Class Initialized
INFO - 2021-01-07 02:15:22 --> Helper loaded: url_helper
INFO - 2021-01-07 02:15:22 --> Helper loaded: file_helper
INFO - 2021-01-07 02:15:22 --> Helper loaded: form_helper
INFO - 2021-01-07 02:15:22 --> Helper loaded: my_helper
INFO - 2021-01-07 02:15:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:15:22 --> Controller Class Initialized
INFO - 2021-01-07 02:15:22 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:15:22 --> Config Class Initialized
INFO - 2021-01-07 02:15:22 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:15:22 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:15:22 --> Utf8 Class Initialized
INFO - 2021-01-07 02:15:22 --> URI Class Initialized
INFO - 2021-01-07 02:15:22 --> Router Class Initialized
INFO - 2021-01-07 02:15:22 --> Output Class Initialized
INFO - 2021-01-07 02:15:22 --> Security Class Initialized
DEBUG - 2021-01-07 02:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:15:22 --> Input Class Initialized
INFO - 2021-01-07 02:15:22 --> Language Class Initialized
INFO - 2021-01-07 02:15:22 --> Language Class Initialized
INFO - 2021-01-07 02:15:22 --> Config Class Initialized
INFO - 2021-01-07 02:15:22 --> Loader Class Initialized
INFO - 2021-01-07 02:15:22 --> Helper loaded: url_helper
INFO - 2021-01-07 02:15:22 --> Helper loaded: file_helper
INFO - 2021-01-07 02:15:22 --> Helper loaded: form_helper
INFO - 2021-01-07 02:15:22 --> Helper loaded: my_helper
INFO - 2021-01-07 02:15:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:15:22 --> Controller Class Initialized
DEBUG - 2021-01-07 02:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 02:15:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:15:22 --> Final output sent to browser
DEBUG - 2021-01-07 02:15:23 --> Total execution time: 0.2778
INFO - 2021-01-07 02:15:27 --> Config Class Initialized
INFO - 2021-01-07 02:15:27 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:15:27 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:15:27 --> Utf8 Class Initialized
INFO - 2021-01-07 02:15:27 --> URI Class Initialized
INFO - 2021-01-07 02:15:27 --> Router Class Initialized
INFO - 2021-01-07 02:15:27 --> Output Class Initialized
INFO - 2021-01-07 02:15:27 --> Security Class Initialized
DEBUG - 2021-01-07 02:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:15:27 --> Input Class Initialized
INFO - 2021-01-07 02:15:27 --> Language Class Initialized
INFO - 2021-01-07 02:15:27 --> Language Class Initialized
INFO - 2021-01-07 02:15:27 --> Config Class Initialized
INFO - 2021-01-07 02:15:27 --> Loader Class Initialized
INFO - 2021-01-07 02:15:27 --> Helper loaded: url_helper
INFO - 2021-01-07 02:15:27 --> Helper loaded: file_helper
INFO - 2021-01-07 02:15:27 --> Helper loaded: form_helper
INFO - 2021-01-07 02:15:27 --> Helper loaded: my_helper
INFO - 2021-01-07 02:15:27 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:15:27 --> Controller Class Initialized
INFO - 2021-01-07 02:15:27 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:15:27 --> Final output sent to browser
DEBUG - 2021-01-07 02:15:27 --> Total execution time: 0.3347
INFO - 2021-01-07 02:15:28 --> Config Class Initialized
INFO - 2021-01-07 02:15:28 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:15:28 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:15:28 --> Utf8 Class Initialized
INFO - 2021-01-07 02:15:28 --> URI Class Initialized
INFO - 2021-01-07 02:15:28 --> Router Class Initialized
INFO - 2021-01-07 02:15:28 --> Output Class Initialized
INFO - 2021-01-07 02:15:28 --> Security Class Initialized
DEBUG - 2021-01-07 02:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:15:28 --> Input Class Initialized
INFO - 2021-01-07 02:15:28 --> Language Class Initialized
INFO - 2021-01-07 02:15:28 --> Language Class Initialized
INFO - 2021-01-07 02:15:28 --> Config Class Initialized
INFO - 2021-01-07 02:15:28 --> Loader Class Initialized
INFO - 2021-01-07 02:15:28 --> Helper loaded: url_helper
INFO - 2021-01-07 02:15:28 --> Helper loaded: file_helper
INFO - 2021-01-07 02:15:28 --> Helper loaded: form_helper
INFO - 2021-01-07 02:15:28 --> Helper loaded: my_helper
INFO - 2021-01-07 02:15:28 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:15:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:15:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:15:28 --> Controller Class Initialized
DEBUG - 2021-01-07 02:15:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 02:15:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:15:28 --> Final output sent to browser
DEBUG - 2021-01-07 02:15:28 --> Total execution time: 0.4032
INFO - 2021-01-07 02:15:31 --> Config Class Initialized
INFO - 2021-01-07 02:15:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:15:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:15:31 --> Utf8 Class Initialized
INFO - 2021-01-07 02:15:31 --> URI Class Initialized
INFO - 2021-01-07 02:15:31 --> Router Class Initialized
INFO - 2021-01-07 02:15:31 --> Output Class Initialized
INFO - 2021-01-07 02:15:31 --> Security Class Initialized
DEBUG - 2021-01-07 02:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:15:31 --> Input Class Initialized
INFO - 2021-01-07 02:15:31 --> Language Class Initialized
INFO - 2021-01-07 02:15:31 --> Language Class Initialized
INFO - 2021-01-07 02:15:31 --> Config Class Initialized
INFO - 2021-01-07 02:15:31 --> Loader Class Initialized
INFO - 2021-01-07 02:15:31 --> Helper loaded: url_helper
INFO - 2021-01-07 02:15:31 --> Helper loaded: file_helper
INFO - 2021-01-07 02:15:31 --> Helper loaded: form_helper
INFO - 2021-01-07 02:15:31 --> Helper loaded: my_helper
INFO - 2021-01-07 02:15:31 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:15:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:15:31 --> Controller Class Initialized
DEBUG - 2021-01-07 02:15:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-07 02:15:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:15:31 --> Final output sent to browser
DEBUG - 2021-01-07 02:15:31 --> Total execution time: 0.2493
INFO - 2021-01-07 02:15:31 --> Config Class Initialized
INFO - 2021-01-07 02:15:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:15:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:15:31 --> Utf8 Class Initialized
INFO - 2021-01-07 02:15:31 --> URI Class Initialized
INFO - 2021-01-07 02:15:31 --> Router Class Initialized
INFO - 2021-01-07 02:15:31 --> Output Class Initialized
INFO - 2021-01-07 02:15:31 --> Security Class Initialized
DEBUG - 2021-01-07 02:15:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:15:31 --> Input Class Initialized
INFO - 2021-01-07 02:15:31 --> Language Class Initialized
INFO - 2021-01-07 02:15:31 --> Language Class Initialized
INFO - 2021-01-07 02:15:31 --> Config Class Initialized
INFO - 2021-01-07 02:15:31 --> Loader Class Initialized
INFO - 2021-01-07 02:15:31 --> Helper loaded: url_helper
INFO - 2021-01-07 02:15:31 --> Helper loaded: file_helper
INFO - 2021-01-07 02:15:31 --> Helper loaded: form_helper
INFO - 2021-01-07 02:15:31 --> Helper loaded: my_helper
INFO - 2021-01-07 02:15:31 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:15:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:15:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:15:32 --> Controller Class Initialized
INFO - 2021-01-07 02:36:14 --> Config Class Initialized
INFO - 2021-01-07 02:36:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:14 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:14 --> URI Class Initialized
INFO - 2021-01-07 02:36:14 --> Router Class Initialized
INFO - 2021-01-07 02:36:14 --> Output Class Initialized
INFO - 2021-01-07 02:36:14 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:14 --> Input Class Initialized
INFO - 2021-01-07 02:36:14 --> Language Class Initialized
INFO - 2021-01-07 02:36:14 --> Language Class Initialized
INFO - 2021-01-07 02:36:14 --> Config Class Initialized
INFO - 2021-01-07 02:36:14 --> Loader Class Initialized
INFO - 2021-01-07 02:36:14 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:14 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:14 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:14 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:14 --> Controller Class Initialized
INFO - 2021-01-07 02:36:14 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:36:14 --> Config Class Initialized
INFO - 2021-01-07 02:36:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:14 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:14 --> URI Class Initialized
INFO - 2021-01-07 02:36:14 --> Router Class Initialized
INFO - 2021-01-07 02:36:14 --> Output Class Initialized
INFO - 2021-01-07 02:36:14 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:14 --> Input Class Initialized
INFO - 2021-01-07 02:36:14 --> Language Class Initialized
INFO - 2021-01-07 02:36:14 --> Language Class Initialized
INFO - 2021-01-07 02:36:14 --> Config Class Initialized
INFO - 2021-01-07 02:36:14 --> Loader Class Initialized
INFO - 2021-01-07 02:36:14 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:14 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:14 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:14 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:14 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 02:36:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:14 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:14 --> Total execution time: 0.2850
INFO - 2021-01-07 02:36:21 --> Config Class Initialized
INFO - 2021-01-07 02:36:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:21 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:21 --> URI Class Initialized
INFO - 2021-01-07 02:36:21 --> Router Class Initialized
INFO - 2021-01-07 02:36:21 --> Output Class Initialized
INFO - 2021-01-07 02:36:21 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:21 --> Input Class Initialized
INFO - 2021-01-07 02:36:21 --> Language Class Initialized
INFO - 2021-01-07 02:36:21 --> Language Class Initialized
INFO - 2021-01-07 02:36:21 --> Config Class Initialized
INFO - 2021-01-07 02:36:21 --> Loader Class Initialized
INFO - 2021-01-07 02:36:21 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:21 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:21 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:21 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:21 --> Controller Class Initialized
INFO - 2021-01-07 02:36:21 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:36:21 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:21 --> Total execution time: 0.3636
INFO - 2021-01-07 02:36:22 --> Config Class Initialized
INFO - 2021-01-07 02:36:22 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:22 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:22 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:22 --> URI Class Initialized
INFO - 2021-01-07 02:36:22 --> Router Class Initialized
INFO - 2021-01-07 02:36:22 --> Output Class Initialized
INFO - 2021-01-07 02:36:22 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:22 --> Input Class Initialized
INFO - 2021-01-07 02:36:22 --> Language Class Initialized
INFO - 2021-01-07 02:36:22 --> Language Class Initialized
INFO - 2021-01-07 02:36:22 --> Config Class Initialized
INFO - 2021-01-07 02:36:22 --> Loader Class Initialized
INFO - 2021-01-07 02:36:22 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:22 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:22 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:22 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:22 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 02:36:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:22 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:22 --> Total execution time: 0.3987
INFO - 2021-01-07 02:36:26 --> Config Class Initialized
INFO - 2021-01-07 02:36:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:26 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:26 --> URI Class Initialized
INFO - 2021-01-07 02:36:26 --> Router Class Initialized
INFO - 2021-01-07 02:36:26 --> Output Class Initialized
INFO - 2021-01-07 02:36:26 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:26 --> Input Class Initialized
INFO - 2021-01-07 02:36:26 --> Language Class Initialized
INFO - 2021-01-07 02:36:26 --> Language Class Initialized
INFO - 2021-01-07 02:36:26 --> Config Class Initialized
INFO - 2021-01-07 02:36:26 --> Loader Class Initialized
INFO - 2021-01-07 02:36:26 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:26 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:26 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:26 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:26 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:36:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:26 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:26 --> Total execution time: 0.2729
INFO - 2021-01-07 02:36:28 --> Config Class Initialized
INFO - 2021-01-07 02:36:28 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:28 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:28 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:28 --> URI Class Initialized
INFO - 2021-01-07 02:36:28 --> Router Class Initialized
INFO - 2021-01-07 02:36:28 --> Output Class Initialized
INFO - 2021-01-07 02:36:28 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:28 --> Input Class Initialized
INFO - 2021-01-07 02:36:28 --> Language Class Initialized
INFO - 2021-01-07 02:36:28 --> Language Class Initialized
INFO - 2021-01-07 02:36:28 --> Config Class Initialized
INFO - 2021-01-07 02:36:28 --> Loader Class Initialized
INFO - 2021-01-07 02:36:28 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:28 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:28 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:28 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:28 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:28 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 02:36:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:28 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:28 --> Total execution time: 0.2759
INFO - 2021-01-07 02:36:28 --> Config Class Initialized
INFO - 2021-01-07 02:36:28 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:28 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:28 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:28 --> URI Class Initialized
INFO - 2021-01-07 02:36:28 --> Router Class Initialized
INFO - 2021-01-07 02:36:28 --> Output Class Initialized
INFO - 2021-01-07 02:36:28 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:28 --> Input Class Initialized
INFO - 2021-01-07 02:36:28 --> Language Class Initialized
INFO - 2021-01-07 02:36:28 --> Language Class Initialized
INFO - 2021-01-07 02:36:28 --> Config Class Initialized
INFO - 2021-01-07 02:36:28 --> Loader Class Initialized
INFO - 2021-01-07 02:36:28 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:28 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:28 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:28 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:28 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:28 --> Controller Class Initialized
INFO - 2021-01-07 02:36:31 --> Config Class Initialized
INFO - 2021-01-07 02:36:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:31 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:31 --> URI Class Initialized
INFO - 2021-01-07 02:36:31 --> Router Class Initialized
INFO - 2021-01-07 02:36:31 --> Output Class Initialized
INFO - 2021-01-07 02:36:31 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:31 --> Input Class Initialized
INFO - 2021-01-07 02:36:31 --> Language Class Initialized
INFO - 2021-01-07 02:36:31 --> Language Class Initialized
INFO - 2021-01-07 02:36:31 --> Config Class Initialized
INFO - 2021-01-07 02:36:31 --> Loader Class Initialized
INFO - 2021-01-07 02:36:31 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:31 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:31 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:31 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:31 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:31 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:36:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:31 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:31 --> Total execution time: 0.3167
INFO - 2021-01-07 02:36:32 --> Config Class Initialized
INFO - 2021-01-07 02:36:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:32 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:32 --> URI Class Initialized
INFO - 2021-01-07 02:36:32 --> Router Class Initialized
INFO - 2021-01-07 02:36:32 --> Output Class Initialized
INFO - 2021-01-07 02:36:32 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:32 --> Input Class Initialized
INFO - 2021-01-07 02:36:32 --> Language Class Initialized
INFO - 2021-01-07 02:36:32 --> Language Class Initialized
INFO - 2021-01-07 02:36:33 --> Config Class Initialized
INFO - 2021-01-07 02:36:33 --> Loader Class Initialized
INFO - 2021-01-07 02:36:33 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:33 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:33 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:33 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:33 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:33 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:33 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:33 --> Total execution time: 0.2982
INFO - 2021-01-07 02:36:40 --> Config Class Initialized
INFO - 2021-01-07 02:36:40 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:40 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:40 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:40 --> URI Class Initialized
INFO - 2021-01-07 02:36:40 --> Router Class Initialized
INFO - 2021-01-07 02:36:40 --> Output Class Initialized
INFO - 2021-01-07 02:36:40 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:40 --> Input Class Initialized
INFO - 2021-01-07 02:36:40 --> Language Class Initialized
INFO - 2021-01-07 02:36:40 --> Language Class Initialized
INFO - 2021-01-07 02:36:40 --> Config Class Initialized
INFO - 2021-01-07 02:36:40 --> Loader Class Initialized
INFO - 2021-01-07 02:36:40 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:40 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:40 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:40 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:40 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:40 --> Controller Class Initialized
INFO - 2021-01-07 02:36:40 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:40 --> Total execution time: 0.2188
INFO - 2021-01-07 02:36:44 --> Config Class Initialized
INFO - 2021-01-07 02:36:44 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:44 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:44 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:44 --> URI Class Initialized
INFO - 2021-01-07 02:36:44 --> Router Class Initialized
INFO - 2021-01-07 02:36:44 --> Output Class Initialized
INFO - 2021-01-07 02:36:44 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:44 --> Input Class Initialized
INFO - 2021-01-07 02:36:44 --> Language Class Initialized
INFO - 2021-01-07 02:36:44 --> Language Class Initialized
INFO - 2021-01-07 02:36:44 --> Config Class Initialized
INFO - 2021-01-07 02:36:44 --> Loader Class Initialized
INFO - 2021-01-07 02:36:44 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:44 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:44 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:44 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:44 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:44 --> Controller Class Initialized
INFO - 2021-01-07 02:36:44 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:44 --> Total execution time: 0.3740
INFO - 2021-01-07 02:36:44 --> Config Class Initialized
INFO - 2021-01-07 02:36:44 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:44 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:44 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:44 --> URI Class Initialized
INFO - 2021-01-07 02:36:44 --> Router Class Initialized
INFO - 2021-01-07 02:36:44 --> Output Class Initialized
INFO - 2021-01-07 02:36:44 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:44 --> Input Class Initialized
INFO - 2021-01-07 02:36:44 --> Language Class Initialized
INFO - 2021-01-07 02:36:44 --> Language Class Initialized
INFO - 2021-01-07 02:36:44 --> Config Class Initialized
INFO - 2021-01-07 02:36:44 --> Loader Class Initialized
INFO - 2021-01-07 02:36:44 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:44 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:44 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:44 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:44 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:44 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:36:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:44 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:44 --> Total execution time: 0.4153
INFO - 2021-01-07 02:36:47 --> Config Class Initialized
INFO - 2021-01-07 02:36:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:47 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:48 --> URI Class Initialized
INFO - 2021-01-07 02:36:48 --> Router Class Initialized
INFO - 2021-01-07 02:36:48 --> Output Class Initialized
INFO - 2021-01-07 02:36:48 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:48 --> Input Class Initialized
INFO - 2021-01-07 02:36:48 --> Language Class Initialized
INFO - 2021-01-07 02:36:48 --> Language Class Initialized
INFO - 2021-01-07 02:36:48 --> Config Class Initialized
INFO - 2021-01-07 02:36:48 --> Loader Class Initialized
INFO - 2021-01-07 02:36:48 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:48 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:48 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:48 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:48 --> Controller Class Initialized
INFO - 2021-01-07 02:36:48 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:48 --> Total execution time: 0.4080
INFO - 2021-01-07 02:36:48 --> Config Class Initialized
INFO - 2021-01-07 02:36:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:48 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:48 --> URI Class Initialized
INFO - 2021-01-07 02:36:48 --> Router Class Initialized
INFO - 2021-01-07 02:36:48 --> Output Class Initialized
INFO - 2021-01-07 02:36:48 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:48 --> Input Class Initialized
INFO - 2021-01-07 02:36:48 --> Language Class Initialized
INFO - 2021-01-07 02:36:48 --> Language Class Initialized
INFO - 2021-01-07 02:36:48 --> Config Class Initialized
INFO - 2021-01-07 02:36:48 --> Loader Class Initialized
INFO - 2021-01-07 02:36:48 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:48 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:48 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:48 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:48 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:36:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:48 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:48 --> Total execution time: 0.4682
INFO - 2021-01-07 02:36:51 --> Config Class Initialized
INFO - 2021-01-07 02:36:51 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:36:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:36:51 --> Utf8 Class Initialized
INFO - 2021-01-07 02:36:51 --> URI Class Initialized
INFO - 2021-01-07 02:36:51 --> Router Class Initialized
INFO - 2021-01-07 02:36:51 --> Output Class Initialized
INFO - 2021-01-07 02:36:51 --> Security Class Initialized
DEBUG - 2021-01-07 02:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:36:51 --> Input Class Initialized
INFO - 2021-01-07 02:36:51 --> Language Class Initialized
INFO - 2021-01-07 02:36:51 --> Language Class Initialized
INFO - 2021-01-07 02:36:51 --> Config Class Initialized
INFO - 2021-01-07 02:36:51 --> Loader Class Initialized
INFO - 2021-01-07 02:36:51 --> Helper loaded: url_helper
INFO - 2021-01-07 02:36:51 --> Helper loaded: file_helper
INFO - 2021-01-07 02:36:51 --> Helper loaded: form_helper
INFO - 2021-01-07 02:36:51 --> Helper loaded: my_helper
INFO - 2021-01-07 02:36:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:36:51 --> Controller Class Initialized
DEBUG - 2021-01-07 02:36:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:36:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:36:51 --> Final output sent to browser
DEBUG - 2021-01-07 02:36:51 --> Total execution time: 0.3339
INFO - 2021-01-07 02:37:01 --> Config Class Initialized
INFO - 2021-01-07 02:37:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:01 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:01 --> URI Class Initialized
INFO - 2021-01-07 02:37:01 --> Router Class Initialized
INFO - 2021-01-07 02:37:01 --> Output Class Initialized
INFO - 2021-01-07 02:37:01 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:01 --> Input Class Initialized
INFO - 2021-01-07 02:37:01 --> Language Class Initialized
INFO - 2021-01-07 02:37:01 --> Language Class Initialized
INFO - 2021-01-07 02:37:01 --> Config Class Initialized
INFO - 2021-01-07 02:37:01 --> Loader Class Initialized
INFO - 2021-01-07 02:37:01 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:01 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:01 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:01 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:01 --> Controller Class Initialized
INFO - 2021-01-07 02:37:01 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:01 --> Total execution time: 0.2698
INFO - 2021-01-07 02:37:17 --> Config Class Initialized
INFO - 2021-01-07 02:37:17 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:17 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:17 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:17 --> URI Class Initialized
INFO - 2021-01-07 02:37:17 --> Router Class Initialized
INFO - 2021-01-07 02:37:17 --> Output Class Initialized
INFO - 2021-01-07 02:37:18 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:18 --> Input Class Initialized
INFO - 2021-01-07 02:37:18 --> Language Class Initialized
INFO - 2021-01-07 02:37:18 --> Language Class Initialized
INFO - 2021-01-07 02:37:18 --> Config Class Initialized
INFO - 2021-01-07 02:37:18 --> Loader Class Initialized
INFO - 2021-01-07 02:37:18 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:18 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:18 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:18 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:18 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:18 --> Controller Class Initialized
INFO - 2021-01-07 02:37:18 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:18 --> Total execution time: 0.2839
INFO - 2021-01-07 02:37:18 --> Config Class Initialized
INFO - 2021-01-07 02:37:18 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:18 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:18 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:18 --> URI Class Initialized
INFO - 2021-01-07 02:37:18 --> Router Class Initialized
INFO - 2021-01-07 02:37:18 --> Output Class Initialized
INFO - 2021-01-07 02:37:18 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:18 --> Input Class Initialized
INFO - 2021-01-07 02:37:18 --> Language Class Initialized
INFO - 2021-01-07 02:37:18 --> Language Class Initialized
INFO - 2021-01-07 02:37:18 --> Config Class Initialized
INFO - 2021-01-07 02:37:18 --> Loader Class Initialized
INFO - 2021-01-07 02:37:18 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:18 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:18 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:18 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:18 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:18 --> Controller Class Initialized
DEBUG - 2021-01-07 02:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:37:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:37:18 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:18 --> Total execution time: 0.4606
INFO - 2021-01-07 02:37:20 --> Config Class Initialized
INFO - 2021-01-07 02:37:20 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:20 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:20 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:20 --> URI Class Initialized
INFO - 2021-01-07 02:37:20 --> Router Class Initialized
INFO - 2021-01-07 02:37:20 --> Output Class Initialized
INFO - 2021-01-07 02:37:20 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:20 --> Input Class Initialized
INFO - 2021-01-07 02:37:20 --> Language Class Initialized
INFO - 2021-01-07 02:37:20 --> Language Class Initialized
INFO - 2021-01-07 02:37:20 --> Config Class Initialized
INFO - 2021-01-07 02:37:20 --> Loader Class Initialized
INFO - 2021-01-07 02:37:20 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:20 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:20 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:20 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:20 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:20 --> Controller Class Initialized
INFO - 2021-01-07 02:37:20 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:20 --> Total execution time: 0.2533
INFO - 2021-01-07 02:37:29 --> Config Class Initialized
INFO - 2021-01-07 02:37:29 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:29 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:29 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:29 --> URI Class Initialized
INFO - 2021-01-07 02:37:29 --> Router Class Initialized
INFO - 2021-01-07 02:37:29 --> Output Class Initialized
INFO - 2021-01-07 02:37:29 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:29 --> Input Class Initialized
INFO - 2021-01-07 02:37:29 --> Language Class Initialized
INFO - 2021-01-07 02:37:29 --> Language Class Initialized
INFO - 2021-01-07 02:37:29 --> Config Class Initialized
INFO - 2021-01-07 02:37:29 --> Loader Class Initialized
INFO - 2021-01-07 02:37:29 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:29 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:29 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:29 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:29 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:29 --> Controller Class Initialized
INFO - 2021-01-07 02:37:29 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:29 --> Total execution time: 0.2708
INFO - 2021-01-07 02:37:29 --> Config Class Initialized
INFO - 2021-01-07 02:37:30 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:30 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:30 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:30 --> URI Class Initialized
INFO - 2021-01-07 02:37:30 --> Router Class Initialized
INFO - 2021-01-07 02:37:30 --> Output Class Initialized
INFO - 2021-01-07 02:37:30 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:30 --> Input Class Initialized
INFO - 2021-01-07 02:37:30 --> Language Class Initialized
INFO - 2021-01-07 02:37:30 --> Language Class Initialized
INFO - 2021-01-07 02:37:30 --> Config Class Initialized
INFO - 2021-01-07 02:37:30 --> Loader Class Initialized
INFO - 2021-01-07 02:37:30 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:30 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:30 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:30 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:30 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:30 --> Controller Class Initialized
DEBUG - 2021-01-07 02:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:37:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:37:30 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:30 --> Total execution time: 0.4136
INFO - 2021-01-07 02:37:32 --> Config Class Initialized
INFO - 2021-01-07 02:37:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:32 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:32 --> URI Class Initialized
INFO - 2021-01-07 02:37:32 --> Router Class Initialized
INFO - 2021-01-07 02:37:32 --> Output Class Initialized
INFO - 2021-01-07 02:37:32 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:32 --> Input Class Initialized
INFO - 2021-01-07 02:37:32 --> Language Class Initialized
INFO - 2021-01-07 02:37:32 --> Language Class Initialized
INFO - 2021-01-07 02:37:32 --> Config Class Initialized
INFO - 2021-01-07 02:37:32 --> Loader Class Initialized
INFO - 2021-01-07 02:37:32 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:32 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:32 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:32 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:32 --> Controller Class Initialized
INFO - 2021-01-07 02:37:32 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:32 --> Total execution time: 0.2064
INFO - 2021-01-07 02:37:41 --> Config Class Initialized
INFO - 2021-01-07 02:37:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:41 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:41 --> URI Class Initialized
INFO - 2021-01-07 02:37:41 --> Router Class Initialized
INFO - 2021-01-07 02:37:41 --> Output Class Initialized
INFO - 2021-01-07 02:37:41 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:41 --> Input Class Initialized
INFO - 2021-01-07 02:37:41 --> Language Class Initialized
INFO - 2021-01-07 02:37:41 --> Language Class Initialized
INFO - 2021-01-07 02:37:41 --> Config Class Initialized
INFO - 2021-01-07 02:37:41 --> Loader Class Initialized
INFO - 2021-01-07 02:37:41 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:41 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:41 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:41 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:41 --> Controller Class Initialized
INFO - 2021-01-07 02:37:41 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:41 --> Total execution time: 0.3760
INFO - 2021-01-07 02:37:47 --> Config Class Initialized
INFO - 2021-01-07 02:37:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:47 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:47 --> URI Class Initialized
INFO - 2021-01-07 02:37:47 --> Router Class Initialized
INFO - 2021-01-07 02:37:47 --> Output Class Initialized
INFO - 2021-01-07 02:37:47 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:47 --> Input Class Initialized
INFO - 2021-01-07 02:37:47 --> Language Class Initialized
INFO - 2021-01-07 02:37:47 --> Language Class Initialized
INFO - 2021-01-07 02:37:47 --> Config Class Initialized
INFO - 2021-01-07 02:37:47 --> Loader Class Initialized
INFO - 2021-01-07 02:37:47 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:47 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:47 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:47 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:47 --> Controller Class Initialized
INFO - 2021-01-07 02:37:47 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:47 --> Total execution time: 0.2406
INFO - 2021-01-07 02:37:51 --> Config Class Initialized
INFO - 2021-01-07 02:37:51 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:37:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:37:51 --> Utf8 Class Initialized
INFO - 2021-01-07 02:37:51 --> URI Class Initialized
INFO - 2021-01-07 02:37:51 --> Router Class Initialized
INFO - 2021-01-07 02:37:51 --> Output Class Initialized
INFO - 2021-01-07 02:37:51 --> Security Class Initialized
DEBUG - 2021-01-07 02:37:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:37:51 --> Input Class Initialized
INFO - 2021-01-07 02:37:51 --> Language Class Initialized
INFO - 2021-01-07 02:37:51 --> Language Class Initialized
INFO - 2021-01-07 02:37:51 --> Config Class Initialized
INFO - 2021-01-07 02:37:51 --> Loader Class Initialized
INFO - 2021-01-07 02:37:51 --> Helper loaded: url_helper
INFO - 2021-01-07 02:37:51 --> Helper loaded: file_helper
INFO - 2021-01-07 02:37:51 --> Helper loaded: form_helper
INFO - 2021-01-07 02:37:51 --> Helper loaded: my_helper
INFO - 2021-01-07 02:37:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:37:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:37:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:37:51 --> Controller Class Initialized
INFO - 2021-01-07 02:37:51 --> Final output sent to browser
DEBUG - 2021-01-07 02:37:51 --> Total execution time: 0.3503
INFO - 2021-01-07 02:38:03 --> Config Class Initialized
INFO - 2021-01-07 02:38:03 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:38:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:38:03 --> Utf8 Class Initialized
INFO - 2021-01-07 02:38:04 --> URI Class Initialized
INFO - 2021-01-07 02:38:04 --> Router Class Initialized
INFO - 2021-01-07 02:38:04 --> Output Class Initialized
INFO - 2021-01-07 02:38:04 --> Security Class Initialized
DEBUG - 2021-01-07 02:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:38:04 --> Input Class Initialized
INFO - 2021-01-07 02:38:04 --> Language Class Initialized
INFO - 2021-01-07 02:38:04 --> Language Class Initialized
INFO - 2021-01-07 02:38:04 --> Config Class Initialized
INFO - 2021-01-07 02:38:04 --> Loader Class Initialized
INFO - 2021-01-07 02:38:04 --> Helper loaded: url_helper
INFO - 2021-01-07 02:38:04 --> Helper loaded: file_helper
INFO - 2021-01-07 02:38:04 --> Helper loaded: form_helper
INFO - 2021-01-07 02:38:04 --> Helper loaded: my_helper
INFO - 2021-01-07 02:38:04 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:38:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:38:04 --> Controller Class Initialized
INFO - 2021-01-07 02:38:04 --> Final output sent to browser
DEBUG - 2021-01-07 02:38:04 --> Total execution time: 0.3420
INFO - 2021-01-07 02:38:08 --> Config Class Initialized
INFO - 2021-01-07 02:38:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:38:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:38:08 --> Utf8 Class Initialized
INFO - 2021-01-07 02:38:08 --> URI Class Initialized
INFO - 2021-01-07 02:38:08 --> Router Class Initialized
INFO - 2021-01-07 02:38:08 --> Output Class Initialized
INFO - 2021-01-07 02:38:08 --> Security Class Initialized
DEBUG - 2021-01-07 02:38:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:38:08 --> Input Class Initialized
INFO - 2021-01-07 02:38:08 --> Language Class Initialized
INFO - 2021-01-07 02:38:08 --> Language Class Initialized
INFO - 2021-01-07 02:38:08 --> Config Class Initialized
INFO - 2021-01-07 02:38:08 --> Loader Class Initialized
INFO - 2021-01-07 02:38:08 --> Helper loaded: url_helper
INFO - 2021-01-07 02:38:08 --> Helper loaded: file_helper
INFO - 2021-01-07 02:38:09 --> Helper loaded: form_helper
INFO - 2021-01-07 02:38:09 --> Helper loaded: my_helper
INFO - 2021-01-07 02:38:09 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:38:09 --> Controller Class Initialized
DEBUG - 2021-01-07 02:38:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 02:38:09 --> Final output sent to browser
DEBUG - 2021-01-07 02:38:09 --> Total execution time: 0.2601
INFO - 2021-01-07 02:38:16 --> Config Class Initialized
INFO - 2021-01-07 02:38:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:38:17 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:38:17 --> Utf8 Class Initialized
INFO - 2021-01-07 02:38:17 --> URI Class Initialized
INFO - 2021-01-07 02:38:17 --> Router Class Initialized
INFO - 2021-01-07 02:38:17 --> Output Class Initialized
INFO - 2021-01-07 02:38:17 --> Security Class Initialized
DEBUG - 2021-01-07 02:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:38:17 --> Input Class Initialized
INFO - 2021-01-07 02:38:17 --> Language Class Initialized
INFO - 2021-01-07 02:38:17 --> Language Class Initialized
INFO - 2021-01-07 02:38:17 --> Config Class Initialized
INFO - 2021-01-07 02:38:17 --> Loader Class Initialized
INFO - 2021-01-07 02:38:17 --> Helper loaded: url_helper
INFO - 2021-01-07 02:38:17 --> Helper loaded: file_helper
INFO - 2021-01-07 02:38:17 --> Helper loaded: form_helper
INFO - 2021-01-07 02:38:17 --> Helper loaded: my_helper
INFO - 2021-01-07 02:38:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:38:17 --> Controller Class Initialized
DEBUG - 2021-01-07 02:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:38:17 --> Final output sent to browser
DEBUG - 2021-01-07 02:38:17 --> Total execution time: 0.2718
INFO - 2021-01-07 02:38:46 --> Config Class Initialized
INFO - 2021-01-07 02:38:46 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:38:46 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:38:46 --> Utf8 Class Initialized
INFO - 2021-01-07 02:38:46 --> URI Class Initialized
INFO - 2021-01-07 02:38:46 --> Router Class Initialized
INFO - 2021-01-07 02:38:46 --> Output Class Initialized
INFO - 2021-01-07 02:38:46 --> Security Class Initialized
DEBUG - 2021-01-07 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:38:46 --> Input Class Initialized
INFO - 2021-01-07 02:38:46 --> Language Class Initialized
INFO - 2021-01-07 02:38:46 --> Language Class Initialized
INFO - 2021-01-07 02:38:46 --> Config Class Initialized
INFO - 2021-01-07 02:38:46 --> Loader Class Initialized
INFO - 2021-01-07 02:38:46 --> Helper loaded: url_helper
INFO - 2021-01-07 02:38:46 --> Helper loaded: file_helper
INFO - 2021-01-07 02:38:46 --> Helper loaded: form_helper
INFO - 2021-01-07 02:38:46 --> Helper loaded: my_helper
INFO - 2021-01-07 02:38:46 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:38:46 --> Controller Class Initialized
INFO - 2021-01-07 02:38:47 --> Final output sent to browser
DEBUG - 2021-01-07 02:38:47 --> Total execution time: 0.3762
INFO - 2021-01-07 02:38:50 --> Config Class Initialized
INFO - 2021-01-07 02:38:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:38:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:38:50 --> Utf8 Class Initialized
INFO - 2021-01-07 02:38:50 --> URI Class Initialized
INFO - 2021-01-07 02:38:50 --> Router Class Initialized
INFO - 2021-01-07 02:38:50 --> Output Class Initialized
INFO - 2021-01-07 02:38:50 --> Security Class Initialized
DEBUG - 2021-01-07 02:38:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:38:50 --> Input Class Initialized
INFO - 2021-01-07 02:38:50 --> Language Class Initialized
INFO - 2021-01-07 02:38:50 --> Language Class Initialized
INFO - 2021-01-07 02:38:50 --> Config Class Initialized
INFO - 2021-01-07 02:38:50 --> Loader Class Initialized
INFO - 2021-01-07 02:38:50 --> Helper loaded: url_helper
INFO - 2021-01-07 02:38:50 --> Helper loaded: file_helper
INFO - 2021-01-07 02:38:50 --> Helper loaded: form_helper
INFO - 2021-01-07 02:38:50 --> Helper loaded: my_helper
INFO - 2021-01-07 02:38:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:38:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:38:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:38:50 --> Controller Class Initialized
DEBUG - 2021-01-07 02:38:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 02:38:50 --> Final output sent to browser
DEBUG - 2021-01-07 02:38:50 --> Total execution time: 0.2825
INFO - 2021-01-07 02:38:56 --> Config Class Initialized
INFO - 2021-01-07 02:38:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:38:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:38:56 --> Utf8 Class Initialized
INFO - 2021-01-07 02:38:56 --> URI Class Initialized
INFO - 2021-01-07 02:38:56 --> Router Class Initialized
INFO - 2021-01-07 02:38:56 --> Output Class Initialized
INFO - 2021-01-07 02:38:56 --> Security Class Initialized
DEBUG - 2021-01-07 02:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:38:56 --> Input Class Initialized
INFO - 2021-01-07 02:38:56 --> Language Class Initialized
INFO - 2021-01-07 02:38:56 --> Language Class Initialized
INFO - 2021-01-07 02:38:56 --> Config Class Initialized
INFO - 2021-01-07 02:38:56 --> Loader Class Initialized
INFO - 2021-01-07 02:38:56 --> Helper loaded: url_helper
INFO - 2021-01-07 02:38:56 --> Helper loaded: file_helper
INFO - 2021-01-07 02:38:56 --> Helper loaded: form_helper
INFO - 2021-01-07 02:38:56 --> Helper loaded: my_helper
INFO - 2021-01-07 02:38:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:38:56 --> Controller Class Initialized
DEBUG - 2021-01-07 02:38:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:38:56 --> Final output sent to browser
DEBUG - 2021-01-07 02:38:56 --> Total execution time: 0.2547
INFO - 2021-01-07 02:41:00 --> Config Class Initialized
INFO - 2021-01-07 02:41:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:41:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:41:00 --> Utf8 Class Initialized
INFO - 2021-01-07 02:41:00 --> URI Class Initialized
INFO - 2021-01-07 02:41:00 --> Router Class Initialized
INFO - 2021-01-07 02:41:00 --> Output Class Initialized
INFO - 2021-01-07 02:41:00 --> Security Class Initialized
DEBUG - 2021-01-07 02:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:41:00 --> Input Class Initialized
INFO - 2021-01-07 02:41:00 --> Language Class Initialized
INFO - 2021-01-07 02:41:00 --> Language Class Initialized
INFO - 2021-01-07 02:41:00 --> Config Class Initialized
INFO - 2021-01-07 02:41:00 --> Loader Class Initialized
INFO - 2021-01-07 02:41:00 --> Helper loaded: url_helper
INFO - 2021-01-07 02:41:00 --> Helper loaded: file_helper
INFO - 2021-01-07 02:41:00 --> Helper loaded: form_helper
INFO - 2021-01-07 02:41:00 --> Helper loaded: my_helper
INFO - 2021-01-07 02:41:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:41:00 --> Controller Class Initialized
DEBUG - 2021-01-07 02:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:41:00 --> Final output sent to browser
DEBUG - 2021-01-07 02:41:00 --> Total execution time: 0.3297
INFO - 2021-01-07 02:41:01 --> Config Class Initialized
INFO - 2021-01-07 02:41:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:41:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:41:01 --> Utf8 Class Initialized
INFO - 2021-01-07 02:41:01 --> URI Class Initialized
INFO - 2021-01-07 02:41:01 --> Router Class Initialized
INFO - 2021-01-07 02:41:01 --> Output Class Initialized
INFO - 2021-01-07 02:41:01 --> Security Class Initialized
DEBUG - 2021-01-07 02:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:41:01 --> Input Class Initialized
INFO - 2021-01-07 02:41:01 --> Language Class Initialized
INFO - 2021-01-07 02:41:01 --> Language Class Initialized
INFO - 2021-01-07 02:41:01 --> Config Class Initialized
INFO - 2021-01-07 02:41:01 --> Loader Class Initialized
INFO - 2021-01-07 02:41:01 --> Helper loaded: url_helper
INFO - 2021-01-07 02:41:01 --> Helper loaded: file_helper
INFO - 2021-01-07 02:41:01 --> Helper loaded: form_helper
INFO - 2021-01-07 02:41:01 --> Helper loaded: my_helper
INFO - 2021-01-07 02:41:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:41:01 --> Controller Class Initialized
DEBUG - 2021-01-07 02:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 02:41:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:41:01 --> Final output sent to browser
DEBUG - 2021-01-07 02:41:01 --> Total execution time: 0.2912
INFO - 2021-01-07 02:41:01 --> Config Class Initialized
INFO - 2021-01-07 02:41:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:41:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:41:01 --> Utf8 Class Initialized
INFO - 2021-01-07 02:41:01 --> URI Class Initialized
INFO - 2021-01-07 02:41:01 --> Router Class Initialized
INFO - 2021-01-07 02:41:01 --> Output Class Initialized
INFO - 2021-01-07 02:41:01 --> Security Class Initialized
DEBUG - 2021-01-07 02:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:41:01 --> Input Class Initialized
INFO - 2021-01-07 02:41:01 --> Language Class Initialized
INFO - 2021-01-07 02:41:01 --> Language Class Initialized
INFO - 2021-01-07 02:41:01 --> Config Class Initialized
INFO - 2021-01-07 02:41:01 --> Loader Class Initialized
INFO - 2021-01-07 02:41:01 --> Helper loaded: url_helper
INFO - 2021-01-07 02:41:01 --> Helper loaded: file_helper
INFO - 2021-01-07 02:41:01 --> Helper loaded: form_helper
INFO - 2021-01-07 02:41:01 --> Helper loaded: my_helper
INFO - 2021-01-07 02:41:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:41:02 --> Controller Class Initialized
INFO - 2021-01-07 02:42:03 --> Config Class Initialized
INFO - 2021-01-07 02:42:03 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:03 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:03 --> URI Class Initialized
INFO - 2021-01-07 02:42:03 --> Router Class Initialized
INFO - 2021-01-07 02:42:03 --> Output Class Initialized
INFO - 2021-01-07 02:42:03 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:03 --> Input Class Initialized
INFO - 2021-01-07 02:42:03 --> Language Class Initialized
INFO - 2021-01-07 02:42:03 --> Language Class Initialized
INFO - 2021-01-07 02:42:03 --> Config Class Initialized
INFO - 2021-01-07 02:42:03 --> Loader Class Initialized
INFO - 2021-01-07 02:42:03 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:03 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:03 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:03 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:03 --> Controller Class Initialized
DEBUG - 2021-01-07 02:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:42:03 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:03 --> Total execution time: 0.2669
INFO - 2021-01-07 02:42:06 --> Config Class Initialized
INFO - 2021-01-07 02:42:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:06 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:06 --> URI Class Initialized
INFO - 2021-01-07 02:42:06 --> Router Class Initialized
INFO - 2021-01-07 02:42:06 --> Output Class Initialized
INFO - 2021-01-07 02:42:06 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:06 --> Input Class Initialized
INFO - 2021-01-07 02:42:06 --> Language Class Initialized
INFO - 2021-01-07 02:42:06 --> Language Class Initialized
INFO - 2021-01-07 02:42:06 --> Config Class Initialized
INFO - 2021-01-07 02:42:06 --> Loader Class Initialized
INFO - 2021-01-07 02:42:06 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:06 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:06 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:06 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:06 --> Controller Class Initialized
DEBUG - 2021-01-07 02:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 02:42:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:42:06 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:07 --> Total execution time: 0.2919
INFO - 2021-01-07 02:42:07 --> Config Class Initialized
INFO - 2021-01-07 02:42:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:07 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:07 --> URI Class Initialized
INFO - 2021-01-07 02:42:07 --> Router Class Initialized
INFO - 2021-01-07 02:42:07 --> Output Class Initialized
INFO - 2021-01-07 02:42:07 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:07 --> Input Class Initialized
INFO - 2021-01-07 02:42:07 --> Language Class Initialized
INFO - 2021-01-07 02:42:07 --> Language Class Initialized
INFO - 2021-01-07 02:42:07 --> Config Class Initialized
INFO - 2021-01-07 02:42:07 --> Loader Class Initialized
INFO - 2021-01-07 02:42:07 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:07 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:07 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:07 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:07 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:07 --> Controller Class Initialized
INFO - 2021-01-07 02:42:09 --> Config Class Initialized
INFO - 2021-01-07 02:42:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:09 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:09 --> URI Class Initialized
INFO - 2021-01-07 02:42:09 --> Router Class Initialized
INFO - 2021-01-07 02:42:09 --> Output Class Initialized
INFO - 2021-01-07 02:42:09 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:09 --> Input Class Initialized
INFO - 2021-01-07 02:42:09 --> Language Class Initialized
INFO - 2021-01-07 02:42:09 --> Language Class Initialized
INFO - 2021-01-07 02:42:09 --> Config Class Initialized
INFO - 2021-01-07 02:42:09 --> Loader Class Initialized
INFO - 2021-01-07 02:42:09 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:09 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:09 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:09 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:09 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:09 --> Controller Class Initialized
INFO - 2021-01-07 02:42:09 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:09 --> Total execution time: 0.2309
INFO - 2021-01-07 02:42:12 --> Config Class Initialized
INFO - 2021-01-07 02:42:12 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:12 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:12 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:12 --> URI Class Initialized
INFO - 2021-01-07 02:42:12 --> Router Class Initialized
INFO - 2021-01-07 02:42:12 --> Output Class Initialized
INFO - 2021-01-07 02:42:12 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:12 --> Input Class Initialized
INFO - 2021-01-07 02:42:12 --> Language Class Initialized
INFO - 2021-01-07 02:42:12 --> Language Class Initialized
INFO - 2021-01-07 02:42:12 --> Config Class Initialized
INFO - 2021-01-07 02:42:12 --> Loader Class Initialized
INFO - 2021-01-07 02:42:12 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:12 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:12 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:12 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:12 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:12 --> Controller Class Initialized
INFO - 2021-01-07 02:42:12 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:12 --> Total execution time: 0.3122
INFO - 2021-01-07 02:42:12 --> Config Class Initialized
INFO - 2021-01-07 02:42:12 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:12 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:12 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:12 --> URI Class Initialized
INFO - 2021-01-07 02:42:13 --> Router Class Initialized
INFO - 2021-01-07 02:42:13 --> Output Class Initialized
INFO - 2021-01-07 02:42:13 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:13 --> Input Class Initialized
INFO - 2021-01-07 02:42:13 --> Language Class Initialized
INFO - 2021-01-07 02:42:13 --> Language Class Initialized
INFO - 2021-01-07 02:42:13 --> Config Class Initialized
INFO - 2021-01-07 02:42:13 --> Loader Class Initialized
INFO - 2021-01-07 02:42:13 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:13 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:13 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:13 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:13 --> Controller Class Initialized
INFO - 2021-01-07 02:42:14 --> Config Class Initialized
INFO - 2021-01-07 02:42:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:14 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:14 --> URI Class Initialized
INFO - 2021-01-07 02:42:14 --> Router Class Initialized
INFO - 2021-01-07 02:42:14 --> Output Class Initialized
INFO - 2021-01-07 02:42:14 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:14 --> Input Class Initialized
INFO - 2021-01-07 02:42:14 --> Language Class Initialized
INFO - 2021-01-07 02:42:14 --> Language Class Initialized
INFO - 2021-01-07 02:42:14 --> Config Class Initialized
INFO - 2021-01-07 02:42:14 --> Loader Class Initialized
INFO - 2021-01-07 02:42:14 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:14 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:14 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:14 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:14 --> Controller Class Initialized
INFO - 2021-01-07 02:42:14 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:14 --> Total execution time: 0.2147
INFO - 2021-01-07 02:42:19 --> Config Class Initialized
INFO - 2021-01-07 02:42:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:19 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:19 --> URI Class Initialized
INFO - 2021-01-07 02:42:19 --> Router Class Initialized
INFO - 2021-01-07 02:42:19 --> Output Class Initialized
INFO - 2021-01-07 02:42:19 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:19 --> Input Class Initialized
INFO - 2021-01-07 02:42:19 --> Language Class Initialized
INFO - 2021-01-07 02:42:19 --> Language Class Initialized
INFO - 2021-01-07 02:42:19 --> Config Class Initialized
INFO - 2021-01-07 02:42:19 --> Loader Class Initialized
INFO - 2021-01-07 02:42:19 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:19 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:19 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:19 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:19 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:19 --> Controller Class Initialized
DEBUG - 2021-01-07 02:42:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:42:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:42:19 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:19 --> Total execution time: 0.4393
INFO - 2021-01-07 02:42:21 --> Config Class Initialized
INFO - 2021-01-07 02:42:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:21 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:21 --> URI Class Initialized
INFO - 2021-01-07 02:42:21 --> Router Class Initialized
INFO - 2021-01-07 02:42:21 --> Output Class Initialized
INFO - 2021-01-07 02:42:21 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:21 --> Input Class Initialized
INFO - 2021-01-07 02:42:21 --> Language Class Initialized
INFO - 2021-01-07 02:42:21 --> Language Class Initialized
INFO - 2021-01-07 02:42:21 --> Config Class Initialized
INFO - 2021-01-07 02:42:21 --> Loader Class Initialized
INFO - 2021-01-07 02:42:21 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:21 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:21 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:21 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:21 --> Controller Class Initialized
DEBUG - 2021-01-07 02:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 02:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:42:21 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:21 --> Total execution time: 0.3221
INFO - 2021-01-07 02:42:22 --> Config Class Initialized
INFO - 2021-01-07 02:42:22 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:22 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:22 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:22 --> URI Class Initialized
INFO - 2021-01-07 02:42:22 --> Router Class Initialized
INFO - 2021-01-07 02:42:22 --> Output Class Initialized
INFO - 2021-01-07 02:42:22 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:22 --> Input Class Initialized
INFO - 2021-01-07 02:42:22 --> Language Class Initialized
INFO - 2021-01-07 02:42:22 --> Language Class Initialized
INFO - 2021-01-07 02:42:22 --> Config Class Initialized
INFO - 2021-01-07 02:42:22 --> Loader Class Initialized
INFO - 2021-01-07 02:42:22 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:22 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:22 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:22 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:22 --> Controller Class Initialized
INFO - 2021-01-07 02:42:34 --> Config Class Initialized
INFO - 2021-01-07 02:42:34 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:34 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:34 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:34 --> URI Class Initialized
INFO - 2021-01-07 02:42:34 --> Router Class Initialized
INFO - 2021-01-07 02:42:34 --> Output Class Initialized
INFO - 2021-01-07 02:42:34 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:34 --> Input Class Initialized
INFO - 2021-01-07 02:42:34 --> Language Class Initialized
INFO - 2021-01-07 02:42:34 --> Language Class Initialized
INFO - 2021-01-07 02:42:34 --> Config Class Initialized
INFO - 2021-01-07 02:42:34 --> Loader Class Initialized
INFO - 2021-01-07 02:42:34 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:34 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:34 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:34 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:34 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:34 --> Controller Class Initialized
INFO - 2021-01-07 02:42:34 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:34 --> Total execution time: 0.2654
INFO - 2021-01-07 02:42:52 --> Config Class Initialized
INFO - 2021-01-07 02:42:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:52 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:52 --> URI Class Initialized
INFO - 2021-01-07 02:42:52 --> Router Class Initialized
INFO - 2021-01-07 02:42:52 --> Output Class Initialized
INFO - 2021-01-07 02:42:52 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:52 --> Input Class Initialized
INFO - 2021-01-07 02:42:52 --> Language Class Initialized
INFO - 2021-01-07 02:42:52 --> Language Class Initialized
INFO - 2021-01-07 02:42:52 --> Config Class Initialized
INFO - 2021-01-07 02:42:52 --> Loader Class Initialized
INFO - 2021-01-07 02:42:52 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:52 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:52 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:52 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:52 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:52 --> Controller Class Initialized
INFO - 2021-01-07 02:42:52 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:52 --> Total execution time: 0.2766
INFO - 2021-01-07 02:42:52 --> Config Class Initialized
INFO - 2021-01-07 02:42:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:52 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:52 --> URI Class Initialized
INFO - 2021-01-07 02:42:52 --> Router Class Initialized
INFO - 2021-01-07 02:42:52 --> Output Class Initialized
INFO - 2021-01-07 02:42:52 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:52 --> Input Class Initialized
INFO - 2021-01-07 02:42:52 --> Language Class Initialized
INFO - 2021-01-07 02:42:52 --> Language Class Initialized
INFO - 2021-01-07 02:42:52 --> Config Class Initialized
INFO - 2021-01-07 02:42:52 --> Loader Class Initialized
INFO - 2021-01-07 02:42:52 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:52 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:52 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:52 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:52 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:52 --> Controller Class Initialized
INFO - 2021-01-07 02:42:55 --> Config Class Initialized
INFO - 2021-01-07 02:42:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:42:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:42:55 --> Utf8 Class Initialized
INFO - 2021-01-07 02:42:55 --> URI Class Initialized
INFO - 2021-01-07 02:42:55 --> Router Class Initialized
INFO - 2021-01-07 02:42:55 --> Output Class Initialized
INFO - 2021-01-07 02:42:55 --> Security Class Initialized
DEBUG - 2021-01-07 02:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:42:55 --> Input Class Initialized
INFO - 2021-01-07 02:42:55 --> Language Class Initialized
INFO - 2021-01-07 02:42:55 --> Language Class Initialized
INFO - 2021-01-07 02:42:55 --> Config Class Initialized
INFO - 2021-01-07 02:42:55 --> Loader Class Initialized
INFO - 2021-01-07 02:42:55 --> Helper loaded: url_helper
INFO - 2021-01-07 02:42:55 --> Helper loaded: file_helper
INFO - 2021-01-07 02:42:55 --> Helper loaded: form_helper
INFO - 2021-01-07 02:42:55 --> Helper loaded: my_helper
INFO - 2021-01-07 02:42:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:42:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:42:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:42:55 --> Controller Class Initialized
INFO - 2021-01-07 02:42:55 --> Final output sent to browser
DEBUG - 2021-01-07 02:42:55 --> Total execution time: 0.2855
INFO - 2021-01-07 02:43:10 --> Config Class Initialized
INFO - 2021-01-07 02:43:10 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:10 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:10 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:10 --> URI Class Initialized
INFO - 2021-01-07 02:43:10 --> Router Class Initialized
INFO - 2021-01-07 02:43:10 --> Output Class Initialized
INFO - 2021-01-07 02:43:10 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:10 --> Input Class Initialized
INFO - 2021-01-07 02:43:10 --> Language Class Initialized
INFO - 2021-01-07 02:43:10 --> Language Class Initialized
INFO - 2021-01-07 02:43:10 --> Config Class Initialized
INFO - 2021-01-07 02:43:10 --> Loader Class Initialized
INFO - 2021-01-07 02:43:10 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:10 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:10 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:10 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:10 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:10 --> Controller Class Initialized
INFO - 2021-01-07 02:43:10 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:10 --> Total execution time: 0.2868
INFO - 2021-01-07 02:43:10 --> Config Class Initialized
INFO - 2021-01-07 02:43:10 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:10 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:10 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:10 --> URI Class Initialized
INFO - 2021-01-07 02:43:10 --> Router Class Initialized
INFO - 2021-01-07 02:43:10 --> Output Class Initialized
INFO - 2021-01-07 02:43:10 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:10 --> Input Class Initialized
INFO - 2021-01-07 02:43:10 --> Language Class Initialized
INFO - 2021-01-07 02:43:10 --> Language Class Initialized
INFO - 2021-01-07 02:43:10 --> Config Class Initialized
INFO - 2021-01-07 02:43:10 --> Loader Class Initialized
INFO - 2021-01-07 02:43:10 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:10 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:10 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:10 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:11 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:11 --> Controller Class Initialized
INFO - 2021-01-07 02:43:13 --> Config Class Initialized
INFO - 2021-01-07 02:43:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:13 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:13 --> URI Class Initialized
INFO - 2021-01-07 02:43:13 --> Router Class Initialized
INFO - 2021-01-07 02:43:13 --> Output Class Initialized
INFO - 2021-01-07 02:43:13 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:13 --> Input Class Initialized
INFO - 2021-01-07 02:43:13 --> Language Class Initialized
INFO - 2021-01-07 02:43:13 --> Language Class Initialized
INFO - 2021-01-07 02:43:13 --> Config Class Initialized
INFO - 2021-01-07 02:43:13 --> Loader Class Initialized
INFO - 2021-01-07 02:43:13 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:13 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:13 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:13 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:13 --> Controller Class Initialized
INFO - 2021-01-07 02:43:13 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:13 --> Total execution time: 0.2183
INFO - 2021-01-07 02:43:22 --> Config Class Initialized
INFO - 2021-01-07 02:43:22 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:22 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:22 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:22 --> URI Class Initialized
INFO - 2021-01-07 02:43:22 --> Router Class Initialized
INFO - 2021-01-07 02:43:22 --> Output Class Initialized
INFO - 2021-01-07 02:43:22 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:22 --> Input Class Initialized
INFO - 2021-01-07 02:43:22 --> Language Class Initialized
INFO - 2021-01-07 02:43:22 --> Language Class Initialized
INFO - 2021-01-07 02:43:22 --> Config Class Initialized
INFO - 2021-01-07 02:43:22 --> Loader Class Initialized
INFO - 2021-01-07 02:43:22 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:22 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:22 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:22 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:23 --> Controller Class Initialized
INFO - 2021-01-07 02:43:23 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:23 --> Total execution time: 0.3439
INFO - 2021-01-07 02:43:30 --> Config Class Initialized
INFO - 2021-01-07 02:43:30 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:30 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:30 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:30 --> URI Class Initialized
INFO - 2021-01-07 02:43:30 --> Router Class Initialized
INFO - 2021-01-07 02:43:30 --> Output Class Initialized
INFO - 2021-01-07 02:43:30 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:30 --> Input Class Initialized
INFO - 2021-01-07 02:43:30 --> Language Class Initialized
INFO - 2021-01-07 02:43:30 --> Language Class Initialized
INFO - 2021-01-07 02:43:30 --> Config Class Initialized
INFO - 2021-01-07 02:43:30 --> Loader Class Initialized
INFO - 2021-01-07 02:43:30 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:30 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:30 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:30 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:30 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:30 --> Controller Class Initialized
INFO - 2021-01-07 02:43:30 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:30 --> Total execution time: 0.2314
INFO - 2021-01-07 02:43:40 --> Config Class Initialized
INFO - 2021-01-07 02:43:40 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:40 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:40 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:40 --> URI Class Initialized
INFO - 2021-01-07 02:43:40 --> Router Class Initialized
INFO - 2021-01-07 02:43:40 --> Output Class Initialized
INFO - 2021-01-07 02:43:40 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:40 --> Input Class Initialized
INFO - 2021-01-07 02:43:40 --> Language Class Initialized
INFO - 2021-01-07 02:43:40 --> Language Class Initialized
INFO - 2021-01-07 02:43:40 --> Config Class Initialized
INFO - 2021-01-07 02:43:40 --> Loader Class Initialized
INFO - 2021-01-07 02:43:40 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:40 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:40 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:40 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:40 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:40 --> Controller Class Initialized
INFO - 2021-01-07 02:43:40 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:40 --> Total execution time: 0.3749
INFO - 2021-01-07 02:43:44 --> Config Class Initialized
INFO - 2021-01-07 02:43:44 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:44 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:44 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:44 --> URI Class Initialized
INFO - 2021-01-07 02:43:44 --> Router Class Initialized
INFO - 2021-01-07 02:43:44 --> Output Class Initialized
INFO - 2021-01-07 02:43:44 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:44 --> Input Class Initialized
INFO - 2021-01-07 02:43:44 --> Language Class Initialized
INFO - 2021-01-07 02:43:44 --> Language Class Initialized
INFO - 2021-01-07 02:43:44 --> Config Class Initialized
INFO - 2021-01-07 02:43:44 --> Loader Class Initialized
INFO - 2021-01-07 02:43:44 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:44 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:44 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:44 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:44 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:44 --> Controller Class Initialized
INFO - 2021-01-07 02:43:44 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:44 --> Total execution time: 0.2202
INFO - 2021-01-07 02:43:52 --> Config Class Initialized
INFO - 2021-01-07 02:43:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:52 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:52 --> URI Class Initialized
INFO - 2021-01-07 02:43:52 --> Router Class Initialized
INFO - 2021-01-07 02:43:52 --> Output Class Initialized
INFO - 2021-01-07 02:43:52 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:52 --> Input Class Initialized
INFO - 2021-01-07 02:43:52 --> Language Class Initialized
INFO - 2021-01-07 02:43:53 --> Language Class Initialized
INFO - 2021-01-07 02:43:53 --> Config Class Initialized
INFO - 2021-01-07 02:43:53 --> Loader Class Initialized
INFO - 2021-01-07 02:43:53 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:53 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:53 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:53 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:53 --> Controller Class Initialized
INFO - 2021-01-07 02:43:53 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:53 --> Total execution time: 0.3471
INFO - 2021-01-07 02:43:56 --> Config Class Initialized
INFO - 2021-01-07 02:43:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:43:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:43:56 --> Utf8 Class Initialized
INFO - 2021-01-07 02:43:56 --> URI Class Initialized
INFO - 2021-01-07 02:43:56 --> Router Class Initialized
INFO - 2021-01-07 02:43:56 --> Output Class Initialized
INFO - 2021-01-07 02:43:56 --> Security Class Initialized
DEBUG - 2021-01-07 02:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:43:56 --> Input Class Initialized
INFO - 2021-01-07 02:43:56 --> Language Class Initialized
INFO - 2021-01-07 02:43:56 --> Language Class Initialized
INFO - 2021-01-07 02:43:56 --> Config Class Initialized
INFO - 2021-01-07 02:43:56 --> Loader Class Initialized
INFO - 2021-01-07 02:43:56 --> Helper loaded: url_helper
INFO - 2021-01-07 02:43:56 --> Helper loaded: file_helper
INFO - 2021-01-07 02:43:56 --> Helper loaded: form_helper
INFO - 2021-01-07 02:43:56 --> Helper loaded: my_helper
INFO - 2021-01-07 02:43:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:43:56 --> Controller Class Initialized
INFO - 2021-01-07 02:43:56 --> Final output sent to browser
DEBUG - 2021-01-07 02:43:56 --> Total execution time: 0.2318
INFO - 2021-01-07 02:44:03 --> Config Class Initialized
INFO - 2021-01-07 02:44:03 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:44:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:44:03 --> Utf8 Class Initialized
INFO - 2021-01-07 02:44:03 --> URI Class Initialized
INFO - 2021-01-07 02:44:03 --> Router Class Initialized
INFO - 2021-01-07 02:44:03 --> Output Class Initialized
INFO - 2021-01-07 02:44:03 --> Security Class Initialized
DEBUG - 2021-01-07 02:44:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:44:03 --> Input Class Initialized
INFO - 2021-01-07 02:44:03 --> Language Class Initialized
INFO - 2021-01-07 02:44:03 --> Language Class Initialized
INFO - 2021-01-07 02:44:03 --> Config Class Initialized
INFO - 2021-01-07 02:44:03 --> Loader Class Initialized
INFO - 2021-01-07 02:44:03 --> Helper loaded: url_helper
INFO - 2021-01-07 02:44:03 --> Helper loaded: file_helper
INFO - 2021-01-07 02:44:03 --> Helper loaded: form_helper
INFO - 2021-01-07 02:44:03 --> Helper loaded: my_helper
INFO - 2021-01-07 02:44:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:44:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:44:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:44:03 --> Controller Class Initialized
INFO - 2021-01-07 02:44:04 --> Final output sent to browser
DEBUG - 2021-01-07 02:44:04 --> Total execution time: 0.3412
INFO - 2021-01-07 02:44:11 --> Config Class Initialized
INFO - 2021-01-07 02:44:11 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:44:11 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:44:11 --> Utf8 Class Initialized
INFO - 2021-01-07 02:44:11 --> URI Class Initialized
INFO - 2021-01-07 02:44:11 --> Router Class Initialized
INFO - 2021-01-07 02:44:11 --> Output Class Initialized
INFO - 2021-01-07 02:44:11 --> Security Class Initialized
DEBUG - 2021-01-07 02:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:44:11 --> Input Class Initialized
INFO - 2021-01-07 02:44:11 --> Language Class Initialized
INFO - 2021-01-07 02:44:11 --> Language Class Initialized
INFO - 2021-01-07 02:44:11 --> Config Class Initialized
INFO - 2021-01-07 02:44:11 --> Loader Class Initialized
INFO - 2021-01-07 02:44:11 --> Helper loaded: url_helper
INFO - 2021-01-07 02:44:11 --> Helper loaded: file_helper
INFO - 2021-01-07 02:44:11 --> Helper loaded: form_helper
INFO - 2021-01-07 02:44:11 --> Helper loaded: my_helper
INFO - 2021-01-07 02:44:11 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:44:11 --> Controller Class Initialized
DEBUG - 2021-01-07 02:44:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 02:44:11 --> Final output sent to browser
DEBUG - 2021-01-07 02:44:11 --> Total execution time: 0.2720
INFO - 2021-01-07 02:44:17 --> Config Class Initialized
INFO - 2021-01-07 02:44:17 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:44:17 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:44:17 --> Utf8 Class Initialized
INFO - 2021-01-07 02:44:17 --> URI Class Initialized
INFO - 2021-01-07 02:44:17 --> Router Class Initialized
INFO - 2021-01-07 02:44:17 --> Output Class Initialized
INFO - 2021-01-07 02:44:17 --> Security Class Initialized
DEBUG - 2021-01-07 02:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:44:17 --> Input Class Initialized
INFO - 2021-01-07 02:44:17 --> Language Class Initialized
INFO - 2021-01-07 02:44:17 --> Language Class Initialized
INFO - 2021-01-07 02:44:17 --> Config Class Initialized
INFO - 2021-01-07 02:44:17 --> Loader Class Initialized
INFO - 2021-01-07 02:44:17 --> Helper loaded: url_helper
INFO - 2021-01-07 02:44:17 --> Helper loaded: file_helper
INFO - 2021-01-07 02:44:17 --> Helper loaded: form_helper
INFO - 2021-01-07 02:44:17 --> Helper loaded: my_helper
INFO - 2021-01-07 02:44:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:44:17 --> Controller Class Initialized
DEBUG - 2021-01-07 02:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:44:17 --> Final output sent to browser
DEBUG - 2021-01-07 02:44:17 --> Total execution time: 0.2943
INFO - 2021-01-07 02:46:06 --> Config Class Initialized
INFO - 2021-01-07 02:46:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:46:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:46:06 --> Utf8 Class Initialized
INFO - 2021-01-07 02:46:06 --> URI Class Initialized
INFO - 2021-01-07 02:46:06 --> Router Class Initialized
INFO - 2021-01-07 02:46:06 --> Output Class Initialized
INFO - 2021-01-07 02:46:06 --> Security Class Initialized
DEBUG - 2021-01-07 02:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:46:06 --> Input Class Initialized
INFO - 2021-01-07 02:46:06 --> Language Class Initialized
INFO - 2021-01-07 02:46:06 --> Language Class Initialized
INFO - 2021-01-07 02:46:06 --> Config Class Initialized
INFO - 2021-01-07 02:46:06 --> Loader Class Initialized
INFO - 2021-01-07 02:46:06 --> Helper loaded: url_helper
INFO - 2021-01-07 02:46:06 --> Helper loaded: file_helper
INFO - 2021-01-07 02:46:06 --> Helper loaded: form_helper
INFO - 2021-01-07 02:46:06 --> Helper loaded: my_helper
INFO - 2021-01-07 02:46:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:46:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:46:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:46:06 --> Controller Class Initialized
DEBUG - 2021-01-07 02:46:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:46:06 --> Final output sent to browser
DEBUG - 2021-01-07 02:46:06 --> Total execution time: 0.2819
INFO - 2021-01-07 02:49:25 --> Config Class Initialized
INFO - 2021-01-07 02:49:25 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:49:25 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:49:25 --> Utf8 Class Initialized
INFO - 2021-01-07 02:49:25 --> URI Class Initialized
INFO - 2021-01-07 02:49:25 --> Router Class Initialized
INFO - 2021-01-07 02:49:25 --> Output Class Initialized
INFO - 2021-01-07 02:49:25 --> Security Class Initialized
DEBUG - 2021-01-07 02:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:49:26 --> Input Class Initialized
INFO - 2021-01-07 02:49:26 --> Language Class Initialized
INFO - 2021-01-07 02:49:26 --> Language Class Initialized
INFO - 2021-01-07 02:49:26 --> Config Class Initialized
INFO - 2021-01-07 02:49:26 --> Loader Class Initialized
INFO - 2021-01-07 02:49:26 --> Helper loaded: url_helper
INFO - 2021-01-07 02:49:26 --> Helper loaded: file_helper
INFO - 2021-01-07 02:49:26 --> Helper loaded: form_helper
INFO - 2021-01-07 02:49:26 --> Helper loaded: my_helper
INFO - 2021-01-07 02:49:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:49:26 --> Controller Class Initialized
INFO - 2021-01-07 02:49:26 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:49:26 --> Config Class Initialized
INFO - 2021-01-07 02:49:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:49:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:49:26 --> Utf8 Class Initialized
INFO - 2021-01-07 02:49:26 --> URI Class Initialized
INFO - 2021-01-07 02:49:26 --> Router Class Initialized
INFO - 2021-01-07 02:49:26 --> Output Class Initialized
INFO - 2021-01-07 02:49:26 --> Security Class Initialized
DEBUG - 2021-01-07 02:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:49:26 --> Input Class Initialized
INFO - 2021-01-07 02:49:26 --> Language Class Initialized
INFO - 2021-01-07 02:49:26 --> Language Class Initialized
INFO - 2021-01-07 02:49:26 --> Config Class Initialized
INFO - 2021-01-07 02:49:26 --> Loader Class Initialized
INFO - 2021-01-07 02:49:26 --> Helper loaded: url_helper
INFO - 2021-01-07 02:49:26 --> Helper loaded: file_helper
INFO - 2021-01-07 02:49:26 --> Helper loaded: form_helper
INFO - 2021-01-07 02:49:26 --> Helper loaded: my_helper
INFO - 2021-01-07 02:49:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:49:26 --> Controller Class Initialized
DEBUG - 2021-01-07 02:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 02:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:49:26 --> Final output sent to browser
DEBUG - 2021-01-07 02:49:26 --> Total execution time: 0.3139
INFO - 2021-01-07 02:49:35 --> Config Class Initialized
INFO - 2021-01-07 02:49:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:49:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:49:35 --> Utf8 Class Initialized
INFO - 2021-01-07 02:49:35 --> URI Class Initialized
INFO - 2021-01-07 02:49:35 --> Router Class Initialized
INFO - 2021-01-07 02:49:35 --> Output Class Initialized
INFO - 2021-01-07 02:49:35 --> Security Class Initialized
DEBUG - 2021-01-07 02:49:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:49:35 --> Input Class Initialized
INFO - 2021-01-07 02:49:35 --> Language Class Initialized
INFO - 2021-01-07 02:49:35 --> Language Class Initialized
INFO - 2021-01-07 02:49:35 --> Config Class Initialized
INFO - 2021-01-07 02:49:35 --> Loader Class Initialized
INFO - 2021-01-07 02:49:35 --> Helper loaded: url_helper
INFO - 2021-01-07 02:49:35 --> Helper loaded: file_helper
INFO - 2021-01-07 02:49:35 --> Helper loaded: form_helper
INFO - 2021-01-07 02:49:35 --> Helper loaded: my_helper
INFO - 2021-01-07 02:49:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:49:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:49:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:49:35 --> Controller Class Initialized
INFO - 2021-01-07 02:49:35 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:49:35 --> Final output sent to browser
DEBUG - 2021-01-07 02:49:35 --> Total execution time: 0.3915
INFO - 2021-01-07 02:49:50 --> Config Class Initialized
INFO - 2021-01-07 02:49:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:49:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:49:50 --> Utf8 Class Initialized
INFO - 2021-01-07 02:49:50 --> URI Class Initialized
INFO - 2021-01-07 02:49:50 --> Router Class Initialized
INFO - 2021-01-07 02:49:50 --> Output Class Initialized
INFO - 2021-01-07 02:49:50 --> Security Class Initialized
DEBUG - 2021-01-07 02:49:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:49:50 --> Input Class Initialized
INFO - 2021-01-07 02:49:50 --> Language Class Initialized
INFO - 2021-01-07 02:49:50 --> Language Class Initialized
INFO - 2021-01-07 02:49:50 --> Config Class Initialized
INFO - 2021-01-07 02:49:50 --> Loader Class Initialized
INFO - 2021-01-07 02:49:50 --> Helper loaded: url_helper
INFO - 2021-01-07 02:49:50 --> Helper loaded: file_helper
INFO - 2021-01-07 02:49:50 --> Helper loaded: form_helper
INFO - 2021-01-07 02:49:50 --> Helper loaded: my_helper
INFO - 2021-01-07 02:49:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:49:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:49:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:49:50 --> Controller Class Initialized
DEBUG - 2021-01-07 02:49:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 02:49:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:49:50 --> Final output sent to browser
DEBUG - 2021-01-07 02:49:50 --> Total execution time: 0.4290
INFO - 2021-01-07 02:49:52 --> Config Class Initialized
INFO - 2021-01-07 02:49:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:49:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:49:52 --> Utf8 Class Initialized
INFO - 2021-01-07 02:49:52 --> URI Class Initialized
INFO - 2021-01-07 02:49:52 --> Router Class Initialized
INFO - 2021-01-07 02:49:52 --> Output Class Initialized
INFO - 2021-01-07 02:49:52 --> Security Class Initialized
DEBUG - 2021-01-07 02:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:49:52 --> Input Class Initialized
INFO - 2021-01-07 02:49:52 --> Language Class Initialized
INFO - 2021-01-07 02:49:53 --> Language Class Initialized
INFO - 2021-01-07 02:49:53 --> Config Class Initialized
INFO - 2021-01-07 02:49:53 --> Loader Class Initialized
INFO - 2021-01-07 02:49:53 --> Helper loaded: url_helper
INFO - 2021-01-07 02:49:53 --> Helper loaded: file_helper
INFO - 2021-01-07 02:49:53 --> Helper loaded: form_helper
INFO - 2021-01-07 02:49:53 --> Helper loaded: my_helper
INFO - 2021-01-07 02:49:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:49:53 --> Controller Class Initialized
DEBUG - 2021-01-07 02:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-07 02:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:49:53 --> Final output sent to browser
DEBUG - 2021-01-07 02:49:53 --> Total execution time: 0.3017
INFO - 2021-01-07 02:49:53 --> Config Class Initialized
INFO - 2021-01-07 02:49:53 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:49:53 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:49:53 --> Utf8 Class Initialized
INFO - 2021-01-07 02:49:53 --> URI Class Initialized
INFO - 2021-01-07 02:49:53 --> Router Class Initialized
INFO - 2021-01-07 02:49:53 --> Output Class Initialized
INFO - 2021-01-07 02:49:53 --> Security Class Initialized
DEBUG - 2021-01-07 02:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:49:53 --> Input Class Initialized
INFO - 2021-01-07 02:49:53 --> Language Class Initialized
INFO - 2021-01-07 02:49:53 --> Language Class Initialized
INFO - 2021-01-07 02:49:53 --> Config Class Initialized
INFO - 2021-01-07 02:49:53 --> Loader Class Initialized
INFO - 2021-01-07 02:49:53 --> Helper loaded: url_helper
INFO - 2021-01-07 02:49:53 --> Helper loaded: file_helper
INFO - 2021-01-07 02:49:53 --> Helper loaded: form_helper
INFO - 2021-01-07 02:49:53 --> Helper loaded: my_helper
INFO - 2021-01-07 02:49:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:49:53 --> Controller Class Initialized
INFO - 2021-01-07 02:49:55 --> Config Class Initialized
INFO - 2021-01-07 02:49:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:49:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:49:55 --> Utf8 Class Initialized
INFO - 2021-01-07 02:49:55 --> URI Class Initialized
INFO - 2021-01-07 02:49:55 --> Router Class Initialized
INFO - 2021-01-07 02:49:55 --> Output Class Initialized
INFO - 2021-01-07 02:49:55 --> Security Class Initialized
DEBUG - 2021-01-07 02:49:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:49:55 --> Input Class Initialized
INFO - 2021-01-07 02:49:55 --> Language Class Initialized
INFO - 2021-01-07 02:49:55 --> Language Class Initialized
INFO - 2021-01-07 02:49:55 --> Config Class Initialized
INFO - 2021-01-07 02:49:55 --> Loader Class Initialized
INFO - 2021-01-07 02:49:55 --> Helper loaded: url_helper
INFO - 2021-01-07 02:49:55 --> Helper loaded: file_helper
INFO - 2021-01-07 02:49:55 --> Helper loaded: form_helper
INFO - 2021-01-07 02:49:55 --> Helper loaded: my_helper
INFO - 2021-01-07 02:49:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:49:55 --> Controller Class Initialized
DEBUG - 2021-01-07 02:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-07 02:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:49:55 --> Final output sent to browser
DEBUG - 2021-01-07 02:49:55 --> Total execution time: 0.4049
INFO - 2021-01-07 02:50:07 --> Config Class Initialized
INFO - 2021-01-07 02:50:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:07 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:07 --> URI Class Initialized
INFO - 2021-01-07 02:50:07 --> Router Class Initialized
INFO - 2021-01-07 02:50:07 --> Output Class Initialized
INFO - 2021-01-07 02:50:07 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:07 --> Input Class Initialized
INFO - 2021-01-07 02:50:07 --> Language Class Initialized
INFO - 2021-01-07 02:50:07 --> Language Class Initialized
INFO - 2021-01-07 02:50:07 --> Config Class Initialized
INFO - 2021-01-07 02:50:07 --> Loader Class Initialized
INFO - 2021-01-07 02:50:07 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:07 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:07 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:07 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:07 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:08 --> Controller Class Initialized
INFO - 2021-01-07 02:50:08 --> Config Class Initialized
INFO - 2021-01-07 02:50:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:08 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:08 --> URI Class Initialized
INFO - 2021-01-07 02:50:08 --> Router Class Initialized
INFO - 2021-01-07 02:50:08 --> Output Class Initialized
INFO - 2021-01-07 02:50:08 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:08 --> Input Class Initialized
INFO - 2021-01-07 02:50:08 --> Language Class Initialized
INFO - 2021-01-07 02:50:08 --> Language Class Initialized
INFO - 2021-01-07 02:50:08 --> Config Class Initialized
INFO - 2021-01-07 02:50:08 --> Loader Class Initialized
INFO - 2021-01-07 02:50:08 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:08 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:08 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:08 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:08 --> Controller Class Initialized
DEBUG - 2021-01-07 02:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-07 02:50:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:50:08 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:08 --> Total execution time: 0.3106
INFO - 2021-01-07 02:50:08 --> Config Class Initialized
INFO - 2021-01-07 02:50:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:08 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:08 --> URI Class Initialized
INFO - 2021-01-07 02:50:08 --> Router Class Initialized
INFO - 2021-01-07 02:50:08 --> Output Class Initialized
INFO - 2021-01-07 02:50:08 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:08 --> Input Class Initialized
INFO - 2021-01-07 02:50:08 --> Language Class Initialized
INFO - 2021-01-07 02:50:08 --> Language Class Initialized
INFO - 2021-01-07 02:50:08 --> Config Class Initialized
INFO - 2021-01-07 02:50:08 --> Loader Class Initialized
INFO - 2021-01-07 02:50:08 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:08 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:08 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:08 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:08 --> Controller Class Initialized
INFO - 2021-01-07 02:50:11 --> Config Class Initialized
INFO - 2021-01-07 02:50:11 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:11 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:11 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:11 --> URI Class Initialized
INFO - 2021-01-07 02:50:11 --> Router Class Initialized
INFO - 2021-01-07 02:50:11 --> Output Class Initialized
INFO - 2021-01-07 02:50:11 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:11 --> Input Class Initialized
INFO - 2021-01-07 02:50:11 --> Language Class Initialized
INFO - 2021-01-07 02:50:11 --> Language Class Initialized
INFO - 2021-01-07 02:50:11 --> Config Class Initialized
INFO - 2021-01-07 02:50:11 --> Loader Class Initialized
INFO - 2021-01-07 02:50:11 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:11 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:11 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:11 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:11 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:11 --> Controller Class Initialized
DEBUG - 2021-01-07 02:50:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-01-07 02:50:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:50:11 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:11 --> Total execution time: 0.2918
INFO - 2021-01-07 02:50:11 --> Config Class Initialized
INFO - 2021-01-07 02:50:12 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:12 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:12 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:12 --> URI Class Initialized
INFO - 2021-01-07 02:50:12 --> Router Class Initialized
INFO - 2021-01-07 02:50:12 --> Output Class Initialized
INFO - 2021-01-07 02:50:12 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:12 --> Input Class Initialized
INFO - 2021-01-07 02:50:12 --> Language Class Initialized
INFO - 2021-01-07 02:50:12 --> Language Class Initialized
INFO - 2021-01-07 02:50:12 --> Config Class Initialized
INFO - 2021-01-07 02:50:12 --> Loader Class Initialized
INFO - 2021-01-07 02:50:12 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:12 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:12 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:12 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:12 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:12 --> Controller Class Initialized
INFO - 2021-01-07 02:50:16 --> Config Class Initialized
INFO - 2021-01-07 02:50:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:16 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:16 --> URI Class Initialized
INFO - 2021-01-07 02:50:16 --> Router Class Initialized
INFO - 2021-01-07 02:50:16 --> Output Class Initialized
INFO - 2021-01-07 02:50:16 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:16 --> Input Class Initialized
INFO - 2021-01-07 02:50:16 --> Language Class Initialized
INFO - 2021-01-07 02:50:16 --> Language Class Initialized
INFO - 2021-01-07 02:50:17 --> Config Class Initialized
INFO - 2021-01-07 02:50:17 --> Loader Class Initialized
INFO - 2021-01-07 02:50:17 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:17 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:17 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:17 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:17 --> Controller Class Initialized
INFO - 2021-01-07 02:50:17 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:50:17 --> Config Class Initialized
INFO - 2021-01-07 02:50:17 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:17 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:17 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:17 --> URI Class Initialized
INFO - 2021-01-07 02:50:17 --> Router Class Initialized
INFO - 2021-01-07 02:50:17 --> Output Class Initialized
INFO - 2021-01-07 02:50:17 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:17 --> Input Class Initialized
INFO - 2021-01-07 02:50:17 --> Language Class Initialized
INFO - 2021-01-07 02:50:17 --> Language Class Initialized
INFO - 2021-01-07 02:50:17 --> Config Class Initialized
INFO - 2021-01-07 02:50:17 --> Loader Class Initialized
INFO - 2021-01-07 02:50:17 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:17 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:17 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:17 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:17 --> Controller Class Initialized
DEBUG - 2021-01-07 02:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 02:50:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:50:17 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:17 --> Total execution time: 0.3307
INFO - 2021-01-07 02:50:23 --> Config Class Initialized
INFO - 2021-01-07 02:50:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:23 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:23 --> URI Class Initialized
INFO - 2021-01-07 02:50:23 --> Router Class Initialized
INFO - 2021-01-07 02:50:23 --> Output Class Initialized
INFO - 2021-01-07 02:50:23 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:23 --> Input Class Initialized
INFO - 2021-01-07 02:50:23 --> Language Class Initialized
INFO - 2021-01-07 02:50:23 --> Language Class Initialized
INFO - 2021-01-07 02:50:23 --> Config Class Initialized
INFO - 2021-01-07 02:50:23 --> Loader Class Initialized
INFO - 2021-01-07 02:50:23 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:23 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:23 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:23 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:24 --> Controller Class Initialized
INFO - 2021-01-07 02:50:24 --> Helper loaded: cookie_helper
INFO - 2021-01-07 02:50:24 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:24 --> Total execution time: 0.4062
INFO - 2021-01-07 02:50:24 --> Config Class Initialized
INFO - 2021-01-07 02:50:24 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:24 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:24 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:24 --> URI Class Initialized
INFO - 2021-01-07 02:50:24 --> Router Class Initialized
INFO - 2021-01-07 02:50:24 --> Output Class Initialized
INFO - 2021-01-07 02:50:24 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:24 --> Input Class Initialized
INFO - 2021-01-07 02:50:24 --> Language Class Initialized
INFO - 2021-01-07 02:50:24 --> Language Class Initialized
INFO - 2021-01-07 02:50:24 --> Config Class Initialized
INFO - 2021-01-07 02:50:24 --> Loader Class Initialized
INFO - 2021-01-07 02:50:24 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:24 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:24 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:24 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:24 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:24 --> Controller Class Initialized
DEBUG - 2021-01-07 02:50:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 02:50:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:50:24 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:24 --> Total execution time: 0.4070
INFO - 2021-01-07 02:50:31 --> Config Class Initialized
INFO - 2021-01-07 02:50:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:32 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:32 --> URI Class Initialized
INFO - 2021-01-07 02:50:32 --> Router Class Initialized
INFO - 2021-01-07 02:50:32 --> Output Class Initialized
INFO - 2021-01-07 02:50:32 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:32 --> Input Class Initialized
INFO - 2021-01-07 02:50:32 --> Language Class Initialized
INFO - 2021-01-07 02:50:32 --> Language Class Initialized
INFO - 2021-01-07 02:50:32 --> Config Class Initialized
INFO - 2021-01-07 02:50:32 --> Loader Class Initialized
INFO - 2021-01-07 02:50:32 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:32 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:32 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:32 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:32 --> Controller Class Initialized
DEBUG - 2021-01-07 02:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:50:32 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:32 --> Total execution time: 0.2828
INFO - 2021-01-07 02:50:33 --> Config Class Initialized
INFO - 2021-01-07 02:50:33 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:33 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:33 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:33 --> URI Class Initialized
INFO - 2021-01-07 02:50:33 --> Router Class Initialized
INFO - 2021-01-07 02:50:33 --> Output Class Initialized
INFO - 2021-01-07 02:50:33 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:33 --> Input Class Initialized
INFO - 2021-01-07 02:50:33 --> Language Class Initialized
INFO - 2021-01-07 02:50:33 --> Language Class Initialized
INFO - 2021-01-07 02:50:34 --> Config Class Initialized
INFO - 2021-01-07 02:50:34 --> Loader Class Initialized
INFO - 2021-01-07 02:50:34 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:34 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:34 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:34 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:34 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:34 --> Controller Class Initialized
DEBUG - 2021-01-07 02:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 02:50:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:50:34 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:34 --> Total execution time: 0.3119
INFO - 2021-01-07 02:50:34 --> Config Class Initialized
INFO - 2021-01-07 02:50:34 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:34 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:34 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:34 --> URI Class Initialized
INFO - 2021-01-07 02:50:34 --> Router Class Initialized
INFO - 2021-01-07 02:50:34 --> Output Class Initialized
INFO - 2021-01-07 02:50:34 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:34 --> Input Class Initialized
INFO - 2021-01-07 02:50:34 --> Language Class Initialized
INFO - 2021-01-07 02:50:34 --> Language Class Initialized
INFO - 2021-01-07 02:50:34 --> Config Class Initialized
INFO - 2021-01-07 02:50:34 --> Loader Class Initialized
INFO - 2021-01-07 02:50:34 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:34 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:34 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:34 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:34 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:34 --> Controller Class Initialized
INFO - 2021-01-07 02:50:41 --> Config Class Initialized
INFO - 2021-01-07 02:50:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:50:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:50:41 --> Utf8 Class Initialized
INFO - 2021-01-07 02:50:41 --> URI Class Initialized
INFO - 2021-01-07 02:50:41 --> Router Class Initialized
INFO - 2021-01-07 02:50:42 --> Output Class Initialized
INFO - 2021-01-07 02:50:42 --> Security Class Initialized
DEBUG - 2021-01-07 02:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:50:42 --> Input Class Initialized
INFO - 2021-01-07 02:50:42 --> Language Class Initialized
INFO - 2021-01-07 02:50:42 --> Language Class Initialized
INFO - 2021-01-07 02:50:42 --> Config Class Initialized
INFO - 2021-01-07 02:50:42 --> Loader Class Initialized
INFO - 2021-01-07 02:50:42 --> Helper loaded: url_helper
INFO - 2021-01-07 02:50:42 --> Helper loaded: file_helper
INFO - 2021-01-07 02:50:42 --> Helper loaded: form_helper
INFO - 2021-01-07 02:50:42 --> Helper loaded: my_helper
INFO - 2021-01-07 02:50:42 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:50:42 --> Controller Class Initialized
INFO - 2021-01-07 02:50:42 --> Final output sent to browser
DEBUG - 2021-01-07 02:50:42 --> Total execution time: 0.2869
INFO - 2021-01-07 02:51:47 --> Config Class Initialized
INFO - 2021-01-07 02:51:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:51:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:51:48 --> Utf8 Class Initialized
INFO - 2021-01-07 02:51:48 --> URI Class Initialized
INFO - 2021-01-07 02:51:48 --> Router Class Initialized
INFO - 2021-01-07 02:51:48 --> Output Class Initialized
INFO - 2021-01-07 02:51:48 --> Security Class Initialized
DEBUG - 2021-01-07 02:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:51:48 --> Input Class Initialized
INFO - 2021-01-07 02:51:48 --> Language Class Initialized
INFO - 2021-01-07 02:51:48 --> Language Class Initialized
INFO - 2021-01-07 02:51:48 --> Config Class Initialized
INFO - 2021-01-07 02:51:48 --> Loader Class Initialized
INFO - 2021-01-07 02:51:48 --> Helper loaded: url_helper
INFO - 2021-01-07 02:51:48 --> Helper loaded: file_helper
INFO - 2021-01-07 02:51:48 --> Helper loaded: form_helper
INFO - 2021-01-07 02:51:48 --> Helper loaded: my_helper
INFO - 2021-01-07 02:51:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:51:48 --> Controller Class Initialized
INFO - 2021-01-07 02:51:48 --> Final output sent to browser
DEBUG - 2021-01-07 02:51:48 --> Total execution time: 0.3042
INFO - 2021-01-07 02:51:48 --> Config Class Initialized
INFO - 2021-01-07 02:51:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:51:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:51:48 --> Utf8 Class Initialized
INFO - 2021-01-07 02:51:48 --> URI Class Initialized
INFO - 2021-01-07 02:51:48 --> Router Class Initialized
INFO - 2021-01-07 02:51:48 --> Output Class Initialized
INFO - 2021-01-07 02:51:48 --> Security Class Initialized
DEBUG - 2021-01-07 02:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:51:48 --> Input Class Initialized
INFO - 2021-01-07 02:51:48 --> Language Class Initialized
INFO - 2021-01-07 02:51:48 --> Language Class Initialized
INFO - 2021-01-07 02:51:48 --> Config Class Initialized
INFO - 2021-01-07 02:51:48 --> Loader Class Initialized
INFO - 2021-01-07 02:51:48 --> Helper loaded: url_helper
INFO - 2021-01-07 02:51:48 --> Helper loaded: file_helper
INFO - 2021-01-07 02:51:48 --> Helper loaded: form_helper
INFO - 2021-01-07 02:51:48 --> Helper loaded: my_helper
INFO - 2021-01-07 02:51:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:51:48 --> Controller Class Initialized
INFO - 2021-01-07 02:51:53 --> Config Class Initialized
INFO - 2021-01-07 02:51:53 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:51:53 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:51:53 --> Utf8 Class Initialized
INFO - 2021-01-07 02:51:53 --> URI Class Initialized
INFO - 2021-01-07 02:51:53 --> Router Class Initialized
INFO - 2021-01-07 02:51:53 --> Output Class Initialized
INFO - 2021-01-07 02:51:53 --> Security Class Initialized
DEBUG - 2021-01-07 02:51:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:51:53 --> Input Class Initialized
INFO - 2021-01-07 02:51:53 --> Language Class Initialized
INFO - 2021-01-07 02:51:53 --> Language Class Initialized
INFO - 2021-01-07 02:51:53 --> Config Class Initialized
INFO - 2021-01-07 02:51:53 --> Loader Class Initialized
INFO - 2021-01-07 02:51:53 --> Helper loaded: url_helper
INFO - 2021-01-07 02:51:53 --> Helper loaded: file_helper
INFO - 2021-01-07 02:51:53 --> Helper loaded: form_helper
INFO - 2021-01-07 02:51:53 --> Helper loaded: my_helper
INFO - 2021-01-07 02:51:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:51:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:51:53 --> Controller Class Initialized
INFO - 2021-01-07 02:51:53 --> Final output sent to browser
DEBUG - 2021-01-07 02:51:53 --> Total execution time: 0.3116
INFO - 2021-01-07 02:52:32 --> Config Class Initialized
INFO - 2021-01-07 02:52:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:52:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:52:32 --> Utf8 Class Initialized
INFO - 2021-01-07 02:52:32 --> URI Class Initialized
INFO - 2021-01-07 02:52:32 --> Router Class Initialized
INFO - 2021-01-07 02:52:32 --> Output Class Initialized
INFO - 2021-01-07 02:52:32 --> Security Class Initialized
DEBUG - 2021-01-07 02:52:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:52:32 --> Input Class Initialized
INFO - 2021-01-07 02:52:32 --> Language Class Initialized
INFO - 2021-01-07 02:52:33 --> Language Class Initialized
INFO - 2021-01-07 02:52:33 --> Config Class Initialized
INFO - 2021-01-07 02:52:33 --> Loader Class Initialized
INFO - 2021-01-07 02:52:33 --> Helper loaded: url_helper
INFO - 2021-01-07 02:52:33 --> Helper loaded: file_helper
INFO - 2021-01-07 02:52:33 --> Helper loaded: form_helper
INFO - 2021-01-07 02:52:33 --> Helper loaded: my_helper
INFO - 2021-01-07 02:52:33 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:52:33 --> Controller Class Initialized
INFO - 2021-01-07 02:52:33 --> Final output sent to browser
DEBUG - 2021-01-07 02:52:33 --> Total execution time: 0.2868
INFO - 2021-01-07 02:52:33 --> Config Class Initialized
INFO - 2021-01-07 02:52:33 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:52:33 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:52:33 --> Utf8 Class Initialized
INFO - 2021-01-07 02:52:33 --> URI Class Initialized
INFO - 2021-01-07 02:52:33 --> Router Class Initialized
INFO - 2021-01-07 02:52:33 --> Output Class Initialized
INFO - 2021-01-07 02:52:33 --> Security Class Initialized
DEBUG - 2021-01-07 02:52:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:52:33 --> Input Class Initialized
INFO - 2021-01-07 02:52:33 --> Language Class Initialized
INFO - 2021-01-07 02:52:33 --> Language Class Initialized
INFO - 2021-01-07 02:52:33 --> Config Class Initialized
INFO - 2021-01-07 02:52:33 --> Loader Class Initialized
INFO - 2021-01-07 02:52:33 --> Helper loaded: url_helper
INFO - 2021-01-07 02:52:33 --> Helper loaded: file_helper
INFO - 2021-01-07 02:52:33 --> Helper loaded: form_helper
INFO - 2021-01-07 02:52:33 --> Helper loaded: my_helper
INFO - 2021-01-07 02:52:33 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:52:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:52:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:52:33 --> Controller Class Initialized
INFO - 2021-01-07 02:52:35 --> Config Class Initialized
INFO - 2021-01-07 02:52:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:52:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:52:35 --> Utf8 Class Initialized
INFO - 2021-01-07 02:52:35 --> URI Class Initialized
INFO - 2021-01-07 02:52:35 --> Router Class Initialized
INFO - 2021-01-07 02:52:35 --> Output Class Initialized
INFO - 2021-01-07 02:52:35 --> Security Class Initialized
DEBUG - 2021-01-07 02:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:52:35 --> Input Class Initialized
INFO - 2021-01-07 02:52:35 --> Language Class Initialized
INFO - 2021-01-07 02:52:35 --> Language Class Initialized
INFO - 2021-01-07 02:52:35 --> Config Class Initialized
INFO - 2021-01-07 02:52:35 --> Loader Class Initialized
INFO - 2021-01-07 02:52:35 --> Helper loaded: url_helper
INFO - 2021-01-07 02:52:35 --> Helper loaded: file_helper
INFO - 2021-01-07 02:52:35 --> Helper loaded: form_helper
INFO - 2021-01-07 02:52:35 --> Helper loaded: my_helper
INFO - 2021-01-07 02:52:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:52:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:52:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:52:35 --> Controller Class Initialized
INFO - 2021-01-07 02:52:35 --> Final output sent to browser
DEBUG - 2021-01-07 02:52:35 --> Total execution time: 0.2455
INFO - 2021-01-07 02:52:43 --> Config Class Initialized
INFO - 2021-01-07 02:52:43 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:52:43 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:52:43 --> Utf8 Class Initialized
INFO - 2021-01-07 02:52:43 --> URI Class Initialized
INFO - 2021-01-07 02:52:43 --> Router Class Initialized
INFO - 2021-01-07 02:52:43 --> Output Class Initialized
INFO - 2021-01-07 02:52:43 --> Security Class Initialized
DEBUG - 2021-01-07 02:52:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:52:43 --> Input Class Initialized
INFO - 2021-01-07 02:52:43 --> Language Class Initialized
INFO - 2021-01-07 02:52:43 --> Language Class Initialized
INFO - 2021-01-07 02:52:43 --> Config Class Initialized
INFO - 2021-01-07 02:52:43 --> Loader Class Initialized
INFO - 2021-01-07 02:52:43 --> Helper loaded: url_helper
INFO - 2021-01-07 02:52:43 --> Helper loaded: file_helper
INFO - 2021-01-07 02:52:43 --> Helper loaded: form_helper
INFO - 2021-01-07 02:52:43 --> Helper loaded: my_helper
INFO - 2021-01-07 02:52:43 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:52:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:52:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:52:43 --> Controller Class Initialized
INFO - 2021-01-07 02:52:44 --> Final output sent to browser
DEBUG - 2021-01-07 02:52:44 --> Total execution time: 0.3799
INFO - 2021-01-07 02:52:46 --> Config Class Initialized
INFO - 2021-01-07 02:52:46 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:52:46 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:52:46 --> Utf8 Class Initialized
INFO - 2021-01-07 02:52:46 --> URI Class Initialized
INFO - 2021-01-07 02:52:46 --> Router Class Initialized
INFO - 2021-01-07 02:52:46 --> Output Class Initialized
INFO - 2021-01-07 02:52:46 --> Security Class Initialized
DEBUG - 2021-01-07 02:52:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:52:47 --> Input Class Initialized
INFO - 2021-01-07 02:52:47 --> Language Class Initialized
INFO - 2021-01-07 02:52:47 --> Language Class Initialized
INFO - 2021-01-07 02:52:47 --> Config Class Initialized
INFO - 2021-01-07 02:52:47 --> Loader Class Initialized
INFO - 2021-01-07 02:52:47 --> Helper loaded: url_helper
INFO - 2021-01-07 02:52:47 --> Helper loaded: file_helper
INFO - 2021-01-07 02:52:47 --> Helper loaded: form_helper
INFO - 2021-01-07 02:52:47 --> Helper loaded: my_helper
INFO - 2021-01-07 02:52:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:52:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:52:47 --> Controller Class Initialized
INFO - 2021-01-07 02:52:47 --> Final output sent to browser
DEBUG - 2021-01-07 02:52:47 --> Total execution time: 0.2559
INFO - 2021-01-07 02:53:02 --> Config Class Initialized
INFO - 2021-01-07 02:53:02 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:53:02 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:53:02 --> Utf8 Class Initialized
INFO - 2021-01-07 02:53:02 --> URI Class Initialized
INFO - 2021-01-07 02:53:02 --> Router Class Initialized
INFO - 2021-01-07 02:53:02 --> Output Class Initialized
INFO - 2021-01-07 02:53:02 --> Security Class Initialized
DEBUG - 2021-01-07 02:53:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:53:02 --> Input Class Initialized
INFO - 2021-01-07 02:53:02 --> Language Class Initialized
INFO - 2021-01-07 02:53:02 --> Language Class Initialized
INFO - 2021-01-07 02:53:02 --> Config Class Initialized
INFO - 2021-01-07 02:53:02 --> Loader Class Initialized
INFO - 2021-01-07 02:53:02 --> Helper loaded: url_helper
INFO - 2021-01-07 02:53:02 --> Helper loaded: file_helper
INFO - 2021-01-07 02:53:02 --> Helper loaded: form_helper
INFO - 2021-01-07 02:53:02 --> Helper loaded: my_helper
INFO - 2021-01-07 02:53:02 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:53:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:53:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:53:02 --> Controller Class Initialized
INFO - 2021-01-07 02:53:03 --> Final output sent to browser
DEBUG - 2021-01-07 02:53:03 --> Total execution time: 0.3695
INFO - 2021-01-07 02:53:08 --> Config Class Initialized
INFO - 2021-01-07 02:53:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:53:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:53:08 --> Utf8 Class Initialized
INFO - 2021-01-07 02:53:08 --> URI Class Initialized
INFO - 2021-01-07 02:53:08 --> Router Class Initialized
INFO - 2021-01-07 02:53:08 --> Output Class Initialized
INFO - 2021-01-07 02:53:08 --> Security Class Initialized
DEBUG - 2021-01-07 02:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:53:08 --> Input Class Initialized
INFO - 2021-01-07 02:53:08 --> Language Class Initialized
INFO - 2021-01-07 02:53:08 --> Language Class Initialized
INFO - 2021-01-07 02:53:08 --> Config Class Initialized
INFO - 2021-01-07 02:53:08 --> Loader Class Initialized
INFO - 2021-01-07 02:53:08 --> Helper loaded: url_helper
INFO - 2021-01-07 02:53:08 --> Helper loaded: file_helper
INFO - 2021-01-07 02:53:08 --> Helper loaded: form_helper
INFO - 2021-01-07 02:53:08 --> Helper loaded: my_helper
INFO - 2021-01-07 02:53:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:53:08 --> Controller Class Initialized
INFO - 2021-01-07 02:53:08 --> Final output sent to browser
DEBUG - 2021-01-07 02:53:08 --> Total execution time: 0.2830
INFO - 2021-01-07 02:53:16 --> Config Class Initialized
INFO - 2021-01-07 02:53:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:53:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:53:16 --> Utf8 Class Initialized
INFO - 2021-01-07 02:53:16 --> URI Class Initialized
INFO - 2021-01-07 02:53:16 --> Router Class Initialized
INFO - 2021-01-07 02:53:16 --> Output Class Initialized
INFO - 2021-01-07 02:53:16 --> Security Class Initialized
DEBUG - 2021-01-07 02:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:53:16 --> Input Class Initialized
INFO - 2021-01-07 02:53:16 --> Language Class Initialized
INFO - 2021-01-07 02:53:16 --> Language Class Initialized
INFO - 2021-01-07 02:53:16 --> Config Class Initialized
INFO - 2021-01-07 02:53:16 --> Loader Class Initialized
INFO - 2021-01-07 02:53:16 --> Helper loaded: url_helper
INFO - 2021-01-07 02:53:16 --> Helper loaded: file_helper
INFO - 2021-01-07 02:53:16 --> Helper loaded: form_helper
INFO - 2021-01-07 02:53:16 --> Helper loaded: my_helper
INFO - 2021-01-07 02:53:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:53:16 --> Controller Class Initialized
INFO - 2021-01-07 02:53:16 --> Final output sent to browser
DEBUG - 2021-01-07 02:53:16 --> Total execution time: 0.3652
INFO - 2021-01-07 02:53:21 --> Config Class Initialized
INFO - 2021-01-07 02:53:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:53:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:53:21 --> Utf8 Class Initialized
INFO - 2021-01-07 02:53:21 --> URI Class Initialized
INFO - 2021-01-07 02:53:21 --> Router Class Initialized
INFO - 2021-01-07 02:53:21 --> Output Class Initialized
INFO - 2021-01-07 02:53:21 --> Security Class Initialized
DEBUG - 2021-01-07 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:53:21 --> Input Class Initialized
INFO - 2021-01-07 02:53:21 --> Language Class Initialized
INFO - 2021-01-07 02:53:21 --> Language Class Initialized
INFO - 2021-01-07 02:53:21 --> Config Class Initialized
INFO - 2021-01-07 02:53:21 --> Loader Class Initialized
INFO - 2021-01-07 02:53:21 --> Helper loaded: url_helper
INFO - 2021-01-07 02:53:21 --> Helper loaded: file_helper
INFO - 2021-01-07 02:53:21 --> Helper loaded: form_helper
INFO - 2021-01-07 02:53:21 --> Helper loaded: my_helper
INFO - 2021-01-07 02:53:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:53:21 --> Controller Class Initialized
INFO - 2021-01-07 02:53:21 --> Final output sent to browser
DEBUG - 2021-01-07 02:53:21 --> Total execution time: 0.2586
INFO - 2021-01-07 02:53:32 --> Config Class Initialized
INFO - 2021-01-07 02:53:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:53:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:53:32 --> Utf8 Class Initialized
INFO - 2021-01-07 02:53:32 --> URI Class Initialized
INFO - 2021-01-07 02:53:32 --> Router Class Initialized
INFO - 2021-01-07 02:53:32 --> Output Class Initialized
INFO - 2021-01-07 02:53:32 --> Security Class Initialized
DEBUG - 2021-01-07 02:53:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:53:32 --> Input Class Initialized
INFO - 2021-01-07 02:53:32 --> Language Class Initialized
INFO - 2021-01-07 02:53:32 --> Language Class Initialized
INFO - 2021-01-07 02:53:32 --> Config Class Initialized
INFO - 2021-01-07 02:53:32 --> Loader Class Initialized
INFO - 2021-01-07 02:53:32 --> Helper loaded: url_helper
INFO - 2021-01-07 02:53:32 --> Helper loaded: file_helper
INFO - 2021-01-07 02:53:32 --> Helper loaded: form_helper
INFO - 2021-01-07 02:53:32 --> Helper loaded: my_helper
INFO - 2021-01-07 02:53:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:53:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:53:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:53:32 --> Controller Class Initialized
INFO - 2021-01-07 02:53:32 --> Final output sent to browser
DEBUG - 2021-01-07 02:53:32 --> Total execution time: 0.3344
INFO - 2021-01-07 02:53:38 --> Config Class Initialized
INFO - 2021-01-07 02:53:38 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:53:38 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:53:38 --> Utf8 Class Initialized
INFO - 2021-01-07 02:53:38 --> URI Class Initialized
INFO - 2021-01-07 02:53:38 --> Router Class Initialized
INFO - 2021-01-07 02:53:38 --> Output Class Initialized
INFO - 2021-01-07 02:53:38 --> Security Class Initialized
DEBUG - 2021-01-07 02:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:53:38 --> Input Class Initialized
INFO - 2021-01-07 02:53:38 --> Language Class Initialized
INFO - 2021-01-07 02:53:38 --> Language Class Initialized
INFO - 2021-01-07 02:53:38 --> Config Class Initialized
INFO - 2021-01-07 02:53:38 --> Loader Class Initialized
INFO - 2021-01-07 02:53:38 --> Helper loaded: url_helper
INFO - 2021-01-07 02:53:38 --> Helper loaded: file_helper
INFO - 2021-01-07 02:53:38 --> Helper loaded: form_helper
INFO - 2021-01-07 02:53:38 --> Helper loaded: my_helper
INFO - 2021-01-07 02:53:38 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:53:38 --> Controller Class Initialized
DEBUG - 2021-01-07 02:53:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 02:53:38 --> Final output sent to browser
DEBUG - 2021-01-07 02:53:38 --> Total execution time: 0.3240
INFO - 2021-01-07 02:53:43 --> Config Class Initialized
INFO - 2021-01-07 02:53:43 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:53:43 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:53:43 --> Utf8 Class Initialized
INFO - 2021-01-07 02:53:43 --> URI Class Initialized
INFO - 2021-01-07 02:53:43 --> Router Class Initialized
INFO - 2021-01-07 02:53:43 --> Output Class Initialized
INFO - 2021-01-07 02:53:43 --> Security Class Initialized
DEBUG - 2021-01-07 02:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:53:43 --> Input Class Initialized
INFO - 2021-01-07 02:53:43 --> Language Class Initialized
INFO - 2021-01-07 02:53:43 --> Language Class Initialized
INFO - 2021-01-07 02:53:43 --> Config Class Initialized
INFO - 2021-01-07 02:53:43 --> Loader Class Initialized
INFO - 2021-01-07 02:53:43 --> Helper loaded: url_helper
INFO - 2021-01-07 02:53:43 --> Helper loaded: file_helper
INFO - 2021-01-07 02:53:43 --> Helper loaded: form_helper
INFO - 2021-01-07 02:53:43 --> Helper loaded: my_helper
INFO - 2021-01-07 02:53:43 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:53:43 --> Controller Class Initialized
DEBUG - 2021-01-07 02:53:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:53:43 --> Final output sent to browser
DEBUG - 2021-01-07 02:53:43 --> Total execution time: 0.3070
INFO - 2021-01-07 02:54:06 --> Config Class Initialized
INFO - 2021-01-07 02:54:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:06 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:06 --> URI Class Initialized
INFO - 2021-01-07 02:54:06 --> Router Class Initialized
INFO - 2021-01-07 02:54:06 --> Output Class Initialized
INFO - 2021-01-07 02:54:06 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:06 --> Input Class Initialized
INFO - 2021-01-07 02:54:06 --> Language Class Initialized
INFO - 2021-01-07 02:54:06 --> Language Class Initialized
INFO - 2021-01-07 02:54:06 --> Config Class Initialized
INFO - 2021-01-07 02:54:06 --> Loader Class Initialized
INFO - 2021-01-07 02:54:06 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:06 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:06 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:06 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:06 --> Controller Class Initialized
DEBUG - 2021-01-07 02:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:54:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:54:06 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:06 --> Total execution time: 0.3309
INFO - 2021-01-07 02:54:07 --> Config Class Initialized
INFO - 2021-01-07 02:54:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:07 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:07 --> URI Class Initialized
INFO - 2021-01-07 02:54:07 --> Router Class Initialized
INFO - 2021-01-07 02:54:07 --> Output Class Initialized
INFO - 2021-01-07 02:54:07 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:07 --> Input Class Initialized
INFO - 2021-01-07 02:54:07 --> Language Class Initialized
INFO - 2021-01-07 02:54:07 --> Language Class Initialized
INFO - 2021-01-07 02:54:07 --> Config Class Initialized
INFO - 2021-01-07 02:54:07 --> Loader Class Initialized
INFO - 2021-01-07 02:54:07 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:07 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:07 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:07 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:07 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:07 --> Controller Class Initialized
DEBUG - 2021-01-07 02:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:54:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:54:07 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:07 --> Total execution time: 0.2852
INFO - 2021-01-07 02:54:10 --> Config Class Initialized
INFO - 2021-01-07 02:54:10 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:10 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:10 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:10 --> URI Class Initialized
INFO - 2021-01-07 02:54:10 --> Router Class Initialized
INFO - 2021-01-07 02:54:10 --> Output Class Initialized
INFO - 2021-01-07 02:54:10 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:10 --> Input Class Initialized
INFO - 2021-01-07 02:54:10 --> Language Class Initialized
INFO - 2021-01-07 02:54:10 --> Language Class Initialized
INFO - 2021-01-07 02:54:10 --> Config Class Initialized
INFO - 2021-01-07 02:54:11 --> Loader Class Initialized
INFO - 2021-01-07 02:54:11 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:11 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:11 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:11 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:11 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:11 --> Controller Class Initialized
INFO - 2021-01-07 02:54:11 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:11 --> Total execution time: 0.2911
INFO - 2021-01-07 02:54:35 --> Config Class Initialized
INFO - 2021-01-07 02:54:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:35 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:35 --> URI Class Initialized
INFO - 2021-01-07 02:54:35 --> Router Class Initialized
INFO - 2021-01-07 02:54:35 --> Output Class Initialized
INFO - 2021-01-07 02:54:35 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:35 --> Input Class Initialized
INFO - 2021-01-07 02:54:35 --> Language Class Initialized
INFO - 2021-01-07 02:54:35 --> Language Class Initialized
INFO - 2021-01-07 02:54:35 --> Config Class Initialized
INFO - 2021-01-07 02:54:35 --> Loader Class Initialized
INFO - 2021-01-07 02:54:35 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:35 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:35 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:35 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:35 --> Controller Class Initialized
INFO - 2021-01-07 02:54:35 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:35 --> Total execution time: 0.2843
INFO - 2021-01-07 02:54:35 --> Config Class Initialized
INFO - 2021-01-07 02:54:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:35 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:35 --> URI Class Initialized
INFO - 2021-01-07 02:54:35 --> Router Class Initialized
INFO - 2021-01-07 02:54:35 --> Output Class Initialized
INFO - 2021-01-07 02:54:35 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:35 --> Input Class Initialized
INFO - 2021-01-07 02:54:35 --> Language Class Initialized
INFO - 2021-01-07 02:54:35 --> Language Class Initialized
INFO - 2021-01-07 02:54:35 --> Config Class Initialized
INFO - 2021-01-07 02:54:35 --> Loader Class Initialized
INFO - 2021-01-07 02:54:36 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:36 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:36 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:36 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:36 --> Controller Class Initialized
DEBUG - 2021-01-07 02:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:54:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:54:36 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:36 --> Total execution time: 0.4856
INFO - 2021-01-07 02:54:37 --> Config Class Initialized
INFO - 2021-01-07 02:54:37 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:37 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:37 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:37 --> URI Class Initialized
INFO - 2021-01-07 02:54:37 --> Router Class Initialized
INFO - 2021-01-07 02:54:37 --> Output Class Initialized
INFO - 2021-01-07 02:54:37 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:37 --> Input Class Initialized
INFO - 2021-01-07 02:54:37 --> Language Class Initialized
INFO - 2021-01-07 02:54:37 --> Language Class Initialized
INFO - 2021-01-07 02:54:37 --> Config Class Initialized
INFO - 2021-01-07 02:54:37 --> Loader Class Initialized
INFO - 2021-01-07 02:54:37 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:37 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:37 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:37 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:37 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:37 --> Controller Class Initialized
INFO - 2021-01-07 02:54:37 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:37 --> Total execution time: 0.2913
INFO - 2021-01-07 02:54:47 --> Config Class Initialized
INFO - 2021-01-07 02:54:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:47 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:47 --> URI Class Initialized
INFO - 2021-01-07 02:54:47 --> Router Class Initialized
INFO - 2021-01-07 02:54:47 --> Output Class Initialized
INFO - 2021-01-07 02:54:47 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:47 --> Input Class Initialized
INFO - 2021-01-07 02:54:47 --> Language Class Initialized
INFO - 2021-01-07 02:54:47 --> Language Class Initialized
INFO - 2021-01-07 02:54:47 --> Config Class Initialized
INFO - 2021-01-07 02:54:47 --> Loader Class Initialized
INFO - 2021-01-07 02:54:47 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:47 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:48 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:48 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:48 --> Controller Class Initialized
INFO - 2021-01-07 02:54:48 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:48 --> Total execution time: 0.3032
INFO - 2021-01-07 02:54:48 --> Config Class Initialized
INFO - 2021-01-07 02:54:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:48 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:48 --> URI Class Initialized
INFO - 2021-01-07 02:54:48 --> Router Class Initialized
INFO - 2021-01-07 02:54:48 --> Output Class Initialized
INFO - 2021-01-07 02:54:48 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:48 --> Input Class Initialized
INFO - 2021-01-07 02:54:48 --> Language Class Initialized
INFO - 2021-01-07 02:54:48 --> Language Class Initialized
INFO - 2021-01-07 02:54:48 --> Config Class Initialized
INFO - 2021-01-07 02:54:48 --> Loader Class Initialized
INFO - 2021-01-07 02:54:48 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:48 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:48 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:48 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:48 --> Controller Class Initialized
DEBUG - 2021-01-07 02:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 02:54:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:54:48 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:48 --> Total execution time: 0.4957
INFO - 2021-01-07 02:54:50 --> Config Class Initialized
INFO - 2021-01-07 02:54:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:50 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:50 --> URI Class Initialized
INFO - 2021-01-07 02:54:50 --> Router Class Initialized
INFO - 2021-01-07 02:54:50 --> Output Class Initialized
INFO - 2021-01-07 02:54:50 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:50 --> Input Class Initialized
INFO - 2021-01-07 02:54:50 --> Language Class Initialized
INFO - 2021-01-07 02:54:50 --> Language Class Initialized
INFO - 2021-01-07 02:54:50 --> Config Class Initialized
INFO - 2021-01-07 02:54:50 --> Loader Class Initialized
INFO - 2021-01-07 02:54:50 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:50 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:50 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:50 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:50 --> Controller Class Initialized
INFO - 2021-01-07 02:54:50 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:50 --> Total execution time: 0.2738
INFO - 2021-01-07 02:54:57 --> Config Class Initialized
INFO - 2021-01-07 02:54:57 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:54:58 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:54:58 --> Utf8 Class Initialized
INFO - 2021-01-07 02:54:58 --> URI Class Initialized
INFO - 2021-01-07 02:54:58 --> Router Class Initialized
INFO - 2021-01-07 02:54:58 --> Output Class Initialized
INFO - 2021-01-07 02:54:58 --> Security Class Initialized
DEBUG - 2021-01-07 02:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:54:58 --> Input Class Initialized
INFO - 2021-01-07 02:54:58 --> Language Class Initialized
INFO - 2021-01-07 02:54:58 --> Language Class Initialized
INFO - 2021-01-07 02:54:58 --> Config Class Initialized
INFO - 2021-01-07 02:54:58 --> Loader Class Initialized
INFO - 2021-01-07 02:54:58 --> Helper loaded: url_helper
INFO - 2021-01-07 02:54:58 --> Helper loaded: file_helper
INFO - 2021-01-07 02:54:58 --> Helper loaded: form_helper
INFO - 2021-01-07 02:54:58 --> Helper loaded: my_helper
INFO - 2021-01-07 02:54:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:54:58 --> Controller Class Initialized
INFO - 2021-01-07 02:54:58 --> Final output sent to browser
DEBUG - 2021-01-07 02:54:58 --> Total execution time: 0.3613
INFO - 2021-01-07 02:55:01 --> Config Class Initialized
INFO - 2021-01-07 02:55:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:55:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:55:01 --> Utf8 Class Initialized
INFO - 2021-01-07 02:55:01 --> URI Class Initialized
INFO - 2021-01-07 02:55:01 --> Router Class Initialized
INFO - 2021-01-07 02:55:01 --> Output Class Initialized
INFO - 2021-01-07 02:55:01 --> Security Class Initialized
DEBUG - 2021-01-07 02:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:55:01 --> Input Class Initialized
INFO - 2021-01-07 02:55:01 --> Language Class Initialized
INFO - 2021-01-07 02:55:01 --> Language Class Initialized
INFO - 2021-01-07 02:55:01 --> Config Class Initialized
INFO - 2021-01-07 02:55:01 --> Loader Class Initialized
INFO - 2021-01-07 02:55:01 --> Helper loaded: url_helper
INFO - 2021-01-07 02:55:01 --> Helper loaded: file_helper
INFO - 2021-01-07 02:55:01 --> Helper loaded: form_helper
INFO - 2021-01-07 02:55:01 --> Helper loaded: my_helper
INFO - 2021-01-07 02:55:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:55:01 --> Controller Class Initialized
INFO - 2021-01-07 02:55:01 --> Final output sent to browser
DEBUG - 2021-01-07 02:55:01 --> Total execution time: 0.2645
INFO - 2021-01-07 02:55:07 --> Config Class Initialized
INFO - 2021-01-07 02:55:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:55:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:55:07 --> Utf8 Class Initialized
INFO - 2021-01-07 02:55:07 --> URI Class Initialized
INFO - 2021-01-07 02:55:07 --> Router Class Initialized
INFO - 2021-01-07 02:55:07 --> Output Class Initialized
INFO - 2021-01-07 02:55:07 --> Security Class Initialized
DEBUG - 2021-01-07 02:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:55:07 --> Input Class Initialized
INFO - 2021-01-07 02:55:07 --> Language Class Initialized
INFO - 2021-01-07 02:55:07 --> Language Class Initialized
INFO - 2021-01-07 02:55:07 --> Config Class Initialized
INFO - 2021-01-07 02:55:07 --> Loader Class Initialized
INFO - 2021-01-07 02:55:07 --> Helper loaded: url_helper
INFO - 2021-01-07 02:55:07 --> Helper loaded: file_helper
INFO - 2021-01-07 02:55:07 --> Helper loaded: form_helper
INFO - 2021-01-07 02:55:07 --> Helper loaded: my_helper
INFO - 2021-01-07 02:55:07 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:55:07 --> Controller Class Initialized
INFO - 2021-01-07 02:55:07 --> Final output sent to browser
DEBUG - 2021-01-07 02:55:07 --> Total execution time: 0.3628
INFO - 2021-01-07 02:55:12 --> Config Class Initialized
INFO - 2021-01-07 02:55:12 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:55:12 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:55:12 --> Utf8 Class Initialized
INFO - 2021-01-07 02:55:12 --> URI Class Initialized
INFO - 2021-01-07 02:55:12 --> Router Class Initialized
INFO - 2021-01-07 02:55:12 --> Output Class Initialized
INFO - 2021-01-07 02:55:12 --> Security Class Initialized
DEBUG - 2021-01-07 02:55:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:55:12 --> Input Class Initialized
INFO - 2021-01-07 02:55:12 --> Language Class Initialized
INFO - 2021-01-07 02:55:12 --> Language Class Initialized
INFO - 2021-01-07 02:55:12 --> Config Class Initialized
INFO - 2021-01-07 02:55:12 --> Loader Class Initialized
INFO - 2021-01-07 02:55:12 --> Helper loaded: url_helper
INFO - 2021-01-07 02:55:12 --> Helper loaded: file_helper
INFO - 2021-01-07 02:55:12 --> Helper loaded: form_helper
INFO - 2021-01-07 02:55:12 --> Helper loaded: my_helper
INFO - 2021-01-07 02:55:12 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:55:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:55:12 --> Controller Class Initialized
DEBUG - 2021-01-07 02:55:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 02:55:12 --> Final output sent to browser
DEBUG - 2021-01-07 02:55:12 --> Total execution time: 0.3497
INFO - 2021-01-07 02:55:20 --> Config Class Initialized
INFO - 2021-01-07 02:55:20 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:55:20 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:55:20 --> Utf8 Class Initialized
INFO - 2021-01-07 02:55:20 --> URI Class Initialized
INFO - 2021-01-07 02:55:20 --> Router Class Initialized
INFO - 2021-01-07 02:55:20 --> Output Class Initialized
INFO - 2021-01-07 02:55:20 --> Security Class Initialized
DEBUG - 2021-01-07 02:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:55:20 --> Input Class Initialized
INFO - 2021-01-07 02:55:20 --> Language Class Initialized
INFO - 2021-01-07 02:55:20 --> Language Class Initialized
INFO - 2021-01-07 02:55:20 --> Config Class Initialized
INFO - 2021-01-07 02:55:20 --> Loader Class Initialized
INFO - 2021-01-07 02:55:20 --> Helper loaded: url_helper
INFO - 2021-01-07 02:55:20 --> Helper loaded: file_helper
INFO - 2021-01-07 02:55:20 --> Helper loaded: form_helper
INFO - 2021-01-07 02:55:20 --> Helper loaded: my_helper
INFO - 2021-01-07 02:55:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:55:21 --> Controller Class Initialized
INFO - 2021-01-07 02:55:21 --> Final output sent to browser
DEBUG - 2021-01-07 02:55:21 --> Total execution time: 0.2600
INFO - 2021-01-07 02:55:26 --> Config Class Initialized
INFO - 2021-01-07 02:55:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:55:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:55:26 --> Utf8 Class Initialized
INFO - 2021-01-07 02:55:26 --> URI Class Initialized
INFO - 2021-01-07 02:55:26 --> Router Class Initialized
INFO - 2021-01-07 02:55:26 --> Output Class Initialized
INFO - 2021-01-07 02:55:26 --> Security Class Initialized
DEBUG - 2021-01-07 02:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:55:26 --> Input Class Initialized
INFO - 2021-01-07 02:55:26 --> Language Class Initialized
INFO - 2021-01-07 02:55:26 --> Language Class Initialized
INFO - 2021-01-07 02:55:26 --> Config Class Initialized
INFO - 2021-01-07 02:55:26 --> Loader Class Initialized
INFO - 2021-01-07 02:55:26 --> Helper loaded: url_helper
INFO - 2021-01-07 02:55:26 --> Helper loaded: file_helper
INFO - 2021-01-07 02:55:26 --> Helper loaded: form_helper
INFO - 2021-01-07 02:55:26 --> Helper loaded: my_helper
INFO - 2021-01-07 02:55:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:55:26 --> Controller Class Initialized
INFO - 2021-01-07 02:55:26 --> Final output sent to browser
DEBUG - 2021-01-07 02:55:26 --> Total execution time: 0.4271
INFO - 2021-01-07 02:55:28 --> Config Class Initialized
INFO - 2021-01-07 02:55:28 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:55:28 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:55:28 --> Utf8 Class Initialized
INFO - 2021-01-07 02:55:28 --> URI Class Initialized
INFO - 2021-01-07 02:55:28 --> Router Class Initialized
INFO - 2021-01-07 02:55:29 --> Output Class Initialized
INFO - 2021-01-07 02:55:29 --> Security Class Initialized
DEBUG - 2021-01-07 02:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:55:29 --> Input Class Initialized
INFO - 2021-01-07 02:55:29 --> Language Class Initialized
INFO - 2021-01-07 02:55:29 --> Language Class Initialized
INFO - 2021-01-07 02:55:29 --> Config Class Initialized
INFO - 2021-01-07 02:55:29 --> Loader Class Initialized
INFO - 2021-01-07 02:55:29 --> Helper loaded: url_helper
INFO - 2021-01-07 02:55:29 --> Helper loaded: file_helper
INFO - 2021-01-07 02:55:29 --> Helper loaded: form_helper
INFO - 2021-01-07 02:55:29 --> Helper loaded: my_helper
INFO - 2021-01-07 02:55:29 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:55:29 --> Controller Class Initialized
DEBUG - 2021-01-07 02:55:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 02:55:29 --> Final output sent to browser
DEBUG - 2021-01-07 02:55:29 --> Total execution time: 0.3534
INFO - 2021-01-07 02:55:33 --> Config Class Initialized
INFO - 2021-01-07 02:55:33 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:55:33 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:55:33 --> Utf8 Class Initialized
INFO - 2021-01-07 02:55:33 --> URI Class Initialized
INFO - 2021-01-07 02:55:33 --> Router Class Initialized
INFO - 2021-01-07 02:55:33 --> Output Class Initialized
INFO - 2021-01-07 02:55:33 --> Security Class Initialized
DEBUG - 2021-01-07 02:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:55:34 --> Input Class Initialized
INFO - 2021-01-07 02:55:34 --> Language Class Initialized
INFO - 2021-01-07 02:55:34 --> Language Class Initialized
INFO - 2021-01-07 02:55:34 --> Config Class Initialized
INFO - 2021-01-07 02:55:34 --> Loader Class Initialized
INFO - 2021-01-07 02:55:34 --> Helper loaded: url_helper
INFO - 2021-01-07 02:55:34 --> Helper loaded: file_helper
INFO - 2021-01-07 02:55:34 --> Helper loaded: form_helper
INFO - 2021-01-07 02:55:34 --> Helper loaded: my_helper
INFO - 2021-01-07 02:55:34 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:55:34 --> Controller Class Initialized
DEBUG - 2021-01-07 02:55:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 02:55:34 --> Final output sent to browser
DEBUG - 2021-01-07 02:55:34 --> Total execution time: 0.3156
INFO - 2021-01-07 02:56:01 --> Config Class Initialized
INFO - 2021-01-07 02:56:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:56:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:56:01 --> Utf8 Class Initialized
INFO - 2021-01-07 02:56:01 --> URI Class Initialized
INFO - 2021-01-07 02:56:01 --> Router Class Initialized
INFO - 2021-01-07 02:56:01 --> Output Class Initialized
INFO - 2021-01-07 02:56:01 --> Security Class Initialized
DEBUG - 2021-01-07 02:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:56:01 --> Input Class Initialized
INFO - 2021-01-07 02:56:01 --> Language Class Initialized
INFO - 2021-01-07 02:56:01 --> Language Class Initialized
INFO - 2021-01-07 02:56:01 --> Config Class Initialized
INFO - 2021-01-07 02:56:01 --> Loader Class Initialized
INFO - 2021-01-07 02:56:01 --> Helper loaded: url_helper
INFO - 2021-01-07 02:56:01 --> Helper loaded: file_helper
INFO - 2021-01-07 02:56:01 --> Helper loaded: form_helper
INFO - 2021-01-07 02:56:01 --> Helper loaded: my_helper
INFO - 2021-01-07 02:56:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:56:01 --> Controller Class Initialized
INFO - 2021-01-07 02:56:31 --> Config Class Initialized
INFO - 2021-01-07 02:56:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:56:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:56:32 --> Utf8 Class Initialized
INFO - 2021-01-07 02:56:32 --> URI Class Initialized
INFO - 2021-01-07 02:56:32 --> Router Class Initialized
INFO - 2021-01-07 02:56:32 --> Output Class Initialized
INFO - 2021-01-07 02:56:32 --> Security Class Initialized
DEBUG - 2021-01-07 02:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:56:32 --> Input Class Initialized
INFO - 2021-01-07 02:56:32 --> Language Class Initialized
INFO - 2021-01-07 02:56:32 --> Language Class Initialized
INFO - 2021-01-07 02:56:32 --> Config Class Initialized
INFO - 2021-01-07 02:56:32 --> Loader Class Initialized
INFO - 2021-01-07 02:56:32 --> Helper loaded: url_helper
INFO - 2021-01-07 02:56:32 --> Helper loaded: file_helper
INFO - 2021-01-07 02:56:32 --> Helper loaded: form_helper
INFO - 2021-01-07 02:56:32 --> Helper loaded: my_helper
INFO - 2021-01-07 02:56:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:56:32 --> Controller Class Initialized
DEBUG - 2021-01-07 02:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 02:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:56:32 --> Final output sent to browser
DEBUG - 2021-01-07 02:56:32 --> Total execution time: 0.3589
INFO - 2021-01-07 02:56:33 --> Config Class Initialized
INFO - 2021-01-07 02:56:33 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:56:33 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:56:33 --> Utf8 Class Initialized
INFO - 2021-01-07 02:56:33 --> URI Class Initialized
INFO - 2021-01-07 02:56:33 --> Router Class Initialized
INFO - 2021-01-07 02:56:33 --> Output Class Initialized
INFO - 2021-01-07 02:56:33 --> Security Class Initialized
DEBUG - 2021-01-07 02:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:56:33 --> Input Class Initialized
INFO - 2021-01-07 02:56:33 --> Language Class Initialized
INFO - 2021-01-07 02:56:33 --> Language Class Initialized
INFO - 2021-01-07 02:56:33 --> Config Class Initialized
INFO - 2021-01-07 02:56:33 --> Loader Class Initialized
INFO - 2021-01-07 02:56:33 --> Helper loaded: url_helper
INFO - 2021-01-07 02:56:33 --> Helper loaded: file_helper
INFO - 2021-01-07 02:56:33 --> Helper loaded: form_helper
INFO - 2021-01-07 02:56:33 --> Helper loaded: my_helper
INFO - 2021-01-07 02:56:33 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:56:33 --> Controller Class Initialized
DEBUG - 2021-01-07 02:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 02:56:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 02:56:34 --> Final output sent to browser
DEBUG - 2021-01-07 02:56:34 --> Total execution time: 0.3030
INFO - 2021-01-07 02:56:34 --> Config Class Initialized
INFO - 2021-01-07 02:56:34 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:56:34 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:56:34 --> Utf8 Class Initialized
INFO - 2021-01-07 02:56:34 --> URI Class Initialized
INFO - 2021-01-07 02:56:34 --> Router Class Initialized
INFO - 2021-01-07 02:56:34 --> Output Class Initialized
INFO - 2021-01-07 02:56:34 --> Security Class Initialized
DEBUG - 2021-01-07 02:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:56:34 --> Input Class Initialized
INFO - 2021-01-07 02:56:34 --> Language Class Initialized
INFO - 2021-01-07 02:56:34 --> Language Class Initialized
INFO - 2021-01-07 02:56:34 --> Config Class Initialized
INFO - 2021-01-07 02:56:34 --> Loader Class Initialized
INFO - 2021-01-07 02:56:34 --> Helper loaded: url_helper
INFO - 2021-01-07 02:56:34 --> Helper loaded: file_helper
INFO - 2021-01-07 02:56:34 --> Helper loaded: form_helper
INFO - 2021-01-07 02:56:34 --> Helper loaded: my_helper
INFO - 2021-01-07 02:56:34 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:56:34 --> Controller Class Initialized
INFO - 2021-01-07 02:56:35 --> Config Class Initialized
INFO - 2021-01-07 02:56:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 02:56:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 02:56:35 --> Utf8 Class Initialized
INFO - 2021-01-07 02:56:35 --> URI Class Initialized
INFO - 2021-01-07 02:56:35 --> Router Class Initialized
INFO - 2021-01-07 02:56:35 --> Output Class Initialized
INFO - 2021-01-07 02:56:35 --> Security Class Initialized
DEBUG - 2021-01-07 02:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 02:56:35 --> Input Class Initialized
INFO - 2021-01-07 02:56:35 --> Language Class Initialized
INFO - 2021-01-07 02:56:35 --> Language Class Initialized
INFO - 2021-01-07 02:56:36 --> Config Class Initialized
INFO - 2021-01-07 02:56:36 --> Loader Class Initialized
INFO - 2021-01-07 02:56:36 --> Helper loaded: url_helper
INFO - 2021-01-07 02:56:36 --> Helper loaded: file_helper
INFO - 2021-01-07 02:56:36 --> Helper loaded: form_helper
INFO - 2021-01-07 02:56:36 --> Helper loaded: my_helper
INFO - 2021-01-07 02:56:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 02:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 02:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 02:56:36 --> Controller Class Initialized
INFO - 2021-01-07 03:06:58 --> Config Class Initialized
INFO - 2021-01-07 03:06:58 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:06:58 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:06:58 --> Utf8 Class Initialized
INFO - 2021-01-07 03:06:58 --> URI Class Initialized
INFO - 2021-01-07 03:06:58 --> Router Class Initialized
INFO - 2021-01-07 03:06:58 --> Output Class Initialized
INFO - 2021-01-07 03:06:58 --> Security Class Initialized
DEBUG - 2021-01-07 03:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:06:58 --> Input Class Initialized
INFO - 2021-01-07 03:06:58 --> Language Class Initialized
INFO - 2021-01-07 03:06:58 --> Language Class Initialized
INFO - 2021-01-07 03:06:58 --> Config Class Initialized
INFO - 2021-01-07 03:06:58 --> Loader Class Initialized
INFO - 2021-01-07 03:06:58 --> Helper loaded: url_helper
INFO - 2021-01-07 03:06:58 --> Helper loaded: file_helper
INFO - 2021-01-07 03:06:58 --> Helper loaded: form_helper
INFO - 2021-01-07 03:06:58 --> Helper loaded: my_helper
INFO - 2021-01-07 03:06:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:06:58 --> Controller Class Initialized
INFO - 2021-01-07 03:06:58 --> Helper loaded: cookie_helper
INFO - 2021-01-07 03:06:58 --> Config Class Initialized
INFO - 2021-01-07 03:06:58 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:06:58 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:06:58 --> Utf8 Class Initialized
INFO - 2021-01-07 03:06:58 --> URI Class Initialized
INFO - 2021-01-07 03:06:58 --> Router Class Initialized
INFO - 2021-01-07 03:06:58 --> Output Class Initialized
INFO - 2021-01-07 03:06:58 --> Security Class Initialized
DEBUG - 2021-01-07 03:06:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:06:58 --> Input Class Initialized
INFO - 2021-01-07 03:06:58 --> Language Class Initialized
INFO - 2021-01-07 03:06:58 --> Language Class Initialized
INFO - 2021-01-07 03:06:58 --> Config Class Initialized
INFO - 2021-01-07 03:06:58 --> Loader Class Initialized
INFO - 2021-01-07 03:06:58 --> Helper loaded: url_helper
INFO - 2021-01-07 03:06:58 --> Helper loaded: file_helper
INFO - 2021-01-07 03:06:58 --> Helper loaded: form_helper
INFO - 2021-01-07 03:06:58 --> Helper loaded: my_helper
INFO - 2021-01-07 03:06:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:06:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:06:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:06:58 --> Controller Class Initialized
DEBUG - 2021-01-07 03:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 03:06:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 03:06:58 --> Final output sent to browser
DEBUG - 2021-01-07 03:06:58 --> Total execution time: 0.3077
INFO - 2021-01-07 03:07:03 --> Config Class Initialized
INFO - 2021-01-07 03:07:03 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:07:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:07:03 --> Utf8 Class Initialized
INFO - 2021-01-07 03:07:03 --> URI Class Initialized
INFO - 2021-01-07 03:07:03 --> Router Class Initialized
INFO - 2021-01-07 03:07:03 --> Output Class Initialized
INFO - 2021-01-07 03:07:03 --> Security Class Initialized
DEBUG - 2021-01-07 03:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:07:03 --> Input Class Initialized
INFO - 2021-01-07 03:07:03 --> Language Class Initialized
INFO - 2021-01-07 03:07:03 --> Language Class Initialized
INFO - 2021-01-07 03:07:03 --> Config Class Initialized
INFO - 2021-01-07 03:07:03 --> Loader Class Initialized
INFO - 2021-01-07 03:07:03 --> Helper loaded: url_helper
INFO - 2021-01-07 03:07:03 --> Helper loaded: file_helper
INFO - 2021-01-07 03:07:03 --> Helper loaded: form_helper
INFO - 2021-01-07 03:07:03 --> Helper loaded: my_helper
INFO - 2021-01-07 03:07:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:07:03 --> Controller Class Initialized
INFO - 2021-01-07 03:07:03 --> Helper loaded: cookie_helper
INFO - 2021-01-07 03:07:03 --> Final output sent to browser
DEBUG - 2021-01-07 03:07:03 --> Total execution time: 0.4182
INFO - 2021-01-07 03:07:04 --> Config Class Initialized
INFO - 2021-01-07 03:07:04 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:07:04 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:07:04 --> Utf8 Class Initialized
INFO - 2021-01-07 03:07:04 --> URI Class Initialized
INFO - 2021-01-07 03:07:04 --> Router Class Initialized
INFO - 2021-01-07 03:07:04 --> Output Class Initialized
INFO - 2021-01-07 03:07:04 --> Security Class Initialized
DEBUG - 2021-01-07 03:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:07:04 --> Input Class Initialized
INFO - 2021-01-07 03:07:04 --> Language Class Initialized
INFO - 2021-01-07 03:07:04 --> Language Class Initialized
INFO - 2021-01-07 03:07:04 --> Config Class Initialized
INFO - 2021-01-07 03:07:04 --> Loader Class Initialized
INFO - 2021-01-07 03:07:04 --> Helper loaded: url_helper
INFO - 2021-01-07 03:07:04 --> Helper loaded: file_helper
INFO - 2021-01-07 03:07:04 --> Helper loaded: form_helper
INFO - 2021-01-07 03:07:04 --> Helper loaded: my_helper
INFO - 2021-01-07 03:07:04 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:07:04 --> Controller Class Initialized
DEBUG - 2021-01-07 03:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 03:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 03:07:04 --> Final output sent to browser
DEBUG - 2021-01-07 03:07:04 --> Total execution time: 0.4506
INFO - 2021-01-07 03:11:06 --> Config Class Initialized
INFO - 2021-01-07 03:11:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:11:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:11:06 --> Utf8 Class Initialized
INFO - 2021-01-07 03:11:06 --> URI Class Initialized
INFO - 2021-01-07 03:11:06 --> Router Class Initialized
INFO - 2021-01-07 03:11:06 --> Output Class Initialized
INFO - 2021-01-07 03:11:06 --> Security Class Initialized
DEBUG - 2021-01-07 03:11:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:11:06 --> Input Class Initialized
INFO - 2021-01-07 03:11:06 --> Language Class Initialized
INFO - 2021-01-07 03:11:06 --> Language Class Initialized
INFO - 2021-01-07 03:11:06 --> Config Class Initialized
INFO - 2021-01-07 03:11:06 --> Loader Class Initialized
INFO - 2021-01-07 03:11:06 --> Helper loaded: url_helper
INFO - 2021-01-07 03:11:06 --> Helper loaded: file_helper
INFO - 2021-01-07 03:11:06 --> Helper loaded: form_helper
INFO - 2021-01-07 03:11:06 --> Helper loaded: my_helper
INFO - 2021-01-07 03:11:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:11:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:11:06 --> Controller Class Initialized
DEBUG - 2021-01-07 03:11:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:11:06 --> Final output sent to browser
DEBUG - 2021-01-07 03:11:06 --> Total execution time: 0.3500
INFO - 2021-01-07 03:11:08 --> Config Class Initialized
INFO - 2021-01-07 03:11:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:11:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:11:08 --> Utf8 Class Initialized
INFO - 2021-01-07 03:11:08 --> URI Class Initialized
INFO - 2021-01-07 03:11:08 --> Router Class Initialized
INFO - 2021-01-07 03:11:08 --> Output Class Initialized
INFO - 2021-01-07 03:11:08 --> Security Class Initialized
DEBUG - 2021-01-07 03:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:11:08 --> Input Class Initialized
INFO - 2021-01-07 03:11:08 --> Language Class Initialized
INFO - 2021-01-07 03:11:08 --> Language Class Initialized
INFO - 2021-01-07 03:11:08 --> Config Class Initialized
INFO - 2021-01-07 03:11:08 --> Loader Class Initialized
INFO - 2021-01-07 03:11:08 --> Helper loaded: url_helper
INFO - 2021-01-07 03:11:08 --> Helper loaded: file_helper
INFO - 2021-01-07 03:11:08 --> Helper loaded: form_helper
INFO - 2021-01-07 03:11:08 --> Helper loaded: my_helper
INFO - 2021-01-07 03:11:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:11:08 --> Controller Class Initialized
DEBUG - 2021-01-07 03:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:11:08 --> Final output sent to browser
DEBUG - 2021-01-07 03:11:08 --> Total execution time: 0.3200
INFO - 2021-01-07 03:18:47 --> Config Class Initialized
INFO - 2021-01-07 03:18:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:18:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:18:47 --> Utf8 Class Initialized
INFO - 2021-01-07 03:18:47 --> URI Class Initialized
INFO - 2021-01-07 03:18:47 --> Router Class Initialized
INFO - 2021-01-07 03:18:47 --> Output Class Initialized
INFO - 2021-01-07 03:18:47 --> Security Class Initialized
DEBUG - 2021-01-07 03:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:18:47 --> Input Class Initialized
INFO - 2021-01-07 03:18:47 --> Language Class Initialized
INFO - 2021-01-07 03:18:47 --> Language Class Initialized
INFO - 2021-01-07 03:18:47 --> Config Class Initialized
INFO - 2021-01-07 03:18:47 --> Loader Class Initialized
INFO - 2021-01-07 03:18:47 --> Helper loaded: url_helper
INFO - 2021-01-07 03:18:47 --> Helper loaded: file_helper
INFO - 2021-01-07 03:18:47 --> Helper loaded: form_helper
INFO - 2021-01-07 03:18:47 --> Helper loaded: my_helper
INFO - 2021-01-07 03:18:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:18:47 --> Controller Class Initialized
DEBUG - 2021-01-07 03:18:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:18:47 --> Final output sent to browser
DEBUG - 2021-01-07 03:18:47 --> Total execution time: 0.3913
INFO - 2021-01-07 03:18:57 --> Config Class Initialized
INFO - 2021-01-07 03:18:57 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:18:57 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:18:57 --> Utf8 Class Initialized
INFO - 2021-01-07 03:18:57 --> URI Class Initialized
INFO - 2021-01-07 03:18:57 --> Router Class Initialized
INFO - 2021-01-07 03:18:57 --> Output Class Initialized
INFO - 2021-01-07 03:18:57 --> Security Class Initialized
DEBUG - 2021-01-07 03:18:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:18:57 --> Input Class Initialized
INFO - 2021-01-07 03:18:57 --> Language Class Initialized
INFO - 2021-01-07 03:18:57 --> Language Class Initialized
INFO - 2021-01-07 03:18:57 --> Config Class Initialized
INFO - 2021-01-07 03:18:57 --> Loader Class Initialized
INFO - 2021-01-07 03:18:57 --> Helper loaded: url_helper
INFO - 2021-01-07 03:18:57 --> Helper loaded: file_helper
INFO - 2021-01-07 03:18:57 --> Helper loaded: form_helper
INFO - 2021-01-07 03:18:57 --> Helper loaded: my_helper
INFO - 2021-01-07 03:18:57 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:18:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:18:57 --> Controller Class Initialized
DEBUG - 2021-01-07 03:18:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:18:57 --> Final output sent to browser
DEBUG - 2021-01-07 03:18:57 --> Total execution time: 0.4093
INFO - 2021-01-07 03:22:03 --> Config Class Initialized
INFO - 2021-01-07 03:22:03 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:22:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:22:03 --> Utf8 Class Initialized
INFO - 2021-01-07 03:22:03 --> URI Class Initialized
INFO - 2021-01-07 03:22:03 --> Router Class Initialized
INFO - 2021-01-07 03:22:03 --> Output Class Initialized
INFO - 2021-01-07 03:22:03 --> Security Class Initialized
DEBUG - 2021-01-07 03:22:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:22:03 --> Input Class Initialized
INFO - 2021-01-07 03:22:03 --> Language Class Initialized
INFO - 2021-01-07 03:22:03 --> Language Class Initialized
INFO - 2021-01-07 03:22:03 --> Config Class Initialized
INFO - 2021-01-07 03:22:03 --> Loader Class Initialized
INFO - 2021-01-07 03:22:03 --> Helper loaded: url_helper
INFO - 2021-01-07 03:22:03 --> Helper loaded: file_helper
INFO - 2021-01-07 03:22:03 --> Helper loaded: form_helper
INFO - 2021-01-07 03:22:03 --> Helper loaded: my_helper
INFO - 2021-01-07 03:22:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:22:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:22:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:22:03 --> Controller Class Initialized
DEBUG - 2021-01-07 03:22:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:22:03 --> Final output sent to browser
DEBUG - 2021-01-07 03:22:03 --> Total execution time: 0.3362
INFO - 2021-01-07 03:27:53 --> Config Class Initialized
INFO - 2021-01-07 03:27:53 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:27:53 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:27:53 --> Utf8 Class Initialized
INFO - 2021-01-07 03:27:53 --> URI Class Initialized
INFO - 2021-01-07 03:27:53 --> Router Class Initialized
INFO - 2021-01-07 03:27:53 --> Output Class Initialized
INFO - 2021-01-07 03:27:53 --> Security Class Initialized
DEBUG - 2021-01-07 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:27:53 --> Input Class Initialized
INFO - 2021-01-07 03:27:53 --> Language Class Initialized
INFO - 2021-01-07 03:27:53 --> Language Class Initialized
INFO - 2021-01-07 03:27:53 --> Config Class Initialized
INFO - 2021-01-07 03:27:53 --> Loader Class Initialized
INFO - 2021-01-07 03:27:53 --> Helper loaded: url_helper
INFO - 2021-01-07 03:27:53 --> Helper loaded: file_helper
INFO - 2021-01-07 03:27:53 --> Helper loaded: form_helper
INFO - 2021-01-07 03:27:53 --> Helper loaded: my_helper
INFO - 2021-01-07 03:27:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:27:53 --> Controller Class Initialized
ERROR - 2021-01-07 03:27:53 --> Query error: Table 'db_nilai.t_mapel_kd' doesn't exist - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-07 03:27:53 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 03:29:02 --> Config Class Initialized
INFO - 2021-01-07 03:29:02 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:29:02 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:29:02 --> Utf8 Class Initialized
INFO - 2021-01-07 03:29:02 --> URI Class Initialized
INFO - 2021-01-07 03:29:02 --> Router Class Initialized
INFO - 2021-01-07 03:29:02 --> Output Class Initialized
INFO - 2021-01-07 03:29:02 --> Security Class Initialized
DEBUG - 2021-01-07 03:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:29:02 --> Input Class Initialized
INFO - 2021-01-07 03:29:02 --> Language Class Initialized
INFO - 2021-01-07 03:29:02 --> Language Class Initialized
INFO - 2021-01-07 03:29:02 --> Config Class Initialized
INFO - 2021-01-07 03:29:02 --> Loader Class Initialized
INFO - 2021-01-07 03:29:02 --> Helper loaded: url_helper
INFO - 2021-01-07 03:29:02 --> Helper loaded: file_helper
INFO - 2021-01-07 03:29:02 --> Helper loaded: form_helper
INFO - 2021-01-07 03:29:02 --> Helper loaded: my_helper
INFO - 2021-01-07 03:29:02 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:29:02 --> Controller Class Initialized
ERROR - 2021-01-07 03:29:02 --> Query error: Unknown column 'd.nama_kd' in 'field list' - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-07 03:29:02 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 03:29:50 --> Config Class Initialized
INFO - 2021-01-07 03:29:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:29:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:29:50 --> Utf8 Class Initialized
INFO - 2021-01-07 03:29:50 --> URI Class Initialized
INFO - 2021-01-07 03:29:50 --> Router Class Initialized
INFO - 2021-01-07 03:29:50 --> Output Class Initialized
INFO - 2021-01-07 03:29:50 --> Security Class Initialized
DEBUG - 2021-01-07 03:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:29:50 --> Input Class Initialized
INFO - 2021-01-07 03:29:50 --> Language Class Initialized
INFO - 2021-01-07 03:29:50 --> Language Class Initialized
INFO - 2021-01-07 03:29:50 --> Config Class Initialized
INFO - 2021-01-07 03:29:50 --> Loader Class Initialized
INFO - 2021-01-07 03:29:50 --> Helper loaded: url_helper
INFO - 2021-01-07 03:29:50 --> Helper loaded: file_helper
INFO - 2021-01-07 03:29:51 --> Helper loaded: form_helper
INFO - 2021-01-07 03:29:51 --> Helper loaded: my_helper
INFO - 2021-01-07 03:29:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:29:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:29:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:29:51 --> Controller Class Initialized
ERROR - 2021-01-07 03:29:51 --> Severity: Notice --> Undefined variable: i C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 328
ERROR - 2021-01-07 03:29:51 --> Severity: Notice --> Undefined index:  C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 328
DEBUG - 2021-01-07 03:29:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:29:51 --> Final output sent to browser
DEBUG - 2021-01-07 03:29:51 --> Total execution time: 0.3411
INFO - 2021-01-07 03:31:23 --> Config Class Initialized
INFO - 2021-01-07 03:31:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:31:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:31:23 --> Utf8 Class Initialized
INFO - 2021-01-07 03:31:23 --> URI Class Initialized
INFO - 2021-01-07 03:31:23 --> Router Class Initialized
INFO - 2021-01-07 03:31:23 --> Output Class Initialized
INFO - 2021-01-07 03:31:23 --> Security Class Initialized
DEBUG - 2021-01-07 03:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:31:23 --> Input Class Initialized
INFO - 2021-01-07 03:31:23 --> Language Class Initialized
INFO - 2021-01-07 03:31:23 --> Language Class Initialized
INFO - 2021-01-07 03:31:23 --> Config Class Initialized
INFO - 2021-01-07 03:31:23 --> Loader Class Initialized
INFO - 2021-01-07 03:31:23 --> Helper loaded: url_helper
INFO - 2021-01-07 03:31:23 --> Helper loaded: file_helper
INFO - 2021-01-07 03:31:23 --> Helper loaded: form_helper
INFO - 2021-01-07 03:31:23 --> Helper loaded: my_helper
INFO - 2021-01-07 03:31:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:31:23 --> Controller Class Initialized
ERROR - 2021-01-07 03:31:23 --> Severity: Notice --> Array to string conversion C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 328
DEBUG - 2021-01-07 03:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:31:23 --> Final output sent to browser
DEBUG - 2021-01-07 03:31:23 --> Total execution time: 0.3294
INFO - 2021-01-07 03:32:00 --> Config Class Initialized
INFO - 2021-01-07 03:32:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:32:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:32:00 --> Utf8 Class Initialized
INFO - 2021-01-07 03:32:00 --> URI Class Initialized
INFO - 2021-01-07 03:32:00 --> Router Class Initialized
INFO - 2021-01-07 03:32:00 --> Output Class Initialized
INFO - 2021-01-07 03:32:00 --> Security Class Initialized
DEBUG - 2021-01-07 03:32:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:32:00 --> Input Class Initialized
INFO - 2021-01-07 03:32:00 --> Language Class Initialized
ERROR - 2021-01-07 03:32:00 --> Severity: Parsing Error --> syntax error, unexpected 'A' (T_STRING) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 328
INFO - 2021-01-07 03:32:17 --> Config Class Initialized
INFO - 2021-01-07 03:32:17 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:32:17 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:32:17 --> Utf8 Class Initialized
INFO - 2021-01-07 03:32:17 --> URI Class Initialized
INFO - 2021-01-07 03:32:17 --> Router Class Initialized
INFO - 2021-01-07 03:32:17 --> Output Class Initialized
INFO - 2021-01-07 03:32:17 --> Security Class Initialized
DEBUG - 2021-01-07 03:32:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:32:17 --> Input Class Initialized
INFO - 2021-01-07 03:32:17 --> Language Class Initialized
INFO - 2021-01-07 03:32:17 --> Language Class Initialized
INFO - 2021-01-07 03:32:17 --> Config Class Initialized
INFO - 2021-01-07 03:32:17 --> Loader Class Initialized
INFO - 2021-01-07 03:32:17 --> Helper loaded: url_helper
INFO - 2021-01-07 03:32:17 --> Helper loaded: file_helper
INFO - 2021-01-07 03:32:17 --> Helper loaded: form_helper
INFO - 2021-01-07 03:32:17 --> Helper loaded: my_helper
INFO - 2021-01-07 03:32:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:32:18 --> Controller Class Initialized
DEBUG - 2021-01-07 03:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:32:18 --> Final output sent to browser
DEBUG - 2021-01-07 03:32:18 --> Total execution time: 0.3203
INFO - 2021-01-07 03:32:31 --> Config Class Initialized
INFO - 2021-01-07 03:32:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 03:32:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 03:32:31 --> Utf8 Class Initialized
INFO - 2021-01-07 03:32:31 --> URI Class Initialized
INFO - 2021-01-07 03:32:31 --> Router Class Initialized
INFO - 2021-01-07 03:32:31 --> Output Class Initialized
INFO - 2021-01-07 03:32:31 --> Security Class Initialized
DEBUG - 2021-01-07 03:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 03:32:31 --> Input Class Initialized
INFO - 2021-01-07 03:32:31 --> Language Class Initialized
INFO - 2021-01-07 03:32:31 --> Language Class Initialized
INFO - 2021-01-07 03:32:31 --> Config Class Initialized
INFO - 2021-01-07 03:32:31 --> Loader Class Initialized
INFO - 2021-01-07 03:32:31 --> Helper loaded: url_helper
INFO - 2021-01-07 03:32:31 --> Helper loaded: file_helper
INFO - 2021-01-07 03:32:31 --> Helper loaded: form_helper
INFO - 2021-01-07 03:32:31 --> Helper loaded: my_helper
INFO - 2021-01-07 03:32:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 03:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 03:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 03:32:32 --> Controller Class Initialized
DEBUG - 2021-01-07 03:32:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 03:32:32 --> Final output sent to browser
DEBUG - 2021-01-07 03:32:32 --> Total execution time: 0.3249
INFO - 2021-01-07 04:12:36 --> Config Class Initialized
INFO - 2021-01-07 04:12:36 --> Hooks Class Initialized
DEBUG - 2021-01-07 04:12:36 --> UTF-8 Support Enabled
INFO - 2021-01-07 04:12:36 --> Utf8 Class Initialized
INFO - 2021-01-07 04:12:36 --> URI Class Initialized
INFO - 2021-01-07 04:12:36 --> Router Class Initialized
INFO - 2021-01-07 04:12:36 --> Output Class Initialized
INFO - 2021-01-07 04:12:36 --> Security Class Initialized
DEBUG - 2021-01-07 04:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 04:12:36 --> Input Class Initialized
INFO - 2021-01-07 04:12:36 --> Language Class Initialized
INFO - 2021-01-07 04:12:36 --> Language Class Initialized
INFO - 2021-01-07 04:12:36 --> Config Class Initialized
INFO - 2021-01-07 04:12:36 --> Loader Class Initialized
INFO - 2021-01-07 04:12:36 --> Helper loaded: url_helper
INFO - 2021-01-07 04:12:36 --> Helper loaded: file_helper
INFO - 2021-01-07 04:12:36 --> Helper loaded: form_helper
INFO - 2021-01-07 04:12:36 --> Helper loaded: my_helper
INFO - 2021-01-07 04:12:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 04:12:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 04:12:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 04:12:36 --> Controller Class Initialized
INFO - 2021-01-07 04:12:36 --> Helper loaded: cookie_helper
INFO - 2021-01-07 04:12:36 --> Config Class Initialized
INFO - 2021-01-07 04:12:36 --> Hooks Class Initialized
DEBUG - 2021-01-07 04:12:36 --> UTF-8 Support Enabled
INFO - 2021-01-07 04:12:36 --> Utf8 Class Initialized
INFO - 2021-01-07 04:12:36 --> URI Class Initialized
INFO - 2021-01-07 04:12:36 --> Router Class Initialized
INFO - 2021-01-07 04:12:36 --> Output Class Initialized
INFO - 2021-01-07 04:12:36 --> Security Class Initialized
DEBUG - 2021-01-07 04:12:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 04:12:36 --> Input Class Initialized
INFO - 2021-01-07 04:12:36 --> Language Class Initialized
INFO - 2021-01-07 04:12:36 --> Language Class Initialized
INFO - 2021-01-07 04:12:36 --> Config Class Initialized
INFO - 2021-01-07 04:12:36 --> Loader Class Initialized
INFO - 2021-01-07 04:12:36 --> Helper loaded: url_helper
INFO - 2021-01-07 04:12:36 --> Helper loaded: file_helper
INFO - 2021-01-07 04:12:36 --> Helper loaded: form_helper
INFO - 2021-01-07 04:12:37 --> Helper loaded: my_helper
INFO - 2021-01-07 04:12:37 --> Database Driver Class Initialized
DEBUG - 2021-01-07 04:12:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 04:12:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 04:12:37 --> Controller Class Initialized
DEBUG - 2021-01-07 04:12:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 04:12:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 04:12:37 --> Final output sent to browser
DEBUG - 2021-01-07 04:12:37 --> Total execution time: 0.4024
INFO - 2021-01-07 04:12:43 --> Config Class Initialized
INFO - 2021-01-07 04:12:43 --> Hooks Class Initialized
DEBUG - 2021-01-07 04:12:43 --> UTF-8 Support Enabled
INFO - 2021-01-07 04:12:43 --> Utf8 Class Initialized
INFO - 2021-01-07 04:12:43 --> URI Class Initialized
INFO - 2021-01-07 04:12:43 --> Router Class Initialized
INFO - 2021-01-07 04:12:43 --> Output Class Initialized
INFO - 2021-01-07 04:12:43 --> Security Class Initialized
DEBUG - 2021-01-07 04:12:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 04:12:43 --> Input Class Initialized
INFO - 2021-01-07 04:12:43 --> Language Class Initialized
INFO - 2021-01-07 04:12:43 --> Language Class Initialized
INFO - 2021-01-07 04:12:43 --> Config Class Initialized
INFO - 2021-01-07 04:12:43 --> Loader Class Initialized
INFO - 2021-01-07 04:12:43 --> Helper loaded: url_helper
INFO - 2021-01-07 04:12:43 --> Helper loaded: file_helper
INFO - 2021-01-07 04:12:43 --> Helper loaded: form_helper
INFO - 2021-01-07 04:12:44 --> Helper loaded: my_helper
INFO - 2021-01-07 04:12:44 --> Database Driver Class Initialized
DEBUG - 2021-01-07 04:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 04:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 04:12:44 --> Controller Class Initialized
INFO - 2021-01-07 04:12:44 --> Helper loaded: cookie_helper
INFO - 2021-01-07 04:12:44 --> Final output sent to browser
DEBUG - 2021-01-07 04:12:44 --> Total execution time: 0.4418
INFO - 2021-01-07 04:12:44 --> Config Class Initialized
INFO - 2021-01-07 04:12:44 --> Hooks Class Initialized
DEBUG - 2021-01-07 04:12:44 --> UTF-8 Support Enabled
INFO - 2021-01-07 04:12:44 --> Utf8 Class Initialized
INFO - 2021-01-07 04:12:44 --> URI Class Initialized
INFO - 2021-01-07 04:12:44 --> Router Class Initialized
INFO - 2021-01-07 04:12:44 --> Output Class Initialized
INFO - 2021-01-07 04:12:44 --> Security Class Initialized
DEBUG - 2021-01-07 04:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 04:12:44 --> Input Class Initialized
INFO - 2021-01-07 04:12:44 --> Language Class Initialized
INFO - 2021-01-07 04:12:44 --> Language Class Initialized
INFO - 2021-01-07 04:12:44 --> Config Class Initialized
INFO - 2021-01-07 04:12:44 --> Loader Class Initialized
INFO - 2021-01-07 04:12:44 --> Helper loaded: url_helper
INFO - 2021-01-07 04:12:44 --> Helper loaded: file_helper
INFO - 2021-01-07 04:12:44 --> Helper loaded: form_helper
INFO - 2021-01-07 04:12:44 --> Helper loaded: my_helper
INFO - 2021-01-07 04:12:44 --> Database Driver Class Initialized
DEBUG - 2021-01-07 04:12:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 04:12:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 04:12:45 --> Controller Class Initialized
DEBUG - 2021-01-07 04:12:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 04:12:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 04:12:45 --> Final output sent to browser
DEBUG - 2021-01-07 04:12:45 --> Total execution time: 0.4721
INFO - 2021-01-07 04:12:47 --> Config Class Initialized
INFO - 2021-01-07 04:12:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 04:12:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 04:12:47 --> Utf8 Class Initialized
INFO - 2021-01-07 04:12:47 --> URI Class Initialized
INFO - 2021-01-07 04:12:47 --> Router Class Initialized
INFO - 2021-01-07 04:12:47 --> Output Class Initialized
INFO - 2021-01-07 04:12:47 --> Security Class Initialized
DEBUG - 2021-01-07 04:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 04:12:47 --> Input Class Initialized
INFO - 2021-01-07 04:12:47 --> Language Class Initialized
INFO - 2021-01-07 04:12:47 --> Language Class Initialized
INFO - 2021-01-07 04:12:47 --> Config Class Initialized
INFO - 2021-01-07 04:12:47 --> Loader Class Initialized
INFO - 2021-01-07 04:12:47 --> Helper loaded: url_helper
INFO - 2021-01-07 04:12:47 --> Helper loaded: file_helper
INFO - 2021-01-07 04:12:47 --> Helper loaded: form_helper
INFO - 2021-01-07 04:12:47 --> Helper loaded: my_helper
INFO - 2021-01-07 04:12:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 04:12:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 04:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 04:12:47 --> Controller Class Initialized
DEBUG - 2021-01-07 04:12:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-07 04:12:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 04:12:47 --> Final output sent to browser
DEBUG - 2021-01-07 04:12:47 --> Total execution time: 0.4349
INFO - 2021-01-07 04:12:50 --> Config Class Initialized
INFO - 2021-01-07 04:12:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 04:12:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 04:12:50 --> Utf8 Class Initialized
INFO - 2021-01-07 04:12:50 --> URI Class Initialized
INFO - 2021-01-07 04:12:50 --> Router Class Initialized
INFO - 2021-01-07 04:12:50 --> Output Class Initialized
INFO - 2021-01-07 04:12:50 --> Security Class Initialized
DEBUG - 2021-01-07 04:12:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 04:12:50 --> Input Class Initialized
INFO - 2021-01-07 04:12:50 --> Language Class Initialized
INFO - 2021-01-07 04:12:50 --> Language Class Initialized
INFO - 2021-01-07 04:12:50 --> Config Class Initialized
INFO - 2021-01-07 04:12:50 --> Loader Class Initialized
INFO - 2021-01-07 04:12:50 --> Helper loaded: url_helper
INFO - 2021-01-07 04:12:50 --> Helper loaded: file_helper
INFO - 2021-01-07 04:12:50 --> Helper loaded: form_helper
INFO - 2021-01-07 04:12:50 --> Helper loaded: my_helper
INFO - 2021-01-07 04:12:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 04:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 04:12:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 04:12:50 --> Controller Class Initialized
DEBUG - 2021-01-07 04:12:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak.php
INFO - 2021-01-07 04:12:50 --> Final output sent to browser
DEBUG - 2021-01-07 04:12:50 --> Total execution time: 0.3874
INFO - 2021-01-07 04:59:39 --> Config Class Initialized
INFO - 2021-01-07 04:59:39 --> Hooks Class Initialized
DEBUG - 2021-01-07 04:59:39 --> UTF-8 Support Enabled
INFO - 2021-01-07 04:59:39 --> Utf8 Class Initialized
INFO - 2021-01-07 04:59:39 --> URI Class Initialized
INFO - 2021-01-07 04:59:39 --> Router Class Initialized
INFO - 2021-01-07 04:59:39 --> Output Class Initialized
INFO - 2021-01-07 04:59:39 --> Security Class Initialized
DEBUG - 2021-01-07 04:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 04:59:39 --> Input Class Initialized
INFO - 2021-01-07 04:59:39 --> Language Class Initialized
ERROR - 2021-01-07 04:59:39 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:01:08 --> Config Class Initialized
INFO - 2021-01-07 05:01:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:01:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:01:08 --> Utf8 Class Initialized
INFO - 2021-01-07 05:01:08 --> URI Class Initialized
INFO - 2021-01-07 05:01:08 --> Router Class Initialized
INFO - 2021-01-07 05:01:08 --> Output Class Initialized
INFO - 2021-01-07 05:01:08 --> Security Class Initialized
DEBUG - 2021-01-07 05:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:01:08 --> Input Class Initialized
INFO - 2021-01-07 05:01:08 --> Language Class Initialized
ERROR - 2021-01-07 05:01:08 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:01:19 --> Config Class Initialized
INFO - 2021-01-07 05:01:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:01:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:01:19 --> Utf8 Class Initialized
INFO - 2021-01-07 05:01:19 --> URI Class Initialized
INFO - 2021-01-07 05:01:19 --> Router Class Initialized
INFO - 2021-01-07 05:01:19 --> Output Class Initialized
INFO - 2021-01-07 05:01:19 --> Security Class Initialized
DEBUG - 2021-01-07 05:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:01:19 --> Input Class Initialized
INFO - 2021-01-07 05:01:19 --> Language Class Initialized
ERROR - 2021-01-07 05:01:19 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:01:20 --> Config Class Initialized
INFO - 2021-01-07 05:01:20 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:01:20 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:01:20 --> Utf8 Class Initialized
INFO - 2021-01-07 05:01:20 --> URI Class Initialized
INFO - 2021-01-07 05:01:20 --> Router Class Initialized
INFO - 2021-01-07 05:01:20 --> Output Class Initialized
INFO - 2021-01-07 05:01:20 --> Security Class Initialized
DEBUG - 2021-01-07 05:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:01:20 --> Input Class Initialized
INFO - 2021-01-07 05:01:20 --> Language Class Initialized
ERROR - 2021-01-07 05:01:20 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:04:48 --> Config Class Initialized
INFO - 2021-01-07 05:04:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:04:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:04:48 --> Utf8 Class Initialized
INFO - 2021-01-07 05:04:48 --> URI Class Initialized
INFO - 2021-01-07 05:04:48 --> Router Class Initialized
INFO - 2021-01-07 05:04:48 --> Output Class Initialized
INFO - 2021-01-07 05:04:48 --> Security Class Initialized
DEBUG - 2021-01-07 05:04:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:04:48 --> Input Class Initialized
INFO - 2021-01-07 05:04:48 --> Language Class Initialized
INFO - 2021-01-07 05:04:48 --> Language Class Initialized
INFO - 2021-01-07 05:04:48 --> Config Class Initialized
INFO - 2021-01-07 05:04:48 --> Loader Class Initialized
INFO - 2021-01-07 05:04:48 --> Helper loaded: url_helper
INFO - 2021-01-07 05:04:48 --> Helper loaded: file_helper
INFO - 2021-01-07 05:04:48 --> Helper loaded: form_helper
INFO - 2021-01-07 05:04:48 --> Helper loaded: my_helper
INFO - 2021-01-07 05:04:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 05:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 05:04:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 05:04:48 --> Controller Class Initialized
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined offset: 85 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 294
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 295
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined offset: 81 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 294
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 295
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined offset: 90 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:48 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 294
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 295
ERROR - 2021-01-07 05:04:48 --> Severity: Notice --> Undefined offset: 80 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:49 --> Severity: Warning --> Invalid argument supplied for foreach() C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 278
ERROR - 2021-01-07 05:04:49 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 294
ERROR - 2021-01-07 05:04:49 --> Severity: Notice --> Undefined variable: _nilai_akhir C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 295
DEBUG - 2021-01-07 05:04:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 05:04:49 --> Final output sent to browser
DEBUG - 2021-01-07 05:04:49 --> Total execution time: 0.6188
INFO - 2021-01-07 05:25:23 --> Config Class Initialized
INFO - 2021-01-07 05:25:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:25:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:25:23 --> Utf8 Class Initialized
INFO - 2021-01-07 05:25:23 --> URI Class Initialized
INFO - 2021-01-07 05:25:23 --> Router Class Initialized
INFO - 2021-01-07 05:25:23 --> Output Class Initialized
INFO - 2021-01-07 05:25:23 --> Security Class Initialized
DEBUG - 2021-01-07 05:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:25:23 --> Input Class Initialized
INFO - 2021-01-07 05:25:23 --> Language Class Initialized
ERROR - 2021-01-07 05:25:23 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:25:40 --> Config Class Initialized
INFO - 2021-01-07 05:25:40 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:25:40 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:25:40 --> Utf8 Class Initialized
INFO - 2021-01-07 05:25:40 --> URI Class Initialized
INFO - 2021-01-07 05:25:40 --> Router Class Initialized
INFO - 2021-01-07 05:25:40 --> Output Class Initialized
INFO - 2021-01-07 05:25:40 --> Security Class Initialized
DEBUG - 2021-01-07 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:25:40 --> Input Class Initialized
INFO - 2021-01-07 05:25:40 --> Language Class Initialized
ERROR - 2021-01-07 05:25:40 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:25:49 --> Config Class Initialized
INFO - 2021-01-07 05:25:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:25:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:25:49 --> Utf8 Class Initialized
INFO - 2021-01-07 05:25:49 --> URI Class Initialized
INFO - 2021-01-07 05:25:49 --> Router Class Initialized
INFO - 2021-01-07 05:25:49 --> Output Class Initialized
INFO - 2021-01-07 05:25:49 --> Security Class Initialized
DEBUG - 2021-01-07 05:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:25:49 --> Input Class Initialized
INFO - 2021-01-07 05:25:49 --> Language Class Initialized
ERROR - 2021-01-07 05:25:49 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:29:28 --> Config Class Initialized
INFO - 2021-01-07 05:29:28 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:29:28 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:29:28 --> Utf8 Class Initialized
INFO - 2021-01-07 05:29:28 --> URI Class Initialized
INFO - 2021-01-07 05:29:28 --> Router Class Initialized
INFO - 2021-01-07 05:29:28 --> Output Class Initialized
INFO - 2021-01-07 05:29:28 --> Security Class Initialized
DEBUG - 2021-01-07 05:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:29:28 --> Input Class Initialized
INFO - 2021-01-07 05:29:28 --> Language Class Initialized
INFO - 2021-01-07 05:29:28 --> Language Class Initialized
INFO - 2021-01-07 05:29:28 --> Config Class Initialized
INFO - 2021-01-07 05:29:28 --> Loader Class Initialized
INFO - 2021-01-07 05:29:28 --> Helper loaded: url_helper
INFO - 2021-01-07 05:29:28 --> Helper loaded: file_helper
INFO - 2021-01-07 05:29:28 --> Helper loaded: form_helper
INFO - 2021-01-07 05:29:28 --> Helper loaded: my_helper
INFO - 2021-01-07 05:29:29 --> Database Driver Class Initialized
DEBUG - 2021-01-07 05:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 05:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 05:29:29 --> Controller Class Initialized
ERROR - 2021-01-07 05:29:29 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:29:47 --> Config Class Initialized
INFO - 2021-01-07 05:29:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:29:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:29:47 --> Utf8 Class Initialized
INFO - 2021-01-07 05:29:47 --> URI Class Initialized
INFO - 2021-01-07 05:29:47 --> Router Class Initialized
INFO - 2021-01-07 05:29:47 --> Output Class Initialized
INFO - 2021-01-07 05:29:47 --> Security Class Initialized
DEBUG - 2021-01-07 05:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:29:47 --> Input Class Initialized
INFO - 2021-01-07 05:29:47 --> Language Class Initialized
INFO - 2021-01-07 05:29:47 --> Language Class Initialized
INFO - 2021-01-07 05:29:47 --> Config Class Initialized
INFO - 2021-01-07 05:29:47 --> Loader Class Initialized
INFO - 2021-01-07 05:29:47 --> Helper loaded: url_helper
INFO - 2021-01-07 05:29:47 --> Helper loaded: file_helper
INFO - 2021-01-07 05:29:47 --> Helper loaded: form_helper
INFO - 2021-01-07 05:29:47 --> Helper loaded: my_helper
INFO - 2021-01-07 05:29:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 05:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 05:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 05:29:47 --> Controller Class Initialized
ERROR - 2021-01-07 05:29:47 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 05:29:56 --> Config Class Initialized
INFO - 2021-01-07 05:29:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 05:29:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 05:29:56 --> Utf8 Class Initialized
INFO - 2021-01-07 05:29:56 --> URI Class Initialized
INFO - 2021-01-07 05:29:56 --> Router Class Initialized
INFO - 2021-01-07 05:29:56 --> Output Class Initialized
INFO - 2021-01-07 05:29:56 --> Security Class Initialized
DEBUG - 2021-01-07 05:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 05:29:56 --> Input Class Initialized
INFO - 2021-01-07 05:29:56 --> Language Class Initialized
INFO - 2021-01-07 05:29:56 --> Language Class Initialized
INFO - 2021-01-07 05:29:56 --> Config Class Initialized
INFO - 2021-01-07 05:29:56 --> Loader Class Initialized
INFO - 2021-01-07 05:29:56 --> Helper loaded: url_helper
INFO - 2021-01-07 05:29:56 --> Helper loaded: file_helper
INFO - 2021-01-07 05:29:56 --> Helper loaded: form_helper
INFO - 2021-01-07 05:29:56 --> Helper loaded: my_helper
INFO - 2021-01-07 05:29:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 05:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 05:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 05:29:56 --> Controller Class Initialized
ERROR - 2021-01-07 05:29:56 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 07:15:40 --> Config Class Initialized
INFO - 2021-01-07 07:15:40 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:15:40 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:15:40 --> Utf8 Class Initialized
INFO - 2021-01-07 07:15:40 --> URI Class Initialized
INFO - 2021-01-07 07:15:40 --> Router Class Initialized
INFO - 2021-01-07 07:15:40 --> Output Class Initialized
INFO - 2021-01-07 07:15:40 --> Security Class Initialized
DEBUG - 2021-01-07 07:15:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:15:40 --> Input Class Initialized
INFO - 2021-01-07 07:15:40 --> Language Class Initialized
INFO - 2021-01-07 07:15:40 --> Language Class Initialized
INFO - 2021-01-07 07:15:41 --> Config Class Initialized
INFO - 2021-01-07 07:15:41 --> Loader Class Initialized
INFO - 2021-01-07 07:15:41 --> Helper loaded: url_helper
INFO - 2021-01-07 07:15:41 --> Helper loaded: file_helper
INFO - 2021-01-07 07:15:41 --> Helper loaded: form_helper
INFO - 2021-01-07 07:15:41 --> Helper loaded: my_helper
INFO - 2021-01-07 07:15:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:15:41 --> Controller Class Initialized
INFO - 2021-01-07 07:15:41 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:15:41 --> Config Class Initialized
INFO - 2021-01-07 07:15:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:15:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:15:41 --> Utf8 Class Initialized
INFO - 2021-01-07 07:15:41 --> URI Class Initialized
INFO - 2021-01-07 07:15:41 --> Router Class Initialized
INFO - 2021-01-07 07:15:41 --> Output Class Initialized
INFO - 2021-01-07 07:15:41 --> Security Class Initialized
DEBUG - 2021-01-07 07:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:15:41 --> Input Class Initialized
INFO - 2021-01-07 07:15:41 --> Language Class Initialized
INFO - 2021-01-07 07:15:41 --> Language Class Initialized
INFO - 2021-01-07 07:15:41 --> Config Class Initialized
INFO - 2021-01-07 07:15:41 --> Loader Class Initialized
INFO - 2021-01-07 07:15:41 --> Helper loaded: url_helper
INFO - 2021-01-07 07:15:41 --> Helper loaded: file_helper
INFO - 2021-01-07 07:15:41 --> Helper loaded: form_helper
INFO - 2021-01-07 07:15:41 --> Helper loaded: my_helper
INFO - 2021-01-07 07:15:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:15:41 --> Controller Class Initialized
DEBUG - 2021-01-07 07:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 07:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:15:41 --> Final output sent to browser
DEBUG - 2021-01-07 07:15:41 --> Total execution time: 0.3298
INFO - 2021-01-07 07:15:50 --> Config Class Initialized
INFO - 2021-01-07 07:15:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:15:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:15:50 --> Utf8 Class Initialized
INFO - 2021-01-07 07:15:50 --> URI Class Initialized
INFO - 2021-01-07 07:15:50 --> Router Class Initialized
INFO - 2021-01-07 07:15:50 --> Output Class Initialized
INFO - 2021-01-07 07:15:50 --> Security Class Initialized
DEBUG - 2021-01-07 07:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:15:50 --> Input Class Initialized
INFO - 2021-01-07 07:15:50 --> Language Class Initialized
INFO - 2021-01-07 07:15:50 --> Language Class Initialized
INFO - 2021-01-07 07:15:50 --> Config Class Initialized
INFO - 2021-01-07 07:15:50 --> Loader Class Initialized
INFO - 2021-01-07 07:15:50 --> Helper loaded: url_helper
INFO - 2021-01-07 07:15:50 --> Helper loaded: file_helper
INFO - 2021-01-07 07:15:50 --> Helper loaded: form_helper
INFO - 2021-01-07 07:15:50 --> Helper loaded: my_helper
INFO - 2021-01-07 07:15:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:15:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:15:50 --> Controller Class Initialized
INFO - 2021-01-07 07:15:50 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:15:50 --> Final output sent to browser
DEBUG - 2021-01-07 07:15:50 --> Total execution time: 0.4333
INFO - 2021-01-07 07:15:52 --> Config Class Initialized
INFO - 2021-01-07 07:15:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:15:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:15:52 --> Utf8 Class Initialized
INFO - 2021-01-07 07:15:52 --> URI Class Initialized
INFO - 2021-01-07 07:15:52 --> Router Class Initialized
INFO - 2021-01-07 07:15:52 --> Output Class Initialized
INFO - 2021-01-07 07:15:52 --> Security Class Initialized
DEBUG - 2021-01-07 07:15:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:15:52 --> Input Class Initialized
INFO - 2021-01-07 07:15:52 --> Language Class Initialized
INFO - 2021-01-07 07:15:52 --> Language Class Initialized
INFO - 2021-01-07 07:15:52 --> Config Class Initialized
INFO - 2021-01-07 07:15:52 --> Loader Class Initialized
INFO - 2021-01-07 07:15:52 --> Helper loaded: url_helper
INFO - 2021-01-07 07:15:52 --> Helper loaded: file_helper
INFO - 2021-01-07 07:15:52 --> Helper loaded: form_helper
INFO - 2021-01-07 07:15:52 --> Helper loaded: my_helper
INFO - 2021-01-07 07:15:52 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:15:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:15:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:15:52 --> Controller Class Initialized
DEBUG - 2021-01-07 07:15:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 07:15:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:15:52 --> Final output sent to browser
DEBUG - 2021-01-07 07:15:52 --> Total execution time: 0.5072
INFO - 2021-01-07 07:15:54 --> Config Class Initialized
INFO - 2021-01-07 07:15:54 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:15:54 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:15:54 --> Utf8 Class Initialized
INFO - 2021-01-07 07:15:54 --> URI Class Initialized
INFO - 2021-01-07 07:15:54 --> Router Class Initialized
INFO - 2021-01-07 07:15:54 --> Output Class Initialized
INFO - 2021-01-07 07:15:54 --> Security Class Initialized
DEBUG - 2021-01-07 07:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:15:54 --> Input Class Initialized
INFO - 2021-01-07 07:15:54 --> Language Class Initialized
INFO - 2021-01-07 07:15:54 --> Language Class Initialized
INFO - 2021-01-07 07:15:54 --> Config Class Initialized
INFO - 2021-01-07 07:15:54 --> Loader Class Initialized
INFO - 2021-01-07 07:15:54 --> Helper loaded: url_helper
INFO - 2021-01-07 07:15:54 --> Helper loaded: file_helper
INFO - 2021-01-07 07:15:54 --> Helper loaded: form_helper
INFO - 2021-01-07 07:15:54 --> Helper loaded: my_helper
INFO - 2021-01-07 07:15:54 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:15:54 --> Controller Class Initialized
DEBUG - 2021-01-07 07:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:15:54 --> Final output sent to browser
DEBUG - 2021-01-07 07:15:54 --> Total execution time: 0.3630
INFO - 2021-01-07 07:15:55 --> Config Class Initialized
INFO - 2021-01-07 07:15:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:15:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:15:55 --> Utf8 Class Initialized
INFO - 2021-01-07 07:15:55 --> URI Class Initialized
INFO - 2021-01-07 07:15:55 --> Router Class Initialized
INFO - 2021-01-07 07:15:55 --> Output Class Initialized
INFO - 2021-01-07 07:15:55 --> Security Class Initialized
DEBUG - 2021-01-07 07:15:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:15:55 --> Input Class Initialized
INFO - 2021-01-07 07:15:55 --> Language Class Initialized
INFO - 2021-01-07 07:15:55 --> Language Class Initialized
INFO - 2021-01-07 07:15:55 --> Config Class Initialized
INFO - 2021-01-07 07:15:55 --> Loader Class Initialized
INFO - 2021-01-07 07:15:55 --> Helper loaded: url_helper
INFO - 2021-01-07 07:15:55 --> Helper loaded: file_helper
INFO - 2021-01-07 07:15:55 --> Helper loaded: form_helper
INFO - 2021-01-07 07:15:55 --> Helper loaded: my_helper
INFO - 2021-01-07 07:15:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:15:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:15:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:15:56 --> Controller Class Initialized
ERROR - 2021-01-07 07:15:56 --> Query error: Table 'db_nilai.t_mapel_kd' doesn't exist - Invalid query: SELECT * FROM t_mapel_kd 
                                    WHERE id_guru = '15'
                                    AND id_mapel = '95'
                                    AND tingkat = '10'
                                    AND semester = '1'
                                    AND jenis = 'P'
INFO - 2021-01-07 07:15:56 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 07:20:51 --> Config Class Initialized
INFO - 2021-01-07 07:20:51 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:20:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:20:51 --> Utf8 Class Initialized
INFO - 2021-01-07 07:20:51 --> URI Class Initialized
DEBUG - 2021-01-07 07:20:51 --> No URI present. Default controller set.
INFO - 2021-01-07 07:20:51 --> Router Class Initialized
INFO - 2021-01-07 07:20:51 --> Output Class Initialized
INFO - 2021-01-07 07:20:51 --> Security Class Initialized
DEBUG - 2021-01-07 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:20:51 --> Input Class Initialized
INFO - 2021-01-07 07:20:51 --> Language Class Initialized
INFO - 2021-01-07 07:20:51 --> Language Class Initialized
INFO - 2021-01-07 07:20:51 --> Config Class Initialized
INFO - 2021-01-07 07:20:51 --> Loader Class Initialized
INFO - 2021-01-07 07:20:51 --> Helper loaded: url_helper
INFO - 2021-01-07 07:20:51 --> Helper loaded: file_helper
INFO - 2021-01-07 07:20:51 --> Helper loaded: form_helper
INFO - 2021-01-07 07:20:51 --> Helper loaded: my_helper
INFO - 2021-01-07 07:20:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:20:51 --> Controller Class Initialized
INFO - 2021-01-07 07:20:51 --> Config Class Initialized
INFO - 2021-01-07 07:20:51 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:20:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:20:51 --> Utf8 Class Initialized
INFO - 2021-01-07 07:20:51 --> URI Class Initialized
INFO - 2021-01-07 07:20:51 --> Router Class Initialized
INFO - 2021-01-07 07:20:51 --> Output Class Initialized
INFO - 2021-01-07 07:20:51 --> Security Class Initialized
DEBUG - 2021-01-07 07:20:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:20:51 --> Input Class Initialized
INFO - 2021-01-07 07:20:51 --> Language Class Initialized
INFO - 2021-01-07 07:20:51 --> Language Class Initialized
INFO - 2021-01-07 07:20:51 --> Config Class Initialized
INFO - 2021-01-07 07:20:51 --> Loader Class Initialized
INFO - 2021-01-07 07:20:51 --> Helper loaded: url_helper
INFO - 2021-01-07 07:20:51 --> Helper loaded: file_helper
INFO - 2021-01-07 07:20:51 --> Helper loaded: form_helper
INFO - 2021-01-07 07:20:51 --> Helper loaded: my_helper
INFO - 2021-01-07 07:20:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:20:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:20:51 --> Controller Class Initialized
DEBUG - 2021-01-07 07:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 07:20:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:20:51 --> Final output sent to browser
DEBUG - 2021-01-07 07:20:51 --> Total execution time: 0.3528
INFO - 2021-01-07 07:20:58 --> Config Class Initialized
INFO - 2021-01-07 07:20:58 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:20:58 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:20:58 --> Utf8 Class Initialized
INFO - 2021-01-07 07:20:58 --> URI Class Initialized
INFO - 2021-01-07 07:20:58 --> Router Class Initialized
INFO - 2021-01-07 07:20:58 --> Output Class Initialized
INFO - 2021-01-07 07:20:58 --> Security Class Initialized
DEBUG - 2021-01-07 07:20:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:20:58 --> Input Class Initialized
INFO - 2021-01-07 07:20:58 --> Language Class Initialized
INFO - 2021-01-07 07:20:58 --> Language Class Initialized
INFO - 2021-01-07 07:20:58 --> Config Class Initialized
INFO - 2021-01-07 07:20:58 --> Loader Class Initialized
INFO - 2021-01-07 07:20:58 --> Helper loaded: url_helper
INFO - 2021-01-07 07:20:58 --> Helper loaded: file_helper
INFO - 2021-01-07 07:20:58 --> Helper loaded: form_helper
INFO - 2021-01-07 07:20:58 --> Helper loaded: my_helper
INFO - 2021-01-07 07:20:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:20:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:20:58 --> Controller Class Initialized
INFO - 2021-01-07 07:20:58 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:20:58 --> Final output sent to browser
DEBUG - 2021-01-07 07:20:58 --> Total execution time: 0.5089
INFO - 2021-01-07 07:20:59 --> Config Class Initialized
INFO - 2021-01-07 07:20:59 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:20:59 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:20:59 --> Utf8 Class Initialized
INFO - 2021-01-07 07:20:59 --> URI Class Initialized
INFO - 2021-01-07 07:20:59 --> Router Class Initialized
INFO - 2021-01-07 07:20:59 --> Output Class Initialized
INFO - 2021-01-07 07:20:59 --> Security Class Initialized
DEBUG - 2021-01-07 07:20:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:20:59 --> Input Class Initialized
INFO - 2021-01-07 07:20:59 --> Language Class Initialized
INFO - 2021-01-07 07:20:59 --> Language Class Initialized
INFO - 2021-01-07 07:20:59 --> Config Class Initialized
INFO - 2021-01-07 07:20:59 --> Loader Class Initialized
INFO - 2021-01-07 07:20:59 --> Helper loaded: url_helper
INFO - 2021-01-07 07:20:59 --> Helper loaded: file_helper
INFO - 2021-01-07 07:20:59 --> Helper loaded: form_helper
INFO - 2021-01-07 07:20:59 --> Helper loaded: my_helper
INFO - 2021-01-07 07:20:59 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:20:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:20:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:20:59 --> Controller Class Initialized
DEBUG - 2021-01-07 07:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 07:21:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:21:00 --> Final output sent to browser
DEBUG - 2021-01-07 07:21:00 --> Total execution time: 0.5801
INFO - 2021-01-07 07:21:02 --> Config Class Initialized
INFO - 2021-01-07 07:21:02 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:02 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:02 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:02 --> URI Class Initialized
INFO - 2021-01-07 07:21:02 --> Router Class Initialized
INFO - 2021-01-07 07:21:02 --> Output Class Initialized
INFO - 2021-01-07 07:21:02 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:02 --> Input Class Initialized
INFO - 2021-01-07 07:21:02 --> Language Class Initialized
INFO - 2021-01-07 07:21:02 --> Language Class Initialized
INFO - 2021-01-07 07:21:02 --> Config Class Initialized
INFO - 2021-01-07 07:21:02 --> Loader Class Initialized
INFO - 2021-01-07 07:21:02 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:02 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:02 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:02 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:02 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:02 --> Controller Class Initialized
DEBUG - 2021-01-07 07:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:21:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:21:02 --> Final output sent to browser
DEBUG - 2021-01-07 07:21:02 --> Total execution time: 0.3678
INFO - 2021-01-07 07:21:09 --> Config Class Initialized
INFO - 2021-01-07 07:21:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:09 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:09 --> URI Class Initialized
INFO - 2021-01-07 07:21:09 --> Router Class Initialized
INFO - 2021-01-07 07:21:09 --> Output Class Initialized
INFO - 2021-01-07 07:21:09 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:09 --> Input Class Initialized
INFO - 2021-01-07 07:21:09 --> Language Class Initialized
INFO - 2021-01-07 07:21:09 --> Language Class Initialized
INFO - 2021-01-07 07:21:09 --> Config Class Initialized
INFO - 2021-01-07 07:21:09 --> Loader Class Initialized
INFO - 2021-01-07 07:21:09 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:09 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:09 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:09 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:09 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:09 --> Controller Class Initialized
INFO - 2021-01-07 07:21:09 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:21:09 --> Config Class Initialized
INFO - 2021-01-07 07:21:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:09 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:09 --> URI Class Initialized
INFO - 2021-01-07 07:21:10 --> Router Class Initialized
INFO - 2021-01-07 07:21:10 --> Output Class Initialized
INFO - 2021-01-07 07:21:10 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:10 --> Input Class Initialized
INFO - 2021-01-07 07:21:10 --> Language Class Initialized
INFO - 2021-01-07 07:21:10 --> Language Class Initialized
INFO - 2021-01-07 07:21:10 --> Config Class Initialized
INFO - 2021-01-07 07:21:10 --> Loader Class Initialized
INFO - 2021-01-07 07:21:10 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:10 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:10 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:10 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:10 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:10 --> Controller Class Initialized
DEBUG - 2021-01-07 07:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 07:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:21:10 --> Final output sent to browser
DEBUG - 2021-01-07 07:21:10 --> Total execution time: 0.3884
INFO - 2021-01-07 07:21:14 --> Config Class Initialized
INFO - 2021-01-07 07:21:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:14 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:14 --> URI Class Initialized
INFO - 2021-01-07 07:21:14 --> Router Class Initialized
INFO - 2021-01-07 07:21:14 --> Output Class Initialized
INFO - 2021-01-07 07:21:14 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:14 --> Input Class Initialized
INFO - 2021-01-07 07:21:14 --> Language Class Initialized
INFO - 2021-01-07 07:21:14 --> Language Class Initialized
INFO - 2021-01-07 07:21:14 --> Config Class Initialized
INFO - 2021-01-07 07:21:14 --> Loader Class Initialized
INFO - 2021-01-07 07:21:14 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:14 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:14 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:14 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:14 --> Controller Class Initialized
INFO - 2021-01-07 07:21:14 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:21:14 --> Final output sent to browser
DEBUG - 2021-01-07 07:21:14 --> Total execution time: 0.4418
INFO - 2021-01-07 07:21:15 --> Config Class Initialized
INFO - 2021-01-07 07:21:15 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:15 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:15 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:15 --> URI Class Initialized
INFO - 2021-01-07 07:21:15 --> Router Class Initialized
INFO - 2021-01-07 07:21:15 --> Output Class Initialized
INFO - 2021-01-07 07:21:15 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:15 --> Input Class Initialized
INFO - 2021-01-07 07:21:15 --> Language Class Initialized
INFO - 2021-01-07 07:21:15 --> Language Class Initialized
INFO - 2021-01-07 07:21:15 --> Config Class Initialized
INFO - 2021-01-07 07:21:15 --> Loader Class Initialized
INFO - 2021-01-07 07:21:15 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:15 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:15 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:15 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:15 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:15 --> Controller Class Initialized
DEBUG - 2021-01-07 07:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 07:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:21:15 --> Final output sent to browser
DEBUG - 2021-01-07 07:21:15 --> Total execution time: 0.4630
INFO - 2021-01-07 07:21:17 --> Config Class Initialized
INFO - 2021-01-07 07:21:17 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:17 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:17 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:17 --> URI Class Initialized
INFO - 2021-01-07 07:21:17 --> Router Class Initialized
INFO - 2021-01-07 07:21:17 --> Output Class Initialized
INFO - 2021-01-07 07:21:17 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:17 --> Input Class Initialized
INFO - 2021-01-07 07:21:17 --> Language Class Initialized
INFO - 2021-01-07 07:21:17 --> Language Class Initialized
INFO - 2021-01-07 07:21:17 --> Config Class Initialized
INFO - 2021-01-07 07:21:17 --> Loader Class Initialized
INFO - 2021-01-07 07:21:17 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:17 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:17 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:17 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:17 --> Controller Class Initialized
DEBUG - 2021-01-07 07:21:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-07 07:21:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:21:17 --> Final output sent to browser
DEBUG - 2021-01-07 07:21:18 --> Total execution time: 0.4950
INFO - 2021-01-07 07:21:19 --> Config Class Initialized
INFO - 2021-01-07 07:21:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:19 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:19 --> URI Class Initialized
INFO - 2021-01-07 07:21:19 --> Router Class Initialized
INFO - 2021-01-07 07:21:19 --> Output Class Initialized
INFO - 2021-01-07 07:21:19 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:19 --> Input Class Initialized
INFO - 2021-01-07 07:21:19 --> Language Class Initialized
INFO - 2021-01-07 07:21:19 --> Language Class Initialized
INFO - 2021-01-07 07:21:19 --> Config Class Initialized
INFO - 2021-01-07 07:21:19 --> Loader Class Initialized
INFO - 2021-01-07 07:21:19 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:19 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:19 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:19 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:19 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:19 --> Controller Class Initialized
ERROR - 2021-01-07 07:21:19 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 07:21:48 --> Config Class Initialized
INFO - 2021-01-07 07:21:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:21:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:21:48 --> Utf8 Class Initialized
INFO - 2021-01-07 07:21:48 --> URI Class Initialized
INFO - 2021-01-07 07:21:48 --> Router Class Initialized
INFO - 2021-01-07 07:21:48 --> Output Class Initialized
INFO - 2021-01-07 07:21:48 --> Security Class Initialized
DEBUG - 2021-01-07 07:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:21:48 --> Input Class Initialized
INFO - 2021-01-07 07:21:48 --> Language Class Initialized
INFO - 2021-01-07 07:21:48 --> Language Class Initialized
INFO - 2021-01-07 07:21:48 --> Config Class Initialized
INFO - 2021-01-07 07:21:48 --> Loader Class Initialized
INFO - 2021-01-07 07:21:48 --> Helper loaded: url_helper
INFO - 2021-01-07 07:21:48 --> Helper loaded: file_helper
INFO - 2021-01-07 07:21:48 --> Helper loaded: form_helper
INFO - 2021-01-07 07:21:48 --> Helper loaded: my_helper
INFO - 2021-01-07 07:21:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:21:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:21:49 --> Controller Class Initialized
DEBUG - 2021-01-07 07:21:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:21:49 --> Final output sent to browser
DEBUG - 2021-01-07 07:21:49 --> Total execution time: 0.3992
INFO - 2021-01-07 07:22:04 --> Config Class Initialized
INFO - 2021-01-07 07:22:04 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:04 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:04 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:04 --> URI Class Initialized
INFO - 2021-01-07 07:22:04 --> Router Class Initialized
INFO - 2021-01-07 07:22:05 --> Output Class Initialized
INFO - 2021-01-07 07:22:05 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:05 --> Input Class Initialized
INFO - 2021-01-07 07:22:05 --> Language Class Initialized
INFO - 2021-01-07 07:22:05 --> Language Class Initialized
INFO - 2021-01-07 07:22:05 --> Config Class Initialized
INFO - 2021-01-07 07:22:05 --> Loader Class Initialized
INFO - 2021-01-07 07:22:05 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:05 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:05 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:05 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:05 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:05 --> Controller Class Initialized
INFO - 2021-01-07 07:22:05 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:22:05 --> Config Class Initialized
INFO - 2021-01-07 07:22:05 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:05 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:05 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:05 --> URI Class Initialized
INFO - 2021-01-07 07:22:05 --> Router Class Initialized
INFO - 2021-01-07 07:22:05 --> Output Class Initialized
INFO - 2021-01-07 07:22:05 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:05 --> Input Class Initialized
INFO - 2021-01-07 07:22:05 --> Language Class Initialized
INFO - 2021-01-07 07:22:05 --> Language Class Initialized
INFO - 2021-01-07 07:22:05 --> Config Class Initialized
INFO - 2021-01-07 07:22:05 --> Loader Class Initialized
INFO - 2021-01-07 07:22:05 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:05 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:05 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:05 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:05 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:05 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 07:22:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:22:05 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:05 --> Total execution time: 0.4978
INFO - 2021-01-07 07:22:13 --> Config Class Initialized
INFO - 2021-01-07 07:22:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:13 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:13 --> URI Class Initialized
INFO - 2021-01-07 07:22:13 --> Router Class Initialized
INFO - 2021-01-07 07:22:13 --> Output Class Initialized
INFO - 2021-01-07 07:22:13 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:13 --> Input Class Initialized
INFO - 2021-01-07 07:22:13 --> Language Class Initialized
INFO - 2021-01-07 07:22:13 --> Language Class Initialized
INFO - 2021-01-07 07:22:13 --> Config Class Initialized
INFO - 2021-01-07 07:22:13 --> Loader Class Initialized
INFO - 2021-01-07 07:22:13 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:13 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:13 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:13 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:13 --> Controller Class Initialized
INFO - 2021-01-07 07:22:13 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:22:13 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:14 --> Total execution time: 0.4521
INFO - 2021-01-07 07:22:14 --> Config Class Initialized
INFO - 2021-01-07 07:22:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:14 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:14 --> URI Class Initialized
INFO - 2021-01-07 07:22:14 --> Router Class Initialized
INFO - 2021-01-07 07:22:14 --> Output Class Initialized
INFO - 2021-01-07 07:22:14 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:14 --> Input Class Initialized
INFO - 2021-01-07 07:22:14 --> Language Class Initialized
INFO - 2021-01-07 07:22:14 --> Language Class Initialized
INFO - 2021-01-07 07:22:14 --> Config Class Initialized
INFO - 2021-01-07 07:22:14 --> Loader Class Initialized
INFO - 2021-01-07 07:22:14 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:14 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:14 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:14 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:14 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 07:22:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:22:14 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:14 --> Total execution time: 0.4812
INFO - 2021-01-07 07:22:16 --> Config Class Initialized
INFO - 2021-01-07 07:22:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:16 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:16 --> URI Class Initialized
INFO - 2021-01-07 07:22:16 --> Router Class Initialized
INFO - 2021-01-07 07:22:16 --> Output Class Initialized
INFO - 2021-01-07 07:22:16 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:16 --> Input Class Initialized
INFO - 2021-01-07 07:22:16 --> Language Class Initialized
INFO - 2021-01-07 07:22:16 --> Language Class Initialized
INFO - 2021-01-07 07:22:16 --> Config Class Initialized
INFO - 2021-01-07 07:22:16 --> Loader Class Initialized
INFO - 2021-01-07 07:22:16 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:16 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:16 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:16 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:16 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:22:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:22:16 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:16 --> Total execution time: 0.4208
INFO - 2021-01-07 07:22:18 --> Config Class Initialized
INFO - 2021-01-07 07:22:18 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:18 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:18 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:18 --> URI Class Initialized
INFO - 2021-01-07 07:22:18 --> Router Class Initialized
INFO - 2021-01-07 07:22:18 --> Output Class Initialized
INFO - 2021-01-07 07:22:18 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:18 --> Input Class Initialized
INFO - 2021-01-07 07:22:18 --> Language Class Initialized
INFO - 2021-01-07 07:22:18 --> Language Class Initialized
INFO - 2021-01-07 07:22:18 --> Config Class Initialized
INFO - 2021-01-07 07:22:18 --> Loader Class Initialized
INFO - 2021-01-07 07:22:18 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:18 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:18 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:18 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:18 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:18 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:22:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:22:18 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:18 --> Total execution time: 0.3958
INFO - 2021-01-07 07:22:18 --> Config Class Initialized
INFO - 2021-01-07 07:22:18 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:18 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:18 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:18 --> URI Class Initialized
INFO - 2021-01-07 07:22:18 --> Router Class Initialized
INFO - 2021-01-07 07:22:18 --> Output Class Initialized
INFO - 2021-01-07 07:22:18 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:18 --> Input Class Initialized
INFO - 2021-01-07 07:22:18 --> Language Class Initialized
INFO - 2021-01-07 07:22:18 --> Language Class Initialized
INFO - 2021-01-07 07:22:18 --> Config Class Initialized
INFO - 2021-01-07 07:22:18 --> Loader Class Initialized
INFO - 2021-01-07 07:22:18 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:18 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:18 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:18 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:18 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:18 --> Controller Class Initialized
INFO - 2021-01-07 07:22:19 --> Config Class Initialized
INFO - 2021-01-07 07:22:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:19 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:19 --> URI Class Initialized
INFO - 2021-01-07 07:22:19 --> Router Class Initialized
INFO - 2021-01-07 07:22:19 --> Output Class Initialized
INFO - 2021-01-07 07:22:19 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:19 --> Input Class Initialized
INFO - 2021-01-07 07:22:19 --> Language Class Initialized
INFO - 2021-01-07 07:22:19 --> Language Class Initialized
INFO - 2021-01-07 07:22:19 --> Config Class Initialized
INFO - 2021-01-07 07:22:19 --> Loader Class Initialized
INFO - 2021-01-07 07:22:19 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:19 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:19 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:19 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:19 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:19 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 07:22:19 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:19 --> Total execution time: 0.4040
INFO - 2021-01-07 07:22:21 --> Config Class Initialized
INFO - 2021-01-07 07:22:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:21 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:22 --> URI Class Initialized
INFO - 2021-01-07 07:22:22 --> Router Class Initialized
INFO - 2021-01-07 07:22:22 --> Output Class Initialized
INFO - 2021-01-07 07:22:22 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:22 --> Input Class Initialized
INFO - 2021-01-07 07:22:22 --> Language Class Initialized
INFO - 2021-01-07 07:22:22 --> Language Class Initialized
INFO - 2021-01-07 07:22:22 --> Config Class Initialized
INFO - 2021-01-07 07:22:22 --> Loader Class Initialized
INFO - 2021-01-07 07:22:22 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:22 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:22 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:22 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:22 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:22:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:22:22 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:22 --> Total execution time: 0.3959
INFO - 2021-01-07 07:22:23 --> Config Class Initialized
INFO - 2021-01-07 07:22:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:23 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:23 --> URI Class Initialized
INFO - 2021-01-07 07:22:23 --> Router Class Initialized
INFO - 2021-01-07 07:22:23 --> Output Class Initialized
INFO - 2021-01-07 07:22:23 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:23 --> Input Class Initialized
INFO - 2021-01-07 07:22:23 --> Language Class Initialized
INFO - 2021-01-07 07:22:23 --> Language Class Initialized
INFO - 2021-01-07 07:22:23 --> Config Class Initialized
INFO - 2021-01-07 07:22:23 --> Loader Class Initialized
INFO - 2021-01-07 07:22:23 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:23 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:23 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:23 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:23 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 07:22:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:22:23 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:23 --> Total execution time: 0.3521
INFO - 2021-01-07 07:22:24 --> Config Class Initialized
INFO - 2021-01-07 07:22:24 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:22:24 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:22:24 --> Utf8 Class Initialized
INFO - 2021-01-07 07:22:24 --> URI Class Initialized
INFO - 2021-01-07 07:22:24 --> Router Class Initialized
INFO - 2021-01-07 07:22:24 --> Output Class Initialized
INFO - 2021-01-07 07:22:24 --> Security Class Initialized
DEBUG - 2021-01-07 07:22:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:22:24 --> Input Class Initialized
INFO - 2021-01-07 07:22:24 --> Language Class Initialized
INFO - 2021-01-07 07:22:24 --> Language Class Initialized
INFO - 2021-01-07 07:22:24 --> Config Class Initialized
INFO - 2021-01-07 07:22:24 --> Loader Class Initialized
INFO - 2021-01-07 07:22:24 --> Helper loaded: url_helper
INFO - 2021-01-07 07:22:24 --> Helper loaded: file_helper
INFO - 2021-01-07 07:22:24 --> Helper loaded: form_helper
INFO - 2021-01-07 07:22:24 --> Helper loaded: my_helper
INFO - 2021-01-07 07:22:24 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:22:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:22:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:22:24 --> Controller Class Initialized
DEBUG - 2021-01-07 07:22:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 07:22:24 --> Final output sent to browser
DEBUG - 2021-01-07 07:22:24 --> Total execution time: 0.3789
INFO - 2021-01-07 07:24:35 --> Config Class Initialized
INFO - 2021-01-07 07:24:36 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:24:36 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:24:36 --> Utf8 Class Initialized
INFO - 2021-01-07 07:24:36 --> URI Class Initialized
INFO - 2021-01-07 07:24:36 --> Router Class Initialized
INFO - 2021-01-07 07:24:36 --> Output Class Initialized
INFO - 2021-01-07 07:24:36 --> Security Class Initialized
DEBUG - 2021-01-07 07:24:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:24:36 --> Input Class Initialized
INFO - 2021-01-07 07:24:36 --> Language Class Initialized
INFO - 2021-01-07 07:24:36 --> Language Class Initialized
INFO - 2021-01-07 07:24:36 --> Config Class Initialized
INFO - 2021-01-07 07:24:36 --> Loader Class Initialized
INFO - 2021-01-07 07:24:36 --> Helper loaded: url_helper
INFO - 2021-01-07 07:24:36 --> Helper loaded: file_helper
INFO - 2021-01-07 07:24:36 --> Helper loaded: form_helper
INFO - 2021-01-07 07:24:36 --> Helper loaded: my_helper
INFO - 2021-01-07 07:24:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:24:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:24:36 --> Controller Class Initialized
DEBUG - 2021-01-07 07:24:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:24:36 --> Final output sent to browser
DEBUG - 2021-01-07 07:24:36 --> Total execution time: 0.3441
INFO - 2021-01-07 07:26:16 --> Config Class Initialized
INFO - 2021-01-07 07:26:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:26:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:26:16 --> Utf8 Class Initialized
INFO - 2021-01-07 07:26:16 --> URI Class Initialized
INFO - 2021-01-07 07:26:16 --> Router Class Initialized
INFO - 2021-01-07 07:26:16 --> Output Class Initialized
INFO - 2021-01-07 07:26:16 --> Security Class Initialized
DEBUG - 2021-01-07 07:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:26:16 --> Input Class Initialized
INFO - 2021-01-07 07:26:16 --> Language Class Initialized
INFO - 2021-01-07 07:26:16 --> Language Class Initialized
INFO - 2021-01-07 07:26:16 --> Config Class Initialized
INFO - 2021-01-07 07:26:16 --> Loader Class Initialized
INFO - 2021-01-07 07:26:16 --> Helper loaded: url_helper
INFO - 2021-01-07 07:26:16 --> Helper loaded: file_helper
INFO - 2021-01-07 07:26:16 --> Helper loaded: form_helper
INFO - 2021-01-07 07:26:16 --> Helper loaded: my_helper
INFO - 2021-01-07 07:26:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:26:16 --> Controller Class Initialized
DEBUG - 2021-01-07 07:26:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:26:16 --> Final output sent to browser
DEBUG - 2021-01-07 07:26:16 --> Total execution time: 0.3517
INFO - 2021-01-07 07:26:24 --> Config Class Initialized
INFO - 2021-01-07 07:26:24 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:26:24 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:26:24 --> Utf8 Class Initialized
INFO - 2021-01-07 07:26:24 --> URI Class Initialized
INFO - 2021-01-07 07:26:24 --> Router Class Initialized
INFO - 2021-01-07 07:26:24 --> Output Class Initialized
INFO - 2021-01-07 07:26:24 --> Security Class Initialized
DEBUG - 2021-01-07 07:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:26:24 --> Input Class Initialized
INFO - 2021-01-07 07:26:24 --> Language Class Initialized
INFO - 2021-01-07 07:26:24 --> Language Class Initialized
INFO - 2021-01-07 07:26:24 --> Config Class Initialized
INFO - 2021-01-07 07:26:24 --> Loader Class Initialized
INFO - 2021-01-07 07:26:24 --> Helper loaded: url_helper
INFO - 2021-01-07 07:26:24 --> Helper loaded: file_helper
INFO - 2021-01-07 07:26:24 --> Helper loaded: form_helper
INFO - 2021-01-07 07:26:24 --> Helper loaded: my_helper
INFO - 2021-01-07 07:26:24 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:26:24 --> Controller Class Initialized
DEBUG - 2021-01-07 07:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:26:24 --> Final output sent to browser
DEBUG - 2021-01-07 07:26:24 --> Total execution time: 0.4286
INFO - 2021-01-07 07:26:36 --> Config Class Initialized
INFO - 2021-01-07 07:26:36 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:26:36 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:26:36 --> Utf8 Class Initialized
INFO - 2021-01-07 07:26:36 --> URI Class Initialized
INFO - 2021-01-07 07:26:36 --> Router Class Initialized
INFO - 2021-01-07 07:26:36 --> Output Class Initialized
INFO - 2021-01-07 07:26:36 --> Security Class Initialized
DEBUG - 2021-01-07 07:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:26:36 --> Input Class Initialized
INFO - 2021-01-07 07:26:36 --> Language Class Initialized
INFO - 2021-01-07 07:26:36 --> Language Class Initialized
INFO - 2021-01-07 07:26:36 --> Config Class Initialized
INFO - 2021-01-07 07:26:36 --> Loader Class Initialized
INFO - 2021-01-07 07:26:36 --> Helper loaded: url_helper
INFO - 2021-01-07 07:26:36 --> Helper loaded: file_helper
INFO - 2021-01-07 07:26:36 --> Helper loaded: form_helper
INFO - 2021-01-07 07:26:36 --> Helper loaded: my_helper
INFO - 2021-01-07 07:26:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:26:36 --> Controller Class Initialized
DEBUG - 2021-01-07 07:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:26:36 --> Final output sent to browser
DEBUG - 2021-01-07 07:26:36 --> Total execution time: 0.3805
INFO - 2021-01-07 07:26:41 --> Config Class Initialized
INFO - 2021-01-07 07:26:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:26:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:26:41 --> Utf8 Class Initialized
INFO - 2021-01-07 07:26:41 --> URI Class Initialized
INFO - 2021-01-07 07:26:41 --> Router Class Initialized
INFO - 2021-01-07 07:26:41 --> Output Class Initialized
INFO - 2021-01-07 07:26:41 --> Security Class Initialized
DEBUG - 2021-01-07 07:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:26:41 --> Input Class Initialized
INFO - 2021-01-07 07:26:41 --> Language Class Initialized
INFO - 2021-01-07 07:26:41 --> Language Class Initialized
INFO - 2021-01-07 07:26:41 --> Config Class Initialized
INFO - 2021-01-07 07:26:41 --> Loader Class Initialized
INFO - 2021-01-07 07:26:41 --> Helper loaded: url_helper
INFO - 2021-01-07 07:26:41 --> Helper loaded: file_helper
INFO - 2021-01-07 07:26:41 --> Helper loaded: form_helper
INFO - 2021-01-07 07:26:41 --> Helper loaded: my_helper
INFO - 2021-01-07 07:26:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:26:41 --> Controller Class Initialized
DEBUG - 2021-01-07 07:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:26:41 --> Final output sent to browser
DEBUG - 2021-01-07 07:26:41 --> Total execution time: 0.3625
INFO - 2021-01-07 07:28:32 --> Config Class Initialized
INFO - 2021-01-07 07:28:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:28:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:28:32 --> Utf8 Class Initialized
INFO - 2021-01-07 07:28:32 --> URI Class Initialized
INFO - 2021-01-07 07:28:32 --> Router Class Initialized
INFO - 2021-01-07 07:28:32 --> Output Class Initialized
INFO - 2021-01-07 07:28:32 --> Security Class Initialized
DEBUG - 2021-01-07 07:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:28:32 --> Input Class Initialized
INFO - 2021-01-07 07:28:32 --> Language Class Initialized
INFO - 2021-01-07 07:28:32 --> Language Class Initialized
INFO - 2021-01-07 07:28:32 --> Config Class Initialized
INFO - 2021-01-07 07:28:32 --> Loader Class Initialized
INFO - 2021-01-07 07:28:32 --> Helper loaded: url_helper
INFO - 2021-01-07 07:28:32 --> Helper loaded: file_helper
INFO - 2021-01-07 07:28:32 --> Helper loaded: form_helper
INFO - 2021-01-07 07:28:32 --> Helper loaded: my_helper
INFO - 2021-01-07 07:28:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:28:32 --> Controller Class Initialized
DEBUG - 2021-01-07 07:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:28:32 --> Final output sent to browser
DEBUG - 2021-01-07 07:28:32 --> Total execution time: 0.3472
INFO - 2021-01-07 07:29:08 --> Config Class Initialized
INFO - 2021-01-07 07:29:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:09 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:09 --> URI Class Initialized
INFO - 2021-01-07 07:29:09 --> Router Class Initialized
INFO - 2021-01-07 07:29:09 --> Output Class Initialized
INFO - 2021-01-07 07:29:09 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:09 --> Input Class Initialized
INFO - 2021-01-07 07:29:09 --> Language Class Initialized
INFO - 2021-01-07 07:29:09 --> Language Class Initialized
INFO - 2021-01-07 07:29:09 --> Config Class Initialized
INFO - 2021-01-07 07:29:09 --> Loader Class Initialized
INFO - 2021-01-07 07:29:09 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:09 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:09 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:09 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:09 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:09 --> Controller Class Initialized
ERROR - 2021-01-07 07:29:09 --> Severity: Error --> Unsupported operand types C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 292
INFO - 2021-01-07 07:29:16 --> Config Class Initialized
INFO - 2021-01-07 07:29:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:16 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:16 --> URI Class Initialized
INFO - 2021-01-07 07:29:16 --> Router Class Initialized
INFO - 2021-01-07 07:29:16 --> Output Class Initialized
INFO - 2021-01-07 07:29:16 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:16 --> Input Class Initialized
INFO - 2021-01-07 07:29:16 --> Language Class Initialized
INFO - 2021-01-07 07:29:16 --> Language Class Initialized
INFO - 2021-01-07 07:29:16 --> Config Class Initialized
INFO - 2021-01-07 07:29:16 --> Loader Class Initialized
INFO - 2021-01-07 07:29:16 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:16 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:16 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:16 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:16 --> Controller Class Initialized
DEBUG - 2021-01-07 07:29:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:29:16 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:16 --> Total execution time: 0.3494
INFO - 2021-01-07 07:29:29 --> Config Class Initialized
INFO - 2021-01-07 07:29:29 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:29 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:29 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:29 --> URI Class Initialized
INFO - 2021-01-07 07:29:29 --> Router Class Initialized
INFO - 2021-01-07 07:29:29 --> Output Class Initialized
INFO - 2021-01-07 07:29:29 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:29 --> Input Class Initialized
INFO - 2021-01-07 07:29:29 --> Language Class Initialized
INFO - 2021-01-07 07:29:29 --> Language Class Initialized
INFO - 2021-01-07 07:29:29 --> Config Class Initialized
INFO - 2021-01-07 07:29:29 --> Loader Class Initialized
INFO - 2021-01-07 07:29:29 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:29 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:30 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:30 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:30 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:30 --> Controller Class Initialized
DEBUG - 2021-01-07 07:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:29:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:29:30 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:30 --> Total execution time: 0.4324
INFO - 2021-01-07 07:29:31 --> Config Class Initialized
INFO - 2021-01-07 07:29:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:31 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:31 --> URI Class Initialized
INFO - 2021-01-07 07:29:31 --> Router Class Initialized
INFO - 2021-01-07 07:29:31 --> Output Class Initialized
INFO - 2021-01-07 07:29:31 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:31 --> Input Class Initialized
INFO - 2021-01-07 07:29:31 --> Language Class Initialized
INFO - 2021-01-07 07:29:31 --> Language Class Initialized
INFO - 2021-01-07 07:29:31 --> Config Class Initialized
INFO - 2021-01-07 07:29:31 --> Loader Class Initialized
INFO - 2021-01-07 07:29:31 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:31 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:31 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:31 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:31 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:31 --> Controller Class Initialized
DEBUG - 2021-01-07 07:29:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:29:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:29:31 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:31 --> Total execution time: 0.3987
INFO - 2021-01-07 07:29:31 --> Config Class Initialized
INFO - 2021-01-07 07:29:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:31 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:31 --> URI Class Initialized
INFO - 2021-01-07 07:29:31 --> Router Class Initialized
INFO - 2021-01-07 07:29:31 --> Output Class Initialized
INFO - 2021-01-07 07:29:31 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:31 --> Input Class Initialized
INFO - 2021-01-07 07:29:31 --> Language Class Initialized
INFO - 2021-01-07 07:29:31 --> Language Class Initialized
INFO - 2021-01-07 07:29:31 --> Config Class Initialized
INFO - 2021-01-07 07:29:31 --> Loader Class Initialized
INFO - 2021-01-07 07:29:31 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:31 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:31 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:31 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:31 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:31 --> Controller Class Initialized
INFO - 2021-01-07 07:29:34 --> Config Class Initialized
INFO - 2021-01-07 07:29:34 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:34 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:34 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:34 --> URI Class Initialized
INFO - 2021-01-07 07:29:34 --> Router Class Initialized
INFO - 2021-01-07 07:29:34 --> Output Class Initialized
INFO - 2021-01-07 07:29:34 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:34 --> Input Class Initialized
INFO - 2021-01-07 07:29:34 --> Language Class Initialized
INFO - 2021-01-07 07:29:34 --> Language Class Initialized
INFO - 2021-01-07 07:29:34 --> Config Class Initialized
INFO - 2021-01-07 07:29:34 --> Loader Class Initialized
INFO - 2021-01-07 07:29:34 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:34 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:34 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:34 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:34 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:34 --> Controller Class Initialized
INFO - 2021-01-07 07:29:34 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:34 --> Total execution time: 0.3778
INFO - 2021-01-07 07:29:41 --> Config Class Initialized
INFO - 2021-01-07 07:29:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:41 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:41 --> URI Class Initialized
INFO - 2021-01-07 07:29:41 --> Router Class Initialized
INFO - 2021-01-07 07:29:41 --> Output Class Initialized
INFO - 2021-01-07 07:29:41 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:41 --> Input Class Initialized
INFO - 2021-01-07 07:29:41 --> Language Class Initialized
INFO - 2021-01-07 07:29:41 --> Language Class Initialized
INFO - 2021-01-07 07:29:41 --> Config Class Initialized
INFO - 2021-01-07 07:29:41 --> Loader Class Initialized
INFO - 2021-01-07 07:29:41 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:41 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:41 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:41 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:41 --> Controller Class Initialized
INFO - 2021-01-07 07:29:41 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:41 --> Total execution time: 0.4148
INFO - 2021-01-07 07:29:41 --> Config Class Initialized
INFO - 2021-01-07 07:29:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:41 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:41 --> URI Class Initialized
INFO - 2021-01-07 07:29:41 --> Router Class Initialized
INFO - 2021-01-07 07:29:41 --> Output Class Initialized
INFO - 2021-01-07 07:29:41 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:41 --> Input Class Initialized
INFO - 2021-01-07 07:29:41 --> Language Class Initialized
INFO - 2021-01-07 07:29:41 --> Language Class Initialized
INFO - 2021-01-07 07:29:41 --> Config Class Initialized
INFO - 2021-01-07 07:29:41 --> Loader Class Initialized
INFO - 2021-01-07 07:29:41 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:41 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:41 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:41 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:42 --> Controller Class Initialized
INFO - 2021-01-07 07:29:43 --> Config Class Initialized
INFO - 2021-01-07 07:29:43 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:43 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:43 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:43 --> URI Class Initialized
INFO - 2021-01-07 07:29:43 --> Router Class Initialized
INFO - 2021-01-07 07:29:43 --> Output Class Initialized
INFO - 2021-01-07 07:29:43 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:43 --> Input Class Initialized
INFO - 2021-01-07 07:29:43 --> Language Class Initialized
INFO - 2021-01-07 07:29:43 --> Language Class Initialized
INFO - 2021-01-07 07:29:43 --> Config Class Initialized
INFO - 2021-01-07 07:29:43 --> Loader Class Initialized
INFO - 2021-01-07 07:29:43 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:43 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:43 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:43 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:43 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:43 --> Controller Class Initialized
INFO - 2021-01-07 07:29:43 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:43 --> Total execution time: 0.3653
INFO - 2021-01-07 07:29:49 --> Config Class Initialized
INFO - 2021-01-07 07:29:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:49 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:49 --> URI Class Initialized
INFO - 2021-01-07 07:29:49 --> Router Class Initialized
INFO - 2021-01-07 07:29:49 --> Output Class Initialized
INFO - 2021-01-07 07:29:49 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:49 --> Input Class Initialized
INFO - 2021-01-07 07:29:49 --> Language Class Initialized
INFO - 2021-01-07 07:29:49 --> Language Class Initialized
INFO - 2021-01-07 07:29:49 --> Config Class Initialized
INFO - 2021-01-07 07:29:49 --> Loader Class Initialized
INFO - 2021-01-07 07:29:49 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:49 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:49 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:49 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:50 --> Controller Class Initialized
INFO - 2021-01-07 07:29:50 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:50 --> Total execution time: 0.4154
INFO - 2021-01-07 07:29:53 --> Config Class Initialized
INFO - 2021-01-07 07:29:53 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:53 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:53 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:53 --> URI Class Initialized
INFO - 2021-01-07 07:29:53 --> Router Class Initialized
INFO - 2021-01-07 07:29:53 --> Output Class Initialized
INFO - 2021-01-07 07:29:53 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:53 --> Input Class Initialized
INFO - 2021-01-07 07:29:53 --> Language Class Initialized
INFO - 2021-01-07 07:29:53 --> Language Class Initialized
INFO - 2021-01-07 07:29:53 --> Config Class Initialized
INFO - 2021-01-07 07:29:53 --> Loader Class Initialized
INFO - 2021-01-07 07:29:53 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:53 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:53 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:53 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:53 --> Controller Class Initialized
DEBUG - 2021-01-07 07:29:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 07:29:53 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:53 --> Total execution time: 0.3624
INFO - 2021-01-07 07:29:56 --> Config Class Initialized
INFO - 2021-01-07 07:29:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:29:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:29:56 --> Utf8 Class Initialized
INFO - 2021-01-07 07:29:56 --> URI Class Initialized
INFO - 2021-01-07 07:29:56 --> Router Class Initialized
INFO - 2021-01-07 07:29:56 --> Output Class Initialized
INFO - 2021-01-07 07:29:56 --> Security Class Initialized
DEBUG - 2021-01-07 07:29:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:29:56 --> Input Class Initialized
INFO - 2021-01-07 07:29:56 --> Language Class Initialized
INFO - 2021-01-07 07:29:56 --> Language Class Initialized
INFO - 2021-01-07 07:29:56 --> Config Class Initialized
INFO - 2021-01-07 07:29:56 --> Loader Class Initialized
INFO - 2021-01-07 07:29:56 --> Helper loaded: url_helper
INFO - 2021-01-07 07:29:56 --> Helper loaded: file_helper
INFO - 2021-01-07 07:29:56 --> Helper loaded: form_helper
INFO - 2021-01-07 07:29:56 --> Helper loaded: my_helper
INFO - 2021-01-07 07:29:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:29:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:29:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:29:57 --> Controller Class Initialized
DEBUG - 2021-01-07 07:29:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:29:57 --> Final output sent to browser
DEBUG - 2021-01-07 07:29:57 --> Total execution time: 0.3580
INFO - 2021-01-07 07:31:33 --> Config Class Initialized
INFO - 2021-01-07 07:31:33 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:31:33 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:31:33 --> Utf8 Class Initialized
INFO - 2021-01-07 07:31:33 --> URI Class Initialized
INFO - 2021-01-07 07:31:33 --> Router Class Initialized
INFO - 2021-01-07 07:31:33 --> Output Class Initialized
INFO - 2021-01-07 07:31:33 --> Security Class Initialized
DEBUG - 2021-01-07 07:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:31:33 --> Input Class Initialized
INFO - 2021-01-07 07:31:33 --> Language Class Initialized
INFO - 2021-01-07 07:31:33 --> Language Class Initialized
INFO - 2021-01-07 07:31:33 --> Config Class Initialized
INFO - 2021-01-07 07:31:33 --> Loader Class Initialized
INFO - 2021-01-07 07:31:33 --> Helper loaded: url_helper
INFO - 2021-01-07 07:31:33 --> Helper loaded: file_helper
INFO - 2021-01-07 07:31:33 --> Helper loaded: form_helper
INFO - 2021-01-07 07:31:33 --> Helper loaded: my_helper
INFO - 2021-01-07 07:31:33 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:31:33 --> Controller Class Initialized
DEBUG - 2021-01-07 07:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:31:33 --> Final output sent to browser
DEBUG - 2021-01-07 07:31:33 --> Total execution time: 0.3700
INFO - 2021-01-07 07:36:49 --> Config Class Initialized
INFO - 2021-01-07 07:36:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:36:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:36:49 --> Utf8 Class Initialized
INFO - 2021-01-07 07:36:49 --> URI Class Initialized
INFO - 2021-01-07 07:36:49 --> Router Class Initialized
INFO - 2021-01-07 07:36:49 --> Output Class Initialized
INFO - 2021-01-07 07:36:49 --> Security Class Initialized
DEBUG - 2021-01-07 07:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:36:49 --> Input Class Initialized
INFO - 2021-01-07 07:36:49 --> Language Class Initialized
INFO - 2021-01-07 07:36:49 --> Language Class Initialized
INFO - 2021-01-07 07:36:49 --> Config Class Initialized
INFO - 2021-01-07 07:36:49 --> Loader Class Initialized
INFO - 2021-01-07 07:36:49 --> Helper loaded: url_helper
INFO - 2021-01-07 07:36:49 --> Helper loaded: file_helper
INFO - 2021-01-07 07:36:49 --> Helper loaded: form_helper
INFO - 2021-01-07 07:36:49 --> Helper loaded: my_helper
INFO - 2021-01-07 07:36:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:36:49 --> Controller Class Initialized
ERROR - 2021-01-07 07:36:49 --> Query error: Unknown column 'd.nama_kd' in 'field list' - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//',d.nama_kd) nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-07 07:36:49 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 07:37:59 --> Config Class Initialized
INFO - 2021-01-07 07:37:59 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:37:59 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:37:59 --> Utf8 Class Initialized
INFO - 2021-01-07 07:37:59 --> URI Class Initialized
INFO - 2021-01-07 07:37:59 --> Router Class Initialized
INFO - 2021-01-07 07:37:59 --> Output Class Initialized
INFO - 2021-01-07 07:37:59 --> Security Class Initialized
DEBUG - 2021-01-07 07:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:37:59 --> Input Class Initialized
INFO - 2021-01-07 07:37:59 --> Language Class Initialized
INFO - 2021-01-07 07:38:00 --> Language Class Initialized
INFO - 2021-01-07 07:38:00 --> Config Class Initialized
INFO - 2021-01-07 07:38:00 --> Loader Class Initialized
INFO - 2021-01-07 07:38:00 --> Helper loaded: url_helper
INFO - 2021-01-07 07:38:00 --> Helper loaded: file_helper
INFO - 2021-01-07 07:38:00 --> Helper loaded: form_helper
INFO - 2021-01-07 07:38:00 --> Helper loaded: my_helper
INFO - 2021-01-07 07:38:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:38:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:38:00 --> Controller Class Initialized
DEBUG - 2021-01-07 07:38:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:38:00 --> Final output sent to browser
DEBUG - 2021-01-07 07:38:00 --> Total execution time: 0.3731
INFO - 2021-01-07 07:38:35 --> Config Class Initialized
INFO - 2021-01-07 07:38:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:38:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:38:35 --> Utf8 Class Initialized
INFO - 2021-01-07 07:38:35 --> URI Class Initialized
INFO - 2021-01-07 07:38:35 --> Router Class Initialized
INFO - 2021-01-07 07:38:35 --> Output Class Initialized
INFO - 2021-01-07 07:38:35 --> Security Class Initialized
DEBUG - 2021-01-07 07:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:38:35 --> Input Class Initialized
INFO - 2021-01-07 07:38:35 --> Language Class Initialized
INFO - 2021-01-07 07:38:35 --> Language Class Initialized
INFO - 2021-01-07 07:38:35 --> Config Class Initialized
INFO - 2021-01-07 07:38:35 --> Loader Class Initialized
INFO - 2021-01-07 07:38:35 --> Helper loaded: url_helper
INFO - 2021-01-07 07:38:35 --> Helper loaded: file_helper
INFO - 2021-01-07 07:38:35 --> Helper loaded: form_helper
INFO - 2021-01-07 07:38:35 --> Helper loaded: my_helper
INFO - 2021-01-07 07:38:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:38:35 --> Controller Class Initialized
DEBUG - 2021-01-07 07:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:38:35 --> Final output sent to browser
DEBUG - 2021-01-07 07:38:35 --> Total execution time: 0.3460
INFO - 2021-01-07 07:38:36 --> Config Class Initialized
INFO - 2021-01-07 07:38:36 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:38:36 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:38:36 --> Utf8 Class Initialized
INFO - 2021-01-07 07:38:36 --> URI Class Initialized
INFO - 2021-01-07 07:38:36 --> Router Class Initialized
INFO - 2021-01-07 07:38:36 --> Output Class Initialized
INFO - 2021-01-07 07:38:36 --> Security Class Initialized
DEBUG - 2021-01-07 07:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:38:36 --> Input Class Initialized
INFO - 2021-01-07 07:38:36 --> Language Class Initialized
INFO - 2021-01-07 07:38:36 --> Language Class Initialized
INFO - 2021-01-07 07:38:36 --> Config Class Initialized
INFO - 2021-01-07 07:38:36 --> Loader Class Initialized
INFO - 2021-01-07 07:38:36 --> Helper loaded: url_helper
INFO - 2021-01-07 07:38:36 --> Helper loaded: file_helper
INFO - 2021-01-07 07:38:36 --> Helper loaded: form_helper
INFO - 2021-01-07 07:38:36 --> Helper loaded: my_helper
INFO - 2021-01-07 07:38:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:38:36 --> Controller Class Initialized
DEBUG - 2021-01-07 07:38:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:38:36 --> Final output sent to browser
DEBUG - 2021-01-07 07:38:36 --> Total execution time: 0.3329
INFO - 2021-01-07 07:40:09 --> Config Class Initialized
INFO - 2021-01-07 07:40:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:40:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:40:09 --> Utf8 Class Initialized
INFO - 2021-01-07 07:40:09 --> URI Class Initialized
INFO - 2021-01-07 07:40:09 --> Router Class Initialized
INFO - 2021-01-07 07:40:09 --> Output Class Initialized
INFO - 2021-01-07 07:40:09 --> Security Class Initialized
DEBUG - 2021-01-07 07:40:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:40:09 --> Input Class Initialized
INFO - 2021-01-07 07:40:09 --> Language Class Initialized
INFO - 2021-01-07 07:40:09 --> Language Class Initialized
INFO - 2021-01-07 07:40:09 --> Config Class Initialized
INFO - 2021-01-07 07:40:10 --> Loader Class Initialized
INFO - 2021-01-07 07:40:10 --> Helper loaded: url_helper
INFO - 2021-01-07 07:40:10 --> Helper loaded: file_helper
INFO - 2021-01-07 07:40:10 --> Helper loaded: form_helper
INFO - 2021-01-07 07:40:10 --> Helper loaded: my_helper
INFO - 2021-01-07 07:40:10 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:40:10 --> Controller Class Initialized
ERROR - 2021-01-07 07:40:10 --> Query error: Unknown column 'b.id_mapel' in 'field list' - Invalid query: SELECT 
                                    b.id_mapel, c.kd_singkat
                                    FROM t_nilai_ket a
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    WHERE a.id_siswa = 1418 AND a.tasm = '20201'
                                    GROUP BY b.id_mapel
INFO - 2021-01-07 07:40:10 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 07:41:55 --> Config Class Initialized
INFO - 2021-01-07 07:41:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:41:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:41:55 --> Utf8 Class Initialized
INFO - 2021-01-07 07:41:55 --> URI Class Initialized
INFO - 2021-01-07 07:41:55 --> Router Class Initialized
INFO - 2021-01-07 07:41:55 --> Output Class Initialized
INFO - 2021-01-07 07:41:55 --> Security Class Initialized
DEBUG - 2021-01-07 07:41:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:41:55 --> Input Class Initialized
INFO - 2021-01-07 07:41:55 --> Language Class Initialized
INFO - 2021-01-07 07:41:55 --> Language Class Initialized
INFO - 2021-01-07 07:41:55 --> Config Class Initialized
INFO - 2021-01-07 07:41:55 --> Loader Class Initialized
INFO - 2021-01-07 07:41:55 --> Helper loaded: url_helper
INFO - 2021-01-07 07:41:55 --> Helper loaded: file_helper
INFO - 2021-01-07 07:41:55 --> Helper loaded: form_helper
INFO - 2021-01-07 07:41:55 --> Helper loaded: my_helper
INFO - 2021-01-07 07:41:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:41:55 --> Controller Class Initialized
ERROR - 2021-01-07 07:41:55 --> Query error: Unknown column 'c.id' in 'field list' - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, CONCAT(a.nilai,'//',d.nama_kd) nilai
                                    FROM t_nilai_ket a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-07 07:41:55 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 07:42:31 --> Config Class Initialized
INFO - 2021-01-07 07:42:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:42:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:42:31 --> Utf8 Class Initialized
INFO - 2021-01-07 07:42:31 --> URI Class Initialized
INFO - 2021-01-07 07:42:31 --> Router Class Initialized
INFO - 2021-01-07 07:42:31 --> Output Class Initialized
INFO - 2021-01-07 07:42:31 --> Security Class Initialized
DEBUG - 2021-01-07 07:42:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:42:31 --> Input Class Initialized
INFO - 2021-01-07 07:42:31 --> Language Class Initialized
INFO - 2021-01-07 07:42:31 --> Language Class Initialized
INFO - 2021-01-07 07:42:31 --> Config Class Initialized
INFO - 2021-01-07 07:42:31 --> Loader Class Initialized
INFO - 2021-01-07 07:42:31 --> Helper loaded: url_helper
INFO - 2021-01-07 07:42:31 --> Helper loaded: file_helper
INFO - 2021-01-07 07:42:31 --> Helper loaded: form_helper
INFO - 2021-01-07 07:42:31 --> Helper loaded: my_helper
INFO - 2021-01-07 07:42:31 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:42:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:42:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:42:31 --> Controller Class Initialized
DEBUG - 2021-01-07 07:42:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:42:31 --> Final output sent to browser
DEBUG - 2021-01-07 07:42:31 --> Total execution time: 0.3610
INFO - 2021-01-07 07:46:19 --> Config Class Initialized
INFO - 2021-01-07 07:46:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:46:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:46:19 --> Utf8 Class Initialized
INFO - 2021-01-07 07:46:19 --> URI Class Initialized
INFO - 2021-01-07 07:46:19 --> Router Class Initialized
INFO - 2021-01-07 07:46:19 --> Output Class Initialized
INFO - 2021-01-07 07:46:19 --> Security Class Initialized
DEBUG - 2021-01-07 07:46:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:46:19 --> Input Class Initialized
INFO - 2021-01-07 07:46:19 --> Language Class Initialized
INFO - 2021-01-07 07:46:19 --> Language Class Initialized
INFO - 2021-01-07 07:46:19 --> Config Class Initialized
INFO - 2021-01-07 07:46:19 --> Loader Class Initialized
INFO - 2021-01-07 07:46:19 --> Helper loaded: url_helper
INFO - 2021-01-07 07:46:19 --> Helper loaded: file_helper
INFO - 2021-01-07 07:46:19 --> Helper loaded: form_helper
INFO - 2021-01-07 07:46:19 --> Helper loaded: my_helper
INFO - 2021-01-07 07:46:19 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:46:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:46:19 --> Controller Class Initialized
DEBUG - 2021-01-07 07:46:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:46:19 --> Final output sent to browser
DEBUG - 2021-01-07 07:46:19 --> Total execution time: 0.3369
INFO - 2021-01-07 07:47:08 --> Config Class Initialized
INFO - 2021-01-07 07:47:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:47:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:47:08 --> Utf8 Class Initialized
INFO - 2021-01-07 07:47:08 --> URI Class Initialized
INFO - 2021-01-07 07:47:08 --> Router Class Initialized
INFO - 2021-01-07 07:47:08 --> Output Class Initialized
INFO - 2021-01-07 07:47:08 --> Security Class Initialized
DEBUG - 2021-01-07 07:47:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:47:08 --> Input Class Initialized
INFO - 2021-01-07 07:47:08 --> Language Class Initialized
INFO - 2021-01-07 07:47:08 --> Language Class Initialized
INFO - 2021-01-07 07:47:08 --> Config Class Initialized
INFO - 2021-01-07 07:47:08 --> Loader Class Initialized
INFO - 2021-01-07 07:47:08 --> Helper loaded: url_helper
INFO - 2021-01-07 07:47:08 --> Helper loaded: file_helper
INFO - 2021-01-07 07:47:08 --> Helper loaded: form_helper
INFO - 2021-01-07 07:47:08 --> Helper loaded: my_helper
INFO - 2021-01-07 07:47:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:47:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:47:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:47:09 --> Controller Class Initialized
DEBUG - 2021-01-07 07:47:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:47:09 --> Final output sent to browser
DEBUG - 2021-01-07 07:47:09 --> Total execution time: 0.3710
INFO - 2021-01-07 07:48:04 --> Config Class Initialized
INFO - 2021-01-07 07:48:04 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:48:04 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:48:04 --> Utf8 Class Initialized
INFO - 2021-01-07 07:48:04 --> URI Class Initialized
INFO - 2021-01-07 07:48:04 --> Router Class Initialized
INFO - 2021-01-07 07:48:04 --> Output Class Initialized
INFO - 2021-01-07 07:48:04 --> Security Class Initialized
DEBUG - 2021-01-07 07:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:48:04 --> Input Class Initialized
INFO - 2021-01-07 07:48:04 --> Language Class Initialized
INFO - 2021-01-07 07:48:04 --> Language Class Initialized
INFO - 2021-01-07 07:48:04 --> Config Class Initialized
INFO - 2021-01-07 07:48:04 --> Loader Class Initialized
INFO - 2021-01-07 07:48:04 --> Helper loaded: url_helper
INFO - 2021-01-07 07:48:04 --> Helper loaded: file_helper
INFO - 2021-01-07 07:48:04 --> Helper loaded: form_helper
INFO - 2021-01-07 07:48:04 --> Helper loaded: my_helper
INFO - 2021-01-07 07:48:04 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:48:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:48:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:48:05 --> Controller Class Initialized
DEBUG - 2021-01-07 07:48:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:48:05 --> Final output sent to browser
DEBUG - 2021-01-07 07:48:05 --> Total execution time: 0.3466
INFO - 2021-01-07 07:48:18 --> Config Class Initialized
INFO - 2021-01-07 07:48:18 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:48:18 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:48:18 --> Utf8 Class Initialized
INFO - 2021-01-07 07:48:18 --> URI Class Initialized
INFO - 2021-01-07 07:48:18 --> Router Class Initialized
INFO - 2021-01-07 07:48:18 --> Output Class Initialized
INFO - 2021-01-07 07:48:18 --> Security Class Initialized
DEBUG - 2021-01-07 07:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:48:18 --> Input Class Initialized
INFO - 2021-01-07 07:48:18 --> Language Class Initialized
INFO - 2021-01-07 07:48:19 --> Language Class Initialized
INFO - 2021-01-07 07:48:19 --> Config Class Initialized
INFO - 2021-01-07 07:48:19 --> Loader Class Initialized
INFO - 2021-01-07 07:48:19 --> Helper loaded: url_helper
INFO - 2021-01-07 07:48:19 --> Helper loaded: file_helper
INFO - 2021-01-07 07:48:19 --> Helper loaded: form_helper
INFO - 2021-01-07 07:48:19 --> Helper loaded: my_helper
INFO - 2021-01-07 07:48:19 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:48:19 --> Controller Class Initialized
DEBUG - 2021-01-07 07:48:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:48:19 --> Final output sent to browser
DEBUG - 2021-01-07 07:48:19 --> Total execution time: 0.3707
INFO - 2021-01-07 07:48:55 --> Config Class Initialized
INFO - 2021-01-07 07:48:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:48:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:48:55 --> Utf8 Class Initialized
INFO - 2021-01-07 07:48:55 --> URI Class Initialized
INFO - 2021-01-07 07:48:55 --> Router Class Initialized
INFO - 2021-01-07 07:48:55 --> Output Class Initialized
INFO - 2021-01-07 07:48:55 --> Security Class Initialized
DEBUG - 2021-01-07 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:48:55 --> Input Class Initialized
INFO - 2021-01-07 07:48:55 --> Language Class Initialized
INFO - 2021-01-07 07:48:55 --> Language Class Initialized
INFO - 2021-01-07 07:48:55 --> Config Class Initialized
INFO - 2021-01-07 07:48:55 --> Loader Class Initialized
INFO - 2021-01-07 07:48:55 --> Helper loaded: url_helper
INFO - 2021-01-07 07:48:55 --> Helper loaded: file_helper
INFO - 2021-01-07 07:48:55 --> Helper loaded: form_helper
INFO - 2021-01-07 07:48:55 --> Helper loaded: my_helper
INFO - 2021-01-07 07:48:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:48:55 --> Controller Class Initialized
INFO - 2021-01-07 07:48:55 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:48:55 --> Config Class Initialized
INFO - 2021-01-07 07:48:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:48:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:48:55 --> Utf8 Class Initialized
INFO - 2021-01-07 07:48:55 --> URI Class Initialized
INFO - 2021-01-07 07:48:55 --> Router Class Initialized
INFO - 2021-01-07 07:48:55 --> Output Class Initialized
INFO - 2021-01-07 07:48:55 --> Security Class Initialized
DEBUG - 2021-01-07 07:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:48:55 --> Input Class Initialized
INFO - 2021-01-07 07:48:55 --> Language Class Initialized
INFO - 2021-01-07 07:48:55 --> Language Class Initialized
INFO - 2021-01-07 07:48:55 --> Config Class Initialized
INFO - 2021-01-07 07:48:55 --> Loader Class Initialized
INFO - 2021-01-07 07:48:55 --> Helper loaded: url_helper
INFO - 2021-01-07 07:48:55 --> Helper loaded: file_helper
INFO - 2021-01-07 07:48:55 --> Helper loaded: form_helper
INFO - 2021-01-07 07:48:55 --> Helper loaded: my_helper
INFO - 2021-01-07 07:48:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:48:55 --> Controller Class Initialized
DEBUG - 2021-01-07 07:48:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 07:48:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:48:55 --> Final output sent to browser
DEBUG - 2021-01-07 07:48:55 --> Total execution time: 0.3661
INFO - 2021-01-07 07:49:00 --> Config Class Initialized
INFO - 2021-01-07 07:49:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:00 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:00 --> URI Class Initialized
INFO - 2021-01-07 07:49:00 --> Router Class Initialized
INFO - 2021-01-07 07:49:00 --> Output Class Initialized
INFO - 2021-01-07 07:49:00 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:00 --> Input Class Initialized
INFO - 2021-01-07 07:49:00 --> Language Class Initialized
INFO - 2021-01-07 07:49:00 --> Language Class Initialized
INFO - 2021-01-07 07:49:00 --> Config Class Initialized
INFO - 2021-01-07 07:49:00 --> Loader Class Initialized
INFO - 2021-01-07 07:49:00 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:00 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:00 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:00 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:00 --> Controller Class Initialized
INFO - 2021-01-07 07:49:00 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:49:00 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:00 --> Total execution time: 0.4635
INFO - 2021-01-07 07:49:00 --> Config Class Initialized
INFO - 2021-01-07 07:49:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:01 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:01 --> URI Class Initialized
INFO - 2021-01-07 07:49:01 --> Router Class Initialized
INFO - 2021-01-07 07:49:01 --> Output Class Initialized
INFO - 2021-01-07 07:49:01 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:01 --> Input Class Initialized
INFO - 2021-01-07 07:49:01 --> Language Class Initialized
INFO - 2021-01-07 07:49:01 --> Language Class Initialized
INFO - 2021-01-07 07:49:01 --> Config Class Initialized
INFO - 2021-01-07 07:49:01 --> Loader Class Initialized
INFO - 2021-01-07 07:49:01 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:01 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:01 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:01 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:01 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 07:49:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:01 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:01 --> Total execution time: 0.5382
INFO - 2021-01-07 07:49:03 --> Config Class Initialized
INFO - 2021-01-07 07:49:03 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:03 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:03 --> URI Class Initialized
INFO - 2021-01-07 07:49:03 --> Router Class Initialized
INFO - 2021-01-07 07:49:03 --> Output Class Initialized
INFO - 2021-01-07 07:49:03 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:03 --> Input Class Initialized
INFO - 2021-01-07 07:49:03 --> Language Class Initialized
INFO - 2021-01-07 07:49:03 --> Language Class Initialized
INFO - 2021-01-07 07:49:03 --> Config Class Initialized
INFO - 2021-01-07 07:49:03 --> Loader Class Initialized
INFO - 2021-01-07 07:49:03 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:03 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:03 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:03 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:04 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-07 07:49:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:04 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:04 --> Total execution time: 0.4479
INFO - 2021-01-07 07:49:04 --> Config Class Initialized
INFO - 2021-01-07 07:49:04 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:04 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:04 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:04 --> URI Class Initialized
INFO - 2021-01-07 07:49:04 --> Router Class Initialized
INFO - 2021-01-07 07:49:04 --> Output Class Initialized
INFO - 2021-01-07 07:49:04 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:04 --> Input Class Initialized
INFO - 2021-01-07 07:49:04 --> Language Class Initialized
INFO - 2021-01-07 07:49:04 --> Language Class Initialized
INFO - 2021-01-07 07:49:04 --> Config Class Initialized
INFO - 2021-01-07 07:49:04 --> Loader Class Initialized
INFO - 2021-01-07 07:49:04 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:04 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:04 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:04 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:04 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:04 --> Controller Class Initialized
INFO - 2021-01-07 07:49:05 --> Config Class Initialized
INFO - 2021-01-07 07:49:05 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:05 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:05 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:05 --> URI Class Initialized
INFO - 2021-01-07 07:49:05 --> Router Class Initialized
INFO - 2021-01-07 07:49:05 --> Output Class Initialized
INFO - 2021-01-07 07:49:05 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:05 --> Input Class Initialized
INFO - 2021-01-07 07:49:05 --> Language Class Initialized
INFO - 2021-01-07 07:49:05 --> Language Class Initialized
INFO - 2021-01-07 07:49:05 --> Config Class Initialized
INFO - 2021-01-07 07:49:05 --> Loader Class Initialized
INFO - 2021-01-07 07:49:05 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:05 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:05 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:05 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:05 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:05 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2021-01-07 07:49:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:05 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:05 --> Total execution time: 0.3989
INFO - 2021-01-07 07:49:13 --> Config Class Initialized
INFO - 2021-01-07 07:49:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:13 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:13 --> URI Class Initialized
INFO - 2021-01-07 07:49:13 --> Router Class Initialized
INFO - 2021-01-07 07:49:13 --> Output Class Initialized
INFO - 2021-01-07 07:49:13 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:13 --> Input Class Initialized
INFO - 2021-01-07 07:49:13 --> Language Class Initialized
INFO - 2021-01-07 07:49:13 --> Language Class Initialized
INFO - 2021-01-07 07:49:13 --> Config Class Initialized
INFO - 2021-01-07 07:49:13 --> Loader Class Initialized
INFO - 2021-01-07 07:49:13 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:13 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:13 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:13 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:13 --> Controller Class Initialized
INFO - 2021-01-07 07:49:13 --> Config Class Initialized
INFO - 2021-01-07 07:49:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:13 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:14 --> URI Class Initialized
INFO - 2021-01-07 07:49:14 --> Router Class Initialized
INFO - 2021-01-07 07:49:14 --> Output Class Initialized
INFO - 2021-01-07 07:49:14 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:14 --> Input Class Initialized
INFO - 2021-01-07 07:49:14 --> Language Class Initialized
INFO - 2021-01-07 07:49:14 --> Language Class Initialized
INFO - 2021-01-07 07:49:14 --> Config Class Initialized
INFO - 2021-01-07 07:49:14 --> Loader Class Initialized
INFO - 2021-01-07 07:49:14 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:14 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:14 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:14 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:14 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-01-07 07:49:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:14 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:14 --> Total execution time: 0.3692
INFO - 2021-01-07 07:49:14 --> Config Class Initialized
INFO - 2021-01-07 07:49:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:14 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:14 --> URI Class Initialized
INFO - 2021-01-07 07:49:14 --> Router Class Initialized
INFO - 2021-01-07 07:49:14 --> Output Class Initialized
INFO - 2021-01-07 07:49:14 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:14 --> Input Class Initialized
INFO - 2021-01-07 07:49:14 --> Language Class Initialized
INFO - 2021-01-07 07:49:14 --> Language Class Initialized
INFO - 2021-01-07 07:49:14 --> Config Class Initialized
INFO - 2021-01-07 07:49:14 --> Loader Class Initialized
INFO - 2021-01-07 07:49:14 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:14 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:14 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:14 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:14 --> Controller Class Initialized
INFO - 2021-01-07 07:49:16 --> Config Class Initialized
INFO - 2021-01-07 07:49:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:16 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:16 --> URI Class Initialized
INFO - 2021-01-07 07:49:16 --> Router Class Initialized
INFO - 2021-01-07 07:49:16 --> Output Class Initialized
INFO - 2021-01-07 07:49:16 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:16 --> Input Class Initialized
INFO - 2021-01-07 07:49:16 --> Language Class Initialized
INFO - 2021-01-07 07:49:16 --> Language Class Initialized
INFO - 2021-01-07 07:49:16 --> Config Class Initialized
INFO - 2021-01-07 07:49:16 --> Loader Class Initialized
INFO - 2021-01-07 07:49:16 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:16 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:16 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:16 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:16 --> Controller Class Initialized
INFO - 2021-01-07 07:49:16 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:49:16 --> Config Class Initialized
INFO - 2021-01-07 07:49:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:16 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:16 --> URI Class Initialized
INFO - 2021-01-07 07:49:16 --> Router Class Initialized
INFO - 2021-01-07 07:49:16 --> Output Class Initialized
INFO - 2021-01-07 07:49:16 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:16 --> Input Class Initialized
INFO - 2021-01-07 07:49:16 --> Language Class Initialized
INFO - 2021-01-07 07:49:16 --> Language Class Initialized
INFO - 2021-01-07 07:49:16 --> Config Class Initialized
INFO - 2021-01-07 07:49:16 --> Loader Class Initialized
INFO - 2021-01-07 07:49:16 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:16 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:16 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:16 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:16 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 07:49:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:17 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:17 --> Total execution time: 0.3527
INFO - 2021-01-07 07:49:21 --> Config Class Initialized
INFO - 2021-01-07 07:49:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:21 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:21 --> URI Class Initialized
INFO - 2021-01-07 07:49:21 --> Router Class Initialized
INFO - 2021-01-07 07:49:21 --> Output Class Initialized
INFO - 2021-01-07 07:49:21 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:22 --> Input Class Initialized
INFO - 2021-01-07 07:49:22 --> Language Class Initialized
INFO - 2021-01-07 07:49:22 --> Language Class Initialized
INFO - 2021-01-07 07:49:22 --> Config Class Initialized
INFO - 2021-01-07 07:49:22 --> Loader Class Initialized
INFO - 2021-01-07 07:49:22 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:22 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:22 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:22 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:22 --> Controller Class Initialized
INFO - 2021-01-07 07:49:22 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:22 --> Total execution time: 0.5063
INFO - 2021-01-07 07:49:25 --> Config Class Initialized
INFO - 2021-01-07 07:49:25 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:25 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:25 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:25 --> URI Class Initialized
INFO - 2021-01-07 07:49:25 --> Router Class Initialized
INFO - 2021-01-07 07:49:25 --> Output Class Initialized
INFO - 2021-01-07 07:49:25 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:25 --> Input Class Initialized
INFO - 2021-01-07 07:49:25 --> Language Class Initialized
INFO - 2021-01-07 07:49:25 --> Language Class Initialized
INFO - 2021-01-07 07:49:25 --> Config Class Initialized
INFO - 2021-01-07 07:49:25 --> Loader Class Initialized
INFO - 2021-01-07 07:49:25 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:25 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:25 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:25 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:25 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:25 --> Controller Class Initialized
INFO - 2021-01-07 07:49:25 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:49:25 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:26 --> Total execution time: 0.4786
INFO - 2021-01-07 07:49:26 --> Config Class Initialized
INFO - 2021-01-07 07:49:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:26 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:26 --> URI Class Initialized
INFO - 2021-01-07 07:49:26 --> Router Class Initialized
INFO - 2021-01-07 07:49:26 --> Output Class Initialized
INFO - 2021-01-07 07:49:26 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:26 --> Input Class Initialized
INFO - 2021-01-07 07:49:26 --> Language Class Initialized
INFO - 2021-01-07 07:49:26 --> Language Class Initialized
INFO - 2021-01-07 07:49:26 --> Config Class Initialized
INFO - 2021-01-07 07:49:26 --> Loader Class Initialized
INFO - 2021-01-07 07:49:26 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:26 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:26 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:26 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:26 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 07:49:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:26 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:26 --> Total execution time: 0.5389
INFO - 2021-01-07 07:49:28 --> Config Class Initialized
INFO - 2021-01-07 07:49:28 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:28 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:28 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:28 --> URI Class Initialized
INFO - 2021-01-07 07:49:28 --> Router Class Initialized
INFO - 2021-01-07 07:49:28 --> Output Class Initialized
INFO - 2021-01-07 07:49:28 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:28 --> Input Class Initialized
INFO - 2021-01-07 07:49:28 --> Language Class Initialized
INFO - 2021-01-07 07:49:28 --> Language Class Initialized
INFO - 2021-01-07 07:49:28 --> Config Class Initialized
INFO - 2021-01-07 07:49:28 --> Loader Class Initialized
INFO - 2021-01-07 07:49:28 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:28 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:28 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:28 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:28 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:28 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:49:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:28 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:28 --> Total execution time: 0.4697
INFO - 2021-01-07 07:49:30 --> Config Class Initialized
INFO - 2021-01-07 07:49:30 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:30 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:30 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:30 --> URI Class Initialized
INFO - 2021-01-07 07:49:30 --> Router Class Initialized
INFO - 2021-01-07 07:49:30 --> Output Class Initialized
INFO - 2021-01-07 07:49:30 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:30 --> Input Class Initialized
INFO - 2021-01-07 07:49:30 --> Language Class Initialized
INFO - 2021-01-07 07:49:30 --> Language Class Initialized
INFO - 2021-01-07 07:49:30 --> Config Class Initialized
INFO - 2021-01-07 07:49:30 --> Loader Class Initialized
INFO - 2021-01-07 07:49:30 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:30 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:30 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:30 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:30 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:30 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:30 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:30 --> Total execution time: 0.3821
INFO - 2021-01-07 07:49:30 --> Config Class Initialized
INFO - 2021-01-07 07:49:30 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:30 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:30 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:30 --> URI Class Initialized
INFO - 2021-01-07 07:49:30 --> Router Class Initialized
INFO - 2021-01-07 07:49:30 --> Output Class Initialized
INFO - 2021-01-07 07:49:30 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:30 --> Input Class Initialized
INFO - 2021-01-07 07:49:30 --> Language Class Initialized
INFO - 2021-01-07 07:49:30 --> Language Class Initialized
INFO - 2021-01-07 07:49:30 --> Config Class Initialized
INFO - 2021-01-07 07:49:30 --> Loader Class Initialized
INFO - 2021-01-07 07:49:30 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:30 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:30 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:30 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:30 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:31 --> Controller Class Initialized
INFO - 2021-01-07 07:49:31 --> Config Class Initialized
INFO - 2021-01-07 07:49:31 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:31 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:32 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:32 --> URI Class Initialized
INFO - 2021-01-07 07:49:32 --> Router Class Initialized
INFO - 2021-01-07 07:49:32 --> Output Class Initialized
INFO - 2021-01-07 07:49:32 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:32 --> Input Class Initialized
INFO - 2021-01-07 07:49:32 --> Language Class Initialized
INFO - 2021-01-07 07:49:32 --> Language Class Initialized
INFO - 2021-01-07 07:49:32 --> Config Class Initialized
INFO - 2021-01-07 07:49:32 --> Loader Class Initialized
INFO - 2021-01-07 07:49:32 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:32 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:32 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:32 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:32 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-07 07:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:32 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:32 --> Total execution time: 0.4033
INFO - 2021-01-07 07:49:48 --> Config Class Initialized
INFO - 2021-01-07 07:49:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:48 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:48 --> URI Class Initialized
INFO - 2021-01-07 07:49:48 --> Router Class Initialized
INFO - 2021-01-07 07:49:48 --> Output Class Initialized
INFO - 2021-01-07 07:49:48 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:48 --> Input Class Initialized
INFO - 2021-01-07 07:49:48 --> Language Class Initialized
INFO - 2021-01-07 07:49:48 --> Language Class Initialized
INFO - 2021-01-07 07:49:48 --> Config Class Initialized
INFO - 2021-01-07 07:49:48 --> Loader Class Initialized
INFO - 2021-01-07 07:49:48 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:48 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:48 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:48 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:48 --> Controller Class Initialized
INFO - 2021-01-07 07:49:48 --> Config Class Initialized
INFO - 2021-01-07 07:49:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:48 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:48 --> URI Class Initialized
INFO - 2021-01-07 07:49:48 --> Router Class Initialized
INFO - 2021-01-07 07:49:48 --> Output Class Initialized
INFO - 2021-01-07 07:49:48 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:48 --> Input Class Initialized
INFO - 2021-01-07 07:49:48 --> Language Class Initialized
INFO - 2021-01-07 07:49:48 --> Language Class Initialized
INFO - 2021-01-07 07:49:48 --> Config Class Initialized
INFO - 2021-01-07 07:49:48 --> Loader Class Initialized
INFO - 2021-01-07 07:49:48 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:48 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:49 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:49 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:49 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:49:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:49:49 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:49 --> Total execution time: 0.3740
INFO - 2021-01-07 07:49:49 --> Config Class Initialized
INFO - 2021-01-07 07:49:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:49 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:49 --> URI Class Initialized
INFO - 2021-01-07 07:49:49 --> Router Class Initialized
INFO - 2021-01-07 07:49:49 --> Output Class Initialized
INFO - 2021-01-07 07:49:49 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:49 --> Input Class Initialized
INFO - 2021-01-07 07:49:49 --> Language Class Initialized
INFO - 2021-01-07 07:49:49 --> Language Class Initialized
INFO - 2021-01-07 07:49:49 --> Config Class Initialized
INFO - 2021-01-07 07:49:49 --> Loader Class Initialized
INFO - 2021-01-07 07:49:49 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:49 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:49 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:49 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:49 --> Controller Class Initialized
INFO - 2021-01-07 07:49:54 --> Config Class Initialized
INFO - 2021-01-07 07:49:54 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:49:54 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:49:54 --> Utf8 Class Initialized
INFO - 2021-01-07 07:49:54 --> URI Class Initialized
INFO - 2021-01-07 07:49:54 --> Router Class Initialized
INFO - 2021-01-07 07:49:54 --> Output Class Initialized
INFO - 2021-01-07 07:49:54 --> Security Class Initialized
DEBUG - 2021-01-07 07:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:49:54 --> Input Class Initialized
INFO - 2021-01-07 07:49:55 --> Language Class Initialized
INFO - 2021-01-07 07:49:55 --> Language Class Initialized
INFO - 2021-01-07 07:49:55 --> Config Class Initialized
INFO - 2021-01-07 07:49:55 --> Loader Class Initialized
INFO - 2021-01-07 07:49:55 --> Helper loaded: url_helper
INFO - 2021-01-07 07:49:55 --> Helper loaded: file_helper
INFO - 2021-01-07 07:49:55 --> Helper loaded: form_helper
INFO - 2021-01-07 07:49:55 --> Helper loaded: my_helper
INFO - 2021-01-07 07:49:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:49:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:49:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:49:55 --> Controller Class Initialized
DEBUG - 2021-01-07 07:49:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 07:49:55 --> Final output sent to browser
DEBUG - 2021-01-07 07:49:55 --> Total execution time: 0.3909
INFO - 2021-01-07 07:50:10 --> Config Class Initialized
INFO - 2021-01-07 07:50:10 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:10 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:10 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:10 --> URI Class Initialized
INFO - 2021-01-07 07:50:10 --> Router Class Initialized
INFO - 2021-01-07 07:50:10 --> Output Class Initialized
INFO - 2021-01-07 07:50:10 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:10 --> Input Class Initialized
INFO - 2021-01-07 07:50:10 --> Language Class Initialized
INFO - 2021-01-07 07:50:10 --> Language Class Initialized
INFO - 2021-01-07 07:50:10 --> Config Class Initialized
INFO - 2021-01-07 07:50:10 --> Loader Class Initialized
INFO - 2021-01-07 07:50:10 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:10 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:10 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:10 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:10 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:11 --> Controller Class Initialized
INFO - 2021-01-07 07:50:11 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:11 --> Total execution time: 0.3480
INFO - 2021-01-07 07:50:23 --> Config Class Initialized
INFO - 2021-01-07 07:50:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:23 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:23 --> URI Class Initialized
INFO - 2021-01-07 07:50:23 --> Router Class Initialized
INFO - 2021-01-07 07:50:23 --> Output Class Initialized
INFO - 2021-01-07 07:50:23 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:23 --> Input Class Initialized
INFO - 2021-01-07 07:50:23 --> Language Class Initialized
INFO - 2021-01-07 07:50:23 --> Language Class Initialized
INFO - 2021-01-07 07:50:23 --> Config Class Initialized
INFO - 2021-01-07 07:50:23 --> Loader Class Initialized
INFO - 2021-01-07 07:50:23 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:23 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:23 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:23 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:23 --> Controller Class Initialized
INFO - 2021-01-07 07:50:23 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:23 --> Total execution time: 0.3633
INFO - 2021-01-07 07:50:23 --> Config Class Initialized
INFO - 2021-01-07 07:50:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:23 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:23 --> URI Class Initialized
INFO - 2021-01-07 07:50:23 --> Router Class Initialized
INFO - 2021-01-07 07:50:23 --> Output Class Initialized
INFO - 2021-01-07 07:50:23 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:23 --> Input Class Initialized
INFO - 2021-01-07 07:50:23 --> Language Class Initialized
INFO - 2021-01-07 07:50:23 --> Language Class Initialized
INFO - 2021-01-07 07:50:23 --> Config Class Initialized
INFO - 2021-01-07 07:50:23 --> Loader Class Initialized
INFO - 2021-01-07 07:50:23 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:23 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:23 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:23 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:23 --> Controller Class Initialized
INFO - 2021-01-07 07:50:29 --> Config Class Initialized
INFO - 2021-01-07 07:50:30 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:30 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:30 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:30 --> URI Class Initialized
INFO - 2021-01-07 07:50:30 --> Router Class Initialized
INFO - 2021-01-07 07:50:30 --> Output Class Initialized
INFO - 2021-01-07 07:50:30 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:30 --> Input Class Initialized
INFO - 2021-01-07 07:50:30 --> Language Class Initialized
INFO - 2021-01-07 07:50:30 --> Language Class Initialized
INFO - 2021-01-07 07:50:30 --> Config Class Initialized
INFO - 2021-01-07 07:50:30 --> Loader Class Initialized
INFO - 2021-01-07 07:50:30 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:30 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:30 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:30 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:30 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:30 --> Controller Class Initialized
INFO - 2021-01-07 07:50:30 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:30 --> Total execution time: 0.4766
INFO - 2021-01-07 07:50:39 --> Config Class Initialized
INFO - 2021-01-07 07:50:39 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:39 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:39 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:39 --> URI Class Initialized
INFO - 2021-01-07 07:50:39 --> Router Class Initialized
INFO - 2021-01-07 07:50:39 --> Output Class Initialized
INFO - 2021-01-07 07:50:39 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:39 --> Input Class Initialized
INFO - 2021-01-07 07:50:39 --> Language Class Initialized
INFO - 2021-01-07 07:50:39 --> Language Class Initialized
INFO - 2021-01-07 07:50:39 --> Config Class Initialized
INFO - 2021-01-07 07:50:39 --> Loader Class Initialized
INFO - 2021-01-07 07:50:39 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:39 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:39 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:39 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:39 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:40 --> Controller Class Initialized
INFO - 2021-01-07 07:50:40 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:40 --> Total execution time: 0.3622
INFO - 2021-01-07 07:50:40 --> Config Class Initialized
INFO - 2021-01-07 07:50:40 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:40 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:40 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:40 --> URI Class Initialized
INFO - 2021-01-07 07:50:40 --> Router Class Initialized
INFO - 2021-01-07 07:50:40 --> Output Class Initialized
INFO - 2021-01-07 07:50:40 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:40 --> Input Class Initialized
INFO - 2021-01-07 07:50:40 --> Language Class Initialized
INFO - 2021-01-07 07:50:40 --> Language Class Initialized
INFO - 2021-01-07 07:50:40 --> Config Class Initialized
INFO - 2021-01-07 07:50:40 --> Loader Class Initialized
INFO - 2021-01-07 07:50:40 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:40 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:40 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:40 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:40 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:40 --> Controller Class Initialized
INFO - 2021-01-07 07:50:42 --> Config Class Initialized
INFO - 2021-01-07 07:50:42 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:42 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:42 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:42 --> URI Class Initialized
INFO - 2021-01-07 07:50:42 --> Router Class Initialized
INFO - 2021-01-07 07:50:42 --> Output Class Initialized
INFO - 2021-01-07 07:50:42 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:42 --> Input Class Initialized
INFO - 2021-01-07 07:50:42 --> Language Class Initialized
INFO - 2021-01-07 07:50:42 --> Language Class Initialized
INFO - 2021-01-07 07:50:42 --> Config Class Initialized
INFO - 2021-01-07 07:50:42 --> Loader Class Initialized
INFO - 2021-01-07 07:50:42 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:42 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:42 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:42 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:42 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:42 --> Controller Class Initialized
DEBUG - 2021-01-07 07:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-07 07:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:50:42 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:42 --> Total execution time: 0.4029
INFO - 2021-01-07 07:50:46 --> Config Class Initialized
INFO - 2021-01-07 07:50:46 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:46 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:46 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:46 --> URI Class Initialized
INFO - 2021-01-07 07:50:46 --> Router Class Initialized
INFO - 2021-01-07 07:50:46 --> Output Class Initialized
INFO - 2021-01-07 07:50:46 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:46 --> Input Class Initialized
INFO - 2021-01-07 07:50:46 --> Language Class Initialized
INFO - 2021-01-07 07:50:46 --> Language Class Initialized
INFO - 2021-01-07 07:50:46 --> Config Class Initialized
INFO - 2021-01-07 07:50:46 --> Loader Class Initialized
INFO - 2021-01-07 07:50:46 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:47 --> Controller Class Initialized
INFO - 2021-01-07 07:50:47 --> Config Class Initialized
INFO - 2021-01-07 07:50:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:47 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:47 --> URI Class Initialized
INFO - 2021-01-07 07:50:47 --> Router Class Initialized
INFO - 2021-01-07 07:50:47 --> Output Class Initialized
INFO - 2021-01-07 07:50:47 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:47 --> Input Class Initialized
INFO - 2021-01-07 07:50:47 --> Language Class Initialized
INFO - 2021-01-07 07:50:47 --> Language Class Initialized
INFO - 2021-01-07 07:50:47 --> Config Class Initialized
INFO - 2021-01-07 07:50:47 --> Loader Class Initialized
INFO - 2021-01-07 07:50:47 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:47 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:47 --> Controller Class Initialized
DEBUG - 2021-01-07 07:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:50:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:50:47 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:47 --> Total execution time: 0.3716
INFO - 2021-01-07 07:50:47 --> Config Class Initialized
INFO - 2021-01-07 07:50:47 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:47 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:47 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:47 --> URI Class Initialized
INFO - 2021-01-07 07:50:47 --> Router Class Initialized
INFO - 2021-01-07 07:50:47 --> Output Class Initialized
INFO - 2021-01-07 07:50:47 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:47 --> Input Class Initialized
INFO - 2021-01-07 07:50:47 --> Language Class Initialized
INFO - 2021-01-07 07:50:47 --> Language Class Initialized
INFO - 2021-01-07 07:50:47 --> Config Class Initialized
INFO - 2021-01-07 07:50:47 --> Loader Class Initialized
INFO - 2021-01-07 07:50:47 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:47 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:48 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:48 --> Controller Class Initialized
INFO - 2021-01-07 07:50:49 --> Config Class Initialized
INFO - 2021-01-07 07:50:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:49 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:49 --> URI Class Initialized
INFO - 2021-01-07 07:50:49 --> Router Class Initialized
INFO - 2021-01-07 07:50:49 --> Output Class Initialized
INFO - 2021-01-07 07:50:49 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:49 --> Input Class Initialized
INFO - 2021-01-07 07:50:49 --> Language Class Initialized
INFO - 2021-01-07 07:50:49 --> Language Class Initialized
INFO - 2021-01-07 07:50:49 --> Config Class Initialized
INFO - 2021-01-07 07:50:49 --> Loader Class Initialized
INFO - 2021-01-07 07:50:49 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:49 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:49 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:49 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:49 --> Controller Class Initialized
INFO - 2021-01-07 07:50:49 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:49 --> Total execution time: 0.2997
INFO - 2021-01-07 07:50:50 --> Config Class Initialized
INFO - 2021-01-07 07:50:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:51 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:51 --> URI Class Initialized
INFO - 2021-01-07 07:50:51 --> Router Class Initialized
INFO - 2021-01-07 07:50:51 --> Output Class Initialized
INFO - 2021-01-07 07:50:51 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:51 --> Input Class Initialized
INFO - 2021-01-07 07:50:51 --> Language Class Initialized
INFO - 2021-01-07 07:50:51 --> Language Class Initialized
INFO - 2021-01-07 07:50:51 --> Config Class Initialized
INFO - 2021-01-07 07:50:51 --> Loader Class Initialized
INFO - 2021-01-07 07:50:51 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:51 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:51 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:51 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:51 --> Controller Class Initialized
INFO - 2021-01-07 07:50:51 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:51 --> Total execution time: 0.3233
INFO - 2021-01-07 07:50:58 --> Config Class Initialized
INFO - 2021-01-07 07:50:58 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:50:58 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:50:58 --> Utf8 Class Initialized
INFO - 2021-01-07 07:50:58 --> URI Class Initialized
INFO - 2021-01-07 07:50:58 --> Router Class Initialized
INFO - 2021-01-07 07:50:58 --> Output Class Initialized
INFO - 2021-01-07 07:50:58 --> Security Class Initialized
DEBUG - 2021-01-07 07:50:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:50:58 --> Input Class Initialized
INFO - 2021-01-07 07:50:58 --> Language Class Initialized
INFO - 2021-01-07 07:50:58 --> Language Class Initialized
INFO - 2021-01-07 07:50:58 --> Config Class Initialized
INFO - 2021-01-07 07:50:58 --> Loader Class Initialized
INFO - 2021-01-07 07:50:58 --> Helper loaded: url_helper
INFO - 2021-01-07 07:50:58 --> Helper loaded: file_helper
INFO - 2021-01-07 07:50:58 --> Helper loaded: form_helper
INFO - 2021-01-07 07:50:58 --> Helper loaded: my_helper
INFO - 2021-01-07 07:50:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:50:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:50:58 --> Controller Class Initialized
DEBUG - 2021-01-07 07:50:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:50:58 --> Final output sent to browser
DEBUG - 2021-01-07 07:50:58 --> Total execution time: 0.3568
INFO - 2021-01-07 07:52:41 --> Config Class Initialized
INFO - 2021-01-07 07:52:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:52:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:52:41 --> Utf8 Class Initialized
INFO - 2021-01-07 07:52:41 --> URI Class Initialized
INFO - 2021-01-07 07:52:41 --> Router Class Initialized
INFO - 2021-01-07 07:52:41 --> Output Class Initialized
INFO - 2021-01-07 07:52:41 --> Security Class Initialized
DEBUG - 2021-01-07 07:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:52:41 --> Input Class Initialized
INFO - 2021-01-07 07:52:41 --> Language Class Initialized
INFO - 2021-01-07 07:52:41 --> Language Class Initialized
INFO - 2021-01-07 07:52:41 --> Config Class Initialized
INFO - 2021-01-07 07:52:41 --> Loader Class Initialized
INFO - 2021-01-07 07:52:41 --> Helper loaded: url_helper
INFO - 2021-01-07 07:52:41 --> Helper loaded: file_helper
INFO - 2021-01-07 07:52:41 --> Helper loaded: form_helper
INFO - 2021-01-07 07:52:41 --> Helper loaded: my_helper
INFO - 2021-01-07 07:52:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:52:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:52:41 --> Controller Class Initialized
DEBUG - 2021-01-07 07:52:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:52:41 --> Final output sent to browser
DEBUG - 2021-01-07 07:52:42 --> Total execution time: 0.4397
INFO - 2021-01-07 07:53:13 --> Config Class Initialized
INFO - 2021-01-07 07:53:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:53:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:53:13 --> Utf8 Class Initialized
INFO - 2021-01-07 07:53:13 --> URI Class Initialized
INFO - 2021-01-07 07:53:13 --> Router Class Initialized
INFO - 2021-01-07 07:53:13 --> Output Class Initialized
INFO - 2021-01-07 07:53:13 --> Security Class Initialized
DEBUG - 2021-01-07 07:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:53:13 --> Input Class Initialized
INFO - 2021-01-07 07:53:13 --> Language Class Initialized
INFO - 2021-01-07 07:53:13 --> Language Class Initialized
INFO - 2021-01-07 07:53:14 --> Config Class Initialized
INFO - 2021-01-07 07:53:14 --> Loader Class Initialized
INFO - 2021-01-07 07:53:14 --> Helper loaded: url_helper
INFO - 2021-01-07 07:53:14 --> Helper loaded: file_helper
INFO - 2021-01-07 07:53:14 --> Helper loaded: form_helper
INFO - 2021-01-07 07:53:14 --> Helper loaded: my_helper
INFO - 2021-01-07 07:53:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:53:14 --> Controller Class Initialized
DEBUG - 2021-01-07 07:53:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:53:14 --> Final output sent to browser
DEBUG - 2021-01-07 07:53:14 --> Total execution time: 0.3784
INFO - 2021-01-07 07:54:29 --> Config Class Initialized
INFO - 2021-01-07 07:54:29 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:54:29 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:54:29 --> Utf8 Class Initialized
INFO - 2021-01-07 07:54:29 --> URI Class Initialized
INFO - 2021-01-07 07:54:29 --> Router Class Initialized
INFO - 2021-01-07 07:54:29 --> Output Class Initialized
INFO - 2021-01-07 07:54:29 --> Security Class Initialized
DEBUG - 2021-01-07 07:54:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:54:29 --> Input Class Initialized
INFO - 2021-01-07 07:54:29 --> Language Class Initialized
INFO - 2021-01-07 07:54:29 --> Language Class Initialized
INFO - 2021-01-07 07:54:29 --> Config Class Initialized
INFO - 2021-01-07 07:54:29 --> Loader Class Initialized
INFO - 2021-01-07 07:54:29 --> Helper loaded: url_helper
INFO - 2021-01-07 07:54:29 --> Helper loaded: file_helper
INFO - 2021-01-07 07:54:29 --> Helper loaded: form_helper
INFO - 2021-01-07 07:54:29 --> Helper loaded: my_helper
INFO - 2021-01-07 07:54:29 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:54:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:54:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:54:29 --> Controller Class Initialized
DEBUG - 2021-01-07 07:54:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:54:29 --> Final output sent to browser
DEBUG - 2021-01-07 07:54:29 --> Total execution time: 0.4444
INFO - 2021-01-07 07:54:30 --> Config Class Initialized
INFO - 2021-01-07 07:54:30 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:54:30 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:54:30 --> Utf8 Class Initialized
INFO - 2021-01-07 07:54:30 --> URI Class Initialized
INFO - 2021-01-07 07:54:30 --> Router Class Initialized
INFO - 2021-01-07 07:54:31 --> Output Class Initialized
INFO - 2021-01-07 07:54:31 --> Security Class Initialized
DEBUG - 2021-01-07 07:54:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:54:31 --> Input Class Initialized
INFO - 2021-01-07 07:54:31 --> Language Class Initialized
ERROR - 2021-01-07 07:54:31 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\n_keterampilan\controllers\N_keterampilan.php 615
INFO - 2021-01-07 07:54:34 --> Config Class Initialized
INFO - 2021-01-07 07:54:34 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:54:34 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:54:34 --> Utf8 Class Initialized
INFO - 2021-01-07 07:54:35 --> URI Class Initialized
INFO - 2021-01-07 07:54:35 --> Router Class Initialized
INFO - 2021-01-07 07:54:35 --> Output Class Initialized
INFO - 2021-01-07 07:54:35 --> Security Class Initialized
DEBUG - 2021-01-07 07:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:54:35 --> Input Class Initialized
INFO - 2021-01-07 07:54:35 --> Language Class Initialized
INFO - 2021-01-07 07:54:35 --> Language Class Initialized
INFO - 2021-01-07 07:54:35 --> Config Class Initialized
INFO - 2021-01-07 07:54:35 --> Loader Class Initialized
INFO - 2021-01-07 07:54:35 --> Helper loaded: url_helper
INFO - 2021-01-07 07:54:35 --> Helper loaded: file_helper
INFO - 2021-01-07 07:54:35 --> Helper loaded: form_helper
INFO - 2021-01-07 07:54:35 --> Helper loaded: my_helper
INFO - 2021-01-07 07:54:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:54:35 --> Controller Class Initialized
DEBUG - 2021-01-07 07:54:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 07:54:35 --> Final output sent to browser
DEBUG - 2021-01-07 07:54:35 --> Total execution time: 0.3683
INFO - 2021-01-07 07:55:46 --> Config Class Initialized
INFO - 2021-01-07 07:55:46 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:55:46 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:55:46 --> Utf8 Class Initialized
INFO - 2021-01-07 07:55:46 --> URI Class Initialized
INFO - 2021-01-07 07:55:46 --> Router Class Initialized
INFO - 2021-01-07 07:55:46 --> Output Class Initialized
INFO - 2021-01-07 07:55:46 --> Security Class Initialized
DEBUG - 2021-01-07 07:55:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:55:46 --> Input Class Initialized
INFO - 2021-01-07 07:55:46 --> Language Class Initialized
INFO - 2021-01-07 07:55:46 --> Language Class Initialized
INFO - 2021-01-07 07:55:46 --> Config Class Initialized
INFO - 2021-01-07 07:55:46 --> Loader Class Initialized
INFO - 2021-01-07 07:55:46 --> Helper loaded: url_helper
INFO - 2021-01-07 07:55:46 --> Helper loaded: file_helper
INFO - 2021-01-07 07:55:46 --> Helper loaded: form_helper
INFO - 2021-01-07 07:55:46 --> Helper loaded: my_helper
INFO - 2021-01-07 07:55:46 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:55:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:55:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:55:46 --> Controller Class Initialized
DEBUG - 2021-01-07 07:55:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 07:55:46 --> Final output sent to browser
DEBUG - 2021-01-07 07:55:46 --> Total execution time: 0.3980
INFO - 2021-01-07 07:55:56 --> Config Class Initialized
INFO - 2021-01-07 07:55:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:55:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:55:56 --> Utf8 Class Initialized
INFO - 2021-01-07 07:55:56 --> URI Class Initialized
INFO - 2021-01-07 07:55:56 --> Router Class Initialized
INFO - 2021-01-07 07:55:56 --> Output Class Initialized
INFO - 2021-01-07 07:55:56 --> Security Class Initialized
DEBUG - 2021-01-07 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:55:56 --> Input Class Initialized
INFO - 2021-01-07 07:55:56 --> Language Class Initialized
INFO - 2021-01-07 07:55:56 --> Language Class Initialized
INFO - 2021-01-07 07:55:56 --> Config Class Initialized
INFO - 2021-01-07 07:55:56 --> Loader Class Initialized
INFO - 2021-01-07 07:55:56 --> Helper loaded: url_helper
INFO - 2021-01-07 07:55:56 --> Helper loaded: file_helper
INFO - 2021-01-07 07:55:56 --> Helper loaded: form_helper
INFO - 2021-01-07 07:55:56 --> Helper loaded: my_helper
INFO - 2021-01-07 07:55:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:55:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:55:56 --> Controller Class Initialized
DEBUG - 2021-01-07 07:55:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:55:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:55:56 --> Final output sent to browser
DEBUG - 2021-01-07 07:55:56 --> Total execution time: 0.4280
INFO - 2021-01-07 07:55:56 --> Config Class Initialized
INFO - 2021-01-07 07:55:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:55:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:55:56 --> Utf8 Class Initialized
INFO - 2021-01-07 07:55:56 --> URI Class Initialized
INFO - 2021-01-07 07:55:56 --> Router Class Initialized
INFO - 2021-01-07 07:55:56 --> Output Class Initialized
INFO - 2021-01-07 07:55:56 --> Security Class Initialized
DEBUG - 2021-01-07 07:55:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:55:56 --> Input Class Initialized
INFO - 2021-01-07 07:55:56 --> Language Class Initialized
INFO - 2021-01-07 07:55:56 --> Language Class Initialized
INFO - 2021-01-07 07:55:56 --> Config Class Initialized
INFO - 2021-01-07 07:55:56 --> Loader Class Initialized
INFO - 2021-01-07 07:55:56 --> Helper loaded: url_helper
INFO - 2021-01-07 07:55:56 --> Helper loaded: file_helper
INFO - 2021-01-07 07:55:56 --> Helper loaded: form_helper
INFO - 2021-01-07 07:55:56 --> Helper loaded: my_helper
INFO - 2021-01-07 07:55:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:55:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:55:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:55:57 --> Controller Class Initialized
INFO - 2021-01-07 07:56:00 --> Config Class Initialized
INFO - 2021-01-07 07:56:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:00 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:00 --> URI Class Initialized
INFO - 2021-01-07 07:56:00 --> Router Class Initialized
INFO - 2021-01-07 07:56:00 --> Output Class Initialized
INFO - 2021-01-07 07:56:00 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:00 --> Input Class Initialized
INFO - 2021-01-07 07:56:00 --> Language Class Initialized
INFO - 2021-01-07 07:56:00 --> Language Class Initialized
INFO - 2021-01-07 07:56:00 --> Config Class Initialized
INFO - 2021-01-07 07:56:00 --> Loader Class Initialized
INFO - 2021-01-07 07:56:00 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:00 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:00 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:00 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:00 --> Controller Class Initialized
INFO - 2021-01-07 07:56:00 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:00 --> Total execution time: 0.4660
INFO - 2021-01-07 07:56:00 --> Config Class Initialized
INFO - 2021-01-07 07:56:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:00 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:00 --> URI Class Initialized
INFO - 2021-01-07 07:56:00 --> Router Class Initialized
INFO - 2021-01-07 07:56:01 --> Output Class Initialized
INFO - 2021-01-07 07:56:01 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:01 --> Input Class Initialized
INFO - 2021-01-07 07:56:01 --> Language Class Initialized
INFO - 2021-01-07 07:56:01 --> Language Class Initialized
INFO - 2021-01-07 07:56:01 --> Config Class Initialized
INFO - 2021-01-07 07:56:01 --> Loader Class Initialized
INFO - 2021-01-07 07:56:01 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:01 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:01 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:01 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:01 --> Controller Class Initialized
INFO - 2021-01-07 07:56:02 --> Config Class Initialized
INFO - 2021-01-07 07:56:02 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:02 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:02 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:02 --> URI Class Initialized
INFO - 2021-01-07 07:56:02 --> Router Class Initialized
INFO - 2021-01-07 07:56:02 --> Output Class Initialized
INFO - 2021-01-07 07:56:02 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:03 --> Input Class Initialized
INFO - 2021-01-07 07:56:03 --> Language Class Initialized
INFO - 2021-01-07 07:56:03 --> Language Class Initialized
INFO - 2021-01-07 07:56:03 --> Config Class Initialized
INFO - 2021-01-07 07:56:03 --> Loader Class Initialized
INFO - 2021-01-07 07:56:03 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:03 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:03 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:03 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:03 --> Controller Class Initialized
INFO - 2021-01-07 07:56:03 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:03 --> Total execution time: 0.4345
INFO - 2021-01-07 07:56:03 --> Config Class Initialized
INFO - 2021-01-07 07:56:03 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:03 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:03 --> URI Class Initialized
INFO - 2021-01-07 07:56:03 --> Router Class Initialized
INFO - 2021-01-07 07:56:03 --> Output Class Initialized
INFO - 2021-01-07 07:56:03 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:03 --> Input Class Initialized
INFO - 2021-01-07 07:56:03 --> Language Class Initialized
INFO - 2021-01-07 07:56:03 --> Language Class Initialized
INFO - 2021-01-07 07:56:03 --> Config Class Initialized
INFO - 2021-01-07 07:56:03 --> Loader Class Initialized
INFO - 2021-01-07 07:56:03 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:03 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:03 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:03 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:03 --> Controller Class Initialized
INFO - 2021-01-07 07:56:06 --> Config Class Initialized
INFO - 2021-01-07 07:56:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:06 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:06 --> URI Class Initialized
INFO - 2021-01-07 07:56:06 --> Router Class Initialized
INFO - 2021-01-07 07:56:06 --> Output Class Initialized
INFO - 2021-01-07 07:56:06 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:06 --> Input Class Initialized
INFO - 2021-01-07 07:56:06 --> Language Class Initialized
INFO - 2021-01-07 07:56:06 --> Language Class Initialized
INFO - 2021-01-07 07:56:06 --> Config Class Initialized
INFO - 2021-01-07 07:56:06 --> Loader Class Initialized
INFO - 2021-01-07 07:56:06 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:06 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:06 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:06 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:06 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:56:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:06 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:06 --> Total execution time: 0.4202
INFO - 2021-01-07 07:56:07 --> Config Class Initialized
INFO - 2021-01-07 07:56:07 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:07 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:07 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:07 --> URI Class Initialized
INFO - 2021-01-07 07:56:07 --> Router Class Initialized
INFO - 2021-01-07 07:56:07 --> Output Class Initialized
INFO - 2021-01-07 07:56:07 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:07 --> Input Class Initialized
INFO - 2021-01-07 07:56:07 --> Language Class Initialized
INFO - 2021-01-07 07:56:07 --> Language Class Initialized
INFO - 2021-01-07 07:56:07 --> Config Class Initialized
INFO - 2021-01-07 07:56:07 --> Loader Class Initialized
INFO - 2021-01-07 07:56:07 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:07 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:07 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:07 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:07 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:07 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:07 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:07 --> Total execution time: 0.3808
INFO - 2021-01-07 07:56:08 --> Config Class Initialized
INFO - 2021-01-07 07:56:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:08 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:08 --> URI Class Initialized
INFO - 2021-01-07 07:56:08 --> Router Class Initialized
INFO - 2021-01-07 07:56:08 --> Output Class Initialized
INFO - 2021-01-07 07:56:08 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:08 --> Input Class Initialized
INFO - 2021-01-07 07:56:08 --> Language Class Initialized
INFO - 2021-01-07 07:56:08 --> Language Class Initialized
INFO - 2021-01-07 07:56:08 --> Config Class Initialized
INFO - 2021-01-07 07:56:08 --> Loader Class Initialized
INFO - 2021-01-07 07:56:08 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:08 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:08 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:08 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:08 --> Controller Class Initialized
INFO - 2021-01-07 07:56:09 --> Config Class Initialized
INFO - 2021-01-07 07:56:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:09 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:09 --> URI Class Initialized
INFO - 2021-01-07 07:56:09 --> Router Class Initialized
INFO - 2021-01-07 07:56:09 --> Output Class Initialized
INFO - 2021-01-07 07:56:09 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:09 --> Input Class Initialized
INFO - 2021-01-07 07:56:09 --> Language Class Initialized
INFO - 2021-01-07 07:56:09 --> Language Class Initialized
INFO - 2021-01-07 07:56:09 --> Config Class Initialized
INFO - 2021-01-07 07:56:09 --> Loader Class Initialized
INFO - 2021-01-07 07:56:09 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:09 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:09 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:09 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:09 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:09 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:56:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:09 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:09 --> Total execution time: 0.3955
INFO - 2021-01-07 07:56:10 --> Config Class Initialized
INFO - 2021-01-07 07:56:10 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:10 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:10 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:10 --> URI Class Initialized
INFO - 2021-01-07 07:56:10 --> Router Class Initialized
INFO - 2021-01-07 07:56:10 --> Output Class Initialized
INFO - 2021-01-07 07:56:10 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:10 --> Input Class Initialized
INFO - 2021-01-07 07:56:10 --> Language Class Initialized
INFO - 2021-01-07 07:56:10 --> Language Class Initialized
INFO - 2021-01-07 07:56:10 --> Config Class Initialized
INFO - 2021-01-07 07:56:10 --> Loader Class Initialized
INFO - 2021-01-07 07:56:10 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:10 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:10 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:10 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:10 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:10 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 07:56:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:10 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:10 --> Total execution time: 0.4316
INFO - 2021-01-07 07:56:13 --> Config Class Initialized
INFO - 2021-01-07 07:56:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:13 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:13 --> URI Class Initialized
INFO - 2021-01-07 07:56:13 --> Router Class Initialized
INFO - 2021-01-07 07:56:13 --> Output Class Initialized
INFO - 2021-01-07 07:56:13 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:13 --> Input Class Initialized
INFO - 2021-01-07 07:56:13 --> Language Class Initialized
INFO - 2021-01-07 07:56:13 --> Language Class Initialized
INFO - 2021-01-07 07:56:13 --> Config Class Initialized
INFO - 2021-01-07 07:56:13 --> Loader Class Initialized
INFO - 2021-01-07 07:56:13 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:13 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:13 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:13 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:13 --> Controller Class Initialized
INFO - 2021-01-07 07:56:13 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:56:13 --> Config Class Initialized
INFO - 2021-01-07 07:56:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:13 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:13 --> URI Class Initialized
INFO - 2021-01-07 07:56:13 --> Router Class Initialized
INFO - 2021-01-07 07:56:13 --> Output Class Initialized
INFO - 2021-01-07 07:56:13 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:13 --> Input Class Initialized
INFO - 2021-01-07 07:56:13 --> Language Class Initialized
INFO - 2021-01-07 07:56:13 --> Language Class Initialized
INFO - 2021-01-07 07:56:13 --> Config Class Initialized
INFO - 2021-01-07 07:56:13 --> Loader Class Initialized
INFO - 2021-01-07 07:56:13 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:13 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:13 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:14 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:14 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-07 07:56:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:14 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:14 --> Total execution time: 0.4519
INFO - 2021-01-07 07:56:19 --> Config Class Initialized
INFO - 2021-01-07 07:56:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:19 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:19 --> URI Class Initialized
INFO - 2021-01-07 07:56:19 --> Router Class Initialized
INFO - 2021-01-07 07:56:19 --> Output Class Initialized
INFO - 2021-01-07 07:56:19 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:19 --> Input Class Initialized
INFO - 2021-01-07 07:56:19 --> Language Class Initialized
INFO - 2021-01-07 07:56:19 --> Language Class Initialized
INFO - 2021-01-07 07:56:19 --> Config Class Initialized
INFO - 2021-01-07 07:56:19 --> Loader Class Initialized
INFO - 2021-01-07 07:56:19 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:19 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:19 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:19 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:19 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:19 --> Controller Class Initialized
INFO - 2021-01-07 07:56:19 --> Helper loaded: cookie_helper
INFO - 2021-01-07 07:56:19 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:19 --> Total execution time: 0.5019
INFO - 2021-01-07 07:56:20 --> Config Class Initialized
INFO - 2021-01-07 07:56:20 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:20 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:20 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:20 --> URI Class Initialized
INFO - 2021-01-07 07:56:20 --> Router Class Initialized
INFO - 2021-01-07 07:56:20 --> Output Class Initialized
INFO - 2021-01-07 07:56:20 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:20 --> Input Class Initialized
INFO - 2021-01-07 07:56:20 --> Language Class Initialized
INFO - 2021-01-07 07:56:20 --> Language Class Initialized
INFO - 2021-01-07 07:56:20 --> Config Class Initialized
INFO - 2021-01-07 07:56:20 --> Loader Class Initialized
INFO - 2021-01-07 07:56:20 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:20 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:20 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:20 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:20 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:20 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-07 07:56:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:20 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:20 --> Total execution time: 0.5751
INFO - 2021-01-07 07:56:22 --> Config Class Initialized
INFO - 2021-01-07 07:56:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:23 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:23 --> URI Class Initialized
INFO - 2021-01-07 07:56:23 --> Router Class Initialized
INFO - 2021-01-07 07:56:23 --> Output Class Initialized
INFO - 2021-01-07 07:56:23 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:23 --> Input Class Initialized
INFO - 2021-01-07 07:56:23 --> Language Class Initialized
INFO - 2021-01-07 07:56:23 --> Language Class Initialized
INFO - 2021-01-07 07:56:23 --> Config Class Initialized
INFO - 2021-01-07 07:56:23 --> Loader Class Initialized
INFO - 2021-01-07 07:56:23 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:23 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:23 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:23 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:23 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:56:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:23 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:23 --> Total execution time: 0.4188
INFO - 2021-01-07 07:56:24 --> Config Class Initialized
INFO - 2021-01-07 07:56:24 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:24 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:24 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:24 --> URI Class Initialized
INFO - 2021-01-07 07:56:24 --> Router Class Initialized
INFO - 2021-01-07 07:56:24 --> Output Class Initialized
INFO - 2021-01-07 07:56:24 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:24 --> Input Class Initialized
INFO - 2021-01-07 07:56:24 --> Language Class Initialized
INFO - 2021-01-07 07:56:24 --> Language Class Initialized
INFO - 2021-01-07 07:56:24 --> Config Class Initialized
INFO - 2021-01-07 07:56:24 --> Loader Class Initialized
INFO - 2021-01-07 07:56:24 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:24 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:24 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:24 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:24 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:24 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:56:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:24 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:24 --> Total execution time: 0.3822
INFO - 2021-01-07 07:56:24 --> Config Class Initialized
INFO - 2021-01-07 07:56:24 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:24 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:24 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:24 --> URI Class Initialized
INFO - 2021-01-07 07:56:24 --> Router Class Initialized
INFO - 2021-01-07 07:56:24 --> Output Class Initialized
INFO - 2021-01-07 07:56:24 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:24 --> Input Class Initialized
INFO - 2021-01-07 07:56:24 --> Language Class Initialized
INFO - 2021-01-07 07:56:24 --> Language Class Initialized
INFO - 2021-01-07 07:56:24 --> Config Class Initialized
INFO - 2021-01-07 07:56:25 --> Loader Class Initialized
INFO - 2021-01-07 07:56:25 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:25 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:25 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:25 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:25 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:25 --> Controller Class Initialized
INFO - 2021-01-07 07:56:29 --> Config Class Initialized
INFO - 2021-01-07 07:56:29 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:29 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:29 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:29 --> URI Class Initialized
INFO - 2021-01-07 07:56:29 --> Router Class Initialized
INFO - 2021-01-07 07:56:29 --> Output Class Initialized
INFO - 2021-01-07 07:56:29 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:29 --> Input Class Initialized
INFO - 2021-01-07 07:56:29 --> Language Class Initialized
INFO - 2021-01-07 07:56:29 --> Language Class Initialized
INFO - 2021-01-07 07:56:29 --> Config Class Initialized
INFO - 2021-01-07 07:56:29 --> Loader Class Initialized
INFO - 2021-01-07 07:56:29 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:29 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:29 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:29 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:29 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:29 --> Controller Class Initialized
INFO - 2021-01-07 07:56:29 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:29 --> Total execution time: 0.4567
INFO - 2021-01-07 07:56:29 --> Config Class Initialized
INFO - 2021-01-07 07:56:29 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:29 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:29 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:29 --> URI Class Initialized
INFO - 2021-01-07 07:56:30 --> Router Class Initialized
INFO - 2021-01-07 07:56:30 --> Output Class Initialized
INFO - 2021-01-07 07:56:30 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:30 --> Input Class Initialized
INFO - 2021-01-07 07:56:30 --> Language Class Initialized
INFO - 2021-01-07 07:56:30 --> Language Class Initialized
INFO - 2021-01-07 07:56:30 --> Config Class Initialized
INFO - 2021-01-07 07:56:30 --> Loader Class Initialized
INFO - 2021-01-07 07:56:30 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:30 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:30 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:30 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:30 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:30 --> Controller Class Initialized
INFO - 2021-01-07 07:56:30 --> Config Class Initialized
INFO - 2021-01-07 07:56:30 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:30 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:30 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:30 --> URI Class Initialized
INFO - 2021-01-07 07:56:30 --> Router Class Initialized
INFO - 2021-01-07 07:56:30 --> Output Class Initialized
INFO - 2021-01-07 07:56:30 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:30 --> Input Class Initialized
INFO - 2021-01-07 07:56:31 --> Language Class Initialized
INFO - 2021-01-07 07:56:31 --> Language Class Initialized
INFO - 2021-01-07 07:56:31 --> Config Class Initialized
INFO - 2021-01-07 07:56:31 --> Loader Class Initialized
INFO - 2021-01-07 07:56:31 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:31 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:31 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:31 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:31 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:31 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:56:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:31 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:31 --> Total execution time: 0.4453
INFO - 2021-01-07 07:56:32 --> Config Class Initialized
INFO - 2021-01-07 07:56:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:32 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:32 --> URI Class Initialized
INFO - 2021-01-07 07:56:32 --> Router Class Initialized
INFO - 2021-01-07 07:56:32 --> Output Class Initialized
INFO - 2021-01-07 07:56:32 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:32 --> Input Class Initialized
INFO - 2021-01-07 07:56:32 --> Language Class Initialized
INFO - 2021-01-07 07:56:32 --> Language Class Initialized
INFO - 2021-01-07 07:56:32 --> Config Class Initialized
INFO - 2021-01-07 07:56:32 --> Loader Class Initialized
INFO - 2021-01-07 07:56:32 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:32 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:32 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:32 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:32 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 07:56:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:32 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:32 --> Total execution time: 0.3896
INFO - 2021-01-07 07:56:35 --> Config Class Initialized
INFO - 2021-01-07 07:56:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:35 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:35 --> URI Class Initialized
INFO - 2021-01-07 07:56:35 --> Router Class Initialized
INFO - 2021-01-07 07:56:35 --> Output Class Initialized
INFO - 2021-01-07 07:56:35 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:35 --> Input Class Initialized
INFO - 2021-01-07 07:56:35 --> Language Class Initialized
INFO - 2021-01-07 07:56:35 --> Language Class Initialized
INFO - 2021-01-07 07:56:35 --> Config Class Initialized
INFO - 2021-01-07 07:56:35 --> Loader Class Initialized
INFO - 2021-01-07 07:56:35 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:35 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:35 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:35 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:35 --> Controller Class Initialized
INFO - 2021-01-07 07:56:35 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:35 --> Total execution time: 0.4785
INFO - 2021-01-07 07:56:35 --> Config Class Initialized
INFO - 2021-01-07 07:56:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:35 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:35 --> URI Class Initialized
INFO - 2021-01-07 07:56:35 --> Router Class Initialized
INFO - 2021-01-07 07:56:35 --> Output Class Initialized
INFO - 2021-01-07 07:56:36 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:36 --> Input Class Initialized
INFO - 2021-01-07 07:56:36 --> Language Class Initialized
INFO - 2021-01-07 07:56:36 --> Language Class Initialized
INFO - 2021-01-07 07:56:36 --> Config Class Initialized
INFO - 2021-01-07 07:56:36 --> Loader Class Initialized
INFO - 2021-01-07 07:56:36 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:36 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:36 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:36 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:36 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 07:56:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:36 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:36 --> Total execution time: 0.5728
INFO - 2021-01-07 07:56:38 --> Config Class Initialized
INFO - 2021-01-07 07:56:38 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:38 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:38 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:38 --> URI Class Initialized
INFO - 2021-01-07 07:56:38 --> Router Class Initialized
INFO - 2021-01-07 07:56:38 --> Output Class Initialized
INFO - 2021-01-07 07:56:38 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:39 --> Input Class Initialized
INFO - 2021-01-07 07:56:39 --> Language Class Initialized
INFO - 2021-01-07 07:56:39 --> Language Class Initialized
INFO - 2021-01-07 07:56:39 --> Config Class Initialized
INFO - 2021-01-07 07:56:39 --> Loader Class Initialized
INFO - 2021-01-07 07:56:39 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:39 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:39 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:39 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:39 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:39 --> Controller Class Initialized
INFO - 2021-01-07 07:56:39 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:39 --> Total execution time: 0.3814
INFO - 2021-01-07 07:56:39 --> Config Class Initialized
INFO - 2021-01-07 07:56:39 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:56:39 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:56:39 --> Utf8 Class Initialized
INFO - 2021-01-07 07:56:39 --> URI Class Initialized
INFO - 2021-01-07 07:56:39 --> Router Class Initialized
INFO - 2021-01-07 07:56:39 --> Output Class Initialized
INFO - 2021-01-07 07:56:39 --> Security Class Initialized
DEBUG - 2021-01-07 07:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:56:39 --> Input Class Initialized
INFO - 2021-01-07 07:56:39 --> Language Class Initialized
INFO - 2021-01-07 07:56:39 --> Language Class Initialized
INFO - 2021-01-07 07:56:39 --> Config Class Initialized
INFO - 2021-01-07 07:56:39 --> Loader Class Initialized
INFO - 2021-01-07 07:56:39 --> Helper loaded: url_helper
INFO - 2021-01-07 07:56:39 --> Helper loaded: file_helper
INFO - 2021-01-07 07:56:39 --> Helper loaded: form_helper
INFO - 2021-01-07 07:56:39 --> Helper loaded: my_helper
INFO - 2021-01-07 07:56:39 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:56:39 --> Controller Class Initialized
DEBUG - 2021-01-07 07:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 07:56:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:56:39 --> Final output sent to browser
DEBUG - 2021-01-07 07:56:39 --> Total execution time: 0.5751
INFO - 2021-01-07 07:58:20 --> Config Class Initialized
INFO - 2021-01-07 07:58:20 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:58:20 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:58:20 --> Utf8 Class Initialized
INFO - 2021-01-07 07:58:20 --> URI Class Initialized
INFO - 2021-01-07 07:58:20 --> Router Class Initialized
INFO - 2021-01-07 07:58:20 --> Output Class Initialized
INFO - 2021-01-07 07:58:20 --> Security Class Initialized
DEBUG - 2021-01-07 07:58:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:58:20 --> Input Class Initialized
INFO - 2021-01-07 07:58:20 --> Language Class Initialized
INFO - 2021-01-07 07:58:20 --> Language Class Initialized
INFO - 2021-01-07 07:58:20 --> Config Class Initialized
INFO - 2021-01-07 07:58:20 --> Loader Class Initialized
INFO - 2021-01-07 07:58:20 --> Helper loaded: url_helper
INFO - 2021-01-07 07:58:20 --> Helper loaded: file_helper
INFO - 2021-01-07 07:58:20 --> Helper loaded: form_helper
INFO - 2021-01-07 07:58:20 --> Helper loaded: my_helper
INFO - 2021-01-07 07:58:20 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:58:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:58:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:58:20 --> Controller Class Initialized
DEBUG - 2021-01-07 07:58:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 07:58:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:58:20 --> Final output sent to browser
DEBUG - 2021-01-07 07:58:20 --> Total execution time: 0.4383
INFO - 2021-01-07 07:58:21 --> Config Class Initialized
INFO - 2021-01-07 07:58:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:58:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:58:21 --> Utf8 Class Initialized
INFO - 2021-01-07 07:58:21 --> URI Class Initialized
INFO - 2021-01-07 07:58:21 --> Router Class Initialized
INFO - 2021-01-07 07:58:21 --> Output Class Initialized
INFO - 2021-01-07 07:58:21 --> Security Class Initialized
DEBUG - 2021-01-07 07:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:58:21 --> Input Class Initialized
INFO - 2021-01-07 07:58:21 --> Language Class Initialized
INFO - 2021-01-07 07:58:21 --> Language Class Initialized
INFO - 2021-01-07 07:58:21 --> Config Class Initialized
INFO - 2021-01-07 07:58:21 --> Loader Class Initialized
INFO - 2021-01-07 07:58:21 --> Helper loaded: url_helper
INFO - 2021-01-07 07:58:21 --> Helper loaded: file_helper
INFO - 2021-01-07 07:58:21 --> Helper loaded: form_helper
INFO - 2021-01-07 07:58:21 --> Helper loaded: my_helper
INFO - 2021-01-07 07:58:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:58:21 --> Controller Class Initialized
DEBUG - 2021-01-07 07:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 07:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 07:58:21 --> Final output sent to browser
DEBUG - 2021-01-07 07:58:21 --> Total execution time: 0.4074
INFO - 2021-01-07 07:58:21 --> Config Class Initialized
INFO - 2021-01-07 07:58:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:58:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:58:22 --> Utf8 Class Initialized
INFO - 2021-01-07 07:58:22 --> URI Class Initialized
INFO - 2021-01-07 07:58:22 --> Router Class Initialized
INFO - 2021-01-07 07:58:22 --> Output Class Initialized
INFO - 2021-01-07 07:58:22 --> Security Class Initialized
DEBUG - 2021-01-07 07:58:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:58:22 --> Input Class Initialized
INFO - 2021-01-07 07:58:22 --> Language Class Initialized
INFO - 2021-01-07 07:58:22 --> Language Class Initialized
INFO - 2021-01-07 07:58:22 --> Config Class Initialized
INFO - 2021-01-07 07:58:22 --> Loader Class Initialized
INFO - 2021-01-07 07:58:22 --> Helper loaded: url_helper
INFO - 2021-01-07 07:58:22 --> Helper loaded: file_helper
INFO - 2021-01-07 07:58:22 --> Helper loaded: form_helper
INFO - 2021-01-07 07:58:22 --> Helper loaded: my_helper
INFO - 2021-01-07 07:58:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:58:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:58:22 --> Controller Class Initialized
INFO - 2021-01-07 07:58:23 --> Config Class Initialized
INFO - 2021-01-07 07:58:23 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:58:23 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:58:23 --> Utf8 Class Initialized
INFO - 2021-01-07 07:58:23 --> URI Class Initialized
INFO - 2021-01-07 07:58:23 --> Router Class Initialized
INFO - 2021-01-07 07:58:23 --> Output Class Initialized
INFO - 2021-01-07 07:58:23 --> Security Class Initialized
DEBUG - 2021-01-07 07:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:58:23 --> Input Class Initialized
INFO - 2021-01-07 07:58:23 --> Language Class Initialized
INFO - 2021-01-07 07:58:23 --> Language Class Initialized
INFO - 2021-01-07 07:58:23 --> Config Class Initialized
INFO - 2021-01-07 07:58:23 --> Loader Class Initialized
INFO - 2021-01-07 07:58:23 --> Helper loaded: url_helper
INFO - 2021-01-07 07:58:23 --> Helper loaded: file_helper
INFO - 2021-01-07 07:58:23 --> Helper loaded: form_helper
INFO - 2021-01-07 07:58:23 --> Helper loaded: my_helper
INFO - 2021-01-07 07:58:23 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:58:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:58:24 --> Controller Class Initialized
INFO - 2021-01-07 07:58:24 --> Final output sent to browser
DEBUG - 2021-01-07 07:58:24 --> Total execution time: 0.3828
INFO - 2021-01-07 07:58:57 --> Config Class Initialized
INFO - 2021-01-07 07:58:57 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:58:57 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:58:57 --> Utf8 Class Initialized
INFO - 2021-01-07 07:58:58 --> URI Class Initialized
INFO - 2021-01-07 07:58:58 --> Router Class Initialized
INFO - 2021-01-07 07:58:58 --> Output Class Initialized
INFO - 2021-01-07 07:58:58 --> Security Class Initialized
DEBUG - 2021-01-07 07:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:58:58 --> Input Class Initialized
INFO - 2021-01-07 07:58:58 --> Language Class Initialized
INFO - 2021-01-07 07:58:58 --> Language Class Initialized
INFO - 2021-01-07 07:58:58 --> Config Class Initialized
INFO - 2021-01-07 07:58:58 --> Loader Class Initialized
INFO - 2021-01-07 07:58:58 --> Helper loaded: url_helper
INFO - 2021-01-07 07:58:58 --> Helper loaded: file_helper
INFO - 2021-01-07 07:58:58 --> Helper loaded: form_helper
INFO - 2021-01-07 07:58:58 --> Helper loaded: my_helper
INFO - 2021-01-07 07:58:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:58:58 --> Controller Class Initialized
INFO - 2021-01-07 07:58:58 --> Final output sent to browser
DEBUG - 2021-01-07 07:58:58 --> Total execution time: 0.3809
INFO - 2021-01-07 07:58:58 --> Config Class Initialized
INFO - 2021-01-07 07:58:58 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:58:58 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:58:58 --> Utf8 Class Initialized
INFO - 2021-01-07 07:58:58 --> URI Class Initialized
INFO - 2021-01-07 07:58:58 --> Router Class Initialized
INFO - 2021-01-07 07:58:58 --> Output Class Initialized
INFO - 2021-01-07 07:58:58 --> Security Class Initialized
DEBUG - 2021-01-07 07:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:58:58 --> Input Class Initialized
INFO - 2021-01-07 07:58:58 --> Language Class Initialized
INFO - 2021-01-07 07:58:58 --> Language Class Initialized
INFO - 2021-01-07 07:58:58 --> Config Class Initialized
INFO - 2021-01-07 07:58:58 --> Loader Class Initialized
INFO - 2021-01-07 07:58:58 --> Helper loaded: url_helper
INFO - 2021-01-07 07:58:58 --> Helper loaded: file_helper
INFO - 2021-01-07 07:58:58 --> Helper loaded: form_helper
INFO - 2021-01-07 07:58:58 --> Helper loaded: my_helper
INFO - 2021-01-07 07:58:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:58:58 --> Controller Class Initialized
INFO - 2021-01-07 07:58:59 --> Config Class Initialized
INFO - 2021-01-07 07:58:59 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:58:59 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:58:59 --> Utf8 Class Initialized
INFO - 2021-01-07 07:58:59 --> URI Class Initialized
INFO - 2021-01-07 07:58:59 --> Router Class Initialized
INFO - 2021-01-07 07:58:59 --> Output Class Initialized
INFO - 2021-01-07 07:58:59 --> Security Class Initialized
DEBUG - 2021-01-07 07:58:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:58:59 --> Input Class Initialized
INFO - 2021-01-07 07:58:59 --> Language Class Initialized
INFO - 2021-01-07 07:58:59 --> Language Class Initialized
INFO - 2021-01-07 07:58:59 --> Config Class Initialized
INFO - 2021-01-07 07:58:59 --> Loader Class Initialized
INFO - 2021-01-07 07:58:59 --> Helper loaded: url_helper
INFO - 2021-01-07 07:58:59 --> Helper loaded: file_helper
INFO - 2021-01-07 07:58:59 --> Helper loaded: form_helper
INFO - 2021-01-07 07:58:59 --> Helper loaded: my_helper
INFO - 2021-01-07 07:58:59 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:58:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:58:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:58:59 --> Controller Class Initialized
INFO - 2021-01-07 07:58:59 --> Final output sent to browser
DEBUG - 2021-01-07 07:58:59 --> Total execution time: 0.3548
INFO - 2021-01-07 07:59:13 --> Config Class Initialized
INFO - 2021-01-07 07:59:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:13 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:13 --> URI Class Initialized
INFO - 2021-01-07 07:59:13 --> Router Class Initialized
INFO - 2021-01-07 07:59:13 --> Output Class Initialized
INFO - 2021-01-07 07:59:13 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:13 --> Input Class Initialized
INFO - 2021-01-07 07:59:13 --> Language Class Initialized
INFO - 2021-01-07 07:59:13 --> Language Class Initialized
INFO - 2021-01-07 07:59:13 --> Config Class Initialized
INFO - 2021-01-07 07:59:13 --> Loader Class Initialized
INFO - 2021-01-07 07:59:13 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:13 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:13 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:13 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:13 --> Controller Class Initialized
INFO - 2021-01-07 07:59:14 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:14 --> Total execution time: 0.4562
INFO - 2021-01-07 07:59:14 --> Config Class Initialized
INFO - 2021-01-07 07:59:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:14 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:14 --> URI Class Initialized
INFO - 2021-01-07 07:59:14 --> Router Class Initialized
INFO - 2021-01-07 07:59:14 --> Output Class Initialized
INFO - 2021-01-07 07:59:14 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:14 --> Input Class Initialized
INFO - 2021-01-07 07:59:14 --> Language Class Initialized
INFO - 2021-01-07 07:59:14 --> Language Class Initialized
INFO - 2021-01-07 07:59:14 --> Config Class Initialized
INFO - 2021-01-07 07:59:14 --> Loader Class Initialized
INFO - 2021-01-07 07:59:14 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:14 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:14 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:14 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:14 --> Controller Class Initialized
INFO - 2021-01-07 07:59:18 --> Config Class Initialized
INFO - 2021-01-07 07:59:18 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:18 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:18 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:18 --> URI Class Initialized
INFO - 2021-01-07 07:59:18 --> Router Class Initialized
INFO - 2021-01-07 07:59:18 --> Output Class Initialized
INFO - 2021-01-07 07:59:18 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:18 --> Input Class Initialized
INFO - 2021-01-07 07:59:18 --> Language Class Initialized
INFO - 2021-01-07 07:59:18 --> Language Class Initialized
INFO - 2021-01-07 07:59:18 --> Config Class Initialized
INFO - 2021-01-07 07:59:18 --> Loader Class Initialized
INFO - 2021-01-07 07:59:18 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:18 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:18 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:18 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:18 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:18 --> Controller Class Initialized
INFO - 2021-01-07 07:59:18 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:18 --> Total execution time: 0.3484
INFO - 2021-01-07 07:59:26 --> Config Class Initialized
INFO - 2021-01-07 07:59:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:26 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:26 --> URI Class Initialized
INFO - 2021-01-07 07:59:26 --> Router Class Initialized
INFO - 2021-01-07 07:59:26 --> Output Class Initialized
INFO - 2021-01-07 07:59:26 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:26 --> Input Class Initialized
INFO - 2021-01-07 07:59:26 --> Language Class Initialized
INFO - 2021-01-07 07:59:26 --> Language Class Initialized
INFO - 2021-01-07 07:59:26 --> Config Class Initialized
INFO - 2021-01-07 07:59:26 --> Loader Class Initialized
INFO - 2021-01-07 07:59:26 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:26 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:26 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:26 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:26 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:26 --> Controller Class Initialized
INFO - 2021-01-07 07:59:26 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:26 --> Total execution time: 0.4846
INFO - 2021-01-07 07:59:28 --> Config Class Initialized
INFO - 2021-01-07 07:59:28 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:28 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:29 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:29 --> URI Class Initialized
INFO - 2021-01-07 07:59:29 --> Router Class Initialized
INFO - 2021-01-07 07:59:29 --> Output Class Initialized
INFO - 2021-01-07 07:59:29 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:29 --> Input Class Initialized
INFO - 2021-01-07 07:59:29 --> Language Class Initialized
INFO - 2021-01-07 07:59:29 --> Language Class Initialized
INFO - 2021-01-07 07:59:29 --> Config Class Initialized
INFO - 2021-01-07 07:59:29 --> Loader Class Initialized
INFO - 2021-01-07 07:59:29 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:29 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:29 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:29 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:29 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:29 --> Controller Class Initialized
INFO - 2021-01-07 07:59:29 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:29 --> Total execution time: 0.3318
INFO - 2021-01-07 07:59:32 --> Config Class Initialized
INFO - 2021-01-07 07:59:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:33 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:33 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:33 --> URI Class Initialized
INFO - 2021-01-07 07:59:33 --> Router Class Initialized
INFO - 2021-01-07 07:59:33 --> Output Class Initialized
INFO - 2021-01-07 07:59:33 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:33 --> Input Class Initialized
INFO - 2021-01-07 07:59:33 --> Language Class Initialized
INFO - 2021-01-07 07:59:33 --> Language Class Initialized
INFO - 2021-01-07 07:59:33 --> Config Class Initialized
INFO - 2021-01-07 07:59:33 --> Loader Class Initialized
INFO - 2021-01-07 07:59:33 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:33 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:33 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:33 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:33 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:33 --> Controller Class Initialized
INFO - 2021-01-07 07:59:33 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:33 --> Total execution time: 0.5787
INFO - 2021-01-07 07:59:35 --> Config Class Initialized
INFO - 2021-01-07 07:59:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:35 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:35 --> URI Class Initialized
INFO - 2021-01-07 07:59:35 --> Router Class Initialized
INFO - 2021-01-07 07:59:35 --> Output Class Initialized
INFO - 2021-01-07 07:59:35 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:35 --> Input Class Initialized
INFO - 2021-01-07 07:59:35 --> Language Class Initialized
INFO - 2021-01-07 07:59:35 --> Language Class Initialized
INFO - 2021-01-07 07:59:35 --> Config Class Initialized
INFO - 2021-01-07 07:59:35 --> Loader Class Initialized
INFO - 2021-01-07 07:59:35 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:35 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:35 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:35 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:35 --> Controller Class Initialized
INFO - 2021-01-07 07:59:35 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:35 --> Total execution time: 0.3504
INFO - 2021-01-07 07:59:38 --> Config Class Initialized
INFO - 2021-01-07 07:59:38 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:38 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:38 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:38 --> URI Class Initialized
INFO - 2021-01-07 07:59:38 --> Router Class Initialized
INFO - 2021-01-07 07:59:38 --> Output Class Initialized
INFO - 2021-01-07 07:59:38 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:38 --> Input Class Initialized
INFO - 2021-01-07 07:59:39 --> Language Class Initialized
INFO - 2021-01-07 07:59:39 --> Language Class Initialized
INFO - 2021-01-07 07:59:39 --> Config Class Initialized
INFO - 2021-01-07 07:59:39 --> Loader Class Initialized
INFO - 2021-01-07 07:59:39 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:39 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:39 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:39 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:39 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:39 --> Controller Class Initialized
INFO - 2021-01-07 07:59:39 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:39 --> Total execution time: 0.4676
INFO - 2021-01-07 07:59:41 --> Config Class Initialized
INFO - 2021-01-07 07:59:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:41 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:41 --> URI Class Initialized
INFO - 2021-01-07 07:59:41 --> Router Class Initialized
INFO - 2021-01-07 07:59:41 --> Output Class Initialized
INFO - 2021-01-07 07:59:41 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:41 --> Input Class Initialized
INFO - 2021-01-07 07:59:41 --> Language Class Initialized
INFO - 2021-01-07 07:59:41 --> Language Class Initialized
INFO - 2021-01-07 07:59:41 --> Config Class Initialized
INFO - 2021-01-07 07:59:41 --> Loader Class Initialized
INFO - 2021-01-07 07:59:41 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:41 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:41 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:41 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:41 --> Controller Class Initialized
INFO - 2021-01-07 07:59:41 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:41 --> Total execution time: 0.3464
INFO - 2021-01-07 07:59:45 --> Config Class Initialized
INFO - 2021-01-07 07:59:45 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:45 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:45 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:45 --> URI Class Initialized
INFO - 2021-01-07 07:59:45 --> Router Class Initialized
INFO - 2021-01-07 07:59:45 --> Output Class Initialized
INFO - 2021-01-07 07:59:45 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:45 --> Input Class Initialized
INFO - 2021-01-07 07:59:45 --> Language Class Initialized
INFO - 2021-01-07 07:59:45 --> Language Class Initialized
INFO - 2021-01-07 07:59:45 --> Config Class Initialized
INFO - 2021-01-07 07:59:45 --> Loader Class Initialized
INFO - 2021-01-07 07:59:45 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:45 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:45 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:45 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:45 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:45 --> Controller Class Initialized
INFO - 2021-01-07 07:59:46 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:46 --> Total execution time: 0.6043
INFO - 2021-01-07 07:59:49 --> Config Class Initialized
INFO - 2021-01-07 07:59:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:49 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:49 --> URI Class Initialized
INFO - 2021-01-07 07:59:49 --> Router Class Initialized
INFO - 2021-01-07 07:59:49 --> Output Class Initialized
INFO - 2021-01-07 07:59:49 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:49 --> Input Class Initialized
INFO - 2021-01-07 07:59:49 --> Language Class Initialized
INFO - 2021-01-07 07:59:49 --> Language Class Initialized
INFO - 2021-01-07 07:59:49 --> Config Class Initialized
INFO - 2021-01-07 07:59:49 --> Loader Class Initialized
INFO - 2021-01-07 07:59:49 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:49 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:49 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:49 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:49 --> Controller Class Initialized
DEBUG - 2021-01-07 07:59:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 07:59:49 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:49 --> Total execution time: 0.4232
INFO - 2021-01-07 07:59:55 --> Config Class Initialized
INFO - 2021-01-07 07:59:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 07:59:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 07:59:55 --> Utf8 Class Initialized
INFO - 2021-01-07 07:59:55 --> URI Class Initialized
INFO - 2021-01-07 07:59:55 --> Router Class Initialized
INFO - 2021-01-07 07:59:55 --> Output Class Initialized
INFO - 2021-01-07 07:59:55 --> Security Class Initialized
DEBUG - 2021-01-07 07:59:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 07:59:55 --> Input Class Initialized
INFO - 2021-01-07 07:59:55 --> Language Class Initialized
INFO - 2021-01-07 07:59:55 --> Language Class Initialized
INFO - 2021-01-07 07:59:55 --> Config Class Initialized
INFO - 2021-01-07 07:59:55 --> Loader Class Initialized
INFO - 2021-01-07 07:59:55 --> Helper loaded: url_helper
INFO - 2021-01-07 07:59:55 --> Helper loaded: file_helper
INFO - 2021-01-07 07:59:55 --> Helper loaded: form_helper
INFO - 2021-01-07 07:59:55 --> Helper loaded: my_helper
INFO - 2021-01-07 07:59:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 07:59:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 07:59:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 07:59:55 --> Controller Class Initialized
DEBUG - 2021-01-07 07:59:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 07:59:55 --> Final output sent to browser
DEBUG - 2021-01-07 07:59:55 --> Total execution time: 0.3773
INFO - 2021-01-07 08:00:01 --> Config Class Initialized
INFO - 2021-01-07 08:00:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:01 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:01 --> URI Class Initialized
INFO - 2021-01-07 08:00:01 --> Router Class Initialized
INFO - 2021-01-07 08:00:01 --> Output Class Initialized
INFO - 2021-01-07 08:00:01 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:01 --> Input Class Initialized
INFO - 2021-01-07 08:00:01 --> Language Class Initialized
INFO - 2021-01-07 08:00:01 --> Language Class Initialized
INFO - 2021-01-07 08:00:01 --> Config Class Initialized
INFO - 2021-01-07 08:00:01 --> Loader Class Initialized
INFO - 2021-01-07 08:00:01 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:01 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:01 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:01 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:01 --> Controller Class Initialized
DEBUG - 2021-01-07 08:00:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 08:00:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 08:00:01 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:01 --> Total execution time: 0.4300
INFO - 2021-01-07 08:00:02 --> Config Class Initialized
INFO - 2021-01-07 08:00:02 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:03 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:03 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:03 --> URI Class Initialized
INFO - 2021-01-07 08:00:03 --> Router Class Initialized
INFO - 2021-01-07 08:00:03 --> Output Class Initialized
INFO - 2021-01-07 08:00:03 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:03 --> Input Class Initialized
INFO - 2021-01-07 08:00:03 --> Language Class Initialized
INFO - 2021-01-07 08:00:03 --> Language Class Initialized
INFO - 2021-01-07 08:00:03 --> Config Class Initialized
INFO - 2021-01-07 08:00:03 --> Loader Class Initialized
INFO - 2021-01-07 08:00:03 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:03 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:03 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:03 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:03 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:03 --> Controller Class Initialized
DEBUG - 2021-01-07 08:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 08:00:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 08:00:03 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:03 --> Total execution time: 0.3946
INFO - 2021-01-07 08:00:04 --> Config Class Initialized
INFO - 2021-01-07 08:00:04 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:04 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:04 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:04 --> URI Class Initialized
INFO - 2021-01-07 08:00:04 --> Router Class Initialized
INFO - 2021-01-07 08:00:04 --> Output Class Initialized
INFO - 2021-01-07 08:00:04 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:04 --> Input Class Initialized
INFO - 2021-01-07 08:00:04 --> Language Class Initialized
INFO - 2021-01-07 08:00:04 --> Language Class Initialized
INFO - 2021-01-07 08:00:04 --> Config Class Initialized
INFO - 2021-01-07 08:00:04 --> Loader Class Initialized
INFO - 2021-01-07 08:00:04 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:04 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:04 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:04 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:04 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:04 --> Controller Class Initialized
INFO - 2021-01-07 08:00:04 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:04 --> Total execution time: 0.3439
INFO - 2021-01-07 08:00:13 --> Config Class Initialized
INFO - 2021-01-07 08:00:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:13 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:13 --> URI Class Initialized
INFO - 2021-01-07 08:00:13 --> Router Class Initialized
INFO - 2021-01-07 08:00:13 --> Output Class Initialized
INFO - 2021-01-07 08:00:13 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:13 --> Input Class Initialized
INFO - 2021-01-07 08:00:13 --> Language Class Initialized
INFO - 2021-01-07 08:00:13 --> Language Class Initialized
INFO - 2021-01-07 08:00:13 --> Config Class Initialized
INFO - 2021-01-07 08:00:13 --> Loader Class Initialized
INFO - 2021-01-07 08:00:13 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:13 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:13 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:13 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:13 --> Controller Class Initialized
INFO - 2021-01-07 08:00:13 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:13 --> Total execution time: 0.4192
INFO - 2021-01-07 08:00:13 --> Config Class Initialized
INFO - 2021-01-07 08:00:13 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:13 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:13 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:13 --> URI Class Initialized
INFO - 2021-01-07 08:00:13 --> Router Class Initialized
INFO - 2021-01-07 08:00:13 --> Output Class Initialized
INFO - 2021-01-07 08:00:13 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:13 --> Input Class Initialized
INFO - 2021-01-07 08:00:13 --> Language Class Initialized
INFO - 2021-01-07 08:00:13 --> Language Class Initialized
INFO - 2021-01-07 08:00:13 --> Config Class Initialized
INFO - 2021-01-07 08:00:13 --> Loader Class Initialized
INFO - 2021-01-07 08:00:13 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:13 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:13 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:13 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:13 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:14 --> Controller Class Initialized
DEBUG - 2021-01-07 08:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 08:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 08:00:14 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:14 --> Total execution time: 0.5477
INFO - 2021-01-07 08:00:15 --> Config Class Initialized
INFO - 2021-01-07 08:00:15 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:15 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:15 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:15 --> URI Class Initialized
INFO - 2021-01-07 08:00:15 --> Router Class Initialized
INFO - 2021-01-07 08:00:15 --> Output Class Initialized
INFO - 2021-01-07 08:00:15 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:15 --> Input Class Initialized
INFO - 2021-01-07 08:00:15 --> Language Class Initialized
INFO - 2021-01-07 08:00:15 --> Language Class Initialized
INFO - 2021-01-07 08:00:15 --> Config Class Initialized
INFO - 2021-01-07 08:00:15 --> Loader Class Initialized
INFO - 2021-01-07 08:00:15 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:15 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:15 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:15 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:15 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:15 --> Controller Class Initialized
INFO - 2021-01-07 08:00:15 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:15 --> Total execution time: 0.3731
INFO - 2021-01-07 08:00:34 --> Config Class Initialized
INFO - 2021-01-07 08:00:34 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:34 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:34 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:34 --> URI Class Initialized
INFO - 2021-01-07 08:00:34 --> Router Class Initialized
INFO - 2021-01-07 08:00:34 --> Output Class Initialized
INFO - 2021-01-07 08:00:34 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:34 --> Input Class Initialized
INFO - 2021-01-07 08:00:34 --> Language Class Initialized
INFO - 2021-01-07 08:00:34 --> Language Class Initialized
INFO - 2021-01-07 08:00:34 --> Config Class Initialized
INFO - 2021-01-07 08:00:34 --> Loader Class Initialized
INFO - 2021-01-07 08:00:34 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:34 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:34 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:34 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:34 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:34 --> Controller Class Initialized
INFO - 2021-01-07 08:00:34 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:34 --> Total execution time: 0.3928
INFO - 2021-01-07 08:00:34 --> Config Class Initialized
INFO - 2021-01-07 08:00:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:35 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:35 --> URI Class Initialized
INFO - 2021-01-07 08:00:35 --> Router Class Initialized
INFO - 2021-01-07 08:00:35 --> Output Class Initialized
INFO - 2021-01-07 08:00:35 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:35 --> Input Class Initialized
INFO - 2021-01-07 08:00:35 --> Language Class Initialized
INFO - 2021-01-07 08:00:35 --> Language Class Initialized
INFO - 2021-01-07 08:00:35 --> Config Class Initialized
INFO - 2021-01-07 08:00:35 --> Loader Class Initialized
INFO - 2021-01-07 08:00:35 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:35 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:35 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:35 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:35 --> Controller Class Initialized
DEBUG - 2021-01-07 08:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-07 08:00:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 08:00:35 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:35 --> Total execution time: 0.5682
INFO - 2021-01-07 08:00:36 --> Config Class Initialized
INFO - 2021-01-07 08:00:36 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:36 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:36 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:36 --> URI Class Initialized
INFO - 2021-01-07 08:00:36 --> Router Class Initialized
INFO - 2021-01-07 08:00:36 --> Output Class Initialized
INFO - 2021-01-07 08:00:36 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:36 --> Input Class Initialized
INFO - 2021-01-07 08:00:36 --> Language Class Initialized
INFO - 2021-01-07 08:00:36 --> Language Class Initialized
INFO - 2021-01-07 08:00:36 --> Config Class Initialized
INFO - 2021-01-07 08:00:36 --> Loader Class Initialized
INFO - 2021-01-07 08:00:36 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:36 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:36 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:36 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:36 --> Controller Class Initialized
INFO - 2021-01-07 08:00:36 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:36 --> Total execution time: 0.3442
INFO - 2021-01-07 08:00:42 --> Config Class Initialized
INFO - 2021-01-07 08:00:42 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:42 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:42 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:42 --> URI Class Initialized
INFO - 2021-01-07 08:00:42 --> Router Class Initialized
INFO - 2021-01-07 08:00:42 --> Output Class Initialized
INFO - 2021-01-07 08:00:42 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:42 --> Input Class Initialized
INFO - 2021-01-07 08:00:42 --> Language Class Initialized
INFO - 2021-01-07 08:00:42 --> Language Class Initialized
INFO - 2021-01-07 08:00:42 --> Config Class Initialized
INFO - 2021-01-07 08:00:42 --> Loader Class Initialized
INFO - 2021-01-07 08:00:42 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:42 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:42 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:42 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:42 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:42 --> Controller Class Initialized
INFO - 2021-01-07 08:00:42 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:42 --> Total execution time: 0.4659
INFO - 2021-01-07 08:00:44 --> Config Class Initialized
INFO - 2021-01-07 08:00:44 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:44 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:44 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:44 --> URI Class Initialized
INFO - 2021-01-07 08:00:44 --> Router Class Initialized
INFO - 2021-01-07 08:00:44 --> Output Class Initialized
INFO - 2021-01-07 08:00:44 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:44 --> Input Class Initialized
INFO - 2021-01-07 08:00:44 --> Language Class Initialized
INFO - 2021-01-07 08:00:44 --> Language Class Initialized
INFO - 2021-01-07 08:00:44 --> Config Class Initialized
INFO - 2021-01-07 08:00:44 --> Loader Class Initialized
INFO - 2021-01-07 08:00:44 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:44 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:45 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:45 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:45 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:45 --> Controller Class Initialized
INFO - 2021-01-07 08:00:45 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:45 --> Total execution time: 0.3507
INFO - 2021-01-07 08:00:48 --> Config Class Initialized
INFO - 2021-01-07 08:00:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:48 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:48 --> URI Class Initialized
INFO - 2021-01-07 08:00:48 --> Router Class Initialized
INFO - 2021-01-07 08:00:48 --> Output Class Initialized
INFO - 2021-01-07 08:00:48 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:48 --> Input Class Initialized
INFO - 2021-01-07 08:00:48 --> Language Class Initialized
INFO - 2021-01-07 08:00:48 --> Language Class Initialized
INFO - 2021-01-07 08:00:49 --> Config Class Initialized
INFO - 2021-01-07 08:00:49 --> Loader Class Initialized
INFO - 2021-01-07 08:00:49 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:49 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:49 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:49 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:49 --> Controller Class Initialized
INFO - 2021-01-07 08:00:49 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:49 --> Total execution time: 0.5640
INFO - 2021-01-07 08:00:52 --> Config Class Initialized
INFO - 2021-01-07 08:00:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:52 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:52 --> URI Class Initialized
INFO - 2021-01-07 08:00:52 --> Router Class Initialized
INFO - 2021-01-07 08:00:52 --> Output Class Initialized
INFO - 2021-01-07 08:00:52 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:52 --> Input Class Initialized
INFO - 2021-01-07 08:00:52 --> Language Class Initialized
INFO - 2021-01-07 08:00:52 --> Language Class Initialized
INFO - 2021-01-07 08:00:52 --> Config Class Initialized
INFO - 2021-01-07 08:00:52 --> Loader Class Initialized
INFO - 2021-01-07 08:00:52 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:52 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:52 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:52 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:52 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:52 --> Controller Class Initialized
DEBUG - 2021-01-07 08:00:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-07 08:00:52 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:52 --> Total execution time: 0.4160
INFO - 2021-01-07 08:00:56 --> Config Class Initialized
INFO - 2021-01-07 08:00:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:00:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:00:56 --> Utf8 Class Initialized
INFO - 2021-01-07 08:00:56 --> URI Class Initialized
INFO - 2021-01-07 08:00:56 --> Router Class Initialized
INFO - 2021-01-07 08:00:56 --> Output Class Initialized
INFO - 2021-01-07 08:00:56 --> Security Class Initialized
DEBUG - 2021-01-07 08:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:00:56 --> Input Class Initialized
INFO - 2021-01-07 08:00:56 --> Language Class Initialized
INFO - 2021-01-07 08:00:56 --> Language Class Initialized
INFO - 2021-01-07 08:00:56 --> Config Class Initialized
INFO - 2021-01-07 08:00:56 --> Loader Class Initialized
INFO - 2021-01-07 08:00:56 --> Helper loaded: url_helper
INFO - 2021-01-07 08:00:56 --> Helper loaded: file_helper
INFO - 2021-01-07 08:00:56 --> Helper loaded: form_helper
INFO - 2021-01-07 08:00:56 --> Helper loaded: my_helper
INFO - 2021-01-07 08:00:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:00:56 --> Controller Class Initialized
DEBUG - 2021-01-07 08:00:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:00:56 --> Final output sent to browser
DEBUG - 2021-01-07 08:00:56 --> Total execution time: 0.3666
INFO - 2021-01-07 08:05:09 --> Config Class Initialized
INFO - 2021-01-07 08:05:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:05:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:05:09 --> Utf8 Class Initialized
INFO - 2021-01-07 08:05:09 --> URI Class Initialized
INFO - 2021-01-07 08:05:09 --> Router Class Initialized
INFO - 2021-01-07 08:05:09 --> Output Class Initialized
INFO - 2021-01-07 08:05:09 --> Security Class Initialized
DEBUG - 2021-01-07 08:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:05:09 --> Input Class Initialized
INFO - 2021-01-07 08:05:09 --> Language Class Initialized
INFO - 2021-01-07 08:05:09 --> Language Class Initialized
INFO - 2021-01-07 08:05:09 --> Config Class Initialized
INFO - 2021-01-07 08:05:09 --> Loader Class Initialized
INFO - 2021-01-07 08:05:09 --> Helper loaded: url_helper
INFO - 2021-01-07 08:05:09 --> Helper loaded: file_helper
INFO - 2021-01-07 08:05:09 --> Helper loaded: form_helper
INFO - 2021-01-07 08:05:09 --> Helper loaded: my_helper
INFO - 2021-01-07 08:05:09 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:05:09 --> Controller Class Initialized
DEBUG - 2021-01-07 08:05:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:05:09 --> Final output sent to browser
DEBUG - 2021-01-07 08:05:09 --> Total execution time: 0.3631
INFO - 2021-01-07 08:09:48 --> Config Class Initialized
INFO - 2021-01-07 08:09:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:09:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:09:48 --> Utf8 Class Initialized
INFO - 2021-01-07 08:09:48 --> URI Class Initialized
INFO - 2021-01-07 08:09:48 --> Router Class Initialized
INFO - 2021-01-07 08:09:48 --> Output Class Initialized
INFO - 2021-01-07 08:09:48 --> Security Class Initialized
DEBUG - 2021-01-07 08:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:09:48 --> Input Class Initialized
INFO - 2021-01-07 08:09:48 --> Language Class Initialized
INFO - 2021-01-07 08:09:48 --> Language Class Initialized
INFO - 2021-01-07 08:09:48 --> Config Class Initialized
INFO - 2021-01-07 08:09:48 --> Loader Class Initialized
INFO - 2021-01-07 08:09:48 --> Helper loaded: url_helper
INFO - 2021-01-07 08:09:48 --> Helper loaded: file_helper
INFO - 2021-01-07 08:09:48 --> Helper loaded: form_helper
INFO - 2021-01-07 08:09:48 --> Helper loaded: my_helper
INFO - 2021-01-07 08:09:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:09:48 --> Controller Class Initialized
DEBUG - 2021-01-07 08:09:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:09:49 --> Final output sent to browser
DEBUG - 2021-01-07 08:09:49 --> Total execution time: 0.3785
INFO - 2021-01-07 08:09:50 --> Config Class Initialized
INFO - 2021-01-07 08:09:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:09:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:09:50 --> Utf8 Class Initialized
INFO - 2021-01-07 08:09:50 --> URI Class Initialized
INFO - 2021-01-07 08:09:50 --> Router Class Initialized
INFO - 2021-01-07 08:09:50 --> Output Class Initialized
INFO - 2021-01-07 08:09:50 --> Security Class Initialized
DEBUG - 2021-01-07 08:09:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:09:50 --> Input Class Initialized
INFO - 2021-01-07 08:09:50 --> Language Class Initialized
INFO - 2021-01-07 08:09:50 --> Language Class Initialized
INFO - 2021-01-07 08:09:50 --> Config Class Initialized
INFO - 2021-01-07 08:09:50 --> Loader Class Initialized
INFO - 2021-01-07 08:09:50 --> Helper loaded: url_helper
INFO - 2021-01-07 08:09:50 --> Helper loaded: file_helper
INFO - 2021-01-07 08:09:50 --> Helper loaded: form_helper
INFO - 2021-01-07 08:09:50 --> Helper loaded: my_helper
INFO - 2021-01-07 08:09:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:09:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:09:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:09:50 --> Controller Class Initialized
DEBUG - 2021-01-07 08:09:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:09:50 --> Final output sent to browser
DEBUG - 2021-01-07 08:09:50 --> Total execution time: 0.3693
INFO - 2021-01-07 08:09:54 --> Config Class Initialized
INFO - 2021-01-07 08:09:54 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:09:54 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:09:54 --> Utf8 Class Initialized
INFO - 2021-01-07 08:09:54 --> URI Class Initialized
INFO - 2021-01-07 08:09:54 --> Router Class Initialized
INFO - 2021-01-07 08:09:54 --> Output Class Initialized
INFO - 2021-01-07 08:09:54 --> Security Class Initialized
DEBUG - 2021-01-07 08:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:09:54 --> Input Class Initialized
INFO - 2021-01-07 08:09:54 --> Language Class Initialized
INFO - 2021-01-07 08:09:54 --> Language Class Initialized
INFO - 2021-01-07 08:09:54 --> Config Class Initialized
INFO - 2021-01-07 08:09:54 --> Loader Class Initialized
INFO - 2021-01-07 08:09:54 --> Helper loaded: url_helper
INFO - 2021-01-07 08:09:54 --> Helper loaded: file_helper
INFO - 2021-01-07 08:09:54 --> Helper loaded: form_helper
INFO - 2021-01-07 08:09:54 --> Helper loaded: my_helper
INFO - 2021-01-07 08:09:54 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:09:54 --> Controller Class Initialized
DEBUG - 2021-01-07 08:09:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-07 08:09:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 08:09:54 --> Final output sent to browser
DEBUG - 2021-01-07 08:09:54 --> Total execution time: 0.4063
INFO - 2021-01-07 08:09:55 --> Config Class Initialized
INFO - 2021-01-07 08:09:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:09:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:09:55 --> Utf8 Class Initialized
INFO - 2021-01-07 08:09:55 --> URI Class Initialized
INFO - 2021-01-07 08:09:55 --> Router Class Initialized
INFO - 2021-01-07 08:09:55 --> Output Class Initialized
INFO - 2021-01-07 08:09:55 --> Security Class Initialized
DEBUG - 2021-01-07 08:09:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:09:55 --> Input Class Initialized
INFO - 2021-01-07 08:09:55 --> Language Class Initialized
INFO - 2021-01-07 08:09:55 --> Language Class Initialized
INFO - 2021-01-07 08:09:55 --> Config Class Initialized
INFO - 2021-01-07 08:09:55 --> Loader Class Initialized
INFO - 2021-01-07 08:09:55 --> Helper loaded: url_helper
INFO - 2021-01-07 08:09:55 --> Helper loaded: file_helper
INFO - 2021-01-07 08:09:55 --> Helper loaded: form_helper
INFO - 2021-01-07 08:09:55 --> Helper loaded: my_helper
INFO - 2021-01-07 08:09:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:09:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:09:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:09:55 --> Controller Class Initialized
DEBUG - 2021-01-07 08:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-07 08:09:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-07 08:09:55 --> Final output sent to browser
DEBUG - 2021-01-07 08:09:56 --> Total execution time: 0.3991
INFO - 2021-01-07 08:09:56 --> Config Class Initialized
INFO - 2021-01-07 08:09:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:09:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:09:56 --> Utf8 Class Initialized
INFO - 2021-01-07 08:09:56 --> URI Class Initialized
INFO - 2021-01-07 08:09:56 --> Router Class Initialized
INFO - 2021-01-07 08:09:56 --> Output Class Initialized
INFO - 2021-01-07 08:09:56 --> Security Class Initialized
DEBUG - 2021-01-07 08:09:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:09:56 --> Input Class Initialized
INFO - 2021-01-07 08:09:56 --> Language Class Initialized
INFO - 2021-01-07 08:09:56 --> Language Class Initialized
INFO - 2021-01-07 08:09:56 --> Config Class Initialized
INFO - 2021-01-07 08:09:56 --> Loader Class Initialized
INFO - 2021-01-07 08:09:56 --> Helper loaded: url_helper
INFO - 2021-01-07 08:09:56 --> Helper loaded: file_helper
INFO - 2021-01-07 08:09:56 --> Helper loaded: form_helper
INFO - 2021-01-07 08:09:56 --> Helper loaded: my_helper
INFO - 2021-01-07 08:09:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:09:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:09:56 --> Controller Class Initialized
INFO - 2021-01-07 08:09:57 --> Config Class Initialized
INFO - 2021-01-07 08:09:57 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:09:57 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:09:57 --> Utf8 Class Initialized
INFO - 2021-01-07 08:09:57 --> URI Class Initialized
INFO - 2021-01-07 08:09:57 --> Router Class Initialized
INFO - 2021-01-07 08:09:57 --> Output Class Initialized
INFO - 2021-01-07 08:09:57 --> Security Class Initialized
DEBUG - 2021-01-07 08:09:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:09:57 --> Input Class Initialized
INFO - 2021-01-07 08:09:57 --> Language Class Initialized
INFO - 2021-01-07 08:09:57 --> Language Class Initialized
INFO - 2021-01-07 08:09:57 --> Config Class Initialized
INFO - 2021-01-07 08:09:57 --> Loader Class Initialized
INFO - 2021-01-07 08:09:57 --> Helper loaded: url_helper
INFO - 2021-01-07 08:09:57 --> Helper loaded: file_helper
INFO - 2021-01-07 08:09:57 --> Helper loaded: form_helper
INFO - 2021-01-07 08:09:57 --> Helper loaded: my_helper
INFO - 2021-01-07 08:09:57 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:09:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:09:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:09:57 --> Controller Class Initialized
DEBUG - 2021-01-07 08:09:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-07 08:09:57 --> Final output sent to browser
DEBUG - 2021-01-07 08:09:57 --> Total execution time: 0.4099
INFO - 2021-01-07 08:31:41 --> Config Class Initialized
INFO - 2021-01-07 08:31:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:31:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:31:41 --> Utf8 Class Initialized
INFO - 2021-01-07 08:31:41 --> URI Class Initialized
INFO - 2021-01-07 08:31:41 --> Router Class Initialized
INFO - 2021-01-07 08:31:41 --> Output Class Initialized
INFO - 2021-01-07 08:31:41 --> Security Class Initialized
DEBUG - 2021-01-07 08:31:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:31:41 --> Input Class Initialized
INFO - 2021-01-07 08:31:41 --> Language Class Initialized
INFO - 2021-01-07 08:31:41 --> Language Class Initialized
INFO - 2021-01-07 08:31:41 --> Config Class Initialized
INFO - 2021-01-07 08:31:41 --> Loader Class Initialized
INFO - 2021-01-07 08:31:41 --> Helper loaded: url_helper
INFO - 2021-01-07 08:31:41 --> Helper loaded: file_helper
INFO - 2021-01-07 08:31:41 --> Helper loaded: form_helper
INFO - 2021-01-07 08:31:41 --> Helper loaded: my_helper
INFO - 2021-01-07 08:31:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:31:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:31:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:31:41 --> Controller Class Initialized
ERROR - 2021-01-07 08:31:41 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' AND tambahan_sub = 'WILAYAH'' at line 1 - Invalid query: SELECT * FROM m_mapel WHERE kelompok = D' AND tambahan_sub = 'WILAYAH'
INFO - 2021-01-07 08:31:41 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 08:32:48 --> Config Class Initialized
INFO - 2021-01-07 08:32:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:32:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:32:48 --> Utf8 Class Initialized
INFO - 2021-01-07 08:32:48 --> URI Class Initialized
INFO - 2021-01-07 08:32:48 --> Router Class Initialized
INFO - 2021-01-07 08:32:48 --> Output Class Initialized
INFO - 2021-01-07 08:32:48 --> Security Class Initialized
DEBUG - 2021-01-07 08:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:32:48 --> Input Class Initialized
INFO - 2021-01-07 08:32:48 --> Language Class Initialized
INFO - 2021-01-07 08:32:48 --> Language Class Initialized
INFO - 2021-01-07 08:32:48 --> Config Class Initialized
INFO - 2021-01-07 08:32:48 --> Loader Class Initialized
INFO - 2021-01-07 08:32:48 --> Helper loaded: url_helper
INFO - 2021-01-07 08:32:48 --> Helper loaded: file_helper
INFO - 2021-01-07 08:32:48 --> Helper loaded: form_helper
INFO - 2021-01-07 08:32:48 --> Helper loaded: my_helper
INFO - 2021-01-07 08:32:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:32:49 --> Controller Class Initialized
DEBUG - 2021-01-07 08:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:32:49 --> Final output sent to browser
DEBUG - 2021-01-07 08:32:49 --> Total execution time: 0.3653
INFO - 2021-01-07 08:34:04 --> Config Class Initialized
INFO - 2021-01-07 08:34:04 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:34:04 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:34:04 --> Utf8 Class Initialized
INFO - 2021-01-07 08:34:04 --> URI Class Initialized
INFO - 2021-01-07 08:34:04 --> Router Class Initialized
INFO - 2021-01-07 08:34:04 --> Output Class Initialized
INFO - 2021-01-07 08:34:04 --> Security Class Initialized
DEBUG - 2021-01-07 08:34:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:34:04 --> Input Class Initialized
INFO - 2021-01-07 08:34:04 --> Language Class Initialized
INFO - 2021-01-07 08:34:04 --> Language Class Initialized
INFO - 2021-01-07 08:34:04 --> Config Class Initialized
INFO - 2021-01-07 08:34:04 --> Loader Class Initialized
INFO - 2021-01-07 08:34:04 --> Helper loaded: url_helper
INFO - 2021-01-07 08:34:04 --> Helper loaded: file_helper
INFO - 2021-01-07 08:34:04 --> Helper loaded: form_helper
INFO - 2021-01-07 08:34:04 --> Helper loaded: my_helper
INFO - 2021-01-07 08:34:04 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:34:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:34:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:34:04 --> Controller Class Initialized
ERROR - 2021-01-07 08:34:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '' AND tambahan_sub = 'WILAYAH'' at line 1 - Invalid query: SELECT * FROM m_mapel WHERE kelompok = D' AND tambahan_sub = 'WILAYAH'
INFO - 2021-01-07 08:34:04 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-07 08:34:57 --> Config Class Initialized
INFO - 2021-01-07 08:34:57 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:34:57 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:34:57 --> Utf8 Class Initialized
INFO - 2021-01-07 08:34:57 --> URI Class Initialized
INFO - 2021-01-07 08:34:57 --> Router Class Initialized
INFO - 2021-01-07 08:34:57 --> Output Class Initialized
INFO - 2021-01-07 08:34:57 --> Security Class Initialized
DEBUG - 2021-01-07 08:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:34:57 --> Input Class Initialized
INFO - 2021-01-07 08:34:57 --> Language Class Initialized
INFO - 2021-01-07 08:34:57 --> Language Class Initialized
INFO - 2021-01-07 08:34:57 --> Config Class Initialized
INFO - 2021-01-07 08:34:57 --> Loader Class Initialized
INFO - 2021-01-07 08:34:57 --> Helper loaded: url_helper
INFO - 2021-01-07 08:34:57 --> Helper loaded: file_helper
INFO - 2021-01-07 08:34:57 --> Helper loaded: form_helper
INFO - 2021-01-07 08:34:57 --> Helper loaded: my_helper
INFO - 2021-01-07 08:34:57 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:34:57 --> Controller Class Initialized
DEBUG - 2021-01-07 08:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:34:57 --> Final output sent to browser
DEBUG - 2021-01-07 08:34:57 --> Total execution time: 0.3681
INFO - 2021-01-07 08:36:50 --> Config Class Initialized
INFO - 2021-01-07 08:36:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:36:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:36:50 --> Utf8 Class Initialized
INFO - 2021-01-07 08:36:50 --> URI Class Initialized
INFO - 2021-01-07 08:36:50 --> Router Class Initialized
INFO - 2021-01-07 08:36:50 --> Output Class Initialized
INFO - 2021-01-07 08:36:50 --> Security Class Initialized
DEBUG - 2021-01-07 08:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:36:50 --> Input Class Initialized
INFO - 2021-01-07 08:36:50 --> Language Class Initialized
INFO - 2021-01-07 08:36:50 --> Language Class Initialized
INFO - 2021-01-07 08:36:50 --> Config Class Initialized
INFO - 2021-01-07 08:36:50 --> Loader Class Initialized
INFO - 2021-01-07 08:36:50 --> Helper loaded: url_helper
INFO - 2021-01-07 08:36:50 --> Helper loaded: file_helper
INFO - 2021-01-07 08:36:50 --> Helper loaded: form_helper
INFO - 2021-01-07 08:36:50 --> Helper loaded: my_helper
INFO - 2021-01-07 08:36:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:36:50 --> Controller Class Initialized
DEBUG - 2021-01-07 08:36:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:36:50 --> Final output sent to browser
DEBUG - 2021-01-07 08:36:50 --> Total execution time: 0.3606
INFO - 2021-01-07 08:37:55 --> Config Class Initialized
INFO - 2021-01-07 08:37:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:37:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:37:55 --> Utf8 Class Initialized
INFO - 2021-01-07 08:37:55 --> URI Class Initialized
INFO - 2021-01-07 08:37:55 --> Router Class Initialized
INFO - 2021-01-07 08:37:55 --> Output Class Initialized
INFO - 2021-01-07 08:37:55 --> Security Class Initialized
DEBUG - 2021-01-07 08:37:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:37:55 --> Input Class Initialized
INFO - 2021-01-07 08:37:55 --> Language Class Initialized
INFO - 2021-01-07 08:37:55 --> Language Class Initialized
INFO - 2021-01-07 08:37:55 --> Config Class Initialized
INFO - 2021-01-07 08:37:55 --> Loader Class Initialized
INFO - 2021-01-07 08:37:55 --> Helper loaded: url_helper
INFO - 2021-01-07 08:37:55 --> Helper loaded: file_helper
INFO - 2021-01-07 08:37:55 --> Helper loaded: form_helper
INFO - 2021-01-07 08:37:55 --> Helper loaded: my_helper
INFO - 2021-01-07 08:37:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:37:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:37:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:37:55 --> Controller Class Initialized
DEBUG - 2021-01-07 08:37:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:37:55 --> Final output sent to browser
DEBUG - 2021-01-07 08:37:55 --> Total execution time: 0.4255
INFO - 2021-01-07 08:38:51 --> Config Class Initialized
INFO - 2021-01-07 08:38:51 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:38:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:38:51 --> Utf8 Class Initialized
INFO - 2021-01-07 08:38:51 --> URI Class Initialized
INFO - 2021-01-07 08:38:51 --> Router Class Initialized
INFO - 2021-01-07 08:38:51 --> Output Class Initialized
INFO - 2021-01-07 08:38:51 --> Security Class Initialized
DEBUG - 2021-01-07 08:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:38:51 --> Input Class Initialized
INFO - 2021-01-07 08:38:51 --> Language Class Initialized
INFO - 2021-01-07 08:38:52 --> Language Class Initialized
INFO - 2021-01-07 08:38:52 --> Config Class Initialized
INFO - 2021-01-07 08:38:52 --> Loader Class Initialized
INFO - 2021-01-07 08:38:52 --> Helper loaded: url_helper
INFO - 2021-01-07 08:38:52 --> Helper loaded: file_helper
INFO - 2021-01-07 08:38:52 --> Helper loaded: form_helper
INFO - 2021-01-07 08:38:52 --> Helper loaded: my_helper
INFO - 2021-01-07 08:38:52 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:38:52 --> Controller Class Initialized
DEBUG - 2021-01-07 08:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:38:52 --> Final output sent to browser
DEBUG - 2021-01-07 08:38:52 --> Total execution time: 0.3805
INFO - 2021-01-07 08:40:24 --> Config Class Initialized
INFO - 2021-01-07 08:40:24 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:40:24 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:40:24 --> Utf8 Class Initialized
INFO - 2021-01-07 08:40:24 --> URI Class Initialized
INFO - 2021-01-07 08:40:24 --> Router Class Initialized
INFO - 2021-01-07 08:40:24 --> Output Class Initialized
INFO - 2021-01-07 08:40:24 --> Security Class Initialized
DEBUG - 2021-01-07 08:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:40:24 --> Input Class Initialized
INFO - 2021-01-07 08:40:24 --> Language Class Initialized
INFO - 2021-01-07 08:40:24 --> Language Class Initialized
INFO - 2021-01-07 08:40:24 --> Config Class Initialized
INFO - 2021-01-07 08:40:24 --> Loader Class Initialized
INFO - 2021-01-07 08:40:24 --> Helper loaded: url_helper
INFO - 2021-01-07 08:40:24 --> Helper loaded: file_helper
INFO - 2021-01-07 08:40:24 --> Helper loaded: form_helper
INFO - 2021-01-07 08:40:24 --> Helper loaded: my_helper
INFO - 2021-01-07 08:40:24 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:40:24 --> Controller Class Initialized
DEBUG - 2021-01-07 08:40:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:40:24 --> Final output sent to browser
DEBUG - 2021-01-07 08:40:24 --> Total execution time: 0.4189
INFO - 2021-01-07 08:40:41 --> Config Class Initialized
INFO - 2021-01-07 08:40:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:40:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:40:41 --> Utf8 Class Initialized
INFO - 2021-01-07 08:40:41 --> URI Class Initialized
INFO - 2021-01-07 08:40:41 --> Router Class Initialized
INFO - 2021-01-07 08:40:41 --> Output Class Initialized
INFO - 2021-01-07 08:40:41 --> Security Class Initialized
DEBUG - 2021-01-07 08:40:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:40:41 --> Input Class Initialized
INFO - 2021-01-07 08:40:41 --> Language Class Initialized
INFO - 2021-01-07 08:40:41 --> Language Class Initialized
INFO - 2021-01-07 08:40:41 --> Config Class Initialized
INFO - 2021-01-07 08:40:41 --> Loader Class Initialized
INFO - 2021-01-07 08:40:42 --> Helper loaded: url_helper
INFO - 2021-01-07 08:40:42 --> Helper loaded: file_helper
INFO - 2021-01-07 08:40:42 --> Helper loaded: form_helper
INFO - 2021-01-07 08:40:42 --> Helper loaded: my_helper
INFO - 2021-01-07 08:40:42 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:40:42 --> Controller Class Initialized
DEBUG - 2021-01-07 08:40:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:40:42 --> Final output sent to browser
DEBUG - 2021-01-07 08:40:42 --> Total execution time: 0.3704
INFO - 2021-01-07 08:40:56 --> Config Class Initialized
INFO - 2021-01-07 08:40:56 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:40:56 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:40:56 --> Utf8 Class Initialized
INFO - 2021-01-07 08:40:56 --> URI Class Initialized
INFO - 2021-01-07 08:40:56 --> Router Class Initialized
INFO - 2021-01-07 08:40:56 --> Output Class Initialized
INFO - 2021-01-07 08:40:56 --> Security Class Initialized
DEBUG - 2021-01-07 08:40:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:40:56 --> Input Class Initialized
INFO - 2021-01-07 08:40:56 --> Language Class Initialized
INFO - 2021-01-07 08:40:56 --> Language Class Initialized
INFO - 2021-01-07 08:40:56 --> Config Class Initialized
INFO - 2021-01-07 08:40:56 --> Loader Class Initialized
INFO - 2021-01-07 08:40:56 --> Helper loaded: url_helper
INFO - 2021-01-07 08:40:56 --> Helper loaded: file_helper
INFO - 2021-01-07 08:40:56 --> Helper loaded: form_helper
INFO - 2021-01-07 08:40:56 --> Helper loaded: my_helper
INFO - 2021-01-07 08:40:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:40:56 --> Controller Class Initialized
DEBUG - 2021-01-07 08:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:40:56 --> Final output sent to browser
DEBUG - 2021-01-07 08:40:56 --> Total execution time: 0.4047
INFO - 2021-01-07 08:41:05 --> Config Class Initialized
INFO - 2021-01-07 08:41:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:41:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:41:06 --> Utf8 Class Initialized
INFO - 2021-01-07 08:41:06 --> URI Class Initialized
INFO - 2021-01-07 08:41:06 --> Router Class Initialized
INFO - 2021-01-07 08:41:06 --> Output Class Initialized
INFO - 2021-01-07 08:41:06 --> Security Class Initialized
DEBUG - 2021-01-07 08:41:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:41:06 --> Input Class Initialized
INFO - 2021-01-07 08:41:06 --> Language Class Initialized
INFO - 2021-01-07 08:41:06 --> Language Class Initialized
INFO - 2021-01-07 08:41:06 --> Config Class Initialized
INFO - 2021-01-07 08:41:06 --> Loader Class Initialized
INFO - 2021-01-07 08:41:06 --> Helper loaded: url_helper
INFO - 2021-01-07 08:41:06 --> Helper loaded: file_helper
INFO - 2021-01-07 08:41:06 --> Helper loaded: form_helper
INFO - 2021-01-07 08:41:06 --> Helper loaded: my_helper
INFO - 2021-01-07 08:41:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:41:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:41:06 --> Controller Class Initialized
DEBUG - 2021-01-07 08:41:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:41:06 --> Final output sent to browser
DEBUG - 2021-01-07 08:41:06 --> Total execution time: 0.3769
INFO - 2021-01-07 08:41:19 --> Config Class Initialized
INFO - 2021-01-07 08:41:19 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:41:19 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:41:19 --> Utf8 Class Initialized
INFO - 2021-01-07 08:41:19 --> URI Class Initialized
INFO - 2021-01-07 08:41:19 --> Router Class Initialized
INFO - 2021-01-07 08:41:19 --> Output Class Initialized
INFO - 2021-01-07 08:41:19 --> Security Class Initialized
DEBUG - 2021-01-07 08:41:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:41:19 --> Input Class Initialized
INFO - 2021-01-07 08:41:19 --> Language Class Initialized
INFO - 2021-01-07 08:41:19 --> Language Class Initialized
INFO - 2021-01-07 08:41:19 --> Config Class Initialized
INFO - 2021-01-07 08:41:19 --> Loader Class Initialized
INFO - 2021-01-07 08:41:19 --> Helper loaded: url_helper
INFO - 2021-01-07 08:41:19 --> Helper loaded: file_helper
INFO - 2021-01-07 08:41:19 --> Helper loaded: form_helper
INFO - 2021-01-07 08:41:19 --> Helper loaded: my_helper
INFO - 2021-01-07 08:41:20 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:41:20 --> Controller Class Initialized
DEBUG - 2021-01-07 08:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:41:20 --> Final output sent to browser
DEBUG - 2021-01-07 08:41:20 --> Total execution time: 0.3788
INFO - 2021-01-07 08:41:21 --> Config Class Initialized
INFO - 2021-01-07 08:41:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:41:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:41:21 --> Utf8 Class Initialized
INFO - 2021-01-07 08:41:21 --> URI Class Initialized
INFO - 2021-01-07 08:41:21 --> Router Class Initialized
INFO - 2021-01-07 08:41:21 --> Output Class Initialized
INFO - 2021-01-07 08:41:21 --> Security Class Initialized
DEBUG - 2021-01-07 08:41:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:41:21 --> Input Class Initialized
INFO - 2021-01-07 08:41:21 --> Language Class Initialized
INFO - 2021-01-07 08:41:21 --> Language Class Initialized
INFO - 2021-01-07 08:41:21 --> Config Class Initialized
INFO - 2021-01-07 08:41:21 --> Loader Class Initialized
INFO - 2021-01-07 08:41:21 --> Helper loaded: url_helper
INFO - 2021-01-07 08:41:21 --> Helper loaded: file_helper
INFO - 2021-01-07 08:41:21 --> Helper loaded: form_helper
INFO - 2021-01-07 08:41:21 --> Helper loaded: my_helper
INFO - 2021-01-07 08:41:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:41:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:41:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:41:21 --> Controller Class Initialized
DEBUG - 2021-01-07 08:41:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:41:21 --> Final output sent to browser
DEBUG - 2021-01-07 08:41:21 --> Total execution time: 0.4090
INFO - 2021-01-07 08:41:32 --> Config Class Initialized
INFO - 2021-01-07 08:41:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:41:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:41:32 --> Utf8 Class Initialized
INFO - 2021-01-07 08:41:32 --> URI Class Initialized
INFO - 2021-01-07 08:41:32 --> Router Class Initialized
INFO - 2021-01-07 08:41:32 --> Output Class Initialized
INFO - 2021-01-07 08:41:32 --> Security Class Initialized
DEBUG - 2021-01-07 08:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:41:32 --> Input Class Initialized
INFO - 2021-01-07 08:41:32 --> Language Class Initialized
INFO - 2021-01-07 08:41:32 --> Language Class Initialized
INFO - 2021-01-07 08:41:32 --> Config Class Initialized
INFO - 2021-01-07 08:41:32 --> Loader Class Initialized
INFO - 2021-01-07 08:41:32 --> Helper loaded: url_helper
INFO - 2021-01-07 08:41:32 --> Helper loaded: file_helper
INFO - 2021-01-07 08:41:32 --> Helper loaded: form_helper
INFO - 2021-01-07 08:41:32 --> Helper loaded: my_helper
INFO - 2021-01-07 08:41:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:41:32 --> Controller Class Initialized
DEBUG - 2021-01-07 08:41:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:41:32 --> Final output sent to browser
DEBUG - 2021-01-07 08:41:32 --> Total execution time: 0.3975
INFO - 2021-01-07 08:41:48 --> Config Class Initialized
INFO - 2021-01-07 08:41:48 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:41:48 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:41:48 --> Utf8 Class Initialized
INFO - 2021-01-07 08:41:48 --> URI Class Initialized
INFO - 2021-01-07 08:41:48 --> Router Class Initialized
INFO - 2021-01-07 08:41:48 --> Output Class Initialized
INFO - 2021-01-07 08:41:48 --> Security Class Initialized
DEBUG - 2021-01-07 08:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:41:48 --> Input Class Initialized
INFO - 2021-01-07 08:41:48 --> Language Class Initialized
INFO - 2021-01-07 08:41:48 --> Language Class Initialized
INFO - 2021-01-07 08:41:48 --> Config Class Initialized
INFO - 2021-01-07 08:41:48 --> Loader Class Initialized
INFO - 2021-01-07 08:41:48 --> Helper loaded: url_helper
INFO - 2021-01-07 08:41:48 --> Helper loaded: file_helper
INFO - 2021-01-07 08:41:48 --> Helper loaded: form_helper
INFO - 2021-01-07 08:41:48 --> Helper loaded: my_helper
INFO - 2021-01-07 08:41:48 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:41:48 --> Controller Class Initialized
DEBUG - 2021-01-07 08:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:41:48 --> Final output sent to browser
DEBUG - 2021-01-07 08:41:48 --> Total execution time: 0.4035
INFO - 2021-01-07 08:42:01 --> Config Class Initialized
INFO - 2021-01-07 08:42:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:42:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:42:01 --> Utf8 Class Initialized
INFO - 2021-01-07 08:42:01 --> URI Class Initialized
INFO - 2021-01-07 08:42:01 --> Router Class Initialized
INFO - 2021-01-07 08:42:01 --> Output Class Initialized
INFO - 2021-01-07 08:42:01 --> Security Class Initialized
DEBUG - 2021-01-07 08:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:42:01 --> Input Class Initialized
INFO - 2021-01-07 08:42:01 --> Language Class Initialized
INFO - 2021-01-07 08:42:01 --> Language Class Initialized
INFO - 2021-01-07 08:42:01 --> Config Class Initialized
INFO - 2021-01-07 08:42:01 --> Loader Class Initialized
INFO - 2021-01-07 08:42:01 --> Helper loaded: url_helper
INFO - 2021-01-07 08:42:01 --> Helper loaded: file_helper
INFO - 2021-01-07 08:42:01 --> Helper loaded: form_helper
INFO - 2021-01-07 08:42:01 --> Helper loaded: my_helper
INFO - 2021-01-07 08:42:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:42:01 --> Controller Class Initialized
DEBUG - 2021-01-07 08:42:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:42:01 --> Final output sent to browser
DEBUG - 2021-01-07 08:42:01 --> Total execution time: 0.3967
INFO - 2021-01-07 08:42:09 --> Config Class Initialized
INFO - 2021-01-07 08:42:09 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:42:09 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:42:09 --> Utf8 Class Initialized
INFO - 2021-01-07 08:42:10 --> URI Class Initialized
INFO - 2021-01-07 08:42:10 --> Router Class Initialized
INFO - 2021-01-07 08:42:10 --> Output Class Initialized
INFO - 2021-01-07 08:42:10 --> Security Class Initialized
DEBUG - 2021-01-07 08:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:42:10 --> Input Class Initialized
INFO - 2021-01-07 08:42:10 --> Language Class Initialized
INFO - 2021-01-07 08:42:10 --> Language Class Initialized
INFO - 2021-01-07 08:42:10 --> Config Class Initialized
INFO - 2021-01-07 08:42:10 --> Loader Class Initialized
INFO - 2021-01-07 08:42:10 --> Helper loaded: url_helper
INFO - 2021-01-07 08:42:10 --> Helper loaded: file_helper
INFO - 2021-01-07 08:42:10 --> Helper loaded: form_helper
INFO - 2021-01-07 08:42:10 --> Helper loaded: my_helper
INFO - 2021-01-07 08:42:10 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:42:10 --> Controller Class Initialized
DEBUG - 2021-01-07 08:42:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:42:10 --> Final output sent to browser
DEBUG - 2021-01-07 08:42:10 --> Total execution time: 0.3668
INFO - 2021-01-07 08:42:17 --> Config Class Initialized
INFO - 2021-01-07 08:42:17 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:42:17 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:42:17 --> Utf8 Class Initialized
INFO - 2021-01-07 08:42:17 --> URI Class Initialized
INFO - 2021-01-07 08:42:17 --> Router Class Initialized
INFO - 2021-01-07 08:42:17 --> Output Class Initialized
INFO - 2021-01-07 08:42:17 --> Security Class Initialized
DEBUG - 2021-01-07 08:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:42:17 --> Input Class Initialized
INFO - 2021-01-07 08:42:17 --> Language Class Initialized
INFO - 2021-01-07 08:42:17 --> Language Class Initialized
INFO - 2021-01-07 08:42:17 --> Config Class Initialized
INFO - 2021-01-07 08:42:17 --> Loader Class Initialized
INFO - 2021-01-07 08:42:17 --> Helper loaded: url_helper
INFO - 2021-01-07 08:42:17 --> Helper loaded: file_helper
INFO - 2021-01-07 08:42:17 --> Helper loaded: form_helper
INFO - 2021-01-07 08:42:17 --> Helper loaded: my_helper
INFO - 2021-01-07 08:42:17 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:42:17 --> Controller Class Initialized
DEBUG - 2021-01-07 08:42:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:42:17 --> Final output sent to browser
DEBUG - 2021-01-07 08:42:17 --> Total execution time: 0.3866
INFO - 2021-01-07 08:42:39 --> Config Class Initialized
INFO - 2021-01-07 08:42:39 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:42:39 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:42:39 --> Utf8 Class Initialized
INFO - 2021-01-07 08:42:39 --> URI Class Initialized
INFO - 2021-01-07 08:42:39 --> Router Class Initialized
INFO - 2021-01-07 08:42:40 --> Output Class Initialized
INFO - 2021-01-07 08:42:40 --> Security Class Initialized
DEBUG - 2021-01-07 08:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:42:40 --> Input Class Initialized
INFO - 2021-01-07 08:42:40 --> Language Class Initialized
INFO - 2021-01-07 08:42:40 --> Language Class Initialized
INFO - 2021-01-07 08:42:40 --> Config Class Initialized
INFO - 2021-01-07 08:42:40 --> Loader Class Initialized
INFO - 2021-01-07 08:42:40 --> Helper loaded: url_helper
INFO - 2021-01-07 08:42:40 --> Helper loaded: file_helper
INFO - 2021-01-07 08:42:40 --> Helper loaded: form_helper
INFO - 2021-01-07 08:42:40 --> Helper loaded: my_helper
INFO - 2021-01-07 08:42:40 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:42:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:42:40 --> Controller Class Initialized
DEBUG - 2021-01-07 08:42:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:42:40 --> Final output sent to browser
DEBUG - 2021-01-07 08:42:40 --> Total execution time: 0.3958
INFO - 2021-01-07 08:42:52 --> Config Class Initialized
INFO - 2021-01-07 08:42:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:42:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:42:52 --> Utf8 Class Initialized
INFO - 2021-01-07 08:42:52 --> URI Class Initialized
INFO - 2021-01-07 08:42:52 --> Router Class Initialized
INFO - 2021-01-07 08:42:52 --> Output Class Initialized
INFO - 2021-01-07 08:42:52 --> Security Class Initialized
DEBUG - 2021-01-07 08:42:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:42:52 --> Input Class Initialized
INFO - 2021-01-07 08:42:52 --> Language Class Initialized
ERROR - 2021-01-07 08:42:52 --> Severity: Parsing Error --> syntax error, unexpected '<' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 432
INFO - 2021-01-07 08:43:06 --> Config Class Initialized
INFO - 2021-01-07 08:43:06 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:43:06 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:43:06 --> Utf8 Class Initialized
INFO - 2021-01-07 08:43:06 --> URI Class Initialized
INFO - 2021-01-07 08:43:06 --> Router Class Initialized
INFO - 2021-01-07 08:43:06 --> Output Class Initialized
INFO - 2021-01-07 08:43:06 --> Security Class Initialized
DEBUG - 2021-01-07 08:43:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:43:06 --> Input Class Initialized
INFO - 2021-01-07 08:43:06 --> Language Class Initialized
INFO - 2021-01-07 08:43:06 --> Language Class Initialized
INFO - 2021-01-07 08:43:06 --> Config Class Initialized
INFO - 2021-01-07 08:43:06 --> Loader Class Initialized
INFO - 2021-01-07 08:43:06 --> Helper loaded: url_helper
INFO - 2021-01-07 08:43:06 --> Helper loaded: file_helper
INFO - 2021-01-07 08:43:06 --> Helper loaded: form_helper
INFO - 2021-01-07 08:43:06 --> Helper loaded: my_helper
INFO - 2021-01-07 08:43:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:43:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:43:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:43:06 --> Controller Class Initialized
DEBUG - 2021-01-07 08:43:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:43:06 --> Final output sent to browser
DEBUG - 2021-01-07 08:43:06 --> Total execution time: 0.3852
INFO - 2021-01-07 08:43:41 --> Config Class Initialized
INFO - 2021-01-07 08:43:42 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:43:42 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:43:42 --> Utf8 Class Initialized
INFO - 2021-01-07 08:43:42 --> URI Class Initialized
INFO - 2021-01-07 08:43:42 --> Router Class Initialized
INFO - 2021-01-07 08:43:42 --> Output Class Initialized
INFO - 2021-01-07 08:43:42 --> Security Class Initialized
DEBUG - 2021-01-07 08:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:43:42 --> Input Class Initialized
INFO - 2021-01-07 08:43:42 --> Language Class Initialized
INFO - 2021-01-07 08:43:42 --> Language Class Initialized
INFO - 2021-01-07 08:43:42 --> Config Class Initialized
INFO - 2021-01-07 08:43:42 --> Loader Class Initialized
INFO - 2021-01-07 08:43:42 --> Helper loaded: url_helper
INFO - 2021-01-07 08:43:42 --> Helper loaded: file_helper
INFO - 2021-01-07 08:43:42 --> Helper loaded: form_helper
INFO - 2021-01-07 08:43:42 --> Helper loaded: my_helper
INFO - 2021-01-07 08:43:42 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:43:42 --> Controller Class Initialized
DEBUG - 2021-01-07 08:43:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:43:42 --> Final output sent to browser
DEBUG - 2021-01-07 08:43:42 --> Total execution time: 0.3910
INFO - 2021-01-07 08:43:50 --> Config Class Initialized
INFO - 2021-01-07 08:43:50 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:43:50 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:43:50 --> Utf8 Class Initialized
INFO - 2021-01-07 08:43:50 --> URI Class Initialized
INFO - 2021-01-07 08:43:50 --> Router Class Initialized
INFO - 2021-01-07 08:43:50 --> Output Class Initialized
INFO - 2021-01-07 08:43:50 --> Security Class Initialized
DEBUG - 2021-01-07 08:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:43:50 --> Input Class Initialized
INFO - 2021-01-07 08:43:50 --> Language Class Initialized
INFO - 2021-01-07 08:43:50 --> Language Class Initialized
INFO - 2021-01-07 08:43:50 --> Config Class Initialized
INFO - 2021-01-07 08:43:50 --> Loader Class Initialized
INFO - 2021-01-07 08:43:50 --> Helper loaded: url_helper
INFO - 2021-01-07 08:43:50 --> Helper loaded: file_helper
INFO - 2021-01-07 08:43:50 --> Helper loaded: form_helper
INFO - 2021-01-07 08:43:50 --> Helper loaded: my_helper
INFO - 2021-01-07 08:43:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:43:50 --> Controller Class Initialized
DEBUG - 2021-01-07 08:43:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:43:50 --> Final output sent to browser
DEBUG - 2021-01-07 08:43:50 --> Total execution time: 0.3844
INFO - 2021-01-07 08:46:00 --> Config Class Initialized
INFO - 2021-01-07 08:46:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:46:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:46:00 --> Utf8 Class Initialized
INFO - 2021-01-07 08:46:00 --> URI Class Initialized
INFO - 2021-01-07 08:46:00 --> Router Class Initialized
INFO - 2021-01-07 08:46:00 --> Output Class Initialized
INFO - 2021-01-07 08:46:00 --> Security Class Initialized
DEBUG - 2021-01-07 08:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:46:00 --> Input Class Initialized
INFO - 2021-01-07 08:46:00 --> Language Class Initialized
INFO - 2021-01-07 08:46:00 --> Language Class Initialized
INFO - 2021-01-07 08:46:00 --> Config Class Initialized
INFO - 2021-01-07 08:46:00 --> Loader Class Initialized
INFO - 2021-01-07 08:46:00 --> Helper loaded: url_helper
INFO - 2021-01-07 08:46:00 --> Helper loaded: file_helper
INFO - 2021-01-07 08:46:00 --> Helper loaded: form_helper
INFO - 2021-01-07 08:46:00 --> Helper loaded: my_helper
INFO - 2021-01-07 08:46:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:46:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:46:00 --> Controller Class Initialized
DEBUG - 2021-01-07 08:46:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:46:00 --> Final output sent to browser
DEBUG - 2021-01-07 08:46:00 --> Total execution time: 0.4016
INFO - 2021-01-07 08:49:52 --> Config Class Initialized
INFO - 2021-01-07 08:49:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:49:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:49:52 --> Utf8 Class Initialized
INFO - 2021-01-07 08:49:52 --> URI Class Initialized
INFO - 2021-01-07 08:49:53 --> Router Class Initialized
INFO - 2021-01-07 08:49:53 --> Output Class Initialized
INFO - 2021-01-07 08:49:53 --> Security Class Initialized
DEBUG - 2021-01-07 08:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:49:53 --> Input Class Initialized
INFO - 2021-01-07 08:49:53 --> Language Class Initialized
INFO - 2021-01-07 08:49:53 --> Language Class Initialized
INFO - 2021-01-07 08:49:53 --> Config Class Initialized
INFO - 2021-01-07 08:49:53 --> Loader Class Initialized
INFO - 2021-01-07 08:49:53 --> Helper loaded: url_helper
INFO - 2021-01-07 08:49:53 --> Helper loaded: file_helper
INFO - 2021-01-07 08:49:53 --> Helper loaded: form_helper
INFO - 2021-01-07 08:49:53 --> Helper loaded: my_helper
INFO - 2021-01-07 08:49:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:49:53 --> Controller Class Initialized
DEBUG - 2021-01-07 08:49:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:49:53 --> Final output sent to browser
DEBUG - 2021-01-07 08:49:53 --> Total execution time: 0.3687
INFO - 2021-01-07 08:50:11 --> Config Class Initialized
INFO - 2021-01-07 08:50:11 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:50:11 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:50:11 --> Utf8 Class Initialized
INFO - 2021-01-07 08:50:11 --> URI Class Initialized
INFO - 2021-01-07 08:50:11 --> Router Class Initialized
INFO - 2021-01-07 08:50:11 --> Output Class Initialized
INFO - 2021-01-07 08:50:11 --> Security Class Initialized
DEBUG - 2021-01-07 08:50:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:50:11 --> Input Class Initialized
INFO - 2021-01-07 08:50:11 --> Language Class Initialized
INFO - 2021-01-07 08:50:11 --> Language Class Initialized
INFO - 2021-01-07 08:50:11 --> Config Class Initialized
INFO - 2021-01-07 08:50:11 --> Loader Class Initialized
INFO - 2021-01-07 08:50:11 --> Helper loaded: url_helper
INFO - 2021-01-07 08:50:11 --> Helper loaded: file_helper
INFO - 2021-01-07 08:50:11 --> Helper loaded: form_helper
INFO - 2021-01-07 08:50:11 --> Helper loaded: my_helper
INFO - 2021-01-07 08:50:11 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:50:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:50:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:50:11 --> Controller Class Initialized
DEBUG - 2021-01-07 08:50:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:50:11 --> Final output sent to browser
DEBUG - 2021-01-07 08:50:11 --> Total execution time: 0.3773
INFO - 2021-01-07 08:50:37 --> Config Class Initialized
INFO - 2021-01-07 08:50:37 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:50:37 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:50:38 --> Utf8 Class Initialized
INFO - 2021-01-07 08:50:38 --> URI Class Initialized
INFO - 2021-01-07 08:50:38 --> Router Class Initialized
INFO - 2021-01-07 08:50:38 --> Output Class Initialized
INFO - 2021-01-07 08:50:38 --> Security Class Initialized
DEBUG - 2021-01-07 08:50:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:50:38 --> Input Class Initialized
INFO - 2021-01-07 08:50:38 --> Language Class Initialized
INFO - 2021-01-07 08:50:38 --> Language Class Initialized
INFO - 2021-01-07 08:50:38 --> Config Class Initialized
INFO - 2021-01-07 08:50:38 --> Loader Class Initialized
INFO - 2021-01-07 08:50:38 --> Helper loaded: url_helper
INFO - 2021-01-07 08:50:38 --> Helper loaded: file_helper
INFO - 2021-01-07 08:50:38 --> Helper loaded: form_helper
INFO - 2021-01-07 08:50:38 --> Helper loaded: my_helper
INFO - 2021-01-07 08:50:38 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:50:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:50:38 --> Controller Class Initialized
DEBUG - 2021-01-07 08:50:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:50:38 --> Final output sent to browser
DEBUG - 2021-01-07 08:50:38 --> Total execution time: 0.4275
INFO - 2021-01-07 08:50:55 --> Config Class Initialized
INFO - 2021-01-07 08:50:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:50:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:50:55 --> Utf8 Class Initialized
INFO - 2021-01-07 08:50:55 --> URI Class Initialized
INFO - 2021-01-07 08:50:55 --> Router Class Initialized
INFO - 2021-01-07 08:50:55 --> Output Class Initialized
INFO - 2021-01-07 08:50:55 --> Security Class Initialized
DEBUG - 2021-01-07 08:50:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:50:55 --> Input Class Initialized
INFO - 2021-01-07 08:50:55 --> Language Class Initialized
INFO - 2021-01-07 08:50:55 --> Language Class Initialized
INFO - 2021-01-07 08:50:55 --> Config Class Initialized
INFO - 2021-01-07 08:50:55 --> Loader Class Initialized
INFO - 2021-01-07 08:50:55 --> Helper loaded: url_helper
INFO - 2021-01-07 08:50:55 --> Helper loaded: file_helper
INFO - 2021-01-07 08:50:55 --> Helper loaded: form_helper
INFO - 2021-01-07 08:50:55 --> Helper loaded: my_helper
INFO - 2021-01-07 08:50:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:50:55 --> Controller Class Initialized
DEBUG - 2021-01-07 08:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:50:55 --> Final output sent to browser
DEBUG - 2021-01-07 08:50:55 --> Total execution time: 0.4050
INFO - 2021-01-07 08:51:16 --> Config Class Initialized
INFO - 2021-01-07 08:51:16 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:51:16 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:51:16 --> Utf8 Class Initialized
INFO - 2021-01-07 08:51:16 --> URI Class Initialized
INFO - 2021-01-07 08:51:16 --> Router Class Initialized
INFO - 2021-01-07 08:51:16 --> Output Class Initialized
INFO - 2021-01-07 08:51:16 --> Security Class Initialized
DEBUG - 2021-01-07 08:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:51:16 --> Input Class Initialized
INFO - 2021-01-07 08:51:16 --> Language Class Initialized
INFO - 2021-01-07 08:51:16 --> Language Class Initialized
INFO - 2021-01-07 08:51:16 --> Config Class Initialized
INFO - 2021-01-07 08:51:16 --> Loader Class Initialized
INFO - 2021-01-07 08:51:16 --> Helper loaded: url_helper
INFO - 2021-01-07 08:51:16 --> Helper loaded: file_helper
INFO - 2021-01-07 08:51:16 --> Helper loaded: form_helper
INFO - 2021-01-07 08:51:16 --> Helper loaded: my_helper
INFO - 2021-01-07 08:51:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:51:16 --> Controller Class Initialized
DEBUG - 2021-01-07 08:51:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:51:16 --> Final output sent to browser
DEBUG - 2021-01-07 08:51:16 --> Total execution time: 0.3683
INFO - 2021-01-07 08:51:33 --> Config Class Initialized
INFO - 2021-01-07 08:51:33 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:51:33 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:51:33 --> Utf8 Class Initialized
INFO - 2021-01-07 08:51:33 --> URI Class Initialized
INFO - 2021-01-07 08:51:33 --> Router Class Initialized
INFO - 2021-01-07 08:51:33 --> Output Class Initialized
INFO - 2021-01-07 08:51:33 --> Security Class Initialized
DEBUG - 2021-01-07 08:51:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:51:33 --> Input Class Initialized
INFO - 2021-01-07 08:51:33 --> Language Class Initialized
INFO - 2021-01-07 08:51:33 --> Language Class Initialized
INFO - 2021-01-07 08:51:33 --> Config Class Initialized
INFO - 2021-01-07 08:51:33 --> Loader Class Initialized
INFO - 2021-01-07 08:51:33 --> Helper loaded: url_helper
INFO - 2021-01-07 08:51:33 --> Helper loaded: file_helper
INFO - 2021-01-07 08:51:33 --> Helper loaded: form_helper
INFO - 2021-01-07 08:51:33 --> Helper loaded: my_helper
INFO - 2021-01-07 08:51:33 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:51:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:51:33 --> Controller Class Initialized
DEBUG - 2021-01-07 08:51:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:51:33 --> Final output sent to browser
DEBUG - 2021-01-07 08:51:33 --> Total execution time: 0.3972
INFO - 2021-01-07 08:51:39 --> Config Class Initialized
INFO - 2021-01-07 08:51:39 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:51:39 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:51:39 --> Utf8 Class Initialized
INFO - 2021-01-07 08:51:39 --> URI Class Initialized
INFO - 2021-01-07 08:51:39 --> Router Class Initialized
INFO - 2021-01-07 08:51:39 --> Output Class Initialized
INFO - 2021-01-07 08:51:39 --> Security Class Initialized
DEBUG - 2021-01-07 08:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:51:39 --> Input Class Initialized
INFO - 2021-01-07 08:51:39 --> Language Class Initialized
INFO - 2021-01-07 08:51:39 --> Language Class Initialized
INFO - 2021-01-07 08:51:39 --> Config Class Initialized
INFO - 2021-01-07 08:51:39 --> Loader Class Initialized
INFO - 2021-01-07 08:51:40 --> Helper loaded: url_helper
INFO - 2021-01-07 08:51:40 --> Helper loaded: file_helper
INFO - 2021-01-07 08:51:40 --> Helper loaded: form_helper
INFO - 2021-01-07 08:51:40 --> Helper loaded: my_helper
INFO - 2021-01-07 08:51:40 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:51:40 --> Controller Class Initialized
DEBUG - 2021-01-07 08:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:51:40 --> Final output sent to browser
DEBUG - 2021-01-07 08:51:40 --> Total execution time: 0.4289
INFO - 2021-01-07 08:52:40 --> Config Class Initialized
INFO - 2021-01-07 08:52:40 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:52:40 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:52:40 --> Utf8 Class Initialized
INFO - 2021-01-07 08:52:40 --> URI Class Initialized
INFO - 2021-01-07 08:52:40 --> Router Class Initialized
INFO - 2021-01-07 08:52:40 --> Output Class Initialized
INFO - 2021-01-07 08:52:40 --> Security Class Initialized
DEBUG - 2021-01-07 08:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:52:40 --> Input Class Initialized
INFO - 2021-01-07 08:52:40 --> Language Class Initialized
INFO - 2021-01-07 08:52:40 --> Language Class Initialized
INFO - 2021-01-07 08:52:40 --> Config Class Initialized
INFO - 2021-01-07 08:52:40 --> Loader Class Initialized
INFO - 2021-01-07 08:52:40 --> Helper loaded: url_helper
INFO - 2021-01-07 08:52:40 --> Helper loaded: file_helper
INFO - 2021-01-07 08:52:40 --> Helper loaded: form_helper
INFO - 2021-01-07 08:52:40 --> Helper loaded: my_helper
INFO - 2021-01-07 08:52:40 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:52:40 --> Controller Class Initialized
DEBUG - 2021-01-07 08:52:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:52:40 --> Final output sent to browser
DEBUG - 2021-01-07 08:52:40 --> Total execution time: 0.3778
INFO - 2021-01-07 08:53:15 --> Config Class Initialized
INFO - 2021-01-07 08:53:15 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:53:15 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:53:15 --> Utf8 Class Initialized
INFO - 2021-01-07 08:53:15 --> URI Class Initialized
INFO - 2021-01-07 08:53:15 --> Router Class Initialized
INFO - 2021-01-07 08:53:15 --> Output Class Initialized
INFO - 2021-01-07 08:53:15 --> Security Class Initialized
DEBUG - 2021-01-07 08:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:53:15 --> Input Class Initialized
INFO - 2021-01-07 08:53:15 --> Language Class Initialized
INFO - 2021-01-07 08:53:15 --> Language Class Initialized
INFO - 2021-01-07 08:53:15 --> Config Class Initialized
INFO - 2021-01-07 08:53:15 --> Loader Class Initialized
INFO - 2021-01-07 08:53:15 --> Helper loaded: url_helper
INFO - 2021-01-07 08:53:15 --> Helper loaded: file_helper
INFO - 2021-01-07 08:53:15 --> Helper loaded: form_helper
INFO - 2021-01-07 08:53:15 --> Helper loaded: my_helper
INFO - 2021-01-07 08:53:15 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:53:16 --> Controller Class Initialized
DEBUG - 2021-01-07 08:53:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:53:16 --> Final output sent to browser
DEBUG - 2021-01-07 08:53:16 --> Total execution time: 0.3860
INFO - 2021-01-07 08:53:26 --> Config Class Initialized
INFO - 2021-01-07 08:53:26 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:53:26 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:53:26 --> Utf8 Class Initialized
INFO - 2021-01-07 08:53:26 --> URI Class Initialized
INFO - 2021-01-07 08:53:26 --> Router Class Initialized
INFO - 2021-01-07 08:53:26 --> Output Class Initialized
INFO - 2021-01-07 08:53:26 --> Security Class Initialized
DEBUG - 2021-01-07 08:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:53:26 --> Input Class Initialized
INFO - 2021-01-07 08:53:26 --> Language Class Initialized
INFO - 2021-01-07 08:53:26 --> Language Class Initialized
INFO - 2021-01-07 08:53:26 --> Config Class Initialized
INFO - 2021-01-07 08:53:26 --> Loader Class Initialized
INFO - 2021-01-07 08:53:27 --> Helper loaded: url_helper
INFO - 2021-01-07 08:53:27 --> Helper loaded: file_helper
INFO - 2021-01-07 08:53:27 --> Helper loaded: form_helper
INFO - 2021-01-07 08:53:27 --> Helper loaded: my_helper
INFO - 2021-01-07 08:53:27 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:53:27 --> Controller Class Initialized
DEBUG - 2021-01-07 08:53:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:53:27 --> Final output sent to browser
DEBUG - 2021-01-07 08:53:27 --> Total execution time: 0.4016
INFO - 2021-01-07 08:53:36 --> Config Class Initialized
INFO - 2021-01-07 08:53:36 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:53:36 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:53:36 --> Utf8 Class Initialized
INFO - 2021-01-07 08:53:36 --> URI Class Initialized
INFO - 2021-01-07 08:53:36 --> Router Class Initialized
INFO - 2021-01-07 08:53:36 --> Output Class Initialized
INFO - 2021-01-07 08:53:36 --> Security Class Initialized
DEBUG - 2021-01-07 08:53:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:53:36 --> Input Class Initialized
INFO - 2021-01-07 08:53:36 --> Language Class Initialized
INFO - 2021-01-07 08:53:36 --> Language Class Initialized
INFO - 2021-01-07 08:53:36 --> Config Class Initialized
INFO - 2021-01-07 08:53:36 --> Loader Class Initialized
INFO - 2021-01-07 08:53:36 --> Helper loaded: url_helper
INFO - 2021-01-07 08:53:36 --> Helper loaded: file_helper
INFO - 2021-01-07 08:53:36 --> Helper loaded: form_helper
INFO - 2021-01-07 08:53:36 --> Helper loaded: my_helper
INFO - 2021-01-07 08:53:36 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:53:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:53:36 --> Controller Class Initialized
DEBUG - 2021-01-07 08:53:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:53:36 --> Final output sent to browser
DEBUG - 2021-01-07 08:53:36 --> Total execution time: 0.3742
INFO - 2021-01-07 08:53:42 --> Config Class Initialized
INFO - 2021-01-07 08:53:42 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:53:42 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:53:42 --> Utf8 Class Initialized
INFO - 2021-01-07 08:53:42 --> URI Class Initialized
INFO - 2021-01-07 08:53:42 --> Router Class Initialized
INFO - 2021-01-07 08:53:42 --> Output Class Initialized
INFO - 2021-01-07 08:53:42 --> Security Class Initialized
DEBUG - 2021-01-07 08:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:53:42 --> Input Class Initialized
INFO - 2021-01-07 08:53:42 --> Language Class Initialized
INFO - 2021-01-07 08:53:42 --> Language Class Initialized
INFO - 2021-01-07 08:53:42 --> Config Class Initialized
INFO - 2021-01-07 08:53:42 --> Loader Class Initialized
INFO - 2021-01-07 08:53:42 --> Helper loaded: url_helper
INFO - 2021-01-07 08:53:42 --> Helper loaded: file_helper
INFO - 2021-01-07 08:53:42 --> Helper loaded: form_helper
INFO - 2021-01-07 08:53:42 --> Helper loaded: my_helper
INFO - 2021-01-07 08:53:42 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:53:42 --> Controller Class Initialized
DEBUG - 2021-01-07 08:53:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:53:42 --> Final output sent to browser
DEBUG - 2021-01-07 08:53:42 --> Total execution time: 0.3745
INFO - 2021-01-07 08:53:54 --> Config Class Initialized
INFO - 2021-01-07 08:53:54 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:53:54 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:53:54 --> Utf8 Class Initialized
INFO - 2021-01-07 08:53:54 --> URI Class Initialized
INFO - 2021-01-07 08:53:54 --> Router Class Initialized
INFO - 2021-01-07 08:53:54 --> Output Class Initialized
INFO - 2021-01-07 08:53:54 --> Security Class Initialized
DEBUG - 2021-01-07 08:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:53:55 --> Input Class Initialized
INFO - 2021-01-07 08:53:55 --> Language Class Initialized
INFO - 2021-01-07 08:53:55 --> Language Class Initialized
INFO - 2021-01-07 08:53:55 --> Config Class Initialized
INFO - 2021-01-07 08:53:55 --> Loader Class Initialized
INFO - 2021-01-07 08:53:55 --> Helper loaded: url_helper
INFO - 2021-01-07 08:53:55 --> Helper loaded: file_helper
INFO - 2021-01-07 08:53:55 --> Helper loaded: form_helper
INFO - 2021-01-07 08:53:55 --> Helper loaded: my_helper
INFO - 2021-01-07 08:53:55 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:53:55 --> Controller Class Initialized
DEBUG - 2021-01-07 08:53:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:53:55 --> Final output sent to browser
DEBUG - 2021-01-07 08:53:55 --> Total execution time: 0.3869
INFO - 2021-01-07 08:54:00 --> Config Class Initialized
INFO - 2021-01-07 08:54:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:54:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:54:00 --> Utf8 Class Initialized
INFO - 2021-01-07 08:54:00 --> URI Class Initialized
INFO - 2021-01-07 08:54:00 --> Router Class Initialized
INFO - 2021-01-07 08:54:00 --> Output Class Initialized
INFO - 2021-01-07 08:54:00 --> Security Class Initialized
DEBUG - 2021-01-07 08:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:54:00 --> Input Class Initialized
INFO - 2021-01-07 08:54:00 --> Language Class Initialized
INFO - 2021-01-07 08:54:00 --> Language Class Initialized
INFO - 2021-01-07 08:54:00 --> Config Class Initialized
INFO - 2021-01-07 08:54:00 --> Loader Class Initialized
INFO - 2021-01-07 08:54:00 --> Helper loaded: url_helper
INFO - 2021-01-07 08:54:00 --> Helper loaded: file_helper
INFO - 2021-01-07 08:54:00 --> Helper loaded: form_helper
INFO - 2021-01-07 08:54:01 --> Helper loaded: my_helper
INFO - 2021-01-07 08:54:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:54:01 --> Controller Class Initialized
DEBUG - 2021-01-07 08:54:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:54:01 --> Final output sent to browser
DEBUG - 2021-01-07 08:54:01 --> Total execution time: 0.3657
INFO - 2021-01-07 08:55:01 --> Config Class Initialized
INFO - 2021-01-07 08:55:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:55:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:55:01 --> Utf8 Class Initialized
INFO - 2021-01-07 08:55:01 --> URI Class Initialized
INFO - 2021-01-07 08:55:01 --> Router Class Initialized
INFO - 2021-01-07 08:55:01 --> Output Class Initialized
INFO - 2021-01-07 08:55:01 --> Security Class Initialized
DEBUG - 2021-01-07 08:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:55:01 --> Input Class Initialized
INFO - 2021-01-07 08:55:01 --> Language Class Initialized
INFO - 2021-01-07 08:55:01 --> Language Class Initialized
INFO - 2021-01-07 08:55:01 --> Config Class Initialized
INFO - 2021-01-07 08:55:01 --> Loader Class Initialized
INFO - 2021-01-07 08:55:01 --> Helper loaded: url_helper
INFO - 2021-01-07 08:55:01 --> Helper loaded: file_helper
INFO - 2021-01-07 08:55:01 --> Helper loaded: form_helper
INFO - 2021-01-07 08:55:01 --> Helper loaded: my_helper
INFO - 2021-01-07 08:55:01 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:55:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:55:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:55:01 --> Controller Class Initialized
DEBUG - 2021-01-07 08:55:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:55:01 --> Final output sent to browser
DEBUG - 2021-01-07 08:55:01 --> Total execution time: 0.3958
INFO - 2021-01-07 08:55:25 --> Config Class Initialized
INFO - 2021-01-07 08:55:25 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:55:25 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:55:25 --> Utf8 Class Initialized
INFO - 2021-01-07 08:55:25 --> URI Class Initialized
INFO - 2021-01-07 08:55:25 --> Router Class Initialized
INFO - 2021-01-07 08:55:25 --> Output Class Initialized
INFO - 2021-01-07 08:55:25 --> Security Class Initialized
DEBUG - 2021-01-07 08:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:55:25 --> Input Class Initialized
INFO - 2021-01-07 08:55:25 --> Language Class Initialized
INFO - 2021-01-07 08:55:25 --> Language Class Initialized
INFO - 2021-01-07 08:55:25 --> Config Class Initialized
INFO - 2021-01-07 08:55:25 --> Loader Class Initialized
INFO - 2021-01-07 08:55:25 --> Helper loaded: url_helper
INFO - 2021-01-07 08:55:25 --> Helper loaded: file_helper
INFO - 2021-01-07 08:55:25 --> Helper loaded: form_helper
INFO - 2021-01-07 08:55:25 --> Helper loaded: my_helper
INFO - 2021-01-07 08:55:25 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:55:25 --> Controller Class Initialized
DEBUG - 2021-01-07 08:55:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:55:25 --> Final output sent to browser
DEBUG - 2021-01-07 08:55:25 --> Total execution time: 0.4017
INFO - 2021-01-07 08:56:08 --> Config Class Initialized
INFO - 2021-01-07 08:56:08 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:56:08 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:56:08 --> Utf8 Class Initialized
INFO - 2021-01-07 08:56:08 --> URI Class Initialized
INFO - 2021-01-07 08:56:08 --> Router Class Initialized
INFO - 2021-01-07 08:56:08 --> Output Class Initialized
INFO - 2021-01-07 08:56:08 --> Security Class Initialized
DEBUG - 2021-01-07 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:56:08 --> Input Class Initialized
INFO - 2021-01-07 08:56:08 --> Language Class Initialized
INFO - 2021-01-07 08:56:08 --> Language Class Initialized
INFO - 2021-01-07 08:56:08 --> Config Class Initialized
INFO - 2021-01-07 08:56:08 --> Loader Class Initialized
INFO - 2021-01-07 08:56:08 --> Helper loaded: url_helper
INFO - 2021-01-07 08:56:08 --> Helper loaded: file_helper
INFO - 2021-01-07 08:56:08 --> Helper loaded: form_helper
INFO - 2021-01-07 08:56:08 --> Helper loaded: my_helper
INFO - 2021-01-07 08:56:08 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:56:08 --> Controller Class Initialized
DEBUG - 2021-01-07 08:56:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:56:08 --> Final output sent to browser
DEBUG - 2021-01-07 08:56:08 --> Total execution time: 0.4629
INFO - 2021-01-07 08:58:11 --> Config Class Initialized
INFO - 2021-01-07 08:58:11 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:58:11 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:58:11 --> Utf8 Class Initialized
INFO - 2021-01-07 08:58:11 --> URI Class Initialized
INFO - 2021-01-07 08:58:11 --> Router Class Initialized
INFO - 2021-01-07 08:58:11 --> Output Class Initialized
INFO - 2021-01-07 08:58:11 --> Security Class Initialized
DEBUG - 2021-01-07 08:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:58:11 --> Input Class Initialized
INFO - 2021-01-07 08:58:11 --> Language Class Initialized
INFO - 2021-01-07 08:58:11 --> Language Class Initialized
INFO - 2021-01-07 08:58:11 --> Config Class Initialized
INFO - 2021-01-07 08:58:11 --> Loader Class Initialized
INFO - 2021-01-07 08:58:11 --> Helper loaded: url_helper
INFO - 2021-01-07 08:58:11 --> Helper loaded: file_helper
INFO - 2021-01-07 08:58:11 --> Helper loaded: form_helper
INFO - 2021-01-07 08:58:11 --> Helper loaded: my_helper
INFO - 2021-01-07 08:58:11 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:58:11 --> Controller Class Initialized
DEBUG - 2021-01-07 08:58:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:58:11 --> Final output sent to browser
DEBUG - 2021-01-07 08:58:11 --> Total execution time: 0.4350
INFO - 2021-01-07 08:58:49 --> Config Class Initialized
INFO - 2021-01-07 08:58:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 08:58:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 08:58:49 --> Utf8 Class Initialized
INFO - 2021-01-07 08:58:49 --> URI Class Initialized
INFO - 2021-01-07 08:58:49 --> Router Class Initialized
INFO - 2021-01-07 08:58:49 --> Output Class Initialized
INFO - 2021-01-07 08:58:49 --> Security Class Initialized
DEBUG - 2021-01-07 08:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 08:58:49 --> Input Class Initialized
INFO - 2021-01-07 08:58:49 --> Language Class Initialized
INFO - 2021-01-07 08:58:49 --> Language Class Initialized
INFO - 2021-01-07 08:58:49 --> Config Class Initialized
INFO - 2021-01-07 08:58:49 --> Loader Class Initialized
INFO - 2021-01-07 08:58:49 --> Helper loaded: url_helper
INFO - 2021-01-07 08:58:49 --> Helper loaded: file_helper
INFO - 2021-01-07 08:58:49 --> Helper loaded: form_helper
INFO - 2021-01-07 08:58:49 --> Helper loaded: my_helper
INFO - 2021-01-07 08:58:49 --> Database Driver Class Initialized
DEBUG - 2021-01-07 08:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 08:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 08:58:49 --> Controller Class Initialized
DEBUG - 2021-01-07 08:58:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 08:58:49 --> Final output sent to browser
DEBUG - 2021-01-07 08:58:49 --> Total execution time: 0.4649
INFO - 2021-01-07 09:05:00 --> Config Class Initialized
INFO - 2021-01-07 09:05:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:05:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:05:00 --> Utf8 Class Initialized
INFO - 2021-01-07 09:05:00 --> URI Class Initialized
INFO - 2021-01-07 09:05:00 --> Router Class Initialized
INFO - 2021-01-07 09:05:00 --> Output Class Initialized
INFO - 2021-01-07 09:05:00 --> Security Class Initialized
DEBUG - 2021-01-07 09:05:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:05:00 --> Input Class Initialized
INFO - 2021-01-07 09:05:00 --> Language Class Initialized
INFO - 2021-01-07 09:05:00 --> Language Class Initialized
INFO - 2021-01-07 09:05:00 --> Config Class Initialized
INFO - 2021-01-07 09:05:00 --> Loader Class Initialized
INFO - 2021-01-07 09:05:00 --> Helper loaded: url_helper
INFO - 2021-01-07 09:05:00 --> Helper loaded: file_helper
INFO - 2021-01-07 09:05:00 --> Helper loaded: form_helper
INFO - 2021-01-07 09:05:00 --> Helper loaded: my_helper
INFO - 2021-01-07 09:05:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:05:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:05:00 --> Controller Class Initialized
DEBUG - 2021-01-07 09:05:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:05:00 --> Final output sent to browser
DEBUG - 2021-01-07 09:05:00 --> Total execution time: 0.4684
INFO - 2021-01-07 09:06:12 --> Config Class Initialized
INFO - 2021-01-07 09:06:12 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:06:12 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:06:12 --> Utf8 Class Initialized
INFO - 2021-01-07 09:06:12 --> URI Class Initialized
INFO - 2021-01-07 09:06:12 --> Router Class Initialized
INFO - 2021-01-07 09:06:12 --> Output Class Initialized
INFO - 2021-01-07 09:06:12 --> Security Class Initialized
DEBUG - 2021-01-07 09:06:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:06:12 --> Input Class Initialized
INFO - 2021-01-07 09:06:12 --> Language Class Initialized
INFO - 2021-01-07 09:06:12 --> Language Class Initialized
INFO - 2021-01-07 09:06:12 --> Config Class Initialized
INFO - 2021-01-07 09:06:12 --> Loader Class Initialized
INFO - 2021-01-07 09:06:12 --> Helper loaded: url_helper
INFO - 2021-01-07 09:06:12 --> Helper loaded: file_helper
INFO - 2021-01-07 09:06:12 --> Helper loaded: form_helper
INFO - 2021-01-07 09:06:12 --> Helper loaded: my_helper
INFO - 2021-01-07 09:06:12 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:06:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:06:12 --> Controller Class Initialized
DEBUG - 2021-01-07 09:06:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:06:12 --> Final output sent to browser
DEBUG - 2021-01-07 09:06:12 --> Total execution time: 0.4028
INFO - 2021-01-07 09:06:51 --> Config Class Initialized
INFO - 2021-01-07 09:06:51 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:06:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:06:51 --> Utf8 Class Initialized
INFO - 2021-01-07 09:06:51 --> URI Class Initialized
INFO - 2021-01-07 09:06:51 --> Router Class Initialized
INFO - 2021-01-07 09:06:51 --> Output Class Initialized
INFO - 2021-01-07 09:06:51 --> Security Class Initialized
DEBUG - 2021-01-07 09:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:06:51 --> Input Class Initialized
INFO - 2021-01-07 09:06:51 --> Language Class Initialized
INFO - 2021-01-07 09:06:51 --> Language Class Initialized
INFO - 2021-01-07 09:06:51 --> Config Class Initialized
INFO - 2021-01-07 09:06:51 --> Loader Class Initialized
INFO - 2021-01-07 09:06:51 --> Helper loaded: url_helper
INFO - 2021-01-07 09:06:51 --> Helper loaded: file_helper
INFO - 2021-01-07 09:06:51 --> Helper loaded: form_helper
INFO - 2021-01-07 09:06:51 --> Helper loaded: my_helper
INFO - 2021-01-07 09:06:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:06:51 --> Controller Class Initialized
DEBUG - 2021-01-07 09:06:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:06:51 --> Final output sent to browser
DEBUG - 2021-01-07 09:06:52 --> Total execution time: 0.4267
INFO - 2021-01-07 09:08:34 --> Config Class Initialized
INFO - 2021-01-07 09:08:34 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:08:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:08:35 --> Utf8 Class Initialized
INFO - 2021-01-07 09:08:35 --> URI Class Initialized
INFO - 2021-01-07 09:08:35 --> Router Class Initialized
INFO - 2021-01-07 09:08:35 --> Output Class Initialized
INFO - 2021-01-07 09:08:35 --> Security Class Initialized
DEBUG - 2021-01-07 09:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:08:35 --> Input Class Initialized
INFO - 2021-01-07 09:08:35 --> Language Class Initialized
INFO - 2021-01-07 09:08:35 --> Language Class Initialized
INFO - 2021-01-07 09:08:35 --> Config Class Initialized
INFO - 2021-01-07 09:08:35 --> Loader Class Initialized
INFO - 2021-01-07 09:08:35 --> Helper loaded: url_helper
INFO - 2021-01-07 09:08:35 --> Helper loaded: file_helper
INFO - 2021-01-07 09:08:35 --> Helper loaded: form_helper
INFO - 2021-01-07 09:08:35 --> Helper loaded: my_helper
INFO - 2021-01-07 09:08:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:08:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:08:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:08:35 --> Controller Class Initialized
DEBUG - 2021-01-07 09:08:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:08:35 --> Final output sent to browser
DEBUG - 2021-01-07 09:08:35 --> Total execution time: 0.4101
INFO - 2021-01-07 09:09:00 --> Config Class Initialized
INFO - 2021-01-07 09:09:00 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:09:00 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:09:00 --> Utf8 Class Initialized
INFO - 2021-01-07 09:09:00 --> URI Class Initialized
INFO - 2021-01-07 09:09:00 --> Router Class Initialized
INFO - 2021-01-07 09:09:00 --> Output Class Initialized
INFO - 2021-01-07 09:09:00 --> Security Class Initialized
DEBUG - 2021-01-07 09:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:09:00 --> Input Class Initialized
INFO - 2021-01-07 09:09:00 --> Language Class Initialized
INFO - 2021-01-07 09:09:00 --> Language Class Initialized
INFO - 2021-01-07 09:09:00 --> Config Class Initialized
INFO - 2021-01-07 09:09:00 --> Loader Class Initialized
INFO - 2021-01-07 09:09:00 --> Helper loaded: url_helper
INFO - 2021-01-07 09:09:00 --> Helper loaded: file_helper
INFO - 2021-01-07 09:09:00 --> Helper loaded: form_helper
INFO - 2021-01-07 09:09:00 --> Helper loaded: my_helper
INFO - 2021-01-07 09:09:00 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:09:00 --> Controller Class Initialized
ERROR - 2021-01-07 09:09:00 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 476
DEBUG - 2021-01-07 09:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:09:00 --> Final output sent to browser
DEBUG - 2021-01-07 09:09:00 --> Total execution time: 0.4183
INFO - 2021-01-07 09:09:22 --> Config Class Initialized
INFO - 2021-01-07 09:09:22 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:09:22 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:09:22 --> Utf8 Class Initialized
INFO - 2021-01-07 09:09:22 --> URI Class Initialized
INFO - 2021-01-07 09:09:22 --> Router Class Initialized
INFO - 2021-01-07 09:09:22 --> Output Class Initialized
INFO - 2021-01-07 09:09:22 --> Security Class Initialized
DEBUG - 2021-01-07 09:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:09:22 --> Input Class Initialized
INFO - 2021-01-07 09:09:22 --> Language Class Initialized
INFO - 2021-01-07 09:09:22 --> Language Class Initialized
INFO - 2021-01-07 09:09:22 --> Config Class Initialized
INFO - 2021-01-07 09:09:22 --> Loader Class Initialized
INFO - 2021-01-07 09:09:22 --> Helper loaded: url_helper
INFO - 2021-01-07 09:09:22 --> Helper loaded: file_helper
INFO - 2021-01-07 09:09:22 --> Helper loaded: form_helper
INFO - 2021-01-07 09:09:22 --> Helper loaded: my_helper
INFO - 2021-01-07 09:09:22 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:09:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:09:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:09:22 --> Controller Class Initialized
ERROR - 2021-01-07 09:09:22 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 476
DEBUG - 2021-01-07 09:09:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:09:22 --> Final output sent to browser
DEBUG - 2021-01-07 09:09:22 --> Total execution time: 0.4984
INFO - 2021-01-07 09:09:54 --> Config Class Initialized
INFO - 2021-01-07 09:09:54 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:09:54 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:09:54 --> Utf8 Class Initialized
INFO - 2021-01-07 09:09:54 --> URI Class Initialized
INFO - 2021-01-07 09:09:54 --> Router Class Initialized
INFO - 2021-01-07 09:09:54 --> Output Class Initialized
INFO - 2021-01-07 09:09:54 --> Security Class Initialized
DEBUG - 2021-01-07 09:09:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:09:54 --> Input Class Initialized
INFO - 2021-01-07 09:09:54 --> Language Class Initialized
INFO - 2021-01-07 09:09:54 --> Language Class Initialized
INFO - 2021-01-07 09:09:54 --> Config Class Initialized
INFO - 2021-01-07 09:09:54 --> Loader Class Initialized
INFO - 2021-01-07 09:09:54 --> Helper loaded: url_helper
INFO - 2021-01-07 09:09:54 --> Helper loaded: file_helper
INFO - 2021-01-07 09:09:54 --> Helper loaded: form_helper
INFO - 2021-01-07 09:09:54 --> Helper loaded: my_helper
INFO - 2021-01-07 09:09:54 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:09:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:09:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:09:54 --> Controller Class Initialized
ERROR - 2021-01-07 09:09:54 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 476
DEBUG - 2021-01-07 09:09:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:09:54 --> Final output sent to browser
DEBUG - 2021-01-07 09:09:54 --> Total execution time: 0.4136
INFO - 2021-01-07 09:10:45 --> Config Class Initialized
INFO - 2021-01-07 09:10:45 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:10:45 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:10:45 --> Utf8 Class Initialized
INFO - 2021-01-07 09:10:45 --> URI Class Initialized
INFO - 2021-01-07 09:10:45 --> Router Class Initialized
INFO - 2021-01-07 09:10:45 --> Output Class Initialized
INFO - 2021-01-07 09:10:45 --> Security Class Initialized
DEBUG - 2021-01-07 09:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:10:45 --> Input Class Initialized
INFO - 2021-01-07 09:10:45 --> Language Class Initialized
INFO - 2021-01-07 09:10:45 --> Language Class Initialized
INFO - 2021-01-07 09:10:45 --> Config Class Initialized
INFO - 2021-01-07 09:10:45 --> Loader Class Initialized
INFO - 2021-01-07 09:10:46 --> Helper loaded: url_helper
INFO - 2021-01-07 09:10:46 --> Helper loaded: file_helper
INFO - 2021-01-07 09:10:46 --> Helper loaded: form_helper
INFO - 2021-01-07 09:10:46 --> Helper loaded: my_helper
INFO - 2021-01-07 09:10:46 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:10:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:10:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:10:46 --> Controller Class Initialized
DEBUG - 2021-01-07 09:10:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:10:46 --> Final output sent to browser
DEBUG - 2021-01-07 09:10:46 --> Total execution time: 0.4147
INFO - 2021-01-07 09:12:52 --> Config Class Initialized
INFO - 2021-01-07 09:12:52 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:12:52 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:12:52 --> Utf8 Class Initialized
INFO - 2021-01-07 09:12:52 --> URI Class Initialized
INFO - 2021-01-07 09:12:52 --> Router Class Initialized
INFO - 2021-01-07 09:12:52 --> Output Class Initialized
INFO - 2021-01-07 09:12:52 --> Security Class Initialized
DEBUG - 2021-01-07 09:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:12:52 --> Input Class Initialized
INFO - 2021-01-07 09:12:52 --> Language Class Initialized
ERROR - 2021-01-07 09:12:52 --> Severity: Parsing Error --> syntax error, unexpected 'elseif' (T_ELSEIF) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 476
INFO - 2021-01-07 09:13:01 --> Config Class Initialized
INFO - 2021-01-07 09:13:01 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:13:01 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:13:01 --> Utf8 Class Initialized
INFO - 2021-01-07 09:13:01 --> URI Class Initialized
INFO - 2021-01-07 09:13:01 --> Router Class Initialized
INFO - 2021-01-07 09:13:01 --> Output Class Initialized
INFO - 2021-01-07 09:13:01 --> Security Class Initialized
DEBUG - 2021-01-07 09:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:13:01 --> Input Class Initialized
INFO - 2021-01-07 09:13:01 --> Language Class Initialized
ERROR - 2021-01-07 09:13:01 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 509
INFO - 2021-01-07 09:28:57 --> Config Class Initialized
INFO - 2021-01-07 09:28:57 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:28:57 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:28:57 --> Utf8 Class Initialized
INFO - 2021-01-07 09:28:57 --> URI Class Initialized
INFO - 2021-01-07 09:28:57 --> Router Class Initialized
INFO - 2021-01-07 09:28:57 --> Output Class Initialized
INFO - 2021-01-07 09:28:57 --> Security Class Initialized
DEBUG - 2021-01-07 09:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:28:57 --> Input Class Initialized
INFO - 2021-01-07 09:28:57 --> Language Class Initialized
INFO - 2021-01-07 09:28:57 --> Language Class Initialized
INFO - 2021-01-07 09:28:57 --> Config Class Initialized
INFO - 2021-01-07 09:28:57 --> Loader Class Initialized
INFO - 2021-01-07 09:28:57 --> Helper loaded: url_helper
INFO - 2021-01-07 09:28:58 --> Helper loaded: file_helper
INFO - 2021-01-07 09:28:58 --> Helper loaded: form_helper
INFO - 2021-01-07 09:28:58 --> Helper loaded: my_helper
INFO - 2021-01-07 09:28:58 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:28:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:28:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:28:58 --> Controller Class Initialized
DEBUG - 2021-01-07 09:28:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:28:58 --> Final output sent to browser
DEBUG - 2021-01-07 09:28:58 --> Total execution time: 0.4204
INFO - 2021-01-07 09:29:20 --> Config Class Initialized
INFO - 2021-01-07 09:29:20 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:29:20 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:29:20 --> Utf8 Class Initialized
INFO - 2021-01-07 09:29:20 --> URI Class Initialized
INFO - 2021-01-07 09:29:20 --> Router Class Initialized
INFO - 2021-01-07 09:29:20 --> Output Class Initialized
INFO - 2021-01-07 09:29:20 --> Security Class Initialized
DEBUG - 2021-01-07 09:29:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:29:20 --> Input Class Initialized
INFO - 2021-01-07 09:29:20 --> Language Class Initialized
INFO - 2021-01-07 09:29:20 --> Language Class Initialized
INFO - 2021-01-07 09:29:20 --> Config Class Initialized
INFO - 2021-01-07 09:29:20 --> Loader Class Initialized
INFO - 2021-01-07 09:29:20 --> Helper loaded: url_helper
INFO - 2021-01-07 09:29:20 --> Helper loaded: file_helper
INFO - 2021-01-07 09:29:20 --> Helper loaded: form_helper
INFO - 2021-01-07 09:29:20 --> Helper loaded: my_helper
INFO - 2021-01-07 09:29:20 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:29:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:29:20 --> Controller Class Initialized
ERROR - 2021-01-07 09:29:20 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 478
DEBUG - 2021-01-07 09:29:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:29:20 --> Final output sent to browser
DEBUG - 2021-01-07 09:29:20 --> Total execution time: 0.4041
INFO - 2021-01-07 09:30:49 --> Config Class Initialized
INFO - 2021-01-07 09:30:49 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:30:49 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:30:49 --> Utf8 Class Initialized
INFO - 2021-01-07 09:30:49 --> URI Class Initialized
INFO - 2021-01-07 09:30:49 --> Router Class Initialized
INFO - 2021-01-07 09:30:49 --> Output Class Initialized
INFO - 2021-01-07 09:30:49 --> Security Class Initialized
DEBUG - 2021-01-07 09:30:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:30:49 --> Input Class Initialized
INFO - 2021-01-07 09:30:49 --> Language Class Initialized
INFO - 2021-01-07 09:30:49 --> Language Class Initialized
INFO - 2021-01-07 09:30:50 --> Config Class Initialized
INFO - 2021-01-07 09:30:50 --> Loader Class Initialized
INFO - 2021-01-07 09:30:50 --> Helper loaded: url_helper
INFO - 2021-01-07 09:30:50 --> Helper loaded: file_helper
INFO - 2021-01-07 09:30:50 --> Helper loaded: form_helper
INFO - 2021-01-07 09:30:50 --> Helper loaded: my_helper
INFO - 2021-01-07 09:30:50 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:30:50 --> Controller Class Initialized
ERROR - 2021-01-07 09:30:50 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 479
DEBUG - 2021-01-07 09:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:30:50 --> Final output sent to browser
DEBUG - 2021-01-07 09:30:50 --> Total execution time: 0.4025
INFO - 2021-01-07 09:33:21 --> Config Class Initialized
INFO - 2021-01-07 09:33:21 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:33:21 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:33:21 --> Utf8 Class Initialized
INFO - 2021-01-07 09:33:21 --> URI Class Initialized
INFO - 2021-01-07 09:33:21 --> Router Class Initialized
INFO - 2021-01-07 09:33:21 --> Output Class Initialized
INFO - 2021-01-07 09:33:21 --> Security Class Initialized
DEBUG - 2021-01-07 09:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:33:21 --> Input Class Initialized
INFO - 2021-01-07 09:33:21 --> Language Class Initialized
INFO - 2021-01-07 09:33:21 --> Language Class Initialized
INFO - 2021-01-07 09:33:21 --> Config Class Initialized
INFO - 2021-01-07 09:33:21 --> Loader Class Initialized
INFO - 2021-01-07 09:33:21 --> Helper loaded: url_helper
INFO - 2021-01-07 09:33:21 --> Helper loaded: file_helper
INFO - 2021-01-07 09:33:21 --> Helper loaded: form_helper
INFO - 2021-01-07 09:33:21 --> Helper loaded: my_helper
INFO - 2021-01-07 09:33:21 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:33:21 --> Controller Class Initialized
ERROR - 2021-01-07 09:33:21 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 479
DEBUG - 2021-01-07 09:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:33:21 --> Final output sent to browser
DEBUG - 2021-01-07 09:33:21 --> Total execution time: 0.4434
INFO - 2021-01-07 09:33:35 --> Config Class Initialized
INFO - 2021-01-07 09:33:35 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:33:35 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:33:35 --> Utf8 Class Initialized
INFO - 2021-01-07 09:33:35 --> URI Class Initialized
INFO - 2021-01-07 09:33:35 --> Router Class Initialized
INFO - 2021-01-07 09:33:35 --> Output Class Initialized
INFO - 2021-01-07 09:33:35 --> Security Class Initialized
DEBUG - 2021-01-07 09:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:33:35 --> Input Class Initialized
INFO - 2021-01-07 09:33:35 --> Language Class Initialized
INFO - 2021-01-07 09:33:35 --> Language Class Initialized
INFO - 2021-01-07 09:33:35 --> Config Class Initialized
INFO - 2021-01-07 09:33:35 --> Loader Class Initialized
INFO - 2021-01-07 09:33:35 --> Helper loaded: url_helper
INFO - 2021-01-07 09:33:35 --> Helper loaded: file_helper
INFO - 2021-01-07 09:33:35 --> Helper loaded: form_helper
INFO - 2021-01-07 09:33:35 --> Helper loaded: my_helper
INFO - 2021-01-07 09:33:35 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:33:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:33:36 --> Controller Class Initialized
ERROR - 2021-01-07 09:33:36 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 479
DEBUG - 2021-01-07 09:33:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:33:36 --> Final output sent to browser
DEBUG - 2021-01-07 09:33:36 --> Total execution time: 0.3957
INFO - 2021-01-07 09:34:14 --> Config Class Initialized
INFO - 2021-01-07 09:34:14 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:34:14 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:34:14 --> Utf8 Class Initialized
INFO - 2021-01-07 09:34:14 --> URI Class Initialized
INFO - 2021-01-07 09:34:14 --> Router Class Initialized
INFO - 2021-01-07 09:34:14 --> Output Class Initialized
INFO - 2021-01-07 09:34:14 --> Security Class Initialized
DEBUG - 2021-01-07 09:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:34:14 --> Input Class Initialized
INFO - 2021-01-07 09:34:14 --> Language Class Initialized
INFO - 2021-01-07 09:34:14 --> Language Class Initialized
INFO - 2021-01-07 09:34:14 --> Config Class Initialized
INFO - 2021-01-07 09:34:14 --> Loader Class Initialized
INFO - 2021-01-07 09:34:14 --> Helper loaded: url_helper
INFO - 2021-01-07 09:34:14 --> Helper loaded: file_helper
INFO - 2021-01-07 09:34:14 --> Helper loaded: form_helper
INFO - 2021-01-07 09:34:14 --> Helper loaded: my_helper
INFO - 2021-01-07 09:34:14 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:34:14 --> Controller Class Initialized
ERROR - 2021-01-07 09:34:14 --> Severity: Notice --> Undefined index: nilai_utama_TKRO C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 477
DEBUG - 2021-01-07 09:34:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:34:14 --> Final output sent to browser
DEBUG - 2021-01-07 09:34:14 --> Total execution time: 0.4405
INFO - 2021-01-07 09:34:37 --> Config Class Initialized
INFO - 2021-01-07 09:34:37 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:34:37 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:34:37 --> Utf8 Class Initialized
INFO - 2021-01-07 09:34:37 --> URI Class Initialized
INFO - 2021-01-07 09:34:37 --> Router Class Initialized
INFO - 2021-01-07 09:34:37 --> Output Class Initialized
INFO - 2021-01-07 09:34:37 --> Security Class Initialized
DEBUG - 2021-01-07 09:34:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:34:37 --> Input Class Initialized
INFO - 2021-01-07 09:34:37 --> Language Class Initialized
INFO - 2021-01-07 09:34:37 --> Language Class Initialized
INFO - 2021-01-07 09:34:37 --> Config Class Initialized
INFO - 2021-01-07 09:34:38 --> Loader Class Initialized
INFO - 2021-01-07 09:34:38 --> Helper loaded: url_helper
INFO - 2021-01-07 09:34:38 --> Helper loaded: file_helper
INFO - 2021-01-07 09:34:38 --> Helper loaded: form_helper
INFO - 2021-01-07 09:34:38 --> Helper loaded: my_helper
INFO - 2021-01-07 09:34:38 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:34:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:34:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:34:38 --> Controller Class Initialized
DEBUG - 2021-01-07 09:34:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:34:38 --> Final output sent to browser
DEBUG - 2021-01-07 09:34:38 --> Total execution time: 0.4782
INFO - 2021-01-07 09:35:53 --> Config Class Initialized
INFO - 2021-01-07 09:35:53 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:35:53 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:35:53 --> Utf8 Class Initialized
INFO - 2021-01-07 09:35:53 --> URI Class Initialized
INFO - 2021-01-07 09:35:53 --> Router Class Initialized
INFO - 2021-01-07 09:35:53 --> Output Class Initialized
INFO - 2021-01-07 09:35:53 --> Security Class Initialized
DEBUG - 2021-01-07 09:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:35:53 --> Input Class Initialized
INFO - 2021-01-07 09:35:53 --> Language Class Initialized
INFO - 2021-01-07 09:35:53 --> Language Class Initialized
INFO - 2021-01-07 09:35:53 --> Config Class Initialized
INFO - 2021-01-07 09:35:53 --> Loader Class Initialized
INFO - 2021-01-07 09:35:53 --> Helper loaded: url_helper
INFO - 2021-01-07 09:35:53 --> Helper loaded: file_helper
INFO - 2021-01-07 09:35:53 --> Helper loaded: form_helper
INFO - 2021-01-07 09:35:53 --> Helper loaded: my_helper
INFO - 2021-01-07 09:35:53 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:35:53 --> Controller Class Initialized
DEBUG - 2021-01-07 09:35:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:35:53 --> Final output sent to browser
DEBUG - 2021-01-07 09:35:53 --> Total execution time: 0.3780
INFO - 2021-01-07 09:37:41 --> Config Class Initialized
INFO - 2021-01-07 09:37:41 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:37:41 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:37:41 --> Utf8 Class Initialized
INFO - 2021-01-07 09:37:41 --> URI Class Initialized
INFO - 2021-01-07 09:37:41 --> Router Class Initialized
INFO - 2021-01-07 09:37:41 --> Output Class Initialized
INFO - 2021-01-07 09:37:41 --> Security Class Initialized
DEBUG - 2021-01-07 09:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:37:41 --> Input Class Initialized
INFO - 2021-01-07 09:37:41 --> Language Class Initialized
INFO - 2021-01-07 09:37:41 --> Language Class Initialized
INFO - 2021-01-07 09:37:41 --> Config Class Initialized
INFO - 2021-01-07 09:37:41 --> Loader Class Initialized
INFO - 2021-01-07 09:37:41 --> Helper loaded: url_helper
INFO - 2021-01-07 09:37:41 --> Helper loaded: file_helper
INFO - 2021-01-07 09:37:41 --> Helper loaded: form_helper
INFO - 2021-01-07 09:37:41 --> Helper loaded: my_helper
INFO - 2021-01-07 09:37:41 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:37:41 --> Controller Class Initialized
DEBUG - 2021-01-07 09:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:37:41 --> Final output sent to browser
DEBUG - 2021-01-07 09:37:41 --> Total execution time: 0.4670
INFO - 2021-01-07 09:38:05 --> Config Class Initialized
INFO - 2021-01-07 09:38:05 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:38:05 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:38:05 --> Utf8 Class Initialized
INFO - 2021-01-07 09:38:05 --> URI Class Initialized
INFO - 2021-01-07 09:38:05 --> Router Class Initialized
INFO - 2021-01-07 09:38:06 --> Output Class Initialized
INFO - 2021-01-07 09:38:06 --> Security Class Initialized
DEBUG - 2021-01-07 09:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:38:06 --> Input Class Initialized
INFO - 2021-01-07 09:38:06 --> Language Class Initialized
INFO - 2021-01-07 09:38:06 --> Language Class Initialized
INFO - 2021-01-07 09:38:06 --> Config Class Initialized
INFO - 2021-01-07 09:38:06 --> Loader Class Initialized
INFO - 2021-01-07 09:38:06 --> Helper loaded: url_helper
INFO - 2021-01-07 09:38:06 --> Helper loaded: file_helper
INFO - 2021-01-07 09:38:06 --> Helper loaded: form_helper
INFO - 2021-01-07 09:38:06 --> Helper loaded: my_helper
INFO - 2021-01-07 09:38:06 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:38:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:38:06 --> Controller Class Initialized
DEBUG - 2021-01-07 09:38:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:38:06 --> Final output sent to browser
DEBUG - 2021-01-07 09:38:06 --> Total execution time: 0.4709
INFO - 2021-01-07 09:40:32 --> Config Class Initialized
INFO - 2021-01-07 09:40:32 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:40:32 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:40:32 --> Utf8 Class Initialized
INFO - 2021-01-07 09:40:32 --> URI Class Initialized
INFO - 2021-01-07 09:40:32 --> Router Class Initialized
INFO - 2021-01-07 09:40:32 --> Output Class Initialized
INFO - 2021-01-07 09:40:32 --> Security Class Initialized
DEBUG - 2021-01-07 09:40:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:40:32 --> Input Class Initialized
INFO - 2021-01-07 09:40:32 --> Language Class Initialized
INFO - 2021-01-07 09:40:32 --> Language Class Initialized
INFO - 2021-01-07 09:40:32 --> Config Class Initialized
INFO - 2021-01-07 09:40:32 --> Loader Class Initialized
INFO - 2021-01-07 09:40:32 --> Helper loaded: url_helper
INFO - 2021-01-07 09:40:32 --> Helper loaded: file_helper
INFO - 2021-01-07 09:40:32 --> Helper loaded: form_helper
INFO - 2021-01-07 09:40:32 --> Helper loaded: my_helper
INFO - 2021-01-07 09:40:32 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:40:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:40:32 --> Controller Class Initialized
DEBUG - 2021-01-07 09:40:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:40:32 --> Final output sent to browser
DEBUG - 2021-01-07 09:40:32 --> Total execution time: 0.4518
INFO - 2021-01-07 09:40:55 --> Config Class Initialized
INFO - 2021-01-07 09:40:55 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:40:55 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:40:55 --> Utf8 Class Initialized
INFO - 2021-01-07 09:40:55 --> URI Class Initialized
INFO - 2021-01-07 09:40:55 --> Router Class Initialized
INFO - 2021-01-07 09:40:55 --> Output Class Initialized
INFO - 2021-01-07 09:40:55 --> Security Class Initialized
DEBUG - 2021-01-07 09:40:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:40:55 --> Input Class Initialized
INFO - 2021-01-07 09:40:55 --> Language Class Initialized
INFO - 2021-01-07 09:40:55 --> Language Class Initialized
INFO - 2021-01-07 09:40:55 --> Config Class Initialized
INFO - 2021-01-07 09:40:55 --> Loader Class Initialized
INFO - 2021-01-07 09:40:56 --> Helper loaded: url_helper
INFO - 2021-01-07 09:40:56 --> Helper loaded: file_helper
INFO - 2021-01-07 09:40:56 --> Helper loaded: form_helper
INFO - 2021-01-07 09:40:56 --> Helper loaded: my_helper
INFO - 2021-01-07 09:40:56 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:40:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:40:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:40:56 --> Controller Class Initialized
DEBUG - 2021-01-07 09:40:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:40:56 --> Final output sent to browser
DEBUG - 2021-01-07 09:40:56 --> Total execution time: 0.5429
INFO - 2021-01-07 09:41:15 --> Config Class Initialized
INFO - 2021-01-07 09:41:15 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:41:15 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:41:15 --> Utf8 Class Initialized
INFO - 2021-01-07 09:41:15 --> URI Class Initialized
INFO - 2021-01-07 09:41:15 --> Router Class Initialized
INFO - 2021-01-07 09:41:16 --> Output Class Initialized
INFO - 2021-01-07 09:41:16 --> Security Class Initialized
DEBUG - 2021-01-07 09:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:41:16 --> Input Class Initialized
INFO - 2021-01-07 09:41:16 --> Language Class Initialized
INFO - 2021-01-07 09:41:16 --> Language Class Initialized
INFO - 2021-01-07 09:41:16 --> Config Class Initialized
INFO - 2021-01-07 09:41:16 --> Loader Class Initialized
INFO - 2021-01-07 09:41:16 --> Helper loaded: url_helper
INFO - 2021-01-07 09:41:16 --> Helper loaded: file_helper
INFO - 2021-01-07 09:41:16 --> Helper loaded: form_helper
INFO - 2021-01-07 09:41:16 --> Helper loaded: my_helper
INFO - 2021-01-07 09:41:16 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:41:16 --> Controller Class Initialized
DEBUG - 2021-01-07 09:41:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:41:16 --> Final output sent to browser
DEBUG - 2021-01-07 09:41:16 --> Total execution time: 0.5360
INFO - 2021-01-07 09:42:51 --> Config Class Initialized
INFO - 2021-01-07 09:42:51 --> Hooks Class Initialized
DEBUG - 2021-01-07 09:42:51 --> UTF-8 Support Enabled
INFO - 2021-01-07 09:42:51 --> Utf8 Class Initialized
INFO - 2021-01-07 09:42:51 --> URI Class Initialized
INFO - 2021-01-07 09:42:51 --> Router Class Initialized
INFO - 2021-01-07 09:42:51 --> Output Class Initialized
INFO - 2021-01-07 09:42:51 --> Security Class Initialized
DEBUG - 2021-01-07 09:42:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-07 09:42:51 --> Input Class Initialized
INFO - 2021-01-07 09:42:51 --> Language Class Initialized
INFO - 2021-01-07 09:42:51 --> Language Class Initialized
INFO - 2021-01-07 09:42:51 --> Config Class Initialized
INFO - 2021-01-07 09:42:51 --> Loader Class Initialized
INFO - 2021-01-07 09:42:51 --> Helper loaded: url_helper
INFO - 2021-01-07 09:42:51 --> Helper loaded: file_helper
INFO - 2021-01-07 09:42:51 --> Helper loaded: form_helper
INFO - 2021-01-07 09:42:51 --> Helper loaded: my_helper
INFO - 2021-01-07 09:42:51 --> Database Driver Class Initialized
DEBUG - 2021-01-07 09:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-07 09:42:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-07 09:42:51 --> Controller Class Initialized
DEBUG - 2021-01-07 09:42:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-07 09:42:51 --> Final output sent to browser
DEBUG - 2021-01-07 09:42:51 --> Total execution time: 0.4810
