<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-06 02:09:16 --> Config Class Initialized
INFO - 2021-12-06 02:09:16 --> Hooks Class Initialized
DEBUG - 2021-12-06 02:09:17 --> UTF-8 Support Enabled
INFO - 2021-12-06 02:09:17 --> Utf8 Class Initialized
INFO - 2021-12-06 02:09:17 --> URI Class Initialized
DEBUG - 2021-12-06 02:09:17 --> No URI present. Default controller set.
INFO - 2021-12-06 02:09:17 --> Router Class Initialized
INFO - 2021-12-06 02:09:17 --> Output Class Initialized
INFO - 2021-12-06 02:09:17 --> Security Class Initialized
DEBUG - 2021-12-06 02:09:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 02:09:17 --> Input Class Initialized
INFO - 2021-12-06 02:09:17 --> Language Class Initialized
INFO - 2021-12-06 02:09:18 --> Language Class Initialized
INFO - 2021-12-06 02:09:18 --> Config Class Initialized
INFO - 2021-12-06 02:09:18 --> Loader Class Initialized
INFO - 2021-12-06 02:09:18 --> Helper loaded: url_helper
INFO - 2021-12-06 02:09:18 --> Helper loaded: file_helper
INFO - 2021-12-06 02:09:18 --> Helper loaded: form_helper
INFO - 2021-12-06 02:09:18 --> Helper loaded: my_helper
INFO - 2021-12-06 02:09:18 --> Database Driver Class Initialized
DEBUG - 2021-12-06 02:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 02:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 02:09:18 --> Controller Class Initialized
INFO - 2021-12-06 02:09:18 --> Config Class Initialized
INFO - 2021-12-06 02:09:18 --> Hooks Class Initialized
DEBUG - 2021-12-06 02:09:18 --> UTF-8 Support Enabled
INFO - 2021-12-06 02:09:18 --> Utf8 Class Initialized
INFO - 2021-12-06 02:09:18 --> URI Class Initialized
INFO - 2021-12-06 02:09:18 --> Router Class Initialized
INFO - 2021-12-06 02:09:18 --> Output Class Initialized
INFO - 2021-12-06 02:09:18 --> Security Class Initialized
DEBUG - 2021-12-06 02:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 02:09:18 --> Input Class Initialized
INFO - 2021-12-06 02:09:18 --> Language Class Initialized
INFO - 2021-12-06 02:09:18 --> Language Class Initialized
INFO - 2021-12-06 02:09:18 --> Config Class Initialized
INFO - 2021-12-06 02:09:18 --> Loader Class Initialized
INFO - 2021-12-06 02:09:18 --> Helper loaded: url_helper
INFO - 2021-12-06 02:09:18 --> Helper loaded: file_helper
INFO - 2021-12-06 02:09:18 --> Helper loaded: form_helper
INFO - 2021-12-06 02:09:18 --> Helper loaded: my_helper
INFO - 2021-12-06 02:09:18 --> Database Driver Class Initialized
DEBUG - 2021-12-06 02:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 02:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 02:09:18 --> Controller Class Initialized
DEBUG - 2021-12-06 02:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 02:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 02:09:18 --> Final output sent to browser
DEBUG - 2021-12-06 02:09:18 --> Total execution time: 0.2039
INFO - 2021-12-06 02:09:30 --> Config Class Initialized
INFO - 2021-12-06 02:09:30 --> Hooks Class Initialized
DEBUG - 2021-12-06 02:09:30 --> UTF-8 Support Enabled
INFO - 2021-12-06 02:09:30 --> Utf8 Class Initialized
INFO - 2021-12-06 02:09:30 --> URI Class Initialized
INFO - 2021-12-06 02:09:30 --> Router Class Initialized
INFO - 2021-12-06 02:09:30 --> Output Class Initialized
INFO - 2021-12-06 02:09:30 --> Security Class Initialized
DEBUG - 2021-12-06 02:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 02:09:30 --> Input Class Initialized
INFO - 2021-12-06 02:09:30 --> Language Class Initialized
INFO - 2021-12-06 02:09:30 --> Language Class Initialized
INFO - 2021-12-06 02:09:30 --> Config Class Initialized
INFO - 2021-12-06 02:09:30 --> Loader Class Initialized
INFO - 2021-12-06 02:09:30 --> Helper loaded: url_helper
INFO - 2021-12-06 02:09:30 --> Helper loaded: file_helper
INFO - 2021-12-06 02:09:30 --> Helper loaded: form_helper
INFO - 2021-12-06 02:09:30 --> Helper loaded: my_helper
INFO - 2021-12-06 02:09:30 --> Database Driver Class Initialized
DEBUG - 2021-12-06 02:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 02:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 02:09:30 --> Controller Class Initialized
INFO - 2021-12-06 02:09:30 --> Helper loaded: cookie_helper
INFO - 2021-12-06 02:09:30 --> Final output sent to browser
DEBUG - 2021-12-06 02:09:30 --> Total execution time: 0.2639
INFO - 2021-12-06 02:09:31 --> Config Class Initialized
INFO - 2021-12-06 02:09:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 02:09:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 02:09:31 --> Utf8 Class Initialized
INFO - 2021-12-06 02:09:31 --> URI Class Initialized
INFO - 2021-12-06 02:09:31 --> Router Class Initialized
INFO - 2021-12-06 02:09:31 --> Output Class Initialized
INFO - 2021-12-06 02:09:31 --> Security Class Initialized
DEBUG - 2021-12-06 02:09:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 02:09:31 --> Input Class Initialized
INFO - 2021-12-06 02:09:31 --> Language Class Initialized
INFO - 2021-12-06 02:09:31 --> Language Class Initialized
INFO - 2021-12-06 02:09:31 --> Config Class Initialized
INFO - 2021-12-06 02:09:31 --> Loader Class Initialized
INFO - 2021-12-06 02:09:31 --> Helper loaded: url_helper
INFO - 2021-12-06 02:09:31 --> Helper loaded: file_helper
INFO - 2021-12-06 02:09:31 --> Helper loaded: form_helper
INFO - 2021-12-06 02:09:31 --> Helper loaded: my_helper
INFO - 2021-12-06 02:09:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 02:09:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 02:09:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 02:09:31 --> Controller Class Initialized
DEBUG - 2021-12-06 02:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 02:09:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 02:09:33 --> Final output sent to browser
DEBUG - 2021-12-06 02:09:33 --> Total execution time: 2.6817
INFO - 2021-12-06 05:33:54 --> Config Class Initialized
INFO - 2021-12-06 05:33:54 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:33:54 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:33:54 --> Utf8 Class Initialized
INFO - 2021-12-06 05:33:54 --> URI Class Initialized
DEBUG - 2021-12-06 05:33:55 --> No URI present. Default controller set.
INFO - 2021-12-06 05:33:55 --> Router Class Initialized
INFO - 2021-12-06 05:33:55 --> Output Class Initialized
INFO - 2021-12-06 05:33:55 --> Security Class Initialized
DEBUG - 2021-12-06 05:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:33:55 --> Input Class Initialized
INFO - 2021-12-06 05:33:55 --> Language Class Initialized
INFO - 2021-12-06 05:33:55 --> Language Class Initialized
INFO - 2021-12-06 05:33:55 --> Config Class Initialized
INFO - 2021-12-06 05:33:55 --> Loader Class Initialized
INFO - 2021-12-06 05:33:55 --> Helper loaded: url_helper
INFO - 2021-12-06 05:33:56 --> Helper loaded: file_helper
INFO - 2021-12-06 05:33:56 --> Helper loaded: form_helper
INFO - 2021-12-06 05:33:56 --> Helper loaded: my_helper
INFO - 2021-12-06 05:33:56 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:33:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:33:56 --> Controller Class Initialized
INFO - 2021-12-06 05:33:56 --> Config Class Initialized
INFO - 2021-12-06 05:33:56 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:33:56 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:33:56 --> Utf8 Class Initialized
INFO - 2021-12-06 05:33:56 --> URI Class Initialized
INFO - 2021-12-06 05:33:56 --> Router Class Initialized
INFO - 2021-12-06 05:33:56 --> Output Class Initialized
INFO - 2021-12-06 05:33:56 --> Security Class Initialized
DEBUG - 2021-12-06 05:33:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:33:56 --> Input Class Initialized
INFO - 2021-12-06 05:33:56 --> Language Class Initialized
INFO - 2021-12-06 05:33:56 --> Language Class Initialized
INFO - 2021-12-06 05:33:56 --> Config Class Initialized
INFO - 2021-12-06 05:33:56 --> Loader Class Initialized
INFO - 2021-12-06 05:33:56 --> Helper loaded: url_helper
INFO - 2021-12-06 05:33:56 --> Helper loaded: file_helper
INFO - 2021-12-06 05:33:56 --> Helper loaded: form_helper
INFO - 2021-12-06 05:33:56 --> Helper loaded: my_helper
INFO - 2021-12-06 05:33:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:33:57 --> Controller Class Initialized
DEBUG - 2021-12-06 05:33:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 05:33:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 05:33:57 --> Final output sent to browser
DEBUG - 2021-12-06 05:33:57 --> Total execution time: 0.4674
INFO - 2021-12-06 05:34:02 --> Config Class Initialized
INFO - 2021-12-06 05:34:02 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:34:02 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:34:02 --> Utf8 Class Initialized
INFO - 2021-12-06 05:34:02 --> URI Class Initialized
INFO - 2021-12-06 05:34:02 --> Router Class Initialized
INFO - 2021-12-06 05:34:02 --> Output Class Initialized
INFO - 2021-12-06 05:34:02 --> Security Class Initialized
DEBUG - 2021-12-06 05:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:34:02 --> Input Class Initialized
INFO - 2021-12-06 05:34:02 --> Language Class Initialized
INFO - 2021-12-06 05:34:02 --> Language Class Initialized
INFO - 2021-12-06 05:34:02 --> Config Class Initialized
INFO - 2021-12-06 05:34:02 --> Loader Class Initialized
INFO - 2021-12-06 05:34:02 --> Helper loaded: url_helper
INFO - 2021-12-06 05:34:02 --> Helper loaded: file_helper
INFO - 2021-12-06 05:34:02 --> Helper loaded: form_helper
INFO - 2021-12-06 05:34:02 --> Helper loaded: my_helper
INFO - 2021-12-06 05:34:02 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:34:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:34:02 --> Controller Class Initialized
INFO - 2021-12-06 05:34:02 --> Helper loaded: cookie_helper
INFO - 2021-12-06 05:34:02 --> Final output sent to browser
DEBUG - 2021-12-06 05:34:02 --> Total execution time: 0.2685
INFO - 2021-12-06 05:34:03 --> Config Class Initialized
INFO - 2021-12-06 05:34:03 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:34:03 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:34:03 --> Utf8 Class Initialized
INFO - 2021-12-06 05:34:03 --> URI Class Initialized
INFO - 2021-12-06 05:34:03 --> Router Class Initialized
INFO - 2021-12-06 05:34:03 --> Output Class Initialized
INFO - 2021-12-06 05:34:03 --> Security Class Initialized
DEBUG - 2021-12-06 05:34:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:34:03 --> Input Class Initialized
INFO - 2021-12-06 05:34:03 --> Language Class Initialized
INFO - 2021-12-06 05:34:03 --> Language Class Initialized
INFO - 2021-12-06 05:34:03 --> Config Class Initialized
INFO - 2021-12-06 05:34:03 --> Loader Class Initialized
INFO - 2021-12-06 05:34:03 --> Helper loaded: url_helper
INFO - 2021-12-06 05:34:03 --> Helper loaded: file_helper
INFO - 2021-12-06 05:34:03 --> Helper loaded: form_helper
INFO - 2021-12-06 05:34:03 --> Helper loaded: my_helper
INFO - 2021-12-06 05:34:03 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:34:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:34:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:34:03 --> Controller Class Initialized
DEBUG - 2021-12-06 05:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 05:34:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 05:34:06 --> Final output sent to browser
DEBUG - 2021-12-06 05:34:06 --> Total execution time: 2.8282
INFO - 2021-12-06 05:35:32 --> Config Class Initialized
INFO - 2021-12-06 05:35:32 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:35:32 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:35:32 --> Utf8 Class Initialized
INFO - 2021-12-06 05:35:32 --> URI Class Initialized
INFO - 2021-12-06 05:35:32 --> Router Class Initialized
INFO - 2021-12-06 05:35:32 --> Output Class Initialized
INFO - 2021-12-06 05:35:32 --> Security Class Initialized
DEBUG - 2021-12-06 05:35:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:35:32 --> Input Class Initialized
INFO - 2021-12-06 05:35:32 --> Language Class Initialized
INFO - 2021-12-06 05:35:32 --> Language Class Initialized
INFO - 2021-12-06 05:35:32 --> Config Class Initialized
INFO - 2021-12-06 05:35:32 --> Loader Class Initialized
INFO - 2021-12-06 05:35:32 --> Helper loaded: url_helper
INFO - 2021-12-06 05:35:32 --> Helper loaded: file_helper
INFO - 2021-12-06 05:35:32 --> Helper loaded: form_helper
INFO - 2021-12-06 05:35:32 --> Helper loaded: my_helper
INFO - 2021-12-06 05:35:33 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:35:33 --> Controller Class Initialized
DEBUG - 2021-12-06 05:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-06 05:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 05:35:33 --> Final output sent to browser
DEBUG - 2021-12-06 05:35:33 --> Total execution time: 0.3655
INFO - 2021-12-06 05:35:35 --> Config Class Initialized
INFO - 2021-12-06 05:35:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:35:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:35:35 --> Utf8 Class Initialized
INFO - 2021-12-06 05:35:35 --> URI Class Initialized
INFO - 2021-12-06 05:35:35 --> Router Class Initialized
INFO - 2021-12-06 05:35:35 --> Output Class Initialized
INFO - 2021-12-06 05:35:35 --> Security Class Initialized
DEBUG - 2021-12-06 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:35:35 --> Input Class Initialized
INFO - 2021-12-06 05:35:35 --> Language Class Initialized
INFO - 2021-12-06 05:35:35 --> Language Class Initialized
INFO - 2021-12-06 05:35:35 --> Config Class Initialized
INFO - 2021-12-06 05:35:35 --> Loader Class Initialized
INFO - 2021-12-06 05:35:35 --> Helper loaded: url_helper
INFO - 2021-12-06 05:35:35 --> Helper loaded: file_helper
INFO - 2021-12-06 05:35:35 --> Helper loaded: form_helper
INFO - 2021-12-06 05:35:35 --> Helper loaded: my_helper
INFO - 2021-12-06 05:35:35 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:35:35 --> Controller Class Initialized
DEBUG - 2021-12-06 05:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:35:36 --> Final output sent to browser
DEBUG - 2021-12-06 05:35:36 --> Total execution time: 0.5075
INFO - 2021-12-06 05:40:15 --> Config Class Initialized
INFO - 2021-12-06 05:40:15 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:40:15 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:40:15 --> Utf8 Class Initialized
INFO - 2021-12-06 05:40:15 --> URI Class Initialized
INFO - 2021-12-06 05:40:15 --> Router Class Initialized
INFO - 2021-12-06 05:40:15 --> Output Class Initialized
INFO - 2021-12-06 05:40:15 --> Security Class Initialized
DEBUG - 2021-12-06 05:40:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:40:16 --> Input Class Initialized
INFO - 2021-12-06 05:40:16 --> Language Class Initialized
INFO - 2021-12-06 05:40:16 --> Language Class Initialized
INFO - 2021-12-06 05:40:16 --> Config Class Initialized
INFO - 2021-12-06 05:40:16 --> Loader Class Initialized
INFO - 2021-12-06 05:40:16 --> Helper loaded: url_helper
INFO - 2021-12-06 05:40:16 --> Helper loaded: file_helper
INFO - 2021-12-06 05:40:16 --> Helper loaded: form_helper
INFO - 2021-12-06 05:40:16 --> Helper loaded: my_helper
INFO - 2021-12-06 05:40:16 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:40:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:40:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:40:16 --> Controller Class Initialized
DEBUG - 2021-12-06 05:40:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:40:16 --> Final output sent to browser
DEBUG - 2021-12-06 05:40:16 --> Total execution time: 0.4116
INFO - 2021-12-06 05:40:22 --> Config Class Initialized
INFO - 2021-12-06 05:40:22 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:40:22 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:40:22 --> Utf8 Class Initialized
INFO - 2021-12-06 05:40:22 --> URI Class Initialized
INFO - 2021-12-06 05:40:22 --> Router Class Initialized
INFO - 2021-12-06 05:40:22 --> Output Class Initialized
INFO - 2021-12-06 05:40:22 --> Security Class Initialized
DEBUG - 2021-12-06 05:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:40:22 --> Input Class Initialized
INFO - 2021-12-06 05:40:22 --> Language Class Initialized
INFO - 2021-12-06 05:40:22 --> Language Class Initialized
INFO - 2021-12-06 05:40:22 --> Config Class Initialized
INFO - 2021-12-06 05:40:22 --> Loader Class Initialized
INFO - 2021-12-06 05:40:22 --> Helper loaded: url_helper
INFO - 2021-12-06 05:40:22 --> Helper loaded: file_helper
INFO - 2021-12-06 05:40:22 --> Helper loaded: form_helper
INFO - 2021-12-06 05:40:22 --> Helper loaded: my_helper
INFO - 2021-12-06 05:40:22 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:40:22 --> Controller Class Initialized
DEBUG - 2021-12-06 05:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:40:22 --> Final output sent to browser
DEBUG - 2021-12-06 05:40:22 --> Total execution time: 0.4059
INFO - 2021-12-06 05:43:31 --> Config Class Initialized
INFO - 2021-12-06 05:43:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:43:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:43:31 --> Utf8 Class Initialized
INFO - 2021-12-06 05:43:31 --> URI Class Initialized
INFO - 2021-12-06 05:43:31 --> Router Class Initialized
INFO - 2021-12-06 05:43:31 --> Output Class Initialized
INFO - 2021-12-06 05:43:31 --> Security Class Initialized
DEBUG - 2021-12-06 05:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:43:31 --> Input Class Initialized
INFO - 2021-12-06 05:43:31 --> Language Class Initialized
INFO - 2021-12-06 05:43:31 --> Language Class Initialized
INFO - 2021-12-06 05:43:31 --> Config Class Initialized
INFO - 2021-12-06 05:43:31 --> Loader Class Initialized
INFO - 2021-12-06 05:43:31 --> Helper loaded: url_helper
INFO - 2021-12-06 05:43:31 --> Helper loaded: file_helper
INFO - 2021-12-06 05:43:31 --> Helper loaded: form_helper
INFO - 2021-12-06 05:43:31 --> Helper loaded: my_helper
INFO - 2021-12-06 05:43:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:43:31 --> Controller Class Initialized
DEBUG - 2021-12-06 05:43:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:43:31 --> Final output sent to browser
DEBUG - 2021-12-06 05:43:31 --> Total execution time: 0.4092
INFO - 2021-12-06 05:43:47 --> Config Class Initialized
INFO - 2021-12-06 05:43:47 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:43:47 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:43:47 --> Utf8 Class Initialized
INFO - 2021-12-06 05:43:47 --> URI Class Initialized
INFO - 2021-12-06 05:43:47 --> Router Class Initialized
INFO - 2021-12-06 05:43:47 --> Output Class Initialized
INFO - 2021-12-06 05:43:47 --> Security Class Initialized
DEBUG - 2021-12-06 05:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:43:47 --> Input Class Initialized
INFO - 2021-12-06 05:43:47 --> Language Class Initialized
INFO - 2021-12-06 05:43:47 --> Language Class Initialized
INFO - 2021-12-06 05:43:47 --> Config Class Initialized
INFO - 2021-12-06 05:43:47 --> Loader Class Initialized
INFO - 2021-12-06 05:43:47 --> Helper loaded: url_helper
INFO - 2021-12-06 05:43:47 --> Helper loaded: file_helper
INFO - 2021-12-06 05:43:47 --> Helper loaded: form_helper
INFO - 2021-12-06 05:43:47 --> Helper loaded: my_helper
INFO - 2021-12-06 05:43:47 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:43:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:43:47 --> Controller Class Initialized
DEBUG - 2021-12-06 05:43:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:43:47 --> Final output sent to browser
DEBUG - 2021-12-06 05:43:47 --> Total execution time: 0.4058
INFO - 2021-12-06 05:46:21 --> Config Class Initialized
INFO - 2021-12-06 05:46:21 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:46:21 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:46:21 --> Utf8 Class Initialized
INFO - 2021-12-06 05:46:21 --> URI Class Initialized
INFO - 2021-12-06 05:46:21 --> Router Class Initialized
INFO - 2021-12-06 05:46:21 --> Output Class Initialized
INFO - 2021-12-06 05:46:21 --> Security Class Initialized
DEBUG - 2021-12-06 05:46:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:46:21 --> Input Class Initialized
INFO - 2021-12-06 05:46:21 --> Language Class Initialized
INFO - 2021-12-06 05:46:21 --> Language Class Initialized
INFO - 2021-12-06 05:46:21 --> Config Class Initialized
INFO - 2021-12-06 05:46:21 --> Loader Class Initialized
INFO - 2021-12-06 05:46:21 --> Helper loaded: url_helper
INFO - 2021-12-06 05:46:21 --> Helper loaded: file_helper
INFO - 2021-12-06 05:46:21 --> Helper loaded: form_helper
INFO - 2021-12-06 05:46:21 --> Helper loaded: my_helper
INFO - 2021-12-06 05:46:21 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:46:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:46:21 --> Controller Class Initialized
DEBUG - 2021-12-06 05:46:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:46:21 --> Final output sent to browser
DEBUG - 2021-12-06 05:46:21 --> Total execution time: 0.3997
INFO - 2021-12-06 05:47:06 --> Config Class Initialized
INFO - 2021-12-06 05:47:06 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:47:06 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:47:06 --> Utf8 Class Initialized
INFO - 2021-12-06 05:47:06 --> URI Class Initialized
INFO - 2021-12-06 05:47:06 --> Router Class Initialized
INFO - 2021-12-06 05:47:06 --> Output Class Initialized
INFO - 2021-12-06 05:47:06 --> Security Class Initialized
DEBUG - 2021-12-06 05:47:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:47:06 --> Input Class Initialized
INFO - 2021-12-06 05:47:06 --> Language Class Initialized
INFO - 2021-12-06 05:47:06 --> Language Class Initialized
INFO - 2021-12-06 05:47:06 --> Config Class Initialized
INFO - 2021-12-06 05:47:06 --> Loader Class Initialized
INFO - 2021-12-06 05:47:06 --> Helper loaded: url_helper
INFO - 2021-12-06 05:47:06 --> Helper loaded: file_helper
INFO - 2021-12-06 05:47:06 --> Helper loaded: form_helper
INFO - 2021-12-06 05:47:06 --> Helper loaded: my_helper
INFO - 2021-12-06 05:47:06 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:47:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:47:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:47:06 --> Controller Class Initialized
DEBUG - 2021-12-06 05:47:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:47:07 --> Final output sent to browser
DEBUG - 2021-12-06 05:47:07 --> Total execution time: 0.3775
INFO - 2021-12-06 05:47:29 --> Config Class Initialized
INFO - 2021-12-06 05:47:29 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:47:29 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:47:29 --> Utf8 Class Initialized
INFO - 2021-12-06 05:47:29 --> URI Class Initialized
INFO - 2021-12-06 05:47:29 --> Router Class Initialized
INFO - 2021-12-06 05:47:29 --> Output Class Initialized
INFO - 2021-12-06 05:47:29 --> Security Class Initialized
DEBUG - 2021-12-06 05:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:47:29 --> Input Class Initialized
INFO - 2021-12-06 05:47:29 --> Language Class Initialized
INFO - 2021-12-06 05:47:29 --> Language Class Initialized
INFO - 2021-12-06 05:47:29 --> Config Class Initialized
INFO - 2021-12-06 05:47:29 --> Loader Class Initialized
INFO - 2021-12-06 05:47:29 --> Helper loaded: url_helper
INFO - 2021-12-06 05:47:29 --> Helper loaded: file_helper
INFO - 2021-12-06 05:47:29 --> Helper loaded: form_helper
INFO - 2021-12-06 05:47:29 --> Helper loaded: my_helper
INFO - 2021-12-06 05:47:29 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:47:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:47:29 --> Controller Class Initialized
DEBUG - 2021-12-06 05:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:47:30 --> Final output sent to browser
DEBUG - 2021-12-06 05:47:30 --> Total execution time: 0.4304
INFO - 2021-12-06 05:47:40 --> Config Class Initialized
INFO - 2021-12-06 05:47:40 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:47:40 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:47:40 --> Utf8 Class Initialized
INFO - 2021-12-06 05:47:40 --> URI Class Initialized
INFO - 2021-12-06 05:47:40 --> Router Class Initialized
INFO - 2021-12-06 05:47:40 --> Output Class Initialized
INFO - 2021-12-06 05:47:40 --> Security Class Initialized
DEBUG - 2021-12-06 05:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:47:40 --> Input Class Initialized
INFO - 2021-12-06 05:47:40 --> Language Class Initialized
INFO - 2021-12-06 05:47:40 --> Language Class Initialized
INFO - 2021-12-06 05:47:40 --> Config Class Initialized
INFO - 2021-12-06 05:47:40 --> Loader Class Initialized
INFO - 2021-12-06 05:47:40 --> Helper loaded: url_helper
INFO - 2021-12-06 05:47:40 --> Helper loaded: file_helper
INFO - 2021-12-06 05:47:40 --> Helper loaded: form_helper
INFO - 2021-12-06 05:47:40 --> Helper loaded: my_helper
INFO - 2021-12-06 05:47:40 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:47:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:47:40 --> Controller Class Initialized
DEBUG - 2021-12-06 05:47:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:47:41 --> Final output sent to browser
DEBUG - 2021-12-06 05:47:41 --> Total execution time: 0.3654
INFO - 2021-12-06 05:47:59 --> Config Class Initialized
INFO - 2021-12-06 05:47:59 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:47:59 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:47:59 --> Utf8 Class Initialized
INFO - 2021-12-06 05:47:59 --> URI Class Initialized
INFO - 2021-12-06 05:47:59 --> Router Class Initialized
INFO - 2021-12-06 05:47:59 --> Output Class Initialized
INFO - 2021-12-06 05:47:59 --> Security Class Initialized
DEBUG - 2021-12-06 05:47:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:47:59 --> Input Class Initialized
INFO - 2021-12-06 05:47:59 --> Language Class Initialized
INFO - 2021-12-06 05:47:59 --> Language Class Initialized
INFO - 2021-12-06 05:47:59 --> Config Class Initialized
INFO - 2021-12-06 05:47:59 --> Loader Class Initialized
INFO - 2021-12-06 05:47:59 --> Helper loaded: url_helper
INFO - 2021-12-06 05:47:59 --> Helper loaded: file_helper
INFO - 2021-12-06 05:47:59 --> Helper loaded: form_helper
INFO - 2021-12-06 05:47:59 --> Helper loaded: my_helper
INFO - 2021-12-06 05:47:59 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:47:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:47:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:47:59 --> Controller Class Initialized
DEBUG - 2021-12-06 05:48:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:48:00 --> Final output sent to browser
DEBUG - 2021-12-06 05:48:00 --> Total execution time: 0.3806
INFO - 2021-12-06 05:48:25 --> Config Class Initialized
INFO - 2021-12-06 05:48:25 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:48:25 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:48:25 --> Utf8 Class Initialized
INFO - 2021-12-06 05:48:25 --> URI Class Initialized
INFO - 2021-12-06 05:48:25 --> Router Class Initialized
INFO - 2021-12-06 05:48:25 --> Output Class Initialized
INFO - 2021-12-06 05:48:26 --> Security Class Initialized
DEBUG - 2021-12-06 05:48:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:48:26 --> Input Class Initialized
INFO - 2021-12-06 05:48:26 --> Language Class Initialized
INFO - 2021-12-06 05:48:26 --> Language Class Initialized
INFO - 2021-12-06 05:48:26 --> Config Class Initialized
INFO - 2021-12-06 05:48:26 --> Loader Class Initialized
INFO - 2021-12-06 05:48:26 --> Helper loaded: url_helper
INFO - 2021-12-06 05:48:26 --> Helper loaded: file_helper
INFO - 2021-12-06 05:48:26 --> Helper loaded: form_helper
INFO - 2021-12-06 05:48:26 --> Helper loaded: my_helper
INFO - 2021-12-06 05:48:26 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:48:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:48:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:48:26 --> Controller Class Initialized
DEBUG - 2021-12-06 05:48:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:48:26 --> Final output sent to browser
DEBUG - 2021-12-06 05:48:26 --> Total execution time: 0.4263
INFO - 2021-12-06 05:48:46 --> Config Class Initialized
INFO - 2021-12-06 05:48:46 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:48:46 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:48:46 --> Utf8 Class Initialized
INFO - 2021-12-06 05:48:46 --> URI Class Initialized
INFO - 2021-12-06 05:48:46 --> Router Class Initialized
INFO - 2021-12-06 05:48:46 --> Output Class Initialized
INFO - 2021-12-06 05:48:46 --> Security Class Initialized
DEBUG - 2021-12-06 05:48:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:48:46 --> Input Class Initialized
INFO - 2021-12-06 05:48:46 --> Language Class Initialized
INFO - 2021-12-06 05:48:46 --> Language Class Initialized
INFO - 2021-12-06 05:48:46 --> Config Class Initialized
INFO - 2021-12-06 05:48:46 --> Loader Class Initialized
INFO - 2021-12-06 05:48:46 --> Helper loaded: url_helper
INFO - 2021-12-06 05:48:46 --> Helper loaded: file_helper
INFO - 2021-12-06 05:48:46 --> Helper loaded: form_helper
INFO - 2021-12-06 05:48:46 --> Helper loaded: my_helper
INFO - 2021-12-06 05:48:46 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:48:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:48:46 --> Controller Class Initialized
DEBUG - 2021-12-06 05:48:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:48:46 --> Final output sent to browser
DEBUG - 2021-12-06 05:48:46 --> Total execution time: 0.3895
INFO - 2021-12-06 05:49:22 --> Config Class Initialized
INFO - 2021-12-06 05:49:22 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:49:22 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:49:22 --> Utf8 Class Initialized
INFO - 2021-12-06 05:49:22 --> URI Class Initialized
INFO - 2021-12-06 05:49:22 --> Router Class Initialized
INFO - 2021-12-06 05:49:22 --> Output Class Initialized
INFO - 2021-12-06 05:49:22 --> Security Class Initialized
DEBUG - 2021-12-06 05:49:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:49:22 --> Input Class Initialized
INFO - 2021-12-06 05:49:22 --> Language Class Initialized
INFO - 2021-12-06 05:49:22 --> Language Class Initialized
INFO - 2021-12-06 05:49:22 --> Config Class Initialized
INFO - 2021-12-06 05:49:22 --> Loader Class Initialized
INFO - 2021-12-06 05:49:22 --> Helper loaded: url_helper
INFO - 2021-12-06 05:49:22 --> Helper loaded: file_helper
INFO - 2021-12-06 05:49:22 --> Helper loaded: form_helper
INFO - 2021-12-06 05:49:22 --> Helper loaded: my_helper
INFO - 2021-12-06 05:49:22 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:49:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:49:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:49:22 --> Controller Class Initialized
DEBUG - 2021-12-06 05:49:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:49:22 --> Final output sent to browser
DEBUG - 2021-12-06 05:49:22 --> Total execution time: 0.3900
INFO - 2021-12-06 05:49:41 --> Config Class Initialized
INFO - 2021-12-06 05:49:41 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:49:41 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:49:41 --> Utf8 Class Initialized
INFO - 2021-12-06 05:49:41 --> URI Class Initialized
INFO - 2021-12-06 05:49:41 --> Router Class Initialized
INFO - 2021-12-06 05:49:41 --> Output Class Initialized
INFO - 2021-12-06 05:49:41 --> Security Class Initialized
DEBUG - 2021-12-06 05:49:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:49:41 --> Input Class Initialized
INFO - 2021-12-06 05:49:41 --> Language Class Initialized
INFO - 2021-12-06 05:49:41 --> Language Class Initialized
INFO - 2021-12-06 05:49:41 --> Config Class Initialized
INFO - 2021-12-06 05:49:41 --> Loader Class Initialized
INFO - 2021-12-06 05:49:41 --> Helper loaded: url_helper
INFO - 2021-12-06 05:49:41 --> Helper loaded: file_helper
INFO - 2021-12-06 05:49:41 --> Helper loaded: form_helper
INFO - 2021-12-06 05:49:41 --> Helper loaded: my_helper
INFO - 2021-12-06 05:49:41 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:49:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:49:41 --> Controller Class Initialized
DEBUG - 2021-12-06 05:49:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:49:41 --> Final output sent to browser
DEBUG - 2021-12-06 05:49:41 --> Total execution time: 0.4309
INFO - 2021-12-06 05:49:54 --> Config Class Initialized
INFO - 2021-12-06 05:49:54 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:49:54 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:49:54 --> Utf8 Class Initialized
INFO - 2021-12-06 05:49:54 --> URI Class Initialized
INFO - 2021-12-06 05:49:54 --> Router Class Initialized
INFO - 2021-12-06 05:49:54 --> Output Class Initialized
INFO - 2021-12-06 05:49:54 --> Security Class Initialized
DEBUG - 2021-12-06 05:49:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:49:54 --> Input Class Initialized
INFO - 2021-12-06 05:49:54 --> Language Class Initialized
INFO - 2021-12-06 05:49:54 --> Language Class Initialized
INFO - 2021-12-06 05:49:54 --> Config Class Initialized
INFO - 2021-12-06 05:49:54 --> Loader Class Initialized
INFO - 2021-12-06 05:49:54 --> Helper loaded: url_helper
INFO - 2021-12-06 05:49:54 --> Helper loaded: file_helper
INFO - 2021-12-06 05:49:54 --> Helper loaded: form_helper
INFO - 2021-12-06 05:49:54 --> Helper loaded: my_helper
INFO - 2021-12-06 05:49:54 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:49:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:49:54 --> Controller Class Initialized
DEBUG - 2021-12-06 05:49:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:49:54 --> Final output sent to browser
DEBUG - 2021-12-06 05:49:54 --> Total execution time: 0.3903
INFO - 2021-12-06 05:51:07 --> Config Class Initialized
INFO - 2021-12-06 05:51:07 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:51:07 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:51:07 --> Utf8 Class Initialized
INFO - 2021-12-06 05:51:07 --> URI Class Initialized
INFO - 2021-12-06 05:51:07 --> Router Class Initialized
INFO - 2021-12-06 05:51:07 --> Output Class Initialized
INFO - 2021-12-06 05:51:07 --> Security Class Initialized
DEBUG - 2021-12-06 05:51:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:51:07 --> Input Class Initialized
INFO - 2021-12-06 05:51:07 --> Language Class Initialized
INFO - 2021-12-06 05:51:07 --> Language Class Initialized
INFO - 2021-12-06 05:51:07 --> Config Class Initialized
INFO - 2021-12-06 05:51:07 --> Loader Class Initialized
INFO - 2021-12-06 05:51:07 --> Helper loaded: url_helper
INFO - 2021-12-06 05:51:07 --> Helper loaded: file_helper
INFO - 2021-12-06 05:51:07 --> Helper loaded: form_helper
INFO - 2021-12-06 05:51:07 --> Helper loaded: my_helper
INFO - 2021-12-06 05:51:07 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:51:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:51:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:51:07 --> Controller Class Initialized
DEBUG - 2021-12-06 05:51:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:51:07 --> Final output sent to browser
DEBUG - 2021-12-06 05:51:07 --> Total execution time: 0.4076
INFO - 2021-12-06 05:53:14 --> Config Class Initialized
INFO - 2021-12-06 05:53:14 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:53:14 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:53:14 --> Utf8 Class Initialized
INFO - 2021-12-06 05:53:14 --> URI Class Initialized
INFO - 2021-12-06 05:53:14 --> Router Class Initialized
INFO - 2021-12-06 05:53:14 --> Output Class Initialized
INFO - 2021-12-06 05:53:14 --> Security Class Initialized
DEBUG - 2021-12-06 05:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:53:14 --> Input Class Initialized
INFO - 2021-12-06 05:53:14 --> Language Class Initialized
INFO - 2021-12-06 05:53:15 --> Language Class Initialized
INFO - 2021-12-06 05:53:15 --> Config Class Initialized
INFO - 2021-12-06 05:53:15 --> Loader Class Initialized
INFO - 2021-12-06 05:53:15 --> Helper loaded: url_helper
INFO - 2021-12-06 05:53:15 --> Helper loaded: file_helper
INFO - 2021-12-06 05:53:15 --> Helper loaded: form_helper
INFO - 2021-12-06 05:53:15 --> Helper loaded: my_helper
INFO - 2021-12-06 05:53:15 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:53:15 --> Controller Class Initialized
DEBUG - 2021-12-06 05:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:53:15 --> Final output sent to browser
DEBUG - 2021-12-06 05:53:15 --> Total execution time: 0.3513
INFO - 2021-12-06 05:53:38 --> Config Class Initialized
INFO - 2021-12-06 05:53:38 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:53:38 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:53:38 --> Utf8 Class Initialized
INFO - 2021-12-06 05:53:38 --> URI Class Initialized
INFO - 2021-12-06 05:53:38 --> Router Class Initialized
INFO - 2021-12-06 05:53:38 --> Output Class Initialized
INFO - 2021-12-06 05:53:38 --> Security Class Initialized
DEBUG - 2021-12-06 05:53:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:53:38 --> Input Class Initialized
INFO - 2021-12-06 05:53:38 --> Language Class Initialized
INFO - 2021-12-06 05:53:38 --> Language Class Initialized
INFO - 2021-12-06 05:53:38 --> Config Class Initialized
INFO - 2021-12-06 05:53:38 --> Loader Class Initialized
INFO - 2021-12-06 05:53:38 --> Helper loaded: url_helper
INFO - 2021-12-06 05:53:38 --> Helper loaded: file_helper
INFO - 2021-12-06 05:53:38 --> Helper loaded: form_helper
INFO - 2021-12-06 05:53:38 --> Helper loaded: my_helper
INFO - 2021-12-06 05:53:38 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:53:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:53:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:53:38 --> Controller Class Initialized
DEBUG - 2021-12-06 05:53:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:53:39 --> Final output sent to browser
DEBUG - 2021-12-06 05:53:39 --> Total execution time: 0.4064
INFO - 2021-12-06 05:54:21 --> Config Class Initialized
INFO - 2021-12-06 05:54:21 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:54:21 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:54:21 --> Utf8 Class Initialized
INFO - 2021-12-06 05:54:21 --> URI Class Initialized
INFO - 2021-12-06 05:54:21 --> Router Class Initialized
INFO - 2021-12-06 05:54:21 --> Output Class Initialized
INFO - 2021-12-06 05:54:21 --> Security Class Initialized
DEBUG - 2021-12-06 05:54:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:54:21 --> Input Class Initialized
INFO - 2021-12-06 05:54:21 --> Language Class Initialized
INFO - 2021-12-06 05:54:21 --> Language Class Initialized
INFO - 2021-12-06 05:54:21 --> Config Class Initialized
INFO - 2021-12-06 05:54:21 --> Loader Class Initialized
INFO - 2021-12-06 05:54:21 --> Helper loaded: url_helper
INFO - 2021-12-06 05:54:21 --> Helper loaded: file_helper
INFO - 2021-12-06 05:54:21 --> Helper loaded: form_helper
INFO - 2021-12-06 05:54:21 --> Helper loaded: my_helper
INFO - 2021-12-06 05:54:21 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:54:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:54:21 --> Controller Class Initialized
DEBUG - 2021-12-06 05:54:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:54:22 --> Final output sent to browser
DEBUG - 2021-12-06 05:54:22 --> Total execution time: 0.3737
INFO - 2021-12-06 05:54:37 --> Config Class Initialized
INFO - 2021-12-06 05:54:37 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:54:37 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:54:37 --> Utf8 Class Initialized
INFO - 2021-12-06 05:54:37 --> URI Class Initialized
INFO - 2021-12-06 05:54:37 --> Router Class Initialized
INFO - 2021-12-06 05:54:37 --> Output Class Initialized
INFO - 2021-12-06 05:54:37 --> Security Class Initialized
DEBUG - 2021-12-06 05:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:54:37 --> Input Class Initialized
INFO - 2021-12-06 05:54:37 --> Language Class Initialized
INFO - 2021-12-06 05:54:37 --> Language Class Initialized
INFO - 2021-12-06 05:54:37 --> Config Class Initialized
INFO - 2021-12-06 05:54:37 --> Loader Class Initialized
INFO - 2021-12-06 05:54:37 --> Helper loaded: url_helper
INFO - 2021-12-06 05:54:37 --> Helper loaded: file_helper
INFO - 2021-12-06 05:54:37 --> Helper loaded: form_helper
INFO - 2021-12-06 05:54:37 --> Helper loaded: my_helper
INFO - 2021-12-06 05:54:37 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:54:37 --> Controller Class Initialized
DEBUG - 2021-12-06 05:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:54:37 --> Final output sent to browser
DEBUG - 2021-12-06 05:54:37 --> Total execution time: 0.3978
INFO - 2021-12-06 05:54:58 --> Config Class Initialized
INFO - 2021-12-06 05:54:58 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:54:58 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:54:58 --> Utf8 Class Initialized
INFO - 2021-12-06 05:54:58 --> URI Class Initialized
INFO - 2021-12-06 05:54:58 --> Router Class Initialized
INFO - 2021-12-06 05:54:58 --> Output Class Initialized
INFO - 2021-12-06 05:54:58 --> Security Class Initialized
DEBUG - 2021-12-06 05:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:54:58 --> Input Class Initialized
INFO - 2021-12-06 05:54:58 --> Language Class Initialized
INFO - 2021-12-06 05:54:58 --> Language Class Initialized
INFO - 2021-12-06 05:54:58 --> Config Class Initialized
INFO - 2021-12-06 05:54:58 --> Loader Class Initialized
INFO - 2021-12-06 05:54:58 --> Helper loaded: url_helper
INFO - 2021-12-06 05:54:58 --> Helper loaded: file_helper
INFO - 2021-12-06 05:54:58 --> Helper loaded: form_helper
INFO - 2021-12-06 05:54:58 --> Helper loaded: my_helper
INFO - 2021-12-06 05:54:58 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:54:58 --> Controller Class Initialized
DEBUG - 2021-12-06 05:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:54:58 --> Final output sent to browser
DEBUG - 2021-12-06 05:54:58 --> Total execution time: 0.4831
INFO - 2021-12-06 05:56:41 --> Config Class Initialized
INFO - 2021-12-06 05:56:41 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:56:41 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:56:41 --> Utf8 Class Initialized
INFO - 2021-12-06 05:56:41 --> URI Class Initialized
INFO - 2021-12-06 05:56:41 --> Router Class Initialized
INFO - 2021-12-06 05:56:41 --> Output Class Initialized
INFO - 2021-12-06 05:56:41 --> Security Class Initialized
DEBUG - 2021-12-06 05:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:56:41 --> Input Class Initialized
INFO - 2021-12-06 05:56:41 --> Language Class Initialized
INFO - 2021-12-06 05:56:41 --> Language Class Initialized
INFO - 2021-12-06 05:56:41 --> Config Class Initialized
INFO - 2021-12-06 05:56:41 --> Loader Class Initialized
INFO - 2021-12-06 05:56:41 --> Helper loaded: url_helper
INFO - 2021-12-06 05:56:41 --> Helper loaded: file_helper
INFO - 2021-12-06 05:56:41 --> Helper loaded: form_helper
INFO - 2021-12-06 05:56:41 --> Helper loaded: my_helper
INFO - 2021-12-06 05:56:41 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:56:41 --> Controller Class Initialized
DEBUG - 2021-12-06 05:56:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:56:41 --> Final output sent to browser
DEBUG - 2021-12-06 05:56:41 --> Total execution time: 0.3692
INFO - 2021-12-06 05:58:57 --> Config Class Initialized
INFO - 2021-12-06 05:58:57 --> Hooks Class Initialized
DEBUG - 2021-12-06 05:58:57 --> UTF-8 Support Enabled
INFO - 2021-12-06 05:58:57 --> Utf8 Class Initialized
INFO - 2021-12-06 05:58:57 --> URI Class Initialized
INFO - 2021-12-06 05:58:57 --> Router Class Initialized
INFO - 2021-12-06 05:58:57 --> Output Class Initialized
INFO - 2021-12-06 05:58:57 --> Security Class Initialized
DEBUG - 2021-12-06 05:58:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 05:58:57 --> Input Class Initialized
INFO - 2021-12-06 05:58:57 --> Language Class Initialized
INFO - 2021-12-06 05:58:57 --> Language Class Initialized
INFO - 2021-12-06 05:58:57 --> Config Class Initialized
INFO - 2021-12-06 05:58:57 --> Loader Class Initialized
INFO - 2021-12-06 05:58:57 --> Helper loaded: url_helper
INFO - 2021-12-06 05:58:57 --> Helper loaded: file_helper
INFO - 2021-12-06 05:58:57 --> Helper loaded: form_helper
INFO - 2021-12-06 05:58:57 --> Helper loaded: my_helper
INFO - 2021-12-06 05:58:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 05:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 05:58:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 05:58:57 --> Controller Class Initialized
DEBUG - 2021-12-06 05:58:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 05:58:58 --> Final output sent to browser
DEBUG - 2021-12-06 05:58:58 --> Total execution time: 0.3791
INFO - 2021-12-06 06:00:55 --> Config Class Initialized
INFO - 2021-12-06 06:00:55 --> Hooks Class Initialized
DEBUG - 2021-12-06 06:00:55 --> UTF-8 Support Enabled
INFO - 2021-12-06 06:00:55 --> Utf8 Class Initialized
INFO - 2021-12-06 06:00:55 --> URI Class Initialized
INFO - 2021-12-06 06:00:55 --> Router Class Initialized
INFO - 2021-12-06 06:00:55 --> Output Class Initialized
INFO - 2021-12-06 06:00:55 --> Security Class Initialized
DEBUG - 2021-12-06 06:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 06:00:55 --> Input Class Initialized
INFO - 2021-12-06 06:00:55 --> Language Class Initialized
INFO - 2021-12-06 06:00:55 --> Language Class Initialized
INFO - 2021-12-06 06:00:55 --> Config Class Initialized
INFO - 2021-12-06 06:00:55 --> Loader Class Initialized
INFO - 2021-12-06 06:00:55 --> Helper loaded: url_helper
INFO - 2021-12-06 06:00:55 --> Helper loaded: file_helper
INFO - 2021-12-06 06:00:55 --> Helper loaded: form_helper
INFO - 2021-12-06 06:00:55 --> Helper loaded: my_helper
INFO - 2021-12-06 06:00:55 --> Database Driver Class Initialized
DEBUG - 2021-12-06 06:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 06:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 06:00:55 --> Controller Class Initialized
DEBUG - 2021-12-06 06:00:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 06:00:55 --> Final output sent to browser
DEBUG - 2021-12-06 06:00:55 --> Total execution time: 0.4300
INFO - 2021-12-06 06:02:01 --> Config Class Initialized
INFO - 2021-12-06 06:02:01 --> Hooks Class Initialized
DEBUG - 2021-12-06 06:02:01 --> UTF-8 Support Enabled
INFO - 2021-12-06 06:02:01 --> Utf8 Class Initialized
INFO - 2021-12-06 06:02:01 --> URI Class Initialized
INFO - 2021-12-06 06:02:01 --> Router Class Initialized
INFO - 2021-12-06 06:02:01 --> Output Class Initialized
INFO - 2021-12-06 06:02:01 --> Security Class Initialized
DEBUG - 2021-12-06 06:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 06:02:01 --> Input Class Initialized
INFO - 2021-12-06 06:02:01 --> Language Class Initialized
INFO - 2021-12-06 06:02:01 --> Language Class Initialized
INFO - 2021-12-06 06:02:01 --> Config Class Initialized
INFO - 2021-12-06 06:02:01 --> Loader Class Initialized
INFO - 2021-12-06 06:02:01 --> Helper loaded: url_helper
INFO - 2021-12-06 06:02:01 --> Helper loaded: file_helper
INFO - 2021-12-06 06:02:01 --> Helper loaded: form_helper
INFO - 2021-12-06 06:02:01 --> Helper loaded: my_helper
INFO - 2021-12-06 06:02:01 --> Database Driver Class Initialized
DEBUG - 2021-12-06 06:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 06:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 06:02:01 --> Controller Class Initialized
DEBUG - 2021-12-06 06:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 06:02:01 --> Final output sent to browser
DEBUG - 2021-12-06 06:02:01 --> Total execution time: 0.1456
INFO - 2021-12-06 06:02:25 --> Config Class Initialized
INFO - 2021-12-06 06:02:25 --> Hooks Class Initialized
DEBUG - 2021-12-06 06:02:25 --> UTF-8 Support Enabled
INFO - 2021-12-06 06:02:25 --> Utf8 Class Initialized
INFO - 2021-12-06 06:02:25 --> URI Class Initialized
INFO - 2021-12-06 06:02:25 --> Router Class Initialized
INFO - 2021-12-06 06:02:25 --> Output Class Initialized
INFO - 2021-12-06 06:02:25 --> Security Class Initialized
DEBUG - 2021-12-06 06:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 06:02:25 --> Input Class Initialized
INFO - 2021-12-06 06:02:25 --> Language Class Initialized
INFO - 2021-12-06 06:02:25 --> Language Class Initialized
INFO - 2021-12-06 06:02:25 --> Config Class Initialized
INFO - 2021-12-06 06:02:25 --> Loader Class Initialized
INFO - 2021-12-06 06:02:25 --> Helper loaded: url_helper
INFO - 2021-12-06 06:02:25 --> Helper loaded: file_helper
INFO - 2021-12-06 06:02:25 --> Helper loaded: form_helper
INFO - 2021-12-06 06:02:25 --> Helper loaded: my_helper
INFO - 2021-12-06 06:02:25 --> Database Driver Class Initialized
DEBUG - 2021-12-06 06:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 06:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 06:02:25 --> Controller Class Initialized
DEBUG - 2021-12-06 06:02:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 06:02:25 --> Final output sent to browser
DEBUG - 2021-12-06 06:02:25 --> Total execution time: 0.1294
INFO - 2021-12-06 06:02:39 --> Config Class Initialized
INFO - 2021-12-06 06:02:39 --> Hooks Class Initialized
DEBUG - 2021-12-06 06:02:39 --> UTF-8 Support Enabled
INFO - 2021-12-06 06:02:39 --> Utf8 Class Initialized
INFO - 2021-12-06 06:02:39 --> URI Class Initialized
INFO - 2021-12-06 06:02:39 --> Router Class Initialized
INFO - 2021-12-06 06:02:39 --> Output Class Initialized
INFO - 2021-12-06 06:02:39 --> Security Class Initialized
DEBUG - 2021-12-06 06:02:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 06:02:39 --> Input Class Initialized
INFO - 2021-12-06 06:02:39 --> Language Class Initialized
INFO - 2021-12-06 06:02:39 --> Language Class Initialized
INFO - 2021-12-06 06:02:39 --> Config Class Initialized
INFO - 2021-12-06 06:02:39 --> Loader Class Initialized
INFO - 2021-12-06 06:02:39 --> Helper loaded: url_helper
INFO - 2021-12-06 06:02:39 --> Helper loaded: file_helper
INFO - 2021-12-06 06:02:39 --> Helper loaded: form_helper
INFO - 2021-12-06 06:02:39 --> Helper loaded: my_helper
INFO - 2021-12-06 06:02:39 --> Database Driver Class Initialized
DEBUG - 2021-12-06 06:02:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 06:02:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 06:02:39 --> Controller Class Initialized
DEBUG - 2021-12-06 06:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 06:02:40 --> Final output sent to browser
DEBUG - 2021-12-06 06:02:40 --> Total execution time: 0.1382
INFO - 2021-12-06 06:02:57 --> Config Class Initialized
INFO - 2021-12-06 06:02:57 --> Hooks Class Initialized
DEBUG - 2021-12-06 06:02:57 --> UTF-8 Support Enabled
INFO - 2021-12-06 06:02:57 --> Utf8 Class Initialized
INFO - 2021-12-06 06:02:57 --> URI Class Initialized
INFO - 2021-12-06 06:02:57 --> Router Class Initialized
INFO - 2021-12-06 06:02:57 --> Output Class Initialized
INFO - 2021-12-06 06:02:57 --> Security Class Initialized
DEBUG - 2021-12-06 06:02:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 06:02:57 --> Input Class Initialized
INFO - 2021-12-06 06:02:57 --> Language Class Initialized
INFO - 2021-12-06 06:02:57 --> Language Class Initialized
INFO - 2021-12-06 06:02:57 --> Config Class Initialized
INFO - 2021-12-06 06:02:57 --> Loader Class Initialized
INFO - 2021-12-06 06:02:57 --> Helper loaded: url_helper
INFO - 2021-12-06 06:02:57 --> Helper loaded: file_helper
INFO - 2021-12-06 06:02:57 --> Helper loaded: form_helper
INFO - 2021-12-06 06:02:57 --> Helper loaded: my_helper
INFO - 2021-12-06 06:02:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 06:02:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 06:02:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 06:02:57 --> Controller Class Initialized
DEBUG - 2021-12-06 06:02:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 06:02:57 --> Final output sent to browser
DEBUG - 2021-12-06 06:02:57 --> Total execution time: 0.1423
INFO - 2021-12-06 06:43:36 --> Config Class Initialized
INFO - 2021-12-06 06:43:36 --> Hooks Class Initialized
DEBUG - 2021-12-06 06:43:36 --> UTF-8 Support Enabled
INFO - 2021-12-06 06:43:36 --> Utf8 Class Initialized
INFO - 2021-12-06 06:43:36 --> URI Class Initialized
INFO - 2021-12-06 06:43:36 --> Router Class Initialized
INFO - 2021-12-06 06:43:36 --> Output Class Initialized
INFO - 2021-12-06 06:43:36 --> Security Class Initialized
DEBUG - 2021-12-06 06:43:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 06:43:36 --> Input Class Initialized
INFO - 2021-12-06 06:43:36 --> Language Class Initialized
INFO - 2021-12-06 06:43:36 --> Language Class Initialized
INFO - 2021-12-06 06:43:36 --> Config Class Initialized
INFO - 2021-12-06 06:43:36 --> Loader Class Initialized
INFO - 2021-12-06 06:43:36 --> Helper loaded: url_helper
INFO - 2021-12-06 06:43:36 --> Helper loaded: file_helper
INFO - 2021-12-06 06:43:36 --> Helper loaded: form_helper
INFO - 2021-12-06 06:43:36 --> Helper loaded: my_helper
INFO - 2021-12-06 06:43:36 --> Database Driver Class Initialized
DEBUG - 2021-12-06 06:43:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 06:43:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 06:43:36 --> Controller Class Initialized
DEBUG - 2021-12-06 06:43:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-12-06 06:43:36 --> Final output sent to browser
DEBUG - 2021-12-06 06:43:36 --> Total execution time: 0.1972
INFO - 2021-12-06 07:16:45 --> Config Class Initialized
INFO - 2021-12-06 07:16:45 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:16:45 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:16:45 --> Utf8 Class Initialized
INFO - 2021-12-06 07:16:45 --> URI Class Initialized
INFO - 2021-12-06 07:16:45 --> Router Class Initialized
INFO - 2021-12-06 07:16:45 --> Output Class Initialized
INFO - 2021-12-06 07:16:45 --> Security Class Initialized
DEBUG - 2021-12-06 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:16:45 --> Input Class Initialized
INFO - 2021-12-06 07:16:45 --> Language Class Initialized
INFO - 2021-12-06 07:16:45 --> Language Class Initialized
INFO - 2021-12-06 07:16:45 --> Config Class Initialized
INFO - 2021-12-06 07:16:45 --> Loader Class Initialized
INFO - 2021-12-06 07:16:45 --> Helper loaded: url_helper
INFO - 2021-12-06 07:16:45 --> Helper loaded: file_helper
INFO - 2021-12-06 07:16:45 --> Helper loaded: form_helper
INFO - 2021-12-06 07:16:45 --> Helper loaded: my_helper
INFO - 2021-12-06 07:16:45 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:16:45 --> Controller Class Initialized
INFO - 2021-12-06 07:16:45 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:16:45 --> Config Class Initialized
INFO - 2021-12-06 07:16:45 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:16:45 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:16:45 --> Utf8 Class Initialized
INFO - 2021-12-06 07:16:45 --> URI Class Initialized
INFO - 2021-12-06 07:16:45 --> Router Class Initialized
INFO - 2021-12-06 07:16:45 --> Output Class Initialized
INFO - 2021-12-06 07:16:45 --> Security Class Initialized
DEBUG - 2021-12-06 07:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:16:45 --> Input Class Initialized
INFO - 2021-12-06 07:16:45 --> Language Class Initialized
INFO - 2021-12-06 07:16:45 --> Language Class Initialized
INFO - 2021-12-06 07:16:45 --> Config Class Initialized
INFO - 2021-12-06 07:16:45 --> Loader Class Initialized
INFO - 2021-12-06 07:16:45 --> Helper loaded: url_helper
INFO - 2021-12-06 07:16:45 --> Helper loaded: file_helper
INFO - 2021-12-06 07:16:45 --> Helper loaded: form_helper
INFO - 2021-12-06 07:16:45 --> Helper loaded: my_helper
INFO - 2021-12-06 07:16:45 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:16:45 --> Controller Class Initialized
DEBUG - 2021-12-06 07:16:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 07:16:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:16:45 --> Final output sent to browser
DEBUG - 2021-12-06 07:16:45 --> Total execution time: 0.0556
INFO - 2021-12-06 07:17:11 --> Config Class Initialized
INFO - 2021-12-06 07:17:11 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:11 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:11 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:11 --> URI Class Initialized
INFO - 2021-12-06 07:17:11 --> Router Class Initialized
INFO - 2021-12-06 07:17:11 --> Output Class Initialized
INFO - 2021-12-06 07:17:11 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:11 --> Input Class Initialized
INFO - 2021-12-06 07:17:11 --> Language Class Initialized
INFO - 2021-12-06 07:17:11 --> Language Class Initialized
INFO - 2021-12-06 07:17:11 --> Config Class Initialized
INFO - 2021-12-06 07:17:11 --> Loader Class Initialized
INFO - 2021-12-06 07:17:11 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:11 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:11 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:11 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:12 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:12 --> Controller Class Initialized
INFO - 2021-12-06 07:17:12 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:17:12 --> Final output sent to browser
DEBUG - 2021-12-06 07:17:12 --> Total execution time: 0.0962
INFO - 2021-12-06 07:17:14 --> Config Class Initialized
INFO - 2021-12-06 07:17:14 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:14 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:14 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:14 --> URI Class Initialized
INFO - 2021-12-06 07:17:14 --> Router Class Initialized
INFO - 2021-12-06 07:17:14 --> Output Class Initialized
INFO - 2021-12-06 07:17:14 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:14 --> Input Class Initialized
INFO - 2021-12-06 07:17:14 --> Language Class Initialized
INFO - 2021-12-06 07:17:14 --> Language Class Initialized
INFO - 2021-12-06 07:17:14 --> Config Class Initialized
INFO - 2021-12-06 07:17:14 --> Loader Class Initialized
INFO - 2021-12-06 07:17:14 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:14 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:14 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:14 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:14 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:14 --> Controller Class Initialized
DEBUG - 2021-12-06 07:17:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 07:17:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:17:15 --> Final output sent to browser
DEBUG - 2021-12-06 07:17:15 --> Total execution time: 1.0672
INFO - 2021-12-06 07:17:21 --> Config Class Initialized
INFO - 2021-12-06 07:17:21 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:21 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:21 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:21 --> URI Class Initialized
INFO - 2021-12-06 07:17:21 --> Router Class Initialized
INFO - 2021-12-06 07:17:21 --> Output Class Initialized
INFO - 2021-12-06 07:17:21 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:21 --> Input Class Initialized
INFO - 2021-12-06 07:17:21 --> Language Class Initialized
INFO - 2021-12-06 07:17:21 --> Language Class Initialized
INFO - 2021-12-06 07:17:21 --> Config Class Initialized
INFO - 2021-12-06 07:17:21 --> Loader Class Initialized
INFO - 2021-12-06 07:17:21 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:21 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:21 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:21 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:21 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:21 --> Controller Class Initialized
DEBUG - 2021-12-06 07:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-06 07:17:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:17:21 --> Final output sent to browser
DEBUG - 2021-12-06 07:17:21 --> Total execution time: 0.1047
INFO - 2021-12-06 07:17:21 --> Config Class Initialized
INFO - 2021-12-06 07:17:21 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:21 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:21 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:21 --> URI Class Initialized
INFO - 2021-12-06 07:17:21 --> Router Class Initialized
INFO - 2021-12-06 07:17:21 --> Output Class Initialized
INFO - 2021-12-06 07:17:21 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:21 --> Input Class Initialized
INFO - 2021-12-06 07:17:21 --> Language Class Initialized
INFO - 2021-12-06 07:17:21 --> Language Class Initialized
INFO - 2021-12-06 07:17:21 --> Config Class Initialized
INFO - 2021-12-06 07:17:21 --> Loader Class Initialized
INFO - 2021-12-06 07:17:21 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:21 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:21 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:21 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:21 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:21 --> Controller Class Initialized
INFO - 2021-12-06 07:17:35 --> Config Class Initialized
INFO - 2021-12-06 07:17:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:35 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:35 --> URI Class Initialized
INFO - 2021-12-06 07:17:35 --> Router Class Initialized
INFO - 2021-12-06 07:17:35 --> Output Class Initialized
INFO - 2021-12-06 07:17:35 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:35 --> Input Class Initialized
INFO - 2021-12-06 07:17:35 --> Language Class Initialized
INFO - 2021-12-06 07:17:35 --> Language Class Initialized
INFO - 2021-12-06 07:17:35 --> Config Class Initialized
INFO - 2021-12-06 07:17:35 --> Loader Class Initialized
INFO - 2021-12-06 07:17:35 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:35 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:35 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:35 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:35 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:35 --> Controller Class Initialized
INFO - 2021-12-06 07:17:35 --> Final output sent to browser
DEBUG - 2021-12-06 07:17:35 --> Total execution time: 0.0853
INFO - 2021-12-06 07:17:35 --> Config Class Initialized
INFO - 2021-12-06 07:17:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:35 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:35 --> URI Class Initialized
INFO - 2021-12-06 07:17:35 --> Router Class Initialized
INFO - 2021-12-06 07:17:35 --> Output Class Initialized
INFO - 2021-12-06 07:17:35 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:35 --> Input Class Initialized
INFO - 2021-12-06 07:17:35 --> Language Class Initialized
INFO - 2021-12-06 07:17:35 --> Language Class Initialized
INFO - 2021-12-06 07:17:35 --> Config Class Initialized
INFO - 2021-12-06 07:17:35 --> Loader Class Initialized
INFO - 2021-12-06 07:17:35 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:35 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:35 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:35 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:35 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:35 --> Controller Class Initialized
INFO - 2021-12-06 07:17:45 --> Config Class Initialized
INFO - 2021-12-06 07:17:45 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:45 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:45 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:45 --> URI Class Initialized
INFO - 2021-12-06 07:17:45 --> Router Class Initialized
INFO - 2021-12-06 07:17:45 --> Output Class Initialized
INFO - 2021-12-06 07:17:45 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:45 --> Input Class Initialized
INFO - 2021-12-06 07:17:45 --> Language Class Initialized
INFO - 2021-12-06 07:17:45 --> Language Class Initialized
INFO - 2021-12-06 07:17:45 --> Config Class Initialized
INFO - 2021-12-06 07:17:45 --> Loader Class Initialized
INFO - 2021-12-06 07:17:45 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:45 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:45 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:45 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:45 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:45 --> Controller Class Initialized
INFO - 2021-12-06 07:17:45 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:17:45 --> Config Class Initialized
INFO - 2021-12-06 07:17:45 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:17:45 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:17:45 --> Utf8 Class Initialized
INFO - 2021-12-06 07:17:45 --> URI Class Initialized
INFO - 2021-12-06 07:17:45 --> Router Class Initialized
INFO - 2021-12-06 07:17:45 --> Output Class Initialized
INFO - 2021-12-06 07:17:45 --> Security Class Initialized
DEBUG - 2021-12-06 07:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:17:45 --> Input Class Initialized
INFO - 2021-12-06 07:17:45 --> Language Class Initialized
INFO - 2021-12-06 07:17:45 --> Language Class Initialized
INFO - 2021-12-06 07:17:45 --> Config Class Initialized
INFO - 2021-12-06 07:17:45 --> Loader Class Initialized
INFO - 2021-12-06 07:17:45 --> Helper loaded: url_helper
INFO - 2021-12-06 07:17:45 --> Helper loaded: file_helper
INFO - 2021-12-06 07:17:45 --> Helper loaded: form_helper
INFO - 2021-12-06 07:17:45 --> Helper loaded: my_helper
INFO - 2021-12-06 07:17:45 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:17:45 --> Controller Class Initialized
DEBUG - 2021-12-06 07:17:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 07:17:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:17:45 --> Final output sent to browser
DEBUG - 2021-12-06 07:17:45 --> Total execution time: 0.0670
INFO - 2021-12-06 07:18:11 --> Config Class Initialized
INFO - 2021-12-06 07:18:11 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:18:11 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:18:11 --> Utf8 Class Initialized
INFO - 2021-12-06 07:18:11 --> URI Class Initialized
INFO - 2021-12-06 07:18:11 --> Router Class Initialized
INFO - 2021-12-06 07:18:11 --> Output Class Initialized
INFO - 2021-12-06 07:18:11 --> Security Class Initialized
DEBUG - 2021-12-06 07:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:18:11 --> Input Class Initialized
INFO - 2021-12-06 07:18:11 --> Language Class Initialized
INFO - 2021-12-06 07:18:11 --> Language Class Initialized
INFO - 2021-12-06 07:18:11 --> Config Class Initialized
INFO - 2021-12-06 07:18:11 --> Loader Class Initialized
INFO - 2021-12-06 07:18:11 --> Helper loaded: url_helper
INFO - 2021-12-06 07:18:11 --> Helper loaded: file_helper
INFO - 2021-12-06 07:18:11 --> Helper loaded: form_helper
INFO - 2021-12-06 07:18:11 --> Helper loaded: my_helper
INFO - 2021-12-06 07:18:11 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:18:11 --> Controller Class Initialized
INFO - 2021-12-06 07:18:11 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:18:11 --> Final output sent to browser
DEBUG - 2021-12-06 07:18:11 --> Total execution time: 0.0785
INFO - 2021-12-06 07:18:17 --> Config Class Initialized
INFO - 2021-12-06 07:18:17 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:18:17 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:18:17 --> Utf8 Class Initialized
INFO - 2021-12-06 07:18:17 --> URI Class Initialized
INFO - 2021-12-06 07:18:17 --> Router Class Initialized
INFO - 2021-12-06 07:18:17 --> Output Class Initialized
INFO - 2021-12-06 07:18:17 --> Security Class Initialized
DEBUG - 2021-12-06 07:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:18:17 --> Input Class Initialized
INFO - 2021-12-06 07:18:17 --> Language Class Initialized
INFO - 2021-12-06 07:18:17 --> Language Class Initialized
INFO - 2021-12-06 07:18:17 --> Config Class Initialized
INFO - 2021-12-06 07:18:17 --> Loader Class Initialized
INFO - 2021-12-06 07:18:17 --> Helper loaded: url_helper
INFO - 2021-12-06 07:18:17 --> Helper loaded: file_helper
INFO - 2021-12-06 07:18:17 --> Helper loaded: form_helper
INFO - 2021-12-06 07:18:17 --> Helper loaded: my_helper
INFO - 2021-12-06 07:18:17 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:18:17 --> Controller Class Initialized
DEBUG - 2021-12-06 07:18:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 07:18:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:18:17 --> Final output sent to browser
DEBUG - 2021-12-06 07:18:17 --> Total execution time: 0.2189
INFO - 2021-12-06 07:18:28 --> Config Class Initialized
INFO - 2021-12-06 07:18:28 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:18:28 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:18:28 --> Utf8 Class Initialized
INFO - 2021-12-06 07:18:28 --> URI Class Initialized
INFO - 2021-12-06 07:18:28 --> Router Class Initialized
INFO - 2021-12-06 07:18:28 --> Output Class Initialized
INFO - 2021-12-06 07:18:28 --> Security Class Initialized
DEBUG - 2021-12-06 07:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:18:28 --> Input Class Initialized
INFO - 2021-12-06 07:18:28 --> Language Class Initialized
INFO - 2021-12-06 07:18:28 --> Language Class Initialized
INFO - 2021-12-06 07:18:28 --> Config Class Initialized
INFO - 2021-12-06 07:18:28 --> Loader Class Initialized
INFO - 2021-12-06 07:18:28 --> Helper loaded: url_helper
INFO - 2021-12-06 07:18:28 --> Helper loaded: file_helper
INFO - 2021-12-06 07:18:28 --> Helper loaded: form_helper
INFO - 2021-12-06 07:18:28 --> Helper loaded: my_helper
INFO - 2021-12-06 07:18:28 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:18:28 --> Controller Class Initialized
DEBUG - 2021-12-06 07:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-06 07:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:18:28 --> Final output sent to browser
DEBUG - 2021-12-06 07:18:28 --> Total execution time: 0.1416
INFO - 2021-12-06 07:18:32 --> Config Class Initialized
INFO - 2021-12-06 07:18:32 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:18:32 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:18:32 --> Utf8 Class Initialized
INFO - 2021-12-06 07:18:32 --> URI Class Initialized
INFO - 2021-12-06 07:18:32 --> Router Class Initialized
INFO - 2021-12-06 07:18:32 --> Output Class Initialized
INFO - 2021-12-06 07:18:32 --> Security Class Initialized
DEBUG - 2021-12-06 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:18:32 --> Input Class Initialized
INFO - 2021-12-06 07:18:32 --> Language Class Initialized
INFO - 2021-12-06 07:18:32 --> Language Class Initialized
INFO - 2021-12-06 07:18:32 --> Config Class Initialized
INFO - 2021-12-06 07:18:32 --> Loader Class Initialized
INFO - 2021-12-06 07:18:32 --> Helper loaded: url_helper
INFO - 2021-12-06 07:18:32 --> Helper loaded: file_helper
INFO - 2021-12-06 07:18:32 --> Helper loaded: form_helper
INFO - 2021-12-06 07:18:32 --> Helper loaded: my_helper
INFO - 2021-12-06 07:18:32 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:18:32 --> Controller Class Initialized
INFO - 2021-12-06 07:18:32 --> Final output sent to browser
DEBUG - 2021-12-06 07:18:32 --> Total execution time: 0.0682
INFO - 2021-12-06 07:20:09 --> Config Class Initialized
INFO - 2021-12-06 07:20:09 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:20:09 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:20:09 --> Utf8 Class Initialized
INFO - 2021-12-06 07:20:09 --> URI Class Initialized
INFO - 2021-12-06 07:20:09 --> Router Class Initialized
INFO - 2021-12-06 07:20:09 --> Output Class Initialized
INFO - 2021-12-06 07:20:09 --> Security Class Initialized
DEBUG - 2021-12-06 07:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:20:09 --> Input Class Initialized
INFO - 2021-12-06 07:20:09 --> Language Class Initialized
INFO - 2021-12-06 07:20:09 --> Language Class Initialized
INFO - 2021-12-06 07:20:09 --> Config Class Initialized
INFO - 2021-12-06 07:20:09 --> Loader Class Initialized
INFO - 2021-12-06 07:20:09 --> Helper loaded: url_helper
INFO - 2021-12-06 07:20:09 --> Helper loaded: file_helper
INFO - 2021-12-06 07:20:09 --> Helper loaded: form_helper
INFO - 2021-12-06 07:20:09 --> Helper loaded: my_helper
INFO - 2021-12-06 07:20:09 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:20:09 --> Controller Class Initialized
INFO - 2021-12-06 07:20:09 --> Final output sent to browser
DEBUG - 2021-12-06 07:20:09 --> Total execution time: 0.1422
INFO - 2021-12-06 07:20:23 --> Config Class Initialized
INFO - 2021-12-06 07:20:23 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:20:23 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:20:23 --> Utf8 Class Initialized
INFO - 2021-12-06 07:20:23 --> URI Class Initialized
INFO - 2021-12-06 07:20:23 --> Router Class Initialized
INFO - 2021-12-06 07:20:23 --> Output Class Initialized
INFO - 2021-12-06 07:20:23 --> Security Class Initialized
DEBUG - 2021-12-06 07:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:20:23 --> Input Class Initialized
INFO - 2021-12-06 07:20:23 --> Language Class Initialized
INFO - 2021-12-06 07:20:23 --> Language Class Initialized
INFO - 2021-12-06 07:20:23 --> Config Class Initialized
INFO - 2021-12-06 07:20:23 --> Loader Class Initialized
INFO - 2021-12-06 07:20:23 --> Helper loaded: url_helper
INFO - 2021-12-06 07:20:23 --> Helper loaded: file_helper
INFO - 2021-12-06 07:20:23 --> Helper loaded: form_helper
INFO - 2021-12-06 07:20:23 --> Helper loaded: my_helper
INFO - 2021-12-06 07:20:23 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:20:23 --> Controller Class Initialized
DEBUG - 2021-12-06 07:20:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 07:20:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:20:23 --> Final output sent to browser
DEBUG - 2021-12-06 07:20:23 --> Total execution time: 0.1094
INFO - 2021-12-06 07:22:31 --> Config Class Initialized
INFO - 2021-12-06 07:22:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:22:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:22:31 --> Utf8 Class Initialized
INFO - 2021-12-06 07:22:31 --> URI Class Initialized
INFO - 2021-12-06 07:22:31 --> Router Class Initialized
INFO - 2021-12-06 07:22:31 --> Output Class Initialized
INFO - 2021-12-06 07:22:31 --> Security Class Initialized
DEBUG - 2021-12-06 07:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:22:31 --> Input Class Initialized
INFO - 2021-12-06 07:22:31 --> Language Class Initialized
INFO - 2021-12-06 07:22:31 --> Language Class Initialized
INFO - 2021-12-06 07:22:31 --> Config Class Initialized
INFO - 2021-12-06 07:22:31 --> Loader Class Initialized
INFO - 2021-12-06 07:22:31 --> Helper loaded: url_helper
INFO - 2021-12-06 07:22:31 --> Helper loaded: file_helper
INFO - 2021-12-06 07:22:31 --> Helper loaded: form_helper
INFO - 2021-12-06 07:22:31 --> Helper loaded: my_helper
INFO - 2021-12-06 07:22:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:22:31 --> Controller Class Initialized
INFO - 2021-12-06 07:22:31 --> Final output sent to browser
DEBUG - 2021-12-06 07:22:31 --> Total execution time: 0.1266
INFO - 2021-12-06 07:22:41 --> Config Class Initialized
INFO - 2021-12-06 07:22:41 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:22:41 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:22:41 --> Utf8 Class Initialized
INFO - 2021-12-06 07:22:41 --> URI Class Initialized
INFO - 2021-12-06 07:22:41 --> Router Class Initialized
INFO - 2021-12-06 07:22:41 --> Output Class Initialized
INFO - 2021-12-06 07:22:41 --> Security Class Initialized
DEBUG - 2021-12-06 07:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:22:41 --> Input Class Initialized
INFO - 2021-12-06 07:22:41 --> Language Class Initialized
INFO - 2021-12-06 07:22:41 --> Language Class Initialized
INFO - 2021-12-06 07:22:41 --> Config Class Initialized
INFO - 2021-12-06 07:22:41 --> Loader Class Initialized
INFO - 2021-12-06 07:22:41 --> Helper loaded: url_helper
INFO - 2021-12-06 07:22:41 --> Helper loaded: file_helper
INFO - 2021-12-06 07:22:41 --> Helper loaded: form_helper
INFO - 2021-12-06 07:22:41 --> Helper loaded: my_helper
INFO - 2021-12-06 07:22:41 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:22:41 --> Controller Class Initialized
DEBUG - 2021-12-06 07:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-06 07:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:22:41 --> Final output sent to browser
DEBUG - 2021-12-06 07:22:41 --> Total execution time: 0.1665
INFO - 2021-12-06 07:22:53 --> Config Class Initialized
INFO - 2021-12-06 07:22:53 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:22:53 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:22:53 --> Utf8 Class Initialized
INFO - 2021-12-06 07:22:53 --> URI Class Initialized
INFO - 2021-12-06 07:22:53 --> Router Class Initialized
INFO - 2021-12-06 07:22:53 --> Output Class Initialized
INFO - 2021-12-06 07:22:53 --> Security Class Initialized
DEBUG - 2021-12-06 07:22:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:22:53 --> Input Class Initialized
INFO - 2021-12-06 07:22:53 --> Language Class Initialized
INFO - 2021-12-06 07:22:53 --> Language Class Initialized
INFO - 2021-12-06 07:22:53 --> Config Class Initialized
INFO - 2021-12-06 07:22:53 --> Loader Class Initialized
INFO - 2021-12-06 07:22:53 --> Helper loaded: url_helper
INFO - 2021-12-06 07:22:53 --> Helper loaded: file_helper
INFO - 2021-12-06 07:22:53 --> Helper loaded: form_helper
INFO - 2021-12-06 07:22:53 --> Helper loaded: my_helper
INFO - 2021-12-06 07:22:53 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:22:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:22:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:22:53 --> Controller Class Initialized
DEBUG - 2021-12-06 07:22:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 07:22:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:22:53 --> Final output sent to browser
DEBUG - 2021-12-06 07:22:53 --> Total execution time: 0.0617
INFO - 2021-12-06 07:22:57 --> Config Class Initialized
INFO - 2021-12-06 07:22:57 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:22:57 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:22:57 --> Utf8 Class Initialized
INFO - 2021-12-06 07:22:57 --> URI Class Initialized
INFO - 2021-12-06 07:22:57 --> Router Class Initialized
INFO - 2021-12-06 07:22:57 --> Output Class Initialized
INFO - 2021-12-06 07:22:57 --> Security Class Initialized
DEBUG - 2021-12-06 07:22:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:22:57 --> Input Class Initialized
INFO - 2021-12-06 07:22:57 --> Language Class Initialized
INFO - 2021-12-06 07:22:57 --> Language Class Initialized
INFO - 2021-12-06 07:22:57 --> Config Class Initialized
INFO - 2021-12-06 07:22:57 --> Loader Class Initialized
INFO - 2021-12-06 07:22:57 --> Helper loaded: url_helper
INFO - 2021-12-06 07:22:57 --> Helper loaded: file_helper
INFO - 2021-12-06 07:22:57 --> Helper loaded: form_helper
INFO - 2021-12-06 07:22:57 --> Helper loaded: my_helper
INFO - 2021-12-06 07:22:57 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:22:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:22:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:22:57 --> Controller Class Initialized
INFO - 2021-12-06 07:22:57 --> Final output sent to browser
DEBUG - 2021-12-06 07:22:57 --> Total execution time: 0.1361
INFO - 2021-12-06 07:23:03 --> Config Class Initialized
INFO - 2021-12-06 07:23:03 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:23:03 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:23:03 --> Utf8 Class Initialized
INFO - 2021-12-06 07:23:03 --> URI Class Initialized
INFO - 2021-12-06 07:23:03 --> Router Class Initialized
INFO - 2021-12-06 07:23:03 --> Output Class Initialized
INFO - 2021-12-06 07:23:03 --> Security Class Initialized
DEBUG - 2021-12-06 07:23:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:23:03 --> Input Class Initialized
INFO - 2021-12-06 07:23:03 --> Language Class Initialized
INFO - 2021-12-06 07:23:03 --> Language Class Initialized
INFO - 2021-12-06 07:23:03 --> Config Class Initialized
INFO - 2021-12-06 07:23:03 --> Loader Class Initialized
INFO - 2021-12-06 07:23:03 --> Helper loaded: url_helper
INFO - 2021-12-06 07:23:03 --> Helper loaded: file_helper
INFO - 2021-12-06 07:23:03 --> Helper loaded: form_helper
INFO - 2021-12-06 07:23:03 --> Helper loaded: my_helper
INFO - 2021-12-06 07:23:03 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:23:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:23:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:23:03 --> Controller Class Initialized
DEBUG - 2021-12-06 07:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-06 07:23:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:23:03 --> Final output sent to browser
DEBUG - 2021-12-06 07:23:03 --> Total execution time: 0.1245
INFO - 2021-12-06 07:23:07 --> Config Class Initialized
INFO - 2021-12-06 07:23:07 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:23:08 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:23:08 --> Utf8 Class Initialized
INFO - 2021-12-06 07:23:08 --> URI Class Initialized
INFO - 2021-12-06 07:23:08 --> Router Class Initialized
INFO - 2021-12-06 07:23:08 --> Output Class Initialized
INFO - 2021-12-06 07:23:08 --> Security Class Initialized
DEBUG - 2021-12-06 07:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:23:08 --> Input Class Initialized
INFO - 2021-12-06 07:23:08 --> Language Class Initialized
INFO - 2021-12-06 07:23:08 --> Language Class Initialized
INFO - 2021-12-06 07:23:08 --> Config Class Initialized
INFO - 2021-12-06 07:23:08 --> Loader Class Initialized
INFO - 2021-12-06 07:23:08 --> Helper loaded: url_helper
INFO - 2021-12-06 07:23:08 --> Helper loaded: file_helper
INFO - 2021-12-06 07:23:08 --> Helper loaded: form_helper
INFO - 2021-12-06 07:23:08 --> Helper loaded: my_helper
INFO - 2021-12-06 07:23:08 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:23:08 --> Controller Class Initialized
DEBUG - 2021-12-06 07:23:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 07:23:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:23:08 --> Final output sent to browser
DEBUG - 2021-12-06 07:23:08 --> Total execution time: 0.1001
INFO - 2021-12-06 07:23:11 --> Config Class Initialized
INFO - 2021-12-06 07:23:11 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:23:11 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:23:11 --> Utf8 Class Initialized
INFO - 2021-12-06 07:23:11 --> URI Class Initialized
INFO - 2021-12-06 07:23:11 --> Router Class Initialized
INFO - 2021-12-06 07:23:11 --> Output Class Initialized
INFO - 2021-12-06 07:23:11 --> Security Class Initialized
DEBUG - 2021-12-06 07:23:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:23:11 --> Input Class Initialized
INFO - 2021-12-06 07:23:11 --> Language Class Initialized
INFO - 2021-12-06 07:23:11 --> Language Class Initialized
INFO - 2021-12-06 07:23:11 --> Config Class Initialized
INFO - 2021-12-06 07:23:11 --> Loader Class Initialized
INFO - 2021-12-06 07:23:11 --> Helper loaded: url_helper
INFO - 2021-12-06 07:23:11 --> Helper loaded: file_helper
INFO - 2021-12-06 07:23:11 --> Helper loaded: form_helper
INFO - 2021-12-06 07:23:11 --> Helper loaded: my_helper
INFO - 2021-12-06 07:23:11 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:23:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:23:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:23:11 --> Controller Class Initialized
DEBUG - 2021-12-06 07:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-06 07:23:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:23:11 --> Final output sent to browser
DEBUG - 2021-12-06 07:23:11 --> Total execution time: 0.1535
INFO - 2021-12-06 07:38:36 --> Config Class Initialized
INFO - 2021-12-06 07:38:36 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:38:36 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:38:36 --> Utf8 Class Initialized
INFO - 2021-12-06 07:38:36 --> URI Class Initialized
INFO - 2021-12-06 07:38:36 --> Router Class Initialized
INFO - 2021-12-06 07:38:36 --> Output Class Initialized
INFO - 2021-12-06 07:38:36 --> Security Class Initialized
DEBUG - 2021-12-06 07:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:38:36 --> Input Class Initialized
INFO - 2021-12-06 07:38:36 --> Language Class Initialized
INFO - 2021-12-06 07:38:36 --> Language Class Initialized
INFO - 2021-12-06 07:38:36 --> Config Class Initialized
INFO - 2021-12-06 07:38:36 --> Loader Class Initialized
INFO - 2021-12-06 07:38:36 --> Helper loaded: url_helper
INFO - 2021-12-06 07:38:36 --> Helper loaded: file_helper
INFO - 2021-12-06 07:38:36 --> Helper loaded: form_helper
INFO - 2021-12-06 07:38:36 --> Helper loaded: my_helper
INFO - 2021-12-06 07:38:36 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:38:36 --> Controller Class Initialized
INFO - 2021-12-06 07:38:36 --> Final output sent to browser
DEBUG - 2021-12-06 07:38:36 --> Total execution time: 0.1224
INFO - 2021-12-06 07:38:52 --> Config Class Initialized
INFO - 2021-12-06 07:38:52 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:38:52 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:38:52 --> Utf8 Class Initialized
INFO - 2021-12-06 07:38:52 --> URI Class Initialized
DEBUG - 2021-12-06 07:38:52 --> No URI present. Default controller set.
INFO - 2021-12-06 07:38:52 --> Router Class Initialized
INFO - 2021-12-06 07:38:52 --> Output Class Initialized
INFO - 2021-12-06 07:38:52 --> Security Class Initialized
DEBUG - 2021-12-06 07:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:38:52 --> Input Class Initialized
INFO - 2021-12-06 07:38:52 --> Language Class Initialized
INFO - 2021-12-06 07:38:52 --> Language Class Initialized
INFO - 2021-12-06 07:38:52 --> Config Class Initialized
INFO - 2021-12-06 07:38:52 --> Loader Class Initialized
INFO - 2021-12-06 07:38:52 --> Helper loaded: url_helper
INFO - 2021-12-06 07:38:52 --> Helper loaded: file_helper
INFO - 2021-12-06 07:38:52 --> Helper loaded: form_helper
INFO - 2021-12-06 07:38:52 --> Helper loaded: my_helper
INFO - 2021-12-06 07:38:52 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:38:52 --> Controller Class Initialized
DEBUG - 2021-12-06 07:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 07:38:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:38:53 --> Final output sent to browser
DEBUG - 2021-12-06 07:38:53 --> Total execution time: 0.2373
INFO - 2021-12-06 07:38:56 --> Config Class Initialized
INFO - 2021-12-06 07:38:56 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:38:56 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:38:56 --> Utf8 Class Initialized
INFO - 2021-12-06 07:38:56 --> URI Class Initialized
INFO - 2021-12-06 07:38:56 --> Router Class Initialized
INFO - 2021-12-06 07:38:56 --> Output Class Initialized
INFO - 2021-12-06 07:38:56 --> Security Class Initialized
DEBUG - 2021-12-06 07:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:38:56 --> Input Class Initialized
INFO - 2021-12-06 07:38:56 --> Language Class Initialized
INFO - 2021-12-06 07:38:56 --> Language Class Initialized
INFO - 2021-12-06 07:38:56 --> Config Class Initialized
INFO - 2021-12-06 07:38:56 --> Loader Class Initialized
INFO - 2021-12-06 07:38:56 --> Helper loaded: url_helper
INFO - 2021-12-06 07:38:56 --> Helper loaded: file_helper
INFO - 2021-12-06 07:38:56 --> Helper loaded: form_helper
INFO - 2021-12-06 07:38:56 --> Helper loaded: my_helper
INFO - 2021-12-06 07:38:56 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:38:56 --> Controller Class Initialized
DEBUG - 2021-12-06 07:38:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-12-06 07:38:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:38:56 --> Final output sent to browser
DEBUG - 2021-12-06 07:38:56 --> Total execution time: 0.1303
INFO - 2021-12-06 07:39:00 --> Config Class Initialized
INFO - 2021-12-06 07:39:00 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:39:00 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:39:00 --> Utf8 Class Initialized
INFO - 2021-12-06 07:39:00 --> URI Class Initialized
INFO - 2021-12-06 07:39:00 --> Router Class Initialized
INFO - 2021-12-06 07:39:00 --> Output Class Initialized
INFO - 2021-12-06 07:39:00 --> Security Class Initialized
DEBUG - 2021-12-06 07:39:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:39:00 --> Input Class Initialized
INFO - 2021-12-06 07:39:00 --> Language Class Initialized
INFO - 2021-12-06 07:39:00 --> Language Class Initialized
INFO - 2021-12-06 07:39:00 --> Config Class Initialized
INFO - 2021-12-06 07:39:00 --> Loader Class Initialized
INFO - 2021-12-06 07:39:00 --> Helper loaded: url_helper
INFO - 2021-12-06 07:39:00 --> Helper loaded: file_helper
INFO - 2021-12-06 07:39:00 --> Helper loaded: form_helper
INFO - 2021-12-06 07:39:00 --> Helper loaded: my_helper
INFO - 2021-12-06 07:39:00 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:39:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:39:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:39:00 --> Controller Class Initialized
DEBUG - 2021-12-06 07:39:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-06 07:39:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:39:00 --> Final output sent to browser
DEBUG - 2021-12-06 07:39:00 --> Total execution time: 0.0751
INFO - 2021-12-06 07:39:10 --> Config Class Initialized
INFO - 2021-12-06 07:39:10 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:39:10 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:39:10 --> Utf8 Class Initialized
INFO - 2021-12-06 07:39:10 --> URI Class Initialized
INFO - 2021-12-06 07:39:10 --> Router Class Initialized
INFO - 2021-12-06 07:39:10 --> Output Class Initialized
INFO - 2021-12-06 07:39:10 --> Security Class Initialized
DEBUG - 2021-12-06 07:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:39:10 --> Input Class Initialized
INFO - 2021-12-06 07:39:10 --> Language Class Initialized
INFO - 2021-12-06 07:39:10 --> Language Class Initialized
INFO - 2021-12-06 07:39:10 --> Config Class Initialized
INFO - 2021-12-06 07:39:10 --> Loader Class Initialized
INFO - 2021-12-06 07:39:10 --> Helper loaded: url_helper
INFO - 2021-12-06 07:39:10 --> Helper loaded: file_helper
INFO - 2021-12-06 07:39:10 --> Helper loaded: form_helper
INFO - 2021-12-06 07:39:10 --> Helper loaded: my_helper
INFO - 2021-12-06 07:39:10 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:39:10 --> Controller Class Initialized
DEBUG - 2021-12-06 07:39:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-06 07:39:10 --> Final output sent to browser
DEBUG - 2021-12-06 07:39:10 --> Total execution time: 0.2566
INFO - 2021-12-06 07:39:33 --> Config Class Initialized
INFO - 2021-12-06 07:39:33 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:39:33 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:39:33 --> Utf8 Class Initialized
INFO - 2021-12-06 07:39:33 --> URI Class Initialized
INFO - 2021-12-06 07:39:33 --> Router Class Initialized
INFO - 2021-12-06 07:39:33 --> Output Class Initialized
INFO - 2021-12-06 07:39:33 --> Security Class Initialized
DEBUG - 2021-12-06 07:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:39:33 --> Input Class Initialized
INFO - 2021-12-06 07:39:33 --> Language Class Initialized
INFO - 2021-12-06 07:39:33 --> Language Class Initialized
INFO - 2021-12-06 07:39:33 --> Config Class Initialized
INFO - 2021-12-06 07:39:33 --> Loader Class Initialized
INFO - 2021-12-06 07:39:33 --> Helper loaded: url_helper
INFO - 2021-12-06 07:39:33 --> Helper loaded: file_helper
INFO - 2021-12-06 07:39:33 --> Helper loaded: form_helper
INFO - 2021-12-06 07:39:33 --> Helper loaded: my_helper
INFO - 2021-12-06 07:39:33 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:39:33 --> Controller Class Initialized
DEBUG - 2021-12-06 07:39:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-06 07:39:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:39:34 --> Final output sent to browser
DEBUG - 2021-12-06 07:39:34 --> Total execution time: 0.1161
INFO - 2021-12-06 07:43:27 --> Config Class Initialized
INFO - 2021-12-06 07:43:27 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:43:27 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:43:27 --> Utf8 Class Initialized
INFO - 2021-12-06 07:43:27 --> URI Class Initialized
INFO - 2021-12-06 07:43:27 --> Router Class Initialized
INFO - 2021-12-06 07:43:27 --> Output Class Initialized
INFO - 2021-12-06 07:43:27 --> Security Class Initialized
DEBUG - 2021-12-06 07:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:43:27 --> Input Class Initialized
INFO - 2021-12-06 07:43:27 --> Language Class Initialized
INFO - 2021-12-06 07:43:27 --> Language Class Initialized
INFO - 2021-12-06 07:43:27 --> Config Class Initialized
INFO - 2021-12-06 07:43:27 --> Loader Class Initialized
INFO - 2021-12-06 07:43:27 --> Helper loaded: url_helper
INFO - 2021-12-06 07:43:27 --> Helper loaded: file_helper
INFO - 2021-12-06 07:43:27 --> Helper loaded: form_helper
INFO - 2021-12-06 07:43:27 --> Helper loaded: my_helper
INFO - 2021-12-06 07:43:27 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:43:27 --> Controller Class Initialized
INFO - 2021-12-06 07:43:27 --> Final output sent to browser
DEBUG - 2021-12-06 07:43:27 --> Total execution time: 0.1401
INFO - 2021-12-06 07:43:42 --> Config Class Initialized
INFO - 2021-12-06 07:43:42 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:43:42 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:43:42 --> Utf8 Class Initialized
INFO - 2021-12-06 07:43:42 --> URI Class Initialized
INFO - 2021-12-06 07:43:42 --> Router Class Initialized
INFO - 2021-12-06 07:43:42 --> Output Class Initialized
INFO - 2021-12-06 07:43:42 --> Security Class Initialized
DEBUG - 2021-12-06 07:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:43:42 --> Input Class Initialized
INFO - 2021-12-06 07:43:42 --> Language Class Initialized
INFO - 2021-12-06 07:43:42 --> Language Class Initialized
INFO - 2021-12-06 07:43:42 --> Config Class Initialized
INFO - 2021-12-06 07:43:42 --> Loader Class Initialized
INFO - 2021-12-06 07:43:42 --> Helper loaded: url_helper
INFO - 2021-12-06 07:43:42 --> Helper loaded: file_helper
INFO - 2021-12-06 07:43:42 --> Helper loaded: form_helper
INFO - 2021-12-06 07:43:42 --> Helper loaded: my_helper
INFO - 2021-12-06 07:43:42 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:43:42 --> Controller Class Initialized
INFO - 2021-12-06 07:43:42 --> Final output sent to browser
DEBUG - 2021-12-06 07:43:42 --> Total execution time: 0.1043
INFO - 2021-12-06 07:43:48 --> Config Class Initialized
INFO - 2021-12-06 07:43:48 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:43:48 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:43:48 --> Utf8 Class Initialized
INFO - 2021-12-06 07:43:48 --> URI Class Initialized
INFO - 2021-12-06 07:43:48 --> Router Class Initialized
INFO - 2021-12-06 07:43:48 --> Output Class Initialized
INFO - 2021-12-06 07:43:48 --> Security Class Initialized
DEBUG - 2021-12-06 07:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:43:48 --> Input Class Initialized
INFO - 2021-12-06 07:43:48 --> Language Class Initialized
INFO - 2021-12-06 07:43:48 --> Language Class Initialized
INFO - 2021-12-06 07:43:48 --> Config Class Initialized
INFO - 2021-12-06 07:43:48 --> Loader Class Initialized
INFO - 2021-12-06 07:43:48 --> Helper loaded: url_helper
INFO - 2021-12-06 07:43:48 --> Helper loaded: file_helper
INFO - 2021-12-06 07:43:48 --> Helper loaded: form_helper
INFO - 2021-12-06 07:43:48 --> Helper loaded: my_helper
INFO - 2021-12-06 07:43:48 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:43:48 --> Controller Class Initialized
DEBUG - 2021-12-06 07:43:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-06 07:43:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:43:48 --> Final output sent to browser
DEBUG - 2021-12-06 07:43:48 --> Total execution time: 0.0663
INFO - 2021-12-06 07:43:50 --> Config Class Initialized
INFO - 2021-12-06 07:43:50 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:43:50 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:43:50 --> Utf8 Class Initialized
INFO - 2021-12-06 07:43:50 --> URI Class Initialized
INFO - 2021-12-06 07:43:50 --> Router Class Initialized
INFO - 2021-12-06 07:43:50 --> Output Class Initialized
INFO - 2021-12-06 07:43:50 --> Security Class Initialized
DEBUG - 2021-12-06 07:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:43:50 --> Input Class Initialized
INFO - 2021-12-06 07:43:50 --> Language Class Initialized
INFO - 2021-12-06 07:43:50 --> Language Class Initialized
INFO - 2021-12-06 07:43:50 --> Config Class Initialized
INFO - 2021-12-06 07:43:50 --> Loader Class Initialized
INFO - 2021-12-06 07:43:50 --> Helper loaded: url_helper
INFO - 2021-12-06 07:43:50 --> Helper loaded: file_helper
INFO - 2021-12-06 07:43:50 --> Helper loaded: form_helper
INFO - 2021-12-06 07:43:50 --> Helper loaded: my_helper
INFO - 2021-12-06 07:43:50 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:43:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:43:50 --> Controller Class Initialized
DEBUG - 2021-12-06 07:43:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-06 07:43:50 --> Final output sent to browser
DEBUG - 2021-12-06 07:43:50 --> Total execution time: 0.1238
INFO - 2021-12-06 07:44:02 --> Config Class Initialized
INFO - 2021-12-06 07:44:02 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:44:02 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:44:02 --> Utf8 Class Initialized
INFO - 2021-12-06 07:44:02 --> URI Class Initialized
INFO - 2021-12-06 07:44:02 --> Router Class Initialized
INFO - 2021-12-06 07:44:02 --> Output Class Initialized
INFO - 2021-12-06 07:44:02 --> Security Class Initialized
DEBUG - 2021-12-06 07:44:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:44:02 --> Input Class Initialized
INFO - 2021-12-06 07:44:02 --> Language Class Initialized
INFO - 2021-12-06 07:44:02 --> Language Class Initialized
INFO - 2021-12-06 07:44:02 --> Config Class Initialized
INFO - 2021-12-06 07:44:02 --> Loader Class Initialized
INFO - 2021-12-06 07:44:02 --> Helper loaded: url_helper
INFO - 2021-12-06 07:44:02 --> Helper loaded: file_helper
INFO - 2021-12-06 07:44:02 --> Helper loaded: form_helper
INFO - 2021-12-06 07:44:02 --> Helper loaded: my_helper
INFO - 2021-12-06 07:44:02 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:44:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:44:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:44:02 --> Controller Class Initialized
DEBUG - 2021-12-06 07:44:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-06 07:44:02 --> Final output sent to browser
DEBUG - 2021-12-06 07:44:02 --> Total execution time: 0.1001
INFO - 2021-12-06 07:44:35 --> Config Class Initialized
INFO - 2021-12-06 07:44:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:44:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:44:35 --> Utf8 Class Initialized
INFO - 2021-12-06 07:44:35 --> URI Class Initialized
INFO - 2021-12-06 07:44:35 --> Router Class Initialized
INFO - 2021-12-06 07:44:35 --> Output Class Initialized
INFO - 2021-12-06 07:44:35 --> Security Class Initialized
DEBUG - 2021-12-06 07:44:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:44:35 --> Input Class Initialized
INFO - 2021-12-06 07:44:35 --> Language Class Initialized
INFO - 2021-12-06 07:44:35 --> Language Class Initialized
INFO - 2021-12-06 07:44:35 --> Config Class Initialized
INFO - 2021-12-06 07:44:35 --> Loader Class Initialized
INFO - 2021-12-06 07:44:35 --> Helper loaded: url_helper
INFO - 2021-12-06 07:44:35 --> Helper loaded: file_helper
INFO - 2021-12-06 07:44:35 --> Helper loaded: form_helper
INFO - 2021-12-06 07:44:35 --> Helper loaded: my_helper
INFO - 2021-12-06 07:44:35 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:44:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:44:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:44:35 --> Controller Class Initialized
DEBUG - 2021-12-06 07:44:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 07:44:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:44:35 --> Final output sent to browser
DEBUG - 2021-12-06 07:44:35 --> Total execution time: 0.0890
INFO - 2021-12-06 07:44:43 --> Config Class Initialized
INFO - 2021-12-06 07:44:43 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:44:43 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:44:43 --> Utf8 Class Initialized
INFO - 2021-12-06 07:44:43 --> URI Class Initialized
INFO - 2021-12-06 07:44:43 --> Router Class Initialized
INFO - 2021-12-06 07:44:43 --> Output Class Initialized
INFO - 2021-12-06 07:44:43 --> Security Class Initialized
DEBUG - 2021-12-06 07:44:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:44:43 --> Input Class Initialized
INFO - 2021-12-06 07:44:43 --> Language Class Initialized
INFO - 2021-12-06 07:44:43 --> Language Class Initialized
INFO - 2021-12-06 07:44:43 --> Config Class Initialized
INFO - 2021-12-06 07:44:43 --> Loader Class Initialized
INFO - 2021-12-06 07:44:43 --> Helper loaded: url_helper
INFO - 2021-12-06 07:44:43 --> Helper loaded: file_helper
INFO - 2021-12-06 07:44:43 --> Helper loaded: form_helper
INFO - 2021-12-06 07:44:43 --> Helper loaded: my_helper
INFO - 2021-12-06 07:44:43 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:44:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:44:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:44:43 --> Controller Class Initialized
DEBUG - 2021-12-06 07:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-06 07:44:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:44:43 --> Final output sent to browser
DEBUG - 2021-12-06 07:44:43 --> Total execution time: 0.1245
INFO - 2021-12-06 07:44:46 --> Config Class Initialized
INFO - 2021-12-06 07:44:46 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:44:46 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:44:46 --> Utf8 Class Initialized
INFO - 2021-12-06 07:44:46 --> URI Class Initialized
INFO - 2021-12-06 07:44:46 --> Router Class Initialized
INFO - 2021-12-06 07:44:46 --> Output Class Initialized
INFO - 2021-12-06 07:44:46 --> Security Class Initialized
DEBUG - 2021-12-06 07:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:44:46 --> Input Class Initialized
INFO - 2021-12-06 07:44:46 --> Language Class Initialized
INFO - 2021-12-06 07:44:46 --> Language Class Initialized
INFO - 2021-12-06 07:44:46 --> Config Class Initialized
INFO - 2021-12-06 07:44:46 --> Loader Class Initialized
INFO - 2021-12-06 07:44:46 --> Helper loaded: url_helper
INFO - 2021-12-06 07:44:46 --> Helper loaded: file_helper
INFO - 2021-12-06 07:44:46 --> Helper loaded: form_helper
INFO - 2021-12-06 07:44:46 --> Helper loaded: my_helper
INFO - 2021-12-06 07:44:46 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:44:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:44:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:44:46 --> Controller Class Initialized
DEBUG - 2021-12-06 07:44:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-06 07:44:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:44:46 --> Final output sent to browser
DEBUG - 2021-12-06 07:44:46 --> Total execution time: 0.0677
INFO - 2021-12-06 07:44:48 --> Config Class Initialized
INFO - 2021-12-06 07:44:48 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:44:48 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:44:48 --> Utf8 Class Initialized
INFO - 2021-12-06 07:44:48 --> URI Class Initialized
INFO - 2021-12-06 07:44:48 --> Router Class Initialized
INFO - 2021-12-06 07:44:48 --> Output Class Initialized
INFO - 2021-12-06 07:44:48 --> Security Class Initialized
DEBUG - 2021-12-06 07:44:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:44:48 --> Input Class Initialized
INFO - 2021-12-06 07:44:48 --> Language Class Initialized
INFO - 2021-12-06 07:44:48 --> Language Class Initialized
INFO - 2021-12-06 07:44:48 --> Config Class Initialized
INFO - 2021-12-06 07:44:48 --> Loader Class Initialized
INFO - 2021-12-06 07:44:48 --> Helper loaded: url_helper
INFO - 2021-12-06 07:44:48 --> Helper loaded: file_helper
INFO - 2021-12-06 07:44:48 --> Helper loaded: form_helper
INFO - 2021-12-06 07:44:48 --> Helper loaded: my_helper
INFO - 2021-12-06 07:44:48 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:44:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:44:48 --> Controller Class Initialized
DEBUG - 2021-12-06 07:44:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-06 07:44:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:44:48 --> Final output sent to browser
DEBUG - 2021-12-06 07:44:48 --> Total execution time: 0.0637
INFO - 2021-12-06 07:44:53 --> Config Class Initialized
INFO - 2021-12-06 07:44:53 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:44:53 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:44:53 --> Utf8 Class Initialized
INFO - 2021-12-06 07:44:53 --> URI Class Initialized
INFO - 2021-12-06 07:44:53 --> Router Class Initialized
INFO - 2021-12-06 07:44:53 --> Output Class Initialized
INFO - 2021-12-06 07:44:53 --> Security Class Initialized
DEBUG - 2021-12-06 07:44:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:44:53 --> Input Class Initialized
INFO - 2021-12-06 07:44:53 --> Language Class Initialized
INFO - 2021-12-06 07:44:53 --> Language Class Initialized
INFO - 2021-12-06 07:44:53 --> Config Class Initialized
INFO - 2021-12-06 07:44:53 --> Loader Class Initialized
INFO - 2021-12-06 07:44:53 --> Helper loaded: url_helper
INFO - 2021-12-06 07:44:53 --> Helper loaded: file_helper
INFO - 2021-12-06 07:44:53 --> Helper loaded: form_helper
INFO - 2021-12-06 07:44:53 --> Helper loaded: my_helper
INFO - 2021-12-06 07:44:53 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:44:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:44:53 --> Controller Class Initialized
DEBUG - 2021-12-06 07:44:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 07:44:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:44:53 --> Final output sent to browser
DEBUG - 2021-12-06 07:44:53 --> Total execution time: 0.0638
INFO - 2021-12-06 07:45:11 --> Config Class Initialized
INFO - 2021-12-06 07:45:11 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:45:11 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:45:11 --> Utf8 Class Initialized
INFO - 2021-12-06 07:45:11 --> URI Class Initialized
INFO - 2021-12-06 07:45:11 --> Router Class Initialized
INFO - 2021-12-06 07:45:11 --> Output Class Initialized
INFO - 2021-12-06 07:45:11 --> Security Class Initialized
DEBUG - 2021-12-06 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:45:11 --> Input Class Initialized
INFO - 2021-12-06 07:45:11 --> Language Class Initialized
INFO - 2021-12-06 07:45:11 --> Language Class Initialized
INFO - 2021-12-06 07:45:11 --> Config Class Initialized
INFO - 2021-12-06 07:45:11 --> Loader Class Initialized
INFO - 2021-12-06 07:45:11 --> Helper loaded: url_helper
INFO - 2021-12-06 07:45:11 --> Helper loaded: file_helper
INFO - 2021-12-06 07:45:11 --> Helper loaded: form_helper
INFO - 2021-12-06 07:45:11 --> Helper loaded: my_helper
INFO - 2021-12-06 07:45:11 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:45:11 --> Controller Class Initialized
INFO - 2021-12-06 07:45:11 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:45:11 --> Config Class Initialized
INFO - 2021-12-06 07:45:11 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:45:11 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:45:11 --> Utf8 Class Initialized
INFO - 2021-12-06 07:45:11 --> URI Class Initialized
INFO - 2021-12-06 07:45:11 --> Router Class Initialized
INFO - 2021-12-06 07:45:11 --> Output Class Initialized
INFO - 2021-12-06 07:45:11 --> Security Class Initialized
DEBUG - 2021-12-06 07:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:45:11 --> Input Class Initialized
INFO - 2021-12-06 07:45:11 --> Language Class Initialized
INFO - 2021-12-06 07:45:11 --> Language Class Initialized
INFO - 2021-12-06 07:45:11 --> Config Class Initialized
INFO - 2021-12-06 07:45:11 --> Loader Class Initialized
INFO - 2021-12-06 07:45:11 --> Helper loaded: url_helper
INFO - 2021-12-06 07:45:11 --> Helper loaded: file_helper
INFO - 2021-12-06 07:45:11 --> Helper loaded: form_helper
INFO - 2021-12-06 07:45:11 --> Helper loaded: my_helper
INFO - 2021-12-06 07:45:11 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:45:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:45:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:45:11 --> Controller Class Initialized
DEBUG - 2021-12-06 07:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 07:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:45:11 --> Final output sent to browser
DEBUG - 2021-12-06 07:45:11 --> Total execution time: 0.0489
INFO - 2021-12-06 07:45:36 --> Config Class Initialized
INFO - 2021-12-06 07:45:36 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:45:36 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:45:36 --> Utf8 Class Initialized
INFO - 2021-12-06 07:45:36 --> URI Class Initialized
INFO - 2021-12-06 07:45:36 --> Router Class Initialized
INFO - 2021-12-06 07:45:36 --> Output Class Initialized
INFO - 2021-12-06 07:45:36 --> Security Class Initialized
DEBUG - 2021-12-06 07:45:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:45:36 --> Input Class Initialized
INFO - 2021-12-06 07:45:36 --> Language Class Initialized
INFO - 2021-12-06 07:45:36 --> Language Class Initialized
INFO - 2021-12-06 07:45:36 --> Config Class Initialized
INFO - 2021-12-06 07:45:36 --> Loader Class Initialized
INFO - 2021-12-06 07:45:36 --> Helper loaded: url_helper
INFO - 2021-12-06 07:45:36 --> Helper loaded: file_helper
INFO - 2021-12-06 07:45:36 --> Helper loaded: form_helper
INFO - 2021-12-06 07:45:36 --> Helper loaded: my_helper
INFO - 2021-12-06 07:45:36 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:45:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:45:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:45:36 --> Controller Class Initialized
INFO - 2021-12-06 07:45:36 --> Final output sent to browser
DEBUG - 2021-12-06 07:45:36 --> Total execution time: 0.0842
INFO - 2021-12-06 07:46:15 --> Config Class Initialized
INFO - 2021-12-06 07:46:15 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:15 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:15 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:15 --> URI Class Initialized
INFO - 2021-12-06 07:46:15 --> Router Class Initialized
INFO - 2021-12-06 07:46:15 --> Output Class Initialized
INFO - 2021-12-06 07:46:15 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:15 --> Input Class Initialized
INFO - 2021-12-06 07:46:15 --> Language Class Initialized
INFO - 2021-12-06 07:46:15 --> Language Class Initialized
INFO - 2021-12-06 07:46:15 --> Config Class Initialized
INFO - 2021-12-06 07:46:15 --> Loader Class Initialized
INFO - 2021-12-06 07:46:15 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:15 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:15 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:15 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:15 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:15 --> Controller Class Initialized
INFO - 2021-12-06 07:46:15 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:15 --> Total execution time: 0.0792
INFO - 2021-12-06 07:46:26 --> Config Class Initialized
INFO - 2021-12-06 07:46:26 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:26 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:26 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:26 --> URI Class Initialized
INFO - 2021-12-06 07:46:26 --> Router Class Initialized
INFO - 2021-12-06 07:46:26 --> Output Class Initialized
INFO - 2021-12-06 07:46:26 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:26 --> Input Class Initialized
INFO - 2021-12-06 07:46:26 --> Language Class Initialized
INFO - 2021-12-06 07:46:26 --> Language Class Initialized
INFO - 2021-12-06 07:46:26 --> Config Class Initialized
INFO - 2021-12-06 07:46:26 --> Loader Class Initialized
INFO - 2021-12-06 07:46:26 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:26 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:26 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:26 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:26 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:26 --> Controller Class Initialized
INFO - 2021-12-06 07:46:26 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:46:26 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:26 --> Total execution time: 0.0915
INFO - 2021-12-06 07:46:29 --> Config Class Initialized
INFO - 2021-12-06 07:46:29 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:29 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:29 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:29 --> URI Class Initialized
INFO - 2021-12-06 07:46:29 --> Router Class Initialized
INFO - 2021-12-06 07:46:29 --> Output Class Initialized
INFO - 2021-12-06 07:46:29 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:29 --> Input Class Initialized
INFO - 2021-12-06 07:46:29 --> Language Class Initialized
INFO - 2021-12-06 07:46:29 --> Language Class Initialized
INFO - 2021-12-06 07:46:29 --> Config Class Initialized
INFO - 2021-12-06 07:46:29 --> Loader Class Initialized
INFO - 2021-12-06 07:46:29 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:29 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:29 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:29 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:29 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:29 --> Controller Class Initialized
DEBUG - 2021-12-06 07:46:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 07:46:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:46:29 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:29 --> Total execution time: 0.2546
INFO - 2021-12-06 07:46:36 --> Config Class Initialized
INFO - 2021-12-06 07:46:36 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:36 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:36 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:36 --> URI Class Initialized
INFO - 2021-12-06 07:46:36 --> Router Class Initialized
INFO - 2021-12-06 07:46:36 --> Output Class Initialized
INFO - 2021-12-06 07:46:36 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:36 --> Input Class Initialized
INFO - 2021-12-06 07:46:36 --> Language Class Initialized
INFO - 2021-12-06 07:46:36 --> Language Class Initialized
INFO - 2021-12-06 07:46:36 --> Config Class Initialized
INFO - 2021-12-06 07:46:36 --> Loader Class Initialized
INFO - 2021-12-06 07:46:36 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:36 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:36 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:36 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:36 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:36 --> Controller Class Initialized
DEBUG - 2021-12-06 07:46:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-06 07:46:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:46:36 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:36 --> Total execution time: 0.0520
INFO - 2021-12-06 07:46:36 --> Config Class Initialized
INFO - 2021-12-06 07:46:36 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:36 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:36 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:36 --> URI Class Initialized
INFO - 2021-12-06 07:46:36 --> Router Class Initialized
INFO - 2021-12-06 07:46:36 --> Output Class Initialized
INFO - 2021-12-06 07:46:36 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:36 --> Input Class Initialized
INFO - 2021-12-06 07:46:36 --> Language Class Initialized
INFO - 2021-12-06 07:46:36 --> Language Class Initialized
INFO - 2021-12-06 07:46:36 --> Config Class Initialized
INFO - 2021-12-06 07:46:36 --> Loader Class Initialized
INFO - 2021-12-06 07:46:36 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:36 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:36 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:36 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:36 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:36 --> Controller Class Initialized
INFO - 2021-12-06 07:46:43 --> Config Class Initialized
INFO - 2021-12-06 07:46:43 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:43 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:43 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:43 --> URI Class Initialized
INFO - 2021-12-06 07:46:43 --> Router Class Initialized
INFO - 2021-12-06 07:46:43 --> Output Class Initialized
INFO - 2021-12-06 07:46:43 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:43 --> Input Class Initialized
INFO - 2021-12-06 07:46:43 --> Language Class Initialized
INFO - 2021-12-06 07:46:43 --> Language Class Initialized
INFO - 2021-12-06 07:46:43 --> Config Class Initialized
INFO - 2021-12-06 07:46:43 --> Loader Class Initialized
INFO - 2021-12-06 07:46:43 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:43 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:43 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:43 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:43 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:43 --> Controller Class Initialized
INFO - 2021-12-06 07:46:43 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:43 --> Total execution time: 0.0898
INFO - 2021-12-06 07:46:43 --> Config Class Initialized
INFO - 2021-12-06 07:46:43 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:43 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:43 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:43 --> URI Class Initialized
INFO - 2021-12-06 07:46:43 --> Router Class Initialized
INFO - 2021-12-06 07:46:43 --> Output Class Initialized
INFO - 2021-12-06 07:46:43 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:43 --> Input Class Initialized
INFO - 2021-12-06 07:46:43 --> Language Class Initialized
INFO - 2021-12-06 07:46:44 --> Language Class Initialized
INFO - 2021-12-06 07:46:44 --> Config Class Initialized
INFO - 2021-12-06 07:46:44 --> Loader Class Initialized
INFO - 2021-12-06 07:46:44 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:44 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:44 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:44 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:44 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:44 --> Controller Class Initialized
INFO - 2021-12-06 07:46:52 --> Config Class Initialized
INFO - 2021-12-06 07:46:52 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:52 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:52 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:52 --> URI Class Initialized
INFO - 2021-12-06 07:46:52 --> Router Class Initialized
INFO - 2021-12-06 07:46:52 --> Output Class Initialized
INFO - 2021-12-06 07:46:52 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:52 --> Input Class Initialized
INFO - 2021-12-06 07:46:52 --> Language Class Initialized
INFO - 2021-12-06 07:46:52 --> Language Class Initialized
INFO - 2021-12-06 07:46:52 --> Config Class Initialized
INFO - 2021-12-06 07:46:52 --> Loader Class Initialized
INFO - 2021-12-06 07:46:52 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:52 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:52 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:52 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:52 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:52 --> Controller Class Initialized
INFO - 2021-12-06 07:46:52 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:46:52 --> Config Class Initialized
INFO - 2021-12-06 07:46:52 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:46:52 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:46:52 --> Utf8 Class Initialized
INFO - 2021-12-06 07:46:52 --> URI Class Initialized
INFO - 2021-12-06 07:46:52 --> Router Class Initialized
INFO - 2021-12-06 07:46:52 --> Output Class Initialized
INFO - 2021-12-06 07:46:52 --> Security Class Initialized
DEBUG - 2021-12-06 07:46:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:46:52 --> Input Class Initialized
INFO - 2021-12-06 07:46:52 --> Language Class Initialized
INFO - 2021-12-06 07:46:52 --> Language Class Initialized
INFO - 2021-12-06 07:46:52 --> Config Class Initialized
INFO - 2021-12-06 07:46:52 --> Loader Class Initialized
INFO - 2021-12-06 07:46:52 --> Helper loaded: url_helper
INFO - 2021-12-06 07:46:52 --> Helper loaded: file_helper
INFO - 2021-12-06 07:46:52 --> Helper loaded: form_helper
INFO - 2021-12-06 07:46:52 --> Helper loaded: my_helper
INFO - 2021-12-06 07:46:52 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:46:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:46:52 --> Controller Class Initialized
DEBUG - 2021-12-06 07:46:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 07:46:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:46:52 --> Final output sent to browser
DEBUG - 2021-12-06 07:46:52 --> Total execution time: 0.0499
INFO - 2021-12-06 07:47:07 --> Config Class Initialized
INFO - 2021-12-06 07:47:07 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:47:07 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:47:07 --> Utf8 Class Initialized
INFO - 2021-12-06 07:47:07 --> URI Class Initialized
INFO - 2021-12-06 07:47:07 --> Router Class Initialized
INFO - 2021-12-06 07:47:07 --> Output Class Initialized
INFO - 2021-12-06 07:47:07 --> Security Class Initialized
DEBUG - 2021-12-06 07:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:47:07 --> Input Class Initialized
INFO - 2021-12-06 07:47:07 --> Language Class Initialized
INFO - 2021-12-06 07:47:07 --> Language Class Initialized
INFO - 2021-12-06 07:47:07 --> Config Class Initialized
INFO - 2021-12-06 07:47:07 --> Loader Class Initialized
INFO - 2021-12-06 07:47:07 --> Helper loaded: url_helper
INFO - 2021-12-06 07:47:07 --> Helper loaded: file_helper
INFO - 2021-12-06 07:47:07 --> Helper loaded: form_helper
INFO - 2021-12-06 07:47:07 --> Helper loaded: my_helper
INFO - 2021-12-06 07:47:07 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:47:07 --> Controller Class Initialized
INFO - 2021-12-06 07:47:07 --> Helper loaded: cookie_helper
INFO - 2021-12-06 07:47:07 --> Final output sent to browser
DEBUG - 2021-12-06 07:47:07 --> Total execution time: 0.0732
INFO - 2021-12-06 07:47:07 --> Config Class Initialized
INFO - 2021-12-06 07:47:07 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:47:07 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:47:07 --> Utf8 Class Initialized
INFO - 2021-12-06 07:47:07 --> URI Class Initialized
INFO - 2021-12-06 07:47:07 --> Router Class Initialized
INFO - 2021-12-06 07:47:07 --> Output Class Initialized
INFO - 2021-12-06 07:47:07 --> Security Class Initialized
DEBUG - 2021-12-06 07:47:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:47:07 --> Input Class Initialized
INFO - 2021-12-06 07:47:07 --> Language Class Initialized
INFO - 2021-12-06 07:47:07 --> Language Class Initialized
INFO - 2021-12-06 07:47:07 --> Config Class Initialized
INFO - 2021-12-06 07:47:07 --> Loader Class Initialized
INFO - 2021-12-06 07:47:07 --> Helper loaded: url_helper
INFO - 2021-12-06 07:47:07 --> Helper loaded: file_helper
INFO - 2021-12-06 07:47:07 --> Helper loaded: form_helper
INFO - 2021-12-06 07:47:07 --> Helper loaded: my_helper
INFO - 2021-12-06 07:47:07 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:47:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:47:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:47:07 --> Controller Class Initialized
DEBUG - 2021-12-06 07:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 07:47:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:47:08 --> Final output sent to browser
DEBUG - 2021-12-06 07:47:08 --> Total execution time: 0.2199
INFO - 2021-12-06 07:47:14 --> Config Class Initialized
INFO - 2021-12-06 07:47:14 --> Hooks Class Initialized
DEBUG - 2021-12-06 07:47:14 --> UTF-8 Support Enabled
INFO - 2021-12-06 07:47:14 --> Utf8 Class Initialized
INFO - 2021-12-06 07:47:14 --> URI Class Initialized
INFO - 2021-12-06 07:47:14 --> Router Class Initialized
INFO - 2021-12-06 07:47:14 --> Output Class Initialized
INFO - 2021-12-06 07:47:14 --> Security Class Initialized
DEBUG - 2021-12-06 07:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 07:47:14 --> Input Class Initialized
INFO - 2021-12-06 07:47:14 --> Language Class Initialized
INFO - 2021-12-06 07:47:14 --> Language Class Initialized
INFO - 2021-12-06 07:47:14 --> Config Class Initialized
INFO - 2021-12-06 07:47:14 --> Loader Class Initialized
INFO - 2021-12-06 07:47:14 --> Helper loaded: url_helper
INFO - 2021-12-06 07:47:14 --> Helper loaded: file_helper
INFO - 2021-12-06 07:47:14 --> Helper loaded: form_helper
INFO - 2021-12-06 07:47:14 --> Helper loaded: my_helper
INFO - 2021-12-06 07:47:14 --> Database Driver Class Initialized
DEBUG - 2021-12-06 07:47:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 07:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 07:47:14 --> Controller Class Initialized
DEBUG - 2021-12-06 07:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-06 07:47:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 07:47:14 --> Final output sent to browser
DEBUG - 2021-12-06 07:47:14 --> Total execution time: 0.1245
INFO - 2021-12-06 08:00:05 --> Config Class Initialized
INFO - 2021-12-06 08:00:05 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:00:05 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:00:05 --> Utf8 Class Initialized
INFO - 2021-12-06 08:00:05 --> URI Class Initialized
INFO - 2021-12-06 08:00:05 --> Router Class Initialized
INFO - 2021-12-06 08:00:05 --> Output Class Initialized
INFO - 2021-12-06 08:00:05 --> Security Class Initialized
DEBUG - 2021-12-06 08:00:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:00:05 --> Input Class Initialized
INFO - 2021-12-06 08:00:05 --> Language Class Initialized
INFO - 2021-12-06 08:00:05 --> Language Class Initialized
INFO - 2021-12-06 08:00:05 --> Config Class Initialized
INFO - 2021-12-06 08:00:05 --> Loader Class Initialized
INFO - 2021-12-06 08:00:05 --> Helper loaded: url_helper
INFO - 2021-12-06 08:00:05 --> Helper loaded: file_helper
INFO - 2021-12-06 08:00:05 --> Helper loaded: form_helper
INFO - 2021-12-06 08:00:05 --> Helper loaded: my_helper
INFO - 2021-12-06 08:00:05 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:00:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:00:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:00:05 --> Controller Class Initialized
INFO - 2021-12-06 08:00:05 --> Final output sent to browser
DEBUG - 2021-12-06 08:00:05 --> Total execution time: 0.1358
INFO - 2021-12-06 08:00:14 --> Config Class Initialized
INFO - 2021-12-06 08:00:14 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:00:14 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:00:14 --> Utf8 Class Initialized
INFO - 2021-12-06 08:00:14 --> URI Class Initialized
INFO - 2021-12-06 08:00:14 --> Router Class Initialized
INFO - 2021-12-06 08:00:14 --> Output Class Initialized
INFO - 2021-12-06 08:00:14 --> Security Class Initialized
DEBUG - 2021-12-06 08:00:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:00:14 --> Input Class Initialized
INFO - 2021-12-06 08:00:14 --> Language Class Initialized
INFO - 2021-12-06 08:00:14 --> Language Class Initialized
INFO - 2021-12-06 08:00:14 --> Config Class Initialized
INFO - 2021-12-06 08:00:14 --> Loader Class Initialized
INFO - 2021-12-06 08:00:14 --> Helper loaded: url_helper
INFO - 2021-12-06 08:00:14 --> Helper loaded: file_helper
INFO - 2021-12-06 08:00:14 --> Helper loaded: form_helper
INFO - 2021-12-06 08:00:14 --> Helper loaded: my_helper
INFO - 2021-12-06 08:00:14 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:00:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:00:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:00:14 --> Controller Class Initialized
DEBUG - 2021-12-06 08:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-06 08:00:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:00:14 --> Final output sent to browser
DEBUG - 2021-12-06 08:00:14 --> Total execution time: 0.0630
INFO - 2021-12-06 08:03:49 --> Config Class Initialized
INFO - 2021-12-06 08:03:49 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:03:49 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:03:49 --> Utf8 Class Initialized
INFO - 2021-12-06 08:03:49 --> URI Class Initialized
INFO - 2021-12-06 08:03:49 --> Router Class Initialized
INFO - 2021-12-06 08:03:49 --> Output Class Initialized
INFO - 2021-12-06 08:03:49 --> Security Class Initialized
DEBUG - 2021-12-06 08:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:03:49 --> Input Class Initialized
INFO - 2021-12-06 08:03:49 --> Language Class Initialized
INFO - 2021-12-06 08:03:49 --> Language Class Initialized
INFO - 2021-12-06 08:03:49 --> Config Class Initialized
INFO - 2021-12-06 08:03:49 --> Loader Class Initialized
INFO - 2021-12-06 08:03:49 --> Helper loaded: url_helper
INFO - 2021-12-06 08:03:49 --> Helper loaded: file_helper
INFO - 2021-12-06 08:03:49 --> Helper loaded: form_helper
INFO - 2021-12-06 08:03:49 --> Helper loaded: my_helper
INFO - 2021-12-06 08:03:49 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:03:49 --> Controller Class Initialized
INFO - 2021-12-06 08:03:49 --> Final output sent to browser
DEBUG - 2021-12-06 08:03:49 --> Total execution time: 0.1407
INFO - 2021-12-06 08:03:59 --> Config Class Initialized
INFO - 2021-12-06 08:03:59 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:03:59 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:03:59 --> Utf8 Class Initialized
INFO - 2021-12-06 08:03:59 --> URI Class Initialized
INFO - 2021-12-06 08:03:59 --> Router Class Initialized
INFO - 2021-12-06 08:03:59 --> Output Class Initialized
INFO - 2021-12-06 08:03:59 --> Security Class Initialized
DEBUG - 2021-12-06 08:03:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:03:59 --> Input Class Initialized
INFO - 2021-12-06 08:03:59 --> Language Class Initialized
INFO - 2021-12-06 08:03:59 --> Language Class Initialized
INFO - 2021-12-06 08:03:59 --> Config Class Initialized
INFO - 2021-12-06 08:03:59 --> Loader Class Initialized
INFO - 2021-12-06 08:03:59 --> Helper loaded: url_helper
INFO - 2021-12-06 08:03:59 --> Helper loaded: file_helper
INFO - 2021-12-06 08:03:59 --> Helper loaded: form_helper
INFO - 2021-12-06 08:03:59 --> Helper loaded: my_helper
INFO - 2021-12-06 08:03:59 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:03:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:03:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:03:59 --> Controller Class Initialized
INFO - 2021-12-06 08:03:59 --> Final output sent to browser
DEBUG - 2021-12-06 08:03:59 --> Total execution time: 0.1251
INFO - 2021-12-06 08:04:08 --> Config Class Initialized
INFO - 2021-12-06 08:04:08 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:04:08 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:04:08 --> Utf8 Class Initialized
INFO - 2021-12-06 08:04:08 --> URI Class Initialized
INFO - 2021-12-06 08:04:08 --> Router Class Initialized
INFO - 2021-12-06 08:04:08 --> Output Class Initialized
INFO - 2021-12-06 08:04:08 --> Security Class Initialized
DEBUG - 2021-12-06 08:04:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:04:08 --> Input Class Initialized
INFO - 2021-12-06 08:04:08 --> Language Class Initialized
INFO - 2021-12-06 08:04:08 --> Language Class Initialized
INFO - 2021-12-06 08:04:08 --> Config Class Initialized
INFO - 2021-12-06 08:04:08 --> Loader Class Initialized
INFO - 2021-12-06 08:04:08 --> Helper loaded: url_helper
INFO - 2021-12-06 08:04:08 --> Helper loaded: file_helper
INFO - 2021-12-06 08:04:08 --> Helper loaded: form_helper
INFO - 2021-12-06 08:04:08 --> Helper loaded: my_helper
INFO - 2021-12-06 08:04:08 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:04:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:04:08 --> Controller Class Initialized
DEBUG - 2021-12-06 08:04:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-06 08:04:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:04:08 --> Final output sent to browser
DEBUG - 2021-12-06 08:04:08 --> Total execution time: 0.0760
INFO - 2021-12-06 08:04:10 --> Config Class Initialized
INFO - 2021-12-06 08:04:10 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:04:10 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:04:10 --> Utf8 Class Initialized
INFO - 2021-12-06 08:04:10 --> URI Class Initialized
INFO - 2021-12-06 08:04:10 --> Router Class Initialized
INFO - 2021-12-06 08:04:10 --> Output Class Initialized
INFO - 2021-12-06 08:04:10 --> Security Class Initialized
DEBUG - 2021-12-06 08:04:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:04:10 --> Input Class Initialized
INFO - 2021-12-06 08:04:10 --> Language Class Initialized
INFO - 2021-12-06 08:04:10 --> Language Class Initialized
INFO - 2021-12-06 08:04:10 --> Config Class Initialized
INFO - 2021-12-06 08:04:10 --> Loader Class Initialized
INFO - 2021-12-06 08:04:10 --> Helper loaded: url_helper
INFO - 2021-12-06 08:04:10 --> Helper loaded: file_helper
INFO - 2021-12-06 08:04:10 --> Helper loaded: form_helper
INFO - 2021-12-06 08:04:10 --> Helper loaded: my_helper
INFO - 2021-12-06 08:04:10 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:04:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:04:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:04:10 --> Controller Class Initialized
INFO - 2021-12-06 08:04:10 --> Final output sent to browser
DEBUG - 2021-12-06 08:04:10 --> Total execution time: 0.0575
INFO - 2021-12-06 08:05:20 --> Config Class Initialized
INFO - 2021-12-06 08:05:20 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:05:20 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:05:20 --> Utf8 Class Initialized
INFO - 2021-12-06 08:05:20 --> URI Class Initialized
INFO - 2021-12-06 08:05:20 --> Router Class Initialized
INFO - 2021-12-06 08:05:20 --> Output Class Initialized
INFO - 2021-12-06 08:05:20 --> Security Class Initialized
DEBUG - 2021-12-06 08:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:05:20 --> Input Class Initialized
INFO - 2021-12-06 08:05:20 --> Language Class Initialized
INFO - 2021-12-06 08:05:20 --> Language Class Initialized
INFO - 2021-12-06 08:05:20 --> Config Class Initialized
INFO - 2021-12-06 08:05:20 --> Loader Class Initialized
INFO - 2021-12-06 08:05:20 --> Helper loaded: url_helper
INFO - 2021-12-06 08:05:20 --> Helper loaded: file_helper
INFO - 2021-12-06 08:05:20 --> Helper loaded: form_helper
INFO - 2021-12-06 08:05:20 --> Helper loaded: my_helper
INFO - 2021-12-06 08:05:20 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:05:20 --> Controller Class Initialized
INFO - 2021-12-06 08:05:20 --> Final output sent to browser
DEBUG - 2021-12-06 08:05:20 --> Total execution time: 0.1333
INFO - 2021-12-06 08:05:30 --> Config Class Initialized
INFO - 2021-12-06 08:05:30 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:05:30 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:05:30 --> Utf8 Class Initialized
INFO - 2021-12-06 08:05:30 --> URI Class Initialized
INFO - 2021-12-06 08:05:30 --> Router Class Initialized
INFO - 2021-12-06 08:05:30 --> Output Class Initialized
INFO - 2021-12-06 08:05:30 --> Security Class Initialized
DEBUG - 2021-12-06 08:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:05:30 --> Input Class Initialized
INFO - 2021-12-06 08:05:30 --> Language Class Initialized
INFO - 2021-12-06 08:05:30 --> Language Class Initialized
INFO - 2021-12-06 08:05:30 --> Config Class Initialized
INFO - 2021-12-06 08:05:30 --> Loader Class Initialized
INFO - 2021-12-06 08:05:30 --> Helper loaded: url_helper
INFO - 2021-12-06 08:05:30 --> Helper loaded: file_helper
INFO - 2021-12-06 08:05:30 --> Helper loaded: form_helper
INFO - 2021-12-06 08:05:30 --> Helper loaded: my_helper
INFO - 2021-12-06 08:05:30 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:05:30 --> Controller Class Initialized
INFO - 2021-12-06 08:05:31 --> Final output sent to browser
DEBUG - 2021-12-06 08:05:31 --> Total execution time: 0.1302
INFO - 2021-12-06 08:05:36 --> Config Class Initialized
INFO - 2021-12-06 08:05:36 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:05:36 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:05:36 --> Utf8 Class Initialized
INFO - 2021-12-06 08:05:36 --> URI Class Initialized
INFO - 2021-12-06 08:05:36 --> Router Class Initialized
INFO - 2021-12-06 08:05:36 --> Output Class Initialized
INFO - 2021-12-06 08:05:36 --> Security Class Initialized
DEBUG - 2021-12-06 08:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:05:36 --> Input Class Initialized
INFO - 2021-12-06 08:05:36 --> Language Class Initialized
INFO - 2021-12-06 08:05:36 --> Language Class Initialized
INFO - 2021-12-06 08:05:36 --> Config Class Initialized
INFO - 2021-12-06 08:05:36 --> Loader Class Initialized
INFO - 2021-12-06 08:05:36 --> Helper loaded: url_helper
INFO - 2021-12-06 08:05:36 --> Helper loaded: file_helper
INFO - 2021-12-06 08:05:36 --> Helper loaded: form_helper
INFO - 2021-12-06 08:05:36 --> Helper loaded: my_helper
INFO - 2021-12-06 08:05:36 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:05:36 --> Controller Class Initialized
DEBUG - 2021-12-06 08:05:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-06 08:05:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:05:36 --> Final output sent to browser
DEBUG - 2021-12-06 08:05:36 --> Total execution time: 0.0659
INFO - 2021-12-06 08:05:39 --> Config Class Initialized
INFO - 2021-12-06 08:05:39 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:05:39 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:05:39 --> Utf8 Class Initialized
INFO - 2021-12-06 08:05:39 --> URI Class Initialized
INFO - 2021-12-06 08:05:39 --> Router Class Initialized
INFO - 2021-12-06 08:05:39 --> Output Class Initialized
INFO - 2021-12-06 08:05:39 --> Security Class Initialized
DEBUG - 2021-12-06 08:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:05:39 --> Input Class Initialized
INFO - 2021-12-06 08:05:39 --> Language Class Initialized
INFO - 2021-12-06 08:05:39 --> Language Class Initialized
INFO - 2021-12-06 08:05:39 --> Config Class Initialized
INFO - 2021-12-06 08:05:39 --> Loader Class Initialized
INFO - 2021-12-06 08:05:39 --> Helper loaded: url_helper
INFO - 2021-12-06 08:05:39 --> Helper loaded: file_helper
INFO - 2021-12-06 08:05:39 --> Helper loaded: form_helper
INFO - 2021-12-06 08:05:39 --> Helper loaded: my_helper
INFO - 2021-12-06 08:05:39 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:05:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:05:39 --> Controller Class Initialized
DEBUG - 2021-12-06 08:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 08:05:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:05:39 --> Final output sent to browser
DEBUG - 2021-12-06 08:05:39 --> Total execution time: 0.0750
INFO - 2021-12-06 08:06:51 --> Config Class Initialized
INFO - 2021-12-06 08:06:51 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:06:51 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:06:51 --> Utf8 Class Initialized
INFO - 2021-12-06 08:06:51 --> URI Class Initialized
INFO - 2021-12-06 08:06:51 --> Router Class Initialized
INFO - 2021-12-06 08:06:51 --> Output Class Initialized
INFO - 2021-12-06 08:06:51 --> Security Class Initialized
DEBUG - 2021-12-06 08:06:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:06:51 --> Input Class Initialized
INFO - 2021-12-06 08:06:51 --> Language Class Initialized
INFO - 2021-12-06 08:06:51 --> Language Class Initialized
INFO - 2021-12-06 08:06:51 --> Config Class Initialized
INFO - 2021-12-06 08:06:51 --> Loader Class Initialized
INFO - 2021-12-06 08:06:51 --> Helper loaded: url_helper
INFO - 2021-12-06 08:06:51 --> Helper loaded: file_helper
INFO - 2021-12-06 08:06:51 --> Helper loaded: form_helper
INFO - 2021-12-06 08:06:51 --> Helper loaded: my_helper
INFO - 2021-12-06 08:06:51 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:06:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:06:51 --> Controller Class Initialized
INFO - 2021-12-06 08:06:51 --> Final output sent to browser
DEBUG - 2021-12-06 08:06:51 --> Total execution time: 0.1110
INFO - 2021-12-06 08:06:56 --> Config Class Initialized
INFO - 2021-12-06 08:06:56 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:06:56 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:06:56 --> Utf8 Class Initialized
INFO - 2021-12-06 08:06:56 --> URI Class Initialized
INFO - 2021-12-06 08:06:56 --> Router Class Initialized
INFO - 2021-12-06 08:06:56 --> Output Class Initialized
INFO - 2021-12-06 08:06:56 --> Security Class Initialized
DEBUG - 2021-12-06 08:06:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:06:56 --> Input Class Initialized
INFO - 2021-12-06 08:06:56 --> Language Class Initialized
INFO - 2021-12-06 08:06:56 --> Language Class Initialized
INFO - 2021-12-06 08:06:56 --> Config Class Initialized
INFO - 2021-12-06 08:06:56 --> Loader Class Initialized
INFO - 2021-12-06 08:06:56 --> Helper loaded: url_helper
INFO - 2021-12-06 08:06:56 --> Helper loaded: file_helper
INFO - 2021-12-06 08:06:56 --> Helper loaded: form_helper
INFO - 2021-12-06 08:06:56 --> Helper loaded: my_helper
INFO - 2021-12-06 08:06:56 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:06:56 --> Controller Class Initialized
INFO - 2021-12-06 08:06:56 --> Final output sent to browser
DEBUG - 2021-12-06 08:06:56 --> Total execution time: 0.1267
INFO - 2021-12-06 08:07:04 --> Config Class Initialized
INFO - 2021-12-06 08:07:04 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:07:04 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:07:04 --> Utf8 Class Initialized
INFO - 2021-12-06 08:07:04 --> URI Class Initialized
INFO - 2021-12-06 08:07:04 --> Router Class Initialized
INFO - 2021-12-06 08:07:04 --> Output Class Initialized
INFO - 2021-12-06 08:07:04 --> Security Class Initialized
DEBUG - 2021-12-06 08:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:07:04 --> Input Class Initialized
INFO - 2021-12-06 08:07:04 --> Language Class Initialized
INFO - 2021-12-06 08:07:04 --> Language Class Initialized
INFO - 2021-12-06 08:07:04 --> Config Class Initialized
INFO - 2021-12-06 08:07:04 --> Loader Class Initialized
INFO - 2021-12-06 08:07:04 --> Helper loaded: url_helper
INFO - 2021-12-06 08:07:04 --> Helper loaded: file_helper
INFO - 2021-12-06 08:07:04 --> Helper loaded: form_helper
INFO - 2021-12-06 08:07:04 --> Helper loaded: my_helper
INFO - 2021-12-06 08:07:04 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:07:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:07:04 --> Controller Class Initialized
DEBUG - 2021-12-06 08:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-06 08:07:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:07:04 --> Final output sent to browser
DEBUG - 2021-12-06 08:07:04 --> Total execution time: 0.0753
INFO - 2021-12-06 08:07:07 --> Config Class Initialized
INFO - 2021-12-06 08:07:07 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:07:07 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:07:07 --> Utf8 Class Initialized
INFO - 2021-12-06 08:07:07 --> URI Class Initialized
INFO - 2021-12-06 08:07:07 --> Router Class Initialized
INFO - 2021-12-06 08:07:07 --> Output Class Initialized
INFO - 2021-12-06 08:07:07 --> Security Class Initialized
DEBUG - 2021-12-06 08:07:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:07:07 --> Input Class Initialized
INFO - 2021-12-06 08:07:07 --> Language Class Initialized
INFO - 2021-12-06 08:07:07 --> Language Class Initialized
INFO - 2021-12-06 08:07:07 --> Config Class Initialized
INFO - 2021-12-06 08:07:07 --> Loader Class Initialized
INFO - 2021-12-06 08:07:07 --> Helper loaded: url_helper
INFO - 2021-12-06 08:07:07 --> Helper loaded: file_helper
INFO - 2021-12-06 08:07:07 --> Helper loaded: form_helper
INFO - 2021-12-06 08:07:07 --> Helper loaded: my_helper
INFO - 2021-12-06 08:07:07 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:07:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:07:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:07:07 --> Controller Class Initialized
DEBUG - 2021-12-06 08:07:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-06 08:07:07 --> Final output sent to browser
DEBUG - 2021-12-06 08:07:07 --> Total execution time: 0.1498
INFO - 2021-12-06 08:07:33 --> Config Class Initialized
INFO - 2021-12-06 08:07:33 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:07:33 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:07:33 --> Utf8 Class Initialized
INFO - 2021-12-06 08:07:33 --> URI Class Initialized
INFO - 2021-12-06 08:07:33 --> Router Class Initialized
INFO - 2021-12-06 08:07:33 --> Output Class Initialized
INFO - 2021-12-06 08:07:33 --> Security Class Initialized
DEBUG - 2021-12-06 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:07:33 --> Input Class Initialized
INFO - 2021-12-06 08:07:33 --> Language Class Initialized
INFO - 2021-12-06 08:07:33 --> Language Class Initialized
INFO - 2021-12-06 08:07:33 --> Config Class Initialized
INFO - 2021-12-06 08:07:33 --> Loader Class Initialized
INFO - 2021-12-06 08:07:33 --> Helper loaded: url_helper
INFO - 2021-12-06 08:07:33 --> Helper loaded: file_helper
INFO - 2021-12-06 08:07:33 --> Helper loaded: form_helper
INFO - 2021-12-06 08:07:33 --> Helper loaded: my_helper
INFO - 2021-12-06 08:07:33 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:07:33 --> Controller Class Initialized
INFO - 2021-12-06 08:07:33 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:07:33 --> Config Class Initialized
INFO - 2021-12-06 08:07:33 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:07:33 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:07:33 --> Utf8 Class Initialized
INFO - 2021-12-06 08:07:33 --> URI Class Initialized
INFO - 2021-12-06 08:07:33 --> Router Class Initialized
INFO - 2021-12-06 08:07:33 --> Output Class Initialized
INFO - 2021-12-06 08:07:33 --> Security Class Initialized
DEBUG - 2021-12-06 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:07:33 --> Input Class Initialized
INFO - 2021-12-06 08:07:33 --> Language Class Initialized
INFO - 2021-12-06 08:07:33 --> Language Class Initialized
INFO - 2021-12-06 08:07:33 --> Config Class Initialized
INFO - 2021-12-06 08:07:33 --> Loader Class Initialized
INFO - 2021-12-06 08:07:33 --> Helper loaded: url_helper
INFO - 2021-12-06 08:07:33 --> Helper loaded: file_helper
INFO - 2021-12-06 08:07:33 --> Helper loaded: form_helper
INFO - 2021-12-06 08:07:33 --> Helper loaded: my_helper
INFO - 2021-12-06 08:07:33 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:07:33 --> Controller Class Initialized
DEBUG - 2021-12-06 08:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 08:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:07:33 --> Final output sent to browser
DEBUG - 2021-12-06 08:07:33 --> Total execution time: 0.0807
INFO - 2021-12-06 08:07:56 --> Config Class Initialized
INFO - 2021-12-06 08:07:56 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:07:56 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:07:56 --> Utf8 Class Initialized
INFO - 2021-12-06 08:07:56 --> URI Class Initialized
INFO - 2021-12-06 08:07:56 --> Router Class Initialized
INFO - 2021-12-06 08:07:56 --> Output Class Initialized
INFO - 2021-12-06 08:07:56 --> Security Class Initialized
DEBUG - 2021-12-06 08:07:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:07:56 --> Input Class Initialized
INFO - 2021-12-06 08:07:56 --> Language Class Initialized
INFO - 2021-12-06 08:07:56 --> Language Class Initialized
INFO - 2021-12-06 08:07:56 --> Config Class Initialized
INFO - 2021-12-06 08:07:56 --> Loader Class Initialized
INFO - 2021-12-06 08:07:56 --> Helper loaded: url_helper
INFO - 2021-12-06 08:07:56 --> Helper loaded: file_helper
INFO - 2021-12-06 08:07:56 --> Helper loaded: form_helper
INFO - 2021-12-06 08:07:56 --> Helper loaded: my_helper
INFO - 2021-12-06 08:07:56 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:07:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:07:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:07:56 --> Controller Class Initialized
INFO - 2021-12-06 08:07:56 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:07:56 --> Final output sent to browser
DEBUG - 2021-12-06 08:07:56 --> Total execution time: 0.1001
INFO - 2021-12-06 08:07:58 --> Config Class Initialized
INFO - 2021-12-06 08:07:58 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:07:58 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:07:58 --> Utf8 Class Initialized
INFO - 2021-12-06 08:07:58 --> URI Class Initialized
INFO - 2021-12-06 08:07:58 --> Router Class Initialized
INFO - 2021-12-06 08:07:58 --> Output Class Initialized
INFO - 2021-12-06 08:07:58 --> Security Class Initialized
DEBUG - 2021-12-06 08:07:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:07:58 --> Input Class Initialized
INFO - 2021-12-06 08:07:58 --> Language Class Initialized
INFO - 2021-12-06 08:07:58 --> Language Class Initialized
INFO - 2021-12-06 08:07:58 --> Config Class Initialized
INFO - 2021-12-06 08:07:58 --> Loader Class Initialized
INFO - 2021-12-06 08:07:58 --> Helper loaded: url_helper
INFO - 2021-12-06 08:07:58 --> Helper loaded: file_helper
INFO - 2021-12-06 08:07:58 --> Helper loaded: form_helper
INFO - 2021-12-06 08:07:58 --> Helper loaded: my_helper
INFO - 2021-12-06 08:07:58 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:07:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:07:58 --> Controller Class Initialized
DEBUG - 2021-12-06 08:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 08:07:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:07:58 --> Final output sent to browser
DEBUG - 2021-12-06 08:07:58 --> Total execution time: 0.3302
INFO - 2021-12-06 08:08:09 --> Config Class Initialized
INFO - 2021-12-06 08:08:09 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:09 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:09 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:09 --> URI Class Initialized
INFO - 2021-12-06 08:08:09 --> Router Class Initialized
INFO - 2021-12-06 08:08:09 --> Output Class Initialized
INFO - 2021-12-06 08:08:09 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:09 --> Input Class Initialized
INFO - 2021-12-06 08:08:09 --> Language Class Initialized
INFO - 2021-12-06 08:08:09 --> Language Class Initialized
INFO - 2021-12-06 08:08:09 --> Config Class Initialized
INFO - 2021-12-06 08:08:09 --> Loader Class Initialized
INFO - 2021-12-06 08:08:09 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:09 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:09 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:09 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:09 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:09 --> Controller Class Initialized
DEBUG - 2021-12-06 08:08:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-06 08:08:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:08:09 --> Final output sent to browser
DEBUG - 2021-12-06 08:08:09 --> Total execution time: 0.0794
INFO - 2021-12-06 08:08:09 --> Config Class Initialized
INFO - 2021-12-06 08:08:09 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:09 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:09 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:09 --> URI Class Initialized
INFO - 2021-12-06 08:08:09 --> Router Class Initialized
INFO - 2021-12-06 08:08:09 --> Output Class Initialized
INFO - 2021-12-06 08:08:09 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:09 --> Input Class Initialized
INFO - 2021-12-06 08:08:09 --> Language Class Initialized
INFO - 2021-12-06 08:08:09 --> Language Class Initialized
INFO - 2021-12-06 08:08:09 --> Config Class Initialized
INFO - 2021-12-06 08:08:09 --> Loader Class Initialized
INFO - 2021-12-06 08:08:09 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:09 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:09 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:09 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:09 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:09 --> Controller Class Initialized
INFO - 2021-12-06 08:08:23 --> Config Class Initialized
INFO - 2021-12-06 08:08:23 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:23 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:23 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:23 --> URI Class Initialized
INFO - 2021-12-06 08:08:23 --> Router Class Initialized
INFO - 2021-12-06 08:08:23 --> Output Class Initialized
INFO - 2021-12-06 08:08:23 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:23 --> Input Class Initialized
INFO - 2021-12-06 08:08:23 --> Language Class Initialized
INFO - 2021-12-06 08:08:23 --> Language Class Initialized
INFO - 2021-12-06 08:08:23 --> Config Class Initialized
INFO - 2021-12-06 08:08:23 --> Loader Class Initialized
INFO - 2021-12-06 08:08:23 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:23 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:23 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:23 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:23 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:23 --> Controller Class Initialized
INFO - 2021-12-06 08:08:23 --> Final output sent to browser
DEBUG - 2021-12-06 08:08:23 --> Total execution time: 0.0662
INFO - 2021-12-06 08:08:23 --> Config Class Initialized
INFO - 2021-12-06 08:08:23 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:23 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:23 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:23 --> URI Class Initialized
INFO - 2021-12-06 08:08:23 --> Router Class Initialized
INFO - 2021-12-06 08:08:23 --> Output Class Initialized
INFO - 2021-12-06 08:08:23 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:23 --> Input Class Initialized
INFO - 2021-12-06 08:08:23 --> Language Class Initialized
INFO - 2021-12-06 08:08:23 --> Language Class Initialized
INFO - 2021-12-06 08:08:23 --> Config Class Initialized
INFO - 2021-12-06 08:08:23 --> Loader Class Initialized
INFO - 2021-12-06 08:08:23 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:23 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:23 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:23 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:23 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:23 --> Controller Class Initialized
INFO - 2021-12-06 08:08:31 --> Config Class Initialized
INFO - 2021-12-06 08:08:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:31 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:31 --> URI Class Initialized
INFO - 2021-12-06 08:08:31 --> Router Class Initialized
INFO - 2021-12-06 08:08:31 --> Output Class Initialized
INFO - 2021-12-06 08:08:31 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:31 --> Input Class Initialized
INFO - 2021-12-06 08:08:31 --> Language Class Initialized
INFO - 2021-12-06 08:08:31 --> Language Class Initialized
INFO - 2021-12-06 08:08:31 --> Config Class Initialized
INFO - 2021-12-06 08:08:31 --> Loader Class Initialized
INFO - 2021-12-06 08:08:31 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:31 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:31 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:31 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:31 --> Controller Class Initialized
INFO - 2021-12-06 08:08:31 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:08:31 --> Config Class Initialized
INFO - 2021-12-06 08:08:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:31 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:31 --> URI Class Initialized
INFO - 2021-12-06 08:08:31 --> Router Class Initialized
INFO - 2021-12-06 08:08:31 --> Output Class Initialized
INFO - 2021-12-06 08:08:31 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:31 --> Input Class Initialized
INFO - 2021-12-06 08:08:31 --> Language Class Initialized
INFO - 2021-12-06 08:08:31 --> Language Class Initialized
INFO - 2021-12-06 08:08:31 --> Config Class Initialized
INFO - 2021-12-06 08:08:31 --> Loader Class Initialized
INFO - 2021-12-06 08:08:31 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:31 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:31 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:31 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:31 --> Controller Class Initialized
DEBUG - 2021-12-06 08:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 08:08:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:08:31 --> Final output sent to browser
DEBUG - 2021-12-06 08:08:31 --> Total execution time: 0.0649
INFO - 2021-12-06 08:08:42 --> Config Class Initialized
INFO - 2021-12-06 08:08:42 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:42 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:42 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:42 --> URI Class Initialized
INFO - 2021-12-06 08:08:42 --> Router Class Initialized
INFO - 2021-12-06 08:08:42 --> Output Class Initialized
INFO - 2021-12-06 08:08:42 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:42 --> Input Class Initialized
INFO - 2021-12-06 08:08:42 --> Language Class Initialized
INFO - 2021-12-06 08:08:42 --> Language Class Initialized
INFO - 2021-12-06 08:08:42 --> Config Class Initialized
INFO - 2021-12-06 08:08:42 --> Loader Class Initialized
INFO - 2021-12-06 08:08:42 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:42 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:42 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:42 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:42 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:43 --> Controller Class Initialized
INFO - 2021-12-06 08:08:43 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:08:43 --> Final output sent to browser
DEBUG - 2021-12-06 08:08:43 --> Total execution time: 0.1027
INFO - 2021-12-06 08:08:45 --> Config Class Initialized
INFO - 2021-12-06 08:08:45 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:45 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:45 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:45 --> URI Class Initialized
INFO - 2021-12-06 08:08:45 --> Router Class Initialized
INFO - 2021-12-06 08:08:45 --> Output Class Initialized
INFO - 2021-12-06 08:08:45 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:45 --> Input Class Initialized
INFO - 2021-12-06 08:08:45 --> Language Class Initialized
INFO - 2021-12-06 08:08:45 --> Language Class Initialized
INFO - 2021-12-06 08:08:45 --> Config Class Initialized
INFO - 2021-12-06 08:08:45 --> Loader Class Initialized
INFO - 2021-12-06 08:08:45 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:45 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:45 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:45 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:45 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:45 --> Controller Class Initialized
DEBUG - 2021-12-06 08:08:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 08:08:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:08:45 --> Final output sent to browser
DEBUG - 2021-12-06 08:08:45 --> Total execution time: 0.2159
INFO - 2021-12-06 08:08:47 --> Config Class Initialized
INFO - 2021-12-06 08:08:47 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:08:47 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:08:47 --> Utf8 Class Initialized
INFO - 2021-12-06 08:08:47 --> URI Class Initialized
INFO - 2021-12-06 08:08:47 --> Router Class Initialized
INFO - 2021-12-06 08:08:47 --> Output Class Initialized
INFO - 2021-12-06 08:08:47 --> Security Class Initialized
DEBUG - 2021-12-06 08:08:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:08:47 --> Input Class Initialized
INFO - 2021-12-06 08:08:47 --> Language Class Initialized
INFO - 2021-12-06 08:08:47 --> Language Class Initialized
INFO - 2021-12-06 08:08:47 --> Config Class Initialized
INFO - 2021-12-06 08:08:47 --> Loader Class Initialized
INFO - 2021-12-06 08:08:47 --> Helper loaded: url_helper
INFO - 2021-12-06 08:08:47 --> Helper loaded: file_helper
INFO - 2021-12-06 08:08:47 --> Helper loaded: form_helper
INFO - 2021-12-06 08:08:47 --> Helper loaded: my_helper
INFO - 2021-12-06 08:08:47 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:08:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:08:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:08:47 --> Controller Class Initialized
DEBUG - 2021-12-06 08:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-06 08:08:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:08:47 --> Final output sent to browser
DEBUG - 2021-12-06 08:08:47 --> Total execution time: 0.1190
INFO - 2021-12-06 08:21:31 --> Config Class Initialized
INFO - 2021-12-06 08:21:31 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:21:31 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:21:31 --> Utf8 Class Initialized
INFO - 2021-12-06 08:21:31 --> URI Class Initialized
INFO - 2021-12-06 08:21:31 --> Router Class Initialized
INFO - 2021-12-06 08:21:31 --> Output Class Initialized
INFO - 2021-12-06 08:21:31 --> Security Class Initialized
DEBUG - 2021-12-06 08:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:21:31 --> Input Class Initialized
INFO - 2021-12-06 08:21:31 --> Language Class Initialized
INFO - 2021-12-06 08:21:31 --> Language Class Initialized
INFO - 2021-12-06 08:21:31 --> Config Class Initialized
INFO - 2021-12-06 08:21:31 --> Loader Class Initialized
INFO - 2021-12-06 08:21:31 --> Helper loaded: url_helper
INFO - 2021-12-06 08:21:31 --> Helper loaded: file_helper
INFO - 2021-12-06 08:21:31 --> Helper loaded: form_helper
INFO - 2021-12-06 08:21:31 --> Helper loaded: my_helper
INFO - 2021-12-06 08:21:31 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:21:31 --> Controller Class Initialized
INFO - 2021-12-06 08:21:31 --> Final output sent to browser
DEBUG - 2021-12-06 08:21:31 --> Total execution time: 0.1247
INFO - 2021-12-06 08:21:38 --> Config Class Initialized
INFO - 2021-12-06 08:21:38 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:21:38 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:21:38 --> Utf8 Class Initialized
INFO - 2021-12-06 08:21:38 --> URI Class Initialized
INFO - 2021-12-06 08:21:38 --> Router Class Initialized
INFO - 2021-12-06 08:21:38 --> Output Class Initialized
INFO - 2021-12-06 08:21:38 --> Security Class Initialized
DEBUG - 2021-12-06 08:21:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:21:38 --> Input Class Initialized
INFO - 2021-12-06 08:21:38 --> Language Class Initialized
INFO - 2021-12-06 08:21:38 --> Language Class Initialized
INFO - 2021-12-06 08:21:38 --> Config Class Initialized
INFO - 2021-12-06 08:21:38 --> Loader Class Initialized
INFO - 2021-12-06 08:21:38 --> Helper loaded: url_helper
INFO - 2021-12-06 08:21:38 --> Helper loaded: file_helper
INFO - 2021-12-06 08:21:38 --> Helper loaded: form_helper
INFO - 2021-12-06 08:21:38 --> Helper loaded: my_helper
INFO - 2021-12-06 08:21:38 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:21:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:21:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:21:38 --> Controller Class Initialized
INFO - 2021-12-06 08:21:38 --> Final output sent to browser
DEBUG - 2021-12-06 08:21:38 --> Total execution time: 0.1309
INFO - 2021-12-06 08:21:44 --> Config Class Initialized
INFO - 2021-12-06 08:21:44 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:21:44 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:21:44 --> Utf8 Class Initialized
INFO - 2021-12-06 08:21:44 --> URI Class Initialized
INFO - 2021-12-06 08:21:44 --> Router Class Initialized
INFO - 2021-12-06 08:21:44 --> Output Class Initialized
INFO - 2021-12-06 08:21:44 --> Security Class Initialized
DEBUG - 2021-12-06 08:21:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:21:44 --> Input Class Initialized
INFO - 2021-12-06 08:21:44 --> Language Class Initialized
INFO - 2021-12-06 08:21:44 --> Language Class Initialized
INFO - 2021-12-06 08:21:44 --> Config Class Initialized
INFO - 2021-12-06 08:21:44 --> Loader Class Initialized
INFO - 2021-12-06 08:21:44 --> Helper loaded: url_helper
INFO - 2021-12-06 08:21:44 --> Helper loaded: file_helper
INFO - 2021-12-06 08:21:44 --> Helper loaded: form_helper
INFO - 2021-12-06 08:21:44 --> Helper loaded: my_helper
INFO - 2021-12-06 08:21:44 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:21:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:21:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:21:44 --> Controller Class Initialized
DEBUG - 2021-12-06 08:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-06 08:21:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:21:44 --> Final output sent to browser
DEBUG - 2021-12-06 08:21:44 --> Total execution time: 0.0735
INFO - 2021-12-06 08:25:05 --> Config Class Initialized
INFO - 2021-12-06 08:25:05 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:25:05 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:25:05 --> Utf8 Class Initialized
INFO - 2021-12-06 08:25:05 --> URI Class Initialized
INFO - 2021-12-06 08:25:05 --> Router Class Initialized
INFO - 2021-12-06 08:25:05 --> Output Class Initialized
INFO - 2021-12-06 08:25:05 --> Security Class Initialized
DEBUG - 2021-12-06 08:25:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:25:05 --> Input Class Initialized
INFO - 2021-12-06 08:25:05 --> Language Class Initialized
INFO - 2021-12-06 08:25:05 --> Language Class Initialized
INFO - 2021-12-06 08:25:05 --> Config Class Initialized
INFO - 2021-12-06 08:25:05 --> Loader Class Initialized
INFO - 2021-12-06 08:25:05 --> Helper loaded: url_helper
INFO - 2021-12-06 08:25:05 --> Helper loaded: file_helper
INFO - 2021-12-06 08:25:05 --> Helper loaded: form_helper
INFO - 2021-12-06 08:25:05 --> Helper loaded: my_helper
INFO - 2021-12-06 08:25:05 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:25:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:25:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:25:05 --> Controller Class Initialized
INFO - 2021-12-06 08:25:05 --> Final output sent to browser
DEBUG - 2021-12-06 08:25:05 --> Total execution time: 0.1512
INFO - 2021-12-06 08:25:13 --> Config Class Initialized
INFO - 2021-12-06 08:25:13 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:25:13 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:25:13 --> Utf8 Class Initialized
INFO - 2021-12-06 08:25:13 --> URI Class Initialized
INFO - 2021-12-06 08:25:13 --> Router Class Initialized
INFO - 2021-12-06 08:25:13 --> Output Class Initialized
INFO - 2021-12-06 08:25:13 --> Security Class Initialized
DEBUG - 2021-12-06 08:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:25:13 --> Input Class Initialized
INFO - 2021-12-06 08:25:13 --> Language Class Initialized
INFO - 2021-12-06 08:25:13 --> Language Class Initialized
INFO - 2021-12-06 08:25:13 --> Config Class Initialized
INFO - 2021-12-06 08:25:13 --> Loader Class Initialized
INFO - 2021-12-06 08:25:13 --> Helper loaded: url_helper
INFO - 2021-12-06 08:25:13 --> Helper loaded: file_helper
INFO - 2021-12-06 08:25:13 --> Helper loaded: form_helper
INFO - 2021-12-06 08:25:13 --> Helper loaded: my_helper
INFO - 2021-12-06 08:25:13 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:25:13 --> Controller Class Initialized
DEBUG - 2021-12-06 08:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-12-06 08:25:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:25:13 --> Final output sent to browser
DEBUG - 2021-12-06 08:25:13 --> Total execution time: 0.0739
INFO - 2021-12-06 08:25:16 --> Config Class Initialized
INFO - 2021-12-06 08:25:16 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:25:16 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:25:16 --> Utf8 Class Initialized
INFO - 2021-12-06 08:25:16 --> URI Class Initialized
INFO - 2021-12-06 08:25:16 --> Router Class Initialized
INFO - 2021-12-06 08:25:16 --> Output Class Initialized
INFO - 2021-12-06 08:25:16 --> Security Class Initialized
DEBUG - 2021-12-06 08:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:25:16 --> Input Class Initialized
INFO - 2021-12-06 08:25:16 --> Language Class Initialized
INFO - 2021-12-06 08:25:16 --> Language Class Initialized
INFO - 2021-12-06 08:25:16 --> Config Class Initialized
INFO - 2021-12-06 08:25:16 --> Loader Class Initialized
INFO - 2021-12-06 08:25:16 --> Helper loaded: url_helper
INFO - 2021-12-06 08:25:16 --> Helper loaded: file_helper
INFO - 2021-12-06 08:25:16 --> Helper loaded: form_helper
INFO - 2021-12-06 08:25:16 --> Helper loaded: my_helper
INFO - 2021-12-06 08:25:16 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:25:16 --> Controller Class Initialized
INFO - 2021-12-06 08:25:16 --> Final output sent to browser
DEBUG - 2021-12-06 08:25:16 --> Total execution time: 0.0632
INFO - 2021-12-06 08:26:19 --> Config Class Initialized
INFO - 2021-12-06 08:26:19 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:26:19 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:26:19 --> Utf8 Class Initialized
INFO - 2021-12-06 08:26:19 --> URI Class Initialized
INFO - 2021-12-06 08:26:19 --> Router Class Initialized
INFO - 2021-12-06 08:26:19 --> Output Class Initialized
INFO - 2021-12-06 08:26:19 --> Security Class Initialized
DEBUG - 2021-12-06 08:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:26:19 --> Input Class Initialized
INFO - 2021-12-06 08:26:19 --> Language Class Initialized
INFO - 2021-12-06 08:26:19 --> Language Class Initialized
INFO - 2021-12-06 08:26:19 --> Config Class Initialized
INFO - 2021-12-06 08:26:19 --> Loader Class Initialized
INFO - 2021-12-06 08:26:19 --> Helper loaded: url_helper
INFO - 2021-12-06 08:26:19 --> Helper loaded: file_helper
INFO - 2021-12-06 08:26:19 --> Helper loaded: form_helper
INFO - 2021-12-06 08:26:19 --> Helper loaded: my_helper
INFO - 2021-12-06 08:26:19 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:26:19 --> Controller Class Initialized
INFO - 2021-12-06 08:26:19 --> Final output sent to browser
DEBUG - 2021-12-06 08:26:19 --> Total execution time: 0.1357
INFO - 2021-12-06 08:26:27 --> Config Class Initialized
INFO - 2021-12-06 08:26:27 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:26:27 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:26:27 --> Utf8 Class Initialized
INFO - 2021-12-06 08:26:27 --> URI Class Initialized
INFO - 2021-12-06 08:26:27 --> Router Class Initialized
INFO - 2021-12-06 08:26:27 --> Output Class Initialized
INFO - 2021-12-06 08:26:27 --> Security Class Initialized
DEBUG - 2021-12-06 08:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:26:27 --> Input Class Initialized
INFO - 2021-12-06 08:26:27 --> Language Class Initialized
INFO - 2021-12-06 08:26:27 --> Language Class Initialized
INFO - 2021-12-06 08:26:27 --> Config Class Initialized
INFO - 2021-12-06 08:26:27 --> Loader Class Initialized
INFO - 2021-12-06 08:26:27 --> Helper loaded: url_helper
INFO - 2021-12-06 08:26:27 --> Helper loaded: file_helper
INFO - 2021-12-06 08:26:27 --> Helper loaded: form_helper
INFO - 2021-12-06 08:26:27 --> Helper loaded: my_helper
INFO - 2021-12-06 08:26:27 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:26:27 --> Controller Class Initialized
DEBUG - 2021-12-06 08:26:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 08:26:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:26:27 --> Final output sent to browser
DEBUG - 2021-12-06 08:26:27 --> Total execution time: 0.0753
INFO - 2021-12-06 08:27:38 --> Config Class Initialized
INFO - 2021-12-06 08:27:38 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:27:38 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:27:38 --> Utf8 Class Initialized
INFO - 2021-12-06 08:27:38 --> URI Class Initialized
INFO - 2021-12-06 08:27:38 --> Router Class Initialized
INFO - 2021-12-06 08:27:38 --> Output Class Initialized
INFO - 2021-12-06 08:27:38 --> Security Class Initialized
DEBUG - 2021-12-06 08:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:27:38 --> Input Class Initialized
INFO - 2021-12-06 08:27:38 --> Language Class Initialized
INFO - 2021-12-06 08:27:38 --> Language Class Initialized
INFO - 2021-12-06 08:27:38 --> Config Class Initialized
INFO - 2021-12-06 08:27:38 --> Loader Class Initialized
INFO - 2021-12-06 08:27:38 --> Helper loaded: url_helper
INFO - 2021-12-06 08:27:38 --> Helper loaded: file_helper
INFO - 2021-12-06 08:27:38 --> Helper loaded: form_helper
INFO - 2021-12-06 08:27:38 --> Helper loaded: my_helper
INFO - 2021-12-06 08:27:38 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:27:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:27:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:27:38 --> Controller Class Initialized
INFO - 2021-12-06 08:27:38 --> Final output sent to browser
DEBUG - 2021-12-06 08:27:38 --> Total execution time: 0.1195
INFO - 2021-12-06 08:27:46 --> Config Class Initialized
INFO - 2021-12-06 08:27:46 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:27:46 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:27:46 --> Utf8 Class Initialized
INFO - 2021-12-06 08:27:46 --> URI Class Initialized
INFO - 2021-12-06 08:27:46 --> Router Class Initialized
INFO - 2021-12-06 08:27:46 --> Output Class Initialized
INFO - 2021-12-06 08:27:46 --> Security Class Initialized
DEBUG - 2021-12-06 08:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:27:46 --> Input Class Initialized
INFO - 2021-12-06 08:27:46 --> Language Class Initialized
INFO - 2021-12-06 08:27:46 --> Language Class Initialized
INFO - 2021-12-06 08:27:46 --> Config Class Initialized
INFO - 2021-12-06 08:27:46 --> Loader Class Initialized
INFO - 2021-12-06 08:27:46 --> Helper loaded: url_helper
INFO - 2021-12-06 08:27:46 --> Helper loaded: file_helper
INFO - 2021-12-06 08:27:46 --> Helper loaded: form_helper
INFO - 2021-12-06 08:27:46 --> Helper loaded: my_helper
INFO - 2021-12-06 08:27:46 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:27:46 --> Controller Class Initialized
DEBUG - 2021-12-06 08:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-12-06 08:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:27:46 --> Final output sent to browser
DEBUG - 2021-12-06 08:27:46 --> Total execution time: 0.0664
INFO - 2021-12-06 08:27:49 --> Config Class Initialized
INFO - 2021-12-06 08:27:49 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:27:49 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:27:49 --> Utf8 Class Initialized
INFO - 2021-12-06 08:27:49 --> URI Class Initialized
INFO - 2021-12-06 08:27:49 --> Router Class Initialized
INFO - 2021-12-06 08:27:49 --> Output Class Initialized
INFO - 2021-12-06 08:27:49 --> Security Class Initialized
DEBUG - 2021-12-06 08:27:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:27:49 --> Input Class Initialized
INFO - 2021-12-06 08:27:49 --> Language Class Initialized
INFO - 2021-12-06 08:27:49 --> Language Class Initialized
INFO - 2021-12-06 08:27:49 --> Config Class Initialized
INFO - 2021-12-06 08:27:49 --> Loader Class Initialized
INFO - 2021-12-06 08:27:49 --> Helper loaded: url_helper
INFO - 2021-12-06 08:27:49 --> Helper loaded: file_helper
INFO - 2021-12-06 08:27:49 --> Helper loaded: form_helper
INFO - 2021-12-06 08:27:49 --> Helper loaded: my_helper
INFO - 2021-12-06 08:27:49 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:27:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:27:49 --> Controller Class Initialized
DEBUG - 2021-12-06 08:27:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-06 08:27:49 --> Final output sent to browser
DEBUG - 2021-12-06 08:27:49 --> Total execution time: 0.1389
INFO - 2021-12-06 08:28:05 --> Config Class Initialized
INFO - 2021-12-06 08:28:05 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:28:05 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:28:05 --> Utf8 Class Initialized
INFO - 2021-12-06 08:28:05 --> URI Class Initialized
INFO - 2021-12-06 08:28:05 --> Router Class Initialized
INFO - 2021-12-06 08:28:05 --> Output Class Initialized
INFO - 2021-12-06 08:28:05 --> Security Class Initialized
DEBUG - 2021-12-06 08:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:28:05 --> Input Class Initialized
INFO - 2021-12-06 08:28:05 --> Language Class Initialized
INFO - 2021-12-06 08:28:05 --> Language Class Initialized
INFO - 2021-12-06 08:28:05 --> Config Class Initialized
INFO - 2021-12-06 08:28:05 --> Loader Class Initialized
INFO - 2021-12-06 08:28:05 --> Helper loaded: url_helper
INFO - 2021-12-06 08:28:05 --> Helper loaded: file_helper
INFO - 2021-12-06 08:28:05 --> Helper loaded: form_helper
INFO - 2021-12-06 08:28:05 --> Helper loaded: my_helper
INFO - 2021-12-06 08:28:05 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:28:05 --> Controller Class Initialized
DEBUG - 2021-12-06 08:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-12-06 08:28:05 --> Final output sent to browser
DEBUG - 2021-12-06 08:28:05 --> Total execution time: 0.1123
INFO - 2021-12-06 08:28:17 --> Config Class Initialized
INFO - 2021-12-06 08:28:17 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:28:17 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:28:17 --> Utf8 Class Initialized
INFO - 2021-12-06 08:28:17 --> URI Class Initialized
INFO - 2021-12-06 08:28:17 --> Router Class Initialized
INFO - 2021-12-06 08:28:17 --> Output Class Initialized
INFO - 2021-12-06 08:28:17 --> Security Class Initialized
DEBUG - 2021-12-06 08:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:28:17 --> Input Class Initialized
INFO - 2021-12-06 08:28:17 --> Language Class Initialized
INFO - 2021-12-06 08:28:17 --> Language Class Initialized
INFO - 2021-12-06 08:28:17 --> Config Class Initialized
INFO - 2021-12-06 08:28:17 --> Loader Class Initialized
INFO - 2021-12-06 08:28:17 --> Helper loaded: url_helper
INFO - 2021-12-06 08:28:17 --> Helper loaded: file_helper
INFO - 2021-12-06 08:28:17 --> Helper loaded: form_helper
INFO - 2021-12-06 08:28:17 --> Helper loaded: my_helper
INFO - 2021-12-06 08:28:17 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:28:17 --> Controller Class Initialized
DEBUG - 2021-12-06 08:28:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-12-06 08:28:18 --> Final output sent to browser
DEBUG - 2021-12-06 08:28:18 --> Total execution time: 0.2096
INFO - 2021-12-06 08:28:35 --> Config Class Initialized
INFO - 2021-12-06 08:28:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:28:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:28:35 --> Utf8 Class Initialized
INFO - 2021-12-06 08:28:35 --> URI Class Initialized
INFO - 2021-12-06 08:28:35 --> Router Class Initialized
INFO - 2021-12-06 08:28:35 --> Output Class Initialized
INFO - 2021-12-06 08:28:35 --> Security Class Initialized
DEBUG - 2021-12-06 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:28:35 --> Input Class Initialized
INFO - 2021-12-06 08:28:35 --> Language Class Initialized
INFO - 2021-12-06 08:28:35 --> Language Class Initialized
INFO - 2021-12-06 08:28:35 --> Config Class Initialized
INFO - 2021-12-06 08:28:35 --> Loader Class Initialized
INFO - 2021-12-06 08:28:35 --> Helper loaded: url_helper
INFO - 2021-12-06 08:28:35 --> Helper loaded: file_helper
INFO - 2021-12-06 08:28:35 --> Helper loaded: form_helper
INFO - 2021-12-06 08:28:35 --> Helper loaded: my_helper
INFO - 2021-12-06 08:28:35 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:28:35 --> Controller Class Initialized
INFO - 2021-12-06 08:28:35 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:28:35 --> Config Class Initialized
INFO - 2021-12-06 08:28:35 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:28:35 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:28:35 --> Utf8 Class Initialized
INFO - 2021-12-06 08:28:35 --> URI Class Initialized
INFO - 2021-12-06 08:28:35 --> Router Class Initialized
INFO - 2021-12-06 08:28:35 --> Output Class Initialized
INFO - 2021-12-06 08:28:35 --> Security Class Initialized
DEBUG - 2021-12-06 08:28:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:28:35 --> Input Class Initialized
INFO - 2021-12-06 08:28:35 --> Language Class Initialized
INFO - 2021-12-06 08:28:35 --> Language Class Initialized
INFO - 2021-12-06 08:28:35 --> Config Class Initialized
INFO - 2021-12-06 08:28:35 --> Loader Class Initialized
INFO - 2021-12-06 08:28:35 --> Helper loaded: url_helper
INFO - 2021-12-06 08:28:35 --> Helper loaded: file_helper
INFO - 2021-12-06 08:28:35 --> Helper loaded: form_helper
INFO - 2021-12-06 08:28:35 --> Helper loaded: my_helper
INFO - 2021-12-06 08:28:35 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:28:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:28:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:28:35 --> Controller Class Initialized
DEBUG - 2021-12-06 08:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 08:28:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:28:35 --> Final output sent to browser
DEBUG - 2021-12-06 08:28:35 --> Total execution time: 0.0822
INFO - 2021-12-06 08:28:46 --> Config Class Initialized
INFO - 2021-12-06 08:28:46 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:28:46 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:28:46 --> Utf8 Class Initialized
INFO - 2021-12-06 08:28:46 --> URI Class Initialized
INFO - 2021-12-06 08:28:46 --> Router Class Initialized
INFO - 2021-12-06 08:28:46 --> Output Class Initialized
INFO - 2021-12-06 08:28:46 --> Security Class Initialized
DEBUG - 2021-12-06 08:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:28:46 --> Input Class Initialized
INFO - 2021-12-06 08:28:46 --> Language Class Initialized
INFO - 2021-12-06 08:28:46 --> Language Class Initialized
INFO - 2021-12-06 08:28:46 --> Config Class Initialized
INFO - 2021-12-06 08:28:46 --> Loader Class Initialized
INFO - 2021-12-06 08:28:46 --> Helper loaded: url_helper
INFO - 2021-12-06 08:28:46 --> Helper loaded: file_helper
INFO - 2021-12-06 08:28:46 --> Helper loaded: form_helper
INFO - 2021-12-06 08:28:46 --> Helper loaded: my_helper
INFO - 2021-12-06 08:28:46 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:28:46 --> Controller Class Initialized
INFO - 2021-12-06 08:28:46 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:28:46 --> Final output sent to browser
DEBUG - 2021-12-06 08:28:46 --> Total execution time: 0.0838
INFO - 2021-12-06 08:28:48 --> Config Class Initialized
INFO - 2021-12-06 08:28:48 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:28:48 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:28:48 --> Utf8 Class Initialized
INFO - 2021-12-06 08:28:48 --> URI Class Initialized
INFO - 2021-12-06 08:28:48 --> Router Class Initialized
INFO - 2021-12-06 08:28:48 --> Output Class Initialized
INFO - 2021-12-06 08:28:48 --> Security Class Initialized
DEBUG - 2021-12-06 08:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:28:48 --> Input Class Initialized
INFO - 2021-12-06 08:28:48 --> Language Class Initialized
INFO - 2021-12-06 08:28:48 --> Language Class Initialized
INFO - 2021-12-06 08:28:48 --> Config Class Initialized
INFO - 2021-12-06 08:28:48 --> Loader Class Initialized
INFO - 2021-12-06 08:28:48 --> Helper loaded: url_helper
INFO - 2021-12-06 08:28:48 --> Helper loaded: file_helper
INFO - 2021-12-06 08:28:48 --> Helper loaded: form_helper
INFO - 2021-12-06 08:28:48 --> Helper loaded: my_helper
INFO - 2021-12-06 08:28:48 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:28:48 --> Controller Class Initialized
DEBUG - 2021-12-06 08:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 08:28:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:28:49 --> Final output sent to browser
DEBUG - 2021-12-06 08:28:49 --> Total execution time: 0.2566
INFO - 2021-12-06 08:29:17 --> Config Class Initialized
INFO - 2021-12-06 08:29:17 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:29:17 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:29:17 --> Utf8 Class Initialized
INFO - 2021-12-06 08:29:17 --> URI Class Initialized
INFO - 2021-12-06 08:29:17 --> Router Class Initialized
INFO - 2021-12-06 08:29:17 --> Output Class Initialized
INFO - 2021-12-06 08:29:17 --> Security Class Initialized
DEBUG - 2021-12-06 08:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:29:17 --> Input Class Initialized
INFO - 2021-12-06 08:29:17 --> Language Class Initialized
INFO - 2021-12-06 08:29:17 --> Language Class Initialized
INFO - 2021-12-06 08:29:17 --> Config Class Initialized
INFO - 2021-12-06 08:29:17 --> Loader Class Initialized
INFO - 2021-12-06 08:29:17 --> Helper loaded: url_helper
INFO - 2021-12-06 08:29:17 --> Helper loaded: file_helper
INFO - 2021-12-06 08:29:17 --> Helper loaded: form_helper
INFO - 2021-12-06 08:29:17 --> Helper loaded: my_helper
INFO - 2021-12-06 08:29:17 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:29:17 --> Controller Class Initialized
DEBUG - 2021-12-06 08:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-06 08:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:29:17 --> Final output sent to browser
DEBUG - 2021-12-06 08:29:17 --> Total execution time: 0.0608
INFO - 2021-12-06 08:29:17 --> Config Class Initialized
INFO - 2021-12-06 08:29:17 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:29:17 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:29:17 --> Utf8 Class Initialized
INFO - 2021-12-06 08:29:17 --> URI Class Initialized
INFO - 2021-12-06 08:29:17 --> Router Class Initialized
INFO - 2021-12-06 08:29:17 --> Output Class Initialized
INFO - 2021-12-06 08:29:17 --> Security Class Initialized
DEBUG - 2021-12-06 08:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:29:17 --> Input Class Initialized
INFO - 2021-12-06 08:29:17 --> Language Class Initialized
INFO - 2021-12-06 08:29:17 --> Language Class Initialized
INFO - 2021-12-06 08:29:17 --> Config Class Initialized
INFO - 2021-12-06 08:29:17 --> Loader Class Initialized
INFO - 2021-12-06 08:29:17 --> Helper loaded: url_helper
INFO - 2021-12-06 08:29:17 --> Helper loaded: file_helper
INFO - 2021-12-06 08:29:17 --> Helper loaded: form_helper
INFO - 2021-12-06 08:29:17 --> Helper loaded: my_helper
INFO - 2021-12-06 08:29:17 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:29:17 --> Controller Class Initialized
INFO - 2021-12-06 08:29:23 --> Config Class Initialized
INFO - 2021-12-06 08:29:23 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:29:23 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:29:23 --> Utf8 Class Initialized
INFO - 2021-12-06 08:29:23 --> URI Class Initialized
INFO - 2021-12-06 08:29:23 --> Router Class Initialized
INFO - 2021-12-06 08:29:23 --> Output Class Initialized
INFO - 2021-12-06 08:29:23 --> Security Class Initialized
DEBUG - 2021-12-06 08:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:29:23 --> Input Class Initialized
INFO - 2021-12-06 08:29:23 --> Language Class Initialized
INFO - 2021-12-06 08:29:23 --> Language Class Initialized
INFO - 2021-12-06 08:29:23 --> Config Class Initialized
INFO - 2021-12-06 08:29:23 --> Loader Class Initialized
INFO - 2021-12-06 08:29:23 --> Helper loaded: url_helper
INFO - 2021-12-06 08:29:23 --> Helper loaded: file_helper
INFO - 2021-12-06 08:29:23 --> Helper loaded: form_helper
INFO - 2021-12-06 08:29:23 --> Helper loaded: my_helper
INFO - 2021-12-06 08:29:23 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:29:23 --> Controller Class Initialized
INFO - 2021-12-06 08:29:23 --> Final output sent to browser
DEBUG - 2021-12-06 08:29:23 --> Total execution time: 0.0863
INFO - 2021-12-06 08:29:23 --> Config Class Initialized
INFO - 2021-12-06 08:29:23 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:29:23 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:29:23 --> Utf8 Class Initialized
INFO - 2021-12-06 08:29:23 --> URI Class Initialized
INFO - 2021-12-06 08:29:23 --> Router Class Initialized
INFO - 2021-12-06 08:29:23 --> Output Class Initialized
INFO - 2021-12-06 08:29:23 --> Security Class Initialized
DEBUG - 2021-12-06 08:29:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:29:23 --> Input Class Initialized
INFO - 2021-12-06 08:29:23 --> Language Class Initialized
INFO - 2021-12-06 08:29:23 --> Language Class Initialized
INFO - 2021-12-06 08:29:23 --> Config Class Initialized
INFO - 2021-12-06 08:29:23 --> Loader Class Initialized
INFO - 2021-12-06 08:29:23 --> Helper loaded: url_helper
INFO - 2021-12-06 08:29:23 --> Helper loaded: file_helper
INFO - 2021-12-06 08:29:23 --> Helper loaded: form_helper
INFO - 2021-12-06 08:29:23 --> Helper loaded: my_helper
INFO - 2021-12-06 08:29:23 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:29:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:29:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:29:23 --> Controller Class Initialized
INFO - 2021-12-06 08:29:40 --> Config Class Initialized
INFO - 2021-12-06 08:29:40 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:29:40 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:29:40 --> Utf8 Class Initialized
INFO - 2021-12-06 08:29:40 --> URI Class Initialized
INFO - 2021-12-06 08:29:40 --> Router Class Initialized
INFO - 2021-12-06 08:29:40 --> Output Class Initialized
INFO - 2021-12-06 08:29:40 --> Security Class Initialized
DEBUG - 2021-12-06 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:29:40 --> Input Class Initialized
INFO - 2021-12-06 08:29:40 --> Language Class Initialized
INFO - 2021-12-06 08:29:40 --> Language Class Initialized
INFO - 2021-12-06 08:29:40 --> Config Class Initialized
INFO - 2021-12-06 08:29:40 --> Loader Class Initialized
INFO - 2021-12-06 08:29:40 --> Helper loaded: url_helper
INFO - 2021-12-06 08:29:40 --> Helper loaded: file_helper
INFO - 2021-12-06 08:29:40 --> Helper loaded: form_helper
INFO - 2021-12-06 08:29:40 --> Helper loaded: my_helper
INFO - 2021-12-06 08:29:40 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:29:40 --> Controller Class Initialized
INFO - 2021-12-06 08:29:40 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:29:40 --> Config Class Initialized
INFO - 2021-12-06 08:29:40 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:29:40 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:29:40 --> Utf8 Class Initialized
INFO - 2021-12-06 08:29:40 --> URI Class Initialized
INFO - 2021-12-06 08:29:40 --> Router Class Initialized
INFO - 2021-12-06 08:29:40 --> Output Class Initialized
INFO - 2021-12-06 08:29:40 --> Security Class Initialized
DEBUG - 2021-12-06 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:29:40 --> Input Class Initialized
INFO - 2021-12-06 08:29:40 --> Language Class Initialized
INFO - 2021-12-06 08:29:40 --> Language Class Initialized
INFO - 2021-12-06 08:29:40 --> Config Class Initialized
INFO - 2021-12-06 08:29:40 --> Loader Class Initialized
INFO - 2021-12-06 08:29:40 --> Helper loaded: url_helper
INFO - 2021-12-06 08:29:40 --> Helper loaded: file_helper
INFO - 2021-12-06 08:29:40 --> Helper loaded: form_helper
INFO - 2021-12-06 08:29:40 --> Helper loaded: my_helper
INFO - 2021-12-06 08:29:40 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:29:40 --> Controller Class Initialized
DEBUG - 2021-12-06 08:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 08:29:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:29:40 --> Final output sent to browser
DEBUG - 2021-12-06 08:29:40 --> Total execution time: 0.0596
INFO - 2021-12-06 08:29:54 --> Config Class Initialized
INFO - 2021-12-06 08:29:54 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:29:54 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:29:54 --> Utf8 Class Initialized
INFO - 2021-12-06 08:29:54 --> URI Class Initialized
INFO - 2021-12-06 08:29:54 --> Router Class Initialized
INFO - 2021-12-06 08:29:54 --> Output Class Initialized
INFO - 2021-12-06 08:29:54 --> Security Class Initialized
DEBUG - 2021-12-06 08:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:29:54 --> Input Class Initialized
INFO - 2021-12-06 08:29:54 --> Language Class Initialized
INFO - 2021-12-06 08:29:54 --> Language Class Initialized
INFO - 2021-12-06 08:29:54 --> Config Class Initialized
INFO - 2021-12-06 08:29:54 --> Loader Class Initialized
INFO - 2021-12-06 08:29:54 --> Helper loaded: url_helper
INFO - 2021-12-06 08:29:54 --> Helper loaded: file_helper
INFO - 2021-12-06 08:29:54 --> Helper loaded: form_helper
INFO - 2021-12-06 08:29:54 --> Helper loaded: my_helper
INFO - 2021-12-06 08:29:54 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:29:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:29:54 --> Controller Class Initialized
INFO - 2021-12-06 08:29:54 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:29:54 --> Final output sent to browser
DEBUG - 2021-12-06 08:29:54 --> Total execution time: 0.0752
INFO - 2021-12-06 08:30:03 --> Config Class Initialized
INFO - 2021-12-06 08:30:03 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:30:03 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:30:03 --> Utf8 Class Initialized
INFO - 2021-12-06 08:30:03 --> URI Class Initialized
INFO - 2021-12-06 08:30:03 --> Router Class Initialized
INFO - 2021-12-06 08:30:03 --> Output Class Initialized
INFO - 2021-12-06 08:30:03 --> Security Class Initialized
DEBUG - 2021-12-06 08:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:30:03 --> Input Class Initialized
INFO - 2021-12-06 08:30:03 --> Language Class Initialized
INFO - 2021-12-06 08:30:03 --> Language Class Initialized
INFO - 2021-12-06 08:30:03 --> Config Class Initialized
INFO - 2021-12-06 08:30:03 --> Loader Class Initialized
INFO - 2021-12-06 08:30:03 --> Helper loaded: url_helper
INFO - 2021-12-06 08:30:03 --> Helper loaded: file_helper
INFO - 2021-12-06 08:30:03 --> Helper loaded: form_helper
INFO - 2021-12-06 08:30:03 --> Helper loaded: my_helper
INFO - 2021-12-06 08:30:03 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:30:03 --> Controller Class Initialized
DEBUG - 2021-12-06 08:30:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-06 08:30:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:30:04 --> Final output sent to browser
DEBUG - 2021-12-06 08:30:04 --> Total execution time: 0.9396
INFO - 2021-12-06 08:30:08 --> Config Class Initialized
INFO - 2021-12-06 08:30:08 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:30:08 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:30:08 --> Utf8 Class Initialized
INFO - 2021-12-06 08:30:08 --> URI Class Initialized
INFO - 2021-12-06 08:30:08 --> Router Class Initialized
INFO - 2021-12-06 08:30:08 --> Output Class Initialized
INFO - 2021-12-06 08:30:08 --> Security Class Initialized
DEBUG - 2021-12-06 08:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:30:08 --> Input Class Initialized
INFO - 2021-12-06 08:30:08 --> Language Class Initialized
INFO - 2021-12-06 08:30:08 --> Language Class Initialized
INFO - 2021-12-06 08:30:08 --> Config Class Initialized
INFO - 2021-12-06 08:30:08 --> Loader Class Initialized
INFO - 2021-12-06 08:30:08 --> Helper loaded: url_helper
INFO - 2021-12-06 08:30:08 --> Helper loaded: file_helper
INFO - 2021-12-06 08:30:08 --> Helper loaded: form_helper
INFO - 2021-12-06 08:30:08 --> Helper loaded: my_helper
INFO - 2021-12-06 08:30:08 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:30:08 --> Controller Class Initialized
DEBUG - 2021-12-06 08:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-12-06 08:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:30:08 --> Final output sent to browser
DEBUG - 2021-12-06 08:30:08 --> Total execution time: 0.0744
INFO - 2021-12-06 08:32:41 --> Config Class Initialized
INFO - 2021-12-06 08:32:41 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:32:41 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:32:41 --> Utf8 Class Initialized
INFO - 2021-12-06 08:32:41 --> URI Class Initialized
INFO - 2021-12-06 08:32:41 --> Router Class Initialized
INFO - 2021-12-06 08:32:41 --> Output Class Initialized
INFO - 2021-12-06 08:32:41 --> Security Class Initialized
DEBUG - 2021-12-06 08:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:32:41 --> Input Class Initialized
INFO - 2021-12-06 08:32:41 --> Language Class Initialized
INFO - 2021-12-06 08:32:41 --> Language Class Initialized
INFO - 2021-12-06 08:32:41 --> Config Class Initialized
INFO - 2021-12-06 08:32:41 --> Loader Class Initialized
INFO - 2021-12-06 08:32:41 --> Helper loaded: url_helper
INFO - 2021-12-06 08:32:41 --> Helper loaded: file_helper
INFO - 2021-12-06 08:32:41 --> Helper loaded: form_helper
INFO - 2021-12-06 08:32:41 --> Helper loaded: my_helper
INFO - 2021-12-06 08:32:41 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:32:41 --> Controller Class Initialized
DEBUG - 2021-12-06 08:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-12-06 08:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:32:41 --> Final output sent to browser
DEBUG - 2021-12-06 08:32:41 --> Total execution time: 0.1230
INFO - 2021-12-06 08:32:48 --> Config Class Initialized
INFO - 2021-12-06 08:32:48 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:32:48 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:32:48 --> Utf8 Class Initialized
INFO - 2021-12-06 08:32:48 --> URI Class Initialized
INFO - 2021-12-06 08:32:48 --> Router Class Initialized
INFO - 2021-12-06 08:32:48 --> Output Class Initialized
INFO - 2021-12-06 08:32:48 --> Security Class Initialized
DEBUG - 2021-12-06 08:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:32:48 --> Input Class Initialized
INFO - 2021-12-06 08:32:48 --> Language Class Initialized
INFO - 2021-12-06 08:32:48 --> Language Class Initialized
INFO - 2021-12-06 08:32:48 --> Config Class Initialized
INFO - 2021-12-06 08:32:48 --> Loader Class Initialized
INFO - 2021-12-06 08:32:48 --> Helper loaded: url_helper
INFO - 2021-12-06 08:32:48 --> Helper loaded: file_helper
INFO - 2021-12-06 08:32:48 --> Helper loaded: form_helper
INFO - 2021-12-06 08:32:48 --> Helper loaded: my_helper
INFO - 2021-12-06 08:32:48 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:32:48 --> Controller Class Initialized
DEBUG - 2021-12-06 08:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-12-06 08:32:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:32:48 --> Final output sent to browser
DEBUG - 2021-12-06 08:32:48 --> Total execution time: 0.0887
INFO - 2021-12-06 08:32:59 --> Config Class Initialized
INFO - 2021-12-06 08:32:59 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:32:59 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:32:59 --> Utf8 Class Initialized
INFO - 2021-12-06 08:32:59 --> URI Class Initialized
INFO - 2021-12-06 08:32:59 --> Router Class Initialized
INFO - 2021-12-06 08:32:59 --> Output Class Initialized
INFO - 2021-12-06 08:32:59 --> Security Class Initialized
DEBUG - 2021-12-06 08:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:32:59 --> Input Class Initialized
INFO - 2021-12-06 08:32:59 --> Language Class Initialized
INFO - 2021-12-06 08:32:59 --> Language Class Initialized
INFO - 2021-12-06 08:32:59 --> Config Class Initialized
INFO - 2021-12-06 08:32:59 --> Loader Class Initialized
INFO - 2021-12-06 08:32:59 --> Helper loaded: url_helper
INFO - 2021-12-06 08:32:59 --> Helper loaded: file_helper
INFO - 2021-12-06 08:32:59 --> Helper loaded: form_helper
INFO - 2021-12-06 08:32:59 --> Helper loaded: my_helper
INFO - 2021-12-06 08:32:59 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:32:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:32:59 --> Controller Class Initialized
DEBUG - 2021-12-06 08:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-12-06 08:32:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:32:59 --> Final output sent to browser
DEBUG - 2021-12-06 08:32:59 --> Total execution time: 0.1319
INFO - 2021-12-06 08:33:06 --> Config Class Initialized
INFO - 2021-12-06 08:33:06 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:33:06 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:33:06 --> Utf8 Class Initialized
INFO - 2021-12-06 08:33:06 --> URI Class Initialized
INFO - 2021-12-06 08:33:06 --> Router Class Initialized
INFO - 2021-12-06 08:33:06 --> Output Class Initialized
INFO - 2021-12-06 08:33:06 --> Security Class Initialized
DEBUG - 2021-12-06 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:33:06 --> Input Class Initialized
INFO - 2021-12-06 08:33:06 --> Language Class Initialized
INFO - 2021-12-06 08:33:06 --> Language Class Initialized
INFO - 2021-12-06 08:33:06 --> Config Class Initialized
INFO - 2021-12-06 08:33:06 --> Loader Class Initialized
INFO - 2021-12-06 08:33:06 --> Helper loaded: url_helper
INFO - 2021-12-06 08:33:06 --> Helper loaded: file_helper
INFO - 2021-12-06 08:33:06 --> Helper loaded: form_helper
INFO - 2021-12-06 08:33:06 --> Helper loaded: my_helper
INFO - 2021-12-06 08:33:06 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:33:06 --> Controller Class Initialized
INFO - 2021-12-06 08:33:06 --> Helper loaded: cookie_helper
INFO - 2021-12-06 08:33:06 --> Config Class Initialized
INFO - 2021-12-06 08:33:06 --> Hooks Class Initialized
DEBUG - 2021-12-06 08:33:06 --> UTF-8 Support Enabled
INFO - 2021-12-06 08:33:06 --> Utf8 Class Initialized
INFO - 2021-12-06 08:33:06 --> URI Class Initialized
INFO - 2021-12-06 08:33:06 --> Router Class Initialized
INFO - 2021-12-06 08:33:06 --> Output Class Initialized
INFO - 2021-12-06 08:33:06 --> Security Class Initialized
DEBUG - 2021-12-06 08:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-06 08:33:06 --> Input Class Initialized
INFO - 2021-12-06 08:33:06 --> Language Class Initialized
INFO - 2021-12-06 08:33:06 --> Language Class Initialized
INFO - 2021-12-06 08:33:06 --> Config Class Initialized
INFO - 2021-12-06 08:33:06 --> Loader Class Initialized
INFO - 2021-12-06 08:33:06 --> Helper loaded: url_helper
INFO - 2021-12-06 08:33:06 --> Helper loaded: file_helper
INFO - 2021-12-06 08:33:06 --> Helper loaded: form_helper
INFO - 2021-12-06 08:33:06 --> Helper loaded: my_helper
INFO - 2021-12-06 08:33:06 --> Database Driver Class Initialized
DEBUG - 2021-12-06 08:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-06 08:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-06 08:33:06 --> Controller Class Initialized
DEBUG - 2021-12-06 08:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-06 08:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-06 08:33:06 --> Final output sent to browser
DEBUG - 2021-12-06 08:33:06 --> Total execution time: 0.0815
