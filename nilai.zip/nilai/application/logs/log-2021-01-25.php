<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-25 01:05:28 --> Config Class Initialized
INFO - 2021-01-25 01:05:28 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:05:28 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:05:28 --> Utf8 Class Initialized
INFO - 2021-01-25 01:05:28 --> URI Class Initialized
DEBUG - 2021-01-25 01:05:28 --> No URI present. Default controller set.
INFO - 2021-01-25 01:05:28 --> Router Class Initialized
INFO - 2021-01-25 01:05:28 --> Output Class Initialized
INFO - 2021-01-25 01:05:28 --> Security Class Initialized
DEBUG - 2021-01-25 01:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:05:28 --> Input Class Initialized
INFO - 2021-01-25 01:05:28 --> Language Class Initialized
INFO - 2021-01-25 01:05:29 --> Language Class Initialized
INFO - 2021-01-25 01:05:29 --> Config Class Initialized
INFO - 2021-01-25 01:05:29 --> Loader Class Initialized
INFO - 2021-01-25 01:05:29 --> Helper loaded: url_helper
INFO - 2021-01-25 01:05:29 --> Helper loaded: file_helper
INFO - 2021-01-25 01:05:29 --> Helper loaded: form_helper
INFO - 2021-01-25 01:05:29 --> Helper loaded: my_helper
INFO - 2021-01-25 01:05:30 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:05:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:05:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:05:30 --> Controller Class Initialized
INFO - 2021-01-25 01:05:30 --> Config Class Initialized
INFO - 2021-01-25 01:05:30 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:05:30 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:05:30 --> Utf8 Class Initialized
INFO - 2021-01-25 01:05:30 --> URI Class Initialized
INFO - 2021-01-25 01:05:30 --> Router Class Initialized
INFO - 2021-01-25 01:05:30 --> Output Class Initialized
INFO - 2021-01-25 01:05:30 --> Security Class Initialized
DEBUG - 2021-01-25 01:05:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:05:30 --> Input Class Initialized
INFO - 2021-01-25 01:05:30 --> Language Class Initialized
INFO - 2021-01-25 01:05:30 --> Language Class Initialized
INFO - 2021-01-25 01:05:30 --> Config Class Initialized
INFO - 2021-01-25 01:05:30 --> Loader Class Initialized
INFO - 2021-01-25 01:05:30 --> Helper loaded: url_helper
INFO - 2021-01-25 01:05:30 --> Helper loaded: file_helper
INFO - 2021-01-25 01:05:30 --> Helper loaded: form_helper
INFO - 2021-01-25 01:05:30 --> Helper loaded: my_helper
INFO - 2021-01-25 01:05:30 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:05:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:05:31 --> Controller Class Initialized
DEBUG - 2021-01-25 01:05:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-25 01:05:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-25 01:05:31 --> Final output sent to browser
DEBUG - 2021-01-25 01:05:31 --> Total execution time: 0.8160
INFO - 2021-01-25 01:05:35 --> Config Class Initialized
INFO - 2021-01-25 01:05:35 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:05:35 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:05:35 --> Utf8 Class Initialized
INFO - 2021-01-25 01:05:36 --> URI Class Initialized
INFO - 2021-01-25 01:05:36 --> Router Class Initialized
INFO - 2021-01-25 01:05:36 --> Output Class Initialized
INFO - 2021-01-25 01:05:36 --> Security Class Initialized
DEBUG - 2021-01-25 01:05:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:05:36 --> Input Class Initialized
INFO - 2021-01-25 01:05:36 --> Language Class Initialized
INFO - 2021-01-25 01:05:36 --> Language Class Initialized
INFO - 2021-01-25 01:05:36 --> Config Class Initialized
INFO - 2021-01-25 01:05:36 --> Loader Class Initialized
INFO - 2021-01-25 01:05:36 --> Helper loaded: url_helper
INFO - 2021-01-25 01:05:36 --> Helper loaded: file_helper
INFO - 2021-01-25 01:05:36 --> Helper loaded: form_helper
INFO - 2021-01-25 01:05:36 --> Helper loaded: my_helper
INFO - 2021-01-25 01:05:36 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:05:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:05:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:05:36 --> Controller Class Initialized
INFO - 2021-01-25 01:05:36 --> Helper loaded: cookie_helper
INFO - 2021-01-25 01:05:36 --> Final output sent to browser
DEBUG - 2021-01-25 01:05:36 --> Total execution time: 0.9747
INFO - 2021-01-25 01:05:37 --> Config Class Initialized
INFO - 2021-01-25 01:05:37 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:05:37 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:05:37 --> Utf8 Class Initialized
INFO - 2021-01-25 01:05:37 --> URI Class Initialized
INFO - 2021-01-25 01:05:37 --> Router Class Initialized
INFO - 2021-01-25 01:05:37 --> Output Class Initialized
INFO - 2021-01-25 01:05:37 --> Security Class Initialized
DEBUG - 2021-01-25 01:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:05:37 --> Input Class Initialized
INFO - 2021-01-25 01:05:37 --> Language Class Initialized
INFO - 2021-01-25 01:05:37 --> Language Class Initialized
INFO - 2021-01-25 01:05:37 --> Config Class Initialized
INFO - 2021-01-25 01:05:37 --> Loader Class Initialized
INFO - 2021-01-25 01:05:37 --> Helper loaded: url_helper
INFO - 2021-01-25 01:05:37 --> Helper loaded: file_helper
INFO - 2021-01-25 01:05:37 --> Helper loaded: form_helper
INFO - 2021-01-25 01:05:38 --> Helper loaded: my_helper
INFO - 2021-01-25 01:05:38 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:05:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:05:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:05:38 --> Controller Class Initialized
DEBUG - 2021-01-25 01:05:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-25 01:05:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-25 01:05:38 --> Final output sent to browser
DEBUG - 2021-01-25 01:05:38 --> Total execution time: 1.0311
INFO - 2021-01-25 01:05:41 --> Config Class Initialized
INFO - 2021-01-25 01:05:41 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:05:41 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:05:41 --> Utf8 Class Initialized
INFO - 2021-01-25 01:05:41 --> URI Class Initialized
INFO - 2021-01-25 01:05:41 --> Router Class Initialized
INFO - 2021-01-25 01:05:41 --> Output Class Initialized
INFO - 2021-01-25 01:05:41 --> Security Class Initialized
DEBUG - 2021-01-25 01:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:05:41 --> Input Class Initialized
INFO - 2021-01-25 01:05:41 --> Language Class Initialized
INFO - 2021-01-25 01:05:42 --> Language Class Initialized
INFO - 2021-01-25 01:05:42 --> Config Class Initialized
INFO - 2021-01-25 01:05:42 --> Loader Class Initialized
INFO - 2021-01-25 01:05:42 --> Helper loaded: url_helper
INFO - 2021-01-25 01:05:42 --> Helper loaded: file_helper
INFO - 2021-01-25 01:05:42 --> Helper loaded: form_helper
INFO - 2021-01-25 01:05:42 --> Helper loaded: my_helper
INFO - 2021-01-25 01:05:42 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:05:42 --> Controller Class Initialized
DEBUG - 2021-01-25 01:05:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-25 01:05:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-25 01:05:42 --> Final output sent to browser
DEBUG - 2021-01-25 01:05:42 --> Total execution time: 0.8064
INFO - 2021-01-25 01:05:44 --> Config Class Initialized
INFO - 2021-01-25 01:05:44 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:05:44 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:05:44 --> Utf8 Class Initialized
INFO - 2021-01-25 01:05:44 --> URI Class Initialized
INFO - 2021-01-25 01:05:44 --> Router Class Initialized
INFO - 2021-01-25 01:05:44 --> Output Class Initialized
INFO - 2021-01-25 01:05:45 --> Security Class Initialized
DEBUG - 2021-01-25 01:05:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:05:45 --> Input Class Initialized
INFO - 2021-01-25 01:05:45 --> Language Class Initialized
INFO - 2021-01-25 01:05:45 --> Language Class Initialized
INFO - 2021-01-25 01:05:45 --> Config Class Initialized
INFO - 2021-01-25 01:05:45 --> Loader Class Initialized
INFO - 2021-01-25 01:05:45 --> Helper loaded: url_helper
INFO - 2021-01-25 01:05:45 --> Helper loaded: file_helper
INFO - 2021-01-25 01:05:45 --> Helper loaded: form_helper
INFO - 2021-01-25 01:05:45 --> Helper loaded: my_helper
INFO - 2021-01-25 01:05:45 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:05:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:05:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:05:45 --> Controller Class Initialized
DEBUG - 2021-01-25 01:05:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-25 01:05:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-25 01:05:45 --> Final output sent to browser
DEBUG - 2021-01-25 01:05:45 --> Total execution time: 0.7607
INFO - 2021-01-25 01:06:02 --> Config Class Initialized
INFO - 2021-01-25 01:06:02 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:06:02 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:06:02 --> Utf8 Class Initialized
INFO - 2021-01-25 01:06:02 --> URI Class Initialized
INFO - 2021-01-25 01:06:02 --> Router Class Initialized
INFO - 2021-01-25 01:06:02 --> Output Class Initialized
INFO - 2021-01-25 01:06:02 --> Security Class Initialized
DEBUG - 2021-01-25 01:06:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:06:02 --> Input Class Initialized
INFO - 2021-01-25 01:06:02 --> Language Class Initialized
INFO - 2021-01-25 01:06:02 --> Language Class Initialized
INFO - 2021-01-25 01:06:02 --> Config Class Initialized
INFO - 2021-01-25 01:06:03 --> Loader Class Initialized
INFO - 2021-01-25 01:06:03 --> Helper loaded: url_helper
INFO - 2021-01-25 01:06:03 --> Helper loaded: file_helper
INFO - 2021-01-25 01:06:03 --> Helper loaded: form_helper
INFO - 2021-01-25 01:06:03 --> Helper loaded: my_helper
INFO - 2021-01-25 01:06:03 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:06:03 --> Controller Class Initialized
DEBUG - 2021-01-25 01:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-25 01:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-25 01:06:03 --> Final output sent to browser
DEBUG - 2021-01-25 01:06:03 --> Total execution time: 0.4642
INFO - 2021-01-25 01:06:04 --> Config Class Initialized
INFO - 2021-01-25 01:06:04 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:06:04 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:06:04 --> Utf8 Class Initialized
INFO - 2021-01-25 01:06:04 --> URI Class Initialized
INFO - 2021-01-25 01:06:04 --> Router Class Initialized
INFO - 2021-01-25 01:06:04 --> Output Class Initialized
INFO - 2021-01-25 01:06:04 --> Security Class Initialized
DEBUG - 2021-01-25 01:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:06:04 --> Input Class Initialized
INFO - 2021-01-25 01:06:04 --> Language Class Initialized
INFO - 2021-01-25 01:06:05 --> Language Class Initialized
INFO - 2021-01-25 01:06:05 --> Config Class Initialized
INFO - 2021-01-25 01:06:05 --> Loader Class Initialized
INFO - 2021-01-25 01:06:05 --> Helper loaded: url_helper
INFO - 2021-01-25 01:06:05 --> Helper loaded: file_helper
INFO - 2021-01-25 01:06:05 --> Helper loaded: form_helper
INFO - 2021-01-25 01:06:05 --> Helper loaded: my_helper
INFO - 2021-01-25 01:06:05 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:06:05 --> Controller Class Initialized
DEBUG - 2021-01-25 01:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-25 01:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-25 01:06:05 --> Final output sent to browser
DEBUG - 2021-01-25 01:06:05 --> Total execution time: 0.8126
INFO - 2021-01-25 01:06:05 --> Config Class Initialized
INFO - 2021-01-25 01:06:05 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:06:05 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:06:05 --> Utf8 Class Initialized
INFO - 2021-01-25 01:06:05 --> URI Class Initialized
INFO - 2021-01-25 01:06:05 --> Router Class Initialized
INFO - 2021-01-25 01:06:05 --> Output Class Initialized
INFO - 2021-01-25 01:06:05 --> Security Class Initialized
DEBUG - 2021-01-25 01:06:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:06:05 --> Input Class Initialized
INFO - 2021-01-25 01:06:05 --> Language Class Initialized
INFO - 2021-01-25 01:06:05 --> Language Class Initialized
INFO - 2021-01-25 01:06:05 --> Config Class Initialized
INFO - 2021-01-25 01:06:05 --> Loader Class Initialized
INFO - 2021-01-25 01:06:05 --> Helper loaded: url_helper
INFO - 2021-01-25 01:06:05 --> Helper loaded: file_helper
INFO - 2021-01-25 01:06:05 --> Helper loaded: form_helper
INFO - 2021-01-25 01:06:05 --> Helper loaded: my_helper
INFO - 2021-01-25 01:06:06 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:06:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:06:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:06:06 --> Controller Class Initialized
INFO - 2021-01-25 01:06:42 --> Config Class Initialized
INFO - 2021-01-25 01:06:42 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:06:42 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:06:42 --> Utf8 Class Initialized
INFO - 2021-01-25 01:06:42 --> URI Class Initialized
INFO - 2021-01-25 01:06:42 --> Router Class Initialized
INFO - 2021-01-25 01:06:42 --> Output Class Initialized
INFO - 2021-01-25 01:06:42 --> Security Class Initialized
DEBUG - 2021-01-25 01:06:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:06:42 --> Input Class Initialized
INFO - 2021-01-25 01:06:42 --> Language Class Initialized
INFO - 2021-01-25 01:06:42 --> Language Class Initialized
INFO - 2021-01-25 01:06:42 --> Config Class Initialized
INFO - 2021-01-25 01:06:42 --> Loader Class Initialized
INFO - 2021-01-25 01:06:42 --> Helper loaded: url_helper
INFO - 2021-01-25 01:06:42 --> Helper loaded: file_helper
INFO - 2021-01-25 01:06:42 --> Helper loaded: form_helper
INFO - 2021-01-25 01:06:42 --> Helper loaded: my_helper
INFO - 2021-01-25 01:06:42 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:06:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:06:42 --> Controller Class Initialized
DEBUG - 2021-01-25 01:06:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-25 01:06:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-25 01:06:42 --> Final output sent to browser
DEBUG - 2021-01-25 01:06:42 --> Total execution time: 0.6257
INFO - 2021-01-25 01:06:42 --> Config Class Initialized
INFO - 2021-01-25 01:06:42 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:06:42 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:06:42 --> Utf8 Class Initialized
INFO - 2021-01-25 01:06:43 --> URI Class Initialized
INFO - 2021-01-25 01:06:43 --> Router Class Initialized
INFO - 2021-01-25 01:06:43 --> Output Class Initialized
INFO - 2021-01-25 01:06:43 --> Security Class Initialized
DEBUG - 2021-01-25 01:06:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:06:43 --> Input Class Initialized
INFO - 2021-01-25 01:06:43 --> Language Class Initialized
INFO - 2021-01-25 01:06:43 --> Language Class Initialized
INFO - 2021-01-25 01:06:43 --> Config Class Initialized
INFO - 2021-01-25 01:06:43 --> Loader Class Initialized
INFO - 2021-01-25 01:06:43 --> Helper loaded: url_helper
INFO - 2021-01-25 01:06:43 --> Helper loaded: file_helper
INFO - 2021-01-25 01:06:43 --> Helper loaded: form_helper
INFO - 2021-01-25 01:06:43 --> Helper loaded: my_helper
INFO - 2021-01-25 01:06:43 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:06:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:06:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:06:43 --> Controller Class Initialized
INFO - 2021-01-25 01:06:45 --> Config Class Initialized
INFO - 2021-01-25 01:06:45 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:06:45 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:06:45 --> Utf8 Class Initialized
INFO - 2021-01-25 01:06:45 --> URI Class Initialized
INFO - 2021-01-25 01:06:45 --> Router Class Initialized
INFO - 2021-01-25 01:06:45 --> Output Class Initialized
INFO - 2021-01-25 01:06:45 --> Security Class Initialized
DEBUG - 2021-01-25 01:06:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:06:45 --> Input Class Initialized
INFO - 2021-01-25 01:06:45 --> Language Class Initialized
INFO - 2021-01-25 01:06:45 --> Language Class Initialized
INFO - 2021-01-25 01:06:45 --> Config Class Initialized
INFO - 2021-01-25 01:06:45 --> Loader Class Initialized
INFO - 2021-01-25 01:06:45 --> Helper loaded: url_helper
INFO - 2021-01-25 01:06:45 --> Helper loaded: file_helper
INFO - 2021-01-25 01:06:45 --> Helper loaded: form_helper
INFO - 2021-01-25 01:06:45 --> Helper loaded: my_helper
INFO - 2021-01-25 01:06:46 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:06:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:06:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:06:46 --> Controller Class Initialized
INFO - 2021-01-25 01:06:46 --> Final output sent to browser
DEBUG - 2021-01-25 01:06:46 --> Total execution time: 0.6526
INFO - 2021-01-25 01:06:47 --> Config Class Initialized
INFO - 2021-01-25 01:06:47 --> Hooks Class Initialized
DEBUG - 2021-01-25 01:06:47 --> UTF-8 Support Enabled
INFO - 2021-01-25 01:06:47 --> Utf8 Class Initialized
INFO - 2021-01-25 01:06:47 --> URI Class Initialized
INFO - 2021-01-25 01:06:47 --> Router Class Initialized
INFO - 2021-01-25 01:06:47 --> Output Class Initialized
INFO - 2021-01-25 01:06:47 --> Security Class Initialized
DEBUG - 2021-01-25 01:06:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-25 01:06:47 --> Input Class Initialized
INFO - 2021-01-25 01:06:47 --> Language Class Initialized
INFO - 2021-01-25 01:06:47 --> Language Class Initialized
INFO - 2021-01-25 01:06:47 --> Config Class Initialized
INFO - 2021-01-25 01:06:47 --> Loader Class Initialized
INFO - 2021-01-25 01:06:47 --> Helper loaded: url_helper
INFO - 2021-01-25 01:06:47 --> Helper loaded: file_helper
INFO - 2021-01-25 01:06:47 --> Helper loaded: form_helper
INFO - 2021-01-25 01:06:47 --> Helper loaded: my_helper
INFO - 2021-01-25 01:06:48 --> Database Driver Class Initialized
DEBUG - 2021-01-25 01:06:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-25 01:06:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-25 01:06:48 --> Controller Class Initialized
INFO - 2021-01-25 01:06:48 --> Final output sent to browser
DEBUG - 2021-01-25 01:06:48 --> Total execution time: 0.6190
