<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-18 02:53:43 --> Config Class Initialized
INFO - 2020-12-18 02:53:43 --> Hooks Class Initialized
DEBUG - 2020-12-18 02:53:43 --> UTF-8 Support Enabled
INFO - 2020-12-18 02:53:43 --> Utf8 Class Initialized
INFO - 2020-12-18 02:53:43 --> URI Class Initialized
DEBUG - 2020-12-18 02:53:43 --> No URI present. Default controller set.
INFO - 2020-12-18 02:53:43 --> Router Class Initialized
INFO - 2020-12-18 02:53:43 --> Output Class Initialized
INFO - 2020-12-18 02:53:43 --> Security Class Initialized
DEBUG - 2020-12-18 02:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 02:53:44 --> Input Class Initialized
INFO - 2020-12-18 02:53:44 --> Language Class Initialized
INFO - 2020-12-18 02:53:44 --> Language Class Initialized
INFO - 2020-12-18 02:53:44 --> Config Class Initialized
INFO - 2020-12-18 02:53:44 --> Loader Class Initialized
INFO - 2020-12-18 02:53:44 --> Helper loaded: url_helper
INFO - 2020-12-18 02:53:44 --> Helper loaded: file_helper
INFO - 2020-12-18 02:53:44 --> Helper loaded: form_helper
INFO - 2020-12-18 02:53:44 --> Helper loaded: my_helper
INFO - 2020-12-18 02:53:44 --> Database Driver Class Initialized
DEBUG - 2020-12-18 02:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 02:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 02:53:44 --> Controller Class Initialized
INFO - 2020-12-18 02:53:44 --> Config Class Initialized
INFO - 2020-12-18 02:53:44 --> Hooks Class Initialized
DEBUG - 2020-12-18 02:53:44 --> UTF-8 Support Enabled
INFO - 2020-12-18 02:53:44 --> Utf8 Class Initialized
INFO - 2020-12-18 02:53:44 --> URI Class Initialized
INFO - 2020-12-18 02:53:44 --> Router Class Initialized
INFO - 2020-12-18 02:53:44 --> Output Class Initialized
INFO - 2020-12-18 02:53:44 --> Security Class Initialized
DEBUG - 2020-12-18 02:53:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 02:53:44 --> Input Class Initialized
INFO - 2020-12-18 02:53:44 --> Language Class Initialized
INFO - 2020-12-18 02:53:44 --> Language Class Initialized
INFO - 2020-12-18 02:53:44 --> Config Class Initialized
INFO - 2020-12-18 02:53:44 --> Loader Class Initialized
INFO - 2020-12-18 02:53:44 --> Helper loaded: url_helper
INFO - 2020-12-18 02:53:44 --> Helper loaded: file_helper
INFO - 2020-12-18 02:53:44 --> Helper loaded: form_helper
INFO - 2020-12-18 02:53:44 --> Helper loaded: my_helper
INFO - 2020-12-18 02:53:44 --> Database Driver Class Initialized
DEBUG - 2020-12-18 02:53:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 02:53:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 02:53:44 --> Controller Class Initialized
DEBUG - 2020-12-18 02:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-18 02:53:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 02:53:44 --> Final output sent to browser
DEBUG - 2020-12-18 02:53:45 --> Total execution time: 0.3486
INFO - 2020-12-18 03:20:11 --> Config Class Initialized
INFO - 2020-12-18 03:20:11 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:20:11 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:20:11 --> Utf8 Class Initialized
INFO - 2020-12-18 03:20:11 --> URI Class Initialized
INFO - 2020-12-18 03:20:11 --> Router Class Initialized
INFO - 2020-12-18 03:20:11 --> Output Class Initialized
INFO - 2020-12-18 03:20:11 --> Security Class Initialized
DEBUG - 2020-12-18 03:20:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:20:11 --> Input Class Initialized
INFO - 2020-12-18 03:20:11 --> Language Class Initialized
INFO - 2020-12-18 03:20:11 --> Language Class Initialized
INFO - 2020-12-18 03:20:11 --> Config Class Initialized
INFO - 2020-12-18 03:20:11 --> Loader Class Initialized
INFO - 2020-12-18 03:20:11 --> Helper loaded: url_helper
INFO - 2020-12-18 03:20:11 --> Helper loaded: file_helper
INFO - 2020-12-18 03:20:11 --> Helper loaded: form_helper
INFO - 2020-12-18 03:20:11 --> Helper loaded: my_helper
INFO - 2020-12-18 03:20:11 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:20:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:20:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:20:11 --> Controller Class Initialized
INFO - 2020-12-18 03:20:11 --> Helper loaded: cookie_helper
INFO - 2020-12-18 03:20:11 --> Final output sent to browser
DEBUG - 2020-12-18 03:20:11 --> Total execution time: 0.3916
INFO - 2020-12-18 03:20:12 --> Config Class Initialized
INFO - 2020-12-18 03:20:12 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:20:12 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:20:12 --> Utf8 Class Initialized
INFO - 2020-12-18 03:20:12 --> URI Class Initialized
INFO - 2020-12-18 03:20:12 --> Router Class Initialized
INFO - 2020-12-18 03:20:12 --> Output Class Initialized
INFO - 2020-12-18 03:20:12 --> Security Class Initialized
DEBUG - 2020-12-18 03:20:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:20:12 --> Input Class Initialized
INFO - 2020-12-18 03:20:12 --> Language Class Initialized
INFO - 2020-12-18 03:20:12 --> Language Class Initialized
INFO - 2020-12-18 03:20:12 --> Config Class Initialized
INFO - 2020-12-18 03:20:12 --> Loader Class Initialized
INFO - 2020-12-18 03:20:12 --> Helper loaded: url_helper
INFO - 2020-12-18 03:20:12 --> Helper loaded: file_helper
INFO - 2020-12-18 03:20:12 --> Helper loaded: form_helper
INFO - 2020-12-18 03:20:12 --> Helper loaded: my_helper
INFO - 2020-12-18 03:20:12 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:20:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:20:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:20:12 --> Controller Class Initialized
DEBUG - 2020-12-18 03:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-18 03:20:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 03:20:12 --> Final output sent to browser
DEBUG - 2020-12-18 03:20:12 --> Total execution time: 0.3110
INFO - 2020-12-18 03:20:15 --> Config Class Initialized
INFO - 2020-12-18 03:20:15 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:20:15 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:20:15 --> Utf8 Class Initialized
INFO - 2020-12-18 03:20:15 --> URI Class Initialized
INFO - 2020-12-18 03:20:15 --> Router Class Initialized
INFO - 2020-12-18 03:20:15 --> Output Class Initialized
INFO - 2020-12-18 03:20:15 --> Security Class Initialized
DEBUG - 2020-12-18 03:20:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:20:15 --> Input Class Initialized
INFO - 2020-12-18 03:20:15 --> Language Class Initialized
INFO - 2020-12-18 03:20:15 --> Language Class Initialized
INFO - 2020-12-18 03:20:15 --> Config Class Initialized
INFO - 2020-12-18 03:20:15 --> Loader Class Initialized
INFO - 2020-12-18 03:20:15 --> Helper loaded: url_helper
INFO - 2020-12-18 03:20:15 --> Helper loaded: file_helper
INFO - 2020-12-18 03:20:15 --> Helper loaded: form_helper
INFO - 2020-12-18 03:20:15 --> Helper loaded: my_helper
INFO - 2020-12-18 03:20:15 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:20:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:20:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:20:15 --> Controller Class Initialized
ERROR - 2020-12-18 03:20:15 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                    a.*, b.nama, a.integritas, a.religius, a.nasionalis, a.mandiri, a.gotong
                                                    FROM t_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-12-18 03:20:15 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-18 03:21:13 --> Config Class Initialized
INFO - 2020-12-18 03:21:13 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:21:13 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:21:13 --> Utf8 Class Initialized
INFO - 2020-12-18 03:21:13 --> URI Class Initialized
INFO - 2020-12-18 03:21:13 --> Router Class Initialized
INFO - 2020-12-18 03:21:13 --> Output Class Initialized
INFO - 2020-12-18 03:21:13 --> Security Class Initialized
DEBUG - 2020-12-18 03:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:21:13 --> Input Class Initialized
INFO - 2020-12-18 03:21:13 --> Language Class Initialized
INFO - 2020-12-18 03:21:13 --> Language Class Initialized
INFO - 2020-12-18 03:21:13 --> Config Class Initialized
INFO - 2020-12-18 03:21:13 --> Loader Class Initialized
INFO - 2020-12-18 03:21:13 --> Helper loaded: url_helper
INFO - 2020-12-18 03:21:13 --> Helper loaded: file_helper
INFO - 2020-12-18 03:21:13 --> Helper loaded: form_helper
INFO - 2020-12-18 03:21:13 --> Helper loaded: my_helper
INFO - 2020-12-18 03:21:13 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:21:13 --> Controller Class Initialized
DEBUG - 2020-12-18 03:21:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-18 03:21:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 03:21:13 --> Final output sent to browser
DEBUG - 2020-12-18 03:21:13 --> Total execution time: 0.1869
INFO - 2020-12-18 03:21:14 --> Config Class Initialized
INFO - 2020-12-18 03:21:14 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:21:14 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:21:14 --> Utf8 Class Initialized
INFO - 2020-12-18 03:21:14 --> URI Class Initialized
INFO - 2020-12-18 03:21:14 --> Router Class Initialized
INFO - 2020-12-18 03:21:14 --> Output Class Initialized
INFO - 2020-12-18 03:21:14 --> Security Class Initialized
DEBUG - 2020-12-18 03:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:21:14 --> Input Class Initialized
INFO - 2020-12-18 03:21:14 --> Language Class Initialized
INFO - 2020-12-18 03:21:14 --> Language Class Initialized
INFO - 2020-12-18 03:21:14 --> Config Class Initialized
INFO - 2020-12-18 03:21:14 --> Loader Class Initialized
INFO - 2020-12-18 03:21:14 --> Helper loaded: url_helper
INFO - 2020-12-18 03:21:14 --> Helper loaded: file_helper
INFO - 2020-12-18 03:21:14 --> Helper loaded: form_helper
INFO - 2020-12-18 03:21:14 --> Helper loaded: my_helper
INFO - 2020-12-18 03:21:14 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:21:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:21:15 --> Controller Class Initialized
DEBUG - 2020-12-18 03:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-18 03:21:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 03:21:15 --> Final output sent to browser
DEBUG - 2020-12-18 03:21:15 --> Total execution time: 0.2963
INFO - 2020-12-18 03:21:16 --> Config Class Initialized
INFO - 2020-12-18 03:21:16 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:21:16 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:21:16 --> Utf8 Class Initialized
INFO - 2020-12-18 03:21:16 --> URI Class Initialized
INFO - 2020-12-18 03:21:16 --> Router Class Initialized
INFO - 2020-12-18 03:21:16 --> Output Class Initialized
INFO - 2020-12-18 03:21:16 --> Security Class Initialized
DEBUG - 2020-12-18 03:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:21:16 --> Input Class Initialized
INFO - 2020-12-18 03:21:16 --> Language Class Initialized
INFO - 2020-12-18 03:21:16 --> Language Class Initialized
INFO - 2020-12-18 03:21:16 --> Config Class Initialized
INFO - 2020-12-18 03:21:16 --> Loader Class Initialized
INFO - 2020-12-18 03:21:16 --> Helper loaded: url_helper
INFO - 2020-12-18 03:21:16 --> Helper loaded: file_helper
INFO - 2020-12-18 03:21:16 --> Helper loaded: form_helper
INFO - 2020-12-18 03:21:16 --> Helper loaded: my_helper
INFO - 2020-12-18 03:21:16 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:21:16 --> Controller Class Initialized
ERROR - 2020-12-18 03:21:16 --> Query error: Unknown column 'a.ta' in 'where clause' - Invalid query: SELECT 
                                                    a.*, b.nama, a.integritas, a.religius, a.nasionalis, a.mandiri, a.gotong
                                                    FROM t_karakter a
                                                    INNER JOIN m_siswa b ON a.id_siswa = b.id
                                                    INNER JOIN t_kelas_siswa c ON CONCAT(c.ta,c.id_kelas,c.id_siswa) = CONCAT('2020','41',b.id)
                                                    WHERE c.id_kelas = '41' AND a.ta = '20201'
INFO - 2020-12-18 03:21:16 --> Language file loaded: language/english/db_lang.php
INFO - 2020-12-18 03:24:20 --> Config Class Initialized
INFO - 2020-12-18 03:24:20 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:24:20 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:24:20 --> Utf8 Class Initialized
INFO - 2020-12-18 03:24:20 --> URI Class Initialized
INFO - 2020-12-18 03:24:20 --> Router Class Initialized
INFO - 2020-12-18 03:24:20 --> Output Class Initialized
INFO - 2020-12-18 03:24:20 --> Security Class Initialized
DEBUG - 2020-12-18 03:24:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:24:20 --> Input Class Initialized
INFO - 2020-12-18 03:24:20 --> Language Class Initialized
INFO - 2020-12-18 03:24:20 --> Language Class Initialized
INFO - 2020-12-18 03:24:20 --> Config Class Initialized
INFO - 2020-12-18 03:24:20 --> Loader Class Initialized
INFO - 2020-12-18 03:24:20 --> Helper loaded: url_helper
INFO - 2020-12-18 03:24:20 --> Helper loaded: file_helper
INFO - 2020-12-18 03:24:20 --> Helper loaded: form_helper
INFO - 2020-12-18 03:24:20 --> Helper loaded: my_helper
INFO - 2020-12-18 03:24:20 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:24:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:24:20 --> Controller Class Initialized
DEBUG - 2020-12-18 03:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-18 03:24:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 03:24:20 --> Final output sent to browser
DEBUG - 2020-12-18 03:24:20 --> Total execution time: 0.1962
INFO - 2020-12-18 03:25:53 --> Config Class Initialized
INFO - 2020-12-18 03:25:53 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:25:53 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:25:53 --> Utf8 Class Initialized
INFO - 2020-12-18 03:25:53 --> URI Class Initialized
INFO - 2020-12-18 03:25:53 --> Router Class Initialized
INFO - 2020-12-18 03:25:53 --> Output Class Initialized
INFO - 2020-12-18 03:25:53 --> Security Class Initialized
DEBUG - 2020-12-18 03:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:25:54 --> Input Class Initialized
INFO - 2020-12-18 03:25:54 --> Language Class Initialized
INFO - 2020-12-18 03:25:54 --> Language Class Initialized
INFO - 2020-12-18 03:25:54 --> Config Class Initialized
INFO - 2020-12-18 03:25:54 --> Loader Class Initialized
INFO - 2020-12-18 03:25:54 --> Helper loaded: url_helper
INFO - 2020-12-18 03:25:54 --> Helper loaded: file_helper
INFO - 2020-12-18 03:25:54 --> Helper loaded: form_helper
INFO - 2020-12-18 03:25:54 --> Helper loaded: my_helper
INFO - 2020-12-18 03:25:54 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:25:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:25:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:25:54 --> Controller Class Initialized
DEBUG - 2020-12-18 03:25:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2020-12-18 03:25:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 03:25:54 --> Final output sent to browser
DEBUG - 2020-12-18 03:25:54 --> Total execution time: 0.2030
INFO - 2020-12-18 03:26:22 --> Config Class Initialized
INFO - 2020-12-18 03:26:22 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:26:22 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:26:22 --> Utf8 Class Initialized
INFO - 2020-12-18 03:26:22 --> URI Class Initialized
INFO - 2020-12-18 03:26:22 --> Router Class Initialized
INFO - 2020-12-18 03:26:22 --> Output Class Initialized
INFO - 2020-12-18 03:26:22 --> Security Class Initialized
DEBUG - 2020-12-18 03:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:26:22 --> Input Class Initialized
INFO - 2020-12-18 03:26:22 --> Language Class Initialized
INFO - 2020-12-18 03:26:22 --> Language Class Initialized
INFO - 2020-12-18 03:26:22 --> Config Class Initialized
INFO - 2020-12-18 03:26:22 --> Loader Class Initialized
INFO - 2020-12-18 03:26:22 --> Helper loaded: url_helper
INFO - 2020-12-18 03:26:22 --> Helper loaded: file_helper
INFO - 2020-12-18 03:26:22 --> Helper loaded: form_helper
INFO - 2020-12-18 03:26:22 --> Helper loaded: my_helper
INFO - 2020-12-18 03:26:22 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:26:22 --> Controller Class Initialized
DEBUG - 2020-12-18 03:26:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-18 03:26:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 03:26:22 --> Final output sent to browser
DEBUG - 2020-12-18 03:26:22 --> Total execution time: 0.1759
INFO - 2020-12-18 03:32:25 --> Config Class Initialized
INFO - 2020-12-18 03:32:25 --> Hooks Class Initialized
DEBUG - 2020-12-18 03:32:25 --> UTF-8 Support Enabled
INFO - 2020-12-18 03:32:25 --> Utf8 Class Initialized
INFO - 2020-12-18 03:32:25 --> URI Class Initialized
INFO - 2020-12-18 03:32:25 --> Router Class Initialized
INFO - 2020-12-18 03:32:25 --> Output Class Initialized
INFO - 2020-12-18 03:32:25 --> Security Class Initialized
DEBUG - 2020-12-18 03:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 03:32:25 --> Input Class Initialized
INFO - 2020-12-18 03:32:25 --> Language Class Initialized
INFO - 2020-12-18 03:32:25 --> Language Class Initialized
INFO - 2020-12-18 03:32:25 --> Config Class Initialized
INFO - 2020-12-18 03:32:25 --> Loader Class Initialized
INFO - 2020-12-18 03:32:25 --> Helper loaded: url_helper
INFO - 2020-12-18 03:32:25 --> Helper loaded: file_helper
INFO - 2020-12-18 03:32:25 --> Helper loaded: form_helper
INFO - 2020-12-18 03:32:25 --> Helper loaded: my_helper
INFO - 2020-12-18 03:32:25 --> Database Driver Class Initialized
DEBUG - 2020-12-18 03:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 03:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 03:32:25 --> Controller Class Initialized
INFO - 2020-12-18 03:32:27 --> Final output sent to browser
DEBUG - 2020-12-18 03:32:27 --> Total execution time: 2.0682
INFO - 2020-12-18 04:45:41 --> Config Class Initialized
INFO - 2020-12-18 04:45:41 --> Hooks Class Initialized
DEBUG - 2020-12-18 04:45:41 --> UTF-8 Support Enabled
INFO - 2020-12-18 04:45:41 --> Utf8 Class Initialized
INFO - 2020-12-18 04:45:41 --> URI Class Initialized
INFO - 2020-12-18 04:45:41 --> Router Class Initialized
INFO - 2020-12-18 04:45:41 --> Output Class Initialized
INFO - 2020-12-18 04:45:41 --> Security Class Initialized
DEBUG - 2020-12-18 04:45:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 04:45:41 --> Input Class Initialized
INFO - 2020-12-18 04:45:41 --> Language Class Initialized
INFO - 2020-12-18 04:45:41 --> Language Class Initialized
INFO - 2020-12-18 04:45:41 --> Config Class Initialized
INFO - 2020-12-18 04:45:41 --> Loader Class Initialized
INFO - 2020-12-18 04:45:41 --> Helper loaded: url_helper
INFO - 2020-12-18 04:45:41 --> Helper loaded: file_helper
INFO - 2020-12-18 04:45:41 --> Helper loaded: form_helper
INFO - 2020-12-18 04:45:41 --> Helper loaded: my_helper
INFO - 2020-12-18 04:45:41 --> Database Driver Class Initialized
DEBUG - 2020-12-18 04:45:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 04:45:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 04:45:41 --> Controller Class Initialized
ERROR - 2020-12-18 04:45:41 --> Severity: Parsing Error --> syntax error, unexpected '$c_integritas' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 117
INFO - 2020-12-18 04:51:42 --> Config Class Initialized
INFO - 2020-12-18 04:51:42 --> Hooks Class Initialized
DEBUG - 2020-12-18 04:51:42 --> UTF-8 Support Enabled
INFO - 2020-12-18 04:51:42 --> Utf8 Class Initialized
INFO - 2020-12-18 04:51:42 --> URI Class Initialized
INFO - 2020-12-18 04:51:42 --> Router Class Initialized
INFO - 2020-12-18 04:51:42 --> Output Class Initialized
INFO - 2020-12-18 04:51:42 --> Security Class Initialized
DEBUG - 2020-12-18 04:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 04:51:42 --> Input Class Initialized
INFO - 2020-12-18 04:51:42 --> Language Class Initialized
INFO - 2020-12-18 04:51:42 --> Language Class Initialized
INFO - 2020-12-18 04:51:42 --> Config Class Initialized
INFO - 2020-12-18 04:51:42 --> Loader Class Initialized
INFO - 2020-12-18 04:51:42 --> Helper loaded: url_helper
INFO - 2020-12-18 04:51:42 --> Helper loaded: file_helper
INFO - 2020-12-18 04:51:42 --> Helper loaded: form_helper
INFO - 2020-12-18 04:51:42 --> Helper loaded: my_helper
INFO - 2020-12-18 04:51:42 --> Database Driver Class Initialized
DEBUG - 2020-12-18 04:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 04:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 04:51:42 --> Controller Class Initialized
ERROR - 2020-12-18 04:51:42 --> Severity: Parsing Error --> syntax error, unexpected '$c_integritas' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 117
INFO - 2020-12-18 04:51:43 --> Config Class Initialized
INFO - 2020-12-18 04:51:43 --> Hooks Class Initialized
DEBUG - 2020-12-18 04:51:43 --> UTF-8 Support Enabled
INFO - 2020-12-18 04:51:43 --> Utf8 Class Initialized
INFO - 2020-12-18 04:51:43 --> URI Class Initialized
INFO - 2020-12-18 04:51:43 --> Router Class Initialized
INFO - 2020-12-18 04:51:43 --> Output Class Initialized
INFO - 2020-12-18 04:51:43 --> Security Class Initialized
DEBUG - 2020-12-18 04:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 04:51:43 --> Input Class Initialized
INFO - 2020-12-18 04:51:43 --> Language Class Initialized
INFO - 2020-12-18 04:51:43 --> Language Class Initialized
INFO - 2020-12-18 04:51:43 --> Config Class Initialized
INFO - 2020-12-18 04:51:43 --> Loader Class Initialized
INFO - 2020-12-18 04:51:43 --> Helper loaded: url_helper
INFO - 2020-12-18 04:51:43 --> Helper loaded: file_helper
INFO - 2020-12-18 04:51:43 --> Helper loaded: form_helper
INFO - 2020-12-18 04:51:43 --> Helper loaded: my_helper
INFO - 2020-12-18 04:51:43 --> Database Driver Class Initialized
DEBUG - 2020-12-18 04:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 04:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 04:51:43 --> Controller Class Initialized
ERROR - 2020-12-18 04:51:43 --> Severity: Parsing Error --> syntax error, unexpected '$c_integritas' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 117
INFO - 2020-12-18 04:51:45 --> Config Class Initialized
INFO - 2020-12-18 04:51:45 --> Hooks Class Initialized
DEBUG - 2020-12-18 04:51:45 --> UTF-8 Support Enabled
INFO - 2020-12-18 04:51:45 --> Utf8 Class Initialized
INFO - 2020-12-18 04:51:45 --> URI Class Initialized
INFO - 2020-12-18 04:51:45 --> Router Class Initialized
INFO - 2020-12-18 04:51:45 --> Output Class Initialized
INFO - 2020-12-18 04:51:45 --> Security Class Initialized
DEBUG - 2020-12-18 04:51:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 04:51:45 --> Input Class Initialized
INFO - 2020-12-18 04:51:45 --> Language Class Initialized
INFO - 2020-12-18 04:51:45 --> Language Class Initialized
INFO - 2020-12-18 04:51:45 --> Config Class Initialized
INFO - 2020-12-18 04:51:45 --> Loader Class Initialized
INFO - 2020-12-18 04:51:45 --> Helper loaded: url_helper
INFO - 2020-12-18 04:51:45 --> Helper loaded: file_helper
INFO - 2020-12-18 04:51:45 --> Helper loaded: form_helper
INFO - 2020-12-18 04:51:45 --> Helper loaded: my_helper
INFO - 2020-12-18 04:51:45 --> Database Driver Class Initialized
DEBUG - 2020-12-18 04:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 04:51:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 04:51:45 --> Controller Class Initialized
DEBUG - 2020-12-18 04:51:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-12-18 04:51:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 04:51:45 --> Final output sent to browser
DEBUG - 2020-12-18 04:51:45 --> Total execution time: 0.2591
INFO - 2020-12-18 04:51:48 --> Config Class Initialized
INFO - 2020-12-18 04:51:48 --> Hooks Class Initialized
DEBUG - 2020-12-18 04:51:48 --> UTF-8 Support Enabled
INFO - 2020-12-18 04:51:48 --> Utf8 Class Initialized
INFO - 2020-12-18 04:51:48 --> URI Class Initialized
INFO - 2020-12-18 04:51:48 --> Router Class Initialized
INFO - 2020-12-18 04:51:48 --> Output Class Initialized
INFO - 2020-12-18 04:51:48 --> Security Class Initialized
DEBUG - 2020-12-18 04:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 04:51:48 --> Input Class Initialized
INFO - 2020-12-18 04:51:48 --> Language Class Initialized
INFO - 2020-12-18 04:51:48 --> Language Class Initialized
INFO - 2020-12-18 04:51:48 --> Config Class Initialized
INFO - 2020-12-18 04:51:48 --> Loader Class Initialized
INFO - 2020-12-18 04:51:48 --> Helper loaded: url_helper
INFO - 2020-12-18 04:51:48 --> Helper loaded: file_helper
INFO - 2020-12-18 04:51:48 --> Helper loaded: form_helper
INFO - 2020-12-18 04:51:48 --> Helper loaded: my_helper
INFO - 2020-12-18 04:51:48 --> Database Driver Class Initialized
DEBUG - 2020-12-18 04:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 04:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 04:51:48 --> Controller Class Initialized
ERROR - 2020-12-18 04:51:48 --> Severity: Parsing Error --> syntax error, unexpected '$c_integritas' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 117
INFO - 2020-12-18 08:54:20 --> Config Class Initialized
INFO - 2020-12-18 08:54:20 --> Hooks Class Initialized
DEBUG - 2020-12-18 08:54:20 --> UTF-8 Support Enabled
INFO - 2020-12-18 08:54:20 --> Utf8 Class Initialized
INFO - 2020-12-18 08:54:20 --> URI Class Initialized
INFO - 2020-12-18 08:54:20 --> Router Class Initialized
INFO - 2020-12-18 08:54:20 --> Output Class Initialized
INFO - 2020-12-18 08:54:20 --> Security Class Initialized
DEBUG - 2020-12-18 08:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 08:54:20 --> Input Class Initialized
INFO - 2020-12-18 08:54:20 --> Language Class Initialized
INFO - 2020-12-18 08:54:20 --> Language Class Initialized
INFO - 2020-12-18 08:54:20 --> Config Class Initialized
INFO - 2020-12-18 08:54:20 --> Loader Class Initialized
INFO - 2020-12-18 08:54:20 --> Helper loaded: url_helper
INFO - 2020-12-18 08:54:20 --> Helper loaded: file_helper
INFO - 2020-12-18 08:54:20 --> Helper loaded: form_helper
INFO - 2020-12-18 08:54:20 --> Helper loaded: my_helper
INFO - 2020-12-18 08:54:20 --> Database Driver Class Initialized
DEBUG - 2020-12-18 08:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 08:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 08:54:20 --> Controller Class Initialized
ERROR - 2020-12-18 08:54:20 --> Severity: Parsing Error --> syntax error, unexpected '$c_religius' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 123
INFO - 2020-12-18 08:54:37 --> Config Class Initialized
INFO - 2020-12-18 08:54:37 --> Hooks Class Initialized
DEBUG - 2020-12-18 08:54:37 --> UTF-8 Support Enabled
INFO - 2020-12-18 08:54:37 --> Utf8 Class Initialized
INFO - 2020-12-18 08:54:37 --> URI Class Initialized
INFO - 2020-12-18 08:54:37 --> Router Class Initialized
INFO - 2020-12-18 08:54:37 --> Output Class Initialized
INFO - 2020-12-18 08:54:37 --> Security Class Initialized
DEBUG - 2020-12-18 08:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 08:54:37 --> Input Class Initialized
INFO - 2020-12-18 08:54:37 --> Language Class Initialized
INFO - 2020-12-18 08:54:37 --> Language Class Initialized
INFO - 2020-12-18 08:54:37 --> Config Class Initialized
INFO - 2020-12-18 08:54:37 --> Loader Class Initialized
INFO - 2020-12-18 08:54:37 --> Helper loaded: url_helper
INFO - 2020-12-18 08:54:37 --> Helper loaded: file_helper
INFO - 2020-12-18 08:54:37 --> Helper loaded: form_helper
INFO - 2020-12-18 08:54:37 --> Helper loaded: my_helper
INFO - 2020-12-18 08:54:37 --> Database Driver Class Initialized
DEBUG - 2020-12-18 08:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 08:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 08:54:37 --> Controller Class Initialized
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:37 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 08:54:38 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
DEBUG - 2020-12-18 08:54:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-18 08:54:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 08:54:38 --> Final output sent to browser
DEBUG - 2020-12-18 08:54:38 --> Total execution time: 1.3514
INFO - 2020-12-18 09:15:33 --> Config Class Initialized
INFO - 2020-12-18 09:15:33 --> Hooks Class Initialized
DEBUG - 2020-12-18 09:15:33 --> UTF-8 Support Enabled
INFO - 2020-12-18 09:15:33 --> Utf8 Class Initialized
INFO - 2020-12-18 09:15:33 --> URI Class Initialized
INFO - 2020-12-18 09:15:33 --> Router Class Initialized
INFO - 2020-12-18 09:15:33 --> Output Class Initialized
INFO - 2020-12-18 09:15:33 --> Security Class Initialized
DEBUG - 2020-12-18 09:15:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 09:15:33 --> Input Class Initialized
INFO - 2020-12-18 09:15:33 --> Language Class Initialized
INFO - 2020-12-18 09:15:33 --> Language Class Initialized
INFO - 2020-12-18 09:15:33 --> Config Class Initialized
INFO - 2020-12-18 09:15:33 --> Loader Class Initialized
INFO - 2020-12-18 09:15:33 --> Helper loaded: url_helper
INFO - 2020-12-18 09:15:33 --> Helper loaded: file_helper
INFO - 2020-12-18 09:15:33 --> Helper loaded: form_helper
INFO - 2020-12-18 09:15:33 --> Helper loaded: my_helper
INFO - 2020-12-18 09:15:33 --> Database Driver Class Initialized
DEBUG - 2020-12-18 09:15:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 09:15:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 09:15:33 --> Controller Class Initialized
ERROR - 2020-12-18 09:15:33 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
INFO - 2020-12-18 09:15:56 --> Config Class Initialized
INFO - 2020-12-18 09:15:56 --> Hooks Class Initialized
DEBUG - 2020-12-18 09:15:56 --> UTF-8 Support Enabled
INFO - 2020-12-18 09:15:56 --> Utf8 Class Initialized
INFO - 2020-12-18 09:15:56 --> URI Class Initialized
INFO - 2020-12-18 09:15:56 --> Router Class Initialized
INFO - 2020-12-18 09:15:56 --> Output Class Initialized
INFO - 2020-12-18 09:15:57 --> Security Class Initialized
DEBUG - 2020-12-18 09:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 09:15:57 --> Input Class Initialized
INFO - 2020-12-18 09:15:57 --> Language Class Initialized
INFO - 2020-12-18 09:15:57 --> Language Class Initialized
INFO - 2020-12-18 09:15:57 --> Config Class Initialized
INFO - 2020-12-18 09:15:57 --> Loader Class Initialized
INFO - 2020-12-18 09:15:57 --> Helper loaded: url_helper
INFO - 2020-12-18 09:15:57 --> Helper loaded: file_helper
INFO - 2020-12-18 09:15:57 --> Helper loaded: form_helper
INFO - 2020-12-18 09:15:57 --> Helper loaded: my_helper
INFO - 2020-12-18 09:15:57 --> Database Driver Class Initialized
DEBUG - 2020-12-18 09:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 09:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 09:15:57 --> Controller Class Initialized
ERROR - 2020-12-18 09:15:57 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
INFO - 2020-12-18 09:15:59 --> Config Class Initialized
INFO - 2020-12-18 09:15:59 --> Hooks Class Initialized
DEBUG - 2020-12-18 09:15:59 --> UTF-8 Support Enabled
INFO - 2020-12-18 09:15:59 --> Utf8 Class Initialized
INFO - 2020-12-18 09:15:59 --> URI Class Initialized
INFO - 2020-12-18 09:15:59 --> Router Class Initialized
INFO - 2020-12-18 09:15:59 --> Output Class Initialized
INFO - 2020-12-18 09:15:59 --> Security Class Initialized
DEBUG - 2020-12-18 09:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 09:15:59 --> Input Class Initialized
INFO - 2020-12-18 09:15:59 --> Language Class Initialized
INFO - 2020-12-18 09:15:59 --> Language Class Initialized
INFO - 2020-12-18 09:15:59 --> Config Class Initialized
INFO - 2020-12-18 09:15:59 --> Loader Class Initialized
INFO - 2020-12-18 09:15:59 --> Helper loaded: url_helper
INFO - 2020-12-18 09:15:59 --> Helper loaded: file_helper
INFO - 2020-12-18 09:15:59 --> Helper loaded: form_helper
INFO - 2020-12-18 09:15:59 --> Helper loaded: my_helper
INFO - 2020-12-18 09:15:59 --> Database Driver Class Initialized
DEBUG - 2020-12-18 09:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 09:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 09:15:59 --> Controller Class Initialized
ERROR - 2020-12-18 09:15:59 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
INFO - 2020-12-18 09:16:12 --> Config Class Initialized
INFO - 2020-12-18 09:16:12 --> Hooks Class Initialized
DEBUG - 2020-12-18 09:16:12 --> UTF-8 Support Enabled
INFO - 2020-12-18 09:16:12 --> Utf8 Class Initialized
INFO - 2020-12-18 09:16:12 --> URI Class Initialized
INFO - 2020-12-18 09:16:12 --> Router Class Initialized
INFO - 2020-12-18 09:16:12 --> Output Class Initialized
INFO - 2020-12-18 09:16:12 --> Security Class Initialized
DEBUG - 2020-12-18 09:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 09:16:12 --> Input Class Initialized
INFO - 2020-12-18 09:16:12 --> Language Class Initialized
INFO - 2020-12-18 09:16:12 --> Language Class Initialized
INFO - 2020-12-18 09:16:12 --> Config Class Initialized
INFO - 2020-12-18 09:16:12 --> Loader Class Initialized
INFO - 2020-12-18 09:16:12 --> Helper loaded: url_helper
INFO - 2020-12-18 09:16:12 --> Helper loaded: file_helper
INFO - 2020-12-18 09:16:12 --> Helper loaded: form_helper
INFO - 2020-12-18 09:16:12 --> Helper loaded: my_helper
INFO - 2020-12-18 09:16:12 --> Database Driver Class Initialized
DEBUG - 2020-12-18 09:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 09:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 09:16:12 --> Controller Class Initialized
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:12 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
ERROR - 2020-12-18 09:16:13 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 63
DEBUG - 2020-12-18 09:16:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-18 09:16:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 09:16:13 --> Final output sent to browser
DEBUG - 2020-12-18 09:16:13 --> Total execution time: 1.4790
INFO - 2020-12-18 10:00:30 --> Config Class Initialized
INFO - 2020-12-18 10:00:30 --> Hooks Class Initialized
DEBUG - 2020-12-18 10:00:30 --> UTF-8 Support Enabled
INFO - 2020-12-18 10:00:30 --> Utf8 Class Initialized
INFO - 2020-12-18 10:00:30 --> URI Class Initialized
INFO - 2020-12-18 10:00:30 --> Router Class Initialized
INFO - 2020-12-18 10:00:30 --> Output Class Initialized
INFO - 2020-12-18 10:00:30 --> Security Class Initialized
DEBUG - 2020-12-18 10:00:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-18 10:00:30 --> Input Class Initialized
INFO - 2020-12-18 10:00:30 --> Language Class Initialized
INFO - 2020-12-18 10:00:30 --> Language Class Initialized
INFO - 2020-12-18 10:00:30 --> Config Class Initialized
INFO - 2020-12-18 10:00:30 --> Loader Class Initialized
INFO - 2020-12-18 10:00:30 --> Helper loaded: url_helper
INFO - 2020-12-18 10:00:30 --> Helper loaded: file_helper
INFO - 2020-12-18 10:00:30 --> Helper loaded: form_helper
INFO - 2020-12-18 10:00:30 --> Helper loaded: my_helper
INFO - 2020-12-18 10:00:30 --> Database Driver Class Initialized
DEBUG - 2020-12-18 10:00:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-18 10:00:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-18 10:00:30 --> Controller Class Initialized
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:30 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_integritas C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_religius C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_nasionalis C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_mandiri C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
ERROR - 2020-12-18 10:00:31 --> Severity: Notice --> Undefined variable: c_gotong C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 64
DEBUG - 2020-12-18 10:00:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-18 10:00:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-18 10:00:31 --> Final output sent to browser
DEBUG - 2020-12-18 10:00:31 --> Total execution time: 1.4805
