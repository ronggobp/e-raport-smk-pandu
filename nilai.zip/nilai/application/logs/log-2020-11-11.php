<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-11 01:36:27 --> Config Class Initialized
INFO - 2020-11-11 01:36:27 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:36:27 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:36:27 --> Utf8 Class Initialized
INFO - 2020-11-11 01:36:27 --> URI Class Initialized
DEBUG - 2020-11-11 01:36:27 --> No URI present. Default controller set.
INFO - 2020-11-11 01:36:27 --> Router Class Initialized
INFO - 2020-11-11 01:36:27 --> Output Class Initialized
INFO - 2020-11-11 01:36:27 --> Security Class Initialized
DEBUG - 2020-11-11 01:36:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:36:27 --> Input Class Initialized
INFO - 2020-11-11 01:36:27 --> Language Class Initialized
INFO - 2020-11-11 01:36:27 --> Language Class Initialized
INFO - 2020-11-11 01:36:27 --> Config Class Initialized
INFO - 2020-11-11 01:36:27 --> Loader Class Initialized
INFO - 2020-11-11 01:36:27 --> Helper loaded: url_helper
INFO - 2020-11-11 01:36:27 --> Helper loaded: file_helper
INFO - 2020-11-11 01:36:27 --> Helper loaded: form_helper
INFO - 2020-11-11 01:36:27 --> Helper loaded: my_helper
INFO - 2020-11-11 01:36:28 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:36:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:36:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:36:28 --> Controller Class Initialized
INFO - 2020-11-11 01:36:30 --> Config Class Initialized
INFO - 2020-11-11 01:36:30 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:36:30 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:36:30 --> Utf8 Class Initialized
INFO - 2020-11-11 01:36:30 --> URI Class Initialized
INFO - 2020-11-11 01:36:30 --> Router Class Initialized
INFO - 2020-11-11 01:36:30 --> Output Class Initialized
INFO - 2020-11-11 01:36:30 --> Security Class Initialized
DEBUG - 2020-11-11 01:36:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:36:30 --> Input Class Initialized
INFO - 2020-11-11 01:36:30 --> Language Class Initialized
INFO - 2020-11-11 01:36:30 --> Language Class Initialized
INFO - 2020-11-11 01:36:30 --> Config Class Initialized
INFO - 2020-11-11 01:36:30 --> Loader Class Initialized
INFO - 2020-11-11 01:36:30 --> Helper loaded: url_helper
INFO - 2020-11-11 01:36:30 --> Helper loaded: file_helper
INFO - 2020-11-11 01:36:30 --> Helper loaded: form_helper
INFO - 2020-11-11 01:36:30 --> Helper loaded: my_helper
INFO - 2020-11-11 01:36:30 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:36:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:36:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:36:30 --> Controller Class Initialized
DEBUG - 2020-11-11 01:36:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 01:36:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:36:31 --> Final output sent to browser
DEBUG - 2020-11-11 01:36:31 --> Total execution time: 0.2579
INFO - 2020-11-11 01:38:56 --> Config Class Initialized
INFO - 2020-11-11 01:38:56 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:38:56 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:38:56 --> Utf8 Class Initialized
INFO - 2020-11-11 01:38:56 --> URI Class Initialized
INFO - 2020-11-11 01:38:56 --> Router Class Initialized
INFO - 2020-11-11 01:38:56 --> Output Class Initialized
INFO - 2020-11-11 01:38:56 --> Security Class Initialized
DEBUG - 2020-11-11 01:38:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:38:56 --> Input Class Initialized
INFO - 2020-11-11 01:38:56 --> Language Class Initialized
INFO - 2020-11-11 01:38:56 --> Language Class Initialized
INFO - 2020-11-11 01:38:56 --> Config Class Initialized
INFO - 2020-11-11 01:38:56 --> Loader Class Initialized
INFO - 2020-11-11 01:38:56 --> Helper loaded: url_helper
INFO - 2020-11-11 01:38:56 --> Helper loaded: file_helper
INFO - 2020-11-11 01:38:56 --> Helper loaded: form_helper
INFO - 2020-11-11 01:38:56 --> Helper loaded: my_helper
INFO - 2020-11-11 01:38:56 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:38:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:38:56 --> Controller Class Initialized
INFO - 2020-11-11 01:38:56 --> Helper loaded: cookie_helper
INFO - 2020-11-11 01:38:56 --> Final output sent to browser
DEBUG - 2020-11-11 01:38:56 --> Total execution time: 0.3203
INFO - 2020-11-11 01:38:58 --> Config Class Initialized
INFO - 2020-11-11 01:38:58 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:38:58 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:38:58 --> Utf8 Class Initialized
INFO - 2020-11-11 01:38:58 --> URI Class Initialized
INFO - 2020-11-11 01:38:58 --> Router Class Initialized
INFO - 2020-11-11 01:38:58 --> Output Class Initialized
INFO - 2020-11-11 01:38:58 --> Security Class Initialized
DEBUG - 2020-11-11 01:38:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:38:58 --> Input Class Initialized
INFO - 2020-11-11 01:38:58 --> Language Class Initialized
INFO - 2020-11-11 01:38:58 --> Language Class Initialized
INFO - 2020-11-11 01:38:58 --> Config Class Initialized
INFO - 2020-11-11 01:38:58 --> Loader Class Initialized
INFO - 2020-11-11 01:38:58 --> Helper loaded: url_helper
INFO - 2020-11-11 01:38:58 --> Helper loaded: file_helper
INFO - 2020-11-11 01:38:58 --> Helper loaded: form_helper
INFO - 2020-11-11 01:38:58 --> Helper loaded: my_helper
INFO - 2020-11-11 01:38:58 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:38:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:38:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:38:58 --> Controller Class Initialized
DEBUG - 2020-11-11 01:38:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 01:38:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:38:58 --> Final output sent to browser
DEBUG - 2020-11-11 01:38:58 --> Total execution time: 0.3886
INFO - 2020-11-11 01:39:03 --> Config Class Initialized
INFO - 2020-11-11 01:39:03 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:03 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:03 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:03 --> URI Class Initialized
INFO - 2020-11-11 01:39:03 --> Router Class Initialized
INFO - 2020-11-11 01:39:03 --> Output Class Initialized
INFO - 2020-11-11 01:39:04 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:04 --> Input Class Initialized
INFO - 2020-11-11 01:39:04 --> Language Class Initialized
INFO - 2020-11-11 01:39:04 --> Language Class Initialized
INFO - 2020-11-11 01:39:04 --> Config Class Initialized
INFO - 2020-11-11 01:39:04 --> Loader Class Initialized
INFO - 2020-11-11 01:39:04 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:04 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:04 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:04 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:04 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:04 --> Controller Class Initialized
INFO - 2020-11-11 01:39:04 --> Helper loaded: cookie_helper
INFO - 2020-11-11 01:39:04 --> Config Class Initialized
INFO - 2020-11-11 01:39:04 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:04 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:04 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:04 --> URI Class Initialized
INFO - 2020-11-11 01:39:04 --> Router Class Initialized
INFO - 2020-11-11 01:39:04 --> Output Class Initialized
INFO - 2020-11-11 01:39:04 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:04 --> Input Class Initialized
INFO - 2020-11-11 01:39:04 --> Language Class Initialized
INFO - 2020-11-11 01:39:04 --> Language Class Initialized
INFO - 2020-11-11 01:39:04 --> Config Class Initialized
INFO - 2020-11-11 01:39:04 --> Loader Class Initialized
INFO - 2020-11-11 01:39:04 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:04 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:04 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:04 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:04 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:04 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 01:39:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:04 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:04 --> Total execution time: 0.2051
INFO - 2020-11-11 01:39:12 --> Config Class Initialized
INFO - 2020-11-11 01:39:12 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:12 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:12 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:12 --> URI Class Initialized
INFO - 2020-11-11 01:39:12 --> Router Class Initialized
INFO - 2020-11-11 01:39:12 --> Output Class Initialized
INFO - 2020-11-11 01:39:12 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:12 --> Input Class Initialized
INFO - 2020-11-11 01:39:12 --> Language Class Initialized
INFO - 2020-11-11 01:39:12 --> Language Class Initialized
INFO - 2020-11-11 01:39:12 --> Config Class Initialized
INFO - 2020-11-11 01:39:12 --> Loader Class Initialized
INFO - 2020-11-11 01:39:12 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:12 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:12 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:12 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:12 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:12 --> Controller Class Initialized
INFO - 2020-11-11 01:39:12 --> Helper loaded: cookie_helper
INFO - 2020-11-11 01:39:12 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:12 --> Total execution time: 0.2587
INFO - 2020-11-11 01:39:13 --> Config Class Initialized
INFO - 2020-11-11 01:39:13 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:13 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:13 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:13 --> URI Class Initialized
INFO - 2020-11-11 01:39:13 --> Router Class Initialized
INFO - 2020-11-11 01:39:13 --> Output Class Initialized
INFO - 2020-11-11 01:39:13 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:13 --> Input Class Initialized
INFO - 2020-11-11 01:39:13 --> Language Class Initialized
INFO - 2020-11-11 01:39:13 --> Language Class Initialized
INFO - 2020-11-11 01:39:13 --> Config Class Initialized
INFO - 2020-11-11 01:39:13 --> Loader Class Initialized
INFO - 2020-11-11 01:39:13 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:13 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:13 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:13 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:13 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:13 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 01:39:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:13 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:13 --> Total execution time: 0.3142
INFO - 2020-11-11 01:39:27 --> Config Class Initialized
INFO - 2020-11-11 01:39:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:28 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:28 --> URI Class Initialized
INFO - 2020-11-11 01:39:28 --> Router Class Initialized
INFO - 2020-11-11 01:39:28 --> Output Class Initialized
INFO - 2020-11-11 01:39:28 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:28 --> Input Class Initialized
INFO - 2020-11-11 01:39:28 --> Language Class Initialized
INFO - 2020-11-11 01:39:28 --> Language Class Initialized
INFO - 2020-11-11 01:39:28 --> Config Class Initialized
INFO - 2020-11-11 01:39:28 --> Loader Class Initialized
INFO - 2020-11-11 01:39:28 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:28 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:28 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:28 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:28 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:28 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 01:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:28 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:28 --> Total execution time: 0.2540
INFO - 2020-11-11 01:39:30 --> Config Class Initialized
INFO - 2020-11-11 01:39:30 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:30 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:30 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:30 --> URI Class Initialized
INFO - 2020-11-11 01:39:30 --> Router Class Initialized
INFO - 2020-11-11 01:39:30 --> Output Class Initialized
INFO - 2020-11-11 01:39:30 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:30 --> Input Class Initialized
INFO - 2020-11-11 01:39:30 --> Language Class Initialized
INFO - 2020-11-11 01:39:30 --> Language Class Initialized
INFO - 2020-11-11 01:39:30 --> Config Class Initialized
INFO - 2020-11-11 01:39:30 --> Loader Class Initialized
INFO - 2020-11-11 01:39:30 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:30 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:30 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:30 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:31 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:31 --> Controller Class Initialized
INFO - 2020-11-11 01:39:31 --> Helper loaded: cookie_helper
INFO - 2020-11-11 01:39:31 --> Config Class Initialized
INFO - 2020-11-11 01:39:31 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:31 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:31 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:31 --> URI Class Initialized
INFO - 2020-11-11 01:39:31 --> Router Class Initialized
INFO - 2020-11-11 01:39:31 --> Output Class Initialized
INFO - 2020-11-11 01:39:31 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:31 --> Input Class Initialized
INFO - 2020-11-11 01:39:31 --> Language Class Initialized
INFO - 2020-11-11 01:39:31 --> Language Class Initialized
INFO - 2020-11-11 01:39:31 --> Config Class Initialized
INFO - 2020-11-11 01:39:31 --> Loader Class Initialized
INFO - 2020-11-11 01:39:31 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:31 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:31 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:31 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:31 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:31 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 01:39:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:31 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:31 --> Total execution time: 0.2316
INFO - 2020-11-11 01:39:36 --> Config Class Initialized
INFO - 2020-11-11 01:39:36 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:36 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:36 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:36 --> URI Class Initialized
INFO - 2020-11-11 01:39:36 --> Router Class Initialized
INFO - 2020-11-11 01:39:36 --> Output Class Initialized
INFO - 2020-11-11 01:39:36 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:36 --> Input Class Initialized
INFO - 2020-11-11 01:39:36 --> Language Class Initialized
INFO - 2020-11-11 01:39:36 --> Language Class Initialized
INFO - 2020-11-11 01:39:36 --> Config Class Initialized
INFO - 2020-11-11 01:39:36 --> Loader Class Initialized
INFO - 2020-11-11 01:39:36 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:36 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:37 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:37 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:37 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:37 --> Controller Class Initialized
INFO - 2020-11-11 01:39:37 --> Helper loaded: cookie_helper
INFO - 2020-11-11 01:39:37 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:37 --> Total execution time: 0.2870
INFO - 2020-11-11 01:39:37 --> Config Class Initialized
INFO - 2020-11-11 01:39:37 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:37 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:37 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:37 --> URI Class Initialized
INFO - 2020-11-11 01:39:37 --> Router Class Initialized
INFO - 2020-11-11 01:39:37 --> Output Class Initialized
INFO - 2020-11-11 01:39:37 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:37 --> Input Class Initialized
INFO - 2020-11-11 01:39:37 --> Language Class Initialized
INFO - 2020-11-11 01:39:37 --> Language Class Initialized
INFO - 2020-11-11 01:39:37 --> Config Class Initialized
INFO - 2020-11-11 01:39:37 --> Loader Class Initialized
INFO - 2020-11-11 01:39:37 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:37 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:37 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:37 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:37 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:37 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 01:39:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:37 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:37 --> Total execution time: 0.3170
INFO - 2020-11-11 01:39:40 --> Config Class Initialized
INFO - 2020-11-11 01:39:40 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:40 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:40 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:40 --> URI Class Initialized
INFO - 2020-11-11 01:39:40 --> Router Class Initialized
INFO - 2020-11-11 01:39:40 --> Output Class Initialized
INFO - 2020-11-11 01:39:40 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:40 --> Input Class Initialized
INFO - 2020-11-11 01:39:40 --> Language Class Initialized
INFO - 2020-11-11 01:39:40 --> Language Class Initialized
INFO - 2020-11-11 01:39:40 --> Config Class Initialized
INFO - 2020-11-11 01:39:40 --> Loader Class Initialized
INFO - 2020-11-11 01:39:40 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:40 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:40 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:40 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:40 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:40 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 01:39:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:40 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:40 --> Total execution time: 0.2083
INFO - 2020-11-11 01:39:42 --> Config Class Initialized
INFO - 2020-11-11 01:39:42 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:42 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:42 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:42 --> URI Class Initialized
INFO - 2020-11-11 01:39:42 --> Router Class Initialized
INFO - 2020-11-11 01:39:42 --> Output Class Initialized
INFO - 2020-11-11 01:39:42 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:42 --> Input Class Initialized
INFO - 2020-11-11 01:39:42 --> Language Class Initialized
INFO - 2020-11-11 01:39:42 --> Language Class Initialized
INFO - 2020-11-11 01:39:42 --> Config Class Initialized
INFO - 2020-11-11 01:39:42 --> Loader Class Initialized
INFO - 2020-11-11 01:39:42 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:42 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:42 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:42 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:42 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:42 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-11 01:39:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:42 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:42 --> Total execution time: 0.2542
INFO - 2020-11-11 01:39:46 --> Config Class Initialized
INFO - 2020-11-11 01:39:46 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:46 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:46 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:46 --> URI Class Initialized
INFO - 2020-11-11 01:39:46 --> Router Class Initialized
INFO - 2020-11-11 01:39:46 --> Output Class Initialized
INFO - 2020-11-11 01:39:46 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:46 --> Input Class Initialized
INFO - 2020-11-11 01:39:46 --> Language Class Initialized
INFO - 2020-11-11 01:39:46 --> Language Class Initialized
INFO - 2020-11-11 01:39:46 --> Config Class Initialized
INFO - 2020-11-11 01:39:46 --> Loader Class Initialized
INFO - 2020-11-11 01:39:46 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:46 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:46 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:46 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:46 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:46 --> Controller Class Initialized
INFO - 2020-11-11 01:39:46 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:46 --> Total execution time: 0.1987
INFO - 2020-11-11 01:39:58 --> Config Class Initialized
INFO - 2020-11-11 01:39:58 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:58 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:58 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:58 --> URI Class Initialized
INFO - 2020-11-11 01:39:58 --> Router Class Initialized
INFO - 2020-11-11 01:39:58 --> Output Class Initialized
INFO - 2020-11-11 01:39:58 --> Security Class Initialized
DEBUG - 2020-11-11 01:39:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:39:58 --> Input Class Initialized
INFO - 2020-11-11 01:39:58 --> Language Class Initialized
INFO - 2020-11-11 01:39:58 --> Language Class Initialized
INFO - 2020-11-11 01:39:58 --> Config Class Initialized
INFO - 2020-11-11 01:39:58 --> Loader Class Initialized
INFO - 2020-11-11 01:39:58 --> Helper loaded: url_helper
INFO - 2020-11-11 01:39:58 --> Helper loaded: file_helper
INFO - 2020-11-11 01:39:58 --> Helper loaded: form_helper
INFO - 2020-11-11 01:39:58 --> Helper loaded: my_helper
INFO - 2020-11-11 01:39:58 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:39:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:39:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:39:58 --> Controller Class Initialized
DEBUG - 2020-11-11 01:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 01:39:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:39:58 --> Final output sent to browser
DEBUG - 2020-11-11 01:39:58 --> Total execution time: 0.2510
INFO - 2020-11-11 01:39:59 --> Config Class Initialized
INFO - 2020-11-11 01:39:59 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:39:59 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:39:59 --> Utf8 Class Initialized
INFO - 2020-11-11 01:39:59 --> URI Class Initialized
INFO - 2020-11-11 01:40:00 --> Router Class Initialized
INFO - 2020-11-11 01:40:00 --> Output Class Initialized
INFO - 2020-11-11 01:40:00 --> Security Class Initialized
DEBUG - 2020-11-11 01:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:40:00 --> Input Class Initialized
INFO - 2020-11-11 01:40:00 --> Language Class Initialized
INFO - 2020-11-11 01:40:00 --> Language Class Initialized
INFO - 2020-11-11 01:40:00 --> Config Class Initialized
INFO - 2020-11-11 01:40:00 --> Loader Class Initialized
INFO - 2020-11-11 01:40:00 --> Helper loaded: url_helper
INFO - 2020-11-11 01:40:00 --> Helper loaded: file_helper
INFO - 2020-11-11 01:40:00 --> Helper loaded: form_helper
INFO - 2020-11-11 01:40:00 --> Helper loaded: my_helper
INFO - 2020-11-11 01:40:00 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:40:00 --> Controller Class Initialized
DEBUG - 2020-11-11 01:40:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-11 01:40:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:40:00 --> Final output sent to browser
DEBUG - 2020-11-11 01:40:00 --> Total execution time: 0.2669
INFO - 2020-11-11 01:40:00 --> Config Class Initialized
INFO - 2020-11-11 01:40:00 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:40:00 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:40:00 --> Utf8 Class Initialized
INFO - 2020-11-11 01:40:00 --> URI Class Initialized
INFO - 2020-11-11 01:40:00 --> Router Class Initialized
INFO - 2020-11-11 01:40:00 --> Output Class Initialized
INFO - 2020-11-11 01:40:00 --> Security Class Initialized
DEBUG - 2020-11-11 01:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:40:00 --> Input Class Initialized
INFO - 2020-11-11 01:40:00 --> Language Class Initialized
INFO - 2020-11-11 01:40:00 --> Language Class Initialized
INFO - 2020-11-11 01:40:00 --> Config Class Initialized
INFO - 2020-11-11 01:40:00 --> Loader Class Initialized
INFO - 2020-11-11 01:40:00 --> Helper loaded: url_helper
INFO - 2020-11-11 01:40:00 --> Helper loaded: file_helper
INFO - 2020-11-11 01:40:00 --> Helper loaded: form_helper
INFO - 2020-11-11 01:40:00 --> Helper loaded: my_helper
INFO - 2020-11-11 01:40:00 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:40:00 --> Controller Class Initialized
INFO - 2020-11-11 01:40:02 --> Config Class Initialized
INFO - 2020-11-11 01:40:02 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:40:02 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:40:02 --> Utf8 Class Initialized
INFO - 2020-11-11 01:40:02 --> URI Class Initialized
INFO - 2020-11-11 01:40:02 --> Router Class Initialized
INFO - 2020-11-11 01:40:02 --> Output Class Initialized
INFO - 2020-11-11 01:40:02 --> Security Class Initialized
DEBUG - 2020-11-11 01:40:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:40:02 --> Input Class Initialized
INFO - 2020-11-11 01:40:02 --> Language Class Initialized
INFO - 2020-11-11 01:40:02 --> Language Class Initialized
INFO - 2020-11-11 01:40:02 --> Config Class Initialized
INFO - 2020-11-11 01:40:02 --> Loader Class Initialized
INFO - 2020-11-11 01:40:02 --> Helper loaded: url_helper
INFO - 2020-11-11 01:40:02 --> Helper loaded: file_helper
INFO - 2020-11-11 01:40:02 --> Helper loaded: form_helper
INFO - 2020-11-11 01:40:02 --> Helper loaded: my_helper
INFO - 2020-11-11 01:40:02 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:40:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:40:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:40:02 --> Controller Class Initialized
INFO - 2020-11-11 01:40:02 --> Final output sent to browser
DEBUG - 2020-11-11 01:40:02 --> Total execution time: 0.1772
INFO - 2020-11-11 01:41:03 --> Config Class Initialized
INFO - 2020-11-11 01:41:03 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:41:03 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:41:03 --> Utf8 Class Initialized
INFO - 2020-11-11 01:41:03 --> URI Class Initialized
INFO - 2020-11-11 01:41:03 --> Router Class Initialized
INFO - 2020-11-11 01:41:03 --> Output Class Initialized
INFO - 2020-11-11 01:41:03 --> Security Class Initialized
DEBUG - 2020-11-11 01:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:41:03 --> Input Class Initialized
INFO - 2020-11-11 01:41:03 --> Language Class Initialized
INFO - 2020-11-11 01:41:03 --> Language Class Initialized
INFO - 2020-11-11 01:41:03 --> Config Class Initialized
INFO - 2020-11-11 01:41:03 --> Loader Class Initialized
INFO - 2020-11-11 01:41:03 --> Helper loaded: url_helper
INFO - 2020-11-11 01:41:03 --> Helper loaded: file_helper
INFO - 2020-11-11 01:41:03 --> Helper loaded: form_helper
INFO - 2020-11-11 01:41:03 --> Helper loaded: my_helper
INFO - 2020-11-11 01:41:03 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:41:03 --> Controller Class Initialized
DEBUG - 2020-11-11 01:41:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-11 01:41:03 --> Final output sent to browser
DEBUG - 2020-11-11 01:41:03 --> Total execution time: 0.3009
INFO - 2020-11-11 01:41:48 --> Config Class Initialized
INFO - 2020-11-11 01:41:48 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:41:48 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:41:48 --> Utf8 Class Initialized
INFO - 2020-11-11 01:41:48 --> URI Class Initialized
INFO - 2020-11-11 01:41:48 --> Router Class Initialized
INFO - 2020-11-11 01:41:48 --> Output Class Initialized
INFO - 2020-11-11 01:41:48 --> Security Class Initialized
DEBUG - 2020-11-11 01:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:41:48 --> Input Class Initialized
INFO - 2020-11-11 01:41:48 --> Language Class Initialized
INFO - 2020-11-11 01:41:48 --> Language Class Initialized
INFO - 2020-11-11 01:41:48 --> Config Class Initialized
INFO - 2020-11-11 01:41:48 --> Loader Class Initialized
INFO - 2020-11-11 01:41:48 --> Helper loaded: url_helper
INFO - 2020-11-11 01:41:48 --> Helper loaded: file_helper
INFO - 2020-11-11 01:41:48 --> Helper loaded: form_helper
INFO - 2020-11-11 01:41:48 --> Helper loaded: my_helper
INFO - 2020-11-11 01:41:48 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:41:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:41:48 --> Controller Class Initialized
DEBUG - 2020-11-11 01:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 01:41:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:41:48 --> Final output sent to browser
DEBUG - 2020-11-11 01:41:48 --> Total execution time: 0.2619
INFO - 2020-11-11 01:41:51 --> Config Class Initialized
INFO - 2020-11-11 01:41:51 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:41:51 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:41:51 --> Utf8 Class Initialized
INFO - 2020-11-11 01:41:51 --> URI Class Initialized
INFO - 2020-11-11 01:41:51 --> Router Class Initialized
INFO - 2020-11-11 01:41:51 --> Output Class Initialized
INFO - 2020-11-11 01:41:51 --> Security Class Initialized
DEBUG - 2020-11-11 01:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:41:51 --> Input Class Initialized
INFO - 2020-11-11 01:41:51 --> Language Class Initialized
INFO - 2020-11-11 01:41:51 --> Language Class Initialized
INFO - 2020-11-11 01:41:51 --> Config Class Initialized
INFO - 2020-11-11 01:41:51 --> Loader Class Initialized
INFO - 2020-11-11 01:41:51 --> Helper loaded: url_helper
INFO - 2020-11-11 01:41:51 --> Helper loaded: file_helper
INFO - 2020-11-11 01:41:51 --> Helper loaded: form_helper
INFO - 2020-11-11 01:41:51 --> Helper loaded: my_helper
INFO - 2020-11-11 01:41:51 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:41:51 --> Controller Class Initialized
DEBUG - 2020-11-11 01:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-11 01:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:41:51 --> Final output sent to browser
DEBUG - 2020-11-11 01:41:51 --> Total execution time: 0.2418
INFO - 2020-11-11 01:41:53 --> Config Class Initialized
INFO - 2020-11-11 01:41:53 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:41:53 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:41:53 --> Utf8 Class Initialized
INFO - 2020-11-11 01:41:53 --> URI Class Initialized
INFO - 2020-11-11 01:41:53 --> Router Class Initialized
INFO - 2020-11-11 01:41:53 --> Output Class Initialized
INFO - 2020-11-11 01:41:53 --> Security Class Initialized
DEBUG - 2020-11-11 01:41:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:41:53 --> Input Class Initialized
INFO - 2020-11-11 01:41:53 --> Language Class Initialized
INFO - 2020-11-11 01:41:53 --> Language Class Initialized
INFO - 2020-11-11 01:41:53 --> Config Class Initialized
INFO - 2020-11-11 01:41:53 --> Loader Class Initialized
INFO - 2020-11-11 01:41:53 --> Helper loaded: url_helper
INFO - 2020-11-11 01:41:53 --> Helper loaded: file_helper
INFO - 2020-11-11 01:41:54 --> Helper loaded: form_helper
INFO - 2020-11-11 01:41:54 --> Helper loaded: my_helper
INFO - 2020-11-11 01:41:54 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:41:54 --> Controller Class Initialized
INFO - 2020-11-11 01:41:54 --> Final output sent to browser
DEBUG - 2020-11-11 01:41:54 --> Total execution time: 0.1951
INFO - 2020-11-11 01:41:59 --> Config Class Initialized
INFO - 2020-11-11 01:41:59 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:41:59 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:41:59 --> Utf8 Class Initialized
INFO - 2020-11-11 01:41:59 --> URI Class Initialized
INFO - 2020-11-11 01:41:59 --> Router Class Initialized
INFO - 2020-11-11 01:41:59 --> Output Class Initialized
INFO - 2020-11-11 01:41:59 --> Security Class Initialized
DEBUG - 2020-11-11 01:41:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:41:59 --> Input Class Initialized
INFO - 2020-11-11 01:41:59 --> Language Class Initialized
INFO - 2020-11-11 01:41:59 --> Language Class Initialized
INFO - 2020-11-11 01:41:59 --> Config Class Initialized
INFO - 2020-11-11 01:41:59 --> Loader Class Initialized
INFO - 2020-11-11 01:41:59 --> Helper loaded: url_helper
INFO - 2020-11-11 01:41:59 --> Helper loaded: file_helper
INFO - 2020-11-11 01:41:59 --> Helper loaded: form_helper
INFO - 2020-11-11 01:41:59 --> Helper loaded: my_helper
INFO - 2020-11-11 01:41:59 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:41:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:41:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:41:59 --> Controller Class Initialized
DEBUG - 2020-11-11 01:41:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 01:41:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:41:59 --> Final output sent to browser
DEBUG - 2020-11-11 01:41:59 --> Total execution time: 0.2498
INFO - 2020-11-11 01:42:02 --> Config Class Initialized
INFO - 2020-11-11 01:42:02 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:42:02 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:42:02 --> Utf8 Class Initialized
INFO - 2020-11-11 01:42:02 --> URI Class Initialized
INFO - 2020-11-11 01:42:02 --> Router Class Initialized
INFO - 2020-11-11 01:42:02 --> Output Class Initialized
INFO - 2020-11-11 01:42:02 --> Security Class Initialized
DEBUG - 2020-11-11 01:42:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:42:02 --> Input Class Initialized
INFO - 2020-11-11 01:42:02 --> Language Class Initialized
INFO - 2020-11-11 01:42:02 --> Language Class Initialized
INFO - 2020-11-11 01:42:02 --> Config Class Initialized
INFO - 2020-11-11 01:42:02 --> Loader Class Initialized
INFO - 2020-11-11 01:42:02 --> Helper loaded: url_helper
INFO - 2020-11-11 01:42:02 --> Helper loaded: file_helper
INFO - 2020-11-11 01:42:02 --> Helper loaded: form_helper
INFO - 2020-11-11 01:42:02 --> Helper loaded: my_helper
INFO - 2020-11-11 01:42:02 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:42:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:42:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:42:02 --> Controller Class Initialized
DEBUG - 2020-11-11 01:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-11 01:42:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:42:02 --> Final output sent to browser
DEBUG - 2020-11-11 01:42:02 --> Total execution time: 0.2391
INFO - 2020-11-11 01:42:02 --> Config Class Initialized
INFO - 2020-11-11 01:42:02 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:42:02 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:42:02 --> Utf8 Class Initialized
INFO - 2020-11-11 01:42:02 --> URI Class Initialized
INFO - 2020-11-11 01:42:02 --> Router Class Initialized
INFO - 2020-11-11 01:42:03 --> Output Class Initialized
INFO - 2020-11-11 01:42:03 --> Security Class Initialized
DEBUG - 2020-11-11 01:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:42:03 --> Input Class Initialized
INFO - 2020-11-11 01:42:03 --> Language Class Initialized
INFO - 2020-11-11 01:42:03 --> Language Class Initialized
INFO - 2020-11-11 01:42:03 --> Config Class Initialized
INFO - 2020-11-11 01:42:03 --> Loader Class Initialized
INFO - 2020-11-11 01:42:03 --> Helper loaded: url_helper
INFO - 2020-11-11 01:42:03 --> Helper loaded: file_helper
INFO - 2020-11-11 01:42:03 --> Helper loaded: form_helper
INFO - 2020-11-11 01:42:03 --> Helper loaded: my_helper
INFO - 2020-11-11 01:42:03 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:42:03 --> Controller Class Initialized
INFO - 2020-11-11 01:42:04 --> Config Class Initialized
INFO - 2020-11-11 01:42:04 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:42:04 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:42:04 --> Utf8 Class Initialized
INFO - 2020-11-11 01:42:04 --> URI Class Initialized
INFO - 2020-11-11 01:42:04 --> Router Class Initialized
INFO - 2020-11-11 01:42:04 --> Output Class Initialized
INFO - 2020-11-11 01:42:04 --> Security Class Initialized
DEBUG - 2020-11-11 01:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:42:04 --> Input Class Initialized
INFO - 2020-11-11 01:42:04 --> Language Class Initialized
INFO - 2020-11-11 01:42:04 --> Language Class Initialized
INFO - 2020-11-11 01:42:04 --> Config Class Initialized
INFO - 2020-11-11 01:42:04 --> Loader Class Initialized
INFO - 2020-11-11 01:42:04 --> Helper loaded: url_helper
INFO - 2020-11-11 01:42:04 --> Helper loaded: file_helper
INFO - 2020-11-11 01:42:04 --> Helper loaded: form_helper
INFO - 2020-11-11 01:42:04 --> Helper loaded: my_helper
INFO - 2020-11-11 01:42:04 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:42:05 --> Controller Class Initialized
INFO - 2020-11-11 01:42:05 --> Final output sent to browser
DEBUG - 2020-11-11 01:42:05 --> Total execution time: 0.2031
INFO - 2020-11-11 01:42:08 --> Config Class Initialized
INFO - 2020-11-11 01:42:09 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:42:09 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:42:09 --> Utf8 Class Initialized
INFO - 2020-11-11 01:42:09 --> URI Class Initialized
INFO - 2020-11-11 01:42:09 --> Router Class Initialized
INFO - 2020-11-11 01:42:09 --> Output Class Initialized
INFO - 2020-11-11 01:42:09 --> Security Class Initialized
DEBUG - 2020-11-11 01:42:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:42:09 --> Input Class Initialized
INFO - 2020-11-11 01:42:09 --> Language Class Initialized
INFO - 2020-11-11 01:42:09 --> Language Class Initialized
INFO - 2020-11-11 01:42:09 --> Config Class Initialized
INFO - 2020-11-11 01:42:09 --> Loader Class Initialized
INFO - 2020-11-11 01:42:09 --> Helper loaded: url_helper
INFO - 2020-11-11 01:42:09 --> Helper loaded: file_helper
INFO - 2020-11-11 01:42:09 --> Helper loaded: form_helper
INFO - 2020-11-11 01:42:09 --> Helper loaded: my_helper
INFO - 2020-11-11 01:42:09 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:42:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:42:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:42:09 --> Controller Class Initialized
INFO - 2020-11-11 01:42:09 --> Final output sent to browser
DEBUG - 2020-11-11 01:42:09 --> Total execution time: 0.2137
INFO - 2020-11-11 01:42:11 --> Config Class Initialized
INFO - 2020-11-11 01:42:11 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:42:11 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:42:11 --> Utf8 Class Initialized
INFO - 2020-11-11 01:42:11 --> URI Class Initialized
INFO - 2020-11-11 01:42:11 --> Router Class Initialized
INFO - 2020-11-11 01:42:11 --> Output Class Initialized
INFO - 2020-11-11 01:42:11 --> Security Class Initialized
DEBUG - 2020-11-11 01:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:42:11 --> Input Class Initialized
INFO - 2020-11-11 01:42:11 --> Language Class Initialized
INFO - 2020-11-11 01:42:11 --> Language Class Initialized
INFO - 2020-11-11 01:42:11 --> Config Class Initialized
INFO - 2020-11-11 01:42:11 --> Loader Class Initialized
INFO - 2020-11-11 01:42:11 --> Helper loaded: url_helper
INFO - 2020-11-11 01:42:11 --> Helper loaded: file_helper
INFO - 2020-11-11 01:42:11 --> Helper loaded: form_helper
INFO - 2020-11-11 01:42:11 --> Helper loaded: my_helper
INFO - 2020-11-11 01:42:11 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:42:11 --> Controller Class Initialized
INFO - 2020-11-11 01:42:11 --> Final output sent to browser
DEBUG - 2020-11-11 01:42:11 --> Total execution time: 0.1807
INFO - 2020-11-11 01:42:13 --> Config Class Initialized
INFO - 2020-11-11 01:42:13 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:42:13 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:42:13 --> Utf8 Class Initialized
INFO - 2020-11-11 01:42:13 --> URI Class Initialized
INFO - 2020-11-11 01:42:13 --> Router Class Initialized
INFO - 2020-11-11 01:42:13 --> Output Class Initialized
INFO - 2020-11-11 01:42:13 --> Security Class Initialized
DEBUG - 2020-11-11 01:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:42:13 --> Input Class Initialized
INFO - 2020-11-11 01:42:13 --> Language Class Initialized
INFO - 2020-11-11 01:42:13 --> Language Class Initialized
INFO - 2020-11-11 01:42:13 --> Config Class Initialized
INFO - 2020-11-11 01:42:13 --> Loader Class Initialized
INFO - 2020-11-11 01:42:13 --> Helper loaded: url_helper
INFO - 2020-11-11 01:42:13 --> Helper loaded: file_helper
INFO - 2020-11-11 01:42:13 --> Helper loaded: form_helper
INFO - 2020-11-11 01:42:13 --> Helper loaded: my_helper
INFO - 2020-11-11 01:42:13 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:42:13 --> Controller Class Initialized
INFO - 2020-11-11 01:42:13 --> Final output sent to browser
DEBUG - 2020-11-11 01:42:13 --> Total execution time: 0.2208
INFO - 2020-11-11 01:42:16 --> Config Class Initialized
INFO - 2020-11-11 01:42:16 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:42:16 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:42:16 --> Utf8 Class Initialized
INFO - 2020-11-11 01:42:16 --> URI Class Initialized
INFO - 2020-11-11 01:42:16 --> Router Class Initialized
INFO - 2020-11-11 01:42:16 --> Output Class Initialized
INFO - 2020-11-11 01:42:16 --> Security Class Initialized
DEBUG - 2020-11-11 01:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:42:16 --> Input Class Initialized
INFO - 2020-11-11 01:42:16 --> Language Class Initialized
INFO - 2020-11-11 01:42:16 --> Language Class Initialized
INFO - 2020-11-11 01:42:16 --> Config Class Initialized
INFO - 2020-11-11 01:42:16 --> Loader Class Initialized
INFO - 2020-11-11 01:42:16 --> Helper loaded: url_helper
INFO - 2020-11-11 01:42:16 --> Helper loaded: file_helper
INFO - 2020-11-11 01:42:16 --> Helper loaded: form_helper
INFO - 2020-11-11 01:42:16 --> Helper loaded: my_helper
INFO - 2020-11-11 01:42:16 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:42:16 --> Controller Class Initialized
INFO - 2020-11-11 01:42:16 --> Final output sent to browser
DEBUG - 2020-11-11 01:42:16 --> Total execution time: 0.2114
INFO - 2020-11-11 01:43:44 --> Config Class Initialized
INFO - 2020-11-11 01:43:44 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:43:44 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:43:44 --> Utf8 Class Initialized
INFO - 2020-11-11 01:43:44 --> URI Class Initialized
INFO - 2020-11-11 01:43:44 --> Router Class Initialized
INFO - 2020-11-11 01:43:44 --> Output Class Initialized
INFO - 2020-11-11 01:43:44 --> Security Class Initialized
DEBUG - 2020-11-11 01:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:43:44 --> Input Class Initialized
INFO - 2020-11-11 01:43:44 --> Language Class Initialized
INFO - 2020-11-11 01:43:44 --> Language Class Initialized
INFO - 2020-11-11 01:43:44 --> Config Class Initialized
INFO - 2020-11-11 01:43:44 --> Loader Class Initialized
INFO - 2020-11-11 01:43:44 --> Helper loaded: url_helper
INFO - 2020-11-11 01:43:44 --> Helper loaded: file_helper
INFO - 2020-11-11 01:43:44 --> Helper loaded: form_helper
INFO - 2020-11-11 01:43:44 --> Helper loaded: my_helper
INFO - 2020-11-11 01:43:44 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:43:44 --> Controller Class Initialized
INFO - 2020-11-11 01:43:44 --> Final output sent to browser
DEBUG - 2020-11-11 01:43:44 --> Total execution time: 0.2191
INFO - 2020-11-11 01:43:48 --> Config Class Initialized
INFO - 2020-11-11 01:43:48 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:43:48 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:43:48 --> Utf8 Class Initialized
INFO - 2020-11-11 01:43:48 --> URI Class Initialized
INFO - 2020-11-11 01:43:48 --> Router Class Initialized
INFO - 2020-11-11 01:43:48 --> Output Class Initialized
INFO - 2020-11-11 01:43:48 --> Security Class Initialized
DEBUG - 2020-11-11 01:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:43:48 --> Input Class Initialized
INFO - 2020-11-11 01:43:48 --> Language Class Initialized
INFO - 2020-11-11 01:43:48 --> Language Class Initialized
INFO - 2020-11-11 01:43:48 --> Config Class Initialized
INFO - 2020-11-11 01:43:48 --> Loader Class Initialized
INFO - 2020-11-11 01:43:48 --> Helper loaded: url_helper
INFO - 2020-11-11 01:43:48 --> Helper loaded: file_helper
INFO - 2020-11-11 01:43:48 --> Helper loaded: form_helper
INFO - 2020-11-11 01:43:48 --> Helper loaded: my_helper
INFO - 2020-11-11 01:43:48 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:43:48 --> Controller Class Initialized
INFO - 2020-11-11 01:43:48 --> Final output sent to browser
DEBUG - 2020-11-11 01:43:48 --> Total execution time: 0.2173
INFO - 2020-11-11 01:43:55 --> Config Class Initialized
INFO - 2020-11-11 01:43:55 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:43:55 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:43:55 --> Utf8 Class Initialized
INFO - 2020-11-11 01:43:55 --> URI Class Initialized
INFO - 2020-11-11 01:43:55 --> Router Class Initialized
INFO - 2020-11-11 01:43:55 --> Output Class Initialized
INFO - 2020-11-11 01:43:55 --> Security Class Initialized
DEBUG - 2020-11-11 01:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:43:55 --> Input Class Initialized
INFO - 2020-11-11 01:43:55 --> Language Class Initialized
INFO - 2020-11-11 01:43:55 --> Language Class Initialized
INFO - 2020-11-11 01:43:55 --> Config Class Initialized
INFO - 2020-11-11 01:43:55 --> Loader Class Initialized
INFO - 2020-11-11 01:43:55 --> Helper loaded: url_helper
INFO - 2020-11-11 01:43:55 --> Helper loaded: file_helper
INFO - 2020-11-11 01:43:55 --> Helper loaded: form_helper
INFO - 2020-11-11 01:43:55 --> Helper loaded: my_helper
INFO - 2020-11-11 01:43:55 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:43:55 --> Controller Class Initialized
INFO - 2020-11-11 01:43:55 --> Final output sent to browser
DEBUG - 2020-11-11 01:43:55 --> Total execution time: 0.2664
INFO - 2020-11-11 01:44:18 --> Config Class Initialized
INFO - 2020-11-11 01:44:18 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:44:18 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:44:18 --> Utf8 Class Initialized
INFO - 2020-11-11 01:44:18 --> URI Class Initialized
INFO - 2020-11-11 01:44:19 --> Router Class Initialized
INFO - 2020-11-11 01:44:19 --> Output Class Initialized
INFO - 2020-11-11 01:44:19 --> Security Class Initialized
DEBUG - 2020-11-11 01:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:44:19 --> Input Class Initialized
INFO - 2020-11-11 01:44:19 --> Language Class Initialized
INFO - 2020-11-11 01:44:19 --> Language Class Initialized
INFO - 2020-11-11 01:44:19 --> Config Class Initialized
INFO - 2020-11-11 01:44:19 --> Loader Class Initialized
INFO - 2020-11-11 01:44:19 --> Helper loaded: url_helper
INFO - 2020-11-11 01:44:19 --> Helper loaded: file_helper
INFO - 2020-11-11 01:44:19 --> Helper loaded: form_helper
INFO - 2020-11-11 01:44:19 --> Helper loaded: my_helper
INFO - 2020-11-11 01:44:19 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:44:19 --> Controller Class Initialized
INFO - 2020-11-11 01:44:19 --> Final output sent to browser
DEBUG - 2020-11-11 01:44:19 --> Total execution time: 0.2374
INFO - 2020-11-11 01:44:19 --> Config Class Initialized
INFO - 2020-11-11 01:44:19 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:44:19 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:44:19 --> Utf8 Class Initialized
INFO - 2020-11-11 01:44:19 --> URI Class Initialized
INFO - 2020-11-11 01:44:19 --> Router Class Initialized
INFO - 2020-11-11 01:44:19 --> Output Class Initialized
INFO - 2020-11-11 01:44:19 --> Security Class Initialized
DEBUG - 2020-11-11 01:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:44:19 --> Input Class Initialized
INFO - 2020-11-11 01:44:19 --> Language Class Initialized
INFO - 2020-11-11 01:44:19 --> Language Class Initialized
INFO - 2020-11-11 01:44:19 --> Config Class Initialized
INFO - 2020-11-11 01:44:19 --> Loader Class Initialized
INFO - 2020-11-11 01:44:19 --> Helper loaded: url_helper
INFO - 2020-11-11 01:44:19 --> Helper loaded: file_helper
INFO - 2020-11-11 01:44:19 --> Helper loaded: form_helper
INFO - 2020-11-11 01:44:19 --> Helper loaded: my_helper
INFO - 2020-11-11 01:44:19 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:44:19 --> Controller Class Initialized
INFO - 2020-11-11 01:44:34 --> Config Class Initialized
INFO - 2020-11-11 01:44:34 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:44:34 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:44:34 --> Utf8 Class Initialized
INFO - 2020-11-11 01:44:34 --> URI Class Initialized
INFO - 2020-11-11 01:44:34 --> Router Class Initialized
INFO - 2020-11-11 01:44:34 --> Output Class Initialized
INFO - 2020-11-11 01:44:34 --> Security Class Initialized
DEBUG - 2020-11-11 01:44:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:44:34 --> Input Class Initialized
INFO - 2020-11-11 01:44:34 --> Language Class Initialized
INFO - 2020-11-11 01:44:34 --> Language Class Initialized
INFO - 2020-11-11 01:44:34 --> Config Class Initialized
INFO - 2020-11-11 01:44:34 --> Loader Class Initialized
INFO - 2020-11-11 01:44:34 --> Helper loaded: url_helper
INFO - 2020-11-11 01:44:34 --> Helper loaded: file_helper
INFO - 2020-11-11 01:44:34 --> Helper loaded: form_helper
INFO - 2020-11-11 01:44:34 --> Helper loaded: my_helper
INFO - 2020-11-11 01:44:34 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:44:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:44:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:44:34 --> Controller Class Initialized
INFO - 2020-11-11 01:44:34 --> Final output sent to browser
DEBUG - 2020-11-11 01:44:34 --> Total execution time: 0.2014
INFO - 2020-11-11 01:44:45 --> Config Class Initialized
INFO - 2020-11-11 01:44:45 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:44:45 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:44:45 --> Utf8 Class Initialized
INFO - 2020-11-11 01:44:45 --> URI Class Initialized
INFO - 2020-11-11 01:44:45 --> Router Class Initialized
INFO - 2020-11-11 01:44:45 --> Output Class Initialized
INFO - 2020-11-11 01:44:45 --> Security Class Initialized
DEBUG - 2020-11-11 01:44:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:44:45 --> Input Class Initialized
INFO - 2020-11-11 01:44:45 --> Language Class Initialized
INFO - 2020-11-11 01:44:45 --> Language Class Initialized
INFO - 2020-11-11 01:44:45 --> Config Class Initialized
INFO - 2020-11-11 01:44:45 --> Loader Class Initialized
INFO - 2020-11-11 01:44:45 --> Helper loaded: url_helper
INFO - 2020-11-11 01:44:45 --> Helper loaded: file_helper
INFO - 2020-11-11 01:44:45 --> Helper loaded: form_helper
INFO - 2020-11-11 01:44:45 --> Helper loaded: my_helper
INFO - 2020-11-11 01:44:45 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:44:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:44:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:44:45 --> Controller Class Initialized
INFO - 2020-11-11 01:44:45 --> Final output sent to browser
DEBUG - 2020-11-11 01:44:45 --> Total execution time: 0.1896
INFO - 2020-11-11 01:45:08 --> Config Class Initialized
INFO - 2020-11-11 01:45:08 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:45:08 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:45:08 --> Utf8 Class Initialized
INFO - 2020-11-11 01:45:08 --> URI Class Initialized
INFO - 2020-11-11 01:45:08 --> Router Class Initialized
INFO - 2020-11-11 01:45:08 --> Output Class Initialized
INFO - 2020-11-11 01:45:08 --> Security Class Initialized
DEBUG - 2020-11-11 01:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:45:08 --> Input Class Initialized
INFO - 2020-11-11 01:45:08 --> Language Class Initialized
INFO - 2020-11-11 01:45:08 --> Language Class Initialized
INFO - 2020-11-11 01:45:08 --> Config Class Initialized
INFO - 2020-11-11 01:45:08 --> Loader Class Initialized
INFO - 2020-11-11 01:45:08 --> Helper loaded: url_helper
INFO - 2020-11-11 01:45:08 --> Helper loaded: file_helper
INFO - 2020-11-11 01:45:08 --> Helper loaded: form_helper
INFO - 2020-11-11 01:45:08 --> Helper loaded: my_helper
INFO - 2020-11-11 01:45:08 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:45:08 --> Controller Class Initialized
INFO - 2020-11-11 01:45:08 --> Final output sent to browser
DEBUG - 2020-11-11 01:45:08 --> Total execution time: 0.2100
INFO - 2020-11-11 01:45:12 --> Config Class Initialized
INFO - 2020-11-11 01:45:12 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:45:12 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:45:12 --> Utf8 Class Initialized
INFO - 2020-11-11 01:45:12 --> URI Class Initialized
INFO - 2020-11-11 01:45:12 --> Router Class Initialized
INFO - 2020-11-11 01:45:12 --> Output Class Initialized
INFO - 2020-11-11 01:45:12 --> Security Class Initialized
DEBUG - 2020-11-11 01:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:45:12 --> Input Class Initialized
INFO - 2020-11-11 01:45:12 --> Language Class Initialized
INFO - 2020-11-11 01:45:12 --> Language Class Initialized
INFO - 2020-11-11 01:45:12 --> Config Class Initialized
INFO - 2020-11-11 01:45:12 --> Loader Class Initialized
INFO - 2020-11-11 01:45:12 --> Helper loaded: url_helper
INFO - 2020-11-11 01:45:12 --> Helper loaded: file_helper
INFO - 2020-11-11 01:45:12 --> Helper loaded: form_helper
INFO - 2020-11-11 01:45:12 --> Helper loaded: my_helper
INFO - 2020-11-11 01:45:12 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:45:12 --> Controller Class Initialized
INFO - 2020-11-11 01:45:12 --> Final output sent to browser
DEBUG - 2020-11-11 01:45:12 --> Total execution time: 0.2169
INFO - 2020-11-11 01:45:14 --> Config Class Initialized
INFO - 2020-11-11 01:45:14 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:45:14 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:45:14 --> Utf8 Class Initialized
INFO - 2020-11-11 01:45:14 --> URI Class Initialized
INFO - 2020-11-11 01:45:14 --> Router Class Initialized
INFO - 2020-11-11 01:45:14 --> Output Class Initialized
INFO - 2020-11-11 01:45:14 --> Security Class Initialized
DEBUG - 2020-11-11 01:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:45:14 --> Input Class Initialized
INFO - 2020-11-11 01:45:14 --> Language Class Initialized
INFO - 2020-11-11 01:45:14 --> Language Class Initialized
INFO - 2020-11-11 01:45:14 --> Config Class Initialized
INFO - 2020-11-11 01:45:14 --> Loader Class Initialized
INFO - 2020-11-11 01:45:14 --> Helper loaded: url_helper
INFO - 2020-11-11 01:45:14 --> Helper loaded: file_helper
INFO - 2020-11-11 01:45:14 --> Helper loaded: form_helper
INFO - 2020-11-11 01:45:14 --> Helper loaded: my_helper
INFO - 2020-11-11 01:45:14 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:45:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:45:14 --> Controller Class Initialized
INFO - 2020-11-11 01:45:14 --> Final output sent to browser
DEBUG - 2020-11-11 01:45:14 --> Total execution time: 0.1806
INFO - 2020-11-11 01:45:42 --> Config Class Initialized
INFO - 2020-11-11 01:45:42 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:45:42 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:45:42 --> Utf8 Class Initialized
INFO - 2020-11-11 01:45:42 --> URI Class Initialized
INFO - 2020-11-11 01:45:42 --> Router Class Initialized
INFO - 2020-11-11 01:45:42 --> Output Class Initialized
INFO - 2020-11-11 01:45:42 --> Security Class Initialized
DEBUG - 2020-11-11 01:45:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:45:42 --> Input Class Initialized
INFO - 2020-11-11 01:45:42 --> Language Class Initialized
INFO - 2020-11-11 01:45:42 --> Language Class Initialized
INFO - 2020-11-11 01:45:42 --> Config Class Initialized
INFO - 2020-11-11 01:45:42 --> Loader Class Initialized
INFO - 2020-11-11 01:45:42 --> Helper loaded: url_helper
INFO - 2020-11-11 01:45:42 --> Helper loaded: file_helper
INFO - 2020-11-11 01:45:42 --> Helper loaded: form_helper
INFO - 2020-11-11 01:45:42 --> Helper loaded: my_helper
INFO - 2020-11-11 01:45:42 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:45:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:45:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:45:42 --> Controller Class Initialized
INFO - 2020-11-11 01:45:42 --> Final output sent to browser
DEBUG - 2020-11-11 01:45:42 --> Total execution time: 0.2099
INFO - 2020-11-11 01:45:44 --> Config Class Initialized
INFO - 2020-11-11 01:45:44 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:45:44 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:45:44 --> Utf8 Class Initialized
INFO - 2020-11-11 01:45:44 --> URI Class Initialized
INFO - 2020-11-11 01:45:44 --> Router Class Initialized
INFO - 2020-11-11 01:45:44 --> Output Class Initialized
INFO - 2020-11-11 01:45:44 --> Security Class Initialized
DEBUG - 2020-11-11 01:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:45:44 --> Input Class Initialized
INFO - 2020-11-11 01:45:44 --> Language Class Initialized
INFO - 2020-11-11 01:45:44 --> Language Class Initialized
INFO - 2020-11-11 01:45:44 --> Config Class Initialized
INFO - 2020-11-11 01:45:44 --> Loader Class Initialized
INFO - 2020-11-11 01:45:44 --> Helper loaded: url_helper
INFO - 2020-11-11 01:45:44 --> Helper loaded: file_helper
INFO - 2020-11-11 01:45:45 --> Helper loaded: form_helper
INFO - 2020-11-11 01:45:45 --> Helper loaded: my_helper
INFO - 2020-11-11 01:45:45 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:45:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:45:45 --> Controller Class Initialized
INFO - 2020-11-11 01:45:45 --> Final output sent to browser
DEBUG - 2020-11-11 01:45:45 --> Total execution time: 0.1985
INFO - 2020-11-11 01:45:46 --> Config Class Initialized
INFO - 2020-11-11 01:45:46 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:45:46 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:45:46 --> Utf8 Class Initialized
INFO - 2020-11-11 01:45:46 --> URI Class Initialized
INFO - 2020-11-11 01:45:46 --> Router Class Initialized
INFO - 2020-11-11 01:45:46 --> Output Class Initialized
INFO - 2020-11-11 01:45:46 --> Security Class Initialized
DEBUG - 2020-11-11 01:45:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:45:46 --> Input Class Initialized
INFO - 2020-11-11 01:45:46 --> Language Class Initialized
INFO - 2020-11-11 01:45:46 --> Language Class Initialized
INFO - 2020-11-11 01:45:46 --> Config Class Initialized
INFO - 2020-11-11 01:45:46 --> Loader Class Initialized
INFO - 2020-11-11 01:45:46 --> Helper loaded: url_helper
INFO - 2020-11-11 01:45:46 --> Helper loaded: file_helper
INFO - 2020-11-11 01:45:46 --> Helper loaded: form_helper
INFO - 2020-11-11 01:45:46 --> Helper loaded: my_helper
INFO - 2020-11-11 01:45:46 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:45:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:45:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:45:46 --> Controller Class Initialized
INFO - 2020-11-11 01:45:46 --> Final output sent to browser
DEBUG - 2020-11-11 01:45:46 --> Total execution time: 0.2082
INFO - 2020-11-11 01:45:50 --> Config Class Initialized
INFO - 2020-11-11 01:45:50 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:45:50 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:45:50 --> Utf8 Class Initialized
INFO - 2020-11-11 01:45:50 --> URI Class Initialized
INFO - 2020-11-11 01:45:50 --> Router Class Initialized
INFO - 2020-11-11 01:45:50 --> Output Class Initialized
INFO - 2020-11-11 01:45:50 --> Security Class Initialized
DEBUG - 2020-11-11 01:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:45:50 --> Input Class Initialized
INFO - 2020-11-11 01:45:50 --> Language Class Initialized
INFO - 2020-11-11 01:45:50 --> Language Class Initialized
INFO - 2020-11-11 01:45:50 --> Config Class Initialized
INFO - 2020-11-11 01:45:50 --> Loader Class Initialized
INFO - 2020-11-11 01:45:50 --> Helper loaded: url_helper
INFO - 2020-11-11 01:45:50 --> Helper loaded: file_helper
INFO - 2020-11-11 01:45:50 --> Helper loaded: form_helper
INFO - 2020-11-11 01:45:50 --> Helper loaded: my_helper
INFO - 2020-11-11 01:45:51 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:45:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:45:51 --> Controller Class Initialized
INFO - 2020-11-11 01:45:51 --> Final output sent to browser
DEBUG - 2020-11-11 01:45:51 --> Total execution time: 0.2109
INFO - 2020-11-11 01:46:17 --> Config Class Initialized
INFO - 2020-11-11 01:46:17 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:46:17 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:46:17 --> Utf8 Class Initialized
INFO - 2020-11-11 01:46:17 --> URI Class Initialized
INFO - 2020-11-11 01:46:17 --> Router Class Initialized
INFO - 2020-11-11 01:46:17 --> Output Class Initialized
INFO - 2020-11-11 01:46:17 --> Security Class Initialized
DEBUG - 2020-11-11 01:46:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:46:17 --> Input Class Initialized
INFO - 2020-11-11 01:46:17 --> Language Class Initialized
INFO - 2020-11-11 01:46:17 --> Language Class Initialized
INFO - 2020-11-11 01:46:17 --> Config Class Initialized
INFO - 2020-11-11 01:46:17 --> Loader Class Initialized
INFO - 2020-11-11 01:46:17 --> Helper loaded: url_helper
INFO - 2020-11-11 01:46:17 --> Helper loaded: file_helper
INFO - 2020-11-11 01:46:17 --> Helper loaded: form_helper
INFO - 2020-11-11 01:46:17 --> Helper loaded: my_helper
INFO - 2020-11-11 01:46:17 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:46:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:46:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:46:17 --> Controller Class Initialized
INFO - 2020-11-11 01:46:17 --> Final output sent to browser
DEBUG - 2020-11-11 01:46:17 --> Total execution time: 0.2144
INFO - 2020-11-11 01:46:24 --> Config Class Initialized
INFO - 2020-11-11 01:46:24 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:46:24 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:46:24 --> Utf8 Class Initialized
INFO - 2020-11-11 01:46:24 --> URI Class Initialized
INFO - 2020-11-11 01:46:24 --> Router Class Initialized
INFO - 2020-11-11 01:46:24 --> Output Class Initialized
INFO - 2020-11-11 01:46:24 --> Security Class Initialized
DEBUG - 2020-11-11 01:46:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:46:24 --> Input Class Initialized
INFO - 2020-11-11 01:46:24 --> Language Class Initialized
INFO - 2020-11-11 01:46:24 --> Language Class Initialized
INFO - 2020-11-11 01:46:24 --> Config Class Initialized
INFO - 2020-11-11 01:46:24 --> Loader Class Initialized
INFO - 2020-11-11 01:46:24 --> Helper loaded: url_helper
INFO - 2020-11-11 01:46:24 --> Helper loaded: file_helper
INFO - 2020-11-11 01:46:24 --> Helper loaded: form_helper
INFO - 2020-11-11 01:46:24 --> Helper loaded: my_helper
INFO - 2020-11-11 01:46:24 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:46:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:46:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:46:24 --> Controller Class Initialized
INFO - 2020-11-11 01:46:24 --> Final output sent to browser
DEBUG - 2020-11-11 01:46:24 --> Total execution time: 0.2015
INFO - 2020-11-11 01:46:33 --> Config Class Initialized
INFO - 2020-11-11 01:46:33 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:46:33 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:46:33 --> Utf8 Class Initialized
INFO - 2020-11-11 01:46:33 --> URI Class Initialized
INFO - 2020-11-11 01:46:33 --> Router Class Initialized
INFO - 2020-11-11 01:46:33 --> Output Class Initialized
INFO - 2020-11-11 01:46:33 --> Security Class Initialized
DEBUG - 2020-11-11 01:46:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:46:33 --> Input Class Initialized
INFO - 2020-11-11 01:46:33 --> Language Class Initialized
INFO - 2020-11-11 01:46:34 --> Language Class Initialized
INFO - 2020-11-11 01:46:34 --> Config Class Initialized
INFO - 2020-11-11 01:46:34 --> Loader Class Initialized
INFO - 2020-11-11 01:46:34 --> Helper loaded: url_helper
INFO - 2020-11-11 01:46:34 --> Helper loaded: file_helper
INFO - 2020-11-11 01:46:34 --> Helper loaded: form_helper
INFO - 2020-11-11 01:46:34 --> Helper loaded: my_helper
INFO - 2020-11-11 01:46:34 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:46:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:46:34 --> Controller Class Initialized
INFO - 2020-11-11 01:46:34 --> Final output sent to browser
DEBUG - 2020-11-11 01:46:34 --> Total execution time: 0.2146
INFO - 2020-11-11 01:46:36 --> Config Class Initialized
INFO - 2020-11-11 01:46:36 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:46:36 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:46:36 --> Utf8 Class Initialized
INFO - 2020-11-11 01:46:36 --> URI Class Initialized
INFO - 2020-11-11 01:46:36 --> Router Class Initialized
INFO - 2020-11-11 01:46:36 --> Output Class Initialized
INFO - 2020-11-11 01:46:36 --> Security Class Initialized
DEBUG - 2020-11-11 01:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:46:36 --> Input Class Initialized
INFO - 2020-11-11 01:46:36 --> Language Class Initialized
INFO - 2020-11-11 01:46:36 --> Language Class Initialized
INFO - 2020-11-11 01:46:36 --> Config Class Initialized
INFO - 2020-11-11 01:46:36 --> Loader Class Initialized
INFO - 2020-11-11 01:46:36 --> Helper loaded: url_helper
INFO - 2020-11-11 01:46:36 --> Helper loaded: file_helper
INFO - 2020-11-11 01:46:36 --> Helper loaded: form_helper
INFO - 2020-11-11 01:46:36 --> Helper loaded: my_helper
INFO - 2020-11-11 01:46:36 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:46:36 --> Controller Class Initialized
INFO - 2020-11-11 01:46:36 --> Final output sent to browser
DEBUG - 2020-11-11 01:46:36 --> Total execution time: 0.2277
INFO - 2020-11-11 01:46:39 --> Config Class Initialized
INFO - 2020-11-11 01:46:39 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:46:39 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:46:39 --> Utf8 Class Initialized
INFO - 2020-11-11 01:46:39 --> URI Class Initialized
INFO - 2020-11-11 01:46:39 --> Router Class Initialized
INFO - 2020-11-11 01:46:39 --> Output Class Initialized
INFO - 2020-11-11 01:46:39 --> Security Class Initialized
DEBUG - 2020-11-11 01:46:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:46:39 --> Input Class Initialized
INFO - 2020-11-11 01:46:39 --> Language Class Initialized
INFO - 2020-11-11 01:46:39 --> Language Class Initialized
INFO - 2020-11-11 01:46:39 --> Config Class Initialized
INFO - 2020-11-11 01:46:39 --> Loader Class Initialized
INFO - 2020-11-11 01:46:39 --> Helper loaded: url_helper
INFO - 2020-11-11 01:46:39 --> Helper loaded: file_helper
INFO - 2020-11-11 01:46:39 --> Helper loaded: form_helper
INFO - 2020-11-11 01:46:39 --> Helper loaded: my_helper
INFO - 2020-11-11 01:46:39 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:46:40 --> Controller Class Initialized
INFO - 2020-11-11 01:46:40 --> Final output sent to browser
DEBUG - 2020-11-11 01:46:40 --> Total execution time: 0.2182
INFO - 2020-11-11 01:46:58 --> Config Class Initialized
INFO - 2020-11-11 01:46:58 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:46:58 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:46:58 --> Utf8 Class Initialized
INFO - 2020-11-11 01:46:58 --> URI Class Initialized
INFO - 2020-11-11 01:46:58 --> Router Class Initialized
INFO - 2020-11-11 01:46:58 --> Output Class Initialized
INFO - 2020-11-11 01:46:58 --> Security Class Initialized
DEBUG - 2020-11-11 01:46:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:46:58 --> Input Class Initialized
INFO - 2020-11-11 01:46:58 --> Language Class Initialized
INFO - 2020-11-11 01:46:58 --> Language Class Initialized
INFO - 2020-11-11 01:46:58 --> Config Class Initialized
INFO - 2020-11-11 01:46:58 --> Loader Class Initialized
INFO - 2020-11-11 01:46:58 --> Helper loaded: url_helper
INFO - 2020-11-11 01:46:58 --> Helper loaded: file_helper
INFO - 2020-11-11 01:46:58 --> Helper loaded: form_helper
INFO - 2020-11-11 01:46:58 --> Helper loaded: my_helper
INFO - 2020-11-11 01:46:58 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:46:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:46:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:46:58 --> Controller Class Initialized
INFO - 2020-11-11 01:46:58 --> Final output sent to browser
DEBUG - 2020-11-11 01:46:58 --> Total execution time: 0.2185
INFO - 2020-11-11 01:46:59 --> Config Class Initialized
INFO - 2020-11-11 01:46:59 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:46:59 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:46:59 --> Utf8 Class Initialized
INFO - 2020-11-11 01:47:00 --> URI Class Initialized
INFO - 2020-11-11 01:47:00 --> Router Class Initialized
INFO - 2020-11-11 01:47:00 --> Output Class Initialized
INFO - 2020-11-11 01:47:00 --> Security Class Initialized
DEBUG - 2020-11-11 01:47:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:47:00 --> Input Class Initialized
INFO - 2020-11-11 01:47:00 --> Language Class Initialized
INFO - 2020-11-11 01:47:00 --> Language Class Initialized
INFO - 2020-11-11 01:47:00 --> Config Class Initialized
INFO - 2020-11-11 01:47:00 --> Loader Class Initialized
INFO - 2020-11-11 01:47:00 --> Helper loaded: url_helper
INFO - 2020-11-11 01:47:00 --> Helper loaded: file_helper
INFO - 2020-11-11 01:47:00 --> Helper loaded: form_helper
INFO - 2020-11-11 01:47:00 --> Helper loaded: my_helper
INFO - 2020-11-11 01:47:00 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:47:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:47:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:47:00 --> Controller Class Initialized
INFO - 2020-11-11 01:47:00 --> Final output sent to browser
DEBUG - 2020-11-11 01:47:00 --> Total execution time: 0.2558
INFO - 2020-11-11 01:52:45 --> Config Class Initialized
INFO - 2020-11-11 01:52:45 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:52:45 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:52:45 --> Utf8 Class Initialized
INFO - 2020-11-11 01:52:45 --> URI Class Initialized
INFO - 2020-11-11 01:52:45 --> Router Class Initialized
INFO - 2020-11-11 01:52:45 --> Output Class Initialized
INFO - 2020-11-11 01:52:45 --> Security Class Initialized
DEBUG - 2020-11-11 01:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:52:45 --> Input Class Initialized
INFO - 2020-11-11 01:52:45 --> Language Class Initialized
INFO - 2020-11-11 01:52:45 --> Language Class Initialized
INFO - 2020-11-11 01:52:45 --> Config Class Initialized
INFO - 2020-11-11 01:52:45 --> Loader Class Initialized
INFO - 2020-11-11 01:52:45 --> Helper loaded: url_helper
INFO - 2020-11-11 01:52:45 --> Helper loaded: file_helper
INFO - 2020-11-11 01:52:45 --> Helper loaded: form_helper
INFO - 2020-11-11 01:52:45 --> Helper loaded: my_helper
INFO - 2020-11-11 01:52:45 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:52:45 --> Controller Class Initialized
INFO - 2020-11-11 01:52:45 --> Final output sent to browser
DEBUG - 2020-11-11 01:52:45 --> Total execution time: 0.2121
INFO - 2020-11-11 01:53:13 --> Config Class Initialized
INFO - 2020-11-11 01:53:13 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:53:13 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:53:13 --> Utf8 Class Initialized
INFO - 2020-11-11 01:53:13 --> URI Class Initialized
INFO - 2020-11-11 01:53:14 --> Router Class Initialized
INFO - 2020-11-11 01:53:14 --> Output Class Initialized
INFO - 2020-11-11 01:53:14 --> Security Class Initialized
DEBUG - 2020-11-11 01:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:53:14 --> Input Class Initialized
INFO - 2020-11-11 01:53:14 --> Language Class Initialized
INFO - 2020-11-11 01:53:14 --> Language Class Initialized
INFO - 2020-11-11 01:53:14 --> Config Class Initialized
INFO - 2020-11-11 01:53:14 --> Loader Class Initialized
INFO - 2020-11-11 01:53:14 --> Helper loaded: url_helper
INFO - 2020-11-11 01:53:14 --> Helper loaded: file_helper
INFO - 2020-11-11 01:53:14 --> Helper loaded: form_helper
INFO - 2020-11-11 01:53:14 --> Helper loaded: my_helper
INFO - 2020-11-11 01:53:14 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:53:14 --> Controller Class Initialized
INFO - 2020-11-11 01:54:37 --> Config Class Initialized
INFO - 2020-11-11 01:54:37 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:38 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:38 --> Utf8 Class Initialized
INFO - 2020-11-11 01:54:38 --> URI Class Initialized
INFO - 2020-11-11 01:54:38 --> Router Class Initialized
INFO - 2020-11-11 01:54:38 --> Output Class Initialized
INFO - 2020-11-11 01:54:38 --> Security Class Initialized
DEBUG - 2020-11-11 01:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:54:38 --> Input Class Initialized
INFO - 2020-11-11 01:54:38 --> Language Class Initialized
INFO - 2020-11-11 01:54:38 --> Language Class Initialized
INFO - 2020-11-11 01:54:38 --> Config Class Initialized
INFO - 2020-11-11 01:54:38 --> Loader Class Initialized
INFO - 2020-11-11 01:54:38 --> Helper loaded: url_helper
INFO - 2020-11-11 01:54:38 --> Helper loaded: file_helper
INFO - 2020-11-11 01:54:38 --> Helper loaded: form_helper
INFO - 2020-11-11 01:54:38 --> Helper loaded: my_helper
INFO - 2020-11-11 01:54:38 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:54:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:54:38 --> Controller Class Initialized
DEBUG - 2020-11-11 01:54:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2020-11-11 01:54:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:54:38 --> Final output sent to browser
DEBUG - 2020-11-11 01:54:38 --> Total execution time: 0.3030
INFO - 2020-11-11 01:54:49 --> Config Class Initialized
INFO - 2020-11-11 01:54:49 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:49 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:49 --> Utf8 Class Initialized
INFO - 2020-11-11 01:54:49 --> URI Class Initialized
INFO - 2020-11-11 01:54:49 --> Router Class Initialized
INFO - 2020-11-11 01:54:49 --> Output Class Initialized
INFO - 2020-11-11 01:54:49 --> Security Class Initialized
DEBUG - 2020-11-11 01:54:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:54:49 --> Input Class Initialized
INFO - 2020-11-11 01:54:49 --> Language Class Initialized
INFO - 2020-11-11 01:54:49 --> Language Class Initialized
INFO - 2020-11-11 01:54:49 --> Config Class Initialized
INFO - 2020-11-11 01:54:49 --> Loader Class Initialized
INFO - 2020-11-11 01:54:50 --> Helper loaded: url_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: file_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: form_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: my_helper
INFO - 2020-11-11 01:54:50 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:54:50 --> Controller Class Initialized
INFO - 2020-11-11 01:54:50 --> Config Class Initialized
INFO - 2020-11-11 01:54:50 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:50 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:50 --> Utf8 Class Initialized
INFO - 2020-11-11 01:54:50 --> URI Class Initialized
INFO - 2020-11-11 01:54:50 --> Router Class Initialized
INFO - 2020-11-11 01:54:50 --> Output Class Initialized
INFO - 2020-11-11 01:54:50 --> Security Class Initialized
DEBUG - 2020-11-11 01:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:54:50 --> Input Class Initialized
INFO - 2020-11-11 01:54:50 --> Language Class Initialized
INFO - 2020-11-11 01:54:50 --> Language Class Initialized
INFO - 2020-11-11 01:54:50 --> Config Class Initialized
INFO - 2020-11-11 01:54:50 --> Loader Class Initialized
INFO - 2020-11-11 01:54:50 --> Helper loaded: url_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: file_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: form_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: my_helper
INFO - 2020-11-11 01:54:50 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:54:50 --> Controller Class Initialized
DEBUG - 2020-11-11 01:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-11 01:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 01:54:50 --> Final output sent to browser
DEBUG - 2020-11-11 01:54:50 --> Total execution time: 0.2469
INFO - 2020-11-11 01:54:50 --> Config Class Initialized
INFO - 2020-11-11 01:54:50 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:50 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:50 --> Utf8 Class Initialized
INFO - 2020-11-11 01:54:50 --> URI Class Initialized
INFO - 2020-11-11 01:54:50 --> Router Class Initialized
INFO - 2020-11-11 01:54:50 --> Output Class Initialized
INFO - 2020-11-11 01:54:50 --> Security Class Initialized
DEBUG - 2020-11-11 01:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:54:50 --> Input Class Initialized
INFO - 2020-11-11 01:54:50 --> Language Class Initialized
INFO - 2020-11-11 01:54:50 --> Language Class Initialized
INFO - 2020-11-11 01:54:50 --> Config Class Initialized
INFO - 2020-11-11 01:54:50 --> Loader Class Initialized
INFO - 2020-11-11 01:54:50 --> Helper loaded: url_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: file_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: form_helper
INFO - 2020-11-11 01:54:50 --> Helper loaded: my_helper
INFO - 2020-11-11 01:54:50 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:54:50 --> Controller Class Initialized
INFO - 2020-11-11 01:54:53 --> Config Class Initialized
INFO - 2020-11-11 01:54:53 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:53 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:53 --> Utf8 Class Initialized
INFO - 2020-11-11 01:54:53 --> URI Class Initialized
INFO - 2020-11-11 01:54:53 --> Router Class Initialized
INFO - 2020-11-11 01:54:53 --> Output Class Initialized
INFO - 2020-11-11 01:54:53 --> Security Class Initialized
DEBUG - 2020-11-11 01:54:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:54:53 --> Input Class Initialized
INFO - 2020-11-11 01:54:53 --> Language Class Initialized
INFO - 2020-11-11 01:54:53 --> Language Class Initialized
INFO - 2020-11-11 01:54:53 --> Config Class Initialized
INFO - 2020-11-11 01:54:53 --> Loader Class Initialized
INFO - 2020-11-11 01:54:53 --> Helper loaded: url_helper
INFO - 2020-11-11 01:54:53 --> Helper loaded: file_helper
INFO - 2020-11-11 01:54:53 --> Helper loaded: form_helper
INFO - 2020-11-11 01:54:53 --> Helper loaded: my_helper
INFO - 2020-11-11 01:54:53 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:54:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:54:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:54:53 --> Controller Class Initialized
INFO - 2020-11-11 01:54:53 --> Final output sent to browser
DEBUG - 2020-11-11 01:54:53 --> Total execution time: 0.2023
INFO - 2020-11-11 01:54:55 --> Config Class Initialized
INFO - 2020-11-11 01:54:55 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:55 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:55 --> Utf8 Class Initialized
INFO - 2020-11-11 01:54:55 --> URI Class Initialized
INFO - 2020-11-11 01:54:55 --> Router Class Initialized
INFO - 2020-11-11 01:54:55 --> Output Class Initialized
INFO - 2020-11-11 01:54:55 --> Security Class Initialized
DEBUG - 2020-11-11 01:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:54:55 --> Input Class Initialized
INFO - 2020-11-11 01:54:55 --> Language Class Initialized
INFO - 2020-11-11 01:54:55 --> Language Class Initialized
INFO - 2020-11-11 01:54:55 --> Config Class Initialized
INFO - 2020-11-11 01:54:55 --> Loader Class Initialized
INFO - 2020-11-11 01:54:55 --> Helper loaded: url_helper
INFO - 2020-11-11 01:54:55 --> Helper loaded: file_helper
INFO - 2020-11-11 01:54:55 --> Helper loaded: form_helper
INFO - 2020-11-11 01:54:55 --> Helper loaded: my_helper
INFO - 2020-11-11 01:54:55 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:54:56 --> Controller Class Initialized
INFO - 2020-11-11 01:54:56 --> Final output sent to browser
DEBUG - 2020-11-11 01:54:56 --> Total execution time: 0.2360
INFO - 2020-11-11 01:54:58 --> Config Class Initialized
INFO - 2020-11-11 01:54:58 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:58 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:58 --> Utf8 Class Initialized
INFO - 2020-11-11 01:54:58 --> URI Class Initialized
INFO - 2020-11-11 01:54:58 --> Router Class Initialized
INFO - 2020-11-11 01:54:58 --> Output Class Initialized
INFO - 2020-11-11 01:54:58 --> Security Class Initialized
DEBUG - 2020-11-11 01:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:54:58 --> Input Class Initialized
INFO - 2020-11-11 01:54:58 --> Language Class Initialized
INFO - 2020-11-11 01:54:58 --> Language Class Initialized
INFO - 2020-11-11 01:54:58 --> Config Class Initialized
INFO - 2020-11-11 01:54:58 --> Loader Class Initialized
INFO - 2020-11-11 01:54:58 --> Helper loaded: url_helper
INFO - 2020-11-11 01:54:58 --> Helper loaded: file_helper
INFO - 2020-11-11 01:54:58 --> Helper loaded: form_helper
INFO - 2020-11-11 01:54:58 --> Helper loaded: my_helper
INFO - 2020-11-11 01:54:58 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:54:58 --> Controller Class Initialized
INFO - 2020-11-11 01:54:58 --> Final output sent to browser
DEBUG - 2020-11-11 01:54:58 --> Total execution time: 0.2160
INFO - 2020-11-11 01:54:59 --> Config Class Initialized
INFO - 2020-11-11 01:54:59 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:54:59 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:54:59 --> Utf8 Class Initialized
INFO - 2020-11-11 01:55:00 --> URI Class Initialized
INFO - 2020-11-11 01:55:00 --> Router Class Initialized
INFO - 2020-11-11 01:55:00 --> Output Class Initialized
INFO - 2020-11-11 01:55:00 --> Security Class Initialized
DEBUG - 2020-11-11 01:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:55:00 --> Input Class Initialized
INFO - 2020-11-11 01:55:00 --> Language Class Initialized
INFO - 2020-11-11 01:55:00 --> Language Class Initialized
INFO - 2020-11-11 01:55:00 --> Config Class Initialized
INFO - 2020-11-11 01:55:00 --> Loader Class Initialized
INFO - 2020-11-11 01:55:00 --> Helper loaded: url_helper
INFO - 2020-11-11 01:55:00 --> Helper loaded: file_helper
INFO - 2020-11-11 01:55:00 --> Helper loaded: form_helper
INFO - 2020-11-11 01:55:00 --> Helper loaded: my_helper
INFO - 2020-11-11 01:55:00 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:55:00 --> Controller Class Initialized
INFO - 2020-11-11 01:55:00 --> Final output sent to browser
DEBUG - 2020-11-11 01:55:00 --> Total execution time: 0.2161
INFO - 2020-11-11 01:55:02 --> Config Class Initialized
INFO - 2020-11-11 01:55:02 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:55:02 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:55:02 --> Utf8 Class Initialized
INFO - 2020-11-11 01:55:02 --> URI Class Initialized
INFO - 2020-11-11 01:55:02 --> Router Class Initialized
INFO - 2020-11-11 01:55:02 --> Output Class Initialized
INFO - 2020-11-11 01:55:02 --> Security Class Initialized
DEBUG - 2020-11-11 01:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:55:02 --> Input Class Initialized
INFO - 2020-11-11 01:55:02 --> Language Class Initialized
INFO - 2020-11-11 01:55:02 --> Language Class Initialized
INFO - 2020-11-11 01:55:02 --> Config Class Initialized
INFO - 2020-11-11 01:55:02 --> Loader Class Initialized
INFO - 2020-11-11 01:55:02 --> Helper loaded: url_helper
INFO - 2020-11-11 01:55:02 --> Helper loaded: file_helper
INFO - 2020-11-11 01:55:02 --> Helper loaded: form_helper
INFO - 2020-11-11 01:55:02 --> Helper loaded: my_helper
INFO - 2020-11-11 01:55:02 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:55:02 --> Controller Class Initialized
DEBUG - 2020-11-11 01:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-11 01:55:02 --> Final output sent to browser
DEBUG - 2020-11-11 01:55:03 --> Total execution time: 0.2807
INFO - 2020-11-11 01:56:12 --> Config Class Initialized
INFO - 2020-11-11 01:56:12 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:56:12 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:56:12 --> Utf8 Class Initialized
INFO - 2020-11-11 01:56:12 --> URI Class Initialized
INFO - 2020-11-11 01:56:12 --> Router Class Initialized
INFO - 2020-11-11 01:56:12 --> Output Class Initialized
INFO - 2020-11-11 01:56:12 --> Security Class Initialized
DEBUG - 2020-11-11 01:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:56:12 --> Input Class Initialized
INFO - 2020-11-11 01:56:12 --> Language Class Initialized
INFO - 2020-11-11 01:56:12 --> Language Class Initialized
INFO - 2020-11-11 01:56:12 --> Config Class Initialized
INFO - 2020-11-11 01:56:12 --> Loader Class Initialized
INFO - 2020-11-11 01:56:12 --> Helper loaded: url_helper
INFO - 2020-11-11 01:56:12 --> Helper loaded: file_helper
INFO - 2020-11-11 01:56:12 --> Helper loaded: form_helper
INFO - 2020-11-11 01:56:12 --> Helper loaded: my_helper
INFO - 2020-11-11 01:56:13 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:56:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:56:13 --> Controller Class Initialized
INFO - 2020-11-11 01:56:13 --> Final output sent to browser
DEBUG - 2020-11-11 01:56:13 --> Total execution time: 0.1927
INFO - 2020-11-11 01:56:14 --> Config Class Initialized
INFO - 2020-11-11 01:56:14 --> Hooks Class Initialized
DEBUG - 2020-11-11 01:56:14 --> UTF-8 Support Enabled
INFO - 2020-11-11 01:56:14 --> Utf8 Class Initialized
INFO - 2020-11-11 01:56:14 --> URI Class Initialized
INFO - 2020-11-11 01:56:14 --> Router Class Initialized
INFO - 2020-11-11 01:56:14 --> Output Class Initialized
INFO - 2020-11-11 01:56:14 --> Security Class Initialized
DEBUG - 2020-11-11 01:56:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 01:56:14 --> Input Class Initialized
INFO - 2020-11-11 01:56:14 --> Language Class Initialized
INFO - 2020-11-11 01:56:14 --> Language Class Initialized
INFO - 2020-11-11 01:56:14 --> Config Class Initialized
INFO - 2020-11-11 01:56:14 --> Loader Class Initialized
INFO - 2020-11-11 01:56:14 --> Helper loaded: url_helper
INFO - 2020-11-11 01:56:14 --> Helper loaded: file_helper
INFO - 2020-11-11 01:56:14 --> Helper loaded: form_helper
INFO - 2020-11-11 01:56:14 --> Helper loaded: my_helper
INFO - 2020-11-11 01:56:14 --> Database Driver Class Initialized
DEBUG - 2020-11-11 01:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 01:56:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 01:56:14 --> Controller Class Initialized
INFO - 2020-11-11 01:56:14 --> Final output sent to browser
DEBUG - 2020-11-11 01:56:14 --> Total execution time: 0.2024
INFO - 2020-11-11 02:04:05 --> Config Class Initialized
INFO - 2020-11-11 02:04:05 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:04:05 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:04:05 --> Utf8 Class Initialized
INFO - 2020-11-11 02:04:05 --> URI Class Initialized
INFO - 2020-11-11 02:04:05 --> Router Class Initialized
INFO - 2020-11-11 02:04:05 --> Output Class Initialized
INFO - 2020-11-11 02:04:05 --> Security Class Initialized
DEBUG - 2020-11-11 02:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:04:05 --> Input Class Initialized
INFO - 2020-11-11 02:04:05 --> Language Class Initialized
INFO - 2020-11-11 02:04:05 --> Language Class Initialized
INFO - 2020-11-11 02:04:05 --> Config Class Initialized
INFO - 2020-11-11 02:04:05 --> Loader Class Initialized
INFO - 2020-11-11 02:04:05 --> Helper loaded: url_helper
INFO - 2020-11-11 02:04:05 --> Helper loaded: file_helper
INFO - 2020-11-11 02:04:05 --> Helper loaded: form_helper
INFO - 2020-11-11 02:04:06 --> Helper loaded: my_helper
INFO - 2020-11-11 02:04:06 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:04:06 --> Controller Class Initialized
INFO - 2020-11-11 02:04:06 --> Final output sent to browser
DEBUG - 2020-11-11 02:04:06 --> Total execution time: 0.2194
INFO - 2020-11-11 02:04:30 --> Config Class Initialized
INFO - 2020-11-11 02:04:30 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:04:30 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:04:30 --> Utf8 Class Initialized
INFO - 2020-11-11 02:04:30 --> URI Class Initialized
INFO - 2020-11-11 02:04:30 --> Router Class Initialized
INFO - 2020-11-11 02:04:30 --> Output Class Initialized
INFO - 2020-11-11 02:04:30 --> Security Class Initialized
DEBUG - 2020-11-11 02:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:04:30 --> Input Class Initialized
INFO - 2020-11-11 02:04:30 --> Language Class Initialized
INFO - 2020-11-11 02:04:30 --> Language Class Initialized
INFO - 2020-11-11 02:04:30 --> Config Class Initialized
INFO - 2020-11-11 02:04:30 --> Loader Class Initialized
INFO - 2020-11-11 02:04:30 --> Helper loaded: url_helper
INFO - 2020-11-11 02:04:30 --> Helper loaded: file_helper
INFO - 2020-11-11 02:04:30 --> Helper loaded: form_helper
INFO - 2020-11-11 02:04:30 --> Helper loaded: my_helper
INFO - 2020-11-11 02:04:30 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:04:30 --> Controller Class Initialized
INFO - 2020-11-11 02:04:30 --> Final output sent to browser
DEBUG - 2020-11-11 02:04:30 --> Total execution time: 0.2307
INFO - 2020-11-11 02:04:35 --> Config Class Initialized
INFO - 2020-11-11 02:04:35 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:04:35 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:04:35 --> Utf8 Class Initialized
INFO - 2020-11-11 02:04:35 --> URI Class Initialized
INFO - 2020-11-11 02:04:35 --> Router Class Initialized
INFO - 2020-11-11 02:04:35 --> Output Class Initialized
INFO - 2020-11-11 02:04:35 --> Security Class Initialized
DEBUG - 2020-11-11 02:04:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:04:35 --> Input Class Initialized
INFO - 2020-11-11 02:04:35 --> Language Class Initialized
INFO - 2020-11-11 02:04:35 --> Language Class Initialized
INFO - 2020-11-11 02:04:35 --> Config Class Initialized
INFO - 2020-11-11 02:04:35 --> Loader Class Initialized
INFO - 2020-11-11 02:04:35 --> Helper loaded: url_helper
INFO - 2020-11-11 02:04:35 --> Helper loaded: file_helper
INFO - 2020-11-11 02:04:35 --> Helper loaded: form_helper
INFO - 2020-11-11 02:04:35 --> Helper loaded: my_helper
INFO - 2020-11-11 02:04:35 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:04:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:04:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:04:35 --> Controller Class Initialized
INFO - 2020-11-11 02:04:35 --> Final output sent to browser
DEBUG - 2020-11-11 02:04:35 --> Total execution time: 0.2193
INFO - 2020-11-11 02:04:40 --> Config Class Initialized
INFO - 2020-11-11 02:04:40 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:04:40 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:04:40 --> Utf8 Class Initialized
INFO - 2020-11-11 02:04:40 --> URI Class Initialized
INFO - 2020-11-11 02:04:40 --> Router Class Initialized
INFO - 2020-11-11 02:04:40 --> Output Class Initialized
INFO - 2020-11-11 02:04:40 --> Security Class Initialized
DEBUG - 2020-11-11 02:04:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:04:40 --> Input Class Initialized
INFO - 2020-11-11 02:04:40 --> Language Class Initialized
INFO - 2020-11-11 02:04:40 --> Language Class Initialized
INFO - 2020-11-11 02:04:40 --> Config Class Initialized
INFO - 2020-11-11 02:04:40 --> Loader Class Initialized
INFO - 2020-11-11 02:04:40 --> Helper loaded: url_helper
INFO - 2020-11-11 02:04:40 --> Helper loaded: file_helper
INFO - 2020-11-11 02:04:40 --> Helper loaded: form_helper
INFO - 2020-11-11 02:04:40 --> Helper loaded: my_helper
INFO - 2020-11-11 02:04:40 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:04:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:04:40 --> Controller Class Initialized
INFO - 2020-11-11 02:04:40 --> Final output sent to browser
DEBUG - 2020-11-11 02:04:40 --> Total execution time: 0.2088
INFO - 2020-11-11 02:04:52 --> Config Class Initialized
INFO - 2020-11-11 02:04:52 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:04:52 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:04:52 --> Utf8 Class Initialized
INFO - 2020-11-11 02:04:52 --> URI Class Initialized
INFO - 2020-11-11 02:04:52 --> Router Class Initialized
INFO - 2020-11-11 02:04:52 --> Output Class Initialized
INFO - 2020-11-11 02:04:52 --> Security Class Initialized
DEBUG - 2020-11-11 02:04:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:04:52 --> Input Class Initialized
INFO - 2020-11-11 02:04:52 --> Language Class Initialized
INFO - 2020-11-11 02:04:52 --> Language Class Initialized
INFO - 2020-11-11 02:04:52 --> Config Class Initialized
INFO - 2020-11-11 02:04:52 --> Loader Class Initialized
INFO - 2020-11-11 02:04:52 --> Helper loaded: url_helper
INFO - 2020-11-11 02:04:52 --> Helper loaded: file_helper
INFO - 2020-11-11 02:04:52 --> Helper loaded: form_helper
INFO - 2020-11-11 02:04:52 --> Helper loaded: my_helper
INFO - 2020-11-11 02:04:53 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:04:53 --> Controller Class Initialized
INFO - 2020-11-11 02:04:53 --> Final output sent to browser
DEBUG - 2020-11-11 02:04:53 --> Total execution time: 0.2123
INFO - 2020-11-11 02:05:04 --> Config Class Initialized
INFO - 2020-11-11 02:05:04 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:05:04 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:05:04 --> Utf8 Class Initialized
INFO - 2020-11-11 02:05:04 --> URI Class Initialized
INFO - 2020-11-11 02:05:04 --> Router Class Initialized
INFO - 2020-11-11 02:05:04 --> Output Class Initialized
INFO - 2020-11-11 02:05:04 --> Security Class Initialized
DEBUG - 2020-11-11 02:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:05:04 --> Input Class Initialized
INFO - 2020-11-11 02:05:04 --> Language Class Initialized
INFO - 2020-11-11 02:05:04 --> Language Class Initialized
INFO - 2020-11-11 02:05:04 --> Config Class Initialized
INFO - 2020-11-11 02:05:05 --> Loader Class Initialized
INFO - 2020-11-11 02:05:05 --> Helper loaded: url_helper
INFO - 2020-11-11 02:05:05 --> Helper loaded: file_helper
INFO - 2020-11-11 02:05:05 --> Helper loaded: form_helper
INFO - 2020-11-11 02:05:05 --> Helper loaded: my_helper
INFO - 2020-11-11 02:05:05 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:05:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:05:05 --> Controller Class Initialized
INFO - 2020-11-11 02:05:05 --> Final output sent to browser
DEBUG - 2020-11-11 02:05:05 --> Total execution time: 0.3284
INFO - 2020-11-11 02:05:09 --> Config Class Initialized
INFO - 2020-11-11 02:05:09 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:05:09 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:05:09 --> Utf8 Class Initialized
INFO - 2020-11-11 02:05:09 --> URI Class Initialized
INFO - 2020-11-11 02:05:09 --> Router Class Initialized
INFO - 2020-11-11 02:05:09 --> Output Class Initialized
INFO - 2020-11-11 02:05:09 --> Security Class Initialized
DEBUG - 2020-11-11 02:05:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:05:09 --> Input Class Initialized
INFO - 2020-11-11 02:05:09 --> Language Class Initialized
INFO - 2020-11-11 02:05:09 --> Language Class Initialized
INFO - 2020-11-11 02:05:09 --> Config Class Initialized
INFO - 2020-11-11 02:05:09 --> Loader Class Initialized
INFO - 2020-11-11 02:05:09 --> Helper loaded: url_helper
INFO - 2020-11-11 02:05:09 --> Helper loaded: file_helper
INFO - 2020-11-11 02:05:09 --> Helper loaded: form_helper
INFO - 2020-11-11 02:05:09 --> Helper loaded: my_helper
INFO - 2020-11-11 02:05:09 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:05:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:05:09 --> Controller Class Initialized
INFO - 2020-11-11 02:05:09 --> Final output sent to browser
DEBUG - 2020-11-11 02:05:09 --> Total execution time: 0.2160
INFO - 2020-11-11 02:05:10 --> Config Class Initialized
INFO - 2020-11-11 02:05:10 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:05:10 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:05:10 --> Utf8 Class Initialized
INFO - 2020-11-11 02:05:10 --> URI Class Initialized
INFO - 2020-11-11 02:05:10 --> Router Class Initialized
INFO - 2020-11-11 02:05:10 --> Output Class Initialized
INFO - 2020-11-11 02:05:10 --> Security Class Initialized
DEBUG - 2020-11-11 02:05:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:05:10 --> Input Class Initialized
INFO - 2020-11-11 02:05:10 --> Language Class Initialized
INFO - 2020-11-11 02:05:10 --> Language Class Initialized
INFO - 2020-11-11 02:05:10 --> Config Class Initialized
INFO - 2020-11-11 02:05:10 --> Loader Class Initialized
INFO - 2020-11-11 02:05:10 --> Helper loaded: url_helper
INFO - 2020-11-11 02:05:10 --> Helper loaded: file_helper
INFO - 2020-11-11 02:05:10 --> Helper loaded: form_helper
INFO - 2020-11-11 02:05:10 --> Helper loaded: my_helper
INFO - 2020-11-11 02:05:10 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:05:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:05:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:05:11 --> Controller Class Initialized
INFO - 2020-11-11 02:05:11 --> Final output sent to browser
DEBUG - 2020-11-11 02:05:11 --> Total execution time: 0.2134
INFO - 2020-11-11 02:05:14 --> Config Class Initialized
INFO - 2020-11-11 02:05:14 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:05:14 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:05:14 --> Utf8 Class Initialized
INFO - 2020-11-11 02:05:14 --> URI Class Initialized
INFO - 2020-11-11 02:05:14 --> Router Class Initialized
INFO - 2020-11-11 02:05:14 --> Output Class Initialized
INFO - 2020-11-11 02:05:14 --> Security Class Initialized
DEBUG - 2020-11-11 02:05:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:05:14 --> Input Class Initialized
INFO - 2020-11-11 02:05:14 --> Language Class Initialized
INFO - 2020-11-11 02:05:14 --> Language Class Initialized
INFO - 2020-11-11 02:05:14 --> Config Class Initialized
INFO - 2020-11-11 02:05:14 --> Loader Class Initialized
INFO - 2020-11-11 02:05:14 --> Helper loaded: url_helper
INFO - 2020-11-11 02:05:14 --> Helper loaded: file_helper
INFO - 2020-11-11 02:05:14 --> Helper loaded: form_helper
INFO - 2020-11-11 02:05:14 --> Helper loaded: my_helper
INFO - 2020-11-11 02:05:14 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:05:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:05:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:05:14 --> Controller Class Initialized
INFO - 2020-11-11 02:05:14 --> Final output sent to browser
DEBUG - 2020-11-11 02:05:14 --> Total execution time: 0.2178
INFO - 2020-11-11 02:06:18 --> Config Class Initialized
INFO - 2020-11-11 02:06:18 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:06:18 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:06:18 --> Utf8 Class Initialized
INFO - 2020-11-11 02:06:18 --> URI Class Initialized
INFO - 2020-11-11 02:06:18 --> Router Class Initialized
INFO - 2020-11-11 02:06:18 --> Output Class Initialized
INFO - 2020-11-11 02:06:18 --> Security Class Initialized
DEBUG - 2020-11-11 02:06:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:06:18 --> Input Class Initialized
INFO - 2020-11-11 02:06:18 --> Language Class Initialized
INFO - 2020-11-11 02:06:18 --> Language Class Initialized
INFO - 2020-11-11 02:06:18 --> Config Class Initialized
INFO - 2020-11-11 02:06:18 --> Loader Class Initialized
INFO - 2020-11-11 02:06:18 --> Helper loaded: url_helper
INFO - 2020-11-11 02:06:18 --> Helper loaded: file_helper
INFO - 2020-11-11 02:06:18 --> Helper loaded: form_helper
INFO - 2020-11-11 02:06:18 --> Helper loaded: my_helper
INFO - 2020-11-11 02:06:18 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:06:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:06:19 --> Controller Class Initialized
INFO - 2020-11-11 02:06:19 --> Helper loaded: cookie_helper
INFO - 2020-11-11 02:06:19 --> Config Class Initialized
INFO - 2020-11-11 02:06:19 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:06:19 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:06:19 --> Utf8 Class Initialized
INFO - 2020-11-11 02:06:19 --> URI Class Initialized
INFO - 2020-11-11 02:06:19 --> Router Class Initialized
INFO - 2020-11-11 02:06:19 --> Output Class Initialized
INFO - 2020-11-11 02:06:19 --> Security Class Initialized
DEBUG - 2020-11-11 02:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:06:19 --> Input Class Initialized
INFO - 2020-11-11 02:06:19 --> Language Class Initialized
INFO - 2020-11-11 02:06:19 --> Language Class Initialized
INFO - 2020-11-11 02:06:19 --> Config Class Initialized
INFO - 2020-11-11 02:06:19 --> Loader Class Initialized
INFO - 2020-11-11 02:06:19 --> Helper loaded: url_helper
INFO - 2020-11-11 02:06:19 --> Helper loaded: file_helper
INFO - 2020-11-11 02:06:19 --> Helper loaded: form_helper
INFO - 2020-11-11 02:06:19 --> Helper loaded: my_helper
INFO - 2020-11-11 02:06:19 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:06:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:06:19 --> Controller Class Initialized
DEBUG - 2020-11-11 02:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 02:06:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:06:19 --> Final output sent to browser
DEBUG - 2020-11-11 02:06:19 --> Total execution time: 0.2396
INFO - 2020-11-11 02:06:26 --> Config Class Initialized
INFO - 2020-11-11 02:06:26 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:06:26 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:06:26 --> Utf8 Class Initialized
INFO - 2020-11-11 02:06:26 --> URI Class Initialized
INFO - 2020-11-11 02:06:26 --> Router Class Initialized
INFO - 2020-11-11 02:06:26 --> Output Class Initialized
INFO - 2020-11-11 02:06:26 --> Security Class Initialized
DEBUG - 2020-11-11 02:06:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:06:26 --> Input Class Initialized
INFO - 2020-11-11 02:06:26 --> Language Class Initialized
INFO - 2020-11-11 02:06:26 --> Language Class Initialized
INFO - 2020-11-11 02:06:26 --> Config Class Initialized
INFO - 2020-11-11 02:06:26 --> Loader Class Initialized
INFO - 2020-11-11 02:06:26 --> Helper loaded: url_helper
INFO - 2020-11-11 02:06:26 --> Helper loaded: file_helper
INFO - 2020-11-11 02:06:26 --> Helper loaded: form_helper
INFO - 2020-11-11 02:06:26 --> Helper loaded: my_helper
INFO - 2020-11-11 02:06:26 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:06:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:06:26 --> Controller Class Initialized
DEBUG - 2020-11-11 02:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-11-11 02:06:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:06:26 --> Final output sent to browser
DEBUG - 2020-11-11 02:06:26 --> Total execution time: 0.3220
INFO - 2020-11-11 02:06:31 --> Config Class Initialized
INFO - 2020-11-11 02:06:31 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:06:31 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:06:31 --> Utf8 Class Initialized
INFO - 2020-11-11 02:06:31 --> URI Class Initialized
INFO - 2020-11-11 02:06:31 --> Router Class Initialized
INFO - 2020-11-11 02:06:31 --> Output Class Initialized
INFO - 2020-11-11 02:06:31 --> Security Class Initialized
DEBUG - 2020-11-11 02:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:06:31 --> Input Class Initialized
INFO - 2020-11-11 02:06:31 --> Language Class Initialized
INFO - 2020-11-11 02:06:31 --> Language Class Initialized
INFO - 2020-11-11 02:06:31 --> Config Class Initialized
INFO - 2020-11-11 02:06:31 --> Loader Class Initialized
INFO - 2020-11-11 02:06:31 --> Helper loaded: url_helper
INFO - 2020-11-11 02:06:31 --> Helper loaded: file_helper
INFO - 2020-11-11 02:06:31 --> Helper loaded: form_helper
INFO - 2020-11-11 02:06:31 --> Helper loaded: my_helper
INFO - 2020-11-11 02:06:31 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:06:31 --> Controller Class Initialized
INFO - 2020-11-11 02:06:31 --> Helper loaded: cookie_helper
INFO - 2020-11-11 02:06:31 --> Config Class Initialized
INFO - 2020-11-11 02:06:31 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:06:31 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:06:31 --> Utf8 Class Initialized
INFO - 2020-11-11 02:06:31 --> URI Class Initialized
INFO - 2020-11-11 02:06:31 --> Router Class Initialized
INFO - 2020-11-11 02:06:31 --> Output Class Initialized
INFO - 2020-11-11 02:06:31 --> Security Class Initialized
DEBUG - 2020-11-11 02:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:06:31 --> Input Class Initialized
INFO - 2020-11-11 02:06:31 --> Language Class Initialized
INFO - 2020-11-11 02:06:31 --> Language Class Initialized
INFO - 2020-11-11 02:06:31 --> Config Class Initialized
INFO - 2020-11-11 02:06:31 --> Loader Class Initialized
INFO - 2020-11-11 02:06:31 --> Helper loaded: url_helper
INFO - 2020-11-11 02:06:31 --> Helper loaded: file_helper
INFO - 2020-11-11 02:06:31 --> Helper loaded: form_helper
INFO - 2020-11-11 02:06:31 --> Helper loaded: my_helper
INFO - 2020-11-11 02:06:31 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:06:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:06:31 --> Controller Class Initialized
DEBUG - 2020-11-11 02:06:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 02:06:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:06:31 --> Final output sent to browser
DEBUG - 2020-11-11 02:06:31 --> Total execution time: 0.2469
INFO - 2020-11-11 02:07:03 --> Config Class Initialized
INFO - 2020-11-11 02:07:03 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:07:03 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:07:03 --> Utf8 Class Initialized
INFO - 2020-11-11 02:07:03 --> URI Class Initialized
DEBUG - 2020-11-11 02:07:03 --> No URI present. Default controller set.
INFO - 2020-11-11 02:07:03 --> Router Class Initialized
INFO - 2020-11-11 02:07:03 --> Output Class Initialized
INFO - 2020-11-11 02:07:03 --> Security Class Initialized
DEBUG - 2020-11-11 02:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:07:03 --> Input Class Initialized
INFO - 2020-11-11 02:07:03 --> Language Class Initialized
INFO - 2020-11-11 02:07:03 --> Language Class Initialized
INFO - 2020-11-11 02:07:03 --> Config Class Initialized
INFO - 2020-11-11 02:07:03 --> Loader Class Initialized
INFO - 2020-11-11 02:07:03 --> Helper loaded: url_helper
INFO - 2020-11-11 02:07:03 --> Helper loaded: file_helper
INFO - 2020-11-11 02:07:03 --> Helper loaded: form_helper
INFO - 2020-11-11 02:07:03 --> Helper loaded: my_helper
INFO - 2020-11-11 02:07:03 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:07:03 --> Controller Class Initialized
INFO - 2020-11-11 02:07:03 --> Config Class Initialized
INFO - 2020-11-11 02:07:03 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:07:03 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:07:03 --> Utf8 Class Initialized
INFO - 2020-11-11 02:07:03 --> URI Class Initialized
INFO - 2020-11-11 02:07:03 --> Router Class Initialized
INFO - 2020-11-11 02:07:03 --> Output Class Initialized
INFO - 2020-11-11 02:07:03 --> Security Class Initialized
DEBUG - 2020-11-11 02:07:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:07:03 --> Input Class Initialized
INFO - 2020-11-11 02:07:03 --> Language Class Initialized
INFO - 2020-11-11 02:07:03 --> Language Class Initialized
INFO - 2020-11-11 02:07:03 --> Config Class Initialized
INFO - 2020-11-11 02:07:03 --> Loader Class Initialized
INFO - 2020-11-11 02:07:03 --> Helper loaded: url_helper
INFO - 2020-11-11 02:07:03 --> Helper loaded: file_helper
INFO - 2020-11-11 02:07:03 --> Helper loaded: form_helper
INFO - 2020-11-11 02:07:03 --> Helper loaded: my_helper
INFO - 2020-11-11 02:07:03 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:07:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:07:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:07:03 --> Controller Class Initialized
DEBUG - 2020-11-11 02:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 02:07:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:07:03 --> Final output sent to browser
DEBUG - 2020-11-11 02:07:03 --> Total execution time: 0.2572
INFO - 2020-11-11 02:26:27 --> Config Class Initialized
INFO - 2020-11-11 02:26:27 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:26:27 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:26:27 --> Utf8 Class Initialized
INFO - 2020-11-11 02:26:27 --> URI Class Initialized
INFO - 2020-11-11 02:26:27 --> Router Class Initialized
INFO - 2020-11-11 02:26:27 --> Output Class Initialized
INFO - 2020-11-11 02:26:27 --> Security Class Initialized
DEBUG - 2020-11-11 02:26:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:26:27 --> Input Class Initialized
INFO - 2020-11-11 02:26:27 --> Language Class Initialized
INFO - 2020-11-11 02:26:27 --> Language Class Initialized
INFO - 2020-11-11 02:26:27 --> Config Class Initialized
INFO - 2020-11-11 02:26:27 --> Loader Class Initialized
INFO - 2020-11-11 02:26:27 --> Helper loaded: url_helper
INFO - 2020-11-11 02:26:27 --> Helper loaded: file_helper
INFO - 2020-11-11 02:26:27 --> Helper loaded: form_helper
INFO - 2020-11-11 02:26:27 --> Helper loaded: my_helper
INFO - 2020-11-11 02:26:27 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:26:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:26:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:26:27 --> Controller Class Initialized
INFO - 2020-11-11 02:26:27 --> Helper loaded: cookie_helper
INFO - 2020-11-11 02:26:27 --> Final output sent to browser
DEBUG - 2020-11-11 02:26:27 --> Total execution time: 0.3449
INFO - 2020-11-11 02:26:28 --> Config Class Initialized
INFO - 2020-11-11 02:26:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:26:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:26:28 --> Utf8 Class Initialized
INFO - 2020-11-11 02:26:28 --> URI Class Initialized
INFO - 2020-11-11 02:26:28 --> Router Class Initialized
INFO - 2020-11-11 02:26:28 --> Output Class Initialized
INFO - 2020-11-11 02:26:28 --> Security Class Initialized
DEBUG - 2020-11-11 02:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:26:28 --> Input Class Initialized
INFO - 2020-11-11 02:26:28 --> Language Class Initialized
INFO - 2020-11-11 02:26:28 --> Language Class Initialized
INFO - 2020-11-11 02:26:28 --> Config Class Initialized
INFO - 2020-11-11 02:26:28 --> Loader Class Initialized
INFO - 2020-11-11 02:26:28 --> Helper loaded: url_helper
INFO - 2020-11-11 02:26:28 --> Helper loaded: file_helper
INFO - 2020-11-11 02:26:28 --> Helper loaded: form_helper
INFO - 2020-11-11 02:26:28 --> Helper loaded: my_helper
INFO - 2020-11-11 02:26:28 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:26:28 --> Controller Class Initialized
DEBUG - 2020-11-11 02:26:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 02:26:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:26:28 --> Final output sent to browser
DEBUG - 2020-11-11 02:26:28 --> Total execution time: 0.4045
INFO - 2020-11-11 02:26:33 --> Config Class Initialized
INFO - 2020-11-11 02:26:33 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:26:33 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:26:33 --> Utf8 Class Initialized
INFO - 2020-11-11 02:26:33 --> URI Class Initialized
INFO - 2020-11-11 02:26:33 --> Router Class Initialized
INFO - 2020-11-11 02:26:33 --> Output Class Initialized
INFO - 2020-11-11 02:26:34 --> Security Class Initialized
DEBUG - 2020-11-11 02:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:26:34 --> Input Class Initialized
INFO - 2020-11-11 02:26:34 --> Language Class Initialized
INFO - 2020-11-11 02:26:34 --> Language Class Initialized
INFO - 2020-11-11 02:26:34 --> Config Class Initialized
INFO - 2020-11-11 02:26:34 --> Loader Class Initialized
INFO - 2020-11-11 02:26:34 --> Helper loaded: url_helper
INFO - 2020-11-11 02:26:34 --> Helper loaded: file_helper
INFO - 2020-11-11 02:26:34 --> Helper loaded: form_helper
INFO - 2020-11-11 02:26:34 --> Helper loaded: my_helper
INFO - 2020-11-11 02:26:34 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:26:34 --> Controller Class Initialized
DEBUG - 2020-11-11 02:26:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-11 02:26:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:26:34 --> Final output sent to browser
DEBUG - 2020-11-11 02:26:34 --> Total execution time: 0.3234
INFO - 2020-11-11 02:26:44 --> Config Class Initialized
INFO - 2020-11-11 02:26:44 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:26:44 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:26:45 --> Utf8 Class Initialized
INFO - 2020-11-11 02:26:45 --> URI Class Initialized
INFO - 2020-11-11 02:26:45 --> Router Class Initialized
INFO - 2020-11-11 02:26:45 --> Output Class Initialized
INFO - 2020-11-11 02:26:45 --> Security Class Initialized
DEBUG - 2020-11-11 02:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:26:45 --> Input Class Initialized
INFO - 2020-11-11 02:26:45 --> Language Class Initialized
INFO - 2020-11-11 02:26:45 --> Language Class Initialized
INFO - 2020-11-11 02:26:45 --> Config Class Initialized
INFO - 2020-11-11 02:26:45 --> Loader Class Initialized
INFO - 2020-11-11 02:26:45 --> Helper loaded: url_helper
INFO - 2020-11-11 02:26:45 --> Helper loaded: file_helper
INFO - 2020-11-11 02:26:45 --> Helper loaded: form_helper
INFO - 2020-11-11 02:26:45 --> Helper loaded: my_helper
INFO - 2020-11-11 02:26:45 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:26:45 --> Controller Class Initialized
INFO - 2020-11-11 02:26:45 --> Final output sent to browser
DEBUG - 2020-11-11 02:26:45 --> Total execution time: 0.2204
INFO - 2020-11-11 02:29:08 --> Config Class Initialized
INFO - 2020-11-11 02:29:08 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:29:08 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:29:08 --> Utf8 Class Initialized
INFO - 2020-11-11 02:29:08 --> URI Class Initialized
INFO - 2020-11-11 02:29:08 --> Router Class Initialized
INFO - 2020-11-11 02:29:08 --> Output Class Initialized
INFO - 2020-11-11 02:29:08 --> Security Class Initialized
DEBUG - 2020-11-11 02:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:29:08 --> Input Class Initialized
INFO - 2020-11-11 02:29:08 --> Language Class Initialized
INFO - 2020-11-11 02:29:08 --> Language Class Initialized
INFO - 2020-11-11 02:29:08 --> Config Class Initialized
INFO - 2020-11-11 02:29:08 --> Loader Class Initialized
INFO - 2020-11-11 02:29:08 --> Helper loaded: url_helper
INFO - 2020-11-11 02:29:08 --> Helper loaded: file_helper
INFO - 2020-11-11 02:29:08 --> Helper loaded: form_helper
INFO - 2020-11-11 02:29:08 --> Helper loaded: my_helper
INFO - 2020-11-11 02:29:08 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:29:08 --> Controller Class Initialized
ERROR - 2020-11-11 02:29:08 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '10', '1418', 'B', 'Cukup memuaskan, aktif mengikuti kegiatan Pramuka mingguan')
INFO - 2020-11-11 02:29:09 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-11 02:33:46 --> Config Class Initialized
INFO - 2020-11-11 02:33:46 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:46 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:46 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:46 --> URI Class Initialized
INFO - 2020-11-11 02:33:46 --> Router Class Initialized
INFO - 2020-11-11 02:33:46 --> Output Class Initialized
INFO - 2020-11-11 02:33:46 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:46 --> Input Class Initialized
INFO - 2020-11-11 02:33:46 --> Language Class Initialized
INFO - 2020-11-11 02:33:46 --> Language Class Initialized
INFO - 2020-11-11 02:33:46 --> Config Class Initialized
INFO - 2020-11-11 02:33:46 --> Loader Class Initialized
INFO - 2020-11-11 02:33:46 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:46 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:46 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:46 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:46 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:46 --> Controller Class Initialized
INFO - 2020-11-11 02:33:46 --> Helper loaded: cookie_helper
INFO - 2020-11-11 02:33:46 --> Config Class Initialized
INFO - 2020-11-11 02:33:46 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:46 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:46 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:46 --> URI Class Initialized
INFO - 2020-11-11 02:33:46 --> Router Class Initialized
INFO - 2020-11-11 02:33:46 --> Output Class Initialized
INFO - 2020-11-11 02:33:46 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:46 --> Input Class Initialized
INFO - 2020-11-11 02:33:46 --> Language Class Initialized
INFO - 2020-11-11 02:33:46 --> Language Class Initialized
INFO - 2020-11-11 02:33:46 --> Config Class Initialized
INFO - 2020-11-11 02:33:46 --> Loader Class Initialized
INFO - 2020-11-11 02:33:46 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:46 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:46 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:46 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:46 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:46 --> Controller Class Initialized
DEBUG - 2020-11-11 02:33:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 02:33:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:33:46 --> Final output sent to browser
DEBUG - 2020-11-11 02:33:46 --> Total execution time: 0.3007
INFO - 2020-11-11 02:33:52 --> Config Class Initialized
INFO - 2020-11-11 02:33:52 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:52 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:52 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:52 --> URI Class Initialized
INFO - 2020-11-11 02:33:52 --> Router Class Initialized
INFO - 2020-11-11 02:33:52 --> Output Class Initialized
INFO - 2020-11-11 02:33:52 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:52 --> Input Class Initialized
INFO - 2020-11-11 02:33:52 --> Language Class Initialized
INFO - 2020-11-11 02:33:52 --> Language Class Initialized
INFO - 2020-11-11 02:33:52 --> Config Class Initialized
INFO - 2020-11-11 02:33:52 --> Loader Class Initialized
INFO - 2020-11-11 02:33:52 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:52 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:52 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:52 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:52 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:52 --> Controller Class Initialized
INFO - 2020-11-11 02:33:52 --> Helper loaded: cookie_helper
INFO - 2020-11-11 02:33:52 --> Final output sent to browser
DEBUG - 2020-11-11 02:33:52 --> Total execution time: 0.3368
INFO - 2020-11-11 02:33:53 --> Config Class Initialized
INFO - 2020-11-11 02:33:53 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:53 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:53 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:53 --> URI Class Initialized
INFO - 2020-11-11 02:33:53 --> Router Class Initialized
INFO - 2020-11-11 02:33:53 --> Output Class Initialized
INFO - 2020-11-11 02:33:53 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:53 --> Input Class Initialized
INFO - 2020-11-11 02:33:53 --> Language Class Initialized
INFO - 2020-11-11 02:33:53 --> Language Class Initialized
INFO - 2020-11-11 02:33:53 --> Config Class Initialized
INFO - 2020-11-11 02:33:53 --> Loader Class Initialized
INFO - 2020-11-11 02:33:53 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:53 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:53 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:53 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:53 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:53 --> Controller Class Initialized
DEBUG - 2020-11-11 02:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 02:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:33:53 --> Final output sent to browser
DEBUG - 2020-11-11 02:33:53 --> Total execution time: 0.4244
INFO - 2020-11-11 02:33:55 --> Config Class Initialized
INFO - 2020-11-11 02:33:55 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:55 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:55 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:55 --> URI Class Initialized
INFO - 2020-11-11 02:33:55 --> Router Class Initialized
INFO - 2020-11-11 02:33:55 --> Output Class Initialized
INFO - 2020-11-11 02:33:55 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:55 --> Input Class Initialized
INFO - 2020-11-11 02:33:55 --> Language Class Initialized
INFO - 2020-11-11 02:33:55 --> Language Class Initialized
INFO - 2020-11-11 02:33:55 --> Config Class Initialized
INFO - 2020-11-11 02:33:55 --> Loader Class Initialized
INFO - 2020-11-11 02:33:55 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:55 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:55 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:55 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:55 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:55 --> Controller Class Initialized
DEBUG - 2020-11-11 02:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-11 02:33:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:33:55 --> Final output sent to browser
DEBUG - 2020-11-11 02:33:55 --> Total execution time: 0.3105
INFO - 2020-11-11 02:33:55 --> Config Class Initialized
INFO - 2020-11-11 02:33:55 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:55 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:55 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:55 --> URI Class Initialized
INFO - 2020-11-11 02:33:55 --> Router Class Initialized
INFO - 2020-11-11 02:33:55 --> Output Class Initialized
INFO - 2020-11-11 02:33:55 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:55 --> Input Class Initialized
INFO - 2020-11-11 02:33:55 --> Language Class Initialized
INFO - 2020-11-11 02:33:55 --> Language Class Initialized
INFO - 2020-11-11 02:33:55 --> Config Class Initialized
INFO - 2020-11-11 02:33:55 --> Loader Class Initialized
INFO - 2020-11-11 02:33:55 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:55 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:55 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:55 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:55 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:55 --> Controller Class Initialized
INFO - 2020-11-11 02:33:57 --> Config Class Initialized
INFO - 2020-11-11 02:33:57 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:57 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:57 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:57 --> URI Class Initialized
INFO - 2020-11-11 02:33:57 --> Router Class Initialized
INFO - 2020-11-11 02:33:57 --> Output Class Initialized
INFO - 2020-11-11 02:33:57 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:57 --> Input Class Initialized
INFO - 2020-11-11 02:33:57 --> Language Class Initialized
INFO - 2020-11-11 02:33:57 --> Language Class Initialized
INFO - 2020-11-11 02:33:57 --> Config Class Initialized
INFO - 2020-11-11 02:33:57 --> Loader Class Initialized
INFO - 2020-11-11 02:33:57 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:57 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:57 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:57 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:57 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:57 --> Controller Class Initialized
INFO - 2020-11-11 02:33:58 --> Config Class Initialized
INFO - 2020-11-11 02:33:58 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:33:58 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:33:58 --> Utf8 Class Initialized
INFO - 2020-11-11 02:33:58 --> URI Class Initialized
INFO - 2020-11-11 02:33:58 --> Router Class Initialized
INFO - 2020-11-11 02:33:58 --> Output Class Initialized
INFO - 2020-11-11 02:33:58 --> Security Class Initialized
DEBUG - 2020-11-11 02:33:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:33:58 --> Input Class Initialized
INFO - 2020-11-11 02:33:58 --> Language Class Initialized
INFO - 2020-11-11 02:33:58 --> Language Class Initialized
INFO - 2020-11-11 02:33:58 --> Config Class Initialized
INFO - 2020-11-11 02:33:58 --> Loader Class Initialized
INFO - 2020-11-11 02:33:58 --> Helper loaded: url_helper
INFO - 2020-11-11 02:33:58 --> Helper loaded: file_helper
INFO - 2020-11-11 02:33:58 --> Helper loaded: form_helper
INFO - 2020-11-11 02:33:58 --> Helper loaded: my_helper
INFO - 2020-11-11 02:33:58 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:33:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:33:58 --> Controller Class Initialized
INFO - 2020-11-11 02:34:00 --> Config Class Initialized
INFO - 2020-11-11 02:34:00 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:00 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:00 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:00 --> URI Class Initialized
INFO - 2020-11-11 02:34:00 --> Router Class Initialized
INFO - 2020-11-11 02:34:00 --> Output Class Initialized
INFO - 2020-11-11 02:34:00 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:00 --> Input Class Initialized
INFO - 2020-11-11 02:34:00 --> Language Class Initialized
INFO - 2020-11-11 02:34:00 --> Language Class Initialized
INFO - 2020-11-11 02:34:00 --> Config Class Initialized
INFO - 2020-11-11 02:34:00 --> Loader Class Initialized
INFO - 2020-11-11 02:34:00 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:00 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:00 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:00 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:00 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:00 --> Controller Class Initialized
INFO - 2020-11-11 02:34:00 --> Config Class Initialized
INFO - 2020-11-11 02:34:00 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:00 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:00 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:00 --> URI Class Initialized
INFO - 2020-11-11 02:34:00 --> Router Class Initialized
INFO - 2020-11-11 02:34:00 --> Output Class Initialized
INFO - 2020-11-11 02:34:00 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:00 --> Input Class Initialized
INFO - 2020-11-11 02:34:00 --> Language Class Initialized
INFO - 2020-11-11 02:34:00 --> Language Class Initialized
INFO - 2020-11-11 02:34:00 --> Config Class Initialized
INFO - 2020-11-11 02:34:00 --> Loader Class Initialized
INFO - 2020-11-11 02:34:00 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:00 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:00 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:00 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:00 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:01 --> Controller Class Initialized
INFO - 2020-11-11 02:34:01 --> Config Class Initialized
INFO - 2020-11-11 02:34:01 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:01 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:01 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:01 --> URI Class Initialized
INFO - 2020-11-11 02:34:01 --> Router Class Initialized
INFO - 2020-11-11 02:34:01 --> Output Class Initialized
INFO - 2020-11-11 02:34:01 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:01 --> Input Class Initialized
INFO - 2020-11-11 02:34:01 --> Language Class Initialized
INFO - 2020-11-11 02:34:01 --> Language Class Initialized
INFO - 2020-11-11 02:34:01 --> Config Class Initialized
INFO - 2020-11-11 02:34:01 --> Loader Class Initialized
INFO - 2020-11-11 02:34:01 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:01 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:01 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:01 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:01 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:01 --> Controller Class Initialized
INFO - 2020-11-11 02:34:19 --> Config Class Initialized
INFO - 2020-11-11 02:34:19 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:19 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:19 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:19 --> URI Class Initialized
INFO - 2020-11-11 02:34:19 --> Router Class Initialized
INFO - 2020-11-11 02:34:19 --> Output Class Initialized
INFO - 2020-11-11 02:34:19 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:19 --> Input Class Initialized
INFO - 2020-11-11 02:34:19 --> Language Class Initialized
INFO - 2020-11-11 02:34:20 --> Language Class Initialized
INFO - 2020-11-11 02:34:20 --> Config Class Initialized
INFO - 2020-11-11 02:34:20 --> Loader Class Initialized
INFO - 2020-11-11 02:34:20 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:20 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:20 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:20 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:20 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:20 --> Controller Class Initialized
INFO - 2020-11-11 02:34:20 --> Helper loaded: cookie_helper
INFO - 2020-11-11 02:34:20 --> Config Class Initialized
INFO - 2020-11-11 02:34:20 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:20 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:20 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:20 --> URI Class Initialized
INFO - 2020-11-11 02:34:20 --> Router Class Initialized
INFO - 2020-11-11 02:34:20 --> Output Class Initialized
INFO - 2020-11-11 02:34:20 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:20 --> Input Class Initialized
INFO - 2020-11-11 02:34:20 --> Language Class Initialized
INFO - 2020-11-11 02:34:20 --> Language Class Initialized
INFO - 2020-11-11 02:34:20 --> Config Class Initialized
INFO - 2020-11-11 02:34:20 --> Loader Class Initialized
INFO - 2020-11-11 02:34:20 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:20 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:20 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:20 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:20 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:20 --> Controller Class Initialized
DEBUG - 2020-11-11 02:34:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 02:34:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:34:20 --> Final output sent to browser
DEBUG - 2020-11-11 02:34:20 --> Total execution time: 0.2903
INFO - 2020-11-11 02:34:31 --> Config Class Initialized
INFO - 2020-11-11 02:34:31 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:31 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:31 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:31 --> URI Class Initialized
INFO - 2020-11-11 02:34:31 --> Router Class Initialized
INFO - 2020-11-11 02:34:31 --> Output Class Initialized
INFO - 2020-11-11 02:34:31 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:31 --> Input Class Initialized
INFO - 2020-11-11 02:34:31 --> Language Class Initialized
INFO - 2020-11-11 02:34:31 --> Language Class Initialized
INFO - 2020-11-11 02:34:31 --> Config Class Initialized
INFO - 2020-11-11 02:34:31 --> Loader Class Initialized
INFO - 2020-11-11 02:34:31 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:31 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:31 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:31 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:31 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:31 --> Controller Class Initialized
INFO - 2020-11-11 02:34:31 --> Helper loaded: cookie_helper
INFO - 2020-11-11 02:34:31 --> Final output sent to browser
DEBUG - 2020-11-11 02:34:31 --> Total execution time: 0.3559
INFO - 2020-11-11 02:34:32 --> Config Class Initialized
INFO - 2020-11-11 02:34:32 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:32 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:32 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:32 --> URI Class Initialized
INFO - 2020-11-11 02:34:32 --> Router Class Initialized
INFO - 2020-11-11 02:34:32 --> Output Class Initialized
INFO - 2020-11-11 02:34:32 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:32 --> Input Class Initialized
INFO - 2020-11-11 02:34:32 --> Language Class Initialized
INFO - 2020-11-11 02:34:32 --> Language Class Initialized
INFO - 2020-11-11 02:34:32 --> Config Class Initialized
INFO - 2020-11-11 02:34:32 --> Loader Class Initialized
INFO - 2020-11-11 02:34:32 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:32 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:32 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:32 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:32 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:32 --> Controller Class Initialized
DEBUG - 2020-11-11 02:34:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 02:34:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:34:32 --> Final output sent to browser
DEBUG - 2020-11-11 02:34:32 --> Total execution time: 0.3949
INFO - 2020-11-11 02:34:34 --> Config Class Initialized
INFO - 2020-11-11 02:34:34 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:34 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:34 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:34 --> URI Class Initialized
INFO - 2020-11-11 02:34:34 --> Router Class Initialized
INFO - 2020-11-11 02:34:34 --> Output Class Initialized
INFO - 2020-11-11 02:34:34 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:34 --> Input Class Initialized
INFO - 2020-11-11 02:34:34 --> Language Class Initialized
INFO - 2020-11-11 02:34:34 --> Language Class Initialized
INFO - 2020-11-11 02:34:34 --> Config Class Initialized
INFO - 2020-11-11 02:34:34 --> Loader Class Initialized
INFO - 2020-11-11 02:34:34 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:34 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:34 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:34 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:34 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:34 --> Controller Class Initialized
DEBUG - 2020-11-11 02:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-11 02:34:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:34:34 --> Final output sent to browser
DEBUG - 2020-11-11 02:34:34 --> Total execution time: 0.2663
INFO - 2020-11-11 02:34:36 --> Config Class Initialized
INFO - 2020-11-11 02:34:36 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:34:36 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:34:36 --> Utf8 Class Initialized
INFO - 2020-11-11 02:34:36 --> URI Class Initialized
INFO - 2020-11-11 02:34:36 --> Router Class Initialized
INFO - 2020-11-11 02:34:36 --> Output Class Initialized
INFO - 2020-11-11 02:34:36 --> Security Class Initialized
DEBUG - 2020-11-11 02:34:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:34:36 --> Input Class Initialized
INFO - 2020-11-11 02:34:36 --> Language Class Initialized
INFO - 2020-11-11 02:34:36 --> Language Class Initialized
INFO - 2020-11-11 02:34:36 --> Config Class Initialized
INFO - 2020-11-11 02:34:36 --> Loader Class Initialized
INFO - 2020-11-11 02:34:36 --> Helper loaded: url_helper
INFO - 2020-11-11 02:34:36 --> Helper loaded: file_helper
INFO - 2020-11-11 02:34:36 --> Helper loaded: form_helper
INFO - 2020-11-11 02:34:36 --> Helper loaded: my_helper
INFO - 2020-11-11 02:34:36 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:34:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:34:36 --> Controller Class Initialized
INFO - 2020-11-11 02:34:37 --> Final output sent to browser
DEBUG - 2020-11-11 02:34:37 --> Total execution time: 0.2332
INFO - 2020-11-11 02:39:14 --> Config Class Initialized
INFO - 2020-11-11 02:39:14 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:39:14 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:39:14 --> Utf8 Class Initialized
INFO - 2020-11-11 02:39:14 --> URI Class Initialized
INFO - 2020-11-11 02:39:14 --> Router Class Initialized
INFO - 2020-11-11 02:39:14 --> Output Class Initialized
INFO - 2020-11-11 02:39:14 --> Security Class Initialized
DEBUG - 2020-11-11 02:39:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:39:14 --> Input Class Initialized
INFO - 2020-11-11 02:39:14 --> Language Class Initialized
INFO - 2020-11-11 02:39:14 --> Language Class Initialized
INFO - 2020-11-11 02:39:14 --> Config Class Initialized
INFO - 2020-11-11 02:39:14 --> Loader Class Initialized
INFO - 2020-11-11 02:39:14 --> Helper loaded: url_helper
INFO - 2020-11-11 02:39:14 --> Helper loaded: file_helper
INFO - 2020-11-11 02:39:14 --> Helper loaded: form_helper
INFO - 2020-11-11 02:39:14 --> Helper loaded: my_helper
INFO - 2020-11-11 02:39:14 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:39:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:39:14 --> Controller Class Initialized
DEBUG - 2020-11-11 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-11 02:39:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:39:14 --> Final output sent to browser
DEBUG - 2020-11-11 02:39:14 --> Total execution time: 0.2689
INFO - 2020-11-11 02:39:17 --> Config Class Initialized
INFO - 2020-11-11 02:39:17 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:39:17 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:39:17 --> Utf8 Class Initialized
INFO - 2020-11-11 02:39:17 --> URI Class Initialized
INFO - 2020-11-11 02:39:17 --> Router Class Initialized
INFO - 2020-11-11 02:39:17 --> Output Class Initialized
INFO - 2020-11-11 02:39:17 --> Security Class Initialized
DEBUG - 2020-11-11 02:39:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:39:17 --> Input Class Initialized
INFO - 2020-11-11 02:39:17 --> Language Class Initialized
INFO - 2020-11-11 02:39:17 --> Language Class Initialized
INFO - 2020-11-11 02:39:17 --> Config Class Initialized
INFO - 2020-11-11 02:39:17 --> Loader Class Initialized
INFO - 2020-11-11 02:39:17 --> Helper loaded: url_helper
INFO - 2020-11-11 02:39:17 --> Helper loaded: file_helper
INFO - 2020-11-11 02:39:17 --> Helper loaded: form_helper
INFO - 2020-11-11 02:39:17 --> Helper loaded: my_helper
INFO - 2020-11-11 02:39:17 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:39:17 --> Controller Class Initialized
INFO - 2020-11-11 02:39:17 --> Final output sent to browser
DEBUG - 2020-11-11 02:39:17 --> Total execution time: 0.2180
INFO - 2020-11-11 02:39:28 --> Config Class Initialized
INFO - 2020-11-11 02:39:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:39:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:39:28 --> Utf8 Class Initialized
INFO - 2020-11-11 02:39:28 --> URI Class Initialized
INFO - 2020-11-11 02:39:28 --> Router Class Initialized
INFO - 2020-11-11 02:39:28 --> Output Class Initialized
INFO - 2020-11-11 02:39:28 --> Security Class Initialized
DEBUG - 2020-11-11 02:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:39:28 --> Input Class Initialized
INFO - 2020-11-11 02:39:28 --> Language Class Initialized
INFO - 2020-11-11 02:39:28 --> Language Class Initialized
INFO - 2020-11-11 02:39:28 --> Config Class Initialized
INFO - 2020-11-11 02:39:28 --> Loader Class Initialized
INFO - 2020-11-11 02:39:28 --> Helper loaded: url_helper
INFO - 2020-11-11 02:39:28 --> Helper loaded: file_helper
INFO - 2020-11-11 02:39:28 --> Helper loaded: form_helper
INFO - 2020-11-11 02:39:28 --> Helper loaded: my_helper
INFO - 2020-11-11 02:39:28 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:39:28 --> Controller Class Initialized
ERROR - 2020-11-11 02:39:28 --> Query error: Cannot add or update a child row: a foreign key constraint fails (`db_nilai`.`t_nilai_ekstra`, CONSTRAINT `FK_t_nilai_ekstra_m_siswa` FOREIGN KEY (`id_siswa`) REFERENCES `m_siswaaa` (`id`)) - Invalid query: INSERT INTO t_nilai_ekstra (tasm, id_ekstra, id_siswa, nilai, desk) VALUES ('20201', '10', '1418', 'B', 'Cukup memuaskan, aktif mengikuti kegiatan Pramuka mingguan')
INFO - 2020-11-11 02:39:28 --> Language file loaded: language/english/db_lang.php
INFO - 2020-11-11 02:39:36 --> Config Class Initialized
INFO - 2020-11-11 02:39:36 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:39:36 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:39:36 --> Utf8 Class Initialized
INFO - 2020-11-11 02:39:36 --> URI Class Initialized
INFO - 2020-11-11 02:39:36 --> Router Class Initialized
INFO - 2020-11-11 02:39:36 --> Output Class Initialized
INFO - 2020-11-11 02:39:36 --> Security Class Initialized
DEBUG - 2020-11-11 02:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:39:36 --> Input Class Initialized
INFO - 2020-11-11 02:39:36 --> Language Class Initialized
INFO - 2020-11-11 02:39:36 --> Language Class Initialized
INFO - 2020-11-11 02:39:36 --> Config Class Initialized
INFO - 2020-11-11 02:39:36 --> Loader Class Initialized
INFO - 2020-11-11 02:39:36 --> Helper loaded: url_helper
INFO - 2020-11-11 02:39:36 --> Helper loaded: file_helper
INFO - 2020-11-11 02:39:36 --> Helper loaded: form_helper
INFO - 2020-11-11 02:39:36 --> Helper loaded: my_helper
INFO - 2020-11-11 02:39:36 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:39:36 --> Controller Class Initialized
DEBUG - 2020-11-11 02:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-11 02:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:39:36 --> Final output sent to browser
DEBUG - 2020-11-11 02:39:36 --> Total execution time: 0.2894
INFO - 2020-11-11 02:39:39 --> Config Class Initialized
INFO - 2020-11-11 02:39:39 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:39:39 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:39:39 --> Utf8 Class Initialized
INFO - 2020-11-11 02:39:39 --> URI Class Initialized
INFO - 2020-11-11 02:39:39 --> Router Class Initialized
INFO - 2020-11-11 02:39:39 --> Output Class Initialized
INFO - 2020-11-11 02:39:39 --> Security Class Initialized
DEBUG - 2020-11-11 02:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:39:39 --> Input Class Initialized
INFO - 2020-11-11 02:39:39 --> Language Class Initialized
INFO - 2020-11-11 02:39:39 --> Language Class Initialized
INFO - 2020-11-11 02:39:39 --> Config Class Initialized
INFO - 2020-11-11 02:39:39 --> Loader Class Initialized
INFO - 2020-11-11 02:39:39 --> Helper loaded: url_helper
INFO - 2020-11-11 02:39:39 --> Helper loaded: file_helper
INFO - 2020-11-11 02:39:39 --> Helper loaded: form_helper
INFO - 2020-11-11 02:39:39 --> Helper loaded: my_helper
INFO - 2020-11-11 02:39:39 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:39:39 --> Controller Class Initialized
INFO - 2020-11-11 02:39:39 --> Final output sent to browser
DEBUG - 2020-11-11 02:39:39 --> Total execution time: 0.2111
INFO - 2020-11-11 02:54:57 --> Config Class Initialized
INFO - 2020-11-11 02:54:57 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:54:57 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:54:57 --> Utf8 Class Initialized
INFO - 2020-11-11 02:54:57 --> URI Class Initialized
INFO - 2020-11-11 02:54:57 --> Router Class Initialized
INFO - 2020-11-11 02:54:57 --> Output Class Initialized
INFO - 2020-11-11 02:54:57 --> Security Class Initialized
DEBUG - 2020-11-11 02:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:54:57 --> Input Class Initialized
INFO - 2020-11-11 02:54:57 --> Language Class Initialized
INFO - 2020-11-11 02:54:57 --> Language Class Initialized
INFO - 2020-11-11 02:54:57 --> Config Class Initialized
INFO - 2020-11-11 02:54:57 --> Loader Class Initialized
INFO - 2020-11-11 02:54:57 --> Helper loaded: url_helper
INFO - 2020-11-11 02:54:57 --> Helper loaded: file_helper
INFO - 2020-11-11 02:54:57 --> Helper loaded: form_helper
INFO - 2020-11-11 02:54:57 --> Helper loaded: my_helper
INFO - 2020-11-11 02:54:57 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:54:57 --> Controller Class Initialized
DEBUG - 2020-11-11 02:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-11 02:54:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:54:58 --> Final output sent to browser
DEBUG - 2020-11-11 02:54:58 --> Total execution time: 0.3309
INFO - 2020-11-11 02:54:59 --> Config Class Initialized
INFO - 2020-11-11 02:54:59 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:54:59 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:54:59 --> Utf8 Class Initialized
INFO - 2020-11-11 02:54:59 --> URI Class Initialized
INFO - 2020-11-11 02:54:59 --> Router Class Initialized
INFO - 2020-11-11 02:54:59 --> Output Class Initialized
INFO - 2020-11-11 02:54:59 --> Security Class Initialized
DEBUG - 2020-11-11 02:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:54:59 --> Input Class Initialized
INFO - 2020-11-11 02:54:59 --> Language Class Initialized
INFO - 2020-11-11 02:54:59 --> Language Class Initialized
INFO - 2020-11-11 02:54:59 --> Config Class Initialized
INFO - 2020-11-11 02:54:59 --> Loader Class Initialized
INFO - 2020-11-11 02:54:59 --> Helper loaded: url_helper
INFO - 2020-11-11 02:54:59 --> Helper loaded: file_helper
INFO - 2020-11-11 02:54:59 --> Helper loaded: form_helper
INFO - 2020-11-11 02:54:59 --> Helper loaded: my_helper
INFO - 2020-11-11 02:54:59 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:55:00 --> Controller Class Initialized
DEBUG - 2020-11-11 02:55:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-11 02:55:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:55:00 --> Final output sent to browser
DEBUG - 2020-11-11 02:55:00 --> Total execution time: 0.3135
INFO - 2020-11-11 02:55:02 --> Config Class Initialized
INFO - 2020-11-11 02:55:02 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:55:02 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:55:02 --> Utf8 Class Initialized
INFO - 2020-11-11 02:55:02 --> URI Class Initialized
INFO - 2020-11-11 02:55:02 --> Router Class Initialized
INFO - 2020-11-11 02:55:02 --> Output Class Initialized
INFO - 2020-11-11 02:55:02 --> Security Class Initialized
DEBUG - 2020-11-11 02:55:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:55:02 --> Input Class Initialized
INFO - 2020-11-11 02:55:02 --> Language Class Initialized
INFO - 2020-11-11 02:55:02 --> Language Class Initialized
INFO - 2020-11-11 02:55:02 --> Config Class Initialized
INFO - 2020-11-11 02:55:02 --> Loader Class Initialized
INFO - 2020-11-11 02:55:02 --> Helper loaded: url_helper
INFO - 2020-11-11 02:55:02 --> Helper loaded: file_helper
INFO - 2020-11-11 02:55:02 --> Helper loaded: form_helper
INFO - 2020-11-11 02:55:02 --> Helper loaded: my_helper
INFO - 2020-11-11 02:55:02 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:55:02 --> Controller Class Initialized
DEBUG - 2020-11-11 02:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-11 02:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:55:02 --> Final output sent to browser
DEBUG - 2020-11-11 02:55:02 --> Total execution time: 0.2959
INFO - 2020-11-11 02:55:03 --> Config Class Initialized
INFO - 2020-11-11 02:55:03 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:55:03 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:55:03 --> Utf8 Class Initialized
INFO - 2020-11-11 02:55:03 --> URI Class Initialized
INFO - 2020-11-11 02:55:03 --> Router Class Initialized
INFO - 2020-11-11 02:55:03 --> Output Class Initialized
INFO - 2020-11-11 02:55:03 --> Security Class Initialized
DEBUG - 2020-11-11 02:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:55:03 --> Input Class Initialized
INFO - 2020-11-11 02:55:03 --> Language Class Initialized
INFO - 2020-11-11 02:55:03 --> Language Class Initialized
INFO - 2020-11-11 02:55:03 --> Config Class Initialized
INFO - 2020-11-11 02:55:03 --> Loader Class Initialized
INFO - 2020-11-11 02:55:03 --> Helper loaded: url_helper
INFO - 2020-11-11 02:55:03 --> Helper loaded: file_helper
INFO - 2020-11-11 02:55:03 --> Helper loaded: form_helper
INFO - 2020-11-11 02:55:03 --> Helper loaded: my_helper
INFO - 2020-11-11 02:55:03 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:55:03 --> Controller Class Initialized
DEBUG - 2020-11-11 02:55:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-11 02:55:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:55:03 --> Final output sent to browser
DEBUG - 2020-11-11 02:55:03 --> Total execution time: 0.2858
INFO - 2020-11-11 02:55:05 --> Config Class Initialized
INFO - 2020-11-11 02:55:05 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:55:05 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:55:05 --> Utf8 Class Initialized
INFO - 2020-11-11 02:55:05 --> URI Class Initialized
INFO - 2020-11-11 02:55:05 --> Router Class Initialized
INFO - 2020-11-11 02:55:05 --> Output Class Initialized
INFO - 2020-11-11 02:55:05 --> Security Class Initialized
DEBUG - 2020-11-11 02:55:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:55:05 --> Input Class Initialized
INFO - 2020-11-11 02:55:05 --> Language Class Initialized
INFO - 2020-11-11 02:55:05 --> Language Class Initialized
INFO - 2020-11-11 02:55:05 --> Config Class Initialized
INFO - 2020-11-11 02:55:05 --> Loader Class Initialized
INFO - 2020-11-11 02:55:05 --> Helper loaded: url_helper
INFO - 2020-11-11 02:55:05 --> Helper loaded: file_helper
INFO - 2020-11-11 02:55:05 --> Helper loaded: form_helper
INFO - 2020-11-11 02:55:05 --> Helper loaded: my_helper
INFO - 2020-11-11 02:55:05 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:55:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:55:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:55:06 --> Controller Class Initialized
DEBUG - 2020-11-11 02:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-11-11 02:55:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:55:06 --> Final output sent to browser
DEBUG - 2020-11-11 02:55:06 --> Total execution time: 0.2890
INFO - 2020-11-11 02:55:06 --> Config Class Initialized
INFO - 2020-11-11 02:55:06 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:55:06 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:55:06 --> Utf8 Class Initialized
INFO - 2020-11-11 02:55:06 --> URI Class Initialized
INFO - 2020-11-11 02:55:06 --> Router Class Initialized
INFO - 2020-11-11 02:55:06 --> Output Class Initialized
INFO - 2020-11-11 02:55:06 --> Security Class Initialized
DEBUG - 2020-11-11 02:55:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:55:06 --> Input Class Initialized
INFO - 2020-11-11 02:55:06 --> Language Class Initialized
INFO - 2020-11-11 02:55:06 --> Language Class Initialized
INFO - 2020-11-11 02:55:06 --> Config Class Initialized
INFO - 2020-11-11 02:55:06 --> Loader Class Initialized
INFO - 2020-11-11 02:55:06 --> Helper loaded: url_helper
INFO - 2020-11-11 02:55:06 --> Helper loaded: file_helper
INFO - 2020-11-11 02:55:06 --> Helper loaded: form_helper
INFO - 2020-11-11 02:55:06 --> Helper loaded: my_helper
INFO - 2020-11-11 02:55:06 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:55:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:55:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:55:06 --> Controller Class Initialized
INFO - 2020-11-11 02:55:09 --> Config Class Initialized
INFO - 2020-11-11 02:55:09 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:55:09 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:55:09 --> Utf8 Class Initialized
INFO - 2020-11-11 02:55:09 --> URI Class Initialized
INFO - 2020-11-11 02:55:09 --> Router Class Initialized
INFO - 2020-11-11 02:55:09 --> Output Class Initialized
INFO - 2020-11-11 02:55:09 --> Security Class Initialized
DEBUG - 2020-11-11 02:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:55:09 --> Input Class Initialized
INFO - 2020-11-11 02:55:09 --> Language Class Initialized
INFO - 2020-11-11 02:55:09 --> Language Class Initialized
INFO - 2020-11-11 02:55:09 --> Config Class Initialized
INFO - 2020-11-11 02:55:09 --> Loader Class Initialized
INFO - 2020-11-11 02:55:09 --> Helper loaded: url_helper
INFO - 2020-11-11 02:55:09 --> Helper loaded: file_helper
INFO - 2020-11-11 02:55:09 --> Helper loaded: form_helper
INFO - 2020-11-11 02:55:09 --> Helper loaded: my_helper
INFO - 2020-11-11 02:55:09 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:55:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:55:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:55:09 --> Controller Class Initialized
DEBUG - 2020-11-11 02:55:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-11-11 02:55:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:55:09 --> Final output sent to browser
DEBUG - 2020-11-11 02:55:09 --> Total execution time: 0.3239
INFO - 2020-11-11 02:55:30 --> Config Class Initialized
INFO - 2020-11-11 02:55:30 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:55:30 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:55:30 --> Utf8 Class Initialized
INFO - 2020-11-11 02:55:30 --> URI Class Initialized
INFO - 2020-11-11 02:55:30 --> Router Class Initialized
INFO - 2020-11-11 02:55:30 --> Output Class Initialized
INFO - 2020-11-11 02:55:30 --> Security Class Initialized
DEBUG - 2020-11-11 02:55:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:55:30 --> Input Class Initialized
INFO - 2020-11-11 02:55:30 --> Language Class Initialized
INFO - 2020-11-11 02:55:30 --> Language Class Initialized
INFO - 2020-11-11 02:55:30 --> Config Class Initialized
INFO - 2020-11-11 02:55:30 --> Loader Class Initialized
INFO - 2020-11-11 02:55:30 --> Helper loaded: url_helper
INFO - 2020-11-11 02:55:30 --> Helper loaded: file_helper
INFO - 2020-11-11 02:55:30 --> Helper loaded: form_helper
INFO - 2020-11-11 02:55:30 --> Helper loaded: my_helper
INFO - 2020-11-11 02:55:30 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:55:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:55:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:55:30 --> Controller Class Initialized
INFO - 2020-11-11 02:55:30 --> Final output sent to browser
DEBUG - 2020-11-11 02:55:30 --> Total execution time: 0.2754
INFO - 2020-11-11 02:56:01 --> Config Class Initialized
INFO - 2020-11-11 02:56:01 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:56:01 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:56:01 --> Utf8 Class Initialized
INFO - 2020-11-11 02:56:01 --> URI Class Initialized
INFO - 2020-11-11 02:56:01 --> Router Class Initialized
INFO - 2020-11-11 02:56:01 --> Output Class Initialized
INFO - 2020-11-11 02:56:01 --> Security Class Initialized
DEBUG - 2020-11-11 02:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:56:01 --> Input Class Initialized
INFO - 2020-11-11 02:56:01 --> Language Class Initialized
INFO - 2020-11-11 02:56:01 --> Language Class Initialized
INFO - 2020-11-11 02:56:01 --> Config Class Initialized
INFO - 2020-11-11 02:56:01 --> Loader Class Initialized
INFO - 2020-11-11 02:56:01 --> Helper loaded: url_helper
INFO - 2020-11-11 02:56:01 --> Helper loaded: file_helper
INFO - 2020-11-11 02:56:01 --> Helper loaded: form_helper
INFO - 2020-11-11 02:56:01 --> Helper loaded: my_helper
INFO - 2020-11-11 02:56:01 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:56:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:56:01 --> Controller Class Initialized
DEBUG - 2020-11-11 02:56:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-11 02:56:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:56:01 --> Final output sent to browser
DEBUG - 2020-11-11 02:56:01 --> Total execution time: 0.3153
INFO - 2020-11-11 02:56:03 --> Config Class Initialized
INFO - 2020-11-11 02:56:03 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:56:03 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:56:03 --> Utf8 Class Initialized
INFO - 2020-11-11 02:56:03 --> URI Class Initialized
INFO - 2020-11-11 02:56:03 --> Router Class Initialized
INFO - 2020-11-11 02:56:03 --> Output Class Initialized
INFO - 2020-11-11 02:56:03 --> Security Class Initialized
DEBUG - 2020-11-11 02:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:56:03 --> Input Class Initialized
INFO - 2020-11-11 02:56:03 --> Language Class Initialized
INFO - 2020-11-11 02:56:03 --> Language Class Initialized
INFO - 2020-11-11 02:56:03 --> Config Class Initialized
INFO - 2020-11-11 02:56:03 --> Loader Class Initialized
INFO - 2020-11-11 02:56:03 --> Helper loaded: url_helper
INFO - 2020-11-11 02:56:03 --> Helper loaded: file_helper
INFO - 2020-11-11 02:56:03 --> Helper loaded: form_helper
INFO - 2020-11-11 02:56:03 --> Helper loaded: my_helper
INFO - 2020-11-11 02:56:03 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:56:03 --> Controller Class Initialized
DEBUG - 2020-11-11 02:56:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-11 02:56:03 --> Final output sent to browser
DEBUG - 2020-11-11 02:56:03 --> Total execution time: 0.3740
INFO - 2020-11-11 02:59:17 --> Config Class Initialized
INFO - 2020-11-11 02:59:17 --> Hooks Class Initialized
DEBUG - 2020-11-11 02:59:17 --> UTF-8 Support Enabled
INFO - 2020-11-11 02:59:17 --> Utf8 Class Initialized
INFO - 2020-11-11 02:59:17 --> URI Class Initialized
INFO - 2020-11-11 02:59:17 --> Router Class Initialized
INFO - 2020-11-11 02:59:17 --> Output Class Initialized
INFO - 2020-11-11 02:59:17 --> Security Class Initialized
DEBUG - 2020-11-11 02:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 02:59:17 --> Input Class Initialized
INFO - 2020-11-11 02:59:17 --> Language Class Initialized
INFO - 2020-11-11 02:59:17 --> Language Class Initialized
INFO - 2020-11-11 02:59:17 --> Config Class Initialized
INFO - 2020-11-11 02:59:17 --> Loader Class Initialized
INFO - 2020-11-11 02:59:17 --> Helper loaded: url_helper
INFO - 2020-11-11 02:59:17 --> Helper loaded: file_helper
INFO - 2020-11-11 02:59:17 --> Helper loaded: form_helper
INFO - 2020-11-11 02:59:17 --> Helper loaded: my_helper
INFO - 2020-11-11 02:59:17 --> Database Driver Class Initialized
DEBUG - 2020-11-11 02:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 02:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 02:59:17 --> Controller Class Initialized
DEBUG - 2020-11-11 02:59:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-11-11 02:59:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 02:59:17 --> Final output sent to browser
DEBUG - 2020-11-11 02:59:17 --> Total execution time: 0.2859
INFO - 2020-11-11 03:01:34 --> Config Class Initialized
INFO - 2020-11-11 03:01:34 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:01:34 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:01:34 --> Utf8 Class Initialized
INFO - 2020-11-11 03:01:34 --> URI Class Initialized
INFO - 2020-11-11 03:01:34 --> Router Class Initialized
INFO - 2020-11-11 03:01:34 --> Output Class Initialized
INFO - 2020-11-11 03:01:34 --> Security Class Initialized
DEBUG - 2020-11-11 03:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:01:34 --> Input Class Initialized
INFO - 2020-11-11 03:01:34 --> Language Class Initialized
INFO - 2020-11-11 03:01:34 --> Language Class Initialized
INFO - 2020-11-11 03:01:34 --> Config Class Initialized
INFO - 2020-11-11 03:01:34 --> Loader Class Initialized
INFO - 2020-11-11 03:01:34 --> Helper loaded: url_helper
INFO - 2020-11-11 03:01:34 --> Helper loaded: file_helper
INFO - 2020-11-11 03:01:34 --> Helper loaded: form_helper
INFO - 2020-11-11 03:01:34 --> Helper loaded: my_helper
INFO - 2020-11-11 03:01:34 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:01:34 --> Controller Class Initialized
DEBUG - 2020-11-11 03:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-11 03:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:01:34 --> Final output sent to browser
DEBUG - 2020-11-11 03:01:34 --> Total execution time: 0.2985
INFO - 2020-11-11 03:01:36 --> Config Class Initialized
INFO - 2020-11-11 03:01:36 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:01:37 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:01:37 --> Utf8 Class Initialized
INFO - 2020-11-11 03:01:37 --> URI Class Initialized
INFO - 2020-11-11 03:01:37 --> Router Class Initialized
INFO - 2020-11-11 03:01:37 --> Output Class Initialized
INFO - 2020-11-11 03:01:37 --> Security Class Initialized
DEBUG - 2020-11-11 03:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:01:37 --> Input Class Initialized
INFO - 2020-11-11 03:01:37 --> Language Class Initialized
INFO - 2020-11-11 03:01:37 --> Language Class Initialized
INFO - 2020-11-11 03:01:37 --> Config Class Initialized
INFO - 2020-11-11 03:01:37 --> Loader Class Initialized
INFO - 2020-11-11 03:01:37 --> Helper loaded: url_helper
INFO - 2020-11-11 03:01:37 --> Helper loaded: file_helper
INFO - 2020-11-11 03:01:37 --> Helper loaded: form_helper
INFO - 2020-11-11 03:01:37 --> Helper loaded: my_helper
INFO - 2020-11-11 03:01:37 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:01:37 --> Controller Class Initialized
DEBUG - 2020-11-11 03:01:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-11 03:01:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:01:37 --> Final output sent to browser
DEBUG - 2020-11-11 03:01:37 --> Total execution time: 0.2840
INFO - 2020-11-11 03:01:40 --> Config Class Initialized
INFO - 2020-11-11 03:01:40 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:01:40 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:01:40 --> Utf8 Class Initialized
INFO - 2020-11-11 03:01:40 --> URI Class Initialized
INFO - 2020-11-11 03:01:40 --> Router Class Initialized
INFO - 2020-11-11 03:01:40 --> Output Class Initialized
INFO - 2020-11-11 03:01:40 --> Security Class Initialized
DEBUG - 2020-11-11 03:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:01:40 --> Input Class Initialized
INFO - 2020-11-11 03:01:40 --> Language Class Initialized
INFO - 2020-11-11 03:01:40 --> Language Class Initialized
INFO - 2020-11-11 03:01:40 --> Config Class Initialized
INFO - 2020-11-11 03:01:40 --> Loader Class Initialized
INFO - 2020-11-11 03:01:40 --> Helper loaded: url_helper
INFO - 2020-11-11 03:01:40 --> Helper loaded: file_helper
INFO - 2020-11-11 03:01:40 --> Helper loaded: form_helper
INFO - 2020-11-11 03:01:40 --> Helper loaded: my_helper
INFO - 2020-11-11 03:01:40 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:01:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:01:40 --> Controller Class Initialized
DEBUG - 2020-11-11 03:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-11-11 03:01:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:01:40 --> Final output sent to browser
DEBUG - 2020-11-11 03:01:40 --> Total execution time: 0.2874
INFO - 2020-11-11 03:01:42 --> Config Class Initialized
INFO - 2020-11-11 03:01:42 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:01:42 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:01:42 --> Utf8 Class Initialized
INFO - 2020-11-11 03:01:42 --> URI Class Initialized
INFO - 2020-11-11 03:01:42 --> Router Class Initialized
INFO - 2020-11-11 03:01:42 --> Output Class Initialized
INFO - 2020-11-11 03:01:42 --> Security Class Initialized
DEBUG - 2020-11-11 03:01:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:01:42 --> Input Class Initialized
INFO - 2020-11-11 03:01:42 --> Language Class Initialized
INFO - 2020-11-11 03:01:42 --> Language Class Initialized
INFO - 2020-11-11 03:01:42 --> Config Class Initialized
INFO - 2020-11-11 03:01:42 --> Loader Class Initialized
INFO - 2020-11-11 03:01:42 --> Helper loaded: url_helper
INFO - 2020-11-11 03:01:42 --> Helper loaded: file_helper
INFO - 2020-11-11 03:01:42 --> Helper loaded: form_helper
INFO - 2020-11-11 03:01:42 --> Helper loaded: my_helper
INFO - 2020-11-11 03:01:42 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:01:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:01:42 --> Controller Class Initialized
DEBUG - 2020-11-11 03:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-11-11 03:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:01:42 --> Final output sent to browser
DEBUG - 2020-11-11 03:01:42 --> Total execution time: 0.2845
INFO - 2020-11-11 03:04:00 --> Config Class Initialized
INFO - 2020-11-11 03:04:00 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:00 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:00 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:00 --> URI Class Initialized
INFO - 2020-11-11 03:04:00 --> Router Class Initialized
INFO - 2020-11-11 03:04:00 --> Output Class Initialized
INFO - 2020-11-11 03:04:00 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:00 --> Input Class Initialized
INFO - 2020-11-11 03:04:00 --> Language Class Initialized
INFO - 2020-11-11 03:04:00 --> Language Class Initialized
INFO - 2020-11-11 03:04:00 --> Config Class Initialized
INFO - 2020-11-11 03:04:00 --> Loader Class Initialized
INFO - 2020-11-11 03:04:00 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:00 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:00 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:00 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:00 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:00 --> Controller Class Initialized
DEBUG - 2020-11-11 03:04:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 03:04:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:04:00 --> Final output sent to browser
DEBUG - 2020-11-11 03:04:00 --> Total execution time: 0.3181
INFO - 2020-11-11 03:04:03 --> Config Class Initialized
INFO - 2020-11-11 03:04:03 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:03 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:03 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:03 --> URI Class Initialized
INFO - 2020-11-11 03:04:03 --> Router Class Initialized
INFO - 2020-11-11 03:04:03 --> Output Class Initialized
INFO - 2020-11-11 03:04:03 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:03 --> Input Class Initialized
INFO - 2020-11-11 03:04:03 --> Language Class Initialized
INFO - 2020-11-11 03:04:03 --> Language Class Initialized
INFO - 2020-11-11 03:04:03 --> Config Class Initialized
INFO - 2020-11-11 03:04:03 --> Loader Class Initialized
INFO - 2020-11-11 03:04:03 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:03 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:03 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:03 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:04 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:04 --> Controller Class Initialized
INFO - 2020-11-11 03:04:04 --> Helper loaded: cookie_helper
INFO - 2020-11-11 03:04:04 --> Config Class Initialized
INFO - 2020-11-11 03:04:04 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:04 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:04 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:04 --> URI Class Initialized
INFO - 2020-11-11 03:04:04 --> Router Class Initialized
INFO - 2020-11-11 03:04:04 --> Output Class Initialized
INFO - 2020-11-11 03:04:04 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:04 --> Input Class Initialized
INFO - 2020-11-11 03:04:04 --> Language Class Initialized
INFO - 2020-11-11 03:04:04 --> Language Class Initialized
INFO - 2020-11-11 03:04:04 --> Config Class Initialized
INFO - 2020-11-11 03:04:04 --> Loader Class Initialized
INFO - 2020-11-11 03:04:04 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:04 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:04 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:04 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:04 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:04 --> Controller Class Initialized
DEBUG - 2020-11-11 03:04:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 03:04:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:04:04 --> Final output sent to browser
DEBUG - 2020-11-11 03:04:04 --> Total execution time: 0.2740
INFO - 2020-11-11 03:04:11 --> Config Class Initialized
INFO - 2020-11-11 03:04:11 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:11 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:11 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:11 --> URI Class Initialized
INFO - 2020-11-11 03:04:11 --> Router Class Initialized
INFO - 2020-11-11 03:04:11 --> Output Class Initialized
INFO - 2020-11-11 03:04:11 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:11 --> Input Class Initialized
INFO - 2020-11-11 03:04:11 --> Language Class Initialized
INFO - 2020-11-11 03:04:11 --> Language Class Initialized
INFO - 2020-11-11 03:04:11 --> Config Class Initialized
INFO - 2020-11-11 03:04:11 --> Loader Class Initialized
INFO - 2020-11-11 03:04:11 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:11 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:11 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:11 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:11 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:11 --> Controller Class Initialized
INFO - 2020-11-11 03:04:11 --> Helper loaded: cookie_helper
INFO - 2020-11-11 03:04:11 --> Final output sent to browser
DEBUG - 2020-11-11 03:04:11 --> Total execution time: 0.3870
INFO - 2020-11-11 03:04:12 --> Config Class Initialized
INFO - 2020-11-11 03:04:12 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:12 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:12 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:12 --> URI Class Initialized
INFO - 2020-11-11 03:04:12 --> Router Class Initialized
INFO - 2020-11-11 03:04:12 --> Output Class Initialized
INFO - 2020-11-11 03:04:12 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:12 --> Input Class Initialized
INFO - 2020-11-11 03:04:12 --> Language Class Initialized
INFO - 2020-11-11 03:04:12 --> Language Class Initialized
INFO - 2020-11-11 03:04:12 --> Config Class Initialized
INFO - 2020-11-11 03:04:12 --> Loader Class Initialized
INFO - 2020-11-11 03:04:12 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:12 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:12 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:12 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:12 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:12 --> Controller Class Initialized
DEBUG - 2020-11-11 03:04:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 03:04:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:04:12 --> Final output sent to browser
DEBUG - 2020-11-11 03:04:12 --> Total execution time: 0.4134
INFO - 2020-11-11 03:04:15 --> Config Class Initialized
INFO - 2020-11-11 03:04:15 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:15 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:15 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:15 --> URI Class Initialized
INFO - 2020-11-11 03:04:15 --> Router Class Initialized
INFO - 2020-11-11 03:04:15 --> Output Class Initialized
INFO - 2020-11-11 03:04:15 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:15 --> Input Class Initialized
INFO - 2020-11-11 03:04:15 --> Language Class Initialized
INFO - 2020-11-11 03:04:15 --> Language Class Initialized
INFO - 2020-11-11 03:04:15 --> Config Class Initialized
INFO - 2020-11-11 03:04:15 --> Loader Class Initialized
INFO - 2020-11-11 03:04:15 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:15 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:15 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:15 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:15 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:15 --> Controller Class Initialized
DEBUG - 2020-11-11 03:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 03:04:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:04:15 --> Final output sent to browser
DEBUG - 2020-11-11 03:04:15 --> Total execution time: 0.2828
INFO - 2020-11-11 03:04:17 --> Config Class Initialized
INFO - 2020-11-11 03:04:17 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:17 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:17 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:17 --> URI Class Initialized
INFO - 2020-11-11 03:04:17 --> Router Class Initialized
INFO - 2020-11-11 03:04:17 --> Output Class Initialized
INFO - 2020-11-11 03:04:17 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:17 --> Input Class Initialized
INFO - 2020-11-11 03:04:17 --> Language Class Initialized
INFO - 2020-11-11 03:04:17 --> Language Class Initialized
INFO - 2020-11-11 03:04:17 --> Config Class Initialized
INFO - 2020-11-11 03:04:17 --> Loader Class Initialized
INFO - 2020-11-11 03:04:17 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:17 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:17 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:17 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:17 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:17 --> Controller Class Initialized
DEBUG - 2020-11-11 03:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-11 03:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:04:17 --> Final output sent to browser
DEBUG - 2020-11-11 03:04:17 --> Total execution time: 0.2862
INFO - 2020-11-11 03:04:17 --> Config Class Initialized
INFO - 2020-11-11 03:04:17 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:18 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:18 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:18 --> URI Class Initialized
INFO - 2020-11-11 03:04:18 --> Router Class Initialized
INFO - 2020-11-11 03:04:18 --> Output Class Initialized
INFO - 2020-11-11 03:04:18 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:18 --> Input Class Initialized
INFO - 2020-11-11 03:04:18 --> Language Class Initialized
INFO - 2020-11-11 03:04:18 --> Language Class Initialized
INFO - 2020-11-11 03:04:18 --> Config Class Initialized
INFO - 2020-11-11 03:04:18 --> Loader Class Initialized
INFO - 2020-11-11 03:04:18 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:18 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:18 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:18 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:18 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:18 --> Controller Class Initialized
INFO - 2020-11-11 03:04:24 --> Config Class Initialized
INFO - 2020-11-11 03:04:24 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:04:24 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:04:24 --> Utf8 Class Initialized
INFO - 2020-11-11 03:04:24 --> URI Class Initialized
INFO - 2020-11-11 03:04:24 --> Router Class Initialized
INFO - 2020-11-11 03:04:24 --> Output Class Initialized
INFO - 2020-11-11 03:04:24 --> Security Class Initialized
DEBUG - 2020-11-11 03:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:04:24 --> Input Class Initialized
INFO - 2020-11-11 03:04:24 --> Language Class Initialized
INFO - 2020-11-11 03:04:24 --> Language Class Initialized
INFO - 2020-11-11 03:04:24 --> Config Class Initialized
INFO - 2020-11-11 03:04:24 --> Loader Class Initialized
INFO - 2020-11-11 03:04:24 --> Helper loaded: url_helper
INFO - 2020-11-11 03:04:24 --> Helper loaded: file_helper
INFO - 2020-11-11 03:04:24 --> Helper loaded: form_helper
INFO - 2020-11-11 03:04:24 --> Helper loaded: my_helper
INFO - 2020-11-11 03:04:24 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:04:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:04:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:04:24 --> Controller Class Initialized
INFO - 2020-11-11 03:07:33 --> Config Class Initialized
INFO - 2020-11-11 03:07:33 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:07:33 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:07:33 --> Utf8 Class Initialized
INFO - 2020-11-11 03:07:33 --> URI Class Initialized
INFO - 2020-11-11 03:07:33 --> Router Class Initialized
INFO - 2020-11-11 03:07:33 --> Output Class Initialized
INFO - 2020-11-11 03:07:33 --> Security Class Initialized
DEBUG - 2020-11-11 03:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:07:33 --> Input Class Initialized
INFO - 2020-11-11 03:07:33 --> Language Class Initialized
INFO - 2020-11-11 03:07:33 --> Language Class Initialized
INFO - 2020-11-11 03:07:33 --> Config Class Initialized
INFO - 2020-11-11 03:07:33 --> Loader Class Initialized
INFO - 2020-11-11 03:07:33 --> Helper loaded: url_helper
INFO - 2020-11-11 03:07:33 --> Helper loaded: file_helper
INFO - 2020-11-11 03:07:33 --> Helper loaded: form_helper
INFO - 2020-11-11 03:07:33 --> Helper loaded: my_helper
INFO - 2020-11-11 03:07:33 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:07:33 --> Controller Class Initialized
DEBUG - 2020-11-11 03:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 03:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:07:33 --> Final output sent to browser
DEBUG - 2020-11-11 03:07:33 --> Total execution time: 0.3216
INFO - 2020-11-11 03:07:35 --> Config Class Initialized
INFO - 2020-11-11 03:07:35 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:07:35 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:07:35 --> Utf8 Class Initialized
INFO - 2020-11-11 03:07:35 --> URI Class Initialized
INFO - 2020-11-11 03:07:35 --> Router Class Initialized
INFO - 2020-11-11 03:07:35 --> Output Class Initialized
INFO - 2020-11-11 03:07:35 --> Security Class Initialized
DEBUG - 2020-11-11 03:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:07:35 --> Input Class Initialized
INFO - 2020-11-11 03:07:35 --> Language Class Initialized
INFO - 2020-11-11 03:07:35 --> Language Class Initialized
INFO - 2020-11-11 03:07:35 --> Config Class Initialized
INFO - 2020-11-11 03:07:35 --> Loader Class Initialized
INFO - 2020-11-11 03:07:35 --> Helper loaded: url_helper
INFO - 2020-11-11 03:07:35 --> Helper loaded: file_helper
INFO - 2020-11-11 03:07:35 --> Helper loaded: form_helper
INFO - 2020-11-11 03:07:35 --> Helper loaded: my_helper
INFO - 2020-11-11 03:07:35 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:07:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:07:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:07:35 --> Controller Class Initialized
DEBUG - 2020-11-11 03:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-11 03:07:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:07:35 --> Final output sent to browser
DEBUG - 2020-11-11 03:07:35 --> Total execution time: 0.2771
INFO - 2020-11-11 03:07:40 --> Config Class Initialized
INFO - 2020-11-11 03:07:40 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:07:40 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:07:40 --> Utf8 Class Initialized
INFO - 2020-11-11 03:07:40 --> URI Class Initialized
INFO - 2020-11-11 03:07:40 --> Router Class Initialized
INFO - 2020-11-11 03:07:40 --> Output Class Initialized
INFO - 2020-11-11 03:07:41 --> Security Class Initialized
DEBUG - 2020-11-11 03:07:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:07:41 --> Input Class Initialized
INFO - 2020-11-11 03:07:41 --> Language Class Initialized
INFO - 2020-11-11 03:07:41 --> Language Class Initialized
INFO - 2020-11-11 03:07:41 --> Config Class Initialized
INFO - 2020-11-11 03:07:41 --> Loader Class Initialized
INFO - 2020-11-11 03:07:41 --> Helper loaded: url_helper
INFO - 2020-11-11 03:07:41 --> Helper loaded: file_helper
INFO - 2020-11-11 03:07:41 --> Helper loaded: form_helper
INFO - 2020-11-11 03:07:41 --> Helper loaded: my_helper
INFO - 2020-11-11 03:07:41 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:07:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:07:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:07:41 --> Controller Class Initialized
INFO - 2020-11-11 03:13:00 --> Config Class Initialized
INFO - 2020-11-11 03:13:01 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:01 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:01 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:01 --> URI Class Initialized
INFO - 2020-11-11 03:13:01 --> Router Class Initialized
INFO - 2020-11-11 03:13:01 --> Output Class Initialized
INFO - 2020-11-11 03:13:01 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:01 --> Input Class Initialized
INFO - 2020-11-11 03:13:01 --> Language Class Initialized
INFO - 2020-11-11 03:13:01 --> Language Class Initialized
INFO - 2020-11-11 03:13:01 --> Config Class Initialized
INFO - 2020-11-11 03:13:01 --> Loader Class Initialized
INFO - 2020-11-11 03:13:01 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:01 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:01 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:01 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:01 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:01 --> Controller Class Initialized
INFO - 2020-11-11 03:13:01 --> Helper loaded: cookie_helper
INFO - 2020-11-11 03:13:01 --> Config Class Initialized
INFO - 2020-11-11 03:13:01 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:01 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:01 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:01 --> URI Class Initialized
INFO - 2020-11-11 03:13:01 --> Router Class Initialized
INFO - 2020-11-11 03:13:01 --> Output Class Initialized
INFO - 2020-11-11 03:13:01 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:01 --> Input Class Initialized
INFO - 2020-11-11 03:13:01 --> Language Class Initialized
INFO - 2020-11-11 03:13:01 --> Language Class Initialized
INFO - 2020-11-11 03:13:01 --> Config Class Initialized
INFO - 2020-11-11 03:13:01 --> Loader Class Initialized
INFO - 2020-11-11 03:13:01 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:01 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:01 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:01 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:01 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:01 --> Controller Class Initialized
DEBUG - 2020-11-11 03:13:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 03:13:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:13:01 --> Final output sent to browser
DEBUG - 2020-11-11 03:13:01 --> Total execution time: 0.2999
INFO - 2020-11-11 03:13:07 --> Config Class Initialized
INFO - 2020-11-11 03:13:07 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:07 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:08 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:08 --> URI Class Initialized
INFO - 2020-11-11 03:13:08 --> Router Class Initialized
INFO - 2020-11-11 03:13:08 --> Output Class Initialized
INFO - 2020-11-11 03:13:08 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:08 --> Input Class Initialized
INFO - 2020-11-11 03:13:08 --> Language Class Initialized
INFO - 2020-11-11 03:13:08 --> Language Class Initialized
INFO - 2020-11-11 03:13:08 --> Config Class Initialized
INFO - 2020-11-11 03:13:08 --> Loader Class Initialized
INFO - 2020-11-11 03:13:08 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:08 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:08 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:08 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:08 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:08 --> Controller Class Initialized
INFO - 2020-11-11 03:13:08 --> Final output sent to browser
DEBUG - 2020-11-11 03:13:08 --> Total execution time: 0.3555
INFO - 2020-11-11 03:13:12 --> Config Class Initialized
INFO - 2020-11-11 03:13:12 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:12 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:12 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:13 --> URI Class Initialized
INFO - 2020-11-11 03:13:13 --> Router Class Initialized
INFO - 2020-11-11 03:13:13 --> Output Class Initialized
INFO - 2020-11-11 03:13:13 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:13 --> Input Class Initialized
INFO - 2020-11-11 03:13:13 --> Language Class Initialized
INFO - 2020-11-11 03:13:13 --> Language Class Initialized
INFO - 2020-11-11 03:13:13 --> Config Class Initialized
INFO - 2020-11-11 03:13:13 --> Loader Class Initialized
INFO - 2020-11-11 03:13:13 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:13 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:13 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:13 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:13 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:13 --> Controller Class Initialized
INFO - 2020-11-11 03:13:13 --> Helper loaded: cookie_helper
INFO - 2020-11-11 03:13:13 --> Final output sent to browser
DEBUG - 2020-11-11 03:13:13 --> Total execution time: 0.3667
INFO - 2020-11-11 03:13:13 --> Config Class Initialized
INFO - 2020-11-11 03:13:13 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:13 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:13 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:13 --> URI Class Initialized
INFO - 2020-11-11 03:13:13 --> Router Class Initialized
INFO - 2020-11-11 03:13:13 --> Output Class Initialized
INFO - 2020-11-11 03:13:13 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:13 --> Input Class Initialized
INFO - 2020-11-11 03:13:14 --> Language Class Initialized
INFO - 2020-11-11 03:13:14 --> Language Class Initialized
INFO - 2020-11-11 03:13:14 --> Config Class Initialized
INFO - 2020-11-11 03:13:14 --> Loader Class Initialized
INFO - 2020-11-11 03:13:14 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:14 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:14 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:14 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:14 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:14 --> Controller Class Initialized
DEBUG - 2020-11-11 03:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 03:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:13:14 --> Final output sent to browser
DEBUG - 2020-11-11 03:13:14 --> Total execution time: 0.4357
INFO - 2020-11-11 03:13:19 --> Config Class Initialized
INFO - 2020-11-11 03:13:19 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:19 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:19 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:19 --> URI Class Initialized
INFO - 2020-11-11 03:13:19 --> Router Class Initialized
INFO - 2020-11-11 03:13:19 --> Output Class Initialized
INFO - 2020-11-11 03:13:19 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:19 --> Input Class Initialized
INFO - 2020-11-11 03:13:19 --> Language Class Initialized
INFO - 2020-11-11 03:13:19 --> Language Class Initialized
INFO - 2020-11-11 03:13:19 --> Config Class Initialized
INFO - 2020-11-11 03:13:19 --> Loader Class Initialized
INFO - 2020-11-11 03:13:19 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:19 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:19 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:19 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:19 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:19 --> Controller Class Initialized
DEBUG - 2020-11-11 03:13:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-11-11 03:13:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:13:19 --> Final output sent to browser
DEBUG - 2020-11-11 03:13:19 --> Total execution time: 0.2854
INFO - 2020-11-11 03:13:22 --> Config Class Initialized
INFO - 2020-11-11 03:13:22 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:22 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:22 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:22 --> URI Class Initialized
INFO - 2020-11-11 03:13:22 --> Router Class Initialized
INFO - 2020-11-11 03:13:22 --> Output Class Initialized
INFO - 2020-11-11 03:13:22 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:22 --> Input Class Initialized
INFO - 2020-11-11 03:13:23 --> Language Class Initialized
INFO - 2020-11-11 03:13:23 --> Language Class Initialized
INFO - 2020-11-11 03:13:23 --> Config Class Initialized
INFO - 2020-11-11 03:13:23 --> Loader Class Initialized
INFO - 2020-11-11 03:13:23 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:23 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:23 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:23 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:23 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:23 --> Controller Class Initialized
DEBUG - 2020-11-11 03:13:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_sampul1.php
INFO - 2020-11-11 03:13:23 --> Final output sent to browser
DEBUG - 2020-11-11 03:13:23 --> Total execution time: 0.3577
INFO - 2020-11-11 03:13:28 --> Config Class Initialized
INFO - 2020-11-11 03:13:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:13:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:13:28 --> Utf8 Class Initialized
INFO - 2020-11-11 03:13:28 --> URI Class Initialized
INFO - 2020-11-11 03:13:28 --> Router Class Initialized
INFO - 2020-11-11 03:13:28 --> Output Class Initialized
INFO - 2020-11-11 03:13:28 --> Security Class Initialized
DEBUG - 2020-11-11 03:13:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:13:28 --> Input Class Initialized
INFO - 2020-11-11 03:13:28 --> Language Class Initialized
INFO - 2020-11-11 03:13:28 --> Language Class Initialized
INFO - 2020-11-11 03:13:28 --> Config Class Initialized
INFO - 2020-11-11 03:13:28 --> Loader Class Initialized
INFO - 2020-11-11 03:13:28 --> Helper loaded: url_helper
INFO - 2020-11-11 03:13:28 --> Helper loaded: file_helper
INFO - 2020-11-11 03:13:28 --> Helper loaded: form_helper
INFO - 2020-11-11 03:13:28 --> Helper loaded: my_helper
INFO - 2020-11-11 03:13:28 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:13:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:13:28 --> Controller Class Initialized
DEBUG - 2020-11-11 03:13:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2020-11-11 03:13:28 --> Final output sent to browser
DEBUG - 2020-11-11 03:13:29 --> Total execution time: 0.3035
INFO - 2020-11-11 03:16:56 --> Config Class Initialized
INFO - 2020-11-11 03:16:56 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:16:56 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:16:56 --> Utf8 Class Initialized
INFO - 2020-11-11 03:16:56 --> URI Class Initialized
INFO - 2020-11-11 03:16:56 --> Router Class Initialized
INFO - 2020-11-11 03:16:56 --> Output Class Initialized
INFO - 2020-11-11 03:16:56 --> Security Class Initialized
DEBUG - 2020-11-11 03:16:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:16:56 --> Input Class Initialized
INFO - 2020-11-11 03:16:56 --> Language Class Initialized
INFO - 2020-11-11 03:16:56 --> Language Class Initialized
INFO - 2020-11-11 03:16:56 --> Config Class Initialized
INFO - 2020-11-11 03:16:56 --> Loader Class Initialized
INFO - 2020-11-11 03:16:56 --> Helper loaded: url_helper
INFO - 2020-11-11 03:16:56 --> Helper loaded: file_helper
INFO - 2020-11-11 03:16:56 --> Helper loaded: form_helper
INFO - 2020-11-11 03:16:56 --> Helper loaded: my_helper
INFO - 2020-11-11 03:16:56 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:16:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:16:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:16:56 --> Controller Class Initialized
DEBUG - 2020-11-11 03:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-11 03:16:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:16:56 --> Final output sent to browser
DEBUG - 2020-11-11 03:16:56 --> Total execution time: 0.2952
INFO - 2020-11-11 03:26:46 --> Config Class Initialized
INFO - 2020-11-11 03:26:46 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:26:46 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:26:46 --> Utf8 Class Initialized
INFO - 2020-11-11 03:26:46 --> URI Class Initialized
INFO - 2020-11-11 03:26:47 --> Router Class Initialized
INFO - 2020-11-11 03:26:47 --> Output Class Initialized
INFO - 2020-11-11 03:26:47 --> Security Class Initialized
DEBUG - 2020-11-11 03:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:26:47 --> Input Class Initialized
INFO - 2020-11-11 03:26:47 --> Language Class Initialized
INFO - 2020-11-11 03:26:47 --> Language Class Initialized
INFO - 2020-11-11 03:26:47 --> Config Class Initialized
INFO - 2020-11-11 03:26:47 --> Loader Class Initialized
INFO - 2020-11-11 03:26:47 --> Helper loaded: url_helper
INFO - 2020-11-11 03:26:47 --> Helper loaded: file_helper
INFO - 2020-11-11 03:26:47 --> Helper loaded: form_helper
INFO - 2020-11-11 03:26:47 --> Helper loaded: my_helper
INFO - 2020-11-11 03:26:47 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:26:47 --> Controller Class Initialized
INFO - 2020-11-11 03:26:47 --> Helper loaded: cookie_helper
INFO - 2020-11-11 03:26:47 --> Config Class Initialized
INFO - 2020-11-11 03:26:47 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:26:47 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:26:47 --> Utf8 Class Initialized
INFO - 2020-11-11 03:26:47 --> URI Class Initialized
INFO - 2020-11-11 03:26:47 --> Router Class Initialized
INFO - 2020-11-11 03:26:47 --> Output Class Initialized
INFO - 2020-11-11 03:26:47 --> Security Class Initialized
DEBUG - 2020-11-11 03:26:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:26:47 --> Input Class Initialized
INFO - 2020-11-11 03:26:47 --> Language Class Initialized
INFO - 2020-11-11 03:26:47 --> Language Class Initialized
INFO - 2020-11-11 03:26:47 --> Config Class Initialized
INFO - 2020-11-11 03:26:47 --> Loader Class Initialized
INFO - 2020-11-11 03:26:47 --> Helper loaded: url_helper
INFO - 2020-11-11 03:26:47 --> Helper loaded: file_helper
INFO - 2020-11-11 03:26:47 --> Helper loaded: form_helper
INFO - 2020-11-11 03:26:47 --> Helper loaded: my_helper
INFO - 2020-11-11 03:26:47 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:26:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:26:47 --> Controller Class Initialized
DEBUG - 2020-11-11 03:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-11 03:26:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:26:47 --> Final output sent to browser
DEBUG - 2020-11-11 03:26:47 --> Total execution time: 0.3203
INFO - 2020-11-11 03:26:56 --> Config Class Initialized
INFO - 2020-11-11 03:26:56 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:26:56 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:26:56 --> Utf8 Class Initialized
INFO - 2020-11-11 03:26:56 --> URI Class Initialized
INFO - 2020-11-11 03:26:56 --> Router Class Initialized
INFO - 2020-11-11 03:26:56 --> Output Class Initialized
INFO - 2020-11-11 03:26:56 --> Security Class Initialized
DEBUG - 2020-11-11 03:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:26:56 --> Input Class Initialized
INFO - 2020-11-11 03:26:56 --> Language Class Initialized
INFO - 2020-11-11 03:26:56 --> Language Class Initialized
INFO - 2020-11-11 03:26:56 --> Config Class Initialized
INFO - 2020-11-11 03:26:56 --> Loader Class Initialized
INFO - 2020-11-11 03:26:56 --> Helper loaded: url_helper
INFO - 2020-11-11 03:26:56 --> Helper loaded: file_helper
INFO - 2020-11-11 03:26:56 --> Helper loaded: form_helper
INFO - 2020-11-11 03:26:56 --> Helper loaded: my_helper
INFO - 2020-11-11 03:26:56 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:26:56 --> Controller Class Initialized
INFO - 2020-11-11 03:26:56 --> Helper loaded: cookie_helper
INFO - 2020-11-11 03:26:56 --> Final output sent to browser
DEBUG - 2020-11-11 03:26:56 --> Total execution time: 0.3634
INFO - 2020-11-11 03:26:56 --> Config Class Initialized
INFO - 2020-11-11 03:26:56 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:26:56 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:26:56 --> Utf8 Class Initialized
INFO - 2020-11-11 03:26:56 --> URI Class Initialized
INFO - 2020-11-11 03:26:56 --> Router Class Initialized
INFO - 2020-11-11 03:26:56 --> Output Class Initialized
INFO - 2020-11-11 03:26:56 --> Security Class Initialized
DEBUG - 2020-11-11 03:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:26:57 --> Input Class Initialized
INFO - 2020-11-11 03:26:57 --> Language Class Initialized
INFO - 2020-11-11 03:26:57 --> Language Class Initialized
INFO - 2020-11-11 03:26:57 --> Config Class Initialized
INFO - 2020-11-11 03:26:57 --> Loader Class Initialized
INFO - 2020-11-11 03:26:57 --> Helper loaded: url_helper
INFO - 2020-11-11 03:26:57 --> Helper loaded: file_helper
INFO - 2020-11-11 03:26:57 --> Helper loaded: form_helper
INFO - 2020-11-11 03:26:57 --> Helper loaded: my_helper
INFO - 2020-11-11 03:26:57 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:26:57 --> Controller Class Initialized
DEBUG - 2020-11-11 03:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-11 03:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:26:57 --> Final output sent to browser
DEBUG - 2020-11-11 03:26:57 --> Total execution time: 0.4591
INFO - 2020-11-11 03:26:59 --> Config Class Initialized
INFO - 2020-11-11 03:26:59 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:26:59 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:26:59 --> Utf8 Class Initialized
INFO - 2020-11-11 03:26:59 --> URI Class Initialized
INFO - 2020-11-11 03:26:59 --> Router Class Initialized
INFO - 2020-11-11 03:26:59 --> Output Class Initialized
INFO - 2020-11-11 03:26:59 --> Security Class Initialized
DEBUG - 2020-11-11 03:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:26:59 --> Input Class Initialized
INFO - 2020-11-11 03:26:59 --> Language Class Initialized
INFO - 2020-11-11 03:26:59 --> Language Class Initialized
INFO - 2020-11-11 03:26:59 --> Config Class Initialized
INFO - 2020-11-11 03:26:59 --> Loader Class Initialized
INFO - 2020-11-11 03:26:59 --> Helper loaded: url_helper
INFO - 2020-11-11 03:26:59 --> Helper loaded: file_helper
INFO - 2020-11-11 03:26:59 --> Helper loaded: form_helper
INFO - 2020-11-11 03:26:59 --> Helper loaded: my_helper
INFO - 2020-11-11 03:26:59 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:26:59 --> Controller Class Initialized
DEBUG - 2020-11-11 03:26:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-11-11 03:26:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:26:59 --> Final output sent to browser
DEBUG - 2020-11-11 03:26:59 --> Total execution time: 0.3053
INFO - 2020-11-11 03:26:59 --> Config Class Initialized
INFO - 2020-11-11 03:26:59 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:26:59 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:26:59 --> Utf8 Class Initialized
INFO - 2020-11-11 03:26:59 --> URI Class Initialized
INFO - 2020-11-11 03:26:59 --> Router Class Initialized
INFO - 2020-11-11 03:26:59 --> Output Class Initialized
INFO - 2020-11-11 03:26:59 --> Security Class Initialized
DEBUG - 2020-11-11 03:26:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:26:59 --> Input Class Initialized
INFO - 2020-11-11 03:26:59 --> Language Class Initialized
INFO - 2020-11-11 03:26:59 --> Language Class Initialized
INFO - 2020-11-11 03:26:59 --> Config Class Initialized
INFO - 2020-11-11 03:26:59 --> Loader Class Initialized
INFO - 2020-11-11 03:26:59 --> Helper loaded: url_helper
INFO - 2020-11-11 03:26:59 --> Helper loaded: file_helper
INFO - 2020-11-11 03:26:59 --> Helper loaded: form_helper
INFO - 2020-11-11 03:26:59 --> Helper loaded: my_helper
INFO - 2020-11-11 03:26:59 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:26:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:26:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:26:59 --> Controller Class Initialized
INFO - 2020-11-11 03:27:04 --> Config Class Initialized
INFO - 2020-11-11 03:27:04 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:04 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:04 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:04 --> URI Class Initialized
INFO - 2020-11-11 03:27:04 --> Router Class Initialized
INFO - 2020-11-11 03:27:04 --> Output Class Initialized
INFO - 2020-11-11 03:27:04 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:04 --> Input Class Initialized
INFO - 2020-11-11 03:27:04 --> Language Class Initialized
INFO - 2020-11-11 03:27:04 --> Language Class Initialized
INFO - 2020-11-11 03:27:04 --> Config Class Initialized
INFO - 2020-11-11 03:27:04 --> Loader Class Initialized
INFO - 2020-11-11 03:27:04 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:04 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:04 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:04 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:04 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:04 --> Controller Class Initialized
INFO - 2020-11-11 03:27:08 --> Config Class Initialized
INFO - 2020-11-11 03:27:08 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:08 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:08 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:08 --> URI Class Initialized
INFO - 2020-11-11 03:27:08 --> Router Class Initialized
INFO - 2020-11-11 03:27:08 --> Output Class Initialized
INFO - 2020-11-11 03:27:08 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:08 --> Input Class Initialized
INFO - 2020-11-11 03:27:08 --> Language Class Initialized
INFO - 2020-11-11 03:27:08 --> Language Class Initialized
INFO - 2020-11-11 03:27:08 --> Config Class Initialized
INFO - 2020-11-11 03:27:08 --> Loader Class Initialized
INFO - 2020-11-11 03:27:08 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:08 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:08 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:08 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:08 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:08 --> Controller Class Initialized
DEBUG - 2020-11-11 03:27:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-11-11 03:27:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:27:08 --> Final output sent to browser
DEBUG - 2020-11-11 03:27:08 --> Total execution time: 0.3339
INFO - 2020-11-11 03:27:08 --> Config Class Initialized
INFO - 2020-11-11 03:27:08 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:08 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:08 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:08 --> URI Class Initialized
INFO - 2020-11-11 03:27:08 --> Router Class Initialized
INFO - 2020-11-11 03:27:08 --> Output Class Initialized
INFO - 2020-11-11 03:27:08 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:08 --> Input Class Initialized
INFO - 2020-11-11 03:27:08 --> Language Class Initialized
INFO - 2020-11-11 03:27:08 --> Language Class Initialized
INFO - 2020-11-11 03:27:08 --> Config Class Initialized
INFO - 2020-11-11 03:27:08 --> Loader Class Initialized
INFO - 2020-11-11 03:27:08 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:08 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:08 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:08 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:08 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:08 --> Controller Class Initialized
INFO - 2020-11-11 03:27:11 --> Config Class Initialized
INFO - 2020-11-11 03:27:11 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:11 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:11 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:11 --> URI Class Initialized
INFO - 2020-11-11 03:27:11 --> Router Class Initialized
INFO - 2020-11-11 03:27:12 --> Output Class Initialized
INFO - 2020-11-11 03:27:12 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:12 --> Input Class Initialized
INFO - 2020-11-11 03:27:12 --> Language Class Initialized
INFO - 2020-11-11 03:27:12 --> Language Class Initialized
INFO - 2020-11-11 03:27:12 --> Config Class Initialized
INFO - 2020-11-11 03:27:12 --> Loader Class Initialized
INFO - 2020-11-11 03:27:12 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:12 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:12 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:12 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:12 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:12 --> Controller Class Initialized
DEBUG - 2020-11-11 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-11 03:27:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:27:12 --> Final output sent to browser
DEBUG - 2020-11-11 03:27:12 --> Total execution time: 0.3347
INFO - 2020-11-11 03:27:24 --> Config Class Initialized
INFO - 2020-11-11 03:27:24 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:24 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:24 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:24 --> URI Class Initialized
INFO - 2020-11-11 03:27:24 --> Router Class Initialized
INFO - 2020-11-11 03:27:24 --> Output Class Initialized
INFO - 2020-11-11 03:27:24 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:24 --> Input Class Initialized
INFO - 2020-11-11 03:27:24 --> Language Class Initialized
INFO - 2020-11-11 03:27:24 --> Language Class Initialized
INFO - 2020-11-11 03:27:24 --> Config Class Initialized
INFO - 2020-11-11 03:27:24 --> Loader Class Initialized
INFO - 2020-11-11 03:27:24 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:24 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:24 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:24 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:24 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:24 --> Controller Class Initialized
DEBUG - 2020-11-11 03:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-11 03:27:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:27:24 --> Final output sent to browser
DEBUG - 2020-11-11 03:27:24 --> Total execution time: 0.3403
INFO - 2020-11-11 03:27:28 --> Config Class Initialized
INFO - 2020-11-11 03:27:28 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:28 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:28 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:28 --> URI Class Initialized
INFO - 2020-11-11 03:27:28 --> Router Class Initialized
INFO - 2020-11-11 03:27:28 --> Output Class Initialized
INFO - 2020-11-11 03:27:28 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:28 --> Input Class Initialized
INFO - 2020-11-11 03:27:28 --> Language Class Initialized
INFO - 2020-11-11 03:27:28 --> Language Class Initialized
INFO - 2020-11-11 03:27:28 --> Config Class Initialized
INFO - 2020-11-11 03:27:28 --> Loader Class Initialized
INFO - 2020-11-11 03:27:28 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:28 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:28 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:28 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:29 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:29 --> Controller Class Initialized
DEBUG - 2020-11-11 03:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-11 03:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:27:29 --> Final output sent to browser
DEBUG - 2020-11-11 03:27:29 --> Total execution time: 0.3202
INFO - 2020-11-11 03:27:39 --> Config Class Initialized
INFO - 2020-11-11 03:27:39 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:39 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:39 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:39 --> URI Class Initialized
INFO - 2020-11-11 03:27:39 --> Router Class Initialized
INFO - 2020-11-11 03:27:39 --> Output Class Initialized
INFO - 2020-11-11 03:27:39 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:39 --> Input Class Initialized
INFO - 2020-11-11 03:27:39 --> Language Class Initialized
INFO - 2020-11-11 03:27:39 --> Language Class Initialized
INFO - 2020-11-11 03:27:39 --> Config Class Initialized
INFO - 2020-11-11 03:27:39 --> Loader Class Initialized
INFO - 2020-11-11 03:27:39 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:39 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:39 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:39 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:39 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:39 --> Controller Class Initialized
INFO - 2020-11-11 03:27:39 --> Final output sent to browser
DEBUG - 2020-11-11 03:27:39 --> Total execution time: 0.3145
INFO - 2020-11-11 03:27:43 --> Config Class Initialized
INFO - 2020-11-11 03:27:43 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:43 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:43 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:43 --> URI Class Initialized
INFO - 2020-11-11 03:27:43 --> Router Class Initialized
INFO - 2020-11-11 03:27:43 --> Output Class Initialized
INFO - 2020-11-11 03:27:43 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:43 --> Input Class Initialized
INFO - 2020-11-11 03:27:43 --> Language Class Initialized
INFO - 2020-11-11 03:27:43 --> Language Class Initialized
INFO - 2020-11-11 03:27:43 --> Config Class Initialized
INFO - 2020-11-11 03:27:43 --> Loader Class Initialized
INFO - 2020-11-11 03:27:43 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:43 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:43 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:43 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:43 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:43 --> Controller Class Initialized
DEBUG - 2020-11-11 03:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-11-11 03:27:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:27:43 --> Final output sent to browser
DEBUG - 2020-11-11 03:27:43 --> Total execution time: 0.3143
INFO - 2020-11-11 03:27:53 --> Config Class Initialized
INFO - 2020-11-11 03:27:53 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:53 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:53 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:53 --> URI Class Initialized
INFO - 2020-11-11 03:27:53 --> Router Class Initialized
INFO - 2020-11-11 03:27:53 --> Output Class Initialized
INFO - 2020-11-11 03:27:53 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:53 --> Input Class Initialized
INFO - 2020-11-11 03:27:53 --> Language Class Initialized
INFO - 2020-11-11 03:27:53 --> Language Class Initialized
INFO - 2020-11-11 03:27:53 --> Config Class Initialized
INFO - 2020-11-11 03:27:53 --> Loader Class Initialized
INFO - 2020-11-11 03:27:53 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:53 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:53 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:53 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:53 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:53 --> Controller Class Initialized
INFO - 2020-11-11 03:27:53 --> Config Class Initialized
INFO - 2020-11-11 03:27:53 --> Hooks Class Initialized
DEBUG - 2020-11-11 03:27:53 --> UTF-8 Support Enabled
INFO - 2020-11-11 03:27:53 --> Utf8 Class Initialized
INFO - 2020-11-11 03:27:53 --> URI Class Initialized
INFO - 2020-11-11 03:27:53 --> Router Class Initialized
INFO - 2020-11-11 03:27:53 --> Output Class Initialized
INFO - 2020-11-11 03:27:53 --> Security Class Initialized
DEBUG - 2020-11-11 03:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-11 03:27:53 --> Input Class Initialized
INFO - 2020-11-11 03:27:53 --> Language Class Initialized
INFO - 2020-11-11 03:27:53 --> Language Class Initialized
INFO - 2020-11-11 03:27:53 --> Config Class Initialized
INFO - 2020-11-11 03:27:53 --> Loader Class Initialized
INFO - 2020-11-11 03:27:53 --> Helper loaded: url_helper
INFO - 2020-11-11 03:27:53 --> Helper loaded: file_helper
INFO - 2020-11-11 03:27:53 --> Helper loaded: form_helper
INFO - 2020-11-11 03:27:53 --> Helper loaded: my_helper
INFO - 2020-11-11 03:27:53 --> Database Driver Class Initialized
DEBUG - 2020-11-11 03:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-11 03:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-11 03:27:53 --> Controller Class Initialized
DEBUG - 2020-11-11 03:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-11-11 03:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-11 03:27:53 --> Final output sent to browser
DEBUG - 2020-11-11 03:27:53 --> Total execution time: 0.3169
