<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-28 01:23:22 --> Config Class Initialized
INFO - 2020-10-28 01:23:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:23:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:23:22 --> Utf8 Class Initialized
INFO - 2020-10-28 01:23:22 --> URI Class Initialized
DEBUG - 2020-10-28 01:23:22 --> No URI present. Default controller set.
INFO - 2020-10-28 01:23:22 --> Router Class Initialized
INFO - 2020-10-28 01:23:22 --> Output Class Initialized
INFO - 2020-10-28 01:23:22 --> Security Class Initialized
DEBUG - 2020-10-28 01:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:23:22 --> Input Class Initialized
INFO - 2020-10-28 01:23:22 --> Language Class Initialized
INFO - 2020-10-28 01:23:22 --> Language Class Initialized
INFO - 2020-10-28 01:23:22 --> Config Class Initialized
INFO - 2020-10-28 01:23:22 --> Loader Class Initialized
INFO - 2020-10-28 01:23:22 --> Helper loaded: url_helper
INFO - 2020-10-28 01:23:22 --> Helper loaded: file_helper
INFO - 2020-10-28 01:23:22 --> Helper loaded: form_helper
INFO - 2020-10-28 01:23:22 --> Helper loaded: my_helper
INFO - 2020-10-28 01:23:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:23:23 --> Controller Class Initialized
INFO - 2020-10-28 01:23:23 --> Config Class Initialized
INFO - 2020-10-28 01:23:23 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:23:23 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:23:23 --> Utf8 Class Initialized
INFO - 2020-10-28 01:23:23 --> URI Class Initialized
INFO - 2020-10-28 01:23:23 --> Router Class Initialized
INFO - 2020-10-28 01:23:23 --> Output Class Initialized
INFO - 2020-10-28 01:23:23 --> Security Class Initialized
DEBUG - 2020-10-28 01:23:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:23:23 --> Input Class Initialized
INFO - 2020-10-28 01:23:23 --> Language Class Initialized
INFO - 2020-10-28 01:23:23 --> Language Class Initialized
INFO - 2020-10-28 01:23:23 --> Config Class Initialized
INFO - 2020-10-28 01:23:23 --> Loader Class Initialized
INFO - 2020-10-28 01:23:23 --> Helper loaded: url_helper
INFO - 2020-10-28 01:23:23 --> Helper loaded: file_helper
INFO - 2020-10-28 01:23:23 --> Helper loaded: form_helper
INFO - 2020-10-28 01:23:23 --> Helper loaded: my_helper
INFO - 2020-10-28 01:23:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:23:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:23:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:23:23 --> Controller Class Initialized
DEBUG - 2020-10-28 01:23:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:23:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:23:23 --> Final output sent to browser
DEBUG - 2020-10-28 01:23:23 --> Total execution time: 0.2035
INFO - 2020-10-28 01:23:42 --> Config Class Initialized
INFO - 2020-10-28 01:23:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:23:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:23:42 --> Utf8 Class Initialized
INFO - 2020-10-28 01:23:42 --> URI Class Initialized
DEBUG - 2020-10-28 01:23:42 --> No URI present. Default controller set.
INFO - 2020-10-28 01:23:42 --> Router Class Initialized
INFO - 2020-10-28 01:23:42 --> Output Class Initialized
INFO - 2020-10-28 01:23:42 --> Security Class Initialized
DEBUG - 2020-10-28 01:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:23:42 --> Input Class Initialized
INFO - 2020-10-28 01:23:42 --> Language Class Initialized
INFO - 2020-10-28 01:23:42 --> Language Class Initialized
INFO - 2020-10-28 01:23:42 --> Config Class Initialized
INFO - 2020-10-28 01:23:42 --> Loader Class Initialized
INFO - 2020-10-28 01:23:42 --> Helper loaded: url_helper
INFO - 2020-10-28 01:23:42 --> Helper loaded: file_helper
INFO - 2020-10-28 01:23:42 --> Helper loaded: form_helper
INFO - 2020-10-28 01:23:42 --> Helper loaded: my_helper
INFO - 2020-10-28 01:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:23:42 --> Controller Class Initialized
INFO - 2020-10-28 01:23:42 --> Config Class Initialized
INFO - 2020-10-28 01:23:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:23:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:23:42 --> Utf8 Class Initialized
INFO - 2020-10-28 01:23:42 --> URI Class Initialized
INFO - 2020-10-28 01:23:42 --> Router Class Initialized
INFO - 2020-10-28 01:23:42 --> Output Class Initialized
INFO - 2020-10-28 01:23:42 --> Security Class Initialized
DEBUG - 2020-10-28 01:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:23:42 --> Input Class Initialized
INFO - 2020-10-28 01:23:42 --> Language Class Initialized
INFO - 2020-10-28 01:23:42 --> Language Class Initialized
INFO - 2020-10-28 01:23:42 --> Config Class Initialized
INFO - 2020-10-28 01:23:42 --> Loader Class Initialized
INFO - 2020-10-28 01:23:42 --> Helper loaded: url_helper
INFO - 2020-10-28 01:23:42 --> Helper loaded: file_helper
INFO - 2020-10-28 01:23:42 --> Helper loaded: form_helper
INFO - 2020-10-28 01:23:42 --> Helper loaded: my_helper
INFO - 2020-10-28 01:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:23:42 --> Controller Class Initialized
DEBUG - 2020-10-28 01:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:23:42 --> Final output sent to browser
DEBUG - 2020-10-28 01:23:42 --> Total execution time: 0.1733
INFO - 2020-10-28 01:23:43 --> Config Class Initialized
INFO - 2020-10-28 01:23:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:23:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:23:43 --> Utf8 Class Initialized
INFO - 2020-10-28 01:23:43 --> URI Class Initialized
INFO - 2020-10-28 01:23:43 --> Router Class Initialized
INFO - 2020-10-28 01:23:43 --> Output Class Initialized
INFO - 2020-10-28 01:23:43 --> Security Class Initialized
DEBUG - 2020-10-28 01:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:23:43 --> Input Class Initialized
INFO - 2020-10-28 01:23:43 --> Language Class Initialized
INFO - 2020-10-28 01:23:43 --> Language Class Initialized
INFO - 2020-10-28 01:23:43 --> Config Class Initialized
INFO - 2020-10-28 01:23:43 --> Loader Class Initialized
INFO - 2020-10-28 01:23:43 --> Helper loaded: url_helper
INFO - 2020-10-28 01:23:43 --> Helper loaded: file_helper
INFO - 2020-10-28 01:23:43 --> Helper loaded: form_helper
INFO - 2020-10-28 01:23:43 --> Helper loaded: my_helper
INFO - 2020-10-28 01:23:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:23:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:23:43 --> Controller Class Initialized
DEBUG - 2020-10-28 01:23:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:23:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:23:43 --> Final output sent to browser
DEBUG - 2020-10-28 01:23:43 --> Total execution time: 0.1820
INFO - 2020-10-28 01:23:59 --> Config Class Initialized
INFO - 2020-10-28 01:23:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:23:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:23:59 --> Utf8 Class Initialized
INFO - 2020-10-28 01:23:59 --> URI Class Initialized
INFO - 2020-10-28 01:23:59 --> Router Class Initialized
INFO - 2020-10-28 01:23:59 --> Output Class Initialized
INFO - 2020-10-28 01:23:59 --> Security Class Initialized
DEBUG - 2020-10-28 01:23:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:23:59 --> Input Class Initialized
INFO - 2020-10-28 01:23:59 --> Language Class Initialized
INFO - 2020-10-28 01:23:59 --> Language Class Initialized
INFO - 2020-10-28 01:23:59 --> Config Class Initialized
INFO - 2020-10-28 01:23:59 --> Loader Class Initialized
INFO - 2020-10-28 01:23:59 --> Helper loaded: url_helper
INFO - 2020-10-28 01:23:59 --> Helper loaded: file_helper
INFO - 2020-10-28 01:23:59 --> Helper loaded: form_helper
INFO - 2020-10-28 01:23:59 --> Helper loaded: my_helper
INFO - 2020-10-28 01:23:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:23:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:23:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:23:59 --> Controller Class Initialized
INFO - 2020-10-28 01:23:59 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:23:59 --> Final output sent to browser
DEBUG - 2020-10-28 01:23:59 --> Total execution time: 0.1996
INFO - 2020-10-28 01:24:00 --> Config Class Initialized
INFO - 2020-10-28 01:24:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:24:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:24:01 --> Utf8 Class Initialized
INFO - 2020-10-28 01:24:01 --> URI Class Initialized
INFO - 2020-10-28 01:24:01 --> Router Class Initialized
INFO - 2020-10-28 01:24:01 --> Output Class Initialized
INFO - 2020-10-28 01:24:01 --> Security Class Initialized
DEBUG - 2020-10-28 01:24:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:24:01 --> Input Class Initialized
INFO - 2020-10-28 01:24:01 --> Language Class Initialized
INFO - 2020-10-28 01:24:01 --> Language Class Initialized
INFO - 2020-10-28 01:24:01 --> Config Class Initialized
INFO - 2020-10-28 01:24:01 --> Loader Class Initialized
INFO - 2020-10-28 01:24:01 --> Helper loaded: url_helper
INFO - 2020-10-28 01:24:01 --> Helper loaded: file_helper
INFO - 2020-10-28 01:24:01 --> Helper loaded: form_helper
INFO - 2020-10-28 01:24:01 --> Helper loaded: my_helper
INFO - 2020-10-28 01:24:01 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:24:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:24:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:24:01 --> Controller Class Initialized
DEBUG - 2020-10-28 01:24:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 01:24:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:24:01 --> Final output sent to browser
DEBUG - 2020-10-28 01:24:01 --> Total execution time: 0.2350
INFO - 2020-10-28 01:24:06 --> Config Class Initialized
INFO - 2020-10-28 01:24:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:24:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:24:06 --> Utf8 Class Initialized
INFO - 2020-10-28 01:24:06 --> URI Class Initialized
INFO - 2020-10-28 01:24:06 --> Router Class Initialized
INFO - 2020-10-28 01:24:06 --> Output Class Initialized
INFO - 2020-10-28 01:24:06 --> Security Class Initialized
DEBUG - 2020-10-28 01:24:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:24:06 --> Input Class Initialized
INFO - 2020-10-28 01:24:06 --> Language Class Initialized
INFO - 2020-10-28 01:24:06 --> Language Class Initialized
INFO - 2020-10-28 01:24:06 --> Config Class Initialized
INFO - 2020-10-28 01:24:06 --> Loader Class Initialized
INFO - 2020-10-28 01:24:06 --> Helper loaded: url_helper
INFO - 2020-10-28 01:24:06 --> Helper loaded: file_helper
INFO - 2020-10-28 01:24:06 --> Helper loaded: form_helper
INFO - 2020-10-28 01:24:06 --> Helper loaded: my_helper
INFO - 2020-10-28 01:24:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:24:07 --> Controller Class Initialized
DEBUG - 2020-10-28 01:24:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 01:24:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:24:07 --> Final output sent to browser
DEBUG - 2020-10-28 01:24:07 --> Total execution time: 0.2005
INFO - 2020-10-28 01:24:07 --> Config Class Initialized
INFO - 2020-10-28 01:24:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:24:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:24:07 --> Utf8 Class Initialized
INFO - 2020-10-28 01:24:07 --> URI Class Initialized
INFO - 2020-10-28 01:24:07 --> Router Class Initialized
INFO - 2020-10-28 01:24:07 --> Output Class Initialized
INFO - 2020-10-28 01:24:07 --> Security Class Initialized
DEBUG - 2020-10-28 01:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:24:07 --> Input Class Initialized
INFO - 2020-10-28 01:24:07 --> Language Class Initialized
INFO - 2020-10-28 01:24:07 --> Language Class Initialized
INFO - 2020-10-28 01:24:07 --> Config Class Initialized
INFO - 2020-10-28 01:24:07 --> Loader Class Initialized
INFO - 2020-10-28 01:24:07 --> Helper loaded: url_helper
INFO - 2020-10-28 01:24:07 --> Helper loaded: file_helper
INFO - 2020-10-28 01:24:07 --> Helper loaded: form_helper
INFO - 2020-10-28 01:24:07 --> Helper loaded: my_helper
INFO - 2020-10-28 01:24:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:24:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:24:07 --> Controller Class Initialized
INFO - 2020-10-28 01:24:17 --> Config Class Initialized
INFO - 2020-10-28 01:24:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:24:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:24:17 --> Utf8 Class Initialized
INFO - 2020-10-28 01:24:17 --> URI Class Initialized
INFO - 2020-10-28 01:24:17 --> Router Class Initialized
INFO - 2020-10-28 01:24:17 --> Output Class Initialized
INFO - 2020-10-28 01:24:17 --> Security Class Initialized
DEBUG - 2020-10-28 01:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:24:17 --> Input Class Initialized
INFO - 2020-10-28 01:24:17 --> Language Class Initialized
INFO - 2020-10-28 01:24:17 --> Language Class Initialized
INFO - 2020-10-28 01:24:17 --> Config Class Initialized
INFO - 2020-10-28 01:24:17 --> Loader Class Initialized
INFO - 2020-10-28 01:24:17 --> Helper loaded: url_helper
INFO - 2020-10-28 01:24:17 --> Helper loaded: file_helper
INFO - 2020-10-28 01:24:17 --> Helper loaded: form_helper
INFO - 2020-10-28 01:24:17 --> Helper loaded: my_helper
INFO - 2020-10-28 01:24:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:24:17 --> Controller Class Initialized
DEBUG - 2020-10-28 01:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:24:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:24:17 --> Final output sent to browser
DEBUG - 2020-10-28 01:24:17 --> Total execution time: 0.2286
INFO - 2020-10-28 01:24:23 --> Config Class Initialized
INFO - 2020-10-28 01:24:23 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:24:23 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:24:23 --> Utf8 Class Initialized
INFO - 2020-10-28 01:24:23 --> URI Class Initialized
INFO - 2020-10-28 01:24:23 --> Router Class Initialized
INFO - 2020-10-28 01:24:23 --> Output Class Initialized
INFO - 2020-10-28 01:24:23 --> Security Class Initialized
DEBUG - 2020-10-28 01:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:24:23 --> Input Class Initialized
INFO - 2020-10-28 01:24:23 --> Language Class Initialized
INFO - 2020-10-28 01:24:23 --> Language Class Initialized
INFO - 2020-10-28 01:24:23 --> Config Class Initialized
INFO - 2020-10-28 01:24:23 --> Loader Class Initialized
INFO - 2020-10-28 01:24:23 --> Helper loaded: url_helper
INFO - 2020-10-28 01:24:23 --> Helper loaded: file_helper
INFO - 2020-10-28 01:24:23 --> Helper loaded: form_helper
INFO - 2020-10-28 01:24:23 --> Helper loaded: my_helper
INFO - 2020-10-28 01:24:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:24:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:24:23 --> Controller Class Initialized
DEBUG - 2020-10-28 01:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 01:24:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:24:23 --> Final output sent to browser
DEBUG - 2020-10-28 01:24:23 --> Total execution time: 0.2176
INFO - 2020-10-28 01:24:52 --> Config Class Initialized
INFO - 2020-10-28 01:24:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:24:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:24:52 --> Utf8 Class Initialized
INFO - 2020-10-28 01:24:52 --> URI Class Initialized
INFO - 2020-10-28 01:24:53 --> Router Class Initialized
INFO - 2020-10-28 01:24:53 --> Output Class Initialized
INFO - 2020-10-28 01:24:53 --> Security Class Initialized
DEBUG - 2020-10-28 01:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:24:53 --> Input Class Initialized
INFO - 2020-10-28 01:24:53 --> Language Class Initialized
INFO - 2020-10-28 01:24:53 --> Language Class Initialized
INFO - 2020-10-28 01:24:53 --> Config Class Initialized
INFO - 2020-10-28 01:24:53 --> Loader Class Initialized
INFO - 2020-10-28 01:24:53 --> Helper loaded: url_helper
INFO - 2020-10-28 01:24:53 --> Helper loaded: file_helper
INFO - 2020-10-28 01:24:53 --> Helper loaded: form_helper
INFO - 2020-10-28 01:24:53 --> Helper loaded: my_helper
INFO - 2020-10-28 01:24:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:24:53 --> Controller Class Initialized
INFO - 2020-10-28 01:24:53 --> Config Class Initialized
INFO - 2020-10-28 01:24:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:24:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:24:53 --> Utf8 Class Initialized
INFO - 2020-10-28 01:24:53 --> URI Class Initialized
INFO - 2020-10-28 01:24:53 --> Router Class Initialized
INFO - 2020-10-28 01:24:53 --> Output Class Initialized
INFO - 2020-10-28 01:24:53 --> Security Class Initialized
DEBUG - 2020-10-28 01:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:24:53 --> Input Class Initialized
INFO - 2020-10-28 01:24:53 --> Language Class Initialized
INFO - 2020-10-28 01:24:53 --> Language Class Initialized
INFO - 2020-10-28 01:24:53 --> Config Class Initialized
INFO - 2020-10-28 01:24:53 --> Loader Class Initialized
INFO - 2020-10-28 01:24:53 --> Helper loaded: url_helper
INFO - 2020-10-28 01:24:53 --> Helper loaded: file_helper
INFO - 2020-10-28 01:24:53 --> Helper loaded: form_helper
INFO - 2020-10-28 01:24:53 --> Helper loaded: my_helper
INFO - 2020-10-28 01:24:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:24:53 --> Controller Class Initialized
DEBUG - 2020-10-28 01:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:24:53 --> Final output sent to browser
DEBUG - 2020-10-28 01:24:53 --> Total execution time: 0.1765
INFO - 2020-10-28 01:25:00 --> Config Class Initialized
INFO - 2020-10-28 01:25:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:00 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:00 --> URI Class Initialized
INFO - 2020-10-28 01:25:00 --> Router Class Initialized
INFO - 2020-10-28 01:25:00 --> Output Class Initialized
INFO - 2020-10-28 01:25:00 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:00 --> Input Class Initialized
INFO - 2020-10-28 01:25:00 --> Language Class Initialized
INFO - 2020-10-28 01:25:00 --> Language Class Initialized
INFO - 2020-10-28 01:25:00 --> Config Class Initialized
INFO - 2020-10-28 01:25:00 --> Loader Class Initialized
INFO - 2020-10-28 01:25:00 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:00 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:00 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:00 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:00 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:00 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-28 01:25:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:00 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:00 --> Total execution time: 0.2008
INFO - 2020-10-28 01:25:00 --> Config Class Initialized
INFO - 2020-10-28 01:25:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:01 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:01 --> URI Class Initialized
INFO - 2020-10-28 01:25:01 --> Router Class Initialized
INFO - 2020-10-28 01:25:01 --> Output Class Initialized
INFO - 2020-10-28 01:25:01 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:01 --> Input Class Initialized
INFO - 2020-10-28 01:25:01 --> Language Class Initialized
INFO - 2020-10-28 01:25:01 --> Language Class Initialized
INFO - 2020-10-28 01:25:01 --> Config Class Initialized
INFO - 2020-10-28 01:25:01 --> Loader Class Initialized
INFO - 2020-10-28 01:25:01 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:01 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:01 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:01 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:01 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:01 --> Controller Class Initialized
INFO - 2020-10-28 01:25:03 --> Config Class Initialized
INFO - 2020-10-28 01:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:03 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:03 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:03 --> URI Class Initialized
INFO - 2020-10-28 01:25:03 --> Router Class Initialized
INFO - 2020-10-28 01:25:03 --> Output Class Initialized
INFO - 2020-10-28 01:25:03 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:03 --> Input Class Initialized
INFO - 2020-10-28 01:25:03 --> Language Class Initialized
INFO - 2020-10-28 01:25:03 --> Language Class Initialized
INFO - 2020-10-28 01:25:03 --> Config Class Initialized
INFO - 2020-10-28 01:25:03 --> Loader Class Initialized
INFO - 2020-10-28 01:25:03 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:03 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:03 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:03 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:03 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:03 --> Controller Class Initialized
INFO - 2020-10-28 01:25:03 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:03 --> Total execution time: 0.1811
INFO - 2020-10-28 01:25:09 --> Config Class Initialized
INFO - 2020-10-28 01:25:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:09 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:09 --> URI Class Initialized
INFO - 2020-10-28 01:25:09 --> Router Class Initialized
INFO - 2020-10-28 01:25:09 --> Output Class Initialized
INFO - 2020-10-28 01:25:09 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:09 --> Input Class Initialized
INFO - 2020-10-28 01:25:09 --> Language Class Initialized
INFO - 2020-10-28 01:25:09 --> Language Class Initialized
INFO - 2020-10-28 01:25:09 --> Config Class Initialized
INFO - 2020-10-28 01:25:09 --> Loader Class Initialized
INFO - 2020-10-28 01:25:09 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:09 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:09 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:09 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:09 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:09 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:25:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:09 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:09 --> Total execution time: 0.1919
INFO - 2020-10-28 01:25:09 --> Config Class Initialized
INFO - 2020-10-28 01:25:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:09 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:09 --> URI Class Initialized
INFO - 2020-10-28 01:25:09 --> Router Class Initialized
INFO - 2020-10-28 01:25:09 --> Output Class Initialized
INFO - 2020-10-28 01:25:09 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:09 --> Input Class Initialized
INFO - 2020-10-28 01:25:09 --> Language Class Initialized
INFO - 2020-10-28 01:25:09 --> Language Class Initialized
INFO - 2020-10-28 01:25:09 --> Config Class Initialized
INFO - 2020-10-28 01:25:09 --> Loader Class Initialized
INFO - 2020-10-28 01:25:09 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:09 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:09 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:09 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:09 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:09 --> Controller Class Initialized
INFO - 2020-10-28 01:25:18 --> Config Class Initialized
INFO - 2020-10-28 01:25:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:18 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:18 --> URI Class Initialized
INFO - 2020-10-28 01:25:18 --> Router Class Initialized
INFO - 2020-10-28 01:25:18 --> Output Class Initialized
INFO - 2020-10-28 01:25:18 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:18 --> Input Class Initialized
INFO - 2020-10-28 01:25:18 --> Language Class Initialized
INFO - 2020-10-28 01:25:18 --> Language Class Initialized
INFO - 2020-10-28 01:25:18 --> Config Class Initialized
INFO - 2020-10-28 01:25:18 --> Loader Class Initialized
INFO - 2020-10-28 01:25:18 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:18 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:18 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:18 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:18 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-28 01:25:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:18 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:19 --> Total execution time: 0.2122
INFO - 2020-10-28 01:25:19 --> Config Class Initialized
INFO - 2020-10-28 01:25:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:19 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:19 --> URI Class Initialized
INFO - 2020-10-28 01:25:19 --> Router Class Initialized
INFO - 2020-10-28 01:25:19 --> Output Class Initialized
INFO - 2020-10-28 01:25:19 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:19 --> Input Class Initialized
INFO - 2020-10-28 01:25:19 --> Language Class Initialized
INFO - 2020-10-28 01:25:19 --> Language Class Initialized
INFO - 2020-10-28 01:25:19 --> Config Class Initialized
INFO - 2020-10-28 01:25:19 --> Loader Class Initialized
INFO - 2020-10-28 01:25:19 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:19 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:19 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:19 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:19 --> Controller Class Initialized
INFO - 2020-10-28 01:25:22 --> Config Class Initialized
INFO - 2020-10-28 01:25:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:22 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:22 --> URI Class Initialized
INFO - 2020-10-28 01:25:22 --> Router Class Initialized
INFO - 2020-10-28 01:25:22 --> Output Class Initialized
INFO - 2020-10-28 01:25:22 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:22 --> Input Class Initialized
INFO - 2020-10-28 01:25:22 --> Language Class Initialized
INFO - 2020-10-28 01:25:22 --> Language Class Initialized
INFO - 2020-10-28 01:25:22 --> Config Class Initialized
INFO - 2020-10-28 01:25:22 --> Loader Class Initialized
INFO - 2020-10-28 01:25:22 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:22 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:22 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:22 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:22 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:22 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 01:25:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:22 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:22 --> Total execution time: 0.2135
INFO - 2020-10-28 01:25:22 --> Config Class Initialized
INFO - 2020-10-28 01:25:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:22 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:22 --> URI Class Initialized
INFO - 2020-10-28 01:25:22 --> Router Class Initialized
INFO - 2020-10-28 01:25:22 --> Output Class Initialized
INFO - 2020-10-28 01:25:22 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:22 --> Input Class Initialized
INFO - 2020-10-28 01:25:22 --> Language Class Initialized
INFO - 2020-10-28 01:25:22 --> Language Class Initialized
INFO - 2020-10-28 01:25:22 --> Config Class Initialized
INFO - 2020-10-28 01:25:22 --> Loader Class Initialized
INFO - 2020-10-28 01:25:22 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:22 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:22 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:22 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:22 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:22 --> Controller Class Initialized
INFO - 2020-10-28 01:25:26 --> Config Class Initialized
INFO - 2020-10-28 01:25:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:26 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:26 --> URI Class Initialized
INFO - 2020-10-28 01:25:26 --> Router Class Initialized
INFO - 2020-10-28 01:25:26 --> Output Class Initialized
INFO - 2020-10-28 01:25:26 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:26 --> Input Class Initialized
INFO - 2020-10-28 01:25:26 --> Language Class Initialized
INFO - 2020-10-28 01:25:26 --> Language Class Initialized
INFO - 2020-10-28 01:25:26 --> Config Class Initialized
INFO - 2020-10-28 01:25:26 --> Loader Class Initialized
INFO - 2020-10-28 01:25:26 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:26 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:26 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:26 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:26 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 01:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:26 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:26 --> Total execution time: 0.1896
INFO - 2020-10-28 01:25:26 --> Config Class Initialized
INFO - 2020-10-28 01:25:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:26 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:26 --> URI Class Initialized
INFO - 2020-10-28 01:25:26 --> Router Class Initialized
INFO - 2020-10-28 01:25:26 --> Output Class Initialized
INFO - 2020-10-28 01:25:26 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:26 --> Input Class Initialized
INFO - 2020-10-28 01:25:26 --> Language Class Initialized
INFO - 2020-10-28 01:25:26 --> Language Class Initialized
INFO - 2020-10-28 01:25:26 --> Config Class Initialized
INFO - 2020-10-28 01:25:26 --> Loader Class Initialized
INFO - 2020-10-28 01:25:26 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:26 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:26 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:26 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:27 --> Controller Class Initialized
INFO - 2020-10-28 01:25:27 --> Config Class Initialized
INFO - 2020-10-28 01:25:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:27 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:27 --> URI Class Initialized
INFO - 2020-10-28 01:25:27 --> Router Class Initialized
INFO - 2020-10-28 01:25:27 --> Output Class Initialized
INFO - 2020-10-28 01:25:27 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:27 --> Input Class Initialized
INFO - 2020-10-28 01:25:28 --> Language Class Initialized
INFO - 2020-10-28 01:25:28 --> Language Class Initialized
INFO - 2020-10-28 01:25:28 --> Config Class Initialized
INFO - 2020-10-28 01:25:28 --> Loader Class Initialized
INFO - 2020-10-28 01:25:28 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:28 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:28 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:28 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:28 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:28 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 01:25:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:28 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:28 --> Total execution time: 0.2147
INFO - 2020-10-28 01:25:28 --> Config Class Initialized
INFO - 2020-10-28 01:25:28 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:28 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:28 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:28 --> URI Class Initialized
INFO - 2020-10-28 01:25:28 --> Router Class Initialized
INFO - 2020-10-28 01:25:28 --> Output Class Initialized
INFO - 2020-10-28 01:25:28 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:28 --> Input Class Initialized
INFO - 2020-10-28 01:25:28 --> Language Class Initialized
INFO - 2020-10-28 01:25:28 --> Language Class Initialized
INFO - 2020-10-28 01:25:28 --> Config Class Initialized
INFO - 2020-10-28 01:25:28 --> Loader Class Initialized
INFO - 2020-10-28 01:25:28 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:28 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:28 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:28 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:28 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:28 --> Controller Class Initialized
INFO - 2020-10-28 01:25:30 --> Config Class Initialized
INFO - 2020-10-28 01:25:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:30 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:30 --> URI Class Initialized
INFO - 2020-10-28 01:25:30 --> Router Class Initialized
INFO - 2020-10-28 01:25:30 --> Output Class Initialized
INFO - 2020-10-28 01:25:30 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:30 --> Input Class Initialized
INFO - 2020-10-28 01:25:30 --> Language Class Initialized
INFO - 2020-10-28 01:25:30 --> Language Class Initialized
INFO - 2020-10-28 01:25:30 --> Config Class Initialized
INFO - 2020-10-28 01:25:30 --> Loader Class Initialized
INFO - 2020-10-28 01:25:30 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:30 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:30 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:30 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:30 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-28 01:25:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:30 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:30 --> Total execution time: 0.1958
INFO - 2020-10-28 01:25:30 --> Config Class Initialized
INFO - 2020-10-28 01:25:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:30 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:30 --> URI Class Initialized
INFO - 2020-10-28 01:25:30 --> Router Class Initialized
INFO - 2020-10-28 01:25:30 --> Output Class Initialized
INFO - 2020-10-28 01:25:30 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:30 --> Input Class Initialized
INFO - 2020-10-28 01:25:30 --> Language Class Initialized
INFO - 2020-10-28 01:25:30 --> Language Class Initialized
INFO - 2020-10-28 01:25:30 --> Config Class Initialized
INFO - 2020-10-28 01:25:30 --> Loader Class Initialized
INFO - 2020-10-28 01:25:30 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:30 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:30 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:30 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:30 --> Controller Class Initialized
INFO - 2020-10-28 01:25:31 --> Config Class Initialized
INFO - 2020-10-28 01:25:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:31 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:31 --> URI Class Initialized
INFO - 2020-10-28 01:25:31 --> Router Class Initialized
INFO - 2020-10-28 01:25:31 --> Output Class Initialized
INFO - 2020-10-28 01:25:31 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:31 --> Input Class Initialized
INFO - 2020-10-28 01:25:31 --> Language Class Initialized
INFO - 2020-10-28 01:25:31 --> Language Class Initialized
INFO - 2020-10-28 01:25:31 --> Config Class Initialized
INFO - 2020-10-28 01:25:31 --> Loader Class Initialized
INFO - 2020-10-28 01:25:31 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:31 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:31 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:31 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:31 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-28 01:25:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:31 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:31 --> Total execution time: 0.2323
INFO - 2020-10-28 01:25:31 --> Config Class Initialized
INFO - 2020-10-28 01:25:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:31 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:31 --> URI Class Initialized
INFO - 2020-10-28 01:25:31 --> Router Class Initialized
INFO - 2020-10-28 01:25:31 --> Output Class Initialized
INFO - 2020-10-28 01:25:31 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:31 --> Input Class Initialized
INFO - 2020-10-28 01:25:31 --> Language Class Initialized
INFO - 2020-10-28 01:25:31 --> Language Class Initialized
INFO - 2020-10-28 01:25:31 --> Config Class Initialized
INFO - 2020-10-28 01:25:31 --> Loader Class Initialized
INFO - 2020-10-28 01:25:31 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:31 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:31 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:31 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:31 --> Controller Class Initialized
INFO - 2020-10-28 01:25:32 --> Config Class Initialized
INFO - 2020-10-28 01:25:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:32 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:32 --> URI Class Initialized
INFO - 2020-10-28 01:25:32 --> Router Class Initialized
INFO - 2020-10-28 01:25:32 --> Output Class Initialized
INFO - 2020-10-28 01:25:32 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:32 --> Input Class Initialized
INFO - 2020-10-28 01:25:32 --> Language Class Initialized
INFO - 2020-10-28 01:25:32 --> Language Class Initialized
INFO - 2020-10-28 01:25:32 --> Config Class Initialized
INFO - 2020-10-28 01:25:32 --> Loader Class Initialized
INFO - 2020-10-28 01:25:32 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:32 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:32 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:32 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:32 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:25:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:32 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:32 --> Total execution time: 0.1907
INFO - 2020-10-28 01:25:35 --> Config Class Initialized
INFO - 2020-10-28 01:25:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:35 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:35 --> URI Class Initialized
INFO - 2020-10-28 01:25:35 --> Router Class Initialized
INFO - 2020-10-28 01:25:35 --> Output Class Initialized
INFO - 2020-10-28 01:25:35 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:35 --> Input Class Initialized
INFO - 2020-10-28 01:25:35 --> Language Class Initialized
INFO - 2020-10-28 01:25:35 --> Language Class Initialized
INFO - 2020-10-28 01:25:35 --> Config Class Initialized
INFO - 2020-10-28 01:25:35 --> Loader Class Initialized
INFO - 2020-10-28 01:25:35 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:35 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:35 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:35 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:35 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:25:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:35 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:35 --> Total execution time: 0.1762
INFO - 2020-10-28 01:25:35 --> Config Class Initialized
INFO - 2020-10-28 01:25:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:35 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:35 --> URI Class Initialized
INFO - 2020-10-28 01:25:35 --> Router Class Initialized
INFO - 2020-10-28 01:25:35 --> Output Class Initialized
INFO - 2020-10-28 01:25:35 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:35 --> Input Class Initialized
INFO - 2020-10-28 01:25:35 --> Language Class Initialized
INFO - 2020-10-28 01:25:35 --> Language Class Initialized
INFO - 2020-10-28 01:25:35 --> Config Class Initialized
INFO - 2020-10-28 01:25:35 --> Loader Class Initialized
INFO - 2020-10-28 01:25:35 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:35 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:35 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:35 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:35 --> Controller Class Initialized
INFO - 2020-10-28 01:25:37 --> Config Class Initialized
INFO - 2020-10-28 01:25:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:37 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:37 --> URI Class Initialized
INFO - 2020-10-28 01:25:37 --> Router Class Initialized
INFO - 2020-10-28 01:25:37 --> Output Class Initialized
INFO - 2020-10-28 01:25:37 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:37 --> Input Class Initialized
INFO - 2020-10-28 01:25:37 --> Language Class Initialized
INFO - 2020-10-28 01:25:37 --> Language Class Initialized
INFO - 2020-10-28 01:25:37 --> Config Class Initialized
INFO - 2020-10-28 01:25:37 --> Loader Class Initialized
INFO - 2020-10-28 01:25:37 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:37 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:37 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:37 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:37 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-10-28 01:25:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:37 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:37 --> Total execution time: 0.1922
INFO - 2020-10-28 01:25:51 --> Config Class Initialized
INFO - 2020-10-28 01:25:51 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:51 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:51 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:51 --> URI Class Initialized
INFO - 2020-10-28 01:25:51 --> Router Class Initialized
INFO - 2020-10-28 01:25:51 --> Output Class Initialized
INFO - 2020-10-28 01:25:51 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:51 --> Input Class Initialized
INFO - 2020-10-28 01:25:51 --> Language Class Initialized
INFO - 2020-10-28 01:25:51 --> Language Class Initialized
INFO - 2020-10-28 01:25:51 --> Config Class Initialized
INFO - 2020-10-28 01:25:51 --> Loader Class Initialized
INFO - 2020-10-28 01:25:51 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:51 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:51 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:51 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:51 --> Controller Class Initialized
INFO - 2020-10-28 01:25:51 --> Config Class Initialized
INFO - 2020-10-28 01:25:51 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:51 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:51 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:51 --> URI Class Initialized
INFO - 2020-10-28 01:25:51 --> Router Class Initialized
INFO - 2020-10-28 01:25:51 --> Output Class Initialized
INFO - 2020-10-28 01:25:51 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:51 --> Input Class Initialized
INFO - 2020-10-28 01:25:51 --> Language Class Initialized
INFO - 2020-10-28 01:25:51 --> Language Class Initialized
INFO - 2020-10-28 01:25:51 --> Config Class Initialized
INFO - 2020-10-28 01:25:51 --> Loader Class Initialized
INFO - 2020-10-28 01:25:51 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:51 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:51 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:51 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:51 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:51 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:51 --> Total execution time: 0.1690
INFO - 2020-10-28 01:25:52 --> Config Class Initialized
INFO - 2020-10-28 01:25:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:52 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:52 --> URI Class Initialized
INFO - 2020-10-28 01:25:52 --> Router Class Initialized
INFO - 2020-10-28 01:25:52 --> Output Class Initialized
INFO - 2020-10-28 01:25:52 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:52 --> Input Class Initialized
INFO - 2020-10-28 01:25:52 --> Language Class Initialized
INFO - 2020-10-28 01:25:52 --> Language Class Initialized
INFO - 2020-10-28 01:25:52 --> Config Class Initialized
INFO - 2020-10-28 01:25:52 --> Loader Class Initialized
INFO - 2020-10-28 01:25:52 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:52 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:52 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:52 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:52 --> Controller Class Initialized
INFO - 2020-10-28 01:25:59 --> Config Class Initialized
INFO - 2020-10-28 01:25:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:59 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:59 --> URI Class Initialized
INFO - 2020-10-28 01:25:59 --> Router Class Initialized
INFO - 2020-10-28 01:25:59 --> Output Class Initialized
INFO - 2020-10-28 01:25:59 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:59 --> Input Class Initialized
INFO - 2020-10-28 01:25:59 --> Language Class Initialized
INFO - 2020-10-28 01:25:59 --> Language Class Initialized
INFO - 2020-10-28 01:25:59 --> Config Class Initialized
INFO - 2020-10-28 01:25:59 --> Loader Class Initialized
INFO - 2020-10-28 01:25:59 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:59 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:59 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:59 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:59 --> Controller Class Initialized
INFO - 2020-10-28 01:25:59 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:25:59 --> Config Class Initialized
INFO - 2020-10-28 01:25:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:25:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:25:59 --> Utf8 Class Initialized
INFO - 2020-10-28 01:25:59 --> URI Class Initialized
INFO - 2020-10-28 01:25:59 --> Router Class Initialized
INFO - 2020-10-28 01:25:59 --> Output Class Initialized
INFO - 2020-10-28 01:25:59 --> Security Class Initialized
DEBUG - 2020-10-28 01:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:25:59 --> Input Class Initialized
INFO - 2020-10-28 01:25:59 --> Language Class Initialized
INFO - 2020-10-28 01:25:59 --> Language Class Initialized
INFO - 2020-10-28 01:25:59 --> Config Class Initialized
INFO - 2020-10-28 01:25:59 --> Loader Class Initialized
INFO - 2020-10-28 01:25:59 --> Helper loaded: url_helper
INFO - 2020-10-28 01:25:59 --> Helper loaded: file_helper
INFO - 2020-10-28 01:25:59 --> Helper loaded: form_helper
INFO - 2020-10-28 01:25:59 --> Helper loaded: my_helper
INFO - 2020-10-28 01:25:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:25:59 --> Controller Class Initialized
DEBUG - 2020-10-28 01:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:25:59 --> Final output sent to browser
DEBUG - 2020-10-28 01:25:59 --> Total execution time: 0.1745
INFO - 2020-10-28 01:26:18 --> Config Class Initialized
INFO - 2020-10-28 01:26:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:18 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:18 --> URI Class Initialized
INFO - 2020-10-28 01:26:18 --> Router Class Initialized
INFO - 2020-10-28 01:26:18 --> Output Class Initialized
INFO - 2020-10-28 01:26:18 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:18 --> Input Class Initialized
INFO - 2020-10-28 01:26:18 --> Language Class Initialized
INFO - 2020-10-28 01:26:18 --> Language Class Initialized
INFO - 2020-10-28 01:26:18 --> Config Class Initialized
INFO - 2020-10-28 01:26:19 --> Loader Class Initialized
INFO - 2020-10-28 01:26:19 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:19 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:19 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:19 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:19 --> Controller Class Initialized
INFO - 2020-10-28 01:26:19 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:26:19 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:19 --> Total execution time: 0.1784
INFO - 2020-10-28 01:26:19 --> Config Class Initialized
INFO - 2020-10-28 01:26:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:19 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:19 --> URI Class Initialized
INFO - 2020-10-28 01:26:19 --> Router Class Initialized
INFO - 2020-10-28 01:26:19 --> Output Class Initialized
INFO - 2020-10-28 01:26:19 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:19 --> Input Class Initialized
INFO - 2020-10-28 01:26:19 --> Language Class Initialized
INFO - 2020-10-28 01:26:19 --> Language Class Initialized
INFO - 2020-10-28 01:26:19 --> Config Class Initialized
INFO - 2020-10-28 01:26:19 --> Loader Class Initialized
INFO - 2020-10-28 01:26:19 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:19 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:19 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:19 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:19 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 01:26:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:20 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:20 --> Total execution time: 0.2179
INFO - 2020-10-28 01:26:24 --> Config Class Initialized
INFO - 2020-10-28 01:26:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:24 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:24 --> URI Class Initialized
INFO - 2020-10-28 01:26:24 --> Router Class Initialized
INFO - 2020-10-28 01:26:24 --> Output Class Initialized
INFO - 2020-10-28 01:26:24 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:24 --> Input Class Initialized
INFO - 2020-10-28 01:26:24 --> Language Class Initialized
INFO - 2020-10-28 01:26:24 --> Language Class Initialized
INFO - 2020-10-28 01:26:24 --> Config Class Initialized
INFO - 2020-10-28 01:26:24 --> Loader Class Initialized
INFO - 2020-10-28 01:26:24 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:24 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:24 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:24 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:24 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:24 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:24 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:24 --> Total execution time: 0.2267
INFO - 2020-10-28 01:26:30 --> Config Class Initialized
INFO - 2020-10-28 01:26:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:30 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:30 --> URI Class Initialized
INFO - 2020-10-28 01:26:30 --> Router Class Initialized
INFO - 2020-10-28 01:26:30 --> Output Class Initialized
INFO - 2020-10-28 01:26:30 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:30 --> Input Class Initialized
INFO - 2020-10-28 01:26:30 --> Language Class Initialized
INFO - 2020-10-28 01:26:30 --> Language Class Initialized
INFO - 2020-10-28 01:26:30 --> Config Class Initialized
INFO - 2020-10-28 01:26:30 --> Loader Class Initialized
INFO - 2020-10-28 01:26:30 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:30 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:30 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:30 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:30 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:26:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:30 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:30 --> Total execution time: 0.2554
INFO - 2020-10-28 01:26:30 --> Config Class Initialized
INFO - 2020-10-28 01:26:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:30 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:30 --> URI Class Initialized
INFO - 2020-10-28 01:26:30 --> Router Class Initialized
INFO - 2020-10-28 01:26:30 --> Output Class Initialized
INFO - 2020-10-28 01:26:30 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:30 --> Input Class Initialized
INFO - 2020-10-28 01:26:30 --> Language Class Initialized
INFO - 2020-10-28 01:26:30 --> Language Class Initialized
INFO - 2020-10-28 01:26:30 --> Config Class Initialized
INFO - 2020-10-28 01:26:30 --> Loader Class Initialized
INFO - 2020-10-28 01:26:30 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:30 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:30 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:30 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:30 --> Controller Class Initialized
INFO - 2020-10-28 01:26:32 --> Config Class Initialized
INFO - 2020-10-28 01:26:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:32 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:32 --> URI Class Initialized
INFO - 2020-10-28 01:26:32 --> Router Class Initialized
INFO - 2020-10-28 01:26:32 --> Output Class Initialized
INFO - 2020-10-28 01:26:32 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:32 --> Input Class Initialized
INFO - 2020-10-28 01:26:32 --> Language Class Initialized
INFO - 2020-10-28 01:26:32 --> Language Class Initialized
INFO - 2020-10-28 01:26:32 --> Config Class Initialized
INFO - 2020-10-28 01:26:32 --> Loader Class Initialized
INFO - 2020-10-28 01:26:32 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:32 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:32 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:32 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:32 --> Controller Class Initialized
INFO - 2020-10-28 01:26:32 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:32 --> Total execution time: 0.1837
INFO - 2020-10-28 01:26:34 --> Config Class Initialized
INFO - 2020-10-28 01:26:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:34 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:34 --> URI Class Initialized
INFO - 2020-10-28 01:26:34 --> Router Class Initialized
INFO - 2020-10-28 01:26:34 --> Output Class Initialized
INFO - 2020-10-28 01:26:34 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:34 --> Input Class Initialized
INFO - 2020-10-28 01:26:34 --> Language Class Initialized
INFO - 2020-10-28 01:26:35 --> Language Class Initialized
INFO - 2020-10-28 01:26:35 --> Config Class Initialized
INFO - 2020-10-28 01:26:35 --> Loader Class Initialized
INFO - 2020-10-28 01:26:35 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:35 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:35 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:35 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:35 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2020-10-28 01:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:35 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:35 --> Total execution time: 0.2337
INFO - 2020-10-28 01:26:37 --> Config Class Initialized
INFO - 2020-10-28 01:26:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:37 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:37 --> URI Class Initialized
INFO - 2020-10-28 01:26:37 --> Router Class Initialized
INFO - 2020-10-28 01:26:37 --> Output Class Initialized
INFO - 2020-10-28 01:26:37 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:37 --> Input Class Initialized
INFO - 2020-10-28 01:26:37 --> Language Class Initialized
INFO - 2020-10-28 01:26:37 --> Language Class Initialized
INFO - 2020-10-28 01:26:37 --> Config Class Initialized
INFO - 2020-10-28 01:26:37 --> Loader Class Initialized
INFO - 2020-10-28 01:26:37 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:37 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:37 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:37 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:37 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-10-28 01:26:37 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:37 --> Total execution time: 0.2154
INFO - 2020-10-28 01:26:41 --> Config Class Initialized
INFO - 2020-10-28 01:26:41 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:41 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:41 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:41 --> URI Class Initialized
INFO - 2020-10-28 01:26:41 --> Router Class Initialized
INFO - 2020-10-28 01:26:41 --> Output Class Initialized
INFO - 2020-10-28 01:26:41 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:41 --> Input Class Initialized
INFO - 2020-10-28 01:26:41 --> Language Class Initialized
INFO - 2020-10-28 01:26:41 --> Language Class Initialized
INFO - 2020-10-28 01:26:41 --> Config Class Initialized
INFO - 2020-10-28 01:26:41 --> Loader Class Initialized
INFO - 2020-10-28 01:26:41 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:41 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:41 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:41 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:41 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:41 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-28 01:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:41 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:41 --> Total execution time: 0.2267
INFO - 2020-10-28 01:26:45 --> Config Class Initialized
INFO - 2020-10-28 01:26:45 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:45 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:45 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:45 --> URI Class Initialized
INFO - 2020-10-28 01:26:45 --> Router Class Initialized
INFO - 2020-10-28 01:26:45 --> Output Class Initialized
INFO - 2020-10-28 01:26:45 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:45 --> Input Class Initialized
INFO - 2020-10-28 01:26:45 --> Language Class Initialized
INFO - 2020-10-28 01:26:45 --> Language Class Initialized
INFO - 2020-10-28 01:26:45 --> Config Class Initialized
INFO - 2020-10-28 01:26:45 --> Loader Class Initialized
INFO - 2020-10-28 01:26:45 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:45 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:45 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:45 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:45 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:45 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_sp/views/list.php
DEBUG - 2020-10-28 01:26:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:45 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:45 --> Total execution time: 0.2053
INFO - 2020-10-28 01:26:46 --> Config Class Initialized
INFO - 2020-10-28 01:26:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:46 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:46 --> URI Class Initialized
INFO - 2020-10-28 01:26:46 --> Router Class Initialized
INFO - 2020-10-28 01:26:46 --> Output Class Initialized
INFO - 2020-10-28 01:26:46 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:46 --> Input Class Initialized
INFO - 2020-10-28 01:26:46 --> Language Class Initialized
INFO - 2020-10-28 01:26:46 --> Language Class Initialized
INFO - 2020-10-28 01:26:46 --> Config Class Initialized
INFO - 2020-10-28 01:26:46 --> Loader Class Initialized
INFO - 2020-10-28 01:26:46 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:46 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:46 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:46 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:46 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_sikap_so/views/list.php
DEBUG - 2020-10-28 01:26:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:46 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:46 --> Total execution time: 0.2325
INFO - 2020-10-28 01:26:49 --> Config Class Initialized
INFO - 2020-10-28 01:26:49 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:49 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:49 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:49 --> URI Class Initialized
INFO - 2020-10-28 01:26:49 --> Router Class Initialized
INFO - 2020-10-28 01:26:49 --> Output Class Initialized
INFO - 2020-10-28 01:26:49 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:49 --> Input Class Initialized
INFO - 2020-10-28 01:26:49 --> Language Class Initialized
INFO - 2020-10-28 01:26:49 --> Language Class Initialized
INFO - 2020-10-28 01:26:49 --> Config Class Initialized
INFO - 2020-10-28 01:26:49 --> Loader Class Initialized
INFO - 2020-10-28 01:26:49 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:49 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:49 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:49 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:49 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:49 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-10-28 01:26:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:49 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:49 --> Total execution time: 0.2263
INFO - 2020-10-28 01:26:52 --> Config Class Initialized
INFO - 2020-10-28 01:26:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:52 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:52 --> URI Class Initialized
INFO - 2020-10-28 01:26:52 --> Router Class Initialized
INFO - 2020-10-28 01:26:52 --> Output Class Initialized
INFO - 2020-10-28 01:26:52 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:52 --> Input Class Initialized
INFO - 2020-10-28 01:26:52 --> Language Class Initialized
INFO - 2020-10-28 01:26:52 --> Language Class Initialized
INFO - 2020-10-28 01:26:52 --> Config Class Initialized
INFO - 2020-10-28 01:26:52 --> Loader Class Initialized
INFO - 2020-10-28 01:26:52 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:52 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:52 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:52 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:53 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2020-10-28 01:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:53 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:53 --> Total execution time: 0.1971
INFO - 2020-10-28 01:26:53 --> Config Class Initialized
INFO - 2020-10-28 01:26:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:53 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:53 --> URI Class Initialized
INFO - 2020-10-28 01:26:53 --> Router Class Initialized
INFO - 2020-10-28 01:26:53 --> Output Class Initialized
INFO - 2020-10-28 01:26:53 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:53 --> Input Class Initialized
INFO - 2020-10-28 01:26:53 --> Language Class Initialized
INFO - 2020-10-28 01:26:53 --> Language Class Initialized
INFO - 2020-10-28 01:26:53 --> Config Class Initialized
INFO - 2020-10-28 01:26:53 --> Loader Class Initialized
INFO - 2020-10-28 01:26:53 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:53 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:53 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:53 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:54 --> Controller Class Initialized
DEBUG - 2020-10-28 01:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-10-28 01:26:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:26:54 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:54 --> Total execution time: 0.2630
INFO - 2020-10-28 01:26:56 --> Config Class Initialized
INFO - 2020-10-28 01:26:56 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:26:56 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:26:56 --> Utf8 Class Initialized
INFO - 2020-10-28 01:26:56 --> URI Class Initialized
INFO - 2020-10-28 01:26:56 --> Router Class Initialized
INFO - 2020-10-28 01:26:56 --> Output Class Initialized
INFO - 2020-10-28 01:26:56 --> Security Class Initialized
DEBUG - 2020-10-28 01:26:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:26:56 --> Input Class Initialized
INFO - 2020-10-28 01:26:56 --> Language Class Initialized
INFO - 2020-10-28 01:26:56 --> Language Class Initialized
INFO - 2020-10-28 01:26:56 --> Config Class Initialized
INFO - 2020-10-28 01:26:56 --> Loader Class Initialized
INFO - 2020-10-28 01:26:56 --> Helper loaded: url_helper
INFO - 2020-10-28 01:26:56 --> Helper loaded: file_helper
INFO - 2020-10-28 01:26:56 --> Helper loaded: form_helper
INFO - 2020-10-28 01:26:56 --> Helper loaded: my_helper
INFO - 2020-10-28 01:26:56 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:26:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:26:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:26:56 --> Controller Class Initialized
INFO - 2020-10-28 01:26:56 --> Final output sent to browser
DEBUG - 2020-10-28 01:26:56 --> Total execution time: 0.1652
INFO - 2020-10-28 01:27:00 --> Config Class Initialized
INFO - 2020-10-28 01:27:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:00 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:00 --> URI Class Initialized
INFO - 2020-10-28 01:27:00 --> Router Class Initialized
INFO - 2020-10-28 01:27:00 --> Output Class Initialized
INFO - 2020-10-28 01:27:00 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:00 --> Input Class Initialized
INFO - 2020-10-28 01:27:00 --> Language Class Initialized
INFO - 2020-10-28 01:27:00 --> Language Class Initialized
INFO - 2020-10-28 01:27:00 --> Config Class Initialized
INFO - 2020-10-28 01:27:00 --> Loader Class Initialized
INFO - 2020-10-28 01:27:00 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:00 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:00 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:00 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:00 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:00 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2020-10-28 01:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:00 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:00 --> Total execution time: 0.2048
INFO - 2020-10-28 01:27:00 --> Config Class Initialized
INFO - 2020-10-28 01:27:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:00 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:00 --> URI Class Initialized
INFO - 2020-10-28 01:27:00 --> Router Class Initialized
INFO - 2020-10-28 01:27:00 --> Output Class Initialized
INFO - 2020-10-28 01:27:00 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:00 --> Input Class Initialized
INFO - 2020-10-28 01:27:00 --> Language Class Initialized
INFO - 2020-10-28 01:27:00 --> Language Class Initialized
INFO - 2020-10-28 01:27:00 --> Config Class Initialized
INFO - 2020-10-28 01:27:00 --> Loader Class Initialized
INFO - 2020-10-28 01:27:00 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:00 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:00 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:00 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:00 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:00 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_prestasi/views/list.php
DEBUG - 2020-10-28 01:27:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:01 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:01 --> Total execution time: 0.2308
INFO - 2020-10-28 01:27:01 --> Config Class Initialized
INFO - 2020-10-28 01:27:01 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:01 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:01 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:01 --> URI Class Initialized
INFO - 2020-10-28 01:27:01 --> Router Class Initialized
INFO - 2020-10-28 01:27:01 --> Output Class Initialized
INFO - 2020-10-28 01:27:01 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:01 --> Input Class Initialized
INFO - 2020-10-28 01:27:01 --> Language Class Initialized
INFO - 2020-10-28 01:27:01 --> Language Class Initialized
INFO - 2020-10-28 01:27:01 --> Config Class Initialized
INFO - 2020-10-28 01:27:01 --> Loader Class Initialized
INFO - 2020-10-28 01:27:01 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:01 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:01 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:01 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:01 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:01 --> Controller Class Initialized
INFO - 2020-10-28 01:27:03 --> Config Class Initialized
INFO - 2020-10-28 01:27:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:03 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:03 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:03 --> URI Class Initialized
INFO - 2020-10-28 01:27:03 --> Router Class Initialized
INFO - 2020-10-28 01:27:03 --> Output Class Initialized
INFO - 2020-10-28 01:27:03 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:03 --> Input Class Initialized
INFO - 2020-10-28 01:27:03 --> Language Class Initialized
INFO - 2020-10-28 01:27:03 --> Language Class Initialized
INFO - 2020-10-28 01:27:03 --> Config Class Initialized
INFO - 2020-10-28 01:27:03 --> Loader Class Initialized
INFO - 2020-10-28 01:27:03 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:03 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:03 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:03 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:03 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:03 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-10-28 01:27:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:03 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:03 --> Total execution time: 0.2459
INFO - 2020-10-28 01:27:04 --> Config Class Initialized
INFO - 2020-10-28 01:27:04 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:04 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:04 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:04 --> URI Class Initialized
INFO - 2020-10-28 01:27:04 --> Router Class Initialized
INFO - 2020-10-28 01:27:04 --> Output Class Initialized
INFO - 2020-10-28 01:27:04 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:04 --> Input Class Initialized
INFO - 2020-10-28 01:27:04 --> Language Class Initialized
INFO - 2020-10-28 01:27:04 --> Language Class Initialized
INFO - 2020-10-28 01:27:05 --> Config Class Initialized
INFO - 2020-10-28 01:27:05 --> Loader Class Initialized
INFO - 2020-10-28 01:27:05 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:05 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:05 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:05 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:05 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:27:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:05 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:05 --> Total execution time: 0.2089
INFO - 2020-10-28 01:27:06 --> Config Class Initialized
INFO - 2020-10-28 01:27:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:06 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:06 --> URI Class Initialized
INFO - 2020-10-28 01:27:06 --> Router Class Initialized
INFO - 2020-10-28 01:27:06 --> Output Class Initialized
INFO - 2020-10-28 01:27:06 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:06 --> Input Class Initialized
INFO - 2020-10-28 01:27:06 --> Language Class Initialized
INFO - 2020-10-28 01:27:06 --> Language Class Initialized
INFO - 2020-10-28 01:27:06 --> Config Class Initialized
INFO - 2020-10-28 01:27:06 --> Loader Class Initialized
INFO - 2020-10-28 01:27:06 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:06 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:06 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:06 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:06 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:27:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:06 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:06 --> Total execution time: 0.1982
INFO - 2020-10-28 01:27:06 --> Config Class Initialized
INFO - 2020-10-28 01:27:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:06 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:06 --> URI Class Initialized
INFO - 2020-10-28 01:27:06 --> Router Class Initialized
INFO - 2020-10-28 01:27:06 --> Output Class Initialized
INFO - 2020-10-28 01:27:07 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:07 --> Input Class Initialized
INFO - 2020-10-28 01:27:07 --> Language Class Initialized
INFO - 2020-10-28 01:27:07 --> Language Class Initialized
INFO - 2020-10-28 01:27:07 --> Config Class Initialized
INFO - 2020-10-28 01:27:07 --> Loader Class Initialized
INFO - 2020-10-28 01:27:07 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:07 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:07 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:07 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:07 --> Controller Class Initialized
INFO - 2020-10-28 01:27:09 --> Config Class Initialized
INFO - 2020-10-28 01:27:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:09 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:09 --> URI Class Initialized
INFO - 2020-10-28 01:27:09 --> Router Class Initialized
INFO - 2020-10-28 01:27:10 --> Output Class Initialized
INFO - 2020-10-28 01:27:10 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:10 --> Input Class Initialized
INFO - 2020-10-28 01:27:10 --> Language Class Initialized
INFO - 2020-10-28 01:27:10 --> Language Class Initialized
INFO - 2020-10-28 01:27:10 --> Config Class Initialized
INFO - 2020-10-28 01:27:10 --> Loader Class Initialized
INFO - 2020-10-28 01:27:10 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:10 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:10 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:10 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:10 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:10 --> Controller Class Initialized
INFO - 2020-10-28 01:27:10 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:10 --> Total execution time: 0.1717
INFO - 2020-10-28 01:27:31 --> Config Class Initialized
INFO - 2020-10-28 01:27:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:31 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:31 --> URI Class Initialized
INFO - 2020-10-28 01:27:31 --> Router Class Initialized
INFO - 2020-10-28 01:27:31 --> Output Class Initialized
INFO - 2020-10-28 01:27:31 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:31 --> Input Class Initialized
INFO - 2020-10-28 01:27:31 --> Language Class Initialized
INFO - 2020-10-28 01:27:31 --> Language Class Initialized
INFO - 2020-10-28 01:27:31 --> Config Class Initialized
INFO - 2020-10-28 01:27:31 --> Loader Class Initialized
INFO - 2020-10-28 01:27:31 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:31 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:31 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:31 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:31 --> Controller Class Initialized
INFO - 2020-10-28 01:27:31 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:31 --> Total execution time: 0.1735
INFO - 2020-10-28 01:27:32 --> Config Class Initialized
INFO - 2020-10-28 01:27:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:32 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:32 --> URI Class Initialized
INFO - 2020-10-28 01:27:32 --> Router Class Initialized
INFO - 2020-10-28 01:27:32 --> Output Class Initialized
INFO - 2020-10-28 01:27:32 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:32 --> Input Class Initialized
INFO - 2020-10-28 01:27:32 --> Language Class Initialized
INFO - 2020-10-28 01:27:32 --> Language Class Initialized
INFO - 2020-10-28 01:27:32 --> Config Class Initialized
INFO - 2020-10-28 01:27:32 --> Loader Class Initialized
INFO - 2020-10-28 01:27:32 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:32 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:32 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:32 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:32 --> Controller Class Initialized
INFO - 2020-10-28 01:27:32 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:32 --> Total execution time: 0.1724
INFO - 2020-10-28 01:27:46 --> Config Class Initialized
INFO - 2020-10-28 01:27:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:46 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:46 --> URI Class Initialized
INFO - 2020-10-28 01:27:46 --> Router Class Initialized
INFO - 2020-10-28 01:27:46 --> Output Class Initialized
INFO - 2020-10-28 01:27:46 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:46 --> Input Class Initialized
INFO - 2020-10-28 01:27:46 --> Language Class Initialized
INFO - 2020-10-28 01:27:46 --> Language Class Initialized
INFO - 2020-10-28 01:27:46 --> Config Class Initialized
INFO - 2020-10-28 01:27:46 --> Loader Class Initialized
INFO - 2020-10-28 01:27:46 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:46 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:46 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:46 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:46 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:46 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:46 --> Total execution time: 0.2176
INFO - 2020-10-28 01:27:47 --> Config Class Initialized
INFO - 2020-10-28 01:27:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:47 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:47 --> URI Class Initialized
INFO - 2020-10-28 01:27:47 --> Router Class Initialized
INFO - 2020-10-28 01:27:47 --> Output Class Initialized
INFO - 2020-10-28 01:27:47 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:47 --> Input Class Initialized
INFO - 2020-10-28 01:27:47 --> Language Class Initialized
INFO - 2020-10-28 01:27:47 --> Language Class Initialized
INFO - 2020-10-28 01:27:47 --> Config Class Initialized
INFO - 2020-10-28 01:27:47 --> Loader Class Initialized
INFO - 2020-10-28 01:27:47 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:47 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:47 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:47 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:47 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:27:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:47 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:47 --> Total execution time: 0.2087
INFO - 2020-10-28 01:27:47 --> Config Class Initialized
INFO - 2020-10-28 01:27:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:47 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:47 --> URI Class Initialized
INFO - 2020-10-28 01:27:47 --> Router Class Initialized
INFO - 2020-10-28 01:27:47 --> Output Class Initialized
INFO - 2020-10-28 01:27:47 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:48 --> Input Class Initialized
INFO - 2020-10-28 01:27:48 --> Language Class Initialized
INFO - 2020-10-28 01:27:48 --> Language Class Initialized
INFO - 2020-10-28 01:27:48 --> Config Class Initialized
INFO - 2020-10-28 01:27:48 --> Loader Class Initialized
INFO - 2020-10-28 01:27:48 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:48 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:48 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:48 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:48 --> Controller Class Initialized
INFO - 2020-10-28 01:27:50 --> Config Class Initialized
INFO - 2020-10-28 01:27:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:50 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:50 --> URI Class Initialized
INFO - 2020-10-28 01:27:50 --> Router Class Initialized
INFO - 2020-10-28 01:27:50 --> Output Class Initialized
INFO - 2020-10-28 01:27:50 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:50 --> Input Class Initialized
INFO - 2020-10-28 01:27:50 --> Language Class Initialized
INFO - 2020-10-28 01:27:50 --> Language Class Initialized
INFO - 2020-10-28 01:27:50 --> Config Class Initialized
INFO - 2020-10-28 01:27:50 --> Loader Class Initialized
INFO - 2020-10-28 01:27:50 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:50 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:50 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:50 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:50 --> Controller Class Initialized
INFO - 2020-10-28 01:27:50 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:50 --> Total execution time: 0.1822
INFO - 2020-10-28 01:27:53 --> Config Class Initialized
INFO - 2020-10-28 01:27:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:53 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:54 --> URI Class Initialized
INFO - 2020-10-28 01:27:54 --> Router Class Initialized
INFO - 2020-10-28 01:27:54 --> Output Class Initialized
INFO - 2020-10-28 01:27:54 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:54 --> Input Class Initialized
INFO - 2020-10-28 01:27:54 --> Language Class Initialized
INFO - 2020-10-28 01:27:54 --> Language Class Initialized
INFO - 2020-10-28 01:27:54 --> Config Class Initialized
INFO - 2020-10-28 01:27:54 --> Loader Class Initialized
INFO - 2020-10-28 01:27:54 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:54 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:54 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:54 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:54 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:27:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:54 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:54 --> Total execution time: 0.2144
INFO - 2020-10-28 01:27:55 --> Config Class Initialized
INFO - 2020-10-28 01:27:55 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:55 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:55 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:55 --> URI Class Initialized
INFO - 2020-10-28 01:27:55 --> Router Class Initialized
INFO - 2020-10-28 01:27:55 --> Output Class Initialized
INFO - 2020-10-28 01:27:55 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:55 --> Input Class Initialized
INFO - 2020-10-28 01:27:55 --> Language Class Initialized
INFO - 2020-10-28 01:27:55 --> Language Class Initialized
INFO - 2020-10-28 01:27:55 --> Config Class Initialized
INFO - 2020-10-28 01:27:55 --> Loader Class Initialized
INFO - 2020-10-28 01:27:55 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:55 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:55 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:55 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:55 --> Controller Class Initialized
DEBUG - 2020-10-28 01:27:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:27:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:27:55 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:55 --> Total execution time: 0.2293
INFO - 2020-10-28 01:27:55 --> Config Class Initialized
INFO - 2020-10-28 01:27:55 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:55 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:55 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:55 --> URI Class Initialized
INFO - 2020-10-28 01:27:55 --> Router Class Initialized
INFO - 2020-10-28 01:27:55 --> Output Class Initialized
INFO - 2020-10-28 01:27:55 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:55 --> Input Class Initialized
INFO - 2020-10-28 01:27:55 --> Language Class Initialized
INFO - 2020-10-28 01:27:55 --> Language Class Initialized
INFO - 2020-10-28 01:27:55 --> Config Class Initialized
INFO - 2020-10-28 01:27:55 --> Loader Class Initialized
INFO - 2020-10-28 01:27:55 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:55 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:55 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:55 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:55 --> Controller Class Initialized
INFO - 2020-10-28 01:27:57 --> Config Class Initialized
INFO - 2020-10-28 01:27:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:57 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:57 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:57 --> URI Class Initialized
INFO - 2020-10-28 01:27:57 --> Router Class Initialized
INFO - 2020-10-28 01:27:57 --> Output Class Initialized
INFO - 2020-10-28 01:27:57 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:57 --> Input Class Initialized
INFO - 2020-10-28 01:27:57 --> Language Class Initialized
INFO - 2020-10-28 01:27:57 --> Language Class Initialized
INFO - 2020-10-28 01:27:57 --> Config Class Initialized
INFO - 2020-10-28 01:27:57 --> Loader Class Initialized
INFO - 2020-10-28 01:27:57 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:57 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:57 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:57 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:57 --> Controller Class Initialized
INFO - 2020-10-28 01:27:57 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:57 --> Total execution time: 0.1843
INFO - 2020-10-28 01:27:58 --> Config Class Initialized
INFO - 2020-10-28 01:27:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:27:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:27:58 --> Utf8 Class Initialized
INFO - 2020-10-28 01:27:58 --> URI Class Initialized
INFO - 2020-10-28 01:27:58 --> Router Class Initialized
INFO - 2020-10-28 01:27:58 --> Output Class Initialized
INFO - 2020-10-28 01:27:58 --> Security Class Initialized
DEBUG - 2020-10-28 01:27:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:27:58 --> Input Class Initialized
INFO - 2020-10-28 01:27:58 --> Language Class Initialized
INFO - 2020-10-28 01:27:58 --> Language Class Initialized
INFO - 2020-10-28 01:27:58 --> Config Class Initialized
INFO - 2020-10-28 01:27:58 --> Loader Class Initialized
INFO - 2020-10-28 01:27:58 --> Helper loaded: url_helper
INFO - 2020-10-28 01:27:58 --> Helper loaded: file_helper
INFO - 2020-10-28 01:27:58 --> Helper loaded: form_helper
INFO - 2020-10-28 01:27:58 --> Helper loaded: my_helper
INFO - 2020-10-28 01:27:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:27:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:27:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:27:58 --> Controller Class Initialized
INFO - 2020-10-28 01:27:58 --> Final output sent to browser
DEBUG - 2020-10-28 01:27:58 --> Total execution time: 0.1863
INFO - 2020-10-28 01:28:02 --> Config Class Initialized
INFO - 2020-10-28 01:28:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:02 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:02 --> URI Class Initialized
INFO - 2020-10-28 01:28:02 --> Router Class Initialized
INFO - 2020-10-28 01:28:02 --> Output Class Initialized
INFO - 2020-10-28 01:28:02 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:02 --> Input Class Initialized
INFO - 2020-10-28 01:28:02 --> Language Class Initialized
INFO - 2020-10-28 01:28:02 --> Language Class Initialized
INFO - 2020-10-28 01:28:02 --> Config Class Initialized
INFO - 2020-10-28 01:28:02 --> Loader Class Initialized
INFO - 2020-10-28 01:28:02 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:02 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:02 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:02 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:02 --> Controller Class Initialized
INFO - 2020-10-28 01:28:02 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:28:02 --> Config Class Initialized
INFO - 2020-10-28 01:28:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:02 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:02 --> URI Class Initialized
INFO - 2020-10-28 01:28:02 --> Router Class Initialized
INFO - 2020-10-28 01:28:02 --> Output Class Initialized
INFO - 2020-10-28 01:28:02 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:02 --> Input Class Initialized
INFO - 2020-10-28 01:28:02 --> Language Class Initialized
INFO - 2020-10-28 01:28:02 --> Language Class Initialized
INFO - 2020-10-28 01:28:02 --> Config Class Initialized
INFO - 2020-10-28 01:28:02 --> Loader Class Initialized
INFO - 2020-10-28 01:28:02 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:02 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:02 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:02 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:02 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:28:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:02 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:02 --> Total execution time: 0.2133
INFO - 2020-10-28 01:28:07 --> Config Class Initialized
INFO - 2020-10-28 01:28:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:07 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:07 --> URI Class Initialized
INFO - 2020-10-28 01:28:07 --> Router Class Initialized
INFO - 2020-10-28 01:28:07 --> Output Class Initialized
INFO - 2020-10-28 01:28:07 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:07 --> Input Class Initialized
INFO - 2020-10-28 01:28:07 --> Language Class Initialized
INFO - 2020-10-28 01:28:07 --> Language Class Initialized
INFO - 2020-10-28 01:28:07 --> Config Class Initialized
INFO - 2020-10-28 01:28:07 --> Loader Class Initialized
INFO - 2020-10-28 01:28:07 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:07 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:07 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:07 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:07 --> Controller Class Initialized
INFO - 2020-10-28 01:28:07 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:28:07 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:07 --> Total execution time: 0.1994
INFO - 2020-10-28 01:28:09 --> Config Class Initialized
INFO - 2020-10-28 01:28:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:09 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:09 --> URI Class Initialized
INFO - 2020-10-28 01:28:09 --> Router Class Initialized
INFO - 2020-10-28 01:28:09 --> Output Class Initialized
INFO - 2020-10-28 01:28:09 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:09 --> Input Class Initialized
INFO - 2020-10-28 01:28:09 --> Language Class Initialized
INFO - 2020-10-28 01:28:09 --> Language Class Initialized
INFO - 2020-10-28 01:28:09 --> Config Class Initialized
INFO - 2020-10-28 01:28:09 --> Loader Class Initialized
INFO - 2020-10-28 01:28:09 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:09 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:09 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:09 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:09 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:09 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 01:28:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:09 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:09 --> Total execution time: 0.2512
INFO - 2020-10-28 01:28:15 --> Config Class Initialized
INFO - 2020-10-28 01:28:15 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:15 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:15 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:15 --> URI Class Initialized
INFO - 2020-10-28 01:28:15 --> Router Class Initialized
INFO - 2020-10-28 01:28:15 --> Output Class Initialized
INFO - 2020-10-28 01:28:15 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:15 --> Input Class Initialized
INFO - 2020-10-28 01:28:15 --> Language Class Initialized
INFO - 2020-10-28 01:28:15 --> Language Class Initialized
INFO - 2020-10-28 01:28:15 --> Config Class Initialized
INFO - 2020-10-28 01:28:15 --> Loader Class Initialized
INFO - 2020-10-28 01:28:16 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:16 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:16 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:16 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:16 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:16 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-28 01:28:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:16 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:16 --> Total execution time: 0.2158
INFO - 2020-10-28 01:28:16 --> Config Class Initialized
INFO - 2020-10-28 01:28:16 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:16 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:16 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:16 --> URI Class Initialized
INFO - 2020-10-28 01:28:16 --> Router Class Initialized
INFO - 2020-10-28 01:28:16 --> Output Class Initialized
INFO - 2020-10-28 01:28:16 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:16 --> Input Class Initialized
INFO - 2020-10-28 01:28:16 --> Language Class Initialized
INFO - 2020-10-28 01:28:16 --> Language Class Initialized
INFO - 2020-10-28 01:28:16 --> Config Class Initialized
INFO - 2020-10-28 01:28:16 --> Loader Class Initialized
INFO - 2020-10-28 01:28:16 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:16 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:16 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:16 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:16 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:16 --> Controller Class Initialized
INFO - 2020-10-28 01:28:17 --> Config Class Initialized
INFO - 2020-10-28 01:28:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:17 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:17 --> URI Class Initialized
INFO - 2020-10-28 01:28:17 --> Router Class Initialized
INFO - 2020-10-28 01:28:17 --> Output Class Initialized
INFO - 2020-10-28 01:28:17 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:17 --> Input Class Initialized
INFO - 2020-10-28 01:28:17 --> Language Class Initialized
INFO - 2020-10-28 01:28:17 --> Language Class Initialized
INFO - 2020-10-28 01:28:17 --> Config Class Initialized
INFO - 2020-10-28 01:28:17 --> Loader Class Initialized
INFO - 2020-10-28 01:28:17 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:17 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:17 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:17 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:17 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 01:28:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:17 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:17 --> Total execution time: 0.2169
INFO - 2020-10-28 01:28:17 --> Config Class Initialized
INFO - 2020-10-28 01:28:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:17 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:17 --> URI Class Initialized
INFO - 2020-10-28 01:28:17 --> Router Class Initialized
INFO - 2020-10-28 01:28:17 --> Output Class Initialized
INFO - 2020-10-28 01:28:17 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:17 --> Input Class Initialized
INFO - 2020-10-28 01:28:17 --> Language Class Initialized
INFO - 2020-10-28 01:28:17 --> Language Class Initialized
INFO - 2020-10-28 01:28:17 --> Config Class Initialized
INFO - 2020-10-28 01:28:17 --> Loader Class Initialized
INFO - 2020-10-28 01:28:17 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:17 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:17 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:17 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:17 --> Controller Class Initialized
INFO - 2020-10-28 01:28:18 --> Config Class Initialized
INFO - 2020-10-28 01:28:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:18 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:19 --> URI Class Initialized
INFO - 2020-10-28 01:28:19 --> Router Class Initialized
INFO - 2020-10-28 01:28:19 --> Output Class Initialized
INFO - 2020-10-28 01:28:19 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:19 --> Input Class Initialized
INFO - 2020-10-28 01:28:19 --> Language Class Initialized
INFO - 2020-10-28 01:28:19 --> Language Class Initialized
INFO - 2020-10-28 01:28:19 --> Config Class Initialized
INFO - 2020-10-28 01:28:19 --> Loader Class Initialized
INFO - 2020-10-28 01:28:19 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:19 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:19 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:19 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:19 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 01:28:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:19 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:19 --> Total execution time: 0.2332
INFO - 2020-10-28 01:28:19 --> Config Class Initialized
INFO - 2020-10-28 01:28:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:19 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:19 --> URI Class Initialized
INFO - 2020-10-28 01:28:19 --> Router Class Initialized
INFO - 2020-10-28 01:28:19 --> Output Class Initialized
INFO - 2020-10-28 01:28:19 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:19 --> Input Class Initialized
INFO - 2020-10-28 01:28:19 --> Language Class Initialized
INFO - 2020-10-28 01:28:19 --> Language Class Initialized
INFO - 2020-10-28 01:28:19 --> Config Class Initialized
INFO - 2020-10-28 01:28:19 --> Loader Class Initialized
INFO - 2020-10-28 01:28:19 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:19 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:19 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:19 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:19 --> Controller Class Initialized
INFO - 2020-10-28 01:28:25 --> Config Class Initialized
INFO - 2020-10-28 01:28:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:25 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:25 --> URI Class Initialized
INFO - 2020-10-28 01:28:25 --> Router Class Initialized
INFO - 2020-10-28 01:28:25 --> Output Class Initialized
INFO - 2020-10-28 01:28:25 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:25 --> Input Class Initialized
INFO - 2020-10-28 01:28:25 --> Language Class Initialized
INFO - 2020-10-28 01:28:25 --> Language Class Initialized
INFO - 2020-10-28 01:28:25 --> Config Class Initialized
INFO - 2020-10-28 01:28:25 --> Loader Class Initialized
INFO - 2020-10-28 01:28:25 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:25 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:25 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:25 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:25 --> Controller Class Initialized
ERROR - 2020-10-28 01:28:25 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-10-28 01:28:25 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 01:28:28 --> Config Class Initialized
INFO - 2020-10-28 01:28:28 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:28 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:28 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:28 --> URI Class Initialized
INFO - 2020-10-28 01:28:28 --> Router Class Initialized
INFO - 2020-10-28 01:28:28 --> Output Class Initialized
INFO - 2020-10-28 01:28:28 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:28 --> Input Class Initialized
INFO - 2020-10-28 01:28:28 --> Language Class Initialized
INFO - 2020-10-28 01:28:28 --> Language Class Initialized
INFO - 2020-10-28 01:28:28 --> Config Class Initialized
INFO - 2020-10-28 01:28:28 --> Loader Class Initialized
INFO - 2020-10-28 01:28:28 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:28 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:28 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:28 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:28 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:28 --> Controller Class Initialized
ERROR - 2020-10-28 01:28:28 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-10-28 01:28:28 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 01:28:30 --> Config Class Initialized
INFO - 2020-10-28 01:28:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:30 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:30 --> URI Class Initialized
INFO - 2020-10-28 01:28:30 --> Router Class Initialized
INFO - 2020-10-28 01:28:30 --> Output Class Initialized
INFO - 2020-10-28 01:28:30 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:30 --> Input Class Initialized
INFO - 2020-10-28 01:28:30 --> Language Class Initialized
INFO - 2020-10-28 01:28:30 --> Language Class Initialized
INFO - 2020-10-28 01:28:30 --> Config Class Initialized
INFO - 2020-10-28 01:28:30 --> Loader Class Initialized
INFO - 2020-10-28 01:28:30 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:30 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:30 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:30 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:30 --> Controller Class Initialized
ERROR - 2020-10-28 01:28:30 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '9'
INFO - 2020-10-28 01:28:30 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 01:28:32 --> Config Class Initialized
INFO - 2020-10-28 01:28:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:32 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:32 --> URI Class Initialized
INFO - 2020-10-28 01:28:32 --> Router Class Initialized
INFO - 2020-10-28 01:28:32 --> Output Class Initialized
INFO - 2020-10-28 01:28:32 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:32 --> Input Class Initialized
INFO - 2020-10-28 01:28:32 --> Language Class Initialized
INFO - 2020-10-28 01:28:32 --> Language Class Initialized
INFO - 2020-10-28 01:28:32 --> Config Class Initialized
INFO - 2020-10-28 01:28:32 --> Loader Class Initialized
INFO - 2020-10-28 01:28:32 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:32 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:32 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:32 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:32 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 01:28:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:32 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:32 --> Total execution time: 0.2272
INFO - 2020-10-28 01:28:32 --> Config Class Initialized
INFO - 2020-10-28 01:28:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:32 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:32 --> URI Class Initialized
INFO - 2020-10-28 01:28:32 --> Router Class Initialized
INFO - 2020-10-28 01:28:32 --> Output Class Initialized
INFO - 2020-10-28 01:28:32 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:32 --> Input Class Initialized
INFO - 2020-10-28 01:28:32 --> Language Class Initialized
INFO - 2020-10-28 01:28:32 --> Language Class Initialized
INFO - 2020-10-28 01:28:32 --> Config Class Initialized
INFO - 2020-10-28 01:28:32 --> Loader Class Initialized
INFO - 2020-10-28 01:28:32 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:32 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:32 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:32 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:32 --> Controller Class Initialized
INFO - 2020-10-28 01:28:33 --> Config Class Initialized
INFO - 2020-10-28 01:28:33 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:33 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:33 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:33 --> URI Class Initialized
INFO - 2020-10-28 01:28:33 --> Router Class Initialized
INFO - 2020-10-28 01:28:33 --> Output Class Initialized
INFO - 2020-10-28 01:28:33 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:33 --> Input Class Initialized
INFO - 2020-10-28 01:28:33 --> Language Class Initialized
INFO - 2020-10-28 01:28:33 --> Language Class Initialized
INFO - 2020-10-28 01:28:33 --> Config Class Initialized
INFO - 2020-10-28 01:28:33 --> Loader Class Initialized
INFO - 2020-10-28 01:28:33 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:33 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:33 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:33 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:33 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:33 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 01:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:33 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:33 --> Total execution time: 0.2103
INFO - 2020-10-28 01:28:33 --> Config Class Initialized
INFO - 2020-10-28 01:28:33 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:33 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:33 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:33 --> URI Class Initialized
INFO - 2020-10-28 01:28:33 --> Router Class Initialized
INFO - 2020-10-28 01:28:33 --> Output Class Initialized
INFO - 2020-10-28 01:28:33 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:33 --> Input Class Initialized
INFO - 2020-10-28 01:28:33 --> Language Class Initialized
INFO - 2020-10-28 01:28:33 --> Language Class Initialized
INFO - 2020-10-28 01:28:33 --> Config Class Initialized
INFO - 2020-10-28 01:28:33 --> Loader Class Initialized
INFO - 2020-10-28 01:28:33 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:33 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:33 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:33 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:34 --> Controller Class Initialized
INFO - 2020-10-28 01:28:38 --> Config Class Initialized
INFO - 2020-10-28 01:28:38 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:38 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:38 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:38 --> URI Class Initialized
INFO - 2020-10-28 01:28:38 --> Router Class Initialized
INFO - 2020-10-28 01:28:38 --> Output Class Initialized
INFO - 2020-10-28 01:28:38 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:38 --> Input Class Initialized
INFO - 2020-10-28 01:28:38 --> Language Class Initialized
INFO - 2020-10-28 01:28:38 --> Language Class Initialized
INFO - 2020-10-28 01:28:38 --> Config Class Initialized
INFO - 2020-10-28 01:28:38 --> Loader Class Initialized
INFO - 2020-10-28 01:28:38 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:38 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:38 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:38 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:38 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:38 --> Controller Class Initialized
INFO - 2020-10-28 01:28:38 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:38 --> Total execution time: 0.2591
INFO - 2020-10-28 01:28:38 --> Config Class Initialized
INFO - 2020-10-28 01:28:38 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:38 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:38 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:38 --> URI Class Initialized
INFO - 2020-10-28 01:28:38 --> Router Class Initialized
INFO - 2020-10-28 01:28:38 --> Output Class Initialized
INFO - 2020-10-28 01:28:38 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:38 --> Input Class Initialized
INFO - 2020-10-28 01:28:38 --> Language Class Initialized
INFO - 2020-10-28 01:28:38 --> Language Class Initialized
INFO - 2020-10-28 01:28:38 --> Config Class Initialized
INFO - 2020-10-28 01:28:38 --> Loader Class Initialized
INFO - 2020-10-28 01:28:38 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:38 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:38 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:38 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:38 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:39 --> Controller Class Initialized
INFO - 2020-10-28 01:28:42 --> Config Class Initialized
INFO - 2020-10-28 01:28:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:42 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:42 --> URI Class Initialized
INFO - 2020-10-28 01:28:42 --> Router Class Initialized
INFO - 2020-10-28 01:28:42 --> Output Class Initialized
INFO - 2020-10-28 01:28:42 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:42 --> Input Class Initialized
INFO - 2020-10-28 01:28:42 --> Language Class Initialized
INFO - 2020-10-28 01:28:42 --> Language Class Initialized
INFO - 2020-10-28 01:28:42 --> Config Class Initialized
INFO - 2020-10-28 01:28:42 --> Loader Class Initialized
INFO - 2020-10-28 01:28:42 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:42 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:42 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:42 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:42 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-28 01:28:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:42 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:42 --> Total execution time: 0.2313
INFO - 2020-10-28 01:28:42 --> Config Class Initialized
INFO - 2020-10-28 01:28:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:42 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:42 --> URI Class Initialized
INFO - 2020-10-28 01:28:42 --> Router Class Initialized
INFO - 2020-10-28 01:28:42 --> Output Class Initialized
INFO - 2020-10-28 01:28:42 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:42 --> Input Class Initialized
INFO - 2020-10-28 01:28:42 --> Language Class Initialized
INFO - 2020-10-28 01:28:42 --> Language Class Initialized
INFO - 2020-10-28 01:28:42 --> Config Class Initialized
INFO - 2020-10-28 01:28:42 --> Loader Class Initialized
INFO - 2020-10-28 01:28:42 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:42 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:43 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:43 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:43 --> Controller Class Initialized
INFO - 2020-10-28 01:28:46 --> Config Class Initialized
INFO - 2020-10-28 01:28:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:46 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:46 --> URI Class Initialized
INFO - 2020-10-28 01:28:46 --> Router Class Initialized
INFO - 2020-10-28 01:28:46 --> Output Class Initialized
INFO - 2020-10-28 01:28:46 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:46 --> Input Class Initialized
INFO - 2020-10-28 01:28:46 --> Language Class Initialized
INFO - 2020-10-28 01:28:46 --> Language Class Initialized
INFO - 2020-10-28 01:28:46 --> Config Class Initialized
INFO - 2020-10-28 01:28:46 --> Loader Class Initialized
INFO - 2020-10-28 01:28:46 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:46 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:46 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:46 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:46 --> Controller Class Initialized
DEBUG - 2020-10-28 01:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-28 01:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:28:46 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:46 --> Total execution time: 0.2144
INFO - 2020-10-28 01:28:46 --> Config Class Initialized
INFO - 2020-10-28 01:28:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:46 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:46 --> URI Class Initialized
INFO - 2020-10-28 01:28:46 --> Router Class Initialized
INFO - 2020-10-28 01:28:46 --> Output Class Initialized
INFO - 2020-10-28 01:28:46 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:46 --> Input Class Initialized
INFO - 2020-10-28 01:28:46 --> Language Class Initialized
INFO - 2020-10-28 01:28:46 --> Language Class Initialized
INFO - 2020-10-28 01:28:46 --> Config Class Initialized
INFO - 2020-10-28 01:28:46 --> Loader Class Initialized
INFO - 2020-10-28 01:28:46 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:46 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:46 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:46 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:46 --> Controller Class Initialized
INFO - 2020-10-28 01:28:49 --> Config Class Initialized
INFO - 2020-10-28 01:28:49 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:28:49 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:28:49 --> Utf8 Class Initialized
INFO - 2020-10-28 01:28:49 --> URI Class Initialized
INFO - 2020-10-28 01:28:49 --> Router Class Initialized
INFO - 2020-10-28 01:28:49 --> Output Class Initialized
INFO - 2020-10-28 01:28:49 --> Security Class Initialized
DEBUG - 2020-10-28 01:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:28:49 --> Input Class Initialized
INFO - 2020-10-28 01:28:49 --> Language Class Initialized
INFO - 2020-10-28 01:28:49 --> Language Class Initialized
INFO - 2020-10-28 01:28:49 --> Config Class Initialized
INFO - 2020-10-28 01:28:49 --> Loader Class Initialized
INFO - 2020-10-28 01:28:49 --> Helper loaded: url_helper
INFO - 2020-10-28 01:28:49 --> Helper loaded: file_helper
INFO - 2020-10-28 01:28:49 --> Helper loaded: form_helper
INFO - 2020-10-28 01:28:49 --> Helper loaded: my_helper
INFO - 2020-10-28 01:28:49 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:28:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:28:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:28:49 --> Controller Class Initialized
INFO - 2020-10-28 01:28:49 --> Final output sent to browser
DEBUG - 2020-10-28 01:28:49 --> Total execution time: 0.2202
INFO - 2020-10-28 01:29:34 --> Config Class Initialized
INFO - 2020-10-28 01:29:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:34 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:34 --> URI Class Initialized
INFO - 2020-10-28 01:29:34 --> Router Class Initialized
INFO - 2020-10-28 01:29:34 --> Output Class Initialized
INFO - 2020-10-28 01:29:34 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:34 --> Input Class Initialized
INFO - 2020-10-28 01:29:34 --> Language Class Initialized
INFO - 2020-10-28 01:29:34 --> Language Class Initialized
INFO - 2020-10-28 01:29:34 --> Config Class Initialized
INFO - 2020-10-28 01:29:34 --> Loader Class Initialized
INFO - 2020-10-28 01:29:34 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:34 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:34 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:34 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:34 --> Controller Class Initialized
INFO - 2020-10-28 01:29:34 --> Final output sent to browser
DEBUG - 2020-10-28 01:29:34 --> Total execution time: 0.3483
INFO - 2020-10-28 01:29:34 --> Config Class Initialized
INFO - 2020-10-28 01:29:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:34 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:34 --> URI Class Initialized
INFO - 2020-10-28 01:29:34 --> Router Class Initialized
INFO - 2020-10-28 01:29:34 --> Output Class Initialized
INFO - 2020-10-28 01:29:34 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:34 --> Input Class Initialized
INFO - 2020-10-28 01:29:34 --> Language Class Initialized
INFO - 2020-10-28 01:29:34 --> Language Class Initialized
INFO - 2020-10-28 01:29:34 --> Config Class Initialized
INFO - 2020-10-28 01:29:34 --> Loader Class Initialized
INFO - 2020-10-28 01:29:34 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:34 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:34 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:34 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:34 --> Controller Class Initialized
INFO - 2020-10-28 01:29:39 --> Config Class Initialized
INFO - 2020-10-28 01:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:39 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:39 --> URI Class Initialized
INFO - 2020-10-28 01:29:39 --> Router Class Initialized
INFO - 2020-10-28 01:29:39 --> Output Class Initialized
INFO - 2020-10-28 01:29:39 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:39 --> Input Class Initialized
INFO - 2020-10-28 01:29:39 --> Language Class Initialized
INFO - 2020-10-28 01:29:39 --> Language Class Initialized
INFO - 2020-10-28 01:29:39 --> Config Class Initialized
INFO - 2020-10-28 01:29:39 --> Loader Class Initialized
INFO - 2020-10-28 01:29:39 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:39 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:39 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:39 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:39 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:39 --> Controller Class Initialized
DEBUG - 2020-10-28 01:29:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-28 01:29:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:29:39 --> Final output sent to browser
DEBUG - 2020-10-28 01:29:39 --> Total execution time: 0.2583
INFO - 2020-10-28 01:29:39 --> Config Class Initialized
INFO - 2020-10-28 01:29:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:39 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:39 --> URI Class Initialized
INFO - 2020-10-28 01:29:39 --> Router Class Initialized
INFO - 2020-10-28 01:29:39 --> Output Class Initialized
INFO - 2020-10-28 01:29:39 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:39 --> Input Class Initialized
INFO - 2020-10-28 01:29:39 --> Language Class Initialized
INFO - 2020-10-28 01:29:39 --> Language Class Initialized
INFO - 2020-10-28 01:29:39 --> Config Class Initialized
INFO - 2020-10-28 01:29:39 --> Loader Class Initialized
INFO - 2020-10-28 01:29:39 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:39 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:39 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:39 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:39 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:40 --> Controller Class Initialized
INFO - 2020-10-28 01:29:42 --> Config Class Initialized
INFO - 2020-10-28 01:29:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:42 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:42 --> URI Class Initialized
INFO - 2020-10-28 01:29:42 --> Router Class Initialized
INFO - 2020-10-28 01:29:42 --> Output Class Initialized
INFO - 2020-10-28 01:29:42 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:42 --> Input Class Initialized
INFO - 2020-10-28 01:29:42 --> Language Class Initialized
INFO - 2020-10-28 01:29:42 --> Language Class Initialized
INFO - 2020-10-28 01:29:42 --> Config Class Initialized
INFO - 2020-10-28 01:29:42 --> Loader Class Initialized
INFO - 2020-10-28 01:29:42 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:42 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:42 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:42 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:42 --> Controller Class Initialized
INFO - 2020-10-28 01:29:42 --> Final output sent to browser
DEBUG - 2020-10-28 01:29:42 --> Total execution time: 0.2685
INFO - 2020-10-28 01:29:47 --> Config Class Initialized
INFO - 2020-10-28 01:29:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:47 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:47 --> URI Class Initialized
INFO - 2020-10-28 01:29:47 --> Router Class Initialized
INFO - 2020-10-28 01:29:47 --> Output Class Initialized
INFO - 2020-10-28 01:29:47 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:47 --> Input Class Initialized
INFO - 2020-10-28 01:29:47 --> Language Class Initialized
INFO - 2020-10-28 01:29:47 --> Language Class Initialized
INFO - 2020-10-28 01:29:47 --> Config Class Initialized
INFO - 2020-10-28 01:29:47 --> Loader Class Initialized
INFO - 2020-10-28 01:29:47 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:47 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:47 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:47 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:47 --> Controller Class Initialized
INFO - 2020-10-28 01:29:47 --> Final output sent to browser
DEBUG - 2020-10-28 01:29:47 --> Total execution time: 0.3210
INFO - 2020-10-28 01:29:47 --> Config Class Initialized
INFO - 2020-10-28 01:29:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:47 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:47 --> URI Class Initialized
INFO - 2020-10-28 01:29:47 --> Router Class Initialized
INFO - 2020-10-28 01:29:47 --> Output Class Initialized
INFO - 2020-10-28 01:29:47 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:47 --> Input Class Initialized
INFO - 2020-10-28 01:29:47 --> Language Class Initialized
INFO - 2020-10-28 01:29:47 --> Language Class Initialized
INFO - 2020-10-28 01:29:47 --> Config Class Initialized
INFO - 2020-10-28 01:29:47 --> Loader Class Initialized
INFO - 2020-10-28 01:29:47 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:47 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:47 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:47 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:47 --> Controller Class Initialized
INFO - 2020-10-28 01:29:49 --> Config Class Initialized
INFO - 2020-10-28 01:29:49 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:49 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:49 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:49 --> URI Class Initialized
INFO - 2020-10-28 01:29:49 --> Router Class Initialized
INFO - 2020-10-28 01:29:49 --> Output Class Initialized
INFO - 2020-10-28 01:29:49 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:49 --> Input Class Initialized
INFO - 2020-10-28 01:29:49 --> Language Class Initialized
INFO - 2020-10-28 01:29:49 --> Language Class Initialized
INFO - 2020-10-28 01:29:49 --> Config Class Initialized
INFO - 2020-10-28 01:29:49 --> Loader Class Initialized
INFO - 2020-10-28 01:29:49 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:49 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:49 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:49 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:49 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:49 --> Controller Class Initialized
DEBUG - 2020-10-28 01:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:29:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:29:49 --> Final output sent to browser
DEBUG - 2020-10-28 01:29:49 --> Total execution time: 0.2440
INFO - 2020-10-28 01:29:49 --> Config Class Initialized
INFO - 2020-10-28 01:29:49 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:49 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:49 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:49 --> URI Class Initialized
INFO - 2020-10-28 01:29:49 --> Router Class Initialized
INFO - 2020-10-28 01:29:49 --> Output Class Initialized
INFO - 2020-10-28 01:29:49 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:49 --> Input Class Initialized
INFO - 2020-10-28 01:29:49 --> Language Class Initialized
INFO - 2020-10-28 01:29:49 --> Language Class Initialized
INFO - 2020-10-28 01:29:49 --> Config Class Initialized
INFO - 2020-10-28 01:29:49 --> Loader Class Initialized
INFO - 2020-10-28 01:29:49 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:49 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:49 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:49 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:49 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:49 --> Controller Class Initialized
INFO - 2020-10-28 01:29:50 --> Config Class Initialized
INFO - 2020-10-28 01:29:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:50 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:50 --> URI Class Initialized
INFO - 2020-10-28 01:29:50 --> Router Class Initialized
INFO - 2020-10-28 01:29:50 --> Output Class Initialized
INFO - 2020-10-28 01:29:50 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:50 --> Input Class Initialized
INFO - 2020-10-28 01:29:50 --> Language Class Initialized
INFO - 2020-10-28 01:29:50 --> Language Class Initialized
INFO - 2020-10-28 01:29:50 --> Config Class Initialized
INFO - 2020-10-28 01:29:50 --> Loader Class Initialized
INFO - 2020-10-28 01:29:50 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:50 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:50 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:50 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:50 --> Controller Class Initialized
DEBUG - 2020-10-28 01:29:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:29:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:29:50 --> Final output sent to browser
DEBUG - 2020-10-28 01:29:50 --> Total execution time: 0.2449
INFO - 2020-10-28 01:29:52 --> Config Class Initialized
INFO - 2020-10-28 01:29:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:29:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:29:52 --> Utf8 Class Initialized
INFO - 2020-10-28 01:29:52 --> URI Class Initialized
INFO - 2020-10-28 01:29:52 --> Router Class Initialized
INFO - 2020-10-28 01:29:52 --> Output Class Initialized
INFO - 2020-10-28 01:29:52 --> Security Class Initialized
DEBUG - 2020-10-28 01:29:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:29:52 --> Input Class Initialized
INFO - 2020-10-28 01:29:52 --> Language Class Initialized
INFO - 2020-10-28 01:29:52 --> Language Class Initialized
INFO - 2020-10-28 01:29:52 --> Config Class Initialized
INFO - 2020-10-28 01:29:52 --> Loader Class Initialized
INFO - 2020-10-28 01:29:52 --> Helper loaded: url_helper
INFO - 2020-10-28 01:29:52 --> Helper loaded: file_helper
INFO - 2020-10-28 01:29:52 --> Helper loaded: form_helper
INFO - 2020-10-28 01:29:52 --> Helper loaded: my_helper
INFO - 2020-10-28 01:29:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:29:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:29:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:29:52 --> Controller Class Initialized
DEBUG - 2020-10-28 01:29:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 01:29:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:29:52 --> Final output sent to browser
DEBUG - 2020-10-28 01:29:52 --> Total execution time: 0.2404
INFO - 2020-10-28 01:30:03 --> Config Class Initialized
INFO - 2020-10-28 01:30:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:03 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:03 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:03 --> URI Class Initialized
INFO - 2020-10-28 01:30:03 --> Router Class Initialized
INFO - 2020-10-28 01:30:03 --> Output Class Initialized
INFO - 2020-10-28 01:30:03 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:03 --> Input Class Initialized
INFO - 2020-10-28 01:30:03 --> Language Class Initialized
INFO - 2020-10-28 01:30:03 --> Language Class Initialized
INFO - 2020-10-28 01:30:03 --> Config Class Initialized
INFO - 2020-10-28 01:30:03 --> Loader Class Initialized
INFO - 2020-10-28 01:30:03 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:03 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:03 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:03 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:03 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:03 --> Controller Class Initialized
INFO - 2020-10-28 01:30:03 --> Config Class Initialized
INFO - 2020-10-28 01:30:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:03 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:03 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:03 --> URI Class Initialized
INFO - 2020-10-28 01:30:03 --> Router Class Initialized
INFO - 2020-10-28 01:30:03 --> Output Class Initialized
INFO - 2020-10-28 01:30:03 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:03 --> Input Class Initialized
INFO - 2020-10-28 01:30:03 --> Language Class Initialized
INFO - 2020-10-28 01:30:03 --> Language Class Initialized
INFO - 2020-10-28 01:30:03 --> Config Class Initialized
INFO - 2020-10-28 01:30:03 --> Loader Class Initialized
INFO - 2020-10-28 01:30:03 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:03 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:03 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:03 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:03 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:03 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:30:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:03 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:03 --> Total execution time: 0.2439
INFO - 2020-10-28 01:30:06 --> Config Class Initialized
INFO - 2020-10-28 01:30:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:06 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:06 --> URI Class Initialized
INFO - 2020-10-28 01:30:06 --> Router Class Initialized
INFO - 2020-10-28 01:30:06 --> Output Class Initialized
INFO - 2020-10-28 01:30:06 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:06 --> Input Class Initialized
INFO - 2020-10-28 01:30:06 --> Language Class Initialized
INFO - 2020-10-28 01:30:06 --> Language Class Initialized
INFO - 2020-10-28 01:30:06 --> Config Class Initialized
INFO - 2020-10-28 01:30:06 --> Loader Class Initialized
INFO - 2020-10-28 01:30:06 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:06 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:06 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:06 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:06 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 01:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:06 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:06 --> Total execution time: 0.2408
INFO - 2020-10-28 01:30:06 --> Config Class Initialized
INFO - 2020-10-28 01:30:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:06 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:06 --> URI Class Initialized
INFO - 2020-10-28 01:30:06 --> Router Class Initialized
INFO - 2020-10-28 01:30:06 --> Output Class Initialized
INFO - 2020-10-28 01:30:06 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:06 --> Input Class Initialized
INFO - 2020-10-28 01:30:06 --> Language Class Initialized
INFO - 2020-10-28 01:30:06 --> Language Class Initialized
INFO - 2020-10-28 01:30:06 --> Config Class Initialized
INFO - 2020-10-28 01:30:06 --> Loader Class Initialized
INFO - 2020-10-28 01:30:06 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:06 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:06 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:06 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:06 --> Controller Class Initialized
INFO - 2020-10-28 01:30:08 --> Config Class Initialized
INFO - 2020-10-28 01:30:08 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:08 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:08 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:08 --> URI Class Initialized
INFO - 2020-10-28 01:30:08 --> Router Class Initialized
INFO - 2020-10-28 01:30:08 --> Output Class Initialized
INFO - 2020-10-28 01:30:08 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:08 --> Input Class Initialized
INFO - 2020-10-28 01:30:08 --> Language Class Initialized
INFO - 2020-10-28 01:30:08 --> Language Class Initialized
INFO - 2020-10-28 01:30:08 --> Config Class Initialized
INFO - 2020-10-28 01:30:08 --> Loader Class Initialized
INFO - 2020-10-28 01:30:08 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:08 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:08 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:08 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:08 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:08 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:30:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:08 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:08 --> Total execution time: 0.2508
INFO - 2020-10-28 01:30:09 --> Config Class Initialized
INFO - 2020-10-28 01:30:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:09 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:09 --> URI Class Initialized
INFO - 2020-10-28 01:30:09 --> Router Class Initialized
INFO - 2020-10-28 01:30:09 --> Output Class Initialized
INFO - 2020-10-28 01:30:09 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:09 --> Input Class Initialized
INFO - 2020-10-28 01:30:09 --> Language Class Initialized
INFO - 2020-10-28 01:30:09 --> Language Class Initialized
INFO - 2020-10-28 01:30:09 --> Config Class Initialized
INFO - 2020-10-28 01:30:09 --> Loader Class Initialized
INFO - 2020-10-28 01:30:09 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:09 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:09 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:09 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:09 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:09 --> Controller Class Initialized
INFO - 2020-10-28 01:30:10 --> Config Class Initialized
INFO - 2020-10-28 01:30:10 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:10 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:10 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:10 --> URI Class Initialized
INFO - 2020-10-28 01:30:10 --> Router Class Initialized
INFO - 2020-10-28 01:30:10 --> Output Class Initialized
INFO - 2020-10-28 01:30:10 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:10 --> Input Class Initialized
INFO - 2020-10-28 01:30:10 --> Language Class Initialized
INFO - 2020-10-28 01:30:10 --> Language Class Initialized
INFO - 2020-10-28 01:30:10 --> Config Class Initialized
INFO - 2020-10-28 01:30:10 --> Loader Class Initialized
INFO - 2020-10-28 01:30:10 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:10 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:10 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:10 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:10 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:10 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-10-28 01:30:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:10 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:10 --> Total execution time: 0.2537
INFO - 2020-10-28 01:30:30 --> Config Class Initialized
INFO - 2020-10-28 01:30:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:30 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:30 --> URI Class Initialized
INFO - 2020-10-28 01:30:30 --> Router Class Initialized
INFO - 2020-10-28 01:30:30 --> Output Class Initialized
INFO - 2020-10-28 01:30:30 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:30 --> Input Class Initialized
INFO - 2020-10-28 01:30:30 --> Language Class Initialized
INFO - 2020-10-28 01:30:30 --> Language Class Initialized
INFO - 2020-10-28 01:30:30 --> Config Class Initialized
INFO - 2020-10-28 01:30:30 --> Loader Class Initialized
INFO - 2020-10-28 01:30:30 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:30 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:30 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:30 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:30 --> Controller Class Initialized
INFO - 2020-10-28 01:30:30 --> Config Class Initialized
INFO - 2020-10-28 01:30:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:31 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:31 --> URI Class Initialized
INFO - 2020-10-28 01:30:31 --> Router Class Initialized
INFO - 2020-10-28 01:30:31 --> Output Class Initialized
INFO - 2020-10-28 01:30:31 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:31 --> Input Class Initialized
INFO - 2020-10-28 01:30:31 --> Language Class Initialized
INFO - 2020-10-28 01:30:31 --> Language Class Initialized
INFO - 2020-10-28 01:30:31 --> Config Class Initialized
INFO - 2020-10-28 01:30:31 --> Loader Class Initialized
INFO - 2020-10-28 01:30:31 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:31 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:31 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:31 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:31 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:30:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:31 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:31 --> Total execution time: 0.2403
INFO - 2020-10-28 01:30:31 --> Config Class Initialized
INFO - 2020-10-28 01:30:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:31 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:31 --> URI Class Initialized
INFO - 2020-10-28 01:30:31 --> Router Class Initialized
INFO - 2020-10-28 01:30:31 --> Output Class Initialized
INFO - 2020-10-28 01:30:31 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:31 --> Input Class Initialized
INFO - 2020-10-28 01:30:31 --> Language Class Initialized
INFO - 2020-10-28 01:30:31 --> Language Class Initialized
INFO - 2020-10-28 01:30:31 --> Config Class Initialized
INFO - 2020-10-28 01:30:31 --> Loader Class Initialized
INFO - 2020-10-28 01:30:31 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:31 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:31 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:31 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:31 --> Controller Class Initialized
INFO - 2020-10-28 01:30:45 --> Config Class Initialized
INFO - 2020-10-28 01:30:45 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:45 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:45 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:45 --> URI Class Initialized
INFO - 2020-10-28 01:30:45 --> Router Class Initialized
INFO - 2020-10-28 01:30:45 --> Output Class Initialized
INFO - 2020-10-28 01:30:45 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:45 --> Input Class Initialized
INFO - 2020-10-28 01:30:45 --> Language Class Initialized
INFO - 2020-10-28 01:30:45 --> Language Class Initialized
INFO - 2020-10-28 01:30:45 --> Config Class Initialized
INFO - 2020-10-28 01:30:45 --> Loader Class Initialized
INFO - 2020-10-28 01:30:45 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:45 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:45 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:45 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:45 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:45 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:30:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:45 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:45 --> Total execution time: 0.2813
INFO - 2020-10-28 01:30:45 --> Config Class Initialized
INFO - 2020-10-28 01:30:45 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:45 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:45 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:45 --> URI Class Initialized
INFO - 2020-10-28 01:30:45 --> Router Class Initialized
INFO - 2020-10-28 01:30:45 --> Output Class Initialized
INFO - 2020-10-28 01:30:45 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:45 --> Input Class Initialized
INFO - 2020-10-28 01:30:45 --> Language Class Initialized
INFO - 2020-10-28 01:30:45 --> Language Class Initialized
INFO - 2020-10-28 01:30:45 --> Config Class Initialized
INFO - 2020-10-28 01:30:45 --> Loader Class Initialized
INFO - 2020-10-28 01:30:45 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:45 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:45 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:45 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:45 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:45 --> Controller Class Initialized
INFO - 2020-10-28 01:30:50 --> Config Class Initialized
INFO - 2020-10-28 01:30:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:50 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:50 --> URI Class Initialized
INFO - 2020-10-28 01:30:50 --> Router Class Initialized
INFO - 2020-10-28 01:30:50 --> Output Class Initialized
INFO - 2020-10-28 01:30:50 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:50 --> Input Class Initialized
INFO - 2020-10-28 01:30:50 --> Language Class Initialized
INFO - 2020-10-28 01:30:50 --> Language Class Initialized
INFO - 2020-10-28 01:30:50 --> Config Class Initialized
INFO - 2020-10-28 01:30:50 --> Loader Class Initialized
INFO - 2020-10-28 01:30:50 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:50 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:50 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:50 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:50 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-28 01:30:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:50 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:50 --> Total execution time: 0.2526
INFO - 2020-10-28 01:30:51 --> Config Class Initialized
INFO - 2020-10-28 01:30:51 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:51 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:51 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:51 --> URI Class Initialized
INFO - 2020-10-28 01:30:51 --> Router Class Initialized
INFO - 2020-10-28 01:30:51 --> Output Class Initialized
INFO - 2020-10-28 01:30:51 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:51 --> Input Class Initialized
INFO - 2020-10-28 01:30:51 --> Language Class Initialized
INFO - 2020-10-28 01:30:51 --> Language Class Initialized
INFO - 2020-10-28 01:30:51 --> Config Class Initialized
INFO - 2020-10-28 01:30:51 --> Loader Class Initialized
INFO - 2020-10-28 01:30:51 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:51 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:51 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:51 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:51 --> Controller Class Initialized
INFO - 2020-10-28 01:30:51 --> Config Class Initialized
INFO - 2020-10-28 01:30:51 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:51 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:51 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:51 --> URI Class Initialized
INFO - 2020-10-28 01:30:51 --> Router Class Initialized
INFO - 2020-10-28 01:30:51 --> Output Class Initialized
INFO - 2020-10-28 01:30:51 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:51 --> Input Class Initialized
INFO - 2020-10-28 01:30:51 --> Language Class Initialized
INFO - 2020-10-28 01:30:51 --> Language Class Initialized
INFO - 2020-10-28 01:30:52 --> Config Class Initialized
INFO - 2020-10-28 01:30:52 --> Loader Class Initialized
INFO - 2020-10-28 01:30:52 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:52 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:52 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:52 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:52 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 01:30:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:52 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:52 --> Total execution time: 0.2737
INFO - 2020-10-28 01:30:52 --> Config Class Initialized
INFO - 2020-10-28 01:30:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:52 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:52 --> URI Class Initialized
INFO - 2020-10-28 01:30:52 --> Router Class Initialized
INFO - 2020-10-28 01:30:52 --> Output Class Initialized
INFO - 2020-10-28 01:30:52 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:52 --> Input Class Initialized
INFO - 2020-10-28 01:30:52 --> Language Class Initialized
INFO - 2020-10-28 01:30:52 --> Language Class Initialized
INFO - 2020-10-28 01:30:52 --> Config Class Initialized
INFO - 2020-10-28 01:30:52 --> Loader Class Initialized
INFO - 2020-10-28 01:30:52 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:52 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:52 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:52 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:52 --> Controller Class Initialized
INFO - 2020-10-28 01:30:53 --> Config Class Initialized
INFO - 2020-10-28 01:30:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:53 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:53 --> URI Class Initialized
INFO - 2020-10-28 01:30:53 --> Router Class Initialized
INFO - 2020-10-28 01:30:54 --> Output Class Initialized
INFO - 2020-10-28 01:30:54 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:54 --> Input Class Initialized
INFO - 2020-10-28 01:30:54 --> Language Class Initialized
INFO - 2020-10-28 01:30:54 --> Language Class Initialized
INFO - 2020-10-28 01:30:54 --> Config Class Initialized
INFO - 2020-10-28 01:30:54 --> Loader Class Initialized
INFO - 2020-10-28 01:30:54 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:54 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:54 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:54 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:54 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:30:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:54 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:54 --> Total execution time: 0.2588
INFO - 2020-10-28 01:30:55 --> Config Class Initialized
INFO - 2020-10-28 01:30:55 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:30:55 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:30:55 --> Utf8 Class Initialized
INFO - 2020-10-28 01:30:55 --> URI Class Initialized
INFO - 2020-10-28 01:30:55 --> Router Class Initialized
INFO - 2020-10-28 01:30:55 --> Output Class Initialized
INFO - 2020-10-28 01:30:55 --> Security Class Initialized
DEBUG - 2020-10-28 01:30:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:30:55 --> Input Class Initialized
INFO - 2020-10-28 01:30:55 --> Language Class Initialized
INFO - 2020-10-28 01:30:55 --> Language Class Initialized
INFO - 2020-10-28 01:30:55 --> Config Class Initialized
INFO - 2020-10-28 01:30:55 --> Loader Class Initialized
INFO - 2020-10-28 01:30:55 --> Helper loaded: url_helper
INFO - 2020-10-28 01:30:55 --> Helper loaded: file_helper
INFO - 2020-10-28 01:30:55 --> Helper loaded: form_helper
INFO - 2020-10-28 01:30:55 --> Helper loaded: my_helper
INFO - 2020-10-28 01:30:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:30:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:30:55 --> Controller Class Initialized
DEBUG - 2020-10-28 01:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 01:30:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:30:55 --> Final output sent to browser
DEBUG - 2020-10-28 01:30:55 --> Total execution time: 0.2473
INFO - 2020-10-28 01:31:01 --> Config Class Initialized
INFO - 2020-10-28 01:31:01 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:01 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:01 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:01 --> URI Class Initialized
INFO - 2020-10-28 01:31:01 --> Router Class Initialized
INFO - 2020-10-28 01:31:01 --> Output Class Initialized
INFO - 2020-10-28 01:31:01 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:01 --> Input Class Initialized
INFO - 2020-10-28 01:31:01 --> Language Class Initialized
INFO - 2020-10-28 01:31:01 --> Language Class Initialized
INFO - 2020-10-28 01:31:01 --> Config Class Initialized
INFO - 2020-10-28 01:31:01 --> Loader Class Initialized
INFO - 2020-10-28 01:31:01 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:01 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:02 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:02 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:02 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:31:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:02 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:02 --> Total execution time: 0.3094
INFO - 2020-10-28 01:31:08 --> Config Class Initialized
INFO - 2020-10-28 01:31:08 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:08 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:08 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:08 --> URI Class Initialized
INFO - 2020-10-28 01:31:08 --> Router Class Initialized
INFO - 2020-10-28 01:31:08 --> Output Class Initialized
INFO - 2020-10-28 01:31:08 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:08 --> Input Class Initialized
INFO - 2020-10-28 01:31:08 --> Language Class Initialized
INFO - 2020-10-28 01:31:08 --> Language Class Initialized
INFO - 2020-10-28 01:31:08 --> Config Class Initialized
INFO - 2020-10-28 01:31:08 --> Loader Class Initialized
INFO - 2020-10-28 01:31:08 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:08 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:08 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:08 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:08 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:08 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 01:31:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:08 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:08 --> Total execution time: 0.3588
INFO - 2020-10-28 01:31:14 --> Config Class Initialized
INFO - 2020-10-28 01:31:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:14 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:14 --> URI Class Initialized
INFO - 2020-10-28 01:31:14 --> Router Class Initialized
INFO - 2020-10-28 01:31:14 --> Output Class Initialized
INFO - 2020-10-28 01:31:14 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:14 --> Input Class Initialized
INFO - 2020-10-28 01:31:14 --> Language Class Initialized
INFO - 2020-10-28 01:31:14 --> Language Class Initialized
INFO - 2020-10-28 01:31:14 --> Config Class Initialized
INFO - 2020-10-28 01:31:14 --> Loader Class Initialized
INFO - 2020-10-28 01:31:14 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:14 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:14 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:14 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:14 --> Controller Class Initialized
INFO - 2020-10-28 01:31:14 --> Config Class Initialized
INFO - 2020-10-28 01:31:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:14 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:14 --> URI Class Initialized
INFO - 2020-10-28 01:31:14 --> Router Class Initialized
INFO - 2020-10-28 01:31:14 --> Output Class Initialized
INFO - 2020-10-28 01:31:14 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:14 --> Input Class Initialized
INFO - 2020-10-28 01:31:14 --> Language Class Initialized
INFO - 2020-10-28 01:31:14 --> Language Class Initialized
INFO - 2020-10-28 01:31:14 --> Config Class Initialized
INFO - 2020-10-28 01:31:14 --> Loader Class Initialized
INFO - 2020-10-28 01:31:14 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:14 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:14 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:14 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:14 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 01:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:14 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:14 --> Total execution time: 0.2461
INFO - 2020-10-28 01:31:20 --> Config Class Initialized
INFO - 2020-10-28 01:31:20 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:20 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:20 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:20 --> URI Class Initialized
INFO - 2020-10-28 01:31:20 --> Router Class Initialized
INFO - 2020-10-28 01:31:20 --> Output Class Initialized
INFO - 2020-10-28 01:31:21 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:21 --> Input Class Initialized
INFO - 2020-10-28 01:31:21 --> Language Class Initialized
INFO - 2020-10-28 01:31:21 --> Language Class Initialized
INFO - 2020-10-28 01:31:21 --> Config Class Initialized
INFO - 2020-10-28 01:31:21 --> Loader Class Initialized
INFO - 2020-10-28 01:31:21 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:21 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:21 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:21 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:21 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:21 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-28 01:31:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:21 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:21 --> Total execution time: 0.2719
INFO - 2020-10-28 01:31:21 --> Config Class Initialized
INFO - 2020-10-28 01:31:21 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:21 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:21 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:21 --> URI Class Initialized
INFO - 2020-10-28 01:31:21 --> Router Class Initialized
INFO - 2020-10-28 01:31:21 --> Output Class Initialized
INFO - 2020-10-28 01:31:21 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:21 --> Input Class Initialized
INFO - 2020-10-28 01:31:21 --> Language Class Initialized
INFO - 2020-10-28 01:31:21 --> Language Class Initialized
INFO - 2020-10-28 01:31:21 --> Config Class Initialized
INFO - 2020-10-28 01:31:21 --> Loader Class Initialized
INFO - 2020-10-28 01:31:21 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:21 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:21 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:21 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:21 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:21 --> Controller Class Initialized
INFO - 2020-10-28 01:31:22 --> Config Class Initialized
INFO - 2020-10-28 01:31:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:22 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:22 --> URI Class Initialized
INFO - 2020-10-28 01:31:22 --> Router Class Initialized
INFO - 2020-10-28 01:31:22 --> Output Class Initialized
INFO - 2020-10-28 01:31:22 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:22 --> Input Class Initialized
INFO - 2020-10-28 01:31:22 --> Language Class Initialized
INFO - 2020-10-28 01:31:22 --> Language Class Initialized
INFO - 2020-10-28 01:31:23 --> Config Class Initialized
INFO - 2020-10-28 01:31:23 --> Loader Class Initialized
INFO - 2020-10-28 01:31:23 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:23 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:23 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:23 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:23 --> Controller Class Initialized
INFO - 2020-10-28 01:31:23 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:31:23 --> Config Class Initialized
INFO - 2020-10-28 01:31:23 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:23 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:23 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:23 --> URI Class Initialized
INFO - 2020-10-28 01:31:23 --> Router Class Initialized
INFO - 2020-10-28 01:31:23 --> Output Class Initialized
INFO - 2020-10-28 01:31:23 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:23 --> Input Class Initialized
INFO - 2020-10-28 01:31:23 --> Language Class Initialized
INFO - 2020-10-28 01:31:23 --> Language Class Initialized
INFO - 2020-10-28 01:31:23 --> Config Class Initialized
INFO - 2020-10-28 01:31:23 --> Loader Class Initialized
INFO - 2020-10-28 01:31:23 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:23 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:23 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:23 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:23 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:31:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:23 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:23 --> Total execution time: 0.2607
INFO - 2020-10-28 01:31:29 --> Config Class Initialized
INFO - 2020-10-28 01:31:29 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:29 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:29 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:29 --> URI Class Initialized
INFO - 2020-10-28 01:31:29 --> Router Class Initialized
INFO - 2020-10-28 01:31:29 --> Output Class Initialized
INFO - 2020-10-28 01:31:29 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:29 --> Input Class Initialized
INFO - 2020-10-28 01:31:29 --> Language Class Initialized
INFO - 2020-10-28 01:31:29 --> Language Class Initialized
INFO - 2020-10-28 01:31:29 --> Config Class Initialized
INFO - 2020-10-28 01:31:29 --> Loader Class Initialized
INFO - 2020-10-28 01:31:29 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:29 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:29 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:29 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:29 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:29 --> Controller Class Initialized
INFO - 2020-10-28 01:31:29 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:31:29 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:29 --> Total execution time: 0.2483
INFO - 2020-10-28 01:31:31 --> Config Class Initialized
INFO - 2020-10-28 01:31:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:31 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:31 --> URI Class Initialized
INFO - 2020-10-28 01:31:31 --> Router Class Initialized
INFO - 2020-10-28 01:31:31 --> Output Class Initialized
INFO - 2020-10-28 01:31:31 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:31 --> Input Class Initialized
INFO - 2020-10-28 01:31:31 --> Language Class Initialized
INFO - 2020-10-28 01:31:31 --> Language Class Initialized
INFO - 2020-10-28 01:31:31 --> Config Class Initialized
INFO - 2020-10-28 01:31:31 --> Loader Class Initialized
INFO - 2020-10-28 01:31:31 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:31 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:31 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:31 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:31 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 01:31:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:31 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:31 --> Total execution time: 0.3038
INFO - 2020-10-28 01:31:33 --> Config Class Initialized
INFO - 2020-10-28 01:31:33 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:33 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:33 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:33 --> URI Class Initialized
INFO - 2020-10-28 01:31:33 --> Router Class Initialized
INFO - 2020-10-28 01:31:33 --> Output Class Initialized
INFO - 2020-10-28 01:31:33 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:33 --> Input Class Initialized
INFO - 2020-10-28 01:31:33 --> Language Class Initialized
INFO - 2020-10-28 01:31:33 --> Language Class Initialized
INFO - 2020-10-28 01:31:33 --> Config Class Initialized
INFO - 2020-10-28 01:31:33 --> Loader Class Initialized
INFO - 2020-10-28 01:31:33 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:33 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:33 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:33 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:33 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:33 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:31:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:33 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:33 --> Total execution time: 0.2595
INFO - 2020-10-28 01:31:34 --> Config Class Initialized
INFO - 2020-10-28 01:31:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:34 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:34 --> URI Class Initialized
INFO - 2020-10-28 01:31:34 --> Router Class Initialized
INFO - 2020-10-28 01:31:34 --> Output Class Initialized
INFO - 2020-10-28 01:31:34 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:34 --> Input Class Initialized
INFO - 2020-10-28 01:31:34 --> Language Class Initialized
INFO - 2020-10-28 01:31:34 --> Language Class Initialized
INFO - 2020-10-28 01:31:34 --> Config Class Initialized
INFO - 2020-10-28 01:31:34 --> Loader Class Initialized
INFO - 2020-10-28 01:31:34 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:34 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:34 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:34 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:34 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:31:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:34 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:34 --> Total execution time: 0.2601
INFO - 2020-10-28 01:31:34 --> Config Class Initialized
INFO - 2020-10-28 01:31:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:34 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:34 --> URI Class Initialized
INFO - 2020-10-28 01:31:34 --> Router Class Initialized
INFO - 2020-10-28 01:31:34 --> Output Class Initialized
INFO - 2020-10-28 01:31:34 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:34 --> Input Class Initialized
INFO - 2020-10-28 01:31:34 --> Language Class Initialized
INFO - 2020-10-28 01:31:34 --> Language Class Initialized
INFO - 2020-10-28 01:31:34 --> Config Class Initialized
INFO - 2020-10-28 01:31:34 --> Loader Class Initialized
INFO - 2020-10-28 01:31:34 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:34 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:35 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:35 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:35 --> Controller Class Initialized
INFO - 2020-10-28 01:31:43 --> Config Class Initialized
INFO - 2020-10-28 01:31:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:43 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:43 --> URI Class Initialized
INFO - 2020-10-28 01:31:43 --> Router Class Initialized
INFO - 2020-10-28 01:31:43 --> Output Class Initialized
INFO - 2020-10-28 01:31:43 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:43 --> Input Class Initialized
INFO - 2020-10-28 01:31:43 --> Language Class Initialized
INFO - 2020-10-28 01:31:43 --> Language Class Initialized
INFO - 2020-10-28 01:31:43 --> Config Class Initialized
INFO - 2020-10-28 01:31:43 --> Loader Class Initialized
INFO - 2020-10-28 01:31:43 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:43 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:43 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:43 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:44 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:31:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:44 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:44 --> Total execution time: 0.2748
INFO - 2020-10-28 01:31:45 --> Config Class Initialized
INFO - 2020-10-28 01:31:45 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:45 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:45 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:45 --> URI Class Initialized
INFO - 2020-10-28 01:31:45 --> Router Class Initialized
INFO - 2020-10-28 01:31:45 --> Output Class Initialized
INFO - 2020-10-28 01:31:45 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:45 --> Input Class Initialized
INFO - 2020-10-28 01:31:45 --> Language Class Initialized
INFO - 2020-10-28 01:31:45 --> Language Class Initialized
INFO - 2020-10-28 01:31:45 --> Config Class Initialized
INFO - 2020-10-28 01:31:45 --> Loader Class Initialized
INFO - 2020-10-28 01:31:45 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:45 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:45 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:45 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:45 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:45 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:31:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:45 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:45 --> Total execution time: 0.2843
INFO - 2020-10-28 01:31:45 --> Config Class Initialized
INFO - 2020-10-28 01:31:45 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:45 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:45 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:45 --> URI Class Initialized
INFO - 2020-10-28 01:31:45 --> Router Class Initialized
INFO - 2020-10-28 01:31:45 --> Output Class Initialized
INFO - 2020-10-28 01:31:45 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:45 --> Input Class Initialized
INFO - 2020-10-28 01:31:45 --> Language Class Initialized
INFO - 2020-10-28 01:31:45 --> Language Class Initialized
INFO - 2020-10-28 01:31:45 --> Config Class Initialized
INFO - 2020-10-28 01:31:45 --> Loader Class Initialized
INFO - 2020-10-28 01:31:45 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:45 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:45 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:45 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:45 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:45 --> Controller Class Initialized
INFO - 2020-10-28 01:31:46 --> Config Class Initialized
INFO - 2020-10-28 01:31:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:46 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:46 --> URI Class Initialized
INFO - 2020-10-28 01:31:46 --> Router Class Initialized
INFO - 2020-10-28 01:31:46 --> Output Class Initialized
INFO - 2020-10-28 01:31:46 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:46 --> Input Class Initialized
INFO - 2020-10-28 01:31:46 --> Language Class Initialized
INFO - 2020-10-28 01:31:47 --> Language Class Initialized
INFO - 2020-10-28 01:31:47 --> Config Class Initialized
INFO - 2020-10-28 01:31:47 --> Loader Class Initialized
INFO - 2020-10-28 01:31:47 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:47 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:47 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:47 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:47 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:31:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:47 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:47 --> Total execution time: 0.2775
INFO - 2020-10-28 01:31:48 --> Config Class Initialized
INFO - 2020-10-28 01:31:48 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:48 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:48 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:48 --> URI Class Initialized
INFO - 2020-10-28 01:31:48 --> Router Class Initialized
INFO - 2020-10-28 01:31:48 --> Output Class Initialized
INFO - 2020-10-28 01:31:48 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:48 --> Input Class Initialized
INFO - 2020-10-28 01:31:48 --> Language Class Initialized
INFO - 2020-10-28 01:31:48 --> Language Class Initialized
INFO - 2020-10-28 01:31:48 --> Config Class Initialized
INFO - 2020-10-28 01:31:48 --> Loader Class Initialized
INFO - 2020-10-28 01:31:48 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:48 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:48 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:48 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:48 --> Controller Class Initialized
DEBUG - 2020-10-28 01:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:31:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:31:48 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:48 --> Total execution time: 0.2904
INFO - 2020-10-28 01:31:48 --> Config Class Initialized
INFO - 2020-10-28 01:31:48 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:48 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:48 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:48 --> URI Class Initialized
INFO - 2020-10-28 01:31:48 --> Router Class Initialized
INFO - 2020-10-28 01:31:48 --> Output Class Initialized
INFO - 2020-10-28 01:31:48 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:48 --> Input Class Initialized
INFO - 2020-10-28 01:31:48 --> Language Class Initialized
INFO - 2020-10-28 01:31:48 --> Language Class Initialized
INFO - 2020-10-28 01:31:48 --> Config Class Initialized
INFO - 2020-10-28 01:31:48 --> Loader Class Initialized
INFO - 2020-10-28 01:31:48 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:48 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:48 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:48 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:48 --> Controller Class Initialized
INFO - 2020-10-28 01:31:50 --> Config Class Initialized
INFO - 2020-10-28 01:31:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:31:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:31:50 --> Utf8 Class Initialized
INFO - 2020-10-28 01:31:50 --> URI Class Initialized
INFO - 2020-10-28 01:31:50 --> Router Class Initialized
INFO - 2020-10-28 01:31:50 --> Output Class Initialized
INFO - 2020-10-28 01:31:50 --> Security Class Initialized
DEBUG - 2020-10-28 01:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:31:50 --> Input Class Initialized
INFO - 2020-10-28 01:31:50 --> Language Class Initialized
INFO - 2020-10-28 01:31:50 --> Language Class Initialized
INFO - 2020-10-28 01:31:50 --> Config Class Initialized
INFO - 2020-10-28 01:31:50 --> Loader Class Initialized
INFO - 2020-10-28 01:31:50 --> Helper loaded: url_helper
INFO - 2020-10-28 01:31:50 --> Helper loaded: file_helper
INFO - 2020-10-28 01:31:50 --> Helper loaded: form_helper
INFO - 2020-10-28 01:31:50 --> Helper loaded: my_helper
INFO - 2020-10-28 01:31:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:31:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:31:50 --> Controller Class Initialized
INFO - 2020-10-28 01:31:50 --> Final output sent to browser
DEBUG - 2020-10-28 01:31:50 --> Total execution time: 0.2821
INFO - 2020-10-28 01:32:11 --> Config Class Initialized
INFO - 2020-10-28 01:32:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:11 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:11 --> URI Class Initialized
INFO - 2020-10-28 01:32:11 --> Router Class Initialized
INFO - 2020-10-28 01:32:11 --> Output Class Initialized
INFO - 2020-10-28 01:32:11 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:11 --> Input Class Initialized
INFO - 2020-10-28 01:32:11 --> Language Class Initialized
INFO - 2020-10-28 01:32:11 --> Language Class Initialized
INFO - 2020-10-28 01:32:11 --> Config Class Initialized
INFO - 2020-10-28 01:32:11 --> Loader Class Initialized
INFO - 2020-10-28 01:32:11 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:11 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:11 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:11 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:11 --> Controller Class Initialized
INFO - 2020-10-28 01:32:11 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:32:11 --> Config Class Initialized
INFO - 2020-10-28 01:32:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:11 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:11 --> URI Class Initialized
INFO - 2020-10-28 01:32:11 --> Router Class Initialized
INFO - 2020-10-28 01:32:11 --> Output Class Initialized
INFO - 2020-10-28 01:32:11 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:11 --> Input Class Initialized
INFO - 2020-10-28 01:32:11 --> Language Class Initialized
INFO - 2020-10-28 01:32:11 --> Language Class Initialized
INFO - 2020-10-28 01:32:11 --> Config Class Initialized
INFO - 2020-10-28 01:32:11 --> Loader Class Initialized
INFO - 2020-10-28 01:32:11 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:11 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:11 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:11 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:11 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:11 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:11 --> Total execution time: 0.2614
INFO - 2020-10-28 01:32:21 --> Config Class Initialized
INFO - 2020-10-28 01:32:21 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:21 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:21 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:21 --> URI Class Initialized
INFO - 2020-10-28 01:32:21 --> Router Class Initialized
INFO - 2020-10-28 01:32:21 --> Output Class Initialized
INFO - 2020-10-28 01:32:21 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:21 --> Input Class Initialized
INFO - 2020-10-28 01:32:21 --> Language Class Initialized
INFO - 2020-10-28 01:32:21 --> Language Class Initialized
INFO - 2020-10-28 01:32:21 --> Config Class Initialized
INFO - 2020-10-28 01:32:21 --> Loader Class Initialized
INFO - 2020-10-28 01:32:21 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:21 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:21 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:21 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:21 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:21 --> Controller Class Initialized
INFO - 2020-10-28 01:32:21 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:32:21 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:21 --> Total execution time: 0.2750
INFO - 2020-10-28 01:32:22 --> Config Class Initialized
INFO - 2020-10-28 01:32:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:22 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:22 --> URI Class Initialized
INFO - 2020-10-28 01:32:22 --> Router Class Initialized
INFO - 2020-10-28 01:32:22 --> Output Class Initialized
INFO - 2020-10-28 01:32:22 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:22 --> Input Class Initialized
INFO - 2020-10-28 01:32:22 --> Language Class Initialized
INFO - 2020-10-28 01:32:22 --> Language Class Initialized
INFO - 2020-10-28 01:32:22 --> Config Class Initialized
INFO - 2020-10-28 01:32:22 --> Loader Class Initialized
INFO - 2020-10-28 01:32:22 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:22 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:22 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:22 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:22 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:23 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 01:32:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:23 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:23 --> Total execution time: 0.3455
INFO - 2020-10-28 01:32:25 --> Config Class Initialized
INFO - 2020-10-28 01:32:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:25 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:25 --> URI Class Initialized
INFO - 2020-10-28 01:32:25 --> Router Class Initialized
INFO - 2020-10-28 01:32:25 --> Output Class Initialized
INFO - 2020-10-28 01:32:25 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:25 --> Input Class Initialized
INFO - 2020-10-28 01:32:25 --> Language Class Initialized
INFO - 2020-10-28 01:32:25 --> Language Class Initialized
INFO - 2020-10-28 01:32:25 --> Config Class Initialized
INFO - 2020-10-28 01:32:25 --> Loader Class Initialized
INFO - 2020-10-28 01:32:25 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:25 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:25 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:25 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:25 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 01:32:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:25 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:25 --> Total execution time: 0.2638
INFO - 2020-10-28 01:32:25 --> Config Class Initialized
INFO - 2020-10-28 01:32:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:25 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:25 --> URI Class Initialized
INFO - 2020-10-28 01:32:25 --> Router Class Initialized
INFO - 2020-10-28 01:32:25 --> Output Class Initialized
INFO - 2020-10-28 01:32:25 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:25 --> Input Class Initialized
INFO - 2020-10-28 01:32:25 --> Language Class Initialized
INFO - 2020-10-28 01:32:25 --> Language Class Initialized
INFO - 2020-10-28 01:32:25 --> Config Class Initialized
INFO - 2020-10-28 01:32:25 --> Loader Class Initialized
INFO - 2020-10-28 01:32:25 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:25 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:25 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:25 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:25 --> Controller Class Initialized
INFO - 2020-10-28 01:32:26 --> Config Class Initialized
INFO - 2020-10-28 01:32:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:26 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:26 --> URI Class Initialized
INFO - 2020-10-28 01:32:26 --> Router Class Initialized
INFO - 2020-10-28 01:32:26 --> Output Class Initialized
INFO - 2020-10-28 01:32:26 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:26 --> Input Class Initialized
INFO - 2020-10-28 01:32:26 --> Language Class Initialized
INFO - 2020-10-28 01:32:26 --> Language Class Initialized
INFO - 2020-10-28 01:32:26 --> Config Class Initialized
INFO - 2020-10-28 01:32:26 --> Loader Class Initialized
INFO - 2020-10-28 01:32:26 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:26 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:26 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:26 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:26 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-28 01:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:26 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:26 --> Total execution time: 0.2603
INFO - 2020-10-28 01:32:26 --> Config Class Initialized
INFO - 2020-10-28 01:32:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:26 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:26 --> URI Class Initialized
INFO - 2020-10-28 01:32:26 --> Router Class Initialized
INFO - 2020-10-28 01:32:26 --> Output Class Initialized
INFO - 2020-10-28 01:32:26 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:26 --> Input Class Initialized
INFO - 2020-10-28 01:32:26 --> Language Class Initialized
INFO - 2020-10-28 01:32:26 --> Language Class Initialized
INFO - 2020-10-28 01:32:26 --> Config Class Initialized
INFO - 2020-10-28 01:32:26 --> Loader Class Initialized
INFO - 2020-10-28 01:32:26 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:26 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:26 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:26 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:26 --> Controller Class Initialized
INFO - 2020-10-28 01:32:30 --> Config Class Initialized
INFO - 2020-10-28 01:32:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:30 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:30 --> URI Class Initialized
INFO - 2020-10-28 01:32:30 --> Router Class Initialized
INFO - 2020-10-28 01:32:30 --> Output Class Initialized
INFO - 2020-10-28 01:32:30 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:30 --> Input Class Initialized
INFO - 2020-10-28 01:32:30 --> Language Class Initialized
INFO - 2020-10-28 01:32:30 --> Language Class Initialized
INFO - 2020-10-28 01:32:30 --> Config Class Initialized
INFO - 2020-10-28 01:32:30 --> Loader Class Initialized
INFO - 2020-10-28 01:32:30 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:30 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:30 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:30 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:30 --> Controller Class Initialized
INFO - 2020-10-28 01:32:30 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:30 --> Total execution time: 0.3013
INFO - 2020-10-28 01:32:34 --> Config Class Initialized
INFO - 2020-10-28 01:32:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:34 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:34 --> URI Class Initialized
INFO - 2020-10-28 01:32:34 --> Router Class Initialized
INFO - 2020-10-28 01:32:34 --> Output Class Initialized
INFO - 2020-10-28 01:32:34 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:34 --> Input Class Initialized
INFO - 2020-10-28 01:32:34 --> Language Class Initialized
INFO - 2020-10-28 01:32:34 --> Language Class Initialized
INFO - 2020-10-28 01:32:34 --> Config Class Initialized
INFO - 2020-10-28 01:32:34 --> Loader Class Initialized
INFO - 2020-10-28 01:32:34 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:34 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:34 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:34 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:34 --> Controller Class Initialized
INFO - 2020-10-28 01:32:34 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:34 --> Total execution time: 0.3075
INFO - 2020-10-28 01:32:35 --> Config Class Initialized
INFO - 2020-10-28 01:32:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:35 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:35 --> URI Class Initialized
INFO - 2020-10-28 01:32:35 --> Router Class Initialized
INFO - 2020-10-28 01:32:35 --> Output Class Initialized
INFO - 2020-10-28 01:32:35 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:35 --> Input Class Initialized
INFO - 2020-10-28 01:32:35 --> Language Class Initialized
INFO - 2020-10-28 01:32:35 --> Language Class Initialized
INFO - 2020-10-28 01:32:35 --> Config Class Initialized
INFO - 2020-10-28 01:32:35 --> Loader Class Initialized
INFO - 2020-10-28 01:32:35 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:35 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:35 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:35 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:35 --> Controller Class Initialized
INFO - 2020-10-28 01:32:36 --> Config Class Initialized
INFO - 2020-10-28 01:32:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:36 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:36 --> URI Class Initialized
INFO - 2020-10-28 01:32:36 --> Router Class Initialized
INFO - 2020-10-28 01:32:36 --> Output Class Initialized
INFO - 2020-10-28 01:32:36 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:36 --> Input Class Initialized
INFO - 2020-10-28 01:32:36 --> Language Class Initialized
INFO - 2020-10-28 01:32:36 --> Language Class Initialized
INFO - 2020-10-28 01:32:36 --> Config Class Initialized
INFO - 2020-10-28 01:32:36 --> Loader Class Initialized
INFO - 2020-10-28 01:32:36 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:36 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:36 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:36 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:36 --> Controller Class Initialized
INFO - 2020-10-28 01:32:36 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:36 --> Total execution time: 0.3295
INFO - 2020-10-28 01:32:36 --> Config Class Initialized
INFO - 2020-10-28 01:32:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:36 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:36 --> URI Class Initialized
INFO - 2020-10-28 01:32:36 --> Router Class Initialized
INFO - 2020-10-28 01:32:36 --> Output Class Initialized
INFO - 2020-10-28 01:32:36 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:36 --> Input Class Initialized
INFO - 2020-10-28 01:32:36 --> Language Class Initialized
INFO - 2020-10-28 01:32:36 --> Language Class Initialized
INFO - 2020-10-28 01:32:36 --> Config Class Initialized
INFO - 2020-10-28 01:32:36 --> Loader Class Initialized
INFO - 2020-10-28 01:32:36 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:36 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:36 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:36 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:36 --> Controller Class Initialized
INFO - 2020-10-28 01:32:43 --> Config Class Initialized
INFO - 2020-10-28 01:32:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:43 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:43 --> URI Class Initialized
INFO - 2020-10-28 01:32:43 --> Router Class Initialized
INFO - 2020-10-28 01:32:43 --> Output Class Initialized
INFO - 2020-10-28 01:32:43 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:43 --> Input Class Initialized
INFO - 2020-10-28 01:32:43 --> Language Class Initialized
INFO - 2020-10-28 01:32:43 --> Language Class Initialized
INFO - 2020-10-28 01:32:43 --> Config Class Initialized
INFO - 2020-10-28 01:32:43 --> Loader Class Initialized
INFO - 2020-10-28 01:32:43 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:43 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:43 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:43 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:43 --> Controller Class Initialized
INFO - 2020-10-28 01:32:43 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:32:43 --> Config Class Initialized
INFO - 2020-10-28 01:32:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:43 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:43 --> URI Class Initialized
INFO - 2020-10-28 01:32:43 --> Router Class Initialized
INFO - 2020-10-28 01:32:43 --> Output Class Initialized
INFO - 2020-10-28 01:32:43 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:43 --> Input Class Initialized
INFO - 2020-10-28 01:32:43 --> Language Class Initialized
INFO - 2020-10-28 01:32:43 --> Language Class Initialized
INFO - 2020-10-28 01:32:43 --> Config Class Initialized
INFO - 2020-10-28 01:32:43 --> Loader Class Initialized
INFO - 2020-10-28 01:32:43 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:43 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:43 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:43 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:43 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 01:32:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:43 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:43 --> Total execution time: 0.2939
INFO - 2020-10-28 01:32:50 --> Config Class Initialized
INFO - 2020-10-28 01:32:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:50 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:50 --> URI Class Initialized
INFO - 2020-10-28 01:32:50 --> Router Class Initialized
INFO - 2020-10-28 01:32:50 --> Output Class Initialized
INFO - 2020-10-28 01:32:50 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:50 --> Input Class Initialized
INFO - 2020-10-28 01:32:50 --> Language Class Initialized
INFO - 2020-10-28 01:32:50 --> Language Class Initialized
INFO - 2020-10-28 01:32:50 --> Config Class Initialized
INFO - 2020-10-28 01:32:50 --> Loader Class Initialized
INFO - 2020-10-28 01:32:50 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:50 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:50 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:50 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:51 --> Controller Class Initialized
INFO - 2020-10-28 01:32:51 --> Helper loaded: cookie_helper
INFO - 2020-10-28 01:32:51 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:51 --> Total execution time: 0.2431
INFO - 2020-10-28 01:32:52 --> Config Class Initialized
INFO - 2020-10-28 01:32:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:52 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:52 --> URI Class Initialized
INFO - 2020-10-28 01:32:52 --> Router Class Initialized
INFO - 2020-10-28 01:32:52 --> Output Class Initialized
INFO - 2020-10-28 01:32:52 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:52 --> Input Class Initialized
INFO - 2020-10-28 01:32:52 --> Language Class Initialized
INFO - 2020-10-28 01:32:52 --> Language Class Initialized
INFO - 2020-10-28 01:32:52 --> Config Class Initialized
INFO - 2020-10-28 01:32:52 --> Loader Class Initialized
INFO - 2020-10-28 01:32:52 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:52 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:52 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:52 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:52 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 01:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:52 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:52 --> Total execution time: 0.2957
INFO - 2020-10-28 01:32:54 --> Config Class Initialized
INFO - 2020-10-28 01:32:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:54 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:54 --> URI Class Initialized
INFO - 2020-10-28 01:32:54 --> Router Class Initialized
INFO - 2020-10-28 01:32:54 --> Output Class Initialized
INFO - 2020-10-28 01:32:54 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:54 --> Input Class Initialized
INFO - 2020-10-28 01:32:54 --> Language Class Initialized
INFO - 2020-10-28 01:32:54 --> Language Class Initialized
INFO - 2020-10-28 01:32:54 --> Config Class Initialized
INFO - 2020-10-28 01:32:54 --> Loader Class Initialized
INFO - 2020-10-28 01:32:54 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:54 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:54 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:54 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:54 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:32:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:54 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:54 --> Total execution time: 0.2679
INFO - 2020-10-28 01:32:56 --> Config Class Initialized
INFO - 2020-10-28 01:32:56 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:56 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:56 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:56 --> URI Class Initialized
INFO - 2020-10-28 01:32:56 --> Router Class Initialized
INFO - 2020-10-28 01:32:56 --> Output Class Initialized
INFO - 2020-10-28 01:32:57 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:57 --> Input Class Initialized
INFO - 2020-10-28 01:32:57 --> Language Class Initialized
INFO - 2020-10-28 01:32:57 --> Language Class Initialized
INFO - 2020-10-28 01:32:57 --> Config Class Initialized
INFO - 2020-10-28 01:32:57 --> Loader Class Initialized
INFO - 2020-10-28 01:32:57 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:57 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:57 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:57 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:57 --> Controller Class Initialized
DEBUG - 2020-10-28 01:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:32:57 --> Final output sent to browser
DEBUG - 2020-10-28 01:32:57 --> Total execution time: 0.2800
INFO - 2020-10-28 01:32:57 --> Config Class Initialized
INFO - 2020-10-28 01:32:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:32:57 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:32:57 --> Utf8 Class Initialized
INFO - 2020-10-28 01:32:57 --> URI Class Initialized
INFO - 2020-10-28 01:32:57 --> Router Class Initialized
INFO - 2020-10-28 01:32:57 --> Output Class Initialized
INFO - 2020-10-28 01:32:57 --> Security Class Initialized
DEBUG - 2020-10-28 01:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:32:57 --> Input Class Initialized
INFO - 2020-10-28 01:32:57 --> Language Class Initialized
INFO - 2020-10-28 01:32:57 --> Language Class Initialized
INFO - 2020-10-28 01:32:57 --> Config Class Initialized
INFO - 2020-10-28 01:32:57 --> Loader Class Initialized
INFO - 2020-10-28 01:32:57 --> Helper loaded: url_helper
INFO - 2020-10-28 01:32:57 --> Helper loaded: file_helper
INFO - 2020-10-28 01:32:57 --> Helper loaded: form_helper
INFO - 2020-10-28 01:32:57 --> Helper loaded: my_helper
INFO - 2020-10-28 01:32:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:32:57 --> Controller Class Initialized
INFO - 2020-10-28 01:33:01 --> Config Class Initialized
INFO - 2020-10-28 01:33:01 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:33:01 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:33:01 --> Utf8 Class Initialized
INFO - 2020-10-28 01:33:01 --> URI Class Initialized
INFO - 2020-10-28 01:33:01 --> Router Class Initialized
INFO - 2020-10-28 01:33:01 --> Output Class Initialized
INFO - 2020-10-28 01:33:01 --> Security Class Initialized
DEBUG - 2020-10-28 01:33:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:33:01 --> Input Class Initialized
INFO - 2020-10-28 01:33:01 --> Language Class Initialized
INFO - 2020-10-28 01:33:01 --> Language Class Initialized
INFO - 2020-10-28 01:33:01 --> Config Class Initialized
INFO - 2020-10-28 01:33:01 --> Loader Class Initialized
INFO - 2020-10-28 01:33:01 --> Helper loaded: url_helper
INFO - 2020-10-28 01:33:01 --> Helper loaded: file_helper
INFO - 2020-10-28 01:33:01 --> Helper loaded: form_helper
INFO - 2020-10-28 01:33:01 --> Helper loaded: my_helper
INFO - 2020-10-28 01:33:01 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:33:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:33:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:33:01 --> Controller Class Initialized
INFO - 2020-10-28 01:33:01 --> Final output sent to browser
DEBUG - 2020-10-28 01:33:01 --> Total execution time: 0.2638
INFO - 2020-10-28 01:33:07 --> Config Class Initialized
INFO - 2020-10-28 01:33:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:33:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:33:07 --> Utf8 Class Initialized
INFO - 2020-10-28 01:33:07 --> URI Class Initialized
INFO - 2020-10-28 01:33:07 --> Router Class Initialized
INFO - 2020-10-28 01:33:07 --> Output Class Initialized
INFO - 2020-10-28 01:33:07 --> Security Class Initialized
DEBUG - 2020-10-28 01:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:33:07 --> Input Class Initialized
INFO - 2020-10-28 01:33:07 --> Language Class Initialized
INFO - 2020-10-28 01:33:07 --> Language Class Initialized
INFO - 2020-10-28 01:33:07 --> Config Class Initialized
INFO - 2020-10-28 01:33:08 --> Loader Class Initialized
INFO - 2020-10-28 01:33:08 --> Helper loaded: url_helper
INFO - 2020-10-28 01:33:08 --> Helper loaded: file_helper
INFO - 2020-10-28 01:33:08 --> Helper loaded: form_helper
INFO - 2020-10-28 01:33:08 --> Helper loaded: my_helper
INFO - 2020-10-28 01:33:08 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:33:08 --> Controller Class Initialized
DEBUG - 2020-10-28 01:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-28 01:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:33:08 --> Final output sent to browser
DEBUG - 2020-10-28 01:33:08 --> Total execution time: 0.3928
INFO - 2020-10-28 01:33:11 --> Config Class Initialized
INFO - 2020-10-28 01:33:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:33:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:33:11 --> Utf8 Class Initialized
INFO - 2020-10-28 01:33:11 --> URI Class Initialized
INFO - 2020-10-28 01:33:11 --> Router Class Initialized
INFO - 2020-10-28 01:33:11 --> Output Class Initialized
INFO - 2020-10-28 01:33:11 --> Security Class Initialized
DEBUG - 2020-10-28 01:33:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:33:11 --> Input Class Initialized
INFO - 2020-10-28 01:33:11 --> Language Class Initialized
INFO - 2020-10-28 01:33:11 --> Language Class Initialized
INFO - 2020-10-28 01:33:12 --> Config Class Initialized
INFO - 2020-10-28 01:33:12 --> Loader Class Initialized
INFO - 2020-10-28 01:33:12 --> Helper loaded: url_helper
INFO - 2020-10-28 01:33:12 --> Helper loaded: file_helper
INFO - 2020-10-28 01:33:12 --> Helper loaded: form_helper
INFO - 2020-10-28 01:33:12 --> Helper loaded: my_helper
INFO - 2020-10-28 01:33:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:33:12 --> Controller Class Initialized
DEBUG - 2020-10-28 01:33:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-28 01:33:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:33:12 --> Final output sent to browser
DEBUG - 2020-10-28 01:33:12 --> Total execution time: 0.3136
INFO - 2020-10-28 01:33:13 --> Config Class Initialized
INFO - 2020-10-28 01:33:13 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:33:13 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:33:13 --> Utf8 Class Initialized
INFO - 2020-10-28 01:33:13 --> URI Class Initialized
INFO - 2020-10-28 01:33:13 --> Router Class Initialized
INFO - 2020-10-28 01:33:13 --> Output Class Initialized
INFO - 2020-10-28 01:33:13 --> Security Class Initialized
DEBUG - 2020-10-28 01:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:33:13 --> Input Class Initialized
INFO - 2020-10-28 01:33:13 --> Language Class Initialized
INFO - 2020-10-28 01:33:13 --> Language Class Initialized
INFO - 2020-10-28 01:33:13 --> Config Class Initialized
INFO - 2020-10-28 01:33:13 --> Loader Class Initialized
INFO - 2020-10-28 01:33:13 --> Helper loaded: url_helper
INFO - 2020-10-28 01:33:13 --> Helper loaded: file_helper
INFO - 2020-10-28 01:33:13 --> Helper loaded: form_helper
INFO - 2020-10-28 01:33:13 --> Helper loaded: my_helper
INFO - 2020-10-28 01:33:13 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:33:13 --> Controller Class Initialized
DEBUG - 2020-10-28 01:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_catatan/views/list.php
DEBUG - 2020-10-28 01:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:33:13 --> Final output sent to browser
DEBUG - 2020-10-28 01:33:13 --> Total execution time: 0.2855
INFO - 2020-10-28 01:33:14 --> Config Class Initialized
INFO - 2020-10-28 01:33:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:33:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:33:14 --> Utf8 Class Initialized
INFO - 2020-10-28 01:33:14 --> URI Class Initialized
INFO - 2020-10-28 01:33:14 --> Router Class Initialized
INFO - 2020-10-28 01:33:14 --> Output Class Initialized
INFO - 2020-10-28 01:33:14 --> Security Class Initialized
DEBUG - 2020-10-28 01:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:33:14 --> Input Class Initialized
INFO - 2020-10-28 01:33:14 --> Language Class Initialized
INFO - 2020-10-28 01:33:14 --> Language Class Initialized
INFO - 2020-10-28 01:33:14 --> Config Class Initialized
INFO - 2020-10-28 01:33:14 --> Loader Class Initialized
INFO - 2020-10-28 01:33:14 --> Helper loaded: url_helper
INFO - 2020-10-28 01:33:14 --> Helper loaded: file_helper
INFO - 2020-10-28 01:33:14 --> Helper loaded: form_helper
INFO - 2020-10-28 01:33:14 --> Helper loaded: my_helper
INFO - 2020-10-28 01:33:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:33:14 --> Controller Class Initialized
DEBUG - 2020-10-28 01:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 01:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:33:14 --> Final output sent to browser
DEBUG - 2020-10-28 01:33:14 --> Total execution time: 0.3314
INFO - 2020-10-28 01:33:16 --> Config Class Initialized
INFO - 2020-10-28 01:33:16 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:33:16 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:33:16 --> Utf8 Class Initialized
INFO - 2020-10-28 01:33:16 --> URI Class Initialized
INFO - 2020-10-28 01:33:16 --> Router Class Initialized
INFO - 2020-10-28 01:33:16 --> Output Class Initialized
INFO - 2020-10-28 01:33:16 --> Security Class Initialized
DEBUG - 2020-10-28 01:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:33:16 --> Input Class Initialized
INFO - 2020-10-28 01:33:16 --> Language Class Initialized
INFO - 2020-10-28 01:33:16 --> Language Class Initialized
INFO - 2020-10-28 01:33:16 --> Config Class Initialized
INFO - 2020-10-28 01:33:16 --> Loader Class Initialized
INFO - 2020-10-28 01:33:16 --> Helper loaded: url_helper
INFO - 2020-10-28 01:33:16 --> Helper loaded: file_helper
INFO - 2020-10-28 01:33:16 --> Helper loaded: form_helper
INFO - 2020-10-28 01:33:16 --> Helper loaded: my_helper
INFO - 2020-10-28 01:33:16 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:33:16 --> Controller Class Initialized
DEBUG - 2020-10-28 01:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 01:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 01:33:16 --> Final output sent to browser
DEBUG - 2020-10-28 01:33:16 --> Total execution time: 0.3055
INFO - 2020-10-28 01:33:16 --> Config Class Initialized
INFO - 2020-10-28 01:33:16 --> Hooks Class Initialized
DEBUG - 2020-10-28 01:33:16 --> UTF-8 Support Enabled
INFO - 2020-10-28 01:33:16 --> Utf8 Class Initialized
INFO - 2020-10-28 01:33:16 --> URI Class Initialized
INFO - 2020-10-28 01:33:16 --> Router Class Initialized
INFO - 2020-10-28 01:33:16 --> Output Class Initialized
INFO - 2020-10-28 01:33:16 --> Security Class Initialized
DEBUG - 2020-10-28 01:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 01:33:16 --> Input Class Initialized
INFO - 2020-10-28 01:33:16 --> Language Class Initialized
INFO - 2020-10-28 01:33:16 --> Language Class Initialized
INFO - 2020-10-28 01:33:16 --> Config Class Initialized
INFO - 2020-10-28 01:33:16 --> Loader Class Initialized
INFO - 2020-10-28 01:33:16 --> Helper loaded: url_helper
INFO - 2020-10-28 01:33:16 --> Helper loaded: file_helper
INFO - 2020-10-28 01:33:16 --> Helper loaded: form_helper
INFO - 2020-10-28 01:33:16 --> Helper loaded: my_helper
INFO - 2020-10-28 01:33:16 --> Database Driver Class Initialized
DEBUG - 2020-10-28 01:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 01:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 01:33:16 --> Controller Class Initialized
INFO - 2020-10-28 02:50:52 --> Config Class Initialized
INFO - 2020-10-28 02:50:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:50:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:50:53 --> Utf8 Class Initialized
INFO - 2020-10-28 02:50:53 --> URI Class Initialized
INFO - 2020-10-28 02:50:53 --> Router Class Initialized
INFO - 2020-10-28 02:50:53 --> Output Class Initialized
INFO - 2020-10-28 02:50:53 --> Security Class Initialized
DEBUG - 2020-10-28 02:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:50:53 --> Input Class Initialized
INFO - 2020-10-28 02:50:53 --> Language Class Initialized
INFO - 2020-10-28 02:50:53 --> Language Class Initialized
INFO - 2020-10-28 02:50:53 --> Config Class Initialized
INFO - 2020-10-28 02:50:53 --> Loader Class Initialized
INFO - 2020-10-28 02:50:53 --> Helper loaded: url_helper
INFO - 2020-10-28 02:50:53 --> Helper loaded: file_helper
INFO - 2020-10-28 02:50:53 --> Helper loaded: form_helper
INFO - 2020-10-28 02:50:53 --> Helper loaded: my_helper
INFO - 2020-10-28 02:50:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:50:53 --> Controller Class Initialized
DEBUG - 2020-10-28 02:50:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-28 02:50:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:50:53 --> Final output sent to browser
DEBUG - 2020-10-28 02:50:53 --> Total execution time: 0.3235
INFO - 2020-10-28 02:50:54 --> Config Class Initialized
INFO - 2020-10-28 02:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:50:54 --> Utf8 Class Initialized
INFO - 2020-10-28 02:50:54 --> URI Class Initialized
INFO - 2020-10-28 02:50:54 --> Router Class Initialized
INFO - 2020-10-28 02:50:54 --> Output Class Initialized
INFO - 2020-10-28 02:50:54 --> Security Class Initialized
DEBUG - 2020-10-28 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:50:54 --> Input Class Initialized
INFO - 2020-10-28 02:50:54 --> Language Class Initialized
INFO - 2020-10-28 02:50:54 --> Language Class Initialized
INFO - 2020-10-28 02:50:54 --> Config Class Initialized
INFO - 2020-10-28 02:50:54 --> Loader Class Initialized
INFO - 2020-10-28 02:50:54 --> Helper loaded: url_helper
INFO - 2020-10-28 02:50:54 --> Helper loaded: file_helper
INFO - 2020-10-28 02:50:54 --> Helper loaded: form_helper
INFO - 2020-10-28 02:50:54 --> Helper loaded: my_helper
INFO - 2020-10-28 02:50:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:50:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:50:54 --> Controller Class Initialized
INFO - 2020-10-28 02:50:54 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:50:54 --> Config Class Initialized
INFO - 2020-10-28 02:50:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:50:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:50:54 --> Utf8 Class Initialized
INFO - 2020-10-28 02:50:54 --> URI Class Initialized
INFO - 2020-10-28 02:50:54 --> Router Class Initialized
INFO - 2020-10-28 02:50:54 --> Output Class Initialized
INFO - 2020-10-28 02:50:54 --> Security Class Initialized
DEBUG - 2020-10-28 02:50:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:50:55 --> Input Class Initialized
INFO - 2020-10-28 02:50:55 --> Language Class Initialized
INFO - 2020-10-28 02:50:55 --> Language Class Initialized
INFO - 2020-10-28 02:50:55 --> Config Class Initialized
INFO - 2020-10-28 02:50:55 --> Loader Class Initialized
INFO - 2020-10-28 02:50:55 --> Helper loaded: url_helper
INFO - 2020-10-28 02:50:55 --> Helper loaded: file_helper
INFO - 2020-10-28 02:50:55 --> Helper loaded: form_helper
INFO - 2020-10-28 02:50:55 --> Helper loaded: my_helper
INFO - 2020-10-28 02:50:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:50:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:50:55 --> Controller Class Initialized
DEBUG - 2020-10-28 02:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 02:50:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:50:55 --> Final output sent to browser
DEBUG - 2020-10-28 02:50:55 --> Total execution time: 0.2355
INFO - 2020-10-28 02:51:02 --> Config Class Initialized
INFO - 2020-10-28 02:51:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:02 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:02 --> URI Class Initialized
INFO - 2020-10-28 02:51:02 --> Router Class Initialized
INFO - 2020-10-28 02:51:02 --> Output Class Initialized
INFO - 2020-10-28 02:51:02 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:02 --> Input Class Initialized
INFO - 2020-10-28 02:51:02 --> Language Class Initialized
INFO - 2020-10-28 02:51:02 --> Language Class Initialized
INFO - 2020-10-28 02:51:02 --> Config Class Initialized
INFO - 2020-10-28 02:51:02 --> Loader Class Initialized
INFO - 2020-10-28 02:51:02 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:02 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:02 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:02 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:02 --> Controller Class Initialized
INFO - 2020-10-28 02:51:02 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:51:02 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:02 --> Total execution time: 0.2482
INFO - 2020-10-28 02:51:03 --> Config Class Initialized
INFO - 2020-10-28 02:51:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:03 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:03 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:03 --> URI Class Initialized
INFO - 2020-10-28 02:51:03 --> Router Class Initialized
INFO - 2020-10-28 02:51:03 --> Output Class Initialized
INFO - 2020-10-28 02:51:03 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:03 --> Input Class Initialized
INFO - 2020-10-28 02:51:03 --> Language Class Initialized
INFO - 2020-10-28 02:51:03 --> Language Class Initialized
INFO - 2020-10-28 02:51:03 --> Config Class Initialized
INFO - 2020-10-28 02:51:03 --> Loader Class Initialized
INFO - 2020-10-28 02:51:03 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:03 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:03 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:03 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:03 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:03 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 02:51:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:03 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:03 --> Total execution time: 0.2802
INFO - 2020-10-28 02:51:05 --> Config Class Initialized
INFO - 2020-10-28 02:51:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:05 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:05 --> URI Class Initialized
INFO - 2020-10-28 02:51:05 --> Router Class Initialized
INFO - 2020-10-28 02:51:05 --> Output Class Initialized
INFO - 2020-10-28 02:51:05 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:05 --> Input Class Initialized
INFO - 2020-10-28 02:51:05 --> Language Class Initialized
INFO - 2020-10-28 02:51:05 --> Language Class Initialized
INFO - 2020-10-28 02:51:05 --> Config Class Initialized
INFO - 2020-10-28 02:51:05 --> Loader Class Initialized
INFO - 2020-10-28 02:51:05 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:05 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:05 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:05 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:05 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2020-10-28 02:51:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:05 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:05 --> Total execution time: 0.3378
INFO - 2020-10-28 02:51:10 --> Config Class Initialized
INFO - 2020-10-28 02:51:10 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:10 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:10 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:10 --> URI Class Initialized
INFO - 2020-10-28 02:51:10 --> Router Class Initialized
INFO - 2020-10-28 02:51:10 --> Output Class Initialized
INFO - 2020-10-28 02:51:10 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:10 --> Input Class Initialized
INFO - 2020-10-28 02:51:10 --> Language Class Initialized
INFO - 2020-10-28 02:51:10 --> Language Class Initialized
INFO - 2020-10-28 02:51:10 --> Config Class Initialized
INFO - 2020-10-28 02:51:10 --> Loader Class Initialized
INFO - 2020-10-28 02:51:10 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:10 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:10 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:10 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:10 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:10 --> Controller Class Initialized
INFO - 2020-10-28 02:51:10 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:51:10 --> Config Class Initialized
INFO - 2020-10-28 02:51:10 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:10 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:10 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:10 --> URI Class Initialized
INFO - 2020-10-28 02:51:10 --> Router Class Initialized
INFO - 2020-10-28 02:51:10 --> Output Class Initialized
INFO - 2020-10-28 02:51:10 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:10 --> Input Class Initialized
INFO - 2020-10-28 02:51:10 --> Language Class Initialized
INFO - 2020-10-28 02:51:10 --> Language Class Initialized
INFO - 2020-10-28 02:51:10 --> Config Class Initialized
INFO - 2020-10-28 02:51:10 --> Loader Class Initialized
INFO - 2020-10-28 02:51:10 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:10 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:10 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:10 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:10 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:10 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 02:51:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:10 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:10 --> Total execution time: 0.2385
INFO - 2020-10-28 02:51:23 --> Config Class Initialized
INFO - 2020-10-28 02:51:23 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:23 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:23 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:23 --> URI Class Initialized
INFO - 2020-10-28 02:51:23 --> Router Class Initialized
INFO - 2020-10-28 02:51:23 --> Output Class Initialized
INFO - 2020-10-28 02:51:23 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:23 --> Input Class Initialized
INFO - 2020-10-28 02:51:23 --> Language Class Initialized
INFO - 2020-10-28 02:51:23 --> Language Class Initialized
INFO - 2020-10-28 02:51:23 --> Config Class Initialized
INFO - 2020-10-28 02:51:23 --> Loader Class Initialized
INFO - 2020-10-28 02:51:23 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:23 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:23 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:23 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:23 --> Controller Class Initialized
INFO - 2020-10-28 02:51:23 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:51:23 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:23 --> Total execution time: 0.2486
INFO - 2020-10-28 02:51:24 --> Config Class Initialized
INFO - 2020-10-28 02:51:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:24 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:24 --> URI Class Initialized
INFO - 2020-10-28 02:51:24 --> Router Class Initialized
INFO - 2020-10-28 02:51:24 --> Output Class Initialized
INFO - 2020-10-28 02:51:24 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:24 --> Input Class Initialized
INFO - 2020-10-28 02:51:24 --> Language Class Initialized
INFO - 2020-10-28 02:51:24 --> Language Class Initialized
INFO - 2020-10-28 02:51:24 --> Config Class Initialized
INFO - 2020-10-28 02:51:24 --> Loader Class Initialized
INFO - 2020-10-28 02:51:24 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:24 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:24 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:24 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:24 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:24 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 02:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:24 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:24 --> Total execution time: 0.2821
INFO - 2020-10-28 02:51:25 --> Config Class Initialized
INFO - 2020-10-28 02:51:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:26 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:26 --> URI Class Initialized
INFO - 2020-10-28 02:51:26 --> Router Class Initialized
INFO - 2020-10-28 02:51:26 --> Output Class Initialized
INFO - 2020-10-28 02:51:26 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:26 --> Input Class Initialized
INFO - 2020-10-28 02:51:26 --> Language Class Initialized
INFO - 2020-10-28 02:51:26 --> Language Class Initialized
INFO - 2020-10-28 02:51:26 --> Config Class Initialized
INFO - 2020-10-28 02:51:26 --> Loader Class Initialized
INFO - 2020-10-28 02:51:26 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:26 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:26 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:26 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:26 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 02:51:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:26 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:26 --> Total execution time: 0.2654
INFO - 2020-10-28 02:51:26 --> Config Class Initialized
INFO - 2020-10-28 02:51:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:26 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:26 --> URI Class Initialized
INFO - 2020-10-28 02:51:26 --> Router Class Initialized
INFO - 2020-10-28 02:51:26 --> Output Class Initialized
INFO - 2020-10-28 02:51:26 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:26 --> Input Class Initialized
INFO - 2020-10-28 02:51:26 --> Language Class Initialized
INFO - 2020-10-28 02:51:26 --> Language Class Initialized
INFO - 2020-10-28 02:51:26 --> Config Class Initialized
INFO - 2020-10-28 02:51:26 --> Loader Class Initialized
INFO - 2020-10-28 02:51:26 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:26 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:26 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:26 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:26 --> Controller Class Initialized
INFO - 2020-10-28 02:51:37 --> Config Class Initialized
INFO - 2020-10-28 02:51:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:37 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:37 --> URI Class Initialized
INFO - 2020-10-28 02:51:37 --> Router Class Initialized
INFO - 2020-10-28 02:51:37 --> Output Class Initialized
INFO - 2020-10-28 02:51:37 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:37 --> Input Class Initialized
INFO - 2020-10-28 02:51:37 --> Language Class Initialized
INFO - 2020-10-28 02:51:37 --> Language Class Initialized
INFO - 2020-10-28 02:51:37 --> Config Class Initialized
INFO - 2020-10-28 02:51:37 --> Loader Class Initialized
INFO - 2020-10-28 02:51:37 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:37 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:37 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:37 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:37 --> Controller Class Initialized
ERROR - 2020-10-28 02:51:37 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-28 02:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-28 02:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:37 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:37 --> Total execution time: 0.3177
INFO - 2020-10-28 02:51:39 --> Config Class Initialized
INFO - 2020-10-28 02:51:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:39 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:39 --> URI Class Initialized
INFO - 2020-10-28 02:51:39 --> Router Class Initialized
INFO - 2020-10-28 02:51:39 --> Output Class Initialized
INFO - 2020-10-28 02:51:39 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:39 --> Input Class Initialized
INFO - 2020-10-28 02:51:39 --> Language Class Initialized
INFO - 2020-10-28 02:51:39 --> Language Class Initialized
INFO - 2020-10-28 02:51:39 --> Config Class Initialized
INFO - 2020-10-28 02:51:39 --> Loader Class Initialized
INFO - 2020-10-28 02:51:39 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:39 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:39 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:39 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:39 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:39 --> Controller Class Initialized
INFO - 2020-10-28 02:51:39 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:51:39 --> Config Class Initialized
INFO - 2020-10-28 02:51:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:39 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:39 --> URI Class Initialized
INFO - 2020-10-28 02:51:39 --> Router Class Initialized
INFO - 2020-10-28 02:51:39 --> Output Class Initialized
INFO - 2020-10-28 02:51:39 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:39 --> Input Class Initialized
INFO - 2020-10-28 02:51:39 --> Language Class Initialized
INFO - 2020-10-28 02:51:39 --> Language Class Initialized
INFO - 2020-10-28 02:51:39 --> Config Class Initialized
INFO - 2020-10-28 02:51:39 --> Loader Class Initialized
INFO - 2020-10-28 02:51:40 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:40 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:40 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:40 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:40 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:40 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 02:51:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:40 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:40 --> Total execution time: 0.2467
INFO - 2020-10-28 02:51:47 --> Config Class Initialized
INFO - 2020-10-28 02:51:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:47 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:47 --> URI Class Initialized
INFO - 2020-10-28 02:51:47 --> Router Class Initialized
INFO - 2020-10-28 02:51:47 --> Output Class Initialized
INFO - 2020-10-28 02:51:47 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:47 --> Input Class Initialized
INFO - 2020-10-28 02:51:47 --> Language Class Initialized
INFO - 2020-10-28 02:51:47 --> Language Class Initialized
INFO - 2020-10-28 02:51:47 --> Config Class Initialized
INFO - 2020-10-28 02:51:47 --> Loader Class Initialized
INFO - 2020-10-28 02:51:47 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:47 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:47 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:47 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:47 --> Controller Class Initialized
INFO - 2020-10-28 02:51:47 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:51:47 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:47 --> Total execution time: 0.2524
INFO - 2020-10-28 02:51:48 --> Config Class Initialized
INFO - 2020-10-28 02:51:48 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:48 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:48 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:48 --> URI Class Initialized
INFO - 2020-10-28 02:51:48 --> Router Class Initialized
INFO - 2020-10-28 02:51:48 --> Output Class Initialized
INFO - 2020-10-28 02:51:48 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:48 --> Input Class Initialized
INFO - 2020-10-28 02:51:48 --> Language Class Initialized
INFO - 2020-10-28 02:51:48 --> Language Class Initialized
INFO - 2020-10-28 02:51:48 --> Config Class Initialized
INFO - 2020-10-28 02:51:48 --> Loader Class Initialized
INFO - 2020-10-28 02:51:48 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:48 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:48 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:48 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:48 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 02:51:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:48 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:49 --> Total execution time: 0.3015
INFO - 2020-10-28 02:51:50 --> Config Class Initialized
INFO - 2020-10-28 02:51:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:50 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:50 --> URI Class Initialized
INFO - 2020-10-28 02:51:50 --> Router Class Initialized
INFO - 2020-10-28 02:51:50 --> Output Class Initialized
INFO - 2020-10-28 02:51:50 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:50 --> Input Class Initialized
INFO - 2020-10-28 02:51:50 --> Language Class Initialized
INFO - 2020-10-28 02:51:50 --> Language Class Initialized
INFO - 2020-10-28 02:51:50 --> Config Class Initialized
INFO - 2020-10-28 02:51:50 --> Loader Class Initialized
INFO - 2020-10-28 02:51:50 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:50 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:50 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:50 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:50 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 02:51:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:50 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:50 --> Total execution time: 0.2850
INFO - 2020-10-28 02:51:50 --> Config Class Initialized
INFO - 2020-10-28 02:51:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:50 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:50 --> URI Class Initialized
INFO - 2020-10-28 02:51:50 --> Router Class Initialized
INFO - 2020-10-28 02:51:50 --> Output Class Initialized
INFO - 2020-10-28 02:51:50 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:50 --> Input Class Initialized
INFO - 2020-10-28 02:51:50 --> Language Class Initialized
INFO - 2020-10-28 02:51:50 --> Language Class Initialized
INFO - 2020-10-28 02:51:50 --> Config Class Initialized
INFO - 2020-10-28 02:51:50 --> Loader Class Initialized
INFO - 2020-10-28 02:51:50 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:50 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:50 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:50 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:50 --> Controller Class Initialized
INFO - 2020-10-28 02:51:54 --> Config Class Initialized
INFO - 2020-10-28 02:51:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:54 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:54 --> URI Class Initialized
INFO - 2020-10-28 02:51:54 --> Router Class Initialized
INFO - 2020-10-28 02:51:54 --> Output Class Initialized
INFO - 2020-10-28 02:51:54 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:54 --> Input Class Initialized
INFO - 2020-10-28 02:51:54 --> Language Class Initialized
INFO - 2020-10-28 02:51:54 --> Language Class Initialized
INFO - 2020-10-28 02:51:54 --> Config Class Initialized
INFO - 2020-10-28 02:51:54 --> Loader Class Initialized
INFO - 2020-10-28 02:51:54 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:54 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:54 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:54 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:54 --> Controller Class Initialized
INFO - 2020-10-28 02:51:54 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:54 --> Total execution time: 0.2794
INFO - 2020-10-28 02:51:54 --> Config Class Initialized
INFO - 2020-10-28 02:51:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:54 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:54 --> URI Class Initialized
INFO - 2020-10-28 02:51:54 --> Router Class Initialized
INFO - 2020-10-28 02:51:54 --> Output Class Initialized
INFO - 2020-10-28 02:51:54 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:54 --> Input Class Initialized
INFO - 2020-10-28 02:51:54 --> Language Class Initialized
INFO - 2020-10-28 02:51:54 --> Language Class Initialized
INFO - 2020-10-28 02:51:55 --> Config Class Initialized
INFO - 2020-10-28 02:51:55 --> Loader Class Initialized
INFO - 2020-10-28 02:51:55 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:55 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:55 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:55 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:55 --> Controller Class Initialized
INFO - 2020-10-28 02:51:56 --> Config Class Initialized
INFO - 2020-10-28 02:51:56 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:56 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:56 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:56 --> URI Class Initialized
INFO - 2020-10-28 02:51:56 --> Router Class Initialized
INFO - 2020-10-28 02:51:56 --> Output Class Initialized
INFO - 2020-10-28 02:51:56 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:56 --> Input Class Initialized
INFO - 2020-10-28 02:51:56 --> Language Class Initialized
INFO - 2020-10-28 02:51:56 --> Language Class Initialized
INFO - 2020-10-28 02:51:56 --> Config Class Initialized
INFO - 2020-10-28 02:51:56 --> Loader Class Initialized
INFO - 2020-10-28 02:51:56 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:56 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:56 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:56 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:56 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:56 --> Controller Class Initialized
ERROR - 2020-10-28 02:51:56 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-28 02:51:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-28 02:51:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:56 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:56 --> Total execution time: 0.3005
INFO - 2020-10-28 02:51:58 --> Config Class Initialized
INFO - 2020-10-28 02:51:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:58 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:58 --> URI Class Initialized
INFO - 2020-10-28 02:51:58 --> Router Class Initialized
INFO - 2020-10-28 02:51:59 --> Output Class Initialized
INFO - 2020-10-28 02:51:59 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:59 --> Input Class Initialized
INFO - 2020-10-28 02:51:59 --> Language Class Initialized
INFO - 2020-10-28 02:51:59 --> Language Class Initialized
INFO - 2020-10-28 02:51:59 --> Config Class Initialized
INFO - 2020-10-28 02:51:59 --> Loader Class Initialized
INFO - 2020-10-28 02:51:59 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:59 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:59 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:59 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:59 --> Controller Class Initialized
INFO - 2020-10-28 02:51:59 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:51:59 --> Config Class Initialized
INFO - 2020-10-28 02:51:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:51:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:51:59 --> Utf8 Class Initialized
INFO - 2020-10-28 02:51:59 --> URI Class Initialized
INFO - 2020-10-28 02:51:59 --> Router Class Initialized
INFO - 2020-10-28 02:51:59 --> Output Class Initialized
INFO - 2020-10-28 02:51:59 --> Security Class Initialized
DEBUG - 2020-10-28 02:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:51:59 --> Input Class Initialized
INFO - 2020-10-28 02:51:59 --> Language Class Initialized
INFO - 2020-10-28 02:51:59 --> Language Class Initialized
INFO - 2020-10-28 02:51:59 --> Config Class Initialized
INFO - 2020-10-28 02:51:59 --> Loader Class Initialized
INFO - 2020-10-28 02:51:59 --> Helper loaded: url_helper
INFO - 2020-10-28 02:51:59 --> Helper loaded: file_helper
INFO - 2020-10-28 02:51:59 --> Helper loaded: form_helper
INFO - 2020-10-28 02:51:59 --> Helper loaded: my_helper
INFO - 2020-10-28 02:51:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:51:59 --> Controller Class Initialized
DEBUG - 2020-10-28 02:51:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 02:51:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:51:59 --> Final output sent to browser
DEBUG - 2020-10-28 02:51:59 --> Total execution time: 0.2596
INFO - 2020-10-28 02:52:02 --> Config Class Initialized
INFO - 2020-10-28 02:52:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:02 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:02 --> URI Class Initialized
INFO - 2020-10-28 02:52:02 --> Router Class Initialized
INFO - 2020-10-28 02:52:02 --> Output Class Initialized
INFO - 2020-10-28 02:52:02 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:02 --> Input Class Initialized
INFO - 2020-10-28 02:52:02 --> Language Class Initialized
INFO - 2020-10-28 02:52:02 --> Language Class Initialized
INFO - 2020-10-28 02:52:02 --> Config Class Initialized
INFO - 2020-10-28 02:52:02 --> Loader Class Initialized
INFO - 2020-10-28 02:52:02 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:02 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:02 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:02 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:02 --> Controller Class Initialized
INFO - 2020-10-28 02:52:02 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:52:02 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:02 --> Total execution time: 0.2694
INFO - 2020-10-28 02:52:03 --> Config Class Initialized
INFO - 2020-10-28 02:52:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:03 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:03 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:03 --> URI Class Initialized
INFO - 2020-10-28 02:52:03 --> Router Class Initialized
INFO - 2020-10-28 02:52:03 --> Output Class Initialized
INFO - 2020-10-28 02:52:03 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:04 --> Input Class Initialized
INFO - 2020-10-28 02:52:04 --> Language Class Initialized
INFO - 2020-10-28 02:52:04 --> Language Class Initialized
INFO - 2020-10-28 02:52:04 --> Config Class Initialized
INFO - 2020-10-28 02:52:04 --> Loader Class Initialized
INFO - 2020-10-28 02:52:04 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:04 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:04 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:04 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:04 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:04 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-10-28 02:52:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:04 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:04 --> Total execution time: 0.3087
INFO - 2020-10-28 02:52:06 --> Config Class Initialized
INFO - 2020-10-28 02:52:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:06 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:06 --> URI Class Initialized
INFO - 2020-10-28 02:52:06 --> Router Class Initialized
INFO - 2020-10-28 02:52:06 --> Output Class Initialized
INFO - 2020-10-28 02:52:06 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:06 --> Input Class Initialized
INFO - 2020-10-28 02:52:06 --> Language Class Initialized
INFO - 2020-10-28 02:52:06 --> Language Class Initialized
INFO - 2020-10-28 02:52:06 --> Config Class Initialized
INFO - 2020-10-28 02:52:06 --> Loader Class Initialized
INFO - 2020-10-28 02:52:06 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:06 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:06 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:06 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:06 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/lihat_raport/views/list.php
DEBUG - 2020-10-28 02:52:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:06 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:06 --> Total execution time: 0.3384
INFO - 2020-10-28 02:52:07 --> Config Class Initialized
INFO - 2020-10-28 02:52:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:07 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:07 --> URI Class Initialized
DEBUG - 2020-10-28 02:52:07 --> No URI present. Default controller set.
INFO - 2020-10-28 02:52:07 --> Router Class Initialized
INFO - 2020-10-28 02:52:07 --> Output Class Initialized
INFO - 2020-10-28 02:52:07 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:07 --> Input Class Initialized
INFO - 2020-10-28 02:52:07 --> Language Class Initialized
INFO - 2020-10-28 02:52:07 --> Language Class Initialized
INFO - 2020-10-28 02:52:07 --> Config Class Initialized
INFO - 2020-10-28 02:52:07 --> Loader Class Initialized
INFO - 2020-10-28 02:52:07 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:07 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:07 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:07 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:08 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:08 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home_siswa.php
DEBUG - 2020-10-28 02:52:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:08 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:08 --> Total execution time: 0.2886
INFO - 2020-10-28 02:52:10 --> Config Class Initialized
INFO - 2020-10-28 02:52:10 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:10 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:10 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:10 --> URI Class Initialized
INFO - 2020-10-28 02:52:10 --> Router Class Initialized
INFO - 2020-10-28 02:52:10 --> Output Class Initialized
INFO - 2020-10-28 02:52:10 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:10 --> Input Class Initialized
INFO - 2020-10-28 02:52:10 --> Language Class Initialized
INFO - 2020-10-28 02:52:10 --> Language Class Initialized
INFO - 2020-10-28 02:52:10 --> Config Class Initialized
INFO - 2020-10-28 02:52:10 --> Loader Class Initialized
INFO - 2020-10-28 02:52:10 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:10 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:10 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:10 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:10 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:10 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/lihat_raport/views/list.php
DEBUG - 2020-10-28 02:52:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:10 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:10 --> Total execution time: 0.2761
INFO - 2020-10-28 02:52:12 --> Config Class Initialized
INFO - 2020-10-28 02:52:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:12 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:12 --> URI Class Initialized
INFO - 2020-10-28 02:52:12 --> Router Class Initialized
INFO - 2020-10-28 02:52:12 --> Output Class Initialized
INFO - 2020-10-28 02:52:12 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:12 --> Input Class Initialized
INFO - 2020-10-28 02:52:12 --> Language Class Initialized
INFO - 2020-10-28 02:52:12 --> Language Class Initialized
INFO - 2020-10-28 02:52:12 --> Config Class Initialized
INFO - 2020-10-28 02:52:12 --> Loader Class Initialized
INFO - 2020-10-28 02:52:12 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:12 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:12 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:12 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:12 --> Controller Class Initialized
INFO - 2020-10-28 02:52:13 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:52:13 --> Config Class Initialized
INFO - 2020-10-28 02:52:13 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:13 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:13 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:13 --> URI Class Initialized
INFO - 2020-10-28 02:52:13 --> Router Class Initialized
INFO - 2020-10-28 02:52:13 --> Output Class Initialized
INFO - 2020-10-28 02:52:13 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:13 --> Input Class Initialized
INFO - 2020-10-28 02:52:13 --> Language Class Initialized
INFO - 2020-10-28 02:52:13 --> Language Class Initialized
INFO - 2020-10-28 02:52:13 --> Config Class Initialized
INFO - 2020-10-28 02:52:13 --> Loader Class Initialized
INFO - 2020-10-28 02:52:13 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:13 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:13 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:13 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:13 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:13 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 02:52:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:13 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:13 --> Total execution time: 0.2807
INFO - 2020-10-28 02:52:25 --> Config Class Initialized
INFO - 2020-10-28 02:52:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:25 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:25 --> URI Class Initialized
INFO - 2020-10-28 02:52:25 --> Router Class Initialized
INFO - 2020-10-28 02:52:25 --> Output Class Initialized
INFO - 2020-10-28 02:52:25 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:25 --> Input Class Initialized
INFO - 2020-10-28 02:52:25 --> Language Class Initialized
INFO - 2020-10-28 02:52:25 --> Language Class Initialized
INFO - 2020-10-28 02:52:25 --> Config Class Initialized
INFO - 2020-10-28 02:52:25 --> Loader Class Initialized
INFO - 2020-10-28 02:52:25 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:25 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:25 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:25 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:25 --> Controller Class Initialized
INFO - 2020-10-28 02:52:25 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:52:25 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:25 --> Total execution time: 0.2765
INFO - 2020-10-28 02:52:26 --> Config Class Initialized
INFO - 2020-10-28 02:52:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:26 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:26 --> URI Class Initialized
INFO - 2020-10-28 02:52:26 --> Router Class Initialized
INFO - 2020-10-28 02:52:26 --> Output Class Initialized
INFO - 2020-10-28 02:52:26 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:26 --> Input Class Initialized
INFO - 2020-10-28 02:52:26 --> Language Class Initialized
INFO - 2020-10-28 02:52:27 --> Language Class Initialized
INFO - 2020-10-28 02:52:27 --> Config Class Initialized
INFO - 2020-10-28 02:52:27 --> Loader Class Initialized
INFO - 2020-10-28 02:52:27 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:27 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:27 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:27 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:27 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 02:52:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:27 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:27 --> Total execution time: 0.2811
INFO - 2020-10-28 02:52:29 --> Config Class Initialized
INFO - 2020-10-28 02:52:29 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:29 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:29 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:29 --> URI Class Initialized
INFO - 2020-10-28 02:52:29 --> Router Class Initialized
INFO - 2020-10-28 02:52:29 --> Output Class Initialized
INFO - 2020-10-28 02:52:29 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:29 --> Input Class Initialized
INFO - 2020-10-28 02:52:29 --> Language Class Initialized
INFO - 2020-10-28 02:52:29 --> Language Class Initialized
INFO - 2020-10-28 02:52:29 --> Config Class Initialized
INFO - 2020-10-28 02:52:29 --> Loader Class Initialized
INFO - 2020-10-28 02:52:29 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:29 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:29 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:29 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:29 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:29 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 02:52:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:29 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:29 --> Total execution time: 0.2673
INFO - 2020-10-28 02:52:31 --> Config Class Initialized
INFO - 2020-10-28 02:52:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:31 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:31 --> URI Class Initialized
INFO - 2020-10-28 02:52:31 --> Router Class Initialized
INFO - 2020-10-28 02:52:31 --> Output Class Initialized
INFO - 2020-10-28 02:52:31 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:31 --> Input Class Initialized
INFO - 2020-10-28 02:52:31 --> Language Class Initialized
INFO - 2020-10-28 02:52:31 --> Language Class Initialized
INFO - 2020-10-28 02:52:31 --> Config Class Initialized
INFO - 2020-10-28 02:52:31 --> Loader Class Initialized
INFO - 2020-10-28 02:52:31 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:31 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:31 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:31 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:31 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 02:52:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:31 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:31 --> Total execution time: 0.2598
INFO - 2020-10-28 02:52:31 --> Config Class Initialized
INFO - 2020-10-28 02:52:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:31 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:31 --> URI Class Initialized
INFO - 2020-10-28 02:52:31 --> Router Class Initialized
INFO - 2020-10-28 02:52:31 --> Output Class Initialized
INFO - 2020-10-28 02:52:31 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:31 --> Input Class Initialized
INFO - 2020-10-28 02:52:31 --> Language Class Initialized
INFO - 2020-10-28 02:52:31 --> Language Class Initialized
INFO - 2020-10-28 02:52:31 --> Config Class Initialized
INFO - 2020-10-28 02:52:32 --> Loader Class Initialized
INFO - 2020-10-28 02:52:32 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:32 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:32 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:32 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:32 --> Controller Class Initialized
INFO - 2020-10-28 02:52:33 --> Config Class Initialized
INFO - 2020-10-28 02:52:33 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:34 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:34 --> URI Class Initialized
INFO - 2020-10-28 02:52:34 --> Router Class Initialized
INFO - 2020-10-28 02:52:34 --> Output Class Initialized
INFO - 2020-10-28 02:52:34 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:34 --> Input Class Initialized
INFO - 2020-10-28 02:52:34 --> Language Class Initialized
INFO - 2020-10-28 02:52:34 --> Language Class Initialized
INFO - 2020-10-28 02:52:34 --> Config Class Initialized
INFO - 2020-10-28 02:52:34 --> Loader Class Initialized
INFO - 2020-10-28 02:52:34 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:34 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:34 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:34 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:34 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-10-28 02:52:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:34 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:34 --> Total execution time: 0.2608
INFO - 2020-10-28 02:52:35 --> Config Class Initialized
INFO - 2020-10-28 02:52:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:35 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:35 --> URI Class Initialized
INFO - 2020-10-28 02:52:35 --> Router Class Initialized
INFO - 2020-10-28 02:52:35 --> Output Class Initialized
INFO - 2020-10-28 02:52:35 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:35 --> Input Class Initialized
INFO - 2020-10-28 02:52:35 --> Language Class Initialized
INFO - 2020-10-28 02:52:35 --> Language Class Initialized
INFO - 2020-10-28 02:52:35 --> Config Class Initialized
INFO - 2020-10-28 02:52:35 --> Loader Class Initialized
INFO - 2020-10-28 02:52:35 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:35 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:35 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:35 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:36 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-10-28 02:52:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:36 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:36 --> Total execution time: 0.2739
INFO - 2020-10-28 02:52:36 --> Config Class Initialized
INFO - 2020-10-28 02:52:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:36 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:36 --> URI Class Initialized
INFO - 2020-10-28 02:52:36 --> Router Class Initialized
INFO - 2020-10-28 02:52:36 --> Output Class Initialized
INFO - 2020-10-28 02:52:36 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:36 --> Input Class Initialized
INFO - 2020-10-28 02:52:36 --> Language Class Initialized
INFO - 2020-10-28 02:52:36 --> Language Class Initialized
INFO - 2020-10-28 02:52:36 --> Config Class Initialized
INFO - 2020-10-28 02:52:36 --> Loader Class Initialized
INFO - 2020-10-28 02:52:36 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:36 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:36 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:36 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:36 --> Controller Class Initialized
INFO - 2020-10-28 02:52:38 --> Config Class Initialized
INFO - 2020-10-28 02:52:38 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:38 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:38 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:38 --> URI Class Initialized
INFO - 2020-10-28 02:52:38 --> Router Class Initialized
INFO - 2020-10-28 02:52:38 --> Output Class Initialized
INFO - 2020-10-28 02:52:38 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:38 --> Input Class Initialized
INFO - 2020-10-28 02:52:38 --> Language Class Initialized
INFO - 2020-10-28 02:52:38 --> Language Class Initialized
INFO - 2020-10-28 02:52:38 --> Config Class Initialized
INFO - 2020-10-28 02:52:38 --> Loader Class Initialized
INFO - 2020-10-28 02:52:38 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:38 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:38 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:38 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:38 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:38 --> Controller Class Initialized
INFO - 2020-10-28 02:52:38 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:38 --> Total execution time: 0.2292
INFO - 2020-10-28 02:52:52 --> Config Class Initialized
INFO - 2020-10-28 02:52:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:52 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:52 --> URI Class Initialized
INFO - 2020-10-28 02:52:52 --> Router Class Initialized
INFO - 2020-10-28 02:52:52 --> Output Class Initialized
INFO - 2020-10-28 02:52:52 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:52 --> Input Class Initialized
INFO - 2020-10-28 02:52:52 --> Language Class Initialized
INFO - 2020-10-28 02:52:52 --> Language Class Initialized
INFO - 2020-10-28 02:52:52 --> Config Class Initialized
INFO - 2020-10-28 02:52:52 --> Loader Class Initialized
INFO - 2020-10-28 02:52:52 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:53 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:53 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:53 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:53 --> Controller Class Initialized
INFO - 2020-10-28 02:52:53 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:52:53 --> Config Class Initialized
INFO - 2020-10-28 02:52:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:53 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:53 --> URI Class Initialized
INFO - 2020-10-28 02:52:53 --> Router Class Initialized
INFO - 2020-10-28 02:52:53 --> Output Class Initialized
INFO - 2020-10-28 02:52:53 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:53 --> Input Class Initialized
INFO - 2020-10-28 02:52:53 --> Language Class Initialized
INFO - 2020-10-28 02:52:53 --> Language Class Initialized
INFO - 2020-10-28 02:52:53 --> Config Class Initialized
INFO - 2020-10-28 02:52:53 --> Loader Class Initialized
INFO - 2020-10-28 02:52:53 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:53 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:53 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:53 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:53 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-28 02:52:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:53 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:53 --> Total execution time: 0.2842
INFO - 2020-10-28 02:52:57 --> Config Class Initialized
INFO - 2020-10-28 02:52:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:57 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:57 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:57 --> URI Class Initialized
INFO - 2020-10-28 02:52:57 --> Router Class Initialized
INFO - 2020-10-28 02:52:57 --> Output Class Initialized
INFO - 2020-10-28 02:52:57 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:57 --> Input Class Initialized
INFO - 2020-10-28 02:52:57 --> Language Class Initialized
INFO - 2020-10-28 02:52:57 --> Language Class Initialized
INFO - 2020-10-28 02:52:57 --> Config Class Initialized
INFO - 2020-10-28 02:52:57 --> Loader Class Initialized
INFO - 2020-10-28 02:52:57 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:57 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:57 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:57 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:58 --> Controller Class Initialized
INFO - 2020-10-28 02:52:58 --> Helper loaded: cookie_helper
INFO - 2020-10-28 02:52:58 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:58 --> Total execution time: 0.2802
INFO - 2020-10-28 02:52:58 --> Config Class Initialized
INFO - 2020-10-28 02:52:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:52:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:52:58 --> Utf8 Class Initialized
INFO - 2020-10-28 02:52:58 --> URI Class Initialized
INFO - 2020-10-28 02:52:58 --> Router Class Initialized
INFO - 2020-10-28 02:52:58 --> Output Class Initialized
INFO - 2020-10-28 02:52:58 --> Security Class Initialized
DEBUG - 2020-10-28 02:52:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:52:58 --> Input Class Initialized
INFO - 2020-10-28 02:52:58 --> Language Class Initialized
INFO - 2020-10-28 02:52:58 --> Language Class Initialized
INFO - 2020-10-28 02:52:58 --> Config Class Initialized
INFO - 2020-10-28 02:52:58 --> Loader Class Initialized
INFO - 2020-10-28 02:52:58 --> Helper loaded: url_helper
INFO - 2020-10-28 02:52:58 --> Helper loaded: file_helper
INFO - 2020-10-28 02:52:58 --> Helper loaded: form_helper
INFO - 2020-10-28 02:52:58 --> Helper loaded: my_helper
INFO - 2020-10-28 02:52:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:52:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:52:58 --> Controller Class Initialized
DEBUG - 2020-10-28 02:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-28 02:52:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:52:58 --> Final output sent to browser
DEBUG - 2020-10-28 02:52:58 --> Total execution time: 0.3160
INFO - 2020-10-28 02:53:01 --> Config Class Initialized
INFO - 2020-10-28 02:53:01 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:01 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:01 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:01 --> URI Class Initialized
INFO - 2020-10-28 02:53:01 --> Router Class Initialized
INFO - 2020-10-28 02:53:01 --> Output Class Initialized
INFO - 2020-10-28 02:53:01 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:01 --> Input Class Initialized
INFO - 2020-10-28 02:53:01 --> Language Class Initialized
INFO - 2020-10-28 02:53:01 --> Language Class Initialized
INFO - 2020-10-28 02:53:01 --> Config Class Initialized
INFO - 2020-10-28 02:53:01 --> Loader Class Initialized
INFO - 2020-10-28 02:53:01 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:01 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:01 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:01 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:01 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:01 --> Controller Class Initialized
DEBUG - 2020-10-28 02:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 02:53:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:53:01 --> Final output sent to browser
DEBUG - 2020-10-28 02:53:01 --> Total execution time: 0.2850
INFO - 2020-10-28 02:53:07 --> Config Class Initialized
INFO - 2020-10-28 02:53:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:07 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:07 --> URI Class Initialized
INFO - 2020-10-28 02:53:07 --> Router Class Initialized
INFO - 2020-10-28 02:53:07 --> Output Class Initialized
INFO - 2020-10-28 02:53:07 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:07 --> Input Class Initialized
INFO - 2020-10-28 02:53:07 --> Language Class Initialized
INFO - 2020-10-28 02:53:07 --> Language Class Initialized
INFO - 2020-10-28 02:53:07 --> Config Class Initialized
INFO - 2020-10-28 02:53:07 --> Loader Class Initialized
INFO - 2020-10-28 02:53:07 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:07 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:07 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:07 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:07 --> Controller Class Initialized
DEBUG - 2020-10-28 02:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 02:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:53:07 --> Final output sent to browser
DEBUG - 2020-10-28 02:53:07 --> Total execution time: 0.2695
INFO - 2020-10-28 02:53:07 --> Config Class Initialized
INFO - 2020-10-28 02:53:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:07 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:07 --> URI Class Initialized
INFO - 2020-10-28 02:53:07 --> Router Class Initialized
INFO - 2020-10-28 02:53:07 --> Output Class Initialized
INFO - 2020-10-28 02:53:07 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:07 --> Input Class Initialized
INFO - 2020-10-28 02:53:07 --> Language Class Initialized
INFO - 2020-10-28 02:53:07 --> Language Class Initialized
INFO - 2020-10-28 02:53:07 --> Config Class Initialized
INFO - 2020-10-28 02:53:07 --> Loader Class Initialized
INFO - 2020-10-28 02:53:07 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:07 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:07 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:07 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:07 --> Controller Class Initialized
INFO - 2020-10-28 02:53:09 --> Config Class Initialized
INFO - 2020-10-28 02:53:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:09 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:09 --> URI Class Initialized
INFO - 2020-10-28 02:53:09 --> Router Class Initialized
INFO - 2020-10-28 02:53:09 --> Output Class Initialized
INFO - 2020-10-28 02:53:09 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:09 --> Input Class Initialized
INFO - 2020-10-28 02:53:09 --> Language Class Initialized
INFO - 2020-10-28 02:53:09 --> Language Class Initialized
INFO - 2020-10-28 02:53:09 --> Config Class Initialized
INFO - 2020-10-28 02:53:09 --> Loader Class Initialized
INFO - 2020-10-28 02:53:09 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:09 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:09 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:09 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:09 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:09 --> Controller Class Initialized
INFO - 2020-10-28 02:53:09 --> Final output sent to browser
DEBUG - 2020-10-28 02:53:09 --> Total execution time: 0.2619
INFO - 2020-10-28 02:53:16 --> Config Class Initialized
INFO - 2020-10-28 02:53:16 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:16 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:16 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:16 --> URI Class Initialized
INFO - 2020-10-28 02:53:16 --> Router Class Initialized
INFO - 2020-10-28 02:53:16 --> Output Class Initialized
INFO - 2020-10-28 02:53:16 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:16 --> Input Class Initialized
INFO - 2020-10-28 02:53:16 --> Language Class Initialized
INFO - 2020-10-28 02:53:17 --> Language Class Initialized
INFO - 2020-10-28 02:53:17 --> Config Class Initialized
INFO - 2020-10-28 02:53:17 --> Loader Class Initialized
INFO - 2020-10-28 02:53:17 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:17 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:17 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:17 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:17 --> Controller Class Initialized
INFO - 2020-10-28 02:53:17 --> Final output sent to browser
DEBUG - 2020-10-28 02:53:17 --> Total execution time: 0.2962
INFO - 2020-10-28 02:53:17 --> Config Class Initialized
INFO - 2020-10-28 02:53:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:17 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:17 --> URI Class Initialized
INFO - 2020-10-28 02:53:17 --> Router Class Initialized
INFO - 2020-10-28 02:53:17 --> Output Class Initialized
INFO - 2020-10-28 02:53:17 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:17 --> Input Class Initialized
INFO - 2020-10-28 02:53:17 --> Language Class Initialized
INFO - 2020-10-28 02:53:17 --> Language Class Initialized
INFO - 2020-10-28 02:53:17 --> Config Class Initialized
INFO - 2020-10-28 02:53:17 --> Loader Class Initialized
INFO - 2020-10-28 02:53:17 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:17 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:17 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:17 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:17 --> Controller Class Initialized
INFO - 2020-10-28 02:53:20 --> Config Class Initialized
INFO - 2020-10-28 02:53:20 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:20 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:20 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:20 --> URI Class Initialized
INFO - 2020-10-28 02:53:20 --> Router Class Initialized
INFO - 2020-10-28 02:53:20 --> Output Class Initialized
INFO - 2020-10-28 02:53:20 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:20 --> Input Class Initialized
INFO - 2020-10-28 02:53:20 --> Language Class Initialized
INFO - 2020-10-28 02:53:20 --> Language Class Initialized
INFO - 2020-10-28 02:53:20 --> Config Class Initialized
INFO - 2020-10-28 02:53:20 --> Loader Class Initialized
INFO - 2020-10-28 02:53:20 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:20 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:20 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:20 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:20 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:20 --> Controller Class Initialized
DEBUG - 2020-10-28 02:53:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 02:53:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:53:20 --> Final output sent to browser
DEBUG - 2020-10-28 02:53:20 --> Total execution time: 0.2788
INFO - 2020-10-28 02:53:25 --> Config Class Initialized
INFO - 2020-10-28 02:53:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:25 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:25 --> URI Class Initialized
INFO - 2020-10-28 02:53:25 --> Router Class Initialized
INFO - 2020-10-28 02:53:25 --> Output Class Initialized
INFO - 2020-10-28 02:53:25 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:25 --> Input Class Initialized
INFO - 2020-10-28 02:53:25 --> Language Class Initialized
INFO - 2020-10-28 02:53:25 --> Language Class Initialized
INFO - 2020-10-28 02:53:25 --> Config Class Initialized
INFO - 2020-10-28 02:53:25 --> Loader Class Initialized
INFO - 2020-10-28 02:53:25 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:25 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:25 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:25 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:25 --> Controller Class Initialized
DEBUG - 2020-10-28 02:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 02:53:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:53:25 --> Final output sent to browser
DEBUG - 2020-10-28 02:53:25 --> Total execution time: 0.3044
INFO - 2020-10-28 02:53:37 --> Config Class Initialized
INFO - 2020-10-28 02:53:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:37 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:37 --> URI Class Initialized
INFO - 2020-10-28 02:53:37 --> Router Class Initialized
INFO - 2020-10-28 02:53:37 --> Output Class Initialized
INFO - 2020-10-28 02:53:37 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:37 --> Input Class Initialized
INFO - 2020-10-28 02:53:37 --> Language Class Initialized
INFO - 2020-10-28 02:53:37 --> Language Class Initialized
INFO - 2020-10-28 02:53:37 --> Config Class Initialized
INFO - 2020-10-28 02:53:37 --> Loader Class Initialized
INFO - 2020-10-28 02:53:37 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:37 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:37 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:37 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:37 --> Controller Class Initialized
DEBUG - 2020-10-28 02:53:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 02:53:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 02:53:37 --> Final output sent to browser
DEBUG - 2020-10-28 02:53:37 --> Total execution time: 0.2748
INFO - 2020-10-28 02:53:37 --> Config Class Initialized
INFO - 2020-10-28 02:53:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 02:53:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 02:53:37 --> Utf8 Class Initialized
INFO - 2020-10-28 02:53:37 --> URI Class Initialized
INFO - 2020-10-28 02:53:37 --> Router Class Initialized
INFO - 2020-10-28 02:53:37 --> Output Class Initialized
INFO - 2020-10-28 02:53:37 --> Security Class Initialized
DEBUG - 2020-10-28 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 02:53:37 --> Input Class Initialized
INFO - 2020-10-28 02:53:37 --> Language Class Initialized
INFO - 2020-10-28 02:53:37 --> Language Class Initialized
INFO - 2020-10-28 02:53:37 --> Config Class Initialized
INFO - 2020-10-28 02:53:37 --> Loader Class Initialized
INFO - 2020-10-28 02:53:37 --> Helper loaded: url_helper
INFO - 2020-10-28 02:53:37 --> Helper loaded: file_helper
INFO - 2020-10-28 02:53:37 --> Helper loaded: form_helper
INFO - 2020-10-28 02:53:37 --> Helper loaded: my_helper
INFO - 2020-10-28 02:53:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 02:53:37 --> Controller Class Initialized
INFO - 2020-10-28 03:43:48 --> Config Class Initialized
INFO - 2020-10-28 03:43:48 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:43:48 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:43:48 --> Utf8 Class Initialized
INFO - 2020-10-28 03:43:48 --> URI Class Initialized
INFO - 2020-10-28 03:43:48 --> Router Class Initialized
INFO - 2020-10-28 03:43:48 --> Output Class Initialized
INFO - 2020-10-28 03:43:48 --> Security Class Initialized
DEBUG - 2020-10-28 03:43:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:43:48 --> Input Class Initialized
INFO - 2020-10-28 03:43:48 --> Language Class Initialized
INFO - 2020-10-28 03:43:48 --> Language Class Initialized
INFO - 2020-10-28 03:43:48 --> Config Class Initialized
INFO - 2020-10-28 03:43:48 --> Loader Class Initialized
INFO - 2020-10-28 03:43:48 --> Helper loaded: url_helper
INFO - 2020-10-28 03:43:48 --> Helper loaded: file_helper
INFO - 2020-10-28 03:43:48 --> Helper loaded: form_helper
INFO - 2020-10-28 03:43:48 --> Helper loaded: my_helper
INFO - 2020-10-28 03:43:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:43:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:43:48 --> Controller Class Initialized
INFO - 2020-10-28 03:43:48 --> Final output sent to browser
DEBUG - 2020-10-28 03:43:48 --> Total execution time: 0.2417
INFO - 2020-10-28 03:49:44 --> Config Class Initialized
INFO - 2020-10-28 03:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:49:44 --> Utf8 Class Initialized
INFO - 2020-10-28 03:49:44 --> URI Class Initialized
INFO - 2020-10-28 03:49:44 --> Router Class Initialized
INFO - 2020-10-28 03:49:44 --> Output Class Initialized
INFO - 2020-10-28 03:49:44 --> Security Class Initialized
DEBUG - 2020-10-28 03:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:49:44 --> Input Class Initialized
INFO - 2020-10-28 03:49:44 --> Language Class Initialized
INFO - 2020-10-28 03:49:44 --> Language Class Initialized
INFO - 2020-10-28 03:49:44 --> Config Class Initialized
INFO - 2020-10-28 03:49:44 --> Loader Class Initialized
INFO - 2020-10-28 03:49:44 --> Helper loaded: url_helper
INFO - 2020-10-28 03:49:44 --> Helper loaded: file_helper
INFO - 2020-10-28 03:49:44 --> Helper loaded: form_helper
INFO - 2020-10-28 03:49:44 --> Helper loaded: my_helper
INFO - 2020-10-28 03:49:44 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:49:44 --> Controller Class Initialized
DEBUG - 2020-10-28 03:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 03:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 03:49:44 --> Final output sent to browser
DEBUG - 2020-10-28 03:49:44 --> Total execution time: 0.2829
INFO - 2020-10-28 03:49:44 --> Config Class Initialized
INFO - 2020-10-28 03:49:44 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:49:44 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:49:44 --> Utf8 Class Initialized
INFO - 2020-10-28 03:49:44 --> URI Class Initialized
INFO - 2020-10-28 03:49:44 --> Router Class Initialized
INFO - 2020-10-28 03:49:44 --> Output Class Initialized
INFO - 2020-10-28 03:49:44 --> Security Class Initialized
DEBUG - 2020-10-28 03:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:49:44 --> Input Class Initialized
INFO - 2020-10-28 03:49:44 --> Language Class Initialized
INFO - 2020-10-28 03:49:44 --> Language Class Initialized
INFO - 2020-10-28 03:49:44 --> Config Class Initialized
INFO - 2020-10-28 03:49:44 --> Loader Class Initialized
INFO - 2020-10-28 03:49:44 --> Helper loaded: url_helper
INFO - 2020-10-28 03:49:44 --> Helper loaded: file_helper
INFO - 2020-10-28 03:49:44 --> Helper loaded: form_helper
INFO - 2020-10-28 03:49:44 --> Helper loaded: my_helper
INFO - 2020-10-28 03:49:44 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:49:44 --> Controller Class Initialized
INFO - 2020-10-28 03:49:46 --> Config Class Initialized
INFO - 2020-10-28 03:49:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:49:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:49:46 --> Utf8 Class Initialized
INFO - 2020-10-28 03:49:46 --> URI Class Initialized
INFO - 2020-10-28 03:49:46 --> Router Class Initialized
INFO - 2020-10-28 03:49:46 --> Output Class Initialized
INFO - 2020-10-28 03:49:46 --> Security Class Initialized
DEBUG - 2020-10-28 03:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:49:46 --> Input Class Initialized
INFO - 2020-10-28 03:49:46 --> Language Class Initialized
INFO - 2020-10-28 03:49:46 --> Language Class Initialized
INFO - 2020-10-28 03:49:46 --> Config Class Initialized
INFO - 2020-10-28 03:49:46 --> Loader Class Initialized
INFO - 2020-10-28 03:49:46 --> Helper loaded: url_helper
INFO - 2020-10-28 03:49:46 --> Helper loaded: file_helper
INFO - 2020-10-28 03:49:46 --> Helper loaded: form_helper
INFO - 2020-10-28 03:49:46 --> Helper loaded: my_helper
INFO - 2020-10-28 03:49:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:49:46 --> Controller Class Initialized
INFO - 2020-10-28 03:49:46 --> Final output sent to browser
DEBUG - 2020-10-28 03:49:46 --> Total execution time: 0.2543
INFO - 2020-10-28 03:53:06 --> Config Class Initialized
INFO - 2020-10-28 03:53:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:06 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:06 --> URI Class Initialized
INFO - 2020-10-28 03:53:06 --> Router Class Initialized
INFO - 2020-10-28 03:53:06 --> Output Class Initialized
INFO - 2020-10-28 03:53:06 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:06 --> Input Class Initialized
INFO - 2020-10-28 03:53:06 --> Language Class Initialized
INFO - 2020-10-28 03:53:06 --> Language Class Initialized
INFO - 2020-10-28 03:53:06 --> Config Class Initialized
INFO - 2020-10-28 03:53:06 --> Loader Class Initialized
INFO - 2020-10-28 03:53:06 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:06 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:06 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:07 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:07 --> Controller Class Initialized
DEBUG - 2020-10-28 03:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 03:53:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 03:53:07 --> Final output sent to browser
DEBUG - 2020-10-28 03:53:07 --> Total execution time: 0.2823
INFO - 2020-10-28 03:53:07 --> Config Class Initialized
INFO - 2020-10-28 03:53:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:07 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:07 --> URI Class Initialized
INFO - 2020-10-28 03:53:07 --> Router Class Initialized
INFO - 2020-10-28 03:53:07 --> Output Class Initialized
INFO - 2020-10-28 03:53:07 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:07 --> Input Class Initialized
INFO - 2020-10-28 03:53:07 --> Language Class Initialized
INFO - 2020-10-28 03:53:07 --> Language Class Initialized
INFO - 2020-10-28 03:53:07 --> Config Class Initialized
INFO - 2020-10-28 03:53:07 --> Loader Class Initialized
INFO - 2020-10-28 03:53:07 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:07 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:07 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:07 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:07 --> Controller Class Initialized
INFO - 2020-10-28 03:53:07 --> Config Class Initialized
INFO - 2020-10-28 03:53:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:08 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:08 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:08 --> URI Class Initialized
INFO - 2020-10-28 03:53:08 --> Router Class Initialized
INFO - 2020-10-28 03:53:08 --> Output Class Initialized
INFO - 2020-10-28 03:53:08 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:08 --> Input Class Initialized
INFO - 2020-10-28 03:53:08 --> Language Class Initialized
INFO - 2020-10-28 03:53:08 --> Language Class Initialized
INFO - 2020-10-28 03:53:08 --> Config Class Initialized
INFO - 2020-10-28 03:53:08 --> Loader Class Initialized
INFO - 2020-10-28 03:53:08 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:08 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:08 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:08 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:08 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:08 --> Controller Class Initialized
INFO - 2020-10-28 03:53:08 --> Final output sent to browser
DEBUG - 2020-10-28 03:53:08 --> Total execution time: 0.2474
INFO - 2020-10-28 03:53:30 --> Config Class Initialized
INFO - 2020-10-28 03:53:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:30 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:30 --> URI Class Initialized
INFO - 2020-10-28 03:53:30 --> Router Class Initialized
INFO - 2020-10-28 03:53:30 --> Output Class Initialized
INFO - 2020-10-28 03:53:30 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:30 --> Input Class Initialized
INFO - 2020-10-28 03:53:30 --> Language Class Initialized
INFO - 2020-10-28 03:53:30 --> Language Class Initialized
INFO - 2020-10-28 03:53:30 --> Config Class Initialized
INFO - 2020-10-28 03:53:30 --> Loader Class Initialized
INFO - 2020-10-28 03:53:30 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:30 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:30 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:30 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:30 --> Controller Class Initialized
ERROR - 2020-10-28 03:53:30 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-28 03:53:30 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-28 03:53:30 --> Final output sent to browser
DEBUG - 2020-10-28 03:53:30 --> Total execution time: 0.3034
INFO - 2020-10-28 03:53:31 --> Config Class Initialized
INFO - 2020-10-28 03:53:31 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:31 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:31 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:31 --> URI Class Initialized
INFO - 2020-10-28 03:53:31 --> Router Class Initialized
INFO - 2020-10-28 03:53:31 --> Output Class Initialized
INFO - 2020-10-28 03:53:31 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:31 --> Input Class Initialized
INFO - 2020-10-28 03:53:31 --> Language Class Initialized
INFO - 2020-10-28 03:53:31 --> Language Class Initialized
INFO - 2020-10-28 03:53:31 --> Config Class Initialized
INFO - 2020-10-28 03:53:31 --> Loader Class Initialized
INFO - 2020-10-28 03:53:31 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:31 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:31 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:31 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:31 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:31 --> Controller Class Initialized
ERROR - 2020-10-28 03:53:32 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-28 03:53:32 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-28 03:53:32 --> Final output sent to browser
DEBUG - 2020-10-28 03:53:32 --> Total execution time: 0.3339
INFO - 2020-10-28 03:53:54 --> Config Class Initialized
INFO - 2020-10-28 03:53:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:54 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:54 --> URI Class Initialized
INFO - 2020-10-28 03:53:54 --> Router Class Initialized
INFO - 2020-10-28 03:53:54 --> Output Class Initialized
INFO - 2020-10-28 03:53:54 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:54 --> Input Class Initialized
INFO - 2020-10-28 03:53:54 --> Language Class Initialized
INFO - 2020-10-28 03:53:54 --> Language Class Initialized
INFO - 2020-10-28 03:53:54 --> Config Class Initialized
INFO - 2020-10-28 03:53:54 --> Loader Class Initialized
INFO - 2020-10-28 03:53:54 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:54 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:54 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:54 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:54 --> Controller Class Initialized
DEBUG - 2020-10-28 03:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 03:53:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 03:53:54 --> Final output sent to browser
DEBUG - 2020-10-28 03:53:54 --> Total execution time: 0.2828
INFO - 2020-10-28 03:53:55 --> Config Class Initialized
INFO - 2020-10-28 03:53:55 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:55 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:55 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:55 --> URI Class Initialized
INFO - 2020-10-28 03:53:55 --> Router Class Initialized
INFO - 2020-10-28 03:53:55 --> Output Class Initialized
INFO - 2020-10-28 03:53:55 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:55 --> Input Class Initialized
INFO - 2020-10-28 03:53:55 --> Language Class Initialized
INFO - 2020-10-28 03:53:55 --> Language Class Initialized
INFO - 2020-10-28 03:53:55 --> Config Class Initialized
INFO - 2020-10-28 03:53:55 --> Loader Class Initialized
INFO - 2020-10-28 03:53:55 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:55 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:55 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:55 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:55 --> Controller Class Initialized
INFO - 2020-10-28 03:53:59 --> Config Class Initialized
INFO - 2020-10-28 03:53:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:53:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:53:59 --> Utf8 Class Initialized
INFO - 2020-10-28 03:53:59 --> URI Class Initialized
INFO - 2020-10-28 03:53:59 --> Router Class Initialized
INFO - 2020-10-28 03:53:59 --> Output Class Initialized
INFO - 2020-10-28 03:53:59 --> Security Class Initialized
DEBUG - 2020-10-28 03:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:53:59 --> Input Class Initialized
INFO - 2020-10-28 03:53:59 --> Language Class Initialized
INFO - 2020-10-28 03:53:59 --> Language Class Initialized
INFO - 2020-10-28 03:53:59 --> Config Class Initialized
INFO - 2020-10-28 03:53:59 --> Loader Class Initialized
INFO - 2020-10-28 03:53:59 --> Helper loaded: url_helper
INFO - 2020-10-28 03:53:59 --> Helper loaded: file_helper
INFO - 2020-10-28 03:53:59 --> Helper loaded: form_helper
INFO - 2020-10-28 03:53:59 --> Helper loaded: my_helper
INFO - 2020-10-28 03:53:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:53:59 --> Controller Class Initialized
INFO - 2020-10-28 03:53:59 --> Final output sent to browser
DEBUG - 2020-10-28 03:53:59 --> Total execution time: 0.2503
INFO - 2020-10-28 03:54:04 --> Config Class Initialized
INFO - 2020-10-28 03:54:04 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:54:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:54:05 --> Utf8 Class Initialized
INFO - 2020-10-28 03:54:05 --> URI Class Initialized
INFO - 2020-10-28 03:54:05 --> Router Class Initialized
INFO - 2020-10-28 03:54:05 --> Output Class Initialized
INFO - 2020-10-28 03:54:05 --> Security Class Initialized
DEBUG - 2020-10-28 03:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:54:05 --> Input Class Initialized
INFO - 2020-10-28 03:54:05 --> Language Class Initialized
INFO - 2020-10-28 03:54:05 --> Language Class Initialized
INFO - 2020-10-28 03:54:05 --> Config Class Initialized
INFO - 2020-10-28 03:54:05 --> Loader Class Initialized
INFO - 2020-10-28 03:54:05 --> Helper loaded: url_helper
INFO - 2020-10-28 03:54:05 --> Helper loaded: file_helper
INFO - 2020-10-28 03:54:05 --> Helper loaded: form_helper
INFO - 2020-10-28 03:54:05 --> Helper loaded: my_helper
INFO - 2020-10-28 03:54:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:54:05 --> Controller Class Initialized
INFO - 2020-10-28 03:54:05 --> Final output sent to browser
DEBUG - 2020-10-28 03:54:05 --> Total execution time: 0.3160
INFO - 2020-10-28 03:54:05 --> Config Class Initialized
INFO - 2020-10-28 03:54:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:54:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:54:05 --> Utf8 Class Initialized
INFO - 2020-10-28 03:54:05 --> URI Class Initialized
INFO - 2020-10-28 03:54:05 --> Router Class Initialized
INFO - 2020-10-28 03:54:05 --> Output Class Initialized
INFO - 2020-10-28 03:54:05 --> Security Class Initialized
DEBUG - 2020-10-28 03:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:54:05 --> Input Class Initialized
INFO - 2020-10-28 03:54:05 --> Language Class Initialized
INFO - 2020-10-28 03:54:05 --> Language Class Initialized
INFO - 2020-10-28 03:54:05 --> Config Class Initialized
INFO - 2020-10-28 03:54:05 --> Loader Class Initialized
INFO - 2020-10-28 03:54:05 --> Helper loaded: url_helper
INFO - 2020-10-28 03:54:05 --> Helper loaded: file_helper
INFO - 2020-10-28 03:54:05 --> Helper loaded: form_helper
INFO - 2020-10-28 03:54:05 --> Helper loaded: my_helper
INFO - 2020-10-28 03:54:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:54:05 --> Controller Class Initialized
INFO - 2020-10-28 03:54:12 --> Config Class Initialized
INFO - 2020-10-28 03:54:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:54:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:54:12 --> Utf8 Class Initialized
INFO - 2020-10-28 03:54:12 --> URI Class Initialized
INFO - 2020-10-28 03:54:12 --> Router Class Initialized
INFO - 2020-10-28 03:54:12 --> Output Class Initialized
INFO - 2020-10-28 03:54:12 --> Security Class Initialized
DEBUG - 2020-10-28 03:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:54:12 --> Input Class Initialized
INFO - 2020-10-28 03:54:12 --> Language Class Initialized
INFO - 2020-10-28 03:54:12 --> Language Class Initialized
INFO - 2020-10-28 03:54:12 --> Config Class Initialized
INFO - 2020-10-28 03:54:12 --> Loader Class Initialized
INFO - 2020-10-28 03:54:12 --> Helper loaded: url_helper
INFO - 2020-10-28 03:54:12 --> Helper loaded: file_helper
INFO - 2020-10-28 03:54:12 --> Helper loaded: form_helper
INFO - 2020-10-28 03:54:12 --> Helper loaded: my_helper
INFO - 2020-10-28 03:54:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:54:12 --> Controller Class Initialized
INFO - 2020-10-28 03:54:12 --> Final output sent to browser
DEBUG - 2020-10-28 03:54:12 --> Total execution time: 0.2588
INFO - 2020-10-28 03:54:19 --> Config Class Initialized
INFO - 2020-10-28 03:54:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:54:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:54:19 --> Utf8 Class Initialized
INFO - 2020-10-28 03:54:19 --> URI Class Initialized
INFO - 2020-10-28 03:54:19 --> Router Class Initialized
INFO - 2020-10-28 03:54:19 --> Output Class Initialized
INFO - 2020-10-28 03:54:19 --> Security Class Initialized
DEBUG - 2020-10-28 03:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:54:19 --> Input Class Initialized
INFO - 2020-10-28 03:54:19 --> Language Class Initialized
INFO - 2020-10-28 03:54:19 --> Language Class Initialized
INFO - 2020-10-28 03:54:19 --> Config Class Initialized
INFO - 2020-10-28 03:54:19 --> Loader Class Initialized
INFO - 2020-10-28 03:54:19 --> Helper loaded: url_helper
INFO - 2020-10-28 03:54:19 --> Helper loaded: file_helper
INFO - 2020-10-28 03:54:19 --> Helper loaded: form_helper
INFO - 2020-10-28 03:54:19 --> Helper loaded: my_helper
INFO - 2020-10-28 03:54:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:54:19 --> Controller Class Initialized
INFO - 2020-10-28 03:54:19 --> Final output sent to browser
DEBUG - 2020-10-28 03:54:19 --> Total execution time: 0.2536
INFO - 2020-10-28 03:58:44 --> Config Class Initialized
INFO - 2020-10-28 03:58:44 --> Hooks Class Initialized
DEBUG - 2020-10-28 03:58:44 --> UTF-8 Support Enabled
INFO - 2020-10-28 03:58:44 --> Utf8 Class Initialized
INFO - 2020-10-28 03:58:44 --> URI Class Initialized
INFO - 2020-10-28 03:58:44 --> Router Class Initialized
INFO - 2020-10-28 03:58:44 --> Output Class Initialized
INFO - 2020-10-28 03:58:44 --> Security Class Initialized
DEBUG - 2020-10-28 03:58:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 03:58:44 --> Input Class Initialized
INFO - 2020-10-28 03:58:44 --> Language Class Initialized
INFO - 2020-10-28 03:58:44 --> Language Class Initialized
INFO - 2020-10-28 03:58:44 --> Config Class Initialized
INFO - 2020-10-28 03:58:44 --> Loader Class Initialized
INFO - 2020-10-28 03:58:44 --> Helper loaded: url_helper
INFO - 2020-10-28 03:58:44 --> Helper loaded: file_helper
INFO - 2020-10-28 03:58:44 --> Helper loaded: form_helper
INFO - 2020-10-28 03:58:44 --> Helper loaded: my_helper
INFO - 2020-10-28 03:58:44 --> Database Driver Class Initialized
DEBUG - 2020-10-28 03:58:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 03:58:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 03:58:44 --> Controller Class Initialized
INFO - 2020-10-28 03:58:44 --> Final output sent to browser
DEBUG - 2020-10-28 03:58:44 --> Total execution time: 0.2551
INFO - 2020-10-28 04:02:10 --> Config Class Initialized
INFO - 2020-10-28 04:02:10 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:02:10 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:02:10 --> Utf8 Class Initialized
INFO - 2020-10-28 04:02:10 --> URI Class Initialized
INFO - 2020-10-28 04:02:10 --> Router Class Initialized
INFO - 2020-10-28 04:02:10 --> Output Class Initialized
INFO - 2020-10-28 04:02:10 --> Security Class Initialized
DEBUG - 2020-10-28 04:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:02:10 --> Input Class Initialized
INFO - 2020-10-28 04:02:10 --> Language Class Initialized
INFO - 2020-10-28 04:02:10 --> Language Class Initialized
INFO - 2020-10-28 04:02:10 --> Config Class Initialized
INFO - 2020-10-28 04:02:10 --> Loader Class Initialized
INFO - 2020-10-28 04:02:10 --> Helper loaded: url_helper
INFO - 2020-10-28 04:02:10 --> Helper loaded: file_helper
INFO - 2020-10-28 04:02:10 --> Helper loaded: form_helper
INFO - 2020-10-28 04:02:10 --> Helper loaded: my_helper
INFO - 2020-10-28 04:02:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:02:11 --> Controller Class Initialized
DEBUG - 2020-10-28 04:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 04:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:02:11 --> Final output sent to browser
DEBUG - 2020-10-28 04:02:11 --> Total execution time: 0.2784
INFO - 2020-10-28 04:02:11 --> Config Class Initialized
INFO - 2020-10-28 04:02:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:02:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:02:11 --> Utf8 Class Initialized
INFO - 2020-10-28 04:02:11 --> URI Class Initialized
INFO - 2020-10-28 04:02:11 --> Router Class Initialized
INFO - 2020-10-28 04:02:11 --> Output Class Initialized
INFO - 2020-10-28 04:02:11 --> Security Class Initialized
DEBUG - 2020-10-28 04:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:02:11 --> Input Class Initialized
INFO - 2020-10-28 04:02:11 --> Language Class Initialized
INFO - 2020-10-28 04:02:11 --> Language Class Initialized
INFO - 2020-10-28 04:02:11 --> Config Class Initialized
INFO - 2020-10-28 04:02:11 --> Loader Class Initialized
INFO - 2020-10-28 04:02:11 --> Helper loaded: url_helper
INFO - 2020-10-28 04:02:11 --> Helper loaded: file_helper
INFO - 2020-10-28 04:02:11 --> Helper loaded: form_helper
INFO - 2020-10-28 04:02:11 --> Helper loaded: my_helper
INFO - 2020-10-28 04:02:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:02:11 --> Controller Class Initialized
INFO - 2020-10-28 04:02:12 --> Config Class Initialized
INFO - 2020-10-28 04:02:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:02:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:02:12 --> Utf8 Class Initialized
INFO - 2020-10-28 04:02:12 --> URI Class Initialized
INFO - 2020-10-28 04:02:13 --> Router Class Initialized
INFO - 2020-10-28 04:02:13 --> Output Class Initialized
INFO - 2020-10-28 04:02:13 --> Security Class Initialized
DEBUG - 2020-10-28 04:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:02:13 --> Input Class Initialized
INFO - 2020-10-28 04:02:13 --> Language Class Initialized
INFO - 2020-10-28 04:02:13 --> Language Class Initialized
INFO - 2020-10-28 04:02:13 --> Config Class Initialized
INFO - 2020-10-28 04:02:13 --> Loader Class Initialized
INFO - 2020-10-28 04:02:13 --> Helper loaded: url_helper
INFO - 2020-10-28 04:02:13 --> Helper loaded: file_helper
INFO - 2020-10-28 04:02:13 --> Helper loaded: form_helper
INFO - 2020-10-28 04:02:13 --> Helper loaded: my_helper
INFO - 2020-10-28 04:02:13 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:02:13 --> Controller Class Initialized
INFO - 2020-10-28 04:02:13 --> Final output sent to browser
DEBUG - 2020-10-28 04:02:13 --> Total execution time: 0.2597
INFO - 2020-10-28 04:02:38 --> Config Class Initialized
INFO - 2020-10-28 04:02:38 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:02:38 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:02:38 --> Utf8 Class Initialized
INFO - 2020-10-28 04:02:38 --> URI Class Initialized
INFO - 2020-10-28 04:02:38 --> Router Class Initialized
INFO - 2020-10-28 04:02:38 --> Output Class Initialized
INFO - 2020-10-28 04:02:38 --> Security Class Initialized
DEBUG - 2020-10-28 04:02:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:02:38 --> Input Class Initialized
INFO - 2020-10-28 04:02:38 --> Language Class Initialized
INFO - 2020-10-28 04:02:38 --> Language Class Initialized
INFO - 2020-10-28 04:02:38 --> Config Class Initialized
INFO - 2020-10-28 04:02:38 --> Loader Class Initialized
INFO - 2020-10-28 04:02:38 --> Helper loaded: url_helper
INFO - 2020-10-28 04:02:38 --> Helper loaded: file_helper
INFO - 2020-10-28 04:02:38 --> Helper loaded: form_helper
INFO - 2020-10-28 04:02:38 --> Helper loaded: my_helper
INFO - 2020-10-28 04:02:38 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:02:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:02:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:02:38 --> Controller Class Initialized
ERROR - 2020-10-28 04:02:38 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-28 04:02:38 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-28 04:02:38 --> Final output sent to browser
DEBUG - 2020-10-28 04:02:38 --> Total execution time: 0.3159
INFO - 2020-10-28 04:02:40 --> Config Class Initialized
INFO - 2020-10-28 04:02:40 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:02:40 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:02:40 --> Utf8 Class Initialized
INFO - 2020-10-28 04:02:40 --> URI Class Initialized
INFO - 2020-10-28 04:02:40 --> Router Class Initialized
INFO - 2020-10-28 04:02:40 --> Output Class Initialized
INFO - 2020-10-28 04:02:40 --> Security Class Initialized
DEBUG - 2020-10-28 04:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:02:40 --> Input Class Initialized
INFO - 2020-10-28 04:02:40 --> Language Class Initialized
INFO - 2020-10-28 04:02:40 --> Language Class Initialized
INFO - 2020-10-28 04:02:40 --> Config Class Initialized
INFO - 2020-10-28 04:02:40 --> Loader Class Initialized
INFO - 2020-10-28 04:02:40 --> Helper loaded: url_helper
INFO - 2020-10-28 04:02:40 --> Helper loaded: file_helper
INFO - 2020-10-28 04:02:40 --> Helper loaded: form_helper
INFO - 2020-10-28 04:02:40 --> Helper loaded: my_helper
INFO - 2020-10-28 04:02:40 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:02:40 --> Controller Class Initialized
DEBUG - 2020-10-28 04:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 04:02:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:02:40 --> Final output sent to browser
DEBUG - 2020-10-28 04:02:40 --> Total execution time: 0.2776
INFO - 2020-10-28 04:02:40 --> Config Class Initialized
INFO - 2020-10-28 04:02:40 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:02:40 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:02:40 --> Utf8 Class Initialized
INFO - 2020-10-28 04:02:40 --> URI Class Initialized
INFO - 2020-10-28 04:02:40 --> Router Class Initialized
INFO - 2020-10-28 04:02:40 --> Output Class Initialized
INFO - 2020-10-28 04:02:40 --> Security Class Initialized
DEBUG - 2020-10-28 04:02:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:02:40 --> Input Class Initialized
INFO - 2020-10-28 04:02:40 --> Language Class Initialized
INFO - 2020-10-28 04:02:40 --> Language Class Initialized
INFO - 2020-10-28 04:02:40 --> Config Class Initialized
INFO - 2020-10-28 04:02:40 --> Loader Class Initialized
INFO - 2020-10-28 04:02:40 --> Helper loaded: url_helper
INFO - 2020-10-28 04:02:40 --> Helper loaded: file_helper
INFO - 2020-10-28 04:02:40 --> Helper loaded: form_helper
INFO - 2020-10-28 04:02:40 --> Helper loaded: my_helper
INFO - 2020-10-28 04:02:40 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:02:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:02:40 --> Controller Class Initialized
INFO - 2020-10-28 04:03:57 --> Config Class Initialized
INFO - 2020-10-28 04:03:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:03:57 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:03:57 --> Utf8 Class Initialized
INFO - 2020-10-28 04:03:57 --> URI Class Initialized
INFO - 2020-10-28 04:03:57 --> Router Class Initialized
INFO - 2020-10-28 04:03:57 --> Output Class Initialized
INFO - 2020-10-28 04:03:57 --> Security Class Initialized
DEBUG - 2020-10-28 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:03:57 --> Input Class Initialized
INFO - 2020-10-28 04:03:57 --> Language Class Initialized
INFO - 2020-10-28 04:03:57 --> Language Class Initialized
INFO - 2020-10-28 04:03:57 --> Config Class Initialized
INFO - 2020-10-28 04:03:57 --> Loader Class Initialized
INFO - 2020-10-28 04:03:57 --> Helper loaded: url_helper
INFO - 2020-10-28 04:03:57 --> Helper loaded: file_helper
INFO - 2020-10-28 04:03:57 --> Helper loaded: form_helper
INFO - 2020-10-28 04:03:57 --> Helper loaded: my_helper
INFO - 2020-10-28 04:03:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:03:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:03:57 --> Controller Class Initialized
DEBUG - 2020-10-28 04:03:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 04:03:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:03:57 --> Final output sent to browser
DEBUG - 2020-10-28 04:03:57 --> Total execution time: 0.2785
INFO - 2020-10-28 04:03:57 --> Config Class Initialized
INFO - 2020-10-28 04:03:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:03:57 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:03:57 --> Utf8 Class Initialized
INFO - 2020-10-28 04:03:57 --> URI Class Initialized
INFO - 2020-10-28 04:03:57 --> Router Class Initialized
INFO - 2020-10-28 04:03:57 --> Output Class Initialized
INFO - 2020-10-28 04:03:57 --> Security Class Initialized
DEBUG - 2020-10-28 04:03:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:03:57 --> Input Class Initialized
INFO - 2020-10-28 04:03:57 --> Language Class Initialized
INFO - 2020-10-28 04:03:57 --> Language Class Initialized
INFO - 2020-10-28 04:03:57 --> Config Class Initialized
INFO - 2020-10-28 04:03:57 --> Loader Class Initialized
INFO - 2020-10-28 04:03:57 --> Helper loaded: url_helper
INFO - 2020-10-28 04:03:57 --> Helper loaded: file_helper
INFO - 2020-10-28 04:03:57 --> Helper loaded: form_helper
INFO - 2020-10-28 04:03:58 --> Helper loaded: my_helper
INFO - 2020-10-28 04:03:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:03:58 --> Controller Class Initialized
INFO - 2020-10-28 04:03:58 --> Config Class Initialized
INFO - 2020-10-28 04:03:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:03:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:03:58 --> Utf8 Class Initialized
INFO - 2020-10-28 04:03:58 --> URI Class Initialized
INFO - 2020-10-28 04:03:58 --> Router Class Initialized
INFO - 2020-10-28 04:03:58 --> Output Class Initialized
INFO - 2020-10-28 04:03:58 --> Security Class Initialized
DEBUG - 2020-10-28 04:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:03:58 --> Input Class Initialized
INFO - 2020-10-28 04:03:58 --> Language Class Initialized
INFO - 2020-10-28 04:03:58 --> Language Class Initialized
INFO - 2020-10-28 04:03:58 --> Config Class Initialized
INFO - 2020-10-28 04:03:58 --> Loader Class Initialized
INFO - 2020-10-28 04:03:58 --> Helper loaded: url_helper
INFO - 2020-10-28 04:03:58 --> Helper loaded: file_helper
INFO - 2020-10-28 04:03:58 --> Helper loaded: form_helper
INFO - 2020-10-28 04:03:58 --> Helper loaded: my_helper
INFO - 2020-10-28 04:03:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:03:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:03:58 --> Controller Class Initialized
INFO - 2020-10-28 04:03:58 --> Final output sent to browser
DEBUG - 2020-10-28 04:03:58 --> Total execution time: 0.2560
INFO - 2020-10-28 04:04:02 --> Config Class Initialized
INFO - 2020-10-28 04:04:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:04:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:04:02 --> Utf8 Class Initialized
INFO - 2020-10-28 04:04:02 --> URI Class Initialized
INFO - 2020-10-28 04:04:02 --> Router Class Initialized
INFO - 2020-10-28 04:04:02 --> Output Class Initialized
INFO - 2020-10-28 04:04:02 --> Security Class Initialized
DEBUG - 2020-10-28 04:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:04:02 --> Input Class Initialized
INFO - 2020-10-28 04:04:02 --> Language Class Initialized
INFO - 2020-10-28 04:04:02 --> Language Class Initialized
INFO - 2020-10-28 04:04:02 --> Config Class Initialized
INFO - 2020-10-28 04:04:02 --> Loader Class Initialized
INFO - 2020-10-28 04:04:02 --> Helper loaded: url_helper
INFO - 2020-10-28 04:04:02 --> Helper loaded: file_helper
INFO - 2020-10-28 04:04:02 --> Helper loaded: form_helper
INFO - 2020-10-28 04:04:02 --> Helper loaded: my_helper
INFO - 2020-10-28 04:04:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:04:02 --> Controller Class Initialized
INFO - 2020-10-28 04:04:02 --> Final output sent to browser
DEBUG - 2020-10-28 04:04:02 --> Total execution time: 0.3226
INFO - 2020-10-28 04:04:02 --> Config Class Initialized
INFO - 2020-10-28 04:04:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:04:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:04:02 --> Utf8 Class Initialized
INFO - 2020-10-28 04:04:02 --> URI Class Initialized
INFO - 2020-10-28 04:04:02 --> Router Class Initialized
INFO - 2020-10-28 04:04:02 --> Output Class Initialized
INFO - 2020-10-28 04:04:02 --> Security Class Initialized
DEBUG - 2020-10-28 04:04:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:04:02 --> Input Class Initialized
INFO - 2020-10-28 04:04:02 --> Language Class Initialized
INFO - 2020-10-28 04:04:02 --> Language Class Initialized
INFO - 2020-10-28 04:04:02 --> Config Class Initialized
INFO - 2020-10-28 04:04:02 --> Loader Class Initialized
INFO - 2020-10-28 04:04:02 --> Helper loaded: url_helper
INFO - 2020-10-28 04:04:02 --> Helper loaded: file_helper
INFO - 2020-10-28 04:04:02 --> Helper loaded: form_helper
INFO - 2020-10-28 04:04:02 --> Helper loaded: my_helper
INFO - 2020-10-28 04:04:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:04:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:04:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:04:02 --> Controller Class Initialized
INFO - 2020-10-28 04:04:05 --> Config Class Initialized
INFO - 2020-10-28 04:04:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:04:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:04:05 --> Utf8 Class Initialized
INFO - 2020-10-28 04:04:05 --> URI Class Initialized
INFO - 2020-10-28 04:04:05 --> Router Class Initialized
INFO - 2020-10-28 04:04:05 --> Output Class Initialized
INFO - 2020-10-28 04:04:05 --> Security Class Initialized
DEBUG - 2020-10-28 04:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:04:05 --> Input Class Initialized
INFO - 2020-10-28 04:04:05 --> Language Class Initialized
INFO - 2020-10-28 04:04:05 --> Language Class Initialized
INFO - 2020-10-28 04:04:05 --> Config Class Initialized
INFO - 2020-10-28 04:04:05 --> Loader Class Initialized
INFO - 2020-10-28 04:04:05 --> Helper loaded: url_helper
INFO - 2020-10-28 04:04:05 --> Helper loaded: file_helper
INFO - 2020-10-28 04:04:05 --> Helper loaded: form_helper
INFO - 2020-10-28 04:04:05 --> Helper loaded: my_helper
INFO - 2020-10-28 04:04:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:04:05 --> Controller Class Initialized
INFO - 2020-10-28 04:04:05 --> Final output sent to browser
DEBUG - 2020-10-28 04:04:05 --> Total execution time: 0.3304
INFO - 2020-10-28 04:04:05 --> Config Class Initialized
INFO - 2020-10-28 04:04:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:04:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:04:05 --> Utf8 Class Initialized
INFO - 2020-10-28 04:04:05 --> URI Class Initialized
INFO - 2020-10-28 04:04:05 --> Router Class Initialized
INFO - 2020-10-28 04:04:05 --> Output Class Initialized
INFO - 2020-10-28 04:04:05 --> Security Class Initialized
DEBUG - 2020-10-28 04:04:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:04:05 --> Input Class Initialized
INFO - 2020-10-28 04:04:05 --> Language Class Initialized
INFO - 2020-10-28 04:04:05 --> Language Class Initialized
INFO - 2020-10-28 04:04:05 --> Config Class Initialized
INFO - 2020-10-28 04:04:05 --> Loader Class Initialized
INFO - 2020-10-28 04:04:05 --> Helper loaded: url_helper
INFO - 2020-10-28 04:04:05 --> Helper loaded: file_helper
INFO - 2020-10-28 04:04:05 --> Helper loaded: form_helper
INFO - 2020-10-28 04:04:05 --> Helper loaded: my_helper
INFO - 2020-10-28 04:04:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:04:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:04:05 --> Controller Class Initialized
INFO - 2020-10-28 04:15:36 --> Config Class Initialized
INFO - 2020-10-28 04:15:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:15:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:15:36 --> Utf8 Class Initialized
INFO - 2020-10-28 04:15:36 --> URI Class Initialized
INFO - 2020-10-28 04:15:36 --> Router Class Initialized
INFO - 2020-10-28 04:15:36 --> Output Class Initialized
INFO - 2020-10-28 04:15:36 --> Security Class Initialized
DEBUG - 2020-10-28 04:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:15:36 --> Input Class Initialized
INFO - 2020-10-28 04:15:36 --> Language Class Initialized
INFO - 2020-10-28 04:15:36 --> Language Class Initialized
INFO - 2020-10-28 04:15:36 --> Config Class Initialized
INFO - 2020-10-28 04:15:36 --> Loader Class Initialized
INFO - 2020-10-28 04:15:36 --> Helper loaded: url_helper
INFO - 2020-10-28 04:15:36 --> Helper loaded: file_helper
INFO - 2020-10-28 04:15:36 --> Helper loaded: form_helper
INFO - 2020-10-28 04:15:36 --> Helper loaded: my_helper
INFO - 2020-10-28 04:15:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:15:36 --> Controller Class Initialized
DEBUG - 2020-10-28 04:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 04:15:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:15:36 --> Final output sent to browser
DEBUG - 2020-10-28 04:15:36 --> Total execution time: 0.2835
INFO - 2020-10-28 04:15:36 --> Config Class Initialized
INFO - 2020-10-28 04:15:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:15:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:15:36 --> Utf8 Class Initialized
INFO - 2020-10-28 04:15:36 --> URI Class Initialized
INFO - 2020-10-28 04:15:36 --> Router Class Initialized
INFO - 2020-10-28 04:15:36 --> Output Class Initialized
INFO - 2020-10-28 04:15:36 --> Security Class Initialized
DEBUG - 2020-10-28 04:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:15:36 --> Input Class Initialized
INFO - 2020-10-28 04:15:36 --> Language Class Initialized
INFO - 2020-10-28 04:15:36 --> Language Class Initialized
INFO - 2020-10-28 04:15:36 --> Config Class Initialized
INFO - 2020-10-28 04:15:36 --> Loader Class Initialized
INFO - 2020-10-28 04:15:36 --> Helper loaded: url_helper
INFO - 2020-10-28 04:15:36 --> Helper loaded: file_helper
INFO - 2020-10-28 04:15:36 --> Helper loaded: form_helper
INFO - 2020-10-28 04:15:36 --> Helper loaded: my_helper
INFO - 2020-10-28 04:15:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:15:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:15:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:15:36 --> Controller Class Initialized
INFO - 2020-10-28 04:16:34 --> Config Class Initialized
INFO - 2020-10-28 04:16:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:16:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:16:34 --> Utf8 Class Initialized
INFO - 2020-10-28 04:16:34 --> URI Class Initialized
INFO - 2020-10-28 04:16:34 --> Router Class Initialized
INFO - 2020-10-28 04:16:34 --> Output Class Initialized
INFO - 2020-10-28 04:16:34 --> Security Class Initialized
DEBUG - 2020-10-28 04:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:16:34 --> Input Class Initialized
INFO - 2020-10-28 04:16:34 --> Language Class Initialized
INFO - 2020-10-28 04:16:34 --> Language Class Initialized
INFO - 2020-10-28 04:16:34 --> Config Class Initialized
INFO - 2020-10-28 04:16:34 --> Loader Class Initialized
INFO - 2020-10-28 04:16:34 --> Helper loaded: url_helper
INFO - 2020-10-28 04:16:34 --> Helper loaded: file_helper
INFO - 2020-10-28 04:16:34 --> Helper loaded: form_helper
INFO - 2020-10-28 04:16:34 --> Helper loaded: my_helper
INFO - 2020-10-28 04:16:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:16:35 --> Controller Class Initialized
DEBUG - 2020-10-28 04:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 04:16:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:16:35 --> Final output sent to browser
DEBUG - 2020-10-28 04:16:35 --> Total execution time: 0.2967
INFO - 2020-10-28 04:16:35 --> Config Class Initialized
INFO - 2020-10-28 04:16:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:16:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:16:35 --> Utf8 Class Initialized
INFO - 2020-10-28 04:16:35 --> URI Class Initialized
INFO - 2020-10-28 04:16:35 --> Router Class Initialized
INFO - 2020-10-28 04:16:35 --> Output Class Initialized
INFO - 2020-10-28 04:16:35 --> Security Class Initialized
DEBUG - 2020-10-28 04:16:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:16:35 --> Input Class Initialized
INFO - 2020-10-28 04:16:35 --> Language Class Initialized
INFO - 2020-10-28 04:16:35 --> Language Class Initialized
INFO - 2020-10-28 04:16:35 --> Config Class Initialized
INFO - 2020-10-28 04:16:35 --> Loader Class Initialized
INFO - 2020-10-28 04:16:35 --> Helper loaded: url_helper
INFO - 2020-10-28 04:16:35 --> Helper loaded: file_helper
INFO - 2020-10-28 04:16:35 --> Helper loaded: form_helper
INFO - 2020-10-28 04:16:35 --> Helper loaded: my_helper
INFO - 2020-10-28 04:16:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:16:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:16:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:16:35 --> Controller Class Initialized
INFO - 2020-10-28 04:26:04 --> Config Class Initialized
INFO - 2020-10-28 04:26:04 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:26:04 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:26:04 --> Utf8 Class Initialized
INFO - 2020-10-28 04:26:04 --> URI Class Initialized
INFO - 2020-10-28 04:26:04 --> Router Class Initialized
INFO - 2020-10-28 04:26:05 --> Output Class Initialized
INFO - 2020-10-28 04:26:05 --> Security Class Initialized
DEBUG - 2020-10-28 04:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:26:05 --> Input Class Initialized
INFO - 2020-10-28 04:26:05 --> Language Class Initialized
INFO - 2020-10-28 04:26:05 --> Language Class Initialized
INFO - 2020-10-28 04:26:05 --> Config Class Initialized
INFO - 2020-10-28 04:26:05 --> Loader Class Initialized
INFO - 2020-10-28 04:26:05 --> Helper loaded: url_helper
INFO - 2020-10-28 04:26:05 --> Helper loaded: file_helper
INFO - 2020-10-28 04:26:05 --> Helper loaded: form_helper
INFO - 2020-10-28 04:26:05 --> Helper loaded: my_helper
INFO - 2020-10-28 04:26:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:26:05 --> Controller Class Initialized
DEBUG - 2020-10-28 04:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 04:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:26:05 --> Final output sent to browser
DEBUG - 2020-10-28 04:26:05 --> Total execution time: 0.2869
INFO - 2020-10-28 04:26:05 --> Config Class Initialized
INFO - 2020-10-28 04:26:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:26:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:26:05 --> Utf8 Class Initialized
INFO - 2020-10-28 04:26:05 --> URI Class Initialized
INFO - 2020-10-28 04:26:05 --> Router Class Initialized
INFO - 2020-10-28 04:26:05 --> Output Class Initialized
INFO - 2020-10-28 04:26:05 --> Security Class Initialized
DEBUG - 2020-10-28 04:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:26:05 --> Input Class Initialized
INFO - 2020-10-28 04:26:05 --> Language Class Initialized
INFO - 2020-10-28 04:26:05 --> Language Class Initialized
INFO - 2020-10-28 04:26:05 --> Config Class Initialized
INFO - 2020-10-28 04:26:05 --> Loader Class Initialized
INFO - 2020-10-28 04:26:05 --> Helper loaded: url_helper
INFO - 2020-10-28 04:26:05 --> Helper loaded: file_helper
INFO - 2020-10-28 04:26:05 --> Helper loaded: form_helper
INFO - 2020-10-28 04:26:05 --> Helper loaded: my_helper
INFO - 2020-10-28 04:26:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:26:05 --> Controller Class Initialized
INFO - 2020-10-28 04:29:08 --> Config Class Initialized
INFO - 2020-10-28 04:29:08 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:29:08 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:29:08 --> Utf8 Class Initialized
INFO - 2020-10-28 04:29:08 --> URI Class Initialized
INFO - 2020-10-28 04:29:08 --> Router Class Initialized
INFO - 2020-10-28 04:29:08 --> Output Class Initialized
INFO - 2020-10-28 04:29:08 --> Security Class Initialized
DEBUG - 2020-10-28 04:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:29:08 --> Input Class Initialized
INFO - 2020-10-28 04:29:08 --> Language Class Initialized
INFO - 2020-10-28 04:29:08 --> Language Class Initialized
INFO - 2020-10-28 04:29:08 --> Config Class Initialized
INFO - 2020-10-28 04:29:08 --> Loader Class Initialized
INFO - 2020-10-28 04:29:08 --> Helper loaded: url_helper
INFO - 2020-10-28 04:29:08 --> Helper loaded: file_helper
INFO - 2020-10-28 04:29:08 --> Helper loaded: form_helper
INFO - 2020-10-28 04:29:08 --> Helper loaded: my_helper
INFO - 2020-10-28 04:29:08 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:29:08 --> Controller Class Initialized
DEBUG - 2020-10-28 04:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-10-28 04:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:29:08 --> Final output sent to browser
DEBUG - 2020-10-28 04:29:08 --> Total execution time: 0.3104
INFO - 2020-10-28 04:29:15 --> Config Class Initialized
INFO - 2020-10-28 04:29:15 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:29:15 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:29:15 --> Utf8 Class Initialized
INFO - 2020-10-28 04:29:15 --> URI Class Initialized
INFO - 2020-10-28 04:29:15 --> Router Class Initialized
INFO - 2020-10-28 04:29:15 --> Output Class Initialized
INFO - 2020-10-28 04:29:15 --> Security Class Initialized
DEBUG - 2020-10-28 04:29:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:29:15 --> Input Class Initialized
INFO - 2020-10-28 04:29:15 --> Language Class Initialized
INFO - 2020-10-28 04:29:15 --> Language Class Initialized
INFO - 2020-10-28 04:29:15 --> Config Class Initialized
INFO - 2020-10-28 04:29:15 --> Loader Class Initialized
INFO - 2020-10-28 04:29:15 --> Helper loaded: url_helper
INFO - 2020-10-28 04:29:15 --> Helper loaded: file_helper
INFO - 2020-10-28 04:29:15 --> Helper loaded: form_helper
INFO - 2020-10-28 04:29:15 --> Helper loaded: my_helper
INFO - 2020-10-28 04:29:15 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:29:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:29:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:29:15 --> Controller Class Initialized
INFO - 2020-10-28 04:29:17 --> Config Class Initialized
INFO - 2020-10-28 04:29:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:29:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:29:17 --> Utf8 Class Initialized
INFO - 2020-10-28 04:29:17 --> URI Class Initialized
INFO - 2020-10-28 04:29:17 --> Router Class Initialized
INFO - 2020-10-28 04:29:17 --> Output Class Initialized
INFO - 2020-10-28 04:29:17 --> Security Class Initialized
DEBUG - 2020-10-28 04:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:29:17 --> Input Class Initialized
INFO - 2020-10-28 04:29:17 --> Language Class Initialized
INFO - 2020-10-28 04:29:17 --> Language Class Initialized
INFO - 2020-10-28 04:29:17 --> Config Class Initialized
INFO - 2020-10-28 04:29:17 --> Loader Class Initialized
INFO - 2020-10-28 04:29:17 --> Helper loaded: url_helper
INFO - 2020-10-28 04:29:17 --> Helper loaded: file_helper
INFO - 2020-10-28 04:29:17 --> Helper loaded: form_helper
INFO - 2020-10-28 04:29:17 --> Helper loaded: my_helper
INFO - 2020-10-28 04:29:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:29:17 --> Controller Class Initialized
DEBUG - 2020-10-28 04:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2020-10-28 04:29:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:29:17 --> Final output sent to browser
DEBUG - 2020-10-28 04:29:17 --> Total execution time: 0.2888
INFO - 2020-10-28 04:29:36 --> Config Class Initialized
INFO - 2020-10-28 04:29:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:29:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:29:36 --> Utf8 Class Initialized
INFO - 2020-10-28 04:29:36 --> URI Class Initialized
INFO - 2020-10-28 04:29:36 --> Router Class Initialized
INFO - 2020-10-28 04:29:36 --> Output Class Initialized
INFO - 2020-10-28 04:29:36 --> Security Class Initialized
DEBUG - 2020-10-28 04:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:29:36 --> Input Class Initialized
INFO - 2020-10-28 04:29:36 --> Language Class Initialized
INFO - 2020-10-28 04:29:36 --> Language Class Initialized
INFO - 2020-10-28 04:29:36 --> Config Class Initialized
INFO - 2020-10-28 04:29:36 --> Loader Class Initialized
INFO - 2020-10-28 04:29:36 --> Helper loaded: url_helper
INFO - 2020-10-28 04:29:36 --> Helper loaded: file_helper
INFO - 2020-10-28 04:29:36 --> Helper loaded: form_helper
INFO - 2020-10-28 04:29:36 --> Helper loaded: my_helper
INFO - 2020-10-28 04:29:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:29:36 --> Controller Class Initialized
DEBUG - 2020-10-28 04:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 04:29:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:29:36 --> Final output sent to browser
DEBUG - 2020-10-28 04:29:36 --> Total execution time: 0.2858
INFO - 2020-10-28 04:29:36 --> Config Class Initialized
INFO - 2020-10-28 04:29:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:29:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:29:36 --> Utf8 Class Initialized
INFO - 2020-10-28 04:29:36 --> URI Class Initialized
INFO - 2020-10-28 04:29:36 --> Router Class Initialized
INFO - 2020-10-28 04:29:36 --> Output Class Initialized
INFO - 2020-10-28 04:29:36 --> Security Class Initialized
DEBUG - 2020-10-28 04:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:29:36 --> Input Class Initialized
INFO - 2020-10-28 04:29:36 --> Language Class Initialized
INFO - 2020-10-28 04:29:36 --> Language Class Initialized
INFO - 2020-10-28 04:29:36 --> Config Class Initialized
INFO - 2020-10-28 04:29:36 --> Loader Class Initialized
INFO - 2020-10-28 04:29:36 --> Helper loaded: url_helper
INFO - 2020-10-28 04:29:36 --> Helper loaded: file_helper
INFO - 2020-10-28 04:29:36 --> Helper loaded: form_helper
INFO - 2020-10-28 04:29:36 --> Helper loaded: my_helper
INFO - 2020-10-28 04:29:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:29:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:29:36 --> Controller Class Initialized
INFO - 2020-10-28 04:36:52 --> Config Class Initialized
INFO - 2020-10-28 04:36:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:36:52 --> Utf8 Class Initialized
INFO - 2020-10-28 04:36:52 --> URI Class Initialized
INFO - 2020-10-28 04:36:52 --> Router Class Initialized
INFO - 2020-10-28 04:36:52 --> Output Class Initialized
INFO - 2020-10-28 04:36:52 --> Security Class Initialized
DEBUG - 2020-10-28 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:36:52 --> Input Class Initialized
INFO - 2020-10-28 04:36:52 --> Language Class Initialized
INFO - 2020-10-28 04:36:52 --> Language Class Initialized
INFO - 2020-10-28 04:36:52 --> Config Class Initialized
INFO - 2020-10-28 04:36:52 --> Loader Class Initialized
INFO - 2020-10-28 04:36:52 --> Helper loaded: url_helper
INFO - 2020-10-28 04:36:52 --> Helper loaded: file_helper
INFO - 2020-10-28 04:36:52 --> Helper loaded: form_helper
INFO - 2020-10-28 04:36:52 --> Helper loaded: my_helper
INFO - 2020-10-28 04:36:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:36:52 --> Controller Class Initialized
DEBUG - 2020-10-28 04:36:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-28 04:36:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:36:52 --> Final output sent to browser
DEBUG - 2020-10-28 04:36:52 --> Total execution time: 0.2915
INFO - 2020-10-28 04:36:52 --> Config Class Initialized
INFO - 2020-10-28 04:36:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:36:52 --> Utf8 Class Initialized
INFO - 2020-10-28 04:36:52 --> URI Class Initialized
INFO - 2020-10-28 04:36:52 --> Router Class Initialized
INFO - 2020-10-28 04:36:52 --> Output Class Initialized
INFO - 2020-10-28 04:36:52 --> Security Class Initialized
DEBUG - 2020-10-28 04:36:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:36:52 --> Input Class Initialized
INFO - 2020-10-28 04:36:52 --> Language Class Initialized
INFO - 2020-10-28 04:36:52 --> Language Class Initialized
INFO - 2020-10-28 04:36:52 --> Config Class Initialized
INFO - 2020-10-28 04:36:52 --> Loader Class Initialized
INFO - 2020-10-28 04:36:52 --> Helper loaded: url_helper
INFO - 2020-10-28 04:36:52 --> Helper loaded: file_helper
INFO - 2020-10-28 04:36:52 --> Helper loaded: form_helper
INFO - 2020-10-28 04:36:52 --> Helper loaded: my_helper
INFO - 2020-10-28 04:36:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:36:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:36:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:36:52 --> Controller Class Initialized
INFO - 2020-10-28 04:36:52 --> Config Class Initialized
INFO - 2020-10-28 04:36:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:36:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:36:52 --> Utf8 Class Initialized
INFO - 2020-10-28 04:36:52 --> URI Class Initialized
INFO - 2020-10-28 04:36:53 --> Router Class Initialized
INFO - 2020-10-28 04:36:53 --> Output Class Initialized
INFO - 2020-10-28 04:36:53 --> Security Class Initialized
DEBUG - 2020-10-28 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:36:53 --> Input Class Initialized
INFO - 2020-10-28 04:36:53 --> Language Class Initialized
INFO - 2020-10-28 04:36:53 --> Language Class Initialized
INFO - 2020-10-28 04:36:53 --> Config Class Initialized
INFO - 2020-10-28 04:36:53 --> Loader Class Initialized
INFO - 2020-10-28 04:36:53 --> Helper loaded: url_helper
INFO - 2020-10-28 04:36:53 --> Helper loaded: file_helper
INFO - 2020-10-28 04:36:53 --> Helper loaded: form_helper
INFO - 2020-10-28 04:36:53 --> Helper loaded: my_helper
INFO - 2020-10-28 04:36:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:36:53 --> Controller Class Initialized
DEBUG - 2020-10-28 04:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 04:36:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:36:53 --> Final output sent to browser
DEBUG - 2020-10-28 04:36:53 --> Total execution time: 0.3256
INFO - 2020-10-28 04:36:53 --> Config Class Initialized
INFO - 2020-10-28 04:36:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:36:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:36:53 --> Utf8 Class Initialized
INFO - 2020-10-28 04:36:53 --> URI Class Initialized
INFO - 2020-10-28 04:36:53 --> Router Class Initialized
INFO - 2020-10-28 04:36:53 --> Output Class Initialized
INFO - 2020-10-28 04:36:53 --> Security Class Initialized
DEBUG - 2020-10-28 04:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:36:53 --> Input Class Initialized
INFO - 2020-10-28 04:36:53 --> Language Class Initialized
INFO - 2020-10-28 04:36:53 --> Language Class Initialized
INFO - 2020-10-28 04:36:53 --> Config Class Initialized
INFO - 2020-10-28 04:36:53 --> Loader Class Initialized
INFO - 2020-10-28 04:36:53 --> Helper loaded: url_helper
INFO - 2020-10-28 04:36:53 --> Helper loaded: file_helper
INFO - 2020-10-28 04:36:53 --> Helper loaded: form_helper
INFO - 2020-10-28 04:36:53 --> Helper loaded: my_helper
INFO - 2020-10-28 04:36:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:36:53 --> Controller Class Initialized
INFO - 2020-10-28 04:36:54 --> Config Class Initialized
INFO - 2020-10-28 04:36:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:36:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:36:54 --> Utf8 Class Initialized
INFO - 2020-10-28 04:36:54 --> URI Class Initialized
INFO - 2020-10-28 04:36:54 --> Router Class Initialized
INFO - 2020-10-28 04:36:54 --> Output Class Initialized
INFO - 2020-10-28 04:36:54 --> Security Class Initialized
DEBUG - 2020-10-28 04:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:36:54 --> Input Class Initialized
INFO - 2020-10-28 04:36:54 --> Language Class Initialized
INFO - 2020-10-28 04:36:54 --> Language Class Initialized
INFO - 2020-10-28 04:36:54 --> Config Class Initialized
INFO - 2020-10-28 04:36:54 --> Loader Class Initialized
INFO - 2020-10-28 04:36:54 --> Helper loaded: url_helper
INFO - 2020-10-28 04:36:54 --> Helper loaded: file_helper
INFO - 2020-10-28 04:36:54 --> Helper loaded: form_helper
INFO - 2020-10-28 04:36:54 --> Helper loaded: my_helper
INFO - 2020-10-28 04:36:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:36:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:36:54 --> Controller Class Initialized
INFO - 2020-10-28 04:36:54 --> Final output sent to browser
DEBUG - 2020-10-28 04:36:54 --> Total execution time: 0.2651
INFO - 2020-10-28 04:41:27 --> Config Class Initialized
INFO - 2020-10-28 04:41:28 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:41:28 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:41:28 --> Utf8 Class Initialized
INFO - 2020-10-28 04:41:28 --> URI Class Initialized
INFO - 2020-10-28 04:41:28 --> Router Class Initialized
INFO - 2020-10-28 04:41:28 --> Output Class Initialized
INFO - 2020-10-28 04:41:28 --> Security Class Initialized
DEBUG - 2020-10-28 04:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:41:28 --> Input Class Initialized
INFO - 2020-10-28 04:41:28 --> Language Class Initialized
INFO - 2020-10-28 04:41:28 --> Language Class Initialized
INFO - 2020-10-28 04:41:28 --> Config Class Initialized
INFO - 2020-10-28 04:41:28 --> Loader Class Initialized
INFO - 2020-10-28 04:41:28 --> Helper loaded: url_helper
INFO - 2020-10-28 04:41:28 --> Helper loaded: file_helper
INFO - 2020-10-28 04:41:28 --> Helper loaded: form_helper
INFO - 2020-10-28 04:41:28 --> Helper loaded: my_helper
INFO - 2020-10-28 04:41:28 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:41:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:41:28 --> Controller Class Initialized
ERROR - 2020-10-28 04:41:28 --> Severity: Notice --> Undefined index: kode_singkat C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
ERROR - 2020-10-28 04:41:28 --> Severity: Notice --> Undefined index: Kelompok C:\xampp\htdocs\nilai\application\modules\data_mapel\controllers\Data_mapel.php 75
INFO - 2020-10-28 04:41:28 --> Final output sent to browser
DEBUG - 2020-10-28 04:41:28 --> Total execution time: 0.3471
INFO - 2020-10-28 04:41:30 --> Config Class Initialized
INFO - 2020-10-28 04:41:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:41:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:41:30 --> Utf8 Class Initialized
INFO - 2020-10-28 04:41:30 --> URI Class Initialized
INFO - 2020-10-28 04:41:30 --> Router Class Initialized
INFO - 2020-10-28 04:41:30 --> Output Class Initialized
INFO - 2020-10-28 04:41:30 --> Security Class Initialized
DEBUG - 2020-10-28 04:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:41:30 --> Input Class Initialized
INFO - 2020-10-28 04:41:30 --> Language Class Initialized
INFO - 2020-10-28 04:41:30 --> Language Class Initialized
INFO - 2020-10-28 04:41:30 --> Config Class Initialized
INFO - 2020-10-28 04:41:30 --> Loader Class Initialized
INFO - 2020-10-28 04:41:30 --> Helper loaded: url_helper
INFO - 2020-10-28 04:41:30 --> Helper loaded: file_helper
INFO - 2020-10-28 04:41:30 --> Helper loaded: form_helper
INFO - 2020-10-28 04:41:30 --> Helper loaded: my_helper
INFO - 2020-10-28 04:41:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:41:30 --> Controller Class Initialized
DEBUG - 2020-10-28 04:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 04:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 04:41:30 --> Final output sent to browser
DEBUG - 2020-10-28 04:41:30 --> Total execution time: 0.2917
INFO - 2020-10-28 04:41:30 --> Config Class Initialized
INFO - 2020-10-28 04:41:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:41:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:41:30 --> Utf8 Class Initialized
INFO - 2020-10-28 04:41:30 --> URI Class Initialized
INFO - 2020-10-28 04:41:30 --> Router Class Initialized
INFO - 2020-10-28 04:41:30 --> Output Class Initialized
INFO - 2020-10-28 04:41:30 --> Security Class Initialized
DEBUG - 2020-10-28 04:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:41:30 --> Input Class Initialized
INFO - 2020-10-28 04:41:30 --> Language Class Initialized
INFO - 2020-10-28 04:41:30 --> Language Class Initialized
INFO - 2020-10-28 04:41:30 --> Config Class Initialized
INFO - 2020-10-28 04:41:30 --> Loader Class Initialized
INFO - 2020-10-28 04:41:30 --> Helper loaded: url_helper
INFO - 2020-10-28 04:41:30 --> Helper loaded: file_helper
INFO - 2020-10-28 04:41:30 --> Helper loaded: form_helper
INFO - 2020-10-28 04:41:30 --> Helper loaded: my_helper
INFO - 2020-10-28 04:41:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:41:30 --> Controller Class Initialized
INFO - 2020-10-28 04:41:32 --> Config Class Initialized
INFO - 2020-10-28 04:41:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 04:41:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 04:41:32 --> Utf8 Class Initialized
INFO - 2020-10-28 04:41:32 --> URI Class Initialized
INFO - 2020-10-28 04:41:32 --> Router Class Initialized
INFO - 2020-10-28 04:41:32 --> Output Class Initialized
INFO - 2020-10-28 04:41:32 --> Security Class Initialized
DEBUG - 2020-10-28 04:41:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 04:41:32 --> Input Class Initialized
INFO - 2020-10-28 04:41:32 --> Language Class Initialized
INFO - 2020-10-28 04:41:32 --> Language Class Initialized
INFO - 2020-10-28 04:41:32 --> Config Class Initialized
INFO - 2020-10-28 04:41:32 --> Loader Class Initialized
INFO - 2020-10-28 04:41:32 --> Helper loaded: url_helper
INFO - 2020-10-28 04:41:32 --> Helper loaded: file_helper
INFO - 2020-10-28 04:41:32 --> Helper loaded: form_helper
INFO - 2020-10-28 04:41:32 --> Helper loaded: my_helper
INFO - 2020-10-28 04:41:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 04:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 04:41:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 04:41:32 --> Controller Class Initialized
INFO - 2020-10-28 04:41:32 --> Final output sent to browser
DEBUG - 2020-10-28 04:41:32 --> Total execution time: 0.2589
INFO - 2020-10-28 07:08:19 --> Config Class Initialized
INFO - 2020-10-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:08:19 --> Utf8 Class Initialized
INFO - 2020-10-28 07:08:19 --> URI Class Initialized
INFO - 2020-10-28 07:08:19 --> Router Class Initialized
INFO - 2020-10-28 07:08:19 --> Output Class Initialized
INFO - 2020-10-28 07:08:19 --> Security Class Initialized
DEBUG - 2020-10-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:08:19 --> Input Class Initialized
INFO - 2020-10-28 07:08:19 --> Language Class Initialized
INFO - 2020-10-28 07:08:19 --> Language Class Initialized
INFO - 2020-10-28 07:08:19 --> Config Class Initialized
INFO - 2020-10-28 07:08:19 --> Loader Class Initialized
INFO - 2020-10-28 07:08:19 --> Helper loaded: url_helper
INFO - 2020-10-28 07:08:19 --> Helper loaded: file_helper
INFO - 2020-10-28 07:08:19 --> Helper loaded: form_helper
INFO - 2020-10-28 07:08:19 --> Helper loaded: my_helper
INFO - 2020-10-28 07:08:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:08:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:08:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:08:19 --> Controller Class Initialized
DEBUG - 2020-10-28 07:08:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 07:08:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:08:19 --> Final output sent to browser
DEBUG - 2020-10-28 07:08:19 --> Total execution time: 0.3113
INFO - 2020-10-28 07:08:19 --> Config Class Initialized
INFO - 2020-10-28 07:08:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:08:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:08:19 --> Utf8 Class Initialized
INFO - 2020-10-28 07:08:19 --> URI Class Initialized
INFO - 2020-10-28 07:08:19 --> Router Class Initialized
INFO - 2020-10-28 07:08:19 --> Output Class Initialized
INFO - 2020-10-28 07:08:19 --> Security Class Initialized
DEBUG - 2020-10-28 07:08:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:08:19 --> Input Class Initialized
INFO - 2020-10-28 07:08:19 --> Language Class Initialized
INFO - 2020-10-28 07:08:19 --> Language Class Initialized
INFO - 2020-10-28 07:08:19 --> Config Class Initialized
INFO - 2020-10-28 07:08:19 --> Loader Class Initialized
INFO - 2020-10-28 07:08:19 --> Helper loaded: url_helper
INFO - 2020-10-28 07:08:19 --> Helper loaded: file_helper
INFO - 2020-10-28 07:08:19 --> Helper loaded: form_helper
INFO - 2020-10-28 07:08:20 --> Helper loaded: my_helper
INFO - 2020-10-28 07:08:20 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:08:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:08:20 --> Controller Class Initialized
INFO - 2020-10-28 07:08:20 --> Config Class Initialized
INFO - 2020-10-28 07:08:20 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:08:20 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:08:20 --> Utf8 Class Initialized
INFO - 2020-10-28 07:08:20 --> URI Class Initialized
INFO - 2020-10-28 07:08:20 --> Router Class Initialized
INFO - 2020-10-28 07:08:20 --> Output Class Initialized
INFO - 2020-10-28 07:08:20 --> Security Class Initialized
DEBUG - 2020-10-28 07:08:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:08:20 --> Input Class Initialized
INFO - 2020-10-28 07:08:20 --> Language Class Initialized
INFO - 2020-10-28 07:08:20 --> Language Class Initialized
INFO - 2020-10-28 07:08:20 --> Config Class Initialized
INFO - 2020-10-28 07:08:20 --> Loader Class Initialized
INFO - 2020-10-28 07:08:20 --> Helper loaded: url_helper
INFO - 2020-10-28 07:08:20 --> Helper loaded: file_helper
INFO - 2020-10-28 07:08:20 --> Helper loaded: form_helper
INFO - 2020-10-28 07:08:20 --> Helper loaded: my_helper
INFO - 2020-10-28 07:08:21 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:08:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:08:21 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:08:21 --> Controller Class Initialized
INFO - 2020-10-28 07:08:21 --> Final output sent to browser
DEBUG - 2020-10-28 07:08:21 --> Total execution time: 0.2719
INFO - 2020-10-28 07:08:42 --> Config Class Initialized
INFO - 2020-10-28 07:08:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:08:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:08:42 --> Utf8 Class Initialized
INFO - 2020-10-28 07:08:42 --> URI Class Initialized
INFO - 2020-10-28 07:08:42 --> Router Class Initialized
INFO - 2020-10-28 07:08:42 --> Output Class Initialized
INFO - 2020-10-28 07:08:42 --> Security Class Initialized
DEBUG - 2020-10-28 07:08:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:08:42 --> Input Class Initialized
INFO - 2020-10-28 07:08:42 --> Language Class Initialized
INFO - 2020-10-28 07:08:42 --> Language Class Initialized
INFO - 2020-10-28 07:08:42 --> Config Class Initialized
INFO - 2020-10-28 07:08:42 --> Loader Class Initialized
INFO - 2020-10-28 07:08:42 --> Helper loaded: url_helper
INFO - 2020-10-28 07:08:42 --> Helper loaded: file_helper
INFO - 2020-10-28 07:08:42 --> Helper loaded: form_helper
INFO - 2020-10-28 07:08:42 --> Helper loaded: my_helper
INFO - 2020-10-28 07:08:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:08:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:08:42 --> Controller Class Initialized
INFO - 2020-10-28 07:08:43 --> Final output sent to browser
DEBUG - 2020-10-28 07:08:43 --> Total execution time: 0.3346
INFO - 2020-10-28 07:08:43 --> Config Class Initialized
INFO - 2020-10-28 07:08:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:08:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:08:43 --> Utf8 Class Initialized
INFO - 2020-10-28 07:08:43 --> URI Class Initialized
INFO - 2020-10-28 07:08:43 --> Router Class Initialized
INFO - 2020-10-28 07:08:43 --> Output Class Initialized
INFO - 2020-10-28 07:08:43 --> Security Class Initialized
DEBUG - 2020-10-28 07:08:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:08:43 --> Input Class Initialized
INFO - 2020-10-28 07:08:43 --> Language Class Initialized
INFO - 2020-10-28 07:08:43 --> Language Class Initialized
INFO - 2020-10-28 07:08:43 --> Config Class Initialized
INFO - 2020-10-28 07:08:43 --> Loader Class Initialized
INFO - 2020-10-28 07:08:43 --> Helper loaded: url_helper
INFO - 2020-10-28 07:08:43 --> Helper loaded: file_helper
INFO - 2020-10-28 07:08:43 --> Helper loaded: form_helper
INFO - 2020-10-28 07:08:43 --> Helper loaded: my_helper
INFO - 2020-10-28 07:08:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:08:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:08:43 --> Controller Class Initialized
INFO - 2020-10-28 07:11:26 --> Config Class Initialized
INFO - 2020-10-28 07:11:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:11:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:11:26 --> Utf8 Class Initialized
INFO - 2020-10-28 07:11:26 --> URI Class Initialized
INFO - 2020-10-28 07:11:26 --> Router Class Initialized
INFO - 2020-10-28 07:11:26 --> Output Class Initialized
INFO - 2020-10-28 07:11:26 --> Security Class Initialized
DEBUG - 2020-10-28 07:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:11:26 --> Input Class Initialized
INFO - 2020-10-28 07:11:26 --> Language Class Initialized
INFO - 2020-10-28 07:11:26 --> Language Class Initialized
INFO - 2020-10-28 07:11:26 --> Config Class Initialized
INFO - 2020-10-28 07:11:26 --> Loader Class Initialized
INFO - 2020-10-28 07:11:26 --> Helper loaded: url_helper
INFO - 2020-10-28 07:11:26 --> Helper loaded: file_helper
INFO - 2020-10-28 07:11:26 --> Helper loaded: form_helper
INFO - 2020-10-28 07:11:26 --> Helper loaded: my_helper
INFO - 2020-10-28 07:11:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:11:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:11:26 --> Controller Class Initialized
INFO - 2020-10-28 07:11:26 --> Final output sent to browser
DEBUG - 2020-10-28 07:11:26 --> Total execution time: 0.2710
INFO - 2020-10-28 07:14:05 --> Config Class Initialized
INFO - 2020-10-28 07:14:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:05 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:05 --> URI Class Initialized
INFO - 2020-10-28 07:14:05 --> Router Class Initialized
INFO - 2020-10-28 07:14:05 --> Output Class Initialized
INFO - 2020-10-28 07:14:05 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:05 --> Input Class Initialized
INFO - 2020-10-28 07:14:05 --> Language Class Initialized
INFO - 2020-10-28 07:14:05 --> Language Class Initialized
INFO - 2020-10-28 07:14:05 --> Config Class Initialized
INFO - 2020-10-28 07:14:05 --> Loader Class Initialized
INFO - 2020-10-28 07:14:05 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:05 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:05 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:05 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:05 --> Controller Class Initialized
DEBUG - 2020-10-28 07:14:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 07:14:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:14:05 --> Final output sent to browser
DEBUG - 2020-10-28 07:14:05 --> Total execution time: 0.3022
INFO - 2020-10-28 07:14:05 --> Config Class Initialized
INFO - 2020-10-28 07:14:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:05 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:05 --> URI Class Initialized
INFO - 2020-10-28 07:14:05 --> Router Class Initialized
INFO - 2020-10-28 07:14:05 --> Output Class Initialized
INFO - 2020-10-28 07:14:05 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:05 --> Input Class Initialized
INFO - 2020-10-28 07:14:05 --> Language Class Initialized
INFO - 2020-10-28 07:14:05 --> Language Class Initialized
INFO - 2020-10-28 07:14:05 --> Config Class Initialized
INFO - 2020-10-28 07:14:05 --> Loader Class Initialized
INFO - 2020-10-28 07:14:05 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:05 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:05 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:05 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:05 --> Controller Class Initialized
INFO - 2020-10-28 07:14:06 --> Config Class Initialized
INFO - 2020-10-28 07:14:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:06 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:06 --> URI Class Initialized
INFO - 2020-10-28 07:14:06 --> Router Class Initialized
INFO - 2020-10-28 07:14:06 --> Output Class Initialized
INFO - 2020-10-28 07:14:06 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:06 --> Input Class Initialized
INFO - 2020-10-28 07:14:06 --> Language Class Initialized
INFO - 2020-10-28 07:14:06 --> Language Class Initialized
INFO - 2020-10-28 07:14:06 --> Config Class Initialized
INFO - 2020-10-28 07:14:06 --> Loader Class Initialized
INFO - 2020-10-28 07:14:06 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:06 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:06 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:06 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:06 --> Controller Class Initialized
INFO - 2020-10-28 07:14:06 --> Final output sent to browser
DEBUG - 2020-10-28 07:14:06 --> Total execution time: 0.2655
INFO - 2020-10-28 07:14:27 --> Config Class Initialized
INFO - 2020-10-28 07:14:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:27 --> URI Class Initialized
INFO - 2020-10-28 07:14:27 --> Router Class Initialized
INFO - 2020-10-28 07:14:27 --> Output Class Initialized
INFO - 2020-10-28 07:14:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:27 --> Input Class Initialized
INFO - 2020-10-28 07:14:27 --> Language Class Initialized
INFO - 2020-10-28 07:14:27 --> Language Class Initialized
INFO - 2020-10-28 07:14:27 --> Config Class Initialized
INFO - 2020-10-28 07:14:27 --> Loader Class Initialized
INFO - 2020-10-28 07:14:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:27 --> Controller Class Initialized
INFO - 2020-10-28 07:14:27 --> Final output sent to browser
DEBUG - 2020-10-28 07:14:27 --> Total execution time: 0.3182
INFO - 2020-10-28 07:14:27 --> Config Class Initialized
INFO - 2020-10-28 07:14:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:27 --> URI Class Initialized
INFO - 2020-10-28 07:14:27 --> Router Class Initialized
INFO - 2020-10-28 07:14:27 --> Output Class Initialized
INFO - 2020-10-28 07:14:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:27 --> Input Class Initialized
INFO - 2020-10-28 07:14:27 --> Language Class Initialized
INFO - 2020-10-28 07:14:27 --> Language Class Initialized
INFO - 2020-10-28 07:14:27 --> Config Class Initialized
INFO - 2020-10-28 07:14:27 --> Loader Class Initialized
INFO - 2020-10-28 07:14:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:27 --> Controller Class Initialized
INFO - 2020-10-28 07:14:41 --> Config Class Initialized
INFO - 2020-10-28 07:14:41 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:41 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:41 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:41 --> URI Class Initialized
INFO - 2020-10-28 07:14:41 --> Router Class Initialized
INFO - 2020-10-28 07:14:41 --> Output Class Initialized
INFO - 2020-10-28 07:14:41 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:41 --> Input Class Initialized
INFO - 2020-10-28 07:14:41 --> Language Class Initialized
INFO - 2020-10-28 07:14:41 --> Language Class Initialized
INFO - 2020-10-28 07:14:41 --> Config Class Initialized
INFO - 2020-10-28 07:14:41 --> Loader Class Initialized
INFO - 2020-10-28 07:14:41 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:41 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:41 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:41 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:41 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:41 --> Controller Class Initialized
INFO - 2020-10-28 07:14:41 --> Final output sent to browser
DEBUG - 2020-10-28 07:14:41 --> Total execution time: 0.2633
INFO - 2020-10-28 07:14:53 --> Config Class Initialized
INFO - 2020-10-28 07:14:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:54 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:54 --> URI Class Initialized
INFO - 2020-10-28 07:14:54 --> Router Class Initialized
INFO - 2020-10-28 07:14:54 --> Output Class Initialized
INFO - 2020-10-28 07:14:54 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:54 --> Input Class Initialized
INFO - 2020-10-28 07:14:54 --> Language Class Initialized
INFO - 2020-10-28 07:14:54 --> Language Class Initialized
INFO - 2020-10-28 07:14:54 --> Config Class Initialized
INFO - 2020-10-28 07:14:54 --> Loader Class Initialized
INFO - 2020-10-28 07:14:54 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:54 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:54 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:54 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:54 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:54 --> Controller Class Initialized
INFO - 2020-10-28 07:14:54 --> Final output sent to browser
DEBUG - 2020-10-28 07:14:54 --> Total execution time: 0.2614
INFO - 2020-10-28 07:14:58 --> Config Class Initialized
INFO - 2020-10-28 07:14:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:58 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:58 --> URI Class Initialized
INFO - 2020-10-28 07:14:58 --> Router Class Initialized
INFO - 2020-10-28 07:14:58 --> Output Class Initialized
INFO - 2020-10-28 07:14:58 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:58 --> Input Class Initialized
INFO - 2020-10-28 07:14:58 --> Language Class Initialized
INFO - 2020-10-28 07:14:58 --> Language Class Initialized
INFO - 2020-10-28 07:14:58 --> Config Class Initialized
INFO - 2020-10-28 07:14:58 --> Loader Class Initialized
INFO - 2020-10-28 07:14:58 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:58 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:58 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:58 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:58 --> Controller Class Initialized
INFO - 2020-10-28 07:14:58 --> Final output sent to browser
DEBUG - 2020-10-28 07:14:58 --> Total execution time: 0.3522
INFO - 2020-10-28 07:14:58 --> Config Class Initialized
INFO - 2020-10-28 07:14:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:14:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:14:58 --> Utf8 Class Initialized
INFO - 2020-10-28 07:14:58 --> URI Class Initialized
INFO - 2020-10-28 07:14:58 --> Router Class Initialized
INFO - 2020-10-28 07:14:58 --> Output Class Initialized
INFO - 2020-10-28 07:14:58 --> Security Class Initialized
DEBUG - 2020-10-28 07:14:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:14:58 --> Input Class Initialized
INFO - 2020-10-28 07:14:58 --> Language Class Initialized
INFO - 2020-10-28 07:14:58 --> Language Class Initialized
INFO - 2020-10-28 07:14:58 --> Config Class Initialized
INFO - 2020-10-28 07:14:58 --> Loader Class Initialized
INFO - 2020-10-28 07:14:58 --> Helper loaded: url_helper
INFO - 2020-10-28 07:14:58 --> Helper loaded: file_helper
INFO - 2020-10-28 07:14:58 --> Helper loaded: form_helper
INFO - 2020-10-28 07:14:58 --> Helper loaded: my_helper
INFO - 2020-10-28 07:14:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:14:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:14:58 --> Controller Class Initialized
INFO - 2020-10-28 07:15:00 --> Config Class Initialized
INFO - 2020-10-28 07:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:00 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:00 --> URI Class Initialized
INFO - 2020-10-28 07:15:00 --> Router Class Initialized
INFO - 2020-10-28 07:15:00 --> Output Class Initialized
INFO - 2020-10-28 07:15:00 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:00 --> Input Class Initialized
INFO - 2020-10-28 07:15:00 --> Language Class Initialized
INFO - 2020-10-28 07:15:00 --> Language Class Initialized
INFO - 2020-10-28 07:15:00 --> Config Class Initialized
INFO - 2020-10-28 07:15:00 --> Loader Class Initialized
INFO - 2020-10-28 07:15:00 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:00 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:00 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:00 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:00 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:00 --> Controller Class Initialized
INFO - 2020-10-28 07:15:00 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:00 --> Total execution time: 0.3172
INFO - 2020-10-28 07:15:00 --> Config Class Initialized
INFO - 2020-10-28 07:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:00 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:00 --> URI Class Initialized
INFO - 2020-10-28 07:15:00 --> Router Class Initialized
INFO - 2020-10-28 07:15:00 --> Output Class Initialized
INFO - 2020-10-28 07:15:00 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:00 --> Input Class Initialized
INFO - 2020-10-28 07:15:00 --> Language Class Initialized
INFO - 2020-10-28 07:15:00 --> Language Class Initialized
INFO - 2020-10-28 07:15:00 --> Config Class Initialized
INFO - 2020-10-28 07:15:00 --> Loader Class Initialized
INFO - 2020-10-28 07:15:00 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:00 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:00 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:00 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:00 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:00 --> Controller Class Initialized
INFO - 2020-10-28 07:15:02 --> Config Class Initialized
INFO - 2020-10-28 07:15:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:02 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:02 --> URI Class Initialized
INFO - 2020-10-28 07:15:02 --> Router Class Initialized
INFO - 2020-10-28 07:15:02 --> Output Class Initialized
INFO - 2020-10-28 07:15:02 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:02 --> Input Class Initialized
INFO - 2020-10-28 07:15:02 --> Language Class Initialized
INFO - 2020-10-28 07:15:02 --> Language Class Initialized
INFO - 2020-10-28 07:15:02 --> Config Class Initialized
INFO - 2020-10-28 07:15:02 --> Loader Class Initialized
INFO - 2020-10-28 07:15:02 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:02 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:02 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:02 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:02 --> Controller Class Initialized
INFO - 2020-10-28 07:15:02 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:02 --> Total execution time: 0.5062
INFO - 2020-10-28 07:15:02 --> Config Class Initialized
INFO - 2020-10-28 07:15:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:02 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:02 --> URI Class Initialized
INFO - 2020-10-28 07:15:02 --> Router Class Initialized
INFO - 2020-10-28 07:15:02 --> Output Class Initialized
INFO - 2020-10-28 07:15:02 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:02 --> Input Class Initialized
INFO - 2020-10-28 07:15:02 --> Language Class Initialized
INFO - 2020-10-28 07:15:02 --> Language Class Initialized
INFO - 2020-10-28 07:15:02 --> Config Class Initialized
INFO - 2020-10-28 07:15:02 --> Loader Class Initialized
INFO - 2020-10-28 07:15:02 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:02 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:02 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:02 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:03 --> Controller Class Initialized
INFO - 2020-10-28 07:15:22 --> Config Class Initialized
INFO - 2020-10-28 07:15:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:22 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:22 --> URI Class Initialized
INFO - 2020-10-28 07:15:22 --> Router Class Initialized
INFO - 2020-10-28 07:15:22 --> Output Class Initialized
INFO - 2020-10-28 07:15:22 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:22 --> Input Class Initialized
INFO - 2020-10-28 07:15:22 --> Language Class Initialized
INFO - 2020-10-28 07:15:22 --> Language Class Initialized
INFO - 2020-10-28 07:15:22 --> Config Class Initialized
INFO - 2020-10-28 07:15:22 --> Loader Class Initialized
INFO - 2020-10-28 07:15:22 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:22 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:22 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:22 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:22 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:22 --> Controller Class Initialized
INFO - 2020-10-28 07:15:22 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:22 --> Total execution time: 0.3222
INFO - 2020-10-28 07:15:22 --> Config Class Initialized
INFO - 2020-10-28 07:15:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:22 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:22 --> URI Class Initialized
INFO - 2020-10-28 07:15:22 --> Router Class Initialized
INFO - 2020-10-28 07:15:22 --> Output Class Initialized
INFO - 2020-10-28 07:15:22 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:22 --> Input Class Initialized
INFO - 2020-10-28 07:15:22 --> Language Class Initialized
INFO - 2020-10-28 07:15:22 --> Language Class Initialized
INFO - 2020-10-28 07:15:22 --> Config Class Initialized
INFO - 2020-10-28 07:15:22 --> Loader Class Initialized
INFO - 2020-10-28 07:15:22 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:22 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:22 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:22 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:22 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:22 --> Controller Class Initialized
INFO - 2020-10-28 07:15:24 --> Config Class Initialized
INFO - 2020-10-28 07:15:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:24 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:24 --> URI Class Initialized
INFO - 2020-10-28 07:15:24 --> Router Class Initialized
INFO - 2020-10-28 07:15:24 --> Output Class Initialized
INFO - 2020-10-28 07:15:24 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:24 --> Input Class Initialized
INFO - 2020-10-28 07:15:24 --> Language Class Initialized
INFO - 2020-10-28 07:15:24 --> Language Class Initialized
INFO - 2020-10-28 07:15:24 --> Config Class Initialized
INFO - 2020-10-28 07:15:24 --> Loader Class Initialized
INFO - 2020-10-28 07:15:24 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:24 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:24 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:24 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:24 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:24 --> Controller Class Initialized
INFO - 2020-10-28 07:15:24 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:24 --> Total execution time: 0.3241
INFO - 2020-10-28 07:15:25 --> Config Class Initialized
INFO - 2020-10-28 07:15:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:25 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:25 --> URI Class Initialized
INFO - 2020-10-28 07:15:25 --> Router Class Initialized
INFO - 2020-10-28 07:15:25 --> Output Class Initialized
INFO - 2020-10-28 07:15:25 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:25 --> Input Class Initialized
INFO - 2020-10-28 07:15:25 --> Language Class Initialized
INFO - 2020-10-28 07:15:25 --> Language Class Initialized
INFO - 2020-10-28 07:15:25 --> Config Class Initialized
INFO - 2020-10-28 07:15:25 --> Loader Class Initialized
INFO - 2020-10-28 07:15:25 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:25 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:25 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:25 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:25 --> Controller Class Initialized
INFO - 2020-10-28 07:15:27 --> Config Class Initialized
INFO - 2020-10-28 07:15:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:27 --> URI Class Initialized
INFO - 2020-10-28 07:15:27 --> Router Class Initialized
INFO - 2020-10-28 07:15:27 --> Output Class Initialized
INFO - 2020-10-28 07:15:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:27 --> Input Class Initialized
INFO - 2020-10-28 07:15:27 --> Language Class Initialized
INFO - 2020-10-28 07:15:27 --> Language Class Initialized
INFO - 2020-10-28 07:15:27 --> Config Class Initialized
INFO - 2020-10-28 07:15:27 --> Loader Class Initialized
INFO - 2020-10-28 07:15:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:27 --> Controller Class Initialized
INFO - 2020-10-28 07:15:27 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:27 --> Total execution time: 0.2738
INFO - 2020-10-28 07:15:34 --> Config Class Initialized
INFO - 2020-10-28 07:15:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:34 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:34 --> URI Class Initialized
INFO - 2020-10-28 07:15:34 --> Router Class Initialized
INFO - 2020-10-28 07:15:34 --> Output Class Initialized
INFO - 2020-10-28 07:15:34 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:34 --> Input Class Initialized
INFO - 2020-10-28 07:15:34 --> Language Class Initialized
INFO - 2020-10-28 07:15:34 --> Language Class Initialized
INFO - 2020-10-28 07:15:34 --> Config Class Initialized
INFO - 2020-10-28 07:15:34 --> Loader Class Initialized
INFO - 2020-10-28 07:15:34 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:34 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:34 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:34 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:34 --> Controller Class Initialized
INFO - 2020-10-28 07:15:34 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:34 --> Total execution time: 0.2955
INFO - 2020-10-28 07:15:34 --> Config Class Initialized
INFO - 2020-10-28 07:15:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:34 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:34 --> URI Class Initialized
INFO - 2020-10-28 07:15:34 --> Router Class Initialized
INFO - 2020-10-28 07:15:35 --> Output Class Initialized
INFO - 2020-10-28 07:15:35 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:35 --> Input Class Initialized
INFO - 2020-10-28 07:15:35 --> Language Class Initialized
INFO - 2020-10-28 07:15:35 --> Language Class Initialized
INFO - 2020-10-28 07:15:35 --> Config Class Initialized
INFO - 2020-10-28 07:15:35 --> Loader Class Initialized
INFO - 2020-10-28 07:15:35 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:35 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:35 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:35 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:35 --> Controller Class Initialized
INFO - 2020-10-28 07:15:37 --> Config Class Initialized
INFO - 2020-10-28 07:15:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:37 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:37 --> URI Class Initialized
INFO - 2020-10-28 07:15:37 --> Router Class Initialized
INFO - 2020-10-28 07:15:37 --> Output Class Initialized
INFO - 2020-10-28 07:15:37 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:37 --> Input Class Initialized
INFO - 2020-10-28 07:15:37 --> Language Class Initialized
INFO - 2020-10-28 07:15:37 --> Language Class Initialized
INFO - 2020-10-28 07:15:37 --> Config Class Initialized
INFO - 2020-10-28 07:15:37 --> Loader Class Initialized
INFO - 2020-10-28 07:15:37 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:37 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:37 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:37 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:37 --> Controller Class Initialized
INFO - 2020-10-28 07:15:37 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:37 --> Total execution time: 0.2690
INFO - 2020-10-28 07:15:43 --> Config Class Initialized
INFO - 2020-10-28 07:15:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:43 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:43 --> URI Class Initialized
INFO - 2020-10-28 07:15:43 --> Router Class Initialized
INFO - 2020-10-28 07:15:43 --> Output Class Initialized
INFO - 2020-10-28 07:15:43 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:43 --> Input Class Initialized
INFO - 2020-10-28 07:15:43 --> Language Class Initialized
INFO - 2020-10-28 07:15:43 --> Language Class Initialized
INFO - 2020-10-28 07:15:43 --> Config Class Initialized
INFO - 2020-10-28 07:15:43 --> Loader Class Initialized
INFO - 2020-10-28 07:15:43 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:43 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:43 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:43 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:43 --> Controller Class Initialized
INFO - 2020-10-28 07:15:44 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:44 --> Total execution time: 0.3184
INFO - 2020-10-28 07:15:44 --> Config Class Initialized
INFO - 2020-10-28 07:15:44 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:44 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:44 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:44 --> URI Class Initialized
INFO - 2020-10-28 07:15:44 --> Router Class Initialized
INFO - 2020-10-28 07:15:44 --> Output Class Initialized
INFO - 2020-10-28 07:15:44 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:44 --> Input Class Initialized
INFO - 2020-10-28 07:15:44 --> Language Class Initialized
INFO - 2020-10-28 07:15:44 --> Language Class Initialized
INFO - 2020-10-28 07:15:44 --> Config Class Initialized
INFO - 2020-10-28 07:15:44 --> Loader Class Initialized
INFO - 2020-10-28 07:15:44 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:44 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:44 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:44 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:44 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:44 --> Controller Class Initialized
INFO - 2020-10-28 07:15:47 --> Config Class Initialized
INFO - 2020-10-28 07:15:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:47 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:47 --> URI Class Initialized
INFO - 2020-10-28 07:15:47 --> Router Class Initialized
INFO - 2020-10-28 07:15:47 --> Output Class Initialized
INFO - 2020-10-28 07:15:47 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:47 --> Input Class Initialized
INFO - 2020-10-28 07:15:47 --> Language Class Initialized
INFO - 2020-10-28 07:15:47 --> Language Class Initialized
INFO - 2020-10-28 07:15:47 --> Config Class Initialized
INFO - 2020-10-28 07:15:47 --> Loader Class Initialized
INFO - 2020-10-28 07:15:47 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:47 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:47 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:47 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:47 --> Controller Class Initialized
INFO - 2020-10-28 07:15:47 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:47 --> Total execution time: 0.2826
INFO - 2020-10-28 07:15:56 --> Config Class Initialized
INFO - 2020-10-28 07:15:56 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:56 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:56 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:56 --> URI Class Initialized
INFO - 2020-10-28 07:15:56 --> Router Class Initialized
INFO - 2020-10-28 07:15:56 --> Output Class Initialized
INFO - 2020-10-28 07:15:56 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:56 --> Input Class Initialized
INFO - 2020-10-28 07:15:56 --> Language Class Initialized
INFO - 2020-10-28 07:15:57 --> Language Class Initialized
INFO - 2020-10-28 07:15:57 --> Config Class Initialized
INFO - 2020-10-28 07:15:57 --> Loader Class Initialized
INFO - 2020-10-28 07:15:57 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:57 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:57 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:57 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:57 --> Controller Class Initialized
INFO - 2020-10-28 07:15:57 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:57 --> Total execution time: 0.3158
INFO - 2020-10-28 07:15:57 --> Config Class Initialized
INFO - 2020-10-28 07:15:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:57 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:57 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:57 --> URI Class Initialized
INFO - 2020-10-28 07:15:57 --> Router Class Initialized
INFO - 2020-10-28 07:15:57 --> Output Class Initialized
INFO - 2020-10-28 07:15:57 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:57 --> Input Class Initialized
INFO - 2020-10-28 07:15:57 --> Language Class Initialized
INFO - 2020-10-28 07:15:57 --> Language Class Initialized
INFO - 2020-10-28 07:15:57 --> Config Class Initialized
INFO - 2020-10-28 07:15:57 --> Loader Class Initialized
INFO - 2020-10-28 07:15:57 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:57 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:57 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:57 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:57 --> Controller Class Initialized
INFO - 2020-10-28 07:15:59 --> Config Class Initialized
INFO - 2020-10-28 07:15:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:15:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:15:59 --> Utf8 Class Initialized
INFO - 2020-10-28 07:15:59 --> URI Class Initialized
INFO - 2020-10-28 07:15:59 --> Router Class Initialized
INFO - 2020-10-28 07:15:59 --> Output Class Initialized
INFO - 2020-10-28 07:15:59 --> Security Class Initialized
DEBUG - 2020-10-28 07:15:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:15:59 --> Input Class Initialized
INFO - 2020-10-28 07:15:59 --> Language Class Initialized
INFO - 2020-10-28 07:15:59 --> Language Class Initialized
INFO - 2020-10-28 07:15:59 --> Config Class Initialized
INFO - 2020-10-28 07:15:59 --> Loader Class Initialized
INFO - 2020-10-28 07:15:59 --> Helper loaded: url_helper
INFO - 2020-10-28 07:15:59 --> Helper loaded: file_helper
INFO - 2020-10-28 07:15:59 --> Helper loaded: form_helper
INFO - 2020-10-28 07:15:59 --> Helper loaded: my_helper
INFO - 2020-10-28 07:15:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:15:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:15:59 --> Controller Class Initialized
INFO - 2020-10-28 07:15:59 --> Final output sent to browser
DEBUG - 2020-10-28 07:15:59 --> Total execution time: 0.2830
INFO - 2020-10-28 07:16:10 --> Config Class Initialized
INFO - 2020-10-28 07:16:10 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:10 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:10 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:10 --> URI Class Initialized
INFO - 2020-10-28 07:16:10 --> Router Class Initialized
INFO - 2020-10-28 07:16:10 --> Output Class Initialized
INFO - 2020-10-28 07:16:10 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:10 --> Input Class Initialized
INFO - 2020-10-28 07:16:10 --> Language Class Initialized
INFO - 2020-10-28 07:16:10 --> Language Class Initialized
INFO - 2020-10-28 07:16:10 --> Config Class Initialized
INFO - 2020-10-28 07:16:10 --> Loader Class Initialized
INFO - 2020-10-28 07:16:10 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:10 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:10 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:10 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:10 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:10 --> Controller Class Initialized
INFO - 2020-10-28 07:16:10 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:10 --> Total execution time: 0.3134
INFO - 2020-10-28 07:16:10 --> Config Class Initialized
INFO - 2020-10-28 07:16:10 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:10 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:10 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:10 --> URI Class Initialized
INFO - 2020-10-28 07:16:10 --> Router Class Initialized
INFO - 2020-10-28 07:16:10 --> Output Class Initialized
INFO - 2020-10-28 07:16:10 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:10 --> Input Class Initialized
INFO - 2020-10-28 07:16:10 --> Language Class Initialized
INFO - 2020-10-28 07:16:10 --> Language Class Initialized
INFO - 2020-10-28 07:16:10 --> Config Class Initialized
INFO - 2020-10-28 07:16:10 --> Loader Class Initialized
INFO - 2020-10-28 07:16:10 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:10 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:10 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:10 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:11 --> Controller Class Initialized
INFO - 2020-10-28 07:16:12 --> Config Class Initialized
INFO - 2020-10-28 07:16:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:12 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:12 --> URI Class Initialized
INFO - 2020-10-28 07:16:12 --> Router Class Initialized
INFO - 2020-10-28 07:16:12 --> Output Class Initialized
INFO - 2020-10-28 07:16:12 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:12 --> Input Class Initialized
INFO - 2020-10-28 07:16:12 --> Language Class Initialized
INFO - 2020-10-28 07:16:12 --> Language Class Initialized
INFO - 2020-10-28 07:16:12 --> Config Class Initialized
INFO - 2020-10-28 07:16:12 --> Loader Class Initialized
INFO - 2020-10-28 07:16:12 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:12 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:12 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:12 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:12 --> Controller Class Initialized
INFO - 2020-10-28 07:16:12 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:12 --> Total execution time: 0.2843
INFO - 2020-10-28 07:16:18 --> Config Class Initialized
INFO - 2020-10-28 07:16:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:18 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:18 --> URI Class Initialized
INFO - 2020-10-28 07:16:18 --> Router Class Initialized
INFO - 2020-10-28 07:16:18 --> Output Class Initialized
INFO - 2020-10-28 07:16:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:18 --> Input Class Initialized
INFO - 2020-10-28 07:16:18 --> Language Class Initialized
INFO - 2020-10-28 07:16:18 --> Language Class Initialized
INFO - 2020-10-28 07:16:18 --> Config Class Initialized
INFO - 2020-10-28 07:16:18 --> Loader Class Initialized
INFO - 2020-10-28 07:16:18 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:18 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:18 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:18 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:18 --> Controller Class Initialized
INFO - 2020-10-28 07:16:18 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:18 --> Total execution time: 0.3371
INFO - 2020-10-28 07:16:18 --> Config Class Initialized
INFO - 2020-10-28 07:16:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:18 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:18 --> URI Class Initialized
INFO - 2020-10-28 07:16:18 --> Router Class Initialized
INFO - 2020-10-28 07:16:18 --> Output Class Initialized
INFO - 2020-10-28 07:16:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:19 --> Input Class Initialized
INFO - 2020-10-28 07:16:19 --> Language Class Initialized
INFO - 2020-10-28 07:16:19 --> Language Class Initialized
INFO - 2020-10-28 07:16:19 --> Config Class Initialized
INFO - 2020-10-28 07:16:19 --> Loader Class Initialized
INFO - 2020-10-28 07:16:19 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:19 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:19 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:19 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:19 --> Controller Class Initialized
INFO - 2020-10-28 07:16:20 --> Config Class Initialized
INFO - 2020-10-28 07:16:20 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:20 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:20 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:20 --> URI Class Initialized
INFO - 2020-10-28 07:16:20 --> Router Class Initialized
INFO - 2020-10-28 07:16:20 --> Output Class Initialized
INFO - 2020-10-28 07:16:20 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:20 --> Input Class Initialized
INFO - 2020-10-28 07:16:20 --> Language Class Initialized
INFO - 2020-10-28 07:16:20 --> Language Class Initialized
INFO - 2020-10-28 07:16:20 --> Config Class Initialized
INFO - 2020-10-28 07:16:20 --> Loader Class Initialized
INFO - 2020-10-28 07:16:20 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:20 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:20 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:20 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:20 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:20 --> Controller Class Initialized
INFO - 2020-10-28 07:16:20 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:20 --> Total execution time: 0.2757
INFO - 2020-10-28 07:16:25 --> Config Class Initialized
INFO - 2020-10-28 07:16:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:25 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:25 --> URI Class Initialized
INFO - 2020-10-28 07:16:25 --> Router Class Initialized
INFO - 2020-10-28 07:16:25 --> Output Class Initialized
INFO - 2020-10-28 07:16:25 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:25 --> Input Class Initialized
INFO - 2020-10-28 07:16:25 --> Language Class Initialized
INFO - 2020-10-28 07:16:25 --> Language Class Initialized
INFO - 2020-10-28 07:16:25 --> Config Class Initialized
INFO - 2020-10-28 07:16:25 --> Loader Class Initialized
INFO - 2020-10-28 07:16:25 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:25 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:25 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:25 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:26 --> Controller Class Initialized
INFO - 2020-10-28 07:16:26 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:26 --> Total execution time: 0.2843
INFO - 2020-10-28 07:16:34 --> Config Class Initialized
INFO - 2020-10-28 07:16:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:34 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:34 --> URI Class Initialized
INFO - 2020-10-28 07:16:34 --> Router Class Initialized
INFO - 2020-10-28 07:16:34 --> Output Class Initialized
INFO - 2020-10-28 07:16:34 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:34 --> Input Class Initialized
INFO - 2020-10-28 07:16:34 --> Language Class Initialized
INFO - 2020-10-28 07:16:34 --> Language Class Initialized
INFO - 2020-10-28 07:16:34 --> Config Class Initialized
INFO - 2020-10-28 07:16:34 --> Loader Class Initialized
INFO - 2020-10-28 07:16:34 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:34 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:34 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:34 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:34 --> Controller Class Initialized
INFO - 2020-10-28 07:16:34 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:34 --> Total execution time: 0.3182
INFO - 2020-10-28 07:16:34 --> Config Class Initialized
INFO - 2020-10-28 07:16:34 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:34 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:34 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:34 --> URI Class Initialized
INFO - 2020-10-28 07:16:34 --> Router Class Initialized
INFO - 2020-10-28 07:16:34 --> Output Class Initialized
INFO - 2020-10-28 07:16:34 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:34 --> Input Class Initialized
INFO - 2020-10-28 07:16:34 --> Language Class Initialized
INFO - 2020-10-28 07:16:34 --> Language Class Initialized
INFO - 2020-10-28 07:16:34 --> Config Class Initialized
INFO - 2020-10-28 07:16:34 --> Loader Class Initialized
INFO - 2020-10-28 07:16:34 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:34 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:34 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:34 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:34 --> Controller Class Initialized
INFO - 2020-10-28 07:16:37 --> Config Class Initialized
INFO - 2020-10-28 07:16:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:37 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:37 --> URI Class Initialized
INFO - 2020-10-28 07:16:37 --> Router Class Initialized
INFO - 2020-10-28 07:16:37 --> Output Class Initialized
INFO - 2020-10-28 07:16:37 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:37 --> Input Class Initialized
INFO - 2020-10-28 07:16:37 --> Language Class Initialized
INFO - 2020-10-28 07:16:37 --> Language Class Initialized
INFO - 2020-10-28 07:16:37 --> Config Class Initialized
INFO - 2020-10-28 07:16:37 --> Loader Class Initialized
INFO - 2020-10-28 07:16:37 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:37 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:37 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:37 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:37 --> Controller Class Initialized
INFO - 2020-10-28 07:16:37 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:37 --> Total execution time: 0.2780
INFO - 2020-10-28 07:16:43 --> Config Class Initialized
INFO - 2020-10-28 07:16:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:43 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:43 --> URI Class Initialized
INFO - 2020-10-28 07:16:43 --> Router Class Initialized
INFO - 2020-10-28 07:16:43 --> Output Class Initialized
INFO - 2020-10-28 07:16:43 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:43 --> Input Class Initialized
INFO - 2020-10-28 07:16:43 --> Language Class Initialized
INFO - 2020-10-28 07:16:43 --> Language Class Initialized
INFO - 2020-10-28 07:16:43 --> Config Class Initialized
INFO - 2020-10-28 07:16:43 --> Loader Class Initialized
INFO - 2020-10-28 07:16:43 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:43 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:43 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:43 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:43 --> Controller Class Initialized
INFO - 2020-10-28 07:16:43 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:43 --> Total execution time: 0.3296
INFO - 2020-10-28 07:16:43 --> Config Class Initialized
INFO - 2020-10-28 07:16:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:43 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:43 --> URI Class Initialized
INFO - 2020-10-28 07:16:43 --> Router Class Initialized
INFO - 2020-10-28 07:16:43 --> Output Class Initialized
INFO - 2020-10-28 07:16:43 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:43 --> Input Class Initialized
INFO - 2020-10-28 07:16:44 --> Language Class Initialized
INFO - 2020-10-28 07:16:44 --> Language Class Initialized
INFO - 2020-10-28 07:16:44 --> Config Class Initialized
INFO - 2020-10-28 07:16:44 --> Loader Class Initialized
INFO - 2020-10-28 07:16:44 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:44 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:44 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:44 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:44 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:44 --> Controller Class Initialized
INFO - 2020-10-28 07:16:49 --> Config Class Initialized
INFO - 2020-10-28 07:16:49 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:16:49 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:16:49 --> Utf8 Class Initialized
INFO - 2020-10-28 07:16:49 --> URI Class Initialized
INFO - 2020-10-28 07:16:49 --> Router Class Initialized
INFO - 2020-10-28 07:16:49 --> Output Class Initialized
INFO - 2020-10-28 07:16:49 --> Security Class Initialized
DEBUG - 2020-10-28 07:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:16:49 --> Input Class Initialized
INFO - 2020-10-28 07:16:49 --> Language Class Initialized
INFO - 2020-10-28 07:16:49 --> Language Class Initialized
INFO - 2020-10-28 07:16:49 --> Config Class Initialized
INFO - 2020-10-28 07:16:49 --> Loader Class Initialized
INFO - 2020-10-28 07:16:49 --> Helper loaded: url_helper
INFO - 2020-10-28 07:16:49 --> Helper loaded: file_helper
INFO - 2020-10-28 07:16:49 --> Helper loaded: form_helper
INFO - 2020-10-28 07:16:49 --> Helper loaded: my_helper
INFO - 2020-10-28 07:16:49 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:16:49 --> Controller Class Initialized
INFO - 2020-10-28 07:16:49 --> Final output sent to browser
DEBUG - 2020-10-28 07:16:49 --> Total execution time: 0.2825
INFO - 2020-10-28 07:17:02 --> Config Class Initialized
INFO - 2020-10-28 07:17:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:02 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:02 --> URI Class Initialized
INFO - 2020-10-28 07:17:02 --> Router Class Initialized
INFO - 2020-10-28 07:17:02 --> Output Class Initialized
INFO - 2020-10-28 07:17:02 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:02 --> Input Class Initialized
INFO - 2020-10-28 07:17:02 --> Language Class Initialized
INFO - 2020-10-28 07:17:02 --> Language Class Initialized
INFO - 2020-10-28 07:17:02 --> Config Class Initialized
INFO - 2020-10-28 07:17:02 --> Loader Class Initialized
INFO - 2020-10-28 07:17:02 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:02 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:02 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:02 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:02 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:02 --> Controller Class Initialized
INFO - 2020-10-28 07:17:02 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:02 --> Total execution time: 0.3131
INFO - 2020-10-28 07:17:02 --> Config Class Initialized
INFO - 2020-10-28 07:17:02 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:02 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:02 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:02 --> URI Class Initialized
INFO - 2020-10-28 07:17:03 --> Router Class Initialized
INFO - 2020-10-28 07:17:03 --> Output Class Initialized
INFO - 2020-10-28 07:17:03 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:03 --> Input Class Initialized
INFO - 2020-10-28 07:17:03 --> Language Class Initialized
INFO - 2020-10-28 07:17:03 --> Language Class Initialized
INFO - 2020-10-28 07:17:03 --> Config Class Initialized
INFO - 2020-10-28 07:17:03 --> Loader Class Initialized
INFO - 2020-10-28 07:17:03 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:03 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:03 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:03 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:03 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:03 --> Controller Class Initialized
INFO - 2020-10-28 07:17:07 --> Config Class Initialized
INFO - 2020-10-28 07:17:07 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:07 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:07 --> URI Class Initialized
INFO - 2020-10-28 07:17:07 --> Router Class Initialized
INFO - 2020-10-28 07:17:07 --> Output Class Initialized
INFO - 2020-10-28 07:17:07 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:07 --> Input Class Initialized
INFO - 2020-10-28 07:17:07 --> Language Class Initialized
INFO - 2020-10-28 07:17:07 --> Language Class Initialized
INFO - 2020-10-28 07:17:07 --> Config Class Initialized
INFO - 2020-10-28 07:17:07 --> Loader Class Initialized
INFO - 2020-10-28 07:17:07 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:07 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:07 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:07 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:07 --> Controller Class Initialized
INFO - 2020-10-28 07:17:07 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:07 --> Total execution time: 0.2831
INFO - 2020-10-28 07:17:11 --> Config Class Initialized
INFO - 2020-10-28 07:17:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:11 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:11 --> URI Class Initialized
INFO - 2020-10-28 07:17:11 --> Router Class Initialized
INFO - 2020-10-28 07:17:11 --> Output Class Initialized
INFO - 2020-10-28 07:17:11 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:11 --> Input Class Initialized
INFO - 2020-10-28 07:17:11 --> Language Class Initialized
INFO - 2020-10-28 07:17:11 --> Language Class Initialized
INFO - 2020-10-28 07:17:11 --> Config Class Initialized
INFO - 2020-10-28 07:17:11 --> Loader Class Initialized
INFO - 2020-10-28 07:17:11 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:11 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:11 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:11 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:11 --> Controller Class Initialized
INFO - 2020-10-28 07:17:11 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:11 --> Total execution time: 0.3355
INFO - 2020-10-28 07:17:11 --> Config Class Initialized
INFO - 2020-10-28 07:17:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:11 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:11 --> URI Class Initialized
INFO - 2020-10-28 07:17:11 --> Router Class Initialized
INFO - 2020-10-28 07:17:11 --> Output Class Initialized
INFO - 2020-10-28 07:17:11 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:11 --> Input Class Initialized
INFO - 2020-10-28 07:17:12 --> Language Class Initialized
INFO - 2020-10-28 07:17:12 --> Language Class Initialized
INFO - 2020-10-28 07:17:12 --> Config Class Initialized
INFO - 2020-10-28 07:17:12 --> Loader Class Initialized
INFO - 2020-10-28 07:17:12 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:12 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:12 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:12 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:12 --> Controller Class Initialized
INFO - 2020-10-28 07:17:16 --> Config Class Initialized
INFO - 2020-10-28 07:17:16 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:16 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:16 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:16 --> URI Class Initialized
INFO - 2020-10-28 07:17:16 --> Router Class Initialized
INFO - 2020-10-28 07:17:16 --> Output Class Initialized
INFO - 2020-10-28 07:17:16 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:16 --> Input Class Initialized
INFO - 2020-10-28 07:17:16 --> Language Class Initialized
INFO - 2020-10-28 07:17:16 --> Language Class Initialized
INFO - 2020-10-28 07:17:16 --> Config Class Initialized
INFO - 2020-10-28 07:17:16 --> Loader Class Initialized
INFO - 2020-10-28 07:17:16 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:16 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:16 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:16 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:16 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:16 --> Controller Class Initialized
INFO - 2020-10-28 07:17:18 --> Config Class Initialized
INFO - 2020-10-28 07:17:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:18 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:18 --> URI Class Initialized
INFO - 2020-10-28 07:17:18 --> Router Class Initialized
INFO - 2020-10-28 07:17:18 --> Output Class Initialized
INFO - 2020-10-28 07:17:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:18 --> Input Class Initialized
INFO - 2020-10-28 07:17:18 --> Language Class Initialized
INFO - 2020-10-28 07:17:18 --> Language Class Initialized
INFO - 2020-10-28 07:17:18 --> Config Class Initialized
INFO - 2020-10-28 07:17:18 --> Loader Class Initialized
INFO - 2020-10-28 07:17:18 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:18 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:18 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:18 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:18 --> Controller Class Initialized
INFO - 2020-10-28 07:17:18 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:18 --> Total execution time: 0.3020
INFO - 2020-10-28 07:17:22 --> Config Class Initialized
INFO - 2020-10-28 07:17:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:22 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:22 --> URI Class Initialized
INFO - 2020-10-28 07:17:22 --> Router Class Initialized
INFO - 2020-10-28 07:17:22 --> Output Class Initialized
INFO - 2020-10-28 07:17:22 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:22 --> Input Class Initialized
INFO - 2020-10-28 07:17:22 --> Language Class Initialized
INFO - 2020-10-28 07:17:22 --> Language Class Initialized
INFO - 2020-10-28 07:17:22 --> Config Class Initialized
INFO - 2020-10-28 07:17:23 --> Loader Class Initialized
INFO - 2020-10-28 07:17:23 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:23 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:23 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:23 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:23 --> Controller Class Initialized
INFO - 2020-10-28 07:17:23 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:23 --> Total execution time: 0.3376
INFO - 2020-10-28 07:17:23 --> Config Class Initialized
INFO - 2020-10-28 07:17:23 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:23 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:23 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:23 --> URI Class Initialized
INFO - 2020-10-28 07:17:23 --> Router Class Initialized
INFO - 2020-10-28 07:17:23 --> Output Class Initialized
INFO - 2020-10-28 07:17:23 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:23 --> Input Class Initialized
INFO - 2020-10-28 07:17:23 --> Language Class Initialized
INFO - 2020-10-28 07:17:23 --> Language Class Initialized
INFO - 2020-10-28 07:17:23 --> Config Class Initialized
INFO - 2020-10-28 07:17:23 --> Loader Class Initialized
INFO - 2020-10-28 07:17:23 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:23 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:23 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:23 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:23 --> Controller Class Initialized
INFO - 2020-10-28 07:17:25 --> Config Class Initialized
INFO - 2020-10-28 07:17:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:25 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:25 --> URI Class Initialized
INFO - 2020-10-28 07:17:25 --> Router Class Initialized
INFO - 2020-10-28 07:17:25 --> Output Class Initialized
INFO - 2020-10-28 07:17:25 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:25 --> Input Class Initialized
INFO - 2020-10-28 07:17:25 --> Language Class Initialized
INFO - 2020-10-28 07:17:25 --> Language Class Initialized
INFO - 2020-10-28 07:17:25 --> Config Class Initialized
INFO - 2020-10-28 07:17:25 --> Loader Class Initialized
INFO - 2020-10-28 07:17:25 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:25 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:25 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:25 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:25 --> Controller Class Initialized
INFO - 2020-10-28 07:17:27 --> Config Class Initialized
INFO - 2020-10-28 07:17:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:27 --> URI Class Initialized
INFO - 2020-10-28 07:17:27 --> Router Class Initialized
INFO - 2020-10-28 07:17:27 --> Output Class Initialized
INFO - 2020-10-28 07:17:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:27 --> Input Class Initialized
INFO - 2020-10-28 07:17:27 --> Language Class Initialized
INFO - 2020-10-28 07:17:27 --> Language Class Initialized
INFO - 2020-10-28 07:17:27 --> Config Class Initialized
INFO - 2020-10-28 07:17:27 --> Loader Class Initialized
INFO - 2020-10-28 07:17:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:27 --> Controller Class Initialized
INFO - 2020-10-28 07:17:27 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:27 --> Total execution time: 0.2817
INFO - 2020-10-28 07:17:33 --> Config Class Initialized
INFO - 2020-10-28 07:17:33 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:33 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:33 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:33 --> URI Class Initialized
INFO - 2020-10-28 07:17:33 --> Router Class Initialized
INFO - 2020-10-28 07:17:33 --> Output Class Initialized
INFO - 2020-10-28 07:17:34 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:34 --> Input Class Initialized
INFO - 2020-10-28 07:17:34 --> Language Class Initialized
INFO - 2020-10-28 07:17:34 --> Language Class Initialized
INFO - 2020-10-28 07:17:34 --> Config Class Initialized
INFO - 2020-10-28 07:17:34 --> Loader Class Initialized
INFO - 2020-10-28 07:17:34 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:34 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:34 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:34 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:34 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:34 --> Controller Class Initialized
ERROR - 2020-10-28 07:17:34 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '4'
INFO - 2020-10-28 07:17:34 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 07:17:40 --> Config Class Initialized
INFO - 2020-10-28 07:17:40 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:40 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:40 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:40 --> URI Class Initialized
INFO - 2020-10-28 07:17:40 --> Router Class Initialized
INFO - 2020-10-28 07:17:40 --> Output Class Initialized
INFO - 2020-10-28 07:17:40 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:40 --> Input Class Initialized
INFO - 2020-10-28 07:17:40 --> Language Class Initialized
INFO - 2020-10-28 07:17:40 --> Language Class Initialized
INFO - 2020-10-28 07:17:40 --> Config Class Initialized
INFO - 2020-10-28 07:17:40 --> Loader Class Initialized
INFO - 2020-10-28 07:17:40 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:40 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:40 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:40 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:40 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:40 --> Controller Class Initialized
ERROR - 2020-10-28 07:17:40 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '4'
INFO - 2020-10-28 07:17:40 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 07:17:43 --> Config Class Initialized
INFO - 2020-10-28 07:17:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:43 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:43 --> URI Class Initialized
INFO - 2020-10-28 07:17:43 --> Router Class Initialized
INFO - 2020-10-28 07:17:43 --> Output Class Initialized
INFO - 2020-10-28 07:17:43 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:43 --> Input Class Initialized
INFO - 2020-10-28 07:17:43 --> Language Class Initialized
INFO - 2020-10-28 07:17:43 --> Language Class Initialized
INFO - 2020-10-28 07:17:43 --> Config Class Initialized
INFO - 2020-10-28 07:17:43 --> Loader Class Initialized
INFO - 2020-10-28 07:17:43 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:43 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:43 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:43 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:43 --> Controller Class Initialized
ERROR - 2020-10-28 07:17:44 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '4'
INFO - 2020-10-28 07:17:44 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 07:17:45 --> Config Class Initialized
INFO - 2020-10-28 07:17:45 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:45 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:45 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:45 --> URI Class Initialized
INFO - 2020-10-28 07:17:45 --> Router Class Initialized
INFO - 2020-10-28 07:17:45 --> Output Class Initialized
INFO - 2020-10-28 07:17:45 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:45 --> Input Class Initialized
INFO - 2020-10-28 07:17:45 --> Language Class Initialized
INFO - 2020-10-28 07:17:45 --> Language Class Initialized
INFO - 2020-10-28 07:17:45 --> Config Class Initialized
INFO - 2020-10-28 07:17:45 --> Loader Class Initialized
INFO - 2020-10-28 07:17:45 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:45 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:45 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:45 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:45 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:45 --> Controller Class Initialized
INFO - 2020-10-28 07:17:45 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:45 --> Total execution time: 0.3754
INFO - 2020-10-28 07:17:45 --> Config Class Initialized
INFO - 2020-10-28 07:17:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:46 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:46 --> URI Class Initialized
INFO - 2020-10-28 07:17:46 --> Router Class Initialized
INFO - 2020-10-28 07:17:46 --> Output Class Initialized
INFO - 2020-10-28 07:17:46 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:46 --> Input Class Initialized
INFO - 2020-10-28 07:17:46 --> Language Class Initialized
INFO - 2020-10-28 07:17:46 --> Language Class Initialized
INFO - 2020-10-28 07:17:46 --> Config Class Initialized
INFO - 2020-10-28 07:17:46 --> Loader Class Initialized
INFO - 2020-10-28 07:17:46 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:46 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:46 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:46 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:46 --> Controller Class Initialized
INFO - 2020-10-28 07:17:47 --> Config Class Initialized
INFO - 2020-10-28 07:17:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:47 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:47 --> URI Class Initialized
INFO - 2020-10-28 07:17:47 --> Router Class Initialized
INFO - 2020-10-28 07:17:47 --> Output Class Initialized
INFO - 2020-10-28 07:17:47 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:47 --> Input Class Initialized
INFO - 2020-10-28 07:17:47 --> Language Class Initialized
INFO - 2020-10-28 07:17:48 --> Language Class Initialized
INFO - 2020-10-28 07:17:48 --> Config Class Initialized
INFO - 2020-10-28 07:17:48 --> Loader Class Initialized
INFO - 2020-10-28 07:17:48 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:48 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:48 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:48 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:48 --> Controller Class Initialized
INFO - 2020-10-28 07:17:50 --> Config Class Initialized
INFO - 2020-10-28 07:17:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:50 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:50 --> URI Class Initialized
INFO - 2020-10-28 07:17:50 --> Router Class Initialized
INFO - 2020-10-28 07:17:50 --> Output Class Initialized
INFO - 2020-10-28 07:17:50 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:50 --> Input Class Initialized
INFO - 2020-10-28 07:17:50 --> Language Class Initialized
INFO - 2020-10-28 07:17:50 --> Language Class Initialized
INFO - 2020-10-28 07:17:50 --> Config Class Initialized
INFO - 2020-10-28 07:17:50 --> Loader Class Initialized
INFO - 2020-10-28 07:17:50 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:50 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:50 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:50 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:50 --> Controller Class Initialized
INFO - 2020-10-28 07:17:50 --> Final output sent to browser
DEBUG - 2020-10-28 07:17:50 --> Total execution time: 0.3533
INFO - 2020-10-28 07:17:50 --> Config Class Initialized
INFO - 2020-10-28 07:17:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:50 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:50 --> URI Class Initialized
INFO - 2020-10-28 07:17:50 --> Router Class Initialized
INFO - 2020-10-28 07:17:50 --> Output Class Initialized
INFO - 2020-10-28 07:17:50 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:50 --> Input Class Initialized
INFO - 2020-10-28 07:17:50 --> Language Class Initialized
INFO - 2020-10-28 07:17:50 --> Language Class Initialized
INFO - 2020-10-28 07:17:50 --> Config Class Initialized
INFO - 2020-10-28 07:17:50 --> Loader Class Initialized
INFO - 2020-10-28 07:17:51 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:51 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:51 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:51 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:51 --> Controller Class Initialized
INFO - 2020-10-28 07:17:52 --> Config Class Initialized
INFO - 2020-10-28 07:17:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:52 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:52 --> URI Class Initialized
INFO - 2020-10-28 07:17:52 --> Router Class Initialized
INFO - 2020-10-28 07:17:52 --> Output Class Initialized
INFO - 2020-10-28 07:17:52 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:52 --> Input Class Initialized
INFO - 2020-10-28 07:17:52 --> Language Class Initialized
INFO - 2020-10-28 07:17:52 --> Language Class Initialized
INFO - 2020-10-28 07:17:52 --> Config Class Initialized
INFO - 2020-10-28 07:17:52 --> Loader Class Initialized
INFO - 2020-10-28 07:17:52 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:52 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:52 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:52 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:52 --> Controller Class Initialized
INFO - 2020-10-28 07:17:54 --> Config Class Initialized
INFO - 2020-10-28 07:17:54 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:54 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:54 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:54 --> URI Class Initialized
INFO - 2020-10-28 07:17:54 --> Router Class Initialized
INFO - 2020-10-28 07:17:54 --> Output Class Initialized
INFO - 2020-10-28 07:17:54 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:54 --> Input Class Initialized
INFO - 2020-10-28 07:17:54 --> Language Class Initialized
INFO - 2020-10-28 07:17:54 --> Language Class Initialized
INFO - 2020-10-28 07:17:55 --> Config Class Initialized
INFO - 2020-10-28 07:17:55 --> Loader Class Initialized
INFO - 2020-10-28 07:17:55 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:55 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:55 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:55 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:55 --> Controller Class Initialized
ERROR - 2020-10-28 07:17:55 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '1'
INFO - 2020-10-28 07:17:55 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 07:17:58 --> Config Class Initialized
INFO - 2020-10-28 07:17:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:17:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:17:58 --> Utf8 Class Initialized
INFO - 2020-10-28 07:17:58 --> URI Class Initialized
INFO - 2020-10-28 07:17:58 --> Router Class Initialized
INFO - 2020-10-28 07:17:58 --> Output Class Initialized
INFO - 2020-10-28 07:17:58 --> Security Class Initialized
DEBUG - 2020-10-28 07:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:17:58 --> Input Class Initialized
INFO - 2020-10-28 07:17:58 --> Language Class Initialized
INFO - 2020-10-28 07:17:58 --> Language Class Initialized
INFO - 2020-10-28 07:17:58 --> Config Class Initialized
INFO - 2020-10-28 07:17:58 --> Loader Class Initialized
INFO - 2020-10-28 07:17:58 --> Helper loaded: url_helper
INFO - 2020-10-28 07:17:58 --> Helper loaded: file_helper
INFO - 2020-10-28 07:17:58 --> Helper loaded: form_helper
INFO - 2020-10-28 07:17:58 --> Helper loaded: my_helper
INFO - 2020-10-28 07:17:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:17:58 --> Controller Class Initialized
ERROR - 2020-10-28 07:17:58 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_mapel` FOREIGN KEY (`id_mapel`) REFERENCES `m_mapel` (`id`)) - Invalid query: DELETE FROM m_mapel WHERE id = '1'
INFO - 2020-10-28 07:17:58 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 07:18:00 --> Config Class Initialized
INFO - 2020-10-28 07:18:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:00 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:00 --> URI Class Initialized
INFO - 2020-10-28 07:18:00 --> Router Class Initialized
INFO - 2020-10-28 07:18:00 --> Output Class Initialized
INFO - 2020-10-28 07:18:00 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:00 --> Input Class Initialized
INFO - 2020-10-28 07:18:00 --> Language Class Initialized
INFO - 2020-10-28 07:18:00 --> Language Class Initialized
INFO - 2020-10-28 07:18:00 --> Config Class Initialized
INFO - 2020-10-28 07:18:00 --> Loader Class Initialized
INFO - 2020-10-28 07:18:00 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:00 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:00 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:00 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:00 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:00 --> Controller Class Initialized
INFO - 2020-10-28 07:18:05 --> Config Class Initialized
INFO - 2020-10-28 07:18:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:05 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:05 --> URI Class Initialized
INFO - 2020-10-28 07:18:05 --> Router Class Initialized
INFO - 2020-10-28 07:18:05 --> Output Class Initialized
INFO - 2020-10-28 07:18:05 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:05 --> Input Class Initialized
INFO - 2020-10-28 07:18:05 --> Language Class Initialized
INFO - 2020-10-28 07:18:05 --> Language Class Initialized
INFO - 2020-10-28 07:18:05 --> Config Class Initialized
INFO - 2020-10-28 07:18:05 --> Loader Class Initialized
INFO - 2020-10-28 07:18:05 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:05 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:05 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:05 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:05 --> Controller Class Initialized
INFO - 2020-10-28 07:18:05 --> Final output sent to browser
DEBUG - 2020-10-28 07:18:05 --> Total execution time: 0.3265
INFO - 2020-10-28 07:18:05 --> Config Class Initialized
INFO - 2020-10-28 07:18:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:05 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:05 --> URI Class Initialized
INFO - 2020-10-28 07:18:05 --> Router Class Initialized
INFO - 2020-10-28 07:18:05 --> Output Class Initialized
INFO - 2020-10-28 07:18:05 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:05 --> Input Class Initialized
INFO - 2020-10-28 07:18:05 --> Language Class Initialized
INFO - 2020-10-28 07:18:05 --> Language Class Initialized
INFO - 2020-10-28 07:18:05 --> Config Class Initialized
INFO - 2020-10-28 07:18:05 --> Loader Class Initialized
INFO - 2020-10-28 07:18:06 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:06 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:06 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:06 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:06 --> Controller Class Initialized
INFO - 2020-10-28 07:18:09 --> Config Class Initialized
INFO - 2020-10-28 07:18:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:09 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:09 --> URI Class Initialized
INFO - 2020-10-28 07:18:09 --> Router Class Initialized
INFO - 2020-10-28 07:18:09 --> Output Class Initialized
INFO - 2020-10-28 07:18:09 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:09 --> Input Class Initialized
INFO - 2020-10-28 07:18:10 --> Language Class Initialized
INFO - 2020-10-28 07:18:10 --> Language Class Initialized
INFO - 2020-10-28 07:18:10 --> Config Class Initialized
INFO - 2020-10-28 07:18:10 --> Loader Class Initialized
INFO - 2020-10-28 07:18:10 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:10 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:10 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:10 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:10 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:10 --> Controller Class Initialized
INFO - 2020-10-28 07:18:18 --> Config Class Initialized
INFO - 2020-10-28 07:18:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:18 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:18 --> URI Class Initialized
INFO - 2020-10-28 07:18:18 --> Router Class Initialized
INFO - 2020-10-28 07:18:18 --> Output Class Initialized
INFO - 2020-10-28 07:18:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:18 --> Input Class Initialized
INFO - 2020-10-28 07:18:18 --> Language Class Initialized
INFO - 2020-10-28 07:18:18 --> Language Class Initialized
INFO - 2020-10-28 07:18:18 --> Config Class Initialized
INFO - 2020-10-28 07:18:18 --> Loader Class Initialized
INFO - 2020-10-28 07:18:18 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:18 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:18 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:18 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:18 --> Controller Class Initialized
DEBUG - 2020-10-28 07:18:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2020-10-28 07:18:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:18:18 --> Final output sent to browser
DEBUG - 2020-10-28 07:18:18 --> Total execution time: 0.3063
INFO - 2020-10-28 07:18:18 --> Config Class Initialized
INFO - 2020-10-28 07:18:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:18 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:18 --> URI Class Initialized
INFO - 2020-10-28 07:18:18 --> Router Class Initialized
INFO - 2020-10-28 07:18:18 --> Output Class Initialized
INFO - 2020-10-28 07:18:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:18 --> Input Class Initialized
INFO - 2020-10-28 07:18:18 --> Language Class Initialized
INFO - 2020-10-28 07:18:18 --> Language Class Initialized
INFO - 2020-10-28 07:18:18 --> Config Class Initialized
INFO - 2020-10-28 07:18:18 --> Loader Class Initialized
INFO - 2020-10-28 07:18:18 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:18 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:18 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:18 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:18 --> Controller Class Initialized
INFO - 2020-10-28 07:18:19 --> Config Class Initialized
INFO - 2020-10-28 07:18:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:19 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:19 --> URI Class Initialized
INFO - 2020-10-28 07:18:19 --> Router Class Initialized
INFO - 2020-10-28 07:18:19 --> Output Class Initialized
INFO - 2020-10-28 07:18:19 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:19 --> Input Class Initialized
INFO - 2020-10-28 07:18:19 --> Language Class Initialized
INFO - 2020-10-28 07:18:19 --> Language Class Initialized
INFO - 2020-10-28 07:18:19 --> Config Class Initialized
INFO - 2020-10-28 07:18:19 --> Loader Class Initialized
INFO - 2020-10-28 07:18:19 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:19 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:19 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:19 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:19 --> Controller Class Initialized
DEBUG - 2020-10-28 07:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 07:18:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:18:19 --> Final output sent to browser
DEBUG - 2020-10-28 07:18:19 --> Total execution time: 0.3012
INFO - 2020-10-28 07:18:20 --> Config Class Initialized
INFO - 2020-10-28 07:18:20 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:20 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:20 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:20 --> URI Class Initialized
INFO - 2020-10-28 07:18:20 --> Router Class Initialized
INFO - 2020-10-28 07:18:20 --> Output Class Initialized
INFO - 2020-10-28 07:18:20 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:20 --> Input Class Initialized
INFO - 2020-10-28 07:18:20 --> Language Class Initialized
INFO - 2020-10-28 07:18:20 --> Language Class Initialized
INFO - 2020-10-28 07:18:20 --> Config Class Initialized
INFO - 2020-10-28 07:18:20 --> Loader Class Initialized
INFO - 2020-10-28 07:18:20 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:20 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:20 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:20 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:20 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:20 --> Controller Class Initialized
INFO - 2020-10-28 07:18:22 --> Config Class Initialized
INFO - 2020-10-28 07:18:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:22 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:22 --> URI Class Initialized
INFO - 2020-10-28 07:18:22 --> Router Class Initialized
INFO - 2020-10-28 07:18:22 --> Output Class Initialized
INFO - 2020-10-28 07:18:22 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:22 --> Input Class Initialized
INFO - 2020-10-28 07:18:22 --> Language Class Initialized
INFO - 2020-10-28 07:18:22 --> Language Class Initialized
INFO - 2020-10-28 07:18:22 --> Config Class Initialized
INFO - 2020-10-28 07:18:22 --> Loader Class Initialized
INFO - 2020-10-28 07:18:22 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:22 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:22 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:22 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:22 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:22 --> Controller Class Initialized
DEBUG - 2020-10-28 07:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 07:18:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:18:22 --> Final output sent to browser
DEBUG - 2020-10-28 07:18:22 --> Total execution time: 0.3363
INFO - 2020-10-28 07:18:22 --> Config Class Initialized
INFO - 2020-10-28 07:18:22 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:22 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:22 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:22 --> URI Class Initialized
INFO - 2020-10-28 07:18:22 --> Router Class Initialized
INFO - 2020-10-28 07:18:22 --> Output Class Initialized
INFO - 2020-10-28 07:18:22 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:22 --> Input Class Initialized
INFO - 2020-10-28 07:18:22 --> Language Class Initialized
INFO - 2020-10-28 07:18:22 --> Language Class Initialized
INFO - 2020-10-28 07:18:22 --> Config Class Initialized
INFO - 2020-10-28 07:18:22 --> Loader Class Initialized
INFO - 2020-10-28 07:18:22 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:22 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:22 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:22 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:22 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:23 --> Controller Class Initialized
INFO - 2020-10-28 07:18:26 --> Config Class Initialized
INFO - 2020-10-28 07:18:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:26 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:26 --> URI Class Initialized
INFO - 2020-10-28 07:18:26 --> Router Class Initialized
INFO - 2020-10-28 07:18:26 --> Output Class Initialized
INFO - 2020-10-28 07:18:26 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:26 --> Input Class Initialized
INFO - 2020-10-28 07:18:26 --> Language Class Initialized
INFO - 2020-10-28 07:18:26 --> Language Class Initialized
INFO - 2020-10-28 07:18:26 --> Config Class Initialized
INFO - 2020-10-28 07:18:26 --> Loader Class Initialized
INFO - 2020-10-28 07:18:26 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:26 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:26 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:26 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:26 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:26 --> Controller Class Initialized
DEBUG - 2020-10-28 07:18:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-28 07:18:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:18:26 --> Final output sent to browser
DEBUG - 2020-10-28 07:18:26 --> Total execution time: 0.3051
INFO - 2020-10-28 07:18:26 --> Config Class Initialized
INFO - 2020-10-28 07:18:26 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:26 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:26 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:26 --> URI Class Initialized
INFO - 2020-10-28 07:18:26 --> Router Class Initialized
INFO - 2020-10-28 07:18:26 --> Output Class Initialized
INFO - 2020-10-28 07:18:26 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:26 --> Input Class Initialized
INFO - 2020-10-28 07:18:26 --> Language Class Initialized
INFO - 2020-10-28 07:18:27 --> Language Class Initialized
INFO - 2020-10-28 07:18:27 --> Config Class Initialized
INFO - 2020-10-28 07:18:27 --> Loader Class Initialized
INFO - 2020-10-28 07:18:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:27 --> Controller Class Initialized
INFO - 2020-10-28 07:18:27 --> Config Class Initialized
INFO - 2020-10-28 07:18:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:27 --> URI Class Initialized
INFO - 2020-10-28 07:18:27 --> Router Class Initialized
INFO - 2020-10-28 07:18:27 --> Output Class Initialized
INFO - 2020-10-28 07:18:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:27 --> Input Class Initialized
INFO - 2020-10-28 07:18:27 --> Language Class Initialized
INFO - 2020-10-28 07:18:27 --> Language Class Initialized
INFO - 2020-10-28 07:18:27 --> Config Class Initialized
INFO - 2020-10-28 07:18:27 --> Loader Class Initialized
INFO - 2020-10-28 07:18:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:27 --> Controller Class Initialized
DEBUG - 2020-10-28 07:18:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-28 07:18:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:18:27 --> Final output sent to browser
DEBUG - 2020-10-28 07:18:27 --> Total execution time: 0.3161
INFO - 2020-10-28 07:18:27 --> Config Class Initialized
INFO - 2020-10-28 07:18:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:27 --> URI Class Initialized
INFO - 2020-10-28 07:18:27 --> Router Class Initialized
INFO - 2020-10-28 07:18:27 --> Output Class Initialized
INFO - 2020-10-28 07:18:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:27 --> Input Class Initialized
INFO - 2020-10-28 07:18:27 --> Language Class Initialized
INFO - 2020-10-28 07:18:27 --> Language Class Initialized
INFO - 2020-10-28 07:18:28 --> Config Class Initialized
INFO - 2020-10-28 07:18:28 --> Loader Class Initialized
INFO - 2020-10-28 07:18:28 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:28 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:28 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:28 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:28 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:28 --> Controller Class Initialized
INFO - 2020-10-28 07:18:32 --> Config Class Initialized
INFO - 2020-10-28 07:18:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:18:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:18:32 --> Utf8 Class Initialized
INFO - 2020-10-28 07:18:32 --> URI Class Initialized
INFO - 2020-10-28 07:18:32 --> Router Class Initialized
INFO - 2020-10-28 07:18:32 --> Output Class Initialized
INFO - 2020-10-28 07:18:32 --> Security Class Initialized
DEBUG - 2020-10-28 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:18:32 --> Input Class Initialized
INFO - 2020-10-28 07:18:32 --> Language Class Initialized
INFO - 2020-10-28 07:18:32 --> Language Class Initialized
INFO - 2020-10-28 07:18:32 --> Config Class Initialized
INFO - 2020-10-28 07:18:32 --> Loader Class Initialized
INFO - 2020-10-28 07:18:32 --> Helper loaded: url_helper
INFO - 2020-10-28 07:18:32 --> Helper loaded: file_helper
INFO - 2020-10-28 07:18:32 --> Helper loaded: form_helper
INFO - 2020-10-28 07:18:32 --> Helper loaded: my_helper
INFO - 2020-10-28 07:18:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:18:32 --> Controller Class Initialized
DEBUG - 2020-10-28 07:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:18:32 --> Final output sent to browser
DEBUG - 2020-10-28 07:18:32 --> Total execution time: 0.3134
INFO - 2020-10-28 07:23:24 --> Config Class Initialized
INFO - 2020-10-28 07:23:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:24 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:24 --> URI Class Initialized
INFO - 2020-10-28 07:23:25 --> Router Class Initialized
INFO - 2020-10-28 07:23:25 --> Output Class Initialized
INFO - 2020-10-28 07:23:25 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:25 --> Input Class Initialized
INFO - 2020-10-28 07:23:25 --> Language Class Initialized
INFO - 2020-10-28 07:23:25 --> Language Class Initialized
INFO - 2020-10-28 07:23:25 --> Config Class Initialized
INFO - 2020-10-28 07:23:25 --> Loader Class Initialized
INFO - 2020-10-28 07:23:25 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:25 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:25 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:25 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:25 --> Controller Class Initialized
DEBUG - 2020-10-28 07:23:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 07:23:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:23:25 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:25 --> Total execution time: 0.3710
INFO - 2020-10-28 07:23:25 --> Config Class Initialized
INFO - 2020-10-28 07:23:25 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:25 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:25 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:25 --> URI Class Initialized
INFO - 2020-10-28 07:23:25 --> Router Class Initialized
INFO - 2020-10-28 07:23:25 --> Output Class Initialized
INFO - 2020-10-28 07:23:25 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:25 --> Input Class Initialized
INFO - 2020-10-28 07:23:25 --> Language Class Initialized
INFO - 2020-10-28 07:23:25 --> Language Class Initialized
INFO - 2020-10-28 07:23:25 --> Config Class Initialized
INFO - 2020-10-28 07:23:25 --> Loader Class Initialized
INFO - 2020-10-28 07:23:25 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:25 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:25 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:25 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:25 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:25 --> Controller Class Initialized
INFO - 2020-10-28 07:23:29 --> Config Class Initialized
INFO - 2020-10-28 07:23:29 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:29 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:29 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:29 --> URI Class Initialized
INFO - 2020-10-28 07:23:29 --> Router Class Initialized
INFO - 2020-10-28 07:23:29 --> Output Class Initialized
INFO - 2020-10-28 07:23:29 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:29 --> Input Class Initialized
INFO - 2020-10-28 07:23:29 --> Language Class Initialized
INFO - 2020-10-28 07:23:29 --> Language Class Initialized
INFO - 2020-10-28 07:23:29 --> Config Class Initialized
INFO - 2020-10-28 07:23:29 --> Loader Class Initialized
INFO - 2020-10-28 07:23:29 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:29 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:29 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:29 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:29 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:29 --> Controller Class Initialized
ERROR - 2020-10-28 07:23:29 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`db_nilai`.`t_guru_mapel`, CONSTRAINT `FK_t_guru_mapel_m_kelas` FOREIGN KEY (`id_kelas`) REFERENCES `m_kelas` (`id`)) - Invalid query: DELETE FROM m_kelas WHERE id = '10'
INFO - 2020-10-28 07:23:29 --> Language file loaded: language/english/db_lang.php
INFO - 2020-10-28 07:23:33 --> Config Class Initialized
INFO - 2020-10-28 07:23:33 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:33 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:33 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:33 --> URI Class Initialized
INFO - 2020-10-28 07:23:33 --> Router Class Initialized
INFO - 2020-10-28 07:23:33 --> Output Class Initialized
INFO - 2020-10-28 07:23:33 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:33 --> Input Class Initialized
INFO - 2020-10-28 07:23:33 --> Language Class Initialized
INFO - 2020-10-28 07:23:33 --> Language Class Initialized
INFO - 2020-10-28 07:23:33 --> Config Class Initialized
INFO - 2020-10-28 07:23:33 --> Loader Class Initialized
INFO - 2020-10-28 07:23:33 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:33 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:33 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:33 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:33 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:33 --> Controller Class Initialized
DEBUG - 2020-10-28 07:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-28 07:23:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:23:33 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:33 --> Total execution time: 0.3211
INFO - 2020-10-28 07:23:33 --> Config Class Initialized
INFO - 2020-10-28 07:23:33 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:33 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:33 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:33 --> URI Class Initialized
INFO - 2020-10-28 07:23:33 --> Router Class Initialized
INFO - 2020-10-28 07:23:33 --> Output Class Initialized
INFO - 2020-10-28 07:23:33 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:33 --> Input Class Initialized
INFO - 2020-10-28 07:23:33 --> Language Class Initialized
INFO - 2020-10-28 07:23:33 --> Language Class Initialized
INFO - 2020-10-28 07:23:33 --> Config Class Initialized
INFO - 2020-10-28 07:23:33 --> Loader Class Initialized
INFO - 2020-10-28 07:23:33 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:33 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:33 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:33 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:33 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:33 --> Controller Class Initialized
INFO - 2020-10-28 07:23:38 --> Config Class Initialized
INFO - 2020-10-28 07:23:38 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:38 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:38 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:38 --> URI Class Initialized
INFO - 2020-10-28 07:23:38 --> Router Class Initialized
INFO - 2020-10-28 07:23:38 --> Output Class Initialized
INFO - 2020-10-28 07:23:38 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:38 --> Input Class Initialized
INFO - 2020-10-28 07:23:38 --> Language Class Initialized
INFO - 2020-10-28 07:23:38 --> Language Class Initialized
INFO - 2020-10-28 07:23:38 --> Config Class Initialized
INFO - 2020-10-28 07:23:38 --> Loader Class Initialized
INFO - 2020-10-28 07:23:38 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:38 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:38 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:38 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:38 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:38 --> Controller Class Initialized
INFO - 2020-10-28 07:23:38 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:38 --> Total execution time: 0.3500
INFO - 2020-10-28 07:23:38 --> Config Class Initialized
INFO - 2020-10-28 07:23:38 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:38 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:38 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:38 --> URI Class Initialized
INFO - 2020-10-28 07:23:38 --> Router Class Initialized
INFO - 2020-10-28 07:23:38 --> Output Class Initialized
INFO - 2020-10-28 07:23:38 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:38 --> Input Class Initialized
INFO - 2020-10-28 07:23:38 --> Language Class Initialized
INFO - 2020-10-28 07:23:38 --> Language Class Initialized
INFO - 2020-10-28 07:23:38 --> Config Class Initialized
INFO - 2020-10-28 07:23:38 --> Loader Class Initialized
INFO - 2020-10-28 07:23:38 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:38 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:38 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:38 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:38 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:38 --> Controller Class Initialized
INFO - 2020-10-28 07:23:41 --> Config Class Initialized
INFO - 2020-10-28 07:23:41 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:41 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:41 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:41 --> URI Class Initialized
INFO - 2020-10-28 07:23:41 --> Router Class Initialized
INFO - 2020-10-28 07:23:41 --> Output Class Initialized
INFO - 2020-10-28 07:23:41 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:41 --> Input Class Initialized
INFO - 2020-10-28 07:23:41 --> Language Class Initialized
INFO - 2020-10-28 07:23:41 --> Language Class Initialized
INFO - 2020-10-28 07:23:41 --> Config Class Initialized
INFO - 2020-10-28 07:23:41 --> Loader Class Initialized
INFO - 2020-10-28 07:23:41 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:41 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:41 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:41 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:41 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:41 --> Controller Class Initialized
INFO - 2020-10-28 07:23:41 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:41 --> Total execution time: 0.3501
INFO - 2020-10-28 07:23:41 --> Config Class Initialized
INFO - 2020-10-28 07:23:41 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:41 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:41 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:42 --> URI Class Initialized
INFO - 2020-10-28 07:23:42 --> Router Class Initialized
INFO - 2020-10-28 07:23:42 --> Output Class Initialized
INFO - 2020-10-28 07:23:42 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:42 --> Input Class Initialized
INFO - 2020-10-28 07:23:42 --> Language Class Initialized
INFO - 2020-10-28 07:23:42 --> Language Class Initialized
INFO - 2020-10-28 07:23:42 --> Config Class Initialized
INFO - 2020-10-28 07:23:42 --> Loader Class Initialized
INFO - 2020-10-28 07:23:42 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:42 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:42 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:42 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:42 --> Controller Class Initialized
INFO - 2020-10-28 07:23:43 --> Config Class Initialized
INFO - 2020-10-28 07:23:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:43 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:43 --> URI Class Initialized
INFO - 2020-10-28 07:23:43 --> Router Class Initialized
INFO - 2020-10-28 07:23:43 --> Output Class Initialized
INFO - 2020-10-28 07:23:43 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:43 --> Input Class Initialized
INFO - 2020-10-28 07:23:43 --> Language Class Initialized
INFO - 2020-10-28 07:23:43 --> Language Class Initialized
INFO - 2020-10-28 07:23:43 --> Config Class Initialized
INFO - 2020-10-28 07:23:43 --> Loader Class Initialized
INFO - 2020-10-28 07:23:43 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:43 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:43 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:44 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:44 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:44 --> Controller Class Initialized
INFO - 2020-10-28 07:23:44 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:44 --> Total execution time: 0.3617
INFO - 2020-10-28 07:23:44 --> Config Class Initialized
INFO - 2020-10-28 07:23:44 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:44 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:44 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:44 --> URI Class Initialized
INFO - 2020-10-28 07:23:44 --> Router Class Initialized
INFO - 2020-10-28 07:23:44 --> Output Class Initialized
INFO - 2020-10-28 07:23:44 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:44 --> Input Class Initialized
INFO - 2020-10-28 07:23:44 --> Language Class Initialized
INFO - 2020-10-28 07:23:44 --> Language Class Initialized
INFO - 2020-10-28 07:23:44 --> Config Class Initialized
INFO - 2020-10-28 07:23:44 --> Loader Class Initialized
INFO - 2020-10-28 07:23:44 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:44 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:44 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:44 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:44 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:44 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:44 --> Controller Class Initialized
INFO - 2020-10-28 07:23:45 --> Config Class Initialized
INFO - 2020-10-28 07:23:45 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:45 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:45 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:45 --> URI Class Initialized
INFO - 2020-10-28 07:23:45 --> Router Class Initialized
INFO - 2020-10-28 07:23:45 --> Output Class Initialized
INFO - 2020-10-28 07:23:45 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:45 --> Input Class Initialized
INFO - 2020-10-28 07:23:46 --> Language Class Initialized
INFO - 2020-10-28 07:23:46 --> Language Class Initialized
INFO - 2020-10-28 07:23:46 --> Config Class Initialized
INFO - 2020-10-28 07:23:46 --> Loader Class Initialized
INFO - 2020-10-28 07:23:46 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:46 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:46 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:46 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:46 --> Controller Class Initialized
INFO - 2020-10-28 07:23:46 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:46 --> Total execution time: 0.3453
INFO - 2020-10-28 07:23:46 --> Config Class Initialized
INFO - 2020-10-28 07:23:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:46 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:46 --> URI Class Initialized
INFO - 2020-10-28 07:23:46 --> Router Class Initialized
INFO - 2020-10-28 07:23:46 --> Output Class Initialized
INFO - 2020-10-28 07:23:46 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:46 --> Input Class Initialized
INFO - 2020-10-28 07:23:46 --> Language Class Initialized
INFO - 2020-10-28 07:23:46 --> Language Class Initialized
INFO - 2020-10-28 07:23:46 --> Config Class Initialized
INFO - 2020-10-28 07:23:46 --> Loader Class Initialized
INFO - 2020-10-28 07:23:46 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:46 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:46 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:46 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:46 --> Controller Class Initialized
INFO - 2020-10-28 07:23:47 --> Config Class Initialized
INFO - 2020-10-28 07:23:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:47 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:47 --> URI Class Initialized
INFO - 2020-10-28 07:23:47 --> Router Class Initialized
INFO - 2020-10-28 07:23:47 --> Output Class Initialized
INFO - 2020-10-28 07:23:48 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:48 --> Input Class Initialized
INFO - 2020-10-28 07:23:48 --> Language Class Initialized
INFO - 2020-10-28 07:23:48 --> Language Class Initialized
INFO - 2020-10-28 07:23:48 --> Config Class Initialized
INFO - 2020-10-28 07:23:48 --> Loader Class Initialized
INFO - 2020-10-28 07:23:48 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:48 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:48 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:48 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:48 --> Controller Class Initialized
INFO - 2020-10-28 07:23:48 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:48 --> Total execution time: 0.3434
INFO - 2020-10-28 07:23:48 --> Config Class Initialized
INFO - 2020-10-28 07:23:48 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:48 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:48 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:48 --> URI Class Initialized
INFO - 2020-10-28 07:23:48 --> Router Class Initialized
INFO - 2020-10-28 07:23:48 --> Output Class Initialized
INFO - 2020-10-28 07:23:48 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:48 --> Input Class Initialized
INFO - 2020-10-28 07:23:48 --> Language Class Initialized
INFO - 2020-10-28 07:23:48 --> Language Class Initialized
INFO - 2020-10-28 07:23:48 --> Config Class Initialized
INFO - 2020-10-28 07:23:48 --> Loader Class Initialized
INFO - 2020-10-28 07:23:48 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:48 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:48 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:48 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:48 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:48 --> Controller Class Initialized
INFO - 2020-10-28 07:23:50 --> Config Class Initialized
INFO - 2020-10-28 07:23:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:50 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:50 --> URI Class Initialized
INFO - 2020-10-28 07:23:50 --> Router Class Initialized
INFO - 2020-10-28 07:23:50 --> Output Class Initialized
INFO - 2020-10-28 07:23:50 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:50 --> Input Class Initialized
INFO - 2020-10-28 07:23:50 --> Language Class Initialized
INFO - 2020-10-28 07:23:50 --> Language Class Initialized
INFO - 2020-10-28 07:23:50 --> Config Class Initialized
INFO - 2020-10-28 07:23:50 --> Loader Class Initialized
INFO - 2020-10-28 07:23:50 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:50 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:50 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:50 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:50 --> Controller Class Initialized
INFO - 2020-10-28 07:23:50 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:50 --> Total execution time: 0.3504
INFO - 2020-10-28 07:23:50 --> Config Class Initialized
INFO - 2020-10-28 07:23:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:50 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:50 --> URI Class Initialized
INFO - 2020-10-28 07:23:50 --> Router Class Initialized
INFO - 2020-10-28 07:23:50 --> Output Class Initialized
INFO - 2020-10-28 07:23:50 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:50 --> Input Class Initialized
INFO - 2020-10-28 07:23:51 --> Language Class Initialized
INFO - 2020-10-28 07:23:51 --> Language Class Initialized
INFO - 2020-10-28 07:23:51 --> Config Class Initialized
INFO - 2020-10-28 07:23:51 --> Loader Class Initialized
INFO - 2020-10-28 07:23:51 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:51 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:51 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:51 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:51 --> Controller Class Initialized
INFO - 2020-10-28 07:23:51 --> Config Class Initialized
INFO - 2020-10-28 07:23:51 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:51 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:51 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:51 --> URI Class Initialized
INFO - 2020-10-28 07:23:51 --> Router Class Initialized
INFO - 2020-10-28 07:23:51 --> Output Class Initialized
INFO - 2020-10-28 07:23:51 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:51 --> Input Class Initialized
INFO - 2020-10-28 07:23:51 --> Language Class Initialized
INFO - 2020-10-28 07:23:51 --> Language Class Initialized
INFO - 2020-10-28 07:23:51 --> Config Class Initialized
INFO - 2020-10-28 07:23:51 --> Loader Class Initialized
INFO - 2020-10-28 07:23:51 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:51 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:51 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:51 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:52 --> Controller Class Initialized
DEBUG - 2020-10-28 07:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 07:23:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:23:52 --> Final output sent to browser
DEBUG - 2020-10-28 07:23:52 --> Total execution time: 0.3695
INFO - 2020-10-28 07:23:52 --> Config Class Initialized
INFO - 2020-10-28 07:23:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:23:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:23:52 --> Utf8 Class Initialized
INFO - 2020-10-28 07:23:52 --> URI Class Initialized
INFO - 2020-10-28 07:23:52 --> Router Class Initialized
INFO - 2020-10-28 07:23:52 --> Output Class Initialized
INFO - 2020-10-28 07:23:52 --> Security Class Initialized
DEBUG - 2020-10-28 07:23:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:23:52 --> Input Class Initialized
INFO - 2020-10-28 07:23:52 --> Language Class Initialized
INFO - 2020-10-28 07:23:52 --> Language Class Initialized
INFO - 2020-10-28 07:23:52 --> Config Class Initialized
INFO - 2020-10-28 07:23:52 --> Loader Class Initialized
INFO - 2020-10-28 07:23:52 --> Helper loaded: url_helper
INFO - 2020-10-28 07:23:52 --> Helper loaded: file_helper
INFO - 2020-10-28 07:23:52 --> Helper loaded: form_helper
INFO - 2020-10-28 07:23:52 --> Helper loaded: my_helper
INFO - 2020-10-28 07:23:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:23:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:23:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:23:52 --> Controller Class Initialized
INFO - 2020-10-28 07:24:23 --> Config Class Initialized
INFO - 2020-10-28 07:24:23 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:24:23 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:24:23 --> Utf8 Class Initialized
INFO - 2020-10-28 07:24:23 --> URI Class Initialized
INFO - 2020-10-28 07:24:23 --> Router Class Initialized
INFO - 2020-10-28 07:24:23 --> Output Class Initialized
INFO - 2020-10-28 07:24:23 --> Security Class Initialized
DEBUG - 2020-10-28 07:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:24:23 --> Input Class Initialized
INFO - 2020-10-28 07:24:23 --> Language Class Initialized
INFO - 2020-10-28 07:24:23 --> Language Class Initialized
INFO - 2020-10-28 07:24:23 --> Config Class Initialized
INFO - 2020-10-28 07:24:23 --> Loader Class Initialized
INFO - 2020-10-28 07:24:23 --> Helper loaded: url_helper
INFO - 2020-10-28 07:24:23 --> Helper loaded: file_helper
INFO - 2020-10-28 07:24:23 --> Helper loaded: form_helper
INFO - 2020-10-28 07:24:23 --> Helper loaded: my_helper
INFO - 2020-10-28 07:24:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:24:24 --> Controller Class Initialized
DEBUG - 2020-10-28 07:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 07:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:24:24 --> Final output sent to browser
DEBUG - 2020-10-28 07:24:24 --> Total execution time: 0.3257
INFO - 2020-10-28 07:24:24 --> Config Class Initialized
INFO - 2020-10-28 07:24:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:24:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:24:24 --> Utf8 Class Initialized
INFO - 2020-10-28 07:24:24 --> URI Class Initialized
INFO - 2020-10-28 07:24:24 --> Router Class Initialized
INFO - 2020-10-28 07:24:24 --> Output Class Initialized
INFO - 2020-10-28 07:24:24 --> Security Class Initialized
DEBUG - 2020-10-28 07:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:24:24 --> Input Class Initialized
INFO - 2020-10-28 07:24:24 --> Language Class Initialized
INFO - 2020-10-28 07:24:24 --> Language Class Initialized
INFO - 2020-10-28 07:24:24 --> Config Class Initialized
INFO - 2020-10-28 07:24:24 --> Loader Class Initialized
INFO - 2020-10-28 07:24:24 --> Helper loaded: url_helper
INFO - 2020-10-28 07:24:24 --> Helper loaded: file_helper
INFO - 2020-10-28 07:24:24 --> Helper loaded: form_helper
INFO - 2020-10-28 07:24:24 --> Helper loaded: my_helper
INFO - 2020-10-28 07:24:24 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:24:24 --> Controller Class Initialized
INFO - 2020-10-28 07:24:46 --> Config Class Initialized
INFO - 2020-10-28 07:24:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:24:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:24:46 --> Utf8 Class Initialized
INFO - 2020-10-28 07:24:46 --> URI Class Initialized
INFO - 2020-10-28 07:24:46 --> Router Class Initialized
INFO - 2020-10-28 07:24:46 --> Output Class Initialized
INFO - 2020-10-28 07:24:46 --> Security Class Initialized
DEBUG - 2020-10-28 07:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:24:46 --> Input Class Initialized
INFO - 2020-10-28 07:24:46 --> Language Class Initialized
INFO - 2020-10-28 07:24:46 --> Language Class Initialized
INFO - 2020-10-28 07:24:46 --> Config Class Initialized
INFO - 2020-10-28 07:24:46 --> Loader Class Initialized
INFO - 2020-10-28 07:24:46 --> Helper loaded: url_helper
INFO - 2020-10-28 07:24:46 --> Helper loaded: file_helper
INFO - 2020-10-28 07:24:46 --> Helper loaded: form_helper
INFO - 2020-10-28 07:24:46 --> Helper loaded: my_helper
INFO - 2020-10-28 07:24:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:24:46 --> Controller Class Initialized
DEBUG - 2020-10-28 07:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 07:24:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:24:46 --> Final output sent to browser
DEBUG - 2020-10-28 07:24:46 --> Total execution time: 0.3318
INFO - 2020-10-28 07:24:46 --> Config Class Initialized
INFO - 2020-10-28 07:24:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:24:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:24:46 --> Utf8 Class Initialized
INFO - 2020-10-28 07:24:46 --> URI Class Initialized
INFO - 2020-10-28 07:24:46 --> Router Class Initialized
INFO - 2020-10-28 07:24:46 --> Output Class Initialized
INFO - 2020-10-28 07:24:46 --> Security Class Initialized
DEBUG - 2020-10-28 07:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:24:46 --> Input Class Initialized
INFO - 2020-10-28 07:24:46 --> Language Class Initialized
INFO - 2020-10-28 07:24:46 --> Language Class Initialized
INFO - 2020-10-28 07:24:46 --> Config Class Initialized
INFO - 2020-10-28 07:24:46 --> Loader Class Initialized
INFO - 2020-10-28 07:24:46 --> Helper loaded: url_helper
INFO - 2020-10-28 07:24:46 --> Helper loaded: file_helper
INFO - 2020-10-28 07:24:46 --> Helper loaded: form_helper
INFO - 2020-10-28 07:24:46 --> Helper loaded: my_helper
INFO - 2020-10-28 07:24:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:24:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:24:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:24:46 --> Controller Class Initialized
INFO - 2020-10-28 07:24:52 --> Config Class Initialized
INFO - 2020-10-28 07:24:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:24:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:24:52 --> Utf8 Class Initialized
INFO - 2020-10-28 07:24:52 --> URI Class Initialized
INFO - 2020-10-28 07:24:52 --> Router Class Initialized
INFO - 2020-10-28 07:24:52 --> Output Class Initialized
INFO - 2020-10-28 07:24:52 --> Security Class Initialized
DEBUG - 2020-10-28 07:24:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:24:52 --> Input Class Initialized
INFO - 2020-10-28 07:24:53 --> Language Class Initialized
INFO - 2020-10-28 07:24:53 --> Language Class Initialized
INFO - 2020-10-28 07:24:53 --> Config Class Initialized
INFO - 2020-10-28 07:24:53 --> Loader Class Initialized
INFO - 2020-10-28 07:24:53 --> Helper loaded: url_helper
INFO - 2020-10-28 07:24:53 --> Helper loaded: file_helper
INFO - 2020-10-28 07:24:53 --> Helper loaded: form_helper
INFO - 2020-10-28 07:24:53 --> Helper loaded: my_helper
INFO - 2020-10-28 07:24:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:24:53 --> Controller Class Initialized
DEBUG - 2020-10-28 07:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 07:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:24:53 --> Final output sent to browser
DEBUG - 2020-10-28 07:24:53 --> Total execution time: 0.3286
INFO - 2020-10-28 07:24:53 --> Config Class Initialized
INFO - 2020-10-28 07:24:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:24:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:24:53 --> Utf8 Class Initialized
INFO - 2020-10-28 07:24:53 --> URI Class Initialized
INFO - 2020-10-28 07:24:53 --> Router Class Initialized
INFO - 2020-10-28 07:24:53 --> Output Class Initialized
INFO - 2020-10-28 07:24:53 --> Security Class Initialized
DEBUG - 2020-10-28 07:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:24:53 --> Input Class Initialized
INFO - 2020-10-28 07:24:53 --> Language Class Initialized
INFO - 2020-10-28 07:24:53 --> Language Class Initialized
INFO - 2020-10-28 07:24:53 --> Config Class Initialized
INFO - 2020-10-28 07:24:53 --> Loader Class Initialized
INFO - 2020-10-28 07:24:53 --> Helper loaded: url_helper
INFO - 2020-10-28 07:24:53 --> Helper loaded: file_helper
INFO - 2020-10-28 07:24:53 --> Helper loaded: form_helper
INFO - 2020-10-28 07:24:53 --> Helper loaded: my_helper
INFO - 2020-10-28 07:24:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:24:53 --> Controller Class Initialized
INFO - 2020-10-28 07:25:03 --> Config Class Initialized
INFO - 2020-10-28 07:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:03 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:03 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:03 --> URI Class Initialized
INFO - 2020-10-28 07:25:03 --> Router Class Initialized
INFO - 2020-10-28 07:25:03 --> Output Class Initialized
INFO - 2020-10-28 07:25:03 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:03 --> Input Class Initialized
INFO - 2020-10-28 07:25:03 --> Language Class Initialized
INFO - 2020-10-28 07:25:03 --> Language Class Initialized
INFO - 2020-10-28 07:25:03 --> Config Class Initialized
INFO - 2020-10-28 07:25:03 --> Loader Class Initialized
INFO - 2020-10-28 07:25:03 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:03 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:03 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:03 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:03 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:03 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:03 --> Controller Class Initialized
DEBUG - 2020-10-28 07:25:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 07:25:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:25:03 --> Final output sent to browser
DEBUG - 2020-10-28 07:25:03 --> Total execution time: 0.3166
INFO - 2020-10-28 07:25:03 --> Config Class Initialized
INFO - 2020-10-28 07:25:03 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:04 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:04 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:04 --> URI Class Initialized
INFO - 2020-10-28 07:25:04 --> Router Class Initialized
INFO - 2020-10-28 07:25:04 --> Output Class Initialized
INFO - 2020-10-28 07:25:04 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:04 --> Input Class Initialized
INFO - 2020-10-28 07:25:04 --> Language Class Initialized
INFO - 2020-10-28 07:25:04 --> Language Class Initialized
INFO - 2020-10-28 07:25:04 --> Config Class Initialized
INFO - 2020-10-28 07:25:04 --> Loader Class Initialized
INFO - 2020-10-28 07:25:04 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:04 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:04 --> Controller Class Initialized
INFO - 2020-10-28 07:25:04 --> Config Class Initialized
INFO - 2020-10-28 07:25:04 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:04 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:04 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:04 --> URI Class Initialized
INFO - 2020-10-28 07:25:04 --> Router Class Initialized
INFO - 2020-10-28 07:25:04 --> Output Class Initialized
INFO - 2020-10-28 07:25:04 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:04 --> Input Class Initialized
INFO - 2020-10-28 07:25:04 --> Language Class Initialized
INFO - 2020-10-28 07:25:04 --> Language Class Initialized
INFO - 2020-10-28 07:25:04 --> Config Class Initialized
INFO - 2020-10-28 07:25:04 --> Loader Class Initialized
INFO - 2020-10-28 07:25:04 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:04 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:04 --> Controller Class Initialized
DEBUG - 2020-10-28 07:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 07:25:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:25:04 --> Final output sent to browser
DEBUG - 2020-10-28 07:25:04 --> Total execution time: 0.3132
INFO - 2020-10-28 07:25:04 --> Config Class Initialized
INFO - 2020-10-28 07:25:04 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:04 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:04 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:04 --> URI Class Initialized
INFO - 2020-10-28 07:25:04 --> Router Class Initialized
INFO - 2020-10-28 07:25:04 --> Output Class Initialized
INFO - 2020-10-28 07:25:04 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:04 --> Input Class Initialized
INFO - 2020-10-28 07:25:04 --> Language Class Initialized
INFO - 2020-10-28 07:25:04 --> Language Class Initialized
INFO - 2020-10-28 07:25:04 --> Config Class Initialized
INFO - 2020-10-28 07:25:04 --> Loader Class Initialized
INFO - 2020-10-28 07:25:04 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:04 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:04 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:04 --> Controller Class Initialized
INFO - 2020-10-28 07:25:06 --> Config Class Initialized
INFO - 2020-10-28 07:25:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:06 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:06 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:06 --> URI Class Initialized
INFO - 2020-10-28 07:25:06 --> Router Class Initialized
INFO - 2020-10-28 07:25:06 --> Output Class Initialized
INFO - 2020-10-28 07:25:06 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:06 --> Input Class Initialized
INFO - 2020-10-28 07:25:06 --> Language Class Initialized
INFO - 2020-10-28 07:25:06 --> Language Class Initialized
INFO - 2020-10-28 07:25:06 --> Config Class Initialized
INFO - 2020-10-28 07:25:06 --> Loader Class Initialized
INFO - 2020-10-28 07:25:06 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:06 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:06 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:06 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:06 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:06 --> Controller Class Initialized
DEBUG - 2020-10-28 07:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_ekstra/views/list.php
DEBUG - 2020-10-28 07:25:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:25:06 --> Final output sent to browser
DEBUG - 2020-10-28 07:25:06 --> Total execution time: 0.3183
INFO - 2020-10-28 07:25:06 --> Config Class Initialized
INFO - 2020-10-28 07:25:06 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:07 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:07 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:07 --> URI Class Initialized
INFO - 2020-10-28 07:25:07 --> Router Class Initialized
INFO - 2020-10-28 07:25:07 --> Output Class Initialized
INFO - 2020-10-28 07:25:07 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:07 --> Input Class Initialized
INFO - 2020-10-28 07:25:07 --> Language Class Initialized
INFO - 2020-10-28 07:25:07 --> Language Class Initialized
INFO - 2020-10-28 07:25:07 --> Config Class Initialized
INFO - 2020-10-28 07:25:07 --> Loader Class Initialized
INFO - 2020-10-28 07:25:07 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:07 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:07 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:07 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:07 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:07 --> Controller Class Initialized
INFO - 2020-10-28 07:25:14 --> Config Class Initialized
INFO - 2020-10-28 07:25:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:14 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:14 --> URI Class Initialized
INFO - 2020-10-28 07:25:14 --> Router Class Initialized
INFO - 2020-10-28 07:25:14 --> Output Class Initialized
INFO - 2020-10-28 07:25:14 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:14 --> Input Class Initialized
INFO - 2020-10-28 07:25:14 --> Language Class Initialized
INFO - 2020-10-28 07:25:14 --> Language Class Initialized
INFO - 2020-10-28 07:25:14 --> Config Class Initialized
INFO - 2020-10-28 07:25:14 --> Loader Class Initialized
INFO - 2020-10-28 07:25:14 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:14 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:14 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:14 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:14 --> Controller Class Initialized
INFO - 2020-10-28 07:25:14 --> Final output sent to browser
DEBUG - 2020-10-28 07:25:14 --> Total execution time: 0.4021
INFO - 2020-10-28 07:25:14 --> Config Class Initialized
INFO - 2020-10-28 07:25:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:14 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:14 --> URI Class Initialized
INFO - 2020-10-28 07:25:14 --> Router Class Initialized
INFO - 2020-10-28 07:25:14 --> Output Class Initialized
INFO - 2020-10-28 07:25:14 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:14 --> Input Class Initialized
INFO - 2020-10-28 07:25:14 --> Language Class Initialized
INFO - 2020-10-28 07:25:14 --> Language Class Initialized
INFO - 2020-10-28 07:25:14 --> Config Class Initialized
INFO - 2020-10-28 07:25:14 --> Loader Class Initialized
INFO - 2020-10-28 07:25:14 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:14 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:14 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:14 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:14 --> Controller Class Initialized
INFO - 2020-10-28 07:25:58 --> Config Class Initialized
INFO - 2020-10-28 07:25:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:58 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:58 --> URI Class Initialized
INFO - 2020-10-28 07:25:58 --> Router Class Initialized
INFO - 2020-10-28 07:25:58 --> Output Class Initialized
INFO - 2020-10-28 07:25:58 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:58 --> Input Class Initialized
INFO - 2020-10-28 07:25:58 --> Language Class Initialized
INFO - 2020-10-28 07:25:58 --> Language Class Initialized
INFO - 2020-10-28 07:25:58 --> Config Class Initialized
INFO - 2020-10-28 07:25:58 --> Loader Class Initialized
INFO - 2020-10-28 07:25:58 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:58 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:58 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:58 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:58 --> Controller Class Initialized
DEBUG - 2020-10-28 07:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 07:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:25:58 --> Final output sent to browser
DEBUG - 2020-10-28 07:25:58 --> Total execution time: 0.3228
INFO - 2020-10-28 07:25:58 --> Config Class Initialized
INFO - 2020-10-28 07:25:58 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:58 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:58 --> URI Class Initialized
INFO - 2020-10-28 07:25:58 --> Router Class Initialized
INFO - 2020-10-28 07:25:58 --> Output Class Initialized
INFO - 2020-10-28 07:25:58 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:58 --> Input Class Initialized
INFO - 2020-10-28 07:25:58 --> Language Class Initialized
INFO - 2020-10-28 07:25:58 --> Language Class Initialized
INFO - 2020-10-28 07:25:58 --> Config Class Initialized
INFO - 2020-10-28 07:25:58 --> Loader Class Initialized
INFO - 2020-10-28 07:25:58 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:58 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:58 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:58 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:58 --> Controller Class Initialized
INFO - 2020-10-28 07:25:59 --> Config Class Initialized
INFO - 2020-10-28 07:25:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:25:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:25:59 --> Utf8 Class Initialized
INFO - 2020-10-28 07:25:59 --> URI Class Initialized
INFO - 2020-10-28 07:25:59 --> Router Class Initialized
INFO - 2020-10-28 07:25:59 --> Output Class Initialized
INFO - 2020-10-28 07:25:59 --> Security Class Initialized
DEBUG - 2020-10-28 07:25:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:25:59 --> Input Class Initialized
INFO - 2020-10-28 07:25:59 --> Language Class Initialized
INFO - 2020-10-28 07:25:59 --> Language Class Initialized
INFO - 2020-10-28 07:25:59 --> Config Class Initialized
INFO - 2020-10-28 07:25:59 --> Loader Class Initialized
INFO - 2020-10-28 07:25:59 --> Helper loaded: url_helper
INFO - 2020-10-28 07:25:59 --> Helper loaded: file_helper
INFO - 2020-10-28 07:25:59 --> Helper loaded: form_helper
INFO - 2020-10-28 07:25:59 --> Helper loaded: my_helper
INFO - 2020-10-28 07:25:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:25:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:25:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:25:59 --> Controller Class Initialized
DEBUG - 2020-10-28 07:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-10-28 07:25:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:25:59 --> Final output sent to browser
DEBUG - 2020-10-28 07:25:59 --> Total execution time: 0.3212
INFO - 2020-10-28 07:26:12 --> Config Class Initialized
INFO - 2020-10-28 07:26:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:26:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:26:12 --> Utf8 Class Initialized
INFO - 2020-10-28 07:26:12 --> URI Class Initialized
INFO - 2020-10-28 07:26:12 --> Router Class Initialized
INFO - 2020-10-28 07:26:12 --> Output Class Initialized
INFO - 2020-10-28 07:26:12 --> Security Class Initialized
DEBUG - 2020-10-28 07:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:26:12 --> Input Class Initialized
INFO - 2020-10-28 07:26:12 --> Language Class Initialized
INFO - 2020-10-28 07:26:12 --> Language Class Initialized
INFO - 2020-10-28 07:26:12 --> Config Class Initialized
INFO - 2020-10-28 07:26:12 --> Loader Class Initialized
INFO - 2020-10-28 07:26:12 --> Helper loaded: url_helper
INFO - 2020-10-28 07:26:12 --> Helper loaded: file_helper
INFO - 2020-10-28 07:26:12 --> Helper loaded: form_helper
INFO - 2020-10-28 07:26:12 --> Helper loaded: my_helper
INFO - 2020-10-28 07:26:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:26:12 --> Controller Class Initialized
DEBUG - 2020-10-28 07:26:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2020-10-28 07:26:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:26:12 --> Final output sent to browser
DEBUG - 2020-10-28 07:26:12 --> Total execution time: 0.3270
INFO - 2020-10-28 07:26:12 --> Config Class Initialized
INFO - 2020-10-28 07:26:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:26:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:26:12 --> Utf8 Class Initialized
INFO - 2020-10-28 07:26:12 --> URI Class Initialized
INFO - 2020-10-28 07:26:12 --> Router Class Initialized
INFO - 2020-10-28 07:26:12 --> Output Class Initialized
INFO - 2020-10-28 07:26:12 --> Security Class Initialized
DEBUG - 2020-10-28 07:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:26:12 --> Input Class Initialized
INFO - 2020-10-28 07:26:12 --> Language Class Initialized
INFO - 2020-10-28 07:26:12 --> Language Class Initialized
INFO - 2020-10-28 07:26:12 --> Config Class Initialized
INFO - 2020-10-28 07:26:12 --> Loader Class Initialized
INFO - 2020-10-28 07:26:12 --> Helper loaded: url_helper
INFO - 2020-10-28 07:26:12 --> Helper loaded: file_helper
INFO - 2020-10-28 07:26:12 --> Helper loaded: form_helper
INFO - 2020-10-28 07:26:12 --> Helper loaded: my_helper
INFO - 2020-10-28 07:26:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:26:12 --> Controller Class Initialized
INFO - 2020-10-28 07:26:20 --> Config Class Initialized
INFO - 2020-10-28 07:26:20 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:26:20 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:26:20 --> Utf8 Class Initialized
INFO - 2020-10-28 07:26:20 --> URI Class Initialized
INFO - 2020-10-28 07:26:20 --> Router Class Initialized
INFO - 2020-10-28 07:26:20 --> Output Class Initialized
INFO - 2020-10-28 07:26:20 --> Security Class Initialized
DEBUG - 2020-10-28 07:26:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:26:20 --> Input Class Initialized
INFO - 2020-10-28 07:26:20 --> Language Class Initialized
INFO - 2020-10-28 07:26:20 --> Language Class Initialized
INFO - 2020-10-28 07:26:20 --> Config Class Initialized
INFO - 2020-10-28 07:26:20 --> Loader Class Initialized
INFO - 2020-10-28 07:26:20 --> Helper loaded: url_helper
INFO - 2020-10-28 07:26:20 --> Helper loaded: file_helper
INFO - 2020-10-28 07:26:20 --> Helper loaded: form_helper
INFO - 2020-10-28 07:26:20 --> Helper loaded: my_helper
INFO - 2020-10-28 07:26:20 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:26:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:26:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:26:20 --> Controller Class Initialized
DEBUG - 2020-10-28 07:26:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:26:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:26:20 --> Final output sent to browser
DEBUG - 2020-10-28 07:26:20 --> Total execution time: 0.3641
INFO - 2020-10-28 07:26:35 --> Config Class Initialized
INFO - 2020-10-28 07:26:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:26:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:26:35 --> Utf8 Class Initialized
INFO - 2020-10-28 07:26:35 --> URI Class Initialized
INFO - 2020-10-28 07:26:35 --> Router Class Initialized
INFO - 2020-10-28 07:26:35 --> Output Class Initialized
INFO - 2020-10-28 07:26:35 --> Security Class Initialized
DEBUG - 2020-10-28 07:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:26:35 --> Input Class Initialized
INFO - 2020-10-28 07:26:35 --> Language Class Initialized
INFO - 2020-10-28 07:26:35 --> Language Class Initialized
INFO - 2020-10-28 07:26:35 --> Config Class Initialized
INFO - 2020-10-28 07:26:35 --> Loader Class Initialized
INFO - 2020-10-28 07:26:35 --> Helper loaded: url_helper
INFO - 2020-10-28 07:26:35 --> Helper loaded: file_helper
INFO - 2020-10-28 07:26:35 --> Helper loaded: form_helper
INFO - 2020-10-28 07:26:35 --> Helper loaded: my_helper
INFO - 2020-10-28 07:26:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:26:35 --> Controller Class Initialized
DEBUG - 2020-10-28 07:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 07:26:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:26:35 --> Final output sent to browser
DEBUG - 2020-10-28 07:26:35 --> Total execution time: 0.4104
INFO - 2020-10-28 07:26:35 --> Config Class Initialized
INFO - 2020-10-28 07:26:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:26:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:26:35 --> Utf8 Class Initialized
INFO - 2020-10-28 07:26:35 --> URI Class Initialized
INFO - 2020-10-28 07:26:35 --> Router Class Initialized
INFO - 2020-10-28 07:26:35 --> Output Class Initialized
INFO - 2020-10-28 07:26:35 --> Security Class Initialized
DEBUG - 2020-10-28 07:26:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:26:35 --> Input Class Initialized
INFO - 2020-10-28 07:26:35 --> Language Class Initialized
INFO - 2020-10-28 07:26:35 --> Language Class Initialized
INFO - 2020-10-28 07:26:35 --> Config Class Initialized
INFO - 2020-10-28 07:26:35 --> Loader Class Initialized
INFO - 2020-10-28 07:26:35 --> Helper loaded: url_helper
INFO - 2020-10-28 07:26:35 --> Helper loaded: file_helper
INFO - 2020-10-28 07:26:35 --> Helper loaded: form_helper
INFO - 2020-10-28 07:26:35 --> Helper loaded: my_helper
INFO - 2020-10-28 07:26:35 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:26:35 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:26:35 --> Controller Class Initialized
INFO - 2020-10-28 07:26:38 --> Config Class Initialized
INFO - 2020-10-28 07:26:38 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:26:38 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:26:38 --> Utf8 Class Initialized
INFO - 2020-10-28 07:26:38 --> URI Class Initialized
INFO - 2020-10-28 07:26:38 --> Router Class Initialized
INFO - 2020-10-28 07:26:38 --> Output Class Initialized
INFO - 2020-10-28 07:26:38 --> Security Class Initialized
DEBUG - 2020-10-28 07:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:26:38 --> Input Class Initialized
INFO - 2020-10-28 07:26:38 --> Language Class Initialized
INFO - 2020-10-28 07:26:39 --> Language Class Initialized
INFO - 2020-10-28 07:26:39 --> Config Class Initialized
INFO - 2020-10-28 07:26:39 --> Loader Class Initialized
INFO - 2020-10-28 07:26:39 --> Helper loaded: url_helper
INFO - 2020-10-28 07:26:39 --> Helper loaded: file_helper
INFO - 2020-10-28 07:26:39 --> Helper loaded: form_helper
INFO - 2020-10-28 07:26:39 --> Helper loaded: my_helper
INFO - 2020-10-28 07:26:39 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:26:39 --> Controller Class Initialized
INFO - 2020-10-28 07:26:39 --> Final output sent to browser
DEBUG - 2020-10-28 07:26:39 --> Total execution time: 0.3772
INFO - 2020-10-28 07:26:39 --> Config Class Initialized
INFO - 2020-10-28 07:26:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:26:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:26:39 --> Utf8 Class Initialized
INFO - 2020-10-28 07:26:39 --> URI Class Initialized
INFO - 2020-10-28 07:26:39 --> Router Class Initialized
INFO - 2020-10-28 07:26:39 --> Output Class Initialized
INFO - 2020-10-28 07:26:39 --> Security Class Initialized
DEBUG - 2020-10-28 07:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:26:39 --> Input Class Initialized
INFO - 2020-10-28 07:26:39 --> Language Class Initialized
INFO - 2020-10-28 07:26:39 --> Language Class Initialized
INFO - 2020-10-28 07:26:39 --> Config Class Initialized
INFO - 2020-10-28 07:26:39 --> Loader Class Initialized
INFO - 2020-10-28 07:26:39 --> Helper loaded: url_helper
INFO - 2020-10-28 07:26:39 --> Helper loaded: file_helper
INFO - 2020-10-28 07:26:39 --> Helper loaded: form_helper
INFO - 2020-10-28 07:26:39 --> Helper loaded: my_helper
INFO - 2020-10-28 07:26:39 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:26:39 --> Controller Class Initialized
INFO - 2020-10-28 07:27:14 --> Config Class Initialized
INFO - 2020-10-28 07:27:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:27:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:27:14 --> Utf8 Class Initialized
INFO - 2020-10-28 07:27:14 --> URI Class Initialized
INFO - 2020-10-28 07:27:14 --> Router Class Initialized
INFO - 2020-10-28 07:27:14 --> Output Class Initialized
INFO - 2020-10-28 07:27:14 --> Security Class Initialized
DEBUG - 2020-10-28 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:27:14 --> Input Class Initialized
INFO - 2020-10-28 07:27:14 --> Language Class Initialized
INFO - 2020-10-28 07:27:14 --> Language Class Initialized
INFO - 2020-10-28 07:27:14 --> Config Class Initialized
INFO - 2020-10-28 07:27:14 --> Loader Class Initialized
INFO - 2020-10-28 07:27:14 --> Helper loaded: url_helper
INFO - 2020-10-28 07:27:14 --> Helper loaded: file_helper
INFO - 2020-10-28 07:27:14 --> Helper loaded: form_helper
INFO - 2020-10-28 07:27:14 --> Helper loaded: my_helper
INFO - 2020-10-28 07:27:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:27:14 --> Controller Class Initialized
DEBUG - 2020-10-28 07:27:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 07:27:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:27:14 --> Final output sent to browser
DEBUG - 2020-10-28 07:27:14 --> Total execution time: 0.3341
INFO - 2020-10-28 07:27:14 --> Config Class Initialized
INFO - 2020-10-28 07:27:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:27:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:27:14 --> Utf8 Class Initialized
INFO - 2020-10-28 07:27:14 --> URI Class Initialized
INFO - 2020-10-28 07:27:14 --> Router Class Initialized
INFO - 2020-10-28 07:27:14 --> Output Class Initialized
INFO - 2020-10-28 07:27:14 --> Security Class Initialized
DEBUG - 2020-10-28 07:27:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:27:14 --> Input Class Initialized
INFO - 2020-10-28 07:27:14 --> Language Class Initialized
INFO - 2020-10-28 07:27:14 --> Language Class Initialized
INFO - 2020-10-28 07:27:14 --> Config Class Initialized
INFO - 2020-10-28 07:27:14 --> Loader Class Initialized
INFO - 2020-10-28 07:27:14 --> Helper loaded: url_helper
INFO - 2020-10-28 07:27:14 --> Helper loaded: file_helper
INFO - 2020-10-28 07:27:14 --> Helper loaded: form_helper
INFO - 2020-10-28 07:27:14 --> Helper loaded: my_helper
INFO - 2020-10-28 07:27:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:27:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:27:14 --> Controller Class Initialized
INFO - 2020-10-28 07:27:17 --> Config Class Initialized
INFO - 2020-10-28 07:27:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:27:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:27:17 --> Utf8 Class Initialized
INFO - 2020-10-28 07:27:18 --> URI Class Initialized
INFO - 2020-10-28 07:27:18 --> Router Class Initialized
INFO - 2020-10-28 07:27:18 --> Output Class Initialized
INFO - 2020-10-28 07:27:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:27:18 --> Input Class Initialized
INFO - 2020-10-28 07:27:18 --> Language Class Initialized
INFO - 2020-10-28 07:27:18 --> Language Class Initialized
INFO - 2020-10-28 07:27:18 --> Config Class Initialized
INFO - 2020-10-28 07:27:18 --> Loader Class Initialized
INFO - 2020-10-28 07:27:18 --> Helper loaded: url_helper
INFO - 2020-10-28 07:27:18 --> Helper loaded: file_helper
INFO - 2020-10-28 07:27:18 --> Helper loaded: form_helper
INFO - 2020-10-28 07:27:18 --> Helper loaded: my_helper
INFO - 2020-10-28 07:27:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:27:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:27:18 --> Controller Class Initialized
DEBUG - 2020-10-28 07:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:27:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:27:18 --> Final output sent to browser
DEBUG - 2020-10-28 07:27:18 --> Total execution time: 0.3205
INFO - 2020-10-28 07:27:30 --> Config Class Initialized
INFO - 2020-10-28 07:27:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:27:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:27:30 --> Utf8 Class Initialized
INFO - 2020-10-28 07:27:30 --> URI Class Initialized
INFO - 2020-10-28 07:27:30 --> Router Class Initialized
INFO - 2020-10-28 07:27:30 --> Output Class Initialized
INFO - 2020-10-28 07:27:30 --> Security Class Initialized
DEBUG - 2020-10-28 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:27:30 --> Input Class Initialized
INFO - 2020-10-28 07:27:30 --> Language Class Initialized
INFO - 2020-10-28 07:27:30 --> Language Class Initialized
INFO - 2020-10-28 07:27:30 --> Config Class Initialized
INFO - 2020-10-28 07:27:30 --> Loader Class Initialized
INFO - 2020-10-28 07:27:30 --> Helper loaded: url_helper
INFO - 2020-10-28 07:27:30 --> Helper loaded: file_helper
INFO - 2020-10-28 07:27:30 --> Helper loaded: form_helper
INFO - 2020-10-28 07:27:30 --> Helper loaded: my_helper
INFO - 2020-10-28 07:27:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:27:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:27:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:27:30 --> Controller Class Initialized
DEBUG - 2020-10-28 07:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 07:27:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:27:30 --> Final output sent to browser
DEBUG - 2020-10-28 07:27:30 --> Total execution time: 0.3274
INFO - 2020-10-28 07:27:30 --> Config Class Initialized
INFO - 2020-10-28 07:27:30 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:27:30 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:27:30 --> Utf8 Class Initialized
INFO - 2020-10-28 07:27:30 --> URI Class Initialized
INFO - 2020-10-28 07:27:30 --> Router Class Initialized
INFO - 2020-10-28 07:27:30 --> Output Class Initialized
INFO - 2020-10-28 07:27:30 --> Security Class Initialized
DEBUG - 2020-10-28 07:27:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:27:30 --> Input Class Initialized
INFO - 2020-10-28 07:27:30 --> Language Class Initialized
INFO - 2020-10-28 07:27:30 --> Language Class Initialized
INFO - 2020-10-28 07:27:30 --> Config Class Initialized
INFO - 2020-10-28 07:27:30 --> Loader Class Initialized
INFO - 2020-10-28 07:27:30 --> Helper loaded: url_helper
INFO - 2020-10-28 07:27:30 --> Helper loaded: file_helper
INFO - 2020-10-28 07:27:30 --> Helper loaded: form_helper
INFO - 2020-10-28 07:27:30 --> Helper loaded: my_helper
INFO - 2020-10-28 07:27:30 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:27:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:27:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:27:31 --> Controller Class Initialized
INFO - 2020-10-28 07:28:11 --> Config Class Initialized
INFO - 2020-10-28 07:28:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:28:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:28:11 --> Utf8 Class Initialized
INFO - 2020-10-28 07:28:11 --> URI Class Initialized
INFO - 2020-10-28 07:28:11 --> Router Class Initialized
INFO - 2020-10-28 07:28:11 --> Output Class Initialized
INFO - 2020-10-28 07:28:11 --> Security Class Initialized
DEBUG - 2020-10-28 07:28:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:28:11 --> Input Class Initialized
INFO - 2020-10-28 07:28:11 --> Language Class Initialized
INFO - 2020-10-28 07:28:11 --> Language Class Initialized
INFO - 2020-10-28 07:28:11 --> Config Class Initialized
INFO - 2020-10-28 07:28:11 --> Loader Class Initialized
INFO - 2020-10-28 07:28:11 --> Helper loaded: url_helper
INFO - 2020-10-28 07:28:11 --> Helper loaded: file_helper
INFO - 2020-10-28 07:28:11 --> Helper loaded: form_helper
INFO - 2020-10-28 07:28:11 --> Helper loaded: my_helper
INFO - 2020-10-28 07:28:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:28:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:28:11 --> Controller Class Initialized
INFO - 2020-10-28 07:28:11 --> Final output sent to browser
DEBUG - 2020-10-28 07:28:11 --> Total execution time: 0.3022
INFO - 2020-10-28 07:28:17 --> Config Class Initialized
INFO - 2020-10-28 07:28:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:28:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:28:17 --> Utf8 Class Initialized
INFO - 2020-10-28 07:28:17 --> URI Class Initialized
INFO - 2020-10-28 07:28:17 --> Router Class Initialized
INFO - 2020-10-28 07:28:17 --> Output Class Initialized
INFO - 2020-10-28 07:28:17 --> Security Class Initialized
DEBUG - 2020-10-28 07:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:28:17 --> Input Class Initialized
INFO - 2020-10-28 07:28:17 --> Language Class Initialized
INFO - 2020-10-28 07:28:17 --> Language Class Initialized
INFO - 2020-10-28 07:28:17 --> Config Class Initialized
INFO - 2020-10-28 07:28:17 --> Loader Class Initialized
INFO - 2020-10-28 07:28:17 --> Helper loaded: url_helper
INFO - 2020-10-28 07:28:17 --> Helper loaded: file_helper
INFO - 2020-10-28 07:28:17 --> Helper loaded: form_helper
INFO - 2020-10-28 07:28:17 --> Helper loaded: my_helper
INFO - 2020-10-28 07:28:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:28:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:28:17 --> Controller Class Initialized
INFO - 2020-10-28 07:28:17 --> Final output sent to browser
DEBUG - 2020-10-28 07:28:17 --> Total execution time: 0.3719
INFO - 2020-10-28 07:28:17 --> Config Class Initialized
INFO - 2020-10-28 07:28:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:28:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:28:17 --> Utf8 Class Initialized
INFO - 2020-10-28 07:28:17 --> URI Class Initialized
INFO - 2020-10-28 07:28:18 --> Router Class Initialized
INFO - 2020-10-28 07:28:18 --> Output Class Initialized
INFO - 2020-10-28 07:28:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:28:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:28:18 --> Input Class Initialized
INFO - 2020-10-28 07:28:18 --> Language Class Initialized
INFO - 2020-10-28 07:28:18 --> Language Class Initialized
INFO - 2020-10-28 07:28:18 --> Config Class Initialized
INFO - 2020-10-28 07:28:18 --> Loader Class Initialized
INFO - 2020-10-28 07:28:18 --> Helper loaded: url_helper
INFO - 2020-10-28 07:28:18 --> Helper loaded: file_helper
INFO - 2020-10-28 07:28:18 --> Helper loaded: form_helper
INFO - 2020-10-28 07:28:18 --> Helper loaded: my_helper
INFO - 2020-10-28 07:28:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:28:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:28:18 --> Controller Class Initialized
INFO - 2020-10-28 07:33:50 --> Config Class Initialized
INFO - 2020-10-28 07:33:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:33:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:33:50 --> Utf8 Class Initialized
INFO - 2020-10-28 07:33:50 --> URI Class Initialized
INFO - 2020-10-28 07:33:50 --> Router Class Initialized
INFO - 2020-10-28 07:33:50 --> Output Class Initialized
INFO - 2020-10-28 07:33:50 --> Security Class Initialized
DEBUG - 2020-10-28 07:33:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:33:50 --> Input Class Initialized
INFO - 2020-10-28 07:33:50 --> Language Class Initialized
INFO - 2020-10-28 07:33:51 --> Language Class Initialized
INFO - 2020-10-28 07:33:51 --> Config Class Initialized
INFO - 2020-10-28 07:33:51 --> Loader Class Initialized
INFO - 2020-10-28 07:33:51 --> Helper loaded: url_helper
INFO - 2020-10-28 07:33:51 --> Helper loaded: file_helper
INFO - 2020-10-28 07:33:51 --> Helper loaded: form_helper
INFO - 2020-10-28 07:33:51 --> Helper loaded: my_helper
INFO - 2020-10-28 07:33:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:33:51 --> Controller Class Initialized
INFO - 2020-10-28 07:33:51 --> Final output sent to browser
DEBUG - 2020-10-28 07:33:51 --> Total execution time: 0.2916
INFO - 2020-10-28 07:52:11 --> Config Class Initialized
INFO - 2020-10-28 07:52:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:52:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:52:11 --> Utf8 Class Initialized
INFO - 2020-10-28 07:52:11 --> URI Class Initialized
INFO - 2020-10-28 07:52:11 --> Router Class Initialized
INFO - 2020-10-28 07:52:11 --> Output Class Initialized
INFO - 2020-10-28 07:52:11 --> Security Class Initialized
DEBUG - 2020-10-28 07:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:52:11 --> Input Class Initialized
INFO - 2020-10-28 07:52:11 --> Language Class Initialized
INFO - 2020-10-28 07:52:11 --> Language Class Initialized
INFO - 2020-10-28 07:52:11 --> Config Class Initialized
INFO - 2020-10-28 07:52:11 --> Loader Class Initialized
INFO - 2020-10-28 07:52:12 --> Helper loaded: url_helper
INFO - 2020-10-28 07:52:12 --> Helper loaded: file_helper
INFO - 2020-10-28 07:52:12 --> Helper loaded: form_helper
INFO - 2020-10-28 07:52:12 --> Helper loaded: my_helper
INFO - 2020-10-28 07:52:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:52:12 --> Controller Class Initialized
DEBUG - 2020-10-28 07:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 07:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:52:12 --> Final output sent to browser
DEBUG - 2020-10-28 07:52:12 --> Total execution time: 0.3533
INFO - 2020-10-28 07:52:12 --> Config Class Initialized
INFO - 2020-10-28 07:52:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:52:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:52:12 --> Utf8 Class Initialized
INFO - 2020-10-28 07:52:12 --> URI Class Initialized
INFO - 2020-10-28 07:52:12 --> Router Class Initialized
INFO - 2020-10-28 07:52:12 --> Output Class Initialized
INFO - 2020-10-28 07:52:12 --> Security Class Initialized
DEBUG - 2020-10-28 07:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:52:12 --> Input Class Initialized
INFO - 2020-10-28 07:52:12 --> Language Class Initialized
INFO - 2020-10-28 07:52:12 --> Language Class Initialized
INFO - 2020-10-28 07:52:12 --> Config Class Initialized
INFO - 2020-10-28 07:52:12 --> Loader Class Initialized
INFO - 2020-10-28 07:52:12 --> Helper loaded: url_helper
INFO - 2020-10-28 07:52:12 --> Helper loaded: file_helper
INFO - 2020-10-28 07:52:12 --> Helper loaded: form_helper
INFO - 2020-10-28 07:52:12 --> Helper loaded: my_helper
INFO - 2020-10-28 07:52:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:52:12 --> Controller Class Initialized
INFO - 2020-10-28 07:52:14 --> Config Class Initialized
INFO - 2020-10-28 07:52:14 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:52:14 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:52:14 --> Utf8 Class Initialized
INFO - 2020-10-28 07:52:14 --> URI Class Initialized
INFO - 2020-10-28 07:52:14 --> Router Class Initialized
INFO - 2020-10-28 07:52:14 --> Output Class Initialized
INFO - 2020-10-28 07:52:14 --> Security Class Initialized
DEBUG - 2020-10-28 07:52:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:52:14 --> Input Class Initialized
INFO - 2020-10-28 07:52:14 --> Language Class Initialized
INFO - 2020-10-28 07:52:14 --> Language Class Initialized
INFO - 2020-10-28 07:52:14 --> Config Class Initialized
INFO - 2020-10-28 07:52:14 --> Loader Class Initialized
INFO - 2020-10-28 07:52:14 --> Helper loaded: url_helper
INFO - 2020-10-28 07:52:14 --> Helper loaded: file_helper
INFO - 2020-10-28 07:52:14 --> Helper loaded: form_helper
INFO - 2020-10-28 07:52:14 --> Helper loaded: my_helper
INFO - 2020-10-28 07:52:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:52:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:52:14 --> Controller Class Initialized
INFO - 2020-10-28 07:52:14 --> Final output sent to browser
DEBUG - 2020-10-28 07:52:14 --> Total execution time: 0.3180
INFO - 2020-10-28 07:52:35 --> Config Class Initialized
INFO - 2020-10-28 07:52:35 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:52:35 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:52:35 --> Utf8 Class Initialized
INFO - 2020-10-28 07:52:36 --> URI Class Initialized
INFO - 2020-10-28 07:52:36 --> Router Class Initialized
INFO - 2020-10-28 07:52:36 --> Output Class Initialized
INFO - 2020-10-28 07:52:36 --> Security Class Initialized
DEBUG - 2020-10-28 07:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:52:36 --> Input Class Initialized
INFO - 2020-10-28 07:52:36 --> Language Class Initialized
INFO - 2020-10-28 07:52:36 --> Language Class Initialized
INFO - 2020-10-28 07:52:36 --> Config Class Initialized
INFO - 2020-10-28 07:52:36 --> Loader Class Initialized
INFO - 2020-10-28 07:52:36 --> Helper loaded: url_helper
INFO - 2020-10-28 07:52:36 --> Helper loaded: file_helper
INFO - 2020-10-28 07:52:36 --> Helper loaded: form_helper
INFO - 2020-10-28 07:52:36 --> Helper loaded: my_helper
INFO - 2020-10-28 07:52:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:52:36 --> Controller Class Initialized
INFO - 2020-10-28 07:52:36 --> Final output sent to browser
DEBUG - 2020-10-28 07:52:36 --> Total execution time: 0.3419
INFO - 2020-10-28 07:52:36 --> Config Class Initialized
INFO - 2020-10-28 07:52:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:52:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:52:36 --> Utf8 Class Initialized
INFO - 2020-10-28 07:52:36 --> URI Class Initialized
INFO - 2020-10-28 07:52:36 --> Router Class Initialized
INFO - 2020-10-28 07:52:36 --> Output Class Initialized
INFO - 2020-10-28 07:52:36 --> Security Class Initialized
DEBUG - 2020-10-28 07:52:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:52:36 --> Input Class Initialized
INFO - 2020-10-28 07:52:36 --> Language Class Initialized
INFO - 2020-10-28 07:52:36 --> Language Class Initialized
INFO - 2020-10-28 07:52:36 --> Config Class Initialized
INFO - 2020-10-28 07:52:36 --> Loader Class Initialized
INFO - 2020-10-28 07:52:36 --> Helper loaded: url_helper
INFO - 2020-10-28 07:52:36 --> Helper loaded: file_helper
INFO - 2020-10-28 07:52:36 --> Helper loaded: form_helper
INFO - 2020-10-28 07:52:36 --> Helper loaded: my_helper
INFO - 2020-10-28 07:52:36 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:52:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:52:36 --> Controller Class Initialized
INFO - 2020-10-28 07:53:23 --> Config Class Initialized
INFO - 2020-10-28 07:53:23 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:53:23 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:53:23 --> Utf8 Class Initialized
INFO - 2020-10-28 07:53:23 --> URI Class Initialized
INFO - 2020-10-28 07:53:23 --> Router Class Initialized
INFO - 2020-10-28 07:53:23 --> Output Class Initialized
INFO - 2020-10-28 07:53:23 --> Security Class Initialized
DEBUG - 2020-10-28 07:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:53:23 --> Input Class Initialized
INFO - 2020-10-28 07:53:23 --> Language Class Initialized
INFO - 2020-10-28 07:53:23 --> Language Class Initialized
INFO - 2020-10-28 07:53:23 --> Config Class Initialized
INFO - 2020-10-28 07:53:23 --> Loader Class Initialized
INFO - 2020-10-28 07:53:23 --> Helper loaded: url_helper
INFO - 2020-10-28 07:53:23 --> Helper loaded: file_helper
INFO - 2020-10-28 07:53:23 --> Helper loaded: form_helper
INFO - 2020-10-28 07:53:23 --> Helper loaded: my_helper
INFO - 2020-10-28 07:53:23 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:53:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:53:23 --> Controller Class Initialized
DEBUG - 2020-10-28 07:53:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 07:53:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:53:23 --> Final output sent to browser
DEBUG - 2020-10-28 07:53:23 --> Total execution time: 0.3506
INFO - 2020-10-28 07:53:24 --> Config Class Initialized
INFO - 2020-10-28 07:53:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:53:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:53:24 --> Utf8 Class Initialized
INFO - 2020-10-28 07:53:24 --> URI Class Initialized
INFO - 2020-10-28 07:53:24 --> Router Class Initialized
INFO - 2020-10-28 07:53:24 --> Output Class Initialized
INFO - 2020-10-28 07:53:24 --> Security Class Initialized
DEBUG - 2020-10-28 07:53:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:53:24 --> Input Class Initialized
INFO - 2020-10-28 07:53:24 --> Language Class Initialized
INFO - 2020-10-28 07:53:24 --> Language Class Initialized
INFO - 2020-10-28 07:53:24 --> Config Class Initialized
INFO - 2020-10-28 07:53:24 --> Loader Class Initialized
INFO - 2020-10-28 07:53:24 --> Helper loaded: url_helper
INFO - 2020-10-28 07:53:24 --> Helper loaded: file_helper
INFO - 2020-10-28 07:53:24 --> Helper loaded: form_helper
INFO - 2020-10-28 07:53:24 --> Helper loaded: my_helper
INFO - 2020-10-28 07:53:24 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:53:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:53:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:53:24 --> Controller Class Initialized
INFO - 2020-10-28 07:53:59 --> Config Class Initialized
INFO - 2020-10-28 07:53:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:53:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:53:59 --> Utf8 Class Initialized
INFO - 2020-10-28 07:53:59 --> URI Class Initialized
INFO - 2020-10-28 07:53:59 --> Router Class Initialized
INFO - 2020-10-28 07:53:59 --> Output Class Initialized
INFO - 2020-10-28 07:53:59 --> Security Class Initialized
DEBUG - 2020-10-28 07:53:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:53:59 --> Input Class Initialized
INFO - 2020-10-28 07:53:59 --> Language Class Initialized
INFO - 2020-10-28 07:53:59 --> Language Class Initialized
INFO - 2020-10-28 07:53:59 --> Config Class Initialized
INFO - 2020-10-28 07:53:59 --> Loader Class Initialized
INFO - 2020-10-28 07:53:59 --> Helper loaded: url_helper
INFO - 2020-10-28 07:53:59 --> Helper loaded: file_helper
INFO - 2020-10-28 07:53:59 --> Helper loaded: form_helper
INFO - 2020-10-28 07:53:59 --> Helper loaded: my_helper
INFO - 2020-10-28 07:53:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:53:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:53:59 --> Controller Class Initialized
DEBUG - 2020-10-28 07:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:53:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:53:59 --> Final output sent to browser
DEBUG - 2020-10-28 07:53:59 --> Total execution time: 0.3428
INFO - 2020-10-28 07:54:00 --> Config Class Initialized
INFO - 2020-10-28 07:54:00 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:00 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:00 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:00 --> URI Class Initialized
INFO - 2020-10-28 07:54:00 --> Router Class Initialized
INFO - 2020-10-28 07:54:00 --> Output Class Initialized
INFO - 2020-10-28 07:54:00 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:00 --> Input Class Initialized
INFO - 2020-10-28 07:54:00 --> Language Class Initialized
INFO - 2020-10-28 07:54:00 --> Language Class Initialized
INFO - 2020-10-28 07:54:00 --> Config Class Initialized
INFO - 2020-10-28 07:54:00 --> Loader Class Initialized
INFO - 2020-10-28 07:54:00 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:00 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:00 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:00 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:00 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:00 --> Controller Class Initialized
DEBUG - 2020-10-28 07:54:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2020-10-28 07:54:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:00 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:00 --> Total execution time: 0.3325
INFO - 2020-10-28 07:54:01 --> Config Class Initialized
INFO - 2020-10-28 07:54:01 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:01 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:01 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:01 --> URI Class Initialized
INFO - 2020-10-28 07:54:01 --> Router Class Initialized
INFO - 2020-10-28 07:54:01 --> Output Class Initialized
INFO - 2020-10-28 07:54:01 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:01 --> Input Class Initialized
INFO - 2020-10-28 07:54:01 --> Language Class Initialized
INFO - 2020-10-28 07:54:01 --> Language Class Initialized
INFO - 2020-10-28 07:54:01 --> Config Class Initialized
INFO - 2020-10-28 07:54:01 --> Loader Class Initialized
INFO - 2020-10-28 07:54:01 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:01 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:01 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:01 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:01 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:01 --> Controller Class Initialized
INFO - 2020-10-28 07:54:04 --> Config Class Initialized
INFO - 2020-10-28 07:54:04 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:04 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:04 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:04 --> URI Class Initialized
INFO - 2020-10-28 07:54:04 --> Router Class Initialized
INFO - 2020-10-28 07:54:04 --> Output Class Initialized
INFO - 2020-10-28 07:54:04 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:04 --> Input Class Initialized
INFO - 2020-10-28 07:54:04 --> Language Class Initialized
INFO - 2020-10-28 07:54:04 --> Language Class Initialized
INFO - 2020-10-28 07:54:04 --> Config Class Initialized
INFO - 2020-10-28 07:54:04 --> Loader Class Initialized
INFO - 2020-10-28 07:54:04 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:04 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:05 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:05 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:05 --> Controller Class Initialized
INFO - 2020-10-28 07:54:05 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:05 --> Total execution time: 0.3236
INFO - 2020-10-28 07:54:08 --> Config Class Initialized
INFO - 2020-10-28 07:54:08 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:08 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:08 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:08 --> URI Class Initialized
INFO - 2020-10-28 07:54:08 --> Router Class Initialized
INFO - 2020-10-28 07:54:08 --> Output Class Initialized
INFO - 2020-10-28 07:54:08 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:08 --> Input Class Initialized
INFO - 2020-10-28 07:54:08 --> Language Class Initialized
INFO - 2020-10-28 07:54:08 --> Language Class Initialized
INFO - 2020-10-28 07:54:08 --> Config Class Initialized
INFO - 2020-10-28 07:54:08 --> Loader Class Initialized
INFO - 2020-10-28 07:54:08 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:08 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:08 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:08 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:08 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:09 --> Controller Class Initialized
INFO - 2020-10-28 07:54:09 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:09 --> Total execution time: 0.3865
INFO - 2020-10-28 07:54:09 --> Config Class Initialized
INFO - 2020-10-28 07:54:09 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:09 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:09 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:09 --> URI Class Initialized
INFO - 2020-10-28 07:54:09 --> Router Class Initialized
INFO - 2020-10-28 07:54:09 --> Output Class Initialized
INFO - 2020-10-28 07:54:09 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:09 --> Input Class Initialized
INFO - 2020-10-28 07:54:09 --> Language Class Initialized
INFO - 2020-10-28 07:54:09 --> Language Class Initialized
INFO - 2020-10-28 07:54:09 --> Config Class Initialized
INFO - 2020-10-28 07:54:09 --> Loader Class Initialized
INFO - 2020-10-28 07:54:09 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:09 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:09 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:09 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:09 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:09 --> Controller Class Initialized
INFO - 2020-10-28 07:54:11 --> Config Class Initialized
INFO - 2020-10-28 07:54:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:11 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:11 --> URI Class Initialized
INFO - 2020-10-28 07:54:11 --> Router Class Initialized
INFO - 2020-10-28 07:54:11 --> Output Class Initialized
INFO - 2020-10-28 07:54:11 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:11 --> Input Class Initialized
INFO - 2020-10-28 07:54:11 --> Language Class Initialized
INFO - 2020-10-28 07:54:11 --> Language Class Initialized
INFO - 2020-10-28 07:54:11 --> Config Class Initialized
INFO - 2020-10-28 07:54:11 --> Loader Class Initialized
INFO - 2020-10-28 07:54:11 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:11 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:11 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:11 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:11 --> Controller Class Initialized
INFO - 2020-10-28 07:54:11 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:11 --> Total execution time: 0.4550
INFO - 2020-10-28 07:54:11 --> Config Class Initialized
INFO - 2020-10-28 07:54:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:11 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:11 --> URI Class Initialized
INFO - 2020-10-28 07:54:11 --> Router Class Initialized
INFO - 2020-10-28 07:54:11 --> Output Class Initialized
INFO - 2020-10-28 07:54:11 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:11 --> Input Class Initialized
INFO - 2020-10-28 07:54:11 --> Language Class Initialized
INFO - 2020-10-28 07:54:11 --> Language Class Initialized
INFO - 2020-10-28 07:54:11 --> Config Class Initialized
INFO - 2020-10-28 07:54:11 --> Loader Class Initialized
INFO - 2020-10-28 07:54:11 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:11 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:11 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:11 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:11 --> Controller Class Initialized
INFO - 2020-10-28 07:54:17 --> Config Class Initialized
INFO - 2020-10-28 07:54:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:17 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:17 --> URI Class Initialized
INFO - 2020-10-28 07:54:17 --> Router Class Initialized
INFO - 2020-10-28 07:54:17 --> Output Class Initialized
INFO - 2020-10-28 07:54:17 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:17 --> Input Class Initialized
INFO - 2020-10-28 07:54:17 --> Language Class Initialized
INFO - 2020-10-28 07:54:17 --> Language Class Initialized
INFO - 2020-10-28 07:54:17 --> Config Class Initialized
INFO - 2020-10-28 07:54:17 --> Loader Class Initialized
INFO - 2020-10-28 07:54:17 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:17 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:17 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:17 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:17 --> Controller Class Initialized
DEBUG - 2020-10-28 07:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:17 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:17 --> Total execution time: 0.3325
INFO - 2020-10-28 07:54:27 --> Config Class Initialized
INFO - 2020-10-28 07:54:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:27 --> URI Class Initialized
INFO - 2020-10-28 07:54:27 --> Router Class Initialized
INFO - 2020-10-28 07:54:27 --> Output Class Initialized
INFO - 2020-10-28 07:54:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:27 --> Input Class Initialized
INFO - 2020-10-28 07:54:27 --> Language Class Initialized
INFO - 2020-10-28 07:54:27 --> Language Class Initialized
INFO - 2020-10-28 07:54:27 --> Config Class Initialized
INFO - 2020-10-28 07:54:27 --> Loader Class Initialized
INFO - 2020-10-28 07:54:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:27 --> Controller Class Initialized
DEBUG - 2020-10-28 07:54:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_mapel/views/list.php
DEBUG - 2020-10-28 07:54:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:27 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:27 --> Total execution time: 0.3609
INFO - 2020-10-28 07:54:27 --> Config Class Initialized
INFO - 2020-10-28 07:54:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:27 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:27 --> URI Class Initialized
INFO - 2020-10-28 07:54:27 --> Router Class Initialized
INFO - 2020-10-28 07:54:27 --> Output Class Initialized
INFO - 2020-10-28 07:54:27 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:27 --> Input Class Initialized
INFO - 2020-10-28 07:54:27 --> Language Class Initialized
INFO - 2020-10-28 07:54:27 --> Language Class Initialized
INFO - 2020-10-28 07:54:27 --> Config Class Initialized
INFO - 2020-10-28 07:54:27 --> Loader Class Initialized
INFO - 2020-10-28 07:54:27 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:27 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:27 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:27 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:28 --> Controller Class Initialized
INFO - 2020-10-28 07:54:37 --> Config Class Initialized
INFO - 2020-10-28 07:54:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:37 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:37 --> URI Class Initialized
INFO - 2020-10-28 07:54:37 --> Router Class Initialized
INFO - 2020-10-28 07:54:37 --> Output Class Initialized
INFO - 2020-10-28 07:54:37 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:37 --> Input Class Initialized
INFO - 2020-10-28 07:54:37 --> Language Class Initialized
INFO - 2020-10-28 07:54:37 --> Language Class Initialized
INFO - 2020-10-28 07:54:37 --> Config Class Initialized
INFO - 2020-10-28 07:54:37 --> Loader Class Initialized
INFO - 2020-10-28 07:54:37 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:37 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:37 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:37 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:37 --> Controller Class Initialized
DEBUG - 2020-10-28 07:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:37 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:37 --> Total execution time: 0.3332
INFO - 2020-10-28 07:54:39 --> Config Class Initialized
INFO - 2020-10-28 07:54:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:39 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:39 --> URI Class Initialized
INFO - 2020-10-28 07:54:39 --> Router Class Initialized
INFO - 2020-10-28 07:54:39 --> Output Class Initialized
INFO - 2020-10-28 07:54:39 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:39 --> Input Class Initialized
INFO - 2020-10-28 07:54:39 --> Language Class Initialized
INFO - 2020-10-28 07:54:39 --> Language Class Initialized
INFO - 2020-10-28 07:54:39 --> Config Class Initialized
INFO - 2020-10-28 07:54:39 --> Loader Class Initialized
INFO - 2020-10-28 07:54:39 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:39 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:39 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:39 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:39 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:39 --> Controller Class Initialized
DEBUG - 2020-10-28 07:54:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 07:54:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:39 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:39 --> Total execution time: 0.3247
INFO - 2020-10-28 07:54:47 --> Config Class Initialized
INFO - 2020-10-28 07:54:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:47 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:47 --> URI Class Initialized
INFO - 2020-10-28 07:54:47 --> Router Class Initialized
INFO - 2020-10-28 07:54:47 --> Output Class Initialized
INFO - 2020-10-28 07:54:47 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:47 --> Input Class Initialized
INFO - 2020-10-28 07:54:47 --> Language Class Initialized
INFO - 2020-10-28 07:54:47 --> Language Class Initialized
INFO - 2020-10-28 07:54:47 --> Config Class Initialized
INFO - 2020-10-28 07:54:47 --> Loader Class Initialized
INFO - 2020-10-28 07:54:47 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:47 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:47 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:47 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:47 --> Controller Class Initialized
DEBUG - 2020-10-28 07:54:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 07:54:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:47 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:47 --> Total execution time: 0.3458
INFO - 2020-10-28 07:54:47 --> Config Class Initialized
INFO - 2020-10-28 07:54:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:47 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:47 --> URI Class Initialized
INFO - 2020-10-28 07:54:47 --> Router Class Initialized
INFO - 2020-10-28 07:54:47 --> Output Class Initialized
INFO - 2020-10-28 07:54:47 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:47 --> Input Class Initialized
INFO - 2020-10-28 07:54:47 --> Language Class Initialized
INFO - 2020-10-28 07:54:47 --> Language Class Initialized
INFO - 2020-10-28 07:54:47 --> Config Class Initialized
INFO - 2020-10-28 07:54:47 --> Loader Class Initialized
INFO - 2020-10-28 07:54:47 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:47 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:47 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:47 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:47 --> Controller Class Initialized
INFO - 2020-10-28 07:54:50 --> Config Class Initialized
INFO - 2020-10-28 07:54:50 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:50 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:50 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:50 --> URI Class Initialized
INFO - 2020-10-28 07:54:50 --> Router Class Initialized
INFO - 2020-10-28 07:54:50 --> Output Class Initialized
INFO - 2020-10-28 07:54:50 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:50 --> Input Class Initialized
INFO - 2020-10-28 07:54:50 --> Language Class Initialized
INFO - 2020-10-28 07:54:50 --> Language Class Initialized
INFO - 2020-10-28 07:54:50 --> Config Class Initialized
INFO - 2020-10-28 07:54:50 --> Loader Class Initialized
INFO - 2020-10-28 07:54:50 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:50 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:50 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:50 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:50 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:50 --> Controller Class Initialized
ERROR - 2020-10-28 07:54:50 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-28 07:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-28 07:54:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:50 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:50 --> Total execution time: 0.4040
INFO - 2020-10-28 07:54:57 --> Config Class Initialized
INFO - 2020-10-28 07:54:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:57 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:57 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:57 --> URI Class Initialized
INFO - 2020-10-28 07:54:57 --> Router Class Initialized
INFO - 2020-10-28 07:54:57 --> Output Class Initialized
INFO - 2020-10-28 07:54:57 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:57 --> Input Class Initialized
INFO - 2020-10-28 07:54:57 --> Language Class Initialized
INFO - 2020-10-28 07:54:57 --> Language Class Initialized
INFO - 2020-10-28 07:54:57 --> Config Class Initialized
INFO - 2020-10-28 07:54:57 --> Loader Class Initialized
INFO - 2020-10-28 07:54:57 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:57 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:57 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:57 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:57 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:57 --> Controller Class Initialized
DEBUG - 2020-10-28 07:54:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 07:54:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:54:57 --> Final output sent to browser
DEBUG - 2020-10-28 07:54:57 --> Total execution time: 0.3433
INFO - 2020-10-28 07:54:57 --> Config Class Initialized
INFO - 2020-10-28 07:54:57 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:54:58 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:54:58 --> Utf8 Class Initialized
INFO - 2020-10-28 07:54:58 --> URI Class Initialized
INFO - 2020-10-28 07:54:58 --> Router Class Initialized
INFO - 2020-10-28 07:54:58 --> Output Class Initialized
INFO - 2020-10-28 07:54:58 --> Security Class Initialized
DEBUG - 2020-10-28 07:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:54:58 --> Input Class Initialized
INFO - 2020-10-28 07:54:58 --> Language Class Initialized
INFO - 2020-10-28 07:54:58 --> Language Class Initialized
INFO - 2020-10-28 07:54:58 --> Config Class Initialized
INFO - 2020-10-28 07:54:58 --> Loader Class Initialized
INFO - 2020-10-28 07:54:58 --> Helper loaded: url_helper
INFO - 2020-10-28 07:54:58 --> Helper loaded: file_helper
INFO - 2020-10-28 07:54:58 --> Helper loaded: form_helper
INFO - 2020-10-28 07:54:58 --> Helper loaded: my_helper
INFO - 2020-10-28 07:54:58 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:54:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:54:58 --> Controller Class Initialized
INFO - 2020-10-28 07:55:19 --> Config Class Initialized
INFO - 2020-10-28 07:55:19 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:55:19 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:55:19 --> Utf8 Class Initialized
INFO - 2020-10-28 07:55:19 --> URI Class Initialized
INFO - 2020-10-28 07:55:19 --> Router Class Initialized
INFO - 2020-10-28 07:55:19 --> Output Class Initialized
INFO - 2020-10-28 07:55:19 --> Security Class Initialized
DEBUG - 2020-10-28 07:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:55:19 --> Input Class Initialized
INFO - 2020-10-28 07:55:19 --> Language Class Initialized
INFO - 2020-10-28 07:55:20 --> Language Class Initialized
INFO - 2020-10-28 07:55:20 --> Config Class Initialized
INFO - 2020-10-28 07:55:20 --> Loader Class Initialized
INFO - 2020-10-28 07:55:20 --> Helper loaded: url_helper
INFO - 2020-10-28 07:55:20 --> Helper loaded: file_helper
INFO - 2020-10-28 07:55:20 --> Helper loaded: form_helper
INFO - 2020-10-28 07:55:20 --> Helper loaded: my_helper
INFO - 2020-10-28 07:55:20 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:55:20 --> Controller Class Initialized
ERROR - 2020-10-28 07:55:20 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-28 07:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-28 07:55:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:55:20 --> Final output sent to browser
DEBUG - 2020-10-28 07:55:20 --> Total execution time: 0.3679
INFO - 2020-10-28 07:56:40 --> Config Class Initialized
INFO - 2020-10-28 07:56:40 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:56:40 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:56:40 --> Utf8 Class Initialized
INFO - 2020-10-28 07:56:40 --> URI Class Initialized
INFO - 2020-10-28 07:56:40 --> Router Class Initialized
INFO - 2020-10-28 07:56:40 --> Output Class Initialized
INFO - 2020-10-28 07:56:40 --> Security Class Initialized
DEBUG - 2020-10-28 07:56:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:56:40 --> Input Class Initialized
INFO - 2020-10-28 07:56:40 --> Language Class Initialized
INFO - 2020-10-28 07:56:40 --> Language Class Initialized
INFO - 2020-10-28 07:56:40 --> Config Class Initialized
INFO - 2020-10-28 07:56:40 --> Loader Class Initialized
INFO - 2020-10-28 07:56:40 --> Helper loaded: url_helper
INFO - 2020-10-28 07:56:40 --> Helper loaded: file_helper
INFO - 2020-10-28 07:56:40 --> Helper loaded: form_helper
INFO - 2020-10-28 07:56:40 --> Helper loaded: my_helper
INFO - 2020-10-28 07:56:40 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:56:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:56:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:56:40 --> Controller Class Initialized
INFO - 2020-10-28 07:56:42 --> Upload Class Initialized
INFO - 2020-10-28 07:56:42 --> Language file loaded: language/english/upload_lang.php
ERROR - 2020-10-28 07:56:42 --> The upload path does not appear to be valid.
INFO - 2020-10-28 07:56:42 --> Config Class Initialized
INFO - 2020-10-28 07:56:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:56:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:56:42 --> Utf8 Class Initialized
INFO - 2020-10-28 07:56:42 --> URI Class Initialized
INFO - 2020-10-28 07:56:42 --> Router Class Initialized
INFO - 2020-10-28 07:56:42 --> Output Class Initialized
INFO - 2020-10-28 07:56:42 --> Security Class Initialized
DEBUG - 2020-10-28 07:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:56:42 --> Input Class Initialized
INFO - 2020-10-28 07:56:42 --> Language Class Initialized
INFO - 2020-10-28 07:56:42 --> Language Class Initialized
INFO - 2020-10-28 07:56:42 --> Config Class Initialized
INFO - 2020-10-28 07:56:42 --> Loader Class Initialized
INFO - 2020-10-28 07:56:42 --> Helper loaded: url_helper
INFO - 2020-10-28 07:56:42 --> Helper loaded: file_helper
INFO - 2020-10-28 07:56:42 --> Helper loaded: form_helper
INFO - 2020-10-28 07:56:42 --> Helper loaded: my_helper
INFO - 2020-10-28 07:56:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:56:42 --> Controller Class Initialized
DEBUG - 2020-10-28 07:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 07:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:56:42 --> Final output sent to browser
DEBUG - 2020-10-28 07:56:42 --> Total execution time: 0.3855
INFO - 2020-10-28 07:56:42 --> Config Class Initialized
INFO - 2020-10-28 07:56:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:56:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:56:42 --> Utf8 Class Initialized
INFO - 2020-10-28 07:56:42 --> URI Class Initialized
INFO - 2020-10-28 07:56:42 --> Router Class Initialized
INFO - 2020-10-28 07:56:42 --> Output Class Initialized
INFO - 2020-10-28 07:56:42 --> Security Class Initialized
DEBUG - 2020-10-28 07:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:56:42 --> Input Class Initialized
INFO - 2020-10-28 07:56:42 --> Language Class Initialized
INFO - 2020-10-28 07:56:42 --> Language Class Initialized
INFO - 2020-10-28 07:56:42 --> Config Class Initialized
INFO - 2020-10-28 07:56:42 --> Loader Class Initialized
INFO - 2020-10-28 07:56:43 --> Helper loaded: url_helper
INFO - 2020-10-28 07:56:43 --> Helper loaded: file_helper
INFO - 2020-10-28 07:56:43 --> Helper loaded: form_helper
INFO - 2020-10-28 07:56:43 --> Helper loaded: my_helper
INFO - 2020-10-28 07:56:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:56:43 --> Controller Class Initialized
INFO - 2020-10-28 07:56:46 --> Config Class Initialized
INFO - 2020-10-28 07:56:46 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:56:46 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:56:46 --> Utf8 Class Initialized
INFO - 2020-10-28 07:56:46 --> URI Class Initialized
INFO - 2020-10-28 07:56:46 --> Router Class Initialized
INFO - 2020-10-28 07:56:46 --> Output Class Initialized
INFO - 2020-10-28 07:56:46 --> Security Class Initialized
DEBUG - 2020-10-28 07:56:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:56:46 --> Input Class Initialized
INFO - 2020-10-28 07:56:46 --> Language Class Initialized
INFO - 2020-10-28 07:56:46 --> Language Class Initialized
INFO - 2020-10-28 07:56:46 --> Config Class Initialized
INFO - 2020-10-28 07:56:46 --> Loader Class Initialized
INFO - 2020-10-28 07:56:46 --> Helper loaded: url_helper
INFO - 2020-10-28 07:56:46 --> Helper loaded: file_helper
INFO - 2020-10-28 07:56:46 --> Helper loaded: form_helper
INFO - 2020-10-28 07:56:46 --> Helper loaded: my_helper
INFO - 2020-10-28 07:56:46 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:56:46 --> Controller Class Initialized
DEBUG - 2020-10-28 07:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:56:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:56:46 --> Final output sent to browser
DEBUG - 2020-10-28 07:56:46 --> Total execution time: 0.3819
INFO - 2020-10-28 07:56:47 --> Config Class Initialized
INFO - 2020-10-28 07:56:47 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:56:47 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:56:47 --> Utf8 Class Initialized
INFO - 2020-10-28 07:56:47 --> URI Class Initialized
INFO - 2020-10-28 07:56:47 --> Router Class Initialized
INFO - 2020-10-28 07:56:47 --> Output Class Initialized
INFO - 2020-10-28 07:56:47 --> Security Class Initialized
DEBUG - 2020-10-28 07:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:56:47 --> Input Class Initialized
INFO - 2020-10-28 07:56:47 --> Language Class Initialized
INFO - 2020-10-28 07:56:47 --> Language Class Initialized
INFO - 2020-10-28 07:56:47 --> Config Class Initialized
INFO - 2020-10-28 07:56:47 --> Loader Class Initialized
INFO - 2020-10-28 07:56:47 --> Helper loaded: url_helper
INFO - 2020-10-28 07:56:47 --> Helper loaded: file_helper
INFO - 2020-10-28 07:56:47 --> Helper loaded: form_helper
INFO - 2020-10-28 07:56:47 --> Helper loaded: my_helper
INFO - 2020-10-28 07:56:47 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:56:47 --> Controller Class Initialized
DEBUG - 2020-10-28 07:56:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 07:56:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:56:47 --> Final output sent to browser
DEBUG - 2020-10-28 07:56:47 --> Total execution time: 0.3464
INFO - 2020-10-28 07:57:05 --> Config Class Initialized
INFO - 2020-10-28 07:57:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:57:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:57:05 --> Utf8 Class Initialized
INFO - 2020-10-28 07:57:05 --> URI Class Initialized
INFO - 2020-10-28 07:57:05 --> Router Class Initialized
INFO - 2020-10-28 07:57:05 --> Output Class Initialized
INFO - 2020-10-28 07:57:05 --> Security Class Initialized
DEBUG - 2020-10-28 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:57:05 --> Input Class Initialized
INFO - 2020-10-28 07:57:05 --> Language Class Initialized
INFO - 2020-10-28 07:57:05 --> Language Class Initialized
INFO - 2020-10-28 07:57:05 --> Config Class Initialized
INFO - 2020-10-28 07:57:05 --> Loader Class Initialized
INFO - 2020-10-28 07:57:05 --> Helper loaded: url_helper
INFO - 2020-10-28 07:57:05 --> Helper loaded: file_helper
INFO - 2020-10-28 07:57:05 --> Helper loaded: form_helper
INFO - 2020-10-28 07:57:05 --> Helper loaded: my_helper
INFO - 2020-10-28 07:57:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:57:05 --> Controller Class Initialized
INFO - 2020-10-28 07:57:05 --> Config Class Initialized
INFO - 2020-10-28 07:57:05 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:57:05 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:57:05 --> Utf8 Class Initialized
INFO - 2020-10-28 07:57:05 --> URI Class Initialized
INFO - 2020-10-28 07:57:05 --> Router Class Initialized
INFO - 2020-10-28 07:57:05 --> Output Class Initialized
INFO - 2020-10-28 07:57:05 --> Security Class Initialized
DEBUG - 2020-10-28 07:57:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:57:05 --> Input Class Initialized
INFO - 2020-10-28 07:57:05 --> Language Class Initialized
INFO - 2020-10-28 07:57:05 --> Language Class Initialized
INFO - 2020-10-28 07:57:05 --> Config Class Initialized
INFO - 2020-10-28 07:57:05 --> Loader Class Initialized
INFO - 2020-10-28 07:57:05 --> Helper loaded: url_helper
INFO - 2020-10-28 07:57:05 --> Helper loaded: file_helper
INFO - 2020-10-28 07:57:05 --> Helper loaded: form_helper
INFO - 2020-10-28 07:57:05 --> Helper loaded: my_helper
INFO - 2020-10-28 07:57:05 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:57:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:57:05 --> Controller Class Initialized
DEBUG - 2020-10-28 07:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 07:57:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:57:05 --> Final output sent to browser
DEBUG - 2020-10-28 07:57:05 --> Total execution time: 0.3582
INFO - 2020-10-28 07:58:17 --> Config Class Initialized
INFO - 2020-10-28 07:58:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:58:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:58:17 --> Utf8 Class Initialized
INFO - 2020-10-28 07:58:17 --> URI Class Initialized
INFO - 2020-10-28 07:58:17 --> Router Class Initialized
INFO - 2020-10-28 07:58:17 --> Output Class Initialized
INFO - 2020-10-28 07:58:17 --> Security Class Initialized
DEBUG - 2020-10-28 07:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:58:17 --> Input Class Initialized
INFO - 2020-10-28 07:58:17 --> Language Class Initialized
INFO - 2020-10-28 07:58:17 --> Language Class Initialized
INFO - 2020-10-28 07:58:17 --> Config Class Initialized
INFO - 2020-10-28 07:58:17 --> Loader Class Initialized
INFO - 2020-10-28 07:58:17 --> Helper loaded: url_helper
INFO - 2020-10-28 07:58:17 --> Helper loaded: file_helper
INFO - 2020-10-28 07:58:17 --> Helper loaded: form_helper
INFO - 2020-10-28 07:58:17 --> Helper loaded: my_helper
INFO - 2020-10-28 07:58:17 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:58:17 --> Controller Class Initialized
DEBUG - 2020-10-28 07:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 07:58:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:58:17 --> Final output sent to browser
DEBUG - 2020-10-28 07:58:17 --> Total execution time: 0.3579
INFO - 2020-10-28 07:58:17 --> Config Class Initialized
INFO - 2020-10-28 07:58:17 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:58:17 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:58:17 --> Utf8 Class Initialized
INFO - 2020-10-28 07:58:17 --> URI Class Initialized
INFO - 2020-10-28 07:58:17 --> Router Class Initialized
INFO - 2020-10-28 07:58:17 --> Output Class Initialized
INFO - 2020-10-28 07:58:17 --> Security Class Initialized
DEBUG - 2020-10-28 07:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:58:18 --> Input Class Initialized
INFO - 2020-10-28 07:58:18 --> Language Class Initialized
INFO - 2020-10-28 07:58:18 --> Language Class Initialized
INFO - 2020-10-28 07:58:18 --> Config Class Initialized
INFO - 2020-10-28 07:58:18 --> Loader Class Initialized
INFO - 2020-10-28 07:58:18 --> Helper loaded: url_helper
INFO - 2020-10-28 07:58:18 --> Helper loaded: file_helper
INFO - 2020-10-28 07:58:18 --> Helper loaded: form_helper
INFO - 2020-10-28 07:58:18 --> Helper loaded: my_helper
INFO - 2020-10-28 07:58:18 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:58:18 --> Controller Class Initialized
INFO - 2020-10-28 07:58:18 --> Config Class Initialized
INFO - 2020-10-28 07:58:18 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:58:18 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:58:18 --> Utf8 Class Initialized
INFO - 2020-10-28 07:58:18 --> URI Class Initialized
INFO - 2020-10-28 07:58:18 --> Router Class Initialized
INFO - 2020-10-28 07:58:18 --> Output Class Initialized
INFO - 2020-10-28 07:58:18 --> Security Class Initialized
DEBUG - 2020-10-28 07:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:58:19 --> Input Class Initialized
INFO - 2020-10-28 07:58:19 --> Language Class Initialized
INFO - 2020-10-28 07:58:19 --> Language Class Initialized
INFO - 2020-10-28 07:58:19 --> Config Class Initialized
INFO - 2020-10-28 07:58:19 --> Loader Class Initialized
INFO - 2020-10-28 07:58:19 --> Helper loaded: url_helper
INFO - 2020-10-28 07:58:19 --> Helper loaded: file_helper
INFO - 2020-10-28 07:58:19 --> Helper loaded: form_helper
INFO - 2020-10-28 07:58:19 --> Helper loaded: my_helper
INFO - 2020-10-28 07:58:19 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:58:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:58:19 --> Controller Class Initialized
DEBUG - 2020-10-28 07:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2020-10-28 07:58:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:58:19 --> Final output sent to browser
DEBUG - 2020-10-28 07:58:19 --> Total execution time: 0.3750
INFO - 2020-10-28 07:58:39 --> Config Class Initialized
INFO - 2020-10-28 07:58:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:58:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:58:39 --> Utf8 Class Initialized
INFO - 2020-10-28 07:58:39 --> URI Class Initialized
INFO - 2020-10-28 07:58:39 --> Router Class Initialized
INFO - 2020-10-28 07:58:39 --> Output Class Initialized
INFO - 2020-10-28 07:58:39 --> Security Class Initialized
DEBUG - 2020-10-28 07:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:58:39 --> Input Class Initialized
INFO - 2020-10-28 07:58:39 --> Language Class Initialized
INFO - 2020-10-28 07:58:39 --> Language Class Initialized
INFO - 2020-10-28 07:58:39 --> Config Class Initialized
INFO - 2020-10-28 07:58:39 --> Loader Class Initialized
INFO - 2020-10-28 07:58:39 --> Helper loaded: url_helper
INFO - 2020-10-28 07:58:39 --> Helper loaded: file_helper
INFO - 2020-10-28 07:58:39 --> Helper loaded: form_helper
INFO - 2020-10-28 07:58:39 --> Helper loaded: my_helper
INFO - 2020-10-28 07:58:39 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:58:39 --> Controller Class Initialized
INFO - 2020-10-28 07:58:39 --> Config Class Initialized
INFO - 2020-10-28 07:58:39 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:58:39 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:58:39 --> Utf8 Class Initialized
INFO - 2020-10-28 07:58:39 --> URI Class Initialized
INFO - 2020-10-28 07:58:39 --> Router Class Initialized
INFO - 2020-10-28 07:58:39 --> Output Class Initialized
INFO - 2020-10-28 07:58:40 --> Security Class Initialized
DEBUG - 2020-10-28 07:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:58:40 --> Input Class Initialized
INFO - 2020-10-28 07:58:40 --> Language Class Initialized
INFO - 2020-10-28 07:58:40 --> Language Class Initialized
INFO - 2020-10-28 07:58:40 --> Config Class Initialized
INFO - 2020-10-28 07:58:40 --> Loader Class Initialized
INFO - 2020-10-28 07:58:40 --> Helper loaded: url_helper
INFO - 2020-10-28 07:58:40 --> Helper loaded: file_helper
INFO - 2020-10-28 07:58:40 --> Helper loaded: form_helper
INFO - 2020-10-28 07:58:40 --> Helper loaded: my_helper
INFO - 2020-10-28 07:58:40 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:58:40 --> Controller Class Initialized
DEBUG - 2020-10-28 07:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 07:58:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 07:58:40 --> Final output sent to browser
DEBUG - 2020-10-28 07:58:40 --> Total execution time: 0.3501
INFO - 2020-10-28 07:58:40 --> Config Class Initialized
INFO - 2020-10-28 07:58:40 --> Hooks Class Initialized
DEBUG - 2020-10-28 07:58:40 --> UTF-8 Support Enabled
INFO - 2020-10-28 07:58:40 --> Utf8 Class Initialized
INFO - 2020-10-28 07:58:40 --> URI Class Initialized
INFO - 2020-10-28 07:58:40 --> Router Class Initialized
INFO - 2020-10-28 07:58:40 --> Output Class Initialized
INFO - 2020-10-28 07:58:40 --> Security Class Initialized
DEBUG - 2020-10-28 07:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 07:58:40 --> Input Class Initialized
INFO - 2020-10-28 07:58:40 --> Language Class Initialized
INFO - 2020-10-28 07:58:40 --> Language Class Initialized
INFO - 2020-10-28 07:58:40 --> Config Class Initialized
INFO - 2020-10-28 07:58:40 --> Loader Class Initialized
INFO - 2020-10-28 07:58:40 --> Helper loaded: url_helper
INFO - 2020-10-28 07:58:40 --> Helper loaded: file_helper
INFO - 2020-10-28 07:58:40 --> Helper loaded: form_helper
INFO - 2020-10-28 07:58:40 --> Helper loaded: my_helper
INFO - 2020-10-28 07:58:40 --> Database Driver Class Initialized
DEBUG - 2020-10-28 07:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 07:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 07:58:40 --> Controller Class Initialized
INFO - 2020-10-28 08:04:51 --> Config Class Initialized
INFO - 2020-10-28 08:04:51 --> Hooks Class Initialized
DEBUG - 2020-10-28 08:04:51 --> UTF-8 Support Enabled
INFO - 2020-10-28 08:04:51 --> Utf8 Class Initialized
INFO - 2020-10-28 08:04:51 --> URI Class Initialized
INFO - 2020-10-28 08:04:51 --> Router Class Initialized
INFO - 2020-10-28 08:04:51 --> Output Class Initialized
INFO - 2020-10-28 08:04:51 --> Security Class Initialized
DEBUG - 2020-10-28 08:04:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 08:04:51 --> Input Class Initialized
INFO - 2020-10-28 08:04:51 --> Language Class Initialized
INFO - 2020-10-28 08:04:51 --> Language Class Initialized
INFO - 2020-10-28 08:04:51 --> Config Class Initialized
INFO - 2020-10-28 08:04:51 --> Loader Class Initialized
INFO - 2020-10-28 08:04:51 --> Helper loaded: url_helper
INFO - 2020-10-28 08:04:51 --> Helper loaded: file_helper
INFO - 2020-10-28 08:04:51 --> Helper loaded: form_helper
INFO - 2020-10-28 08:04:51 --> Helper loaded: my_helper
INFO - 2020-10-28 08:04:51 --> Database Driver Class Initialized
DEBUG - 2020-10-28 08:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 08:04:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 08:04:52 --> Controller Class Initialized
DEBUG - 2020-10-28 08:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 08:04:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 08:04:52 --> Final output sent to browser
DEBUG - 2020-10-28 08:04:52 --> Total execution time: 0.3428
INFO - 2020-10-28 08:34:24 --> Config Class Initialized
INFO - 2020-10-28 08:34:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 08:34:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 08:34:24 --> Utf8 Class Initialized
INFO - 2020-10-28 08:34:24 --> URI Class Initialized
INFO - 2020-10-28 08:34:24 --> Router Class Initialized
INFO - 2020-10-28 08:34:24 --> Output Class Initialized
INFO - 2020-10-28 08:34:24 --> Security Class Initialized
DEBUG - 2020-10-28 08:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 08:34:24 --> Input Class Initialized
INFO - 2020-10-28 08:34:24 --> Language Class Initialized
INFO - 2020-10-28 08:34:24 --> Language Class Initialized
INFO - 2020-10-28 08:34:24 --> Config Class Initialized
INFO - 2020-10-28 08:34:24 --> Loader Class Initialized
INFO - 2020-10-28 08:34:24 --> Helper loaded: url_helper
INFO - 2020-10-28 08:34:24 --> Helper loaded: file_helper
INFO - 2020-10-28 08:34:24 --> Helper loaded: form_helper
INFO - 2020-10-28 08:34:24 --> Helper loaded: my_helper
INFO - 2020-10-28 08:34:24 --> Database Driver Class Initialized
DEBUG - 2020-10-28 08:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 08:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 08:34:24 --> Controller Class Initialized
DEBUG - 2020-10-28 08:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 08:34:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 08:34:24 --> Final output sent to browser
DEBUG - 2020-10-28 08:34:24 --> Total execution time: 0.3479
INFO - 2020-10-28 08:34:24 --> Config Class Initialized
INFO - 2020-10-28 08:34:24 --> Hooks Class Initialized
DEBUG - 2020-10-28 08:34:24 --> UTF-8 Support Enabled
INFO - 2020-10-28 08:34:24 --> Utf8 Class Initialized
INFO - 2020-10-28 08:34:24 --> URI Class Initialized
INFO - 2020-10-28 08:34:24 --> Router Class Initialized
INFO - 2020-10-28 08:34:24 --> Output Class Initialized
INFO - 2020-10-28 08:34:24 --> Security Class Initialized
DEBUG - 2020-10-28 08:34:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 08:34:24 --> Input Class Initialized
INFO - 2020-10-28 08:34:24 --> Language Class Initialized
INFO - 2020-10-28 08:34:24 --> Language Class Initialized
INFO - 2020-10-28 08:34:24 --> Config Class Initialized
INFO - 2020-10-28 08:34:24 --> Loader Class Initialized
INFO - 2020-10-28 08:34:24 --> Helper loaded: url_helper
INFO - 2020-10-28 08:34:24 --> Helper loaded: file_helper
INFO - 2020-10-28 08:34:24 --> Helper loaded: form_helper
INFO - 2020-10-28 08:34:24 --> Helper loaded: my_helper
INFO - 2020-10-28 08:34:24 --> Database Driver Class Initialized
DEBUG - 2020-10-28 08:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 08:34:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 08:34:24 --> Controller Class Initialized
INFO - 2020-10-28 09:05:51 --> Config Class Initialized
INFO - 2020-10-28 09:05:51 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:05:51 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:05:51 --> Utf8 Class Initialized
INFO - 2020-10-28 09:05:51 --> URI Class Initialized
INFO - 2020-10-28 09:05:51 --> Router Class Initialized
INFO - 2020-10-28 09:05:51 --> Output Class Initialized
INFO - 2020-10-28 09:05:51 --> Security Class Initialized
DEBUG - 2020-10-28 09:05:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:05:51 --> Input Class Initialized
INFO - 2020-10-28 09:05:52 --> Language Class Initialized
INFO - 2020-10-28 09:05:52 --> Language Class Initialized
INFO - 2020-10-28 09:05:52 --> Config Class Initialized
INFO - 2020-10-28 09:05:52 --> Loader Class Initialized
INFO - 2020-10-28 09:05:52 --> Helper loaded: url_helper
INFO - 2020-10-28 09:05:52 --> Helper loaded: file_helper
INFO - 2020-10-28 09:05:52 --> Helper loaded: form_helper
INFO - 2020-10-28 09:05:52 --> Helper loaded: my_helper
INFO - 2020-10-28 09:05:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:05:52 --> Controller Class Initialized
DEBUG - 2020-10-28 09:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 09:05:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:05:52 --> Final output sent to browser
DEBUG - 2020-10-28 09:05:52 --> Total execution time: 0.3346
INFO - 2020-10-28 09:05:52 --> Config Class Initialized
INFO - 2020-10-28 09:05:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:05:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:05:52 --> Utf8 Class Initialized
INFO - 2020-10-28 09:05:52 --> URI Class Initialized
INFO - 2020-10-28 09:05:52 --> Router Class Initialized
INFO - 2020-10-28 09:05:52 --> Output Class Initialized
INFO - 2020-10-28 09:05:52 --> Security Class Initialized
DEBUG - 2020-10-28 09:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:05:52 --> Input Class Initialized
INFO - 2020-10-28 09:05:52 --> Language Class Initialized
INFO - 2020-10-28 09:05:52 --> Language Class Initialized
INFO - 2020-10-28 09:05:52 --> Config Class Initialized
INFO - 2020-10-28 09:05:52 --> Loader Class Initialized
INFO - 2020-10-28 09:05:52 --> Helper loaded: url_helper
INFO - 2020-10-28 09:05:52 --> Helper loaded: file_helper
INFO - 2020-10-28 09:05:52 --> Helper loaded: form_helper
INFO - 2020-10-28 09:05:52 --> Helper loaded: my_helper
INFO - 2020-10-28 09:05:52 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:05:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:05:52 --> Controller Class Initialized
INFO - 2020-10-28 09:05:52 --> Config Class Initialized
INFO - 2020-10-28 09:05:52 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:05:52 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:05:52 --> Utf8 Class Initialized
INFO - 2020-10-28 09:05:52 --> URI Class Initialized
INFO - 2020-10-28 09:05:52 --> Router Class Initialized
INFO - 2020-10-28 09:05:52 --> Output Class Initialized
INFO - 2020-10-28 09:05:52 --> Security Class Initialized
DEBUG - 2020-10-28 09:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:05:52 --> Input Class Initialized
INFO - 2020-10-28 09:05:52 --> Language Class Initialized
INFO - 2020-10-28 09:05:52 --> Language Class Initialized
INFO - 2020-10-28 09:05:52 --> Config Class Initialized
INFO - 2020-10-28 09:05:52 --> Loader Class Initialized
INFO - 2020-10-28 09:05:53 --> Helper loaded: url_helper
INFO - 2020-10-28 09:05:53 --> Helper loaded: file_helper
INFO - 2020-10-28 09:05:53 --> Helper loaded: form_helper
INFO - 2020-10-28 09:05:53 --> Helper loaded: my_helper
INFO - 2020-10-28 09:05:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:05:53 --> Controller Class Initialized
DEBUG - 2020-10-28 09:05:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2020-10-28 09:05:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:05:53 --> Final output sent to browser
DEBUG - 2020-10-28 09:05:53 --> Total execution time: 0.3744
INFO - 2020-10-28 09:05:53 --> Config Class Initialized
INFO - 2020-10-28 09:05:53 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:05:53 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:05:53 --> Utf8 Class Initialized
INFO - 2020-10-28 09:05:53 --> URI Class Initialized
INFO - 2020-10-28 09:05:53 --> Router Class Initialized
INFO - 2020-10-28 09:05:53 --> Output Class Initialized
INFO - 2020-10-28 09:05:53 --> Security Class Initialized
DEBUG - 2020-10-28 09:05:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:05:53 --> Input Class Initialized
INFO - 2020-10-28 09:05:53 --> Language Class Initialized
INFO - 2020-10-28 09:05:53 --> Language Class Initialized
INFO - 2020-10-28 09:05:53 --> Config Class Initialized
INFO - 2020-10-28 09:05:53 --> Loader Class Initialized
INFO - 2020-10-28 09:05:53 --> Helper loaded: url_helper
INFO - 2020-10-28 09:05:53 --> Helper loaded: file_helper
INFO - 2020-10-28 09:05:53 --> Helper loaded: form_helper
INFO - 2020-10-28 09:05:53 --> Helper loaded: my_helper
INFO - 2020-10-28 09:05:53 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:05:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:05:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:05:53 --> Controller Class Initialized
INFO - 2020-10-28 09:50:27 --> Config Class Initialized
INFO - 2020-10-28 09:50:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:27 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:27 --> URI Class Initialized
INFO - 2020-10-28 09:50:27 --> Router Class Initialized
INFO - 2020-10-28 09:50:27 --> Output Class Initialized
INFO - 2020-10-28 09:50:27 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:27 --> Input Class Initialized
INFO - 2020-10-28 09:50:27 --> Language Class Initialized
INFO - 2020-10-28 09:50:27 --> Language Class Initialized
INFO - 2020-10-28 09:50:27 --> Config Class Initialized
INFO - 2020-10-28 09:50:27 --> Loader Class Initialized
INFO - 2020-10-28 09:50:27 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:27 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:27 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:27 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:27 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 09:50:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:27 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:27 --> Total execution time: 0.4115
INFO - 2020-10-28 09:50:28 --> Config Class Initialized
INFO - 2020-10-28 09:50:28 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:28 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:28 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:28 --> URI Class Initialized
INFO - 2020-10-28 09:50:28 --> Router Class Initialized
INFO - 2020-10-28 09:50:28 --> Output Class Initialized
INFO - 2020-10-28 09:50:28 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:28 --> Input Class Initialized
INFO - 2020-10-28 09:50:28 --> Language Class Initialized
INFO - 2020-10-28 09:50:28 --> Language Class Initialized
INFO - 2020-10-28 09:50:28 --> Config Class Initialized
INFO - 2020-10-28 09:50:28 --> Loader Class Initialized
INFO - 2020-10-28 09:50:28 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:28 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:28 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:28 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:28 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:28 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 09:50:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:28 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:28 --> Total execution time: 0.3689
INFO - 2020-10-28 09:50:29 --> Config Class Initialized
INFO - 2020-10-28 09:50:29 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:29 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:29 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:29 --> URI Class Initialized
INFO - 2020-10-28 09:50:29 --> Router Class Initialized
INFO - 2020-10-28 09:50:29 --> Output Class Initialized
INFO - 2020-10-28 09:50:29 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:29 --> Input Class Initialized
INFO - 2020-10-28 09:50:29 --> Language Class Initialized
INFO - 2020-10-28 09:50:29 --> Language Class Initialized
INFO - 2020-10-28 09:50:29 --> Config Class Initialized
INFO - 2020-10-28 09:50:29 --> Loader Class Initialized
INFO - 2020-10-28 09:50:29 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:29 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:29 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:29 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:29 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:29 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 09:50:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:29 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:29 --> Total execution time: 0.3661
INFO - 2020-10-28 09:50:32 --> Config Class Initialized
INFO - 2020-10-28 09:50:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:32 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:32 --> URI Class Initialized
INFO - 2020-10-28 09:50:32 --> Router Class Initialized
INFO - 2020-10-28 09:50:32 --> Output Class Initialized
INFO - 2020-10-28 09:50:32 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:32 --> Input Class Initialized
INFO - 2020-10-28 09:50:32 --> Language Class Initialized
INFO - 2020-10-28 09:50:32 --> Language Class Initialized
INFO - 2020-10-28 09:50:32 --> Config Class Initialized
INFO - 2020-10-28 09:50:32 --> Loader Class Initialized
INFO - 2020-10-28 09:50:32 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:32 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:32 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:32 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:32 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:32 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 09:50:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:32 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:32 --> Total execution time: 0.3772
INFO - 2020-10-28 09:50:32 --> Config Class Initialized
INFO - 2020-10-28 09:50:32 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:32 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:32 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:32 --> URI Class Initialized
INFO - 2020-10-28 09:50:32 --> Router Class Initialized
INFO - 2020-10-28 09:50:32 --> Output Class Initialized
INFO - 2020-10-28 09:50:32 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:32 --> Input Class Initialized
INFO - 2020-10-28 09:50:32 --> Language Class Initialized
INFO - 2020-10-28 09:50:32 --> Language Class Initialized
INFO - 2020-10-28 09:50:32 --> Config Class Initialized
INFO - 2020-10-28 09:50:32 --> Loader Class Initialized
INFO - 2020-10-28 09:50:32 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:32 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:32 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:32 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:33 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:33 --> Controller Class Initialized
INFO - 2020-10-28 09:50:42 --> Config Class Initialized
INFO - 2020-10-28 09:50:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:42 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:42 --> URI Class Initialized
INFO - 2020-10-28 09:50:42 --> Router Class Initialized
INFO - 2020-10-28 09:50:42 --> Output Class Initialized
INFO - 2020-10-28 09:50:42 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:42 --> Input Class Initialized
INFO - 2020-10-28 09:50:42 --> Language Class Initialized
INFO - 2020-10-28 09:50:42 --> Language Class Initialized
INFO - 2020-10-28 09:50:42 --> Config Class Initialized
INFO - 2020-10-28 09:50:42 --> Loader Class Initialized
INFO - 2020-10-28 09:50:42 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:42 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:42 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:42 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:42 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2020-10-28 09:50:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:42 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:42 --> Total execution time: 0.3661
INFO - 2020-10-28 09:50:42 --> Config Class Initialized
INFO - 2020-10-28 09:50:42 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:42 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:42 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:42 --> URI Class Initialized
INFO - 2020-10-28 09:50:42 --> Router Class Initialized
INFO - 2020-10-28 09:50:42 --> Output Class Initialized
INFO - 2020-10-28 09:50:42 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:42 --> Input Class Initialized
INFO - 2020-10-28 09:50:42 --> Language Class Initialized
INFO - 2020-10-28 09:50:42 --> Language Class Initialized
INFO - 2020-10-28 09:50:42 --> Config Class Initialized
INFO - 2020-10-28 09:50:42 --> Loader Class Initialized
INFO - 2020-10-28 09:50:42 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:42 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:42 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:42 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:42 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:42 --> Controller Class Initialized
INFO - 2020-10-28 09:50:43 --> Config Class Initialized
INFO - 2020-10-28 09:50:43 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:43 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:43 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:43 --> URI Class Initialized
INFO - 2020-10-28 09:50:43 --> Router Class Initialized
INFO - 2020-10-28 09:50:43 --> Output Class Initialized
INFO - 2020-10-28 09:50:43 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:43 --> Input Class Initialized
INFO - 2020-10-28 09:50:43 --> Language Class Initialized
INFO - 2020-10-28 09:50:43 --> Language Class Initialized
INFO - 2020-10-28 09:50:43 --> Config Class Initialized
INFO - 2020-10-28 09:50:43 --> Loader Class Initialized
INFO - 2020-10-28 09:50:43 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:43 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:43 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:43 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:43 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:43 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 09:50:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:44 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:44 --> Total execution time: 0.3582
INFO - 2020-10-28 09:50:44 --> Config Class Initialized
INFO - 2020-10-28 09:50:44 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:44 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:44 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:44 --> URI Class Initialized
INFO - 2020-10-28 09:50:44 --> Router Class Initialized
INFO - 2020-10-28 09:50:44 --> Output Class Initialized
INFO - 2020-10-28 09:50:45 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:45 --> Input Class Initialized
INFO - 2020-10-28 09:50:45 --> Language Class Initialized
INFO - 2020-10-28 09:50:45 --> Language Class Initialized
INFO - 2020-10-28 09:50:45 --> Config Class Initialized
INFO - 2020-10-28 09:50:45 --> Loader Class Initialized
INFO - 2020-10-28 09:50:45 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:45 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:45 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:45 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:45 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:45 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 09:50:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:45 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:45 --> Total execution time: 0.3736
INFO - 2020-10-28 09:50:59 --> Config Class Initialized
INFO - 2020-10-28 09:50:59 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:50:59 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:50:59 --> Utf8 Class Initialized
INFO - 2020-10-28 09:50:59 --> URI Class Initialized
INFO - 2020-10-28 09:50:59 --> Router Class Initialized
INFO - 2020-10-28 09:50:59 --> Output Class Initialized
INFO - 2020-10-28 09:50:59 --> Security Class Initialized
DEBUG - 2020-10-28 09:50:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:50:59 --> Input Class Initialized
INFO - 2020-10-28 09:50:59 --> Language Class Initialized
INFO - 2020-10-28 09:50:59 --> Language Class Initialized
INFO - 2020-10-28 09:50:59 --> Config Class Initialized
INFO - 2020-10-28 09:50:59 --> Loader Class Initialized
INFO - 2020-10-28 09:50:59 --> Helper loaded: url_helper
INFO - 2020-10-28 09:50:59 --> Helper loaded: file_helper
INFO - 2020-10-28 09:50:59 --> Helper loaded: form_helper
INFO - 2020-10-28 09:50:59 --> Helper loaded: my_helper
INFO - 2020-10-28 09:50:59 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:50:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:50:59 --> Controller Class Initialized
DEBUG - 2020-10-28 09:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 09:50:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:50:59 --> Final output sent to browser
DEBUG - 2020-10-28 09:50:59 --> Total execution time: 0.3726
INFO - 2020-10-28 09:51:11 --> Config Class Initialized
INFO - 2020-10-28 09:51:11 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:11 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:11 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:11 --> URI Class Initialized
INFO - 2020-10-28 09:51:11 --> Router Class Initialized
INFO - 2020-10-28 09:51:11 --> Output Class Initialized
INFO - 2020-10-28 09:51:11 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:11 --> Input Class Initialized
INFO - 2020-10-28 09:51:11 --> Language Class Initialized
INFO - 2020-10-28 09:51:11 --> Language Class Initialized
INFO - 2020-10-28 09:51:11 --> Config Class Initialized
INFO - 2020-10-28 09:51:11 --> Loader Class Initialized
INFO - 2020-10-28 09:51:11 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:11 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:11 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:11 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:11 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:11 --> Controller Class Initialized
DEBUG - 2020-10-28 09:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2020-10-28 09:51:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:51:11 --> Final output sent to browser
DEBUG - 2020-10-28 09:51:11 --> Total execution time: 0.3652
INFO - 2020-10-28 09:51:12 --> Config Class Initialized
INFO - 2020-10-28 09:51:12 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:12 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:12 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:12 --> URI Class Initialized
INFO - 2020-10-28 09:51:12 --> Router Class Initialized
INFO - 2020-10-28 09:51:12 --> Output Class Initialized
INFO - 2020-10-28 09:51:12 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:12 --> Input Class Initialized
INFO - 2020-10-28 09:51:12 --> Language Class Initialized
INFO - 2020-10-28 09:51:12 --> Language Class Initialized
INFO - 2020-10-28 09:51:12 --> Config Class Initialized
INFO - 2020-10-28 09:51:12 --> Loader Class Initialized
INFO - 2020-10-28 09:51:12 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:12 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:12 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:12 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:12 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:12 --> Controller Class Initialized
INFO - 2020-10-28 09:51:13 --> Config Class Initialized
INFO - 2020-10-28 09:51:13 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:13 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:13 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:13 --> URI Class Initialized
INFO - 2020-10-28 09:51:13 --> Router Class Initialized
INFO - 2020-10-28 09:51:14 --> Output Class Initialized
INFO - 2020-10-28 09:51:14 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:14 --> Input Class Initialized
INFO - 2020-10-28 09:51:14 --> Language Class Initialized
INFO - 2020-10-28 09:51:14 --> Language Class Initialized
INFO - 2020-10-28 09:51:14 --> Config Class Initialized
INFO - 2020-10-28 09:51:14 --> Loader Class Initialized
INFO - 2020-10-28 09:51:14 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:14 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:14 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:14 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:14 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:14 --> Controller Class Initialized
ERROR - 2020-10-28 09:51:14 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 235
DEBUG - 2020-10-28 09:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2020-10-28 09:51:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:51:14 --> Final output sent to browser
DEBUG - 2020-10-28 09:51:14 --> Total execution time: 0.3996
INFO - 2020-10-28 09:51:27 --> Config Class Initialized
INFO - 2020-10-28 09:51:27 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:27 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:27 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:27 --> URI Class Initialized
INFO - 2020-10-28 09:51:27 --> Router Class Initialized
INFO - 2020-10-28 09:51:27 --> Output Class Initialized
INFO - 2020-10-28 09:51:27 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:27 --> Input Class Initialized
INFO - 2020-10-28 09:51:27 --> Language Class Initialized
INFO - 2020-10-28 09:51:27 --> Language Class Initialized
INFO - 2020-10-28 09:51:27 --> Config Class Initialized
INFO - 2020-10-28 09:51:27 --> Loader Class Initialized
INFO - 2020-10-28 09:51:27 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:27 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:27 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:27 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:27 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:27 --> Controller Class Initialized
DEBUG - 2020-10-28 09:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 09:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:51:27 --> Final output sent to browser
DEBUG - 2020-10-28 09:51:27 --> Total execution time: 0.3629
INFO - 2020-10-28 09:51:28 --> Config Class Initialized
INFO - 2020-10-28 09:51:28 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:28 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:28 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:28 --> URI Class Initialized
INFO - 2020-10-28 09:51:28 --> Router Class Initialized
INFO - 2020-10-28 09:51:28 --> Output Class Initialized
INFO - 2020-10-28 09:51:28 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:28 --> Input Class Initialized
INFO - 2020-10-28 09:51:28 --> Language Class Initialized
INFO - 2020-10-28 09:51:28 --> Language Class Initialized
INFO - 2020-10-28 09:51:28 --> Config Class Initialized
INFO - 2020-10-28 09:51:28 --> Loader Class Initialized
INFO - 2020-10-28 09:51:28 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:28 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:28 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:28 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:28 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:28 --> Controller Class Initialized
DEBUG - 2020-10-28 09:51:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 09:51:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:51:28 --> Final output sent to browser
DEBUG - 2020-10-28 09:51:28 --> Total execution time: 0.3760
INFO - 2020-10-28 09:51:36 --> Config Class Initialized
INFO - 2020-10-28 09:51:36 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:36 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:36 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:37 --> URI Class Initialized
INFO - 2020-10-28 09:51:37 --> Router Class Initialized
INFO - 2020-10-28 09:51:37 --> Output Class Initialized
INFO - 2020-10-28 09:51:37 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:37 --> Input Class Initialized
INFO - 2020-10-28 09:51:37 --> Language Class Initialized
INFO - 2020-10-28 09:51:37 --> Language Class Initialized
INFO - 2020-10-28 09:51:37 --> Config Class Initialized
INFO - 2020-10-28 09:51:37 --> Loader Class Initialized
INFO - 2020-10-28 09:51:37 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:37 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:37 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:37 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:37 --> Controller Class Initialized
INFO - 2020-10-28 09:51:37 --> Config Class Initialized
INFO - 2020-10-28 09:51:37 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:37 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:37 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:37 --> URI Class Initialized
INFO - 2020-10-28 09:51:37 --> Router Class Initialized
INFO - 2020-10-28 09:51:37 --> Output Class Initialized
INFO - 2020-10-28 09:51:37 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:37 --> Input Class Initialized
INFO - 2020-10-28 09:51:37 --> Language Class Initialized
INFO - 2020-10-28 09:51:37 --> Language Class Initialized
INFO - 2020-10-28 09:51:37 --> Config Class Initialized
INFO - 2020-10-28 09:51:37 --> Loader Class Initialized
INFO - 2020-10-28 09:51:37 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:37 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:37 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:37 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:37 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:37 --> Controller Class Initialized
DEBUG - 2020-10-28 09:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2020-10-28 09:51:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:51:37 --> Final output sent to browser
DEBUG - 2020-10-28 09:51:37 --> Total execution time: 0.3632
INFO - 2020-10-28 09:51:55 --> Config Class Initialized
INFO - 2020-10-28 09:51:55 --> Hooks Class Initialized
DEBUG - 2020-10-28 09:51:55 --> UTF-8 Support Enabled
INFO - 2020-10-28 09:51:55 --> Utf8 Class Initialized
INFO - 2020-10-28 09:51:55 --> URI Class Initialized
INFO - 2020-10-28 09:51:55 --> Router Class Initialized
INFO - 2020-10-28 09:51:55 --> Output Class Initialized
INFO - 2020-10-28 09:51:55 --> Security Class Initialized
DEBUG - 2020-10-28 09:51:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-28 09:51:55 --> Input Class Initialized
INFO - 2020-10-28 09:51:55 --> Language Class Initialized
INFO - 2020-10-28 09:51:55 --> Language Class Initialized
INFO - 2020-10-28 09:51:55 --> Config Class Initialized
INFO - 2020-10-28 09:51:55 --> Loader Class Initialized
INFO - 2020-10-28 09:51:55 --> Helper loaded: url_helper
INFO - 2020-10-28 09:51:55 --> Helper loaded: file_helper
INFO - 2020-10-28 09:51:55 --> Helper loaded: form_helper
INFO - 2020-10-28 09:51:55 --> Helper loaded: my_helper
INFO - 2020-10-28 09:51:55 --> Database Driver Class Initialized
DEBUG - 2020-10-28 09:51:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-28 09:51:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-28 09:51:55 --> Controller Class Initialized
DEBUG - 2020-10-28 09:51:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2020-10-28 09:51:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-28 09:51:55 --> Final output sent to browser
DEBUG - 2020-10-28 09:51:55 --> Total execution time: 0.3665
