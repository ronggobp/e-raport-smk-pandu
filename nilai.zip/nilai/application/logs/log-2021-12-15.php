<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-15 02:58:03 --> Config Class Initialized
INFO - 2021-12-15 02:58:03 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:03 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:03 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:03 --> URI Class Initialized
DEBUG - 2021-12-15 02:58:03 --> No URI present. Default controller set.
INFO - 2021-12-15 02:58:03 --> Router Class Initialized
INFO - 2021-12-15 02:58:03 --> Output Class Initialized
INFO - 2021-12-15 02:58:03 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:03 --> Input Class Initialized
INFO - 2021-12-15 02:58:03 --> Language Class Initialized
INFO - 2021-12-15 02:58:03 --> Language Class Initialized
INFO - 2021-12-15 02:58:03 --> Config Class Initialized
INFO - 2021-12-15 02:58:03 --> Loader Class Initialized
INFO - 2021-12-15 02:58:03 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:03 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:03 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:03 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:03 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:03 --> Controller Class Initialized
INFO - 2021-12-15 02:58:03 --> Config Class Initialized
INFO - 2021-12-15 02:58:03 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:03 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:03 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:03 --> URI Class Initialized
INFO - 2021-12-15 02:58:03 --> Router Class Initialized
INFO - 2021-12-15 02:58:03 --> Output Class Initialized
INFO - 2021-12-15 02:58:03 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:03 --> Input Class Initialized
INFO - 2021-12-15 02:58:03 --> Language Class Initialized
INFO - 2021-12-15 02:58:03 --> Language Class Initialized
INFO - 2021-12-15 02:58:03 --> Config Class Initialized
INFO - 2021-12-15 02:58:03 --> Loader Class Initialized
INFO - 2021-12-15 02:58:03 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:03 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:03 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:03 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:03 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:03 --> Controller Class Initialized
DEBUG - 2021-12-15 02:58:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-15 02:58:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 02:58:03 --> Final output sent to browser
DEBUG - 2021-12-15 02:58:03 --> Total execution time: 0.0370
INFO - 2021-12-15 02:58:11 --> Config Class Initialized
INFO - 2021-12-15 02:58:11 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:11 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:11 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:11 --> URI Class Initialized
INFO - 2021-12-15 02:58:11 --> Router Class Initialized
INFO - 2021-12-15 02:58:11 --> Output Class Initialized
INFO - 2021-12-15 02:58:11 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:11 --> Input Class Initialized
INFO - 2021-12-15 02:58:11 --> Language Class Initialized
INFO - 2021-12-15 02:58:11 --> Language Class Initialized
INFO - 2021-12-15 02:58:11 --> Config Class Initialized
INFO - 2021-12-15 02:58:11 --> Loader Class Initialized
INFO - 2021-12-15 02:58:11 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:11 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:11 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:11 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:11 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:11 --> Controller Class Initialized
INFO - 2021-12-15 02:58:11 --> Helper loaded: cookie_helper
INFO - 2021-12-15 02:58:11 --> Final output sent to browser
DEBUG - 2021-12-15 02:58:11 --> Total execution time: 0.0480
INFO - 2021-12-15 02:58:11 --> Config Class Initialized
INFO - 2021-12-15 02:58:11 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:11 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:11 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:11 --> URI Class Initialized
INFO - 2021-12-15 02:58:11 --> Router Class Initialized
INFO - 2021-12-15 02:58:11 --> Output Class Initialized
INFO - 2021-12-15 02:58:11 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:11 --> Input Class Initialized
INFO - 2021-12-15 02:58:11 --> Language Class Initialized
INFO - 2021-12-15 02:58:11 --> Language Class Initialized
INFO - 2021-12-15 02:58:11 --> Config Class Initialized
INFO - 2021-12-15 02:58:11 --> Loader Class Initialized
INFO - 2021-12-15 02:58:11 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:11 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:11 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:11 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:11 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:11 --> Controller Class Initialized
DEBUG - 2021-12-15 02:58:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-15 02:58:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 02:58:12 --> Final output sent to browser
DEBUG - 2021-12-15 02:58:12 --> Total execution time: 0.7380
INFO - 2021-12-15 02:58:14 --> Config Class Initialized
INFO - 2021-12-15 02:58:14 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:14 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:14 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:14 --> URI Class Initialized
INFO - 2021-12-15 02:58:14 --> Router Class Initialized
INFO - 2021-12-15 02:58:14 --> Output Class Initialized
INFO - 2021-12-15 02:58:14 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:14 --> Input Class Initialized
INFO - 2021-12-15 02:58:14 --> Language Class Initialized
INFO - 2021-12-15 02:58:14 --> Language Class Initialized
INFO - 2021-12-15 02:58:14 --> Config Class Initialized
INFO - 2021-12-15 02:58:14 --> Loader Class Initialized
INFO - 2021-12-15 02:58:14 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:14 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:14 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:14 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:14 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:14 --> Controller Class Initialized
DEBUG - 2021-12-15 02:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-15 02:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 02:58:14 --> Final output sent to browser
DEBUG - 2021-12-15 02:58:14 --> Total execution time: 0.0430
INFO - 2021-12-15 02:58:14 --> Config Class Initialized
INFO - 2021-12-15 02:58:14 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:14 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:14 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:14 --> URI Class Initialized
INFO - 2021-12-15 02:58:14 --> Router Class Initialized
INFO - 2021-12-15 02:58:14 --> Output Class Initialized
INFO - 2021-12-15 02:58:14 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:14 --> Input Class Initialized
INFO - 2021-12-15 02:58:14 --> Language Class Initialized
INFO - 2021-12-15 02:58:14 --> Language Class Initialized
INFO - 2021-12-15 02:58:14 --> Config Class Initialized
INFO - 2021-12-15 02:58:14 --> Loader Class Initialized
INFO - 2021-12-15 02:58:14 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:14 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:14 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:14 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:14 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:14 --> Controller Class Initialized
INFO - 2021-12-15 02:58:16 --> Config Class Initialized
INFO - 2021-12-15 02:58:16 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:16 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:16 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:16 --> URI Class Initialized
INFO - 2021-12-15 02:58:16 --> Router Class Initialized
INFO - 2021-12-15 02:58:16 --> Output Class Initialized
INFO - 2021-12-15 02:58:16 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:16 --> Input Class Initialized
INFO - 2021-12-15 02:58:16 --> Language Class Initialized
INFO - 2021-12-15 02:58:16 --> Language Class Initialized
INFO - 2021-12-15 02:58:16 --> Config Class Initialized
INFO - 2021-12-15 02:58:16 --> Loader Class Initialized
INFO - 2021-12-15 02:58:16 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:16 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:16 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:16 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:16 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:16 --> Controller Class Initialized
INFO - 2021-12-15 02:58:16 --> Final output sent to browser
DEBUG - 2021-12-15 02:58:16 --> Total execution time: 0.0410
INFO - 2021-12-15 02:58:16 --> Config Class Initialized
INFO - 2021-12-15 02:58:16 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:16 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:16 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:16 --> URI Class Initialized
INFO - 2021-12-15 02:58:16 --> Router Class Initialized
INFO - 2021-12-15 02:58:16 --> Output Class Initialized
INFO - 2021-12-15 02:58:16 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:16 --> Input Class Initialized
INFO - 2021-12-15 02:58:16 --> Language Class Initialized
INFO - 2021-12-15 02:58:16 --> Language Class Initialized
INFO - 2021-12-15 02:58:16 --> Config Class Initialized
INFO - 2021-12-15 02:58:16 --> Loader Class Initialized
INFO - 2021-12-15 02:58:16 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:16 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:16 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:16 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:16 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:16 --> Controller Class Initialized
INFO - 2021-12-15 02:58:18 --> Config Class Initialized
INFO - 2021-12-15 02:58:18 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:18 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:18 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:18 --> URI Class Initialized
INFO - 2021-12-15 02:58:18 --> Router Class Initialized
INFO - 2021-12-15 02:58:18 --> Output Class Initialized
INFO - 2021-12-15 02:58:18 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:18 --> Input Class Initialized
INFO - 2021-12-15 02:58:18 --> Language Class Initialized
INFO - 2021-12-15 02:58:18 --> Language Class Initialized
INFO - 2021-12-15 02:58:18 --> Config Class Initialized
INFO - 2021-12-15 02:58:18 --> Loader Class Initialized
INFO - 2021-12-15 02:58:18 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:18 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:18 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:18 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:18 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:18 --> Controller Class Initialized
DEBUG - 2021-12-15 02:58:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 02:58:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 02:58:18 --> Final output sent to browser
DEBUG - 2021-12-15 02:58:18 --> Total execution time: 0.0510
INFO - 2021-12-15 02:58:21 --> Config Class Initialized
INFO - 2021-12-15 02:58:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 02:58:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 02:58:21 --> Utf8 Class Initialized
INFO - 2021-12-15 02:58:21 --> URI Class Initialized
INFO - 2021-12-15 02:58:21 --> Router Class Initialized
INFO - 2021-12-15 02:58:21 --> Output Class Initialized
INFO - 2021-12-15 02:58:21 --> Security Class Initialized
DEBUG - 2021-12-15 02:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 02:58:21 --> Input Class Initialized
INFO - 2021-12-15 02:58:21 --> Language Class Initialized
INFO - 2021-12-15 02:58:21 --> Language Class Initialized
INFO - 2021-12-15 02:58:21 --> Config Class Initialized
INFO - 2021-12-15 02:58:21 --> Loader Class Initialized
INFO - 2021-12-15 02:58:21 --> Helper loaded: url_helper
INFO - 2021-12-15 02:58:21 --> Helper loaded: file_helper
INFO - 2021-12-15 02:58:21 --> Helper loaded: form_helper
INFO - 2021-12-15 02:58:21 --> Helper loaded: my_helper
INFO - 2021-12-15 02:58:21 --> Database Driver Class Initialized
DEBUG - 2021-12-15 02:58:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 02:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 02:58:21 --> Controller Class Initialized
DEBUG - 2021-12-15 02:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 02:58:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 02:58:21 --> Final output sent to browser
DEBUG - 2021-12-15 02:58:21 --> Total execution time: 0.0580
INFO - 2021-12-15 03:00:25 --> Config Class Initialized
INFO - 2021-12-15 03:00:25 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:25 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:25 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:25 --> URI Class Initialized
INFO - 2021-12-15 03:00:25 --> Router Class Initialized
INFO - 2021-12-15 03:00:25 --> Output Class Initialized
INFO - 2021-12-15 03:00:25 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:25 --> Input Class Initialized
INFO - 2021-12-15 03:00:25 --> Language Class Initialized
INFO - 2021-12-15 03:00:25 --> Language Class Initialized
INFO - 2021-12-15 03:00:25 --> Config Class Initialized
INFO - 2021-12-15 03:00:25 --> Loader Class Initialized
INFO - 2021-12-15 03:00:25 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:25 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:25 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:25 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:25 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:25 --> Controller Class Initialized
DEBUG - 2021-12-15 03:00:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-15 03:00:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:00:25 --> Final output sent to browser
DEBUG - 2021-12-15 03:00:25 --> Total execution time: 0.0400
INFO - 2021-12-15 03:00:25 --> Config Class Initialized
INFO - 2021-12-15 03:00:25 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:25 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:25 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:25 --> URI Class Initialized
INFO - 2021-12-15 03:00:25 --> Router Class Initialized
INFO - 2021-12-15 03:00:25 --> Output Class Initialized
INFO - 2021-12-15 03:00:25 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:25 --> Input Class Initialized
INFO - 2021-12-15 03:00:25 --> Language Class Initialized
INFO - 2021-12-15 03:00:25 --> Language Class Initialized
INFO - 2021-12-15 03:00:25 --> Config Class Initialized
INFO - 2021-12-15 03:00:25 --> Loader Class Initialized
INFO - 2021-12-15 03:00:25 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:25 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:25 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:25 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:25 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:25 --> Controller Class Initialized
INFO - 2021-12-15 03:00:27 --> Config Class Initialized
INFO - 2021-12-15 03:00:27 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:27 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:27 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:27 --> URI Class Initialized
INFO - 2021-12-15 03:00:27 --> Router Class Initialized
INFO - 2021-12-15 03:00:27 --> Output Class Initialized
INFO - 2021-12-15 03:00:27 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:27 --> Input Class Initialized
INFO - 2021-12-15 03:00:27 --> Language Class Initialized
INFO - 2021-12-15 03:00:27 --> Language Class Initialized
INFO - 2021-12-15 03:00:27 --> Config Class Initialized
INFO - 2021-12-15 03:00:27 --> Loader Class Initialized
INFO - 2021-12-15 03:00:27 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:27 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:27 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:27 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:27 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:27 --> Controller Class Initialized
INFO - 2021-12-15 03:00:27 --> Config Class Initialized
INFO - 2021-12-15 03:00:27 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:27 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:27 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:27 --> URI Class Initialized
INFO - 2021-12-15 03:00:27 --> Router Class Initialized
INFO - 2021-12-15 03:00:27 --> Output Class Initialized
INFO - 2021-12-15 03:00:27 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:27 --> Input Class Initialized
INFO - 2021-12-15 03:00:27 --> Language Class Initialized
INFO - 2021-12-15 03:00:27 --> Language Class Initialized
INFO - 2021-12-15 03:00:27 --> Config Class Initialized
INFO - 2021-12-15 03:00:27 --> Loader Class Initialized
INFO - 2021-12-15 03:00:27 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:27 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:27 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:27 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:27 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:27 --> Controller Class Initialized
INFO - 2021-12-15 03:00:29 --> Config Class Initialized
INFO - 2021-12-15 03:00:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:29 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:29 --> URI Class Initialized
INFO - 2021-12-15 03:00:29 --> Router Class Initialized
INFO - 2021-12-15 03:00:29 --> Output Class Initialized
INFO - 2021-12-15 03:00:29 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:29 --> Input Class Initialized
INFO - 2021-12-15 03:00:29 --> Language Class Initialized
INFO - 2021-12-15 03:00:29 --> Language Class Initialized
INFO - 2021-12-15 03:00:29 --> Config Class Initialized
INFO - 2021-12-15 03:00:29 --> Loader Class Initialized
INFO - 2021-12-15 03:00:29 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:29 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:29 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:29 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:29 --> Controller Class Initialized
ERROR - 2021-12-15 03:00:29 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-12-15 03:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-12-15 03:00:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:00:29 --> Final output sent to browser
DEBUG - 2021-12-15 03:00:29 --> Total execution time: 0.0390
INFO - 2021-12-15 03:00:41 --> Config Class Initialized
INFO - 2021-12-15 03:00:41 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:41 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:41 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:41 --> URI Class Initialized
INFO - 2021-12-15 03:00:41 --> Router Class Initialized
INFO - 2021-12-15 03:00:41 --> Output Class Initialized
INFO - 2021-12-15 03:00:41 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:41 --> Input Class Initialized
INFO - 2021-12-15 03:00:41 --> Language Class Initialized
INFO - 2021-12-15 03:00:41 --> Language Class Initialized
INFO - 2021-12-15 03:00:41 --> Config Class Initialized
INFO - 2021-12-15 03:00:41 --> Loader Class Initialized
INFO - 2021-12-15 03:00:41 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:41 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:41 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:41 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:41 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:41 --> Controller Class Initialized
DEBUG - 2021-12-15 03:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 03:00:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:00:41 --> Final output sent to browser
DEBUG - 2021-12-15 03:00:41 --> Total execution time: 0.0430
INFO - 2021-12-15 03:00:57 --> Config Class Initialized
INFO - 2021-12-15 03:00:57 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:57 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:57 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:57 --> URI Class Initialized
INFO - 2021-12-15 03:00:57 --> Router Class Initialized
INFO - 2021-12-15 03:00:57 --> Output Class Initialized
INFO - 2021-12-15 03:00:57 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:57 --> Input Class Initialized
INFO - 2021-12-15 03:00:57 --> Language Class Initialized
INFO - 2021-12-15 03:00:57 --> Language Class Initialized
INFO - 2021-12-15 03:00:57 --> Config Class Initialized
INFO - 2021-12-15 03:00:57 --> Loader Class Initialized
INFO - 2021-12-15 03:00:57 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:57 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:57 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:57 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:57 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:57 --> Controller Class Initialized
DEBUG - 2021-12-15 03:00:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 03:00:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:00:57 --> Final output sent to browser
DEBUG - 2021-12-15 03:00:57 --> Total execution time: 0.0510
INFO - 2021-12-15 03:00:58 --> Config Class Initialized
INFO - 2021-12-15 03:00:58 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:00:58 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:00:58 --> Utf8 Class Initialized
INFO - 2021-12-15 03:00:58 --> URI Class Initialized
INFO - 2021-12-15 03:00:58 --> Router Class Initialized
INFO - 2021-12-15 03:00:58 --> Output Class Initialized
INFO - 2021-12-15 03:00:58 --> Security Class Initialized
DEBUG - 2021-12-15 03:00:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:00:58 --> Input Class Initialized
INFO - 2021-12-15 03:00:58 --> Language Class Initialized
INFO - 2021-12-15 03:00:58 --> Language Class Initialized
INFO - 2021-12-15 03:00:58 --> Config Class Initialized
INFO - 2021-12-15 03:00:58 --> Loader Class Initialized
INFO - 2021-12-15 03:00:58 --> Helper loaded: url_helper
INFO - 2021-12-15 03:00:58 --> Helper loaded: file_helper
INFO - 2021-12-15 03:00:58 --> Helper loaded: form_helper
INFO - 2021-12-15 03:00:58 --> Helper loaded: my_helper
INFO - 2021-12-15 03:00:58 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:00:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:00:58 --> Controller Class Initialized
DEBUG - 2021-12-15 03:00:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 03:00:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:00:58 --> Final output sent to browser
DEBUG - 2021-12-15 03:00:58 --> Total execution time: 0.0460
INFO - 2021-12-15 03:01:34 --> Config Class Initialized
INFO - 2021-12-15 03:01:34 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:01:34 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:01:34 --> Utf8 Class Initialized
INFO - 2021-12-15 03:01:34 --> URI Class Initialized
INFO - 2021-12-15 03:01:34 --> Router Class Initialized
INFO - 2021-12-15 03:01:34 --> Output Class Initialized
INFO - 2021-12-15 03:01:34 --> Security Class Initialized
DEBUG - 2021-12-15 03:01:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:01:34 --> Input Class Initialized
INFO - 2021-12-15 03:01:34 --> Language Class Initialized
INFO - 2021-12-15 03:01:34 --> Language Class Initialized
INFO - 2021-12-15 03:01:34 --> Config Class Initialized
INFO - 2021-12-15 03:01:34 --> Loader Class Initialized
INFO - 2021-12-15 03:01:34 --> Helper loaded: url_helper
INFO - 2021-12-15 03:01:34 --> Helper loaded: file_helper
INFO - 2021-12-15 03:01:34 --> Helper loaded: form_helper
INFO - 2021-12-15 03:01:34 --> Helper loaded: my_helper
INFO - 2021-12-15 03:01:34 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:01:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:01:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:01:34 --> Controller Class Initialized
DEBUG - 2021-12-15 03:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 03:01:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:01:34 --> Final output sent to browser
DEBUG - 2021-12-15 03:01:34 --> Total execution time: 0.0300
INFO - 2021-12-15 03:35:24 --> Config Class Initialized
INFO - 2021-12-15 03:35:24 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:35:24 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:35:24 --> Utf8 Class Initialized
INFO - 2021-12-15 03:35:24 --> URI Class Initialized
INFO - 2021-12-15 03:35:24 --> Router Class Initialized
INFO - 2021-12-15 03:35:24 --> Output Class Initialized
INFO - 2021-12-15 03:35:24 --> Security Class Initialized
DEBUG - 2021-12-15 03:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:35:24 --> Input Class Initialized
INFO - 2021-12-15 03:35:24 --> Language Class Initialized
INFO - 2021-12-15 03:35:24 --> Language Class Initialized
INFO - 2021-12-15 03:35:24 --> Config Class Initialized
INFO - 2021-12-15 03:35:24 --> Loader Class Initialized
INFO - 2021-12-15 03:35:24 --> Helper loaded: url_helper
INFO - 2021-12-15 03:35:24 --> Helper loaded: file_helper
INFO - 2021-12-15 03:35:24 --> Helper loaded: form_helper
INFO - 2021-12-15 03:35:24 --> Helper loaded: my_helper
INFO - 2021-12-15 03:35:24 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:35:24 --> Controller Class Initialized
DEBUG - 2021-12-15 03:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-15 03:35:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:35:24 --> Final output sent to browser
DEBUG - 2021-12-15 03:35:24 --> Total execution time: 0.0450
INFO - 2021-12-15 03:35:24 --> Config Class Initialized
INFO - 2021-12-15 03:35:24 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:35:24 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:35:24 --> Utf8 Class Initialized
INFO - 2021-12-15 03:35:24 --> URI Class Initialized
INFO - 2021-12-15 03:35:24 --> Router Class Initialized
INFO - 2021-12-15 03:35:24 --> Output Class Initialized
INFO - 2021-12-15 03:35:24 --> Security Class Initialized
DEBUG - 2021-12-15 03:35:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:35:24 --> Input Class Initialized
INFO - 2021-12-15 03:35:24 --> Language Class Initialized
INFO - 2021-12-15 03:35:24 --> Language Class Initialized
INFO - 2021-12-15 03:35:24 --> Config Class Initialized
INFO - 2021-12-15 03:35:24 --> Loader Class Initialized
INFO - 2021-12-15 03:35:24 --> Helper loaded: url_helper
INFO - 2021-12-15 03:35:24 --> Helper loaded: file_helper
INFO - 2021-12-15 03:35:24 --> Helper loaded: form_helper
INFO - 2021-12-15 03:35:24 --> Helper loaded: my_helper
INFO - 2021-12-15 03:35:24 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:35:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:35:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:35:24 --> Controller Class Initialized
INFO - 2021-12-15 03:35:29 --> Config Class Initialized
INFO - 2021-12-15 03:35:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:35:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:35:29 --> Utf8 Class Initialized
INFO - 2021-12-15 03:35:29 --> URI Class Initialized
INFO - 2021-12-15 03:35:29 --> Router Class Initialized
INFO - 2021-12-15 03:35:29 --> Output Class Initialized
INFO - 2021-12-15 03:35:29 --> Security Class Initialized
DEBUG - 2021-12-15 03:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:35:29 --> Input Class Initialized
INFO - 2021-12-15 03:35:29 --> Language Class Initialized
INFO - 2021-12-15 03:35:29 --> Language Class Initialized
INFO - 2021-12-15 03:35:29 --> Config Class Initialized
INFO - 2021-12-15 03:35:29 --> Loader Class Initialized
INFO - 2021-12-15 03:35:29 --> Helper loaded: url_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: file_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: form_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: my_helper
INFO - 2021-12-15 03:35:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:35:29 --> Controller Class Initialized
INFO - 2021-12-15 03:35:29 --> Config Class Initialized
INFO - 2021-12-15 03:35:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:35:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:35:29 --> Utf8 Class Initialized
INFO - 2021-12-15 03:35:29 --> URI Class Initialized
INFO - 2021-12-15 03:35:29 --> Router Class Initialized
INFO - 2021-12-15 03:35:29 --> Output Class Initialized
INFO - 2021-12-15 03:35:29 --> Security Class Initialized
DEBUG - 2021-12-15 03:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:35:29 --> Input Class Initialized
INFO - 2021-12-15 03:35:29 --> Language Class Initialized
INFO - 2021-12-15 03:35:29 --> Language Class Initialized
INFO - 2021-12-15 03:35:29 --> Config Class Initialized
INFO - 2021-12-15 03:35:29 --> Loader Class Initialized
INFO - 2021-12-15 03:35:29 --> Helper loaded: url_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: file_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: form_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: my_helper
INFO - 2021-12-15 03:35:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:35:29 --> Controller Class Initialized
DEBUG - 2021-12-15 03:35:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-15 03:35:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 03:35:29 --> Final output sent to browser
DEBUG - 2021-12-15 03:35:29 --> Total execution time: 0.0410
INFO - 2021-12-15 03:35:29 --> Config Class Initialized
INFO - 2021-12-15 03:35:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:35:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:35:29 --> Utf8 Class Initialized
INFO - 2021-12-15 03:35:29 --> URI Class Initialized
INFO - 2021-12-15 03:35:29 --> Router Class Initialized
INFO - 2021-12-15 03:35:29 --> Output Class Initialized
INFO - 2021-12-15 03:35:29 --> Security Class Initialized
DEBUG - 2021-12-15 03:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:35:29 --> Input Class Initialized
INFO - 2021-12-15 03:35:29 --> Language Class Initialized
INFO - 2021-12-15 03:35:29 --> Language Class Initialized
INFO - 2021-12-15 03:35:29 --> Config Class Initialized
INFO - 2021-12-15 03:35:29 --> Loader Class Initialized
INFO - 2021-12-15 03:35:29 --> Helper loaded: url_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: file_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: form_helper
INFO - 2021-12-15 03:35:29 --> Helper loaded: my_helper
INFO - 2021-12-15 03:35:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:35:29 --> Controller Class Initialized
INFO - 2021-12-15 03:35:31 --> Config Class Initialized
INFO - 2021-12-15 03:35:31 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:35:31 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:35:31 --> Utf8 Class Initialized
INFO - 2021-12-15 03:35:31 --> URI Class Initialized
INFO - 2021-12-15 03:35:31 --> Router Class Initialized
INFO - 2021-12-15 03:35:31 --> Output Class Initialized
INFO - 2021-12-15 03:35:31 --> Security Class Initialized
DEBUG - 2021-12-15 03:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:35:31 --> Input Class Initialized
INFO - 2021-12-15 03:35:31 --> Language Class Initialized
INFO - 2021-12-15 03:35:31 --> Language Class Initialized
INFO - 2021-12-15 03:35:31 --> Config Class Initialized
INFO - 2021-12-15 03:35:31 --> Loader Class Initialized
INFO - 2021-12-15 03:35:31 --> Helper loaded: url_helper
INFO - 2021-12-15 03:35:31 --> Helper loaded: file_helper
INFO - 2021-12-15 03:35:31 --> Helper loaded: form_helper
INFO - 2021-12-15 03:35:31 --> Helper loaded: my_helper
INFO - 2021-12-15 03:35:31 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:35:31 --> Controller Class Initialized
INFO - 2021-12-15 03:35:34 --> Config Class Initialized
INFO - 2021-12-15 03:35:34 --> Hooks Class Initialized
DEBUG - 2021-12-15 03:35:34 --> UTF-8 Support Enabled
INFO - 2021-12-15 03:35:34 --> Utf8 Class Initialized
INFO - 2021-12-15 03:35:34 --> URI Class Initialized
INFO - 2021-12-15 03:35:34 --> Router Class Initialized
INFO - 2021-12-15 03:35:34 --> Output Class Initialized
INFO - 2021-12-15 03:35:34 --> Security Class Initialized
DEBUG - 2021-12-15 03:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 03:35:34 --> Input Class Initialized
INFO - 2021-12-15 03:35:34 --> Language Class Initialized
INFO - 2021-12-15 03:35:34 --> Language Class Initialized
INFO - 2021-12-15 03:35:34 --> Config Class Initialized
INFO - 2021-12-15 03:35:34 --> Loader Class Initialized
INFO - 2021-12-15 03:35:34 --> Helper loaded: url_helper
INFO - 2021-12-15 03:35:34 --> Helper loaded: file_helper
INFO - 2021-12-15 03:35:34 --> Helper loaded: form_helper
INFO - 2021-12-15 03:35:34 --> Helper loaded: my_helper
INFO - 2021-12-15 03:35:34 --> Database Driver Class Initialized
DEBUG - 2021-12-15 03:35:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 03:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 03:35:34 --> Controller Class Initialized
INFO - 2021-12-15 04:26:55 --> Config Class Initialized
INFO - 2021-12-15 04:26:55 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:26:55 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:26:55 --> Utf8 Class Initialized
INFO - 2021-12-15 04:26:55 --> URI Class Initialized
INFO - 2021-12-15 04:26:55 --> Router Class Initialized
INFO - 2021-12-15 04:26:55 --> Output Class Initialized
INFO - 2021-12-15 04:26:55 --> Security Class Initialized
DEBUG - 2021-12-15 04:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:26:55 --> Input Class Initialized
INFO - 2021-12-15 04:26:55 --> Language Class Initialized
INFO - 2021-12-15 04:26:55 --> Language Class Initialized
INFO - 2021-12-15 04:26:55 --> Config Class Initialized
INFO - 2021-12-15 04:26:55 --> Loader Class Initialized
INFO - 2021-12-15 04:26:55 --> Helper loaded: url_helper
INFO - 2021-12-15 04:26:55 --> Helper loaded: file_helper
INFO - 2021-12-15 04:26:55 --> Helper loaded: form_helper
INFO - 2021-12-15 04:26:55 --> Helper loaded: my_helper
INFO - 2021-12-15 04:26:55 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:26:55 --> Controller Class Initialized
DEBUG - 2021-12-15 04:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 04:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:26:55 --> Final output sent to browser
DEBUG - 2021-12-15 04:26:55 --> Total execution time: 0.0490
INFO - 2021-12-15 04:27:04 --> Config Class Initialized
INFO - 2021-12-15 04:27:04 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:27:04 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:27:04 --> Utf8 Class Initialized
INFO - 2021-12-15 04:27:04 --> URI Class Initialized
INFO - 2021-12-15 04:27:04 --> Router Class Initialized
INFO - 2021-12-15 04:27:04 --> Output Class Initialized
INFO - 2021-12-15 04:27:04 --> Security Class Initialized
DEBUG - 2021-12-15 04:27:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:27:04 --> Input Class Initialized
INFO - 2021-12-15 04:27:04 --> Language Class Initialized
INFO - 2021-12-15 04:27:04 --> Language Class Initialized
INFO - 2021-12-15 04:27:04 --> Config Class Initialized
INFO - 2021-12-15 04:27:04 --> Loader Class Initialized
INFO - 2021-12-15 04:27:04 --> Helper loaded: url_helper
INFO - 2021-12-15 04:27:04 --> Helper loaded: file_helper
INFO - 2021-12-15 04:27:04 --> Helper loaded: form_helper
INFO - 2021-12-15 04:27:04 --> Helper loaded: my_helper
INFO - 2021-12-15 04:27:04 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:27:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:27:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:27:04 --> Controller Class Initialized
DEBUG - 2021-12-15 04:27:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 04:27:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:27:04 --> Final output sent to browser
DEBUG - 2021-12-15 04:27:04 --> Total execution time: 0.0440
INFO - 2021-12-15 04:29:32 --> Config Class Initialized
INFO - 2021-12-15 04:29:32 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:29:32 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:29:32 --> Utf8 Class Initialized
INFO - 2021-12-15 04:29:32 --> URI Class Initialized
INFO - 2021-12-15 04:29:32 --> Router Class Initialized
INFO - 2021-12-15 04:29:32 --> Output Class Initialized
INFO - 2021-12-15 04:29:32 --> Security Class Initialized
DEBUG - 2021-12-15 04:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:29:32 --> Input Class Initialized
INFO - 2021-12-15 04:29:32 --> Language Class Initialized
INFO - 2021-12-15 04:29:32 --> Language Class Initialized
INFO - 2021-12-15 04:29:32 --> Config Class Initialized
INFO - 2021-12-15 04:29:32 --> Loader Class Initialized
INFO - 2021-12-15 04:29:32 --> Helper loaded: url_helper
INFO - 2021-12-15 04:29:32 --> Helper loaded: file_helper
INFO - 2021-12-15 04:29:32 --> Helper loaded: form_helper
INFO - 2021-12-15 04:29:32 --> Helper loaded: my_helper
INFO - 2021-12-15 04:29:32 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:29:32 --> Controller Class Initialized
INFO - 2021-12-15 04:29:32 --> Config Class Initialized
INFO - 2021-12-15 04:29:32 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:29:32 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:29:32 --> Utf8 Class Initialized
INFO - 2021-12-15 04:29:32 --> URI Class Initialized
INFO - 2021-12-15 04:29:32 --> Router Class Initialized
INFO - 2021-12-15 04:29:32 --> Output Class Initialized
INFO - 2021-12-15 04:29:32 --> Security Class Initialized
DEBUG - 2021-12-15 04:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:29:32 --> Input Class Initialized
INFO - 2021-12-15 04:29:32 --> Language Class Initialized
INFO - 2021-12-15 04:29:32 --> Language Class Initialized
INFO - 2021-12-15 04:29:32 --> Config Class Initialized
INFO - 2021-12-15 04:29:32 --> Loader Class Initialized
INFO - 2021-12-15 04:29:32 --> Helper loaded: url_helper
INFO - 2021-12-15 04:29:32 --> Helper loaded: file_helper
INFO - 2021-12-15 04:29:32 --> Helper loaded: form_helper
INFO - 2021-12-15 04:29:32 --> Helper loaded: my_helper
INFO - 2021-12-15 04:29:32 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:29:32 --> Controller Class Initialized
DEBUG - 2021-12-15 04:29:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 04:29:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:29:32 --> Final output sent to browser
DEBUG - 2021-12-15 04:29:32 --> Total execution time: 0.0420
INFO - 2021-12-15 04:32:55 --> Config Class Initialized
INFO - 2021-12-15 04:32:55 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:32:55 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:32:55 --> Utf8 Class Initialized
INFO - 2021-12-15 04:32:55 --> URI Class Initialized
INFO - 2021-12-15 04:32:55 --> Router Class Initialized
INFO - 2021-12-15 04:32:55 --> Output Class Initialized
INFO - 2021-12-15 04:32:55 --> Security Class Initialized
DEBUG - 2021-12-15 04:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:32:55 --> Input Class Initialized
INFO - 2021-12-15 04:32:55 --> Language Class Initialized
INFO - 2021-12-15 04:32:55 --> Language Class Initialized
INFO - 2021-12-15 04:32:55 --> Config Class Initialized
INFO - 2021-12-15 04:32:55 --> Loader Class Initialized
INFO - 2021-12-15 04:32:55 --> Helper loaded: url_helper
INFO - 2021-12-15 04:32:55 --> Helper loaded: file_helper
INFO - 2021-12-15 04:32:55 --> Helper loaded: form_helper
INFO - 2021-12-15 04:32:55 --> Helper loaded: my_helper
INFO - 2021-12-15 04:32:55 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:32:55 --> Controller Class Initialized
DEBUG - 2021-12-15 04:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-12-15 04:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:32:55 --> Final output sent to browser
DEBUG - 2021-12-15 04:32:55 --> Total execution time: 0.0510
INFO - 2021-12-15 04:32:55 --> Config Class Initialized
INFO - 2021-12-15 04:32:55 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:32:55 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:32:55 --> Utf8 Class Initialized
INFO - 2021-12-15 04:32:55 --> URI Class Initialized
INFO - 2021-12-15 04:32:55 --> Router Class Initialized
INFO - 2021-12-15 04:32:55 --> Output Class Initialized
INFO - 2021-12-15 04:32:55 --> Security Class Initialized
DEBUG - 2021-12-15 04:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:32:55 --> Input Class Initialized
INFO - 2021-12-15 04:32:55 --> Language Class Initialized
INFO - 2021-12-15 04:32:55 --> Language Class Initialized
INFO - 2021-12-15 04:32:55 --> Config Class Initialized
INFO - 2021-12-15 04:32:55 --> Loader Class Initialized
INFO - 2021-12-15 04:32:55 --> Helper loaded: url_helper
INFO - 2021-12-15 04:32:55 --> Helper loaded: file_helper
INFO - 2021-12-15 04:32:55 --> Helper loaded: form_helper
INFO - 2021-12-15 04:32:55 --> Helper loaded: my_helper
INFO - 2021-12-15 04:32:55 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:32:55 --> Controller Class Initialized
INFO - 2021-12-15 04:32:57 --> Config Class Initialized
INFO - 2021-12-15 04:32:57 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:32:57 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:32:57 --> Utf8 Class Initialized
INFO - 2021-12-15 04:32:57 --> URI Class Initialized
INFO - 2021-12-15 04:32:57 --> Router Class Initialized
INFO - 2021-12-15 04:32:57 --> Output Class Initialized
INFO - 2021-12-15 04:32:57 --> Security Class Initialized
DEBUG - 2021-12-15 04:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:32:57 --> Input Class Initialized
INFO - 2021-12-15 04:32:57 --> Language Class Initialized
INFO - 2021-12-15 04:32:57 --> Language Class Initialized
INFO - 2021-12-15 04:32:57 --> Config Class Initialized
INFO - 2021-12-15 04:32:57 --> Loader Class Initialized
INFO - 2021-12-15 04:32:57 --> Helper loaded: url_helper
INFO - 2021-12-15 04:32:57 --> Helper loaded: file_helper
INFO - 2021-12-15 04:32:57 --> Helper loaded: form_helper
INFO - 2021-12-15 04:32:57 --> Helper loaded: my_helper
INFO - 2021-12-15 04:32:57 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:32:57 --> Controller Class Initialized
INFO - 2021-12-15 04:32:57 --> Final output sent to browser
DEBUG - 2021-12-15 04:32:57 --> Total execution time: 0.0500
INFO - 2021-12-15 04:33:04 --> Config Class Initialized
INFO - 2021-12-15 04:33:04 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:33:04 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:33:04 --> Utf8 Class Initialized
INFO - 2021-12-15 04:33:04 --> URI Class Initialized
INFO - 2021-12-15 04:33:04 --> Router Class Initialized
INFO - 2021-12-15 04:33:04 --> Output Class Initialized
INFO - 2021-12-15 04:33:04 --> Security Class Initialized
DEBUG - 2021-12-15 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:33:04 --> Input Class Initialized
INFO - 2021-12-15 04:33:04 --> Language Class Initialized
INFO - 2021-12-15 04:33:04 --> Language Class Initialized
INFO - 2021-12-15 04:33:04 --> Config Class Initialized
INFO - 2021-12-15 04:33:04 --> Loader Class Initialized
INFO - 2021-12-15 04:33:04 --> Helper loaded: url_helper
INFO - 2021-12-15 04:33:04 --> Helper loaded: file_helper
INFO - 2021-12-15 04:33:04 --> Helper loaded: form_helper
INFO - 2021-12-15 04:33:04 --> Helper loaded: my_helper
INFO - 2021-12-15 04:33:04 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:33:04 --> Controller Class Initialized
INFO - 2021-12-15 04:33:04 --> Final output sent to browser
DEBUG - 2021-12-15 04:33:04 --> Total execution time: 0.0470
INFO - 2021-12-15 04:33:04 --> Config Class Initialized
INFO - 2021-12-15 04:33:04 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:33:04 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:33:04 --> Utf8 Class Initialized
INFO - 2021-12-15 04:33:04 --> URI Class Initialized
INFO - 2021-12-15 04:33:04 --> Router Class Initialized
INFO - 2021-12-15 04:33:04 --> Output Class Initialized
INFO - 2021-12-15 04:33:04 --> Security Class Initialized
DEBUG - 2021-12-15 04:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:33:04 --> Input Class Initialized
INFO - 2021-12-15 04:33:04 --> Language Class Initialized
INFO - 2021-12-15 04:33:04 --> Language Class Initialized
INFO - 2021-12-15 04:33:04 --> Config Class Initialized
INFO - 2021-12-15 04:33:04 --> Loader Class Initialized
INFO - 2021-12-15 04:33:04 --> Helper loaded: url_helper
INFO - 2021-12-15 04:33:04 --> Helper loaded: file_helper
INFO - 2021-12-15 04:33:04 --> Helper loaded: form_helper
INFO - 2021-12-15 04:33:04 --> Helper loaded: my_helper
INFO - 2021-12-15 04:33:04 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:33:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:33:04 --> Controller Class Initialized
INFO - 2021-12-15 04:33:06 --> Config Class Initialized
INFO - 2021-12-15 04:33:06 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:33:06 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:33:06 --> Utf8 Class Initialized
INFO - 2021-12-15 04:33:06 --> URI Class Initialized
INFO - 2021-12-15 04:33:06 --> Router Class Initialized
INFO - 2021-12-15 04:33:06 --> Output Class Initialized
INFO - 2021-12-15 04:33:06 --> Security Class Initialized
DEBUG - 2021-12-15 04:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:33:06 --> Input Class Initialized
INFO - 2021-12-15 04:33:06 --> Language Class Initialized
INFO - 2021-12-15 04:33:06 --> Language Class Initialized
INFO - 2021-12-15 04:33:06 --> Config Class Initialized
INFO - 2021-12-15 04:33:06 --> Loader Class Initialized
INFO - 2021-12-15 04:33:06 --> Helper loaded: url_helper
INFO - 2021-12-15 04:33:06 --> Helper loaded: file_helper
INFO - 2021-12-15 04:33:06 --> Helper loaded: form_helper
INFO - 2021-12-15 04:33:06 --> Helper loaded: my_helper
INFO - 2021-12-15 04:33:06 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:33:06 --> Controller Class Initialized
DEBUG - 2021-12-15 04:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-15 04:33:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:33:06 --> Final output sent to browser
DEBUG - 2021-12-15 04:33:06 --> Total execution time: 0.0450
INFO - 2021-12-15 04:33:06 --> Config Class Initialized
INFO - 2021-12-15 04:33:06 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:33:06 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:33:06 --> Utf8 Class Initialized
INFO - 2021-12-15 04:33:06 --> URI Class Initialized
INFO - 2021-12-15 04:33:06 --> Router Class Initialized
INFO - 2021-12-15 04:33:06 --> Output Class Initialized
INFO - 2021-12-15 04:33:06 --> Security Class Initialized
DEBUG - 2021-12-15 04:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:33:06 --> Input Class Initialized
INFO - 2021-12-15 04:33:06 --> Language Class Initialized
INFO - 2021-12-15 04:33:06 --> Language Class Initialized
INFO - 2021-12-15 04:33:06 --> Config Class Initialized
INFO - 2021-12-15 04:33:06 --> Loader Class Initialized
INFO - 2021-12-15 04:33:06 --> Helper loaded: url_helper
INFO - 2021-12-15 04:33:06 --> Helper loaded: file_helper
INFO - 2021-12-15 04:33:06 --> Helper loaded: form_helper
INFO - 2021-12-15 04:33:06 --> Helper loaded: my_helper
INFO - 2021-12-15 04:33:06 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:33:06 --> Controller Class Initialized
INFO - 2021-12-15 04:33:07 --> Config Class Initialized
INFO - 2021-12-15 04:33:07 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:33:07 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:33:07 --> Utf8 Class Initialized
INFO - 2021-12-15 04:33:07 --> URI Class Initialized
INFO - 2021-12-15 04:33:07 --> Router Class Initialized
INFO - 2021-12-15 04:33:07 --> Output Class Initialized
INFO - 2021-12-15 04:33:07 --> Security Class Initialized
DEBUG - 2021-12-15 04:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:33:07 --> Input Class Initialized
INFO - 2021-12-15 04:33:07 --> Language Class Initialized
INFO - 2021-12-15 04:33:07 --> Language Class Initialized
INFO - 2021-12-15 04:33:07 --> Config Class Initialized
INFO - 2021-12-15 04:33:07 --> Loader Class Initialized
INFO - 2021-12-15 04:33:07 --> Helper loaded: url_helper
INFO - 2021-12-15 04:33:07 --> Helper loaded: file_helper
INFO - 2021-12-15 04:33:07 --> Helper loaded: form_helper
INFO - 2021-12-15 04:33:07 --> Helper loaded: my_helper
INFO - 2021-12-15 04:33:07 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:33:07 --> Controller Class Initialized
DEBUG - 2021-12-15 04:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 04:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:33:07 --> Final output sent to browser
DEBUG - 2021-12-15 04:33:07 --> Total execution time: 0.0550
INFO - 2021-12-15 04:40:48 --> Config Class Initialized
INFO - 2021-12-15 04:40:48 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:40:48 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:40:48 --> Utf8 Class Initialized
INFO - 2021-12-15 04:40:48 --> URI Class Initialized
INFO - 2021-12-15 04:40:48 --> Router Class Initialized
INFO - 2021-12-15 04:40:48 --> Output Class Initialized
INFO - 2021-12-15 04:40:48 --> Security Class Initialized
DEBUG - 2021-12-15 04:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:40:48 --> Input Class Initialized
INFO - 2021-12-15 04:40:48 --> Language Class Initialized
INFO - 2021-12-15 04:40:48 --> Language Class Initialized
INFO - 2021-12-15 04:40:48 --> Config Class Initialized
INFO - 2021-12-15 04:40:48 --> Loader Class Initialized
INFO - 2021-12-15 04:40:48 --> Helper loaded: url_helper
INFO - 2021-12-15 04:40:48 --> Helper loaded: file_helper
INFO - 2021-12-15 04:40:48 --> Helper loaded: form_helper
INFO - 2021-12-15 04:40:48 --> Helper loaded: my_helper
INFO - 2021-12-15 04:40:48 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:40:48 --> Controller Class Initialized
DEBUG - 2021-12-15 04:40:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-12-15 04:40:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:40:48 --> Final output sent to browser
DEBUG - 2021-12-15 04:40:48 --> Total execution time: 0.0500
INFO - 2021-12-15 04:40:48 --> Config Class Initialized
INFO - 2021-12-15 04:40:48 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:40:48 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:40:48 --> Utf8 Class Initialized
INFO - 2021-12-15 04:40:48 --> URI Class Initialized
INFO - 2021-12-15 04:40:48 --> Router Class Initialized
INFO - 2021-12-15 04:40:48 --> Output Class Initialized
INFO - 2021-12-15 04:40:48 --> Security Class Initialized
DEBUG - 2021-12-15 04:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:40:48 --> Input Class Initialized
INFO - 2021-12-15 04:40:48 --> Language Class Initialized
INFO - 2021-12-15 04:40:48 --> Language Class Initialized
INFO - 2021-12-15 04:40:48 --> Config Class Initialized
INFO - 2021-12-15 04:40:48 --> Loader Class Initialized
INFO - 2021-12-15 04:40:48 --> Helper loaded: url_helper
INFO - 2021-12-15 04:40:48 --> Helper loaded: file_helper
INFO - 2021-12-15 04:40:48 --> Helper loaded: form_helper
INFO - 2021-12-15 04:40:48 --> Helper loaded: my_helper
INFO - 2021-12-15 04:40:48 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:40:48 --> Controller Class Initialized
INFO - 2021-12-15 04:40:50 --> Config Class Initialized
INFO - 2021-12-15 04:40:50 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:40:50 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:40:50 --> Utf8 Class Initialized
INFO - 2021-12-15 04:40:50 --> URI Class Initialized
INFO - 2021-12-15 04:40:50 --> Router Class Initialized
INFO - 2021-12-15 04:40:50 --> Output Class Initialized
INFO - 2021-12-15 04:40:50 --> Security Class Initialized
DEBUG - 2021-12-15 04:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:40:50 --> Input Class Initialized
INFO - 2021-12-15 04:40:50 --> Language Class Initialized
INFO - 2021-12-15 04:40:50 --> Language Class Initialized
INFO - 2021-12-15 04:40:50 --> Config Class Initialized
INFO - 2021-12-15 04:40:50 --> Loader Class Initialized
INFO - 2021-12-15 04:40:50 --> Helper loaded: url_helper
INFO - 2021-12-15 04:40:50 --> Helper loaded: file_helper
INFO - 2021-12-15 04:40:50 --> Helper loaded: form_helper
INFO - 2021-12-15 04:40:50 --> Helper loaded: my_helper
INFO - 2021-12-15 04:40:50 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:40:50 --> Controller Class Initialized
INFO - 2021-12-15 04:40:53 --> Config Class Initialized
INFO - 2021-12-15 04:40:53 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:40:53 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:40:53 --> Utf8 Class Initialized
INFO - 2021-12-15 04:40:53 --> URI Class Initialized
INFO - 2021-12-15 04:40:53 --> Router Class Initialized
INFO - 2021-12-15 04:40:53 --> Output Class Initialized
INFO - 2021-12-15 04:40:53 --> Security Class Initialized
DEBUG - 2021-12-15 04:40:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:40:53 --> Input Class Initialized
INFO - 2021-12-15 04:40:53 --> Language Class Initialized
INFO - 2021-12-15 04:40:53 --> Language Class Initialized
INFO - 2021-12-15 04:40:53 --> Config Class Initialized
INFO - 2021-12-15 04:40:53 --> Loader Class Initialized
INFO - 2021-12-15 04:40:53 --> Helper loaded: url_helper
INFO - 2021-12-15 04:40:53 --> Helper loaded: file_helper
INFO - 2021-12-15 04:40:53 --> Helper loaded: form_helper
INFO - 2021-12-15 04:40:53 --> Helper loaded: my_helper
INFO - 2021-12-15 04:40:53 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:40:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:40:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:40:53 --> Controller Class Initialized
INFO - 2021-12-15 04:40:57 --> Config Class Initialized
INFO - 2021-12-15 04:40:57 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:40:57 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:40:57 --> Utf8 Class Initialized
INFO - 2021-12-15 04:40:57 --> URI Class Initialized
INFO - 2021-12-15 04:40:57 --> Router Class Initialized
INFO - 2021-12-15 04:40:57 --> Output Class Initialized
INFO - 2021-12-15 04:40:57 --> Security Class Initialized
DEBUG - 2021-12-15 04:40:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:40:57 --> Input Class Initialized
INFO - 2021-12-15 04:40:57 --> Language Class Initialized
INFO - 2021-12-15 04:40:57 --> Language Class Initialized
INFO - 2021-12-15 04:40:57 --> Config Class Initialized
INFO - 2021-12-15 04:40:57 --> Loader Class Initialized
INFO - 2021-12-15 04:40:57 --> Helper loaded: url_helper
INFO - 2021-12-15 04:40:57 --> Helper loaded: file_helper
INFO - 2021-12-15 04:40:57 --> Helper loaded: form_helper
INFO - 2021-12-15 04:40:57 --> Helper loaded: my_helper
INFO - 2021-12-15 04:40:57 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:40:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:40:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:40:57 --> Controller Class Initialized
INFO - 2021-12-15 04:41:02 --> Config Class Initialized
INFO - 2021-12-15 04:41:02 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:02 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:02 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:02 --> URI Class Initialized
INFO - 2021-12-15 04:41:02 --> Router Class Initialized
INFO - 2021-12-15 04:41:02 --> Output Class Initialized
INFO - 2021-12-15 04:41:02 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:02 --> Input Class Initialized
INFO - 2021-12-15 04:41:02 --> Language Class Initialized
INFO - 2021-12-15 04:41:02 --> Language Class Initialized
INFO - 2021-12-15 04:41:02 --> Config Class Initialized
INFO - 2021-12-15 04:41:02 --> Loader Class Initialized
INFO - 2021-12-15 04:41:02 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:02 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:02 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:02 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:02 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:02 --> Controller Class Initialized
INFO - 2021-12-15 04:41:02 --> Final output sent to browser
DEBUG - 2021-12-15 04:41:02 --> Total execution time: 0.0350
INFO - 2021-12-15 04:41:20 --> Config Class Initialized
INFO - 2021-12-15 04:41:20 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:20 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:20 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:20 --> URI Class Initialized
DEBUG - 2021-12-15 04:41:20 --> No URI present. Default controller set.
INFO - 2021-12-15 04:41:20 --> Router Class Initialized
INFO - 2021-12-15 04:41:20 --> Output Class Initialized
INFO - 2021-12-15 04:41:20 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:20 --> Input Class Initialized
INFO - 2021-12-15 04:41:20 --> Language Class Initialized
INFO - 2021-12-15 04:41:20 --> Language Class Initialized
INFO - 2021-12-15 04:41:20 --> Config Class Initialized
INFO - 2021-12-15 04:41:20 --> Loader Class Initialized
INFO - 2021-12-15 04:41:20 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:20 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:20 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:20 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:20 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:20 --> Controller Class Initialized
DEBUG - 2021-12-15 04:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-15 04:41:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:41:20 --> Final output sent to browser
DEBUG - 2021-12-15 04:41:20 --> Total execution time: 0.1870
INFO - 2021-12-15 04:41:51 --> Config Class Initialized
INFO - 2021-12-15 04:41:51 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:51 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:51 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:51 --> URI Class Initialized
INFO - 2021-12-15 04:41:51 --> Router Class Initialized
INFO - 2021-12-15 04:41:51 --> Output Class Initialized
INFO - 2021-12-15 04:41:51 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:51 --> Input Class Initialized
INFO - 2021-12-15 04:41:51 --> Language Class Initialized
INFO - 2021-12-15 04:41:51 --> Language Class Initialized
INFO - 2021-12-15 04:41:51 --> Config Class Initialized
INFO - 2021-12-15 04:41:51 --> Loader Class Initialized
INFO - 2021-12-15 04:41:51 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:51 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:51 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:51 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:51 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:51 --> Controller Class Initialized
DEBUG - 2021-12-15 04:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-15 04:41:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:41:51 --> Final output sent to browser
DEBUG - 2021-12-15 04:41:51 --> Total execution time: 0.0470
INFO - 2021-12-15 04:41:51 --> Config Class Initialized
INFO - 2021-12-15 04:41:51 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:51 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:51 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:51 --> URI Class Initialized
INFO - 2021-12-15 04:41:51 --> Router Class Initialized
INFO - 2021-12-15 04:41:51 --> Output Class Initialized
INFO - 2021-12-15 04:41:51 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:51 --> Input Class Initialized
INFO - 2021-12-15 04:41:51 --> Language Class Initialized
INFO - 2021-12-15 04:41:51 --> Language Class Initialized
INFO - 2021-12-15 04:41:51 --> Config Class Initialized
INFO - 2021-12-15 04:41:51 --> Loader Class Initialized
INFO - 2021-12-15 04:41:51 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:51 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:51 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:51 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:51 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:51 --> Controller Class Initialized
INFO - 2021-12-15 04:41:52 --> Config Class Initialized
INFO - 2021-12-15 04:41:52 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:52 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:52 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:52 --> URI Class Initialized
INFO - 2021-12-15 04:41:52 --> Router Class Initialized
INFO - 2021-12-15 04:41:52 --> Output Class Initialized
INFO - 2021-12-15 04:41:52 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:52 --> Input Class Initialized
INFO - 2021-12-15 04:41:52 --> Language Class Initialized
INFO - 2021-12-15 04:41:52 --> Language Class Initialized
INFO - 2021-12-15 04:41:52 --> Config Class Initialized
INFO - 2021-12-15 04:41:52 --> Loader Class Initialized
INFO - 2021-12-15 04:41:52 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:52 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:52 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:52 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:52 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:52 --> Controller Class Initialized
INFO - 2021-12-15 04:41:52 --> Final output sent to browser
DEBUG - 2021-12-15 04:41:52 --> Total execution time: 0.0500
INFO - 2021-12-15 04:41:52 --> Config Class Initialized
INFO - 2021-12-15 04:41:52 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:52 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:52 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:52 --> URI Class Initialized
INFO - 2021-12-15 04:41:52 --> Router Class Initialized
INFO - 2021-12-15 04:41:52 --> Output Class Initialized
INFO - 2021-12-15 04:41:52 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:52 --> Input Class Initialized
INFO - 2021-12-15 04:41:53 --> Language Class Initialized
INFO - 2021-12-15 04:41:53 --> Language Class Initialized
INFO - 2021-12-15 04:41:53 --> Config Class Initialized
INFO - 2021-12-15 04:41:53 --> Loader Class Initialized
INFO - 2021-12-15 04:41:53 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:53 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:53 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:53 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:53 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:53 --> Controller Class Initialized
INFO - 2021-12-15 04:41:54 --> Config Class Initialized
INFO - 2021-12-15 04:41:54 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:54 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:54 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:54 --> URI Class Initialized
INFO - 2021-12-15 04:41:54 --> Router Class Initialized
INFO - 2021-12-15 04:41:54 --> Output Class Initialized
INFO - 2021-12-15 04:41:54 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:54 --> Input Class Initialized
INFO - 2021-12-15 04:41:54 --> Language Class Initialized
INFO - 2021-12-15 04:41:54 --> Language Class Initialized
INFO - 2021-12-15 04:41:54 --> Config Class Initialized
INFO - 2021-12-15 04:41:54 --> Loader Class Initialized
INFO - 2021-12-15 04:41:54 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:54 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:54 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:54 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:54 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:54 --> Controller Class Initialized
DEBUG - 2021-12-15 04:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-12-15 04:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:41:54 --> Final output sent to browser
DEBUG - 2021-12-15 04:41:54 --> Total execution time: 0.0530
INFO - 2021-12-15 04:41:54 --> Config Class Initialized
INFO - 2021-12-15 04:41:54 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:41:54 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:41:54 --> Utf8 Class Initialized
INFO - 2021-12-15 04:41:54 --> URI Class Initialized
INFO - 2021-12-15 04:41:54 --> Router Class Initialized
INFO - 2021-12-15 04:41:54 --> Output Class Initialized
INFO - 2021-12-15 04:41:54 --> Security Class Initialized
DEBUG - 2021-12-15 04:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:41:54 --> Input Class Initialized
INFO - 2021-12-15 04:41:54 --> Language Class Initialized
INFO - 2021-12-15 04:41:54 --> Language Class Initialized
INFO - 2021-12-15 04:41:54 --> Config Class Initialized
INFO - 2021-12-15 04:41:54 --> Loader Class Initialized
INFO - 2021-12-15 04:41:54 --> Helper loaded: url_helper
INFO - 2021-12-15 04:41:54 --> Helper loaded: file_helper
INFO - 2021-12-15 04:41:54 --> Helper loaded: form_helper
INFO - 2021-12-15 04:41:54 --> Helper loaded: my_helper
INFO - 2021-12-15 04:41:54 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:41:54 --> Controller Class Initialized
INFO - 2021-12-15 04:42:06 --> Config Class Initialized
INFO - 2021-12-15 04:42:06 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:42:06 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:42:06 --> Utf8 Class Initialized
INFO - 2021-12-15 04:42:06 --> URI Class Initialized
INFO - 2021-12-15 04:42:06 --> Router Class Initialized
INFO - 2021-12-15 04:42:06 --> Output Class Initialized
INFO - 2021-12-15 04:42:06 --> Security Class Initialized
DEBUG - 2021-12-15 04:42:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:42:06 --> Input Class Initialized
INFO - 2021-12-15 04:42:06 --> Language Class Initialized
INFO - 2021-12-15 04:42:06 --> Language Class Initialized
INFO - 2021-12-15 04:42:06 --> Config Class Initialized
INFO - 2021-12-15 04:42:06 --> Loader Class Initialized
INFO - 2021-12-15 04:42:06 --> Helper loaded: url_helper
INFO - 2021-12-15 04:42:06 --> Helper loaded: file_helper
INFO - 2021-12-15 04:42:06 --> Helper loaded: form_helper
INFO - 2021-12-15 04:42:06 --> Helper loaded: my_helper
INFO - 2021-12-15 04:42:06 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:42:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:42:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:42:06 --> Controller Class Initialized
INFO - 2021-12-15 04:42:06 --> Final output sent to browser
DEBUG - 2021-12-15 04:42:06 --> Total execution time: 0.0370
INFO - 2021-12-15 04:43:55 --> Config Class Initialized
INFO - 2021-12-15 04:43:55 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:43:55 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:43:55 --> Utf8 Class Initialized
INFO - 2021-12-15 04:43:55 --> URI Class Initialized
INFO - 2021-12-15 04:43:55 --> Router Class Initialized
INFO - 2021-12-15 04:43:55 --> Output Class Initialized
INFO - 2021-12-15 04:43:55 --> Security Class Initialized
DEBUG - 2021-12-15 04:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:43:55 --> Input Class Initialized
INFO - 2021-12-15 04:43:55 --> Language Class Initialized
INFO - 2021-12-15 04:43:55 --> Language Class Initialized
INFO - 2021-12-15 04:43:55 --> Config Class Initialized
INFO - 2021-12-15 04:43:55 --> Loader Class Initialized
INFO - 2021-12-15 04:43:55 --> Helper loaded: url_helper
INFO - 2021-12-15 04:43:55 --> Helper loaded: file_helper
INFO - 2021-12-15 04:43:55 --> Helper loaded: form_helper
INFO - 2021-12-15 04:43:55 --> Helper loaded: my_helper
INFO - 2021-12-15 04:43:55 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:43:55 --> Controller Class Initialized
DEBUG - 2021-12-15 04:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_kelas/views/list.php
DEBUG - 2021-12-15 04:43:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:43:55 --> Final output sent to browser
DEBUG - 2021-12-15 04:43:55 --> Total execution time: 0.0430
INFO - 2021-12-15 04:43:55 --> Config Class Initialized
INFO - 2021-12-15 04:43:55 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:43:55 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:43:55 --> Utf8 Class Initialized
INFO - 2021-12-15 04:43:55 --> URI Class Initialized
INFO - 2021-12-15 04:43:55 --> Router Class Initialized
INFO - 2021-12-15 04:43:55 --> Output Class Initialized
INFO - 2021-12-15 04:43:55 --> Security Class Initialized
DEBUG - 2021-12-15 04:43:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:43:55 --> Input Class Initialized
INFO - 2021-12-15 04:43:55 --> Language Class Initialized
INFO - 2021-12-15 04:43:55 --> Language Class Initialized
INFO - 2021-12-15 04:43:55 --> Config Class Initialized
INFO - 2021-12-15 04:43:55 --> Loader Class Initialized
INFO - 2021-12-15 04:43:55 --> Helper loaded: url_helper
INFO - 2021-12-15 04:43:55 --> Helper loaded: file_helper
INFO - 2021-12-15 04:43:55 --> Helper loaded: form_helper
INFO - 2021-12-15 04:43:55 --> Helper loaded: my_helper
INFO - 2021-12-15 04:43:55 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:43:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:43:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:43:55 --> Controller Class Initialized
INFO - 2021-12-15 04:43:56 --> Config Class Initialized
INFO - 2021-12-15 04:43:56 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:43:56 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:43:56 --> Utf8 Class Initialized
INFO - 2021-12-15 04:43:56 --> URI Class Initialized
INFO - 2021-12-15 04:43:56 --> Router Class Initialized
INFO - 2021-12-15 04:43:56 --> Output Class Initialized
INFO - 2021-12-15 04:43:56 --> Security Class Initialized
DEBUG - 2021-12-15 04:43:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:43:56 --> Input Class Initialized
INFO - 2021-12-15 04:43:56 --> Language Class Initialized
INFO - 2021-12-15 04:43:56 --> Language Class Initialized
INFO - 2021-12-15 04:43:56 --> Config Class Initialized
INFO - 2021-12-15 04:43:56 --> Loader Class Initialized
INFO - 2021-12-15 04:43:56 --> Helper loaded: url_helper
INFO - 2021-12-15 04:43:56 --> Helper loaded: file_helper
INFO - 2021-12-15 04:43:56 --> Helper loaded: form_helper
INFO - 2021-12-15 04:43:56 --> Helper loaded: my_helper
INFO - 2021-12-15 04:43:56 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:43:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:43:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:43:56 --> Controller Class Initialized
INFO - 2021-12-15 04:43:56 --> Final output sent to browser
DEBUG - 2021-12-15 04:43:56 --> Total execution time: 0.0400
INFO - 2021-12-15 04:43:58 --> Config Class Initialized
INFO - 2021-12-15 04:43:58 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:43:58 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:43:58 --> Utf8 Class Initialized
INFO - 2021-12-15 04:43:58 --> URI Class Initialized
INFO - 2021-12-15 04:43:58 --> Router Class Initialized
INFO - 2021-12-15 04:43:58 --> Output Class Initialized
INFO - 2021-12-15 04:43:58 --> Security Class Initialized
DEBUG - 2021-12-15 04:43:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:43:58 --> Input Class Initialized
INFO - 2021-12-15 04:43:58 --> Language Class Initialized
INFO - 2021-12-15 04:43:59 --> Language Class Initialized
INFO - 2021-12-15 04:43:59 --> Config Class Initialized
INFO - 2021-12-15 04:43:59 --> Loader Class Initialized
INFO - 2021-12-15 04:43:59 --> Helper loaded: url_helper
INFO - 2021-12-15 04:43:59 --> Helper loaded: file_helper
INFO - 2021-12-15 04:43:59 --> Helper loaded: form_helper
INFO - 2021-12-15 04:43:59 --> Helper loaded: my_helper
INFO - 2021-12-15 04:43:59 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:43:59 --> Controller Class Initialized
INFO - 2021-12-15 04:43:59 --> Final output sent to browser
DEBUG - 2021-12-15 04:43:59 --> Total execution time: 0.0460
INFO - 2021-12-15 04:43:59 --> Config Class Initialized
INFO - 2021-12-15 04:43:59 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:43:59 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:43:59 --> Utf8 Class Initialized
INFO - 2021-12-15 04:43:59 --> URI Class Initialized
INFO - 2021-12-15 04:43:59 --> Router Class Initialized
INFO - 2021-12-15 04:43:59 --> Output Class Initialized
INFO - 2021-12-15 04:43:59 --> Security Class Initialized
DEBUG - 2021-12-15 04:43:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:43:59 --> Input Class Initialized
INFO - 2021-12-15 04:43:59 --> Language Class Initialized
INFO - 2021-12-15 04:43:59 --> Language Class Initialized
INFO - 2021-12-15 04:43:59 --> Config Class Initialized
INFO - 2021-12-15 04:43:59 --> Loader Class Initialized
INFO - 2021-12-15 04:43:59 --> Helper loaded: url_helper
INFO - 2021-12-15 04:43:59 --> Helper loaded: file_helper
INFO - 2021-12-15 04:43:59 --> Helper loaded: form_helper
INFO - 2021-12-15 04:43:59 --> Helper loaded: my_helper
INFO - 2021-12-15 04:43:59 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:43:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:43:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:43:59 --> Controller Class Initialized
INFO - 2021-12-15 04:44:04 --> Config Class Initialized
INFO - 2021-12-15 04:44:04 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:44:04 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:44:04 --> Utf8 Class Initialized
INFO - 2021-12-15 04:44:04 --> URI Class Initialized
INFO - 2021-12-15 04:44:04 --> Router Class Initialized
INFO - 2021-12-15 04:44:04 --> Output Class Initialized
INFO - 2021-12-15 04:44:04 --> Security Class Initialized
DEBUG - 2021-12-15 04:44:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:44:04 --> Input Class Initialized
INFO - 2021-12-15 04:44:04 --> Language Class Initialized
INFO - 2021-12-15 04:44:04 --> Language Class Initialized
INFO - 2021-12-15 04:44:04 --> Config Class Initialized
INFO - 2021-12-15 04:44:04 --> Loader Class Initialized
INFO - 2021-12-15 04:44:04 --> Helper loaded: url_helper
INFO - 2021-12-15 04:44:04 --> Helper loaded: file_helper
INFO - 2021-12-15 04:44:04 --> Helper loaded: form_helper
INFO - 2021-12-15 04:44:04 --> Helper loaded: my_helper
INFO - 2021-12-15 04:44:04 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:44:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:44:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:44:05 --> Controller Class Initialized
DEBUG - 2021-12-15 04:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 04:44:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:44:05 --> Final output sent to browser
DEBUG - 2021-12-15 04:44:05 --> Total execution time: 0.0530
INFO - 2021-12-15 04:44:07 --> Config Class Initialized
INFO - 2021-12-15 04:44:07 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:44:07 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:44:07 --> Utf8 Class Initialized
INFO - 2021-12-15 04:44:07 --> URI Class Initialized
INFO - 2021-12-15 04:44:07 --> Router Class Initialized
INFO - 2021-12-15 04:44:07 --> Output Class Initialized
INFO - 2021-12-15 04:44:07 --> Security Class Initialized
DEBUG - 2021-12-15 04:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:44:07 --> Input Class Initialized
INFO - 2021-12-15 04:44:07 --> Language Class Initialized
INFO - 2021-12-15 04:44:07 --> Language Class Initialized
INFO - 2021-12-15 04:44:07 --> Config Class Initialized
INFO - 2021-12-15 04:44:07 --> Loader Class Initialized
INFO - 2021-12-15 04:44:07 --> Helper loaded: url_helper
INFO - 2021-12-15 04:44:07 --> Helper loaded: file_helper
INFO - 2021-12-15 04:44:07 --> Helper loaded: form_helper
INFO - 2021-12-15 04:44:07 --> Helper loaded: my_helper
INFO - 2021-12-15 04:44:07 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:44:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:44:07 --> Controller Class Initialized
DEBUG - 2021-12-15 04:44:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 04:44:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:44:07 --> Final output sent to browser
DEBUG - 2021-12-15 04:44:07 --> Total execution time: 0.0830
INFO - 2021-12-15 04:44:12 --> Config Class Initialized
INFO - 2021-12-15 04:44:12 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:44:12 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:44:12 --> Utf8 Class Initialized
INFO - 2021-12-15 04:44:12 --> URI Class Initialized
INFO - 2021-12-15 04:44:12 --> Router Class Initialized
INFO - 2021-12-15 04:44:12 --> Output Class Initialized
INFO - 2021-12-15 04:44:12 --> Security Class Initialized
DEBUG - 2021-12-15 04:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:44:12 --> Input Class Initialized
INFO - 2021-12-15 04:44:12 --> Language Class Initialized
INFO - 2021-12-15 04:44:12 --> Language Class Initialized
INFO - 2021-12-15 04:44:12 --> Config Class Initialized
INFO - 2021-12-15 04:44:12 --> Loader Class Initialized
INFO - 2021-12-15 04:44:12 --> Helper loaded: url_helper
INFO - 2021-12-15 04:44:12 --> Helper loaded: file_helper
INFO - 2021-12-15 04:44:12 --> Helper loaded: form_helper
INFO - 2021-12-15 04:44:12 --> Helper loaded: my_helper
INFO - 2021-12-15 04:44:12 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:44:12 --> Controller Class Initialized
DEBUG - 2021-12-15 04:44:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-12-15 04:44:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:44:12 --> Final output sent to browser
DEBUG - 2021-12-15 04:44:12 --> Total execution time: 0.0400
INFO - 2021-12-15 04:44:12 --> Config Class Initialized
INFO - 2021-12-15 04:44:12 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:44:12 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:44:12 --> Utf8 Class Initialized
INFO - 2021-12-15 04:44:12 --> URI Class Initialized
INFO - 2021-12-15 04:44:12 --> Router Class Initialized
INFO - 2021-12-15 04:44:12 --> Output Class Initialized
INFO - 2021-12-15 04:44:12 --> Security Class Initialized
DEBUG - 2021-12-15 04:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:44:12 --> Input Class Initialized
INFO - 2021-12-15 04:44:12 --> Language Class Initialized
INFO - 2021-12-15 04:44:12 --> Language Class Initialized
INFO - 2021-12-15 04:44:12 --> Config Class Initialized
INFO - 2021-12-15 04:44:12 --> Loader Class Initialized
INFO - 2021-12-15 04:44:12 --> Helper loaded: url_helper
INFO - 2021-12-15 04:44:12 --> Helper loaded: file_helper
INFO - 2021-12-15 04:44:12 --> Helper loaded: form_helper
INFO - 2021-12-15 04:44:12 --> Helper loaded: my_helper
INFO - 2021-12-15 04:44:12 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:44:12 --> Controller Class Initialized
INFO - 2021-12-15 04:44:13 --> Config Class Initialized
INFO - 2021-12-15 04:44:13 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:44:13 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:44:13 --> Utf8 Class Initialized
INFO - 2021-12-15 04:44:13 --> URI Class Initialized
INFO - 2021-12-15 04:44:13 --> Router Class Initialized
INFO - 2021-12-15 04:44:13 --> Output Class Initialized
INFO - 2021-12-15 04:44:13 --> Security Class Initialized
DEBUG - 2021-12-15 04:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:44:13 --> Input Class Initialized
INFO - 2021-12-15 04:44:13 --> Language Class Initialized
INFO - 2021-12-15 04:44:13 --> Language Class Initialized
INFO - 2021-12-15 04:44:13 --> Config Class Initialized
INFO - 2021-12-15 04:44:13 --> Loader Class Initialized
INFO - 2021-12-15 04:44:13 --> Helper loaded: url_helper
INFO - 2021-12-15 04:44:13 --> Helper loaded: file_helper
INFO - 2021-12-15 04:44:13 --> Helper loaded: form_helper
INFO - 2021-12-15 04:44:13 --> Helper loaded: my_helper
INFO - 2021-12-15 04:44:13 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:44:13 --> Controller Class Initialized
INFO - 2021-12-15 04:44:13 --> Final output sent to browser
DEBUG - 2021-12-15 04:44:13 --> Total execution time: 0.0560
INFO - 2021-12-15 04:44:13 --> Config Class Initialized
INFO - 2021-12-15 04:44:13 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:44:13 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:44:13 --> Utf8 Class Initialized
INFO - 2021-12-15 04:44:13 --> URI Class Initialized
INFO - 2021-12-15 04:44:13 --> Router Class Initialized
INFO - 2021-12-15 04:44:13 --> Output Class Initialized
INFO - 2021-12-15 04:44:13 --> Security Class Initialized
DEBUG - 2021-12-15 04:44:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:44:13 --> Input Class Initialized
INFO - 2021-12-15 04:44:13 --> Language Class Initialized
INFO - 2021-12-15 04:44:13 --> Language Class Initialized
INFO - 2021-12-15 04:44:13 --> Config Class Initialized
INFO - 2021-12-15 04:44:13 --> Loader Class Initialized
INFO - 2021-12-15 04:44:13 --> Helper loaded: url_helper
INFO - 2021-12-15 04:44:13 --> Helper loaded: file_helper
INFO - 2021-12-15 04:44:13 --> Helper loaded: form_helper
INFO - 2021-12-15 04:44:13 --> Helper loaded: my_helper
INFO - 2021-12-15 04:44:13 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:44:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:44:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:44:13 --> Controller Class Initialized
INFO - 2021-12-15 04:44:16 --> Config Class Initialized
INFO - 2021-12-15 04:44:16 --> Hooks Class Initialized
DEBUG - 2021-12-15 04:44:16 --> UTF-8 Support Enabled
INFO - 2021-12-15 04:44:16 --> Utf8 Class Initialized
INFO - 2021-12-15 04:44:16 --> URI Class Initialized
INFO - 2021-12-15 04:44:16 --> Router Class Initialized
INFO - 2021-12-15 04:44:16 --> Output Class Initialized
INFO - 2021-12-15 04:44:16 --> Security Class Initialized
DEBUG - 2021-12-15 04:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 04:44:16 --> Input Class Initialized
INFO - 2021-12-15 04:44:16 --> Language Class Initialized
INFO - 2021-12-15 04:44:16 --> Language Class Initialized
INFO - 2021-12-15 04:44:16 --> Config Class Initialized
INFO - 2021-12-15 04:44:16 --> Loader Class Initialized
INFO - 2021-12-15 04:44:16 --> Helper loaded: url_helper
INFO - 2021-12-15 04:44:16 --> Helper loaded: file_helper
INFO - 2021-12-15 04:44:16 --> Helper loaded: form_helper
INFO - 2021-12-15 04:44:16 --> Helper loaded: my_helper
INFO - 2021-12-15 04:44:16 --> Database Driver Class Initialized
DEBUG - 2021-12-15 04:44:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 04:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 04:44:16 --> Controller Class Initialized
DEBUG - 2021-12-15 04:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 04:44:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 04:44:16 --> Final output sent to browser
DEBUG - 2021-12-15 04:44:16 --> Total execution time: 0.0510
INFO - 2021-12-15 05:02:19 --> Config Class Initialized
INFO - 2021-12-15 05:02:19 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:02:19 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:02:19 --> Utf8 Class Initialized
INFO - 2021-12-15 05:02:19 --> URI Class Initialized
INFO - 2021-12-15 05:02:19 --> Router Class Initialized
INFO - 2021-12-15 05:02:19 --> Output Class Initialized
INFO - 2021-12-15 05:02:19 --> Security Class Initialized
DEBUG - 2021-12-15 05:02:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:02:19 --> Input Class Initialized
INFO - 2021-12-15 05:02:19 --> Language Class Initialized
INFO - 2021-12-15 05:02:19 --> Language Class Initialized
INFO - 2021-12-15 05:02:19 --> Config Class Initialized
INFO - 2021-12-15 05:02:19 --> Loader Class Initialized
INFO - 2021-12-15 05:02:19 --> Helper loaded: url_helper
INFO - 2021-12-15 05:02:19 --> Helper loaded: file_helper
INFO - 2021-12-15 05:02:19 --> Helper loaded: form_helper
INFO - 2021-12-15 05:02:19 --> Helper loaded: my_helper
INFO - 2021-12-15 05:02:19 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:02:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:02:19 --> Controller Class Initialized
DEBUG - 2021-12-15 05:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:02:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:02:19 --> Final output sent to browser
DEBUG - 2021-12-15 05:02:19 --> Total execution time: 0.0460
INFO - 2021-12-15 05:04:17 --> Config Class Initialized
INFO - 2021-12-15 05:04:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:17 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:17 --> URI Class Initialized
INFO - 2021-12-15 05:04:17 --> Router Class Initialized
INFO - 2021-12-15 05:04:17 --> Output Class Initialized
INFO - 2021-12-15 05:04:17 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:17 --> Input Class Initialized
INFO - 2021-12-15 05:04:17 --> Language Class Initialized
INFO - 2021-12-15 05:04:17 --> Language Class Initialized
INFO - 2021-12-15 05:04:17 --> Config Class Initialized
INFO - 2021-12-15 05:04:17 --> Loader Class Initialized
INFO - 2021-12-15 05:04:17 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:17 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:17 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:17 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:17 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:17 --> Controller Class Initialized
INFO - 2021-12-15 05:04:17 --> Config Class Initialized
INFO - 2021-12-15 05:04:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:17 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:17 --> URI Class Initialized
INFO - 2021-12-15 05:04:17 --> Router Class Initialized
INFO - 2021-12-15 05:04:17 --> Output Class Initialized
INFO - 2021-12-15 05:04:17 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:17 --> Input Class Initialized
INFO - 2021-12-15 05:04:17 --> Language Class Initialized
INFO - 2021-12-15 05:04:17 --> Language Class Initialized
INFO - 2021-12-15 05:04:17 --> Config Class Initialized
INFO - 2021-12-15 05:04:17 --> Loader Class Initialized
INFO - 2021-12-15 05:04:17 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:17 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:17 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:17 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:17 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:17 --> Controller Class Initialized
DEBUG - 2021-12-15 05:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:04:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:04:17 --> Final output sent to browser
DEBUG - 2021-12-15 05:04:17 --> Total execution time: 0.0430
INFO - 2021-12-15 05:04:25 --> Config Class Initialized
INFO - 2021-12-15 05:04:25 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:25 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:25 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:25 --> URI Class Initialized
DEBUG - 2021-12-15 05:04:25 --> No URI present. Default controller set.
INFO - 2021-12-15 05:04:25 --> Router Class Initialized
INFO - 2021-12-15 05:04:25 --> Output Class Initialized
INFO - 2021-12-15 05:04:25 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:25 --> Input Class Initialized
INFO - 2021-12-15 05:04:25 --> Language Class Initialized
INFO - 2021-12-15 05:04:25 --> Language Class Initialized
INFO - 2021-12-15 05:04:25 --> Config Class Initialized
INFO - 2021-12-15 05:04:25 --> Loader Class Initialized
INFO - 2021-12-15 05:04:25 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:25 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:25 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:25 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:25 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:25 --> Controller Class Initialized
DEBUG - 2021-12-15 05:04:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-15 05:04:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:04:25 --> Final output sent to browser
DEBUG - 2021-12-15 05:04:25 --> Total execution time: 0.1540
INFO - 2021-12-15 05:04:26 --> Config Class Initialized
INFO - 2021-12-15 05:04:26 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:26 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:26 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:26 --> URI Class Initialized
INFO - 2021-12-15 05:04:26 --> Router Class Initialized
INFO - 2021-12-15 05:04:26 --> Output Class Initialized
INFO - 2021-12-15 05:04:26 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:26 --> Input Class Initialized
INFO - 2021-12-15 05:04:26 --> Language Class Initialized
INFO - 2021-12-15 05:04:26 --> Language Class Initialized
INFO - 2021-12-15 05:04:26 --> Config Class Initialized
INFO - 2021-12-15 05:04:26 --> Loader Class Initialized
INFO - 2021-12-15 05:04:26 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:26 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:26 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:26 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:26 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:26 --> Controller Class Initialized
DEBUG - 2021-12-15 05:04:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2021-12-15 05:04:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:04:26 --> Final output sent to browser
DEBUG - 2021-12-15 05:04:26 --> Total execution time: 0.0510
INFO - 2021-12-15 05:04:27 --> Config Class Initialized
INFO - 2021-12-15 05:04:27 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:27 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:27 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:27 --> URI Class Initialized
INFO - 2021-12-15 05:04:27 --> Router Class Initialized
INFO - 2021-12-15 05:04:27 --> Output Class Initialized
INFO - 2021-12-15 05:04:27 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:27 --> Input Class Initialized
INFO - 2021-12-15 05:04:27 --> Language Class Initialized
INFO - 2021-12-15 05:04:27 --> Language Class Initialized
INFO - 2021-12-15 05:04:27 --> Config Class Initialized
INFO - 2021-12-15 05:04:27 --> Loader Class Initialized
INFO - 2021-12-15 05:04:27 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:27 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:27 --> Controller Class Initialized
INFO - 2021-12-15 05:04:27 --> Config Class Initialized
INFO - 2021-12-15 05:04:27 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:27 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:27 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:27 --> URI Class Initialized
INFO - 2021-12-15 05:04:27 --> Router Class Initialized
INFO - 2021-12-15 05:04:27 --> Output Class Initialized
INFO - 2021-12-15 05:04:27 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:27 --> Input Class Initialized
INFO - 2021-12-15 05:04:27 --> Language Class Initialized
INFO - 2021-12-15 05:04:27 --> Language Class Initialized
INFO - 2021-12-15 05:04:27 --> Config Class Initialized
INFO - 2021-12-15 05:04:27 --> Loader Class Initialized
INFO - 2021-12-15 05:04:27 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:27 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:27 --> Controller Class Initialized
DEBUG - 2021-12-15 05:04:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-12-15 05:04:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:04:27 --> Final output sent to browser
DEBUG - 2021-12-15 05:04:27 --> Total execution time: 0.0440
INFO - 2021-12-15 05:04:27 --> Config Class Initialized
INFO - 2021-12-15 05:04:27 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:27 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:27 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:27 --> URI Class Initialized
INFO - 2021-12-15 05:04:27 --> Router Class Initialized
INFO - 2021-12-15 05:04:27 --> Output Class Initialized
INFO - 2021-12-15 05:04:27 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:27 --> Input Class Initialized
INFO - 2021-12-15 05:04:27 --> Language Class Initialized
INFO - 2021-12-15 05:04:27 --> Language Class Initialized
INFO - 2021-12-15 05:04:27 --> Config Class Initialized
INFO - 2021-12-15 05:04:27 --> Loader Class Initialized
INFO - 2021-12-15 05:04:27 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:27 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:27 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:27 --> Controller Class Initialized
INFO - 2021-12-15 05:04:28 --> Config Class Initialized
INFO - 2021-12-15 05:04:28 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:28 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:28 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:28 --> URI Class Initialized
INFO - 2021-12-15 05:04:28 --> Router Class Initialized
INFO - 2021-12-15 05:04:28 --> Output Class Initialized
INFO - 2021-12-15 05:04:28 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:28 --> Input Class Initialized
INFO - 2021-12-15 05:04:28 --> Language Class Initialized
INFO - 2021-12-15 05:04:28 --> Language Class Initialized
INFO - 2021-12-15 05:04:28 --> Config Class Initialized
INFO - 2021-12-15 05:04:28 --> Loader Class Initialized
INFO - 2021-12-15 05:04:28 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:28 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:28 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:28 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:28 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:28 --> Controller Class Initialized
INFO - 2021-12-15 05:04:29 --> Config Class Initialized
INFO - 2021-12-15 05:04:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:29 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:29 --> URI Class Initialized
INFO - 2021-12-15 05:04:29 --> Router Class Initialized
INFO - 2021-12-15 05:04:29 --> Output Class Initialized
INFO - 2021-12-15 05:04:29 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:29 --> Input Class Initialized
INFO - 2021-12-15 05:04:29 --> Language Class Initialized
INFO - 2021-12-15 05:04:29 --> Language Class Initialized
INFO - 2021-12-15 05:04:29 --> Config Class Initialized
INFO - 2021-12-15 05:04:29 --> Loader Class Initialized
INFO - 2021-12-15 05:04:29 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:29 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:29 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:29 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:29 --> Controller Class Initialized
INFO - 2021-12-15 05:04:29 --> Config Class Initialized
INFO - 2021-12-15 05:04:29 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:29 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:29 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:29 --> URI Class Initialized
INFO - 2021-12-15 05:04:29 --> Router Class Initialized
INFO - 2021-12-15 05:04:29 --> Output Class Initialized
INFO - 2021-12-15 05:04:29 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:29 --> Input Class Initialized
INFO - 2021-12-15 05:04:29 --> Language Class Initialized
INFO - 2021-12-15 05:04:29 --> Language Class Initialized
INFO - 2021-12-15 05:04:29 --> Config Class Initialized
INFO - 2021-12-15 05:04:29 --> Loader Class Initialized
INFO - 2021-12-15 05:04:29 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:29 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:29 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:29 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:29 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:29 --> Controller Class Initialized
INFO - 2021-12-15 05:04:30 --> Config Class Initialized
INFO - 2021-12-15 05:04:30 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:30 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:30 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:30 --> URI Class Initialized
INFO - 2021-12-15 05:04:30 --> Router Class Initialized
INFO - 2021-12-15 05:04:30 --> Output Class Initialized
INFO - 2021-12-15 05:04:30 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:30 --> Input Class Initialized
INFO - 2021-12-15 05:04:30 --> Language Class Initialized
INFO - 2021-12-15 05:04:30 --> Language Class Initialized
INFO - 2021-12-15 05:04:30 --> Config Class Initialized
INFO - 2021-12-15 05:04:30 --> Loader Class Initialized
INFO - 2021-12-15 05:04:30 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:30 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:30 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:30 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:30 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:30 --> Controller Class Initialized
INFO - 2021-12-15 05:04:37 --> Config Class Initialized
INFO - 2021-12-15 05:04:37 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:37 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:37 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:37 --> URI Class Initialized
INFO - 2021-12-15 05:04:37 --> Router Class Initialized
INFO - 2021-12-15 05:04:37 --> Output Class Initialized
INFO - 2021-12-15 05:04:37 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:37 --> Input Class Initialized
INFO - 2021-12-15 05:04:37 --> Language Class Initialized
INFO - 2021-12-15 05:04:37 --> Language Class Initialized
INFO - 2021-12-15 05:04:37 --> Config Class Initialized
INFO - 2021-12-15 05:04:37 --> Loader Class Initialized
INFO - 2021-12-15 05:04:37 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:37 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:37 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:37 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:37 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:37 --> Controller Class Initialized
DEBUG - 2021-12-15 05:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:04:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:04:37 --> Final output sent to browser
DEBUG - 2021-12-15 05:04:37 --> Total execution time: 0.0570
INFO - 2021-12-15 05:04:38 --> Config Class Initialized
INFO - 2021-12-15 05:04:38 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:38 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:38 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:38 --> URI Class Initialized
INFO - 2021-12-15 05:04:38 --> Router Class Initialized
INFO - 2021-12-15 05:04:38 --> Output Class Initialized
INFO - 2021-12-15 05:04:38 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:38 --> Input Class Initialized
INFO - 2021-12-15 05:04:38 --> Language Class Initialized
INFO - 2021-12-15 05:04:38 --> Language Class Initialized
INFO - 2021-12-15 05:04:38 --> Config Class Initialized
INFO - 2021-12-15 05:04:38 --> Loader Class Initialized
INFO - 2021-12-15 05:04:38 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:38 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:38 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:38 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:38 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:38 --> Controller Class Initialized
DEBUG - 2021-12-15 05:04:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:04:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:04:38 --> Final output sent to browser
DEBUG - 2021-12-15 05:04:38 --> Total execution time: 0.0460
INFO - 2021-12-15 05:04:41 --> Config Class Initialized
INFO - 2021-12-15 05:04:41 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:04:41 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:04:41 --> Utf8 Class Initialized
INFO - 2021-12-15 05:04:41 --> URI Class Initialized
INFO - 2021-12-15 05:04:41 --> Router Class Initialized
INFO - 2021-12-15 05:04:41 --> Output Class Initialized
INFO - 2021-12-15 05:04:41 --> Security Class Initialized
DEBUG - 2021-12-15 05:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:04:41 --> Input Class Initialized
INFO - 2021-12-15 05:04:41 --> Language Class Initialized
INFO - 2021-12-15 05:04:41 --> Language Class Initialized
INFO - 2021-12-15 05:04:41 --> Config Class Initialized
INFO - 2021-12-15 05:04:41 --> Loader Class Initialized
INFO - 2021-12-15 05:04:41 --> Helper loaded: url_helper
INFO - 2021-12-15 05:04:41 --> Helper loaded: file_helper
INFO - 2021-12-15 05:04:41 --> Helper loaded: form_helper
INFO - 2021-12-15 05:04:41 --> Helper loaded: my_helper
INFO - 2021-12-15 05:04:41 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:04:41 --> Controller Class Initialized
DEBUG - 2021-12-15 05:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:04:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:04:41 --> Final output sent to browser
DEBUG - 2021-12-15 05:04:41 --> Total execution time: 0.0430
INFO - 2021-12-15 05:05:02 --> Config Class Initialized
INFO - 2021-12-15 05:05:02 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:05:02 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:05:02 --> Utf8 Class Initialized
INFO - 2021-12-15 05:05:02 --> URI Class Initialized
INFO - 2021-12-15 05:05:02 --> Router Class Initialized
INFO - 2021-12-15 05:05:02 --> Output Class Initialized
INFO - 2021-12-15 05:05:02 --> Security Class Initialized
DEBUG - 2021-12-15 05:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:05:02 --> Input Class Initialized
INFO - 2021-12-15 05:05:02 --> Language Class Initialized
INFO - 2021-12-15 05:05:02 --> Language Class Initialized
INFO - 2021-12-15 05:05:02 --> Config Class Initialized
INFO - 2021-12-15 05:05:02 --> Loader Class Initialized
INFO - 2021-12-15 05:05:02 --> Helper loaded: url_helper
INFO - 2021-12-15 05:05:02 --> Helper loaded: file_helper
INFO - 2021-12-15 05:05:02 --> Helper loaded: form_helper
INFO - 2021-12-15 05:05:02 --> Helper loaded: my_helper
INFO - 2021-12-15 05:05:02 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:05:02 --> Controller Class Initialized
DEBUG - 2021-12-15 05:05:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:05:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:05:02 --> Final output sent to browser
DEBUG - 2021-12-15 05:05:02 --> Total execution time: 0.0500
INFO - 2021-12-15 05:38:14 --> Config Class Initialized
INFO - 2021-12-15 05:38:14 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:38:14 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:38:14 --> Utf8 Class Initialized
INFO - 2021-12-15 05:38:14 --> URI Class Initialized
INFO - 2021-12-15 05:38:14 --> Router Class Initialized
INFO - 2021-12-15 05:38:14 --> Output Class Initialized
INFO - 2021-12-15 05:38:14 --> Security Class Initialized
DEBUG - 2021-12-15 05:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:38:14 --> Input Class Initialized
INFO - 2021-12-15 05:38:14 --> Language Class Initialized
INFO - 2021-12-15 05:38:14 --> Language Class Initialized
INFO - 2021-12-15 05:38:14 --> Config Class Initialized
INFO - 2021-12-15 05:38:14 --> Loader Class Initialized
INFO - 2021-12-15 05:38:14 --> Helper loaded: url_helper
INFO - 2021-12-15 05:38:14 --> Helper loaded: file_helper
INFO - 2021-12-15 05:38:14 --> Helper loaded: form_helper
INFO - 2021-12-15 05:38:14 --> Helper loaded: my_helper
INFO - 2021-12-15 05:38:14 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:38:14 --> Controller Class Initialized
INFO - 2021-12-15 05:38:14 --> Config Class Initialized
INFO - 2021-12-15 05:38:14 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:38:14 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:38:14 --> Utf8 Class Initialized
INFO - 2021-12-15 05:38:14 --> URI Class Initialized
INFO - 2021-12-15 05:38:14 --> Router Class Initialized
INFO - 2021-12-15 05:38:14 --> Output Class Initialized
INFO - 2021-12-15 05:38:14 --> Security Class Initialized
DEBUG - 2021-12-15 05:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:38:14 --> Input Class Initialized
INFO - 2021-12-15 05:38:14 --> Language Class Initialized
INFO - 2021-12-15 05:38:14 --> Language Class Initialized
INFO - 2021-12-15 05:38:14 --> Config Class Initialized
INFO - 2021-12-15 05:38:14 --> Loader Class Initialized
INFO - 2021-12-15 05:38:14 --> Helper loaded: url_helper
INFO - 2021-12-15 05:38:14 --> Helper loaded: file_helper
INFO - 2021-12-15 05:38:14 --> Helper loaded: form_helper
INFO - 2021-12-15 05:38:14 --> Helper loaded: my_helper
INFO - 2021-12-15 05:38:14 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:38:14 --> Controller Class Initialized
DEBUG - 2021-12-15 05:38:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:38:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:38:14 --> Final output sent to browser
DEBUG - 2021-12-15 05:38:14 --> Total execution time: 0.0430
INFO - 2021-12-15 05:38:35 --> Config Class Initialized
INFO - 2021-12-15 05:38:35 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:38:35 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:38:35 --> Utf8 Class Initialized
INFO - 2021-12-15 05:38:35 --> URI Class Initialized
INFO - 2021-12-15 05:38:35 --> Router Class Initialized
INFO - 2021-12-15 05:38:35 --> Output Class Initialized
INFO - 2021-12-15 05:38:35 --> Security Class Initialized
DEBUG - 2021-12-15 05:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:38:35 --> Input Class Initialized
INFO - 2021-12-15 05:38:35 --> Language Class Initialized
INFO - 2021-12-15 05:38:35 --> Language Class Initialized
INFO - 2021-12-15 05:38:35 --> Config Class Initialized
INFO - 2021-12-15 05:38:35 --> Loader Class Initialized
INFO - 2021-12-15 05:38:35 --> Helper loaded: url_helper
INFO - 2021-12-15 05:38:35 --> Helper loaded: file_helper
INFO - 2021-12-15 05:38:35 --> Helper loaded: form_helper
INFO - 2021-12-15 05:38:35 --> Helper loaded: my_helper
INFO - 2021-12-15 05:38:35 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:38:35 --> Controller Class Initialized
DEBUG - 2021-12-15 05:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:38:35 --> Final output sent to browser
DEBUG - 2021-12-15 05:38:35 --> Total execution time: 0.0590
INFO - 2021-12-15 05:41:02 --> Config Class Initialized
INFO - 2021-12-15 05:41:02 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:41:02 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:41:02 --> Utf8 Class Initialized
INFO - 2021-12-15 05:41:02 --> URI Class Initialized
INFO - 2021-12-15 05:41:02 --> Router Class Initialized
INFO - 2021-12-15 05:41:02 --> Output Class Initialized
INFO - 2021-12-15 05:41:02 --> Security Class Initialized
DEBUG - 2021-12-15 05:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:41:02 --> Input Class Initialized
INFO - 2021-12-15 05:41:02 --> Language Class Initialized
INFO - 2021-12-15 05:41:02 --> Language Class Initialized
INFO - 2021-12-15 05:41:02 --> Config Class Initialized
INFO - 2021-12-15 05:41:02 --> Loader Class Initialized
INFO - 2021-12-15 05:41:02 --> Helper loaded: url_helper
INFO - 2021-12-15 05:41:02 --> Helper loaded: file_helper
INFO - 2021-12-15 05:41:02 --> Helper loaded: form_helper
INFO - 2021-12-15 05:41:02 --> Helper loaded: my_helper
INFO - 2021-12-15 05:41:02 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:41:02 --> Controller Class Initialized
INFO - 2021-12-15 05:41:02 --> Config Class Initialized
INFO - 2021-12-15 05:41:02 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:41:02 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:41:02 --> Utf8 Class Initialized
INFO - 2021-12-15 05:41:02 --> URI Class Initialized
INFO - 2021-12-15 05:41:02 --> Router Class Initialized
INFO - 2021-12-15 05:41:02 --> Output Class Initialized
INFO - 2021-12-15 05:41:02 --> Security Class Initialized
DEBUG - 2021-12-15 05:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:41:02 --> Input Class Initialized
INFO - 2021-12-15 05:41:02 --> Language Class Initialized
INFO - 2021-12-15 05:41:02 --> Language Class Initialized
INFO - 2021-12-15 05:41:02 --> Config Class Initialized
INFO - 2021-12-15 05:41:02 --> Loader Class Initialized
INFO - 2021-12-15 05:41:02 --> Helper loaded: url_helper
INFO - 2021-12-15 05:41:02 --> Helper loaded: file_helper
INFO - 2021-12-15 05:41:02 --> Helper loaded: form_helper
INFO - 2021-12-15 05:41:02 --> Helper loaded: my_helper
INFO - 2021-12-15 05:41:02 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:41:02 --> Controller Class Initialized
DEBUG - 2021-12-15 05:41:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:41:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:41:02 --> Final output sent to browser
DEBUG - 2021-12-15 05:41:02 --> Total execution time: 0.0420
INFO - 2021-12-15 05:41:58 --> Config Class Initialized
INFO - 2021-12-15 05:41:58 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:41:58 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:41:58 --> Utf8 Class Initialized
INFO - 2021-12-15 05:41:58 --> URI Class Initialized
INFO - 2021-12-15 05:41:58 --> Router Class Initialized
INFO - 2021-12-15 05:41:58 --> Output Class Initialized
INFO - 2021-12-15 05:41:58 --> Security Class Initialized
DEBUG - 2021-12-15 05:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:41:58 --> Input Class Initialized
INFO - 2021-12-15 05:41:58 --> Language Class Initialized
INFO - 2021-12-15 05:41:58 --> Language Class Initialized
INFO - 2021-12-15 05:41:58 --> Config Class Initialized
INFO - 2021-12-15 05:41:58 --> Loader Class Initialized
INFO - 2021-12-15 05:41:58 --> Helper loaded: url_helper
INFO - 2021-12-15 05:41:58 --> Helper loaded: file_helper
INFO - 2021-12-15 05:41:58 --> Helper loaded: form_helper
INFO - 2021-12-15 05:41:58 --> Helper loaded: my_helper
INFO - 2021-12-15 05:41:58 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:41:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:41:58 --> Controller Class Initialized
DEBUG - 2021-12-15 05:41:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:41:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:41:58 --> Final output sent to browser
DEBUG - 2021-12-15 05:41:58 --> Total execution time: 0.0470
INFO - 2021-12-15 05:42:21 --> Config Class Initialized
INFO - 2021-12-15 05:42:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:42:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:42:21 --> Utf8 Class Initialized
INFO - 2021-12-15 05:42:21 --> URI Class Initialized
INFO - 2021-12-15 05:42:21 --> Router Class Initialized
INFO - 2021-12-15 05:42:21 --> Output Class Initialized
INFO - 2021-12-15 05:42:21 --> Security Class Initialized
DEBUG - 2021-12-15 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:42:21 --> Input Class Initialized
INFO - 2021-12-15 05:42:21 --> Language Class Initialized
INFO - 2021-12-15 05:42:21 --> Language Class Initialized
INFO - 2021-12-15 05:42:21 --> Config Class Initialized
INFO - 2021-12-15 05:42:21 --> Loader Class Initialized
INFO - 2021-12-15 05:42:21 --> Helper loaded: url_helper
INFO - 2021-12-15 05:42:21 --> Helper loaded: file_helper
INFO - 2021-12-15 05:42:21 --> Helper loaded: form_helper
INFO - 2021-12-15 05:42:21 --> Helper loaded: my_helper
INFO - 2021-12-15 05:42:21 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:42:21 --> Controller Class Initialized
INFO - 2021-12-15 05:42:21 --> Config Class Initialized
INFO - 2021-12-15 05:42:21 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:42:21 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:42:21 --> Utf8 Class Initialized
INFO - 2021-12-15 05:42:21 --> URI Class Initialized
INFO - 2021-12-15 05:42:21 --> Router Class Initialized
INFO - 2021-12-15 05:42:21 --> Output Class Initialized
INFO - 2021-12-15 05:42:21 --> Security Class Initialized
DEBUG - 2021-12-15 05:42:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:42:21 --> Input Class Initialized
INFO - 2021-12-15 05:42:21 --> Language Class Initialized
INFO - 2021-12-15 05:42:21 --> Language Class Initialized
INFO - 2021-12-15 05:42:21 --> Config Class Initialized
INFO - 2021-12-15 05:42:21 --> Loader Class Initialized
INFO - 2021-12-15 05:42:21 --> Helper loaded: url_helper
INFO - 2021-12-15 05:42:21 --> Helper loaded: file_helper
INFO - 2021-12-15 05:42:21 --> Helper loaded: form_helper
INFO - 2021-12-15 05:42:21 --> Helper loaded: my_helper
INFO - 2021-12-15 05:42:21 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:42:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:42:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:42:21 --> Controller Class Initialized
DEBUG - 2021-12-15 05:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:42:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:42:21 --> Final output sent to browser
DEBUG - 2021-12-15 05:42:21 --> Total execution time: 0.0430
INFO - 2021-12-15 05:42:35 --> Config Class Initialized
INFO - 2021-12-15 05:42:35 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:42:35 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:42:35 --> Utf8 Class Initialized
INFO - 2021-12-15 05:42:35 --> URI Class Initialized
INFO - 2021-12-15 05:42:35 --> Router Class Initialized
INFO - 2021-12-15 05:42:35 --> Output Class Initialized
INFO - 2021-12-15 05:42:35 --> Security Class Initialized
DEBUG - 2021-12-15 05:42:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:42:35 --> Input Class Initialized
INFO - 2021-12-15 05:42:35 --> Language Class Initialized
INFO - 2021-12-15 05:42:35 --> Language Class Initialized
INFO - 2021-12-15 05:42:35 --> Config Class Initialized
INFO - 2021-12-15 05:42:35 --> Loader Class Initialized
INFO - 2021-12-15 05:42:35 --> Helper loaded: url_helper
INFO - 2021-12-15 05:42:35 --> Helper loaded: file_helper
INFO - 2021-12-15 05:42:35 --> Helper loaded: form_helper
INFO - 2021-12-15 05:42:35 --> Helper loaded: my_helper
INFO - 2021-12-15 05:42:35 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:42:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:42:35 --> Controller Class Initialized
DEBUG - 2021-12-15 05:42:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:42:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:42:35 --> Final output sent to browser
DEBUG - 2021-12-15 05:42:35 --> Total execution time: 0.0450
INFO - 2021-12-15 05:47:25 --> Config Class Initialized
INFO - 2021-12-15 05:47:25 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:47:25 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:47:25 --> Utf8 Class Initialized
INFO - 2021-12-15 05:47:25 --> URI Class Initialized
INFO - 2021-12-15 05:47:25 --> Router Class Initialized
INFO - 2021-12-15 05:47:25 --> Output Class Initialized
INFO - 2021-12-15 05:47:25 --> Security Class Initialized
DEBUG - 2021-12-15 05:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:47:25 --> Input Class Initialized
INFO - 2021-12-15 05:47:25 --> Language Class Initialized
INFO - 2021-12-15 05:47:25 --> Language Class Initialized
INFO - 2021-12-15 05:47:25 --> Config Class Initialized
INFO - 2021-12-15 05:47:25 --> Loader Class Initialized
INFO - 2021-12-15 05:47:25 --> Helper loaded: url_helper
INFO - 2021-12-15 05:47:25 --> Helper loaded: file_helper
INFO - 2021-12-15 05:47:25 --> Helper loaded: form_helper
INFO - 2021-12-15 05:47:25 --> Helper loaded: my_helper
INFO - 2021-12-15 05:47:25 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:47:25 --> Controller Class Initialized
INFO - 2021-12-15 05:47:25 --> Config Class Initialized
INFO - 2021-12-15 05:47:25 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:47:25 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:47:25 --> Utf8 Class Initialized
INFO - 2021-12-15 05:47:25 --> URI Class Initialized
INFO - 2021-12-15 05:47:25 --> Router Class Initialized
INFO - 2021-12-15 05:47:25 --> Output Class Initialized
INFO - 2021-12-15 05:47:25 --> Security Class Initialized
DEBUG - 2021-12-15 05:47:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:47:25 --> Input Class Initialized
INFO - 2021-12-15 05:47:25 --> Language Class Initialized
INFO - 2021-12-15 05:47:25 --> Language Class Initialized
INFO - 2021-12-15 05:47:25 --> Config Class Initialized
INFO - 2021-12-15 05:47:25 --> Loader Class Initialized
INFO - 2021-12-15 05:47:25 --> Helper loaded: url_helper
INFO - 2021-12-15 05:47:25 --> Helper loaded: file_helper
INFO - 2021-12-15 05:47:25 --> Helper loaded: form_helper
INFO - 2021-12-15 05:47:25 --> Helper loaded: my_helper
INFO - 2021-12-15 05:47:25 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:47:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:47:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:47:25 --> Controller Class Initialized
DEBUG - 2021-12-15 05:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:47:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:47:25 --> Final output sent to browser
DEBUG - 2021-12-15 05:47:25 --> Total execution time: 0.0440
INFO - 2021-12-15 05:48:50 --> Config Class Initialized
INFO - 2021-12-15 05:48:50 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:48:50 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:48:50 --> Utf8 Class Initialized
INFO - 2021-12-15 05:48:50 --> URI Class Initialized
INFO - 2021-12-15 05:48:50 --> Router Class Initialized
INFO - 2021-12-15 05:48:50 --> Output Class Initialized
INFO - 2021-12-15 05:48:50 --> Security Class Initialized
DEBUG - 2021-12-15 05:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:48:50 --> Input Class Initialized
INFO - 2021-12-15 05:48:50 --> Language Class Initialized
INFO - 2021-12-15 05:48:50 --> Language Class Initialized
INFO - 2021-12-15 05:48:50 --> Config Class Initialized
INFO - 2021-12-15 05:48:50 --> Loader Class Initialized
INFO - 2021-12-15 05:48:50 --> Helper loaded: url_helper
INFO - 2021-12-15 05:48:50 --> Helper loaded: file_helper
INFO - 2021-12-15 05:48:50 --> Helper loaded: form_helper
INFO - 2021-12-15 05:48:50 --> Helper loaded: my_helper
INFO - 2021-12-15 05:48:50 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:48:50 --> Controller Class Initialized
DEBUG - 2021-12-15 05:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:48:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:48:50 --> Final output sent to browser
DEBUG - 2021-12-15 05:48:50 --> Total execution time: 0.0470
INFO - 2021-12-15 05:50:42 --> Config Class Initialized
INFO - 2021-12-15 05:50:42 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:50:42 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:50:42 --> Utf8 Class Initialized
INFO - 2021-12-15 05:50:42 --> URI Class Initialized
INFO - 2021-12-15 05:50:42 --> Router Class Initialized
INFO - 2021-12-15 05:50:42 --> Output Class Initialized
INFO - 2021-12-15 05:50:42 --> Security Class Initialized
DEBUG - 2021-12-15 05:50:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:50:42 --> Input Class Initialized
INFO - 2021-12-15 05:50:42 --> Language Class Initialized
INFO - 2021-12-15 05:50:42 --> Language Class Initialized
INFO - 2021-12-15 05:50:42 --> Config Class Initialized
INFO - 2021-12-15 05:50:42 --> Loader Class Initialized
INFO - 2021-12-15 05:50:42 --> Helper loaded: url_helper
INFO - 2021-12-15 05:50:42 --> Helper loaded: file_helper
INFO - 2021-12-15 05:50:42 --> Helper loaded: form_helper
INFO - 2021-12-15 05:50:42 --> Helper loaded: my_helper
INFO - 2021-12-15 05:50:42 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:50:43 --> Controller Class Initialized
INFO - 2021-12-15 05:50:43 --> Config Class Initialized
INFO - 2021-12-15 05:50:43 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:50:43 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:50:43 --> Utf8 Class Initialized
INFO - 2021-12-15 05:50:43 --> URI Class Initialized
INFO - 2021-12-15 05:50:43 --> Router Class Initialized
INFO - 2021-12-15 05:50:43 --> Output Class Initialized
INFO - 2021-12-15 05:50:43 --> Security Class Initialized
DEBUG - 2021-12-15 05:50:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:50:43 --> Input Class Initialized
INFO - 2021-12-15 05:50:43 --> Language Class Initialized
INFO - 2021-12-15 05:50:43 --> Language Class Initialized
INFO - 2021-12-15 05:50:43 --> Config Class Initialized
INFO - 2021-12-15 05:50:43 --> Loader Class Initialized
INFO - 2021-12-15 05:50:43 --> Helper loaded: url_helper
INFO - 2021-12-15 05:50:43 --> Helper loaded: file_helper
INFO - 2021-12-15 05:50:43 --> Helper loaded: form_helper
INFO - 2021-12-15 05:50:43 --> Helper loaded: my_helper
INFO - 2021-12-15 05:50:43 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:50:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:50:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:50:43 --> Controller Class Initialized
DEBUG - 2021-12-15 05:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 05:50:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:50:43 --> Final output sent to browser
DEBUG - 2021-12-15 05:50:43 --> Total execution time: 0.0420
INFO - 2021-12-15 05:50:57 --> Config Class Initialized
INFO - 2021-12-15 05:50:57 --> Hooks Class Initialized
DEBUG - 2021-12-15 05:50:57 --> UTF-8 Support Enabled
INFO - 2021-12-15 05:50:57 --> Utf8 Class Initialized
INFO - 2021-12-15 05:50:57 --> URI Class Initialized
INFO - 2021-12-15 05:50:57 --> Router Class Initialized
INFO - 2021-12-15 05:50:57 --> Output Class Initialized
INFO - 2021-12-15 05:50:57 --> Security Class Initialized
DEBUG - 2021-12-15 05:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 05:50:57 --> Input Class Initialized
INFO - 2021-12-15 05:50:57 --> Language Class Initialized
INFO - 2021-12-15 05:50:57 --> Language Class Initialized
INFO - 2021-12-15 05:50:57 --> Config Class Initialized
INFO - 2021-12-15 05:50:57 --> Loader Class Initialized
INFO - 2021-12-15 05:50:57 --> Helper loaded: url_helper
INFO - 2021-12-15 05:50:57 --> Helper loaded: file_helper
INFO - 2021-12-15 05:50:57 --> Helper loaded: form_helper
INFO - 2021-12-15 05:50:57 --> Helper loaded: my_helper
INFO - 2021-12-15 05:50:57 --> Database Driver Class Initialized
DEBUG - 2021-12-15 05:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 05:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 05:50:57 --> Controller Class Initialized
DEBUG - 2021-12-15 05:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-12-15 05:50:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 05:50:57 --> Final output sent to browser
DEBUG - 2021-12-15 05:50:57 --> Total execution time: 0.0470
INFO - 2021-12-15 06:05:17 --> Config Class Initialized
INFO - 2021-12-15 06:05:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:05:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:05:17 --> Utf8 Class Initialized
INFO - 2021-12-15 06:05:17 --> URI Class Initialized
INFO - 2021-12-15 06:05:17 --> Router Class Initialized
INFO - 2021-12-15 06:05:17 --> Output Class Initialized
INFO - 2021-12-15 06:05:17 --> Security Class Initialized
DEBUG - 2021-12-15 06:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:05:17 --> Input Class Initialized
INFO - 2021-12-15 06:05:17 --> Language Class Initialized
INFO - 2021-12-15 06:05:17 --> Language Class Initialized
INFO - 2021-12-15 06:05:17 --> Config Class Initialized
INFO - 2021-12-15 06:05:17 --> Loader Class Initialized
INFO - 2021-12-15 06:05:17 --> Helper loaded: url_helper
INFO - 2021-12-15 06:05:17 --> Helper loaded: file_helper
INFO - 2021-12-15 06:05:17 --> Helper loaded: form_helper
INFO - 2021-12-15 06:05:17 --> Helper loaded: my_helper
INFO - 2021-12-15 06:05:17 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:05:17 --> Controller Class Initialized
INFO - 2021-12-15 06:05:17 --> Config Class Initialized
INFO - 2021-12-15 06:05:17 --> Hooks Class Initialized
DEBUG - 2021-12-15 06:05:17 --> UTF-8 Support Enabled
INFO - 2021-12-15 06:05:17 --> Utf8 Class Initialized
INFO - 2021-12-15 06:05:17 --> URI Class Initialized
INFO - 2021-12-15 06:05:17 --> Router Class Initialized
INFO - 2021-12-15 06:05:17 --> Output Class Initialized
INFO - 2021-12-15 06:05:17 --> Security Class Initialized
DEBUG - 2021-12-15 06:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-15 06:05:17 --> Input Class Initialized
INFO - 2021-12-15 06:05:17 --> Language Class Initialized
INFO - 2021-12-15 06:05:17 --> Language Class Initialized
INFO - 2021-12-15 06:05:17 --> Config Class Initialized
INFO - 2021-12-15 06:05:17 --> Loader Class Initialized
INFO - 2021-12-15 06:05:17 --> Helper loaded: url_helper
INFO - 2021-12-15 06:05:17 --> Helper loaded: file_helper
INFO - 2021-12-15 06:05:17 --> Helper loaded: form_helper
INFO - 2021-12-15 06:05:17 --> Helper loaded: my_helper
INFO - 2021-12-15 06:05:17 --> Database Driver Class Initialized
DEBUG - 2021-12-15 06:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-15 06:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-15 06:05:17 --> Controller Class Initialized
DEBUG - 2021-12-15 06:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-12-15 06:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-15 06:05:17 --> Final output sent to browser
DEBUG - 2021-12-15 06:05:17 --> Total execution time: 0.0430
