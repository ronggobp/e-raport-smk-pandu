<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-06 01:22:25 --> Config Class Initialized
INFO - 2021-01-06 01:22:25 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:22:26 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:22:26 --> Utf8 Class Initialized
INFO - 2021-01-06 01:22:26 --> URI Class Initialized
DEBUG - 2021-01-06 01:22:26 --> No URI present. Default controller set.
INFO - 2021-01-06 01:22:26 --> Router Class Initialized
INFO - 2021-01-06 01:22:26 --> Output Class Initialized
INFO - 2021-01-06 01:22:26 --> Security Class Initialized
DEBUG - 2021-01-06 01:22:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:22:26 --> Input Class Initialized
INFO - 2021-01-06 01:22:26 --> Language Class Initialized
INFO - 2021-01-06 01:22:26 --> Language Class Initialized
INFO - 2021-01-06 01:22:26 --> Config Class Initialized
INFO - 2021-01-06 01:22:26 --> Loader Class Initialized
INFO - 2021-01-06 01:22:26 --> Helper loaded: url_helper
INFO - 2021-01-06 01:22:26 --> Helper loaded: file_helper
INFO - 2021-01-06 01:22:26 --> Helper loaded: form_helper
INFO - 2021-01-06 01:22:26 --> Helper loaded: my_helper
INFO - 2021-01-06 01:22:27 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:22:27 --> Controller Class Initialized
INFO - 2021-01-06 01:22:27 --> Config Class Initialized
INFO - 2021-01-06 01:22:27 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:22:27 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:22:27 --> Utf8 Class Initialized
INFO - 2021-01-06 01:22:27 --> URI Class Initialized
INFO - 2021-01-06 01:22:27 --> Router Class Initialized
INFO - 2021-01-06 01:22:27 --> Output Class Initialized
INFO - 2021-01-06 01:22:27 --> Security Class Initialized
DEBUG - 2021-01-06 01:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:22:27 --> Input Class Initialized
INFO - 2021-01-06 01:22:27 --> Language Class Initialized
INFO - 2021-01-06 01:22:27 --> Language Class Initialized
INFO - 2021-01-06 01:22:27 --> Config Class Initialized
INFO - 2021-01-06 01:22:27 --> Loader Class Initialized
INFO - 2021-01-06 01:22:27 --> Helper loaded: url_helper
INFO - 2021-01-06 01:22:27 --> Helper loaded: file_helper
INFO - 2021-01-06 01:22:27 --> Helper loaded: form_helper
INFO - 2021-01-06 01:22:27 --> Helper loaded: my_helper
INFO - 2021-01-06 01:22:27 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:22:27 --> Controller Class Initialized
DEBUG - 2021-01-06 01:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-06 01:22:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:22:27 --> Final output sent to browser
DEBUG - 2021-01-06 01:22:27 --> Total execution time: 0.4494
INFO - 2021-01-06 01:25:55 --> Config Class Initialized
INFO - 2021-01-06 01:25:55 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:25:55 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:25:55 --> Utf8 Class Initialized
INFO - 2021-01-06 01:25:55 --> URI Class Initialized
INFO - 2021-01-06 01:25:55 --> Router Class Initialized
INFO - 2021-01-06 01:25:55 --> Output Class Initialized
INFO - 2021-01-06 01:25:55 --> Security Class Initialized
DEBUG - 2021-01-06 01:25:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:25:55 --> Input Class Initialized
INFO - 2021-01-06 01:25:55 --> Language Class Initialized
INFO - 2021-01-06 01:25:55 --> Language Class Initialized
INFO - 2021-01-06 01:25:55 --> Config Class Initialized
INFO - 2021-01-06 01:25:55 --> Loader Class Initialized
INFO - 2021-01-06 01:25:55 --> Helper loaded: url_helper
INFO - 2021-01-06 01:25:55 --> Helper loaded: file_helper
INFO - 2021-01-06 01:25:55 --> Helper loaded: form_helper
INFO - 2021-01-06 01:25:55 --> Helper loaded: my_helper
INFO - 2021-01-06 01:25:55 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:25:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:25:55 --> Controller Class Initialized
INFO - 2021-01-06 01:25:55 --> Helper loaded: cookie_helper
INFO - 2021-01-06 01:25:55 --> Final output sent to browser
DEBUG - 2021-01-06 01:25:55 --> Total execution time: 0.5034
INFO - 2021-01-06 01:25:56 --> Config Class Initialized
INFO - 2021-01-06 01:25:56 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:25:56 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:25:56 --> Utf8 Class Initialized
INFO - 2021-01-06 01:25:56 --> URI Class Initialized
INFO - 2021-01-06 01:25:56 --> Router Class Initialized
INFO - 2021-01-06 01:25:56 --> Output Class Initialized
INFO - 2021-01-06 01:25:56 --> Security Class Initialized
DEBUG - 2021-01-06 01:25:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:25:56 --> Input Class Initialized
INFO - 2021-01-06 01:25:56 --> Language Class Initialized
INFO - 2021-01-06 01:25:56 --> Language Class Initialized
INFO - 2021-01-06 01:25:56 --> Config Class Initialized
INFO - 2021-01-06 01:25:56 --> Loader Class Initialized
INFO - 2021-01-06 01:25:56 --> Helper loaded: url_helper
INFO - 2021-01-06 01:25:56 --> Helper loaded: file_helper
INFO - 2021-01-06 01:25:56 --> Helper loaded: form_helper
INFO - 2021-01-06 01:25:56 --> Helper loaded: my_helper
INFO - 2021-01-06 01:25:56 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:25:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:25:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:25:56 --> Controller Class Initialized
DEBUG - 2021-01-06 01:25:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-06 01:25:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:25:57 --> Final output sent to browser
DEBUG - 2021-01-06 01:25:57 --> Total execution time: 0.5592
INFO - 2021-01-06 01:51:58 --> Config Class Initialized
INFO - 2021-01-06 01:51:58 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:51:58 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:51:58 --> Utf8 Class Initialized
INFO - 2021-01-06 01:51:58 --> URI Class Initialized
INFO - 2021-01-06 01:51:58 --> Router Class Initialized
INFO - 2021-01-06 01:51:58 --> Output Class Initialized
INFO - 2021-01-06 01:51:58 --> Security Class Initialized
DEBUG - 2021-01-06 01:51:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:51:58 --> Input Class Initialized
INFO - 2021-01-06 01:51:58 --> Language Class Initialized
INFO - 2021-01-06 01:51:58 --> Language Class Initialized
INFO - 2021-01-06 01:51:58 --> Config Class Initialized
INFO - 2021-01-06 01:51:58 --> Loader Class Initialized
INFO - 2021-01-06 01:51:58 --> Helper loaded: url_helper
INFO - 2021-01-06 01:51:58 --> Helper loaded: file_helper
INFO - 2021-01-06 01:51:58 --> Helper loaded: form_helper
INFO - 2021-01-06 01:51:58 --> Helper loaded: my_helper
INFO - 2021-01-06 01:51:58 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:51:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:51:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:51:58 --> Controller Class Initialized
DEBUG - 2021-01-06 01:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-06 01:51:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:51:58 --> Final output sent to browser
DEBUG - 2021-01-06 01:51:58 --> Total execution time: 0.3905
INFO - 2021-01-06 01:52:00 --> Config Class Initialized
INFO - 2021-01-06 01:52:00 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:52:00 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:52:00 --> Utf8 Class Initialized
INFO - 2021-01-06 01:52:00 --> URI Class Initialized
INFO - 2021-01-06 01:52:00 --> Router Class Initialized
INFO - 2021-01-06 01:52:00 --> Output Class Initialized
INFO - 2021-01-06 01:52:00 --> Security Class Initialized
DEBUG - 2021-01-06 01:52:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:52:00 --> Input Class Initialized
INFO - 2021-01-06 01:52:00 --> Language Class Initialized
INFO - 2021-01-06 01:52:00 --> Language Class Initialized
INFO - 2021-01-06 01:52:00 --> Config Class Initialized
INFO - 2021-01-06 01:52:00 --> Loader Class Initialized
INFO - 2021-01-06 01:52:00 --> Helper loaded: url_helper
INFO - 2021-01-06 01:52:00 --> Helper loaded: file_helper
INFO - 2021-01-06 01:52:00 --> Helper loaded: form_helper
INFO - 2021-01-06 01:52:00 --> Helper loaded: my_helper
INFO - 2021-01-06 01:52:00 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:52:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:52:00 --> Controller Class Initialized
DEBUG - 2021-01-06 01:52:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 01:52:00 --> Final output sent to browser
DEBUG - 2021-01-06 01:52:00 --> Total execution time: 0.4888
INFO - 2021-01-06 01:52:11 --> Config Class Initialized
INFO - 2021-01-06 01:52:11 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:52:11 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:52:11 --> Utf8 Class Initialized
INFO - 2021-01-06 01:52:11 --> URI Class Initialized
INFO - 2021-01-06 01:52:11 --> Router Class Initialized
INFO - 2021-01-06 01:52:11 --> Output Class Initialized
INFO - 2021-01-06 01:52:11 --> Security Class Initialized
DEBUG - 2021-01-06 01:52:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:52:12 --> Input Class Initialized
INFO - 2021-01-06 01:52:12 --> Language Class Initialized
INFO - 2021-01-06 01:52:12 --> Language Class Initialized
INFO - 2021-01-06 01:52:12 --> Config Class Initialized
INFO - 2021-01-06 01:52:12 --> Loader Class Initialized
INFO - 2021-01-06 01:52:12 --> Helper loaded: url_helper
INFO - 2021-01-06 01:52:12 --> Helper loaded: file_helper
INFO - 2021-01-06 01:52:12 --> Helper loaded: form_helper
INFO - 2021-01-06 01:52:12 --> Helper loaded: my_helper
INFO - 2021-01-06 01:52:12 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:52:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:52:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:52:12 --> Controller Class Initialized
DEBUG - 2021-01-06 01:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-06 01:52:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:52:12 --> Final output sent to browser
DEBUG - 2021-01-06 01:52:12 --> Total execution time: 0.2815
INFO - 2021-01-06 01:52:13 --> Config Class Initialized
INFO - 2021-01-06 01:52:13 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:52:13 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:52:13 --> Utf8 Class Initialized
INFO - 2021-01-06 01:52:13 --> URI Class Initialized
INFO - 2021-01-06 01:52:13 --> Router Class Initialized
INFO - 2021-01-06 01:52:13 --> Output Class Initialized
INFO - 2021-01-06 01:52:13 --> Security Class Initialized
DEBUG - 2021-01-06 01:52:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:52:13 --> Input Class Initialized
INFO - 2021-01-06 01:52:13 --> Language Class Initialized
INFO - 2021-01-06 01:52:13 --> Language Class Initialized
INFO - 2021-01-06 01:52:13 --> Config Class Initialized
INFO - 2021-01-06 01:52:13 --> Loader Class Initialized
INFO - 2021-01-06 01:52:13 --> Helper loaded: url_helper
INFO - 2021-01-06 01:52:13 --> Helper loaded: file_helper
INFO - 2021-01-06 01:52:13 --> Helper loaded: form_helper
INFO - 2021-01-06 01:52:13 --> Helper loaded: my_helper
INFO - 2021-01-06 01:52:13 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:52:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:52:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:52:14 --> Controller Class Initialized
DEBUG - 2021-01-06 01:52:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-06 01:52:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:52:14 --> Final output sent to browser
DEBUG - 2021-01-06 01:52:14 --> Total execution time: 0.2798
INFO - 2021-01-06 01:52:17 --> Config Class Initialized
INFO - 2021-01-06 01:52:17 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:52:17 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:52:17 --> Utf8 Class Initialized
INFO - 2021-01-06 01:52:17 --> URI Class Initialized
INFO - 2021-01-06 01:52:17 --> Router Class Initialized
INFO - 2021-01-06 01:52:17 --> Output Class Initialized
INFO - 2021-01-06 01:52:17 --> Security Class Initialized
DEBUG - 2021-01-06 01:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:52:17 --> Input Class Initialized
INFO - 2021-01-06 01:52:17 --> Language Class Initialized
INFO - 2021-01-06 01:52:17 --> Language Class Initialized
INFO - 2021-01-06 01:52:17 --> Config Class Initialized
INFO - 2021-01-06 01:52:17 --> Loader Class Initialized
INFO - 2021-01-06 01:52:17 --> Helper loaded: url_helper
INFO - 2021-01-06 01:52:17 --> Helper loaded: file_helper
INFO - 2021-01-06 01:52:17 --> Helper loaded: form_helper
INFO - 2021-01-06 01:52:17 --> Helper loaded: my_helper
INFO - 2021-01-06 01:52:17 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:52:17 --> Controller Class Initialized
DEBUG - 2021-01-06 01:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-01-06 01:52:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:52:17 --> Final output sent to browser
DEBUG - 2021-01-06 01:52:18 --> Total execution time: 0.2785
INFO - 2021-01-06 01:52:20 --> Config Class Initialized
INFO - 2021-01-06 01:52:20 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:52:20 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:52:20 --> Utf8 Class Initialized
INFO - 2021-01-06 01:52:20 --> URI Class Initialized
INFO - 2021-01-06 01:52:20 --> Router Class Initialized
INFO - 2021-01-06 01:52:20 --> Output Class Initialized
INFO - 2021-01-06 01:52:20 --> Security Class Initialized
DEBUG - 2021-01-06 01:52:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:52:20 --> Input Class Initialized
INFO - 2021-01-06 01:52:20 --> Language Class Initialized
INFO - 2021-01-06 01:52:20 --> Language Class Initialized
INFO - 2021-01-06 01:52:20 --> Config Class Initialized
INFO - 2021-01-06 01:52:20 --> Loader Class Initialized
INFO - 2021-01-06 01:52:20 --> Helper loaded: url_helper
INFO - 2021-01-06 01:52:20 --> Helper loaded: file_helper
INFO - 2021-01-06 01:52:20 --> Helper loaded: form_helper
INFO - 2021-01-06 01:52:20 --> Helper loaded: my_helper
INFO - 2021-01-06 01:52:20 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:52:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:52:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:52:20 --> Controller Class Initialized
DEBUG - 2021-01-06 01:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-06 01:52:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:52:20 --> Final output sent to browser
DEBUG - 2021-01-06 01:52:20 --> Total execution time: 0.3019
INFO - 2021-01-06 01:56:07 --> Config Class Initialized
INFO - 2021-01-06 01:56:07 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:07 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:07 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:07 --> URI Class Initialized
INFO - 2021-01-06 01:56:07 --> Router Class Initialized
INFO - 2021-01-06 01:56:07 --> Output Class Initialized
INFO - 2021-01-06 01:56:07 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:07 --> Input Class Initialized
INFO - 2021-01-06 01:56:07 --> Language Class Initialized
INFO - 2021-01-06 01:56:07 --> Language Class Initialized
INFO - 2021-01-06 01:56:07 --> Config Class Initialized
INFO - 2021-01-06 01:56:07 --> Loader Class Initialized
INFO - 2021-01-06 01:56:07 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:07 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:07 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:07 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:07 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:07 --> Controller Class Initialized
DEBUG - 2021-01-06 01:56:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 01:56:07 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:07 --> Total execution time: 0.2884
INFO - 2021-01-06 01:56:24 --> Config Class Initialized
INFO - 2021-01-06 01:56:24 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:24 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:24 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:24 --> URI Class Initialized
INFO - 2021-01-06 01:56:24 --> Router Class Initialized
INFO - 2021-01-06 01:56:24 --> Output Class Initialized
INFO - 2021-01-06 01:56:24 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:24 --> Input Class Initialized
INFO - 2021-01-06 01:56:24 --> Language Class Initialized
INFO - 2021-01-06 01:56:24 --> Language Class Initialized
INFO - 2021-01-06 01:56:24 --> Config Class Initialized
INFO - 2021-01-06 01:56:24 --> Loader Class Initialized
INFO - 2021-01-06 01:56:24 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:24 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:24 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:24 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:24 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:24 --> Controller Class Initialized
DEBUG - 2021-01-06 01:56:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 01:56:24 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:24 --> Total execution time: 0.2896
INFO - 2021-01-06 01:56:33 --> Config Class Initialized
INFO - 2021-01-06 01:56:33 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:33 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:33 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:33 --> URI Class Initialized
INFO - 2021-01-06 01:56:33 --> Router Class Initialized
INFO - 2021-01-06 01:56:33 --> Output Class Initialized
INFO - 2021-01-06 01:56:33 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:33 --> Input Class Initialized
INFO - 2021-01-06 01:56:33 --> Language Class Initialized
INFO - 2021-01-06 01:56:33 --> Language Class Initialized
INFO - 2021-01-06 01:56:33 --> Config Class Initialized
INFO - 2021-01-06 01:56:33 --> Loader Class Initialized
INFO - 2021-01-06 01:56:33 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:33 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:33 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:33 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:33 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:33 --> Controller Class Initialized
INFO - 2021-01-06 01:56:33 --> Helper loaded: cookie_helper
INFO - 2021-01-06 01:56:33 --> Config Class Initialized
INFO - 2021-01-06 01:56:33 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:33 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:33 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:33 --> URI Class Initialized
INFO - 2021-01-06 01:56:33 --> Router Class Initialized
INFO - 2021-01-06 01:56:33 --> Output Class Initialized
INFO - 2021-01-06 01:56:33 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:33 --> Input Class Initialized
INFO - 2021-01-06 01:56:33 --> Language Class Initialized
INFO - 2021-01-06 01:56:33 --> Language Class Initialized
INFO - 2021-01-06 01:56:33 --> Config Class Initialized
INFO - 2021-01-06 01:56:33 --> Loader Class Initialized
INFO - 2021-01-06 01:56:33 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:34 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:34 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:34 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:34 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:34 --> Controller Class Initialized
DEBUG - 2021-01-06 01:56:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-06 01:56:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:56:34 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:34 --> Total execution time: 0.4418
INFO - 2021-01-06 01:56:41 --> Config Class Initialized
INFO - 2021-01-06 01:56:41 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:41 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:41 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:41 --> URI Class Initialized
INFO - 2021-01-06 01:56:41 --> Router Class Initialized
INFO - 2021-01-06 01:56:41 --> Output Class Initialized
INFO - 2021-01-06 01:56:41 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:41 --> Input Class Initialized
INFO - 2021-01-06 01:56:41 --> Language Class Initialized
INFO - 2021-01-06 01:56:41 --> Language Class Initialized
INFO - 2021-01-06 01:56:41 --> Config Class Initialized
INFO - 2021-01-06 01:56:41 --> Loader Class Initialized
INFO - 2021-01-06 01:56:41 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:41 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:41 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:41 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:41 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:41 --> Controller Class Initialized
INFO - 2021-01-06 01:56:41 --> Helper loaded: cookie_helper
INFO - 2021-01-06 01:56:41 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:41 --> Total execution time: 0.4602
INFO - 2021-01-06 01:56:42 --> Config Class Initialized
INFO - 2021-01-06 01:56:42 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:42 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:42 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:42 --> URI Class Initialized
INFO - 2021-01-06 01:56:42 --> Router Class Initialized
INFO - 2021-01-06 01:56:42 --> Output Class Initialized
INFO - 2021-01-06 01:56:42 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:42 --> Input Class Initialized
INFO - 2021-01-06 01:56:42 --> Language Class Initialized
INFO - 2021-01-06 01:56:42 --> Language Class Initialized
INFO - 2021-01-06 01:56:42 --> Config Class Initialized
INFO - 2021-01-06 01:56:42 --> Loader Class Initialized
INFO - 2021-01-06 01:56:42 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:42 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:42 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:42 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:42 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:42 --> Controller Class Initialized
DEBUG - 2021-01-06 01:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-06 01:56:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:56:42 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:42 --> Total execution time: 0.3943
INFO - 2021-01-06 01:56:44 --> Config Class Initialized
INFO - 2021-01-06 01:56:44 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:44 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:44 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:44 --> URI Class Initialized
INFO - 2021-01-06 01:56:44 --> Router Class Initialized
INFO - 2021-01-06 01:56:44 --> Output Class Initialized
INFO - 2021-01-06 01:56:44 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:44 --> Input Class Initialized
INFO - 2021-01-06 01:56:44 --> Language Class Initialized
INFO - 2021-01-06 01:56:44 --> Language Class Initialized
INFO - 2021-01-06 01:56:44 --> Config Class Initialized
INFO - 2021-01-06 01:56:44 --> Loader Class Initialized
INFO - 2021-01-06 01:56:44 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:44 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:44 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:44 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:44 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:44 --> Controller Class Initialized
DEBUG - 2021-01-06 01:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-06 01:56:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:56:44 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:44 --> Total execution time: 0.4348
INFO - 2021-01-06 01:56:45 --> Config Class Initialized
INFO - 2021-01-06 01:56:45 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:45 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:45 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:45 --> URI Class Initialized
INFO - 2021-01-06 01:56:45 --> Router Class Initialized
INFO - 2021-01-06 01:56:45 --> Output Class Initialized
INFO - 2021-01-06 01:56:45 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:45 --> Input Class Initialized
INFO - 2021-01-06 01:56:45 --> Language Class Initialized
INFO - 2021-01-06 01:56:45 --> Language Class Initialized
INFO - 2021-01-06 01:56:45 --> Config Class Initialized
INFO - 2021-01-06 01:56:45 --> Loader Class Initialized
INFO - 2021-01-06 01:56:45 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:45 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:45 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:45 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:45 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:45 --> Controller Class Initialized
DEBUG - 2021-01-06 01:56:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-06 01:56:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:56:45 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:45 --> Total execution time: 0.2998
INFO - 2021-01-06 01:56:45 --> Config Class Initialized
INFO - 2021-01-06 01:56:45 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:45 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:45 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:45 --> URI Class Initialized
INFO - 2021-01-06 01:56:45 --> Router Class Initialized
INFO - 2021-01-06 01:56:45 --> Output Class Initialized
INFO - 2021-01-06 01:56:45 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:45 --> Input Class Initialized
INFO - 2021-01-06 01:56:45 --> Language Class Initialized
INFO - 2021-01-06 01:56:46 --> Language Class Initialized
INFO - 2021-01-06 01:56:46 --> Config Class Initialized
INFO - 2021-01-06 01:56:46 --> Loader Class Initialized
INFO - 2021-01-06 01:56:46 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:46 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:46 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:46 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:46 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:46 --> Controller Class Initialized
INFO - 2021-01-06 01:56:47 --> Config Class Initialized
INFO - 2021-01-06 01:56:47 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:47 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:47 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:47 --> URI Class Initialized
INFO - 2021-01-06 01:56:47 --> Router Class Initialized
INFO - 2021-01-06 01:56:47 --> Output Class Initialized
INFO - 2021-01-06 01:56:47 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:47 --> Input Class Initialized
INFO - 2021-01-06 01:56:47 --> Language Class Initialized
INFO - 2021-01-06 01:56:47 --> Language Class Initialized
INFO - 2021-01-06 01:56:47 --> Config Class Initialized
INFO - 2021-01-06 01:56:47 --> Loader Class Initialized
INFO - 2021-01-06 01:56:47 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:47 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:47 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:47 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:47 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:47 --> Controller Class Initialized
INFO - 2021-01-06 01:56:47 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:47 --> Total execution time: 0.2212
INFO - 2021-01-06 01:56:48 --> Config Class Initialized
INFO - 2021-01-06 01:56:48 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:48 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:48 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:48 --> URI Class Initialized
INFO - 2021-01-06 01:56:48 --> Router Class Initialized
INFO - 2021-01-06 01:56:48 --> Output Class Initialized
INFO - 2021-01-06 01:56:48 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:48 --> Input Class Initialized
INFO - 2021-01-06 01:56:48 --> Language Class Initialized
INFO - 2021-01-06 01:56:48 --> Language Class Initialized
INFO - 2021-01-06 01:56:48 --> Config Class Initialized
INFO - 2021-01-06 01:56:48 --> Loader Class Initialized
INFO - 2021-01-06 01:56:48 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:48 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:48 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:48 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:48 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:48 --> Controller Class Initialized
INFO - 2021-01-06 01:56:48 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:48 --> Total execution time: 0.2359
INFO - 2021-01-06 01:56:51 --> Config Class Initialized
INFO - 2021-01-06 01:56:51 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:51 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:51 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:51 --> URI Class Initialized
INFO - 2021-01-06 01:56:51 --> Router Class Initialized
INFO - 2021-01-06 01:56:51 --> Output Class Initialized
INFO - 2021-01-06 01:56:51 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:51 --> Input Class Initialized
INFO - 2021-01-06 01:56:51 --> Language Class Initialized
INFO - 2021-01-06 01:56:51 --> Language Class Initialized
INFO - 2021-01-06 01:56:51 --> Config Class Initialized
INFO - 2021-01-06 01:56:51 --> Loader Class Initialized
INFO - 2021-01-06 01:56:51 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:51 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:51 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:51 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:51 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:51 --> Controller Class Initialized
INFO - 2021-01-06 01:56:51 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:51 --> Total execution time: 0.2990
INFO - 2021-01-06 01:56:52 --> Config Class Initialized
INFO - 2021-01-06 01:56:52 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:52 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:52 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:52 --> URI Class Initialized
INFO - 2021-01-06 01:56:52 --> Router Class Initialized
INFO - 2021-01-06 01:56:52 --> Output Class Initialized
INFO - 2021-01-06 01:56:52 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:52 --> Input Class Initialized
INFO - 2021-01-06 01:56:52 --> Language Class Initialized
INFO - 2021-01-06 01:56:52 --> Language Class Initialized
INFO - 2021-01-06 01:56:52 --> Config Class Initialized
INFO - 2021-01-06 01:56:52 --> Loader Class Initialized
INFO - 2021-01-06 01:56:52 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:52 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:52 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:52 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:52 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:53 --> Controller Class Initialized
INFO - 2021-01-06 01:56:53 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:53 --> Total execution time: 0.2867
INFO - 2021-01-06 01:56:54 --> Config Class Initialized
INFO - 2021-01-06 01:56:54 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:56:54 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:56:54 --> Utf8 Class Initialized
INFO - 2021-01-06 01:56:54 --> URI Class Initialized
INFO - 2021-01-06 01:56:54 --> Router Class Initialized
INFO - 2021-01-06 01:56:54 --> Output Class Initialized
INFO - 2021-01-06 01:56:54 --> Security Class Initialized
DEBUG - 2021-01-06 01:56:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:56:54 --> Input Class Initialized
INFO - 2021-01-06 01:56:54 --> Language Class Initialized
INFO - 2021-01-06 01:56:54 --> Language Class Initialized
INFO - 2021-01-06 01:56:54 --> Config Class Initialized
INFO - 2021-01-06 01:56:54 --> Loader Class Initialized
INFO - 2021-01-06 01:56:54 --> Helper loaded: url_helper
INFO - 2021-01-06 01:56:54 --> Helper loaded: file_helper
INFO - 2021-01-06 01:56:54 --> Helper loaded: form_helper
INFO - 2021-01-06 01:56:54 --> Helper loaded: my_helper
INFO - 2021-01-06 01:56:54 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:56:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:56:54 --> Controller Class Initialized
INFO - 2021-01-06 01:56:54 --> Final output sent to browser
DEBUG - 2021-01-06 01:56:54 --> Total execution time: 0.2743
INFO - 2021-01-06 01:57:15 --> Config Class Initialized
INFO - 2021-01-06 01:57:15 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:57:15 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:57:15 --> Utf8 Class Initialized
INFO - 2021-01-06 01:57:15 --> URI Class Initialized
INFO - 2021-01-06 01:57:15 --> Router Class Initialized
INFO - 2021-01-06 01:57:15 --> Output Class Initialized
INFO - 2021-01-06 01:57:15 --> Security Class Initialized
DEBUG - 2021-01-06 01:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:57:15 --> Input Class Initialized
INFO - 2021-01-06 01:57:15 --> Language Class Initialized
INFO - 2021-01-06 01:57:15 --> Language Class Initialized
INFO - 2021-01-06 01:57:15 --> Config Class Initialized
INFO - 2021-01-06 01:57:15 --> Loader Class Initialized
INFO - 2021-01-06 01:57:15 --> Helper loaded: url_helper
INFO - 2021-01-06 01:57:15 --> Helper loaded: file_helper
INFO - 2021-01-06 01:57:15 --> Helper loaded: form_helper
INFO - 2021-01-06 01:57:15 --> Helper loaded: my_helper
INFO - 2021-01-06 01:57:15 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:57:15 --> Controller Class Initialized
DEBUG - 2021-01-06 01:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 01:57:15 --> Final output sent to browser
DEBUG - 2021-01-06 01:57:16 --> Total execution time: 0.3692
INFO - 2021-01-06 01:59:16 --> Config Class Initialized
INFO - 2021-01-06 01:59:16 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:59:16 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:59:16 --> Utf8 Class Initialized
INFO - 2021-01-06 01:59:17 --> URI Class Initialized
INFO - 2021-01-06 01:59:17 --> Router Class Initialized
INFO - 2021-01-06 01:59:17 --> Output Class Initialized
INFO - 2021-01-06 01:59:17 --> Security Class Initialized
DEBUG - 2021-01-06 01:59:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:59:17 --> Input Class Initialized
INFO - 2021-01-06 01:59:17 --> Language Class Initialized
INFO - 2021-01-06 01:59:17 --> Language Class Initialized
INFO - 2021-01-06 01:59:17 --> Config Class Initialized
INFO - 2021-01-06 01:59:17 --> Loader Class Initialized
INFO - 2021-01-06 01:59:17 --> Helper loaded: url_helper
INFO - 2021-01-06 01:59:17 --> Helper loaded: file_helper
INFO - 2021-01-06 01:59:17 --> Helper loaded: form_helper
INFO - 2021-01-06 01:59:17 --> Helper loaded: my_helper
INFO - 2021-01-06 01:59:17 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:59:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:59:17 --> Controller Class Initialized
DEBUG - 2021-01-06 01:59:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-06 01:59:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:59:17 --> Final output sent to browser
DEBUG - 2021-01-06 01:59:17 --> Total execution time: 0.3239
INFO - 2021-01-06 01:59:18 --> Config Class Initialized
INFO - 2021-01-06 01:59:18 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:59:18 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:59:18 --> Utf8 Class Initialized
INFO - 2021-01-06 01:59:18 --> URI Class Initialized
INFO - 2021-01-06 01:59:18 --> Router Class Initialized
INFO - 2021-01-06 01:59:18 --> Output Class Initialized
INFO - 2021-01-06 01:59:18 --> Security Class Initialized
DEBUG - 2021-01-06 01:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:59:18 --> Input Class Initialized
INFO - 2021-01-06 01:59:18 --> Language Class Initialized
INFO - 2021-01-06 01:59:18 --> Language Class Initialized
INFO - 2021-01-06 01:59:18 --> Config Class Initialized
INFO - 2021-01-06 01:59:18 --> Loader Class Initialized
INFO - 2021-01-06 01:59:18 --> Helper loaded: url_helper
INFO - 2021-01-06 01:59:18 --> Helper loaded: file_helper
INFO - 2021-01-06 01:59:18 --> Helper loaded: form_helper
INFO - 2021-01-06 01:59:18 --> Helper loaded: my_helper
INFO - 2021-01-06 01:59:18 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:59:18 --> Controller Class Initialized
DEBUG - 2021-01-06 01:59:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-06 01:59:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 01:59:18 --> Final output sent to browser
DEBUG - 2021-01-06 01:59:18 --> Total execution time: 0.3957
INFO - 2021-01-06 01:59:19 --> Config Class Initialized
INFO - 2021-01-06 01:59:19 --> Hooks Class Initialized
DEBUG - 2021-01-06 01:59:19 --> UTF-8 Support Enabled
INFO - 2021-01-06 01:59:20 --> Utf8 Class Initialized
INFO - 2021-01-06 01:59:20 --> URI Class Initialized
INFO - 2021-01-06 01:59:20 --> Router Class Initialized
INFO - 2021-01-06 01:59:20 --> Output Class Initialized
INFO - 2021-01-06 01:59:20 --> Security Class Initialized
DEBUG - 2021-01-06 01:59:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 01:59:20 --> Input Class Initialized
INFO - 2021-01-06 01:59:20 --> Language Class Initialized
INFO - 2021-01-06 01:59:20 --> Language Class Initialized
INFO - 2021-01-06 01:59:20 --> Config Class Initialized
INFO - 2021-01-06 01:59:20 --> Loader Class Initialized
INFO - 2021-01-06 01:59:20 --> Helper loaded: url_helper
INFO - 2021-01-06 01:59:20 --> Helper loaded: file_helper
INFO - 2021-01-06 01:59:20 --> Helper loaded: form_helper
INFO - 2021-01-06 01:59:20 --> Helper loaded: my_helper
INFO - 2021-01-06 01:59:20 --> Database Driver Class Initialized
DEBUG - 2021-01-06 01:59:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 01:59:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 01:59:20 --> Controller Class Initialized
DEBUG - 2021-01-06 01:59:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-06 01:59:20 --> Final output sent to browser
DEBUG - 2021-01-06 01:59:20 --> Total execution time: 0.3363
INFO - 2021-01-06 02:13:54 --> Config Class Initialized
INFO - 2021-01-06 02:13:54 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:13:54 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:13:54 --> Utf8 Class Initialized
INFO - 2021-01-06 02:13:54 --> URI Class Initialized
INFO - 2021-01-06 02:13:54 --> Router Class Initialized
INFO - 2021-01-06 02:13:54 --> Output Class Initialized
INFO - 2021-01-06 02:13:54 --> Security Class Initialized
DEBUG - 2021-01-06 02:13:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:13:54 --> Input Class Initialized
INFO - 2021-01-06 02:13:54 --> Language Class Initialized
INFO - 2021-01-06 02:13:54 --> Language Class Initialized
INFO - 2021-01-06 02:13:54 --> Config Class Initialized
INFO - 2021-01-06 02:13:54 --> Loader Class Initialized
INFO - 2021-01-06 02:13:54 --> Helper loaded: url_helper
INFO - 2021-01-06 02:13:54 --> Helper loaded: file_helper
INFO - 2021-01-06 02:13:54 --> Helper loaded: form_helper
INFO - 2021-01-06 02:13:54 --> Helper loaded: my_helper
INFO - 2021-01-06 02:13:54 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:13:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:13:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:13:54 --> Controller Class Initialized
DEBUG - 2021-01-06 02:13:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 02:13:54 --> Final output sent to browser
DEBUG - 2021-01-06 02:13:54 --> Total execution time: 0.2799
INFO - 2021-01-06 02:15:45 --> Config Class Initialized
INFO - 2021-01-06 02:15:45 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:15:45 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:15:45 --> Utf8 Class Initialized
INFO - 2021-01-06 02:15:45 --> URI Class Initialized
INFO - 2021-01-06 02:15:45 --> Router Class Initialized
INFO - 2021-01-06 02:15:45 --> Output Class Initialized
INFO - 2021-01-06 02:15:45 --> Security Class Initialized
DEBUG - 2021-01-06 02:15:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:15:45 --> Input Class Initialized
INFO - 2021-01-06 02:15:45 --> Language Class Initialized
ERROR - 2021-01-06 02:15:45 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 170
INFO - 2021-01-06 02:16:18 --> Config Class Initialized
INFO - 2021-01-06 02:16:18 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:16:18 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:16:18 --> Utf8 Class Initialized
INFO - 2021-01-06 02:16:18 --> URI Class Initialized
INFO - 2021-01-06 02:16:18 --> Router Class Initialized
INFO - 2021-01-06 02:16:18 --> Output Class Initialized
INFO - 2021-01-06 02:16:18 --> Security Class Initialized
DEBUG - 2021-01-06 02:16:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:16:18 --> Input Class Initialized
INFO - 2021-01-06 02:16:18 --> Language Class Initialized
ERROR - 2021-01-06 02:16:18 --> Severity: Parsing Error --> syntax error, unexpected ';' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 170
INFO - 2021-01-06 02:16:27 --> Config Class Initialized
INFO - 2021-01-06 02:16:27 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:16:27 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:16:27 --> Utf8 Class Initialized
INFO - 2021-01-06 02:16:27 --> URI Class Initialized
INFO - 2021-01-06 02:16:27 --> Router Class Initialized
INFO - 2021-01-06 02:16:27 --> Output Class Initialized
INFO - 2021-01-06 02:16:27 --> Security Class Initialized
DEBUG - 2021-01-06 02:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:16:27 --> Input Class Initialized
INFO - 2021-01-06 02:16:27 --> Language Class Initialized
ERROR - 2021-01-06 02:16:27 --> Severity: Parsing Error --> syntax error, unexpected '$nilai_pengetahuan' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 173
INFO - 2021-01-06 02:17:12 --> Config Class Initialized
INFO - 2021-01-06 02:17:12 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:17:12 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:17:12 --> Utf8 Class Initialized
INFO - 2021-01-06 02:17:12 --> URI Class Initialized
INFO - 2021-01-06 02:17:12 --> Router Class Initialized
INFO - 2021-01-06 02:17:12 --> Output Class Initialized
INFO - 2021-01-06 02:17:12 --> Security Class Initialized
DEBUG - 2021-01-06 02:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:17:12 --> Input Class Initialized
INFO - 2021-01-06 02:17:12 --> Language Class Initialized
ERROR - 2021-01-06 02:17:12 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 170
INFO - 2021-01-06 02:17:27 --> Config Class Initialized
INFO - 2021-01-06 02:17:27 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:17:27 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:17:27 --> Utf8 Class Initialized
INFO - 2021-01-06 02:17:27 --> URI Class Initialized
INFO - 2021-01-06 02:17:27 --> Router Class Initialized
INFO - 2021-01-06 02:17:27 --> Output Class Initialized
INFO - 2021-01-06 02:17:27 --> Security Class Initialized
DEBUG - 2021-01-06 02:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:17:27 --> Input Class Initialized
INFO - 2021-01-06 02:17:27 --> Language Class Initialized
ERROR - 2021-01-06 02:17:27 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 170
INFO - 2021-01-06 02:17:47 --> Config Class Initialized
INFO - 2021-01-06 02:17:47 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:17:47 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:17:47 --> Utf8 Class Initialized
INFO - 2021-01-06 02:17:47 --> URI Class Initialized
INFO - 2021-01-06 02:17:47 --> Router Class Initialized
INFO - 2021-01-06 02:17:47 --> Output Class Initialized
INFO - 2021-01-06 02:17:47 --> Security Class Initialized
DEBUG - 2021-01-06 02:17:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:17:47 --> Input Class Initialized
INFO - 2021-01-06 02:17:47 --> Language Class Initialized
INFO - 2021-01-06 02:17:47 --> Language Class Initialized
INFO - 2021-01-06 02:17:47 --> Config Class Initialized
INFO - 2021-01-06 02:17:47 --> Loader Class Initialized
INFO - 2021-01-06 02:17:47 --> Helper loaded: url_helper
INFO - 2021-01-06 02:17:47 --> Helper loaded: file_helper
INFO - 2021-01-06 02:17:47 --> Helper loaded: form_helper
INFO - 2021-01-06 02:17:47 --> Helper loaded: my_helper
INFO - 2021-01-06 02:17:47 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:17:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:17:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:17:47 --> Controller Class Initialized
DEBUG - 2021-01-06 02:17:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 02:17:47 --> Final output sent to browser
DEBUG - 2021-01-06 02:17:47 --> Total execution time: 0.3658
INFO - 2021-01-06 02:20:05 --> Config Class Initialized
INFO - 2021-01-06 02:20:05 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:20:05 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:20:05 --> Utf8 Class Initialized
INFO - 2021-01-06 02:20:05 --> URI Class Initialized
INFO - 2021-01-06 02:20:05 --> Router Class Initialized
INFO - 2021-01-06 02:20:05 --> Output Class Initialized
INFO - 2021-01-06 02:20:05 --> Security Class Initialized
DEBUG - 2021-01-06 02:20:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:20:05 --> Input Class Initialized
INFO - 2021-01-06 02:20:05 --> Language Class Initialized
INFO - 2021-01-06 02:20:05 --> Language Class Initialized
INFO - 2021-01-06 02:20:05 --> Config Class Initialized
INFO - 2021-01-06 02:20:05 --> Loader Class Initialized
INFO - 2021-01-06 02:20:05 --> Helper loaded: url_helper
INFO - 2021-01-06 02:20:05 --> Helper loaded: file_helper
INFO - 2021-01-06 02:20:05 --> Helper loaded: form_helper
INFO - 2021-01-06 02:20:05 --> Helper loaded: my_helper
INFO - 2021-01-06 02:20:05 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:20:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:20:05 --> Controller Class Initialized
DEBUG - 2021-01-06 02:20:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 02:20:05 --> Final output sent to browser
DEBUG - 2021-01-06 02:20:05 --> Total execution time: 0.3022
INFO - 2021-01-06 02:21:22 --> Config Class Initialized
INFO - 2021-01-06 02:21:22 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:22 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:22 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:22 --> URI Class Initialized
INFO - 2021-01-06 02:21:23 --> Router Class Initialized
INFO - 2021-01-06 02:21:23 --> Output Class Initialized
INFO - 2021-01-06 02:21:23 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:23 --> Input Class Initialized
INFO - 2021-01-06 02:21:23 --> Language Class Initialized
INFO - 2021-01-06 02:21:23 --> Language Class Initialized
INFO - 2021-01-06 02:21:23 --> Config Class Initialized
INFO - 2021-01-06 02:21:23 --> Loader Class Initialized
INFO - 2021-01-06 02:21:23 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:23 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:23 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:23 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:23 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:23 --> Controller Class Initialized
DEBUG - 2021-01-06 02:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-06 02:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 02:21:23 --> Final output sent to browser
DEBUG - 2021-01-06 02:21:23 --> Total execution time: 0.3480
INFO - 2021-01-06 02:21:24 --> Config Class Initialized
INFO - 2021-01-06 02:21:24 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:24 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:24 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:24 --> URI Class Initialized
INFO - 2021-01-06 02:21:24 --> Router Class Initialized
INFO - 2021-01-06 02:21:24 --> Output Class Initialized
INFO - 2021-01-06 02:21:24 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:24 --> Input Class Initialized
INFO - 2021-01-06 02:21:24 --> Language Class Initialized
INFO - 2021-01-06 02:21:24 --> Language Class Initialized
INFO - 2021-01-06 02:21:24 --> Config Class Initialized
INFO - 2021-01-06 02:21:24 --> Loader Class Initialized
INFO - 2021-01-06 02:21:24 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:24 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:24 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:24 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:24 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:24 --> Controller Class Initialized
DEBUG - 2021-01-06 02:21:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-06 02:21:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 02:21:24 --> Final output sent to browser
DEBUG - 2021-01-06 02:21:24 --> Total execution time: 0.3042
INFO - 2021-01-06 02:21:24 --> Config Class Initialized
INFO - 2021-01-06 02:21:24 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:24 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:24 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:24 --> URI Class Initialized
INFO - 2021-01-06 02:21:24 --> Router Class Initialized
INFO - 2021-01-06 02:21:24 --> Output Class Initialized
INFO - 2021-01-06 02:21:24 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:24 --> Input Class Initialized
INFO - 2021-01-06 02:21:24 --> Language Class Initialized
INFO - 2021-01-06 02:21:24 --> Language Class Initialized
INFO - 2021-01-06 02:21:24 --> Config Class Initialized
INFO - 2021-01-06 02:21:24 --> Loader Class Initialized
INFO - 2021-01-06 02:21:24 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:24 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:24 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:24 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:24 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:24 --> Controller Class Initialized
INFO - 2021-01-06 02:21:27 --> Config Class Initialized
INFO - 2021-01-06 02:21:27 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:27 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:27 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:27 --> URI Class Initialized
INFO - 2021-01-06 02:21:27 --> Router Class Initialized
INFO - 2021-01-06 02:21:27 --> Output Class Initialized
INFO - 2021-01-06 02:21:27 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:27 --> Input Class Initialized
INFO - 2021-01-06 02:21:27 --> Language Class Initialized
INFO - 2021-01-06 02:21:27 --> Language Class Initialized
INFO - 2021-01-06 02:21:27 --> Config Class Initialized
INFO - 2021-01-06 02:21:27 --> Loader Class Initialized
INFO - 2021-01-06 02:21:27 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:27 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:27 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:27 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:27 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:27 --> Controller Class Initialized
INFO - 2021-01-06 02:21:27 --> Final output sent to browser
DEBUG - 2021-01-06 02:21:27 --> Total execution time: 0.2805
INFO - 2021-01-06 02:21:31 --> Config Class Initialized
INFO - 2021-01-06 02:21:31 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:31 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:31 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:31 --> URI Class Initialized
INFO - 2021-01-06 02:21:31 --> Router Class Initialized
INFO - 2021-01-06 02:21:31 --> Output Class Initialized
INFO - 2021-01-06 02:21:31 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:31 --> Input Class Initialized
INFO - 2021-01-06 02:21:31 --> Language Class Initialized
INFO - 2021-01-06 02:21:31 --> Language Class Initialized
INFO - 2021-01-06 02:21:31 --> Config Class Initialized
INFO - 2021-01-06 02:21:31 --> Loader Class Initialized
INFO - 2021-01-06 02:21:31 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:31 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:31 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:31 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:31 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:31 --> Controller Class Initialized
INFO - 2021-01-06 02:21:31 --> Final output sent to browser
DEBUG - 2021-01-06 02:21:31 --> Total execution time: 0.3937
INFO - 2021-01-06 02:21:31 --> Config Class Initialized
INFO - 2021-01-06 02:21:31 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:31 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:31 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:32 --> URI Class Initialized
INFO - 2021-01-06 02:21:32 --> Router Class Initialized
INFO - 2021-01-06 02:21:32 --> Output Class Initialized
INFO - 2021-01-06 02:21:32 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:32 --> Input Class Initialized
INFO - 2021-01-06 02:21:32 --> Language Class Initialized
INFO - 2021-01-06 02:21:32 --> Language Class Initialized
INFO - 2021-01-06 02:21:32 --> Config Class Initialized
INFO - 2021-01-06 02:21:32 --> Loader Class Initialized
INFO - 2021-01-06 02:21:32 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:32 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:32 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:32 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:32 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:32 --> Controller Class Initialized
INFO - 2021-01-06 02:21:35 --> Config Class Initialized
INFO - 2021-01-06 02:21:35 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:35 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:35 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:35 --> URI Class Initialized
INFO - 2021-01-06 02:21:35 --> Router Class Initialized
INFO - 2021-01-06 02:21:35 --> Output Class Initialized
INFO - 2021-01-06 02:21:35 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:35 --> Input Class Initialized
INFO - 2021-01-06 02:21:35 --> Language Class Initialized
INFO - 2021-01-06 02:21:35 --> Language Class Initialized
INFO - 2021-01-06 02:21:35 --> Config Class Initialized
INFO - 2021-01-06 02:21:35 --> Loader Class Initialized
INFO - 2021-01-06 02:21:35 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:35 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:35 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:35 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:35 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:35 --> Controller Class Initialized
DEBUG - 2021-01-06 02:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 02:21:35 --> Final output sent to browser
DEBUG - 2021-01-06 02:21:35 --> Total execution time: 0.2616
INFO - 2021-01-06 02:21:50 --> Config Class Initialized
INFO - 2021-01-06 02:21:50 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:21:50 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:21:50 --> Utf8 Class Initialized
INFO - 2021-01-06 02:21:50 --> URI Class Initialized
INFO - 2021-01-06 02:21:50 --> Router Class Initialized
INFO - 2021-01-06 02:21:50 --> Output Class Initialized
INFO - 2021-01-06 02:21:50 --> Security Class Initialized
DEBUG - 2021-01-06 02:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:21:50 --> Input Class Initialized
INFO - 2021-01-06 02:21:50 --> Language Class Initialized
INFO - 2021-01-06 02:21:50 --> Language Class Initialized
INFO - 2021-01-06 02:21:50 --> Config Class Initialized
INFO - 2021-01-06 02:21:50 --> Loader Class Initialized
INFO - 2021-01-06 02:21:50 --> Helper loaded: url_helper
INFO - 2021-01-06 02:21:50 --> Helper loaded: file_helper
INFO - 2021-01-06 02:21:50 --> Helper loaded: form_helper
INFO - 2021-01-06 02:21:50 --> Helper loaded: my_helper
INFO - 2021-01-06 02:21:50 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:21:50 --> Controller Class Initialized
DEBUG - 2021-01-06 02:21:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 02:21:50 --> Final output sent to browser
DEBUG - 2021-01-06 02:21:50 --> Total execution time: 0.2779
INFO - 2021-01-06 02:48:58 --> Config Class Initialized
INFO - 2021-01-06 02:48:58 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:48:58 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:48:58 --> Utf8 Class Initialized
INFO - 2021-01-06 02:48:58 --> URI Class Initialized
INFO - 2021-01-06 02:48:58 --> Router Class Initialized
INFO - 2021-01-06 02:48:58 --> Output Class Initialized
INFO - 2021-01-06 02:48:58 --> Security Class Initialized
DEBUG - 2021-01-06 02:48:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:48:58 --> Input Class Initialized
INFO - 2021-01-06 02:48:58 --> Language Class Initialized
INFO - 2021-01-06 02:48:58 --> Language Class Initialized
INFO - 2021-01-06 02:48:58 --> Config Class Initialized
INFO - 2021-01-06 02:48:58 --> Loader Class Initialized
INFO - 2021-01-06 02:48:58 --> Helper loaded: url_helper
INFO - 2021-01-06 02:48:58 --> Helper loaded: file_helper
INFO - 2021-01-06 02:48:58 --> Helper loaded: form_helper
INFO - 2021-01-06 02:48:58 --> Helper loaded: my_helper
INFO - 2021-01-06 02:48:58 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:48:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:48:58 --> Controller Class Initialized
DEBUG - 2021-01-06 02:48:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 02:48:58 --> Final output sent to browser
DEBUG - 2021-01-06 02:48:58 --> Total execution time: 0.3373
INFO - 2021-01-06 02:49:07 --> Config Class Initialized
INFO - 2021-01-06 02:49:07 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:49:07 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:49:07 --> Utf8 Class Initialized
INFO - 2021-01-06 02:49:07 --> URI Class Initialized
INFO - 2021-01-06 02:49:07 --> Router Class Initialized
INFO - 2021-01-06 02:49:07 --> Output Class Initialized
INFO - 2021-01-06 02:49:07 --> Security Class Initialized
DEBUG - 2021-01-06 02:49:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:49:07 --> Input Class Initialized
INFO - 2021-01-06 02:49:07 --> Language Class Initialized
INFO - 2021-01-06 02:49:07 --> Language Class Initialized
INFO - 2021-01-06 02:49:07 --> Config Class Initialized
INFO - 2021-01-06 02:49:07 --> Loader Class Initialized
INFO - 2021-01-06 02:49:07 --> Helper loaded: url_helper
INFO - 2021-01-06 02:49:07 --> Helper loaded: file_helper
INFO - 2021-01-06 02:49:07 --> Helper loaded: form_helper
INFO - 2021-01-06 02:49:07 --> Helper loaded: my_helper
INFO - 2021-01-06 02:49:07 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:49:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:49:07 --> Controller Class Initialized
DEBUG - 2021-01-06 02:49:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 02:49:07 --> Final output sent to browser
DEBUG - 2021-01-06 02:49:07 --> Total execution time: 0.2876
INFO - 2021-01-06 02:50:03 --> Config Class Initialized
INFO - 2021-01-06 02:50:03 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:03 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:03 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:03 --> URI Class Initialized
INFO - 2021-01-06 02:50:03 --> Router Class Initialized
INFO - 2021-01-06 02:50:03 --> Output Class Initialized
INFO - 2021-01-06 02:50:03 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:04 --> Input Class Initialized
INFO - 2021-01-06 02:50:04 --> Language Class Initialized
INFO - 2021-01-06 02:50:04 --> Language Class Initialized
INFO - 2021-01-06 02:50:04 --> Config Class Initialized
INFO - 2021-01-06 02:50:04 --> Loader Class Initialized
INFO - 2021-01-06 02:50:04 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:04 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:04 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:04 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:04 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:04 --> Controller Class Initialized
DEBUG - 2021-01-06 02:50:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 02:50:04 --> Final output sent to browser
DEBUG - 2021-01-06 02:50:04 --> Total execution time: 0.2685
INFO - 2021-01-06 02:50:36 --> Config Class Initialized
INFO - 2021-01-06 02:50:36 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:36 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:36 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:36 --> URI Class Initialized
INFO - 2021-01-06 02:50:36 --> Router Class Initialized
INFO - 2021-01-06 02:50:36 --> Output Class Initialized
INFO - 2021-01-06 02:50:36 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:36 --> Input Class Initialized
INFO - 2021-01-06 02:50:36 --> Language Class Initialized
INFO - 2021-01-06 02:50:36 --> Language Class Initialized
INFO - 2021-01-06 02:50:36 --> Config Class Initialized
INFO - 2021-01-06 02:50:36 --> Loader Class Initialized
INFO - 2021-01-06 02:50:36 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:36 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:36 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:36 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:36 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:36 --> Controller Class Initialized
DEBUG - 2021-01-06 02:50:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 02:50:36 --> Final output sent to browser
DEBUG - 2021-01-06 02:50:36 --> Total execution time: 0.2888
INFO - 2021-01-06 02:50:45 --> Config Class Initialized
INFO - 2021-01-06 02:50:45 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:45 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:45 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:45 --> URI Class Initialized
INFO - 2021-01-06 02:50:45 --> Router Class Initialized
INFO - 2021-01-06 02:50:45 --> Output Class Initialized
INFO - 2021-01-06 02:50:45 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:45 --> Input Class Initialized
INFO - 2021-01-06 02:50:45 --> Language Class Initialized
INFO - 2021-01-06 02:50:45 --> Language Class Initialized
INFO - 2021-01-06 02:50:45 --> Config Class Initialized
INFO - 2021-01-06 02:50:45 --> Loader Class Initialized
INFO - 2021-01-06 02:50:45 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:45 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:45 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:45 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:45 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:46 --> Controller Class Initialized
DEBUG - 2021-01-06 02:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-06 02:50:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 02:50:46 --> Final output sent to browser
DEBUG - 2021-01-06 02:50:46 --> Total execution time: 0.3541
INFO - 2021-01-06 02:50:46 --> Config Class Initialized
INFO - 2021-01-06 02:50:46 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:46 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:46 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:46 --> URI Class Initialized
INFO - 2021-01-06 02:50:46 --> Router Class Initialized
INFO - 2021-01-06 02:50:46 --> Output Class Initialized
INFO - 2021-01-06 02:50:46 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:46 --> Input Class Initialized
INFO - 2021-01-06 02:50:46 --> Language Class Initialized
INFO - 2021-01-06 02:50:46 --> Language Class Initialized
INFO - 2021-01-06 02:50:46 --> Config Class Initialized
INFO - 2021-01-06 02:50:46 --> Loader Class Initialized
INFO - 2021-01-06 02:50:46 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:46 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:46 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:46 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:46 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:46 --> Controller Class Initialized
INFO - 2021-01-06 02:50:48 --> Config Class Initialized
INFO - 2021-01-06 02:50:48 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:48 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:48 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:48 --> URI Class Initialized
INFO - 2021-01-06 02:50:48 --> Router Class Initialized
INFO - 2021-01-06 02:50:48 --> Output Class Initialized
INFO - 2021-01-06 02:50:48 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:48 --> Input Class Initialized
INFO - 2021-01-06 02:50:48 --> Language Class Initialized
INFO - 2021-01-06 02:50:48 --> Language Class Initialized
INFO - 2021-01-06 02:50:48 --> Config Class Initialized
INFO - 2021-01-06 02:50:48 --> Loader Class Initialized
INFO - 2021-01-06 02:50:48 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:48 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:48 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:48 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:48 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:48 --> Controller Class Initialized
INFO - 2021-01-06 02:50:48 --> Final output sent to browser
DEBUG - 2021-01-06 02:50:48 --> Total execution time: 0.2922
INFO - 2021-01-06 02:50:52 --> Config Class Initialized
INFO - 2021-01-06 02:50:53 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:53 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:53 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:53 --> URI Class Initialized
INFO - 2021-01-06 02:50:53 --> Router Class Initialized
INFO - 2021-01-06 02:50:53 --> Output Class Initialized
INFO - 2021-01-06 02:50:53 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:53 --> Input Class Initialized
INFO - 2021-01-06 02:50:53 --> Language Class Initialized
INFO - 2021-01-06 02:50:53 --> Language Class Initialized
INFO - 2021-01-06 02:50:53 --> Config Class Initialized
INFO - 2021-01-06 02:50:53 --> Loader Class Initialized
INFO - 2021-01-06 02:50:53 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:53 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:53 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:53 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:53 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:53 --> Controller Class Initialized
INFO - 2021-01-06 02:50:53 --> Final output sent to browser
DEBUG - 2021-01-06 02:50:53 --> Total execution time: 0.3217
INFO - 2021-01-06 02:50:53 --> Config Class Initialized
INFO - 2021-01-06 02:50:53 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:53 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:53 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:53 --> URI Class Initialized
INFO - 2021-01-06 02:50:53 --> Router Class Initialized
INFO - 2021-01-06 02:50:53 --> Output Class Initialized
INFO - 2021-01-06 02:50:53 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:53 --> Input Class Initialized
INFO - 2021-01-06 02:50:53 --> Language Class Initialized
INFO - 2021-01-06 02:50:53 --> Language Class Initialized
INFO - 2021-01-06 02:50:53 --> Config Class Initialized
INFO - 2021-01-06 02:50:53 --> Loader Class Initialized
INFO - 2021-01-06 02:50:53 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:53 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:53 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:53 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:53 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:53 --> Controller Class Initialized
INFO - 2021-01-06 02:50:57 --> Config Class Initialized
INFO - 2021-01-06 02:50:57 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:50:57 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:50:57 --> Utf8 Class Initialized
INFO - 2021-01-06 02:50:57 --> URI Class Initialized
INFO - 2021-01-06 02:50:57 --> Router Class Initialized
INFO - 2021-01-06 02:50:57 --> Output Class Initialized
INFO - 2021-01-06 02:50:57 --> Security Class Initialized
DEBUG - 2021-01-06 02:50:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:50:57 --> Input Class Initialized
INFO - 2021-01-06 02:50:57 --> Language Class Initialized
INFO - 2021-01-06 02:50:57 --> Language Class Initialized
INFO - 2021-01-06 02:50:57 --> Config Class Initialized
INFO - 2021-01-06 02:50:57 --> Loader Class Initialized
INFO - 2021-01-06 02:50:57 --> Helper loaded: url_helper
INFO - 2021-01-06 02:50:57 --> Helper loaded: file_helper
INFO - 2021-01-06 02:50:57 --> Helper loaded: form_helper
INFO - 2021-01-06 02:50:57 --> Helper loaded: my_helper
INFO - 2021-01-06 02:50:57 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:50:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:50:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:50:57 --> Controller Class Initialized
INFO - 2021-01-06 02:50:57 --> Final output sent to browser
DEBUG - 2021-01-06 02:50:57 --> Total execution time: 0.2783
INFO - 2021-01-06 02:51:05 --> Config Class Initialized
INFO - 2021-01-06 02:51:05 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:51:05 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:51:05 --> Utf8 Class Initialized
INFO - 2021-01-06 02:51:05 --> URI Class Initialized
INFO - 2021-01-06 02:51:05 --> Router Class Initialized
INFO - 2021-01-06 02:51:05 --> Output Class Initialized
INFO - 2021-01-06 02:51:05 --> Security Class Initialized
DEBUG - 2021-01-06 02:51:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:51:05 --> Input Class Initialized
INFO - 2021-01-06 02:51:05 --> Language Class Initialized
INFO - 2021-01-06 02:51:05 --> Language Class Initialized
INFO - 2021-01-06 02:51:05 --> Config Class Initialized
INFO - 2021-01-06 02:51:05 --> Loader Class Initialized
INFO - 2021-01-06 02:51:05 --> Helper loaded: url_helper
INFO - 2021-01-06 02:51:05 --> Helper loaded: file_helper
INFO - 2021-01-06 02:51:06 --> Helper loaded: form_helper
INFO - 2021-01-06 02:51:06 --> Helper loaded: my_helper
INFO - 2021-01-06 02:51:06 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:51:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:51:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:51:06 --> Controller Class Initialized
INFO - 2021-01-06 02:51:06 --> Final output sent to browser
DEBUG - 2021-01-06 02:51:06 --> Total execution time: 0.4355
INFO - 2021-01-06 02:51:08 --> Config Class Initialized
INFO - 2021-01-06 02:51:08 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:51:08 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:51:08 --> Utf8 Class Initialized
INFO - 2021-01-06 02:51:08 --> URI Class Initialized
INFO - 2021-01-06 02:51:08 --> Router Class Initialized
INFO - 2021-01-06 02:51:08 --> Output Class Initialized
INFO - 2021-01-06 02:51:08 --> Security Class Initialized
DEBUG - 2021-01-06 02:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:51:08 --> Input Class Initialized
INFO - 2021-01-06 02:51:08 --> Language Class Initialized
INFO - 2021-01-06 02:51:08 --> Language Class Initialized
INFO - 2021-01-06 02:51:08 --> Config Class Initialized
INFO - 2021-01-06 02:51:08 --> Loader Class Initialized
INFO - 2021-01-06 02:51:09 --> Helper loaded: url_helper
INFO - 2021-01-06 02:51:09 --> Helper loaded: file_helper
INFO - 2021-01-06 02:51:09 --> Helper loaded: form_helper
INFO - 2021-01-06 02:51:09 --> Helper loaded: my_helper
INFO - 2021-01-06 02:51:09 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:51:09 --> Controller Class Initialized
INFO - 2021-01-06 02:51:09 --> Final output sent to browser
DEBUG - 2021-01-06 02:51:09 --> Total execution time: 0.2491
INFO - 2021-01-06 02:51:13 --> Config Class Initialized
INFO - 2021-01-06 02:51:13 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:51:13 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:51:13 --> Utf8 Class Initialized
INFO - 2021-01-06 02:51:13 --> URI Class Initialized
INFO - 2021-01-06 02:51:13 --> Router Class Initialized
INFO - 2021-01-06 02:51:13 --> Output Class Initialized
INFO - 2021-01-06 02:51:13 --> Security Class Initialized
DEBUG - 2021-01-06 02:51:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:51:13 --> Input Class Initialized
INFO - 2021-01-06 02:51:13 --> Language Class Initialized
INFO - 2021-01-06 02:51:13 --> Language Class Initialized
INFO - 2021-01-06 02:51:13 --> Config Class Initialized
INFO - 2021-01-06 02:51:13 --> Loader Class Initialized
INFO - 2021-01-06 02:51:13 --> Helper loaded: url_helper
INFO - 2021-01-06 02:51:13 --> Helper loaded: file_helper
INFO - 2021-01-06 02:51:13 --> Helper loaded: form_helper
INFO - 2021-01-06 02:51:13 --> Helper loaded: my_helper
INFO - 2021-01-06 02:51:13 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:51:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:51:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:51:13 --> Controller Class Initialized
INFO - 2021-01-06 02:51:14 --> Final output sent to browser
DEBUG - 2021-01-06 02:51:14 --> Total execution time: 0.4239
INFO - 2021-01-06 02:51:16 --> Config Class Initialized
INFO - 2021-01-06 02:51:16 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:51:16 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:51:16 --> Utf8 Class Initialized
INFO - 2021-01-06 02:51:16 --> URI Class Initialized
INFO - 2021-01-06 02:51:16 --> Router Class Initialized
INFO - 2021-01-06 02:51:16 --> Output Class Initialized
INFO - 2021-01-06 02:51:16 --> Security Class Initialized
DEBUG - 2021-01-06 02:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:51:16 --> Input Class Initialized
INFO - 2021-01-06 02:51:16 --> Language Class Initialized
INFO - 2021-01-06 02:51:16 --> Language Class Initialized
INFO - 2021-01-06 02:51:16 --> Config Class Initialized
INFO - 2021-01-06 02:51:16 --> Loader Class Initialized
INFO - 2021-01-06 02:51:16 --> Helper loaded: url_helper
INFO - 2021-01-06 02:51:16 --> Helper loaded: file_helper
INFO - 2021-01-06 02:51:16 --> Helper loaded: form_helper
INFO - 2021-01-06 02:51:16 --> Helper loaded: my_helper
INFO - 2021-01-06 02:51:16 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:51:16 --> Controller Class Initialized
INFO - 2021-01-06 02:51:16 --> Final output sent to browser
DEBUG - 2021-01-06 02:51:16 --> Total execution time: 0.2771
INFO - 2021-01-06 02:51:19 --> Config Class Initialized
INFO - 2021-01-06 02:51:19 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:51:19 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:51:19 --> Utf8 Class Initialized
INFO - 2021-01-06 02:51:19 --> URI Class Initialized
INFO - 2021-01-06 02:51:19 --> Router Class Initialized
INFO - 2021-01-06 02:51:20 --> Output Class Initialized
INFO - 2021-01-06 02:51:20 --> Security Class Initialized
DEBUG - 2021-01-06 02:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:51:20 --> Input Class Initialized
INFO - 2021-01-06 02:51:20 --> Language Class Initialized
INFO - 2021-01-06 02:51:20 --> Language Class Initialized
INFO - 2021-01-06 02:51:20 --> Config Class Initialized
INFO - 2021-01-06 02:51:20 --> Loader Class Initialized
INFO - 2021-01-06 02:51:20 --> Helper loaded: url_helper
INFO - 2021-01-06 02:51:20 --> Helper loaded: file_helper
INFO - 2021-01-06 02:51:20 --> Helper loaded: form_helper
INFO - 2021-01-06 02:51:20 --> Helper loaded: my_helper
INFO - 2021-01-06 02:51:20 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:51:20 --> Controller Class Initialized
INFO - 2021-01-06 02:51:20 --> Final output sent to browser
DEBUG - 2021-01-06 02:51:20 --> Total execution time: 0.4136
INFO - 2021-01-06 02:51:23 --> Config Class Initialized
INFO - 2021-01-06 02:51:23 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:51:23 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:51:23 --> Utf8 Class Initialized
INFO - 2021-01-06 02:51:23 --> URI Class Initialized
INFO - 2021-01-06 02:51:23 --> Router Class Initialized
INFO - 2021-01-06 02:51:23 --> Output Class Initialized
INFO - 2021-01-06 02:51:23 --> Security Class Initialized
DEBUG - 2021-01-06 02:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:51:23 --> Input Class Initialized
INFO - 2021-01-06 02:51:23 --> Language Class Initialized
INFO - 2021-01-06 02:51:23 --> Language Class Initialized
INFO - 2021-01-06 02:51:24 --> Config Class Initialized
INFO - 2021-01-06 02:51:24 --> Loader Class Initialized
INFO - 2021-01-06 02:51:24 --> Helper loaded: url_helper
INFO - 2021-01-06 02:51:24 --> Helper loaded: file_helper
INFO - 2021-01-06 02:51:24 --> Helper loaded: form_helper
INFO - 2021-01-06 02:51:24 --> Helper loaded: my_helper
INFO - 2021-01-06 02:51:24 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:51:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:51:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:51:24 --> Controller Class Initialized
DEBUG - 2021-01-06 02:51:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 02:51:24 --> Final output sent to browser
DEBUG - 2021-01-06 02:51:24 --> Total execution time: 0.3197
INFO - 2021-01-06 02:51:27 --> Config Class Initialized
INFO - 2021-01-06 02:51:27 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:51:27 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:51:27 --> Utf8 Class Initialized
INFO - 2021-01-06 02:51:27 --> URI Class Initialized
INFO - 2021-01-06 02:51:27 --> Router Class Initialized
INFO - 2021-01-06 02:51:27 --> Output Class Initialized
INFO - 2021-01-06 02:51:27 --> Security Class Initialized
DEBUG - 2021-01-06 02:51:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:51:27 --> Input Class Initialized
INFO - 2021-01-06 02:51:27 --> Language Class Initialized
INFO - 2021-01-06 02:51:27 --> Language Class Initialized
INFO - 2021-01-06 02:51:27 --> Config Class Initialized
INFO - 2021-01-06 02:51:27 --> Loader Class Initialized
INFO - 2021-01-06 02:51:27 --> Helper loaded: url_helper
INFO - 2021-01-06 02:51:27 --> Helper loaded: file_helper
INFO - 2021-01-06 02:51:27 --> Helper loaded: form_helper
INFO - 2021-01-06 02:51:27 --> Helper loaded: my_helper
INFO - 2021-01-06 02:51:27 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:51:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:51:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:51:27 --> Controller Class Initialized
DEBUG - 2021-01-06 02:51:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 02:51:27 --> Final output sent to browser
DEBUG - 2021-01-06 02:51:27 --> Total execution time: 0.3137
INFO - 2021-01-06 02:52:55 --> Config Class Initialized
INFO - 2021-01-06 02:52:55 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:52:55 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:52:55 --> Utf8 Class Initialized
INFO - 2021-01-06 02:52:55 --> URI Class Initialized
INFO - 2021-01-06 02:52:55 --> Router Class Initialized
INFO - 2021-01-06 02:52:55 --> Output Class Initialized
INFO - 2021-01-06 02:52:55 --> Security Class Initialized
DEBUG - 2021-01-06 02:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:52:55 --> Input Class Initialized
INFO - 2021-01-06 02:52:55 --> Language Class Initialized
ERROR - 2021-01-06 02:52:55 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 170
INFO - 2021-01-06 02:53:09 --> Config Class Initialized
INFO - 2021-01-06 02:53:09 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:53:09 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:53:09 --> Utf8 Class Initialized
INFO - 2021-01-06 02:53:09 --> URI Class Initialized
INFO - 2021-01-06 02:53:09 --> Router Class Initialized
INFO - 2021-01-06 02:53:09 --> Output Class Initialized
INFO - 2021-01-06 02:53:09 --> Security Class Initialized
DEBUG - 2021-01-06 02:53:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:53:09 --> Input Class Initialized
INFO - 2021-01-06 02:53:09 --> Language Class Initialized
ERROR - 2021-01-06 02:53:09 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 170
INFO - 2021-01-06 02:53:15 --> Config Class Initialized
INFO - 2021-01-06 02:53:15 --> Hooks Class Initialized
DEBUG - 2021-01-06 02:53:15 --> UTF-8 Support Enabled
INFO - 2021-01-06 02:53:15 --> Utf8 Class Initialized
INFO - 2021-01-06 02:53:15 --> URI Class Initialized
INFO - 2021-01-06 02:53:15 --> Router Class Initialized
INFO - 2021-01-06 02:53:15 --> Output Class Initialized
INFO - 2021-01-06 02:53:15 --> Security Class Initialized
DEBUG - 2021-01-06 02:53:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 02:53:15 --> Input Class Initialized
INFO - 2021-01-06 02:53:15 --> Language Class Initialized
INFO - 2021-01-06 02:53:15 --> Language Class Initialized
INFO - 2021-01-06 02:53:15 --> Config Class Initialized
INFO - 2021-01-06 02:53:15 --> Loader Class Initialized
INFO - 2021-01-06 02:53:15 --> Helper loaded: url_helper
INFO - 2021-01-06 02:53:15 --> Helper loaded: file_helper
INFO - 2021-01-06 02:53:15 --> Helper loaded: form_helper
INFO - 2021-01-06 02:53:15 --> Helper loaded: my_helper
INFO - 2021-01-06 02:53:15 --> Database Driver Class Initialized
DEBUG - 2021-01-06 02:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 02:53:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 02:53:15 --> Controller Class Initialized
DEBUG - 2021-01-06 02:53:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 02:53:15 --> Final output sent to browser
DEBUG - 2021-01-06 02:53:15 --> Total execution time: 0.3043
INFO - 2021-01-06 03:10:44 --> Config Class Initialized
INFO - 2021-01-06 03:10:44 --> Hooks Class Initialized
DEBUG - 2021-01-06 03:10:44 --> UTF-8 Support Enabled
INFO - 2021-01-06 03:10:44 --> Utf8 Class Initialized
INFO - 2021-01-06 03:10:44 --> URI Class Initialized
INFO - 2021-01-06 03:10:44 --> Router Class Initialized
INFO - 2021-01-06 03:10:44 --> Output Class Initialized
INFO - 2021-01-06 03:10:44 --> Security Class Initialized
DEBUG - 2021-01-06 03:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 03:10:44 --> Input Class Initialized
INFO - 2021-01-06 03:10:44 --> Language Class Initialized
ERROR - 2021-01-06 03:10:44 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 168
INFO - 2021-01-06 03:39:32 --> Config Class Initialized
INFO - 2021-01-06 03:39:32 --> Hooks Class Initialized
DEBUG - 2021-01-06 03:39:32 --> UTF-8 Support Enabled
INFO - 2021-01-06 03:39:32 --> Utf8 Class Initialized
INFO - 2021-01-06 03:39:32 --> URI Class Initialized
INFO - 2021-01-06 03:39:32 --> Router Class Initialized
INFO - 2021-01-06 03:39:32 --> Output Class Initialized
INFO - 2021-01-06 03:39:32 --> Security Class Initialized
DEBUG - 2021-01-06 03:39:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 03:39:32 --> Input Class Initialized
INFO - 2021-01-06 03:39:32 --> Language Class Initialized
ERROR - 2021-01-06 03:39:32 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 168
INFO - 2021-01-06 03:39:55 --> Config Class Initialized
INFO - 2021-01-06 03:39:55 --> Hooks Class Initialized
DEBUG - 2021-01-06 03:39:55 --> UTF-8 Support Enabled
INFO - 2021-01-06 03:39:55 --> Utf8 Class Initialized
INFO - 2021-01-06 03:39:55 --> URI Class Initialized
INFO - 2021-01-06 03:39:55 --> Router Class Initialized
INFO - 2021-01-06 03:39:55 --> Output Class Initialized
INFO - 2021-01-06 03:39:55 --> Security Class Initialized
DEBUG - 2021-01-06 03:39:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 03:39:55 --> Input Class Initialized
INFO - 2021-01-06 03:39:55 --> Language Class Initialized
INFO - 2021-01-06 03:39:55 --> Language Class Initialized
INFO - 2021-01-06 03:39:55 --> Config Class Initialized
INFO - 2021-01-06 03:39:55 --> Loader Class Initialized
INFO - 2021-01-06 03:39:56 --> Helper loaded: url_helper
INFO - 2021-01-06 03:39:56 --> Helper loaded: file_helper
INFO - 2021-01-06 03:39:56 --> Helper loaded: form_helper
INFO - 2021-01-06 03:39:56 --> Helper loaded: my_helper
INFO - 2021-01-06 03:39:56 --> Database Driver Class Initialized
DEBUG - 2021-01-06 03:39:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 03:39:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 03:39:56 --> Controller Class Initialized
DEBUG - 2021-01-06 03:39:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 03:39:56 --> Final output sent to browser
DEBUG - 2021-01-06 03:39:56 --> Total execution time: 0.3047
INFO - 2021-01-06 03:47:16 --> Config Class Initialized
INFO - 2021-01-06 03:47:16 --> Hooks Class Initialized
DEBUG - 2021-01-06 03:47:16 --> UTF-8 Support Enabled
INFO - 2021-01-06 03:47:16 --> Utf8 Class Initialized
INFO - 2021-01-06 03:47:16 --> URI Class Initialized
INFO - 2021-01-06 03:47:16 --> Router Class Initialized
INFO - 2021-01-06 03:47:16 --> Output Class Initialized
INFO - 2021-01-06 03:47:16 --> Security Class Initialized
DEBUG - 2021-01-06 03:47:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 03:47:16 --> Input Class Initialized
INFO - 2021-01-06 03:47:17 --> Language Class Initialized
INFO - 2021-01-06 03:47:17 --> Language Class Initialized
INFO - 2021-01-06 03:47:17 --> Config Class Initialized
INFO - 2021-01-06 03:47:17 --> Loader Class Initialized
INFO - 2021-01-06 03:47:17 --> Helper loaded: url_helper
INFO - 2021-01-06 03:47:17 --> Helper loaded: file_helper
INFO - 2021-01-06 03:47:17 --> Helper loaded: form_helper
INFO - 2021-01-06 03:47:17 --> Helper loaded: my_helper
INFO - 2021-01-06 03:47:17 --> Database Driver Class Initialized
DEBUG - 2021-01-06 03:47:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 03:47:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 03:47:17 --> Controller Class Initialized
INFO - 2021-01-06 04:59:09 --> Config Class Initialized
INFO - 2021-01-06 04:59:09 --> Hooks Class Initialized
DEBUG - 2021-01-06 04:59:09 --> UTF-8 Support Enabled
INFO - 2021-01-06 04:59:09 --> Utf8 Class Initialized
INFO - 2021-01-06 04:59:09 --> URI Class Initialized
INFO - 2021-01-06 04:59:09 --> Router Class Initialized
INFO - 2021-01-06 04:59:09 --> Output Class Initialized
INFO - 2021-01-06 04:59:09 --> Security Class Initialized
DEBUG - 2021-01-06 04:59:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 04:59:09 --> Input Class Initialized
INFO - 2021-01-06 04:59:09 --> Language Class Initialized
INFO - 2021-01-06 04:59:09 --> Language Class Initialized
INFO - 2021-01-06 04:59:09 --> Config Class Initialized
INFO - 2021-01-06 04:59:09 --> Loader Class Initialized
INFO - 2021-01-06 04:59:09 --> Helper loaded: url_helper
INFO - 2021-01-06 04:59:09 --> Helper loaded: file_helper
INFO - 2021-01-06 04:59:09 --> Helper loaded: form_helper
INFO - 2021-01-06 04:59:09 --> Helper loaded: my_helper
INFO - 2021-01-06 04:59:09 --> Database Driver Class Initialized
DEBUG - 2021-01-06 04:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 04:59:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 04:59:09 --> Controller Class Initialized
DEBUG - 2021-01-06 04:59:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 04:59:09 --> Final output sent to browser
DEBUG - 2021-01-06 04:59:09 --> Total execution time: 0.2729
INFO - 2021-01-06 04:59:11 --> Config Class Initialized
INFO - 2021-01-06 04:59:11 --> Hooks Class Initialized
DEBUG - 2021-01-06 04:59:11 --> UTF-8 Support Enabled
INFO - 2021-01-06 04:59:11 --> Utf8 Class Initialized
INFO - 2021-01-06 04:59:11 --> URI Class Initialized
INFO - 2021-01-06 04:59:11 --> Router Class Initialized
INFO - 2021-01-06 04:59:11 --> Output Class Initialized
INFO - 2021-01-06 04:59:11 --> Security Class Initialized
DEBUG - 2021-01-06 04:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 04:59:11 --> Input Class Initialized
INFO - 2021-01-06 04:59:11 --> Language Class Initialized
INFO - 2021-01-06 04:59:11 --> Language Class Initialized
INFO - 2021-01-06 04:59:11 --> Config Class Initialized
INFO - 2021-01-06 04:59:11 --> Loader Class Initialized
INFO - 2021-01-06 04:59:11 --> Helper loaded: url_helper
INFO - 2021-01-06 04:59:11 --> Helper loaded: file_helper
INFO - 2021-01-06 04:59:11 --> Helper loaded: form_helper
INFO - 2021-01-06 04:59:11 --> Helper loaded: my_helper
INFO - 2021-01-06 04:59:11 --> Database Driver Class Initialized
DEBUG - 2021-01-06 04:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 04:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 04:59:12 --> Controller Class Initialized
DEBUG - 2021-01-06 04:59:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-06 04:59:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 04:59:12 --> Final output sent to browser
DEBUG - 2021-01-06 04:59:12 --> Total execution time: 0.2670
INFO - 2021-01-06 04:59:12 --> Config Class Initialized
INFO - 2021-01-06 04:59:12 --> Hooks Class Initialized
DEBUG - 2021-01-06 04:59:12 --> UTF-8 Support Enabled
INFO - 2021-01-06 04:59:12 --> Utf8 Class Initialized
INFO - 2021-01-06 04:59:12 --> URI Class Initialized
INFO - 2021-01-06 04:59:12 --> Router Class Initialized
INFO - 2021-01-06 04:59:12 --> Output Class Initialized
INFO - 2021-01-06 04:59:12 --> Security Class Initialized
DEBUG - 2021-01-06 04:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 04:59:12 --> Input Class Initialized
INFO - 2021-01-06 04:59:12 --> Language Class Initialized
INFO - 2021-01-06 04:59:12 --> Language Class Initialized
INFO - 2021-01-06 04:59:12 --> Config Class Initialized
INFO - 2021-01-06 04:59:12 --> Loader Class Initialized
INFO - 2021-01-06 04:59:12 --> Helper loaded: url_helper
INFO - 2021-01-06 04:59:12 --> Helper loaded: file_helper
INFO - 2021-01-06 04:59:12 --> Helper loaded: form_helper
INFO - 2021-01-06 04:59:12 --> Helper loaded: my_helper
INFO - 2021-01-06 04:59:12 --> Database Driver Class Initialized
DEBUG - 2021-01-06 04:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 04:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 04:59:12 --> Controller Class Initialized
INFO - 2021-01-06 04:59:15 --> Config Class Initialized
INFO - 2021-01-06 04:59:15 --> Hooks Class Initialized
DEBUG - 2021-01-06 04:59:15 --> UTF-8 Support Enabled
INFO - 2021-01-06 04:59:15 --> Utf8 Class Initialized
INFO - 2021-01-06 04:59:15 --> URI Class Initialized
INFO - 2021-01-06 04:59:15 --> Router Class Initialized
INFO - 2021-01-06 04:59:15 --> Output Class Initialized
INFO - 2021-01-06 04:59:15 --> Security Class Initialized
DEBUG - 2021-01-06 04:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 04:59:15 --> Input Class Initialized
INFO - 2021-01-06 04:59:15 --> Language Class Initialized
INFO - 2021-01-06 04:59:15 --> Language Class Initialized
INFO - 2021-01-06 04:59:15 --> Config Class Initialized
INFO - 2021-01-06 04:59:15 --> Loader Class Initialized
INFO - 2021-01-06 04:59:15 --> Helper loaded: url_helper
INFO - 2021-01-06 04:59:15 --> Helper loaded: file_helper
INFO - 2021-01-06 04:59:15 --> Helper loaded: form_helper
INFO - 2021-01-06 04:59:15 --> Helper loaded: my_helper
INFO - 2021-01-06 04:59:15 --> Database Driver Class Initialized
DEBUG - 2021-01-06 04:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 04:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 04:59:15 --> Controller Class Initialized
DEBUG - 2021-01-06 04:59:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 04:59:15 --> Final output sent to browser
DEBUG - 2021-01-06 04:59:15 --> Total execution time: 0.2718
INFO - 2021-01-06 05:05:33 --> Config Class Initialized
INFO - 2021-01-06 05:05:33 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:05:33 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:05:33 --> Utf8 Class Initialized
INFO - 2021-01-06 05:05:33 --> URI Class Initialized
INFO - 2021-01-06 05:05:33 --> Router Class Initialized
INFO - 2021-01-06 05:05:33 --> Output Class Initialized
INFO - 2021-01-06 05:05:33 --> Security Class Initialized
DEBUG - 2021-01-06 05:05:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:05:33 --> Input Class Initialized
INFO - 2021-01-06 05:05:33 --> Language Class Initialized
INFO - 2021-01-06 05:05:33 --> Language Class Initialized
INFO - 2021-01-06 05:05:33 --> Config Class Initialized
INFO - 2021-01-06 05:05:33 --> Loader Class Initialized
INFO - 2021-01-06 05:05:33 --> Helper loaded: url_helper
INFO - 2021-01-06 05:05:33 --> Helper loaded: file_helper
INFO - 2021-01-06 05:05:33 --> Helper loaded: form_helper
INFO - 2021-01-06 05:05:33 --> Helper loaded: my_helper
INFO - 2021-01-06 05:05:33 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:05:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:05:33 --> Controller Class Initialized
DEBUG - 2021-01-06 05:05:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:05:33 --> Final output sent to browser
DEBUG - 2021-01-06 05:05:33 --> Total execution time: 0.2937
INFO - 2021-01-06 05:10:56 --> Config Class Initialized
INFO - 2021-01-06 05:10:56 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:10:56 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:10:56 --> Utf8 Class Initialized
INFO - 2021-01-06 05:10:56 --> URI Class Initialized
INFO - 2021-01-06 05:10:56 --> Router Class Initialized
INFO - 2021-01-06 05:10:56 --> Output Class Initialized
INFO - 2021-01-06 05:10:56 --> Security Class Initialized
DEBUG - 2021-01-06 05:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:10:56 --> Input Class Initialized
INFO - 2021-01-06 05:10:56 --> Language Class Initialized
INFO - 2021-01-06 05:10:56 --> Language Class Initialized
INFO - 2021-01-06 05:10:56 --> Config Class Initialized
INFO - 2021-01-06 05:10:56 --> Loader Class Initialized
INFO - 2021-01-06 05:10:56 --> Helper loaded: url_helper
INFO - 2021-01-06 05:10:56 --> Helper loaded: file_helper
INFO - 2021-01-06 05:10:56 --> Helper loaded: form_helper
INFO - 2021-01-06 05:10:56 --> Helper loaded: my_helper
INFO - 2021-01-06 05:10:56 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:10:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:10:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:10:56 --> Controller Class Initialized
DEBUG - 2021-01-06 05:10:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:10:56 --> Final output sent to browser
DEBUG - 2021-01-06 05:10:56 --> Total execution time: 0.2818
INFO - 2021-01-06 05:11:09 --> Config Class Initialized
INFO - 2021-01-06 05:11:09 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:11:09 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:11:09 --> Utf8 Class Initialized
INFO - 2021-01-06 05:11:09 --> URI Class Initialized
INFO - 2021-01-06 05:11:09 --> Router Class Initialized
INFO - 2021-01-06 05:11:09 --> Output Class Initialized
INFO - 2021-01-06 05:11:09 --> Security Class Initialized
DEBUG - 2021-01-06 05:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:11:09 --> Input Class Initialized
INFO - 2021-01-06 05:11:09 --> Language Class Initialized
INFO - 2021-01-06 05:11:09 --> Language Class Initialized
INFO - 2021-01-06 05:11:09 --> Config Class Initialized
INFO - 2021-01-06 05:11:09 --> Loader Class Initialized
INFO - 2021-01-06 05:11:09 --> Helper loaded: url_helper
INFO - 2021-01-06 05:11:09 --> Helper loaded: file_helper
INFO - 2021-01-06 05:11:09 --> Helper loaded: form_helper
INFO - 2021-01-06 05:11:09 --> Helper loaded: my_helper
INFO - 2021-01-06 05:11:09 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:11:09 --> Controller Class Initialized
DEBUG - 2021-01-06 05:11:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:11:09 --> Final output sent to browser
DEBUG - 2021-01-06 05:11:09 --> Total execution time: 0.2906
INFO - 2021-01-06 05:12:34 --> Config Class Initialized
INFO - 2021-01-06 05:12:34 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:12:34 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:12:34 --> Utf8 Class Initialized
INFO - 2021-01-06 05:12:34 --> URI Class Initialized
INFO - 2021-01-06 05:12:34 --> Router Class Initialized
INFO - 2021-01-06 05:12:34 --> Output Class Initialized
INFO - 2021-01-06 05:12:34 --> Security Class Initialized
DEBUG - 2021-01-06 05:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:12:34 --> Input Class Initialized
INFO - 2021-01-06 05:12:34 --> Language Class Initialized
INFO - 2021-01-06 05:12:34 --> Language Class Initialized
INFO - 2021-01-06 05:12:34 --> Config Class Initialized
INFO - 2021-01-06 05:12:34 --> Loader Class Initialized
INFO - 2021-01-06 05:12:34 --> Helper loaded: url_helper
INFO - 2021-01-06 05:12:34 --> Helper loaded: file_helper
INFO - 2021-01-06 05:12:34 --> Helper loaded: form_helper
INFO - 2021-01-06 05:12:34 --> Helper loaded: my_helper
INFO - 2021-01-06 05:12:34 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:12:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:12:35 --> Controller Class Initialized
ERROR - 2021-01-06 05:12:35 --> Severity: Notice --> Undefined index: t C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 166
ERROR - 2021-01-06 05:12:35 --> Severity: Notice --> Undefined index: a C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 167
DEBUG - 2021-01-06 05:12:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:12:35 --> Final output sent to browser
DEBUG - 2021-01-06 05:12:35 --> Total execution time: 0.3334
INFO - 2021-01-06 05:18:26 --> Config Class Initialized
INFO - 2021-01-06 05:18:26 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:18:26 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:18:26 --> Utf8 Class Initialized
INFO - 2021-01-06 05:18:26 --> URI Class Initialized
INFO - 2021-01-06 05:18:26 --> Router Class Initialized
INFO - 2021-01-06 05:18:26 --> Output Class Initialized
INFO - 2021-01-06 05:18:26 --> Security Class Initialized
DEBUG - 2021-01-06 05:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:18:26 --> Input Class Initialized
INFO - 2021-01-06 05:18:26 --> Language Class Initialized
INFO - 2021-01-06 05:18:26 --> Language Class Initialized
INFO - 2021-01-06 05:18:26 --> Config Class Initialized
INFO - 2021-01-06 05:18:26 --> Loader Class Initialized
INFO - 2021-01-06 05:18:26 --> Helper loaded: url_helper
INFO - 2021-01-06 05:18:26 --> Helper loaded: file_helper
INFO - 2021-01-06 05:18:26 --> Helper loaded: form_helper
INFO - 2021-01-06 05:18:26 --> Helper loaded: my_helper
INFO - 2021-01-06 05:18:26 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:18:26 --> Controller Class Initialized
DEBUG - 2021-01-06 05:18:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:18:26 --> Final output sent to browser
DEBUG - 2021-01-06 05:18:26 --> Total execution time: 0.3041
INFO - 2021-01-06 05:18:42 --> Config Class Initialized
INFO - 2021-01-06 05:18:42 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:18:42 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:18:42 --> Utf8 Class Initialized
INFO - 2021-01-06 05:18:42 --> URI Class Initialized
INFO - 2021-01-06 05:18:42 --> Router Class Initialized
INFO - 2021-01-06 05:18:42 --> Output Class Initialized
INFO - 2021-01-06 05:18:42 --> Security Class Initialized
DEBUG - 2021-01-06 05:18:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:18:42 --> Input Class Initialized
INFO - 2021-01-06 05:18:42 --> Language Class Initialized
INFO - 2021-01-06 05:18:42 --> Language Class Initialized
INFO - 2021-01-06 05:18:42 --> Config Class Initialized
INFO - 2021-01-06 05:18:42 --> Loader Class Initialized
INFO - 2021-01-06 05:18:42 --> Helper loaded: url_helper
INFO - 2021-01-06 05:18:42 --> Helper loaded: file_helper
INFO - 2021-01-06 05:18:42 --> Helper loaded: form_helper
INFO - 2021-01-06 05:18:42 --> Helper loaded: my_helper
INFO - 2021-01-06 05:18:42 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:18:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:18:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:18:42 --> Controller Class Initialized
DEBUG - 2021-01-06 05:18:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:18:42 --> Final output sent to browser
DEBUG - 2021-01-06 05:18:42 --> Total execution time: 0.2849
INFO - 2021-01-06 05:18:57 --> Config Class Initialized
INFO - 2021-01-06 05:18:57 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:18:57 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:18:57 --> Utf8 Class Initialized
INFO - 2021-01-06 05:18:57 --> URI Class Initialized
INFO - 2021-01-06 05:18:57 --> Router Class Initialized
INFO - 2021-01-06 05:18:58 --> Output Class Initialized
INFO - 2021-01-06 05:18:58 --> Security Class Initialized
DEBUG - 2021-01-06 05:18:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:18:58 --> Input Class Initialized
INFO - 2021-01-06 05:18:58 --> Language Class Initialized
ERROR - 2021-01-06 05:18:58 --> Severity: Parsing Error --> syntax error, unexpected ',' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 169
INFO - 2021-01-06 05:19:21 --> Config Class Initialized
INFO - 2021-01-06 05:19:21 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:19:21 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:19:21 --> Utf8 Class Initialized
INFO - 2021-01-06 05:19:21 --> URI Class Initialized
INFO - 2021-01-06 05:19:21 --> Router Class Initialized
INFO - 2021-01-06 05:19:21 --> Output Class Initialized
INFO - 2021-01-06 05:19:21 --> Security Class Initialized
DEBUG - 2021-01-06 05:19:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:19:21 --> Input Class Initialized
INFO - 2021-01-06 05:19:21 --> Language Class Initialized
INFO - 2021-01-06 05:19:21 --> Language Class Initialized
INFO - 2021-01-06 05:19:21 --> Config Class Initialized
INFO - 2021-01-06 05:19:21 --> Loader Class Initialized
INFO - 2021-01-06 05:19:21 --> Helper loaded: url_helper
INFO - 2021-01-06 05:19:21 --> Helper loaded: file_helper
INFO - 2021-01-06 05:19:21 --> Helper loaded: form_helper
INFO - 2021-01-06 05:19:21 --> Helper loaded: my_helper
INFO - 2021-01-06 05:19:21 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:19:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:19:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:19:21 --> Controller Class Initialized
DEBUG - 2021-01-06 05:19:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:19:21 --> Final output sent to browser
DEBUG - 2021-01-06 05:19:21 --> Total execution time: 0.3456
INFO - 2021-01-06 05:23:22 --> Config Class Initialized
INFO - 2021-01-06 05:23:22 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:23:22 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:23:22 --> Utf8 Class Initialized
INFO - 2021-01-06 05:23:22 --> URI Class Initialized
INFO - 2021-01-06 05:23:22 --> Router Class Initialized
INFO - 2021-01-06 05:23:22 --> Output Class Initialized
INFO - 2021-01-06 05:23:22 --> Security Class Initialized
DEBUG - 2021-01-06 05:23:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:23:22 --> Input Class Initialized
INFO - 2021-01-06 05:23:22 --> Language Class Initialized
ERROR - 2021-01-06 05:23:22 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 169
INFO - 2021-01-06 05:23:50 --> Config Class Initialized
INFO - 2021-01-06 05:23:50 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:23:50 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:23:50 --> Utf8 Class Initialized
INFO - 2021-01-06 05:23:50 --> URI Class Initialized
INFO - 2021-01-06 05:23:50 --> Router Class Initialized
INFO - 2021-01-06 05:23:50 --> Output Class Initialized
INFO - 2021-01-06 05:23:50 --> Security Class Initialized
DEBUG - 2021-01-06 05:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:23:51 --> Input Class Initialized
INFO - 2021-01-06 05:23:51 --> Language Class Initialized
ERROR - 2021-01-06 05:23:51 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 169
INFO - 2021-01-06 05:23:51 --> Config Class Initialized
INFO - 2021-01-06 05:23:51 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:23:51 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:23:51 --> Utf8 Class Initialized
INFO - 2021-01-06 05:23:51 --> URI Class Initialized
INFO - 2021-01-06 05:23:51 --> Router Class Initialized
INFO - 2021-01-06 05:23:51 --> Output Class Initialized
INFO - 2021-01-06 05:23:51 --> Security Class Initialized
DEBUG - 2021-01-06 05:23:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:23:52 --> Input Class Initialized
INFO - 2021-01-06 05:23:52 --> Language Class Initialized
ERROR - 2021-01-06 05:23:52 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 169
INFO - 2021-01-06 05:24:23 --> Config Class Initialized
INFO - 2021-01-06 05:24:23 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:24:23 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:24:23 --> Utf8 Class Initialized
INFO - 2021-01-06 05:24:23 --> URI Class Initialized
INFO - 2021-01-06 05:24:23 --> Router Class Initialized
INFO - 2021-01-06 05:24:23 --> Output Class Initialized
INFO - 2021-01-06 05:24:23 --> Security Class Initialized
DEBUG - 2021-01-06 05:24:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:24:23 --> Input Class Initialized
INFO - 2021-01-06 05:24:23 --> Language Class Initialized
ERROR - 2021-01-06 05:24:23 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 169
INFO - 2021-01-06 05:24:41 --> Config Class Initialized
INFO - 2021-01-06 05:24:41 --> Hooks Class Initialized
DEBUG - 2021-01-06 05:24:41 --> UTF-8 Support Enabled
INFO - 2021-01-06 05:24:41 --> Utf8 Class Initialized
INFO - 2021-01-06 05:24:41 --> URI Class Initialized
INFO - 2021-01-06 05:24:41 --> Router Class Initialized
INFO - 2021-01-06 05:24:42 --> Output Class Initialized
INFO - 2021-01-06 05:24:42 --> Security Class Initialized
DEBUG - 2021-01-06 05:24:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 05:24:42 --> Input Class Initialized
INFO - 2021-01-06 05:24:42 --> Language Class Initialized
INFO - 2021-01-06 05:24:42 --> Language Class Initialized
INFO - 2021-01-06 05:24:42 --> Config Class Initialized
INFO - 2021-01-06 05:24:42 --> Loader Class Initialized
INFO - 2021-01-06 05:24:42 --> Helper loaded: url_helper
INFO - 2021-01-06 05:24:42 --> Helper loaded: file_helper
INFO - 2021-01-06 05:24:42 --> Helper loaded: form_helper
INFO - 2021-01-06 05:24:42 --> Helper loaded: my_helper
INFO - 2021-01-06 05:24:42 --> Database Driver Class Initialized
DEBUG - 2021-01-06 05:24:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 05:24:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 05:24:42 --> Controller Class Initialized
DEBUG - 2021-01-06 05:24:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 05:24:42 --> Final output sent to browser
DEBUG - 2021-01-06 05:24:42 --> Total execution time: 0.3105
INFO - 2021-01-06 07:38:40 --> Config Class Initialized
INFO - 2021-01-06 07:38:40 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:38:40 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:38:40 --> Utf8 Class Initialized
INFO - 2021-01-06 07:38:40 --> URI Class Initialized
INFO - 2021-01-06 07:38:40 --> Router Class Initialized
INFO - 2021-01-06 07:38:40 --> Output Class Initialized
INFO - 2021-01-06 07:38:40 --> Security Class Initialized
DEBUG - 2021-01-06 07:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:38:40 --> Input Class Initialized
INFO - 2021-01-06 07:38:40 --> Language Class Initialized
INFO - 2021-01-06 07:38:40 --> Language Class Initialized
INFO - 2021-01-06 07:38:40 --> Config Class Initialized
INFO - 2021-01-06 07:38:40 --> Loader Class Initialized
INFO - 2021-01-06 07:38:40 --> Helper loaded: url_helper
INFO - 2021-01-06 07:38:40 --> Helper loaded: file_helper
INFO - 2021-01-06 07:38:40 --> Helper loaded: form_helper
INFO - 2021-01-06 07:38:40 --> Helper loaded: my_helper
INFO - 2021-01-06 07:38:40 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:38:40 --> Controller Class Initialized
DEBUG - 2021-01-06 07:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 07:38:40 --> Final output sent to browser
DEBUG - 2021-01-06 07:38:40 --> Total execution time: 0.3103
INFO - 2021-01-06 07:42:12 --> Config Class Initialized
INFO - 2021-01-06 07:42:12 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:42:12 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:42:12 --> Utf8 Class Initialized
INFO - 2021-01-06 07:42:12 --> URI Class Initialized
INFO - 2021-01-06 07:42:12 --> Router Class Initialized
INFO - 2021-01-06 07:42:12 --> Output Class Initialized
INFO - 2021-01-06 07:42:12 --> Security Class Initialized
DEBUG - 2021-01-06 07:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:42:12 --> Input Class Initialized
INFO - 2021-01-06 07:42:12 --> Language Class Initialized
INFO - 2021-01-06 07:42:12 --> Language Class Initialized
INFO - 2021-01-06 07:42:12 --> Config Class Initialized
INFO - 2021-01-06 07:42:12 --> Loader Class Initialized
INFO - 2021-01-06 07:42:12 --> Helper loaded: url_helper
INFO - 2021-01-06 07:42:12 --> Helper loaded: file_helper
INFO - 2021-01-06 07:42:12 --> Helper loaded: form_helper
INFO - 2021-01-06 07:42:12 --> Helper loaded: my_helper
INFO - 2021-01-06 07:42:12 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:42:12 --> Controller Class Initialized
DEBUG - 2021-01-06 07:42:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 07:42:12 --> Final output sent to browser
DEBUG - 2021-01-06 07:42:12 --> Total execution time: 0.3475
INFO - 2021-01-06 07:49:00 --> Config Class Initialized
INFO - 2021-01-06 07:49:00 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:49:00 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:49:00 --> Utf8 Class Initialized
INFO - 2021-01-06 07:49:00 --> URI Class Initialized
INFO - 2021-01-06 07:49:00 --> Router Class Initialized
INFO - 2021-01-06 07:49:00 --> Output Class Initialized
INFO - 2021-01-06 07:49:00 --> Security Class Initialized
DEBUG - 2021-01-06 07:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:49:00 --> Input Class Initialized
INFO - 2021-01-06 07:49:00 --> Language Class Initialized
ERROR - 2021-01-06 07:49:00 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 521
INFO - 2021-01-06 07:49:39 --> Config Class Initialized
INFO - 2021-01-06 07:49:39 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:49:39 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:49:39 --> Utf8 Class Initialized
INFO - 2021-01-06 07:49:39 --> URI Class Initialized
INFO - 2021-01-06 07:49:39 --> Router Class Initialized
INFO - 2021-01-06 07:49:39 --> Output Class Initialized
INFO - 2021-01-06 07:49:39 --> Security Class Initialized
DEBUG - 2021-01-06 07:49:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:49:39 --> Input Class Initialized
INFO - 2021-01-06 07:49:39 --> Language Class Initialized
ERROR - 2021-01-06 07:49:39 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 521
INFO - 2021-01-06 07:50:15 --> Config Class Initialized
INFO - 2021-01-06 07:50:15 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:50:15 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:50:15 --> Utf8 Class Initialized
INFO - 2021-01-06 07:50:15 --> URI Class Initialized
INFO - 2021-01-06 07:50:15 --> Router Class Initialized
INFO - 2021-01-06 07:50:15 --> Output Class Initialized
INFO - 2021-01-06 07:50:15 --> Security Class Initialized
DEBUG - 2021-01-06 07:50:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:50:15 --> Input Class Initialized
INFO - 2021-01-06 07:50:15 --> Language Class Initialized
ERROR - 2021-01-06 07:50:15 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 521
INFO - 2021-01-06 07:50:26 --> Config Class Initialized
INFO - 2021-01-06 07:50:26 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:50:27 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:50:27 --> Utf8 Class Initialized
INFO - 2021-01-06 07:50:27 --> URI Class Initialized
INFO - 2021-01-06 07:50:27 --> Router Class Initialized
INFO - 2021-01-06 07:50:27 --> Output Class Initialized
INFO - 2021-01-06 07:50:27 --> Security Class Initialized
DEBUG - 2021-01-06 07:50:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:50:27 --> Input Class Initialized
INFO - 2021-01-06 07:50:27 --> Language Class Initialized
ERROR - 2021-01-06 07:50:27 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 521
INFO - 2021-01-06 07:50:50 --> Config Class Initialized
INFO - 2021-01-06 07:50:50 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:50:50 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:50:50 --> Utf8 Class Initialized
INFO - 2021-01-06 07:50:50 --> URI Class Initialized
INFO - 2021-01-06 07:50:50 --> Router Class Initialized
INFO - 2021-01-06 07:50:50 --> Output Class Initialized
INFO - 2021-01-06 07:50:50 --> Security Class Initialized
DEBUG - 2021-01-06 07:50:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:50:50 --> Input Class Initialized
INFO - 2021-01-06 07:50:50 --> Language Class Initialized
INFO - 2021-01-06 07:50:50 --> Language Class Initialized
INFO - 2021-01-06 07:50:50 --> Config Class Initialized
INFO - 2021-01-06 07:50:50 --> Loader Class Initialized
INFO - 2021-01-06 07:50:50 --> Helper loaded: url_helper
INFO - 2021-01-06 07:50:50 --> Helper loaded: file_helper
INFO - 2021-01-06 07:50:50 --> Helper loaded: form_helper
INFO - 2021-01-06 07:50:50 --> Helper loaded: my_helper
INFO - 2021-01-06 07:50:50 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:50:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:50:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:50:50 --> Controller Class Initialized
DEBUG - 2021-01-06 07:50:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 07:50:50 --> Final output sent to browser
DEBUG - 2021-01-06 07:50:50 --> Total execution time: 0.2833
INFO - 2021-01-06 07:51:08 --> Config Class Initialized
INFO - 2021-01-06 07:51:08 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:51:08 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:51:08 --> Utf8 Class Initialized
INFO - 2021-01-06 07:51:08 --> URI Class Initialized
INFO - 2021-01-06 07:51:08 --> Router Class Initialized
INFO - 2021-01-06 07:51:08 --> Output Class Initialized
INFO - 2021-01-06 07:51:08 --> Security Class Initialized
DEBUG - 2021-01-06 07:51:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:51:08 --> Input Class Initialized
INFO - 2021-01-06 07:51:08 --> Language Class Initialized
INFO - 2021-01-06 07:51:08 --> Language Class Initialized
INFO - 2021-01-06 07:51:08 --> Config Class Initialized
INFO - 2021-01-06 07:51:08 --> Loader Class Initialized
INFO - 2021-01-06 07:51:08 --> Helper loaded: url_helper
INFO - 2021-01-06 07:51:08 --> Helper loaded: file_helper
INFO - 2021-01-06 07:51:08 --> Helper loaded: form_helper
INFO - 2021-01-06 07:51:08 --> Helper loaded: my_helper
INFO - 2021-01-06 07:51:08 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:51:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:51:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:51:08 --> Controller Class Initialized
ERROR - 2021-01-06 07:51:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                 ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',a.jenis='t',a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 07:51:08 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 07:51:31 --> Config Class Initialized
INFO - 2021-01-06 07:51:31 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:51:31 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:51:31 --> Utf8 Class Initialized
INFO - 2021-01-06 07:51:31 --> URI Class Initialized
INFO - 2021-01-06 07:51:31 --> Router Class Initialized
INFO - 2021-01-06 07:51:31 --> Output Class Initialized
INFO - 2021-01-06 07:51:31 --> Security Class Initialized
DEBUG - 2021-01-06 07:51:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:51:31 --> Input Class Initialized
INFO - 2021-01-06 07:51:31 --> Language Class Initialized
INFO - 2021-01-06 07:51:31 --> Language Class Initialized
INFO - 2021-01-06 07:51:31 --> Config Class Initialized
INFO - 2021-01-06 07:51:31 --> Loader Class Initialized
INFO - 2021-01-06 07:51:31 --> Helper loaded: url_helper
INFO - 2021-01-06 07:51:31 --> Helper loaded: file_helper
INFO - 2021-01-06 07:51:31 --> Helper loaded: form_helper
INFO - 2021-01-06 07:51:31 --> Helper loaded: my_helper
INFO - 2021-01-06 07:51:32 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:51:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:51:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:51:32 --> Controller Class Initialized
ERROR - 2021-01-06 07:51:32 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                 ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h','t','a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 07:51:32 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 07:51:56 --> Config Class Initialized
INFO - 2021-01-06 07:51:56 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:51:56 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:51:56 --> Utf8 Class Initialized
INFO - 2021-01-06 07:51:56 --> URI Class Initialized
INFO - 2021-01-06 07:51:56 --> Router Class Initialized
INFO - 2021-01-06 07:51:57 --> Output Class Initialized
INFO - 2021-01-06 07:51:57 --> Security Class Initialized
DEBUG - 2021-01-06 07:51:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:51:57 --> Input Class Initialized
INFO - 2021-01-06 07:51:57 --> Language Class Initialized
INFO - 2021-01-06 07:51:57 --> Language Class Initialized
INFO - 2021-01-06 07:51:57 --> Config Class Initialized
INFO - 2021-01-06 07:51:57 --> Loader Class Initialized
INFO - 2021-01-06 07:51:57 --> Helper loaded: url_helper
INFO - 2021-01-06 07:51:57 --> Helper loaded: file_helper
INFO - 2021-01-06 07:51:57 --> Helper loaded: form_helper
INFO - 2021-01-06 07:51:57 --> Helper loaded: my_helper
INFO - 2021-01-06 07:51:57 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:51:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:51:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:51:57 --> Controller Class Initialized
DEBUG - 2021-01-06 07:51:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 07:51:57 --> Final output sent to browser
DEBUG - 2021-01-06 07:51:57 --> Total execution time: 0.6427
INFO - 2021-01-06 07:55:01 --> Config Class Initialized
INFO - 2021-01-06 07:55:01 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:55:01 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:55:01 --> Utf8 Class Initialized
INFO - 2021-01-06 07:55:01 --> URI Class Initialized
INFO - 2021-01-06 07:55:01 --> Router Class Initialized
INFO - 2021-01-06 07:55:01 --> Output Class Initialized
INFO - 2021-01-06 07:55:01 --> Security Class Initialized
DEBUG - 2021-01-06 07:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:55:01 --> Input Class Initialized
INFO - 2021-01-06 07:55:01 --> Language Class Initialized
INFO - 2021-01-06 07:55:01 --> Language Class Initialized
INFO - 2021-01-06 07:55:01 --> Config Class Initialized
INFO - 2021-01-06 07:55:02 --> Loader Class Initialized
INFO - 2021-01-06 07:55:02 --> Helper loaded: url_helper
INFO - 2021-01-06 07:55:02 --> Helper loaded: file_helper
INFO - 2021-01-06 07:55:02 --> Helper loaded: form_helper
INFO - 2021-01-06 07:55:02 --> Helper loaded: my_helper
INFO - 2021-01-06 07:55:02 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:55:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:55:02 --> Controller Class Initialized
ERROR - 2021-01-06 07:55:02 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 171
DEBUG - 2021-01-06 07:55:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 07:55:02 --> Final output sent to browser
DEBUG - 2021-01-06 07:55:02 --> Total execution time: 0.6935
INFO - 2021-01-06 07:59:39 --> Config Class Initialized
INFO - 2021-01-06 07:59:39 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:59:39 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:59:39 --> Utf8 Class Initialized
INFO - 2021-01-06 07:59:39 --> URI Class Initialized
INFO - 2021-01-06 07:59:39 --> Router Class Initialized
INFO - 2021-01-06 07:59:39 --> Output Class Initialized
INFO - 2021-01-06 07:59:39 --> Security Class Initialized
DEBUG - 2021-01-06 07:59:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:59:39 --> Input Class Initialized
INFO - 2021-01-06 07:59:39 --> Language Class Initialized
INFO - 2021-01-06 07:59:39 --> Language Class Initialized
INFO - 2021-01-06 07:59:39 --> Config Class Initialized
INFO - 2021-01-06 07:59:39 --> Loader Class Initialized
INFO - 2021-01-06 07:59:39 --> Helper loaded: url_helper
INFO - 2021-01-06 07:59:39 --> Helper loaded: file_helper
INFO - 2021-01-06 07:59:39 --> Helper loaded: form_helper
INFO - 2021-01-06 07:59:39 --> Helper loaded: my_helper
INFO - 2021-01-06 07:59:39 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:59:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:59:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:59:39 --> Controller Class Initialized
ERROR - 2021-01-06 07:59:39 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 171
DEBUG - 2021-01-06 07:59:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 07:59:39 --> Final output sent to browser
DEBUG - 2021-01-06 07:59:39 --> Total execution time: 0.3363
INFO - 2021-01-06 07:59:45 --> Config Class Initialized
INFO - 2021-01-06 07:59:45 --> Hooks Class Initialized
DEBUG - 2021-01-06 07:59:45 --> UTF-8 Support Enabled
INFO - 2021-01-06 07:59:45 --> Utf8 Class Initialized
INFO - 2021-01-06 07:59:45 --> URI Class Initialized
INFO - 2021-01-06 07:59:45 --> Router Class Initialized
INFO - 2021-01-06 07:59:45 --> Output Class Initialized
INFO - 2021-01-06 07:59:45 --> Security Class Initialized
DEBUG - 2021-01-06 07:59:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 07:59:45 --> Input Class Initialized
INFO - 2021-01-06 07:59:45 --> Language Class Initialized
INFO - 2021-01-06 07:59:45 --> Language Class Initialized
INFO - 2021-01-06 07:59:45 --> Config Class Initialized
INFO - 2021-01-06 07:59:45 --> Loader Class Initialized
INFO - 2021-01-06 07:59:46 --> Helper loaded: url_helper
INFO - 2021-01-06 07:59:46 --> Helper loaded: file_helper
INFO - 2021-01-06 07:59:46 --> Helper loaded: form_helper
INFO - 2021-01-06 07:59:46 --> Helper loaded: my_helper
INFO - 2021-01-06 07:59:46 --> Database Driver Class Initialized
DEBUG - 2021-01-06 07:59:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 07:59:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 07:59:46 --> Controller Class Initialized
DEBUG - 2021-01-06 07:59:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 07:59:46 --> Final output sent to browser
DEBUG - 2021-01-06 07:59:46 --> Total execution time: 0.3073
INFO - 2021-01-06 08:00:03 --> Config Class Initialized
INFO - 2021-01-06 08:00:03 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:00:03 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:00:03 --> Utf8 Class Initialized
INFO - 2021-01-06 08:00:03 --> URI Class Initialized
INFO - 2021-01-06 08:00:03 --> Router Class Initialized
INFO - 2021-01-06 08:00:03 --> Output Class Initialized
INFO - 2021-01-06 08:00:03 --> Security Class Initialized
DEBUG - 2021-01-06 08:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:00:03 --> Input Class Initialized
INFO - 2021-01-06 08:00:03 --> Language Class Initialized
INFO - 2021-01-06 08:00:03 --> Language Class Initialized
INFO - 2021-01-06 08:00:03 --> Config Class Initialized
INFO - 2021-01-06 08:00:03 --> Loader Class Initialized
INFO - 2021-01-06 08:00:03 --> Helper loaded: url_helper
INFO - 2021-01-06 08:00:03 --> Helper loaded: file_helper
INFO - 2021-01-06 08:00:03 --> Helper loaded: form_helper
INFO - 2021-01-06 08:00:03 --> Helper loaded: my_helper
INFO - 2021-01-06 08:00:03 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:00:03 --> Controller Class Initialized
ERROR - 2021-01-06 08:00:03 --> Query error: Operand should contain 1 column(s) - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, (a.jenis='h',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:00:03 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:00:16 --> Config Class Initialized
INFO - 2021-01-06 08:00:16 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:00:16 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:00:16 --> Utf8 Class Initialized
INFO - 2021-01-06 08:00:16 --> URI Class Initialized
INFO - 2021-01-06 08:00:16 --> Router Class Initialized
INFO - 2021-01-06 08:00:16 --> Output Class Initialized
INFO - 2021-01-06 08:00:16 --> Security Class Initialized
DEBUG - 2021-01-06 08:00:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:00:16 --> Input Class Initialized
INFO - 2021-01-06 08:00:16 --> Language Class Initialized
INFO - 2021-01-06 08:00:16 --> Language Class Initialized
INFO - 2021-01-06 08:00:16 --> Config Class Initialized
INFO - 2021-01-06 08:00:16 --> Loader Class Initialized
INFO - 2021-01-06 08:00:16 --> Helper loaded: url_helper
INFO - 2021-01-06 08:00:16 --> Helper loaded: file_helper
INFO - 2021-01-06 08:00:16 --> Helper loaded: form_helper
INFO - 2021-01-06 08:00:16 --> Helper loaded: my_helper
INFO - 2021-01-06 08:00:16 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:00:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:00:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:00:16 --> Controller Class Initialized
DEBUG - 2021-01-06 08:00:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:00:16 --> Final output sent to browser
DEBUG - 2021-01-06 08:00:16 --> Total execution time: 0.2985
INFO - 2021-01-06 08:01:36 --> Config Class Initialized
INFO - 2021-01-06 08:01:37 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:01:37 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:01:37 --> Utf8 Class Initialized
INFO - 2021-01-06 08:01:37 --> URI Class Initialized
INFO - 2021-01-06 08:01:37 --> Router Class Initialized
INFO - 2021-01-06 08:01:37 --> Output Class Initialized
INFO - 2021-01-06 08:01:37 --> Security Class Initialized
DEBUG - 2021-01-06 08:01:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:01:37 --> Input Class Initialized
INFO - 2021-01-06 08:01:37 --> Language Class Initialized
INFO - 2021-01-06 08:01:37 --> Language Class Initialized
INFO - 2021-01-06 08:01:37 --> Config Class Initialized
INFO - 2021-01-06 08:01:37 --> Loader Class Initialized
INFO - 2021-01-06 08:01:37 --> Helper loaded: url_helper
INFO - 2021-01-06 08:01:37 --> Helper loaded: file_helper
INFO - 2021-01-06 08:01:37 --> Helper loaded: form_helper
INFO - 2021-01-06 08:01:37 --> Helper loaded: my_helper
INFO - 2021-01-06 08:01:37 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:01:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:01:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:01:37 --> Controller Class Initialized
ERROR - 2021-01-06 08:01:37 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                 ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',a.jenis='t',a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:01:37 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:01:55 --> Config Class Initialized
INFO - 2021-01-06 08:01:55 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:01:55 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:01:55 --> Utf8 Class Initialized
INFO - 2021-01-06 08:01:55 --> URI Class Initialized
INFO - 2021-01-06 08:01:55 --> Router Class Initialized
INFO - 2021-01-06 08:01:55 --> Output Class Initialized
INFO - 2021-01-06 08:01:55 --> Security Class Initialized
DEBUG - 2021-01-06 08:01:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:01:55 --> Input Class Initialized
INFO - 2021-01-06 08:01:55 --> Language Class Initialized
INFO - 2021-01-06 08:01:55 --> Language Class Initialized
INFO - 2021-01-06 08:01:55 --> Config Class Initialized
INFO - 2021-01-06 08:01:55 --> Loader Class Initialized
INFO - 2021-01-06 08:01:55 --> Helper loaded: url_helper
INFO - 2021-01-06 08:01:55 --> Helper loaded: file_helper
INFO - 2021-01-06 08:01:55 --> Helper loaded: form_helper
INFO - 2021-01-06 08:01:55 --> Helper loaded: my_helper
INFO - 2021-01-06 08:01:55 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:01:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:01:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:01:55 --> Controller Class Initialized
ERROR - 2021-01-06 08:01:55 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a.nilai) nilai
                                    FROM t_nilai a
            ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',a.jenis='t',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:01:55 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:02:05 --> Config Class Initialized
INFO - 2021-01-06 08:02:05 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:02:05 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:02:05 --> Utf8 Class Initialized
INFO - 2021-01-06 08:02:05 --> URI Class Initialized
INFO - 2021-01-06 08:02:05 --> Router Class Initialized
INFO - 2021-01-06 08:02:05 --> Output Class Initialized
INFO - 2021-01-06 08:02:05 --> Security Class Initialized
DEBUG - 2021-01-06 08:02:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:02:05 --> Input Class Initialized
INFO - 2021-01-06 08:02:05 --> Language Class Initialized
INFO - 2021-01-06 08:02:05 --> Language Class Initialized
INFO - 2021-01-06 08:02:05 --> Config Class Initialized
INFO - 2021-01-06 08:02:05 --> Loader Class Initialized
INFO - 2021-01-06 08:02:05 --> Helper loaded: url_helper
INFO - 2021-01-06 08:02:05 --> Helper loaded: file_helper
INFO - 2021-01-06 08:02:05 --> Helper loaded: form_helper
INFO - 2021-01-06 08:02:05 --> Helper loaded: my_helper
INFO - 2021-01-06 08:02:05 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:02:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:02:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:02:05 --> Controller Class Initialized
DEBUG - 2021-01-06 08:02:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:02:06 --> Final output sent to browser
DEBUG - 2021-01-06 08:02:06 --> Total execution time: 0.6883
INFO - 2021-01-06 08:02:19 --> Config Class Initialized
INFO - 2021-01-06 08:02:20 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:02:20 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:02:20 --> Utf8 Class Initialized
INFO - 2021-01-06 08:02:20 --> URI Class Initialized
INFO - 2021-01-06 08:02:20 --> Router Class Initialized
INFO - 2021-01-06 08:02:20 --> Output Class Initialized
INFO - 2021-01-06 08:02:20 --> Security Class Initialized
DEBUG - 2021-01-06 08:02:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:02:20 --> Input Class Initialized
INFO - 2021-01-06 08:02:20 --> Language Class Initialized
INFO - 2021-01-06 08:02:20 --> Language Class Initialized
INFO - 2021-01-06 08:02:20 --> Config Class Initialized
INFO - 2021-01-06 08:02:20 --> Loader Class Initialized
INFO - 2021-01-06 08:02:20 --> Helper loaded: url_helper
INFO - 2021-01-06 08:02:20 --> Helper loaded: file_helper
INFO - 2021-01-06 08:02:20 --> Helper loaded: form_helper
INFO - 2021-01-06 08:02:20 --> Helper loaded: my_helper
INFO - 2021-01-06 08:02:20 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:02:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:02:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:02:20 --> Controller Class Initialized
ERROR - 2021-01-06 08:02:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                 ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h','t','a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:02:20 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:02:41 --> Config Class Initialized
INFO - 2021-01-06 08:02:41 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:02:41 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:02:42 --> Utf8 Class Initialized
INFO - 2021-01-06 08:02:42 --> URI Class Initialized
INFO - 2021-01-06 08:02:42 --> Router Class Initialized
INFO - 2021-01-06 08:02:42 --> Output Class Initialized
INFO - 2021-01-06 08:02:42 --> Security Class Initialized
DEBUG - 2021-01-06 08:02:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:02:42 --> Input Class Initialized
INFO - 2021-01-06 08:02:42 --> Language Class Initialized
INFO - 2021-01-06 08:02:42 --> Language Class Initialized
INFO - 2021-01-06 08:02:42 --> Config Class Initialized
INFO - 2021-01-06 08:02:42 --> Loader Class Initialized
INFO - 2021-01-06 08:02:42 --> Helper loaded: url_helper
INFO - 2021-01-06 08:02:42 --> Helper loaded: file_helper
INFO - 2021-01-06 08:02:42 --> Helper loaded: form_helper
INFO - 2021-01-06 08:02:42 --> Helper loaded: my_helper
INFO - 2021-01-06 08:02:42 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:02:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:02:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:02:42 --> Controller Class Initialized
DEBUG - 2021-01-06 08:02:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:02:42 --> Final output sent to browser
DEBUG - 2021-01-06 08:02:42 --> Total execution time: 0.7121
INFO - 2021-01-06 08:02:58 --> Config Class Initialized
INFO - 2021-01-06 08:02:58 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:02:58 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:02:58 --> Utf8 Class Initialized
INFO - 2021-01-06 08:02:58 --> URI Class Initialized
INFO - 2021-01-06 08:02:58 --> Router Class Initialized
INFO - 2021-01-06 08:02:58 --> Output Class Initialized
INFO - 2021-01-06 08:02:58 --> Security Class Initialized
DEBUG - 2021-01-06 08:02:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:02:59 --> Input Class Initialized
INFO - 2021-01-06 08:02:59 --> Language Class Initialized
INFO - 2021-01-06 08:02:59 --> Language Class Initialized
INFO - 2021-01-06 08:02:59 --> Config Class Initialized
INFO - 2021-01-06 08:02:59 --> Loader Class Initialized
INFO - 2021-01-06 08:02:59 --> Helper loaded: url_helper
INFO - 2021-01-06 08:02:59 --> Helper loaded: file_helper
INFO - 2021-01-06 08:02:59 --> Helper loaded: form_helper
INFO - 2021-01-06 08:02:59 --> Helper loaded: my_helper
INFO - 2021-01-06 08:02:59 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:02:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:02:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:02:59 --> Controller Class Initialized
ERROR - 2021-01-06 08:02:59 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 153
DEBUG - 2021-01-06 08:02:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:02:59 --> Final output sent to browser
DEBUG - 2021-01-06 08:02:59 --> Total execution time: 0.7975
INFO - 2021-01-06 08:04:28 --> Config Class Initialized
INFO - 2021-01-06 08:04:28 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:04:28 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:04:28 --> Utf8 Class Initialized
INFO - 2021-01-06 08:04:28 --> URI Class Initialized
INFO - 2021-01-06 08:04:28 --> Router Class Initialized
INFO - 2021-01-06 08:04:28 --> Output Class Initialized
INFO - 2021-01-06 08:04:28 --> Security Class Initialized
DEBUG - 2021-01-06 08:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:04:28 --> Input Class Initialized
INFO - 2021-01-06 08:04:28 --> Language Class Initialized
INFO - 2021-01-06 08:04:28 --> Language Class Initialized
INFO - 2021-01-06 08:04:28 --> Config Class Initialized
INFO - 2021-01-06 08:04:28 --> Loader Class Initialized
INFO - 2021-01-06 08:04:28 --> Helper loaded: url_helper
INFO - 2021-01-06 08:04:28 --> Helper loaded: file_helper
INFO - 2021-01-06 08:04:28 --> Helper loaded: form_helper
INFO - 2021-01-06 08:04:29 --> Helper loaded: my_helper
INFO - 2021-01-06 08:04:29 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:04:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:04:29 --> Controller Class Initialized
ERROR - 2021-01-06 08:04:29 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'nilai
                                    FROM t_nilai a
                     ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',(a.jenis='t',(a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:04:29 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:04:43 --> Config Class Initialized
INFO - 2021-01-06 08:04:43 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:04:43 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:04:43 --> Utf8 Class Initialized
INFO - 2021-01-06 08:04:43 --> URI Class Initialized
INFO - 2021-01-06 08:04:43 --> Router Class Initialized
INFO - 2021-01-06 08:04:43 --> Output Class Initialized
INFO - 2021-01-06 08:04:43 --> Security Class Initialized
DEBUG - 2021-01-06 08:04:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:04:44 --> Input Class Initialized
INFO - 2021-01-06 08:04:44 --> Language Class Initialized
INFO - 2021-01-06 08:04:44 --> Language Class Initialized
INFO - 2021-01-06 08:04:44 --> Config Class Initialized
INFO - 2021-01-06 08:04:44 --> Loader Class Initialized
INFO - 2021-01-06 08:04:44 --> Helper loaded: url_helper
INFO - 2021-01-06 08:04:44 --> Helper loaded: file_helper
INFO - 2021-01-06 08:04:44 --> Helper loaded: form_helper
INFO - 2021-01-06 08:04:44 --> Helper loaded: my_helper
INFO - 2021-01-06 08:04:44 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:04:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:04:44 --> Controller Class Initialized
ERROR - 2021-01-06 08:04:44 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'nilai
                                    FROM t_nilai a
                     ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h',if(a.jenis='t',if(a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:04:44 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:04:53 --> Config Class Initialized
INFO - 2021-01-06 08:04:53 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:04:53 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:04:53 --> Utf8 Class Initialized
INFO - 2021-01-06 08:04:53 --> URI Class Initialized
INFO - 2021-01-06 08:04:53 --> Router Class Initialized
INFO - 2021-01-06 08:04:53 --> Output Class Initialized
INFO - 2021-01-06 08:04:53 --> Security Class Initialized
DEBUG - 2021-01-06 08:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:04:53 --> Input Class Initialized
INFO - 2021-01-06 08:04:53 --> Language Class Initialized
INFO - 2021-01-06 08:04:53 --> Language Class Initialized
INFO - 2021-01-06 08:04:53 --> Config Class Initialized
INFO - 2021-01-06 08:04:53 --> Loader Class Initialized
INFO - 2021-01-06 08:04:53 --> Helper loaded: url_helper
INFO - 2021-01-06 08:04:53 --> Helper loaded: file_helper
INFO - 2021-01-06 08:04:53 --> Helper loaded: form_helper
INFO - 2021-01-06 08:04:53 --> Helper loaded: my_helper
INFO - 2021-01-06 08:04:53 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:04:53 --> Controller Class Initialized
ERROR - 2021-01-06 08:04:53 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'nilai
                                    FROM t_nilai a
                     ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h', if(a.jenis='t', if(a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:04:53 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:06:55 --> Config Class Initialized
INFO - 2021-01-06 08:06:55 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:06:55 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:06:55 --> Utf8 Class Initialized
INFO - 2021-01-06 08:06:55 --> URI Class Initialized
INFO - 2021-01-06 08:06:55 --> Router Class Initialized
INFO - 2021-01-06 08:06:55 --> Output Class Initialized
INFO - 2021-01-06 08:06:55 --> Security Class Initialized
DEBUG - 2021-01-06 08:06:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:06:55 --> Input Class Initialized
INFO - 2021-01-06 08:06:55 --> Language Class Initialized
INFO - 2021-01-06 08:06:55 --> Language Class Initialized
INFO - 2021-01-06 08:06:55 --> Config Class Initialized
INFO - 2021-01-06 08:06:55 --> Loader Class Initialized
INFO - 2021-01-06 08:06:55 --> Helper loaded: url_helper
INFO - 2021-01-06 08:06:55 --> Helper loaded: file_helper
INFO - 2021-01-06 08:06:56 --> Helper loaded: form_helper
INFO - 2021-01-06 08:06:56 --> Helper loaded: my_helper
INFO - 2021-01-06 08:06:56 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:06:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:06:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:06:56 --> Controller Class Initialized
ERROR - 2021-01-06 08:06:56 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'else(a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h', ifelse(a.jenis='t', else(a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:06:56 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:07:16 --> Config Class Initialized
INFO - 2021-01-06 08:07:16 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:07:16 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:07:16 --> Utf8 Class Initialized
INFO - 2021-01-06 08:07:16 --> URI Class Initialized
INFO - 2021-01-06 08:07:16 --> Router Class Initialized
INFO - 2021-01-06 08:07:16 --> Output Class Initialized
INFO - 2021-01-06 08:07:16 --> Security Class Initialized
DEBUG - 2021-01-06 08:07:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:07:17 --> Input Class Initialized
INFO - 2021-01-06 08:07:17 --> Language Class Initialized
INFO - 2021-01-06 08:07:17 --> Language Class Initialized
INFO - 2021-01-06 08:07:17 --> Config Class Initialized
INFO - 2021-01-06 08:07:17 --> Loader Class Initialized
INFO - 2021-01-06 08:07:17 --> Helper loaded: url_helper
INFO - 2021-01-06 08:07:17 --> Helper loaded: file_helper
INFO - 2021-01-06 08:07:17 --> Helper loaded: form_helper
INFO - 2021-01-06 08:07:17 --> Helper loaded: my_helper
INFO - 2021-01-06 08:07:17 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:07:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:07:17 --> Controller Class Initialized
ERROR - 2021-01-06 08:07:17 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a.jenis='t', else a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
   ' at line 2 - Invalid query: SELECT 
                                    c.id idmapel, a.tasm, c.kd_singkat, a.jenis, if(a.jenis='h', ifelse a.jenis='t', else a.jenis='a',CONCAT(a.nilai,'//',d.nama_kd),a.nilai) nilai
                                    FROM t_nilai a
                                    INNER JOIN t_guru_mapel b ON a.id_guru_mapel = b.id
                                    INNER JOIN m_mapel c ON b.id_mapel = c.id
                                    INNER JOIN t_mapel_kd d ON a.id_mapel_kd = d.id
                                    WHERE a.id_siswa = 1418
                                    AND a.tasm = '20201'
INFO - 2021-01-06 08:07:17 --> Language file loaded: language/english/db_lang.php
INFO - 2021-01-06 08:07:32 --> Config Class Initialized
INFO - 2021-01-06 08:07:32 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:07:32 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:07:32 --> Utf8 Class Initialized
INFO - 2021-01-06 08:07:33 --> URI Class Initialized
INFO - 2021-01-06 08:07:33 --> Router Class Initialized
INFO - 2021-01-06 08:07:33 --> Output Class Initialized
INFO - 2021-01-06 08:07:33 --> Security Class Initialized
DEBUG - 2021-01-06 08:07:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:07:33 --> Input Class Initialized
INFO - 2021-01-06 08:07:33 --> Language Class Initialized
INFO - 2021-01-06 08:07:33 --> Language Class Initialized
INFO - 2021-01-06 08:07:33 --> Config Class Initialized
INFO - 2021-01-06 08:07:33 --> Loader Class Initialized
INFO - 2021-01-06 08:07:33 --> Helper loaded: url_helper
INFO - 2021-01-06 08:07:33 --> Helper loaded: file_helper
INFO - 2021-01-06 08:07:33 --> Helper loaded: form_helper
INFO - 2021-01-06 08:07:33 --> Helper loaded: my_helper
INFO - 2021-01-06 08:07:33 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:07:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:07:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:07:33 --> Controller Class Initialized
ERROR - 2021-01-06 08:07:33 --> Severity: Notice --> Undefined offset: 1 C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 153
DEBUG - 2021-01-06 08:07:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:07:33 --> Final output sent to browser
DEBUG - 2021-01-06 08:07:33 --> Total execution time: 0.7702
INFO - 2021-01-06 08:08:04 --> Config Class Initialized
INFO - 2021-01-06 08:08:04 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:08:04 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:08:04 --> Utf8 Class Initialized
INFO - 2021-01-06 08:08:04 --> URI Class Initialized
INFO - 2021-01-06 08:08:04 --> Router Class Initialized
INFO - 2021-01-06 08:08:04 --> Output Class Initialized
INFO - 2021-01-06 08:08:04 --> Security Class Initialized
DEBUG - 2021-01-06 08:08:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:08:05 --> Input Class Initialized
INFO - 2021-01-06 08:08:05 --> Language Class Initialized
INFO - 2021-01-06 08:08:05 --> Language Class Initialized
INFO - 2021-01-06 08:08:05 --> Config Class Initialized
INFO - 2021-01-06 08:08:05 --> Loader Class Initialized
INFO - 2021-01-06 08:08:05 --> Helper loaded: url_helper
INFO - 2021-01-06 08:08:05 --> Helper loaded: file_helper
INFO - 2021-01-06 08:08:05 --> Helper loaded: form_helper
INFO - 2021-01-06 08:08:05 --> Helper loaded: my_helper
INFO - 2021-01-06 08:08:05 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:08:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:08:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:08:05 --> Controller Class Initialized
DEBUG - 2021-01-06 08:08:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:08:05 --> Final output sent to browser
DEBUG - 2021-01-06 08:08:05 --> Total execution time: 0.7257
INFO - 2021-01-06 08:39:44 --> Config Class Initialized
INFO - 2021-01-06 08:39:44 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:39:44 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:39:44 --> Utf8 Class Initialized
INFO - 2021-01-06 08:39:44 --> URI Class Initialized
INFO - 2021-01-06 08:39:44 --> Router Class Initialized
INFO - 2021-01-06 08:39:44 --> Output Class Initialized
INFO - 2021-01-06 08:39:44 --> Security Class Initialized
DEBUG - 2021-01-06 08:39:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:39:44 --> Input Class Initialized
INFO - 2021-01-06 08:39:44 --> Language Class Initialized
INFO - 2021-01-06 08:39:44 --> Language Class Initialized
INFO - 2021-01-06 08:39:44 --> Config Class Initialized
INFO - 2021-01-06 08:39:44 --> Loader Class Initialized
INFO - 2021-01-06 08:39:44 --> Helper loaded: url_helper
INFO - 2021-01-06 08:39:44 --> Helper loaded: file_helper
INFO - 2021-01-06 08:39:44 --> Helper loaded: form_helper
INFO - 2021-01-06 08:39:44 --> Helper loaded: my_helper
INFO - 2021-01-06 08:39:44 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:39:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:39:44 --> Controller Class Initialized
DEBUG - 2021-01-06 08:39:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:39:44 --> Final output sent to browser
DEBUG - 2021-01-06 08:39:45 --> Total execution time: 0.3225
INFO - 2021-01-06 08:39:50 --> Config Class Initialized
INFO - 2021-01-06 08:39:50 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:39:50 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:39:50 --> Utf8 Class Initialized
INFO - 2021-01-06 08:39:50 --> URI Class Initialized
INFO - 2021-01-06 08:39:50 --> Router Class Initialized
INFO - 2021-01-06 08:39:50 --> Output Class Initialized
INFO - 2021-01-06 08:39:50 --> Security Class Initialized
DEBUG - 2021-01-06 08:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:39:50 --> Input Class Initialized
INFO - 2021-01-06 08:39:50 --> Language Class Initialized
INFO - 2021-01-06 08:39:50 --> Language Class Initialized
INFO - 2021-01-06 08:39:50 --> Config Class Initialized
INFO - 2021-01-06 08:39:50 --> Loader Class Initialized
INFO - 2021-01-06 08:39:50 --> Helper loaded: url_helper
INFO - 2021-01-06 08:39:50 --> Helper loaded: file_helper
INFO - 2021-01-06 08:39:50 --> Helper loaded: form_helper
INFO - 2021-01-06 08:39:50 --> Helper loaded: my_helper
INFO - 2021-01-06 08:39:50 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:39:50 --> Controller Class Initialized
DEBUG - 2021-01-06 08:39:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:39:50 --> Final output sent to browser
DEBUG - 2021-01-06 08:39:50 --> Total execution time: 0.3495
INFO - 2021-01-06 08:40:01 --> Config Class Initialized
INFO - 2021-01-06 08:40:01 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:40:01 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:40:01 --> Utf8 Class Initialized
INFO - 2021-01-06 08:40:01 --> URI Class Initialized
INFO - 2021-01-06 08:40:01 --> Router Class Initialized
INFO - 2021-01-06 08:40:01 --> Output Class Initialized
INFO - 2021-01-06 08:40:01 --> Security Class Initialized
DEBUG - 2021-01-06 08:40:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:40:01 --> Input Class Initialized
INFO - 2021-01-06 08:40:01 --> Language Class Initialized
INFO - 2021-01-06 08:40:01 --> Language Class Initialized
INFO - 2021-01-06 08:40:01 --> Config Class Initialized
INFO - 2021-01-06 08:40:01 --> Loader Class Initialized
INFO - 2021-01-06 08:40:01 --> Helper loaded: url_helper
INFO - 2021-01-06 08:40:01 --> Helper loaded: file_helper
INFO - 2021-01-06 08:40:01 --> Helper loaded: form_helper
INFO - 2021-01-06 08:40:01 --> Helper loaded: my_helper
INFO - 2021-01-06 08:40:01 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:40:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:40:01 --> Controller Class Initialized
DEBUG - 2021-01-06 08:40:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:40:01 --> Final output sent to browser
DEBUG - 2021-01-06 08:40:01 --> Total execution time: 0.3269
INFO - 2021-01-06 08:41:30 --> Config Class Initialized
INFO - 2021-01-06 08:41:30 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:41:30 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:41:30 --> Utf8 Class Initialized
INFO - 2021-01-06 08:41:30 --> URI Class Initialized
INFO - 2021-01-06 08:41:30 --> Router Class Initialized
INFO - 2021-01-06 08:41:30 --> Output Class Initialized
INFO - 2021-01-06 08:41:30 --> Security Class Initialized
DEBUG - 2021-01-06 08:41:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:41:30 --> Input Class Initialized
INFO - 2021-01-06 08:41:30 --> Language Class Initialized
INFO - 2021-01-06 08:41:30 --> Language Class Initialized
INFO - 2021-01-06 08:41:30 --> Config Class Initialized
INFO - 2021-01-06 08:41:30 --> Loader Class Initialized
INFO - 2021-01-06 08:41:30 --> Helper loaded: url_helper
INFO - 2021-01-06 08:41:30 --> Helper loaded: file_helper
INFO - 2021-01-06 08:41:30 --> Helper loaded: form_helper
INFO - 2021-01-06 08:41:30 --> Helper loaded: my_helper
INFO - 2021-01-06 08:41:30 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:41:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:41:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:41:30 --> Controller Class Initialized
DEBUG - 2021-01-06 08:41:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:41:30 --> Final output sent to browser
DEBUG - 2021-01-06 08:41:30 --> Total execution time: 0.3251
INFO - 2021-01-06 08:42:43 --> Config Class Initialized
INFO - 2021-01-06 08:42:43 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:42:43 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:42:43 --> Utf8 Class Initialized
INFO - 2021-01-06 08:42:43 --> URI Class Initialized
INFO - 2021-01-06 08:42:43 --> Router Class Initialized
INFO - 2021-01-06 08:42:43 --> Output Class Initialized
INFO - 2021-01-06 08:42:43 --> Security Class Initialized
DEBUG - 2021-01-06 08:42:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:42:43 --> Input Class Initialized
INFO - 2021-01-06 08:42:43 --> Language Class Initialized
INFO - 2021-01-06 08:42:43 --> Language Class Initialized
INFO - 2021-01-06 08:42:43 --> Config Class Initialized
INFO - 2021-01-06 08:42:43 --> Loader Class Initialized
INFO - 2021-01-06 08:42:43 --> Helper loaded: url_helper
INFO - 2021-01-06 08:42:43 --> Helper loaded: file_helper
INFO - 2021-01-06 08:42:43 --> Helper loaded: form_helper
INFO - 2021-01-06 08:42:43 --> Helper loaded: my_helper
INFO - 2021-01-06 08:42:43 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:42:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:42:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:42:43 --> Controller Class Initialized
DEBUG - 2021-01-06 08:42:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:42:43 --> Final output sent to browser
DEBUG - 2021-01-06 08:42:43 --> Total execution time: 0.3372
INFO - 2021-01-06 08:43:01 --> Config Class Initialized
INFO - 2021-01-06 08:43:01 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:43:01 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:43:01 --> Utf8 Class Initialized
INFO - 2021-01-06 08:43:01 --> URI Class Initialized
INFO - 2021-01-06 08:43:01 --> Router Class Initialized
INFO - 2021-01-06 08:43:01 --> Output Class Initialized
INFO - 2021-01-06 08:43:01 --> Security Class Initialized
DEBUG - 2021-01-06 08:43:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:43:01 --> Input Class Initialized
INFO - 2021-01-06 08:43:01 --> Language Class Initialized
INFO - 2021-01-06 08:43:01 --> Language Class Initialized
INFO - 2021-01-06 08:43:01 --> Config Class Initialized
INFO - 2021-01-06 08:43:01 --> Loader Class Initialized
INFO - 2021-01-06 08:43:01 --> Helper loaded: url_helper
INFO - 2021-01-06 08:43:01 --> Helper loaded: file_helper
INFO - 2021-01-06 08:43:01 --> Helper loaded: form_helper
INFO - 2021-01-06 08:43:01 --> Helper loaded: my_helper
INFO - 2021-01-06 08:43:02 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:43:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:43:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:43:02 --> Controller Class Initialized
DEBUG - 2021-01-06 08:43:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:43:02 --> Final output sent to browser
DEBUG - 2021-01-06 08:43:02 --> Total execution time: 0.3198
INFO - 2021-01-06 08:43:13 --> Config Class Initialized
INFO - 2021-01-06 08:43:13 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:43:13 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:43:13 --> Utf8 Class Initialized
INFO - 2021-01-06 08:43:13 --> URI Class Initialized
INFO - 2021-01-06 08:43:13 --> Router Class Initialized
INFO - 2021-01-06 08:43:13 --> Output Class Initialized
INFO - 2021-01-06 08:43:13 --> Security Class Initialized
DEBUG - 2021-01-06 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:43:13 --> Input Class Initialized
INFO - 2021-01-06 08:43:13 --> Language Class Initialized
INFO - 2021-01-06 08:43:13 --> Language Class Initialized
INFO - 2021-01-06 08:43:13 --> Config Class Initialized
INFO - 2021-01-06 08:43:13 --> Loader Class Initialized
INFO - 2021-01-06 08:43:13 --> Helper loaded: url_helper
INFO - 2021-01-06 08:43:13 --> Helper loaded: file_helper
INFO - 2021-01-06 08:43:13 --> Helper loaded: form_helper
INFO - 2021-01-06 08:43:13 --> Helper loaded: my_helper
INFO - 2021-01-06 08:43:13 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:43:13 --> Controller Class Initialized
DEBUG - 2021-01-06 08:43:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:43:14 --> Final output sent to browser
DEBUG - 2021-01-06 08:43:14 --> Total execution time: 0.3176
INFO - 2021-01-06 08:48:27 --> Config Class Initialized
INFO - 2021-01-06 08:48:27 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:48:27 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:48:27 --> Utf8 Class Initialized
INFO - 2021-01-06 08:48:27 --> URI Class Initialized
INFO - 2021-01-06 08:48:27 --> Router Class Initialized
INFO - 2021-01-06 08:48:27 --> Output Class Initialized
INFO - 2021-01-06 08:48:27 --> Security Class Initialized
DEBUG - 2021-01-06 08:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:48:27 --> Input Class Initialized
INFO - 2021-01-06 08:48:27 --> Language Class Initialized
INFO - 2021-01-06 08:48:27 --> Language Class Initialized
INFO - 2021-01-06 08:48:27 --> Config Class Initialized
INFO - 2021-01-06 08:48:27 --> Loader Class Initialized
INFO - 2021-01-06 08:48:27 --> Helper loaded: url_helper
INFO - 2021-01-06 08:48:27 --> Helper loaded: file_helper
INFO - 2021-01-06 08:48:27 --> Helper loaded: form_helper
INFO - 2021-01-06 08:48:27 --> Helper loaded: my_helper
INFO - 2021-01-06 08:48:27 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:48:27 --> Controller Class Initialized
DEBUG - 2021-01-06 08:48:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:48:27 --> Final output sent to browser
DEBUG - 2021-01-06 08:48:27 --> Total execution time: 0.3273
INFO - 2021-01-06 08:48:55 --> Config Class Initialized
INFO - 2021-01-06 08:48:55 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:48:55 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:48:55 --> Utf8 Class Initialized
INFO - 2021-01-06 08:48:55 --> URI Class Initialized
INFO - 2021-01-06 08:48:55 --> Router Class Initialized
INFO - 2021-01-06 08:48:55 --> Output Class Initialized
INFO - 2021-01-06 08:48:55 --> Security Class Initialized
DEBUG - 2021-01-06 08:48:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:48:55 --> Input Class Initialized
INFO - 2021-01-06 08:48:55 --> Language Class Initialized
INFO - 2021-01-06 08:48:55 --> Language Class Initialized
INFO - 2021-01-06 08:48:55 --> Config Class Initialized
INFO - 2021-01-06 08:48:55 --> Loader Class Initialized
INFO - 2021-01-06 08:48:55 --> Helper loaded: url_helper
INFO - 2021-01-06 08:48:55 --> Helper loaded: file_helper
INFO - 2021-01-06 08:48:55 --> Helper loaded: form_helper
INFO - 2021-01-06 08:48:55 --> Helper loaded: my_helper
INFO - 2021-01-06 08:48:55 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:48:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:48:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:48:55 --> Controller Class Initialized
DEBUG - 2021-01-06 08:48:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:48:55 --> Final output sent to browser
DEBUG - 2021-01-06 08:48:55 --> Total execution time: 0.3666
INFO - 2021-01-06 08:49:12 --> Config Class Initialized
INFO - 2021-01-06 08:49:12 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:49:12 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:49:12 --> Utf8 Class Initialized
INFO - 2021-01-06 08:49:12 --> URI Class Initialized
INFO - 2021-01-06 08:49:12 --> Router Class Initialized
INFO - 2021-01-06 08:49:12 --> Output Class Initialized
INFO - 2021-01-06 08:49:12 --> Security Class Initialized
DEBUG - 2021-01-06 08:49:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:49:12 --> Input Class Initialized
INFO - 2021-01-06 08:49:12 --> Language Class Initialized
INFO - 2021-01-06 08:49:12 --> Language Class Initialized
INFO - 2021-01-06 08:49:12 --> Config Class Initialized
INFO - 2021-01-06 08:49:12 --> Loader Class Initialized
INFO - 2021-01-06 08:49:12 --> Helper loaded: url_helper
INFO - 2021-01-06 08:49:12 --> Helper loaded: file_helper
INFO - 2021-01-06 08:49:12 --> Helper loaded: form_helper
INFO - 2021-01-06 08:49:12 --> Helper loaded: my_helper
INFO - 2021-01-06 08:49:12 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:49:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:49:12 --> Controller Class Initialized
DEBUG - 2021-01-06 08:49:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:49:12 --> Final output sent to browser
DEBUG - 2021-01-06 08:49:12 --> Total execution time: 0.3280
INFO - 2021-01-06 08:49:43 --> Config Class Initialized
INFO - 2021-01-06 08:49:43 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:49:44 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:49:44 --> Utf8 Class Initialized
INFO - 2021-01-06 08:49:44 --> URI Class Initialized
INFO - 2021-01-06 08:49:44 --> Router Class Initialized
INFO - 2021-01-06 08:49:44 --> Output Class Initialized
INFO - 2021-01-06 08:49:44 --> Security Class Initialized
DEBUG - 2021-01-06 08:49:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:49:44 --> Input Class Initialized
INFO - 2021-01-06 08:49:44 --> Language Class Initialized
INFO - 2021-01-06 08:49:44 --> Language Class Initialized
INFO - 2021-01-06 08:49:44 --> Config Class Initialized
INFO - 2021-01-06 08:49:44 --> Loader Class Initialized
INFO - 2021-01-06 08:49:44 --> Helper loaded: url_helper
INFO - 2021-01-06 08:49:44 --> Helper loaded: file_helper
INFO - 2021-01-06 08:49:44 --> Helper loaded: form_helper
INFO - 2021-01-06 08:49:44 --> Helper loaded: my_helper
INFO - 2021-01-06 08:49:44 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:49:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:49:44 --> Controller Class Initialized
DEBUG - 2021-01-06 08:49:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:49:44 --> Final output sent to browser
DEBUG - 2021-01-06 08:49:44 --> Total execution time: 0.3155
INFO - 2021-01-06 08:50:03 --> Config Class Initialized
INFO - 2021-01-06 08:50:04 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:50:04 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:50:04 --> Utf8 Class Initialized
INFO - 2021-01-06 08:50:04 --> URI Class Initialized
INFO - 2021-01-06 08:50:04 --> Router Class Initialized
INFO - 2021-01-06 08:50:04 --> Output Class Initialized
INFO - 2021-01-06 08:50:04 --> Security Class Initialized
DEBUG - 2021-01-06 08:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:50:04 --> Input Class Initialized
INFO - 2021-01-06 08:50:04 --> Language Class Initialized
INFO - 2021-01-06 08:50:04 --> Language Class Initialized
INFO - 2021-01-06 08:50:04 --> Config Class Initialized
INFO - 2021-01-06 08:50:04 --> Loader Class Initialized
INFO - 2021-01-06 08:50:04 --> Helper loaded: url_helper
INFO - 2021-01-06 08:50:04 --> Helper loaded: file_helper
INFO - 2021-01-06 08:50:04 --> Helper loaded: form_helper
INFO - 2021-01-06 08:50:04 --> Helper loaded: my_helper
INFO - 2021-01-06 08:50:04 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:50:04 --> Controller Class Initialized
DEBUG - 2021-01-06 08:50:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:50:04 --> Final output sent to browser
DEBUG - 2021-01-06 08:50:04 --> Total execution time: 0.3560
INFO - 2021-01-06 08:55:44 --> Config Class Initialized
INFO - 2021-01-06 08:55:44 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:55:44 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:55:44 --> Utf8 Class Initialized
INFO - 2021-01-06 08:55:44 --> URI Class Initialized
INFO - 2021-01-06 08:55:44 --> Router Class Initialized
INFO - 2021-01-06 08:55:44 --> Output Class Initialized
INFO - 2021-01-06 08:55:44 --> Security Class Initialized
DEBUG - 2021-01-06 08:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:55:44 --> Input Class Initialized
INFO - 2021-01-06 08:55:44 --> Language Class Initialized
INFO - 2021-01-06 08:55:44 --> Language Class Initialized
INFO - 2021-01-06 08:55:44 --> Config Class Initialized
INFO - 2021-01-06 08:55:44 --> Loader Class Initialized
INFO - 2021-01-06 08:55:44 --> Helper loaded: url_helper
INFO - 2021-01-06 08:55:44 --> Helper loaded: file_helper
INFO - 2021-01-06 08:55:44 --> Helper loaded: form_helper
INFO - 2021-01-06 08:55:44 --> Helper loaded: my_helper
INFO - 2021-01-06 08:55:44 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:55:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:55:44 --> Controller Class Initialized
DEBUG - 2021-01-06 08:55:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:55:44 --> Final output sent to browser
DEBUG - 2021-01-06 08:55:44 --> Total execution time: 0.3346
INFO - 2021-01-06 08:56:08 --> Config Class Initialized
INFO - 2021-01-06 08:56:08 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:56:08 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:56:08 --> Utf8 Class Initialized
INFO - 2021-01-06 08:56:08 --> URI Class Initialized
INFO - 2021-01-06 08:56:08 --> Router Class Initialized
INFO - 2021-01-06 08:56:08 --> Output Class Initialized
INFO - 2021-01-06 08:56:08 --> Security Class Initialized
DEBUG - 2021-01-06 08:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:56:08 --> Input Class Initialized
INFO - 2021-01-06 08:56:08 --> Language Class Initialized
INFO - 2021-01-06 08:56:08 --> Language Class Initialized
INFO - 2021-01-06 08:56:08 --> Config Class Initialized
INFO - 2021-01-06 08:56:08 --> Loader Class Initialized
INFO - 2021-01-06 08:56:08 --> Helper loaded: url_helper
INFO - 2021-01-06 08:56:08 --> Helper loaded: file_helper
INFO - 2021-01-06 08:56:08 --> Helper loaded: form_helper
INFO - 2021-01-06 08:56:08 --> Helper loaded: my_helper
INFO - 2021-01-06 08:56:08 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:56:08 --> Controller Class Initialized
DEBUG - 2021-01-06 08:56:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:56:08 --> Final output sent to browser
DEBUG - 2021-01-06 08:56:08 --> Total execution time: 0.3276
INFO - 2021-01-06 08:56:43 --> Config Class Initialized
INFO - 2021-01-06 08:56:43 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:56:43 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:56:43 --> Utf8 Class Initialized
INFO - 2021-01-06 08:56:43 --> URI Class Initialized
INFO - 2021-01-06 08:56:43 --> Router Class Initialized
INFO - 2021-01-06 08:56:43 --> Output Class Initialized
INFO - 2021-01-06 08:56:43 --> Security Class Initialized
DEBUG - 2021-01-06 08:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:56:43 --> Input Class Initialized
INFO - 2021-01-06 08:56:43 --> Language Class Initialized
ERROR - 2021-01-06 08:56:43 --> Severity: Parsing Error --> syntax error, unexpected ')' C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 169
INFO - 2021-01-06 08:57:04 --> Config Class Initialized
INFO - 2021-01-06 08:57:04 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:04 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:04 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:04 --> URI Class Initialized
INFO - 2021-01-06 08:57:04 --> Router Class Initialized
INFO - 2021-01-06 08:57:04 --> Output Class Initialized
INFO - 2021-01-06 08:57:04 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:04 --> Input Class Initialized
INFO - 2021-01-06 08:57:04 --> Language Class Initialized
INFO - 2021-01-06 08:57:04 --> Language Class Initialized
INFO - 2021-01-06 08:57:04 --> Config Class Initialized
INFO - 2021-01-06 08:57:04 --> Loader Class Initialized
INFO - 2021-01-06 08:57:04 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:04 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:04 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:04 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:04 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:04 --> Controller Class Initialized
DEBUG - 2021-01-06 08:57:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:57:04 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:04 --> Total execution time: 0.3359
INFO - 2021-01-06 08:57:14 --> Config Class Initialized
INFO - 2021-01-06 08:57:14 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:14 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:14 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:14 --> URI Class Initialized
INFO - 2021-01-06 08:57:14 --> Router Class Initialized
INFO - 2021-01-06 08:57:14 --> Output Class Initialized
INFO - 2021-01-06 08:57:14 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:14 --> Input Class Initialized
INFO - 2021-01-06 08:57:14 --> Language Class Initialized
INFO - 2021-01-06 08:57:14 --> Language Class Initialized
INFO - 2021-01-06 08:57:14 --> Config Class Initialized
INFO - 2021-01-06 08:57:14 --> Loader Class Initialized
INFO - 2021-01-06 08:57:14 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:14 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:14 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:14 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:14 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:14 --> Controller Class Initialized
DEBUG - 2021-01-06 08:57:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:57:14 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:14 --> Total execution time: 0.3382
INFO - 2021-01-06 08:57:42 --> Config Class Initialized
INFO - 2021-01-06 08:57:42 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:42 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:42 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:42 --> URI Class Initialized
INFO - 2021-01-06 08:57:42 --> Router Class Initialized
INFO - 2021-01-06 08:57:42 --> Output Class Initialized
INFO - 2021-01-06 08:57:42 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:42 --> Input Class Initialized
INFO - 2021-01-06 08:57:42 --> Language Class Initialized
INFO - 2021-01-06 08:57:42 --> Language Class Initialized
INFO - 2021-01-06 08:57:42 --> Config Class Initialized
INFO - 2021-01-06 08:57:43 --> Loader Class Initialized
INFO - 2021-01-06 08:57:43 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:43 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:43 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:43 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:43 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:43 --> Controller Class Initialized
DEBUG - 2021-01-06 08:57:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-06 08:57:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 08:57:43 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:43 --> Total execution time: 0.3966
INFO - 2021-01-06 08:57:44 --> Config Class Initialized
INFO - 2021-01-06 08:57:44 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:44 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:44 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:44 --> URI Class Initialized
INFO - 2021-01-06 08:57:44 --> Router Class Initialized
INFO - 2021-01-06 08:57:44 --> Output Class Initialized
INFO - 2021-01-06 08:57:44 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:44 --> Input Class Initialized
INFO - 2021-01-06 08:57:44 --> Language Class Initialized
INFO - 2021-01-06 08:57:44 --> Language Class Initialized
INFO - 2021-01-06 08:57:44 --> Config Class Initialized
INFO - 2021-01-06 08:57:44 --> Loader Class Initialized
INFO - 2021-01-06 08:57:44 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:44 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:44 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:44 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:44 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:44 --> Controller Class Initialized
DEBUG - 2021-01-06 08:57:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-06 08:57:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 08:57:44 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:44 --> Total execution time: 0.3464
INFO - 2021-01-06 08:57:46 --> Config Class Initialized
INFO - 2021-01-06 08:57:46 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:46 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:46 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:46 --> URI Class Initialized
INFO - 2021-01-06 08:57:46 --> Router Class Initialized
INFO - 2021-01-06 08:57:46 --> Output Class Initialized
INFO - 2021-01-06 08:57:46 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:46 --> Input Class Initialized
INFO - 2021-01-06 08:57:46 --> Language Class Initialized
INFO - 2021-01-06 08:57:46 --> Language Class Initialized
INFO - 2021-01-06 08:57:46 --> Config Class Initialized
INFO - 2021-01-06 08:57:46 --> Loader Class Initialized
INFO - 2021-01-06 08:57:46 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:46 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:46 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:46 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:46 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:47 --> Controller Class Initialized
INFO - 2021-01-06 08:57:47 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:47 --> Total execution time: 0.3460
INFO - 2021-01-06 08:57:52 --> Config Class Initialized
INFO - 2021-01-06 08:57:52 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:52 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:52 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:52 --> URI Class Initialized
INFO - 2021-01-06 08:57:52 --> Router Class Initialized
INFO - 2021-01-06 08:57:52 --> Output Class Initialized
INFO - 2021-01-06 08:57:52 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:52 --> Input Class Initialized
INFO - 2021-01-06 08:57:52 --> Language Class Initialized
INFO - 2021-01-06 08:57:52 --> Language Class Initialized
INFO - 2021-01-06 08:57:52 --> Config Class Initialized
INFO - 2021-01-06 08:57:52 --> Loader Class Initialized
INFO - 2021-01-06 08:57:52 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:52 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:52 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:52 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:52 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:52 --> Controller Class Initialized
INFO - 2021-01-06 08:57:52 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:52 --> Total execution time: 0.3403
INFO - 2021-01-06 08:57:52 --> Config Class Initialized
INFO - 2021-01-06 08:57:52 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:52 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:52 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:52 --> URI Class Initialized
INFO - 2021-01-06 08:57:52 --> Router Class Initialized
INFO - 2021-01-06 08:57:52 --> Output Class Initialized
INFO - 2021-01-06 08:57:52 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:52 --> Input Class Initialized
INFO - 2021-01-06 08:57:52 --> Language Class Initialized
INFO - 2021-01-06 08:57:52 --> Language Class Initialized
INFO - 2021-01-06 08:57:52 --> Config Class Initialized
INFO - 2021-01-06 08:57:52 --> Loader Class Initialized
INFO - 2021-01-06 08:57:52 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:52 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:52 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:52 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:52 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:52 --> Controller Class Initialized
DEBUG - 2021-01-06 08:57:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-06 08:57:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 08:57:52 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:52 --> Total execution time: 0.4735
INFO - 2021-01-06 08:57:56 --> Config Class Initialized
INFO - 2021-01-06 08:57:56 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:56 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:56 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:56 --> URI Class Initialized
INFO - 2021-01-06 08:57:56 --> Router Class Initialized
INFO - 2021-01-06 08:57:56 --> Output Class Initialized
INFO - 2021-01-06 08:57:56 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:56 --> Input Class Initialized
INFO - 2021-01-06 08:57:56 --> Language Class Initialized
INFO - 2021-01-06 08:57:56 --> Language Class Initialized
INFO - 2021-01-06 08:57:56 --> Config Class Initialized
INFO - 2021-01-06 08:57:56 --> Loader Class Initialized
INFO - 2021-01-06 08:57:56 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:56 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:56 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:56 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:56 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:56 --> Controller Class Initialized
INFO - 2021-01-06 08:57:56 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:56 --> Total execution time: 0.3391
INFO - 2021-01-06 08:57:58 --> Config Class Initialized
INFO - 2021-01-06 08:57:58 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:58 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:58 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:58 --> URI Class Initialized
INFO - 2021-01-06 08:57:58 --> Router Class Initialized
INFO - 2021-01-06 08:57:58 --> Output Class Initialized
INFO - 2021-01-06 08:57:58 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:58 --> Input Class Initialized
INFO - 2021-01-06 08:57:58 --> Language Class Initialized
INFO - 2021-01-06 08:57:58 --> Language Class Initialized
INFO - 2021-01-06 08:57:58 --> Config Class Initialized
INFO - 2021-01-06 08:57:58 --> Loader Class Initialized
INFO - 2021-01-06 08:57:58 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:58 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:58 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:58 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:58 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:58 --> Controller Class Initialized
INFO - 2021-01-06 08:57:58 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:58 --> Total execution time: 0.3384
INFO - 2021-01-06 08:57:58 --> Config Class Initialized
INFO - 2021-01-06 08:57:58 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:57:58 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:57:58 --> Utf8 Class Initialized
INFO - 2021-01-06 08:57:58 --> URI Class Initialized
INFO - 2021-01-06 08:57:58 --> Router Class Initialized
INFO - 2021-01-06 08:57:58 --> Output Class Initialized
INFO - 2021-01-06 08:57:58 --> Security Class Initialized
DEBUG - 2021-01-06 08:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:57:58 --> Input Class Initialized
INFO - 2021-01-06 08:57:58 --> Language Class Initialized
INFO - 2021-01-06 08:57:58 --> Language Class Initialized
INFO - 2021-01-06 08:57:58 --> Config Class Initialized
INFO - 2021-01-06 08:57:58 --> Loader Class Initialized
INFO - 2021-01-06 08:57:58 --> Helper loaded: url_helper
INFO - 2021-01-06 08:57:58 --> Helper loaded: file_helper
INFO - 2021-01-06 08:57:58 --> Helper loaded: form_helper
INFO - 2021-01-06 08:57:58 --> Helper loaded: my_helper
INFO - 2021-01-06 08:57:58 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:57:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:57:58 --> Controller Class Initialized
DEBUG - 2021-01-06 08:57:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-06 08:57:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-06 08:57:59 --> Final output sent to browser
DEBUG - 2021-01-06 08:57:59 --> Total execution time: 0.4780
INFO - 2021-01-06 08:58:00 --> Config Class Initialized
INFO - 2021-01-06 08:58:00 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:58:00 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:58:00 --> Utf8 Class Initialized
INFO - 2021-01-06 08:58:00 --> URI Class Initialized
INFO - 2021-01-06 08:58:00 --> Router Class Initialized
INFO - 2021-01-06 08:58:00 --> Output Class Initialized
INFO - 2021-01-06 08:58:00 --> Security Class Initialized
DEBUG - 2021-01-06 08:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:58:00 --> Input Class Initialized
INFO - 2021-01-06 08:58:00 --> Language Class Initialized
INFO - 2021-01-06 08:58:00 --> Language Class Initialized
INFO - 2021-01-06 08:58:00 --> Config Class Initialized
INFO - 2021-01-06 08:58:00 --> Loader Class Initialized
INFO - 2021-01-06 08:58:00 --> Helper loaded: url_helper
INFO - 2021-01-06 08:58:00 --> Helper loaded: file_helper
INFO - 2021-01-06 08:58:00 --> Helper loaded: form_helper
INFO - 2021-01-06 08:58:00 --> Helper loaded: my_helper
INFO - 2021-01-06 08:58:00 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:58:00 --> Controller Class Initialized
INFO - 2021-01-06 08:58:00 --> Final output sent to browser
DEBUG - 2021-01-06 08:58:00 --> Total execution time: 0.3067
INFO - 2021-01-06 08:58:05 --> Config Class Initialized
INFO - 2021-01-06 08:58:05 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:58:05 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:58:05 --> Utf8 Class Initialized
INFO - 2021-01-06 08:58:05 --> URI Class Initialized
INFO - 2021-01-06 08:58:05 --> Router Class Initialized
INFO - 2021-01-06 08:58:05 --> Output Class Initialized
INFO - 2021-01-06 08:58:05 --> Security Class Initialized
DEBUG - 2021-01-06 08:58:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:58:06 --> Input Class Initialized
INFO - 2021-01-06 08:58:06 --> Language Class Initialized
INFO - 2021-01-06 08:58:06 --> Language Class Initialized
INFO - 2021-01-06 08:58:06 --> Config Class Initialized
INFO - 2021-01-06 08:58:06 --> Loader Class Initialized
INFO - 2021-01-06 08:58:06 --> Helper loaded: url_helper
INFO - 2021-01-06 08:58:06 --> Helper loaded: file_helper
INFO - 2021-01-06 08:58:06 --> Helper loaded: form_helper
INFO - 2021-01-06 08:58:06 --> Helper loaded: my_helper
INFO - 2021-01-06 08:58:06 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:58:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:58:06 --> Controller Class Initialized
INFO - 2021-01-06 08:58:06 --> Final output sent to browser
DEBUG - 2021-01-06 08:58:06 --> Total execution time: 0.4027
INFO - 2021-01-06 08:58:09 --> Config Class Initialized
INFO - 2021-01-06 08:58:09 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:58:09 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:58:09 --> Utf8 Class Initialized
INFO - 2021-01-06 08:58:09 --> URI Class Initialized
INFO - 2021-01-06 08:58:09 --> Router Class Initialized
INFO - 2021-01-06 08:58:09 --> Output Class Initialized
INFO - 2021-01-06 08:58:09 --> Security Class Initialized
DEBUG - 2021-01-06 08:58:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:58:09 --> Input Class Initialized
INFO - 2021-01-06 08:58:09 --> Language Class Initialized
INFO - 2021-01-06 08:58:09 --> Language Class Initialized
INFO - 2021-01-06 08:58:09 --> Config Class Initialized
INFO - 2021-01-06 08:58:09 --> Loader Class Initialized
INFO - 2021-01-06 08:58:09 --> Helper loaded: url_helper
INFO - 2021-01-06 08:58:09 --> Helper loaded: file_helper
INFO - 2021-01-06 08:58:09 --> Helper loaded: form_helper
INFO - 2021-01-06 08:58:09 --> Helper loaded: my_helper
INFO - 2021-01-06 08:58:09 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:58:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:58:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:58:09 --> Controller Class Initialized
DEBUG - 2021-01-06 08:58:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-06 08:58:09 --> Final output sent to browser
DEBUG - 2021-01-06 08:58:09 --> Total execution time: 0.3229
INFO - 2021-01-06 08:58:13 --> Config Class Initialized
INFO - 2021-01-06 08:58:13 --> Hooks Class Initialized
DEBUG - 2021-01-06 08:58:13 --> UTF-8 Support Enabled
INFO - 2021-01-06 08:58:13 --> Utf8 Class Initialized
INFO - 2021-01-06 08:58:13 --> URI Class Initialized
INFO - 2021-01-06 08:58:13 --> Router Class Initialized
INFO - 2021-01-06 08:58:13 --> Output Class Initialized
INFO - 2021-01-06 08:58:13 --> Security Class Initialized
DEBUG - 2021-01-06 08:58:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 08:58:13 --> Input Class Initialized
INFO - 2021-01-06 08:58:14 --> Language Class Initialized
INFO - 2021-01-06 08:58:14 --> Language Class Initialized
INFO - 2021-01-06 08:58:14 --> Config Class Initialized
INFO - 2021-01-06 08:58:14 --> Loader Class Initialized
INFO - 2021-01-06 08:58:14 --> Helper loaded: url_helper
INFO - 2021-01-06 08:58:14 --> Helper loaded: file_helper
INFO - 2021-01-06 08:58:14 --> Helper loaded: form_helper
INFO - 2021-01-06 08:58:14 --> Helper loaded: my_helper
INFO - 2021-01-06 08:58:14 --> Database Driver Class Initialized
DEBUG - 2021-01-06 08:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 08:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 08:58:14 --> Controller Class Initialized
DEBUG - 2021-01-06 08:58:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 08:58:14 --> Final output sent to browser
DEBUG - 2021-01-06 08:58:14 --> Total execution time: 0.3315
INFO - 2021-01-06 09:33:12 --> Config Class Initialized
INFO - 2021-01-06 09:33:12 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:33:12 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:33:12 --> Utf8 Class Initialized
INFO - 2021-01-06 09:33:12 --> URI Class Initialized
INFO - 2021-01-06 09:33:12 --> Router Class Initialized
INFO - 2021-01-06 09:33:12 --> Output Class Initialized
INFO - 2021-01-06 09:33:12 --> Security Class Initialized
DEBUG - 2021-01-06 09:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:33:12 --> Input Class Initialized
INFO - 2021-01-06 09:33:12 --> Language Class Initialized
INFO - 2021-01-06 09:33:12 --> Language Class Initialized
INFO - 2021-01-06 09:33:12 --> Config Class Initialized
INFO - 2021-01-06 09:33:12 --> Loader Class Initialized
INFO - 2021-01-06 09:33:12 --> Helper loaded: url_helper
INFO - 2021-01-06 09:33:12 --> Helper loaded: file_helper
INFO - 2021-01-06 09:33:12 --> Helper loaded: form_helper
INFO - 2021-01-06 09:33:12 --> Helper loaded: my_helper
INFO - 2021-01-06 09:33:12 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:33:12 --> Controller Class Initialized
DEBUG - 2021-01-06 09:33:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 09:33:12 --> Final output sent to browser
DEBUG - 2021-01-06 09:33:12 --> Total execution time: 0.3228
INFO - 2021-01-06 09:33:13 --> Config Class Initialized
INFO - 2021-01-06 09:33:14 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:33:14 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:33:14 --> Utf8 Class Initialized
INFO - 2021-01-06 09:33:14 --> URI Class Initialized
INFO - 2021-01-06 09:33:14 --> Router Class Initialized
INFO - 2021-01-06 09:33:14 --> Output Class Initialized
INFO - 2021-01-06 09:33:14 --> Security Class Initialized
DEBUG - 2021-01-06 09:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:33:14 --> Input Class Initialized
INFO - 2021-01-06 09:33:14 --> Language Class Initialized
INFO - 2021-01-06 09:33:14 --> Language Class Initialized
INFO - 2021-01-06 09:33:14 --> Config Class Initialized
INFO - 2021-01-06 09:33:14 --> Loader Class Initialized
INFO - 2021-01-06 09:33:14 --> Helper loaded: url_helper
INFO - 2021-01-06 09:33:14 --> Helper loaded: file_helper
INFO - 2021-01-06 09:33:14 --> Helper loaded: form_helper
INFO - 2021-01-06 09:33:14 --> Helper loaded: my_helper
INFO - 2021-01-06 09:33:14 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:33:14 --> Controller Class Initialized
DEBUG - 2021-01-06 09:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 09:33:14 --> Final output sent to browser
DEBUG - 2021-01-06 09:33:14 --> Total execution time: 0.3471
INFO - 2021-01-06 09:35:05 --> Config Class Initialized
INFO - 2021-01-06 09:35:05 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:35:05 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:35:05 --> Utf8 Class Initialized
INFO - 2021-01-06 09:35:05 --> URI Class Initialized
INFO - 2021-01-06 09:35:05 --> Router Class Initialized
INFO - 2021-01-06 09:35:05 --> Output Class Initialized
INFO - 2021-01-06 09:35:05 --> Security Class Initialized
DEBUG - 2021-01-06 09:35:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:35:05 --> Input Class Initialized
INFO - 2021-01-06 09:35:05 --> Language Class Initialized
INFO - 2021-01-06 09:35:05 --> Language Class Initialized
INFO - 2021-01-06 09:35:05 --> Config Class Initialized
INFO - 2021-01-06 09:35:05 --> Loader Class Initialized
INFO - 2021-01-06 09:35:05 --> Helper loaded: url_helper
INFO - 2021-01-06 09:35:05 --> Helper loaded: file_helper
INFO - 2021-01-06 09:35:05 --> Helper loaded: form_helper
INFO - 2021-01-06 09:35:05 --> Helper loaded: my_helper
INFO - 2021-01-06 09:35:05 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:35:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:35:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:35:05 --> Controller Class Initialized
DEBUG - 2021-01-06 09:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-06 09:35:05 --> Final output sent to browser
DEBUG - 2021-01-06 09:35:05 --> Total execution time: 0.3142
INFO - 2021-01-06 09:35:07 --> Config Class Initialized
INFO - 2021-01-06 09:35:07 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:35:07 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:35:07 --> Utf8 Class Initialized
INFO - 2021-01-06 09:35:07 --> URI Class Initialized
INFO - 2021-01-06 09:35:07 --> Router Class Initialized
INFO - 2021-01-06 09:35:07 --> Output Class Initialized
INFO - 2021-01-06 09:35:07 --> Security Class Initialized
DEBUG - 2021-01-06 09:35:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:35:07 --> Input Class Initialized
INFO - 2021-01-06 09:35:07 --> Language Class Initialized
INFO - 2021-01-06 09:35:07 --> Language Class Initialized
INFO - 2021-01-06 09:35:07 --> Config Class Initialized
INFO - 2021-01-06 09:35:07 --> Loader Class Initialized
INFO - 2021-01-06 09:35:07 --> Helper loaded: url_helper
INFO - 2021-01-06 09:35:07 --> Helper loaded: file_helper
INFO - 2021-01-06 09:35:07 --> Helper loaded: form_helper
INFO - 2021-01-06 09:35:07 --> Helper loaded: my_helper
INFO - 2021-01-06 09:35:07 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:35:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:35:07 --> Controller Class Initialized
DEBUG - 2021-01-06 09:35:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 09:35:07 --> Final output sent to browser
DEBUG - 2021-01-06 09:35:07 --> Total execution time: 0.4010
INFO - 2021-01-06 09:35:26 --> Config Class Initialized
INFO - 2021-01-06 09:35:26 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:35:26 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:35:26 --> Utf8 Class Initialized
INFO - 2021-01-06 09:35:26 --> URI Class Initialized
INFO - 2021-01-06 09:35:26 --> Router Class Initialized
INFO - 2021-01-06 09:35:26 --> Output Class Initialized
INFO - 2021-01-06 09:35:26 --> Security Class Initialized
DEBUG - 2021-01-06 09:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:35:26 --> Input Class Initialized
INFO - 2021-01-06 09:35:26 --> Language Class Initialized
INFO - 2021-01-06 09:35:26 --> Language Class Initialized
INFO - 2021-01-06 09:35:26 --> Config Class Initialized
INFO - 2021-01-06 09:35:26 --> Loader Class Initialized
INFO - 2021-01-06 09:35:26 --> Helper loaded: url_helper
INFO - 2021-01-06 09:35:26 --> Helper loaded: file_helper
INFO - 2021-01-06 09:35:26 --> Helper loaded: form_helper
INFO - 2021-01-06 09:35:26 --> Helper loaded: my_helper
INFO - 2021-01-06 09:35:26 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:35:26 --> Controller Class Initialized
DEBUG - 2021-01-06 09:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 09:35:26 --> Final output sent to browser
DEBUG - 2021-01-06 09:35:26 --> Total execution time: 0.3034
INFO - 2021-01-06 09:35:35 --> Config Class Initialized
INFO - 2021-01-06 09:35:35 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:35:35 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:35:35 --> Utf8 Class Initialized
INFO - 2021-01-06 09:35:35 --> URI Class Initialized
INFO - 2021-01-06 09:35:35 --> Router Class Initialized
INFO - 2021-01-06 09:35:35 --> Output Class Initialized
INFO - 2021-01-06 09:35:35 --> Security Class Initialized
DEBUG - 2021-01-06 09:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:35:35 --> Input Class Initialized
INFO - 2021-01-06 09:35:35 --> Language Class Initialized
INFO - 2021-01-06 09:35:36 --> Language Class Initialized
INFO - 2021-01-06 09:35:36 --> Config Class Initialized
INFO - 2021-01-06 09:35:36 --> Loader Class Initialized
INFO - 2021-01-06 09:35:36 --> Helper loaded: url_helper
INFO - 2021-01-06 09:35:36 --> Helper loaded: file_helper
INFO - 2021-01-06 09:35:36 --> Helper loaded: form_helper
INFO - 2021-01-06 09:35:36 --> Helper loaded: my_helper
INFO - 2021-01-06 09:35:36 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:35:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:35:36 --> Controller Class Initialized
DEBUG - 2021-01-06 09:35:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-06 09:35:36 --> Final output sent to browser
DEBUG - 2021-01-06 09:35:36 --> Total execution time: 0.3215
INFO - 2021-01-06 09:35:38 --> Config Class Initialized
INFO - 2021-01-06 09:35:38 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:35:38 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:35:38 --> Utf8 Class Initialized
INFO - 2021-01-06 09:35:38 --> URI Class Initialized
INFO - 2021-01-06 09:35:38 --> Router Class Initialized
INFO - 2021-01-06 09:35:38 --> Output Class Initialized
INFO - 2021-01-06 09:35:38 --> Security Class Initialized
DEBUG - 2021-01-06 09:35:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:35:38 --> Input Class Initialized
INFO - 2021-01-06 09:35:38 --> Language Class Initialized
INFO - 2021-01-06 09:35:38 --> Language Class Initialized
INFO - 2021-01-06 09:35:38 --> Config Class Initialized
INFO - 2021-01-06 09:35:38 --> Loader Class Initialized
INFO - 2021-01-06 09:35:38 --> Helper loaded: url_helper
INFO - 2021-01-06 09:35:38 --> Helper loaded: file_helper
INFO - 2021-01-06 09:35:38 --> Helper loaded: form_helper
INFO - 2021-01-06 09:35:38 --> Helper loaded: my_helper
INFO - 2021-01-06 09:35:38 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:35:39 --> Controller Class Initialized
DEBUG - 2021-01-06 09:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 09:35:39 --> Final output sent to browser
DEBUG - 2021-01-06 09:35:39 --> Total execution time: 0.3167
INFO - 2021-01-06 09:52:06 --> Config Class Initialized
INFO - 2021-01-06 09:52:06 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:52:06 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:52:06 --> Utf8 Class Initialized
INFO - 2021-01-06 09:52:06 --> URI Class Initialized
INFO - 2021-01-06 09:52:06 --> Router Class Initialized
INFO - 2021-01-06 09:52:06 --> Output Class Initialized
INFO - 2021-01-06 09:52:07 --> Security Class Initialized
DEBUG - 2021-01-06 09:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:52:07 --> Input Class Initialized
INFO - 2021-01-06 09:52:07 --> Language Class Initialized
INFO - 2021-01-06 09:52:07 --> Language Class Initialized
INFO - 2021-01-06 09:52:07 --> Config Class Initialized
INFO - 2021-01-06 09:52:07 --> Loader Class Initialized
INFO - 2021-01-06 09:52:07 --> Helper loaded: url_helper
INFO - 2021-01-06 09:52:07 --> Helper loaded: file_helper
INFO - 2021-01-06 09:52:07 --> Helper loaded: form_helper
INFO - 2021-01-06 09:52:07 --> Helper loaded: my_helper
INFO - 2021-01-06 09:52:07 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:52:07 --> Controller Class Initialized
ERROR - 2021-01-06 09:52:07 --> Severity: Notice --> Undefined index: prog_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 57
ERROR - 2021-01-06 09:52:07 --> Severity: Notice --> Undefined index: komp_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 62
ERROR - 2021-01-06 09:52:07 --> Severity: Notice --> Undefined index: prog_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 117
ERROR - 2021-01-06 09:52:07 --> Severity: Notice --> Undefined index: komp_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 122
ERROR - 2021-01-06 09:52:07 --> Severity: Notice --> Undefined index: prog_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 278
ERROR - 2021-01-06 09:52:07 --> Severity: Notice --> Undefined index: komp_keahlian C:\xampp\htdocs\nilai\application\modules\cetak_raport\views\cetak_rapot.php 283
DEBUG - 2021-01-06 09:52:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 09:52:07 --> Final output sent to browser
DEBUG - 2021-01-06 09:52:07 --> Total execution time: 0.4049
INFO - 2021-01-06 09:52:15 --> Config Class Initialized
INFO - 2021-01-06 09:52:15 --> Hooks Class Initialized
DEBUG - 2021-01-06 09:52:15 --> UTF-8 Support Enabled
INFO - 2021-01-06 09:52:15 --> Utf8 Class Initialized
INFO - 2021-01-06 09:52:15 --> URI Class Initialized
INFO - 2021-01-06 09:52:15 --> Router Class Initialized
INFO - 2021-01-06 09:52:15 --> Output Class Initialized
INFO - 2021-01-06 09:52:15 --> Security Class Initialized
DEBUG - 2021-01-06 09:52:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-06 09:52:15 --> Input Class Initialized
INFO - 2021-01-06 09:52:15 --> Language Class Initialized
INFO - 2021-01-06 09:52:15 --> Language Class Initialized
INFO - 2021-01-06 09:52:15 --> Config Class Initialized
INFO - 2021-01-06 09:52:15 --> Loader Class Initialized
INFO - 2021-01-06 09:52:15 --> Helper loaded: url_helper
INFO - 2021-01-06 09:52:15 --> Helper loaded: file_helper
INFO - 2021-01-06 09:52:15 --> Helper loaded: form_helper
INFO - 2021-01-06 09:52:15 --> Helper loaded: my_helper
INFO - 2021-01-06 09:52:15 --> Database Driver Class Initialized
DEBUG - 2021-01-06 09:52:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-06 09:52:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-06 09:52:15 --> Controller Class Initialized
DEBUG - 2021-01-06 09:52:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-06 09:52:16 --> Final output sent to browser
DEBUG - 2021-01-06 09:52:16 --> Total execution time: 0.3567
