<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-12-23 07:40:38 --> Config Class Initialized
INFO - 2021-12-23 07:40:38 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:40:38 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:40:38 --> Utf8 Class Initialized
INFO - 2021-12-23 07:40:38 --> URI Class Initialized
INFO - 2021-12-23 07:40:38 --> Router Class Initialized
INFO - 2021-12-23 07:40:38 --> Output Class Initialized
INFO - 2021-12-23 07:40:38 --> Security Class Initialized
DEBUG - 2021-12-23 07:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:40:38 --> Input Class Initialized
INFO - 2021-12-23 07:40:38 --> Language Class Initialized
INFO - 2021-12-23 07:40:38 --> Language Class Initialized
INFO - 2021-12-23 07:40:38 --> Config Class Initialized
INFO - 2021-12-23 07:40:38 --> Loader Class Initialized
INFO - 2021-12-23 07:40:38 --> Helper loaded: url_helper
INFO - 2021-12-23 07:40:38 --> Helper loaded: file_helper
INFO - 2021-12-23 07:40:38 --> Helper loaded: form_helper
INFO - 2021-12-23 07:40:38 --> Helper loaded: my_helper
INFO - 2021-12-23 07:40:38 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:40:38 --> Controller Class Initialized
DEBUG - 2021-12-23 07:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 07:40:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 07:40:38 --> Final output sent to browser
DEBUG - 2021-12-23 07:40:38 --> Total execution time: 0.6344
INFO - 2021-12-23 07:40:50 --> Config Class Initialized
INFO - 2021-12-23 07:40:50 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:40:50 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:40:50 --> Utf8 Class Initialized
INFO - 2021-12-23 07:40:50 --> URI Class Initialized
INFO - 2021-12-23 07:40:50 --> Router Class Initialized
INFO - 2021-12-23 07:40:50 --> Output Class Initialized
INFO - 2021-12-23 07:40:50 --> Security Class Initialized
DEBUG - 2021-12-23 07:40:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:40:50 --> Input Class Initialized
INFO - 2021-12-23 07:40:50 --> Language Class Initialized
INFO - 2021-12-23 07:40:50 --> Language Class Initialized
INFO - 2021-12-23 07:40:50 --> Config Class Initialized
INFO - 2021-12-23 07:40:50 --> Loader Class Initialized
INFO - 2021-12-23 07:40:50 --> Helper loaded: url_helper
INFO - 2021-12-23 07:40:50 --> Helper loaded: file_helper
INFO - 2021-12-23 07:40:50 --> Helper loaded: form_helper
INFO - 2021-12-23 07:40:50 --> Helper loaded: my_helper
INFO - 2021-12-23 07:40:50 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:40:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:40:50 --> Controller Class Initialized
INFO - 2021-12-23 07:40:50 --> Final output sent to browser
DEBUG - 2021-12-23 07:40:50 --> Total execution time: 0.0543
INFO - 2021-12-23 07:41:16 --> Config Class Initialized
INFO - 2021-12-23 07:41:16 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:41:16 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:41:16 --> Utf8 Class Initialized
INFO - 2021-12-23 07:41:16 --> URI Class Initialized
INFO - 2021-12-23 07:41:16 --> Router Class Initialized
INFO - 2021-12-23 07:41:16 --> Output Class Initialized
INFO - 2021-12-23 07:41:16 --> Security Class Initialized
DEBUG - 2021-12-23 07:41:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:41:16 --> Input Class Initialized
INFO - 2021-12-23 07:41:16 --> Language Class Initialized
INFO - 2021-12-23 07:41:16 --> Language Class Initialized
INFO - 2021-12-23 07:41:16 --> Config Class Initialized
INFO - 2021-12-23 07:41:16 --> Loader Class Initialized
INFO - 2021-12-23 07:41:16 --> Helper loaded: url_helper
INFO - 2021-12-23 07:41:16 --> Helper loaded: file_helper
INFO - 2021-12-23 07:41:16 --> Helper loaded: form_helper
INFO - 2021-12-23 07:41:16 --> Helper loaded: my_helper
INFO - 2021-12-23 07:41:16 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:41:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:41:16 --> Controller Class Initialized
INFO - 2021-12-23 07:41:16 --> Final output sent to browser
DEBUG - 2021-12-23 07:41:16 --> Total execution time: 0.0380
INFO - 2021-12-23 07:41:57 --> Config Class Initialized
INFO - 2021-12-23 07:41:57 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:41:57 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:41:57 --> Utf8 Class Initialized
INFO - 2021-12-23 07:41:57 --> URI Class Initialized
INFO - 2021-12-23 07:41:57 --> Router Class Initialized
INFO - 2021-12-23 07:41:57 --> Output Class Initialized
INFO - 2021-12-23 07:41:57 --> Security Class Initialized
DEBUG - 2021-12-23 07:41:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:41:57 --> Input Class Initialized
INFO - 2021-12-23 07:41:57 --> Language Class Initialized
INFO - 2021-12-23 07:41:57 --> Language Class Initialized
INFO - 2021-12-23 07:41:57 --> Config Class Initialized
INFO - 2021-12-23 07:41:57 --> Loader Class Initialized
INFO - 2021-12-23 07:41:57 --> Helper loaded: url_helper
INFO - 2021-12-23 07:41:57 --> Helper loaded: file_helper
INFO - 2021-12-23 07:41:57 --> Helper loaded: form_helper
INFO - 2021-12-23 07:41:57 --> Helper loaded: my_helper
INFO - 2021-12-23 07:41:57 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:41:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:41:57 --> Controller Class Initialized
INFO - 2021-12-23 07:41:57 --> Final output sent to browser
DEBUG - 2021-12-23 07:41:57 --> Total execution time: 0.0473
INFO - 2021-12-23 07:42:41 --> Config Class Initialized
INFO - 2021-12-23 07:42:41 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:42:41 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:42:41 --> Utf8 Class Initialized
INFO - 2021-12-23 07:42:41 --> URI Class Initialized
INFO - 2021-12-23 07:42:41 --> Router Class Initialized
INFO - 2021-12-23 07:42:41 --> Output Class Initialized
INFO - 2021-12-23 07:42:41 --> Security Class Initialized
DEBUG - 2021-12-23 07:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:42:41 --> Input Class Initialized
INFO - 2021-12-23 07:42:41 --> Language Class Initialized
INFO - 2021-12-23 07:42:41 --> Language Class Initialized
INFO - 2021-12-23 07:42:41 --> Config Class Initialized
INFO - 2021-12-23 07:42:41 --> Loader Class Initialized
INFO - 2021-12-23 07:42:41 --> Helper loaded: url_helper
INFO - 2021-12-23 07:42:41 --> Helper loaded: file_helper
INFO - 2021-12-23 07:42:41 --> Helper loaded: form_helper
INFO - 2021-12-23 07:42:41 --> Helper loaded: my_helper
INFO - 2021-12-23 07:42:41 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:42:41 --> Controller Class Initialized
INFO - 2021-12-23 07:42:41 --> Final output sent to browser
DEBUG - 2021-12-23 07:42:41 --> Total execution time: 0.0462
INFO - 2021-12-23 07:42:53 --> Config Class Initialized
INFO - 2021-12-23 07:42:53 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:42:53 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:42:53 --> Utf8 Class Initialized
INFO - 2021-12-23 07:42:53 --> URI Class Initialized
INFO - 2021-12-23 07:42:53 --> Router Class Initialized
INFO - 2021-12-23 07:42:53 --> Output Class Initialized
INFO - 2021-12-23 07:42:53 --> Security Class Initialized
DEBUG - 2021-12-23 07:42:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:42:53 --> Input Class Initialized
INFO - 2021-12-23 07:42:53 --> Language Class Initialized
INFO - 2021-12-23 07:42:53 --> Language Class Initialized
INFO - 2021-12-23 07:42:53 --> Config Class Initialized
INFO - 2021-12-23 07:42:53 --> Loader Class Initialized
INFO - 2021-12-23 07:42:53 --> Helper loaded: url_helper
INFO - 2021-12-23 07:42:53 --> Helper loaded: file_helper
INFO - 2021-12-23 07:42:53 --> Helper loaded: form_helper
INFO - 2021-12-23 07:42:53 --> Helper loaded: my_helper
INFO - 2021-12-23 07:42:53 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:42:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:42:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:42:53 --> Controller Class Initialized
INFO - 2021-12-23 07:42:53 --> Final output sent to browser
DEBUG - 2021-12-23 07:42:53 --> Total execution time: 0.0461
INFO - 2021-12-23 07:43:57 --> Config Class Initialized
INFO - 2021-12-23 07:43:57 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:43:57 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:43:57 --> Utf8 Class Initialized
INFO - 2021-12-23 07:43:57 --> URI Class Initialized
INFO - 2021-12-23 07:43:57 --> Router Class Initialized
INFO - 2021-12-23 07:43:57 --> Output Class Initialized
INFO - 2021-12-23 07:43:57 --> Security Class Initialized
DEBUG - 2021-12-23 07:43:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:43:57 --> Input Class Initialized
INFO - 2021-12-23 07:43:57 --> Language Class Initialized
INFO - 2021-12-23 07:43:57 --> Language Class Initialized
INFO - 2021-12-23 07:43:57 --> Config Class Initialized
INFO - 2021-12-23 07:43:57 --> Loader Class Initialized
INFO - 2021-12-23 07:43:57 --> Helper loaded: url_helper
INFO - 2021-12-23 07:43:57 --> Helper loaded: file_helper
INFO - 2021-12-23 07:43:57 --> Helper loaded: form_helper
INFO - 2021-12-23 07:43:57 --> Helper loaded: my_helper
INFO - 2021-12-23 07:43:57 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:43:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:43:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:43:57 --> Controller Class Initialized
INFO - 2021-12-23 07:43:57 --> Final output sent to browser
DEBUG - 2021-12-23 07:43:57 --> Total execution time: 0.0378
INFO - 2021-12-23 07:44:11 --> Config Class Initialized
INFO - 2021-12-23 07:44:11 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:44:11 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:44:11 --> Utf8 Class Initialized
INFO - 2021-12-23 07:44:11 --> URI Class Initialized
INFO - 2021-12-23 07:44:11 --> Router Class Initialized
INFO - 2021-12-23 07:44:11 --> Output Class Initialized
INFO - 2021-12-23 07:44:11 --> Security Class Initialized
DEBUG - 2021-12-23 07:44:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:44:11 --> Input Class Initialized
INFO - 2021-12-23 07:44:11 --> Language Class Initialized
INFO - 2021-12-23 07:44:11 --> Language Class Initialized
INFO - 2021-12-23 07:44:11 --> Config Class Initialized
INFO - 2021-12-23 07:44:11 --> Loader Class Initialized
INFO - 2021-12-23 07:44:11 --> Helper loaded: url_helper
INFO - 2021-12-23 07:44:11 --> Helper loaded: file_helper
INFO - 2021-12-23 07:44:11 --> Helper loaded: form_helper
INFO - 2021-12-23 07:44:11 --> Helper loaded: my_helper
INFO - 2021-12-23 07:44:11 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:44:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:44:11 --> Controller Class Initialized
INFO - 2021-12-23 07:44:11 --> Final output sent to browser
DEBUG - 2021-12-23 07:44:11 --> Total execution time: 0.0478
INFO - 2021-12-23 07:44:17 --> Config Class Initialized
INFO - 2021-12-23 07:44:17 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:44:17 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:44:17 --> Utf8 Class Initialized
INFO - 2021-12-23 07:44:17 --> URI Class Initialized
INFO - 2021-12-23 07:44:17 --> Router Class Initialized
INFO - 2021-12-23 07:44:17 --> Output Class Initialized
INFO - 2021-12-23 07:44:17 --> Security Class Initialized
DEBUG - 2021-12-23 07:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:44:17 --> Input Class Initialized
INFO - 2021-12-23 07:44:17 --> Language Class Initialized
INFO - 2021-12-23 07:44:17 --> Language Class Initialized
INFO - 2021-12-23 07:44:17 --> Config Class Initialized
INFO - 2021-12-23 07:44:17 --> Loader Class Initialized
INFO - 2021-12-23 07:44:17 --> Helper loaded: url_helper
INFO - 2021-12-23 07:44:17 --> Helper loaded: file_helper
INFO - 2021-12-23 07:44:17 --> Helper loaded: form_helper
INFO - 2021-12-23 07:44:17 --> Helper loaded: my_helper
INFO - 2021-12-23 07:44:17 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:44:17 --> Controller Class Initialized
INFO - 2021-12-23 07:44:17 --> Final output sent to browser
DEBUG - 2021-12-23 07:44:17 --> Total execution time: 0.0359
INFO - 2021-12-23 07:44:40 --> Config Class Initialized
INFO - 2021-12-23 07:44:40 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:44:40 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:44:40 --> Utf8 Class Initialized
INFO - 2021-12-23 07:44:40 --> URI Class Initialized
INFO - 2021-12-23 07:44:40 --> Router Class Initialized
INFO - 2021-12-23 07:44:40 --> Output Class Initialized
INFO - 2021-12-23 07:44:40 --> Security Class Initialized
DEBUG - 2021-12-23 07:44:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:44:40 --> Input Class Initialized
INFO - 2021-12-23 07:44:40 --> Language Class Initialized
INFO - 2021-12-23 07:44:40 --> Language Class Initialized
INFO - 2021-12-23 07:44:40 --> Config Class Initialized
INFO - 2021-12-23 07:44:40 --> Loader Class Initialized
INFO - 2021-12-23 07:44:40 --> Helper loaded: url_helper
INFO - 2021-12-23 07:44:40 --> Helper loaded: file_helper
INFO - 2021-12-23 07:44:40 --> Helper loaded: form_helper
INFO - 2021-12-23 07:44:40 --> Helper loaded: my_helper
INFO - 2021-12-23 07:44:40 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:44:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:44:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:44:40 --> Controller Class Initialized
INFO - 2021-12-23 07:44:40 --> Final output sent to browser
DEBUG - 2021-12-23 07:44:40 --> Total execution time: 0.0463
INFO - 2021-12-23 07:45:08 --> Config Class Initialized
INFO - 2021-12-23 07:45:08 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:45:08 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:45:08 --> Utf8 Class Initialized
INFO - 2021-12-23 07:45:08 --> URI Class Initialized
INFO - 2021-12-23 07:45:08 --> Router Class Initialized
INFO - 2021-12-23 07:45:08 --> Output Class Initialized
INFO - 2021-12-23 07:45:08 --> Security Class Initialized
DEBUG - 2021-12-23 07:45:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:45:08 --> Input Class Initialized
INFO - 2021-12-23 07:45:08 --> Language Class Initialized
INFO - 2021-12-23 07:45:08 --> Language Class Initialized
INFO - 2021-12-23 07:45:08 --> Config Class Initialized
INFO - 2021-12-23 07:45:08 --> Loader Class Initialized
INFO - 2021-12-23 07:45:08 --> Helper loaded: url_helper
INFO - 2021-12-23 07:45:08 --> Helper loaded: file_helper
INFO - 2021-12-23 07:45:08 --> Helper loaded: form_helper
INFO - 2021-12-23 07:45:08 --> Helper loaded: my_helper
INFO - 2021-12-23 07:45:08 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:45:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:45:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:45:08 --> Controller Class Initialized
INFO - 2021-12-23 07:45:08 --> Final output sent to browser
DEBUG - 2021-12-23 07:45:08 --> Total execution time: 0.0372
INFO - 2021-12-23 07:56:12 --> Config Class Initialized
INFO - 2021-12-23 07:56:12 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:56:12 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:56:12 --> Utf8 Class Initialized
INFO - 2021-12-23 07:56:12 --> URI Class Initialized
DEBUG - 2021-12-23 07:56:12 --> No URI present. Default controller set.
INFO - 2021-12-23 07:56:12 --> Router Class Initialized
INFO - 2021-12-23 07:56:12 --> Output Class Initialized
INFO - 2021-12-23 07:56:12 --> Security Class Initialized
DEBUG - 2021-12-23 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:56:12 --> Input Class Initialized
INFO - 2021-12-23 07:56:12 --> Language Class Initialized
INFO - 2021-12-23 07:56:12 --> Language Class Initialized
INFO - 2021-12-23 07:56:12 --> Config Class Initialized
INFO - 2021-12-23 07:56:12 --> Loader Class Initialized
INFO - 2021-12-23 07:56:12 --> Helper loaded: url_helper
INFO - 2021-12-23 07:56:12 --> Helper loaded: file_helper
INFO - 2021-12-23 07:56:12 --> Helper loaded: form_helper
INFO - 2021-12-23 07:56:12 --> Helper loaded: my_helper
INFO - 2021-12-23 07:56:12 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:56:12 --> Controller Class Initialized
INFO - 2021-12-23 07:56:12 --> Config Class Initialized
INFO - 2021-12-23 07:56:12 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:56:12 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:56:12 --> Utf8 Class Initialized
INFO - 2021-12-23 07:56:12 --> URI Class Initialized
INFO - 2021-12-23 07:56:12 --> Router Class Initialized
INFO - 2021-12-23 07:56:12 --> Output Class Initialized
INFO - 2021-12-23 07:56:12 --> Security Class Initialized
DEBUG - 2021-12-23 07:56:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:56:12 --> Input Class Initialized
INFO - 2021-12-23 07:56:12 --> Language Class Initialized
INFO - 2021-12-23 07:56:12 --> Language Class Initialized
INFO - 2021-12-23 07:56:12 --> Config Class Initialized
INFO - 2021-12-23 07:56:12 --> Loader Class Initialized
INFO - 2021-12-23 07:56:12 --> Helper loaded: url_helper
INFO - 2021-12-23 07:56:12 --> Helper loaded: file_helper
INFO - 2021-12-23 07:56:12 --> Helper loaded: form_helper
INFO - 2021-12-23 07:56:12 --> Helper loaded: my_helper
INFO - 2021-12-23 07:56:12 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:56:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:56:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:56:12 --> Controller Class Initialized
DEBUG - 2021-12-23 07:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 07:56:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 07:56:12 --> Final output sent to browser
DEBUG - 2021-12-23 07:56:12 --> Total execution time: 0.0700
INFO - 2021-12-23 07:56:29 --> Config Class Initialized
INFO - 2021-12-23 07:56:29 --> Hooks Class Initialized
DEBUG - 2021-12-23 07:56:29 --> UTF-8 Support Enabled
INFO - 2021-12-23 07:56:29 --> Utf8 Class Initialized
INFO - 2021-12-23 07:56:29 --> URI Class Initialized
INFO - 2021-12-23 07:56:29 --> Router Class Initialized
INFO - 2021-12-23 07:56:29 --> Output Class Initialized
INFO - 2021-12-23 07:56:29 --> Security Class Initialized
DEBUG - 2021-12-23 07:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 07:56:29 --> Input Class Initialized
INFO - 2021-12-23 07:56:29 --> Language Class Initialized
INFO - 2021-12-23 07:56:29 --> Language Class Initialized
INFO - 2021-12-23 07:56:29 --> Config Class Initialized
INFO - 2021-12-23 07:56:29 --> Loader Class Initialized
INFO - 2021-12-23 07:56:29 --> Helper loaded: url_helper
INFO - 2021-12-23 07:56:29 --> Helper loaded: file_helper
INFO - 2021-12-23 07:56:29 --> Helper loaded: form_helper
INFO - 2021-12-23 07:56:29 --> Helper loaded: my_helper
INFO - 2021-12-23 07:56:29 --> Database Driver Class Initialized
DEBUG - 2021-12-23 07:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 07:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 07:56:29 --> Controller Class Initialized
DEBUG - 2021-12-23 07:56:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 07:56:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 07:56:29 --> Final output sent to browser
DEBUG - 2021-12-23 07:56:29 --> Total execution time: 0.0437
INFO - 2021-12-23 09:00:59 --> Config Class Initialized
INFO - 2021-12-23 09:00:59 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:00:59 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:00:59 --> Utf8 Class Initialized
INFO - 2021-12-23 09:00:59 --> URI Class Initialized
DEBUG - 2021-12-23 09:00:59 --> No URI present. Default controller set.
INFO - 2021-12-23 09:00:59 --> Router Class Initialized
INFO - 2021-12-23 09:00:59 --> Output Class Initialized
INFO - 2021-12-23 09:00:59 --> Security Class Initialized
DEBUG - 2021-12-23 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:00:59 --> Input Class Initialized
INFO - 2021-12-23 09:00:59 --> Language Class Initialized
INFO - 2021-12-23 09:00:59 --> Language Class Initialized
INFO - 2021-12-23 09:00:59 --> Config Class Initialized
INFO - 2021-12-23 09:00:59 --> Loader Class Initialized
INFO - 2021-12-23 09:00:59 --> Helper loaded: url_helper
INFO - 2021-12-23 09:00:59 --> Helper loaded: file_helper
INFO - 2021-12-23 09:00:59 --> Helper loaded: form_helper
INFO - 2021-12-23 09:00:59 --> Helper loaded: my_helper
INFO - 2021-12-23 09:00:59 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:00:59 --> Controller Class Initialized
INFO - 2021-12-23 09:00:59 --> Config Class Initialized
INFO - 2021-12-23 09:00:59 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:00:59 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:00:59 --> Utf8 Class Initialized
INFO - 2021-12-23 09:00:59 --> URI Class Initialized
INFO - 2021-12-23 09:00:59 --> Router Class Initialized
INFO - 2021-12-23 09:00:59 --> Output Class Initialized
INFO - 2021-12-23 09:00:59 --> Security Class Initialized
DEBUG - 2021-12-23 09:00:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:00:59 --> Input Class Initialized
INFO - 2021-12-23 09:00:59 --> Language Class Initialized
INFO - 2021-12-23 09:00:59 --> Language Class Initialized
INFO - 2021-12-23 09:00:59 --> Config Class Initialized
INFO - 2021-12-23 09:00:59 --> Loader Class Initialized
INFO - 2021-12-23 09:00:59 --> Helper loaded: url_helper
INFO - 2021-12-23 09:00:59 --> Helper loaded: file_helper
INFO - 2021-12-23 09:00:59 --> Helper loaded: form_helper
INFO - 2021-12-23 09:00:59 --> Helper loaded: my_helper
INFO - 2021-12-23 09:00:59 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:00:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:00:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:00:59 --> Controller Class Initialized
DEBUG - 2021-12-23 09:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 09:00:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:00:59 --> Final output sent to browser
DEBUG - 2021-12-23 09:00:59 --> Total execution time: 0.0453
INFO - 2021-12-23 09:01:14 --> Config Class Initialized
INFO - 2021-12-23 09:01:14 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:01:14 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:01:14 --> Utf8 Class Initialized
INFO - 2021-12-23 09:01:14 --> URI Class Initialized
INFO - 2021-12-23 09:01:14 --> Router Class Initialized
INFO - 2021-12-23 09:01:14 --> Output Class Initialized
INFO - 2021-12-23 09:01:14 --> Security Class Initialized
DEBUG - 2021-12-23 09:01:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:01:14 --> Input Class Initialized
INFO - 2021-12-23 09:01:14 --> Language Class Initialized
INFO - 2021-12-23 09:01:14 --> Language Class Initialized
INFO - 2021-12-23 09:01:14 --> Config Class Initialized
INFO - 2021-12-23 09:01:14 --> Loader Class Initialized
INFO - 2021-12-23 09:01:14 --> Helper loaded: url_helper
INFO - 2021-12-23 09:01:14 --> Helper loaded: file_helper
INFO - 2021-12-23 09:01:14 --> Helper loaded: form_helper
INFO - 2021-12-23 09:01:14 --> Helper loaded: my_helper
INFO - 2021-12-23 09:01:14 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:01:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:01:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:01:14 --> Controller Class Initialized
INFO - 2021-12-23 09:01:14 --> Helper loaded: cookie_helper
INFO - 2021-12-23 09:01:14 --> Final output sent to browser
DEBUG - 2021-12-23 09:01:14 --> Total execution time: 0.0712
INFO - 2021-12-23 09:01:18 --> Config Class Initialized
INFO - 2021-12-23 09:01:18 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:01:18 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:01:18 --> Utf8 Class Initialized
INFO - 2021-12-23 09:01:18 --> URI Class Initialized
INFO - 2021-12-23 09:01:18 --> Router Class Initialized
INFO - 2021-12-23 09:01:18 --> Output Class Initialized
INFO - 2021-12-23 09:01:18 --> Security Class Initialized
DEBUG - 2021-12-23 09:01:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:01:18 --> Input Class Initialized
INFO - 2021-12-23 09:01:18 --> Language Class Initialized
INFO - 2021-12-23 09:01:18 --> Language Class Initialized
INFO - 2021-12-23 09:01:18 --> Config Class Initialized
INFO - 2021-12-23 09:01:18 --> Loader Class Initialized
INFO - 2021-12-23 09:01:18 --> Helper loaded: url_helper
INFO - 2021-12-23 09:01:18 --> Helper loaded: file_helper
INFO - 2021-12-23 09:01:18 --> Helper loaded: form_helper
INFO - 2021-12-23 09:01:18 --> Helper loaded: my_helper
INFO - 2021-12-23 09:01:18 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:01:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:01:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:01:18 --> Controller Class Initialized
DEBUG - 2021-12-23 09:01:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-23 09:01:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:01:18 --> Final output sent to browser
DEBUG - 2021-12-23 09:01:18 --> Total execution time: 0.2497
INFO - 2021-12-23 09:01:25 --> Config Class Initialized
INFO - 2021-12-23 09:01:25 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:01:25 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:01:25 --> Utf8 Class Initialized
INFO - 2021-12-23 09:01:25 --> URI Class Initialized
INFO - 2021-12-23 09:01:25 --> Router Class Initialized
INFO - 2021-12-23 09:01:25 --> Output Class Initialized
INFO - 2021-12-23 09:01:25 --> Security Class Initialized
DEBUG - 2021-12-23 09:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:01:25 --> Input Class Initialized
INFO - 2021-12-23 09:01:25 --> Language Class Initialized
INFO - 2021-12-23 09:01:25 --> Language Class Initialized
INFO - 2021-12-23 09:01:25 --> Config Class Initialized
INFO - 2021-12-23 09:01:25 --> Loader Class Initialized
INFO - 2021-12-23 09:01:25 --> Helper loaded: url_helper
INFO - 2021-12-23 09:01:25 --> Helper loaded: file_helper
INFO - 2021-12-23 09:01:25 --> Helper loaded: form_helper
INFO - 2021-12-23 09:01:25 --> Helper loaded: my_helper
INFO - 2021-12-23 09:01:25 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:01:25 --> Controller Class Initialized
DEBUG - 2021-12-23 09:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-23 09:01:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:01:25 --> Final output sent to browser
DEBUG - 2021-12-23 09:01:25 --> Total execution time: 0.0809
INFO - 2021-12-23 09:30:36 --> Config Class Initialized
INFO - 2021-12-23 09:30:36 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:30:36 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:30:36 --> Utf8 Class Initialized
INFO - 2021-12-23 09:30:36 --> URI Class Initialized
DEBUG - 2021-12-23 09:30:36 --> No URI present. Default controller set.
INFO - 2021-12-23 09:30:36 --> Router Class Initialized
INFO - 2021-12-23 09:30:36 --> Output Class Initialized
INFO - 2021-12-23 09:30:36 --> Security Class Initialized
DEBUG - 2021-12-23 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:30:36 --> Input Class Initialized
INFO - 2021-12-23 09:30:36 --> Language Class Initialized
INFO - 2021-12-23 09:30:36 --> Language Class Initialized
INFO - 2021-12-23 09:30:36 --> Config Class Initialized
INFO - 2021-12-23 09:30:36 --> Loader Class Initialized
INFO - 2021-12-23 09:30:36 --> Helper loaded: url_helper
INFO - 2021-12-23 09:30:36 --> Helper loaded: file_helper
INFO - 2021-12-23 09:30:36 --> Helper loaded: form_helper
INFO - 2021-12-23 09:30:36 --> Helper loaded: my_helper
INFO - 2021-12-23 09:30:36 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:30:36 --> Controller Class Initialized
INFO - 2021-12-23 09:30:36 --> Config Class Initialized
INFO - 2021-12-23 09:30:36 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:30:36 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:30:36 --> Utf8 Class Initialized
INFO - 2021-12-23 09:30:36 --> URI Class Initialized
INFO - 2021-12-23 09:30:36 --> Router Class Initialized
INFO - 2021-12-23 09:30:36 --> Output Class Initialized
INFO - 2021-12-23 09:30:36 --> Security Class Initialized
DEBUG - 2021-12-23 09:30:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:30:36 --> Input Class Initialized
INFO - 2021-12-23 09:30:36 --> Language Class Initialized
INFO - 2021-12-23 09:30:36 --> Language Class Initialized
INFO - 2021-12-23 09:30:36 --> Config Class Initialized
INFO - 2021-12-23 09:30:36 --> Loader Class Initialized
INFO - 2021-12-23 09:30:36 --> Helper loaded: url_helper
INFO - 2021-12-23 09:30:36 --> Helper loaded: file_helper
INFO - 2021-12-23 09:30:36 --> Helper loaded: form_helper
INFO - 2021-12-23 09:30:36 --> Helper loaded: my_helper
INFO - 2021-12-23 09:30:36 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:30:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:30:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:30:36 --> Controller Class Initialized
DEBUG - 2021-12-23 09:30:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 09:30:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:30:36 --> Final output sent to browser
DEBUG - 2021-12-23 09:30:36 --> Total execution time: 0.0443
INFO - 2021-12-23 09:31:14 --> Config Class Initialized
INFO - 2021-12-23 09:31:14 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:31:14 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:31:14 --> Utf8 Class Initialized
INFO - 2021-12-23 09:31:14 --> URI Class Initialized
INFO - 2021-12-23 09:31:14 --> Router Class Initialized
INFO - 2021-12-23 09:31:14 --> Output Class Initialized
INFO - 2021-12-23 09:31:14 --> Security Class Initialized
DEBUG - 2021-12-23 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:31:14 --> Input Class Initialized
INFO - 2021-12-23 09:31:14 --> Language Class Initialized
INFO - 2021-12-23 09:31:14 --> Language Class Initialized
INFO - 2021-12-23 09:31:14 --> Config Class Initialized
INFO - 2021-12-23 09:31:14 --> Loader Class Initialized
INFO - 2021-12-23 09:31:14 --> Helper loaded: url_helper
INFO - 2021-12-23 09:31:14 --> Helper loaded: file_helper
INFO - 2021-12-23 09:31:14 --> Helper loaded: form_helper
INFO - 2021-12-23 09:31:14 --> Helper loaded: my_helper
INFO - 2021-12-23 09:31:14 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:31:14 --> Controller Class Initialized
INFO - 2021-12-23 09:31:14 --> Final output sent to browser
DEBUG - 2021-12-23 09:31:14 --> Total execution time: 0.0470
INFO - 2021-12-23 09:31:14 --> Config Class Initialized
INFO - 2021-12-23 09:31:14 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:31:14 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:31:14 --> Utf8 Class Initialized
INFO - 2021-12-23 09:31:14 --> URI Class Initialized
INFO - 2021-12-23 09:31:14 --> Router Class Initialized
INFO - 2021-12-23 09:31:14 --> Output Class Initialized
INFO - 2021-12-23 09:31:14 --> Security Class Initialized
DEBUG - 2021-12-23 09:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:31:14 --> Input Class Initialized
INFO - 2021-12-23 09:31:14 --> Language Class Initialized
INFO - 2021-12-23 09:31:14 --> Language Class Initialized
INFO - 2021-12-23 09:31:14 --> Config Class Initialized
INFO - 2021-12-23 09:31:14 --> Loader Class Initialized
INFO - 2021-12-23 09:31:14 --> Helper loaded: url_helper
INFO - 2021-12-23 09:31:14 --> Helper loaded: file_helper
INFO - 2021-12-23 09:31:14 --> Helper loaded: form_helper
INFO - 2021-12-23 09:31:14 --> Helper loaded: my_helper
INFO - 2021-12-23 09:31:14 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:31:14 --> Controller Class Initialized
INFO - 2021-12-23 09:31:14 --> Helper loaded: cookie_helper
INFO - 2021-12-23 09:31:14 --> Final output sent to browser
DEBUG - 2021-12-23 09:31:14 --> Total execution time: 0.0408
INFO - 2021-12-23 09:31:27 --> Config Class Initialized
INFO - 2021-12-23 09:31:27 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:31:27 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:31:27 --> Utf8 Class Initialized
INFO - 2021-12-23 09:31:27 --> URI Class Initialized
INFO - 2021-12-23 09:31:27 --> Router Class Initialized
INFO - 2021-12-23 09:31:27 --> Output Class Initialized
INFO - 2021-12-23 09:31:27 --> Security Class Initialized
DEBUG - 2021-12-23 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:31:27 --> Input Class Initialized
INFO - 2021-12-23 09:31:27 --> Language Class Initialized
INFO - 2021-12-23 09:31:27 --> Language Class Initialized
INFO - 2021-12-23 09:31:27 --> Config Class Initialized
INFO - 2021-12-23 09:31:27 --> Loader Class Initialized
INFO - 2021-12-23 09:31:27 --> Helper loaded: url_helper
INFO - 2021-12-23 09:31:27 --> Helper loaded: file_helper
INFO - 2021-12-23 09:31:27 --> Helper loaded: form_helper
INFO - 2021-12-23 09:31:27 --> Helper loaded: my_helper
INFO - 2021-12-23 09:31:27 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:31:27 --> Controller Class Initialized
DEBUG - 2021-12-23 09:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-23 09:31:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:31:27 --> Final output sent to browser
DEBUG - 2021-12-23 09:31:27 --> Total execution time: 0.0970
INFO - 2021-12-23 09:31:27 --> Config Class Initialized
INFO - 2021-12-23 09:31:27 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:31:27 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:31:27 --> Utf8 Class Initialized
INFO - 2021-12-23 09:31:27 --> URI Class Initialized
INFO - 2021-12-23 09:31:27 --> Router Class Initialized
INFO - 2021-12-23 09:31:27 --> Output Class Initialized
INFO - 2021-12-23 09:31:27 --> Security Class Initialized
DEBUG - 2021-12-23 09:31:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:31:27 --> Input Class Initialized
INFO - 2021-12-23 09:31:27 --> Language Class Initialized
INFO - 2021-12-23 09:31:27 --> Language Class Initialized
INFO - 2021-12-23 09:31:27 --> Config Class Initialized
INFO - 2021-12-23 09:31:27 --> Loader Class Initialized
INFO - 2021-12-23 09:31:27 --> Helper loaded: url_helper
INFO - 2021-12-23 09:31:27 --> Helper loaded: file_helper
INFO - 2021-12-23 09:31:27 --> Helper loaded: form_helper
INFO - 2021-12-23 09:31:27 --> Helper loaded: my_helper
INFO - 2021-12-23 09:31:27 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:31:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:31:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:31:27 --> Controller Class Initialized
INFO - 2021-12-23 09:31:27 --> Helper loaded: cookie_helper
INFO - 2021-12-23 09:31:27 --> Final output sent to browser
DEBUG - 2021-12-23 09:31:27 --> Total execution time: 0.0513
INFO - 2021-12-23 09:31:29 --> Config Class Initialized
INFO - 2021-12-23 09:31:29 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:31:29 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:31:29 --> Utf8 Class Initialized
INFO - 2021-12-23 09:31:29 --> URI Class Initialized
INFO - 2021-12-23 09:31:29 --> Router Class Initialized
INFO - 2021-12-23 09:31:29 --> Output Class Initialized
INFO - 2021-12-23 09:31:29 --> Security Class Initialized
DEBUG - 2021-12-23 09:31:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:31:29 --> Input Class Initialized
INFO - 2021-12-23 09:31:29 --> Language Class Initialized
INFO - 2021-12-23 09:31:29 --> Language Class Initialized
INFO - 2021-12-23 09:31:29 --> Config Class Initialized
INFO - 2021-12-23 09:31:29 --> Loader Class Initialized
INFO - 2021-12-23 09:31:29 --> Helper loaded: url_helper
INFO - 2021-12-23 09:31:29 --> Helper loaded: file_helper
INFO - 2021-12-23 09:31:29 --> Helper loaded: form_helper
INFO - 2021-12-23 09:31:29 --> Helper loaded: my_helper
INFO - 2021-12-23 09:31:29 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:31:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:31:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:31:29 --> Controller Class Initialized
DEBUG - 2021-12-23 09:31:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-23 09:31:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:31:29 --> Final output sent to browser
DEBUG - 2021-12-23 09:31:29 --> Total execution time: 0.1110
INFO - 2021-12-23 09:31:46 --> Config Class Initialized
INFO - 2021-12-23 09:31:46 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:31:46 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:31:46 --> Utf8 Class Initialized
INFO - 2021-12-23 09:31:46 --> URI Class Initialized
INFO - 2021-12-23 09:31:46 --> Router Class Initialized
INFO - 2021-12-23 09:31:46 --> Output Class Initialized
INFO - 2021-12-23 09:31:46 --> Security Class Initialized
DEBUG - 2021-12-23 09:31:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:31:46 --> Input Class Initialized
INFO - 2021-12-23 09:31:46 --> Language Class Initialized
INFO - 2021-12-23 09:31:46 --> Language Class Initialized
INFO - 2021-12-23 09:31:46 --> Config Class Initialized
INFO - 2021-12-23 09:31:46 --> Loader Class Initialized
INFO - 2021-12-23 09:31:46 --> Helper loaded: url_helper
INFO - 2021-12-23 09:31:46 --> Helper loaded: file_helper
INFO - 2021-12-23 09:31:46 --> Helper loaded: form_helper
INFO - 2021-12-23 09:31:46 --> Helper loaded: my_helper
INFO - 2021-12-23 09:31:46 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:31:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:31:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:31:46 --> Controller Class Initialized
DEBUG - 2021-12-23 09:31:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-23 09:31:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:31:46 --> Final output sent to browser
DEBUG - 2021-12-23 09:31:46 --> Total execution time: 0.0383
INFO - 2021-12-23 09:32:18 --> Config Class Initialized
INFO - 2021-12-23 09:32:18 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:32:18 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:32:18 --> Utf8 Class Initialized
INFO - 2021-12-23 09:32:18 --> URI Class Initialized
INFO - 2021-12-23 09:32:18 --> Router Class Initialized
INFO - 2021-12-23 09:32:18 --> Output Class Initialized
INFO - 2021-12-23 09:32:18 --> Security Class Initialized
DEBUG - 2021-12-23 09:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:32:18 --> Input Class Initialized
INFO - 2021-12-23 09:32:18 --> Language Class Initialized
INFO - 2021-12-23 09:32:18 --> Language Class Initialized
INFO - 2021-12-23 09:32:18 --> Config Class Initialized
INFO - 2021-12-23 09:32:18 --> Loader Class Initialized
INFO - 2021-12-23 09:32:18 --> Helper loaded: url_helper
INFO - 2021-12-23 09:32:18 --> Helper loaded: file_helper
INFO - 2021-12-23 09:32:18 --> Helper loaded: form_helper
INFO - 2021-12-23 09:32:18 --> Helper loaded: my_helper
INFO - 2021-12-23 09:32:18 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:32:18 --> Controller Class Initialized
DEBUG - 2021-12-23 09:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-12-23 09:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:32:18 --> Final output sent to browser
DEBUG - 2021-12-23 09:32:18 --> Total execution time: 0.0839
INFO - 2021-12-23 09:32:30 --> Config Class Initialized
INFO - 2021-12-23 09:32:30 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:32:30 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:32:30 --> Utf8 Class Initialized
INFO - 2021-12-23 09:32:30 --> URI Class Initialized
INFO - 2021-12-23 09:32:30 --> Router Class Initialized
INFO - 2021-12-23 09:32:30 --> Output Class Initialized
INFO - 2021-12-23 09:32:30 --> Security Class Initialized
DEBUG - 2021-12-23 09:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:32:30 --> Input Class Initialized
INFO - 2021-12-23 09:32:30 --> Language Class Initialized
INFO - 2021-12-23 09:32:30 --> Language Class Initialized
INFO - 2021-12-23 09:32:30 --> Config Class Initialized
INFO - 2021-12-23 09:32:30 --> Loader Class Initialized
INFO - 2021-12-23 09:32:30 --> Helper loaded: url_helper
INFO - 2021-12-23 09:32:30 --> Helper loaded: file_helper
INFO - 2021-12-23 09:32:30 --> Helper loaded: form_helper
INFO - 2021-12-23 09:32:30 --> Helper loaded: my_helper
INFO - 2021-12-23 09:32:30 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:32:30 --> Controller Class Initialized
INFO - 2021-12-23 09:32:41 --> Config Class Initialized
INFO - 2021-12-23 09:32:41 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:32:41 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:32:41 --> Utf8 Class Initialized
INFO - 2021-12-23 09:32:41 --> URI Class Initialized
INFO - 2021-12-23 09:32:41 --> Router Class Initialized
INFO - 2021-12-23 09:32:41 --> Output Class Initialized
INFO - 2021-12-23 09:32:41 --> Security Class Initialized
DEBUG - 2021-12-23 09:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:32:41 --> Input Class Initialized
INFO - 2021-12-23 09:32:41 --> Language Class Initialized
INFO - 2021-12-23 09:32:41 --> Language Class Initialized
INFO - 2021-12-23 09:32:41 --> Config Class Initialized
INFO - 2021-12-23 09:32:41 --> Loader Class Initialized
INFO - 2021-12-23 09:32:41 --> Helper loaded: url_helper
INFO - 2021-12-23 09:32:41 --> Helper loaded: file_helper
INFO - 2021-12-23 09:32:41 --> Helper loaded: form_helper
INFO - 2021-12-23 09:32:41 --> Helper loaded: my_helper
INFO - 2021-12-23 09:32:41 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:32:41 --> Controller Class Initialized
INFO - 2021-12-23 09:32:41 --> Final output sent to browser
DEBUG - 2021-12-23 09:32:41 --> Total execution time: 0.0486
INFO - 2021-12-23 09:38:40 --> Config Class Initialized
INFO - 2021-12-23 09:38:40 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:38:40 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:38:40 --> Utf8 Class Initialized
INFO - 2021-12-23 09:38:40 --> URI Class Initialized
DEBUG - 2021-12-23 09:38:40 --> No URI present. Default controller set.
INFO - 2021-12-23 09:38:40 --> Router Class Initialized
INFO - 2021-12-23 09:38:40 --> Output Class Initialized
INFO - 2021-12-23 09:38:40 --> Security Class Initialized
DEBUG - 2021-12-23 09:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:38:40 --> Input Class Initialized
INFO - 2021-12-23 09:38:40 --> Language Class Initialized
INFO - 2021-12-23 09:38:40 --> Language Class Initialized
INFO - 2021-12-23 09:38:40 --> Config Class Initialized
INFO - 2021-12-23 09:38:40 --> Loader Class Initialized
INFO - 2021-12-23 09:38:40 --> Helper loaded: url_helper
INFO - 2021-12-23 09:38:40 --> Helper loaded: file_helper
INFO - 2021-12-23 09:38:40 --> Helper loaded: form_helper
INFO - 2021-12-23 09:38:40 --> Helper loaded: my_helper
INFO - 2021-12-23 09:38:40 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:38:40 --> Controller Class Initialized
INFO - 2021-12-23 09:38:40 --> Config Class Initialized
INFO - 2021-12-23 09:38:40 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:38:40 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:38:40 --> Utf8 Class Initialized
INFO - 2021-12-23 09:38:40 --> URI Class Initialized
INFO - 2021-12-23 09:38:40 --> Router Class Initialized
INFO - 2021-12-23 09:38:40 --> Output Class Initialized
INFO - 2021-12-23 09:38:40 --> Security Class Initialized
DEBUG - 2021-12-23 09:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:38:40 --> Input Class Initialized
INFO - 2021-12-23 09:38:40 --> Language Class Initialized
INFO - 2021-12-23 09:38:40 --> Language Class Initialized
INFO - 2021-12-23 09:38:40 --> Config Class Initialized
INFO - 2021-12-23 09:38:40 --> Loader Class Initialized
INFO - 2021-12-23 09:38:40 --> Helper loaded: url_helper
INFO - 2021-12-23 09:38:40 --> Helper loaded: file_helper
INFO - 2021-12-23 09:38:40 --> Helper loaded: form_helper
INFO - 2021-12-23 09:38:40 --> Helper loaded: my_helper
INFO - 2021-12-23 09:38:40 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:38:40 --> Controller Class Initialized
DEBUG - 2021-12-23 09:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 09:38:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:38:40 --> Final output sent to browser
DEBUG - 2021-12-23 09:38:40 --> Total execution time: 0.0485
INFO - 2021-12-23 09:39:15 --> Config Class Initialized
INFO - 2021-12-23 09:39:15 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:39:15 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:39:15 --> Utf8 Class Initialized
INFO - 2021-12-23 09:39:15 --> URI Class Initialized
INFO - 2021-12-23 09:39:15 --> Router Class Initialized
INFO - 2021-12-23 09:39:15 --> Output Class Initialized
INFO - 2021-12-23 09:39:15 --> Security Class Initialized
DEBUG - 2021-12-23 09:39:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:39:15 --> Input Class Initialized
INFO - 2021-12-23 09:39:15 --> Language Class Initialized
INFO - 2021-12-23 09:39:15 --> Language Class Initialized
INFO - 2021-12-23 09:39:15 --> Config Class Initialized
INFO - 2021-12-23 09:39:15 --> Loader Class Initialized
INFO - 2021-12-23 09:39:15 --> Helper loaded: url_helper
INFO - 2021-12-23 09:39:15 --> Helper loaded: file_helper
INFO - 2021-12-23 09:39:15 --> Helper loaded: form_helper
INFO - 2021-12-23 09:39:15 --> Helper loaded: my_helper
INFO - 2021-12-23 09:39:15 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:39:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:39:15 --> Controller Class Initialized
INFO - 2021-12-23 09:39:15 --> Helper loaded: cookie_helper
INFO - 2021-12-23 09:39:15 --> Final output sent to browser
DEBUG - 2021-12-23 09:39:15 --> Total execution time: 0.0463
INFO - 2021-12-23 09:42:01 --> Config Class Initialized
INFO - 2021-12-23 09:42:01 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:42:01 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:42:01 --> Utf8 Class Initialized
INFO - 2021-12-23 09:42:01 --> URI Class Initialized
INFO - 2021-12-23 09:42:01 --> Router Class Initialized
INFO - 2021-12-23 09:42:01 --> Output Class Initialized
INFO - 2021-12-23 09:42:01 --> Security Class Initialized
DEBUG - 2021-12-23 09:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:42:01 --> Input Class Initialized
INFO - 2021-12-23 09:42:01 --> Language Class Initialized
INFO - 2021-12-23 09:42:01 --> Language Class Initialized
INFO - 2021-12-23 09:42:01 --> Config Class Initialized
INFO - 2021-12-23 09:42:01 --> Loader Class Initialized
INFO - 2021-12-23 09:42:01 --> Helper loaded: url_helper
INFO - 2021-12-23 09:42:01 --> Helper loaded: file_helper
INFO - 2021-12-23 09:42:01 --> Helper loaded: form_helper
INFO - 2021-12-23 09:42:01 --> Helper loaded: my_helper
INFO - 2021-12-23 09:42:01 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:42:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:42:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:42:01 --> Controller Class Initialized
DEBUG - 2021-12-23 09:42:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-12-23 09:42:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:42:01 --> Final output sent to browser
DEBUG - 2021-12-23 09:42:01 --> Total execution time: 0.1139
INFO - 2021-12-23 09:44:00 --> Config Class Initialized
INFO - 2021-12-23 09:44:00 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:44:00 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:44:00 --> Utf8 Class Initialized
INFO - 2021-12-23 09:44:00 --> URI Class Initialized
INFO - 2021-12-23 09:44:00 --> Router Class Initialized
INFO - 2021-12-23 09:44:00 --> Output Class Initialized
INFO - 2021-12-23 09:44:00 --> Security Class Initialized
DEBUG - 2021-12-23 09:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:44:00 --> Input Class Initialized
INFO - 2021-12-23 09:44:00 --> Language Class Initialized
INFO - 2021-12-23 09:44:00 --> Language Class Initialized
INFO - 2021-12-23 09:44:00 --> Config Class Initialized
INFO - 2021-12-23 09:44:00 --> Loader Class Initialized
INFO - 2021-12-23 09:44:00 --> Helper loaded: url_helper
INFO - 2021-12-23 09:44:00 --> Helper loaded: file_helper
INFO - 2021-12-23 09:44:00 --> Helper loaded: form_helper
INFO - 2021-12-23 09:44:00 --> Helper loaded: my_helper
INFO - 2021-12-23 09:44:00 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:44:00 --> Controller Class Initialized
INFO - 2021-12-23 09:44:00 --> Final output sent to browser
DEBUG - 2021-12-23 09:44:00 --> Total execution time: 0.0420
INFO - 2021-12-23 09:44:00 --> Config Class Initialized
INFO - 2021-12-23 09:44:00 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:44:00 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:44:00 --> Utf8 Class Initialized
INFO - 2021-12-23 09:44:00 --> URI Class Initialized
INFO - 2021-12-23 09:44:00 --> Router Class Initialized
INFO - 2021-12-23 09:44:00 --> Output Class Initialized
INFO - 2021-12-23 09:44:00 --> Security Class Initialized
DEBUG - 2021-12-23 09:44:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:44:00 --> Input Class Initialized
INFO - 2021-12-23 09:44:00 --> Language Class Initialized
INFO - 2021-12-23 09:44:00 --> Language Class Initialized
INFO - 2021-12-23 09:44:00 --> Config Class Initialized
INFO - 2021-12-23 09:44:00 --> Loader Class Initialized
INFO - 2021-12-23 09:44:00 --> Helper loaded: url_helper
INFO - 2021-12-23 09:44:00 --> Helper loaded: file_helper
INFO - 2021-12-23 09:44:00 --> Helper loaded: form_helper
INFO - 2021-12-23 09:44:00 --> Helper loaded: my_helper
INFO - 2021-12-23 09:44:00 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:44:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:44:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:44:00 --> Controller Class Initialized
INFO - 2021-12-23 09:44:12 --> Config Class Initialized
INFO - 2021-12-23 09:44:12 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:44:12 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:44:12 --> Utf8 Class Initialized
INFO - 2021-12-23 09:44:12 --> URI Class Initialized
INFO - 2021-12-23 09:44:12 --> Router Class Initialized
INFO - 2021-12-23 09:44:12 --> Output Class Initialized
INFO - 2021-12-23 09:44:12 --> Security Class Initialized
DEBUG - 2021-12-23 09:44:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:44:12 --> Input Class Initialized
INFO - 2021-12-23 09:44:12 --> Language Class Initialized
INFO - 2021-12-23 09:44:12 --> Language Class Initialized
INFO - 2021-12-23 09:44:12 --> Config Class Initialized
INFO - 2021-12-23 09:44:12 --> Loader Class Initialized
INFO - 2021-12-23 09:44:12 --> Helper loaded: url_helper
INFO - 2021-12-23 09:44:12 --> Helper loaded: file_helper
INFO - 2021-12-23 09:44:12 --> Helper loaded: form_helper
INFO - 2021-12-23 09:44:12 --> Helper loaded: my_helper
INFO - 2021-12-23 09:44:12 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:44:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:44:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:44:12 --> Controller Class Initialized
INFO - 2021-12-23 09:44:12 --> Final output sent to browser
DEBUG - 2021-12-23 09:44:12 --> Total execution time: 0.0358
INFO - 2021-12-23 09:49:32 --> Config Class Initialized
INFO - 2021-12-23 09:49:32 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:49:32 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:49:32 --> Utf8 Class Initialized
INFO - 2021-12-23 09:49:32 --> URI Class Initialized
INFO - 2021-12-23 09:49:32 --> Router Class Initialized
INFO - 2021-12-23 09:49:32 --> Output Class Initialized
INFO - 2021-12-23 09:49:32 --> Security Class Initialized
DEBUG - 2021-12-23 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:49:32 --> Input Class Initialized
INFO - 2021-12-23 09:49:32 --> Language Class Initialized
INFO - 2021-12-23 09:49:32 --> Language Class Initialized
INFO - 2021-12-23 09:49:32 --> Config Class Initialized
INFO - 2021-12-23 09:49:32 --> Loader Class Initialized
INFO - 2021-12-23 09:49:32 --> Helper loaded: url_helper
INFO - 2021-12-23 09:49:32 --> Helper loaded: file_helper
INFO - 2021-12-23 09:49:32 --> Helper loaded: form_helper
INFO - 2021-12-23 09:49:32 --> Helper loaded: my_helper
INFO - 2021-12-23 09:49:32 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:49:32 --> Controller Class Initialized
INFO - 2021-12-23 09:49:32 --> Helper loaded: cookie_helper
INFO - 2021-12-23 09:49:32 --> Config Class Initialized
INFO - 2021-12-23 09:49:32 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:49:32 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:49:32 --> Utf8 Class Initialized
INFO - 2021-12-23 09:49:32 --> URI Class Initialized
INFO - 2021-12-23 09:49:32 --> Router Class Initialized
INFO - 2021-12-23 09:49:32 --> Output Class Initialized
INFO - 2021-12-23 09:49:32 --> Security Class Initialized
DEBUG - 2021-12-23 09:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:49:32 --> Input Class Initialized
INFO - 2021-12-23 09:49:32 --> Language Class Initialized
INFO - 2021-12-23 09:49:32 --> Language Class Initialized
INFO - 2021-12-23 09:49:32 --> Config Class Initialized
INFO - 2021-12-23 09:49:32 --> Loader Class Initialized
INFO - 2021-12-23 09:49:32 --> Helper loaded: url_helper
INFO - 2021-12-23 09:49:32 --> Helper loaded: file_helper
INFO - 2021-12-23 09:49:32 --> Helper loaded: form_helper
INFO - 2021-12-23 09:49:32 --> Helper loaded: my_helper
INFO - 2021-12-23 09:49:32 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:49:32 --> Controller Class Initialized
DEBUG - 2021-12-23 09:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 09:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:49:32 --> Final output sent to browser
DEBUG - 2021-12-23 09:49:32 --> Total execution time: 0.0464
INFO - 2021-12-23 09:50:03 --> Config Class Initialized
INFO - 2021-12-23 09:50:03 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:50:03 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:50:03 --> Utf8 Class Initialized
INFO - 2021-12-23 09:50:03 --> URI Class Initialized
INFO - 2021-12-23 09:50:03 --> Router Class Initialized
INFO - 2021-12-23 09:50:03 --> Output Class Initialized
INFO - 2021-12-23 09:50:03 --> Security Class Initialized
DEBUG - 2021-12-23 09:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:50:03 --> Input Class Initialized
INFO - 2021-12-23 09:50:03 --> Language Class Initialized
INFO - 2021-12-23 09:50:03 --> Language Class Initialized
INFO - 2021-12-23 09:50:03 --> Config Class Initialized
INFO - 2021-12-23 09:50:03 --> Loader Class Initialized
INFO - 2021-12-23 09:50:03 --> Helper loaded: url_helper
INFO - 2021-12-23 09:50:03 --> Helper loaded: file_helper
INFO - 2021-12-23 09:50:03 --> Helper loaded: form_helper
INFO - 2021-12-23 09:50:03 --> Helper loaded: my_helper
INFO - 2021-12-23 09:50:03 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:50:03 --> Controller Class Initialized
INFO - 2021-12-23 09:50:03 --> Final output sent to browser
DEBUG - 2021-12-23 09:50:03 --> Total execution time: 0.0512
INFO - 2021-12-23 09:50:03 --> Config Class Initialized
INFO - 2021-12-23 09:50:03 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:50:03 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:50:03 --> Utf8 Class Initialized
INFO - 2021-12-23 09:50:03 --> URI Class Initialized
INFO - 2021-12-23 09:50:03 --> Router Class Initialized
INFO - 2021-12-23 09:50:03 --> Output Class Initialized
INFO - 2021-12-23 09:50:03 --> Security Class Initialized
DEBUG - 2021-12-23 09:50:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:50:03 --> Input Class Initialized
INFO - 2021-12-23 09:50:03 --> Language Class Initialized
INFO - 2021-12-23 09:50:03 --> Language Class Initialized
INFO - 2021-12-23 09:50:03 --> Config Class Initialized
INFO - 2021-12-23 09:50:03 --> Loader Class Initialized
INFO - 2021-12-23 09:50:03 --> Helper loaded: url_helper
INFO - 2021-12-23 09:50:03 --> Helper loaded: file_helper
INFO - 2021-12-23 09:50:03 --> Helper loaded: form_helper
INFO - 2021-12-23 09:50:03 --> Helper loaded: my_helper
INFO - 2021-12-23 09:50:03 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:50:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:50:03 --> Controller Class Initialized
INFO - 2021-12-23 09:50:10 --> Config Class Initialized
INFO - 2021-12-23 09:50:10 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:50:10 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:50:10 --> Utf8 Class Initialized
INFO - 2021-12-23 09:50:10 --> URI Class Initialized
INFO - 2021-12-23 09:50:10 --> Router Class Initialized
INFO - 2021-12-23 09:50:10 --> Output Class Initialized
INFO - 2021-12-23 09:50:10 --> Security Class Initialized
DEBUG - 2021-12-23 09:50:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:50:10 --> Input Class Initialized
INFO - 2021-12-23 09:50:10 --> Language Class Initialized
INFO - 2021-12-23 09:50:10 --> Language Class Initialized
INFO - 2021-12-23 09:50:10 --> Config Class Initialized
INFO - 2021-12-23 09:50:10 --> Loader Class Initialized
INFO - 2021-12-23 09:50:10 --> Helper loaded: url_helper
INFO - 2021-12-23 09:50:10 --> Helper loaded: file_helper
INFO - 2021-12-23 09:50:10 --> Helper loaded: form_helper
INFO - 2021-12-23 09:50:10 --> Helper loaded: my_helper
INFO - 2021-12-23 09:50:10 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:50:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:50:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:50:10 --> Controller Class Initialized
INFO - 2021-12-23 09:50:10 --> Final output sent to browser
DEBUG - 2021-12-23 09:50:10 --> Total execution time: 0.0348
INFO - 2021-12-23 09:51:39 --> Config Class Initialized
INFO - 2021-12-23 09:51:39 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:51:39 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:51:39 --> Utf8 Class Initialized
INFO - 2021-12-23 09:51:39 --> URI Class Initialized
INFO - 2021-12-23 09:51:39 --> Router Class Initialized
INFO - 2021-12-23 09:51:39 --> Output Class Initialized
INFO - 2021-12-23 09:51:39 --> Security Class Initialized
DEBUG - 2021-12-23 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:51:39 --> Input Class Initialized
INFO - 2021-12-23 09:51:39 --> Language Class Initialized
INFO - 2021-12-23 09:51:39 --> Language Class Initialized
INFO - 2021-12-23 09:51:39 --> Config Class Initialized
INFO - 2021-12-23 09:51:39 --> Loader Class Initialized
INFO - 2021-12-23 09:51:39 --> Helper loaded: url_helper
INFO - 2021-12-23 09:51:39 --> Helper loaded: file_helper
INFO - 2021-12-23 09:51:39 --> Helper loaded: form_helper
INFO - 2021-12-23 09:51:39 --> Helper loaded: my_helper
INFO - 2021-12-23 09:51:39 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:51:39 --> Controller Class Initialized
INFO - 2021-12-23 09:51:39 --> Final output sent to browser
DEBUG - 2021-12-23 09:51:39 --> Total execution time: 0.0471
INFO - 2021-12-23 09:51:39 --> Config Class Initialized
INFO - 2021-12-23 09:51:39 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:51:39 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:51:39 --> Utf8 Class Initialized
INFO - 2021-12-23 09:51:39 --> URI Class Initialized
INFO - 2021-12-23 09:51:39 --> Router Class Initialized
INFO - 2021-12-23 09:51:39 --> Output Class Initialized
INFO - 2021-12-23 09:51:39 --> Security Class Initialized
DEBUG - 2021-12-23 09:51:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:51:39 --> Input Class Initialized
INFO - 2021-12-23 09:51:39 --> Language Class Initialized
INFO - 2021-12-23 09:51:39 --> Language Class Initialized
INFO - 2021-12-23 09:51:39 --> Config Class Initialized
INFO - 2021-12-23 09:51:39 --> Loader Class Initialized
INFO - 2021-12-23 09:51:39 --> Helper loaded: url_helper
INFO - 2021-12-23 09:51:39 --> Helper loaded: file_helper
INFO - 2021-12-23 09:51:39 --> Helper loaded: form_helper
INFO - 2021-12-23 09:51:39 --> Helper loaded: my_helper
INFO - 2021-12-23 09:51:39 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:51:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:51:39 --> Controller Class Initialized
INFO - 2021-12-23 09:51:42 --> Config Class Initialized
INFO - 2021-12-23 09:51:42 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:51:42 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:51:42 --> Utf8 Class Initialized
INFO - 2021-12-23 09:51:42 --> URI Class Initialized
INFO - 2021-12-23 09:51:42 --> Router Class Initialized
INFO - 2021-12-23 09:51:42 --> Output Class Initialized
INFO - 2021-12-23 09:51:42 --> Security Class Initialized
DEBUG - 2021-12-23 09:51:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:51:42 --> Input Class Initialized
INFO - 2021-12-23 09:51:42 --> Language Class Initialized
INFO - 2021-12-23 09:51:42 --> Language Class Initialized
INFO - 2021-12-23 09:51:42 --> Config Class Initialized
INFO - 2021-12-23 09:51:42 --> Loader Class Initialized
INFO - 2021-12-23 09:51:42 --> Helper loaded: url_helper
INFO - 2021-12-23 09:51:42 --> Helper loaded: file_helper
INFO - 2021-12-23 09:51:42 --> Helper loaded: form_helper
INFO - 2021-12-23 09:51:42 --> Helper loaded: my_helper
INFO - 2021-12-23 09:51:42 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:51:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:51:42 --> Controller Class Initialized
INFO - 2021-12-23 09:51:42 --> Final output sent to browser
DEBUG - 2021-12-23 09:51:42 --> Total execution time: 0.0397
INFO - 2021-12-23 09:53:29 --> Config Class Initialized
INFO - 2021-12-23 09:53:29 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:53:29 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:53:29 --> Utf8 Class Initialized
INFO - 2021-12-23 09:53:29 --> URI Class Initialized
INFO - 2021-12-23 09:53:29 --> Router Class Initialized
INFO - 2021-12-23 09:53:29 --> Output Class Initialized
INFO - 2021-12-23 09:53:29 --> Security Class Initialized
DEBUG - 2021-12-23 09:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:53:29 --> Input Class Initialized
INFO - 2021-12-23 09:53:29 --> Language Class Initialized
INFO - 2021-12-23 09:53:29 --> Language Class Initialized
INFO - 2021-12-23 09:53:29 --> Config Class Initialized
INFO - 2021-12-23 09:53:29 --> Loader Class Initialized
INFO - 2021-12-23 09:53:29 --> Helper loaded: url_helper
INFO - 2021-12-23 09:53:29 --> Helper loaded: file_helper
INFO - 2021-12-23 09:53:29 --> Helper loaded: form_helper
INFO - 2021-12-23 09:53:29 --> Helper loaded: my_helper
INFO - 2021-12-23 09:53:29 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:53:29 --> Controller Class Initialized
INFO - 2021-12-23 09:53:29 --> Final output sent to browser
DEBUG - 2021-12-23 09:53:29 --> Total execution time: 0.0464
INFO - 2021-12-23 09:53:29 --> Config Class Initialized
INFO - 2021-12-23 09:53:29 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:53:29 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:53:29 --> Utf8 Class Initialized
INFO - 2021-12-23 09:53:29 --> URI Class Initialized
INFO - 2021-12-23 09:53:29 --> Router Class Initialized
INFO - 2021-12-23 09:53:29 --> Output Class Initialized
INFO - 2021-12-23 09:53:29 --> Security Class Initialized
DEBUG - 2021-12-23 09:53:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:53:29 --> Input Class Initialized
INFO - 2021-12-23 09:53:29 --> Language Class Initialized
INFO - 2021-12-23 09:53:29 --> Language Class Initialized
INFO - 2021-12-23 09:53:29 --> Config Class Initialized
INFO - 2021-12-23 09:53:29 --> Loader Class Initialized
INFO - 2021-12-23 09:53:29 --> Helper loaded: url_helper
INFO - 2021-12-23 09:53:29 --> Helper loaded: file_helper
INFO - 2021-12-23 09:53:29 --> Helper loaded: form_helper
INFO - 2021-12-23 09:53:29 --> Helper loaded: my_helper
INFO - 2021-12-23 09:53:29 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:53:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:53:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:53:29 --> Controller Class Initialized
INFO - 2021-12-23 09:53:43 --> Config Class Initialized
INFO - 2021-12-23 09:53:43 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:53:43 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:53:43 --> Utf8 Class Initialized
INFO - 2021-12-23 09:53:43 --> URI Class Initialized
INFO - 2021-12-23 09:53:43 --> Router Class Initialized
INFO - 2021-12-23 09:53:43 --> Output Class Initialized
INFO - 2021-12-23 09:53:43 --> Security Class Initialized
DEBUG - 2021-12-23 09:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:53:43 --> Input Class Initialized
INFO - 2021-12-23 09:53:43 --> Language Class Initialized
INFO - 2021-12-23 09:53:43 --> Language Class Initialized
INFO - 2021-12-23 09:53:43 --> Config Class Initialized
INFO - 2021-12-23 09:53:43 --> Loader Class Initialized
INFO - 2021-12-23 09:53:43 --> Helper loaded: url_helper
INFO - 2021-12-23 09:53:43 --> Helper loaded: file_helper
INFO - 2021-12-23 09:53:43 --> Helper loaded: form_helper
INFO - 2021-12-23 09:53:43 --> Helper loaded: my_helper
INFO - 2021-12-23 09:53:43 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:53:43 --> Controller Class Initialized
DEBUG - 2021-12-23 09:53:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-12-23 09:53:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:53:43 --> Final output sent to browser
DEBUG - 2021-12-23 09:53:43 --> Total execution time: 0.0497
INFO - 2021-12-23 09:54:19 --> Config Class Initialized
INFO - 2021-12-23 09:54:19 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:54:19 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:54:19 --> Utf8 Class Initialized
INFO - 2021-12-23 09:54:19 --> URI Class Initialized
INFO - 2021-12-23 09:54:19 --> Router Class Initialized
INFO - 2021-12-23 09:54:19 --> Output Class Initialized
INFO - 2021-12-23 09:54:19 --> Security Class Initialized
DEBUG - 2021-12-23 09:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:54:19 --> Input Class Initialized
INFO - 2021-12-23 09:54:19 --> Language Class Initialized
INFO - 2021-12-23 09:54:19 --> Language Class Initialized
INFO - 2021-12-23 09:54:19 --> Config Class Initialized
INFO - 2021-12-23 09:54:19 --> Loader Class Initialized
INFO - 2021-12-23 09:54:19 --> Helper loaded: url_helper
INFO - 2021-12-23 09:54:19 --> Helper loaded: file_helper
INFO - 2021-12-23 09:54:19 --> Helper loaded: form_helper
INFO - 2021-12-23 09:54:19 --> Helper loaded: my_helper
INFO - 2021-12-23 09:54:19 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:54:19 --> Controller Class Initialized
INFO - 2021-12-23 09:54:19 --> Helper loaded: cookie_helper
INFO - 2021-12-23 09:54:19 --> Config Class Initialized
INFO - 2021-12-23 09:54:19 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:54:19 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:54:19 --> Utf8 Class Initialized
INFO - 2021-12-23 09:54:19 --> URI Class Initialized
INFO - 2021-12-23 09:54:19 --> Router Class Initialized
INFO - 2021-12-23 09:54:19 --> Output Class Initialized
INFO - 2021-12-23 09:54:19 --> Security Class Initialized
DEBUG - 2021-12-23 09:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:54:19 --> Input Class Initialized
INFO - 2021-12-23 09:54:19 --> Language Class Initialized
INFO - 2021-12-23 09:54:19 --> Language Class Initialized
INFO - 2021-12-23 09:54:19 --> Config Class Initialized
INFO - 2021-12-23 09:54:19 --> Loader Class Initialized
INFO - 2021-12-23 09:54:19 --> Helper loaded: url_helper
INFO - 2021-12-23 09:54:19 --> Helper loaded: file_helper
INFO - 2021-12-23 09:54:19 --> Helper loaded: form_helper
INFO - 2021-12-23 09:54:19 --> Helper loaded: my_helper
INFO - 2021-12-23 09:54:19 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:54:19 --> Controller Class Initialized
DEBUG - 2021-12-23 09:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 09:54:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:54:19 --> Final output sent to browser
DEBUG - 2021-12-23 09:54:19 --> Total execution time: 0.0362
INFO - 2021-12-23 09:57:24 --> Config Class Initialized
INFO - 2021-12-23 09:57:24 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:57:24 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:57:24 --> Utf8 Class Initialized
INFO - 2021-12-23 09:57:24 --> URI Class Initialized
INFO - 2021-12-23 09:57:24 --> Router Class Initialized
INFO - 2021-12-23 09:57:24 --> Output Class Initialized
INFO - 2021-12-23 09:57:24 --> Security Class Initialized
DEBUG - 2021-12-23 09:57:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:57:24 --> Input Class Initialized
INFO - 2021-12-23 09:57:24 --> Language Class Initialized
INFO - 2021-12-23 09:57:24 --> Language Class Initialized
INFO - 2021-12-23 09:57:24 --> Config Class Initialized
INFO - 2021-12-23 09:57:24 --> Loader Class Initialized
INFO - 2021-12-23 09:57:24 --> Helper loaded: url_helper
INFO - 2021-12-23 09:57:24 --> Helper loaded: file_helper
INFO - 2021-12-23 09:57:24 --> Helper loaded: form_helper
INFO - 2021-12-23 09:57:24 --> Helper loaded: my_helper
INFO - 2021-12-23 09:57:25 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:57:25 --> Controller Class Initialized
INFO - 2021-12-23 09:57:25 --> Helper loaded: cookie_helper
INFO - 2021-12-23 09:57:25 --> Config Class Initialized
INFO - 2021-12-23 09:57:25 --> Hooks Class Initialized
DEBUG - 2021-12-23 09:57:25 --> UTF-8 Support Enabled
INFO - 2021-12-23 09:57:25 --> Utf8 Class Initialized
INFO - 2021-12-23 09:57:25 --> URI Class Initialized
INFO - 2021-12-23 09:57:25 --> Router Class Initialized
INFO - 2021-12-23 09:57:25 --> Output Class Initialized
INFO - 2021-12-23 09:57:25 --> Security Class Initialized
DEBUG - 2021-12-23 09:57:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-12-23 09:57:25 --> Input Class Initialized
INFO - 2021-12-23 09:57:25 --> Language Class Initialized
INFO - 2021-12-23 09:57:25 --> Language Class Initialized
INFO - 2021-12-23 09:57:25 --> Config Class Initialized
INFO - 2021-12-23 09:57:25 --> Loader Class Initialized
INFO - 2021-12-23 09:57:25 --> Helper loaded: url_helper
INFO - 2021-12-23 09:57:25 --> Helper loaded: file_helper
INFO - 2021-12-23 09:57:25 --> Helper loaded: form_helper
INFO - 2021-12-23 09:57:25 --> Helper loaded: my_helper
INFO - 2021-12-23 09:57:25 --> Database Driver Class Initialized
DEBUG - 2021-12-23 09:57:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-12-23 09:57:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-12-23 09:57:25 --> Controller Class Initialized
DEBUG - 2021-12-23 09:57:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-12-23 09:57:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-12-23 09:57:25 --> Final output sent to browser
DEBUG - 2021-12-23 09:57:25 --> Total execution time: 0.0369
