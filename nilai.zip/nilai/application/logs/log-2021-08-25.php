<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-08-25 02:08:59 --> Config Class Initialized
INFO - 2021-08-25 02:08:59 --> Hooks Class Initialized
DEBUG - 2021-08-25 02:08:59 --> UTF-8 Support Enabled
INFO - 2021-08-25 02:08:59 --> Utf8 Class Initialized
INFO - 2021-08-25 02:08:59 --> URI Class Initialized
INFO - 2021-08-25 02:08:59 --> Router Class Initialized
INFO - 2021-08-25 02:08:59 --> Output Class Initialized
INFO - 2021-08-25 02:08:59 --> Security Class Initialized
DEBUG - 2021-08-25 02:08:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-25 02:08:59 --> Input Class Initialized
INFO - 2021-08-25 02:08:59 --> Language Class Initialized
INFO - 2021-08-25 02:08:59 --> Language Class Initialized
INFO - 2021-08-25 02:08:59 --> Config Class Initialized
INFO - 2021-08-25 02:08:59 --> Loader Class Initialized
INFO - 2021-08-25 02:08:59 --> Helper loaded: url_helper
INFO - 2021-08-25 02:08:59 --> Helper loaded: file_helper
INFO - 2021-08-25 02:08:59 --> Helper loaded: form_helper
INFO - 2021-08-25 02:08:59 --> Helper loaded: my_helper
INFO - 2021-08-25 02:09:00 --> Database Driver Class Initialized
DEBUG - 2021-08-25 02:09:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-25 02:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-25 02:09:00 --> Controller Class Initialized
DEBUG - 2021-08-25 02:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-08-25 02:09:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-25 02:09:00 --> Final output sent to browser
DEBUG - 2021-08-25 02:09:00 --> Total execution time: 0.6324
INFO - 2021-08-25 02:09:07 --> Config Class Initialized
INFO - 2021-08-25 02:09:07 --> Hooks Class Initialized
DEBUG - 2021-08-25 02:09:07 --> UTF-8 Support Enabled
INFO - 2021-08-25 02:09:07 --> Utf8 Class Initialized
INFO - 2021-08-25 02:09:07 --> URI Class Initialized
INFO - 2021-08-25 02:09:07 --> Router Class Initialized
INFO - 2021-08-25 02:09:07 --> Output Class Initialized
INFO - 2021-08-25 02:09:07 --> Security Class Initialized
DEBUG - 2021-08-25 02:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-25 02:09:07 --> Input Class Initialized
INFO - 2021-08-25 02:09:07 --> Language Class Initialized
INFO - 2021-08-25 02:09:07 --> Language Class Initialized
INFO - 2021-08-25 02:09:07 --> Config Class Initialized
INFO - 2021-08-25 02:09:07 --> Loader Class Initialized
INFO - 2021-08-25 02:09:07 --> Helper loaded: url_helper
INFO - 2021-08-25 02:09:07 --> Helper loaded: file_helper
INFO - 2021-08-25 02:09:07 --> Helper loaded: form_helper
INFO - 2021-08-25 02:09:07 --> Helper loaded: my_helper
INFO - 2021-08-25 02:09:07 --> Database Driver Class Initialized
DEBUG - 2021-08-25 02:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-25 02:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-25 02:09:07 --> Controller Class Initialized
INFO - 2021-08-25 02:09:07 --> Helper loaded: cookie_helper
INFO - 2021-08-25 02:09:07 --> Final output sent to browser
DEBUG - 2021-08-25 02:09:07 --> Total execution time: 0.1085
INFO - 2021-08-25 02:09:08 --> Config Class Initialized
INFO - 2021-08-25 02:09:08 --> Hooks Class Initialized
DEBUG - 2021-08-25 02:09:08 --> UTF-8 Support Enabled
INFO - 2021-08-25 02:09:08 --> Utf8 Class Initialized
INFO - 2021-08-25 02:09:08 --> URI Class Initialized
INFO - 2021-08-25 02:09:08 --> Router Class Initialized
INFO - 2021-08-25 02:09:08 --> Output Class Initialized
INFO - 2021-08-25 02:09:08 --> Security Class Initialized
DEBUG - 2021-08-25 02:09:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-25 02:09:08 --> Input Class Initialized
INFO - 2021-08-25 02:09:08 --> Language Class Initialized
INFO - 2021-08-25 02:09:08 --> Language Class Initialized
INFO - 2021-08-25 02:09:08 --> Config Class Initialized
INFO - 2021-08-25 02:09:08 --> Loader Class Initialized
INFO - 2021-08-25 02:09:08 --> Helper loaded: url_helper
INFO - 2021-08-25 02:09:08 --> Helper loaded: file_helper
INFO - 2021-08-25 02:09:08 --> Helper loaded: form_helper
INFO - 2021-08-25 02:09:08 --> Helper loaded: my_helper
INFO - 2021-08-25 02:09:08 --> Database Driver Class Initialized
DEBUG - 2021-08-25 02:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-25 02:09:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-25 02:09:08 --> Controller Class Initialized
DEBUG - 2021-08-25 02:09:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-08-25 02:09:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-25 02:09:08 --> Final output sent to browser
DEBUG - 2021-08-25 02:09:08 --> Total execution time: 0.8280
INFO - 2021-08-25 02:09:12 --> Config Class Initialized
INFO - 2021-08-25 02:09:12 --> Hooks Class Initialized
DEBUG - 2021-08-25 02:09:12 --> UTF-8 Support Enabled
INFO - 2021-08-25 02:09:12 --> Utf8 Class Initialized
INFO - 2021-08-25 02:09:12 --> URI Class Initialized
INFO - 2021-08-25 02:09:12 --> Router Class Initialized
INFO - 2021-08-25 02:09:12 --> Output Class Initialized
INFO - 2021-08-25 02:09:12 --> Security Class Initialized
DEBUG - 2021-08-25 02:09:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-25 02:09:12 --> Input Class Initialized
INFO - 2021-08-25 02:09:12 --> Language Class Initialized
INFO - 2021-08-25 02:09:12 --> Language Class Initialized
INFO - 2021-08-25 02:09:12 --> Config Class Initialized
INFO - 2021-08-25 02:09:12 --> Loader Class Initialized
INFO - 2021-08-25 02:09:12 --> Helper loaded: url_helper
INFO - 2021-08-25 02:09:12 --> Helper loaded: file_helper
INFO - 2021-08-25 02:09:12 --> Helper loaded: form_helper
INFO - 2021-08-25 02:09:12 --> Helper loaded: my_helper
INFO - 2021-08-25 02:09:12 --> Database Driver Class Initialized
DEBUG - 2021-08-25 02:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-25 02:09:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-25 02:09:12 --> Controller Class Initialized
DEBUG - 2021-08-25 02:09:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-08-25 02:09:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-08-25 02:09:12 --> Final output sent to browser
DEBUG - 2021-08-25 02:09:12 --> Total execution time: 0.0941
INFO - 2021-08-25 02:09:39 --> Config Class Initialized
INFO - 2021-08-25 02:09:39 --> Hooks Class Initialized
DEBUG - 2021-08-25 02:09:39 --> UTF-8 Support Enabled
INFO - 2021-08-25 02:09:39 --> Utf8 Class Initialized
INFO - 2021-08-25 02:09:39 --> URI Class Initialized
INFO - 2021-08-25 02:09:39 --> Router Class Initialized
INFO - 2021-08-25 02:09:39 --> Output Class Initialized
INFO - 2021-08-25 02:09:39 --> Security Class Initialized
DEBUG - 2021-08-25 02:09:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-08-25 02:09:39 --> Input Class Initialized
INFO - 2021-08-25 02:09:39 --> Language Class Initialized
INFO - 2021-08-25 02:09:39 --> Language Class Initialized
INFO - 2021-08-25 02:09:39 --> Config Class Initialized
INFO - 2021-08-25 02:09:39 --> Loader Class Initialized
INFO - 2021-08-25 02:09:39 --> Helper loaded: url_helper
INFO - 2021-08-25 02:09:39 --> Helper loaded: file_helper
INFO - 2021-08-25 02:09:39 --> Helper loaded: form_helper
INFO - 2021-08-25 02:09:39 --> Helper loaded: my_helper
INFO - 2021-08-25 02:09:39 --> Database Driver Class Initialized
DEBUG - 2021-08-25 02:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-08-25 02:09:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-08-25 02:09:39 --> Controller Class Initialized
DEBUG - 2021-08-25 02:09:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2021-08-25 02:09:39 --> Final output sent to browser
DEBUG - 2021-08-25 02:09:39 --> Total execution time: 0.3102
