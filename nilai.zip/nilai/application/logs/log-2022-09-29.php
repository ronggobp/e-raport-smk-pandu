<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-09-29 02:36:55 --> Config Class Initialized
INFO - 2022-09-29 02:36:55 --> Hooks Class Initialized
DEBUG - 2022-09-29 02:36:55 --> UTF-8 Support Enabled
INFO - 2022-09-29 02:36:55 --> Utf8 Class Initialized
INFO - 2022-09-29 02:36:55 --> URI Class Initialized
DEBUG - 2022-09-29 02:36:55 --> No URI present. Default controller set.
INFO - 2022-09-29 02:36:55 --> Router Class Initialized
INFO - 2022-09-29 02:36:55 --> Output Class Initialized
INFO - 2022-09-29 02:36:55 --> Security Class Initialized
DEBUG - 2022-09-29 02:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 02:36:55 --> Input Class Initialized
INFO - 2022-09-29 02:36:55 --> Language Class Initialized
INFO - 2022-09-29 02:36:55 --> Language Class Initialized
INFO - 2022-09-29 02:36:55 --> Config Class Initialized
INFO - 2022-09-29 02:36:55 --> Loader Class Initialized
INFO - 2022-09-29 02:36:55 --> Helper loaded: url_helper
INFO - 2022-09-29 02:36:55 --> Helper loaded: file_helper
INFO - 2022-09-29 02:36:55 --> Helper loaded: form_helper
INFO - 2022-09-29 02:36:55 --> Helper loaded: my_helper
INFO - 2022-09-29 02:36:55 --> Database Driver Class Initialized
DEBUG - 2022-09-29 02:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 02:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 02:36:55 --> Controller Class Initialized
INFO - 2022-09-29 02:36:55 --> Config Class Initialized
INFO - 2022-09-29 02:36:55 --> Hooks Class Initialized
DEBUG - 2022-09-29 02:36:55 --> UTF-8 Support Enabled
INFO - 2022-09-29 02:36:55 --> Utf8 Class Initialized
INFO - 2022-09-29 02:36:55 --> URI Class Initialized
INFO - 2022-09-29 02:36:55 --> Router Class Initialized
INFO - 2022-09-29 02:36:55 --> Output Class Initialized
INFO - 2022-09-29 02:36:55 --> Security Class Initialized
DEBUG - 2022-09-29 02:36:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 02:36:55 --> Input Class Initialized
INFO - 2022-09-29 02:36:55 --> Language Class Initialized
INFO - 2022-09-29 02:36:55 --> Language Class Initialized
INFO - 2022-09-29 02:36:55 --> Config Class Initialized
INFO - 2022-09-29 02:36:55 --> Loader Class Initialized
INFO - 2022-09-29 02:36:55 --> Helper loaded: url_helper
INFO - 2022-09-29 02:36:55 --> Helper loaded: file_helper
INFO - 2022-09-29 02:36:55 --> Helper loaded: form_helper
INFO - 2022-09-29 02:36:55 --> Helper loaded: my_helper
INFO - 2022-09-29 02:36:55 --> Database Driver Class Initialized
DEBUG - 2022-09-29 02:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 02:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 02:36:56 --> Controller Class Initialized
DEBUG - 2022-09-29 02:36:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-29 02:36:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-29 02:36:56 --> Final output sent to browser
DEBUG - 2022-09-29 02:36:56 --> Total execution time: 0.0960
INFO - 2022-09-29 02:37:07 --> Config Class Initialized
INFO - 2022-09-29 02:37:07 --> Hooks Class Initialized
DEBUG - 2022-09-29 02:37:07 --> UTF-8 Support Enabled
INFO - 2022-09-29 02:37:07 --> Utf8 Class Initialized
INFO - 2022-09-29 02:37:07 --> URI Class Initialized
DEBUG - 2022-09-29 02:37:07 --> No URI present. Default controller set.
INFO - 2022-09-29 02:37:07 --> Router Class Initialized
INFO - 2022-09-29 02:37:07 --> Output Class Initialized
INFO - 2022-09-29 02:37:07 --> Security Class Initialized
DEBUG - 2022-09-29 02:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 02:37:07 --> Input Class Initialized
INFO - 2022-09-29 02:37:07 --> Language Class Initialized
INFO - 2022-09-29 02:37:07 --> Language Class Initialized
INFO - 2022-09-29 02:37:07 --> Config Class Initialized
INFO - 2022-09-29 02:37:07 --> Loader Class Initialized
INFO - 2022-09-29 02:37:07 --> Helper loaded: url_helper
INFO - 2022-09-29 02:37:07 --> Helper loaded: file_helper
INFO - 2022-09-29 02:37:07 --> Helper loaded: form_helper
INFO - 2022-09-29 02:37:07 --> Helper loaded: my_helper
INFO - 2022-09-29 02:37:07 --> Database Driver Class Initialized
DEBUG - 2022-09-29 02:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 02:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 02:37:07 --> Controller Class Initialized
INFO - 2022-09-29 02:37:07 --> Config Class Initialized
INFO - 2022-09-29 02:37:07 --> Hooks Class Initialized
DEBUG - 2022-09-29 02:37:07 --> UTF-8 Support Enabled
INFO - 2022-09-29 02:37:07 --> Utf8 Class Initialized
INFO - 2022-09-29 02:37:07 --> URI Class Initialized
INFO - 2022-09-29 02:37:07 --> Router Class Initialized
INFO - 2022-09-29 02:37:07 --> Output Class Initialized
INFO - 2022-09-29 02:37:07 --> Security Class Initialized
DEBUG - 2022-09-29 02:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 02:37:07 --> Input Class Initialized
INFO - 2022-09-29 02:37:07 --> Language Class Initialized
INFO - 2022-09-29 02:37:07 --> Language Class Initialized
INFO - 2022-09-29 02:37:07 --> Config Class Initialized
INFO - 2022-09-29 02:37:07 --> Loader Class Initialized
INFO - 2022-09-29 02:37:07 --> Helper loaded: url_helper
INFO - 2022-09-29 02:37:07 --> Helper loaded: file_helper
INFO - 2022-09-29 02:37:07 --> Helper loaded: form_helper
INFO - 2022-09-29 02:37:07 --> Helper loaded: my_helper
INFO - 2022-09-29 02:37:07 --> Database Driver Class Initialized
DEBUG - 2022-09-29 02:37:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 02:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 02:37:07 --> Controller Class Initialized
DEBUG - 2022-09-29 02:37:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-29 02:37:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-29 02:37:07 --> Final output sent to browser
DEBUG - 2022-09-29 02:37:07 --> Total execution time: 0.0512
INFO - 2022-09-29 03:52:45 --> Config Class Initialized
INFO - 2022-09-29 03:52:45 --> Hooks Class Initialized
DEBUG - 2022-09-29 03:52:45 --> UTF-8 Support Enabled
INFO - 2022-09-29 03:52:45 --> Utf8 Class Initialized
INFO - 2022-09-29 03:52:45 --> URI Class Initialized
DEBUG - 2022-09-29 03:52:45 --> No URI present. Default controller set.
INFO - 2022-09-29 03:52:45 --> Router Class Initialized
INFO - 2022-09-29 03:52:45 --> Output Class Initialized
INFO - 2022-09-29 03:52:45 --> Security Class Initialized
DEBUG - 2022-09-29 03:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 03:52:45 --> Input Class Initialized
INFO - 2022-09-29 03:52:45 --> Language Class Initialized
INFO - 2022-09-29 03:52:45 --> Language Class Initialized
INFO - 2022-09-29 03:52:45 --> Config Class Initialized
INFO - 2022-09-29 03:52:45 --> Loader Class Initialized
INFO - 2022-09-29 03:52:45 --> Helper loaded: url_helper
INFO - 2022-09-29 03:52:45 --> Helper loaded: file_helper
INFO - 2022-09-29 03:52:45 --> Helper loaded: form_helper
INFO - 2022-09-29 03:52:45 --> Helper loaded: my_helper
INFO - 2022-09-29 03:52:45 --> Database Driver Class Initialized
DEBUG - 2022-09-29 03:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 03:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 03:52:45 --> Controller Class Initialized
INFO - 2022-09-29 03:52:45 --> Config Class Initialized
INFO - 2022-09-29 03:52:45 --> Hooks Class Initialized
DEBUG - 2022-09-29 03:52:45 --> UTF-8 Support Enabled
INFO - 2022-09-29 03:52:45 --> Utf8 Class Initialized
INFO - 2022-09-29 03:52:45 --> URI Class Initialized
INFO - 2022-09-29 03:52:45 --> Router Class Initialized
INFO - 2022-09-29 03:52:45 --> Output Class Initialized
INFO - 2022-09-29 03:52:45 --> Security Class Initialized
DEBUG - 2022-09-29 03:52:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 03:52:45 --> Input Class Initialized
INFO - 2022-09-29 03:52:45 --> Language Class Initialized
INFO - 2022-09-29 03:52:45 --> Language Class Initialized
INFO - 2022-09-29 03:52:45 --> Config Class Initialized
INFO - 2022-09-29 03:52:45 --> Loader Class Initialized
INFO - 2022-09-29 03:52:45 --> Helper loaded: url_helper
INFO - 2022-09-29 03:52:45 --> Helper loaded: file_helper
INFO - 2022-09-29 03:52:45 --> Helper loaded: form_helper
INFO - 2022-09-29 03:52:45 --> Helper loaded: my_helper
INFO - 2022-09-29 03:52:45 --> Database Driver Class Initialized
DEBUG - 2022-09-29 03:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 03:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 03:52:45 --> Controller Class Initialized
DEBUG - 2022-09-29 03:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-29 03:52:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-29 03:52:45 --> Final output sent to browser
DEBUG - 2022-09-29 03:52:45 --> Total execution time: 0.0405
INFO - 2022-09-29 06:57:27 --> Config Class Initialized
INFO - 2022-09-29 06:57:27 --> Hooks Class Initialized
DEBUG - 2022-09-29 06:57:27 --> UTF-8 Support Enabled
INFO - 2022-09-29 06:57:27 --> Utf8 Class Initialized
INFO - 2022-09-29 06:57:27 --> URI Class Initialized
DEBUG - 2022-09-29 06:57:27 --> No URI present. Default controller set.
INFO - 2022-09-29 06:57:27 --> Router Class Initialized
INFO - 2022-09-29 06:57:27 --> Output Class Initialized
INFO - 2022-09-29 06:57:27 --> Security Class Initialized
DEBUG - 2022-09-29 06:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 06:57:27 --> Input Class Initialized
INFO - 2022-09-29 06:57:27 --> Language Class Initialized
INFO - 2022-09-29 06:57:27 --> Language Class Initialized
INFO - 2022-09-29 06:57:27 --> Config Class Initialized
INFO - 2022-09-29 06:57:27 --> Loader Class Initialized
INFO - 2022-09-29 06:57:27 --> Helper loaded: url_helper
INFO - 2022-09-29 06:57:27 --> Helper loaded: file_helper
INFO - 2022-09-29 06:57:27 --> Helper loaded: form_helper
INFO - 2022-09-29 06:57:27 --> Helper loaded: my_helper
INFO - 2022-09-29 06:57:27 --> Database Driver Class Initialized
DEBUG - 2022-09-29 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 06:57:28 --> Controller Class Initialized
INFO - 2022-09-29 06:57:28 --> Config Class Initialized
INFO - 2022-09-29 06:57:28 --> Hooks Class Initialized
DEBUG - 2022-09-29 06:57:28 --> UTF-8 Support Enabled
INFO - 2022-09-29 06:57:28 --> Utf8 Class Initialized
INFO - 2022-09-29 06:57:28 --> URI Class Initialized
INFO - 2022-09-29 06:57:28 --> Router Class Initialized
INFO - 2022-09-29 06:57:28 --> Output Class Initialized
INFO - 2022-09-29 06:57:28 --> Security Class Initialized
DEBUG - 2022-09-29 06:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-09-29 06:57:28 --> Input Class Initialized
INFO - 2022-09-29 06:57:28 --> Language Class Initialized
INFO - 2022-09-29 06:57:28 --> Language Class Initialized
INFO - 2022-09-29 06:57:28 --> Config Class Initialized
INFO - 2022-09-29 06:57:28 --> Loader Class Initialized
INFO - 2022-09-29 06:57:28 --> Helper loaded: url_helper
INFO - 2022-09-29 06:57:28 --> Helper loaded: file_helper
INFO - 2022-09-29 06:57:28 --> Helper loaded: form_helper
INFO - 2022-09-29 06:57:28 --> Helper loaded: my_helper
INFO - 2022-09-29 06:57:28 --> Database Driver Class Initialized
DEBUG - 2022-09-29 06:57:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-09-29 06:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-09-29 06:57:28 --> Controller Class Initialized
DEBUG - 2022-09-29 06:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-09-29 06:57:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-09-29 06:57:28 --> Final output sent to browser
DEBUG - 2022-09-29 06:57:28 --> Total execution time: 0.1075
