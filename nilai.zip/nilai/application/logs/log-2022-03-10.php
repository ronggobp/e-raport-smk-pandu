<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-03-10 04:01:41 --> Config Class Initialized
INFO - 2022-03-10 04:01:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:01:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:01:41 --> Utf8 Class Initialized
INFO - 2022-03-10 04:01:41 --> URI Class Initialized
DEBUG - 2022-03-10 04:01:41 --> No URI present. Default controller set.
INFO - 2022-03-10 04:01:41 --> Router Class Initialized
INFO - 2022-03-10 04:01:41 --> Output Class Initialized
INFO - 2022-03-10 04:01:41 --> Security Class Initialized
DEBUG - 2022-03-10 04:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:01:41 --> Input Class Initialized
INFO - 2022-03-10 04:01:41 --> Language Class Initialized
INFO - 2022-03-10 04:01:41 --> Language Class Initialized
INFO - 2022-03-10 04:01:41 --> Config Class Initialized
INFO - 2022-03-10 04:01:41 --> Loader Class Initialized
INFO - 2022-03-10 04:01:41 --> Helper loaded: url_helper
INFO - 2022-03-10 04:01:41 --> Helper loaded: file_helper
INFO - 2022-03-10 04:01:41 --> Helper loaded: form_helper
INFO - 2022-03-10 04:01:41 --> Helper loaded: my_helper
INFO - 2022-03-10 04:01:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:01:41 --> Controller Class Initialized
INFO - 2022-03-10 04:01:41 --> Config Class Initialized
INFO - 2022-03-10 04:01:41 --> Hooks Class Initialized
DEBUG - 2022-03-10 04:01:41 --> UTF-8 Support Enabled
INFO - 2022-03-10 04:01:41 --> Utf8 Class Initialized
INFO - 2022-03-10 04:01:41 --> URI Class Initialized
INFO - 2022-03-10 04:01:41 --> Router Class Initialized
INFO - 2022-03-10 04:01:41 --> Output Class Initialized
INFO - 2022-03-10 04:01:41 --> Security Class Initialized
DEBUG - 2022-03-10 04:01:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-03-10 04:01:41 --> Input Class Initialized
INFO - 2022-03-10 04:01:41 --> Language Class Initialized
INFO - 2022-03-10 04:01:41 --> Language Class Initialized
INFO - 2022-03-10 04:01:41 --> Config Class Initialized
INFO - 2022-03-10 04:01:41 --> Loader Class Initialized
INFO - 2022-03-10 04:01:41 --> Helper loaded: url_helper
INFO - 2022-03-10 04:01:41 --> Helper loaded: file_helper
INFO - 2022-03-10 04:01:41 --> Helper loaded: form_helper
INFO - 2022-03-10 04:01:41 --> Helper loaded: my_helper
INFO - 2022-03-10 04:01:41 --> Database Driver Class Initialized
DEBUG - 2022-03-10 04:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-03-10 04:01:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-03-10 04:01:41 --> Controller Class Initialized
DEBUG - 2022-03-10 04:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-03-10 04:01:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-03-10 04:01:42 --> Final output sent to browser
DEBUG - 2022-03-10 04:01:42 --> Total execution time: 0.1539
