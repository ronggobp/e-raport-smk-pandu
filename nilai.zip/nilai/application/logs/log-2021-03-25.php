<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-03-25 09:06:04 --> Config Class Initialized
INFO - 2021-03-25 09:06:04 --> Hooks Class Initialized
DEBUG - 2021-03-25 09:06:04 --> UTF-8 Support Enabled
INFO - 2021-03-25 09:06:04 --> Utf8 Class Initialized
INFO - 2021-03-25 09:06:04 --> URI Class Initialized
DEBUG - 2021-03-25 09:06:04 --> No URI present. Default controller set.
INFO - 2021-03-25 09:06:04 --> Router Class Initialized
INFO - 2021-03-25 09:06:04 --> Output Class Initialized
INFO - 2021-03-25 09:06:04 --> Security Class Initialized
DEBUG - 2021-03-25 09:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 09:06:04 --> Input Class Initialized
INFO - 2021-03-25 09:06:04 --> Language Class Initialized
INFO - 2021-03-25 09:06:04 --> Language Class Initialized
INFO - 2021-03-25 09:06:04 --> Config Class Initialized
INFO - 2021-03-25 09:06:04 --> Loader Class Initialized
INFO - 2021-03-25 09:06:04 --> Helper loaded: url_helper
INFO - 2021-03-25 09:06:04 --> Helper loaded: file_helper
INFO - 2021-03-25 09:06:04 --> Helper loaded: form_helper
INFO - 2021-03-25 09:06:04 --> Helper loaded: my_helper
INFO - 2021-03-25 09:06:04 --> Database Driver Class Initialized
DEBUG - 2021-03-25 09:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 09:06:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 09:06:04 --> Controller Class Initialized
INFO - 2021-03-25 09:06:04 --> Config Class Initialized
INFO - 2021-03-25 09:06:04 --> Hooks Class Initialized
DEBUG - 2021-03-25 09:06:04 --> UTF-8 Support Enabled
INFO - 2021-03-25 09:06:04 --> Utf8 Class Initialized
INFO - 2021-03-25 09:06:04 --> URI Class Initialized
INFO - 2021-03-25 09:06:04 --> Router Class Initialized
INFO - 2021-03-25 09:06:04 --> Output Class Initialized
INFO - 2021-03-25 09:06:04 --> Security Class Initialized
DEBUG - 2021-03-25 09:06:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-25 09:06:04 --> Input Class Initialized
INFO - 2021-03-25 09:06:04 --> Language Class Initialized
INFO - 2021-03-25 09:06:04 --> Language Class Initialized
INFO - 2021-03-25 09:06:05 --> Config Class Initialized
INFO - 2021-03-25 09:06:05 --> Loader Class Initialized
INFO - 2021-03-25 09:06:05 --> Helper loaded: url_helper
INFO - 2021-03-25 09:06:05 --> Helper loaded: file_helper
INFO - 2021-03-25 09:06:05 --> Helper loaded: form_helper
INFO - 2021-03-25 09:06:05 --> Helper loaded: my_helper
INFO - 2021-03-25 09:06:05 --> Database Driver Class Initialized
DEBUG - 2021-03-25 09:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-25 09:06:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-25 09:06:05 --> Controller Class Initialized
DEBUG - 2021-03-25 09:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-03-25 09:06:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-03-25 09:06:05 --> Final output sent to browser
DEBUG - 2021-03-25 09:06:05 --> Total execution time: 0.2691
