<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-25 01:29:27 --> Config Class Initialized
INFO - 2020-11-25 01:29:28 --> Hooks Class Initialized
DEBUG - 2020-11-25 01:29:28 --> UTF-8 Support Enabled
INFO - 2020-11-25 01:29:28 --> Utf8 Class Initialized
INFO - 2020-11-25 01:29:28 --> URI Class Initialized
DEBUG - 2020-11-25 01:29:28 --> No URI present. Default controller set.
INFO - 2020-11-25 01:29:28 --> Router Class Initialized
INFO - 2020-11-25 01:29:28 --> Output Class Initialized
INFO - 2020-11-25 01:29:28 --> Security Class Initialized
DEBUG - 2020-11-25 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 01:29:28 --> Input Class Initialized
INFO - 2020-11-25 01:29:28 --> Language Class Initialized
INFO - 2020-11-25 01:29:28 --> Language Class Initialized
INFO - 2020-11-25 01:29:28 --> Config Class Initialized
INFO - 2020-11-25 01:29:28 --> Loader Class Initialized
INFO - 2020-11-25 01:29:28 --> Helper loaded: url_helper
INFO - 2020-11-25 01:29:28 --> Helper loaded: file_helper
INFO - 2020-11-25 01:29:28 --> Helper loaded: form_helper
INFO - 2020-11-25 01:29:28 --> Helper loaded: my_helper
INFO - 2020-11-25 01:29:28 --> Database Driver Class Initialized
DEBUG - 2020-11-25 01:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 01:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 01:29:28 --> Controller Class Initialized
INFO - 2020-11-25 01:29:28 --> Config Class Initialized
INFO - 2020-11-25 01:29:28 --> Hooks Class Initialized
DEBUG - 2020-11-25 01:29:28 --> UTF-8 Support Enabled
INFO - 2020-11-25 01:29:28 --> Utf8 Class Initialized
INFO - 2020-11-25 01:29:28 --> URI Class Initialized
INFO - 2020-11-25 01:29:28 --> Router Class Initialized
INFO - 2020-11-25 01:29:28 --> Output Class Initialized
INFO - 2020-11-25 01:29:28 --> Security Class Initialized
DEBUG - 2020-11-25 01:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 01:29:28 --> Input Class Initialized
INFO - 2020-11-25 01:29:28 --> Language Class Initialized
INFO - 2020-11-25 01:29:28 --> Language Class Initialized
INFO - 2020-11-25 01:29:28 --> Config Class Initialized
INFO - 2020-11-25 01:29:28 --> Loader Class Initialized
INFO - 2020-11-25 01:29:28 --> Helper loaded: url_helper
INFO - 2020-11-25 01:29:28 --> Helper loaded: file_helper
INFO - 2020-11-25 01:29:28 --> Helper loaded: form_helper
INFO - 2020-11-25 01:29:28 --> Helper loaded: my_helper
INFO - 2020-11-25 01:29:28 --> Database Driver Class Initialized
DEBUG - 2020-11-25 01:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 01:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 01:29:28 --> Controller Class Initialized
DEBUG - 2020-11-25 01:29:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-25 01:29:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-25 01:29:28 --> Final output sent to browser
DEBUG - 2020-11-25 01:29:28 --> Total execution time: 0.2220
INFO - 2020-11-25 01:36:24 --> Config Class Initialized
INFO - 2020-11-25 01:36:24 --> Hooks Class Initialized
DEBUG - 2020-11-25 01:36:24 --> UTF-8 Support Enabled
INFO - 2020-11-25 01:36:24 --> Utf8 Class Initialized
INFO - 2020-11-25 01:36:24 --> URI Class Initialized
INFO - 2020-11-25 01:36:24 --> Router Class Initialized
INFO - 2020-11-25 01:36:24 --> Output Class Initialized
INFO - 2020-11-25 01:36:24 --> Security Class Initialized
DEBUG - 2020-11-25 01:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 01:36:24 --> Input Class Initialized
INFO - 2020-11-25 01:36:24 --> Language Class Initialized
INFO - 2020-11-25 01:36:24 --> Language Class Initialized
INFO - 2020-11-25 01:36:24 --> Config Class Initialized
INFO - 2020-11-25 01:36:24 --> Loader Class Initialized
INFO - 2020-11-25 01:36:24 --> Helper loaded: url_helper
INFO - 2020-11-25 01:36:24 --> Helper loaded: file_helper
INFO - 2020-11-25 01:36:24 --> Helper loaded: form_helper
INFO - 2020-11-25 01:36:24 --> Helper loaded: my_helper
INFO - 2020-11-25 01:36:24 --> Database Driver Class Initialized
DEBUG - 2020-11-25 01:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 01:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 01:36:24 --> Controller Class Initialized
INFO - 2020-11-25 01:36:24 --> Helper loaded: cookie_helper
INFO - 2020-11-25 01:36:24 --> Final output sent to browser
DEBUG - 2020-11-25 01:36:24 --> Total execution time: 0.3726
INFO - 2020-11-25 01:36:25 --> Config Class Initialized
INFO - 2020-11-25 01:36:25 --> Hooks Class Initialized
DEBUG - 2020-11-25 01:36:25 --> UTF-8 Support Enabled
INFO - 2020-11-25 01:36:25 --> Utf8 Class Initialized
INFO - 2020-11-25 01:36:25 --> URI Class Initialized
INFO - 2020-11-25 01:36:25 --> Router Class Initialized
INFO - 2020-11-25 01:36:25 --> Output Class Initialized
INFO - 2020-11-25 01:36:25 --> Security Class Initialized
DEBUG - 2020-11-25 01:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 01:36:25 --> Input Class Initialized
INFO - 2020-11-25 01:36:25 --> Language Class Initialized
INFO - 2020-11-25 01:36:25 --> Language Class Initialized
INFO - 2020-11-25 01:36:25 --> Config Class Initialized
INFO - 2020-11-25 01:36:25 --> Loader Class Initialized
INFO - 2020-11-25 01:36:25 --> Helper loaded: url_helper
INFO - 2020-11-25 01:36:25 --> Helper loaded: file_helper
INFO - 2020-11-25 01:36:25 --> Helper loaded: form_helper
INFO - 2020-11-25 01:36:25 --> Helper loaded: my_helper
INFO - 2020-11-25 01:36:25 --> Database Driver Class Initialized
DEBUG - 2020-11-25 01:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 01:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 01:36:25 --> Controller Class Initialized
DEBUG - 2020-11-25 01:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-25 01:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-25 01:36:25 --> Final output sent to browser
DEBUG - 2020-11-25 01:36:25 --> Total execution time: 0.3857
INFO - 2020-11-25 01:36:33 --> Config Class Initialized
INFO - 2020-11-25 01:36:33 --> Hooks Class Initialized
DEBUG - 2020-11-25 01:36:33 --> UTF-8 Support Enabled
INFO - 2020-11-25 01:36:33 --> Utf8 Class Initialized
INFO - 2020-11-25 01:36:33 --> URI Class Initialized
INFO - 2020-11-25 01:36:33 --> Router Class Initialized
INFO - 2020-11-25 01:36:33 --> Output Class Initialized
INFO - 2020-11-25 01:36:33 --> Security Class Initialized
DEBUG - 2020-11-25 01:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 01:36:33 --> Input Class Initialized
INFO - 2020-11-25 01:36:33 --> Language Class Initialized
INFO - 2020-11-25 01:36:33 --> Language Class Initialized
INFO - 2020-11-25 01:36:33 --> Config Class Initialized
INFO - 2020-11-25 01:36:33 --> Loader Class Initialized
INFO - 2020-11-25 01:36:33 --> Helper loaded: url_helper
INFO - 2020-11-25 01:36:33 --> Helper loaded: file_helper
INFO - 2020-11-25 01:36:33 --> Helper loaded: form_helper
INFO - 2020-11-25 01:36:33 --> Helper loaded: my_helper
INFO - 2020-11-25 01:36:33 --> Database Driver Class Initialized
DEBUG - 2020-11-25 01:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 01:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 01:36:33 --> Controller Class Initialized
DEBUG - 2020-11-25 01:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-25 01:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-25 01:36:33 --> Final output sent to browser
DEBUG - 2020-11-25 01:36:33 --> Total execution time: 0.3876
INFO - 2020-11-25 06:20:24 --> Config Class Initialized
INFO - 2020-11-25 06:20:24 --> Hooks Class Initialized
DEBUG - 2020-11-25 06:20:24 --> UTF-8 Support Enabled
INFO - 2020-11-25 06:20:24 --> Utf8 Class Initialized
INFO - 2020-11-25 06:20:24 --> URI Class Initialized
INFO - 2020-11-25 06:20:24 --> Router Class Initialized
INFO - 2020-11-25 06:20:24 --> Output Class Initialized
INFO - 2020-11-25 06:20:24 --> Security Class Initialized
DEBUG - 2020-11-25 06:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 06:20:24 --> Input Class Initialized
INFO - 2020-11-25 06:20:24 --> Language Class Initialized
INFO - 2020-11-25 06:20:24 --> Language Class Initialized
INFO - 2020-11-25 06:20:24 --> Config Class Initialized
INFO - 2020-11-25 06:20:24 --> Loader Class Initialized
INFO - 2020-11-25 06:20:24 --> Helper loaded: url_helper
INFO - 2020-11-25 06:20:24 --> Helper loaded: file_helper
INFO - 2020-11-25 06:20:24 --> Helper loaded: form_helper
INFO - 2020-11-25 06:20:24 --> Helper loaded: my_helper
INFO - 2020-11-25 06:20:24 --> Database Driver Class Initialized
DEBUG - 2020-11-25 06:20:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 06:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 06:20:24 --> Controller Class Initialized
INFO - 2020-11-25 06:20:24 --> Helper loaded: cookie_helper
INFO - 2020-11-25 06:20:24 --> Config Class Initialized
INFO - 2020-11-25 06:20:24 --> Hooks Class Initialized
DEBUG - 2020-11-25 06:20:24 --> UTF-8 Support Enabled
INFO - 2020-11-25 06:20:24 --> Utf8 Class Initialized
INFO - 2020-11-25 06:20:24 --> URI Class Initialized
INFO - 2020-11-25 06:20:24 --> Router Class Initialized
INFO - 2020-11-25 06:20:24 --> Output Class Initialized
INFO - 2020-11-25 06:20:24 --> Security Class Initialized
DEBUG - 2020-11-25 06:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 06:20:24 --> Input Class Initialized
INFO - 2020-11-25 06:20:25 --> Language Class Initialized
INFO - 2020-11-25 06:20:25 --> Language Class Initialized
INFO - 2020-11-25 06:20:25 --> Config Class Initialized
INFO - 2020-11-25 06:20:25 --> Loader Class Initialized
INFO - 2020-11-25 06:20:25 --> Helper loaded: url_helper
INFO - 2020-11-25 06:20:25 --> Helper loaded: file_helper
INFO - 2020-11-25 06:20:25 --> Helper loaded: form_helper
INFO - 2020-11-25 06:20:25 --> Helper loaded: my_helper
INFO - 2020-11-25 06:20:25 --> Database Driver Class Initialized
DEBUG - 2020-11-25 06:20:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 06:20:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 06:20:25 --> Controller Class Initialized
DEBUG - 2020-11-25 06:20:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-25 06:20:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-25 06:20:25 --> Final output sent to browser
DEBUG - 2020-11-25 06:20:25 --> Total execution time: 0.1963
INFO - 2020-11-25 08:15:27 --> Config Class Initialized
INFO - 2020-11-25 08:15:27 --> Hooks Class Initialized
DEBUG - 2020-11-25 08:15:27 --> UTF-8 Support Enabled
INFO - 2020-11-25 08:15:27 --> Utf8 Class Initialized
INFO - 2020-11-25 08:15:27 --> URI Class Initialized
INFO - 2020-11-25 08:15:27 --> Router Class Initialized
INFO - 2020-11-25 08:15:27 --> Output Class Initialized
INFO - 2020-11-25 08:15:27 --> Security Class Initialized
DEBUG - 2020-11-25 08:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 08:15:27 --> Input Class Initialized
INFO - 2020-11-25 08:15:27 --> Language Class Initialized
INFO - 2020-11-25 08:15:27 --> Language Class Initialized
INFO - 2020-11-25 08:15:27 --> Config Class Initialized
INFO - 2020-11-25 08:15:27 --> Loader Class Initialized
INFO - 2020-11-25 08:15:27 --> Helper loaded: url_helper
INFO - 2020-11-25 08:15:27 --> Helper loaded: file_helper
INFO - 2020-11-25 08:15:27 --> Helper loaded: form_helper
INFO - 2020-11-25 08:15:27 --> Helper loaded: my_helper
INFO - 2020-11-25 08:15:27 --> Database Driver Class Initialized
DEBUG - 2020-11-25 08:15:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 08:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 08:15:27 --> Controller Class Initialized
DEBUG - 2020-11-25 08:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-25 08:15:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-25 08:15:27 --> Final output sent to browser
DEBUG - 2020-11-25 08:15:27 --> Total execution time: 0.1924
INFO - 2020-11-25 08:35:04 --> Config Class Initialized
INFO - 2020-11-25 08:35:04 --> Hooks Class Initialized
DEBUG - 2020-11-25 08:35:04 --> UTF-8 Support Enabled
INFO - 2020-11-25 08:35:04 --> Utf8 Class Initialized
INFO - 2020-11-25 08:35:04 --> URI Class Initialized
INFO - 2020-11-25 08:35:04 --> Router Class Initialized
INFO - 2020-11-25 08:35:04 --> Output Class Initialized
INFO - 2020-11-25 08:35:04 --> Security Class Initialized
DEBUG - 2020-11-25 08:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 08:35:04 --> Input Class Initialized
INFO - 2020-11-25 08:35:04 --> Language Class Initialized
INFO - 2020-11-25 08:35:04 --> Language Class Initialized
INFO - 2020-11-25 08:35:04 --> Config Class Initialized
INFO - 2020-11-25 08:35:04 --> Loader Class Initialized
INFO - 2020-11-25 08:35:04 --> Helper loaded: url_helper
INFO - 2020-11-25 08:35:04 --> Helper loaded: file_helper
INFO - 2020-11-25 08:35:04 --> Helper loaded: form_helper
INFO - 2020-11-25 08:35:04 --> Helper loaded: my_helper
INFO - 2020-11-25 08:35:04 --> Database Driver Class Initialized
DEBUG - 2020-11-25 08:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 08:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 08:35:04 --> Controller Class Initialized
INFO - 2020-11-25 08:35:04 --> Helper loaded: cookie_helper
INFO - 2020-11-25 08:35:04 --> Final output sent to browser
DEBUG - 2020-11-25 08:35:04 --> Total execution time: 0.1698
INFO - 2020-11-25 08:35:04 --> Config Class Initialized
INFO - 2020-11-25 08:35:04 --> Hooks Class Initialized
DEBUG - 2020-11-25 08:35:04 --> UTF-8 Support Enabled
INFO - 2020-11-25 08:35:04 --> Utf8 Class Initialized
INFO - 2020-11-25 08:35:04 --> URI Class Initialized
INFO - 2020-11-25 08:35:04 --> Router Class Initialized
INFO - 2020-11-25 08:35:04 --> Output Class Initialized
INFO - 2020-11-25 08:35:04 --> Security Class Initialized
DEBUG - 2020-11-25 08:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 08:35:04 --> Input Class Initialized
INFO - 2020-11-25 08:35:04 --> Language Class Initialized
INFO - 2020-11-25 08:35:04 --> Language Class Initialized
INFO - 2020-11-25 08:35:04 --> Config Class Initialized
INFO - 2020-11-25 08:35:04 --> Loader Class Initialized
INFO - 2020-11-25 08:35:04 --> Helper loaded: url_helper
INFO - 2020-11-25 08:35:04 --> Helper loaded: file_helper
INFO - 2020-11-25 08:35:04 --> Helper loaded: form_helper
INFO - 2020-11-25 08:35:04 --> Helper loaded: my_helper
INFO - 2020-11-25 08:35:04 --> Database Driver Class Initialized
DEBUG - 2020-11-25 08:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 08:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 08:35:04 --> Controller Class Initialized
DEBUG - 2020-11-25 08:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-25 08:35:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-25 08:35:05 --> Final output sent to browser
DEBUG - 2020-11-25 08:35:05 --> Total execution time: 0.2719
INFO - 2020-11-25 08:35:09 --> Config Class Initialized
INFO - 2020-11-25 08:35:09 --> Hooks Class Initialized
DEBUG - 2020-11-25 08:35:09 --> UTF-8 Support Enabled
INFO - 2020-11-25 08:35:09 --> Utf8 Class Initialized
INFO - 2020-11-25 08:35:09 --> URI Class Initialized
INFO - 2020-11-25 08:35:09 --> Router Class Initialized
INFO - 2020-11-25 08:35:09 --> Output Class Initialized
INFO - 2020-11-25 08:35:09 --> Security Class Initialized
DEBUG - 2020-11-25 08:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-25 08:35:09 --> Input Class Initialized
INFO - 2020-11-25 08:35:09 --> Language Class Initialized
INFO - 2020-11-25 08:35:09 --> Language Class Initialized
INFO - 2020-11-25 08:35:09 --> Config Class Initialized
INFO - 2020-11-25 08:35:09 --> Loader Class Initialized
INFO - 2020-11-25 08:35:09 --> Helper loaded: url_helper
INFO - 2020-11-25 08:35:09 --> Helper loaded: file_helper
INFO - 2020-11-25 08:35:09 --> Helper loaded: form_helper
INFO - 2020-11-25 08:35:09 --> Helper loaded: my_helper
INFO - 2020-11-25 08:35:09 --> Database Driver Class Initialized
DEBUG - 2020-11-25 08:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-25 08:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-25 08:35:09 --> Controller Class Initialized
DEBUG - 2020-11-25 08:35:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-11-25 08:35:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-25 08:35:09 --> Final output sent to browser
DEBUG - 2020-11-25 08:35:09 --> Total execution time: 0.2132
