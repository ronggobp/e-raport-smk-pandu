<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-07-16 02:32:08 --> Config Class Initialized
INFO - 2021-07-16 02:32:08 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:08 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:08 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:08 --> URI Class Initialized
DEBUG - 2021-07-16 02:32:08 --> No URI present. Default controller set.
INFO - 2021-07-16 02:32:08 --> Router Class Initialized
INFO - 2021-07-16 02:32:08 --> Output Class Initialized
INFO - 2021-07-16 02:32:08 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:08 --> Input Class Initialized
INFO - 2021-07-16 02:32:08 --> Language Class Initialized
INFO - 2021-07-16 02:32:08 --> Language Class Initialized
INFO - 2021-07-16 02:32:08 --> Config Class Initialized
INFO - 2021-07-16 02:32:08 --> Loader Class Initialized
INFO - 2021-07-16 02:32:08 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:08 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:08 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:08 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:08 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:09 --> Controller Class Initialized
INFO - 2021-07-16 02:32:09 --> Config Class Initialized
INFO - 2021-07-16 02:32:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:09 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:09 --> URI Class Initialized
INFO - 2021-07-16 02:32:09 --> Router Class Initialized
INFO - 2021-07-16 02:32:09 --> Output Class Initialized
INFO - 2021-07-16 02:32:09 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:09 --> Input Class Initialized
INFO - 2021-07-16 02:32:09 --> Language Class Initialized
INFO - 2021-07-16 02:32:09 --> Language Class Initialized
INFO - 2021-07-16 02:32:09 --> Config Class Initialized
INFO - 2021-07-16 02:32:09 --> Loader Class Initialized
INFO - 2021-07-16 02:32:09 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:09 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:09 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:09 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:09 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 02:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:09 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:09 --> Total execution time: 0.0848
INFO - 2021-07-16 02:32:20 --> Config Class Initialized
INFO - 2021-07-16 02:32:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:20 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:20 --> URI Class Initialized
INFO - 2021-07-16 02:32:20 --> Router Class Initialized
INFO - 2021-07-16 02:32:20 --> Output Class Initialized
INFO - 2021-07-16 02:32:20 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:20 --> Input Class Initialized
INFO - 2021-07-16 02:32:20 --> Language Class Initialized
INFO - 2021-07-16 02:32:20 --> Language Class Initialized
INFO - 2021-07-16 02:32:20 --> Config Class Initialized
INFO - 2021-07-16 02:32:20 --> Loader Class Initialized
INFO - 2021-07-16 02:32:20 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:20 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:20 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:20 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:20 --> Controller Class Initialized
INFO - 2021-07-16 02:32:20 --> Helper loaded: cookie_helper
INFO - 2021-07-16 02:32:20 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:20 --> Total execution time: 0.1692
INFO - 2021-07-16 02:32:21 --> Config Class Initialized
INFO - 2021-07-16 02:32:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:21 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:21 --> URI Class Initialized
INFO - 2021-07-16 02:32:21 --> Router Class Initialized
INFO - 2021-07-16 02:32:21 --> Output Class Initialized
INFO - 2021-07-16 02:32:21 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:21 --> Input Class Initialized
INFO - 2021-07-16 02:32:21 --> Language Class Initialized
INFO - 2021-07-16 02:32:21 --> Language Class Initialized
INFO - 2021-07-16 02:32:21 --> Config Class Initialized
INFO - 2021-07-16 02:32:21 --> Loader Class Initialized
INFO - 2021-07-16 02:32:21 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:21 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:21 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:21 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:21 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 02:32:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:22 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:22 --> Total execution time: 1.4650
INFO - 2021-07-16 02:32:26 --> Config Class Initialized
INFO - 2021-07-16 02:32:26 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:26 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:26 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:26 --> URI Class Initialized
INFO - 2021-07-16 02:32:26 --> Router Class Initialized
INFO - 2021-07-16 02:32:26 --> Output Class Initialized
INFO - 2021-07-16 02:32:26 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:26 --> Input Class Initialized
INFO - 2021-07-16 02:32:26 --> Language Class Initialized
INFO - 2021-07-16 02:32:26 --> Language Class Initialized
INFO - 2021-07-16 02:32:26 --> Config Class Initialized
INFO - 2021-07-16 02:32:27 --> Loader Class Initialized
INFO - 2021-07-16 02:32:27 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:27 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:27 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:27 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:27 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-07-16 02:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:27 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:27 --> Total execution time: 0.6636
INFO - 2021-07-16 02:32:27 --> Config Class Initialized
INFO - 2021-07-16 02:32:27 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:27 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:27 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:27 --> URI Class Initialized
INFO - 2021-07-16 02:32:27 --> Router Class Initialized
INFO - 2021-07-16 02:32:27 --> Output Class Initialized
INFO - 2021-07-16 02:32:27 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:27 --> Input Class Initialized
INFO - 2021-07-16 02:32:27 --> Language Class Initialized
INFO - 2021-07-16 02:32:27 --> Language Class Initialized
INFO - 2021-07-16 02:32:27 --> Config Class Initialized
INFO - 2021-07-16 02:32:27 --> Loader Class Initialized
INFO - 2021-07-16 02:32:27 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:27 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:27 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:27 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:27 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 02:32:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:27 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:27 --> Total execution time: 0.1354
INFO - 2021-07-16 02:32:48 --> Config Class Initialized
INFO - 2021-07-16 02:32:48 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:48 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:48 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:48 --> URI Class Initialized
INFO - 2021-07-16 02:32:48 --> Router Class Initialized
INFO - 2021-07-16 02:32:48 --> Output Class Initialized
INFO - 2021-07-16 02:32:48 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:48 --> Input Class Initialized
INFO - 2021-07-16 02:32:48 --> Language Class Initialized
INFO - 2021-07-16 02:32:48 --> Language Class Initialized
INFO - 2021-07-16 02:32:48 --> Config Class Initialized
INFO - 2021-07-16 02:32:48 --> Loader Class Initialized
INFO - 2021-07-16 02:32:48 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:48 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:48 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:48 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:48 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:48 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-16 02:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:49 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:49 --> Total execution time: 0.1009
INFO - 2021-07-16 02:32:51 --> Config Class Initialized
INFO - 2021-07-16 02:32:51 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:51 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:51 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:51 --> URI Class Initialized
INFO - 2021-07-16 02:32:51 --> Router Class Initialized
INFO - 2021-07-16 02:32:51 --> Output Class Initialized
INFO - 2021-07-16 02:32:51 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:51 --> Input Class Initialized
INFO - 2021-07-16 02:32:51 --> Language Class Initialized
INFO - 2021-07-16 02:32:51 --> Language Class Initialized
INFO - 2021-07-16 02:32:51 --> Config Class Initialized
INFO - 2021-07-16 02:32:51 --> Loader Class Initialized
INFO - 2021-07-16 02:32:51 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:51 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:51 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:51 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:51 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:51 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 02:32:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:51 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:51 --> Total execution time: 0.0491
INFO - 2021-07-16 02:32:54 --> Config Class Initialized
INFO - 2021-07-16 02:32:54 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:54 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:54 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:54 --> URI Class Initialized
INFO - 2021-07-16 02:32:54 --> Router Class Initialized
INFO - 2021-07-16 02:32:54 --> Output Class Initialized
INFO - 2021-07-16 02:32:54 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:54 --> Input Class Initialized
INFO - 2021-07-16 02:32:54 --> Language Class Initialized
INFO - 2021-07-16 02:32:54 --> Language Class Initialized
INFO - 2021-07-16 02:32:54 --> Config Class Initialized
INFO - 2021-07-16 02:32:54 --> Loader Class Initialized
INFO - 2021-07-16 02:32:54 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:54 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:54 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:54 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:54 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:54 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-07-16 02:32:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:54 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:54 --> Total execution time: 0.0560
INFO - 2021-07-16 02:32:55 --> Config Class Initialized
INFO - 2021-07-16 02:32:55 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:55 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:55 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:55 --> URI Class Initialized
INFO - 2021-07-16 02:32:55 --> Router Class Initialized
INFO - 2021-07-16 02:32:55 --> Output Class Initialized
INFO - 2021-07-16 02:32:55 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:55 --> Input Class Initialized
INFO - 2021-07-16 02:32:55 --> Language Class Initialized
INFO - 2021-07-16 02:32:55 --> Language Class Initialized
INFO - 2021-07-16 02:32:55 --> Config Class Initialized
INFO - 2021-07-16 02:32:55 --> Loader Class Initialized
INFO - 2021-07-16 02:32:55 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:55 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:55 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:55 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:55 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:55 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-07-16 02:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:55 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:55 --> Total execution time: 0.0832
INFO - 2021-07-16 02:32:56 --> Config Class Initialized
INFO - 2021-07-16 02:32:56 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:56 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:56 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:56 --> URI Class Initialized
INFO - 2021-07-16 02:32:56 --> Router Class Initialized
INFO - 2021-07-16 02:32:56 --> Output Class Initialized
INFO - 2021-07-16 02:32:56 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:56 --> Input Class Initialized
INFO - 2021-07-16 02:32:56 --> Language Class Initialized
INFO - 2021-07-16 02:32:56 --> Language Class Initialized
INFO - 2021-07-16 02:32:56 --> Config Class Initialized
INFO - 2021-07-16 02:32:56 --> Loader Class Initialized
INFO - 2021-07-16 02:32:56 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:56 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:56 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:56 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:56 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:56 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-07-16 02:32:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:56 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:56 --> Total execution time: 0.1428
INFO - 2021-07-16 02:32:57 --> Config Class Initialized
INFO - 2021-07-16 02:32:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:32:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:32:57 --> Utf8 Class Initialized
INFO - 2021-07-16 02:32:57 --> URI Class Initialized
INFO - 2021-07-16 02:32:57 --> Router Class Initialized
INFO - 2021-07-16 02:32:57 --> Output Class Initialized
INFO - 2021-07-16 02:32:57 --> Security Class Initialized
DEBUG - 2021-07-16 02:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:32:57 --> Input Class Initialized
INFO - 2021-07-16 02:32:57 --> Language Class Initialized
INFO - 2021-07-16 02:32:58 --> Language Class Initialized
INFO - 2021-07-16 02:32:58 --> Config Class Initialized
INFO - 2021-07-16 02:32:58 --> Loader Class Initialized
INFO - 2021-07-16 02:32:58 --> Helper loaded: url_helper
INFO - 2021-07-16 02:32:58 --> Helper loaded: file_helper
INFO - 2021-07-16 02:32:58 --> Helper loaded: form_helper
INFO - 2021-07-16 02:32:58 --> Helper loaded: my_helper
INFO - 2021-07-16 02:32:58 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:32:58 --> Controller Class Initialized
DEBUG - 2021-07-16 02:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-07-16 02:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:32:58 --> Final output sent to browser
DEBUG - 2021-07-16 02:32:58 --> Total execution time: 0.0964
INFO - 2021-07-16 02:33:05 --> Config Class Initialized
INFO - 2021-07-16 02:33:05 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:33:05 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:33:05 --> Utf8 Class Initialized
INFO - 2021-07-16 02:33:05 --> URI Class Initialized
INFO - 2021-07-16 02:33:05 --> Router Class Initialized
INFO - 2021-07-16 02:33:05 --> Output Class Initialized
INFO - 2021-07-16 02:33:05 --> Security Class Initialized
DEBUG - 2021-07-16 02:33:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:33:05 --> Input Class Initialized
INFO - 2021-07-16 02:33:05 --> Language Class Initialized
INFO - 2021-07-16 02:33:05 --> Language Class Initialized
INFO - 2021-07-16 02:33:05 --> Config Class Initialized
INFO - 2021-07-16 02:33:05 --> Loader Class Initialized
INFO - 2021-07-16 02:33:05 --> Helper loaded: url_helper
INFO - 2021-07-16 02:33:05 --> Helper loaded: file_helper
INFO - 2021-07-16 02:33:05 --> Helper loaded: form_helper
INFO - 2021-07-16 02:33:05 --> Helper loaded: my_helper
INFO - 2021-07-16 02:33:05 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:33:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:33:05 --> Controller Class Initialized
DEBUG - 2021-07-16 02:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 02:33:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:33:05 --> Final output sent to browser
DEBUG - 2021-07-16 02:33:05 --> Total execution time: 0.0512
INFO - 2021-07-16 02:36:21 --> Config Class Initialized
INFO - 2021-07-16 02:36:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 02:36:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 02:36:21 --> Utf8 Class Initialized
INFO - 2021-07-16 02:36:21 --> URI Class Initialized
INFO - 2021-07-16 02:36:21 --> Router Class Initialized
INFO - 2021-07-16 02:36:21 --> Output Class Initialized
INFO - 2021-07-16 02:36:21 --> Security Class Initialized
DEBUG - 2021-07-16 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 02:36:21 --> Input Class Initialized
INFO - 2021-07-16 02:36:21 --> Language Class Initialized
INFO - 2021-07-16 02:36:21 --> Language Class Initialized
INFO - 2021-07-16 02:36:21 --> Config Class Initialized
INFO - 2021-07-16 02:36:21 --> Loader Class Initialized
INFO - 2021-07-16 02:36:21 --> Helper loaded: url_helper
INFO - 2021-07-16 02:36:21 --> Helper loaded: file_helper
INFO - 2021-07-16 02:36:21 --> Helper loaded: form_helper
INFO - 2021-07-16 02:36:21 --> Helper loaded: my_helper
INFO - 2021-07-16 02:36:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 02:36:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 02:36:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 02:36:21 --> Controller Class Initialized
DEBUG - 2021-07-16 02:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 02:36:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 02:36:21 --> Final output sent to browser
DEBUG - 2021-07-16 02:36:21 --> Total execution time: 0.0509
INFO - 2021-07-16 05:03:05 --> Config Class Initialized
INFO - 2021-07-16 05:03:05 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:03:05 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:03:05 --> Utf8 Class Initialized
INFO - 2021-07-16 05:03:05 --> URI Class Initialized
DEBUG - 2021-07-16 05:03:05 --> No URI present. Default controller set.
INFO - 2021-07-16 05:03:05 --> Router Class Initialized
INFO - 2021-07-16 05:03:05 --> Output Class Initialized
INFO - 2021-07-16 05:03:05 --> Security Class Initialized
DEBUG - 2021-07-16 05:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:03:05 --> Input Class Initialized
INFO - 2021-07-16 05:03:05 --> Language Class Initialized
INFO - 2021-07-16 05:03:05 --> Language Class Initialized
INFO - 2021-07-16 05:03:05 --> Config Class Initialized
INFO - 2021-07-16 05:03:05 --> Loader Class Initialized
INFO - 2021-07-16 05:03:05 --> Helper loaded: url_helper
INFO - 2021-07-16 05:03:05 --> Helper loaded: file_helper
INFO - 2021-07-16 05:03:05 --> Helper loaded: form_helper
INFO - 2021-07-16 05:03:05 --> Helper loaded: my_helper
INFO - 2021-07-16 05:03:05 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:03:06 --> Controller Class Initialized
INFO - 2021-07-16 05:03:06 --> Config Class Initialized
INFO - 2021-07-16 05:03:06 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:03:06 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:03:06 --> Utf8 Class Initialized
INFO - 2021-07-16 05:03:06 --> URI Class Initialized
INFO - 2021-07-16 05:03:06 --> Router Class Initialized
INFO - 2021-07-16 05:03:06 --> Output Class Initialized
INFO - 2021-07-16 05:03:06 --> Security Class Initialized
DEBUG - 2021-07-16 05:03:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:03:06 --> Input Class Initialized
INFO - 2021-07-16 05:03:06 --> Language Class Initialized
INFO - 2021-07-16 05:03:06 --> Language Class Initialized
INFO - 2021-07-16 05:03:06 --> Config Class Initialized
INFO - 2021-07-16 05:03:06 --> Loader Class Initialized
INFO - 2021-07-16 05:03:06 --> Helper loaded: url_helper
INFO - 2021-07-16 05:03:06 --> Helper loaded: file_helper
INFO - 2021-07-16 05:03:06 --> Helper loaded: form_helper
INFO - 2021-07-16 05:03:06 --> Helper loaded: my_helper
INFO - 2021-07-16 05:03:06 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:03:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:03:06 --> Controller Class Initialized
DEBUG - 2021-07-16 05:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 05:03:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:03:06 --> Final output sent to browser
DEBUG - 2021-07-16 05:03:06 --> Total execution time: 0.0968
INFO - 2021-07-16 05:03:25 --> Config Class Initialized
INFO - 2021-07-16 05:03:25 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:03:25 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:03:25 --> Utf8 Class Initialized
INFO - 2021-07-16 05:03:25 --> URI Class Initialized
INFO - 2021-07-16 05:03:25 --> Router Class Initialized
INFO - 2021-07-16 05:03:25 --> Output Class Initialized
INFO - 2021-07-16 05:03:25 --> Security Class Initialized
DEBUG - 2021-07-16 05:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:03:25 --> Input Class Initialized
INFO - 2021-07-16 05:03:25 --> Language Class Initialized
INFO - 2021-07-16 05:03:25 --> Language Class Initialized
INFO - 2021-07-16 05:03:25 --> Config Class Initialized
INFO - 2021-07-16 05:03:25 --> Loader Class Initialized
INFO - 2021-07-16 05:03:25 --> Helper loaded: url_helper
INFO - 2021-07-16 05:03:25 --> Helper loaded: file_helper
INFO - 2021-07-16 05:03:25 --> Helper loaded: form_helper
INFO - 2021-07-16 05:03:25 --> Helper loaded: my_helper
INFO - 2021-07-16 05:03:25 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:03:25 --> Controller Class Initialized
INFO - 2021-07-16 05:03:25 --> Helper loaded: cookie_helper
INFO - 2021-07-16 05:03:25 --> Final output sent to browser
DEBUG - 2021-07-16 05:03:25 --> Total execution time: 0.0882
INFO - 2021-07-16 05:03:27 --> Config Class Initialized
INFO - 2021-07-16 05:03:27 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:03:27 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:03:27 --> Utf8 Class Initialized
INFO - 2021-07-16 05:03:27 --> URI Class Initialized
INFO - 2021-07-16 05:03:27 --> Router Class Initialized
INFO - 2021-07-16 05:03:27 --> Output Class Initialized
INFO - 2021-07-16 05:03:27 --> Security Class Initialized
DEBUG - 2021-07-16 05:03:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:03:27 --> Input Class Initialized
INFO - 2021-07-16 05:03:27 --> Language Class Initialized
INFO - 2021-07-16 05:03:27 --> Language Class Initialized
INFO - 2021-07-16 05:03:27 --> Config Class Initialized
INFO - 2021-07-16 05:03:27 --> Loader Class Initialized
INFO - 2021-07-16 05:03:27 --> Helper loaded: url_helper
INFO - 2021-07-16 05:03:27 --> Helper loaded: file_helper
INFO - 2021-07-16 05:03:27 --> Helper loaded: form_helper
INFO - 2021-07-16 05:03:27 --> Helper loaded: my_helper
INFO - 2021-07-16 05:03:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:03:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:03:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:03:27 --> Controller Class Initialized
DEBUG - 2021-07-16 05:03:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 05:03:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:03:27 --> Final output sent to browser
DEBUG - 2021-07-16 05:03:27 --> Total execution time: 0.7973
INFO - 2021-07-16 05:03:30 --> Config Class Initialized
INFO - 2021-07-16 05:03:30 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:03:30 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:03:30 --> Utf8 Class Initialized
INFO - 2021-07-16 05:03:30 --> URI Class Initialized
INFO - 2021-07-16 05:03:30 --> Router Class Initialized
INFO - 2021-07-16 05:03:30 --> Output Class Initialized
INFO - 2021-07-16 05:03:30 --> Security Class Initialized
DEBUG - 2021-07-16 05:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:03:30 --> Input Class Initialized
INFO - 2021-07-16 05:03:30 --> Language Class Initialized
INFO - 2021-07-16 05:03:30 --> Language Class Initialized
INFO - 2021-07-16 05:03:30 --> Config Class Initialized
INFO - 2021-07-16 05:03:30 --> Loader Class Initialized
INFO - 2021-07-16 05:03:30 --> Helper loaded: url_helper
INFO - 2021-07-16 05:03:30 --> Helper loaded: file_helper
INFO - 2021-07-16 05:03:30 --> Helper loaded: form_helper
INFO - 2021-07-16 05:03:30 --> Helper loaded: my_helper
INFO - 2021-07-16 05:03:30 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:03:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:03:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:03:30 --> Controller Class Initialized
DEBUG - 2021-07-16 05:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 05:03:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:03:30 --> Final output sent to browser
DEBUG - 2021-07-16 05:03:30 --> Total execution time: 0.0747
INFO - 2021-07-16 05:03:32 --> Config Class Initialized
INFO - 2021-07-16 05:03:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:03:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:03:32 --> Utf8 Class Initialized
INFO - 2021-07-16 05:03:32 --> URI Class Initialized
INFO - 2021-07-16 05:03:32 --> Router Class Initialized
INFO - 2021-07-16 05:03:32 --> Output Class Initialized
INFO - 2021-07-16 05:03:32 --> Security Class Initialized
DEBUG - 2021-07-16 05:03:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:03:32 --> Input Class Initialized
INFO - 2021-07-16 05:03:32 --> Language Class Initialized
INFO - 2021-07-16 05:03:32 --> Language Class Initialized
INFO - 2021-07-16 05:03:32 --> Config Class Initialized
INFO - 2021-07-16 05:03:32 --> Loader Class Initialized
INFO - 2021-07-16 05:03:32 --> Helper loaded: url_helper
INFO - 2021-07-16 05:03:32 --> Helper loaded: file_helper
INFO - 2021-07-16 05:03:32 --> Helper loaded: form_helper
INFO - 2021-07-16 05:03:32 --> Helper loaded: my_helper
INFO - 2021-07-16 05:03:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:03:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:03:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:03:32 --> Controller Class Initialized
DEBUG - 2021-07-16 05:03:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-07-16 05:03:32 --> Final output sent to browser
DEBUG - 2021-07-16 05:03:32 --> Total execution time: 0.2612
INFO - 2021-07-16 05:03:54 --> Config Class Initialized
INFO - 2021-07-16 05:03:54 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:03:54 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:03:54 --> Utf8 Class Initialized
INFO - 2021-07-16 05:03:54 --> URI Class Initialized
INFO - 2021-07-16 05:03:54 --> Router Class Initialized
INFO - 2021-07-16 05:03:54 --> Output Class Initialized
INFO - 2021-07-16 05:03:54 --> Security Class Initialized
DEBUG - 2021-07-16 05:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:03:54 --> Input Class Initialized
INFO - 2021-07-16 05:03:54 --> Language Class Initialized
INFO - 2021-07-16 05:03:54 --> Language Class Initialized
INFO - 2021-07-16 05:03:54 --> Config Class Initialized
INFO - 2021-07-16 05:03:54 --> Loader Class Initialized
INFO - 2021-07-16 05:03:54 --> Helper loaded: url_helper
INFO - 2021-07-16 05:03:54 --> Helper loaded: file_helper
INFO - 2021-07-16 05:03:54 --> Helper loaded: form_helper
INFO - 2021-07-16 05:03:54 --> Helper loaded: my_helper
INFO - 2021-07-16 05:03:54 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:03:54 --> Controller Class Initialized
DEBUG - 2021-07-16 05:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 05:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:03:54 --> Final output sent to browser
DEBUG - 2021-07-16 05:03:54 --> Total execution time: 0.1191
INFO - 2021-07-16 05:05:28 --> Config Class Initialized
INFO - 2021-07-16 05:05:28 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:05:28 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:05:28 --> Utf8 Class Initialized
INFO - 2021-07-16 05:05:28 --> URI Class Initialized
INFO - 2021-07-16 05:05:28 --> Router Class Initialized
INFO - 2021-07-16 05:05:28 --> Output Class Initialized
INFO - 2021-07-16 05:05:28 --> Security Class Initialized
DEBUG - 2021-07-16 05:05:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:05:28 --> Input Class Initialized
INFO - 2021-07-16 05:05:28 --> Language Class Initialized
INFO - 2021-07-16 05:05:28 --> Language Class Initialized
INFO - 2021-07-16 05:05:28 --> Config Class Initialized
INFO - 2021-07-16 05:05:28 --> Loader Class Initialized
INFO - 2021-07-16 05:05:28 --> Helper loaded: url_helper
INFO - 2021-07-16 05:05:28 --> Helper loaded: file_helper
INFO - 2021-07-16 05:05:28 --> Helper loaded: form_helper
INFO - 2021-07-16 05:05:28 --> Helper loaded: my_helper
INFO - 2021-07-16 05:05:28 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:05:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:05:28 --> Controller Class Initialized
INFO - 2021-07-16 05:05:29 --> Final output sent to browser
DEBUG - 2021-07-16 05:05:29 --> Total execution time: 1.2443
INFO - 2021-07-16 05:05:40 --> Config Class Initialized
INFO - 2021-07-16 05:05:40 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:05:40 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:05:40 --> Utf8 Class Initialized
INFO - 2021-07-16 05:05:40 --> URI Class Initialized
INFO - 2021-07-16 05:05:40 --> Router Class Initialized
INFO - 2021-07-16 05:05:40 --> Output Class Initialized
INFO - 2021-07-16 05:05:40 --> Security Class Initialized
DEBUG - 2021-07-16 05:05:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:05:40 --> Input Class Initialized
INFO - 2021-07-16 05:05:40 --> Language Class Initialized
INFO - 2021-07-16 05:05:40 --> Language Class Initialized
INFO - 2021-07-16 05:05:40 --> Config Class Initialized
INFO - 2021-07-16 05:05:40 --> Loader Class Initialized
INFO - 2021-07-16 05:05:40 --> Helper loaded: url_helper
INFO - 2021-07-16 05:05:40 --> Helper loaded: file_helper
INFO - 2021-07-16 05:05:40 --> Helper loaded: form_helper
INFO - 2021-07-16 05:05:40 --> Helper loaded: my_helper
INFO - 2021-07-16 05:05:40 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:05:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:05:40 --> Controller Class Initialized
DEBUG - 2021-07-16 05:05:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 05:05:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:05:40 --> Final output sent to browser
DEBUG - 2021-07-16 05:05:40 --> Total execution time: 0.0537
INFO - 2021-07-16 05:05:41 --> Config Class Initialized
INFO - 2021-07-16 05:05:41 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:05:41 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:05:41 --> Utf8 Class Initialized
INFO - 2021-07-16 05:05:41 --> URI Class Initialized
INFO - 2021-07-16 05:05:41 --> Router Class Initialized
INFO - 2021-07-16 05:05:41 --> Output Class Initialized
INFO - 2021-07-16 05:05:41 --> Security Class Initialized
DEBUG - 2021-07-16 05:05:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:05:41 --> Input Class Initialized
INFO - 2021-07-16 05:05:41 --> Language Class Initialized
INFO - 2021-07-16 05:05:41 --> Language Class Initialized
INFO - 2021-07-16 05:05:41 --> Config Class Initialized
INFO - 2021-07-16 05:05:41 --> Loader Class Initialized
INFO - 2021-07-16 05:05:41 --> Helper loaded: url_helper
INFO - 2021-07-16 05:05:41 --> Helper loaded: file_helper
INFO - 2021-07-16 05:05:41 --> Helper loaded: form_helper
INFO - 2021-07-16 05:05:41 --> Helper loaded: my_helper
INFO - 2021-07-16 05:05:41 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:05:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:05:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:05:41 --> Controller Class Initialized
DEBUG - 2021-07-16 05:05:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-07-16 05:05:41 --> Final output sent to browser
DEBUG - 2021-07-16 05:05:41 --> Total execution time: 0.2121
INFO - 2021-07-16 05:05:49 --> Config Class Initialized
INFO - 2021-07-16 05:05:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:05:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:05:49 --> Utf8 Class Initialized
INFO - 2021-07-16 05:05:49 --> URI Class Initialized
INFO - 2021-07-16 05:05:49 --> Router Class Initialized
INFO - 2021-07-16 05:05:49 --> Output Class Initialized
INFO - 2021-07-16 05:05:49 --> Security Class Initialized
DEBUG - 2021-07-16 05:05:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:05:49 --> Input Class Initialized
INFO - 2021-07-16 05:05:49 --> Language Class Initialized
INFO - 2021-07-16 05:05:49 --> Language Class Initialized
INFO - 2021-07-16 05:05:49 --> Config Class Initialized
INFO - 2021-07-16 05:05:49 --> Loader Class Initialized
INFO - 2021-07-16 05:05:49 --> Helper loaded: url_helper
INFO - 2021-07-16 05:05:49 --> Helper loaded: file_helper
INFO - 2021-07-16 05:05:49 --> Helper loaded: form_helper
INFO - 2021-07-16 05:05:49 --> Helper loaded: my_helper
INFO - 2021-07-16 05:05:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:05:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:05:49 --> Controller Class Initialized
DEBUG - 2021-07-16 05:05:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_mm_xii.php
INFO - 2021-07-16 05:05:49 --> Final output sent to browser
DEBUG - 2021-07-16 05:05:49 --> Total execution time: 0.1801
INFO - 2021-07-16 05:13:14 --> Config Class Initialized
INFO - 2021-07-16 05:13:14 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:13:14 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:13:14 --> Utf8 Class Initialized
INFO - 2021-07-16 05:13:14 --> URI Class Initialized
INFO - 2021-07-16 05:13:14 --> Router Class Initialized
INFO - 2021-07-16 05:13:14 --> Output Class Initialized
INFO - 2021-07-16 05:13:14 --> Security Class Initialized
DEBUG - 2021-07-16 05:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:13:14 --> Input Class Initialized
INFO - 2021-07-16 05:13:14 --> Language Class Initialized
INFO - 2021-07-16 05:13:14 --> Language Class Initialized
INFO - 2021-07-16 05:13:14 --> Config Class Initialized
INFO - 2021-07-16 05:13:14 --> Loader Class Initialized
INFO - 2021-07-16 05:13:15 --> Helper loaded: url_helper
INFO - 2021-07-16 05:13:15 --> Helper loaded: file_helper
INFO - 2021-07-16 05:13:15 --> Helper loaded: form_helper
INFO - 2021-07-16 05:13:15 --> Helper loaded: my_helper
INFO - 2021-07-16 05:13:15 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:13:15 --> Controller Class Initialized
DEBUG - 2021-07-16 05:13:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-07-16 05:13:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:13:15 --> Final output sent to browser
DEBUG - 2021-07-16 05:13:15 --> Total execution time: 0.6832
INFO - 2021-07-16 05:13:18 --> Config Class Initialized
INFO - 2021-07-16 05:13:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:13:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:13:18 --> Utf8 Class Initialized
INFO - 2021-07-16 05:13:18 --> URI Class Initialized
INFO - 2021-07-16 05:13:18 --> Router Class Initialized
INFO - 2021-07-16 05:13:18 --> Output Class Initialized
INFO - 2021-07-16 05:13:18 --> Security Class Initialized
DEBUG - 2021-07-16 05:13:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:13:18 --> Input Class Initialized
INFO - 2021-07-16 05:13:18 --> Language Class Initialized
INFO - 2021-07-16 05:13:18 --> Language Class Initialized
INFO - 2021-07-16 05:13:18 --> Config Class Initialized
INFO - 2021-07-16 05:13:18 --> Loader Class Initialized
INFO - 2021-07-16 05:13:18 --> Helper loaded: url_helper
INFO - 2021-07-16 05:13:18 --> Helper loaded: file_helper
INFO - 2021-07-16 05:13:18 --> Helper loaded: form_helper
INFO - 2021-07-16 05:13:18 --> Helper loaded: my_helper
INFO - 2021-07-16 05:13:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:13:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:13:18 --> Controller Class Initialized
DEBUG - 2021-07-16 05:13:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-16 05:13:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:13:18 --> Final output sent to browser
DEBUG - 2021-07-16 05:13:18 --> Total execution time: 0.1025
INFO - 2021-07-16 05:23:09 --> Config Class Initialized
INFO - 2021-07-16 05:23:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:23:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:23:09 --> Utf8 Class Initialized
INFO - 2021-07-16 05:23:09 --> URI Class Initialized
INFO - 2021-07-16 05:23:09 --> Router Class Initialized
INFO - 2021-07-16 05:23:09 --> Output Class Initialized
INFO - 2021-07-16 05:23:09 --> Security Class Initialized
DEBUG - 2021-07-16 05:23:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:23:09 --> Input Class Initialized
INFO - 2021-07-16 05:23:09 --> Language Class Initialized
INFO - 2021-07-16 05:23:09 --> Language Class Initialized
INFO - 2021-07-16 05:23:09 --> Config Class Initialized
INFO - 2021-07-16 05:23:09 --> Loader Class Initialized
INFO - 2021-07-16 05:23:09 --> Helper loaded: url_helper
INFO - 2021-07-16 05:23:09 --> Helper loaded: file_helper
INFO - 2021-07-16 05:23:09 --> Helper loaded: form_helper
INFO - 2021-07-16 05:23:09 --> Helper loaded: my_helper
INFO - 2021-07-16 05:23:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:23:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:23:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:23:09 --> Controller Class Initialized
DEBUG - 2021-07-16 05:23:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pkl/views/list.php
DEBUG - 2021-07-16 05:23:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:23:09 --> Final output sent to browser
DEBUG - 2021-07-16 05:23:09 --> Total execution time: 0.0930
INFO - 2021-07-16 05:23:35 --> Config Class Initialized
INFO - 2021-07-16 05:23:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:23:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:23:35 --> Utf8 Class Initialized
INFO - 2021-07-16 05:23:35 --> URI Class Initialized
INFO - 2021-07-16 05:23:35 --> Router Class Initialized
INFO - 2021-07-16 05:23:35 --> Output Class Initialized
INFO - 2021-07-16 05:23:35 --> Security Class Initialized
DEBUG - 2021-07-16 05:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:23:35 --> Input Class Initialized
INFO - 2021-07-16 05:23:35 --> Language Class Initialized
INFO - 2021-07-16 05:23:35 --> Language Class Initialized
INFO - 2021-07-16 05:23:35 --> Config Class Initialized
INFO - 2021-07-16 05:23:35 --> Loader Class Initialized
INFO - 2021-07-16 05:23:35 --> Helper loaded: url_helper
INFO - 2021-07-16 05:23:35 --> Helper loaded: file_helper
INFO - 2021-07-16 05:23:35 --> Helper loaded: form_helper
INFO - 2021-07-16 05:23:35 --> Helper loaded: my_helper
INFO - 2021-07-16 05:23:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:23:35 --> Controller Class Initialized
DEBUG - 2021-07-16 05:23:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 05:23:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:23:35 --> Final output sent to browser
DEBUG - 2021-07-16 05:23:35 --> Total execution time: 0.1027
INFO - 2021-07-16 05:23:36 --> Config Class Initialized
INFO - 2021-07-16 05:23:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:23:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:23:36 --> Utf8 Class Initialized
INFO - 2021-07-16 05:23:36 --> URI Class Initialized
INFO - 2021-07-16 05:23:36 --> Router Class Initialized
INFO - 2021-07-16 05:23:36 --> Output Class Initialized
INFO - 2021-07-16 05:23:36 --> Security Class Initialized
DEBUG - 2021-07-16 05:23:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:23:36 --> Input Class Initialized
INFO - 2021-07-16 05:23:36 --> Language Class Initialized
INFO - 2021-07-16 05:23:36 --> Language Class Initialized
INFO - 2021-07-16 05:23:36 --> Config Class Initialized
INFO - 2021-07-16 05:23:36 --> Loader Class Initialized
INFO - 2021-07-16 05:23:36 --> Helper loaded: url_helper
INFO - 2021-07-16 05:23:36 --> Helper loaded: file_helper
INFO - 2021-07-16 05:23:36 --> Helper loaded: form_helper
INFO - 2021-07-16 05:23:36 --> Helper loaded: my_helper
INFO - 2021-07-16 05:23:36 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:23:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:23:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:23:36 --> Controller Class Initialized
DEBUG - 2021-07-16 05:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_ekstra/views/list.php
DEBUG - 2021-07-16 05:23:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:23:36 --> Final output sent to browser
DEBUG - 2021-07-16 05:23:36 --> Total execution time: 0.1144
INFO - 2021-07-16 05:23:38 --> Config Class Initialized
INFO - 2021-07-16 05:23:38 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:23:38 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:23:38 --> Utf8 Class Initialized
INFO - 2021-07-16 05:23:38 --> URI Class Initialized
INFO - 2021-07-16 05:23:38 --> Router Class Initialized
INFO - 2021-07-16 05:23:38 --> Output Class Initialized
INFO - 2021-07-16 05:23:38 --> Security Class Initialized
DEBUG - 2021-07-16 05:23:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:23:38 --> Input Class Initialized
INFO - 2021-07-16 05:23:38 --> Language Class Initialized
INFO - 2021-07-16 05:23:38 --> Language Class Initialized
INFO - 2021-07-16 05:23:38 --> Config Class Initialized
INFO - 2021-07-16 05:23:38 --> Loader Class Initialized
INFO - 2021-07-16 05:23:38 --> Helper loaded: url_helper
INFO - 2021-07-16 05:23:38 --> Helper loaded: file_helper
INFO - 2021-07-16 05:23:38 --> Helper loaded: form_helper
INFO - 2021-07-16 05:23:38 --> Helper loaded: my_helper
INFO - 2021-07-16 05:23:38 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:23:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:23:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:23:38 --> Controller Class Initialized
DEBUG - 2021-07-16 05:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_absensi/views/list.php
DEBUG - 2021-07-16 05:23:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:23:38 --> Final output sent to browser
DEBUG - 2021-07-16 05:23:38 --> Total execution time: 0.0965
INFO - 2021-07-16 05:23:40 --> Config Class Initialized
INFO - 2021-07-16 05:23:40 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:23:40 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:23:40 --> Utf8 Class Initialized
INFO - 2021-07-16 05:23:40 --> URI Class Initialized
INFO - 2021-07-16 05:23:40 --> Router Class Initialized
INFO - 2021-07-16 05:23:40 --> Output Class Initialized
INFO - 2021-07-16 05:23:40 --> Security Class Initialized
DEBUG - 2021-07-16 05:23:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:23:40 --> Input Class Initialized
INFO - 2021-07-16 05:23:40 --> Language Class Initialized
INFO - 2021-07-16 05:23:40 --> Language Class Initialized
INFO - 2021-07-16 05:23:40 --> Config Class Initialized
INFO - 2021-07-16 05:23:40 --> Loader Class Initialized
INFO - 2021-07-16 05:23:40 --> Helper loaded: url_helper
INFO - 2021-07-16 05:23:40 --> Helper loaded: file_helper
INFO - 2021-07-16 05:23:40 --> Helper loaded: form_helper
INFO - 2021-07-16 05:23:40 --> Helper loaded: my_helper
INFO - 2021-07-16 05:23:40 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:23:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:23:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:23:40 --> Controller Class Initialized
DEBUG - 2021-07-16 05:23:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2021-07-16 05:23:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:23:40 --> Final output sent to browser
DEBUG - 2021-07-16 05:23:40 --> Total execution time: 0.0820
INFO - 2021-07-16 05:23:42 --> Config Class Initialized
INFO - 2021-07-16 05:23:42 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:23:42 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:23:42 --> Utf8 Class Initialized
INFO - 2021-07-16 05:23:42 --> URI Class Initialized
INFO - 2021-07-16 05:23:42 --> Router Class Initialized
INFO - 2021-07-16 05:23:42 --> Output Class Initialized
INFO - 2021-07-16 05:23:42 --> Security Class Initialized
DEBUG - 2021-07-16 05:23:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:23:42 --> Input Class Initialized
INFO - 2021-07-16 05:23:42 --> Language Class Initialized
INFO - 2021-07-16 05:23:42 --> Language Class Initialized
INFO - 2021-07-16 05:23:42 --> Config Class Initialized
INFO - 2021-07-16 05:23:42 --> Loader Class Initialized
INFO - 2021-07-16 05:23:42 --> Helper loaded: url_helper
INFO - 2021-07-16 05:23:42 --> Helper loaded: file_helper
INFO - 2021-07-16 05:23:42 --> Helper loaded: form_helper
INFO - 2021-07-16 05:23:42 --> Helper loaded: my_helper
INFO - 2021-07-16 05:23:42 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:23:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:23:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:23:42 --> Controller Class Initialized
DEBUG - 2021-07-16 05:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/riwayat_mengajar/views/list.php
DEBUG - 2021-07-16 05:23:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:23:42 --> Final output sent to browser
DEBUG - 2021-07-16 05:23:42 --> Total execution time: 0.0875
INFO - 2021-07-16 05:27:39 --> Config Class Initialized
INFO - 2021-07-16 05:27:39 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:27:39 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:27:39 --> Utf8 Class Initialized
INFO - 2021-07-16 05:27:39 --> URI Class Initialized
INFO - 2021-07-16 05:27:39 --> Router Class Initialized
INFO - 2021-07-16 05:27:39 --> Output Class Initialized
INFO - 2021-07-16 05:27:39 --> Security Class Initialized
DEBUG - 2021-07-16 05:27:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:27:39 --> Input Class Initialized
INFO - 2021-07-16 05:27:39 --> Language Class Initialized
INFO - 2021-07-16 05:27:39 --> Language Class Initialized
INFO - 2021-07-16 05:27:39 --> Config Class Initialized
INFO - 2021-07-16 05:27:39 --> Loader Class Initialized
INFO - 2021-07-16 05:27:39 --> Helper loaded: url_helper
INFO - 2021-07-16 05:27:39 --> Helper loaded: file_helper
INFO - 2021-07-16 05:27:39 --> Helper loaded: form_helper
INFO - 2021-07-16 05:27:39 --> Helper loaded: my_helper
INFO - 2021-07-16 05:27:39 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:27:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:27:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:27:39 --> Controller Class Initialized
DEBUG - 2021-07-16 05:27:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-16 05:27:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:27:39 --> Final output sent to browser
DEBUG - 2021-07-16 05:27:39 --> Total execution time: 0.1137
INFO - 2021-07-16 05:27:59 --> Config Class Initialized
INFO - 2021-07-16 05:27:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:27:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:27:59 --> Utf8 Class Initialized
INFO - 2021-07-16 05:27:59 --> URI Class Initialized
INFO - 2021-07-16 05:27:59 --> Router Class Initialized
INFO - 2021-07-16 05:27:59 --> Output Class Initialized
INFO - 2021-07-16 05:27:59 --> Security Class Initialized
DEBUG - 2021-07-16 05:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:27:59 --> Input Class Initialized
INFO - 2021-07-16 05:27:59 --> Language Class Initialized
INFO - 2021-07-16 05:27:59 --> Language Class Initialized
INFO - 2021-07-16 05:27:59 --> Config Class Initialized
INFO - 2021-07-16 05:27:59 --> Loader Class Initialized
INFO - 2021-07-16 05:27:59 --> Helper loaded: url_helper
INFO - 2021-07-16 05:27:59 --> Helper loaded: file_helper
INFO - 2021-07-16 05:27:59 --> Helper loaded: form_helper
INFO - 2021-07-16 05:27:59 --> Helper loaded: my_helper
INFO - 2021-07-16 05:27:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:27:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:27:59 --> Controller Class Initialized
DEBUG - 2021-07-16 05:28:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:28:00 --> Final output sent to browser
DEBUG - 2021-07-16 05:28:00 --> Total execution time: 0.2062
INFO - 2021-07-16 05:28:33 --> Config Class Initialized
INFO - 2021-07-16 05:28:33 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:28:33 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:28:33 --> Utf8 Class Initialized
INFO - 2021-07-16 05:28:33 --> URI Class Initialized
INFO - 2021-07-16 05:28:33 --> Router Class Initialized
INFO - 2021-07-16 05:28:33 --> Output Class Initialized
INFO - 2021-07-16 05:28:33 --> Security Class Initialized
DEBUG - 2021-07-16 05:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:28:33 --> Input Class Initialized
INFO - 2021-07-16 05:28:33 --> Language Class Initialized
INFO - 2021-07-16 05:28:33 --> Language Class Initialized
INFO - 2021-07-16 05:28:33 --> Config Class Initialized
INFO - 2021-07-16 05:28:33 --> Loader Class Initialized
INFO - 2021-07-16 05:28:33 --> Helper loaded: url_helper
INFO - 2021-07-16 05:28:33 --> Helper loaded: file_helper
INFO - 2021-07-16 05:28:33 --> Helper loaded: form_helper
INFO - 2021-07-16 05:28:33 --> Helper loaded: my_helper
INFO - 2021-07-16 05:28:33 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:28:33 --> Controller Class Initialized
DEBUG - 2021-07-16 05:28:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:28:33 --> Final output sent to browser
DEBUG - 2021-07-16 05:28:33 --> Total execution time: 0.1347
INFO - 2021-07-16 05:29:55 --> Config Class Initialized
INFO - 2021-07-16 05:29:55 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:29:55 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:29:55 --> Utf8 Class Initialized
INFO - 2021-07-16 05:29:55 --> URI Class Initialized
INFO - 2021-07-16 05:29:55 --> Router Class Initialized
INFO - 2021-07-16 05:29:55 --> Output Class Initialized
INFO - 2021-07-16 05:29:55 --> Security Class Initialized
DEBUG - 2021-07-16 05:29:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:29:55 --> Input Class Initialized
INFO - 2021-07-16 05:29:55 --> Language Class Initialized
INFO - 2021-07-16 05:29:55 --> Language Class Initialized
INFO - 2021-07-16 05:29:55 --> Config Class Initialized
INFO - 2021-07-16 05:29:55 --> Loader Class Initialized
INFO - 2021-07-16 05:29:55 --> Helper loaded: url_helper
INFO - 2021-07-16 05:29:55 --> Helper loaded: file_helper
INFO - 2021-07-16 05:29:55 --> Helper loaded: form_helper
INFO - 2021-07-16 05:29:55 --> Helper loaded: my_helper
INFO - 2021-07-16 05:29:55 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:29:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:29:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:29:55 --> Controller Class Initialized
DEBUG - 2021-07-16 05:29:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:29:55 --> Final output sent to browser
DEBUG - 2021-07-16 05:29:55 --> Total execution time: 0.1265
INFO - 2021-07-16 05:29:58 --> Config Class Initialized
INFO - 2021-07-16 05:29:58 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:29:58 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:29:58 --> Utf8 Class Initialized
INFO - 2021-07-16 05:29:58 --> URI Class Initialized
INFO - 2021-07-16 05:29:58 --> Router Class Initialized
INFO - 2021-07-16 05:29:58 --> Output Class Initialized
INFO - 2021-07-16 05:29:58 --> Security Class Initialized
DEBUG - 2021-07-16 05:29:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:29:58 --> Input Class Initialized
INFO - 2021-07-16 05:29:58 --> Language Class Initialized
INFO - 2021-07-16 05:29:58 --> Language Class Initialized
INFO - 2021-07-16 05:29:58 --> Config Class Initialized
INFO - 2021-07-16 05:29:58 --> Loader Class Initialized
INFO - 2021-07-16 05:29:58 --> Helper loaded: url_helper
INFO - 2021-07-16 05:29:58 --> Helper loaded: file_helper
INFO - 2021-07-16 05:29:58 --> Helper loaded: form_helper
INFO - 2021-07-16 05:29:58 --> Helper loaded: my_helper
INFO - 2021-07-16 05:29:58 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:29:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:29:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:29:58 --> Controller Class Initialized
DEBUG - 2021-07-16 05:29:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xi.php
INFO - 2021-07-16 05:29:59 --> Final output sent to browser
DEBUG - 2021-07-16 05:29:59 --> Total execution time: 0.1814
INFO - 2021-07-16 05:30:06 --> Config Class Initialized
INFO - 2021-07-16 05:30:06 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:30:06 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:30:06 --> Utf8 Class Initialized
INFO - 2021-07-16 05:30:06 --> URI Class Initialized
INFO - 2021-07-16 05:30:06 --> Router Class Initialized
INFO - 2021-07-16 05:30:06 --> Output Class Initialized
INFO - 2021-07-16 05:30:06 --> Security Class Initialized
DEBUG - 2021-07-16 05:30:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:30:06 --> Input Class Initialized
INFO - 2021-07-16 05:30:06 --> Language Class Initialized
INFO - 2021-07-16 05:30:06 --> Language Class Initialized
INFO - 2021-07-16 05:30:06 --> Config Class Initialized
INFO - 2021-07-16 05:30:06 --> Loader Class Initialized
INFO - 2021-07-16 05:30:06 --> Helper loaded: url_helper
INFO - 2021-07-16 05:30:06 --> Helper loaded: file_helper
INFO - 2021-07-16 05:30:06 --> Helper loaded: form_helper
INFO - 2021-07-16 05:30:06 --> Helper loaded: my_helper
INFO - 2021-07-16 05:30:06 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:30:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:30:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:30:06 --> Controller Class Initialized
DEBUG - 2021-07-16 05:30:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:30:06 --> Final output sent to browser
DEBUG - 2021-07-16 05:30:06 --> Total execution time: 0.1199
INFO - 2021-07-16 05:30:27 --> Config Class Initialized
INFO - 2021-07-16 05:30:27 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:30:27 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:30:27 --> Utf8 Class Initialized
INFO - 2021-07-16 05:30:27 --> URI Class Initialized
INFO - 2021-07-16 05:30:27 --> Router Class Initialized
INFO - 2021-07-16 05:30:27 --> Output Class Initialized
INFO - 2021-07-16 05:30:27 --> Security Class Initialized
DEBUG - 2021-07-16 05:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:30:27 --> Input Class Initialized
INFO - 2021-07-16 05:30:27 --> Language Class Initialized
INFO - 2021-07-16 05:30:27 --> Language Class Initialized
INFO - 2021-07-16 05:30:27 --> Config Class Initialized
INFO - 2021-07-16 05:30:27 --> Loader Class Initialized
INFO - 2021-07-16 05:30:27 --> Helper loaded: url_helper
INFO - 2021-07-16 05:30:27 --> Helper loaded: file_helper
INFO - 2021-07-16 05:30:27 --> Helper loaded: form_helper
INFO - 2021-07-16 05:30:27 --> Helper loaded: my_helper
INFO - 2021-07-16 05:30:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:30:27 --> Controller Class Initialized
DEBUG - 2021-07-16 05:30:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:30:27 --> Final output sent to browser
DEBUG - 2021-07-16 05:30:27 --> Total execution time: 0.1262
INFO - 2021-07-16 05:31:14 --> Config Class Initialized
INFO - 2021-07-16 05:31:14 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:31:14 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:31:14 --> Utf8 Class Initialized
INFO - 2021-07-16 05:31:14 --> URI Class Initialized
INFO - 2021-07-16 05:31:14 --> Router Class Initialized
INFO - 2021-07-16 05:31:14 --> Output Class Initialized
INFO - 2021-07-16 05:31:14 --> Security Class Initialized
DEBUG - 2021-07-16 05:31:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:31:14 --> Input Class Initialized
INFO - 2021-07-16 05:31:14 --> Language Class Initialized
INFO - 2021-07-16 05:31:14 --> Language Class Initialized
INFO - 2021-07-16 05:31:14 --> Config Class Initialized
INFO - 2021-07-16 05:31:14 --> Loader Class Initialized
INFO - 2021-07-16 05:31:14 --> Helper loaded: url_helper
INFO - 2021-07-16 05:31:14 --> Helper loaded: file_helper
INFO - 2021-07-16 05:31:14 --> Helper loaded: form_helper
INFO - 2021-07-16 05:31:14 --> Helper loaded: my_helper
INFO - 2021-07-16 05:31:14 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:31:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:31:14 --> Controller Class Initialized
DEBUG - 2021-07-16 05:31:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:31:14 --> Final output sent to browser
DEBUG - 2021-07-16 05:31:14 --> Total execution time: 0.1228
INFO - 2021-07-16 05:31:32 --> Config Class Initialized
INFO - 2021-07-16 05:31:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:31:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:31:32 --> Utf8 Class Initialized
INFO - 2021-07-16 05:31:32 --> URI Class Initialized
INFO - 2021-07-16 05:31:32 --> Router Class Initialized
INFO - 2021-07-16 05:31:32 --> Output Class Initialized
INFO - 2021-07-16 05:31:32 --> Security Class Initialized
DEBUG - 2021-07-16 05:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:31:32 --> Input Class Initialized
INFO - 2021-07-16 05:31:32 --> Language Class Initialized
INFO - 2021-07-16 05:31:32 --> Language Class Initialized
INFO - 2021-07-16 05:31:32 --> Config Class Initialized
INFO - 2021-07-16 05:31:32 --> Loader Class Initialized
INFO - 2021-07-16 05:31:32 --> Helper loaded: url_helper
INFO - 2021-07-16 05:31:32 --> Helper loaded: file_helper
INFO - 2021-07-16 05:31:32 --> Helper loaded: form_helper
INFO - 2021-07-16 05:31:32 --> Helper loaded: my_helper
INFO - 2021-07-16 05:31:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:31:32 --> Controller Class Initialized
DEBUG - 2021-07-16 05:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:31:32 --> Final output sent to browser
DEBUG - 2021-07-16 05:31:32 --> Total execution time: 0.1264
INFO - 2021-07-16 05:32:09 --> Config Class Initialized
INFO - 2021-07-16 05:32:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:32:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:32:09 --> Utf8 Class Initialized
INFO - 2021-07-16 05:32:09 --> URI Class Initialized
INFO - 2021-07-16 05:32:09 --> Router Class Initialized
INFO - 2021-07-16 05:32:09 --> Output Class Initialized
INFO - 2021-07-16 05:32:09 --> Security Class Initialized
DEBUG - 2021-07-16 05:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:32:09 --> Input Class Initialized
INFO - 2021-07-16 05:32:09 --> Language Class Initialized
INFO - 2021-07-16 05:32:09 --> Language Class Initialized
INFO - 2021-07-16 05:32:09 --> Config Class Initialized
INFO - 2021-07-16 05:32:09 --> Loader Class Initialized
INFO - 2021-07-16 05:32:09 --> Helper loaded: url_helper
INFO - 2021-07-16 05:32:09 --> Helper loaded: file_helper
INFO - 2021-07-16 05:32:09 --> Helper loaded: form_helper
INFO - 2021-07-16 05:32:09 --> Helper loaded: my_helper
INFO - 2021-07-16 05:32:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:32:09 --> Controller Class Initialized
DEBUG - 2021-07-16 05:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:32:09 --> Final output sent to browser
DEBUG - 2021-07-16 05:32:09 --> Total execution time: 0.1221
INFO - 2021-07-16 05:32:36 --> Config Class Initialized
INFO - 2021-07-16 05:32:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:32:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:32:36 --> Utf8 Class Initialized
INFO - 2021-07-16 05:32:36 --> URI Class Initialized
INFO - 2021-07-16 05:32:36 --> Router Class Initialized
INFO - 2021-07-16 05:32:36 --> Output Class Initialized
INFO - 2021-07-16 05:32:36 --> Security Class Initialized
DEBUG - 2021-07-16 05:32:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:32:36 --> Input Class Initialized
INFO - 2021-07-16 05:32:36 --> Language Class Initialized
INFO - 2021-07-16 05:32:36 --> Language Class Initialized
INFO - 2021-07-16 05:32:36 --> Config Class Initialized
INFO - 2021-07-16 05:32:36 --> Loader Class Initialized
INFO - 2021-07-16 05:32:36 --> Helper loaded: url_helper
INFO - 2021-07-16 05:32:36 --> Helper loaded: file_helper
INFO - 2021-07-16 05:32:36 --> Helper loaded: form_helper
INFO - 2021-07-16 05:32:36 --> Helper loaded: my_helper
INFO - 2021-07-16 05:32:36 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:32:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:32:36 --> Controller Class Initialized
DEBUG - 2021-07-16 05:32:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:32:36 --> Final output sent to browser
DEBUG - 2021-07-16 05:32:36 --> Total execution time: 0.1216
INFO - 2021-07-16 05:33:14 --> Config Class Initialized
INFO - 2021-07-16 05:33:14 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:33:14 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:33:14 --> Utf8 Class Initialized
INFO - 2021-07-16 05:33:14 --> URI Class Initialized
INFO - 2021-07-16 05:33:14 --> Router Class Initialized
INFO - 2021-07-16 05:33:14 --> Output Class Initialized
INFO - 2021-07-16 05:33:14 --> Security Class Initialized
DEBUG - 2021-07-16 05:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:33:14 --> Input Class Initialized
INFO - 2021-07-16 05:33:14 --> Language Class Initialized
INFO - 2021-07-16 05:33:14 --> Language Class Initialized
INFO - 2021-07-16 05:33:14 --> Config Class Initialized
INFO - 2021-07-16 05:33:14 --> Loader Class Initialized
INFO - 2021-07-16 05:33:14 --> Helper loaded: url_helper
INFO - 2021-07-16 05:33:14 --> Helper loaded: file_helper
INFO - 2021-07-16 05:33:14 --> Helper loaded: form_helper
INFO - 2021-07-16 05:33:14 --> Helper loaded: my_helper
INFO - 2021-07-16 05:33:14 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:33:14 --> Controller Class Initialized
DEBUG - 2021-07-16 05:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:33:14 --> Final output sent to browser
DEBUG - 2021-07-16 05:33:14 --> Total execution time: 0.1217
INFO - 2021-07-16 05:33:51 --> Config Class Initialized
INFO - 2021-07-16 05:33:51 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:33:51 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:33:51 --> Utf8 Class Initialized
INFO - 2021-07-16 05:33:51 --> URI Class Initialized
INFO - 2021-07-16 05:33:51 --> Router Class Initialized
INFO - 2021-07-16 05:33:51 --> Output Class Initialized
INFO - 2021-07-16 05:33:51 --> Security Class Initialized
DEBUG - 2021-07-16 05:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:33:51 --> Input Class Initialized
INFO - 2021-07-16 05:33:51 --> Language Class Initialized
INFO - 2021-07-16 05:33:51 --> Language Class Initialized
INFO - 2021-07-16 05:33:51 --> Config Class Initialized
INFO - 2021-07-16 05:33:51 --> Loader Class Initialized
INFO - 2021-07-16 05:33:51 --> Helper loaded: url_helper
INFO - 2021-07-16 05:33:51 --> Helper loaded: file_helper
INFO - 2021-07-16 05:33:51 --> Helper loaded: form_helper
INFO - 2021-07-16 05:33:51 --> Helper loaded: my_helper
INFO - 2021-07-16 05:33:51 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:33:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:33:51 --> Controller Class Initialized
DEBUG - 2021-07-16 05:33:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:33:51 --> Final output sent to browser
DEBUG - 2021-07-16 05:33:51 --> Total execution time: 0.1234
INFO - 2021-07-16 05:34:17 --> Config Class Initialized
INFO - 2021-07-16 05:34:17 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:34:17 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:34:17 --> Utf8 Class Initialized
INFO - 2021-07-16 05:34:17 --> URI Class Initialized
INFO - 2021-07-16 05:34:17 --> Router Class Initialized
INFO - 2021-07-16 05:34:17 --> Output Class Initialized
INFO - 2021-07-16 05:34:17 --> Security Class Initialized
DEBUG - 2021-07-16 05:34:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:34:17 --> Input Class Initialized
INFO - 2021-07-16 05:34:17 --> Language Class Initialized
INFO - 2021-07-16 05:34:17 --> Language Class Initialized
INFO - 2021-07-16 05:34:17 --> Config Class Initialized
INFO - 2021-07-16 05:34:17 --> Loader Class Initialized
INFO - 2021-07-16 05:34:17 --> Helper loaded: url_helper
INFO - 2021-07-16 05:34:17 --> Helper loaded: file_helper
INFO - 2021-07-16 05:34:17 --> Helper loaded: form_helper
INFO - 2021-07-16 05:34:17 --> Helper loaded: my_helper
INFO - 2021-07-16 05:34:17 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:34:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:34:17 --> Controller Class Initialized
DEBUG - 2021-07-16 05:34:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:34:17 --> Final output sent to browser
DEBUG - 2021-07-16 05:34:17 --> Total execution time: 0.1195
INFO - 2021-07-16 05:34:50 --> Config Class Initialized
INFO - 2021-07-16 05:34:50 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:34:50 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:34:50 --> Utf8 Class Initialized
INFO - 2021-07-16 05:34:50 --> URI Class Initialized
INFO - 2021-07-16 05:34:50 --> Router Class Initialized
INFO - 2021-07-16 05:34:50 --> Output Class Initialized
INFO - 2021-07-16 05:34:50 --> Security Class Initialized
DEBUG - 2021-07-16 05:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:34:50 --> Input Class Initialized
INFO - 2021-07-16 05:34:50 --> Language Class Initialized
INFO - 2021-07-16 05:34:50 --> Language Class Initialized
INFO - 2021-07-16 05:34:50 --> Config Class Initialized
INFO - 2021-07-16 05:34:50 --> Loader Class Initialized
INFO - 2021-07-16 05:34:50 --> Helper loaded: url_helper
INFO - 2021-07-16 05:34:50 --> Helper loaded: file_helper
INFO - 2021-07-16 05:34:50 --> Helper loaded: form_helper
INFO - 2021-07-16 05:34:50 --> Helper loaded: my_helper
INFO - 2021-07-16 05:34:50 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:34:50 --> Controller Class Initialized
DEBUG - 2021-07-16 05:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:34:50 --> Final output sent to browser
DEBUG - 2021-07-16 05:34:50 --> Total execution time: 0.1240
INFO - 2021-07-16 05:35:08 --> Config Class Initialized
INFO - 2021-07-16 05:35:08 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:35:08 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:35:08 --> Utf8 Class Initialized
INFO - 2021-07-16 05:35:08 --> URI Class Initialized
INFO - 2021-07-16 05:35:08 --> Router Class Initialized
INFO - 2021-07-16 05:35:08 --> Output Class Initialized
INFO - 2021-07-16 05:35:08 --> Security Class Initialized
DEBUG - 2021-07-16 05:35:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:35:08 --> Input Class Initialized
INFO - 2021-07-16 05:35:08 --> Language Class Initialized
INFO - 2021-07-16 05:35:08 --> Language Class Initialized
INFO - 2021-07-16 05:35:08 --> Config Class Initialized
INFO - 2021-07-16 05:35:08 --> Loader Class Initialized
INFO - 2021-07-16 05:35:08 --> Helper loaded: url_helper
INFO - 2021-07-16 05:35:08 --> Helper loaded: file_helper
INFO - 2021-07-16 05:35:08 --> Helper loaded: form_helper
INFO - 2021-07-16 05:35:08 --> Helper loaded: my_helper
INFO - 2021-07-16 05:35:08 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:35:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:35:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:35:08 --> Controller Class Initialized
DEBUG - 2021-07-16 05:35:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:35:08 --> Final output sent to browser
DEBUG - 2021-07-16 05:35:08 --> Total execution time: 0.1265
INFO - 2021-07-16 05:35:39 --> Config Class Initialized
INFO - 2021-07-16 05:35:39 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:35:39 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:35:39 --> Utf8 Class Initialized
INFO - 2021-07-16 05:35:39 --> URI Class Initialized
INFO - 2021-07-16 05:35:39 --> Router Class Initialized
INFO - 2021-07-16 05:35:39 --> Output Class Initialized
INFO - 2021-07-16 05:35:39 --> Security Class Initialized
DEBUG - 2021-07-16 05:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:35:39 --> Input Class Initialized
INFO - 2021-07-16 05:35:39 --> Language Class Initialized
INFO - 2021-07-16 05:35:39 --> Language Class Initialized
INFO - 2021-07-16 05:35:39 --> Config Class Initialized
INFO - 2021-07-16 05:35:39 --> Loader Class Initialized
INFO - 2021-07-16 05:35:39 --> Helper loaded: url_helper
INFO - 2021-07-16 05:35:39 --> Helper loaded: file_helper
INFO - 2021-07-16 05:35:39 --> Helper loaded: form_helper
INFO - 2021-07-16 05:35:39 --> Helper loaded: my_helper
INFO - 2021-07-16 05:35:39 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:35:39 --> Controller Class Initialized
DEBUG - 2021-07-16 05:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:35:39 --> Final output sent to browser
DEBUG - 2021-07-16 05:35:39 --> Total execution time: 0.1328
INFO - 2021-07-16 05:36:06 --> Config Class Initialized
INFO - 2021-07-16 05:36:06 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:36:06 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:36:06 --> Utf8 Class Initialized
INFO - 2021-07-16 05:36:06 --> URI Class Initialized
INFO - 2021-07-16 05:36:06 --> Router Class Initialized
INFO - 2021-07-16 05:36:06 --> Output Class Initialized
INFO - 2021-07-16 05:36:06 --> Security Class Initialized
DEBUG - 2021-07-16 05:36:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:36:06 --> Input Class Initialized
INFO - 2021-07-16 05:36:06 --> Language Class Initialized
INFO - 2021-07-16 05:36:06 --> Language Class Initialized
INFO - 2021-07-16 05:36:06 --> Config Class Initialized
INFO - 2021-07-16 05:36:06 --> Loader Class Initialized
INFO - 2021-07-16 05:36:06 --> Helper loaded: url_helper
INFO - 2021-07-16 05:36:06 --> Helper loaded: file_helper
INFO - 2021-07-16 05:36:06 --> Helper loaded: form_helper
INFO - 2021-07-16 05:36:06 --> Helper loaded: my_helper
INFO - 2021-07-16 05:36:06 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:36:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:36:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:36:06 --> Controller Class Initialized
DEBUG - 2021-07-16 05:36:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:36:06 --> Final output sent to browser
DEBUG - 2021-07-16 05:36:06 --> Total execution time: 0.1234
INFO - 2021-07-16 05:36:47 --> Config Class Initialized
INFO - 2021-07-16 05:36:47 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:36:47 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:36:47 --> Utf8 Class Initialized
INFO - 2021-07-16 05:36:47 --> URI Class Initialized
INFO - 2021-07-16 05:36:47 --> Router Class Initialized
INFO - 2021-07-16 05:36:47 --> Output Class Initialized
INFO - 2021-07-16 05:36:47 --> Security Class Initialized
DEBUG - 2021-07-16 05:36:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:36:47 --> Input Class Initialized
INFO - 2021-07-16 05:36:47 --> Language Class Initialized
INFO - 2021-07-16 05:36:47 --> Language Class Initialized
INFO - 2021-07-16 05:36:47 --> Config Class Initialized
INFO - 2021-07-16 05:36:47 --> Loader Class Initialized
INFO - 2021-07-16 05:36:47 --> Helper loaded: url_helper
INFO - 2021-07-16 05:36:47 --> Helper loaded: file_helper
INFO - 2021-07-16 05:36:47 --> Helper loaded: form_helper
INFO - 2021-07-16 05:36:47 --> Helper loaded: my_helper
INFO - 2021-07-16 05:36:47 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:36:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:36:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:36:47 --> Controller Class Initialized
DEBUG - 2021-07-16 05:36:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:36:47 --> Final output sent to browser
DEBUG - 2021-07-16 05:36:47 --> Total execution time: 0.1205
INFO - 2021-07-16 05:36:59 --> Config Class Initialized
INFO - 2021-07-16 05:36:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:36:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:36:59 --> Utf8 Class Initialized
INFO - 2021-07-16 05:36:59 --> URI Class Initialized
INFO - 2021-07-16 05:36:59 --> Router Class Initialized
INFO - 2021-07-16 05:36:59 --> Output Class Initialized
INFO - 2021-07-16 05:36:59 --> Security Class Initialized
DEBUG - 2021-07-16 05:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:36:59 --> Input Class Initialized
INFO - 2021-07-16 05:36:59 --> Language Class Initialized
INFO - 2021-07-16 05:36:59 --> Language Class Initialized
INFO - 2021-07-16 05:36:59 --> Config Class Initialized
INFO - 2021-07-16 05:36:59 --> Loader Class Initialized
INFO - 2021-07-16 05:36:59 --> Helper loaded: url_helper
INFO - 2021-07-16 05:36:59 --> Helper loaded: file_helper
INFO - 2021-07-16 05:36:59 --> Helper loaded: form_helper
INFO - 2021-07-16 05:36:59 --> Helper loaded: my_helper
INFO - 2021-07-16 05:36:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:36:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:36:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:36:59 --> Controller Class Initialized
DEBUG - 2021-07-16 05:37:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_mm_xii.php
INFO - 2021-07-16 05:37:00 --> Final output sent to browser
DEBUG - 2021-07-16 05:37:00 --> Total execution time: 0.1193
INFO - 2021-07-16 05:57:15 --> Config Class Initialized
INFO - 2021-07-16 05:57:15 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:57:15 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:57:15 --> Utf8 Class Initialized
INFO - 2021-07-16 05:57:15 --> URI Class Initialized
INFO - 2021-07-16 05:57:15 --> Router Class Initialized
INFO - 2021-07-16 05:57:15 --> Output Class Initialized
INFO - 2021-07-16 05:57:15 --> Security Class Initialized
DEBUG - 2021-07-16 05:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:57:15 --> Input Class Initialized
INFO - 2021-07-16 05:57:15 --> Language Class Initialized
INFO - 2021-07-16 05:57:15 --> Language Class Initialized
INFO - 2021-07-16 05:57:15 --> Config Class Initialized
INFO - 2021-07-16 05:57:15 --> Loader Class Initialized
INFO - 2021-07-16 05:57:15 --> Helper loaded: url_helper
INFO - 2021-07-16 05:57:15 --> Helper loaded: file_helper
INFO - 2021-07-16 05:57:15 --> Helper loaded: form_helper
INFO - 2021-07-16 05:57:15 --> Helper loaded: my_helper
INFO - 2021-07-16 05:57:15 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:57:15 --> Controller Class Initialized
INFO - 2021-07-16 05:57:15 --> Helper loaded: cookie_helper
INFO - 2021-07-16 05:57:15 --> Config Class Initialized
INFO - 2021-07-16 05:57:15 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:57:15 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:57:15 --> Utf8 Class Initialized
INFO - 2021-07-16 05:57:15 --> URI Class Initialized
INFO - 2021-07-16 05:57:15 --> Router Class Initialized
INFO - 2021-07-16 05:57:15 --> Output Class Initialized
INFO - 2021-07-16 05:57:15 --> Security Class Initialized
DEBUG - 2021-07-16 05:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:57:15 --> Input Class Initialized
INFO - 2021-07-16 05:57:15 --> Language Class Initialized
INFO - 2021-07-16 05:57:15 --> Language Class Initialized
INFO - 2021-07-16 05:57:15 --> Config Class Initialized
INFO - 2021-07-16 05:57:15 --> Loader Class Initialized
INFO - 2021-07-16 05:57:15 --> Helper loaded: url_helper
INFO - 2021-07-16 05:57:15 --> Helper loaded: file_helper
INFO - 2021-07-16 05:57:15 --> Helper loaded: form_helper
INFO - 2021-07-16 05:57:15 --> Helper loaded: my_helper
INFO - 2021-07-16 05:57:15 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:57:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:57:15 --> Controller Class Initialized
DEBUG - 2021-07-16 05:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 05:57:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:57:15 --> Final output sent to browser
DEBUG - 2021-07-16 05:57:15 --> Total execution time: 0.0537
INFO - 2021-07-16 05:57:32 --> Config Class Initialized
INFO - 2021-07-16 05:57:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:57:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:57:32 --> Utf8 Class Initialized
INFO - 2021-07-16 05:57:32 --> URI Class Initialized
INFO - 2021-07-16 05:57:32 --> Router Class Initialized
INFO - 2021-07-16 05:57:32 --> Output Class Initialized
INFO - 2021-07-16 05:57:32 --> Security Class Initialized
DEBUG - 2021-07-16 05:57:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:57:32 --> Input Class Initialized
INFO - 2021-07-16 05:57:32 --> Language Class Initialized
INFO - 2021-07-16 05:57:32 --> Language Class Initialized
INFO - 2021-07-16 05:57:32 --> Config Class Initialized
INFO - 2021-07-16 05:57:32 --> Loader Class Initialized
INFO - 2021-07-16 05:57:32 --> Helper loaded: url_helper
INFO - 2021-07-16 05:57:32 --> Helper loaded: file_helper
INFO - 2021-07-16 05:57:32 --> Helper loaded: form_helper
INFO - 2021-07-16 05:57:32 --> Helper loaded: my_helper
INFO - 2021-07-16 05:57:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:57:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:57:32 --> Controller Class Initialized
INFO - 2021-07-16 05:57:32 --> Helper loaded: cookie_helper
INFO - 2021-07-16 05:57:32 --> Final output sent to browser
DEBUG - 2021-07-16 05:57:32 --> Total execution time: 0.0717
INFO - 2021-07-16 05:57:34 --> Config Class Initialized
INFO - 2021-07-16 05:57:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:57:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:57:34 --> Utf8 Class Initialized
INFO - 2021-07-16 05:57:34 --> URI Class Initialized
INFO - 2021-07-16 05:57:34 --> Router Class Initialized
INFO - 2021-07-16 05:57:34 --> Output Class Initialized
INFO - 2021-07-16 05:57:34 --> Security Class Initialized
DEBUG - 2021-07-16 05:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:57:34 --> Input Class Initialized
INFO - 2021-07-16 05:57:34 --> Language Class Initialized
INFO - 2021-07-16 05:57:34 --> Language Class Initialized
INFO - 2021-07-16 05:57:34 --> Config Class Initialized
INFO - 2021-07-16 05:57:34 --> Loader Class Initialized
INFO - 2021-07-16 05:57:34 --> Helper loaded: url_helper
INFO - 2021-07-16 05:57:34 --> Helper loaded: file_helper
INFO - 2021-07-16 05:57:34 --> Helper loaded: form_helper
INFO - 2021-07-16 05:57:34 --> Helper loaded: my_helper
INFO - 2021-07-16 05:57:34 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:57:34 --> Controller Class Initialized
DEBUG - 2021-07-16 05:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 05:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:57:35 --> Final output sent to browser
DEBUG - 2021-07-16 05:57:35 --> Total execution time: 0.7727
INFO - 2021-07-16 05:57:42 --> Config Class Initialized
INFO - 2021-07-16 05:57:42 --> Hooks Class Initialized
DEBUG - 2021-07-16 05:57:42 --> UTF-8 Support Enabled
INFO - 2021-07-16 05:57:42 --> Utf8 Class Initialized
INFO - 2021-07-16 05:57:42 --> URI Class Initialized
INFO - 2021-07-16 05:57:42 --> Router Class Initialized
INFO - 2021-07-16 05:57:42 --> Output Class Initialized
INFO - 2021-07-16 05:57:42 --> Security Class Initialized
DEBUG - 2021-07-16 05:57:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 05:57:42 --> Input Class Initialized
INFO - 2021-07-16 05:57:42 --> Language Class Initialized
INFO - 2021-07-16 05:57:42 --> Language Class Initialized
INFO - 2021-07-16 05:57:42 --> Config Class Initialized
INFO - 2021-07-16 05:57:42 --> Loader Class Initialized
INFO - 2021-07-16 05:57:42 --> Helper loaded: url_helper
INFO - 2021-07-16 05:57:42 --> Helper loaded: file_helper
INFO - 2021-07-16 05:57:42 --> Helper loaded: form_helper
INFO - 2021-07-16 05:57:42 --> Helper loaded: my_helper
INFO - 2021-07-16 05:57:42 --> Database Driver Class Initialized
DEBUG - 2021-07-16 05:57:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 05:57:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 05:57:42 --> Controller Class Initialized
DEBUG - 2021-07-16 05:57:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 05:57:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 05:57:42 --> Final output sent to browser
DEBUG - 2021-07-16 05:57:42 --> Total execution time: 0.0812
INFO - 2021-07-16 06:02:32 --> Config Class Initialized
INFO - 2021-07-16 06:02:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:02:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:02:32 --> Utf8 Class Initialized
INFO - 2021-07-16 06:02:32 --> URI Class Initialized
INFO - 2021-07-16 06:02:32 --> Router Class Initialized
INFO - 2021-07-16 06:02:32 --> Output Class Initialized
INFO - 2021-07-16 06:02:32 --> Security Class Initialized
DEBUG - 2021-07-16 06:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:02:32 --> Input Class Initialized
INFO - 2021-07-16 06:02:32 --> Language Class Initialized
INFO - 2021-07-16 06:02:32 --> Language Class Initialized
INFO - 2021-07-16 06:02:32 --> Config Class Initialized
INFO - 2021-07-16 06:02:32 --> Loader Class Initialized
INFO - 2021-07-16 06:02:32 --> Helper loaded: url_helper
INFO - 2021-07-16 06:02:32 --> Helper loaded: file_helper
INFO - 2021-07-16 06:02:32 --> Helper loaded: form_helper
INFO - 2021-07-16 06:02:32 --> Helper loaded: my_helper
INFO - 2021-07-16 06:02:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:02:32 --> Controller Class Initialized
INFO - 2021-07-16 06:02:32 --> Final output sent to browser
DEBUG - 2021-07-16 06:02:32 --> Total execution time: 0.1038
INFO - 2021-07-16 06:02:45 --> Config Class Initialized
INFO - 2021-07-16 06:02:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:02:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:02:45 --> Utf8 Class Initialized
INFO - 2021-07-16 06:02:45 --> URI Class Initialized
INFO - 2021-07-16 06:02:45 --> Router Class Initialized
INFO - 2021-07-16 06:02:45 --> Output Class Initialized
INFO - 2021-07-16 06:02:45 --> Security Class Initialized
DEBUG - 2021-07-16 06:02:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:02:45 --> Input Class Initialized
INFO - 2021-07-16 06:02:45 --> Language Class Initialized
INFO - 2021-07-16 06:02:45 --> Language Class Initialized
INFO - 2021-07-16 06:02:45 --> Config Class Initialized
INFO - 2021-07-16 06:02:45 --> Loader Class Initialized
INFO - 2021-07-16 06:02:45 --> Helper loaded: url_helper
INFO - 2021-07-16 06:02:45 --> Helper loaded: file_helper
INFO - 2021-07-16 06:02:45 --> Helper loaded: form_helper
INFO - 2021-07-16 06:02:45 --> Helper loaded: my_helper
INFO - 2021-07-16 06:02:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:02:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:02:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:02:45 --> Controller Class Initialized
DEBUG - 2021-07-16 06:02:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-16 06:02:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 06:02:45 --> Final output sent to browser
DEBUG - 2021-07-16 06:02:45 --> Total execution time: 0.0704
INFO - 2021-07-16 06:02:55 --> Config Class Initialized
INFO - 2021-07-16 06:02:55 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:02:55 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:02:55 --> Utf8 Class Initialized
INFO - 2021-07-16 06:02:55 --> URI Class Initialized
INFO - 2021-07-16 06:02:55 --> Router Class Initialized
INFO - 2021-07-16 06:02:55 --> Output Class Initialized
INFO - 2021-07-16 06:02:55 --> Security Class Initialized
DEBUG - 2021-07-16 06:02:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:02:55 --> Input Class Initialized
INFO - 2021-07-16 06:02:55 --> Language Class Initialized
INFO - 2021-07-16 06:02:55 --> Language Class Initialized
INFO - 2021-07-16 06:02:55 --> Config Class Initialized
INFO - 2021-07-16 06:02:55 --> Loader Class Initialized
INFO - 2021-07-16 06:02:55 --> Helper loaded: url_helper
INFO - 2021-07-16 06:02:55 --> Helper loaded: file_helper
INFO - 2021-07-16 06:02:55 --> Helper loaded: form_helper
INFO - 2021-07-16 06:02:55 --> Helper loaded: my_helper
INFO - 2021-07-16 06:02:55 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:02:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:02:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:02:55 --> Controller Class Initialized
DEBUG - 2021-07-16 06:02:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:02:55 --> Final output sent to browser
DEBUG - 2021-07-16 06:02:55 --> Total execution time: 0.2497
INFO - 2021-07-16 06:03:36 --> Config Class Initialized
INFO - 2021-07-16 06:03:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:03:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:03:36 --> Utf8 Class Initialized
INFO - 2021-07-16 06:03:36 --> URI Class Initialized
INFO - 2021-07-16 06:03:36 --> Router Class Initialized
INFO - 2021-07-16 06:03:36 --> Output Class Initialized
INFO - 2021-07-16 06:03:36 --> Security Class Initialized
DEBUG - 2021-07-16 06:03:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:03:36 --> Input Class Initialized
INFO - 2021-07-16 06:03:36 --> Language Class Initialized
INFO - 2021-07-16 06:03:36 --> Language Class Initialized
INFO - 2021-07-16 06:03:36 --> Config Class Initialized
INFO - 2021-07-16 06:03:36 --> Loader Class Initialized
INFO - 2021-07-16 06:03:36 --> Helper loaded: url_helper
INFO - 2021-07-16 06:03:36 --> Helper loaded: file_helper
INFO - 2021-07-16 06:03:36 --> Helper loaded: form_helper
INFO - 2021-07-16 06:03:36 --> Helper loaded: my_helper
INFO - 2021-07-16 06:03:36 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:03:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:03:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:03:36 --> Controller Class Initialized
DEBUG - 2021-07-16 06:03:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:03:36 --> Final output sent to browser
DEBUG - 2021-07-16 06:03:36 --> Total execution time: 0.1330
INFO - 2021-07-16 06:03:41 --> Config Class Initialized
INFO - 2021-07-16 06:03:41 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:03:41 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:03:41 --> Utf8 Class Initialized
INFO - 2021-07-16 06:03:41 --> URI Class Initialized
INFO - 2021-07-16 06:03:41 --> Router Class Initialized
INFO - 2021-07-16 06:03:41 --> Output Class Initialized
INFO - 2021-07-16 06:03:41 --> Security Class Initialized
DEBUG - 2021-07-16 06:03:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:03:41 --> Input Class Initialized
INFO - 2021-07-16 06:03:41 --> Language Class Initialized
INFO - 2021-07-16 06:03:41 --> Language Class Initialized
INFO - 2021-07-16 06:03:41 --> Config Class Initialized
INFO - 2021-07-16 06:03:41 --> Loader Class Initialized
INFO - 2021-07-16 06:03:41 --> Helper loaded: url_helper
INFO - 2021-07-16 06:03:41 --> Helper loaded: file_helper
INFO - 2021-07-16 06:03:41 --> Helper loaded: form_helper
INFO - 2021-07-16 06:03:41 --> Helper loaded: my_helper
INFO - 2021-07-16 06:03:41 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:03:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:03:41 --> Controller Class Initialized
DEBUG - 2021-07-16 06:03:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:03:41 --> Final output sent to browser
DEBUG - 2021-07-16 06:03:41 --> Total execution time: 0.1317
INFO - 2021-07-16 06:04:06 --> Config Class Initialized
INFO - 2021-07-16 06:04:06 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:04:06 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:04:06 --> Utf8 Class Initialized
INFO - 2021-07-16 06:04:06 --> URI Class Initialized
INFO - 2021-07-16 06:04:06 --> Router Class Initialized
INFO - 2021-07-16 06:04:06 --> Output Class Initialized
INFO - 2021-07-16 06:04:06 --> Security Class Initialized
DEBUG - 2021-07-16 06:04:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:04:06 --> Input Class Initialized
INFO - 2021-07-16 06:04:06 --> Language Class Initialized
INFO - 2021-07-16 06:04:06 --> Language Class Initialized
INFO - 2021-07-16 06:04:06 --> Config Class Initialized
INFO - 2021-07-16 06:04:06 --> Loader Class Initialized
INFO - 2021-07-16 06:04:06 --> Helper loaded: url_helper
INFO - 2021-07-16 06:04:06 --> Helper loaded: file_helper
INFO - 2021-07-16 06:04:06 --> Helper loaded: form_helper
INFO - 2021-07-16 06:04:06 --> Helper loaded: my_helper
INFO - 2021-07-16 06:04:06 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:04:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:04:06 --> Controller Class Initialized
DEBUG - 2021-07-16 06:04:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:04:06 --> Final output sent to browser
DEBUG - 2021-07-16 06:04:06 --> Total execution time: 0.1226
INFO - 2021-07-16 06:04:58 --> Config Class Initialized
INFO - 2021-07-16 06:04:58 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:04:58 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:04:58 --> Utf8 Class Initialized
INFO - 2021-07-16 06:04:58 --> URI Class Initialized
INFO - 2021-07-16 06:04:58 --> Router Class Initialized
INFO - 2021-07-16 06:04:58 --> Output Class Initialized
INFO - 2021-07-16 06:04:58 --> Security Class Initialized
DEBUG - 2021-07-16 06:04:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:04:58 --> Input Class Initialized
INFO - 2021-07-16 06:04:58 --> Language Class Initialized
INFO - 2021-07-16 06:04:58 --> Language Class Initialized
INFO - 2021-07-16 06:04:58 --> Config Class Initialized
INFO - 2021-07-16 06:04:58 --> Loader Class Initialized
INFO - 2021-07-16 06:04:58 --> Helper loaded: url_helper
INFO - 2021-07-16 06:04:58 --> Helper loaded: file_helper
INFO - 2021-07-16 06:04:58 --> Helper loaded: form_helper
INFO - 2021-07-16 06:04:58 --> Helper loaded: my_helper
INFO - 2021-07-16 06:04:58 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:04:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:04:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:04:58 --> Controller Class Initialized
DEBUG - 2021-07-16 06:04:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:04:58 --> Final output sent to browser
DEBUG - 2021-07-16 06:04:58 --> Total execution time: 0.1126
INFO - 2021-07-16 06:05:20 --> Config Class Initialized
INFO - 2021-07-16 06:05:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:05:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:05:20 --> Utf8 Class Initialized
INFO - 2021-07-16 06:05:20 --> URI Class Initialized
INFO - 2021-07-16 06:05:20 --> Router Class Initialized
INFO - 2021-07-16 06:05:20 --> Output Class Initialized
INFO - 2021-07-16 06:05:20 --> Security Class Initialized
DEBUG - 2021-07-16 06:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:05:20 --> Input Class Initialized
INFO - 2021-07-16 06:05:20 --> Language Class Initialized
INFO - 2021-07-16 06:05:20 --> Language Class Initialized
INFO - 2021-07-16 06:05:20 --> Config Class Initialized
INFO - 2021-07-16 06:05:20 --> Loader Class Initialized
INFO - 2021-07-16 06:05:20 --> Helper loaded: url_helper
INFO - 2021-07-16 06:05:20 --> Helper loaded: file_helper
INFO - 2021-07-16 06:05:20 --> Helper loaded: form_helper
INFO - 2021-07-16 06:05:20 --> Helper loaded: my_helper
INFO - 2021-07-16 06:05:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:05:20 --> Controller Class Initialized
DEBUG - 2021-07-16 06:05:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:05:20 --> Final output sent to browser
DEBUG - 2021-07-16 06:05:20 --> Total execution time: 0.1178
INFO - 2021-07-16 06:05:42 --> Config Class Initialized
INFO - 2021-07-16 06:05:42 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:05:42 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:05:42 --> Utf8 Class Initialized
INFO - 2021-07-16 06:05:42 --> URI Class Initialized
INFO - 2021-07-16 06:05:42 --> Router Class Initialized
INFO - 2021-07-16 06:05:42 --> Output Class Initialized
INFO - 2021-07-16 06:05:42 --> Security Class Initialized
DEBUG - 2021-07-16 06:05:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:05:42 --> Input Class Initialized
INFO - 2021-07-16 06:05:42 --> Language Class Initialized
INFO - 2021-07-16 06:05:42 --> Language Class Initialized
INFO - 2021-07-16 06:05:42 --> Config Class Initialized
INFO - 2021-07-16 06:05:42 --> Loader Class Initialized
INFO - 2021-07-16 06:05:42 --> Helper loaded: url_helper
INFO - 2021-07-16 06:05:42 --> Helper loaded: file_helper
INFO - 2021-07-16 06:05:42 --> Helper loaded: form_helper
INFO - 2021-07-16 06:05:42 --> Helper loaded: my_helper
INFO - 2021-07-16 06:05:42 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:05:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:05:42 --> Controller Class Initialized
DEBUG - 2021-07-16 06:05:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:05:42 --> Final output sent to browser
DEBUG - 2021-07-16 06:05:42 --> Total execution time: 0.1278
INFO - 2021-07-16 06:06:03 --> Config Class Initialized
INFO - 2021-07-16 06:06:03 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:06:03 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:06:03 --> Utf8 Class Initialized
INFO - 2021-07-16 06:06:03 --> URI Class Initialized
INFO - 2021-07-16 06:06:03 --> Router Class Initialized
INFO - 2021-07-16 06:06:03 --> Output Class Initialized
INFO - 2021-07-16 06:06:03 --> Security Class Initialized
DEBUG - 2021-07-16 06:06:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:06:03 --> Input Class Initialized
INFO - 2021-07-16 06:06:03 --> Language Class Initialized
INFO - 2021-07-16 06:06:03 --> Language Class Initialized
INFO - 2021-07-16 06:06:03 --> Config Class Initialized
INFO - 2021-07-16 06:06:03 --> Loader Class Initialized
INFO - 2021-07-16 06:06:03 --> Helper loaded: url_helper
INFO - 2021-07-16 06:06:03 --> Helper loaded: file_helper
INFO - 2021-07-16 06:06:03 --> Helper loaded: form_helper
INFO - 2021-07-16 06:06:03 --> Helper loaded: my_helper
INFO - 2021-07-16 06:06:03 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:06:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:06:03 --> Controller Class Initialized
DEBUG - 2021-07-16 06:06:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:06:03 --> Final output sent to browser
DEBUG - 2021-07-16 06:06:03 --> Total execution time: 0.1156
INFO - 2021-07-16 06:10:24 --> Config Class Initialized
INFO - 2021-07-16 06:10:24 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:10:24 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:10:24 --> Utf8 Class Initialized
INFO - 2021-07-16 06:10:24 --> URI Class Initialized
INFO - 2021-07-16 06:10:24 --> Router Class Initialized
INFO - 2021-07-16 06:10:24 --> Output Class Initialized
INFO - 2021-07-16 06:10:24 --> Security Class Initialized
DEBUG - 2021-07-16 06:10:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:10:24 --> Input Class Initialized
INFO - 2021-07-16 06:10:24 --> Language Class Initialized
INFO - 2021-07-16 06:10:24 --> Language Class Initialized
INFO - 2021-07-16 06:10:24 --> Config Class Initialized
INFO - 2021-07-16 06:10:24 --> Loader Class Initialized
INFO - 2021-07-16 06:10:24 --> Helper loaded: url_helper
INFO - 2021-07-16 06:10:24 --> Helper loaded: file_helper
INFO - 2021-07-16 06:10:24 --> Helper loaded: form_helper
INFO - 2021-07-16 06:10:24 --> Helper loaded: my_helper
INFO - 2021-07-16 06:10:24 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:10:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:10:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:10:24 --> Controller Class Initialized
DEBUG - 2021-07-16 06:10:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:10:25 --> Final output sent to browser
DEBUG - 2021-07-16 06:10:25 --> Total execution time: 0.1143
INFO - 2021-07-16 06:11:37 --> Config Class Initialized
INFO - 2021-07-16 06:11:37 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:11:37 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:11:37 --> Utf8 Class Initialized
INFO - 2021-07-16 06:11:37 --> URI Class Initialized
INFO - 2021-07-16 06:11:37 --> Router Class Initialized
INFO - 2021-07-16 06:11:37 --> Output Class Initialized
INFO - 2021-07-16 06:11:37 --> Security Class Initialized
DEBUG - 2021-07-16 06:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:11:37 --> Input Class Initialized
INFO - 2021-07-16 06:11:37 --> Language Class Initialized
INFO - 2021-07-16 06:11:37 --> Language Class Initialized
INFO - 2021-07-16 06:11:37 --> Config Class Initialized
INFO - 2021-07-16 06:11:37 --> Loader Class Initialized
INFO - 2021-07-16 06:11:37 --> Helper loaded: url_helper
INFO - 2021-07-16 06:11:37 --> Helper loaded: file_helper
INFO - 2021-07-16 06:11:37 --> Helper loaded: form_helper
INFO - 2021-07-16 06:11:37 --> Helper loaded: my_helper
INFO - 2021-07-16 06:11:37 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:11:37 --> Controller Class Initialized
DEBUG - 2021-07-16 06:11:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:11:37 --> Final output sent to browser
DEBUG - 2021-07-16 06:11:37 --> Total execution time: 0.1264
INFO - 2021-07-16 06:12:24 --> Config Class Initialized
INFO - 2021-07-16 06:12:24 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:12:24 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:12:24 --> Utf8 Class Initialized
INFO - 2021-07-16 06:12:24 --> URI Class Initialized
INFO - 2021-07-16 06:12:24 --> Router Class Initialized
INFO - 2021-07-16 06:12:24 --> Output Class Initialized
INFO - 2021-07-16 06:12:24 --> Security Class Initialized
DEBUG - 2021-07-16 06:12:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:12:24 --> Input Class Initialized
INFO - 2021-07-16 06:12:24 --> Language Class Initialized
INFO - 2021-07-16 06:12:24 --> Language Class Initialized
INFO - 2021-07-16 06:12:24 --> Config Class Initialized
INFO - 2021-07-16 06:12:24 --> Loader Class Initialized
INFO - 2021-07-16 06:12:24 --> Helper loaded: url_helper
INFO - 2021-07-16 06:12:24 --> Helper loaded: file_helper
INFO - 2021-07-16 06:12:24 --> Helper loaded: form_helper
INFO - 2021-07-16 06:12:24 --> Helper loaded: my_helper
INFO - 2021-07-16 06:12:24 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:12:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:12:24 --> Controller Class Initialized
DEBUG - 2021-07-16 06:12:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:12:24 --> Final output sent to browser
DEBUG - 2021-07-16 06:12:24 --> Total execution time: 0.1126
INFO - 2021-07-16 06:13:17 --> Config Class Initialized
INFO - 2021-07-16 06:13:17 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:13:17 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:13:17 --> Utf8 Class Initialized
INFO - 2021-07-16 06:13:17 --> URI Class Initialized
INFO - 2021-07-16 06:13:17 --> Router Class Initialized
INFO - 2021-07-16 06:13:17 --> Output Class Initialized
INFO - 2021-07-16 06:13:17 --> Security Class Initialized
DEBUG - 2021-07-16 06:13:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:13:17 --> Input Class Initialized
INFO - 2021-07-16 06:13:17 --> Language Class Initialized
INFO - 2021-07-16 06:13:17 --> Language Class Initialized
INFO - 2021-07-16 06:13:17 --> Config Class Initialized
INFO - 2021-07-16 06:13:17 --> Loader Class Initialized
INFO - 2021-07-16 06:13:17 --> Helper loaded: url_helper
INFO - 2021-07-16 06:13:17 --> Helper loaded: file_helper
INFO - 2021-07-16 06:13:17 --> Helper loaded: form_helper
INFO - 2021-07-16 06:13:17 --> Helper loaded: my_helper
INFO - 2021-07-16 06:13:17 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:13:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:13:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:13:17 --> Controller Class Initialized
DEBUG - 2021-07-16 06:13:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:13:17 --> Final output sent to browser
DEBUG - 2021-07-16 06:13:17 --> Total execution time: 0.1164
INFO - 2021-07-16 06:13:40 --> Config Class Initialized
INFO - 2021-07-16 06:13:40 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:13:40 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:13:40 --> Utf8 Class Initialized
INFO - 2021-07-16 06:13:40 --> URI Class Initialized
INFO - 2021-07-16 06:13:40 --> Router Class Initialized
INFO - 2021-07-16 06:13:40 --> Output Class Initialized
INFO - 2021-07-16 06:13:40 --> Security Class Initialized
DEBUG - 2021-07-16 06:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:13:40 --> Input Class Initialized
INFO - 2021-07-16 06:13:40 --> Language Class Initialized
INFO - 2021-07-16 06:13:40 --> Language Class Initialized
INFO - 2021-07-16 06:13:40 --> Config Class Initialized
INFO - 2021-07-16 06:13:40 --> Loader Class Initialized
INFO - 2021-07-16 06:13:40 --> Helper loaded: url_helper
INFO - 2021-07-16 06:13:40 --> Helper loaded: file_helper
INFO - 2021-07-16 06:13:40 --> Helper loaded: form_helper
INFO - 2021-07-16 06:13:40 --> Helper loaded: my_helper
INFO - 2021-07-16 06:13:40 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:13:40 --> Controller Class Initialized
DEBUG - 2021-07-16 06:13:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:13:40 --> Final output sent to browser
DEBUG - 2021-07-16 06:13:40 --> Total execution time: 0.1250
INFO - 2021-07-16 06:14:09 --> Config Class Initialized
INFO - 2021-07-16 06:14:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:14:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:14:09 --> Utf8 Class Initialized
INFO - 2021-07-16 06:14:09 --> URI Class Initialized
INFO - 2021-07-16 06:14:09 --> Router Class Initialized
INFO - 2021-07-16 06:14:09 --> Output Class Initialized
INFO - 2021-07-16 06:14:09 --> Security Class Initialized
DEBUG - 2021-07-16 06:14:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:14:09 --> Input Class Initialized
INFO - 2021-07-16 06:14:09 --> Language Class Initialized
INFO - 2021-07-16 06:14:09 --> Language Class Initialized
INFO - 2021-07-16 06:14:09 --> Config Class Initialized
INFO - 2021-07-16 06:14:09 --> Loader Class Initialized
INFO - 2021-07-16 06:14:09 --> Helper loaded: url_helper
INFO - 2021-07-16 06:14:09 --> Helper loaded: file_helper
INFO - 2021-07-16 06:14:09 --> Helper loaded: form_helper
INFO - 2021-07-16 06:14:09 --> Helper loaded: my_helper
INFO - 2021-07-16 06:14:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:14:09 --> Controller Class Initialized
DEBUG - 2021-07-16 06:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:14:09 --> Final output sent to browser
DEBUG - 2021-07-16 06:14:09 --> Total execution time: 0.1131
INFO - 2021-07-16 06:14:46 --> Config Class Initialized
INFO - 2021-07-16 06:14:46 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:14:46 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:14:46 --> Utf8 Class Initialized
INFO - 2021-07-16 06:14:46 --> URI Class Initialized
INFO - 2021-07-16 06:14:46 --> Router Class Initialized
INFO - 2021-07-16 06:14:46 --> Output Class Initialized
INFO - 2021-07-16 06:14:46 --> Security Class Initialized
DEBUG - 2021-07-16 06:14:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:14:46 --> Input Class Initialized
INFO - 2021-07-16 06:14:46 --> Language Class Initialized
INFO - 2021-07-16 06:14:46 --> Language Class Initialized
INFO - 2021-07-16 06:14:46 --> Config Class Initialized
INFO - 2021-07-16 06:14:46 --> Loader Class Initialized
INFO - 2021-07-16 06:14:46 --> Helper loaded: url_helper
INFO - 2021-07-16 06:14:46 --> Helper loaded: file_helper
INFO - 2021-07-16 06:14:46 --> Helper loaded: form_helper
INFO - 2021-07-16 06:14:46 --> Helper loaded: my_helper
INFO - 2021-07-16 06:14:46 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:14:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:14:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:14:46 --> Controller Class Initialized
DEBUG - 2021-07-16 06:14:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:14:46 --> Final output sent to browser
DEBUG - 2021-07-16 06:14:46 --> Total execution time: 0.1134
INFO - 2021-07-16 06:15:03 --> Config Class Initialized
INFO - 2021-07-16 06:15:03 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:15:03 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:15:03 --> Utf8 Class Initialized
INFO - 2021-07-16 06:15:03 --> URI Class Initialized
INFO - 2021-07-16 06:15:03 --> Router Class Initialized
INFO - 2021-07-16 06:15:03 --> Output Class Initialized
INFO - 2021-07-16 06:15:03 --> Security Class Initialized
DEBUG - 2021-07-16 06:15:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:15:03 --> Input Class Initialized
INFO - 2021-07-16 06:15:03 --> Language Class Initialized
INFO - 2021-07-16 06:15:03 --> Language Class Initialized
INFO - 2021-07-16 06:15:03 --> Config Class Initialized
INFO - 2021-07-16 06:15:03 --> Loader Class Initialized
INFO - 2021-07-16 06:15:03 --> Helper loaded: url_helper
INFO - 2021-07-16 06:15:03 --> Helper loaded: file_helper
INFO - 2021-07-16 06:15:03 --> Helper loaded: form_helper
INFO - 2021-07-16 06:15:03 --> Helper loaded: my_helper
INFO - 2021-07-16 06:15:03 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:15:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:15:03 --> Controller Class Initialized
DEBUG - 2021-07-16 06:15:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:15:03 --> Final output sent to browser
DEBUG - 2021-07-16 06:15:03 --> Total execution time: 0.1299
INFO - 2021-07-16 06:15:09 --> Config Class Initialized
INFO - 2021-07-16 06:15:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:15:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:15:09 --> Utf8 Class Initialized
INFO - 2021-07-16 06:15:09 --> URI Class Initialized
INFO - 2021-07-16 06:15:09 --> Router Class Initialized
INFO - 2021-07-16 06:15:09 --> Output Class Initialized
INFO - 2021-07-16 06:15:09 --> Security Class Initialized
DEBUG - 2021-07-16 06:15:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:15:09 --> Input Class Initialized
INFO - 2021-07-16 06:15:09 --> Language Class Initialized
INFO - 2021-07-16 06:15:09 --> Language Class Initialized
INFO - 2021-07-16 06:15:09 --> Config Class Initialized
INFO - 2021-07-16 06:15:09 --> Loader Class Initialized
INFO - 2021-07-16 06:15:09 --> Helper loaded: url_helper
INFO - 2021-07-16 06:15:09 --> Helper loaded: file_helper
INFO - 2021-07-16 06:15:09 --> Helper loaded: form_helper
INFO - 2021-07-16 06:15:09 --> Helper loaded: my_helper
INFO - 2021-07-16 06:15:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:15:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:15:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:15:09 --> Controller Class Initialized
DEBUG - 2021-07-16 06:15:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:15:09 --> Final output sent to browser
DEBUG - 2021-07-16 06:15:09 --> Total execution time: 0.1188
INFO - 2021-07-16 06:15:24 --> Config Class Initialized
INFO - 2021-07-16 06:15:24 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:15:24 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:15:24 --> Utf8 Class Initialized
INFO - 2021-07-16 06:15:24 --> URI Class Initialized
INFO - 2021-07-16 06:15:24 --> Router Class Initialized
INFO - 2021-07-16 06:15:24 --> Output Class Initialized
INFO - 2021-07-16 06:15:24 --> Security Class Initialized
DEBUG - 2021-07-16 06:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:15:24 --> Input Class Initialized
INFO - 2021-07-16 06:15:24 --> Language Class Initialized
INFO - 2021-07-16 06:15:24 --> Language Class Initialized
INFO - 2021-07-16 06:15:24 --> Config Class Initialized
INFO - 2021-07-16 06:15:24 --> Loader Class Initialized
INFO - 2021-07-16 06:15:24 --> Helper loaded: url_helper
INFO - 2021-07-16 06:15:24 --> Helper loaded: file_helper
INFO - 2021-07-16 06:15:24 --> Helper loaded: form_helper
INFO - 2021-07-16 06:15:24 --> Helper loaded: my_helper
INFO - 2021-07-16 06:15:24 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:15:24 --> Controller Class Initialized
DEBUG - 2021-07-16 06:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:15:24 --> Final output sent to browser
DEBUG - 2021-07-16 06:15:24 --> Total execution time: 0.1146
INFO - 2021-07-16 06:15:54 --> Config Class Initialized
INFO - 2021-07-16 06:15:54 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:15:54 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:15:54 --> Utf8 Class Initialized
INFO - 2021-07-16 06:15:54 --> URI Class Initialized
INFO - 2021-07-16 06:15:54 --> Router Class Initialized
INFO - 2021-07-16 06:15:54 --> Output Class Initialized
INFO - 2021-07-16 06:15:54 --> Security Class Initialized
DEBUG - 2021-07-16 06:15:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:15:54 --> Input Class Initialized
INFO - 2021-07-16 06:15:54 --> Language Class Initialized
INFO - 2021-07-16 06:15:54 --> Language Class Initialized
INFO - 2021-07-16 06:15:54 --> Config Class Initialized
INFO - 2021-07-16 06:15:54 --> Loader Class Initialized
INFO - 2021-07-16 06:15:54 --> Helper loaded: url_helper
INFO - 2021-07-16 06:15:54 --> Helper loaded: file_helper
INFO - 2021-07-16 06:15:54 --> Helper loaded: form_helper
INFO - 2021-07-16 06:15:54 --> Helper loaded: my_helper
INFO - 2021-07-16 06:15:54 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:15:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:15:54 --> Controller Class Initialized
DEBUG - 2021-07-16 06:15:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:15:54 --> Final output sent to browser
DEBUG - 2021-07-16 06:15:54 --> Total execution time: 0.1332
INFO - 2021-07-16 06:16:27 --> Config Class Initialized
INFO - 2021-07-16 06:16:27 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:16:27 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:16:27 --> Utf8 Class Initialized
INFO - 2021-07-16 06:16:27 --> URI Class Initialized
INFO - 2021-07-16 06:16:27 --> Router Class Initialized
INFO - 2021-07-16 06:16:27 --> Output Class Initialized
INFO - 2021-07-16 06:16:27 --> Security Class Initialized
DEBUG - 2021-07-16 06:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:16:27 --> Input Class Initialized
INFO - 2021-07-16 06:16:27 --> Language Class Initialized
INFO - 2021-07-16 06:16:27 --> Language Class Initialized
INFO - 2021-07-16 06:16:27 --> Config Class Initialized
INFO - 2021-07-16 06:16:27 --> Loader Class Initialized
INFO - 2021-07-16 06:16:27 --> Helper loaded: url_helper
INFO - 2021-07-16 06:16:27 --> Helper loaded: file_helper
INFO - 2021-07-16 06:16:27 --> Helper loaded: form_helper
INFO - 2021-07-16 06:16:27 --> Helper loaded: my_helper
INFO - 2021-07-16 06:16:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:16:27 --> Controller Class Initialized
DEBUG - 2021-07-16 06:16:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:16:27 --> Final output sent to browser
DEBUG - 2021-07-16 06:16:27 --> Total execution time: 0.1168
INFO - 2021-07-16 06:16:49 --> Config Class Initialized
INFO - 2021-07-16 06:16:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 06:16:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 06:16:49 --> Utf8 Class Initialized
INFO - 2021-07-16 06:16:49 --> URI Class Initialized
INFO - 2021-07-16 06:16:49 --> Router Class Initialized
INFO - 2021-07-16 06:16:49 --> Output Class Initialized
INFO - 2021-07-16 06:16:49 --> Security Class Initialized
DEBUG - 2021-07-16 06:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 06:16:49 --> Input Class Initialized
INFO - 2021-07-16 06:16:49 --> Language Class Initialized
INFO - 2021-07-16 06:16:49 --> Language Class Initialized
INFO - 2021-07-16 06:16:49 --> Config Class Initialized
INFO - 2021-07-16 06:16:49 --> Loader Class Initialized
INFO - 2021-07-16 06:16:49 --> Helper loaded: url_helper
INFO - 2021-07-16 06:16:49 --> Helper loaded: file_helper
INFO - 2021-07-16 06:16:49 --> Helper loaded: form_helper
INFO - 2021-07-16 06:16:49 --> Helper loaded: my_helper
INFO - 2021-07-16 06:16:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 06:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 06:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 06:16:49 --> Controller Class Initialized
DEBUG - 2021-07-16 06:16:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 06:16:49 --> Final output sent to browser
DEBUG - 2021-07-16 06:16:49 --> Total execution time: 0.1290
INFO - 2021-07-16 08:29:35 --> Config Class Initialized
INFO - 2021-07-16 08:29:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:29:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:29:35 --> Utf8 Class Initialized
INFO - 2021-07-16 08:29:35 --> URI Class Initialized
INFO - 2021-07-16 08:29:35 --> Router Class Initialized
INFO - 2021-07-16 08:29:35 --> Output Class Initialized
INFO - 2021-07-16 08:29:35 --> Security Class Initialized
DEBUG - 2021-07-16 08:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:29:35 --> Input Class Initialized
INFO - 2021-07-16 08:29:35 --> Language Class Initialized
INFO - 2021-07-16 08:29:35 --> Language Class Initialized
INFO - 2021-07-16 08:29:35 --> Config Class Initialized
INFO - 2021-07-16 08:29:35 --> Loader Class Initialized
INFO - 2021-07-16 08:29:35 --> Helper loaded: url_helper
INFO - 2021-07-16 08:29:35 --> Helper loaded: file_helper
INFO - 2021-07-16 08:29:35 --> Helper loaded: form_helper
INFO - 2021-07-16 08:29:35 --> Helper loaded: my_helper
INFO - 2021-07-16 08:29:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:29:35 --> Controller Class Initialized
INFO - 2021-07-16 08:29:35 --> Helper loaded: cookie_helper
INFO - 2021-07-16 08:29:35 --> Config Class Initialized
INFO - 2021-07-16 08:29:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:29:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:29:35 --> Utf8 Class Initialized
INFO - 2021-07-16 08:29:35 --> URI Class Initialized
INFO - 2021-07-16 08:29:35 --> Router Class Initialized
INFO - 2021-07-16 08:29:35 --> Output Class Initialized
INFO - 2021-07-16 08:29:35 --> Security Class Initialized
DEBUG - 2021-07-16 08:29:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:29:35 --> Input Class Initialized
INFO - 2021-07-16 08:29:35 --> Language Class Initialized
INFO - 2021-07-16 08:29:35 --> Language Class Initialized
INFO - 2021-07-16 08:29:35 --> Config Class Initialized
INFO - 2021-07-16 08:29:35 --> Loader Class Initialized
INFO - 2021-07-16 08:29:35 --> Helper loaded: url_helper
INFO - 2021-07-16 08:29:35 --> Helper loaded: file_helper
INFO - 2021-07-16 08:29:35 --> Helper loaded: form_helper
INFO - 2021-07-16 08:29:35 --> Helper loaded: my_helper
INFO - 2021-07-16 08:29:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:29:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:29:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:29:35 --> Controller Class Initialized
DEBUG - 2021-07-16 08:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 08:29:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:29:35 --> Final output sent to browser
DEBUG - 2021-07-16 08:29:35 --> Total execution time: 0.0543
INFO - 2021-07-16 08:29:40 --> Config Class Initialized
INFO - 2021-07-16 08:29:40 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:29:40 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:29:40 --> Utf8 Class Initialized
INFO - 2021-07-16 08:29:40 --> URI Class Initialized
INFO - 2021-07-16 08:29:40 --> Router Class Initialized
INFO - 2021-07-16 08:29:40 --> Output Class Initialized
INFO - 2021-07-16 08:29:40 --> Security Class Initialized
DEBUG - 2021-07-16 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:29:40 --> Input Class Initialized
INFO - 2021-07-16 08:29:40 --> Language Class Initialized
INFO - 2021-07-16 08:29:40 --> Language Class Initialized
INFO - 2021-07-16 08:29:40 --> Config Class Initialized
INFO - 2021-07-16 08:29:40 --> Loader Class Initialized
INFO - 2021-07-16 08:29:40 --> Helper loaded: url_helper
INFO - 2021-07-16 08:29:40 --> Helper loaded: file_helper
INFO - 2021-07-16 08:29:40 --> Helper loaded: form_helper
INFO - 2021-07-16 08:29:40 --> Helper loaded: my_helper
INFO - 2021-07-16 08:29:40 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:29:40 --> Controller Class Initialized
INFO - 2021-07-16 08:29:40 --> Helper loaded: cookie_helper
INFO - 2021-07-16 08:29:40 --> Final output sent to browser
DEBUG - 2021-07-16 08:29:40 --> Total execution time: 0.0461
INFO - 2021-07-16 08:29:40 --> Config Class Initialized
INFO - 2021-07-16 08:29:40 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:29:40 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:29:40 --> Utf8 Class Initialized
INFO - 2021-07-16 08:29:40 --> URI Class Initialized
INFO - 2021-07-16 08:29:40 --> Router Class Initialized
INFO - 2021-07-16 08:29:40 --> Output Class Initialized
INFO - 2021-07-16 08:29:40 --> Security Class Initialized
DEBUG - 2021-07-16 08:29:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:29:40 --> Input Class Initialized
INFO - 2021-07-16 08:29:40 --> Language Class Initialized
INFO - 2021-07-16 08:29:40 --> Language Class Initialized
INFO - 2021-07-16 08:29:40 --> Config Class Initialized
INFO - 2021-07-16 08:29:40 --> Loader Class Initialized
INFO - 2021-07-16 08:29:40 --> Helper loaded: url_helper
INFO - 2021-07-16 08:29:40 --> Helper loaded: file_helper
INFO - 2021-07-16 08:29:40 --> Helper loaded: form_helper
INFO - 2021-07-16 08:29:40 --> Helper loaded: my_helper
INFO - 2021-07-16 08:29:40 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:29:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:29:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:29:40 --> Controller Class Initialized
DEBUG - 2021-07-16 08:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 08:29:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:29:41 --> Final output sent to browser
DEBUG - 2021-07-16 08:29:41 --> Total execution time: 0.7278
INFO - 2021-07-16 08:29:46 --> Config Class Initialized
INFO - 2021-07-16 08:29:46 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:29:46 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:29:46 --> Utf8 Class Initialized
INFO - 2021-07-16 08:29:46 --> URI Class Initialized
INFO - 2021-07-16 08:29:46 --> Router Class Initialized
INFO - 2021-07-16 08:29:46 --> Output Class Initialized
INFO - 2021-07-16 08:29:46 --> Security Class Initialized
DEBUG - 2021-07-16 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:29:46 --> Input Class Initialized
INFO - 2021-07-16 08:29:46 --> Language Class Initialized
INFO - 2021-07-16 08:29:46 --> Language Class Initialized
INFO - 2021-07-16 08:29:46 --> Config Class Initialized
INFO - 2021-07-16 08:29:46 --> Loader Class Initialized
INFO - 2021-07-16 08:29:46 --> Helper loaded: url_helper
INFO - 2021-07-16 08:29:46 --> Helper loaded: file_helper
INFO - 2021-07-16 08:29:46 --> Helper loaded: form_helper
INFO - 2021-07-16 08:29:46 --> Helper loaded: my_helper
INFO - 2021-07-16 08:29:46 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:29:46 --> Controller Class Initialized
DEBUG - 2021-07-16 08:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:29:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:29:46 --> Final output sent to browser
DEBUG - 2021-07-16 08:29:46 --> Total execution time: 0.0850
INFO - 2021-07-16 08:29:46 --> Config Class Initialized
INFO - 2021-07-16 08:29:46 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:29:46 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:29:46 --> Utf8 Class Initialized
INFO - 2021-07-16 08:29:46 --> URI Class Initialized
INFO - 2021-07-16 08:29:46 --> Router Class Initialized
INFO - 2021-07-16 08:29:46 --> Output Class Initialized
INFO - 2021-07-16 08:29:46 --> Security Class Initialized
DEBUG - 2021-07-16 08:29:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:29:46 --> Input Class Initialized
INFO - 2021-07-16 08:29:46 --> Language Class Initialized
INFO - 2021-07-16 08:29:46 --> Language Class Initialized
INFO - 2021-07-16 08:29:46 --> Config Class Initialized
INFO - 2021-07-16 08:29:46 --> Loader Class Initialized
INFO - 2021-07-16 08:29:46 --> Helper loaded: url_helper
INFO - 2021-07-16 08:29:46 --> Helper loaded: file_helper
INFO - 2021-07-16 08:29:46 --> Helper loaded: form_helper
INFO - 2021-07-16 08:29:46 --> Helper loaded: my_helper
INFO - 2021-07-16 08:29:46 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:29:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:29:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:29:46 --> Controller Class Initialized
INFO - 2021-07-16 08:31:32 --> Config Class Initialized
INFO - 2021-07-16 08:31:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:31:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:31:32 --> Utf8 Class Initialized
INFO - 2021-07-16 08:31:32 --> URI Class Initialized
INFO - 2021-07-16 08:31:32 --> Router Class Initialized
INFO - 2021-07-16 08:31:32 --> Output Class Initialized
INFO - 2021-07-16 08:31:32 --> Security Class Initialized
DEBUG - 2021-07-16 08:31:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:31:32 --> Input Class Initialized
INFO - 2021-07-16 08:31:32 --> Language Class Initialized
INFO - 2021-07-16 08:31:32 --> Language Class Initialized
INFO - 2021-07-16 08:31:32 --> Config Class Initialized
INFO - 2021-07-16 08:31:32 --> Loader Class Initialized
INFO - 2021-07-16 08:31:32 --> Helper loaded: url_helper
INFO - 2021-07-16 08:31:32 --> Helper loaded: file_helper
INFO - 2021-07-16 08:31:32 --> Helper loaded: form_helper
INFO - 2021-07-16 08:31:32 --> Helper loaded: my_helper
INFO - 2021-07-16 08:31:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:31:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:31:32 --> Controller Class Initialized
INFO - 2021-07-16 08:31:35 --> Config Class Initialized
INFO - 2021-07-16 08:31:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:31:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:31:35 --> Utf8 Class Initialized
INFO - 2021-07-16 08:31:35 --> URI Class Initialized
INFO - 2021-07-16 08:31:35 --> Router Class Initialized
INFO - 2021-07-16 08:31:35 --> Output Class Initialized
INFO - 2021-07-16 08:31:35 --> Security Class Initialized
DEBUG - 2021-07-16 08:31:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:31:35 --> Input Class Initialized
INFO - 2021-07-16 08:31:35 --> Language Class Initialized
INFO - 2021-07-16 08:31:35 --> Language Class Initialized
INFO - 2021-07-16 08:31:35 --> Config Class Initialized
INFO - 2021-07-16 08:31:35 --> Loader Class Initialized
INFO - 2021-07-16 08:31:35 --> Helper loaded: url_helper
INFO - 2021-07-16 08:31:35 --> Helper loaded: file_helper
INFO - 2021-07-16 08:31:35 --> Helper loaded: form_helper
INFO - 2021-07-16 08:31:35 --> Helper loaded: my_helper
INFO - 2021-07-16 08:31:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:31:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:31:35 --> Controller Class Initialized
ERROR - 2021-07-16 08:31:35 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:31:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:31:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:31:35 --> Final output sent to browser
DEBUG - 2021-07-16 08:31:35 --> Total execution time: 0.1251
INFO - 2021-07-16 08:31:53 --> Config Class Initialized
INFO - 2021-07-16 08:31:53 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:31:53 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:31:53 --> Utf8 Class Initialized
INFO - 2021-07-16 08:31:53 --> URI Class Initialized
INFO - 2021-07-16 08:31:53 --> Router Class Initialized
INFO - 2021-07-16 08:31:53 --> Output Class Initialized
INFO - 2021-07-16 08:31:53 --> Security Class Initialized
DEBUG - 2021-07-16 08:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:31:53 --> Input Class Initialized
INFO - 2021-07-16 08:31:53 --> Language Class Initialized
INFO - 2021-07-16 08:31:53 --> Language Class Initialized
INFO - 2021-07-16 08:31:53 --> Config Class Initialized
INFO - 2021-07-16 08:31:53 --> Loader Class Initialized
INFO - 2021-07-16 08:31:54 --> Helper loaded: url_helper
INFO - 2021-07-16 08:31:54 --> Helper loaded: file_helper
INFO - 2021-07-16 08:31:54 --> Helper loaded: form_helper
INFO - 2021-07-16 08:31:54 --> Helper loaded: my_helper
INFO - 2021-07-16 08:31:54 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:31:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:31:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:31:54 --> Controller Class Initialized
INFO - 2021-07-16 08:31:57 --> Upload Class Initialized
INFO - 2021-07-16 08:31:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:31:57 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:31:57 --> Config Class Initialized
INFO - 2021-07-16 08:31:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:31:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:31:57 --> Utf8 Class Initialized
INFO - 2021-07-16 08:31:57 --> URI Class Initialized
INFO - 2021-07-16 08:31:57 --> Router Class Initialized
INFO - 2021-07-16 08:31:57 --> Output Class Initialized
INFO - 2021-07-16 08:31:57 --> Security Class Initialized
DEBUG - 2021-07-16 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:31:57 --> Input Class Initialized
INFO - 2021-07-16 08:31:57 --> Language Class Initialized
INFO - 2021-07-16 08:31:57 --> Language Class Initialized
INFO - 2021-07-16 08:31:57 --> Config Class Initialized
INFO - 2021-07-16 08:31:57 --> Loader Class Initialized
INFO - 2021-07-16 08:31:57 --> Helper loaded: url_helper
INFO - 2021-07-16 08:31:57 --> Helper loaded: file_helper
INFO - 2021-07-16 08:31:57 --> Helper loaded: form_helper
INFO - 2021-07-16 08:31:57 --> Helper loaded: my_helper
INFO - 2021-07-16 08:31:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:31:57 --> Controller Class Initialized
DEBUG - 2021-07-16 08:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:31:57 --> Final output sent to browser
DEBUG - 2021-07-16 08:31:57 --> Total execution time: 0.0455
INFO - 2021-07-16 08:31:57 --> Config Class Initialized
INFO - 2021-07-16 08:31:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:31:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:31:57 --> Utf8 Class Initialized
INFO - 2021-07-16 08:31:57 --> URI Class Initialized
INFO - 2021-07-16 08:31:57 --> Router Class Initialized
INFO - 2021-07-16 08:31:57 --> Output Class Initialized
INFO - 2021-07-16 08:31:57 --> Security Class Initialized
DEBUG - 2021-07-16 08:31:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:31:57 --> Input Class Initialized
INFO - 2021-07-16 08:31:57 --> Language Class Initialized
INFO - 2021-07-16 08:31:57 --> Language Class Initialized
INFO - 2021-07-16 08:31:57 --> Config Class Initialized
INFO - 2021-07-16 08:31:57 --> Loader Class Initialized
INFO - 2021-07-16 08:31:57 --> Helper loaded: url_helper
INFO - 2021-07-16 08:31:57 --> Helper loaded: file_helper
INFO - 2021-07-16 08:31:57 --> Helper loaded: form_helper
INFO - 2021-07-16 08:31:57 --> Helper loaded: my_helper
INFO - 2021-07-16 08:31:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:31:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:31:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:31:58 --> Controller Class Initialized
INFO - 2021-07-16 08:32:08 --> Config Class Initialized
INFO - 2021-07-16 08:32:08 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:08 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:08 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:08 --> URI Class Initialized
INFO - 2021-07-16 08:32:08 --> Router Class Initialized
INFO - 2021-07-16 08:32:08 --> Output Class Initialized
INFO - 2021-07-16 08:32:08 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:08 --> Input Class Initialized
INFO - 2021-07-16 08:32:08 --> Language Class Initialized
INFO - 2021-07-16 08:32:08 --> Language Class Initialized
INFO - 2021-07-16 08:32:08 --> Config Class Initialized
INFO - 2021-07-16 08:32:08 --> Loader Class Initialized
INFO - 2021-07-16 08:32:08 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:08 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:08 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:08 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:08 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:08 --> Controller Class Initialized
INFO - 2021-07-16 08:32:09 --> Config Class Initialized
INFO - 2021-07-16 08:32:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:09 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:09 --> URI Class Initialized
INFO - 2021-07-16 08:32:09 --> Router Class Initialized
INFO - 2021-07-16 08:32:09 --> Output Class Initialized
INFO - 2021-07-16 08:32:09 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:09 --> Input Class Initialized
INFO - 2021-07-16 08:32:09 --> Language Class Initialized
INFO - 2021-07-16 08:32:09 --> Language Class Initialized
INFO - 2021-07-16 08:32:09 --> Config Class Initialized
INFO - 2021-07-16 08:32:09 --> Loader Class Initialized
INFO - 2021-07-16 08:32:09 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:09 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:09 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:09 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:09 --> Controller Class Initialized
ERROR - 2021-07-16 08:32:09 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:32:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:32:09 --> Final output sent to browser
DEBUG - 2021-07-16 08:32:09 --> Total execution time: 0.0479
INFO - 2021-07-16 08:32:18 --> Config Class Initialized
INFO - 2021-07-16 08:32:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:18 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:18 --> URI Class Initialized
INFO - 2021-07-16 08:32:18 --> Router Class Initialized
INFO - 2021-07-16 08:32:18 --> Output Class Initialized
INFO - 2021-07-16 08:32:18 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:18 --> Input Class Initialized
INFO - 2021-07-16 08:32:18 --> Language Class Initialized
INFO - 2021-07-16 08:32:18 --> Language Class Initialized
INFO - 2021-07-16 08:32:18 --> Config Class Initialized
INFO - 2021-07-16 08:32:18 --> Loader Class Initialized
INFO - 2021-07-16 08:32:18 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:18 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:18 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:18 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:18 --> Controller Class Initialized
INFO - 2021-07-16 08:32:18 --> Upload Class Initialized
INFO - 2021-07-16 08:32:18 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:32:18 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:32:18 --> Config Class Initialized
INFO - 2021-07-16 08:32:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:18 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:18 --> URI Class Initialized
INFO - 2021-07-16 08:32:18 --> Router Class Initialized
INFO - 2021-07-16 08:32:18 --> Output Class Initialized
INFO - 2021-07-16 08:32:18 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:18 --> Input Class Initialized
INFO - 2021-07-16 08:32:18 --> Language Class Initialized
INFO - 2021-07-16 08:32:18 --> Language Class Initialized
INFO - 2021-07-16 08:32:18 --> Config Class Initialized
INFO - 2021-07-16 08:32:18 --> Loader Class Initialized
INFO - 2021-07-16 08:32:18 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:18 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:18 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:18 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:18 --> Controller Class Initialized
DEBUG - 2021-07-16 08:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:32:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:32:18 --> Final output sent to browser
DEBUG - 2021-07-16 08:32:18 --> Total execution time: 0.0580
INFO - 2021-07-16 08:32:18 --> Config Class Initialized
INFO - 2021-07-16 08:32:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:19 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:19 --> URI Class Initialized
INFO - 2021-07-16 08:32:19 --> Router Class Initialized
INFO - 2021-07-16 08:32:19 --> Output Class Initialized
INFO - 2021-07-16 08:32:19 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:19 --> Input Class Initialized
INFO - 2021-07-16 08:32:19 --> Language Class Initialized
INFO - 2021-07-16 08:32:19 --> Language Class Initialized
INFO - 2021-07-16 08:32:19 --> Config Class Initialized
INFO - 2021-07-16 08:32:19 --> Loader Class Initialized
INFO - 2021-07-16 08:32:19 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:19 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:19 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:19 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:19 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:19 --> Controller Class Initialized
INFO - 2021-07-16 08:32:25 --> Config Class Initialized
INFO - 2021-07-16 08:32:25 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:25 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:25 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:25 --> URI Class Initialized
INFO - 2021-07-16 08:32:25 --> Router Class Initialized
INFO - 2021-07-16 08:32:25 --> Output Class Initialized
INFO - 2021-07-16 08:32:25 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:25 --> Input Class Initialized
INFO - 2021-07-16 08:32:25 --> Language Class Initialized
INFO - 2021-07-16 08:32:25 --> Language Class Initialized
INFO - 2021-07-16 08:32:25 --> Config Class Initialized
INFO - 2021-07-16 08:32:25 --> Loader Class Initialized
INFO - 2021-07-16 08:32:25 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:25 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:25 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:25 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:25 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:25 --> Controller Class Initialized
INFO - 2021-07-16 08:32:26 --> Config Class Initialized
INFO - 2021-07-16 08:32:26 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:26 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:26 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:26 --> URI Class Initialized
INFO - 2021-07-16 08:32:26 --> Router Class Initialized
INFO - 2021-07-16 08:32:26 --> Output Class Initialized
INFO - 2021-07-16 08:32:26 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:26 --> Input Class Initialized
INFO - 2021-07-16 08:32:26 --> Language Class Initialized
INFO - 2021-07-16 08:32:26 --> Language Class Initialized
INFO - 2021-07-16 08:32:26 --> Config Class Initialized
INFO - 2021-07-16 08:32:26 --> Loader Class Initialized
INFO - 2021-07-16 08:32:26 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:26 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:26 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:26 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:26 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:26 --> Controller Class Initialized
ERROR - 2021-07-16 08:32:26 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:32:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:32:26 --> Final output sent to browser
DEBUG - 2021-07-16 08:32:26 --> Total execution time: 0.0498
INFO - 2021-07-16 08:32:34 --> Config Class Initialized
INFO - 2021-07-16 08:32:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:34 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:34 --> URI Class Initialized
INFO - 2021-07-16 08:32:34 --> Router Class Initialized
INFO - 2021-07-16 08:32:34 --> Output Class Initialized
INFO - 2021-07-16 08:32:34 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:34 --> Input Class Initialized
INFO - 2021-07-16 08:32:34 --> Language Class Initialized
INFO - 2021-07-16 08:32:34 --> Language Class Initialized
INFO - 2021-07-16 08:32:34 --> Config Class Initialized
INFO - 2021-07-16 08:32:34 --> Loader Class Initialized
INFO - 2021-07-16 08:32:34 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:34 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:34 --> Controller Class Initialized
INFO - 2021-07-16 08:32:34 --> Upload Class Initialized
INFO - 2021-07-16 08:32:34 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:32:34 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:32:34 --> Config Class Initialized
INFO - 2021-07-16 08:32:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:34 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:34 --> URI Class Initialized
INFO - 2021-07-16 08:32:34 --> Router Class Initialized
INFO - 2021-07-16 08:32:34 --> Output Class Initialized
INFO - 2021-07-16 08:32:34 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:34 --> Input Class Initialized
INFO - 2021-07-16 08:32:34 --> Language Class Initialized
INFO - 2021-07-16 08:32:34 --> Language Class Initialized
INFO - 2021-07-16 08:32:34 --> Config Class Initialized
INFO - 2021-07-16 08:32:34 --> Loader Class Initialized
INFO - 2021-07-16 08:32:34 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:34 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:34 --> Controller Class Initialized
DEBUG - 2021-07-16 08:32:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:32:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:32:34 --> Final output sent to browser
DEBUG - 2021-07-16 08:32:34 --> Total execution time: 0.0651
INFO - 2021-07-16 08:32:34 --> Config Class Initialized
INFO - 2021-07-16 08:32:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:34 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:34 --> URI Class Initialized
INFO - 2021-07-16 08:32:34 --> Router Class Initialized
INFO - 2021-07-16 08:32:34 --> Output Class Initialized
INFO - 2021-07-16 08:32:34 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:34 --> Input Class Initialized
INFO - 2021-07-16 08:32:34 --> Language Class Initialized
INFO - 2021-07-16 08:32:34 --> Language Class Initialized
INFO - 2021-07-16 08:32:34 --> Config Class Initialized
INFO - 2021-07-16 08:32:34 --> Loader Class Initialized
INFO - 2021-07-16 08:32:34 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:34 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:34 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:34 --> Controller Class Initialized
INFO - 2021-07-16 08:32:40 --> Config Class Initialized
INFO - 2021-07-16 08:32:40 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:40 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:40 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:40 --> URI Class Initialized
INFO - 2021-07-16 08:32:40 --> Router Class Initialized
INFO - 2021-07-16 08:32:40 --> Output Class Initialized
INFO - 2021-07-16 08:32:40 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:40 --> Input Class Initialized
INFO - 2021-07-16 08:32:40 --> Language Class Initialized
INFO - 2021-07-16 08:32:40 --> Language Class Initialized
INFO - 2021-07-16 08:32:40 --> Config Class Initialized
INFO - 2021-07-16 08:32:40 --> Loader Class Initialized
INFO - 2021-07-16 08:32:40 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:40 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:40 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:40 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:40 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:40 --> Controller Class Initialized
INFO - 2021-07-16 08:32:41 --> Config Class Initialized
INFO - 2021-07-16 08:32:41 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:41 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:41 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:41 --> URI Class Initialized
INFO - 2021-07-16 08:32:41 --> Router Class Initialized
INFO - 2021-07-16 08:32:41 --> Output Class Initialized
INFO - 2021-07-16 08:32:41 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:41 --> Input Class Initialized
INFO - 2021-07-16 08:32:41 --> Language Class Initialized
INFO - 2021-07-16 08:32:41 --> Language Class Initialized
INFO - 2021-07-16 08:32:41 --> Config Class Initialized
INFO - 2021-07-16 08:32:41 --> Loader Class Initialized
INFO - 2021-07-16 08:32:41 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:41 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:41 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:41 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:41 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:41 --> Controller Class Initialized
ERROR - 2021-07-16 08:32:41 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:32:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:32:41 --> Final output sent to browser
DEBUG - 2021-07-16 08:32:41 --> Total execution time: 0.0673
INFO - 2021-07-16 08:32:49 --> Config Class Initialized
INFO - 2021-07-16 08:32:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:49 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:49 --> URI Class Initialized
INFO - 2021-07-16 08:32:49 --> Router Class Initialized
INFO - 2021-07-16 08:32:49 --> Output Class Initialized
INFO - 2021-07-16 08:32:49 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:49 --> Input Class Initialized
INFO - 2021-07-16 08:32:49 --> Language Class Initialized
INFO - 2021-07-16 08:32:49 --> Language Class Initialized
INFO - 2021-07-16 08:32:49 --> Config Class Initialized
INFO - 2021-07-16 08:32:49 --> Loader Class Initialized
INFO - 2021-07-16 08:32:49 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:49 --> Controller Class Initialized
INFO - 2021-07-16 08:32:49 --> Upload Class Initialized
INFO - 2021-07-16 08:32:49 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:32:49 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:32:49 --> Config Class Initialized
INFO - 2021-07-16 08:32:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:49 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:49 --> URI Class Initialized
INFO - 2021-07-16 08:32:49 --> Router Class Initialized
INFO - 2021-07-16 08:32:49 --> Output Class Initialized
INFO - 2021-07-16 08:32:49 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:49 --> Input Class Initialized
INFO - 2021-07-16 08:32:49 --> Language Class Initialized
INFO - 2021-07-16 08:32:49 --> Language Class Initialized
INFO - 2021-07-16 08:32:49 --> Config Class Initialized
INFO - 2021-07-16 08:32:49 --> Loader Class Initialized
INFO - 2021-07-16 08:32:49 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:49 --> Controller Class Initialized
DEBUG - 2021-07-16 08:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:32:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:32:49 --> Final output sent to browser
DEBUG - 2021-07-16 08:32:49 --> Total execution time: 0.0637
INFO - 2021-07-16 08:32:49 --> Config Class Initialized
INFO - 2021-07-16 08:32:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:49 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:49 --> URI Class Initialized
INFO - 2021-07-16 08:32:49 --> Router Class Initialized
INFO - 2021-07-16 08:32:49 --> Output Class Initialized
INFO - 2021-07-16 08:32:49 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:49 --> Input Class Initialized
INFO - 2021-07-16 08:32:49 --> Language Class Initialized
INFO - 2021-07-16 08:32:49 --> Language Class Initialized
INFO - 2021-07-16 08:32:49 --> Config Class Initialized
INFO - 2021-07-16 08:32:49 --> Loader Class Initialized
INFO - 2021-07-16 08:32:49 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:49 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:49 --> Controller Class Initialized
INFO - 2021-07-16 08:32:56 --> Config Class Initialized
INFO - 2021-07-16 08:32:56 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:56 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:56 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:56 --> URI Class Initialized
INFO - 2021-07-16 08:32:56 --> Router Class Initialized
INFO - 2021-07-16 08:32:56 --> Output Class Initialized
INFO - 2021-07-16 08:32:56 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:56 --> Input Class Initialized
INFO - 2021-07-16 08:32:56 --> Language Class Initialized
INFO - 2021-07-16 08:32:56 --> Language Class Initialized
INFO - 2021-07-16 08:32:56 --> Config Class Initialized
INFO - 2021-07-16 08:32:56 --> Loader Class Initialized
INFO - 2021-07-16 08:32:56 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:56 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:56 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:56 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:56 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:56 --> Controller Class Initialized
INFO - 2021-07-16 08:32:56 --> Config Class Initialized
INFO - 2021-07-16 08:32:56 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:32:56 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:32:56 --> Utf8 Class Initialized
INFO - 2021-07-16 08:32:56 --> URI Class Initialized
INFO - 2021-07-16 08:32:56 --> Router Class Initialized
INFO - 2021-07-16 08:32:56 --> Output Class Initialized
INFO - 2021-07-16 08:32:56 --> Security Class Initialized
DEBUG - 2021-07-16 08:32:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:32:56 --> Input Class Initialized
INFO - 2021-07-16 08:32:56 --> Language Class Initialized
INFO - 2021-07-16 08:32:56 --> Language Class Initialized
INFO - 2021-07-16 08:32:56 --> Config Class Initialized
INFO - 2021-07-16 08:32:57 --> Loader Class Initialized
INFO - 2021-07-16 08:32:57 --> Helper loaded: url_helper
INFO - 2021-07-16 08:32:57 --> Helper loaded: file_helper
INFO - 2021-07-16 08:32:57 --> Helper loaded: form_helper
INFO - 2021-07-16 08:32:57 --> Helper loaded: my_helper
INFO - 2021-07-16 08:32:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:32:57 --> Controller Class Initialized
ERROR - 2021-07-16 08:32:57 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:32:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:32:57 --> Final output sent to browser
DEBUG - 2021-07-16 08:32:57 --> Total execution time: 0.0665
INFO - 2021-07-16 08:33:07 --> Config Class Initialized
INFO - 2021-07-16 08:33:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:07 --> URI Class Initialized
INFO - 2021-07-16 08:33:07 --> Router Class Initialized
INFO - 2021-07-16 08:33:07 --> Output Class Initialized
INFO - 2021-07-16 08:33:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:07 --> Input Class Initialized
INFO - 2021-07-16 08:33:07 --> Language Class Initialized
INFO - 2021-07-16 08:33:07 --> Language Class Initialized
INFO - 2021-07-16 08:33:07 --> Config Class Initialized
INFO - 2021-07-16 08:33:07 --> Loader Class Initialized
INFO - 2021-07-16 08:33:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:07 --> Controller Class Initialized
INFO - 2021-07-16 08:33:07 --> Upload Class Initialized
INFO - 2021-07-16 08:33:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:33:07 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:33:07 --> Config Class Initialized
INFO - 2021-07-16 08:33:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:07 --> URI Class Initialized
INFO - 2021-07-16 08:33:07 --> Router Class Initialized
INFO - 2021-07-16 08:33:07 --> Output Class Initialized
INFO - 2021-07-16 08:33:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:07 --> Input Class Initialized
INFO - 2021-07-16 08:33:07 --> Language Class Initialized
INFO - 2021-07-16 08:33:07 --> Language Class Initialized
INFO - 2021-07-16 08:33:07 --> Config Class Initialized
INFO - 2021-07-16 08:33:07 --> Loader Class Initialized
INFO - 2021-07-16 08:33:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:07 --> Controller Class Initialized
DEBUG - 2021-07-16 08:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:33:07 --> Final output sent to browser
DEBUG - 2021-07-16 08:33:07 --> Total execution time: 0.0451
INFO - 2021-07-16 08:33:07 --> Config Class Initialized
INFO - 2021-07-16 08:33:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:07 --> URI Class Initialized
INFO - 2021-07-16 08:33:07 --> Router Class Initialized
INFO - 2021-07-16 08:33:07 --> Output Class Initialized
INFO - 2021-07-16 08:33:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:07 --> Input Class Initialized
INFO - 2021-07-16 08:33:07 --> Language Class Initialized
INFO - 2021-07-16 08:33:07 --> Language Class Initialized
INFO - 2021-07-16 08:33:07 --> Config Class Initialized
INFO - 2021-07-16 08:33:07 --> Loader Class Initialized
INFO - 2021-07-16 08:33:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:07 --> Controller Class Initialized
INFO - 2021-07-16 08:33:13 --> Config Class Initialized
INFO - 2021-07-16 08:33:13 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:13 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:13 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:13 --> URI Class Initialized
INFO - 2021-07-16 08:33:13 --> Router Class Initialized
INFO - 2021-07-16 08:33:13 --> Output Class Initialized
INFO - 2021-07-16 08:33:13 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:13 --> Input Class Initialized
INFO - 2021-07-16 08:33:13 --> Language Class Initialized
INFO - 2021-07-16 08:33:13 --> Language Class Initialized
INFO - 2021-07-16 08:33:13 --> Config Class Initialized
INFO - 2021-07-16 08:33:13 --> Loader Class Initialized
INFO - 2021-07-16 08:33:13 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:13 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:13 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:13 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:13 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:13 --> Controller Class Initialized
INFO - 2021-07-16 08:33:13 --> Config Class Initialized
INFO - 2021-07-16 08:33:13 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:13 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:13 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:13 --> URI Class Initialized
INFO - 2021-07-16 08:33:13 --> Router Class Initialized
INFO - 2021-07-16 08:33:13 --> Output Class Initialized
INFO - 2021-07-16 08:33:13 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:13 --> Input Class Initialized
INFO - 2021-07-16 08:33:13 --> Language Class Initialized
INFO - 2021-07-16 08:33:13 --> Language Class Initialized
INFO - 2021-07-16 08:33:13 --> Config Class Initialized
INFO - 2021-07-16 08:33:13 --> Loader Class Initialized
INFO - 2021-07-16 08:33:13 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:13 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:13 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:13 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:13 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:13 --> Controller Class Initialized
ERROR - 2021-07-16 08:33:13 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:33:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:33:13 --> Final output sent to browser
DEBUG - 2021-07-16 08:33:13 --> Total execution time: 0.0482
INFO - 2021-07-16 08:33:21 --> Config Class Initialized
INFO - 2021-07-16 08:33:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:21 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:21 --> URI Class Initialized
INFO - 2021-07-16 08:33:21 --> Router Class Initialized
INFO - 2021-07-16 08:33:21 --> Output Class Initialized
INFO - 2021-07-16 08:33:21 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:21 --> Input Class Initialized
INFO - 2021-07-16 08:33:21 --> Language Class Initialized
INFO - 2021-07-16 08:33:21 --> Language Class Initialized
INFO - 2021-07-16 08:33:21 --> Config Class Initialized
INFO - 2021-07-16 08:33:21 --> Loader Class Initialized
INFO - 2021-07-16 08:33:21 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:21 --> Controller Class Initialized
INFO - 2021-07-16 08:33:21 --> Upload Class Initialized
INFO - 2021-07-16 08:33:21 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:33:21 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:33:21 --> Config Class Initialized
INFO - 2021-07-16 08:33:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:21 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:21 --> URI Class Initialized
INFO - 2021-07-16 08:33:21 --> Router Class Initialized
INFO - 2021-07-16 08:33:21 --> Output Class Initialized
INFO - 2021-07-16 08:33:21 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:21 --> Input Class Initialized
INFO - 2021-07-16 08:33:21 --> Language Class Initialized
INFO - 2021-07-16 08:33:21 --> Language Class Initialized
INFO - 2021-07-16 08:33:21 --> Config Class Initialized
INFO - 2021-07-16 08:33:21 --> Loader Class Initialized
INFO - 2021-07-16 08:33:21 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:21 --> Controller Class Initialized
DEBUG - 2021-07-16 08:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:33:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:33:21 --> Final output sent to browser
DEBUG - 2021-07-16 08:33:21 --> Total execution time: 0.0666
INFO - 2021-07-16 08:33:21 --> Config Class Initialized
INFO - 2021-07-16 08:33:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:21 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:21 --> URI Class Initialized
INFO - 2021-07-16 08:33:21 --> Router Class Initialized
INFO - 2021-07-16 08:33:21 --> Output Class Initialized
INFO - 2021-07-16 08:33:21 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:21 --> Input Class Initialized
INFO - 2021-07-16 08:33:21 --> Language Class Initialized
INFO - 2021-07-16 08:33:21 --> Language Class Initialized
INFO - 2021-07-16 08:33:21 --> Config Class Initialized
INFO - 2021-07-16 08:33:21 --> Loader Class Initialized
INFO - 2021-07-16 08:33:21 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:21 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:21 --> Controller Class Initialized
INFO - 2021-07-16 08:33:29 --> Config Class Initialized
INFO - 2021-07-16 08:33:29 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:29 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:29 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:29 --> URI Class Initialized
INFO - 2021-07-16 08:33:29 --> Router Class Initialized
INFO - 2021-07-16 08:33:29 --> Output Class Initialized
INFO - 2021-07-16 08:33:29 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:29 --> Input Class Initialized
INFO - 2021-07-16 08:33:29 --> Language Class Initialized
INFO - 2021-07-16 08:33:29 --> Language Class Initialized
INFO - 2021-07-16 08:33:29 --> Config Class Initialized
INFO - 2021-07-16 08:33:29 --> Loader Class Initialized
INFO - 2021-07-16 08:33:29 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:29 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:29 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:29 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:29 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:29 --> Controller Class Initialized
INFO - 2021-07-16 08:33:29 --> Config Class Initialized
INFO - 2021-07-16 08:33:29 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:29 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:29 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:29 --> URI Class Initialized
INFO - 2021-07-16 08:33:29 --> Router Class Initialized
INFO - 2021-07-16 08:33:29 --> Output Class Initialized
INFO - 2021-07-16 08:33:29 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:29 --> Input Class Initialized
INFO - 2021-07-16 08:33:29 --> Language Class Initialized
INFO - 2021-07-16 08:33:29 --> Language Class Initialized
INFO - 2021-07-16 08:33:29 --> Config Class Initialized
INFO - 2021-07-16 08:33:29 --> Loader Class Initialized
INFO - 2021-07-16 08:33:29 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:29 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:29 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:29 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:29 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:29 --> Controller Class Initialized
ERROR - 2021-07-16 08:33:29 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:33:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:33:29 --> Final output sent to browser
DEBUG - 2021-07-16 08:33:29 --> Total execution time: 0.0654
INFO - 2021-07-16 08:33:37 --> Config Class Initialized
INFO - 2021-07-16 08:33:37 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:37 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:37 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:37 --> URI Class Initialized
INFO - 2021-07-16 08:33:37 --> Router Class Initialized
INFO - 2021-07-16 08:33:37 --> Output Class Initialized
INFO - 2021-07-16 08:33:37 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:37 --> Input Class Initialized
INFO - 2021-07-16 08:33:37 --> Language Class Initialized
INFO - 2021-07-16 08:33:37 --> Language Class Initialized
INFO - 2021-07-16 08:33:37 --> Config Class Initialized
INFO - 2021-07-16 08:33:37 --> Loader Class Initialized
INFO - 2021-07-16 08:33:37 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:37 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:37 --> Controller Class Initialized
INFO - 2021-07-16 08:33:37 --> Upload Class Initialized
INFO - 2021-07-16 08:33:37 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:33:37 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:33:37 --> Config Class Initialized
INFO - 2021-07-16 08:33:37 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:37 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:37 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:37 --> URI Class Initialized
INFO - 2021-07-16 08:33:37 --> Router Class Initialized
INFO - 2021-07-16 08:33:37 --> Output Class Initialized
INFO - 2021-07-16 08:33:37 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:37 --> Input Class Initialized
INFO - 2021-07-16 08:33:37 --> Language Class Initialized
INFO - 2021-07-16 08:33:37 --> Language Class Initialized
INFO - 2021-07-16 08:33:37 --> Config Class Initialized
INFO - 2021-07-16 08:33:37 --> Loader Class Initialized
INFO - 2021-07-16 08:33:37 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:37 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:37 --> Controller Class Initialized
DEBUG - 2021-07-16 08:33:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:33:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:33:37 --> Final output sent to browser
DEBUG - 2021-07-16 08:33:37 --> Total execution time: 0.0648
INFO - 2021-07-16 08:33:37 --> Config Class Initialized
INFO - 2021-07-16 08:33:37 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:37 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:37 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:37 --> URI Class Initialized
INFO - 2021-07-16 08:33:37 --> Router Class Initialized
INFO - 2021-07-16 08:33:37 --> Output Class Initialized
INFO - 2021-07-16 08:33:37 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:37 --> Input Class Initialized
INFO - 2021-07-16 08:33:37 --> Language Class Initialized
INFO - 2021-07-16 08:33:37 --> Language Class Initialized
INFO - 2021-07-16 08:33:37 --> Config Class Initialized
INFO - 2021-07-16 08:33:37 --> Loader Class Initialized
INFO - 2021-07-16 08:33:37 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:37 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:37 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:37 --> Controller Class Initialized
INFO - 2021-07-16 08:33:43 --> Config Class Initialized
INFO - 2021-07-16 08:33:43 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:43 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:43 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:43 --> URI Class Initialized
INFO - 2021-07-16 08:33:43 --> Router Class Initialized
INFO - 2021-07-16 08:33:43 --> Output Class Initialized
INFO - 2021-07-16 08:33:43 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:43 --> Input Class Initialized
INFO - 2021-07-16 08:33:43 --> Language Class Initialized
INFO - 2021-07-16 08:33:43 --> Language Class Initialized
INFO - 2021-07-16 08:33:43 --> Config Class Initialized
INFO - 2021-07-16 08:33:43 --> Loader Class Initialized
INFO - 2021-07-16 08:33:43 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:43 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:43 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:43 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:43 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:43 --> Controller Class Initialized
INFO - 2021-07-16 08:33:44 --> Config Class Initialized
INFO - 2021-07-16 08:33:44 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:44 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:44 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:44 --> URI Class Initialized
INFO - 2021-07-16 08:33:44 --> Router Class Initialized
INFO - 2021-07-16 08:33:44 --> Output Class Initialized
INFO - 2021-07-16 08:33:44 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:44 --> Input Class Initialized
INFO - 2021-07-16 08:33:44 --> Language Class Initialized
INFO - 2021-07-16 08:33:44 --> Language Class Initialized
INFO - 2021-07-16 08:33:44 --> Config Class Initialized
INFO - 2021-07-16 08:33:44 --> Loader Class Initialized
INFO - 2021-07-16 08:33:44 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:44 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:44 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:44 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:44 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:44 --> Controller Class Initialized
ERROR - 2021-07-16 08:33:44 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:33:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:33:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:33:44 --> Final output sent to browser
DEBUG - 2021-07-16 08:33:44 --> Total execution time: 0.0604
INFO - 2021-07-16 08:33:53 --> Config Class Initialized
INFO - 2021-07-16 08:33:53 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:53 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:53 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:53 --> URI Class Initialized
INFO - 2021-07-16 08:33:53 --> Router Class Initialized
INFO - 2021-07-16 08:33:53 --> Output Class Initialized
INFO - 2021-07-16 08:33:53 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:53 --> Input Class Initialized
INFO - 2021-07-16 08:33:53 --> Language Class Initialized
INFO - 2021-07-16 08:33:53 --> Language Class Initialized
INFO - 2021-07-16 08:33:53 --> Config Class Initialized
INFO - 2021-07-16 08:33:53 --> Loader Class Initialized
INFO - 2021-07-16 08:33:53 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:53 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:53 --> Controller Class Initialized
INFO - 2021-07-16 08:33:53 --> Upload Class Initialized
INFO - 2021-07-16 08:33:53 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:33:53 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:33:53 --> Config Class Initialized
INFO - 2021-07-16 08:33:53 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:53 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:53 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:53 --> URI Class Initialized
INFO - 2021-07-16 08:33:53 --> Router Class Initialized
INFO - 2021-07-16 08:33:53 --> Output Class Initialized
INFO - 2021-07-16 08:33:53 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:53 --> Input Class Initialized
INFO - 2021-07-16 08:33:53 --> Language Class Initialized
INFO - 2021-07-16 08:33:53 --> Language Class Initialized
INFO - 2021-07-16 08:33:53 --> Config Class Initialized
INFO - 2021-07-16 08:33:53 --> Loader Class Initialized
INFO - 2021-07-16 08:33:53 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:53 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:53 --> Controller Class Initialized
DEBUG - 2021-07-16 08:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:33:53 --> Final output sent to browser
DEBUG - 2021-07-16 08:33:53 --> Total execution time: 0.0434
INFO - 2021-07-16 08:33:53 --> Config Class Initialized
INFO - 2021-07-16 08:33:53 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:53 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:53 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:53 --> URI Class Initialized
INFO - 2021-07-16 08:33:53 --> Router Class Initialized
INFO - 2021-07-16 08:33:53 --> Output Class Initialized
INFO - 2021-07-16 08:33:53 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:53 --> Input Class Initialized
INFO - 2021-07-16 08:33:53 --> Language Class Initialized
INFO - 2021-07-16 08:33:53 --> Language Class Initialized
INFO - 2021-07-16 08:33:53 --> Config Class Initialized
INFO - 2021-07-16 08:33:53 --> Loader Class Initialized
INFO - 2021-07-16 08:33:53 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:53 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:53 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:53 --> Controller Class Initialized
INFO - 2021-07-16 08:33:59 --> Config Class Initialized
INFO - 2021-07-16 08:33:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:33:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:33:59 --> Utf8 Class Initialized
INFO - 2021-07-16 08:33:59 --> URI Class Initialized
INFO - 2021-07-16 08:33:59 --> Router Class Initialized
INFO - 2021-07-16 08:33:59 --> Output Class Initialized
INFO - 2021-07-16 08:33:59 --> Security Class Initialized
DEBUG - 2021-07-16 08:33:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:33:59 --> Input Class Initialized
INFO - 2021-07-16 08:33:59 --> Language Class Initialized
INFO - 2021-07-16 08:33:59 --> Language Class Initialized
INFO - 2021-07-16 08:33:59 --> Config Class Initialized
INFO - 2021-07-16 08:33:59 --> Loader Class Initialized
INFO - 2021-07-16 08:33:59 --> Helper loaded: url_helper
INFO - 2021-07-16 08:33:59 --> Helper loaded: file_helper
INFO - 2021-07-16 08:33:59 --> Helper loaded: form_helper
INFO - 2021-07-16 08:33:59 --> Helper loaded: my_helper
INFO - 2021-07-16 08:33:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:33:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:33:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:33:59 --> Controller Class Initialized
INFO - 2021-07-16 08:34:00 --> Config Class Initialized
INFO - 2021-07-16 08:34:00 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:00 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:00 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:00 --> URI Class Initialized
INFO - 2021-07-16 08:34:00 --> Router Class Initialized
INFO - 2021-07-16 08:34:00 --> Output Class Initialized
INFO - 2021-07-16 08:34:00 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:00 --> Input Class Initialized
INFO - 2021-07-16 08:34:00 --> Language Class Initialized
INFO - 2021-07-16 08:34:00 --> Language Class Initialized
INFO - 2021-07-16 08:34:00 --> Config Class Initialized
INFO - 2021-07-16 08:34:00 --> Loader Class Initialized
INFO - 2021-07-16 08:34:00 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:00 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:00 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:00 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:00 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:00 --> Controller Class Initialized
ERROR - 2021-07-16 08:34:00 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:34:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:34:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:34:00 --> Final output sent to browser
DEBUG - 2021-07-16 08:34:00 --> Total execution time: 0.0605
INFO - 2021-07-16 08:34:07 --> Config Class Initialized
INFO - 2021-07-16 08:34:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:07 --> URI Class Initialized
INFO - 2021-07-16 08:34:07 --> Router Class Initialized
INFO - 2021-07-16 08:34:07 --> Output Class Initialized
INFO - 2021-07-16 08:34:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:07 --> Input Class Initialized
INFO - 2021-07-16 08:34:07 --> Language Class Initialized
INFO - 2021-07-16 08:34:07 --> Language Class Initialized
INFO - 2021-07-16 08:34:07 --> Config Class Initialized
INFO - 2021-07-16 08:34:07 --> Loader Class Initialized
INFO - 2021-07-16 08:34:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:07 --> Controller Class Initialized
INFO - 2021-07-16 08:34:07 --> Upload Class Initialized
INFO - 2021-07-16 08:34:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:34:07 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:34:07 --> Config Class Initialized
INFO - 2021-07-16 08:34:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:07 --> URI Class Initialized
INFO - 2021-07-16 08:34:07 --> Router Class Initialized
INFO - 2021-07-16 08:34:07 --> Output Class Initialized
INFO - 2021-07-16 08:34:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:07 --> Input Class Initialized
INFO - 2021-07-16 08:34:07 --> Language Class Initialized
INFO - 2021-07-16 08:34:07 --> Language Class Initialized
INFO - 2021-07-16 08:34:07 --> Config Class Initialized
INFO - 2021-07-16 08:34:07 --> Loader Class Initialized
INFO - 2021-07-16 08:34:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:07 --> Controller Class Initialized
DEBUG - 2021-07-16 08:34:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:34:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:34:07 --> Final output sent to browser
DEBUG - 2021-07-16 08:34:07 --> Total execution time: 0.0650
INFO - 2021-07-16 08:34:07 --> Config Class Initialized
INFO - 2021-07-16 08:34:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:07 --> URI Class Initialized
INFO - 2021-07-16 08:34:07 --> Router Class Initialized
INFO - 2021-07-16 08:34:07 --> Output Class Initialized
INFO - 2021-07-16 08:34:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:07 --> Input Class Initialized
INFO - 2021-07-16 08:34:07 --> Language Class Initialized
INFO - 2021-07-16 08:34:07 --> Language Class Initialized
INFO - 2021-07-16 08:34:07 --> Config Class Initialized
INFO - 2021-07-16 08:34:07 --> Loader Class Initialized
INFO - 2021-07-16 08:34:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:07 --> Controller Class Initialized
INFO - 2021-07-16 08:34:19 --> Config Class Initialized
INFO - 2021-07-16 08:34:19 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:19 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:19 --> URI Class Initialized
INFO - 2021-07-16 08:34:19 --> Router Class Initialized
INFO - 2021-07-16 08:34:19 --> Output Class Initialized
INFO - 2021-07-16 08:34:19 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:19 --> Input Class Initialized
INFO - 2021-07-16 08:34:19 --> Language Class Initialized
INFO - 2021-07-16 08:34:19 --> Language Class Initialized
INFO - 2021-07-16 08:34:19 --> Config Class Initialized
INFO - 2021-07-16 08:34:19 --> Loader Class Initialized
INFO - 2021-07-16 08:34:19 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:19 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:19 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:19 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:19 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:19 --> Controller Class Initialized
INFO - 2021-07-16 08:34:20 --> Config Class Initialized
INFO - 2021-07-16 08:34:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:20 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:20 --> URI Class Initialized
INFO - 2021-07-16 08:34:20 --> Router Class Initialized
INFO - 2021-07-16 08:34:20 --> Output Class Initialized
INFO - 2021-07-16 08:34:20 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:20 --> Input Class Initialized
INFO - 2021-07-16 08:34:20 --> Language Class Initialized
INFO - 2021-07-16 08:34:20 --> Language Class Initialized
INFO - 2021-07-16 08:34:20 --> Config Class Initialized
INFO - 2021-07-16 08:34:20 --> Loader Class Initialized
INFO - 2021-07-16 08:34:20 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:20 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:20 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:20 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:20 --> Controller Class Initialized
ERROR - 2021-07-16 08:34:20 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:34:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:34:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:34:20 --> Final output sent to browser
DEBUG - 2021-07-16 08:34:20 --> Total execution time: 0.0489
INFO - 2021-07-16 08:34:28 --> Config Class Initialized
INFO - 2021-07-16 08:34:28 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:28 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:28 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:28 --> URI Class Initialized
INFO - 2021-07-16 08:34:28 --> Router Class Initialized
INFO - 2021-07-16 08:34:28 --> Output Class Initialized
INFO - 2021-07-16 08:34:28 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:28 --> Input Class Initialized
INFO - 2021-07-16 08:34:28 --> Language Class Initialized
INFO - 2021-07-16 08:34:28 --> Language Class Initialized
INFO - 2021-07-16 08:34:28 --> Config Class Initialized
INFO - 2021-07-16 08:34:28 --> Loader Class Initialized
INFO - 2021-07-16 08:34:28 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:28 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:28 --> Controller Class Initialized
INFO - 2021-07-16 08:34:28 --> Upload Class Initialized
INFO - 2021-07-16 08:34:28 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:34:28 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:34:28 --> Config Class Initialized
INFO - 2021-07-16 08:34:28 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:28 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:28 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:28 --> URI Class Initialized
INFO - 2021-07-16 08:34:28 --> Router Class Initialized
INFO - 2021-07-16 08:34:28 --> Output Class Initialized
INFO - 2021-07-16 08:34:28 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:28 --> Input Class Initialized
INFO - 2021-07-16 08:34:28 --> Language Class Initialized
INFO - 2021-07-16 08:34:28 --> Language Class Initialized
INFO - 2021-07-16 08:34:28 --> Config Class Initialized
INFO - 2021-07-16 08:34:28 --> Loader Class Initialized
INFO - 2021-07-16 08:34:28 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:28 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:28 --> Controller Class Initialized
DEBUG - 2021-07-16 08:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:34:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:34:28 --> Final output sent to browser
DEBUG - 2021-07-16 08:34:28 --> Total execution time: 0.0657
INFO - 2021-07-16 08:34:28 --> Config Class Initialized
INFO - 2021-07-16 08:34:28 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:28 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:28 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:28 --> URI Class Initialized
INFO - 2021-07-16 08:34:28 --> Router Class Initialized
INFO - 2021-07-16 08:34:28 --> Output Class Initialized
INFO - 2021-07-16 08:34:28 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:28 --> Input Class Initialized
INFO - 2021-07-16 08:34:28 --> Language Class Initialized
INFO - 2021-07-16 08:34:28 --> Language Class Initialized
INFO - 2021-07-16 08:34:28 --> Config Class Initialized
INFO - 2021-07-16 08:34:28 --> Loader Class Initialized
INFO - 2021-07-16 08:34:28 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:28 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:28 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:28 --> Controller Class Initialized
INFO - 2021-07-16 08:34:34 --> Config Class Initialized
INFO - 2021-07-16 08:34:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:34 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:34 --> URI Class Initialized
INFO - 2021-07-16 08:34:34 --> Router Class Initialized
INFO - 2021-07-16 08:34:34 --> Output Class Initialized
INFO - 2021-07-16 08:34:34 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:34 --> Input Class Initialized
INFO - 2021-07-16 08:34:34 --> Language Class Initialized
INFO - 2021-07-16 08:34:35 --> Language Class Initialized
INFO - 2021-07-16 08:34:35 --> Config Class Initialized
INFO - 2021-07-16 08:34:35 --> Loader Class Initialized
INFO - 2021-07-16 08:34:35 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:35 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:35 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:35 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:35 --> Controller Class Initialized
INFO - 2021-07-16 08:34:35 --> Config Class Initialized
INFO - 2021-07-16 08:34:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:35 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:35 --> URI Class Initialized
INFO - 2021-07-16 08:34:35 --> Router Class Initialized
INFO - 2021-07-16 08:34:35 --> Output Class Initialized
INFO - 2021-07-16 08:34:35 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:35 --> Input Class Initialized
INFO - 2021-07-16 08:34:35 --> Language Class Initialized
INFO - 2021-07-16 08:34:35 --> Language Class Initialized
INFO - 2021-07-16 08:34:35 --> Config Class Initialized
INFO - 2021-07-16 08:34:35 --> Loader Class Initialized
INFO - 2021-07-16 08:34:35 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:35 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:35 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:35 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:35 --> Controller Class Initialized
ERROR - 2021-07-16 08:34:35 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:34:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:34:35 --> Final output sent to browser
DEBUG - 2021-07-16 08:34:35 --> Total execution time: 0.0691
INFO - 2021-07-16 08:34:44 --> Config Class Initialized
INFO - 2021-07-16 08:34:44 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:44 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:44 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:44 --> URI Class Initialized
INFO - 2021-07-16 08:34:44 --> Router Class Initialized
INFO - 2021-07-16 08:34:44 --> Output Class Initialized
INFO - 2021-07-16 08:34:44 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:44 --> Input Class Initialized
INFO - 2021-07-16 08:34:44 --> Language Class Initialized
INFO - 2021-07-16 08:34:44 --> Language Class Initialized
INFO - 2021-07-16 08:34:44 --> Config Class Initialized
INFO - 2021-07-16 08:34:44 --> Loader Class Initialized
INFO - 2021-07-16 08:34:44 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:44 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:44 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:44 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:44 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:44 --> Controller Class Initialized
INFO - 2021-07-16 08:34:44 --> Upload Class Initialized
INFO - 2021-07-16 08:34:44 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:34:44 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:34:44 --> Config Class Initialized
INFO - 2021-07-16 08:34:44 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:44 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:44 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:44 --> URI Class Initialized
INFO - 2021-07-16 08:34:45 --> Router Class Initialized
INFO - 2021-07-16 08:34:45 --> Output Class Initialized
INFO - 2021-07-16 08:34:45 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:45 --> Input Class Initialized
INFO - 2021-07-16 08:34:45 --> Language Class Initialized
INFO - 2021-07-16 08:34:45 --> Language Class Initialized
INFO - 2021-07-16 08:34:45 --> Config Class Initialized
INFO - 2021-07-16 08:34:45 --> Loader Class Initialized
INFO - 2021-07-16 08:34:45 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:45 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:45 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:45 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:45 --> Controller Class Initialized
DEBUG - 2021-07-16 08:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:34:45 --> Final output sent to browser
DEBUG - 2021-07-16 08:34:45 --> Total execution time: 0.0622
INFO - 2021-07-16 08:34:45 --> Config Class Initialized
INFO - 2021-07-16 08:34:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:45 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:45 --> URI Class Initialized
INFO - 2021-07-16 08:34:45 --> Router Class Initialized
INFO - 2021-07-16 08:34:45 --> Output Class Initialized
INFO - 2021-07-16 08:34:45 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:45 --> Input Class Initialized
INFO - 2021-07-16 08:34:45 --> Language Class Initialized
INFO - 2021-07-16 08:34:45 --> Language Class Initialized
INFO - 2021-07-16 08:34:45 --> Config Class Initialized
INFO - 2021-07-16 08:34:45 --> Loader Class Initialized
INFO - 2021-07-16 08:34:45 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:45 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:45 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:45 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:45 --> Controller Class Initialized
INFO - 2021-07-16 08:34:52 --> Config Class Initialized
INFO - 2021-07-16 08:34:52 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:52 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:52 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:52 --> URI Class Initialized
INFO - 2021-07-16 08:34:52 --> Router Class Initialized
INFO - 2021-07-16 08:34:52 --> Output Class Initialized
INFO - 2021-07-16 08:34:52 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:52 --> Input Class Initialized
INFO - 2021-07-16 08:34:52 --> Language Class Initialized
INFO - 2021-07-16 08:34:52 --> Language Class Initialized
INFO - 2021-07-16 08:34:52 --> Config Class Initialized
INFO - 2021-07-16 08:34:52 --> Loader Class Initialized
INFO - 2021-07-16 08:34:52 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:52 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:52 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:52 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:52 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:52 --> Controller Class Initialized
INFO - 2021-07-16 08:34:52 --> Config Class Initialized
INFO - 2021-07-16 08:34:52 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:34:52 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:34:52 --> Utf8 Class Initialized
INFO - 2021-07-16 08:34:52 --> URI Class Initialized
INFO - 2021-07-16 08:34:52 --> Router Class Initialized
INFO - 2021-07-16 08:34:52 --> Output Class Initialized
INFO - 2021-07-16 08:34:52 --> Security Class Initialized
DEBUG - 2021-07-16 08:34:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:34:52 --> Input Class Initialized
INFO - 2021-07-16 08:34:52 --> Language Class Initialized
INFO - 2021-07-16 08:34:52 --> Language Class Initialized
INFO - 2021-07-16 08:34:52 --> Config Class Initialized
INFO - 2021-07-16 08:34:52 --> Loader Class Initialized
INFO - 2021-07-16 08:34:52 --> Helper loaded: url_helper
INFO - 2021-07-16 08:34:52 --> Helper loaded: file_helper
INFO - 2021-07-16 08:34:52 --> Helper loaded: form_helper
INFO - 2021-07-16 08:34:52 --> Helper loaded: my_helper
INFO - 2021-07-16 08:34:52 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:34:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:34:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:34:52 --> Controller Class Initialized
ERROR - 2021-07-16 08:34:52 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:34:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:34:52 --> Final output sent to browser
DEBUG - 2021-07-16 08:34:52 --> Total execution time: 0.0618
INFO - 2021-07-16 08:35:01 --> Config Class Initialized
INFO - 2021-07-16 08:35:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:01 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:01 --> URI Class Initialized
INFO - 2021-07-16 08:35:01 --> Router Class Initialized
INFO - 2021-07-16 08:35:01 --> Output Class Initialized
INFO - 2021-07-16 08:35:01 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:01 --> Input Class Initialized
INFO - 2021-07-16 08:35:01 --> Language Class Initialized
INFO - 2021-07-16 08:35:01 --> Language Class Initialized
INFO - 2021-07-16 08:35:01 --> Config Class Initialized
INFO - 2021-07-16 08:35:01 --> Loader Class Initialized
INFO - 2021-07-16 08:35:01 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:01 --> Controller Class Initialized
INFO - 2021-07-16 08:35:01 --> Upload Class Initialized
INFO - 2021-07-16 08:35:01 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:35:01 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:35:01 --> Config Class Initialized
INFO - 2021-07-16 08:35:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:01 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:01 --> URI Class Initialized
INFO - 2021-07-16 08:35:01 --> Router Class Initialized
INFO - 2021-07-16 08:35:01 --> Output Class Initialized
INFO - 2021-07-16 08:35:01 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:01 --> Input Class Initialized
INFO - 2021-07-16 08:35:01 --> Language Class Initialized
INFO - 2021-07-16 08:35:01 --> Language Class Initialized
INFO - 2021-07-16 08:35:01 --> Config Class Initialized
INFO - 2021-07-16 08:35:01 --> Loader Class Initialized
INFO - 2021-07-16 08:35:01 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:01 --> Controller Class Initialized
DEBUG - 2021-07-16 08:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:01 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:01 --> Total execution time: 0.0429
INFO - 2021-07-16 08:35:01 --> Config Class Initialized
INFO - 2021-07-16 08:35:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:01 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:01 --> URI Class Initialized
INFO - 2021-07-16 08:35:01 --> Router Class Initialized
INFO - 2021-07-16 08:35:01 --> Output Class Initialized
INFO - 2021-07-16 08:35:01 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:01 --> Input Class Initialized
INFO - 2021-07-16 08:35:01 --> Language Class Initialized
INFO - 2021-07-16 08:35:01 --> Language Class Initialized
INFO - 2021-07-16 08:35:01 --> Config Class Initialized
INFO - 2021-07-16 08:35:01 --> Loader Class Initialized
INFO - 2021-07-16 08:35:01 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:01 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:01 --> Controller Class Initialized
INFO - 2021-07-16 08:35:12 --> Config Class Initialized
INFO - 2021-07-16 08:35:12 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:12 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:12 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:12 --> URI Class Initialized
INFO - 2021-07-16 08:35:12 --> Router Class Initialized
INFO - 2021-07-16 08:35:12 --> Output Class Initialized
INFO - 2021-07-16 08:35:12 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:12 --> Input Class Initialized
INFO - 2021-07-16 08:35:12 --> Language Class Initialized
INFO - 2021-07-16 08:35:12 --> Language Class Initialized
INFO - 2021-07-16 08:35:12 --> Config Class Initialized
INFO - 2021-07-16 08:35:12 --> Loader Class Initialized
INFO - 2021-07-16 08:35:12 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:12 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:12 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:12 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:12 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:12 --> Controller Class Initialized
INFO - 2021-07-16 08:35:12 --> Config Class Initialized
INFO - 2021-07-16 08:35:12 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:12 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:12 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:12 --> URI Class Initialized
INFO - 2021-07-16 08:35:12 --> Router Class Initialized
INFO - 2021-07-16 08:35:12 --> Output Class Initialized
INFO - 2021-07-16 08:35:12 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:12 --> Input Class Initialized
INFO - 2021-07-16 08:35:12 --> Language Class Initialized
INFO - 2021-07-16 08:35:12 --> Language Class Initialized
INFO - 2021-07-16 08:35:12 --> Config Class Initialized
INFO - 2021-07-16 08:35:12 --> Loader Class Initialized
INFO - 2021-07-16 08:35:12 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:12 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:12 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:12 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:12 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:12 --> Controller Class Initialized
ERROR - 2021-07-16 08:35:12 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:35:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:35:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:12 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:12 --> Total execution time: 0.0609
INFO - 2021-07-16 08:35:20 --> Config Class Initialized
INFO - 2021-07-16 08:35:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:20 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:20 --> URI Class Initialized
INFO - 2021-07-16 08:35:20 --> Router Class Initialized
INFO - 2021-07-16 08:35:20 --> Output Class Initialized
INFO - 2021-07-16 08:35:20 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:20 --> Input Class Initialized
INFO - 2021-07-16 08:35:20 --> Language Class Initialized
INFO - 2021-07-16 08:35:20 --> Language Class Initialized
INFO - 2021-07-16 08:35:20 --> Config Class Initialized
INFO - 2021-07-16 08:35:20 --> Loader Class Initialized
INFO - 2021-07-16 08:35:20 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:20 --> Controller Class Initialized
INFO - 2021-07-16 08:35:20 --> Upload Class Initialized
INFO - 2021-07-16 08:35:20 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:35:20 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:35:20 --> Config Class Initialized
INFO - 2021-07-16 08:35:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:20 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:20 --> URI Class Initialized
INFO - 2021-07-16 08:35:20 --> Router Class Initialized
INFO - 2021-07-16 08:35:20 --> Output Class Initialized
INFO - 2021-07-16 08:35:20 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:20 --> Input Class Initialized
INFO - 2021-07-16 08:35:20 --> Language Class Initialized
INFO - 2021-07-16 08:35:20 --> Language Class Initialized
INFO - 2021-07-16 08:35:20 --> Config Class Initialized
INFO - 2021-07-16 08:35:20 --> Loader Class Initialized
INFO - 2021-07-16 08:35:20 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:20 --> Controller Class Initialized
DEBUG - 2021-07-16 08:35:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:35:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:20 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:20 --> Total execution time: 0.0435
INFO - 2021-07-16 08:35:20 --> Config Class Initialized
INFO - 2021-07-16 08:35:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:20 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:20 --> URI Class Initialized
INFO - 2021-07-16 08:35:20 --> Router Class Initialized
INFO - 2021-07-16 08:35:20 --> Output Class Initialized
INFO - 2021-07-16 08:35:20 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:20 --> Input Class Initialized
INFO - 2021-07-16 08:35:20 --> Language Class Initialized
INFO - 2021-07-16 08:35:20 --> Language Class Initialized
INFO - 2021-07-16 08:35:20 --> Config Class Initialized
INFO - 2021-07-16 08:35:20 --> Loader Class Initialized
INFO - 2021-07-16 08:35:20 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:20 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:20 --> Controller Class Initialized
INFO - 2021-07-16 08:35:26 --> Config Class Initialized
INFO - 2021-07-16 08:35:26 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:26 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:26 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:26 --> URI Class Initialized
INFO - 2021-07-16 08:35:26 --> Router Class Initialized
INFO - 2021-07-16 08:35:26 --> Output Class Initialized
INFO - 2021-07-16 08:35:26 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:26 --> Input Class Initialized
INFO - 2021-07-16 08:35:26 --> Language Class Initialized
INFO - 2021-07-16 08:35:26 --> Language Class Initialized
INFO - 2021-07-16 08:35:26 --> Config Class Initialized
INFO - 2021-07-16 08:35:26 --> Loader Class Initialized
INFO - 2021-07-16 08:35:26 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:26 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:26 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:26 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:26 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:26 --> Controller Class Initialized
INFO - 2021-07-16 08:35:27 --> Config Class Initialized
INFO - 2021-07-16 08:35:27 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:27 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:27 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:27 --> URI Class Initialized
INFO - 2021-07-16 08:35:27 --> Router Class Initialized
INFO - 2021-07-16 08:35:27 --> Output Class Initialized
INFO - 2021-07-16 08:35:27 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:27 --> Input Class Initialized
INFO - 2021-07-16 08:35:27 --> Language Class Initialized
INFO - 2021-07-16 08:35:27 --> Language Class Initialized
INFO - 2021-07-16 08:35:27 --> Config Class Initialized
INFO - 2021-07-16 08:35:27 --> Loader Class Initialized
INFO - 2021-07-16 08:35:27 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:27 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:27 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:27 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:27 --> Controller Class Initialized
ERROR - 2021-07-16 08:35:27 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:35:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:27 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:27 --> Total execution time: 0.0484
INFO - 2021-07-16 08:35:39 --> Config Class Initialized
INFO - 2021-07-16 08:35:39 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:39 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:39 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:39 --> URI Class Initialized
INFO - 2021-07-16 08:35:39 --> Router Class Initialized
INFO - 2021-07-16 08:35:39 --> Output Class Initialized
INFO - 2021-07-16 08:35:39 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:39 --> Input Class Initialized
INFO - 2021-07-16 08:35:39 --> Language Class Initialized
INFO - 2021-07-16 08:35:39 --> Language Class Initialized
INFO - 2021-07-16 08:35:39 --> Config Class Initialized
INFO - 2021-07-16 08:35:39 --> Loader Class Initialized
INFO - 2021-07-16 08:35:39 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:39 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:39 --> Controller Class Initialized
INFO - 2021-07-16 08:35:39 --> Upload Class Initialized
INFO - 2021-07-16 08:35:39 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:35:39 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:35:39 --> Config Class Initialized
INFO - 2021-07-16 08:35:39 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:39 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:39 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:39 --> URI Class Initialized
INFO - 2021-07-16 08:35:39 --> Router Class Initialized
INFO - 2021-07-16 08:35:39 --> Output Class Initialized
INFO - 2021-07-16 08:35:39 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:39 --> Input Class Initialized
INFO - 2021-07-16 08:35:39 --> Language Class Initialized
INFO - 2021-07-16 08:35:39 --> Language Class Initialized
INFO - 2021-07-16 08:35:39 --> Config Class Initialized
INFO - 2021-07-16 08:35:39 --> Loader Class Initialized
INFO - 2021-07-16 08:35:39 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:39 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:39 --> Controller Class Initialized
DEBUG - 2021-07-16 08:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:35:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:39 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:39 --> Total execution time: 0.0636
INFO - 2021-07-16 08:35:39 --> Config Class Initialized
INFO - 2021-07-16 08:35:39 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:39 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:39 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:39 --> URI Class Initialized
INFO - 2021-07-16 08:35:39 --> Router Class Initialized
INFO - 2021-07-16 08:35:39 --> Output Class Initialized
INFO - 2021-07-16 08:35:39 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:39 --> Input Class Initialized
INFO - 2021-07-16 08:35:39 --> Language Class Initialized
INFO - 2021-07-16 08:35:39 --> Language Class Initialized
INFO - 2021-07-16 08:35:39 --> Config Class Initialized
INFO - 2021-07-16 08:35:39 --> Loader Class Initialized
INFO - 2021-07-16 08:35:39 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:39 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:39 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:39 --> Controller Class Initialized
INFO - 2021-07-16 08:35:48 --> Config Class Initialized
INFO - 2021-07-16 08:35:48 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:48 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:48 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:48 --> URI Class Initialized
INFO - 2021-07-16 08:35:48 --> Router Class Initialized
INFO - 2021-07-16 08:35:48 --> Output Class Initialized
INFO - 2021-07-16 08:35:48 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:48 --> Input Class Initialized
INFO - 2021-07-16 08:35:48 --> Language Class Initialized
INFO - 2021-07-16 08:35:48 --> Language Class Initialized
INFO - 2021-07-16 08:35:48 --> Config Class Initialized
INFO - 2021-07-16 08:35:48 --> Loader Class Initialized
INFO - 2021-07-16 08:35:48 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:48 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:48 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:48 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:48 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:48 --> Controller Class Initialized
INFO - 2021-07-16 08:35:49 --> Config Class Initialized
INFO - 2021-07-16 08:35:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:49 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:49 --> URI Class Initialized
INFO - 2021-07-16 08:35:49 --> Router Class Initialized
INFO - 2021-07-16 08:35:49 --> Output Class Initialized
INFO - 2021-07-16 08:35:49 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:49 --> Input Class Initialized
INFO - 2021-07-16 08:35:49 --> Language Class Initialized
INFO - 2021-07-16 08:35:49 --> Language Class Initialized
INFO - 2021-07-16 08:35:49 --> Config Class Initialized
INFO - 2021-07-16 08:35:49 --> Loader Class Initialized
INFO - 2021-07-16 08:35:49 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:49 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:49 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:49 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:49 --> Controller Class Initialized
ERROR - 2021-07-16 08:35:49 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:35:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:49 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:49 --> Total execution time: 0.0618
INFO - 2021-07-16 08:35:56 --> Config Class Initialized
INFO - 2021-07-16 08:35:56 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:56 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:56 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:56 --> URI Class Initialized
INFO - 2021-07-16 08:35:56 --> Router Class Initialized
INFO - 2021-07-16 08:35:56 --> Output Class Initialized
INFO - 2021-07-16 08:35:56 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:56 --> Input Class Initialized
INFO - 2021-07-16 08:35:56 --> Language Class Initialized
INFO - 2021-07-16 08:35:56 --> Language Class Initialized
INFO - 2021-07-16 08:35:56 --> Config Class Initialized
INFO - 2021-07-16 08:35:56 --> Loader Class Initialized
INFO - 2021-07-16 08:35:56 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:56 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:56 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:56 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:56 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:56 --> Controller Class Initialized
DEBUG - 2021-07-16 08:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:35:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:56 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:56 --> Total execution time: 0.0607
INFO - 2021-07-16 08:35:56 --> Config Class Initialized
INFO - 2021-07-16 08:35:56 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:56 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:56 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:56 --> URI Class Initialized
INFO - 2021-07-16 08:35:56 --> Router Class Initialized
INFO - 2021-07-16 08:35:56 --> Output Class Initialized
INFO - 2021-07-16 08:35:56 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:56 --> Input Class Initialized
INFO - 2021-07-16 08:35:56 --> Language Class Initialized
INFO - 2021-07-16 08:35:56 --> Language Class Initialized
INFO - 2021-07-16 08:35:56 --> Config Class Initialized
INFO - 2021-07-16 08:35:56 --> Loader Class Initialized
INFO - 2021-07-16 08:35:56 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:56 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:56 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:56 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:56 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:56 --> Controller Class Initialized
INFO - 2021-07-16 08:35:58 --> Config Class Initialized
INFO - 2021-07-16 08:35:58 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:58 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:58 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:58 --> URI Class Initialized
INFO - 2021-07-16 08:35:58 --> Router Class Initialized
INFO - 2021-07-16 08:35:58 --> Output Class Initialized
INFO - 2021-07-16 08:35:58 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:58 --> Input Class Initialized
INFO - 2021-07-16 08:35:58 --> Language Class Initialized
INFO - 2021-07-16 08:35:58 --> Language Class Initialized
INFO - 2021-07-16 08:35:58 --> Config Class Initialized
INFO - 2021-07-16 08:35:58 --> Loader Class Initialized
INFO - 2021-07-16 08:35:58 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:58 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:58 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:58 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:58 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:58 --> Controller Class Initialized
INFO - 2021-07-16 08:35:59 --> Config Class Initialized
INFO - 2021-07-16 08:35:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:35:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:35:59 --> Utf8 Class Initialized
INFO - 2021-07-16 08:35:59 --> URI Class Initialized
INFO - 2021-07-16 08:35:59 --> Router Class Initialized
INFO - 2021-07-16 08:35:59 --> Output Class Initialized
INFO - 2021-07-16 08:35:59 --> Security Class Initialized
DEBUG - 2021-07-16 08:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:35:59 --> Input Class Initialized
INFO - 2021-07-16 08:35:59 --> Language Class Initialized
INFO - 2021-07-16 08:35:59 --> Language Class Initialized
INFO - 2021-07-16 08:35:59 --> Config Class Initialized
INFO - 2021-07-16 08:35:59 --> Loader Class Initialized
INFO - 2021-07-16 08:35:59 --> Helper loaded: url_helper
INFO - 2021-07-16 08:35:59 --> Helper loaded: file_helper
INFO - 2021-07-16 08:35:59 --> Helper loaded: form_helper
INFO - 2021-07-16 08:35:59 --> Helper loaded: my_helper
INFO - 2021-07-16 08:35:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:35:59 --> Controller Class Initialized
ERROR - 2021-07-16 08:35:59 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:35:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:35:59 --> Final output sent to browser
DEBUG - 2021-07-16 08:35:59 --> Total execution time: 0.0593
INFO - 2021-07-16 08:36:07 --> Config Class Initialized
INFO - 2021-07-16 08:36:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:07 --> URI Class Initialized
INFO - 2021-07-16 08:36:07 --> Router Class Initialized
INFO - 2021-07-16 08:36:07 --> Output Class Initialized
INFO - 2021-07-16 08:36:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:07 --> Input Class Initialized
INFO - 2021-07-16 08:36:07 --> Language Class Initialized
INFO - 2021-07-16 08:36:07 --> Language Class Initialized
INFO - 2021-07-16 08:36:07 --> Config Class Initialized
INFO - 2021-07-16 08:36:07 --> Loader Class Initialized
INFO - 2021-07-16 08:36:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:07 --> Controller Class Initialized
INFO - 2021-07-16 08:36:07 --> Upload Class Initialized
INFO - 2021-07-16 08:36:07 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:36:07 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:36:07 --> Config Class Initialized
INFO - 2021-07-16 08:36:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:07 --> URI Class Initialized
INFO - 2021-07-16 08:36:07 --> Router Class Initialized
INFO - 2021-07-16 08:36:07 --> Output Class Initialized
INFO - 2021-07-16 08:36:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:07 --> Input Class Initialized
INFO - 2021-07-16 08:36:07 --> Language Class Initialized
INFO - 2021-07-16 08:36:07 --> Language Class Initialized
INFO - 2021-07-16 08:36:07 --> Config Class Initialized
INFO - 2021-07-16 08:36:07 --> Loader Class Initialized
INFO - 2021-07-16 08:36:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:07 --> Controller Class Initialized
DEBUG - 2021-07-16 08:36:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:36:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:36:07 --> Final output sent to browser
DEBUG - 2021-07-16 08:36:07 --> Total execution time: 0.0534
INFO - 2021-07-16 08:36:08 --> Config Class Initialized
INFO - 2021-07-16 08:36:08 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:08 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:08 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:08 --> URI Class Initialized
INFO - 2021-07-16 08:36:08 --> Router Class Initialized
INFO - 2021-07-16 08:36:08 --> Output Class Initialized
INFO - 2021-07-16 08:36:08 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:08 --> Input Class Initialized
INFO - 2021-07-16 08:36:08 --> Language Class Initialized
INFO - 2021-07-16 08:36:08 --> Language Class Initialized
INFO - 2021-07-16 08:36:08 --> Config Class Initialized
INFO - 2021-07-16 08:36:08 --> Loader Class Initialized
INFO - 2021-07-16 08:36:08 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:08 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:08 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:08 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:08 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:08 --> Controller Class Initialized
INFO - 2021-07-16 08:36:15 --> Config Class Initialized
INFO - 2021-07-16 08:36:15 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:15 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:15 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:15 --> URI Class Initialized
INFO - 2021-07-16 08:36:15 --> Router Class Initialized
INFO - 2021-07-16 08:36:15 --> Output Class Initialized
INFO - 2021-07-16 08:36:15 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:15 --> Input Class Initialized
INFO - 2021-07-16 08:36:15 --> Language Class Initialized
INFO - 2021-07-16 08:36:15 --> Language Class Initialized
INFO - 2021-07-16 08:36:15 --> Config Class Initialized
INFO - 2021-07-16 08:36:15 --> Loader Class Initialized
INFO - 2021-07-16 08:36:15 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:15 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:15 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:15 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:15 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:15 --> Controller Class Initialized
INFO - 2021-07-16 08:36:16 --> Config Class Initialized
INFO - 2021-07-16 08:36:16 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:16 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:16 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:16 --> URI Class Initialized
INFO - 2021-07-16 08:36:16 --> Router Class Initialized
INFO - 2021-07-16 08:36:16 --> Output Class Initialized
INFO - 2021-07-16 08:36:16 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:16 --> Input Class Initialized
INFO - 2021-07-16 08:36:16 --> Language Class Initialized
INFO - 2021-07-16 08:36:16 --> Language Class Initialized
INFO - 2021-07-16 08:36:16 --> Config Class Initialized
INFO - 2021-07-16 08:36:16 --> Loader Class Initialized
INFO - 2021-07-16 08:36:16 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:16 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:16 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:16 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:16 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:16 --> Controller Class Initialized
ERROR - 2021-07-16 08:36:16 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:36:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:36:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:36:16 --> Final output sent to browser
DEBUG - 2021-07-16 08:36:16 --> Total execution time: 0.0494
INFO - 2021-07-16 08:36:22 --> Config Class Initialized
INFO - 2021-07-16 08:36:22 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:23 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:23 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:23 --> URI Class Initialized
INFO - 2021-07-16 08:36:23 --> Router Class Initialized
INFO - 2021-07-16 08:36:23 --> Output Class Initialized
INFO - 2021-07-16 08:36:23 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:23 --> Input Class Initialized
INFO - 2021-07-16 08:36:23 --> Language Class Initialized
INFO - 2021-07-16 08:36:23 --> Language Class Initialized
INFO - 2021-07-16 08:36:23 --> Config Class Initialized
INFO - 2021-07-16 08:36:23 --> Loader Class Initialized
INFO - 2021-07-16 08:36:23 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:23 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:23 --> Controller Class Initialized
INFO - 2021-07-16 08:36:23 --> Upload Class Initialized
INFO - 2021-07-16 08:36:23 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:36:23 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:36:23 --> Config Class Initialized
INFO - 2021-07-16 08:36:23 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:23 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:23 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:23 --> URI Class Initialized
INFO - 2021-07-16 08:36:23 --> Router Class Initialized
INFO - 2021-07-16 08:36:23 --> Output Class Initialized
INFO - 2021-07-16 08:36:23 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:23 --> Input Class Initialized
INFO - 2021-07-16 08:36:23 --> Language Class Initialized
INFO - 2021-07-16 08:36:23 --> Language Class Initialized
INFO - 2021-07-16 08:36:23 --> Config Class Initialized
INFO - 2021-07-16 08:36:23 --> Loader Class Initialized
INFO - 2021-07-16 08:36:23 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:23 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:23 --> Controller Class Initialized
DEBUG - 2021-07-16 08:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:36:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:36:23 --> Final output sent to browser
DEBUG - 2021-07-16 08:36:23 --> Total execution time: 0.0425
INFO - 2021-07-16 08:36:23 --> Config Class Initialized
INFO - 2021-07-16 08:36:23 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:23 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:23 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:23 --> URI Class Initialized
INFO - 2021-07-16 08:36:23 --> Router Class Initialized
INFO - 2021-07-16 08:36:23 --> Output Class Initialized
INFO - 2021-07-16 08:36:23 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:23 --> Input Class Initialized
INFO - 2021-07-16 08:36:23 --> Language Class Initialized
INFO - 2021-07-16 08:36:23 --> Language Class Initialized
INFO - 2021-07-16 08:36:23 --> Config Class Initialized
INFO - 2021-07-16 08:36:23 --> Loader Class Initialized
INFO - 2021-07-16 08:36:23 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:23 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:23 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:23 --> Controller Class Initialized
INFO - 2021-07-16 08:36:32 --> Config Class Initialized
INFO - 2021-07-16 08:36:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:32 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:32 --> URI Class Initialized
INFO - 2021-07-16 08:36:32 --> Router Class Initialized
INFO - 2021-07-16 08:36:32 --> Output Class Initialized
INFO - 2021-07-16 08:36:32 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:32 --> Input Class Initialized
INFO - 2021-07-16 08:36:32 --> Language Class Initialized
INFO - 2021-07-16 08:36:32 --> Language Class Initialized
INFO - 2021-07-16 08:36:32 --> Config Class Initialized
INFO - 2021-07-16 08:36:32 --> Loader Class Initialized
INFO - 2021-07-16 08:36:32 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:32 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:32 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:32 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:32 --> Controller Class Initialized
INFO - 2021-07-16 08:36:33 --> Config Class Initialized
INFO - 2021-07-16 08:36:33 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:33 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:33 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:33 --> URI Class Initialized
INFO - 2021-07-16 08:36:33 --> Router Class Initialized
INFO - 2021-07-16 08:36:33 --> Output Class Initialized
INFO - 2021-07-16 08:36:33 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:33 --> Input Class Initialized
INFO - 2021-07-16 08:36:33 --> Language Class Initialized
INFO - 2021-07-16 08:36:33 --> Language Class Initialized
INFO - 2021-07-16 08:36:33 --> Config Class Initialized
INFO - 2021-07-16 08:36:33 --> Loader Class Initialized
INFO - 2021-07-16 08:36:33 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:33 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:33 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:33 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:33 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:33 --> Controller Class Initialized
ERROR - 2021-07-16 08:36:33 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:36:33 --> Final output sent to browser
DEBUG - 2021-07-16 08:36:33 --> Total execution time: 0.0731
INFO - 2021-07-16 08:36:42 --> Config Class Initialized
INFO - 2021-07-16 08:36:42 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:42 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:42 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:42 --> URI Class Initialized
INFO - 2021-07-16 08:36:42 --> Router Class Initialized
INFO - 2021-07-16 08:36:42 --> Output Class Initialized
INFO - 2021-07-16 08:36:42 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:42 --> Input Class Initialized
INFO - 2021-07-16 08:36:42 --> Language Class Initialized
INFO - 2021-07-16 08:36:42 --> Language Class Initialized
INFO - 2021-07-16 08:36:42 --> Config Class Initialized
INFO - 2021-07-16 08:36:42 --> Loader Class Initialized
INFO - 2021-07-16 08:36:42 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:42 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:42 --> Controller Class Initialized
INFO - 2021-07-16 08:36:42 --> Upload Class Initialized
INFO - 2021-07-16 08:36:42 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:36:42 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:36:42 --> Config Class Initialized
INFO - 2021-07-16 08:36:42 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:42 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:42 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:42 --> URI Class Initialized
INFO - 2021-07-16 08:36:42 --> Router Class Initialized
INFO - 2021-07-16 08:36:42 --> Output Class Initialized
INFO - 2021-07-16 08:36:42 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:42 --> Input Class Initialized
INFO - 2021-07-16 08:36:42 --> Language Class Initialized
INFO - 2021-07-16 08:36:42 --> Language Class Initialized
INFO - 2021-07-16 08:36:42 --> Config Class Initialized
INFO - 2021-07-16 08:36:42 --> Loader Class Initialized
INFO - 2021-07-16 08:36:42 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:42 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:42 --> Controller Class Initialized
DEBUG - 2021-07-16 08:36:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:36:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:36:42 --> Final output sent to browser
DEBUG - 2021-07-16 08:36:42 --> Total execution time: 0.0666
INFO - 2021-07-16 08:36:42 --> Config Class Initialized
INFO - 2021-07-16 08:36:42 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:42 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:42 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:42 --> URI Class Initialized
INFO - 2021-07-16 08:36:42 --> Router Class Initialized
INFO - 2021-07-16 08:36:42 --> Output Class Initialized
INFO - 2021-07-16 08:36:42 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:42 --> Input Class Initialized
INFO - 2021-07-16 08:36:42 --> Language Class Initialized
INFO - 2021-07-16 08:36:42 --> Language Class Initialized
INFO - 2021-07-16 08:36:42 --> Config Class Initialized
INFO - 2021-07-16 08:36:42 --> Loader Class Initialized
INFO - 2021-07-16 08:36:42 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:42 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:42 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:42 --> Controller Class Initialized
INFO - 2021-07-16 08:36:48 --> Config Class Initialized
INFO - 2021-07-16 08:36:48 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:48 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:48 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:48 --> URI Class Initialized
INFO - 2021-07-16 08:36:48 --> Router Class Initialized
INFO - 2021-07-16 08:36:48 --> Output Class Initialized
INFO - 2021-07-16 08:36:48 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:48 --> Input Class Initialized
INFO - 2021-07-16 08:36:48 --> Language Class Initialized
INFO - 2021-07-16 08:36:48 --> Language Class Initialized
INFO - 2021-07-16 08:36:48 --> Config Class Initialized
INFO - 2021-07-16 08:36:48 --> Loader Class Initialized
INFO - 2021-07-16 08:36:48 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:48 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:48 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:48 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:48 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:48 --> Controller Class Initialized
INFO - 2021-07-16 08:36:49 --> Config Class Initialized
INFO - 2021-07-16 08:36:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:49 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:49 --> URI Class Initialized
INFO - 2021-07-16 08:36:49 --> Router Class Initialized
INFO - 2021-07-16 08:36:49 --> Output Class Initialized
INFO - 2021-07-16 08:36:49 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:49 --> Input Class Initialized
INFO - 2021-07-16 08:36:49 --> Language Class Initialized
INFO - 2021-07-16 08:36:49 --> Language Class Initialized
INFO - 2021-07-16 08:36:49 --> Config Class Initialized
INFO - 2021-07-16 08:36:49 --> Loader Class Initialized
INFO - 2021-07-16 08:36:49 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:49 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:49 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:49 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:49 --> Controller Class Initialized
ERROR - 2021-07-16 08:36:49 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:36:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:36:49 --> Final output sent to browser
DEBUG - 2021-07-16 08:36:49 --> Total execution time: 0.0483
INFO - 2021-07-16 08:36:57 --> Config Class Initialized
INFO - 2021-07-16 08:36:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:57 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:57 --> URI Class Initialized
INFO - 2021-07-16 08:36:57 --> Router Class Initialized
INFO - 2021-07-16 08:36:57 --> Output Class Initialized
INFO - 2021-07-16 08:36:57 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:57 --> Input Class Initialized
INFO - 2021-07-16 08:36:57 --> Language Class Initialized
INFO - 2021-07-16 08:36:57 --> Language Class Initialized
INFO - 2021-07-16 08:36:57 --> Config Class Initialized
INFO - 2021-07-16 08:36:57 --> Loader Class Initialized
INFO - 2021-07-16 08:36:57 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:57 --> Controller Class Initialized
INFO - 2021-07-16 08:36:57 --> Upload Class Initialized
INFO - 2021-07-16 08:36:57 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:36:57 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:36:57 --> Config Class Initialized
INFO - 2021-07-16 08:36:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:57 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:57 --> URI Class Initialized
INFO - 2021-07-16 08:36:57 --> Router Class Initialized
INFO - 2021-07-16 08:36:57 --> Output Class Initialized
INFO - 2021-07-16 08:36:57 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:57 --> Input Class Initialized
INFO - 2021-07-16 08:36:57 --> Language Class Initialized
INFO - 2021-07-16 08:36:57 --> Language Class Initialized
INFO - 2021-07-16 08:36:57 --> Config Class Initialized
INFO - 2021-07-16 08:36:57 --> Loader Class Initialized
INFO - 2021-07-16 08:36:57 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:57 --> Controller Class Initialized
DEBUG - 2021-07-16 08:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:36:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:36:57 --> Final output sent to browser
DEBUG - 2021-07-16 08:36:57 --> Total execution time: 0.0437
INFO - 2021-07-16 08:36:57 --> Config Class Initialized
INFO - 2021-07-16 08:36:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:36:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:36:57 --> Utf8 Class Initialized
INFO - 2021-07-16 08:36:57 --> URI Class Initialized
INFO - 2021-07-16 08:36:57 --> Router Class Initialized
INFO - 2021-07-16 08:36:57 --> Output Class Initialized
INFO - 2021-07-16 08:36:57 --> Security Class Initialized
DEBUG - 2021-07-16 08:36:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:36:57 --> Input Class Initialized
INFO - 2021-07-16 08:36:57 --> Language Class Initialized
INFO - 2021-07-16 08:36:57 --> Language Class Initialized
INFO - 2021-07-16 08:36:57 --> Config Class Initialized
INFO - 2021-07-16 08:36:57 --> Loader Class Initialized
INFO - 2021-07-16 08:36:57 --> Helper loaded: url_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: file_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: form_helper
INFO - 2021-07-16 08:36:57 --> Helper loaded: my_helper
INFO - 2021-07-16 08:36:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:36:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:36:57 --> Controller Class Initialized
INFO - 2021-07-16 08:37:04 --> Config Class Initialized
INFO - 2021-07-16 08:37:04 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:04 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:04 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:04 --> URI Class Initialized
INFO - 2021-07-16 08:37:04 --> Router Class Initialized
INFO - 2021-07-16 08:37:04 --> Output Class Initialized
INFO - 2021-07-16 08:37:04 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:04 --> Input Class Initialized
INFO - 2021-07-16 08:37:04 --> Language Class Initialized
INFO - 2021-07-16 08:37:04 --> Language Class Initialized
INFO - 2021-07-16 08:37:04 --> Config Class Initialized
INFO - 2021-07-16 08:37:04 --> Loader Class Initialized
INFO - 2021-07-16 08:37:04 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:04 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:04 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:04 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:04 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:04 --> Controller Class Initialized
INFO - 2021-07-16 08:37:05 --> Config Class Initialized
INFO - 2021-07-16 08:37:05 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:05 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:05 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:05 --> URI Class Initialized
INFO - 2021-07-16 08:37:05 --> Router Class Initialized
INFO - 2021-07-16 08:37:05 --> Output Class Initialized
INFO - 2021-07-16 08:37:05 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:05 --> Input Class Initialized
INFO - 2021-07-16 08:37:05 --> Language Class Initialized
INFO - 2021-07-16 08:37:05 --> Language Class Initialized
INFO - 2021-07-16 08:37:05 --> Config Class Initialized
INFO - 2021-07-16 08:37:05 --> Loader Class Initialized
INFO - 2021-07-16 08:37:05 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:05 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:05 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:05 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:05 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:05 --> Controller Class Initialized
ERROR - 2021-07-16 08:37:05 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:37:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:37:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:37:05 --> Final output sent to browser
DEBUG - 2021-07-16 08:37:05 --> Total execution time: 0.0602
INFO - 2021-07-16 08:37:14 --> Config Class Initialized
INFO - 2021-07-16 08:37:14 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:14 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:14 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:14 --> URI Class Initialized
INFO - 2021-07-16 08:37:14 --> Router Class Initialized
INFO - 2021-07-16 08:37:14 --> Output Class Initialized
INFO - 2021-07-16 08:37:14 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:14 --> Input Class Initialized
INFO - 2021-07-16 08:37:14 --> Language Class Initialized
INFO - 2021-07-16 08:37:14 --> Language Class Initialized
INFO - 2021-07-16 08:37:14 --> Config Class Initialized
INFO - 2021-07-16 08:37:14 --> Loader Class Initialized
INFO - 2021-07-16 08:37:14 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:14 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:14 --> Controller Class Initialized
INFO - 2021-07-16 08:37:14 --> Upload Class Initialized
INFO - 2021-07-16 08:37:14 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:37:14 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:37:14 --> Config Class Initialized
INFO - 2021-07-16 08:37:14 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:14 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:14 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:14 --> URI Class Initialized
INFO - 2021-07-16 08:37:14 --> Router Class Initialized
INFO - 2021-07-16 08:37:14 --> Output Class Initialized
INFO - 2021-07-16 08:37:14 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:14 --> Input Class Initialized
INFO - 2021-07-16 08:37:14 --> Language Class Initialized
INFO - 2021-07-16 08:37:14 --> Language Class Initialized
INFO - 2021-07-16 08:37:14 --> Config Class Initialized
INFO - 2021-07-16 08:37:14 --> Loader Class Initialized
INFO - 2021-07-16 08:37:14 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:14 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:14 --> Controller Class Initialized
DEBUG - 2021-07-16 08:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:37:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:37:14 --> Final output sent to browser
DEBUG - 2021-07-16 08:37:14 --> Total execution time: 0.0631
INFO - 2021-07-16 08:37:14 --> Config Class Initialized
INFO - 2021-07-16 08:37:14 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:14 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:14 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:14 --> URI Class Initialized
INFO - 2021-07-16 08:37:14 --> Router Class Initialized
INFO - 2021-07-16 08:37:14 --> Output Class Initialized
INFO - 2021-07-16 08:37:14 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:14 --> Input Class Initialized
INFO - 2021-07-16 08:37:14 --> Language Class Initialized
INFO - 2021-07-16 08:37:14 --> Language Class Initialized
INFO - 2021-07-16 08:37:14 --> Config Class Initialized
INFO - 2021-07-16 08:37:14 --> Loader Class Initialized
INFO - 2021-07-16 08:37:14 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:14 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:14 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:14 --> Controller Class Initialized
INFO - 2021-07-16 08:37:20 --> Config Class Initialized
INFO - 2021-07-16 08:37:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:20 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:20 --> URI Class Initialized
INFO - 2021-07-16 08:37:20 --> Router Class Initialized
INFO - 2021-07-16 08:37:20 --> Output Class Initialized
INFO - 2021-07-16 08:37:20 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:20 --> Input Class Initialized
INFO - 2021-07-16 08:37:20 --> Language Class Initialized
INFO - 2021-07-16 08:37:20 --> Language Class Initialized
INFO - 2021-07-16 08:37:20 --> Config Class Initialized
INFO - 2021-07-16 08:37:20 --> Loader Class Initialized
INFO - 2021-07-16 08:37:20 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:20 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:20 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:20 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:20 --> Controller Class Initialized
INFO - 2021-07-16 08:37:21 --> Config Class Initialized
INFO - 2021-07-16 08:37:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:21 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:21 --> URI Class Initialized
INFO - 2021-07-16 08:37:21 --> Router Class Initialized
INFO - 2021-07-16 08:37:21 --> Output Class Initialized
INFO - 2021-07-16 08:37:21 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:21 --> Input Class Initialized
INFO - 2021-07-16 08:37:21 --> Language Class Initialized
INFO - 2021-07-16 08:37:21 --> Language Class Initialized
INFO - 2021-07-16 08:37:21 --> Config Class Initialized
INFO - 2021-07-16 08:37:21 --> Loader Class Initialized
INFO - 2021-07-16 08:37:21 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:21 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:21 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:21 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:21 --> Controller Class Initialized
ERROR - 2021-07-16 08:37:21 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:37:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:37:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:37:21 --> Final output sent to browser
DEBUG - 2021-07-16 08:37:21 --> Total execution time: 0.0476
INFO - 2021-07-16 08:37:29 --> Config Class Initialized
INFO - 2021-07-16 08:37:29 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:29 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:29 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:29 --> URI Class Initialized
INFO - 2021-07-16 08:37:29 --> Router Class Initialized
INFO - 2021-07-16 08:37:29 --> Output Class Initialized
INFO - 2021-07-16 08:37:29 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:29 --> Input Class Initialized
INFO - 2021-07-16 08:37:29 --> Language Class Initialized
INFO - 2021-07-16 08:37:29 --> Language Class Initialized
INFO - 2021-07-16 08:37:29 --> Config Class Initialized
INFO - 2021-07-16 08:37:29 --> Loader Class Initialized
INFO - 2021-07-16 08:37:29 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:29 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:29 --> Controller Class Initialized
INFO - 2021-07-16 08:37:29 --> Upload Class Initialized
INFO - 2021-07-16 08:37:29 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:37:29 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:37:29 --> Config Class Initialized
INFO - 2021-07-16 08:37:29 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:29 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:29 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:29 --> URI Class Initialized
INFO - 2021-07-16 08:37:29 --> Router Class Initialized
INFO - 2021-07-16 08:37:29 --> Output Class Initialized
INFO - 2021-07-16 08:37:29 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:29 --> Input Class Initialized
INFO - 2021-07-16 08:37:29 --> Language Class Initialized
INFO - 2021-07-16 08:37:29 --> Language Class Initialized
INFO - 2021-07-16 08:37:29 --> Config Class Initialized
INFO - 2021-07-16 08:37:29 --> Loader Class Initialized
INFO - 2021-07-16 08:37:29 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:29 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:29 --> Controller Class Initialized
DEBUG - 2021-07-16 08:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:37:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:37:29 --> Final output sent to browser
DEBUG - 2021-07-16 08:37:29 --> Total execution time: 0.0439
INFO - 2021-07-16 08:37:29 --> Config Class Initialized
INFO - 2021-07-16 08:37:29 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:29 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:29 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:29 --> URI Class Initialized
INFO - 2021-07-16 08:37:29 --> Router Class Initialized
INFO - 2021-07-16 08:37:29 --> Output Class Initialized
INFO - 2021-07-16 08:37:29 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:29 --> Input Class Initialized
INFO - 2021-07-16 08:37:29 --> Language Class Initialized
INFO - 2021-07-16 08:37:29 --> Language Class Initialized
INFO - 2021-07-16 08:37:29 --> Config Class Initialized
INFO - 2021-07-16 08:37:29 --> Loader Class Initialized
INFO - 2021-07-16 08:37:29 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:29 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:29 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:29 --> Controller Class Initialized
INFO - 2021-07-16 08:37:36 --> Config Class Initialized
INFO - 2021-07-16 08:37:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:36 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:36 --> URI Class Initialized
INFO - 2021-07-16 08:37:36 --> Router Class Initialized
INFO - 2021-07-16 08:37:36 --> Output Class Initialized
INFO - 2021-07-16 08:37:36 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:36 --> Input Class Initialized
INFO - 2021-07-16 08:37:36 --> Language Class Initialized
INFO - 2021-07-16 08:37:36 --> Language Class Initialized
INFO - 2021-07-16 08:37:36 --> Config Class Initialized
INFO - 2021-07-16 08:37:36 --> Loader Class Initialized
INFO - 2021-07-16 08:37:36 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:36 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:36 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:36 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:36 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:36 --> Controller Class Initialized
INFO - 2021-07-16 08:37:37 --> Config Class Initialized
INFO - 2021-07-16 08:37:37 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:37 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:37 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:37 --> URI Class Initialized
INFO - 2021-07-16 08:37:37 --> Router Class Initialized
INFO - 2021-07-16 08:37:37 --> Output Class Initialized
INFO - 2021-07-16 08:37:37 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:37 --> Input Class Initialized
INFO - 2021-07-16 08:37:37 --> Language Class Initialized
INFO - 2021-07-16 08:37:37 --> Language Class Initialized
INFO - 2021-07-16 08:37:37 --> Config Class Initialized
INFO - 2021-07-16 08:37:37 --> Loader Class Initialized
INFO - 2021-07-16 08:37:37 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:37 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:37 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:37 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:37 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:37 --> Controller Class Initialized
ERROR - 2021-07-16 08:37:37 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:37:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:37:37 --> Final output sent to browser
DEBUG - 2021-07-16 08:37:37 --> Total execution time: 0.0651
INFO - 2021-07-16 08:37:45 --> Config Class Initialized
INFO - 2021-07-16 08:37:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:45 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:45 --> URI Class Initialized
INFO - 2021-07-16 08:37:45 --> Router Class Initialized
INFO - 2021-07-16 08:37:45 --> Output Class Initialized
INFO - 2021-07-16 08:37:45 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:45 --> Input Class Initialized
INFO - 2021-07-16 08:37:45 --> Language Class Initialized
INFO - 2021-07-16 08:37:45 --> Language Class Initialized
INFO - 2021-07-16 08:37:45 --> Config Class Initialized
INFO - 2021-07-16 08:37:45 --> Loader Class Initialized
INFO - 2021-07-16 08:37:45 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:45 --> Controller Class Initialized
INFO - 2021-07-16 08:37:45 --> Upload Class Initialized
INFO - 2021-07-16 08:37:45 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:37:45 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:37:45 --> Config Class Initialized
INFO - 2021-07-16 08:37:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:45 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:45 --> URI Class Initialized
INFO - 2021-07-16 08:37:45 --> Router Class Initialized
INFO - 2021-07-16 08:37:45 --> Output Class Initialized
INFO - 2021-07-16 08:37:45 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:45 --> Input Class Initialized
INFO - 2021-07-16 08:37:45 --> Language Class Initialized
INFO - 2021-07-16 08:37:45 --> Language Class Initialized
INFO - 2021-07-16 08:37:45 --> Config Class Initialized
INFO - 2021-07-16 08:37:45 --> Loader Class Initialized
INFO - 2021-07-16 08:37:45 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:45 --> Controller Class Initialized
DEBUG - 2021-07-16 08:37:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:37:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:37:45 --> Final output sent to browser
DEBUG - 2021-07-16 08:37:45 --> Total execution time: 0.0624
INFO - 2021-07-16 08:37:45 --> Config Class Initialized
INFO - 2021-07-16 08:37:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:45 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:45 --> URI Class Initialized
INFO - 2021-07-16 08:37:45 --> Router Class Initialized
INFO - 2021-07-16 08:37:45 --> Output Class Initialized
INFO - 2021-07-16 08:37:45 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:45 --> Input Class Initialized
INFO - 2021-07-16 08:37:45 --> Language Class Initialized
INFO - 2021-07-16 08:37:45 --> Language Class Initialized
INFO - 2021-07-16 08:37:45 --> Config Class Initialized
INFO - 2021-07-16 08:37:45 --> Loader Class Initialized
INFO - 2021-07-16 08:37:45 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:45 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:45 --> Controller Class Initialized
INFO - 2021-07-16 08:37:53 --> Config Class Initialized
INFO - 2021-07-16 08:37:53 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:53 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:53 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:53 --> URI Class Initialized
INFO - 2021-07-16 08:37:53 --> Router Class Initialized
INFO - 2021-07-16 08:37:53 --> Output Class Initialized
INFO - 2021-07-16 08:37:53 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:53 --> Input Class Initialized
INFO - 2021-07-16 08:37:53 --> Language Class Initialized
INFO - 2021-07-16 08:37:53 --> Language Class Initialized
INFO - 2021-07-16 08:37:53 --> Config Class Initialized
INFO - 2021-07-16 08:37:53 --> Loader Class Initialized
INFO - 2021-07-16 08:37:53 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:53 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:53 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:53 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:53 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:53 --> Controller Class Initialized
INFO - 2021-07-16 08:37:54 --> Config Class Initialized
INFO - 2021-07-16 08:37:54 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:37:54 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:37:54 --> Utf8 Class Initialized
INFO - 2021-07-16 08:37:54 --> URI Class Initialized
INFO - 2021-07-16 08:37:54 --> Router Class Initialized
INFO - 2021-07-16 08:37:54 --> Output Class Initialized
INFO - 2021-07-16 08:37:54 --> Security Class Initialized
DEBUG - 2021-07-16 08:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:37:54 --> Input Class Initialized
INFO - 2021-07-16 08:37:54 --> Language Class Initialized
INFO - 2021-07-16 08:37:54 --> Language Class Initialized
INFO - 2021-07-16 08:37:54 --> Config Class Initialized
INFO - 2021-07-16 08:37:54 --> Loader Class Initialized
INFO - 2021-07-16 08:37:54 --> Helper loaded: url_helper
INFO - 2021-07-16 08:37:54 --> Helper loaded: file_helper
INFO - 2021-07-16 08:37:54 --> Helper loaded: form_helper
INFO - 2021-07-16 08:37:54 --> Helper loaded: my_helper
INFO - 2021-07-16 08:37:54 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:37:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:37:54 --> Controller Class Initialized
ERROR - 2021-07-16 08:37:54 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:37:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:37:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:37:54 --> Final output sent to browser
DEBUG - 2021-07-16 08:37:54 --> Total execution time: 0.0728
INFO - 2021-07-16 08:38:02 --> Config Class Initialized
INFO - 2021-07-16 08:38:02 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:02 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:02 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:02 --> URI Class Initialized
INFO - 2021-07-16 08:38:02 --> Router Class Initialized
INFO - 2021-07-16 08:38:02 --> Output Class Initialized
INFO - 2021-07-16 08:38:02 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:02 --> Input Class Initialized
INFO - 2021-07-16 08:38:02 --> Language Class Initialized
INFO - 2021-07-16 08:38:02 --> Language Class Initialized
INFO - 2021-07-16 08:38:02 --> Config Class Initialized
INFO - 2021-07-16 08:38:02 --> Loader Class Initialized
INFO - 2021-07-16 08:38:02 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:02 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:02 --> Controller Class Initialized
INFO - 2021-07-16 08:38:02 --> Upload Class Initialized
INFO - 2021-07-16 08:38:02 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:38:02 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:38:02 --> Config Class Initialized
INFO - 2021-07-16 08:38:02 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:02 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:02 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:02 --> URI Class Initialized
INFO - 2021-07-16 08:38:02 --> Router Class Initialized
INFO - 2021-07-16 08:38:02 --> Output Class Initialized
INFO - 2021-07-16 08:38:02 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:02 --> Input Class Initialized
INFO - 2021-07-16 08:38:02 --> Language Class Initialized
INFO - 2021-07-16 08:38:02 --> Language Class Initialized
INFO - 2021-07-16 08:38:02 --> Config Class Initialized
INFO - 2021-07-16 08:38:02 --> Loader Class Initialized
INFO - 2021-07-16 08:38:02 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:02 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:02 --> Controller Class Initialized
DEBUG - 2021-07-16 08:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:38:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:38:02 --> Final output sent to browser
DEBUG - 2021-07-16 08:38:02 --> Total execution time: 0.0616
INFO - 2021-07-16 08:38:02 --> Config Class Initialized
INFO - 2021-07-16 08:38:02 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:02 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:02 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:02 --> URI Class Initialized
INFO - 2021-07-16 08:38:02 --> Router Class Initialized
INFO - 2021-07-16 08:38:02 --> Output Class Initialized
INFO - 2021-07-16 08:38:02 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:02 --> Input Class Initialized
INFO - 2021-07-16 08:38:02 --> Language Class Initialized
INFO - 2021-07-16 08:38:02 --> Language Class Initialized
INFO - 2021-07-16 08:38:02 --> Config Class Initialized
INFO - 2021-07-16 08:38:02 --> Loader Class Initialized
INFO - 2021-07-16 08:38:02 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:02 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:02 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:02 --> Controller Class Initialized
INFO - 2021-07-16 08:38:09 --> Config Class Initialized
INFO - 2021-07-16 08:38:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:09 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:09 --> URI Class Initialized
INFO - 2021-07-16 08:38:09 --> Router Class Initialized
INFO - 2021-07-16 08:38:09 --> Output Class Initialized
INFO - 2021-07-16 08:38:09 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:09 --> Input Class Initialized
INFO - 2021-07-16 08:38:09 --> Language Class Initialized
INFO - 2021-07-16 08:38:09 --> Language Class Initialized
INFO - 2021-07-16 08:38:09 --> Config Class Initialized
INFO - 2021-07-16 08:38:09 --> Loader Class Initialized
INFO - 2021-07-16 08:38:09 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:09 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:09 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:09 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:09 --> Controller Class Initialized
INFO - 2021-07-16 08:38:11 --> Config Class Initialized
INFO - 2021-07-16 08:38:11 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:11 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:11 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:11 --> URI Class Initialized
INFO - 2021-07-16 08:38:11 --> Router Class Initialized
INFO - 2021-07-16 08:38:11 --> Output Class Initialized
INFO - 2021-07-16 08:38:11 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:11 --> Input Class Initialized
INFO - 2021-07-16 08:38:11 --> Language Class Initialized
INFO - 2021-07-16 08:38:11 --> Language Class Initialized
INFO - 2021-07-16 08:38:11 --> Config Class Initialized
INFO - 2021-07-16 08:38:11 --> Loader Class Initialized
INFO - 2021-07-16 08:38:11 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:11 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:11 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:11 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:11 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:11 --> Controller Class Initialized
ERROR - 2021-07-16 08:38:11 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:38:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:38:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:38:11 --> Final output sent to browser
DEBUG - 2021-07-16 08:38:11 --> Total execution time: 0.0483
INFO - 2021-07-16 08:38:19 --> Config Class Initialized
INFO - 2021-07-16 08:38:19 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:19 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:19 --> URI Class Initialized
INFO - 2021-07-16 08:38:19 --> Router Class Initialized
INFO - 2021-07-16 08:38:19 --> Output Class Initialized
INFO - 2021-07-16 08:38:19 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:19 --> Input Class Initialized
INFO - 2021-07-16 08:38:19 --> Language Class Initialized
INFO - 2021-07-16 08:38:19 --> Language Class Initialized
INFO - 2021-07-16 08:38:19 --> Config Class Initialized
INFO - 2021-07-16 08:38:19 --> Loader Class Initialized
INFO - 2021-07-16 08:38:19 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:19 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:19 --> Controller Class Initialized
INFO - 2021-07-16 08:38:19 --> Upload Class Initialized
INFO - 2021-07-16 08:38:19 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:38:19 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:38:19 --> Config Class Initialized
INFO - 2021-07-16 08:38:19 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:19 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:19 --> URI Class Initialized
INFO - 2021-07-16 08:38:19 --> Router Class Initialized
INFO - 2021-07-16 08:38:19 --> Output Class Initialized
INFO - 2021-07-16 08:38:19 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:19 --> Input Class Initialized
INFO - 2021-07-16 08:38:19 --> Language Class Initialized
INFO - 2021-07-16 08:38:19 --> Language Class Initialized
INFO - 2021-07-16 08:38:19 --> Config Class Initialized
INFO - 2021-07-16 08:38:19 --> Loader Class Initialized
INFO - 2021-07-16 08:38:19 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:19 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:19 --> Controller Class Initialized
DEBUG - 2021-07-16 08:38:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:38:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:38:19 --> Final output sent to browser
DEBUG - 2021-07-16 08:38:19 --> Total execution time: 0.0649
INFO - 2021-07-16 08:38:19 --> Config Class Initialized
INFO - 2021-07-16 08:38:19 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:19 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:19 --> URI Class Initialized
INFO - 2021-07-16 08:38:19 --> Router Class Initialized
INFO - 2021-07-16 08:38:19 --> Output Class Initialized
INFO - 2021-07-16 08:38:19 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:19 --> Input Class Initialized
INFO - 2021-07-16 08:38:19 --> Language Class Initialized
INFO - 2021-07-16 08:38:19 --> Language Class Initialized
INFO - 2021-07-16 08:38:19 --> Config Class Initialized
INFO - 2021-07-16 08:38:19 --> Loader Class Initialized
INFO - 2021-07-16 08:38:19 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:19 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:19 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:19 --> Controller Class Initialized
INFO - 2021-07-16 08:38:25 --> Config Class Initialized
INFO - 2021-07-16 08:38:25 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:25 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:25 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:25 --> URI Class Initialized
INFO - 2021-07-16 08:38:25 --> Router Class Initialized
INFO - 2021-07-16 08:38:25 --> Output Class Initialized
INFO - 2021-07-16 08:38:25 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:25 --> Input Class Initialized
INFO - 2021-07-16 08:38:25 --> Language Class Initialized
INFO - 2021-07-16 08:38:25 --> Language Class Initialized
INFO - 2021-07-16 08:38:25 --> Config Class Initialized
INFO - 2021-07-16 08:38:25 --> Loader Class Initialized
INFO - 2021-07-16 08:38:25 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:25 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:25 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:25 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:25 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:25 --> Controller Class Initialized
ERROR - 2021-07-16 08:38:25 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'an Ananta%' AND stat_data = 'A'' at line 1 - Invalid query: SELECT id FROM m_siswa WHERE nama LIKE '%A'an Ananta%' AND stat_data = 'A'
INFO - 2021-07-16 08:38:25 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-16 08:38:29 --> Config Class Initialized
INFO - 2021-07-16 08:38:29 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:29 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:29 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:29 --> URI Class Initialized
INFO - 2021-07-16 08:38:29 --> Router Class Initialized
INFO - 2021-07-16 08:38:29 --> Output Class Initialized
INFO - 2021-07-16 08:38:29 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:29 --> Input Class Initialized
INFO - 2021-07-16 08:38:29 --> Language Class Initialized
INFO - 2021-07-16 08:38:29 --> Language Class Initialized
INFO - 2021-07-16 08:38:29 --> Config Class Initialized
INFO - 2021-07-16 08:38:29 --> Loader Class Initialized
INFO - 2021-07-16 08:38:29 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:29 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:29 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:29 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:29 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:29 --> Controller Class Initialized
ERROR - 2021-07-16 08:38:29 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:38:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:38:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:38:29 --> Final output sent to browser
DEBUG - 2021-07-16 08:38:29 --> Total execution time: 0.0485
INFO - 2021-07-16 08:38:31 --> Config Class Initialized
INFO - 2021-07-16 08:38:31 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:31 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:31 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:31 --> URI Class Initialized
INFO - 2021-07-16 08:38:31 --> Router Class Initialized
INFO - 2021-07-16 08:38:31 --> Output Class Initialized
INFO - 2021-07-16 08:38:31 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:31 --> Input Class Initialized
INFO - 2021-07-16 08:38:31 --> Language Class Initialized
INFO - 2021-07-16 08:38:31 --> Language Class Initialized
INFO - 2021-07-16 08:38:31 --> Config Class Initialized
INFO - 2021-07-16 08:38:31 --> Loader Class Initialized
INFO - 2021-07-16 08:38:31 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:31 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:31 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:31 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:31 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:31 --> Controller Class Initialized
DEBUG - 2021-07-16 08:38:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:38:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:38:31 --> Final output sent to browser
DEBUG - 2021-07-16 08:38:31 --> Total execution time: 0.0442
INFO - 2021-07-16 08:38:31 --> Config Class Initialized
INFO - 2021-07-16 08:38:31 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:31 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:31 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:31 --> URI Class Initialized
INFO - 2021-07-16 08:38:31 --> Router Class Initialized
INFO - 2021-07-16 08:38:31 --> Output Class Initialized
INFO - 2021-07-16 08:38:31 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:31 --> Input Class Initialized
INFO - 2021-07-16 08:38:31 --> Language Class Initialized
INFO - 2021-07-16 08:38:31 --> Language Class Initialized
INFO - 2021-07-16 08:38:31 --> Config Class Initialized
INFO - 2021-07-16 08:38:31 --> Loader Class Initialized
INFO - 2021-07-16 08:38:31 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:31 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:31 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:31 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:31 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:31 --> Controller Class Initialized
INFO - 2021-07-16 08:38:33 --> Config Class Initialized
INFO - 2021-07-16 08:38:33 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:33 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:33 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:33 --> URI Class Initialized
INFO - 2021-07-16 08:38:33 --> Router Class Initialized
INFO - 2021-07-16 08:38:33 --> Output Class Initialized
INFO - 2021-07-16 08:38:33 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:33 --> Input Class Initialized
INFO - 2021-07-16 08:38:33 --> Language Class Initialized
INFO - 2021-07-16 08:38:33 --> Language Class Initialized
INFO - 2021-07-16 08:38:33 --> Config Class Initialized
INFO - 2021-07-16 08:38:33 --> Loader Class Initialized
INFO - 2021-07-16 08:38:33 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:33 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:33 --> Controller Class Initialized
INFO - 2021-07-16 08:38:33 --> Config Class Initialized
INFO - 2021-07-16 08:38:33 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:33 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:33 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:33 --> URI Class Initialized
INFO - 2021-07-16 08:38:33 --> Router Class Initialized
INFO - 2021-07-16 08:38:33 --> Output Class Initialized
INFO - 2021-07-16 08:38:33 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:33 --> Input Class Initialized
INFO - 2021-07-16 08:38:33 --> Language Class Initialized
INFO - 2021-07-16 08:38:33 --> Language Class Initialized
INFO - 2021-07-16 08:38:33 --> Config Class Initialized
INFO - 2021-07-16 08:38:33 --> Loader Class Initialized
INFO - 2021-07-16 08:38:33 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:33 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:33 --> Controller Class Initialized
INFO - 2021-07-16 08:38:33 --> Config Class Initialized
INFO - 2021-07-16 08:38:33 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:33 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:33 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:33 --> URI Class Initialized
INFO - 2021-07-16 08:38:33 --> Router Class Initialized
INFO - 2021-07-16 08:38:33 --> Output Class Initialized
INFO - 2021-07-16 08:38:33 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:33 --> Input Class Initialized
INFO - 2021-07-16 08:38:33 --> Language Class Initialized
INFO - 2021-07-16 08:38:33 --> Language Class Initialized
INFO - 2021-07-16 08:38:33 --> Config Class Initialized
INFO - 2021-07-16 08:38:33 --> Loader Class Initialized
INFO - 2021-07-16 08:38:33 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:33 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:33 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:33 --> Controller Class Initialized
INFO - 2021-07-16 08:38:35 --> Config Class Initialized
INFO - 2021-07-16 08:38:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:35 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:35 --> URI Class Initialized
INFO - 2021-07-16 08:38:35 --> Router Class Initialized
INFO - 2021-07-16 08:38:35 --> Output Class Initialized
INFO - 2021-07-16 08:38:35 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:35 --> Input Class Initialized
INFO - 2021-07-16 08:38:35 --> Language Class Initialized
INFO - 2021-07-16 08:38:35 --> Language Class Initialized
INFO - 2021-07-16 08:38:35 --> Config Class Initialized
INFO - 2021-07-16 08:38:35 --> Loader Class Initialized
INFO - 2021-07-16 08:38:35 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:35 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:35 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:35 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:35 --> Controller Class Initialized
ERROR - 2021-07-16 08:38:35 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:38:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:38:35 --> Final output sent to browser
DEBUG - 2021-07-16 08:38:35 --> Total execution time: 0.0685
INFO - 2021-07-16 08:38:59 --> Config Class Initialized
INFO - 2021-07-16 08:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:59 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:59 --> URI Class Initialized
INFO - 2021-07-16 08:38:59 --> Router Class Initialized
INFO - 2021-07-16 08:38:59 --> Output Class Initialized
INFO - 2021-07-16 08:38:59 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:59 --> Input Class Initialized
INFO - 2021-07-16 08:38:59 --> Language Class Initialized
INFO - 2021-07-16 08:38:59 --> Language Class Initialized
INFO - 2021-07-16 08:38:59 --> Config Class Initialized
INFO - 2021-07-16 08:38:59 --> Loader Class Initialized
INFO - 2021-07-16 08:38:59 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:59 --> Controller Class Initialized
INFO - 2021-07-16 08:38:59 --> Upload Class Initialized
INFO - 2021-07-16 08:38:59 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:38:59 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:38:59 --> Config Class Initialized
INFO - 2021-07-16 08:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:59 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:59 --> URI Class Initialized
INFO - 2021-07-16 08:38:59 --> Router Class Initialized
INFO - 2021-07-16 08:38:59 --> Output Class Initialized
INFO - 2021-07-16 08:38:59 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:59 --> Input Class Initialized
INFO - 2021-07-16 08:38:59 --> Language Class Initialized
INFO - 2021-07-16 08:38:59 --> Language Class Initialized
INFO - 2021-07-16 08:38:59 --> Config Class Initialized
INFO - 2021-07-16 08:38:59 --> Loader Class Initialized
INFO - 2021-07-16 08:38:59 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:59 --> Controller Class Initialized
DEBUG - 2021-07-16 08:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:38:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:38:59 --> Final output sent to browser
DEBUG - 2021-07-16 08:38:59 --> Total execution time: 0.0641
INFO - 2021-07-16 08:38:59 --> Config Class Initialized
INFO - 2021-07-16 08:38:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:38:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:38:59 --> Utf8 Class Initialized
INFO - 2021-07-16 08:38:59 --> URI Class Initialized
INFO - 2021-07-16 08:38:59 --> Router Class Initialized
INFO - 2021-07-16 08:38:59 --> Output Class Initialized
INFO - 2021-07-16 08:38:59 --> Security Class Initialized
DEBUG - 2021-07-16 08:38:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:38:59 --> Input Class Initialized
INFO - 2021-07-16 08:38:59 --> Language Class Initialized
INFO - 2021-07-16 08:38:59 --> Language Class Initialized
INFO - 2021-07-16 08:38:59 --> Config Class Initialized
INFO - 2021-07-16 08:38:59 --> Loader Class Initialized
INFO - 2021-07-16 08:38:59 --> Helper loaded: url_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: file_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: form_helper
INFO - 2021-07-16 08:38:59 --> Helper loaded: my_helper
INFO - 2021-07-16 08:38:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:38:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:38:59 --> Controller Class Initialized
INFO - 2021-07-16 08:39:01 --> Config Class Initialized
INFO - 2021-07-16 08:39:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:01 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:01 --> URI Class Initialized
INFO - 2021-07-16 08:39:01 --> Router Class Initialized
INFO - 2021-07-16 08:39:01 --> Output Class Initialized
INFO - 2021-07-16 08:39:01 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:01 --> Input Class Initialized
INFO - 2021-07-16 08:39:01 --> Language Class Initialized
INFO - 2021-07-16 08:39:01 --> Language Class Initialized
INFO - 2021-07-16 08:39:01 --> Config Class Initialized
INFO - 2021-07-16 08:39:01 --> Loader Class Initialized
INFO - 2021-07-16 08:39:01 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:01 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:01 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:01 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:01 --> Controller Class Initialized
INFO - 2021-07-16 08:39:02 --> Config Class Initialized
INFO - 2021-07-16 08:39:02 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:02 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:02 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:02 --> URI Class Initialized
INFO - 2021-07-16 08:39:02 --> Router Class Initialized
INFO - 2021-07-16 08:39:02 --> Output Class Initialized
INFO - 2021-07-16 08:39:02 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:02 --> Input Class Initialized
INFO - 2021-07-16 08:39:02 --> Language Class Initialized
INFO - 2021-07-16 08:39:02 --> Language Class Initialized
INFO - 2021-07-16 08:39:02 --> Config Class Initialized
INFO - 2021-07-16 08:39:02 --> Loader Class Initialized
INFO - 2021-07-16 08:39:02 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:02 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:02 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:02 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:02 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:02 --> Controller Class Initialized
ERROR - 2021-07-16 08:39:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near '%' AND stat_data = 'A'' at line 1 - Invalid query: SELECT id FROM m_siswa WHERE nama LIKE '%A'%' AND stat_data = 'A'
INFO - 2021-07-16 08:39:02 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-16 08:39:03 --> Config Class Initialized
INFO - 2021-07-16 08:39:03 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:03 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:03 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:03 --> URI Class Initialized
INFO - 2021-07-16 08:39:03 --> Router Class Initialized
INFO - 2021-07-16 08:39:03 --> Output Class Initialized
INFO - 2021-07-16 08:39:03 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:03 --> Input Class Initialized
INFO - 2021-07-16 08:39:03 --> Language Class Initialized
INFO - 2021-07-16 08:39:03 --> Language Class Initialized
INFO - 2021-07-16 08:39:03 --> Config Class Initialized
INFO - 2021-07-16 08:39:03 --> Loader Class Initialized
INFO - 2021-07-16 08:39:03 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:03 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:03 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:03 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:03 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:03 --> Controller Class Initialized
ERROR - 2021-07-16 08:39:03 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a%' AND stat_data = 'A'' at line 1 - Invalid query: SELECT id FROM m_siswa WHERE nama LIKE '%A'a%' AND stat_data = 'A'
INFO - 2021-07-16 08:39:03 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-16 08:39:04 --> Config Class Initialized
INFO - 2021-07-16 08:39:04 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:04 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:04 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:04 --> URI Class Initialized
INFO - 2021-07-16 08:39:04 --> Router Class Initialized
INFO - 2021-07-16 08:39:04 --> Output Class Initialized
INFO - 2021-07-16 08:39:04 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:04 --> Input Class Initialized
INFO - 2021-07-16 08:39:04 --> Language Class Initialized
INFO - 2021-07-16 08:39:04 --> Language Class Initialized
INFO - 2021-07-16 08:39:04 --> Config Class Initialized
INFO - 2021-07-16 08:39:04 --> Loader Class Initialized
INFO - 2021-07-16 08:39:04 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:04 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:04 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:04 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:04 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:04 --> Controller Class Initialized
ERROR - 2021-07-16 08:39:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'an%' AND stat_data = 'A'' at line 1 - Invalid query: SELECT id FROM m_siswa WHERE nama LIKE '%A'an%' AND stat_data = 'A'
INFO - 2021-07-16 08:39:04 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-16 08:39:06 --> Config Class Initialized
INFO - 2021-07-16 08:39:06 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:06 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:06 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:06 --> URI Class Initialized
INFO - 2021-07-16 08:39:06 --> Router Class Initialized
INFO - 2021-07-16 08:39:06 --> Output Class Initialized
INFO - 2021-07-16 08:39:06 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:06 --> Input Class Initialized
INFO - 2021-07-16 08:39:06 --> Language Class Initialized
INFO - 2021-07-16 08:39:06 --> Language Class Initialized
INFO - 2021-07-16 08:39:06 --> Config Class Initialized
INFO - 2021-07-16 08:39:06 --> Loader Class Initialized
INFO - 2021-07-16 08:39:06 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:06 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:06 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:06 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:06 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:06 --> Controller Class Initialized
ERROR - 2021-07-16 08:39:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near 'a%' AND stat_data = 'A'' at line 1 - Invalid query: SELECT id FROM m_siswa WHERE nama LIKE '%A'a%' AND stat_data = 'A'
INFO - 2021-07-16 08:39:06 --> Language file loaded: language/english/db_lang.php
INFO - 2021-07-16 08:39:07 --> Config Class Initialized
INFO - 2021-07-16 08:39:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:07 --> URI Class Initialized
INFO - 2021-07-16 08:39:07 --> Router Class Initialized
INFO - 2021-07-16 08:39:07 --> Output Class Initialized
INFO - 2021-07-16 08:39:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:07 --> Input Class Initialized
INFO - 2021-07-16 08:39:07 --> Language Class Initialized
INFO - 2021-07-16 08:39:07 --> Language Class Initialized
INFO - 2021-07-16 08:39:07 --> Config Class Initialized
INFO - 2021-07-16 08:39:07 --> Loader Class Initialized
INFO - 2021-07-16 08:39:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:07 --> Controller Class Initialized
INFO - 2021-07-16 08:39:07 --> Config Class Initialized
INFO - 2021-07-16 08:39:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:07 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:07 --> URI Class Initialized
INFO - 2021-07-16 08:39:07 --> Router Class Initialized
INFO - 2021-07-16 08:39:07 --> Output Class Initialized
INFO - 2021-07-16 08:39:07 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:07 --> Input Class Initialized
INFO - 2021-07-16 08:39:07 --> Language Class Initialized
INFO - 2021-07-16 08:39:07 --> Language Class Initialized
INFO - 2021-07-16 08:39:07 --> Config Class Initialized
INFO - 2021-07-16 08:39:07 --> Loader Class Initialized
INFO - 2021-07-16 08:39:07 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:07 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:07 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:07 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:07 --> Controller Class Initialized
INFO - 2021-07-16 08:39:11 --> Config Class Initialized
INFO - 2021-07-16 08:39:11 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:11 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:11 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:11 --> URI Class Initialized
INFO - 2021-07-16 08:39:11 --> Router Class Initialized
INFO - 2021-07-16 08:39:11 --> Output Class Initialized
INFO - 2021-07-16 08:39:11 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:11 --> Input Class Initialized
INFO - 2021-07-16 08:39:11 --> Language Class Initialized
INFO - 2021-07-16 08:39:11 --> Language Class Initialized
INFO - 2021-07-16 08:39:11 --> Config Class Initialized
INFO - 2021-07-16 08:39:11 --> Loader Class Initialized
INFO - 2021-07-16 08:39:11 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:11 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:11 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:11 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:11 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:11 --> Controller Class Initialized
INFO - 2021-07-16 08:39:12 --> Config Class Initialized
INFO - 2021-07-16 08:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:12 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:12 --> URI Class Initialized
INFO - 2021-07-16 08:39:12 --> Router Class Initialized
INFO - 2021-07-16 08:39:12 --> Output Class Initialized
INFO - 2021-07-16 08:39:12 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:12 --> Input Class Initialized
INFO - 2021-07-16 08:39:12 --> Language Class Initialized
INFO - 2021-07-16 08:39:12 --> Language Class Initialized
INFO - 2021-07-16 08:39:12 --> Config Class Initialized
INFO - 2021-07-16 08:39:12 --> Loader Class Initialized
INFO - 2021-07-16 08:39:12 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:12 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:12 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:12 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:12 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:12 --> Controller Class Initialized
INFO - 2021-07-16 08:39:12 --> Config Class Initialized
INFO - 2021-07-16 08:39:12 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:12 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:12 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:12 --> URI Class Initialized
INFO - 2021-07-16 08:39:12 --> Router Class Initialized
INFO - 2021-07-16 08:39:12 --> Output Class Initialized
INFO - 2021-07-16 08:39:12 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:12 --> Input Class Initialized
INFO - 2021-07-16 08:39:12 --> Language Class Initialized
INFO - 2021-07-16 08:39:12 --> Language Class Initialized
INFO - 2021-07-16 08:39:12 --> Config Class Initialized
INFO - 2021-07-16 08:39:12 --> Loader Class Initialized
INFO - 2021-07-16 08:39:12 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:12 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:12 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:12 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:12 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:12 --> Controller Class Initialized
INFO - 2021-07-16 08:39:13 --> Config Class Initialized
INFO - 2021-07-16 08:39:13 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:13 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:13 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:13 --> URI Class Initialized
INFO - 2021-07-16 08:39:13 --> Router Class Initialized
INFO - 2021-07-16 08:39:13 --> Output Class Initialized
INFO - 2021-07-16 08:39:13 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:13 --> Input Class Initialized
INFO - 2021-07-16 08:39:13 --> Language Class Initialized
INFO - 2021-07-16 08:39:13 --> Language Class Initialized
INFO - 2021-07-16 08:39:13 --> Config Class Initialized
INFO - 2021-07-16 08:39:13 --> Loader Class Initialized
INFO - 2021-07-16 08:39:13 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:13 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:13 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:13 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:13 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:13 --> Controller Class Initialized
INFO - 2021-07-16 08:39:16 --> Config Class Initialized
INFO - 2021-07-16 08:39:16 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:16 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:16 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:16 --> URI Class Initialized
INFO - 2021-07-16 08:39:16 --> Router Class Initialized
INFO - 2021-07-16 08:39:16 --> Output Class Initialized
INFO - 2021-07-16 08:39:16 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:16 --> Input Class Initialized
INFO - 2021-07-16 08:39:16 --> Language Class Initialized
INFO - 2021-07-16 08:39:16 --> Language Class Initialized
INFO - 2021-07-16 08:39:16 --> Config Class Initialized
INFO - 2021-07-16 08:39:16 --> Loader Class Initialized
INFO - 2021-07-16 08:39:16 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:16 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:16 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:16 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:16 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:16 --> Controller Class Initialized
DEBUG - 2021-07-16 08:39:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:39:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:39:16 --> Final output sent to browser
DEBUG - 2021-07-16 08:39:16 --> Total execution time: 0.0589
INFO - 2021-07-16 08:39:16 --> Config Class Initialized
INFO - 2021-07-16 08:39:16 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:16 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:16 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:16 --> URI Class Initialized
INFO - 2021-07-16 08:39:16 --> Router Class Initialized
INFO - 2021-07-16 08:39:16 --> Output Class Initialized
INFO - 2021-07-16 08:39:16 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:16 --> Input Class Initialized
INFO - 2021-07-16 08:39:17 --> Language Class Initialized
INFO - 2021-07-16 08:39:17 --> Language Class Initialized
INFO - 2021-07-16 08:39:17 --> Config Class Initialized
INFO - 2021-07-16 08:39:17 --> Loader Class Initialized
INFO - 2021-07-16 08:39:17 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:17 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:17 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:17 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:17 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:17 --> Controller Class Initialized
INFO - 2021-07-16 08:39:18 --> Config Class Initialized
INFO - 2021-07-16 08:39:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:18 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:18 --> URI Class Initialized
INFO - 2021-07-16 08:39:18 --> Router Class Initialized
INFO - 2021-07-16 08:39:18 --> Output Class Initialized
INFO - 2021-07-16 08:39:18 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:18 --> Input Class Initialized
INFO - 2021-07-16 08:39:18 --> Language Class Initialized
INFO - 2021-07-16 08:39:18 --> Language Class Initialized
INFO - 2021-07-16 08:39:18 --> Config Class Initialized
INFO - 2021-07-16 08:39:18 --> Loader Class Initialized
INFO - 2021-07-16 08:39:18 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:18 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:18 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:18 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:18 --> Controller Class Initialized
INFO - 2021-07-16 08:39:18 --> Config Class Initialized
INFO - 2021-07-16 08:39:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:18 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:18 --> URI Class Initialized
INFO - 2021-07-16 08:39:18 --> Router Class Initialized
INFO - 2021-07-16 08:39:18 --> Output Class Initialized
INFO - 2021-07-16 08:39:18 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:18 --> Input Class Initialized
INFO - 2021-07-16 08:39:18 --> Language Class Initialized
INFO - 2021-07-16 08:39:18 --> Language Class Initialized
INFO - 2021-07-16 08:39:18 --> Config Class Initialized
INFO - 2021-07-16 08:39:18 --> Loader Class Initialized
INFO - 2021-07-16 08:39:18 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:18 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:18 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:18 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:18 --> Controller Class Initialized
INFO - 2021-07-16 08:39:19 --> Config Class Initialized
INFO - 2021-07-16 08:39:19 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:19 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:19 --> URI Class Initialized
INFO - 2021-07-16 08:39:19 --> Router Class Initialized
INFO - 2021-07-16 08:39:19 --> Output Class Initialized
INFO - 2021-07-16 08:39:19 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:19 --> Input Class Initialized
INFO - 2021-07-16 08:39:19 --> Language Class Initialized
INFO - 2021-07-16 08:39:19 --> Language Class Initialized
INFO - 2021-07-16 08:39:19 --> Config Class Initialized
INFO - 2021-07-16 08:39:19 --> Loader Class Initialized
INFO - 2021-07-16 08:39:19 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:19 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:19 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:19 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:19 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:19 --> Controller Class Initialized
INFO - 2021-07-16 08:39:21 --> Config Class Initialized
INFO - 2021-07-16 08:39:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:21 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:21 --> URI Class Initialized
INFO - 2021-07-16 08:39:21 --> Router Class Initialized
INFO - 2021-07-16 08:39:21 --> Output Class Initialized
INFO - 2021-07-16 08:39:21 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:21 --> Input Class Initialized
INFO - 2021-07-16 08:39:21 --> Language Class Initialized
INFO - 2021-07-16 08:39:21 --> Language Class Initialized
INFO - 2021-07-16 08:39:21 --> Config Class Initialized
INFO - 2021-07-16 08:39:21 --> Loader Class Initialized
INFO - 2021-07-16 08:39:21 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:21 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:21 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:21 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:21 --> Controller Class Initialized
ERROR - 2021-07-16 08:39:21 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:39:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:39:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:39:21 --> Final output sent to browser
DEBUG - 2021-07-16 08:39:21 --> Total execution time: 0.0483
INFO - 2021-07-16 08:39:45 --> Config Class Initialized
INFO - 2021-07-16 08:39:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:45 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:45 --> URI Class Initialized
INFO - 2021-07-16 08:39:45 --> Router Class Initialized
INFO - 2021-07-16 08:39:45 --> Output Class Initialized
INFO - 2021-07-16 08:39:45 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:45 --> Input Class Initialized
INFO - 2021-07-16 08:39:45 --> Language Class Initialized
INFO - 2021-07-16 08:39:45 --> Language Class Initialized
INFO - 2021-07-16 08:39:45 --> Config Class Initialized
INFO - 2021-07-16 08:39:45 --> Loader Class Initialized
INFO - 2021-07-16 08:39:45 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:45 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:45 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:45 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:45 --> Controller Class Initialized
INFO - 2021-07-16 08:39:45 --> Upload Class Initialized
INFO - 2021-07-16 08:39:45 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:39:45 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:39:45 --> Config Class Initialized
INFO - 2021-07-16 08:39:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:45 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:45 --> URI Class Initialized
INFO - 2021-07-16 08:39:45 --> Router Class Initialized
INFO - 2021-07-16 08:39:45 --> Output Class Initialized
INFO - 2021-07-16 08:39:45 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:45 --> Input Class Initialized
INFO - 2021-07-16 08:39:45 --> Language Class Initialized
INFO - 2021-07-16 08:39:45 --> Language Class Initialized
INFO - 2021-07-16 08:39:45 --> Config Class Initialized
INFO - 2021-07-16 08:39:45 --> Loader Class Initialized
INFO - 2021-07-16 08:39:45 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:45 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:45 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:45 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:45 --> Controller Class Initialized
DEBUG - 2021-07-16 08:39:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:39:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:39:45 --> Final output sent to browser
DEBUG - 2021-07-16 08:39:45 --> Total execution time: 0.0623
INFO - 2021-07-16 08:39:46 --> Config Class Initialized
INFO - 2021-07-16 08:39:46 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:46 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:46 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:46 --> URI Class Initialized
INFO - 2021-07-16 08:39:46 --> Router Class Initialized
INFO - 2021-07-16 08:39:46 --> Output Class Initialized
INFO - 2021-07-16 08:39:46 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:46 --> Input Class Initialized
INFO - 2021-07-16 08:39:46 --> Language Class Initialized
INFO - 2021-07-16 08:39:46 --> Language Class Initialized
INFO - 2021-07-16 08:39:46 --> Config Class Initialized
INFO - 2021-07-16 08:39:46 --> Loader Class Initialized
INFO - 2021-07-16 08:39:46 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:46 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:46 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:46 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:46 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:46 --> Controller Class Initialized
INFO - 2021-07-16 08:39:52 --> Config Class Initialized
INFO - 2021-07-16 08:39:52 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:52 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:52 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:52 --> URI Class Initialized
INFO - 2021-07-16 08:39:52 --> Router Class Initialized
INFO - 2021-07-16 08:39:52 --> Output Class Initialized
INFO - 2021-07-16 08:39:52 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:52 --> Input Class Initialized
INFO - 2021-07-16 08:39:52 --> Language Class Initialized
INFO - 2021-07-16 08:39:52 --> Language Class Initialized
INFO - 2021-07-16 08:39:52 --> Config Class Initialized
INFO - 2021-07-16 08:39:52 --> Loader Class Initialized
INFO - 2021-07-16 08:39:52 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:52 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:52 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:52 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:52 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:52 --> Controller Class Initialized
INFO - 2021-07-16 08:39:52 --> Config Class Initialized
INFO - 2021-07-16 08:39:52 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:39:52 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:39:52 --> Utf8 Class Initialized
INFO - 2021-07-16 08:39:52 --> URI Class Initialized
INFO - 2021-07-16 08:39:52 --> Router Class Initialized
INFO - 2021-07-16 08:39:52 --> Output Class Initialized
INFO - 2021-07-16 08:39:52 --> Security Class Initialized
DEBUG - 2021-07-16 08:39:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:39:52 --> Input Class Initialized
INFO - 2021-07-16 08:39:52 --> Language Class Initialized
INFO - 2021-07-16 08:39:52 --> Language Class Initialized
INFO - 2021-07-16 08:39:52 --> Config Class Initialized
INFO - 2021-07-16 08:39:52 --> Loader Class Initialized
INFO - 2021-07-16 08:39:52 --> Helper loaded: url_helper
INFO - 2021-07-16 08:39:52 --> Helper loaded: file_helper
INFO - 2021-07-16 08:39:52 --> Helper loaded: form_helper
INFO - 2021-07-16 08:39:52 --> Helper loaded: my_helper
INFO - 2021-07-16 08:39:52 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:39:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:39:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:39:52 --> Controller Class Initialized
ERROR - 2021-07-16 08:39:52 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 08:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 08:39:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:39:52 --> Final output sent to browser
DEBUG - 2021-07-16 08:39:52 --> Total execution time: 0.0689
INFO - 2021-07-16 08:40:43 --> Config Class Initialized
INFO - 2021-07-16 08:40:43 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:43 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:43 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:43 --> URI Class Initialized
INFO - 2021-07-16 08:40:43 --> Router Class Initialized
INFO - 2021-07-16 08:40:43 --> Output Class Initialized
INFO - 2021-07-16 08:40:43 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:43 --> Input Class Initialized
INFO - 2021-07-16 08:40:43 --> Language Class Initialized
INFO - 2021-07-16 08:40:43 --> Language Class Initialized
INFO - 2021-07-16 08:40:43 --> Config Class Initialized
INFO - 2021-07-16 08:40:43 --> Loader Class Initialized
INFO - 2021-07-16 08:40:43 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:43 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:43 --> Controller Class Initialized
INFO - 2021-07-16 08:40:43 --> Upload Class Initialized
INFO - 2021-07-16 08:40:43 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 08:40:43 --> The upload path does not appear to be valid.
INFO - 2021-07-16 08:40:43 --> Config Class Initialized
INFO - 2021-07-16 08:40:43 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:43 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:43 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:43 --> URI Class Initialized
INFO - 2021-07-16 08:40:43 --> Router Class Initialized
INFO - 2021-07-16 08:40:43 --> Output Class Initialized
INFO - 2021-07-16 08:40:43 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:43 --> Input Class Initialized
INFO - 2021-07-16 08:40:43 --> Language Class Initialized
INFO - 2021-07-16 08:40:43 --> Language Class Initialized
INFO - 2021-07-16 08:40:43 --> Config Class Initialized
INFO - 2021-07-16 08:40:43 --> Loader Class Initialized
INFO - 2021-07-16 08:40:43 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:43 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:43 --> Controller Class Initialized
DEBUG - 2021-07-16 08:40:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 08:40:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:40:43 --> Final output sent to browser
DEBUG - 2021-07-16 08:40:43 --> Total execution time: 0.0639
INFO - 2021-07-16 08:40:43 --> Config Class Initialized
INFO - 2021-07-16 08:40:43 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:43 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:43 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:43 --> URI Class Initialized
INFO - 2021-07-16 08:40:43 --> Router Class Initialized
INFO - 2021-07-16 08:40:43 --> Output Class Initialized
INFO - 2021-07-16 08:40:43 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:43 --> Input Class Initialized
INFO - 2021-07-16 08:40:43 --> Language Class Initialized
INFO - 2021-07-16 08:40:43 --> Language Class Initialized
INFO - 2021-07-16 08:40:43 --> Config Class Initialized
INFO - 2021-07-16 08:40:43 --> Loader Class Initialized
INFO - 2021-07-16 08:40:43 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:43 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:43 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:43 --> Controller Class Initialized
INFO - 2021-07-16 08:40:44 --> Config Class Initialized
INFO - 2021-07-16 08:40:44 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:44 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:44 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:44 --> URI Class Initialized
INFO - 2021-07-16 08:40:44 --> Router Class Initialized
INFO - 2021-07-16 08:40:44 --> Output Class Initialized
INFO - 2021-07-16 08:40:44 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:44 --> Input Class Initialized
INFO - 2021-07-16 08:40:44 --> Language Class Initialized
INFO - 2021-07-16 08:40:44 --> Language Class Initialized
INFO - 2021-07-16 08:40:44 --> Config Class Initialized
INFO - 2021-07-16 08:40:44 --> Loader Class Initialized
INFO - 2021-07-16 08:40:44 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:44 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:44 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:44 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:44 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:44 --> Controller Class Initialized
INFO - 2021-07-16 08:40:44 --> Helper loaded: cookie_helper
INFO - 2021-07-16 08:40:44 --> Config Class Initialized
INFO - 2021-07-16 08:40:44 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:44 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:44 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:44 --> URI Class Initialized
INFO - 2021-07-16 08:40:44 --> Router Class Initialized
INFO - 2021-07-16 08:40:44 --> Output Class Initialized
INFO - 2021-07-16 08:40:44 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:44 --> Input Class Initialized
INFO - 2021-07-16 08:40:44 --> Language Class Initialized
INFO - 2021-07-16 08:40:44 --> Language Class Initialized
INFO - 2021-07-16 08:40:44 --> Config Class Initialized
INFO - 2021-07-16 08:40:44 --> Loader Class Initialized
INFO - 2021-07-16 08:40:44 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:44 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:44 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:44 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:44 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:44 --> Controller Class Initialized
DEBUG - 2021-07-16 08:40:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 08:40:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:40:44 --> Final output sent to browser
DEBUG - 2021-07-16 08:40:44 --> Total execution time: 0.0532
INFO - 2021-07-16 08:40:48 --> Config Class Initialized
INFO - 2021-07-16 08:40:48 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:48 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:48 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:48 --> URI Class Initialized
INFO - 2021-07-16 08:40:48 --> Router Class Initialized
INFO - 2021-07-16 08:40:48 --> Output Class Initialized
INFO - 2021-07-16 08:40:48 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:48 --> Input Class Initialized
INFO - 2021-07-16 08:40:48 --> Language Class Initialized
INFO - 2021-07-16 08:40:48 --> Language Class Initialized
INFO - 2021-07-16 08:40:48 --> Config Class Initialized
INFO - 2021-07-16 08:40:48 --> Loader Class Initialized
INFO - 2021-07-16 08:40:48 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:48 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:48 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:48 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:48 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:48 --> Controller Class Initialized
INFO - 2021-07-16 08:40:48 --> Helper loaded: cookie_helper
INFO - 2021-07-16 08:40:48 --> Final output sent to browser
DEBUG - 2021-07-16 08:40:48 --> Total execution time: 0.0488
INFO - 2021-07-16 08:40:48 --> Config Class Initialized
INFO - 2021-07-16 08:40:48 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:48 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:48 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:48 --> URI Class Initialized
INFO - 2021-07-16 08:40:48 --> Router Class Initialized
INFO - 2021-07-16 08:40:48 --> Output Class Initialized
INFO - 2021-07-16 08:40:48 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:48 --> Input Class Initialized
INFO - 2021-07-16 08:40:48 --> Language Class Initialized
INFO - 2021-07-16 08:40:48 --> Language Class Initialized
INFO - 2021-07-16 08:40:48 --> Config Class Initialized
INFO - 2021-07-16 08:40:48 --> Loader Class Initialized
INFO - 2021-07-16 08:40:48 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:48 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:48 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:48 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:48 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:48 --> Controller Class Initialized
DEBUG - 2021-07-16 08:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 08:40:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:40:49 --> Final output sent to browser
DEBUG - 2021-07-16 08:40:49 --> Total execution time: 0.7219
INFO - 2021-07-16 08:40:52 --> Config Class Initialized
INFO - 2021-07-16 08:40:52 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:40:52 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:40:52 --> Utf8 Class Initialized
INFO - 2021-07-16 08:40:52 --> URI Class Initialized
INFO - 2021-07-16 08:40:52 --> Router Class Initialized
INFO - 2021-07-16 08:40:52 --> Output Class Initialized
INFO - 2021-07-16 08:40:52 --> Security Class Initialized
DEBUG - 2021-07-16 08:40:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:40:52 --> Input Class Initialized
INFO - 2021-07-16 08:40:52 --> Language Class Initialized
INFO - 2021-07-16 08:40:52 --> Language Class Initialized
INFO - 2021-07-16 08:40:52 --> Config Class Initialized
INFO - 2021-07-16 08:40:52 --> Loader Class Initialized
INFO - 2021-07-16 08:40:52 --> Helper loaded: url_helper
INFO - 2021-07-16 08:40:52 --> Helper loaded: file_helper
INFO - 2021-07-16 08:40:52 --> Helper loaded: form_helper
INFO - 2021-07-16 08:40:52 --> Helper loaded: my_helper
INFO - 2021-07-16 08:40:52 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:40:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:40:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:40:52 --> Controller Class Initialized
DEBUG - 2021-07-16 08:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 08:40:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:40:52 --> Final output sent to browser
DEBUG - 2021-07-16 08:40:52 --> Total execution time: 0.0734
INFO - 2021-07-16 08:41:23 --> Config Class Initialized
INFO - 2021-07-16 08:41:23 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:41:23 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:41:23 --> Utf8 Class Initialized
INFO - 2021-07-16 08:41:23 --> URI Class Initialized
INFO - 2021-07-16 08:41:23 --> Router Class Initialized
INFO - 2021-07-16 08:41:23 --> Output Class Initialized
INFO - 2021-07-16 08:41:23 --> Security Class Initialized
DEBUG - 2021-07-16 08:41:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:41:23 --> Input Class Initialized
INFO - 2021-07-16 08:41:23 --> Language Class Initialized
INFO - 2021-07-16 08:41:23 --> Language Class Initialized
INFO - 2021-07-16 08:41:23 --> Config Class Initialized
INFO - 2021-07-16 08:41:23 --> Loader Class Initialized
INFO - 2021-07-16 08:41:23 --> Helper loaded: url_helper
INFO - 2021-07-16 08:41:23 --> Helper loaded: file_helper
INFO - 2021-07-16 08:41:23 --> Helper loaded: form_helper
INFO - 2021-07-16 08:41:23 --> Helper loaded: my_helper
INFO - 2021-07-16 08:41:23 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:41:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:41:23 --> Controller Class Initialized
DEBUG - 2021-07-16 08:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 08:41:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:41:23 --> Final output sent to browser
DEBUG - 2021-07-16 08:41:23 --> Total execution time: 0.0882
INFO - 2021-07-16 08:41:27 --> Config Class Initialized
INFO - 2021-07-16 08:41:27 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:41:27 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:41:27 --> Utf8 Class Initialized
INFO - 2021-07-16 08:41:27 --> URI Class Initialized
INFO - 2021-07-16 08:41:27 --> Router Class Initialized
INFO - 2021-07-16 08:41:27 --> Output Class Initialized
INFO - 2021-07-16 08:41:27 --> Security Class Initialized
DEBUG - 2021-07-16 08:41:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:41:27 --> Input Class Initialized
INFO - 2021-07-16 08:41:27 --> Language Class Initialized
INFO - 2021-07-16 08:41:27 --> Language Class Initialized
INFO - 2021-07-16 08:41:27 --> Config Class Initialized
INFO - 2021-07-16 08:41:27 --> Loader Class Initialized
INFO - 2021-07-16 08:41:27 --> Helper loaded: url_helper
INFO - 2021-07-16 08:41:27 --> Helper loaded: file_helper
INFO - 2021-07-16 08:41:27 --> Helper loaded: form_helper
INFO - 2021-07-16 08:41:27 --> Helper loaded: my_helper
INFO - 2021-07-16 08:41:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:41:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:41:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:41:27 --> Controller Class Initialized
DEBUG - 2021-07-16 08:41:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2021-07-16 08:41:28 --> Final output sent to browser
DEBUG - 2021-07-16 08:41:28 --> Total execution time: 0.2743
INFO - 2021-07-16 08:42:18 --> Config Class Initialized
INFO - 2021-07-16 08:42:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:42:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:42:18 --> Utf8 Class Initialized
INFO - 2021-07-16 08:42:18 --> URI Class Initialized
INFO - 2021-07-16 08:42:18 --> Router Class Initialized
INFO - 2021-07-16 08:42:18 --> Output Class Initialized
INFO - 2021-07-16 08:42:18 --> Security Class Initialized
DEBUG - 2021-07-16 08:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:42:18 --> Input Class Initialized
INFO - 2021-07-16 08:42:18 --> Language Class Initialized
INFO - 2021-07-16 08:42:18 --> Language Class Initialized
INFO - 2021-07-16 08:42:18 --> Config Class Initialized
INFO - 2021-07-16 08:42:18 --> Loader Class Initialized
INFO - 2021-07-16 08:42:18 --> Helper loaded: url_helper
INFO - 2021-07-16 08:42:18 --> Helper loaded: file_helper
INFO - 2021-07-16 08:42:18 --> Helper loaded: form_helper
INFO - 2021-07-16 08:42:18 --> Helper loaded: my_helper
INFO - 2021-07-16 08:42:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:42:18 --> Controller Class Initialized
DEBUG - 2021-07-16 08:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 08:42:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:42:18 --> Final output sent to browser
DEBUG - 2021-07-16 08:42:18 --> Total execution time: 0.0885
INFO - 2021-07-16 08:42:46 --> Config Class Initialized
INFO - 2021-07-16 08:42:46 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:42:46 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:42:46 --> Utf8 Class Initialized
INFO - 2021-07-16 08:42:46 --> URI Class Initialized
INFO - 2021-07-16 08:42:46 --> Router Class Initialized
INFO - 2021-07-16 08:42:46 --> Output Class Initialized
INFO - 2021-07-16 08:42:46 --> Security Class Initialized
DEBUG - 2021-07-16 08:42:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:42:46 --> Input Class Initialized
INFO - 2021-07-16 08:42:46 --> Language Class Initialized
INFO - 2021-07-16 08:42:46 --> Language Class Initialized
INFO - 2021-07-16 08:42:46 --> Config Class Initialized
INFO - 2021-07-16 08:42:46 --> Loader Class Initialized
INFO - 2021-07-16 08:42:46 --> Helper loaded: url_helper
INFO - 2021-07-16 08:42:46 --> Helper loaded: file_helper
INFO - 2021-07-16 08:42:46 --> Helper loaded: form_helper
INFO - 2021-07-16 08:42:46 --> Helper loaded: my_helper
INFO - 2021-07-16 08:42:46 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:42:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:42:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:42:46 --> Controller Class Initialized
DEBUG - 2021-07-16 08:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 08:42:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:42:46 --> Final output sent to browser
DEBUG - 2021-07-16 08:42:46 --> Total execution time: 0.0797
INFO - 2021-07-16 08:42:57 --> Config Class Initialized
INFO - 2021-07-16 08:42:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:42:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:42:57 --> Utf8 Class Initialized
INFO - 2021-07-16 08:42:57 --> URI Class Initialized
INFO - 2021-07-16 08:42:57 --> Router Class Initialized
INFO - 2021-07-16 08:42:57 --> Output Class Initialized
INFO - 2021-07-16 08:42:57 --> Security Class Initialized
DEBUG - 2021-07-16 08:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:42:57 --> Input Class Initialized
INFO - 2021-07-16 08:42:57 --> Language Class Initialized
INFO - 2021-07-16 08:42:57 --> Language Class Initialized
INFO - 2021-07-16 08:42:57 --> Config Class Initialized
INFO - 2021-07-16 08:42:57 --> Loader Class Initialized
INFO - 2021-07-16 08:42:57 --> Helper loaded: url_helper
INFO - 2021-07-16 08:42:57 --> Helper loaded: file_helper
INFO - 2021-07-16 08:42:57 --> Helper loaded: form_helper
INFO - 2021-07-16 08:42:57 --> Helper loaded: my_helper
INFO - 2021-07-16 08:42:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:42:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:42:57 --> Controller Class Initialized
DEBUG - 2021-07-16 08:42:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2021-07-16 08:42:57 --> Final output sent to browser
DEBUG - 2021-07-16 08:42:57 --> Total execution time: 0.2331
INFO - 2021-07-16 08:43:05 --> Config Class Initialized
INFO - 2021-07-16 08:43:05 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:43:05 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:43:05 --> Utf8 Class Initialized
INFO - 2021-07-16 08:43:05 --> URI Class Initialized
INFO - 2021-07-16 08:43:05 --> Router Class Initialized
INFO - 2021-07-16 08:43:05 --> Output Class Initialized
INFO - 2021-07-16 08:43:05 --> Security Class Initialized
DEBUG - 2021-07-16 08:43:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:43:05 --> Input Class Initialized
INFO - 2021-07-16 08:43:05 --> Language Class Initialized
INFO - 2021-07-16 08:43:05 --> Language Class Initialized
INFO - 2021-07-16 08:43:05 --> Config Class Initialized
INFO - 2021-07-16 08:43:05 --> Loader Class Initialized
INFO - 2021-07-16 08:43:05 --> Helper loaded: url_helper
INFO - 2021-07-16 08:43:05 --> Helper loaded: file_helper
INFO - 2021-07-16 08:43:05 --> Helper loaded: form_helper
INFO - 2021-07-16 08:43:05 --> Helper loaded: my_helper
INFO - 2021-07-16 08:43:05 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:43:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:43:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:43:05 --> Controller Class Initialized
DEBUG - 2021-07-16 08:43:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-16 08:43:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:43:05 --> Final output sent to browser
DEBUG - 2021-07-16 08:43:05 --> Total execution time: 0.0794
INFO - 2021-07-16 08:43:13 --> Config Class Initialized
INFO - 2021-07-16 08:43:13 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:43:13 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:43:13 --> Utf8 Class Initialized
INFO - 2021-07-16 08:43:13 --> URI Class Initialized
INFO - 2021-07-16 08:43:13 --> Router Class Initialized
INFO - 2021-07-16 08:43:13 --> Output Class Initialized
INFO - 2021-07-16 08:43:13 --> Security Class Initialized
DEBUG - 2021-07-16 08:43:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:43:13 --> Input Class Initialized
INFO - 2021-07-16 08:43:13 --> Language Class Initialized
INFO - 2021-07-16 08:43:13 --> Language Class Initialized
INFO - 2021-07-16 08:43:13 --> Config Class Initialized
INFO - 2021-07-16 08:43:14 --> Loader Class Initialized
INFO - 2021-07-16 08:43:14 --> Helper loaded: url_helper
INFO - 2021-07-16 08:43:14 --> Helper loaded: file_helper
INFO - 2021-07-16 08:43:14 --> Helper loaded: form_helper
INFO - 2021-07-16 08:43:14 --> Helper loaded: my_helper
INFO - 2021-07-16 08:43:14 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:43:14 --> Controller Class Initialized
DEBUG - 2021-07-16 08:43:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xii.php
INFO - 2021-07-16 08:43:14 --> Final output sent to browser
DEBUG - 2021-07-16 08:43:14 --> Total execution time: 0.1868
INFO - 2021-07-16 08:44:17 --> Config Class Initialized
INFO - 2021-07-16 08:44:17 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:44:17 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:44:17 --> Utf8 Class Initialized
INFO - 2021-07-16 08:44:17 --> URI Class Initialized
INFO - 2021-07-16 08:44:17 --> Router Class Initialized
INFO - 2021-07-16 08:44:17 --> Output Class Initialized
INFO - 2021-07-16 08:44:17 --> Security Class Initialized
DEBUG - 2021-07-16 08:44:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:44:17 --> Input Class Initialized
INFO - 2021-07-16 08:44:17 --> Language Class Initialized
INFO - 2021-07-16 08:44:17 --> Language Class Initialized
INFO - 2021-07-16 08:44:17 --> Config Class Initialized
INFO - 2021-07-16 08:44:17 --> Loader Class Initialized
INFO - 2021-07-16 08:44:17 --> Helper loaded: url_helper
INFO - 2021-07-16 08:44:17 --> Helper loaded: file_helper
INFO - 2021-07-16 08:44:17 --> Helper loaded: form_helper
INFO - 2021-07-16 08:44:17 --> Helper loaded: my_helper
INFO - 2021-07-16 08:44:17 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:44:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:44:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:44:17 --> Controller Class Initialized
DEBUG - 2021-07-16 08:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 08:44:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:44:17 --> Final output sent to browser
DEBUG - 2021-07-16 08:44:17 --> Total execution time: 0.0716
INFO - 2021-07-16 08:49:30 --> Config Class Initialized
INFO - 2021-07-16 08:49:30 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:49:30 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:49:30 --> Utf8 Class Initialized
INFO - 2021-07-16 08:49:30 --> URI Class Initialized
INFO - 2021-07-16 08:49:30 --> Router Class Initialized
INFO - 2021-07-16 08:49:30 --> Output Class Initialized
INFO - 2021-07-16 08:49:30 --> Security Class Initialized
DEBUG - 2021-07-16 08:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:49:30 --> Input Class Initialized
INFO - 2021-07-16 08:49:30 --> Language Class Initialized
INFO - 2021-07-16 08:49:30 --> Language Class Initialized
INFO - 2021-07-16 08:49:30 --> Config Class Initialized
INFO - 2021-07-16 08:49:30 --> Loader Class Initialized
INFO - 2021-07-16 08:49:30 --> Helper loaded: url_helper
INFO - 2021-07-16 08:49:30 --> Helper loaded: file_helper
INFO - 2021-07-16 08:49:30 --> Helper loaded: form_helper
INFO - 2021-07-16 08:49:30 --> Helper loaded: my_helper
INFO - 2021-07-16 08:49:30 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:49:30 --> Controller Class Initialized
DEBUG - 2021-07-16 08:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 08:49:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:49:30 --> Final output sent to browser
DEBUG - 2021-07-16 08:49:30 --> Total execution time: 0.0597
INFO - 2021-07-16 08:49:32 --> Config Class Initialized
INFO - 2021-07-16 08:49:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:49:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:49:32 --> Utf8 Class Initialized
INFO - 2021-07-16 08:49:32 --> URI Class Initialized
INFO - 2021-07-16 08:49:32 --> Router Class Initialized
INFO - 2021-07-16 08:49:32 --> Output Class Initialized
INFO - 2021-07-16 08:49:32 --> Security Class Initialized
DEBUG - 2021-07-16 08:49:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:49:32 --> Input Class Initialized
INFO - 2021-07-16 08:49:32 --> Language Class Initialized
INFO - 2021-07-16 08:49:32 --> Language Class Initialized
INFO - 2021-07-16 08:49:32 --> Config Class Initialized
INFO - 2021-07-16 08:49:32 --> Loader Class Initialized
INFO - 2021-07-16 08:49:32 --> Helper loaded: url_helper
INFO - 2021-07-16 08:49:32 --> Helper loaded: file_helper
INFO - 2021-07-16 08:49:32 --> Helper loaded: form_helper
INFO - 2021-07-16 08:49:32 --> Helper loaded: my_helper
INFO - 2021-07-16 08:49:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:49:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:49:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:49:32 --> Controller Class Initialized
DEBUG - 2021-07-16 08:49:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2021-07-16 08:49:32 --> Final output sent to browser
DEBUG - 2021-07-16 08:49:32 --> Total execution time: 0.2332
INFO - 2021-07-16 08:51:09 --> Config Class Initialized
INFO - 2021-07-16 08:51:09 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:51:09 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:51:09 --> Utf8 Class Initialized
INFO - 2021-07-16 08:51:09 --> URI Class Initialized
INFO - 2021-07-16 08:51:09 --> Router Class Initialized
INFO - 2021-07-16 08:51:09 --> Output Class Initialized
INFO - 2021-07-16 08:51:09 --> Security Class Initialized
DEBUG - 2021-07-16 08:51:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:51:09 --> Input Class Initialized
INFO - 2021-07-16 08:51:09 --> Language Class Initialized
INFO - 2021-07-16 08:51:09 --> Language Class Initialized
INFO - 2021-07-16 08:51:09 --> Config Class Initialized
INFO - 2021-07-16 08:51:09 --> Loader Class Initialized
INFO - 2021-07-16 08:51:09 --> Helper loaded: url_helper
INFO - 2021-07-16 08:51:09 --> Helper loaded: file_helper
INFO - 2021-07-16 08:51:09 --> Helper loaded: form_helper
INFO - 2021-07-16 08:51:09 --> Helper loaded: my_helper
INFO - 2021-07-16 08:51:09 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:51:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:51:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:51:09 --> Controller Class Initialized
DEBUG - 2021-07-16 08:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 08:51:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:51:09 --> Final output sent to browser
DEBUG - 2021-07-16 08:51:09 --> Total execution time: 0.0598
INFO - 2021-07-16 08:59:18 --> Config Class Initialized
INFO - 2021-07-16 08:59:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:59:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:59:18 --> Utf8 Class Initialized
INFO - 2021-07-16 08:59:18 --> URI Class Initialized
INFO - 2021-07-16 08:59:18 --> Router Class Initialized
INFO - 2021-07-16 08:59:18 --> Output Class Initialized
INFO - 2021-07-16 08:59:18 --> Security Class Initialized
DEBUG - 2021-07-16 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:59:18 --> Input Class Initialized
INFO - 2021-07-16 08:59:18 --> Language Class Initialized
INFO - 2021-07-16 08:59:18 --> Language Class Initialized
INFO - 2021-07-16 08:59:18 --> Config Class Initialized
INFO - 2021-07-16 08:59:18 --> Loader Class Initialized
INFO - 2021-07-16 08:59:18 --> Helper loaded: url_helper
INFO - 2021-07-16 08:59:18 --> Helper loaded: file_helper
INFO - 2021-07-16 08:59:18 --> Helper loaded: form_helper
INFO - 2021-07-16 08:59:18 --> Helper loaded: my_helper
INFO - 2021-07-16 08:59:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:59:18 --> Controller Class Initialized
INFO - 2021-07-16 08:59:18 --> Helper loaded: cookie_helper
INFO - 2021-07-16 08:59:18 --> Config Class Initialized
INFO - 2021-07-16 08:59:18 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:59:18 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:59:18 --> Utf8 Class Initialized
INFO - 2021-07-16 08:59:18 --> URI Class Initialized
INFO - 2021-07-16 08:59:18 --> Router Class Initialized
INFO - 2021-07-16 08:59:18 --> Output Class Initialized
INFO - 2021-07-16 08:59:18 --> Security Class Initialized
DEBUG - 2021-07-16 08:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:59:18 --> Input Class Initialized
INFO - 2021-07-16 08:59:18 --> Language Class Initialized
INFO - 2021-07-16 08:59:18 --> Language Class Initialized
INFO - 2021-07-16 08:59:18 --> Config Class Initialized
INFO - 2021-07-16 08:59:18 --> Loader Class Initialized
INFO - 2021-07-16 08:59:18 --> Helper loaded: url_helper
INFO - 2021-07-16 08:59:18 --> Helper loaded: file_helper
INFO - 2021-07-16 08:59:18 --> Helper loaded: form_helper
INFO - 2021-07-16 08:59:18 --> Helper loaded: my_helper
INFO - 2021-07-16 08:59:18 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:59:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:59:18 --> Controller Class Initialized
DEBUG - 2021-07-16 08:59:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 08:59:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 08:59:18 --> Final output sent to browser
DEBUG - 2021-07-16 08:59:18 --> Total execution time: 0.0644
INFO - 2021-07-16 08:59:35 --> Config Class Initialized
INFO - 2021-07-16 08:59:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 08:59:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 08:59:35 --> Utf8 Class Initialized
INFO - 2021-07-16 08:59:35 --> URI Class Initialized
INFO - 2021-07-16 08:59:35 --> Router Class Initialized
INFO - 2021-07-16 08:59:35 --> Output Class Initialized
INFO - 2021-07-16 08:59:35 --> Security Class Initialized
DEBUG - 2021-07-16 08:59:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 08:59:35 --> Input Class Initialized
INFO - 2021-07-16 08:59:35 --> Language Class Initialized
INFO - 2021-07-16 08:59:35 --> Language Class Initialized
INFO - 2021-07-16 08:59:35 --> Config Class Initialized
INFO - 2021-07-16 08:59:35 --> Loader Class Initialized
INFO - 2021-07-16 08:59:35 --> Helper loaded: url_helper
INFO - 2021-07-16 08:59:35 --> Helper loaded: file_helper
INFO - 2021-07-16 08:59:35 --> Helper loaded: form_helper
INFO - 2021-07-16 08:59:35 --> Helper loaded: my_helper
INFO - 2021-07-16 08:59:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 08:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 08:59:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 08:59:35 --> Controller Class Initialized
INFO - 2021-07-16 08:59:35 --> Helper loaded: cookie_helper
INFO - 2021-07-16 08:59:35 --> Final output sent to browser
DEBUG - 2021-07-16 08:59:35 --> Total execution time: 0.0599
INFO - 2021-07-16 09:00:01 --> Config Class Initialized
INFO - 2021-07-16 09:00:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:00:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:00:01 --> Utf8 Class Initialized
INFO - 2021-07-16 09:00:01 --> URI Class Initialized
INFO - 2021-07-16 09:00:01 --> Router Class Initialized
INFO - 2021-07-16 09:00:01 --> Output Class Initialized
INFO - 2021-07-16 09:00:01 --> Security Class Initialized
DEBUG - 2021-07-16 09:00:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:00:01 --> Input Class Initialized
INFO - 2021-07-16 09:00:01 --> Language Class Initialized
INFO - 2021-07-16 09:00:01 --> Language Class Initialized
INFO - 2021-07-16 09:00:01 --> Config Class Initialized
INFO - 2021-07-16 09:00:01 --> Loader Class Initialized
INFO - 2021-07-16 09:00:01 --> Helper loaded: url_helper
INFO - 2021-07-16 09:00:01 --> Helper loaded: file_helper
INFO - 2021-07-16 09:00:01 --> Helper loaded: form_helper
INFO - 2021-07-16 09:00:01 --> Helper loaded: my_helper
INFO - 2021-07-16 09:00:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:00:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:00:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:00:01 --> Controller Class Initialized
DEBUG - 2021-07-16 09:00:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:00:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:00:02 --> Final output sent to browser
DEBUG - 2021-07-16 09:00:02 --> Total execution time: 0.7166
INFO - 2021-07-16 09:00:04 --> Config Class Initialized
INFO - 2021-07-16 09:00:04 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:00:04 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:00:04 --> Utf8 Class Initialized
INFO - 2021-07-16 09:00:04 --> URI Class Initialized
INFO - 2021-07-16 09:00:04 --> Router Class Initialized
INFO - 2021-07-16 09:00:04 --> Output Class Initialized
INFO - 2021-07-16 09:00:04 --> Security Class Initialized
DEBUG - 2021-07-16 09:00:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:00:04 --> Input Class Initialized
INFO - 2021-07-16 09:00:04 --> Language Class Initialized
INFO - 2021-07-16 09:00:04 --> Language Class Initialized
INFO - 2021-07-16 09:00:04 --> Config Class Initialized
INFO - 2021-07-16 09:00:04 --> Loader Class Initialized
INFO - 2021-07-16 09:00:04 --> Helper loaded: url_helper
INFO - 2021-07-16 09:00:04 --> Helper loaded: file_helper
INFO - 2021-07-16 09:00:04 --> Helper loaded: form_helper
INFO - 2021-07-16 09:00:04 --> Helper loaded: my_helper
INFO - 2021-07-16 09:00:04 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:00:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:00:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:00:04 --> Controller Class Initialized
DEBUG - 2021-07-16 09:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-16 09:00:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:00:04 --> Final output sent to browser
DEBUG - 2021-07-16 09:00:04 --> Total execution time: 0.0642
INFO - 2021-07-16 09:00:11 --> Config Class Initialized
INFO - 2021-07-16 09:00:11 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:00:11 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:00:11 --> Utf8 Class Initialized
INFO - 2021-07-16 09:00:11 --> URI Class Initialized
INFO - 2021-07-16 09:00:11 --> Router Class Initialized
INFO - 2021-07-16 09:00:11 --> Output Class Initialized
INFO - 2021-07-16 09:00:11 --> Security Class Initialized
DEBUG - 2021-07-16 09:00:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:00:11 --> Input Class Initialized
INFO - 2021-07-16 09:00:11 --> Language Class Initialized
INFO - 2021-07-16 09:00:11 --> Language Class Initialized
INFO - 2021-07-16 09:00:11 --> Config Class Initialized
INFO - 2021-07-16 09:00:11 --> Loader Class Initialized
INFO - 2021-07-16 09:00:11 --> Helper loaded: url_helper
INFO - 2021-07-16 09:00:11 --> Helper loaded: file_helper
INFO - 2021-07-16 09:00:11 --> Helper loaded: form_helper
INFO - 2021-07-16 09:00:11 --> Helper loaded: my_helper
INFO - 2021-07-16 09:00:11 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:00:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:00:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:00:11 --> Controller Class Initialized
DEBUG - 2021-07-16 09:00:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:00:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:00:11 --> Final output sent to browser
DEBUG - 2021-07-16 09:00:11 --> Total execution time: 0.0787
INFO - 2021-07-16 09:05:35 --> Config Class Initialized
INFO - 2021-07-16 09:05:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:05:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:05:35 --> Utf8 Class Initialized
INFO - 2021-07-16 09:05:35 --> URI Class Initialized
INFO - 2021-07-16 09:05:35 --> Router Class Initialized
INFO - 2021-07-16 09:05:35 --> Output Class Initialized
INFO - 2021-07-16 09:05:35 --> Security Class Initialized
DEBUG - 2021-07-16 09:05:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:05:35 --> Input Class Initialized
INFO - 2021-07-16 09:05:35 --> Language Class Initialized
INFO - 2021-07-16 09:05:35 --> Language Class Initialized
INFO - 2021-07-16 09:05:35 --> Config Class Initialized
INFO - 2021-07-16 09:05:35 --> Loader Class Initialized
INFO - 2021-07-16 09:05:35 --> Helper loaded: url_helper
INFO - 2021-07-16 09:05:35 --> Helper loaded: file_helper
INFO - 2021-07-16 09:05:35 --> Helper loaded: form_helper
INFO - 2021-07-16 09:05:35 --> Helper loaded: my_helper
INFO - 2021-07-16 09:05:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:05:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:05:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:05:35 --> Controller Class Initialized
INFO - 2021-07-16 09:05:35 --> Final output sent to browser
DEBUG - 2021-07-16 09:05:35 --> Total execution time: 0.1064
INFO - 2021-07-16 09:08:28 --> Config Class Initialized
INFO - 2021-07-16 09:08:28 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:08:28 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:08:28 --> Utf8 Class Initialized
INFO - 2021-07-16 09:08:28 --> URI Class Initialized
INFO - 2021-07-16 09:08:28 --> Router Class Initialized
INFO - 2021-07-16 09:08:28 --> Output Class Initialized
INFO - 2021-07-16 09:08:28 --> Security Class Initialized
DEBUG - 2021-07-16 09:08:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:08:28 --> Input Class Initialized
INFO - 2021-07-16 09:08:28 --> Language Class Initialized
INFO - 2021-07-16 09:08:28 --> Language Class Initialized
INFO - 2021-07-16 09:08:28 --> Config Class Initialized
INFO - 2021-07-16 09:08:28 --> Loader Class Initialized
INFO - 2021-07-16 09:08:28 --> Helper loaded: url_helper
INFO - 2021-07-16 09:08:28 --> Helper loaded: file_helper
INFO - 2021-07-16 09:08:28 --> Helper loaded: form_helper
INFO - 2021-07-16 09:08:28 --> Helper loaded: my_helper
INFO - 2021-07-16 09:08:28 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:08:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:08:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:08:28 --> Controller Class Initialized
DEBUG - 2021-07-16 09:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 09:08:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:08:28 --> Final output sent to browser
DEBUG - 2021-07-16 09:08:28 --> Total execution time: 0.0726
INFO - 2021-07-16 09:08:32 --> Config Class Initialized
INFO - 2021-07-16 09:08:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:08:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:08:32 --> Utf8 Class Initialized
INFO - 2021-07-16 09:08:32 --> URI Class Initialized
INFO - 2021-07-16 09:08:32 --> Router Class Initialized
INFO - 2021-07-16 09:08:32 --> Output Class Initialized
INFO - 2021-07-16 09:08:32 --> Security Class Initialized
DEBUG - 2021-07-16 09:08:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:08:32 --> Input Class Initialized
INFO - 2021-07-16 09:08:32 --> Language Class Initialized
INFO - 2021-07-16 09:08:32 --> Language Class Initialized
INFO - 2021-07-16 09:08:32 --> Config Class Initialized
INFO - 2021-07-16 09:08:32 --> Loader Class Initialized
INFO - 2021-07-16 09:08:32 --> Helper loaded: url_helper
INFO - 2021-07-16 09:08:32 --> Helper loaded: file_helper
INFO - 2021-07-16 09:08:32 --> Helper loaded: form_helper
INFO - 2021-07-16 09:08:32 --> Helper loaded: my_helper
INFO - 2021-07-16 09:08:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:08:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:08:32 --> Controller Class Initialized
DEBUG - 2021-07-16 09:08:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xii.php
INFO - 2021-07-16 09:08:32 --> Final output sent to browser
DEBUG - 2021-07-16 09:08:32 --> Total execution time: 0.2795
INFO - 2021-07-16 09:10:31 --> Config Class Initialized
INFO - 2021-07-16 09:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:10:31 --> Utf8 Class Initialized
INFO - 2021-07-16 09:10:31 --> URI Class Initialized
INFO - 2021-07-16 09:10:31 --> Router Class Initialized
INFO - 2021-07-16 09:10:31 --> Output Class Initialized
INFO - 2021-07-16 09:10:31 --> Security Class Initialized
DEBUG - 2021-07-16 09:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:10:31 --> Input Class Initialized
INFO - 2021-07-16 09:10:31 --> Language Class Initialized
INFO - 2021-07-16 09:10:31 --> Language Class Initialized
INFO - 2021-07-16 09:10:31 --> Config Class Initialized
INFO - 2021-07-16 09:10:31 --> Loader Class Initialized
INFO - 2021-07-16 09:10:31 --> Helper loaded: url_helper
INFO - 2021-07-16 09:10:31 --> Helper loaded: file_helper
INFO - 2021-07-16 09:10:31 --> Helper loaded: form_helper
INFO - 2021-07-16 09:10:31 --> Helper loaded: my_helper
INFO - 2021-07-16 09:10:31 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:10:31 --> Controller Class Initialized
INFO - 2021-07-16 09:10:31 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:10:31 --> Config Class Initialized
INFO - 2021-07-16 09:10:31 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:10:31 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:10:31 --> Utf8 Class Initialized
INFO - 2021-07-16 09:10:31 --> URI Class Initialized
INFO - 2021-07-16 09:10:31 --> Router Class Initialized
INFO - 2021-07-16 09:10:31 --> Output Class Initialized
INFO - 2021-07-16 09:10:31 --> Security Class Initialized
DEBUG - 2021-07-16 09:10:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:10:31 --> Input Class Initialized
INFO - 2021-07-16 09:10:31 --> Language Class Initialized
INFO - 2021-07-16 09:10:31 --> Language Class Initialized
INFO - 2021-07-16 09:10:31 --> Config Class Initialized
INFO - 2021-07-16 09:10:31 --> Loader Class Initialized
INFO - 2021-07-16 09:10:31 --> Helper loaded: url_helper
INFO - 2021-07-16 09:10:31 --> Helper loaded: file_helper
INFO - 2021-07-16 09:10:31 --> Helper loaded: form_helper
INFO - 2021-07-16 09:10:31 --> Helper loaded: my_helper
INFO - 2021-07-16 09:10:31 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:10:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:10:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:10:31 --> Controller Class Initialized
DEBUG - 2021-07-16 09:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 09:10:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:10:31 --> Final output sent to browser
DEBUG - 2021-07-16 09:10:31 --> Total execution time: 0.0537
INFO - 2021-07-16 09:10:58 --> Config Class Initialized
INFO - 2021-07-16 09:10:58 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:10:58 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:10:58 --> Utf8 Class Initialized
INFO - 2021-07-16 09:10:58 --> URI Class Initialized
INFO - 2021-07-16 09:10:58 --> Router Class Initialized
INFO - 2021-07-16 09:10:58 --> Output Class Initialized
INFO - 2021-07-16 09:10:58 --> Security Class Initialized
DEBUG - 2021-07-16 09:10:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:10:58 --> Input Class Initialized
INFO - 2021-07-16 09:10:58 --> Language Class Initialized
INFO - 2021-07-16 09:10:58 --> Language Class Initialized
INFO - 2021-07-16 09:10:58 --> Config Class Initialized
INFO - 2021-07-16 09:10:58 --> Loader Class Initialized
INFO - 2021-07-16 09:10:58 --> Helper loaded: url_helper
INFO - 2021-07-16 09:10:58 --> Helper loaded: file_helper
INFO - 2021-07-16 09:10:58 --> Helper loaded: form_helper
INFO - 2021-07-16 09:10:58 --> Helper loaded: my_helper
INFO - 2021-07-16 09:10:58 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:10:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:10:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:10:58 --> Controller Class Initialized
INFO - 2021-07-16 09:10:58 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:10:58 --> Final output sent to browser
DEBUG - 2021-07-16 09:10:58 --> Total execution time: 0.0671
INFO - 2021-07-16 09:11:00 --> Config Class Initialized
INFO - 2021-07-16 09:11:00 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:11:00 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:11:00 --> Utf8 Class Initialized
INFO - 2021-07-16 09:11:00 --> URI Class Initialized
INFO - 2021-07-16 09:11:00 --> Router Class Initialized
INFO - 2021-07-16 09:11:00 --> Output Class Initialized
INFO - 2021-07-16 09:11:01 --> Security Class Initialized
DEBUG - 2021-07-16 09:11:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:11:01 --> Input Class Initialized
INFO - 2021-07-16 09:11:01 --> Language Class Initialized
INFO - 2021-07-16 09:11:01 --> Language Class Initialized
INFO - 2021-07-16 09:11:01 --> Config Class Initialized
INFO - 2021-07-16 09:11:01 --> Loader Class Initialized
INFO - 2021-07-16 09:11:01 --> Helper loaded: url_helper
INFO - 2021-07-16 09:11:01 --> Helper loaded: file_helper
INFO - 2021-07-16 09:11:01 --> Helper loaded: form_helper
INFO - 2021-07-16 09:11:01 --> Helper loaded: my_helper
INFO - 2021-07-16 09:11:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:11:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:11:01 --> Controller Class Initialized
DEBUG - 2021-07-16 09:11:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:11:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:11:01 --> Final output sent to browser
DEBUG - 2021-07-16 09:11:01 --> Total execution time: 0.7067
INFO - 2021-07-16 09:11:05 --> Config Class Initialized
INFO - 2021-07-16 09:11:05 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:11:05 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:11:05 --> Utf8 Class Initialized
INFO - 2021-07-16 09:11:05 --> URI Class Initialized
INFO - 2021-07-16 09:11:05 --> Router Class Initialized
INFO - 2021-07-16 09:11:05 --> Output Class Initialized
INFO - 2021-07-16 09:11:05 --> Security Class Initialized
DEBUG - 2021-07-16 09:11:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:11:05 --> Input Class Initialized
INFO - 2021-07-16 09:11:05 --> Language Class Initialized
INFO - 2021-07-16 09:11:05 --> Language Class Initialized
INFO - 2021-07-16 09:11:05 --> Config Class Initialized
INFO - 2021-07-16 09:11:05 --> Loader Class Initialized
INFO - 2021-07-16 09:11:05 --> Helper loaded: url_helper
INFO - 2021-07-16 09:11:05 --> Helper loaded: file_helper
INFO - 2021-07-16 09:11:05 --> Helper loaded: form_helper
INFO - 2021-07-16 09:11:05 --> Helper loaded: my_helper
INFO - 2021-07-16 09:11:05 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:11:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:11:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:11:05 --> Controller Class Initialized
DEBUG - 2021-07-16 09:11:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:11:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:11:05 --> Final output sent to browser
DEBUG - 2021-07-16 09:11:05 --> Total execution time: 0.0745
INFO - 2021-07-16 09:12:52 --> Config Class Initialized
INFO - 2021-07-16 09:12:52 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:12:52 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:12:52 --> Utf8 Class Initialized
INFO - 2021-07-16 09:12:52 --> URI Class Initialized
INFO - 2021-07-16 09:12:52 --> Router Class Initialized
INFO - 2021-07-16 09:12:52 --> Output Class Initialized
INFO - 2021-07-16 09:12:52 --> Security Class Initialized
DEBUG - 2021-07-16 09:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:12:52 --> Input Class Initialized
INFO - 2021-07-16 09:12:52 --> Language Class Initialized
INFO - 2021-07-16 09:12:52 --> Language Class Initialized
INFO - 2021-07-16 09:12:52 --> Config Class Initialized
INFO - 2021-07-16 09:12:52 --> Loader Class Initialized
INFO - 2021-07-16 09:12:52 --> Helper loaded: url_helper
INFO - 2021-07-16 09:12:52 --> Helper loaded: file_helper
INFO - 2021-07-16 09:12:52 --> Helper loaded: form_helper
INFO - 2021-07-16 09:12:52 --> Helper loaded: my_helper
INFO - 2021-07-16 09:12:52 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:12:52 --> Controller Class Initialized
INFO - 2021-07-16 09:12:52 --> Final output sent to browser
DEBUG - 2021-07-16 09:12:52 --> Total execution time: 0.1109
INFO - 2021-07-16 09:14:47 --> Config Class Initialized
INFO - 2021-07-16 09:14:47 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:14:47 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:14:47 --> Utf8 Class Initialized
INFO - 2021-07-16 09:14:47 --> URI Class Initialized
INFO - 2021-07-16 09:14:47 --> Router Class Initialized
INFO - 2021-07-16 09:14:47 --> Output Class Initialized
INFO - 2021-07-16 09:14:47 --> Security Class Initialized
DEBUG - 2021-07-16 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:14:47 --> Input Class Initialized
INFO - 2021-07-16 09:14:47 --> Language Class Initialized
INFO - 2021-07-16 09:14:47 --> Language Class Initialized
INFO - 2021-07-16 09:14:47 --> Config Class Initialized
INFO - 2021-07-16 09:14:47 --> Loader Class Initialized
INFO - 2021-07-16 09:14:47 --> Helper loaded: url_helper
INFO - 2021-07-16 09:14:47 --> Helper loaded: file_helper
INFO - 2021-07-16 09:14:47 --> Helper loaded: form_helper
INFO - 2021-07-16 09:14:47 --> Helper loaded: my_helper
INFO - 2021-07-16 09:14:47 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:14:47 --> Controller Class Initialized
INFO - 2021-07-16 09:14:47 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:14:47 --> Config Class Initialized
INFO - 2021-07-16 09:14:47 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:14:47 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:14:47 --> Utf8 Class Initialized
INFO - 2021-07-16 09:14:47 --> URI Class Initialized
INFO - 2021-07-16 09:14:47 --> Router Class Initialized
INFO - 2021-07-16 09:14:47 --> Output Class Initialized
INFO - 2021-07-16 09:14:47 --> Security Class Initialized
DEBUG - 2021-07-16 09:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:14:47 --> Input Class Initialized
INFO - 2021-07-16 09:14:47 --> Language Class Initialized
INFO - 2021-07-16 09:14:47 --> Language Class Initialized
INFO - 2021-07-16 09:14:47 --> Config Class Initialized
INFO - 2021-07-16 09:14:47 --> Loader Class Initialized
INFO - 2021-07-16 09:14:47 --> Helper loaded: url_helper
INFO - 2021-07-16 09:14:47 --> Helper loaded: file_helper
INFO - 2021-07-16 09:14:47 --> Helper loaded: form_helper
INFO - 2021-07-16 09:14:47 --> Helper loaded: my_helper
INFO - 2021-07-16 09:14:47 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:14:47 --> Controller Class Initialized
DEBUG - 2021-07-16 09:14:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 09:14:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:14:47 --> Final output sent to browser
DEBUG - 2021-07-16 09:14:47 --> Total execution time: 0.0446
INFO - 2021-07-16 09:16:15 --> Config Class Initialized
INFO - 2021-07-16 09:16:15 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:16:15 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:16:15 --> Utf8 Class Initialized
INFO - 2021-07-16 09:16:15 --> URI Class Initialized
INFO - 2021-07-16 09:16:15 --> Router Class Initialized
INFO - 2021-07-16 09:16:15 --> Output Class Initialized
INFO - 2021-07-16 09:16:15 --> Security Class Initialized
DEBUG - 2021-07-16 09:16:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:16:15 --> Input Class Initialized
INFO - 2021-07-16 09:16:15 --> Language Class Initialized
INFO - 2021-07-16 09:16:15 --> Language Class Initialized
INFO - 2021-07-16 09:16:15 --> Config Class Initialized
INFO - 2021-07-16 09:16:15 --> Loader Class Initialized
INFO - 2021-07-16 09:16:15 --> Helper loaded: url_helper
INFO - 2021-07-16 09:16:15 --> Helper loaded: file_helper
INFO - 2021-07-16 09:16:15 --> Helper loaded: form_helper
INFO - 2021-07-16 09:16:15 --> Helper loaded: my_helper
INFO - 2021-07-16 09:16:15 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:16:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:16:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:16:15 --> Controller Class Initialized
INFO - 2021-07-16 09:16:15 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:16:15 --> Final output sent to browser
DEBUG - 2021-07-16 09:16:15 --> Total execution time: 0.0720
INFO - 2021-07-16 09:16:17 --> Config Class Initialized
INFO - 2021-07-16 09:16:17 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:16:17 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:16:17 --> Utf8 Class Initialized
INFO - 2021-07-16 09:16:17 --> URI Class Initialized
INFO - 2021-07-16 09:16:17 --> Router Class Initialized
INFO - 2021-07-16 09:16:17 --> Output Class Initialized
INFO - 2021-07-16 09:16:17 --> Security Class Initialized
DEBUG - 2021-07-16 09:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:16:17 --> Input Class Initialized
INFO - 2021-07-16 09:16:17 --> Language Class Initialized
INFO - 2021-07-16 09:16:17 --> Language Class Initialized
INFO - 2021-07-16 09:16:17 --> Config Class Initialized
INFO - 2021-07-16 09:16:17 --> Loader Class Initialized
INFO - 2021-07-16 09:16:17 --> Helper loaded: url_helper
INFO - 2021-07-16 09:16:17 --> Helper loaded: file_helper
INFO - 2021-07-16 09:16:17 --> Helper loaded: form_helper
INFO - 2021-07-16 09:16:17 --> Helper loaded: my_helper
INFO - 2021-07-16 09:16:17 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:16:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:16:17 --> Controller Class Initialized
DEBUG - 2021-07-16 09:16:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:16:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:16:17 --> Final output sent to browser
DEBUG - 2021-07-16 09:16:17 --> Total execution time: 0.7108
INFO - 2021-07-16 09:16:20 --> Config Class Initialized
INFO - 2021-07-16 09:16:20 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:16:20 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:16:20 --> Utf8 Class Initialized
INFO - 2021-07-16 09:16:20 --> URI Class Initialized
INFO - 2021-07-16 09:16:20 --> Router Class Initialized
INFO - 2021-07-16 09:16:20 --> Output Class Initialized
INFO - 2021-07-16 09:16:20 --> Security Class Initialized
DEBUG - 2021-07-16 09:16:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:16:20 --> Input Class Initialized
INFO - 2021-07-16 09:16:20 --> Language Class Initialized
INFO - 2021-07-16 09:16:20 --> Language Class Initialized
INFO - 2021-07-16 09:16:20 --> Config Class Initialized
INFO - 2021-07-16 09:16:20 --> Loader Class Initialized
INFO - 2021-07-16 09:16:20 --> Helper loaded: url_helper
INFO - 2021-07-16 09:16:20 --> Helper loaded: file_helper
INFO - 2021-07-16 09:16:20 --> Helper loaded: form_helper
INFO - 2021-07-16 09:16:20 --> Helper loaded: my_helper
INFO - 2021-07-16 09:16:20 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:16:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:16:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:16:20 --> Controller Class Initialized
DEBUG - 2021-07-16 09:16:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:16:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:16:20 --> Final output sent to browser
DEBUG - 2021-07-16 09:16:20 --> Total execution time: 0.0808
INFO - 2021-07-16 09:17:06 --> Config Class Initialized
INFO - 2021-07-16 09:17:06 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:17:06 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:17:06 --> Utf8 Class Initialized
INFO - 2021-07-16 09:17:06 --> URI Class Initialized
INFO - 2021-07-16 09:17:06 --> Router Class Initialized
INFO - 2021-07-16 09:17:06 --> Output Class Initialized
INFO - 2021-07-16 09:17:06 --> Security Class Initialized
DEBUG - 2021-07-16 09:17:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:17:06 --> Input Class Initialized
INFO - 2021-07-16 09:17:06 --> Language Class Initialized
INFO - 2021-07-16 09:17:06 --> Language Class Initialized
INFO - 2021-07-16 09:17:06 --> Config Class Initialized
INFO - 2021-07-16 09:17:06 --> Loader Class Initialized
INFO - 2021-07-16 09:17:06 --> Helper loaded: url_helper
INFO - 2021-07-16 09:17:06 --> Helper loaded: file_helper
INFO - 2021-07-16 09:17:06 --> Helper loaded: form_helper
INFO - 2021-07-16 09:17:06 --> Helper loaded: my_helper
INFO - 2021-07-16 09:17:06 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:17:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:17:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:17:06 --> Controller Class Initialized
DEBUG - 2021-07-16 09:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:17:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:17:06 --> Final output sent to browser
DEBUG - 2021-07-16 09:17:06 --> Total execution time: 0.0750
INFO - 2021-07-16 09:17:49 --> Config Class Initialized
INFO - 2021-07-16 09:17:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:17:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:17:49 --> Utf8 Class Initialized
INFO - 2021-07-16 09:17:49 --> URI Class Initialized
INFO - 2021-07-16 09:17:49 --> Router Class Initialized
INFO - 2021-07-16 09:17:49 --> Output Class Initialized
INFO - 2021-07-16 09:17:49 --> Security Class Initialized
DEBUG - 2021-07-16 09:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:17:49 --> Input Class Initialized
INFO - 2021-07-16 09:17:49 --> Language Class Initialized
INFO - 2021-07-16 09:17:49 --> Language Class Initialized
INFO - 2021-07-16 09:17:49 --> Config Class Initialized
INFO - 2021-07-16 09:17:49 --> Loader Class Initialized
INFO - 2021-07-16 09:17:49 --> Helper loaded: url_helper
INFO - 2021-07-16 09:17:49 --> Helper loaded: file_helper
INFO - 2021-07-16 09:17:49 --> Helper loaded: form_helper
INFO - 2021-07-16 09:17:49 --> Helper loaded: my_helper
INFO - 2021-07-16 09:17:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:17:49 --> Controller Class Initialized
DEBUG - 2021-07-16 09:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 09:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:17:49 --> Final output sent to browser
DEBUG - 2021-07-16 09:17:49 --> Total execution time: 0.0704
INFO - 2021-07-16 09:17:52 --> Config Class Initialized
INFO - 2021-07-16 09:17:52 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:17:52 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:17:52 --> Utf8 Class Initialized
INFO - 2021-07-16 09:17:52 --> URI Class Initialized
INFO - 2021-07-16 09:17:52 --> Router Class Initialized
INFO - 2021-07-16 09:17:52 --> Output Class Initialized
INFO - 2021-07-16 09:17:52 --> Security Class Initialized
DEBUG - 2021-07-16 09:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:17:52 --> Input Class Initialized
INFO - 2021-07-16 09:17:52 --> Language Class Initialized
INFO - 2021-07-16 09:17:52 --> Language Class Initialized
INFO - 2021-07-16 09:17:52 --> Config Class Initialized
INFO - 2021-07-16 09:17:52 --> Loader Class Initialized
INFO - 2021-07-16 09:17:52 --> Helper loaded: url_helper
INFO - 2021-07-16 09:17:52 --> Helper loaded: file_helper
INFO - 2021-07-16 09:17:52 --> Helper loaded: form_helper
INFO - 2021-07-16 09:17:52 --> Helper loaded: my_helper
INFO - 2021-07-16 09:17:52 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:17:52 --> Controller Class Initialized
DEBUG - 2021-07-16 09:17:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-07-16 09:17:52 --> Final output sent to browser
DEBUG - 2021-07-16 09:17:52 --> Total execution time: 0.2919
INFO - 2021-07-16 09:17:54 --> Config Class Initialized
INFO - 2021-07-16 09:17:54 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:17:54 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:17:54 --> Utf8 Class Initialized
INFO - 2021-07-16 09:17:54 --> URI Class Initialized
INFO - 2021-07-16 09:17:54 --> Router Class Initialized
INFO - 2021-07-16 09:17:54 --> Output Class Initialized
INFO - 2021-07-16 09:17:54 --> Security Class Initialized
DEBUG - 2021-07-16 09:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:17:54 --> Input Class Initialized
INFO - 2021-07-16 09:17:54 --> Language Class Initialized
INFO - 2021-07-16 09:17:54 --> Language Class Initialized
INFO - 2021-07-16 09:17:54 --> Config Class Initialized
INFO - 2021-07-16 09:17:54 --> Loader Class Initialized
INFO - 2021-07-16 09:17:54 --> Helper loaded: url_helper
INFO - 2021-07-16 09:17:54 --> Helper loaded: file_helper
INFO - 2021-07-16 09:17:54 --> Helper loaded: form_helper
INFO - 2021-07-16 09:17:54 --> Helper loaded: my_helper
INFO - 2021-07-16 09:17:54 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:17:54 --> Controller Class Initialized
DEBUG - 2021-07-16 09:17:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:17:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:17:54 --> Final output sent to browser
DEBUG - 2021-07-16 09:17:54 --> Total execution time: 0.0687
INFO - 2021-07-16 09:18:38 --> Config Class Initialized
INFO - 2021-07-16 09:18:38 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:18:38 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:18:38 --> Utf8 Class Initialized
INFO - 2021-07-16 09:18:38 --> URI Class Initialized
DEBUG - 2021-07-16 09:18:38 --> No URI present. Default controller set.
INFO - 2021-07-16 09:18:38 --> Router Class Initialized
INFO - 2021-07-16 09:18:38 --> Output Class Initialized
INFO - 2021-07-16 09:18:38 --> Security Class Initialized
DEBUG - 2021-07-16 09:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:18:38 --> Input Class Initialized
INFO - 2021-07-16 09:18:38 --> Language Class Initialized
INFO - 2021-07-16 09:18:38 --> Language Class Initialized
INFO - 2021-07-16 09:18:38 --> Config Class Initialized
INFO - 2021-07-16 09:18:38 --> Loader Class Initialized
INFO - 2021-07-16 09:18:38 --> Helper loaded: url_helper
INFO - 2021-07-16 09:18:38 --> Helper loaded: file_helper
INFO - 2021-07-16 09:18:38 --> Helper loaded: form_helper
INFO - 2021-07-16 09:18:38 --> Helper loaded: my_helper
INFO - 2021-07-16 09:18:38 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:18:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:18:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:18:38 --> Controller Class Initialized
DEBUG - 2021-07-16 09:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:18:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:18:39 --> Final output sent to browser
DEBUG - 2021-07-16 09:18:39 --> Total execution time: 0.7034
INFO - 2021-07-16 09:18:40 --> Config Class Initialized
INFO - 2021-07-16 09:18:40 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:18:40 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:18:40 --> Utf8 Class Initialized
INFO - 2021-07-16 09:18:40 --> URI Class Initialized
INFO - 2021-07-16 09:18:40 --> Router Class Initialized
INFO - 2021-07-16 09:18:40 --> Output Class Initialized
INFO - 2021-07-16 09:18:40 --> Security Class Initialized
DEBUG - 2021-07-16 09:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:18:40 --> Input Class Initialized
INFO - 2021-07-16 09:18:40 --> Language Class Initialized
INFO - 2021-07-16 09:18:40 --> Language Class Initialized
INFO - 2021-07-16 09:18:40 --> Config Class Initialized
INFO - 2021-07-16 09:18:40 --> Loader Class Initialized
INFO - 2021-07-16 09:18:40 --> Helper loaded: url_helper
INFO - 2021-07-16 09:18:40 --> Helper loaded: file_helper
INFO - 2021-07-16 09:18:40 --> Helper loaded: form_helper
INFO - 2021-07-16 09:18:40 --> Helper loaded: my_helper
INFO - 2021-07-16 09:18:40 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:18:40 --> Controller Class Initialized
DEBUG - 2021-07-16 09:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-07-16 09:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:18:40 --> Final output sent to browser
DEBUG - 2021-07-16 09:18:40 --> Total execution time: 0.0589
INFO - 2021-07-16 09:18:47 --> Config Class Initialized
INFO - 2021-07-16 09:18:47 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:18:47 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:18:47 --> Utf8 Class Initialized
INFO - 2021-07-16 09:18:47 --> URI Class Initialized
INFO - 2021-07-16 09:18:47 --> Router Class Initialized
INFO - 2021-07-16 09:18:47 --> Output Class Initialized
INFO - 2021-07-16 09:18:47 --> Security Class Initialized
DEBUG - 2021-07-16 09:18:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:18:47 --> Input Class Initialized
INFO - 2021-07-16 09:18:47 --> Language Class Initialized
INFO - 2021-07-16 09:18:47 --> Language Class Initialized
INFO - 2021-07-16 09:18:47 --> Config Class Initialized
INFO - 2021-07-16 09:18:47 --> Loader Class Initialized
INFO - 2021-07-16 09:18:47 --> Helper loaded: url_helper
INFO - 2021-07-16 09:18:47 --> Helper loaded: file_helper
INFO - 2021-07-16 09:18:47 --> Helper loaded: form_helper
INFO - 2021-07-16 09:18:47 --> Helper loaded: my_helper
INFO - 2021-07-16 09:18:47 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:18:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:18:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:18:47 --> Controller Class Initialized
DEBUG - 2021-07-16 09:18:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 09:18:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:18:47 --> Final output sent to browser
DEBUG - 2021-07-16 09:18:47 --> Total execution time: 0.0636
INFO - 2021-07-16 09:18:56 --> Config Class Initialized
INFO - 2021-07-16 09:18:56 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:18:56 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:18:56 --> Utf8 Class Initialized
INFO - 2021-07-16 09:18:56 --> URI Class Initialized
INFO - 2021-07-16 09:18:56 --> Router Class Initialized
INFO - 2021-07-16 09:18:56 --> Output Class Initialized
INFO - 2021-07-16 09:18:56 --> Security Class Initialized
DEBUG - 2021-07-16 09:18:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:18:56 --> Input Class Initialized
INFO - 2021-07-16 09:18:56 --> Language Class Initialized
INFO - 2021-07-16 09:18:56 --> Language Class Initialized
INFO - 2021-07-16 09:18:56 --> Config Class Initialized
INFO - 2021-07-16 09:18:56 --> Loader Class Initialized
INFO - 2021-07-16 09:18:56 --> Helper loaded: url_helper
INFO - 2021-07-16 09:18:56 --> Helper loaded: file_helper
INFO - 2021-07-16 09:18:56 --> Helper loaded: form_helper
INFO - 2021-07-16 09:18:56 --> Helper loaded: my_helper
INFO - 2021-07-16 09:18:56 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:18:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:18:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:18:56 --> Controller Class Initialized
DEBUG - 2021-07-16 09:18:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-07-16 09:18:56 --> Final output sent to browser
DEBUG - 2021-07-16 09:18:56 --> Total execution time: 0.2857
INFO - 2021-07-16 09:19:57 --> Config Class Initialized
INFO - 2021-07-16 09:19:57 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:19:57 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:19:57 --> Utf8 Class Initialized
INFO - 2021-07-16 09:19:57 --> URI Class Initialized
INFO - 2021-07-16 09:19:57 --> Router Class Initialized
INFO - 2021-07-16 09:19:57 --> Output Class Initialized
INFO - 2021-07-16 09:19:57 --> Security Class Initialized
DEBUG - 2021-07-16 09:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:19:57 --> Input Class Initialized
INFO - 2021-07-16 09:19:57 --> Language Class Initialized
INFO - 2021-07-16 09:19:57 --> Language Class Initialized
INFO - 2021-07-16 09:19:57 --> Config Class Initialized
INFO - 2021-07-16 09:19:57 --> Loader Class Initialized
INFO - 2021-07-16 09:19:57 --> Helper loaded: url_helper
INFO - 2021-07-16 09:19:57 --> Helper loaded: file_helper
INFO - 2021-07-16 09:19:57 --> Helper loaded: form_helper
INFO - 2021-07-16 09:19:57 --> Helper loaded: my_helper
INFO - 2021-07-16 09:19:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:19:57 --> Controller Class Initialized
DEBUG - 2021-07-16 09:19:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:19:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:19:57 --> Final output sent to browser
DEBUG - 2021-07-16 09:19:57 --> Total execution time: 0.0905
INFO - 2021-07-16 09:26:39 --> Config Class Initialized
INFO - 2021-07-16 09:26:39 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:26:39 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:26:39 --> Utf8 Class Initialized
INFO - 2021-07-16 09:26:39 --> URI Class Initialized
INFO - 2021-07-16 09:26:39 --> Router Class Initialized
INFO - 2021-07-16 09:26:39 --> Output Class Initialized
INFO - 2021-07-16 09:26:39 --> Security Class Initialized
DEBUG - 2021-07-16 09:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:26:39 --> Input Class Initialized
INFO - 2021-07-16 09:26:39 --> Language Class Initialized
INFO - 2021-07-16 09:26:39 --> Language Class Initialized
INFO - 2021-07-16 09:26:39 --> Config Class Initialized
INFO - 2021-07-16 09:26:39 --> Loader Class Initialized
INFO - 2021-07-16 09:26:39 --> Helper loaded: url_helper
INFO - 2021-07-16 09:26:39 --> Helper loaded: file_helper
INFO - 2021-07-16 09:26:39 --> Helper loaded: form_helper
INFO - 2021-07-16 09:26:39 --> Helper loaded: my_helper
INFO - 2021-07-16 09:26:39 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:26:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:26:39 --> Controller Class Initialized
INFO - 2021-07-16 09:26:40 --> Final output sent to browser
DEBUG - 2021-07-16 09:26:40 --> Total execution time: 0.1112
INFO - 2021-07-16 09:26:44 --> Config Class Initialized
INFO - 2021-07-16 09:26:44 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:26:44 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:26:44 --> Utf8 Class Initialized
INFO - 2021-07-16 09:26:44 --> URI Class Initialized
INFO - 2021-07-16 09:26:44 --> Router Class Initialized
INFO - 2021-07-16 09:26:44 --> Output Class Initialized
INFO - 2021-07-16 09:26:44 --> Security Class Initialized
DEBUG - 2021-07-16 09:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:26:44 --> Input Class Initialized
INFO - 2021-07-16 09:26:44 --> Language Class Initialized
INFO - 2021-07-16 09:26:44 --> Language Class Initialized
INFO - 2021-07-16 09:26:44 --> Config Class Initialized
INFO - 2021-07-16 09:26:44 --> Loader Class Initialized
INFO - 2021-07-16 09:26:44 --> Helper loaded: url_helper
INFO - 2021-07-16 09:26:44 --> Helper loaded: file_helper
INFO - 2021-07-16 09:26:44 --> Helper loaded: form_helper
INFO - 2021-07-16 09:26:44 --> Helper loaded: my_helper
INFO - 2021-07-16 09:26:44 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:26:44 --> Controller Class Initialized
DEBUG - 2021-07-16 09:26:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 09:26:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:26:44 --> Final output sent to browser
DEBUG - 2021-07-16 09:26:44 --> Total execution time: 0.0572
INFO - 2021-07-16 09:26:48 --> Config Class Initialized
INFO - 2021-07-16 09:26:48 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:26:48 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:26:48 --> Utf8 Class Initialized
INFO - 2021-07-16 09:26:48 --> URI Class Initialized
INFO - 2021-07-16 09:26:48 --> Router Class Initialized
INFO - 2021-07-16 09:26:48 --> Output Class Initialized
INFO - 2021-07-16 09:26:48 --> Security Class Initialized
DEBUG - 2021-07-16 09:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:26:48 --> Input Class Initialized
INFO - 2021-07-16 09:26:48 --> Language Class Initialized
INFO - 2021-07-16 09:26:48 --> Language Class Initialized
INFO - 2021-07-16 09:26:48 --> Config Class Initialized
INFO - 2021-07-16 09:26:48 --> Loader Class Initialized
INFO - 2021-07-16 09:26:48 --> Helper loaded: url_helper
INFO - 2021-07-16 09:26:48 --> Helper loaded: file_helper
INFO - 2021-07-16 09:26:48 --> Helper loaded: form_helper
INFO - 2021-07-16 09:26:48 --> Helper loaded: my_helper
INFO - 2021-07-16 09:26:48 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:26:48 --> Controller Class Initialized
INFO - 2021-07-16 09:26:48 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:26:48 --> Config Class Initialized
INFO - 2021-07-16 09:26:48 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:26:48 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:26:48 --> Utf8 Class Initialized
INFO - 2021-07-16 09:26:48 --> URI Class Initialized
INFO - 2021-07-16 09:26:48 --> Router Class Initialized
INFO - 2021-07-16 09:26:48 --> Output Class Initialized
INFO - 2021-07-16 09:26:48 --> Security Class Initialized
DEBUG - 2021-07-16 09:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:26:48 --> Input Class Initialized
INFO - 2021-07-16 09:26:48 --> Language Class Initialized
INFO - 2021-07-16 09:26:48 --> Language Class Initialized
INFO - 2021-07-16 09:26:48 --> Config Class Initialized
INFO - 2021-07-16 09:26:48 --> Loader Class Initialized
INFO - 2021-07-16 09:26:48 --> Helper loaded: url_helper
INFO - 2021-07-16 09:26:48 --> Helper loaded: file_helper
INFO - 2021-07-16 09:26:48 --> Helper loaded: form_helper
INFO - 2021-07-16 09:26:48 --> Helper loaded: my_helper
INFO - 2021-07-16 09:26:48 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:26:48 --> Controller Class Initialized
DEBUG - 2021-07-16 09:26:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 09:26:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:26:48 --> Final output sent to browser
DEBUG - 2021-07-16 09:26:48 --> Total execution time: 0.0553
INFO - 2021-07-16 09:27:17 --> Config Class Initialized
INFO - 2021-07-16 09:27:17 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:27:17 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:27:17 --> Utf8 Class Initialized
INFO - 2021-07-16 09:27:17 --> URI Class Initialized
INFO - 2021-07-16 09:27:17 --> Router Class Initialized
INFO - 2021-07-16 09:27:17 --> Output Class Initialized
INFO - 2021-07-16 09:27:17 --> Security Class Initialized
DEBUG - 2021-07-16 09:27:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:27:17 --> Input Class Initialized
INFO - 2021-07-16 09:27:17 --> Language Class Initialized
INFO - 2021-07-16 09:27:17 --> Language Class Initialized
INFO - 2021-07-16 09:27:17 --> Config Class Initialized
INFO - 2021-07-16 09:27:17 --> Loader Class Initialized
INFO - 2021-07-16 09:27:17 --> Helper loaded: url_helper
INFO - 2021-07-16 09:27:17 --> Helper loaded: file_helper
INFO - 2021-07-16 09:27:17 --> Helper loaded: form_helper
INFO - 2021-07-16 09:27:17 --> Helper loaded: my_helper
INFO - 2021-07-16 09:27:17 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:27:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:27:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:27:17 --> Controller Class Initialized
INFO - 2021-07-16 09:27:17 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:27:17 --> Final output sent to browser
DEBUG - 2021-07-16 09:27:17 --> Total execution time: 0.0597
INFO - 2021-07-16 09:27:19 --> Config Class Initialized
INFO - 2021-07-16 09:27:19 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:27:19 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:27:19 --> Utf8 Class Initialized
INFO - 2021-07-16 09:27:19 --> URI Class Initialized
INFO - 2021-07-16 09:27:19 --> Router Class Initialized
INFO - 2021-07-16 09:27:19 --> Output Class Initialized
INFO - 2021-07-16 09:27:19 --> Security Class Initialized
DEBUG - 2021-07-16 09:27:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:27:19 --> Input Class Initialized
INFO - 2021-07-16 09:27:19 --> Language Class Initialized
INFO - 2021-07-16 09:27:19 --> Language Class Initialized
INFO - 2021-07-16 09:27:19 --> Config Class Initialized
INFO - 2021-07-16 09:27:19 --> Loader Class Initialized
INFO - 2021-07-16 09:27:19 --> Helper loaded: url_helper
INFO - 2021-07-16 09:27:19 --> Helper loaded: file_helper
INFO - 2021-07-16 09:27:19 --> Helper loaded: form_helper
INFO - 2021-07-16 09:27:19 --> Helper loaded: my_helper
INFO - 2021-07-16 09:27:19 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:27:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:27:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:27:19 --> Controller Class Initialized
DEBUG - 2021-07-16 09:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:27:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:27:20 --> Final output sent to browser
DEBUG - 2021-07-16 09:27:20 --> Total execution time: 0.7188
INFO - 2021-07-16 09:27:53 --> Config Class Initialized
INFO - 2021-07-16 09:27:53 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:27:53 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:27:53 --> Utf8 Class Initialized
INFO - 2021-07-16 09:27:53 --> URI Class Initialized
INFO - 2021-07-16 09:27:53 --> Router Class Initialized
INFO - 2021-07-16 09:27:53 --> Output Class Initialized
INFO - 2021-07-16 09:27:53 --> Security Class Initialized
DEBUG - 2021-07-16 09:27:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:27:53 --> Input Class Initialized
INFO - 2021-07-16 09:27:53 --> Language Class Initialized
INFO - 2021-07-16 09:27:53 --> Language Class Initialized
INFO - 2021-07-16 09:27:53 --> Config Class Initialized
INFO - 2021-07-16 09:27:53 --> Loader Class Initialized
INFO - 2021-07-16 09:27:53 --> Helper loaded: url_helper
INFO - 2021-07-16 09:27:53 --> Helper loaded: file_helper
INFO - 2021-07-16 09:27:53 --> Helper loaded: form_helper
INFO - 2021-07-16 09:27:53 --> Helper loaded: my_helper
INFO - 2021-07-16 09:27:53 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:27:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:27:53 --> Controller Class Initialized
DEBUG - 2021-07-16 09:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:27:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:27:53 --> Final output sent to browser
DEBUG - 2021-07-16 09:27:53 --> Total execution time: 0.0589
INFO - 2021-07-16 09:29:00 --> Config Class Initialized
INFO - 2021-07-16 09:29:00 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:29:00 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:29:00 --> Utf8 Class Initialized
INFO - 2021-07-16 09:29:00 --> URI Class Initialized
INFO - 2021-07-16 09:29:00 --> Router Class Initialized
INFO - 2021-07-16 09:29:00 --> Output Class Initialized
INFO - 2021-07-16 09:29:00 --> Security Class Initialized
DEBUG - 2021-07-16 09:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:29:00 --> Input Class Initialized
INFO - 2021-07-16 09:29:00 --> Language Class Initialized
INFO - 2021-07-16 09:29:00 --> Language Class Initialized
INFO - 2021-07-16 09:29:00 --> Config Class Initialized
INFO - 2021-07-16 09:29:00 --> Loader Class Initialized
INFO - 2021-07-16 09:29:00 --> Helper loaded: url_helper
INFO - 2021-07-16 09:29:00 --> Helper loaded: file_helper
INFO - 2021-07-16 09:29:00 --> Helper loaded: form_helper
INFO - 2021-07-16 09:29:00 --> Helper loaded: my_helper
INFO - 2021-07-16 09:29:00 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:29:00 --> Controller Class Initialized
INFO - 2021-07-16 09:29:00 --> Final output sent to browser
DEBUG - 2021-07-16 09:29:00 --> Total execution time: 0.0913
INFO - 2021-07-16 09:29:28 --> Config Class Initialized
INFO - 2021-07-16 09:29:28 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:29:28 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:29:28 --> Utf8 Class Initialized
INFO - 2021-07-16 09:29:28 --> URI Class Initialized
INFO - 2021-07-16 09:29:28 --> Router Class Initialized
INFO - 2021-07-16 09:29:28 --> Output Class Initialized
INFO - 2021-07-16 09:29:28 --> Security Class Initialized
DEBUG - 2021-07-16 09:29:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:29:28 --> Input Class Initialized
INFO - 2021-07-16 09:29:28 --> Language Class Initialized
INFO - 2021-07-16 09:29:28 --> Language Class Initialized
INFO - 2021-07-16 09:29:28 --> Config Class Initialized
INFO - 2021-07-16 09:29:28 --> Loader Class Initialized
INFO - 2021-07-16 09:29:28 --> Helper loaded: url_helper
INFO - 2021-07-16 09:29:28 --> Helper loaded: file_helper
INFO - 2021-07-16 09:29:28 --> Helper loaded: form_helper
INFO - 2021-07-16 09:29:28 --> Helper loaded: my_helper
INFO - 2021-07-16 09:29:28 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:29:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:29:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:29:28 --> Controller Class Initialized
INFO - 2021-07-16 09:29:28 --> Final output sent to browser
DEBUG - 2021-07-16 09:29:28 --> Total execution time: 0.0730
INFO - 2021-07-16 09:29:32 --> Config Class Initialized
INFO - 2021-07-16 09:29:32 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:29:32 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:29:32 --> Utf8 Class Initialized
INFO - 2021-07-16 09:29:32 --> URI Class Initialized
INFO - 2021-07-16 09:29:32 --> Router Class Initialized
INFO - 2021-07-16 09:29:32 --> Output Class Initialized
INFO - 2021-07-16 09:29:32 --> Security Class Initialized
DEBUG - 2021-07-16 09:29:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:29:32 --> Input Class Initialized
INFO - 2021-07-16 09:29:32 --> Language Class Initialized
INFO - 2021-07-16 09:29:32 --> Language Class Initialized
INFO - 2021-07-16 09:29:32 --> Config Class Initialized
INFO - 2021-07-16 09:29:32 --> Loader Class Initialized
INFO - 2021-07-16 09:29:32 --> Helper loaded: url_helper
INFO - 2021-07-16 09:29:32 --> Helper loaded: file_helper
INFO - 2021-07-16 09:29:32 --> Helper loaded: form_helper
INFO - 2021-07-16 09:29:32 --> Helper loaded: my_helper
INFO - 2021-07-16 09:29:32 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:29:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:29:32 --> Controller Class Initialized
DEBUG - 2021-07-16 09:29:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:29:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:29:33 --> Final output sent to browser
DEBUG - 2021-07-16 09:29:33 --> Total execution time: 0.7035
INFO - 2021-07-16 09:29:34 --> Config Class Initialized
INFO - 2021-07-16 09:29:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:29:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:29:34 --> Utf8 Class Initialized
INFO - 2021-07-16 09:29:34 --> URI Class Initialized
INFO - 2021-07-16 09:29:34 --> Router Class Initialized
INFO - 2021-07-16 09:29:34 --> Output Class Initialized
INFO - 2021-07-16 09:29:34 --> Security Class Initialized
DEBUG - 2021-07-16 09:29:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:29:34 --> Input Class Initialized
INFO - 2021-07-16 09:29:34 --> Language Class Initialized
INFO - 2021-07-16 09:29:34 --> Language Class Initialized
INFO - 2021-07-16 09:29:34 --> Config Class Initialized
INFO - 2021-07-16 09:29:34 --> Loader Class Initialized
INFO - 2021-07-16 09:29:34 --> Helper loaded: url_helper
INFO - 2021-07-16 09:29:34 --> Helper loaded: file_helper
INFO - 2021-07-16 09:29:34 --> Helper loaded: form_helper
INFO - 2021-07-16 09:29:34 --> Helper loaded: my_helper
INFO - 2021-07-16 09:29:34 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:29:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:29:34 --> Controller Class Initialized
DEBUG - 2021-07-16 09:29:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 09:29:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:29:34 --> Final output sent to browser
DEBUG - 2021-07-16 09:29:34 --> Total execution time: 0.0703
INFO - 2021-07-16 09:29:42 --> Config Class Initialized
INFO - 2021-07-16 09:29:42 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:29:42 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:29:42 --> Utf8 Class Initialized
INFO - 2021-07-16 09:29:42 --> URI Class Initialized
INFO - 2021-07-16 09:29:42 --> Router Class Initialized
INFO - 2021-07-16 09:29:42 --> Output Class Initialized
INFO - 2021-07-16 09:29:42 --> Security Class Initialized
DEBUG - 2021-07-16 09:29:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:29:42 --> Input Class Initialized
INFO - 2021-07-16 09:29:42 --> Language Class Initialized
INFO - 2021-07-16 09:29:42 --> Language Class Initialized
INFO - 2021-07-16 09:29:42 --> Config Class Initialized
INFO - 2021-07-16 09:29:42 --> Loader Class Initialized
INFO - 2021-07-16 09:29:42 --> Helper loaded: url_helper
INFO - 2021-07-16 09:29:42 --> Helper loaded: file_helper
INFO - 2021-07-16 09:29:42 --> Helper loaded: form_helper
INFO - 2021-07-16 09:29:42 --> Helper loaded: my_helper
INFO - 2021-07-16 09:29:42 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:29:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:29:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:29:42 --> Controller Class Initialized
DEBUG - 2021-07-16 09:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 09:29:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:29:42 --> Final output sent to browser
DEBUG - 2021-07-16 09:29:42 --> Total execution time: 0.0710
INFO - 2021-07-16 09:29:45 --> Config Class Initialized
INFO - 2021-07-16 09:29:45 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:29:45 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:29:45 --> Utf8 Class Initialized
INFO - 2021-07-16 09:29:45 --> URI Class Initialized
INFO - 2021-07-16 09:29:45 --> Router Class Initialized
INFO - 2021-07-16 09:29:45 --> Output Class Initialized
INFO - 2021-07-16 09:29:45 --> Security Class Initialized
DEBUG - 2021-07-16 09:29:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:29:45 --> Input Class Initialized
INFO - 2021-07-16 09:29:45 --> Language Class Initialized
INFO - 2021-07-16 09:29:45 --> Language Class Initialized
INFO - 2021-07-16 09:29:45 --> Config Class Initialized
INFO - 2021-07-16 09:29:45 --> Loader Class Initialized
INFO - 2021-07-16 09:29:45 --> Helper loaded: url_helper
INFO - 2021-07-16 09:29:45 --> Helper loaded: file_helper
INFO - 2021-07-16 09:29:45 --> Helper loaded: form_helper
INFO - 2021-07-16 09:29:45 --> Helper loaded: my_helper
INFO - 2021-07-16 09:29:45 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:29:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:29:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:29:45 --> Controller Class Initialized
DEBUG - 2021-07-16 09:29:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-07-16 09:29:45 --> Final output sent to browser
DEBUG - 2021-07-16 09:29:45 --> Total execution time: 0.2871
INFO - 2021-07-16 09:30:01 --> Config Class Initialized
INFO - 2021-07-16 09:30:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:30:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:30:01 --> Utf8 Class Initialized
INFO - 2021-07-16 09:30:01 --> URI Class Initialized
INFO - 2021-07-16 09:30:01 --> Router Class Initialized
INFO - 2021-07-16 09:30:01 --> Output Class Initialized
INFO - 2021-07-16 09:30:01 --> Security Class Initialized
DEBUG - 2021-07-16 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:30:01 --> Input Class Initialized
INFO - 2021-07-16 09:30:01 --> Language Class Initialized
INFO - 2021-07-16 09:30:01 --> Language Class Initialized
INFO - 2021-07-16 09:30:01 --> Config Class Initialized
INFO - 2021-07-16 09:30:01 --> Loader Class Initialized
INFO - 2021-07-16 09:30:01 --> Helper loaded: url_helper
INFO - 2021-07-16 09:30:01 --> Helper loaded: file_helper
INFO - 2021-07-16 09:30:01 --> Helper loaded: form_helper
INFO - 2021-07-16 09:30:01 --> Helper loaded: my_helper
INFO - 2021-07-16 09:30:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:30:01 --> Controller Class Initialized
INFO - 2021-07-16 09:30:01 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:30:01 --> Config Class Initialized
INFO - 2021-07-16 09:30:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:30:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:30:01 --> Utf8 Class Initialized
INFO - 2021-07-16 09:30:01 --> URI Class Initialized
INFO - 2021-07-16 09:30:01 --> Router Class Initialized
INFO - 2021-07-16 09:30:01 --> Output Class Initialized
INFO - 2021-07-16 09:30:01 --> Security Class Initialized
DEBUG - 2021-07-16 09:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:30:01 --> Input Class Initialized
INFO - 2021-07-16 09:30:01 --> Language Class Initialized
INFO - 2021-07-16 09:30:01 --> Language Class Initialized
INFO - 2021-07-16 09:30:01 --> Config Class Initialized
INFO - 2021-07-16 09:30:01 --> Loader Class Initialized
INFO - 2021-07-16 09:30:01 --> Helper loaded: url_helper
INFO - 2021-07-16 09:30:01 --> Helper loaded: file_helper
INFO - 2021-07-16 09:30:01 --> Helper loaded: form_helper
INFO - 2021-07-16 09:30:01 --> Helper loaded: my_helper
INFO - 2021-07-16 09:30:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:30:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:30:01 --> Controller Class Initialized
DEBUG - 2021-07-16 09:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 09:30:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:30:01 --> Final output sent to browser
DEBUG - 2021-07-16 09:30:01 --> Total execution time: 0.0432
INFO - 2021-07-16 09:30:27 --> Config Class Initialized
INFO - 2021-07-16 09:30:27 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:30:27 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:30:27 --> Utf8 Class Initialized
INFO - 2021-07-16 09:30:27 --> URI Class Initialized
INFO - 2021-07-16 09:30:27 --> Router Class Initialized
INFO - 2021-07-16 09:30:27 --> Output Class Initialized
INFO - 2021-07-16 09:30:27 --> Security Class Initialized
DEBUG - 2021-07-16 09:30:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:30:27 --> Input Class Initialized
INFO - 2021-07-16 09:30:27 --> Language Class Initialized
INFO - 2021-07-16 09:30:27 --> Language Class Initialized
INFO - 2021-07-16 09:30:27 --> Config Class Initialized
INFO - 2021-07-16 09:30:27 --> Loader Class Initialized
INFO - 2021-07-16 09:30:27 --> Helper loaded: url_helper
INFO - 2021-07-16 09:30:27 --> Helper loaded: file_helper
INFO - 2021-07-16 09:30:27 --> Helper loaded: form_helper
INFO - 2021-07-16 09:30:27 --> Helper loaded: my_helper
INFO - 2021-07-16 09:30:27 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:30:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:30:27 --> Controller Class Initialized
INFO - 2021-07-16 09:30:27 --> Final output sent to browser
DEBUG - 2021-07-16 09:30:27 --> Total execution time: 0.0611
INFO - 2021-07-16 09:30:39 --> Config Class Initialized
INFO - 2021-07-16 09:30:39 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:30:39 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:30:39 --> Utf8 Class Initialized
INFO - 2021-07-16 09:30:39 --> URI Class Initialized
INFO - 2021-07-16 09:30:39 --> Router Class Initialized
INFO - 2021-07-16 09:30:39 --> Output Class Initialized
INFO - 2021-07-16 09:30:39 --> Security Class Initialized
DEBUG - 2021-07-16 09:30:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:30:39 --> Input Class Initialized
INFO - 2021-07-16 09:30:39 --> Language Class Initialized
INFO - 2021-07-16 09:30:39 --> Language Class Initialized
INFO - 2021-07-16 09:30:39 --> Config Class Initialized
INFO - 2021-07-16 09:30:39 --> Loader Class Initialized
INFO - 2021-07-16 09:30:39 --> Helper loaded: url_helper
INFO - 2021-07-16 09:30:39 --> Helper loaded: file_helper
INFO - 2021-07-16 09:30:39 --> Helper loaded: form_helper
INFO - 2021-07-16 09:30:39 --> Helper loaded: my_helper
INFO - 2021-07-16 09:30:39 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:30:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:30:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:30:39 --> Controller Class Initialized
INFO - 2021-07-16 09:30:39 --> Final output sent to browser
DEBUG - 2021-07-16 09:30:39 --> Total execution time: 0.0580
INFO - 2021-07-16 09:30:58 --> Config Class Initialized
INFO - 2021-07-16 09:30:58 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:30:58 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:30:58 --> Utf8 Class Initialized
INFO - 2021-07-16 09:30:58 --> URI Class Initialized
INFO - 2021-07-16 09:30:58 --> Router Class Initialized
INFO - 2021-07-16 09:30:58 --> Output Class Initialized
INFO - 2021-07-16 09:30:58 --> Security Class Initialized
DEBUG - 2021-07-16 09:30:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:30:58 --> Input Class Initialized
INFO - 2021-07-16 09:30:58 --> Language Class Initialized
INFO - 2021-07-16 09:30:58 --> Language Class Initialized
INFO - 2021-07-16 09:30:58 --> Config Class Initialized
INFO - 2021-07-16 09:30:58 --> Loader Class Initialized
INFO - 2021-07-16 09:30:58 --> Helper loaded: url_helper
INFO - 2021-07-16 09:30:58 --> Helper loaded: file_helper
INFO - 2021-07-16 09:30:58 --> Helper loaded: form_helper
INFO - 2021-07-16 09:30:58 --> Helper loaded: my_helper
INFO - 2021-07-16 09:30:58 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:30:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:30:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:30:58 --> Controller Class Initialized
INFO - 2021-07-16 09:30:58 --> Final output sent to browser
DEBUG - 2021-07-16 09:30:58 --> Total execution time: 0.0695
INFO - 2021-07-16 09:31:28 --> Config Class Initialized
INFO - 2021-07-16 09:31:28 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:31:28 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:31:28 --> Utf8 Class Initialized
INFO - 2021-07-16 09:31:28 --> URI Class Initialized
INFO - 2021-07-16 09:31:28 --> Router Class Initialized
INFO - 2021-07-16 09:31:28 --> Output Class Initialized
INFO - 2021-07-16 09:31:28 --> Security Class Initialized
DEBUG - 2021-07-16 09:31:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:31:28 --> Input Class Initialized
INFO - 2021-07-16 09:31:28 --> Language Class Initialized
INFO - 2021-07-16 09:31:28 --> Language Class Initialized
INFO - 2021-07-16 09:31:28 --> Config Class Initialized
INFO - 2021-07-16 09:31:28 --> Loader Class Initialized
INFO - 2021-07-16 09:31:28 --> Helper loaded: url_helper
INFO - 2021-07-16 09:31:28 --> Helper loaded: file_helper
INFO - 2021-07-16 09:31:28 --> Helper loaded: form_helper
INFO - 2021-07-16 09:31:28 --> Helper loaded: my_helper
INFO - 2021-07-16 09:31:28 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:31:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:31:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:31:28 --> Controller Class Initialized
INFO - 2021-07-16 09:31:28 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:31:28 --> Final output sent to browser
DEBUG - 2021-07-16 09:31:28 --> Total execution time: 0.0492
INFO - 2021-07-16 09:31:31 --> Config Class Initialized
INFO - 2021-07-16 09:31:31 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:31:31 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:31:31 --> Utf8 Class Initialized
INFO - 2021-07-16 09:31:31 --> URI Class Initialized
INFO - 2021-07-16 09:31:31 --> Router Class Initialized
INFO - 2021-07-16 09:31:31 --> Output Class Initialized
INFO - 2021-07-16 09:31:31 --> Security Class Initialized
DEBUG - 2021-07-16 09:31:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:31:31 --> Input Class Initialized
INFO - 2021-07-16 09:31:31 --> Language Class Initialized
INFO - 2021-07-16 09:31:31 --> Language Class Initialized
INFO - 2021-07-16 09:31:31 --> Config Class Initialized
INFO - 2021-07-16 09:31:31 --> Loader Class Initialized
INFO - 2021-07-16 09:31:31 --> Helper loaded: url_helper
INFO - 2021-07-16 09:31:31 --> Helper loaded: file_helper
INFO - 2021-07-16 09:31:31 --> Helper loaded: form_helper
INFO - 2021-07-16 09:31:31 --> Helper loaded: my_helper
INFO - 2021-07-16 09:31:31 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:31:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:31:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:31:31 --> Controller Class Initialized
DEBUG - 2021-07-16 09:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:31:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:31:32 --> Final output sent to browser
DEBUG - 2021-07-16 09:31:32 --> Total execution time: 0.7125
INFO - 2021-07-16 09:31:36 --> Config Class Initialized
INFO - 2021-07-16 09:31:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:31:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:31:36 --> Utf8 Class Initialized
INFO - 2021-07-16 09:31:36 --> URI Class Initialized
INFO - 2021-07-16 09:31:36 --> Router Class Initialized
INFO - 2021-07-16 09:31:36 --> Output Class Initialized
INFO - 2021-07-16 09:31:36 --> Security Class Initialized
DEBUG - 2021-07-16 09:31:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:31:36 --> Input Class Initialized
INFO - 2021-07-16 09:31:36 --> Language Class Initialized
INFO - 2021-07-16 09:31:36 --> Language Class Initialized
INFO - 2021-07-16 09:31:36 --> Config Class Initialized
INFO - 2021-07-16 09:31:36 --> Loader Class Initialized
INFO - 2021-07-16 09:31:36 --> Helper loaded: url_helper
INFO - 2021-07-16 09:31:36 --> Helper loaded: file_helper
INFO - 2021-07-16 09:31:36 --> Helper loaded: form_helper
INFO - 2021-07-16 09:31:36 --> Helper loaded: my_helper
INFO - 2021-07-16 09:31:36 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:31:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:31:36 --> Controller Class Initialized
DEBUG - 2021-07-16 09:31:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-07-16 09:31:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:31:36 --> Final output sent to browser
DEBUG - 2021-07-16 09:31:36 --> Total execution time: 0.0654
INFO - 2021-07-16 09:31:43 --> Config Class Initialized
INFO - 2021-07-16 09:31:43 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:31:43 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:31:43 --> Utf8 Class Initialized
INFO - 2021-07-16 09:31:43 --> URI Class Initialized
INFO - 2021-07-16 09:31:43 --> Router Class Initialized
INFO - 2021-07-16 09:31:43 --> Output Class Initialized
INFO - 2021-07-16 09:31:43 --> Security Class Initialized
DEBUG - 2021-07-16 09:31:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:31:43 --> Input Class Initialized
INFO - 2021-07-16 09:31:43 --> Language Class Initialized
INFO - 2021-07-16 09:31:43 --> Language Class Initialized
INFO - 2021-07-16 09:31:43 --> Config Class Initialized
INFO - 2021-07-16 09:31:43 --> Loader Class Initialized
INFO - 2021-07-16 09:31:43 --> Helper loaded: url_helper
INFO - 2021-07-16 09:31:43 --> Helper loaded: file_helper
INFO - 2021-07-16 09:31:43 --> Helper loaded: form_helper
INFO - 2021-07-16 09:31:43 --> Helper loaded: my_helper
INFO - 2021-07-16 09:31:43 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:31:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:31:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:31:43 --> Controller Class Initialized
DEBUG - 2021-07-16 09:31:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-07-16 09:31:43 --> Final output sent to browser
DEBUG - 2021-07-16 09:31:43 --> Total execution time: 0.2696
INFO - 2021-07-16 09:31:56 --> Config Class Initialized
INFO - 2021-07-16 09:31:56 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:31:56 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:31:56 --> Utf8 Class Initialized
INFO - 2021-07-16 09:31:56 --> URI Class Initialized
INFO - 2021-07-16 09:31:56 --> Router Class Initialized
INFO - 2021-07-16 09:31:56 --> Output Class Initialized
INFO - 2021-07-16 09:31:56 --> Security Class Initialized
DEBUG - 2021-07-16 09:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:31:56 --> Input Class Initialized
INFO - 2021-07-16 09:31:56 --> Language Class Initialized
INFO - 2021-07-16 09:31:56 --> Language Class Initialized
INFO - 2021-07-16 09:31:56 --> Config Class Initialized
INFO - 2021-07-16 09:31:56 --> Loader Class Initialized
INFO - 2021-07-16 09:31:56 --> Helper loaded: url_helper
INFO - 2021-07-16 09:31:56 --> Helper loaded: file_helper
INFO - 2021-07-16 09:31:57 --> Helper loaded: form_helper
INFO - 2021-07-16 09:31:57 --> Helper loaded: my_helper
INFO - 2021-07-16 09:31:57 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:31:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:31:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:31:57 --> Controller Class Initialized
DEBUG - 2021-07-16 09:31:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xii.php
INFO - 2021-07-16 09:31:57 --> Final output sent to browser
DEBUG - 2021-07-16 09:31:57 --> Total execution time: 0.2348
INFO - 2021-07-16 09:33:17 --> Config Class Initialized
INFO - 2021-07-16 09:33:17 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:33:17 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:33:17 --> Utf8 Class Initialized
INFO - 2021-07-16 09:33:17 --> URI Class Initialized
INFO - 2021-07-16 09:33:17 --> Router Class Initialized
INFO - 2021-07-16 09:33:17 --> Output Class Initialized
INFO - 2021-07-16 09:33:17 --> Security Class Initialized
DEBUG - 2021-07-16 09:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:33:17 --> Input Class Initialized
INFO - 2021-07-16 09:33:17 --> Language Class Initialized
INFO - 2021-07-16 09:33:17 --> Language Class Initialized
INFO - 2021-07-16 09:33:17 --> Config Class Initialized
INFO - 2021-07-16 09:33:17 --> Loader Class Initialized
INFO - 2021-07-16 09:33:17 --> Helper loaded: url_helper
INFO - 2021-07-16 09:33:17 --> Helper loaded: file_helper
INFO - 2021-07-16 09:33:17 --> Helper loaded: form_helper
INFO - 2021-07-16 09:33:17 --> Helper loaded: my_helper
INFO - 2021-07-16 09:33:17 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:33:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:33:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:33:17 --> Controller Class Initialized
DEBUG - 2021-07-16 09:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 09:33:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:33:17 --> Final output sent to browser
DEBUG - 2021-07-16 09:33:17 --> Total execution time: 0.0459
INFO - 2021-07-16 09:33:31 --> Config Class Initialized
INFO - 2021-07-16 09:33:31 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:33:31 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:33:31 --> Utf8 Class Initialized
INFO - 2021-07-16 09:33:31 --> URI Class Initialized
INFO - 2021-07-16 09:33:31 --> Router Class Initialized
INFO - 2021-07-16 09:33:31 --> Output Class Initialized
INFO - 2021-07-16 09:33:31 --> Security Class Initialized
DEBUG - 2021-07-16 09:33:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:33:31 --> Input Class Initialized
INFO - 2021-07-16 09:33:31 --> Language Class Initialized
INFO - 2021-07-16 09:33:31 --> Language Class Initialized
INFO - 2021-07-16 09:33:31 --> Config Class Initialized
INFO - 2021-07-16 09:33:31 --> Loader Class Initialized
INFO - 2021-07-16 09:33:31 --> Helper loaded: url_helper
INFO - 2021-07-16 09:33:31 --> Helper loaded: file_helper
INFO - 2021-07-16 09:33:31 --> Helper loaded: form_helper
INFO - 2021-07-16 09:33:31 --> Helper loaded: my_helper
INFO - 2021-07-16 09:33:31 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:33:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:33:31 --> Controller Class Initialized
INFO - 2021-07-16 09:33:31 --> Helper loaded: cookie_helper
INFO - 2021-07-16 09:33:31 --> Final output sent to browser
DEBUG - 2021-07-16 09:33:31 --> Total execution time: 0.0703
INFO - 2021-07-16 09:33:34 --> Config Class Initialized
INFO - 2021-07-16 09:33:34 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:33:34 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:33:34 --> Utf8 Class Initialized
INFO - 2021-07-16 09:33:34 --> URI Class Initialized
INFO - 2021-07-16 09:33:34 --> Router Class Initialized
INFO - 2021-07-16 09:33:34 --> Output Class Initialized
INFO - 2021-07-16 09:33:34 --> Security Class Initialized
DEBUG - 2021-07-16 09:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:33:34 --> Input Class Initialized
INFO - 2021-07-16 09:33:34 --> Language Class Initialized
INFO - 2021-07-16 09:33:34 --> Language Class Initialized
INFO - 2021-07-16 09:33:34 --> Config Class Initialized
INFO - 2021-07-16 09:33:34 --> Loader Class Initialized
INFO - 2021-07-16 09:33:34 --> Helper loaded: url_helper
INFO - 2021-07-16 09:33:34 --> Helper loaded: file_helper
INFO - 2021-07-16 09:33:34 --> Helper loaded: form_helper
INFO - 2021-07-16 09:33:34 --> Helper loaded: my_helper
INFO - 2021-07-16 09:33:34 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:33:34 --> Controller Class Initialized
DEBUG - 2021-07-16 09:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 09:33:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:33:35 --> Final output sent to browser
DEBUG - 2021-07-16 09:33:35 --> Total execution time: 0.7367
INFO - 2021-07-16 09:33:38 --> Config Class Initialized
INFO - 2021-07-16 09:33:38 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:33:38 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:33:38 --> Utf8 Class Initialized
INFO - 2021-07-16 09:33:38 --> URI Class Initialized
INFO - 2021-07-16 09:33:38 --> Router Class Initialized
INFO - 2021-07-16 09:33:38 --> Output Class Initialized
INFO - 2021-07-16 09:33:38 --> Security Class Initialized
DEBUG - 2021-07-16 09:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:33:38 --> Input Class Initialized
INFO - 2021-07-16 09:33:38 --> Language Class Initialized
INFO - 2021-07-16 09:33:38 --> Language Class Initialized
INFO - 2021-07-16 09:33:38 --> Config Class Initialized
INFO - 2021-07-16 09:33:38 --> Loader Class Initialized
INFO - 2021-07-16 09:33:38 --> Helper loaded: url_helper
INFO - 2021-07-16 09:33:38 --> Helper loaded: file_helper
INFO - 2021-07-16 09:33:38 --> Helper loaded: form_helper
INFO - 2021-07-16 09:33:38 --> Helper loaded: my_helper
INFO - 2021-07-16 09:33:38 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:33:38 --> Controller Class Initialized
DEBUG - 2021-07-16 09:33:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:33:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:33:38 --> Final output sent to browser
DEBUG - 2021-07-16 09:33:38 --> Total execution time: 0.0853
INFO - 2021-07-16 09:37:03 --> Config Class Initialized
INFO - 2021-07-16 09:37:03 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:37:03 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:37:03 --> Utf8 Class Initialized
INFO - 2021-07-16 09:37:03 --> URI Class Initialized
INFO - 2021-07-16 09:37:03 --> Router Class Initialized
INFO - 2021-07-16 09:37:03 --> Output Class Initialized
INFO - 2021-07-16 09:37:03 --> Security Class Initialized
DEBUG - 2021-07-16 09:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:37:03 --> Input Class Initialized
INFO - 2021-07-16 09:37:03 --> Language Class Initialized
INFO - 2021-07-16 09:37:03 --> Language Class Initialized
INFO - 2021-07-16 09:37:03 --> Config Class Initialized
INFO - 2021-07-16 09:37:03 --> Loader Class Initialized
INFO - 2021-07-16 09:37:03 --> Helper loaded: url_helper
INFO - 2021-07-16 09:37:03 --> Helper loaded: file_helper
INFO - 2021-07-16 09:37:03 --> Helper loaded: form_helper
INFO - 2021-07-16 09:37:03 --> Helper loaded: my_helper
INFO - 2021-07-16 09:37:03 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:37:03 --> Controller Class Initialized
DEBUG - 2021-07-16 09:37:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-16 09:37:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:37:03 --> Final output sent to browser
DEBUG - 2021-07-16 09:37:03 --> Total execution time: 0.0696
INFO - 2021-07-16 09:37:05 --> Config Class Initialized
INFO - 2021-07-16 09:37:05 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:37:05 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:37:05 --> Utf8 Class Initialized
INFO - 2021-07-16 09:37:05 --> URI Class Initialized
INFO - 2021-07-16 09:37:05 --> Router Class Initialized
INFO - 2021-07-16 09:37:05 --> Output Class Initialized
INFO - 2021-07-16 09:37:05 --> Security Class Initialized
DEBUG - 2021-07-16 09:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:37:05 --> Input Class Initialized
INFO - 2021-07-16 09:37:05 --> Language Class Initialized
INFO - 2021-07-16 09:37:05 --> Language Class Initialized
INFO - 2021-07-16 09:37:05 --> Config Class Initialized
INFO - 2021-07-16 09:37:05 --> Loader Class Initialized
INFO - 2021-07-16 09:37:05 --> Helper loaded: url_helper
INFO - 2021-07-16 09:37:05 --> Helper loaded: file_helper
INFO - 2021-07-16 09:37:05 --> Helper loaded: form_helper
INFO - 2021-07-16 09:37:05 --> Helper loaded: my_helper
INFO - 2021-07-16 09:37:05 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:37:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:37:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:37:05 --> Controller Class Initialized
DEBUG - 2021-07-16 09:37:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_c_akademik/views/list.php
DEBUG - 2021-07-16 09:37:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:37:05 --> Final output sent to browser
DEBUG - 2021-07-16 09:37:05 --> Total execution time: 0.0803
INFO - 2021-07-16 09:39:59 --> Config Class Initialized
INFO - 2021-07-16 09:39:59 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:39:59 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:39:59 --> Utf8 Class Initialized
INFO - 2021-07-16 09:39:59 --> URI Class Initialized
INFO - 2021-07-16 09:39:59 --> Router Class Initialized
INFO - 2021-07-16 09:39:59 --> Output Class Initialized
INFO - 2021-07-16 09:39:59 --> Security Class Initialized
DEBUG - 2021-07-16 09:39:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:39:59 --> Input Class Initialized
INFO - 2021-07-16 09:39:59 --> Language Class Initialized
INFO - 2021-07-16 09:39:59 --> Language Class Initialized
INFO - 2021-07-16 09:39:59 --> Config Class Initialized
INFO - 2021-07-16 09:39:59 --> Loader Class Initialized
INFO - 2021-07-16 09:39:59 --> Helper loaded: url_helper
INFO - 2021-07-16 09:39:59 --> Helper loaded: file_helper
INFO - 2021-07-16 09:39:59 --> Helper loaded: form_helper
INFO - 2021-07-16 09:39:59 --> Helper loaded: my_helper
INFO - 2021-07-16 09:39:59 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:39:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:39:59 --> Controller Class Initialized
INFO - 2021-07-16 09:39:59 --> Final output sent to browser
DEBUG - 2021-07-16 09:39:59 --> Total execution time: 0.1407
INFO - 2021-07-16 09:40:04 --> Config Class Initialized
INFO - 2021-07-16 09:40:04 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:40:04 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:40:04 --> Utf8 Class Initialized
INFO - 2021-07-16 09:40:04 --> URI Class Initialized
INFO - 2021-07-16 09:40:04 --> Router Class Initialized
INFO - 2021-07-16 09:40:04 --> Output Class Initialized
INFO - 2021-07-16 09:40:04 --> Security Class Initialized
DEBUG - 2021-07-16 09:40:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:40:04 --> Input Class Initialized
INFO - 2021-07-16 09:40:04 --> Language Class Initialized
INFO - 2021-07-16 09:40:04 --> Language Class Initialized
INFO - 2021-07-16 09:40:04 --> Config Class Initialized
INFO - 2021-07-16 09:40:04 --> Loader Class Initialized
INFO - 2021-07-16 09:40:04 --> Helper loaded: url_helper
INFO - 2021-07-16 09:40:04 --> Helper loaded: file_helper
INFO - 2021-07-16 09:40:04 --> Helper loaded: form_helper
INFO - 2021-07-16 09:40:04 --> Helper loaded: my_helper
INFO - 2021-07-16 09:40:04 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:40:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:40:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:40:04 --> Controller Class Initialized
DEBUG - 2021-07-16 09:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-07-16 09:40:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:40:04 --> Final output sent to browser
DEBUG - 2021-07-16 09:40:04 --> Total execution time: 0.0635
INFO - 2021-07-16 09:40:07 --> Config Class Initialized
INFO - 2021-07-16 09:40:07 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:40:07 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:40:07 --> Utf8 Class Initialized
INFO - 2021-07-16 09:40:07 --> URI Class Initialized
INFO - 2021-07-16 09:40:07 --> Router Class Initialized
INFO - 2021-07-16 09:40:07 --> Output Class Initialized
INFO - 2021-07-16 09:40:07 --> Security Class Initialized
DEBUG - 2021-07-16 09:40:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:40:07 --> Input Class Initialized
INFO - 2021-07-16 09:40:07 --> Language Class Initialized
INFO - 2021-07-16 09:40:07 --> Language Class Initialized
INFO - 2021-07-16 09:40:07 --> Config Class Initialized
INFO - 2021-07-16 09:40:07 --> Loader Class Initialized
INFO - 2021-07-16 09:40:07 --> Helper loaded: url_helper
INFO - 2021-07-16 09:40:07 --> Helper loaded: file_helper
INFO - 2021-07-16 09:40:07 --> Helper loaded: form_helper
INFO - 2021-07-16 09:40:07 --> Helper loaded: my_helper
INFO - 2021-07-16 09:40:07 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:40:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:40:07 --> Controller Class Initialized
DEBUG - 2021-07-16 09:40:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 09:40:07 --> Final output sent to browser
DEBUG - 2021-07-16 09:40:07 --> Total execution time: 0.1732
INFO - 2021-07-16 09:40:21 --> Config Class Initialized
INFO - 2021-07-16 09:40:21 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:40:21 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:40:21 --> Utf8 Class Initialized
INFO - 2021-07-16 09:40:21 --> URI Class Initialized
INFO - 2021-07-16 09:40:21 --> Router Class Initialized
INFO - 2021-07-16 09:40:21 --> Output Class Initialized
INFO - 2021-07-16 09:40:21 --> Security Class Initialized
DEBUG - 2021-07-16 09:40:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:40:21 --> Input Class Initialized
INFO - 2021-07-16 09:40:21 --> Language Class Initialized
INFO - 2021-07-16 09:40:21 --> Language Class Initialized
INFO - 2021-07-16 09:40:21 --> Config Class Initialized
INFO - 2021-07-16 09:40:21 --> Loader Class Initialized
INFO - 2021-07-16 09:40:21 --> Helper loaded: url_helper
INFO - 2021-07-16 09:40:21 --> Helper loaded: file_helper
INFO - 2021-07-16 09:40:21 --> Helper loaded: form_helper
INFO - 2021-07-16 09:40:21 --> Helper loaded: my_helper
INFO - 2021-07-16 09:40:21 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:40:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:40:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:40:21 --> Controller Class Initialized
DEBUG - 2021-07-16 09:40:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkj_xii.php
INFO - 2021-07-16 09:40:21 --> Final output sent to browser
DEBUG - 2021-07-16 09:40:21 --> Total execution time: 0.1337
INFO - 2021-07-16 09:43:35 --> Config Class Initialized
INFO - 2021-07-16 09:43:35 --> Hooks Class Initialized
DEBUG - 2021-07-16 09:43:35 --> UTF-8 Support Enabled
INFO - 2021-07-16 09:43:35 --> Utf8 Class Initialized
INFO - 2021-07-16 09:43:35 --> URI Class Initialized
INFO - 2021-07-16 09:43:35 --> Router Class Initialized
INFO - 2021-07-16 09:43:35 --> Output Class Initialized
INFO - 2021-07-16 09:43:35 --> Security Class Initialized
DEBUG - 2021-07-16 09:43:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 09:43:35 --> Input Class Initialized
INFO - 2021-07-16 09:43:35 --> Language Class Initialized
INFO - 2021-07-16 09:43:35 --> Language Class Initialized
INFO - 2021-07-16 09:43:35 --> Config Class Initialized
INFO - 2021-07-16 09:43:35 --> Loader Class Initialized
INFO - 2021-07-16 09:43:35 --> Helper loaded: url_helper
INFO - 2021-07-16 09:43:35 --> Helper loaded: file_helper
INFO - 2021-07-16 09:43:35 --> Helper loaded: form_helper
INFO - 2021-07-16 09:43:35 --> Helper loaded: my_helper
INFO - 2021-07-16 09:43:35 --> Database Driver Class Initialized
DEBUG - 2021-07-16 09:43:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 09:43:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 09:43:35 --> Controller Class Initialized
DEBUG - 2021-07-16 09:43:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-07-16 09:43:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 09:43:35 --> Final output sent to browser
DEBUG - 2021-07-16 09:43:35 --> Total execution time: 0.0483
INFO - 2021-07-16 10:01:49 --> Config Class Initialized
INFO - 2021-07-16 10:01:49 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:01:49 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:01:49 --> Utf8 Class Initialized
INFO - 2021-07-16 10:01:49 --> URI Class Initialized
INFO - 2021-07-16 10:01:49 --> Router Class Initialized
INFO - 2021-07-16 10:01:49 --> Output Class Initialized
INFO - 2021-07-16 10:01:49 --> Security Class Initialized
DEBUG - 2021-07-16 10:01:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:01:49 --> Input Class Initialized
INFO - 2021-07-16 10:01:49 --> Language Class Initialized
INFO - 2021-07-16 10:01:49 --> Language Class Initialized
INFO - 2021-07-16 10:01:49 --> Config Class Initialized
INFO - 2021-07-16 10:01:49 --> Loader Class Initialized
INFO - 2021-07-16 10:01:49 --> Helper loaded: url_helper
INFO - 2021-07-16 10:01:49 --> Helper loaded: file_helper
INFO - 2021-07-16 10:01:49 --> Helper loaded: form_helper
INFO - 2021-07-16 10:01:49 --> Helper loaded: my_helper
INFO - 2021-07-16 10:01:49 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:01:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:01:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:01:49 --> Controller Class Initialized
INFO - 2021-07-16 10:01:49 --> Helper loaded: cookie_helper
INFO - 2021-07-16 10:01:49 --> Final output sent to browser
DEBUG - 2021-07-16 10:01:49 --> Total execution time: 0.0469
INFO - 2021-07-16 10:01:50 --> Config Class Initialized
INFO - 2021-07-16 10:01:50 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:01:50 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:01:50 --> Utf8 Class Initialized
INFO - 2021-07-16 10:01:50 --> URI Class Initialized
INFO - 2021-07-16 10:01:50 --> Router Class Initialized
INFO - 2021-07-16 10:01:50 --> Output Class Initialized
INFO - 2021-07-16 10:01:50 --> Security Class Initialized
DEBUG - 2021-07-16 10:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:01:50 --> Input Class Initialized
INFO - 2021-07-16 10:01:50 --> Language Class Initialized
INFO - 2021-07-16 10:01:50 --> Language Class Initialized
INFO - 2021-07-16 10:01:50 --> Config Class Initialized
INFO - 2021-07-16 10:01:50 --> Loader Class Initialized
INFO - 2021-07-16 10:01:50 --> Helper loaded: url_helper
INFO - 2021-07-16 10:01:50 --> Helper loaded: file_helper
INFO - 2021-07-16 10:01:50 --> Helper loaded: form_helper
INFO - 2021-07-16 10:01:50 --> Helper loaded: my_helper
INFO - 2021-07-16 10:01:50 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:01:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:01:50 --> Controller Class Initialized
DEBUG - 2021-07-16 10:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-07-16 10:01:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 10:01:51 --> Final output sent to browser
DEBUG - 2021-07-16 10:01:51 --> Total execution time: 0.7317
INFO - 2021-07-16 10:02:01 --> Config Class Initialized
INFO - 2021-07-16 10:02:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:01 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:01 --> URI Class Initialized
INFO - 2021-07-16 10:02:01 --> Router Class Initialized
INFO - 2021-07-16 10:02:01 --> Output Class Initialized
INFO - 2021-07-16 10:02:01 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:01 --> Input Class Initialized
INFO - 2021-07-16 10:02:01 --> Language Class Initialized
INFO - 2021-07-16 10:02:01 --> Language Class Initialized
INFO - 2021-07-16 10:02:01 --> Config Class Initialized
INFO - 2021-07-16 10:02:01 --> Loader Class Initialized
INFO - 2021-07-16 10:02:01 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:01 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:01 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:01 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:01 --> Controller Class Initialized
DEBUG - 2021-07-16 10:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 10:02:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 10:02:01 --> Final output sent to browser
DEBUG - 2021-07-16 10:02:01 --> Total execution time: 0.0578
INFO - 2021-07-16 10:02:01 --> Config Class Initialized
INFO - 2021-07-16 10:02:01 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:01 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:01 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:01 --> URI Class Initialized
INFO - 2021-07-16 10:02:01 --> Router Class Initialized
INFO - 2021-07-16 10:02:01 --> Output Class Initialized
INFO - 2021-07-16 10:02:01 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:01 --> Input Class Initialized
INFO - 2021-07-16 10:02:01 --> Language Class Initialized
INFO - 2021-07-16 10:02:01 --> Language Class Initialized
INFO - 2021-07-16 10:02:01 --> Config Class Initialized
INFO - 2021-07-16 10:02:01 --> Loader Class Initialized
INFO - 2021-07-16 10:02:01 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:01 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:01 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:01 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:01 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:01 --> Controller Class Initialized
INFO - 2021-07-16 10:02:10 --> Config Class Initialized
INFO - 2021-07-16 10:02:10 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:10 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:10 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:10 --> URI Class Initialized
INFO - 2021-07-16 10:02:10 --> Router Class Initialized
INFO - 2021-07-16 10:02:10 --> Output Class Initialized
INFO - 2021-07-16 10:02:10 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:10 --> Input Class Initialized
INFO - 2021-07-16 10:02:10 --> Language Class Initialized
INFO - 2021-07-16 10:02:10 --> Language Class Initialized
INFO - 2021-07-16 10:02:10 --> Config Class Initialized
INFO - 2021-07-16 10:02:10 --> Loader Class Initialized
INFO - 2021-07-16 10:02:10 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:10 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:10 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:10 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:10 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:10 --> Controller Class Initialized
INFO - 2021-07-16 10:02:11 --> Config Class Initialized
INFO - 2021-07-16 10:02:11 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:11 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:11 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:11 --> URI Class Initialized
INFO - 2021-07-16 10:02:11 --> Router Class Initialized
INFO - 2021-07-16 10:02:11 --> Output Class Initialized
INFO - 2021-07-16 10:02:11 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:11 --> Input Class Initialized
INFO - 2021-07-16 10:02:11 --> Language Class Initialized
INFO - 2021-07-16 10:02:11 --> Language Class Initialized
INFO - 2021-07-16 10:02:11 --> Config Class Initialized
INFO - 2021-07-16 10:02:11 --> Loader Class Initialized
INFO - 2021-07-16 10:02:11 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:11 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:11 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:11 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:11 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:11 --> Controller Class Initialized
ERROR - 2021-07-16 10:02:11 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 10:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 10:02:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 10:02:11 --> Final output sent to browser
DEBUG - 2021-07-16 10:02:11 --> Total execution time: 0.0720
INFO - 2021-07-16 10:02:13 --> Config Class Initialized
INFO - 2021-07-16 10:02:13 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:13 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:13 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:13 --> URI Class Initialized
INFO - 2021-07-16 10:02:13 --> Router Class Initialized
INFO - 2021-07-16 10:02:13 --> Output Class Initialized
INFO - 2021-07-16 10:02:13 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:13 --> Input Class Initialized
INFO - 2021-07-16 10:02:13 --> Language Class Initialized
INFO - 2021-07-16 10:02:13 --> Language Class Initialized
INFO - 2021-07-16 10:02:13 --> Config Class Initialized
INFO - 2021-07-16 10:02:13 --> Loader Class Initialized
INFO - 2021-07-16 10:02:13 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:13 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:13 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:13 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:13 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:13 --> Controller Class Initialized
DEBUG - 2021-07-16 10:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 10:02:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 10:02:13 --> Final output sent to browser
DEBUG - 2021-07-16 10:02:13 --> Total execution time: 0.0693
INFO - 2021-07-16 10:02:14 --> Config Class Initialized
INFO - 2021-07-16 10:02:14 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:14 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:14 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:14 --> URI Class Initialized
INFO - 2021-07-16 10:02:14 --> Router Class Initialized
INFO - 2021-07-16 10:02:14 --> Output Class Initialized
INFO - 2021-07-16 10:02:14 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:14 --> Input Class Initialized
INFO - 2021-07-16 10:02:14 --> Language Class Initialized
INFO - 2021-07-16 10:02:14 --> Language Class Initialized
INFO - 2021-07-16 10:02:14 --> Config Class Initialized
INFO - 2021-07-16 10:02:14 --> Loader Class Initialized
INFO - 2021-07-16 10:02:14 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:14 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:14 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:14 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:14 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:14 --> Controller Class Initialized
INFO - 2021-07-16 10:02:24 --> Config Class Initialized
INFO - 2021-07-16 10:02:24 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:24 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:24 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:24 --> URI Class Initialized
INFO - 2021-07-16 10:02:24 --> Router Class Initialized
INFO - 2021-07-16 10:02:24 --> Output Class Initialized
INFO - 2021-07-16 10:02:24 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:24 --> Input Class Initialized
INFO - 2021-07-16 10:02:24 --> Language Class Initialized
INFO - 2021-07-16 10:02:24 --> Language Class Initialized
INFO - 2021-07-16 10:02:24 --> Config Class Initialized
INFO - 2021-07-16 10:02:24 --> Loader Class Initialized
INFO - 2021-07-16 10:02:24 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:24 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:24 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:24 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:24 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:24 --> Controller Class Initialized
INFO - 2021-07-16 10:02:25 --> Config Class Initialized
INFO - 2021-07-16 10:02:25 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:25 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:25 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:25 --> URI Class Initialized
INFO - 2021-07-16 10:02:25 --> Router Class Initialized
INFO - 2021-07-16 10:02:25 --> Output Class Initialized
INFO - 2021-07-16 10:02:25 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:25 --> Input Class Initialized
INFO - 2021-07-16 10:02:25 --> Language Class Initialized
INFO - 2021-07-16 10:02:25 --> Language Class Initialized
INFO - 2021-07-16 10:02:25 --> Config Class Initialized
INFO - 2021-07-16 10:02:25 --> Loader Class Initialized
INFO - 2021-07-16 10:02:25 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:25 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:25 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:25 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:25 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:25 --> Controller Class Initialized
ERROR - 2021-07-16 10:02:25 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2021-07-16 10:02:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2021-07-16 10:02:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 10:02:25 --> Final output sent to browser
DEBUG - 2021-07-16 10:02:25 --> Total execution time: 0.0594
INFO - 2021-07-16 10:02:36 --> Config Class Initialized
INFO - 2021-07-16 10:02:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:36 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:36 --> URI Class Initialized
INFO - 2021-07-16 10:02:36 --> Router Class Initialized
INFO - 2021-07-16 10:02:36 --> Output Class Initialized
INFO - 2021-07-16 10:02:36 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:36 --> Input Class Initialized
INFO - 2021-07-16 10:02:36 --> Language Class Initialized
INFO - 2021-07-16 10:02:36 --> Language Class Initialized
INFO - 2021-07-16 10:02:36 --> Config Class Initialized
INFO - 2021-07-16 10:02:36 --> Loader Class Initialized
INFO - 2021-07-16 10:02:36 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:36 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:36 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:36 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:36 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:36 --> Controller Class Initialized
INFO - 2021-07-16 10:02:36 --> Upload Class Initialized
INFO - 2021-07-16 10:02:36 --> Language file loaded: language/english/upload_lang.php
ERROR - 2021-07-16 10:02:36 --> The upload path does not appear to be valid.
INFO - 2021-07-16 10:02:36 --> Config Class Initialized
INFO - 2021-07-16 10:02:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:36 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:36 --> URI Class Initialized
INFO - 2021-07-16 10:02:36 --> Router Class Initialized
INFO - 2021-07-16 10:02:36 --> Output Class Initialized
INFO - 2021-07-16 10:02:36 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:36 --> Input Class Initialized
INFO - 2021-07-16 10:02:36 --> Language Class Initialized
INFO - 2021-07-16 10:02:36 --> Language Class Initialized
INFO - 2021-07-16 10:02:36 --> Config Class Initialized
INFO - 2021-07-16 10:02:36 --> Loader Class Initialized
INFO - 2021-07-16 10:02:36 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:36 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:36 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:36 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:36 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:36 --> Controller Class Initialized
DEBUG - 2021-07-16 10:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2021-07-16 10:02:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-07-16 10:02:36 --> Final output sent to browser
DEBUG - 2021-07-16 10:02:36 --> Total execution time: 0.0440
INFO - 2021-07-16 10:02:36 --> Config Class Initialized
INFO - 2021-07-16 10:02:36 --> Hooks Class Initialized
DEBUG - 2021-07-16 10:02:36 --> UTF-8 Support Enabled
INFO - 2021-07-16 10:02:36 --> Utf8 Class Initialized
INFO - 2021-07-16 10:02:36 --> URI Class Initialized
INFO - 2021-07-16 10:02:36 --> Router Class Initialized
INFO - 2021-07-16 10:02:36 --> Output Class Initialized
INFO - 2021-07-16 10:02:36 --> Security Class Initialized
DEBUG - 2021-07-16 10:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-07-16 10:02:36 --> Input Class Initialized
INFO - 2021-07-16 10:02:36 --> Language Class Initialized
INFO - 2021-07-16 10:02:36 --> Language Class Initialized
INFO - 2021-07-16 10:02:36 --> Config Class Initialized
INFO - 2021-07-16 10:02:36 --> Loader Class Initialized
INFO - 2021-07-16 10:02:37 --> Helper loaded: url_helper
INFO - 2021-07-16 10:02:37 --> Helper loaded: file_helper
INFO - 2021-07-16 10:02:37 --> Helper loaded: form_helper
INFO - 2021-07-16 10:02:37 --> Helper loaded: my_helper
INFO - 2021-07-16 10:02:37 --> Database Driver Class Initialized
DEBUG - 2021-07-16 10:02:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-07-16 10:02:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-07-16 10:02:37 --> Controller Class Initialized
