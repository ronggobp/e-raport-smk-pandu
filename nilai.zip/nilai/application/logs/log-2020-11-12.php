<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-11-12 02:13:13 --> Config Class Initialized
INFO - 2020-11-12 02:13:13 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:13:13 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:13:13 --> Utf8 Class Initialized
INFO - 2020-11-12 02:13:13 --> URI Class Initialized
DEBUG - 2020-11-12 02:13:13 --> No URI present. Default controller set.
INFO - 2020-11-12 02:13:13 --> Router Class Initialized
INFO - 2020-11-12 02:13:13 --> Output Class Initialized
INFO - 2020-11-12 02:13:13 --> Security Class Initialized
DEBUG - 2020-11-12 02:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:13:13 --> Input Class Initialized
INFO - 2020-11-12 02:13:13 --> Language Class Initialized
INFO - 2020-11-12 02:13:13 --> Language Class Initialized
INFO - 2020-11-12 02:13:13 --> Config Class Initialized
INFO - 2020-11-12 02:13:13 --> Loader Class Initialized
INFO - 2020-11-12 02:13:13 --> Helper loaded: url_helper
INFO - 2020-11-12 02:13:13 --> Helper loaded: file_helper
INFO - 2020-11-12 02:13:13 --> Helper loaded: form_helper
INFO - 2020-11-12 02:13:13 --> Helper loaded: my_helper
INFO - 2020-11-12 02:13:13 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:13:13 --> Controller Class Initialized
INFO - 2020-11-12 02:13:13 --> Config Class Initialized
INFO - 2020-11-12 02:13:13 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:13:13 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:13:14 --> Utf8 Class Initialized
INFO - 2020-11-12 02:13:14 --> URI Class Initialized
INFO - 2020-11-12 02:13:14 --> Router Class Initialized
INFO - 2020-11-12 02:13:14 --> Output Class Initialized
INFO - 2020-11-12 02:13:14 --> Security Class Initialized
DEBUG - 2020-11-12 02:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:13:14 --> Input Class Initialized
INFO - 2020-11-12 02:13:14 --> Language Class Initialized
INFO - 2020-11-12 02:13:14 --> Language Class Initialized
INFO - 2020-11-12 02:13:14 --> Config Class Initialized
INFO - 2020-11-12 02:13:14 --> Loader Class Initialized
INFO - 2020-11-12 02:13:14 --> Helper loaded: url_helper
INFO - 2020-11-12 02:13:14 --> Helper loaded: file_helper
INFO - 2020-11-12 02:13:14 --> Helper loaded: form_helper
INFO - 2020-11-12 02:13:14 --> Helper loaded: my_helper
INFO - 2020-11-12 02:13:14 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:13:14 --> Controller Class Initialized
DEBUG - 2020-11-12 02:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-12 02:13:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:13:14 --> Final output sent to browser
DEBUG - 2020-11-12 02:13:14 --> Total execution time: 0.2728
INFO - 2020-11-12 02:13:20 --> Config Class Initialized
INFO - 2020-11-12 02:13:20 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:13:20 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:13:20 --> Utf8 Class Initialized
INFO - 2020-11-12 02:13:20 --> URI Class Initialized
INFO - 2020-11-12 02:13:20 --> Router Class Initialized
INFO - 2020-11-12 02:13:20 --> Output Class Initialized
INFO - 2020-11-12 02:13:20 --> Security Class Initialized
DEBUG - 2020-11-12 02:13:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:13:20 --> Input Class Initialized
INFO - 2020-11-12 02:13:20 --> Language Class Initialized
INFO - 2020-11-12 02:13:20 --> Language Class Initialized
INFO - 2020-11-12 02:13:20 --> Config Class Initialized
INFO - 2020-11-12 02:13:20 --> Loader Class Initialized
INFO - 2020-11-12 02:13:20 --> Helper loaded: url_helper
INFO - 2020-11-12 02:13:20 --> Helper loaded: file_helper
INFO - 2020-11-12 02:13:20 --> Helper loaded: form_helper
INFO - 2020-11-12 02:13:20 --> Helper loaded: my_helper
INFO - 2020-11-12 02:13:20 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:13:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:13:20 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:13:20 --> Controller Class Initialized
INFO - 2020-11-12 02:13:20 --> Helper loaded: cookie_helper
INFO - 2020-11-12 02:13:20 --> Final output sent to browser
DEBUG - 2020-11-12 02:13:20 --> Total execution time: 0.3200
INFO - 2020-11-12 02:13:21 --> Config Class Initialized
INFO - 2020-11-12 02:13:21 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:13:21 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:13:21 --> Utf8 Class Initialized
INFO - 2020-11-12 02:13:21 --> URI Class Initialized
INFO - 2020-11-12 02:13:21 --> Router Class Initialized
INFO - 2020-11-12 02:13:21 --> Output Class Initialized
INFO - 2020-11-12 02:13:21 --> Security Class Initialized
DEBUG - 2020-11-12 02:13:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:13:21 --> Input Class Initialized
INFO - 2020-11-12 02:13:21 --> Language Class Initialized
INFO - 2020-11-12 02:13:21 --> Language Class Initialized
INFO - 2020-11-12 02:13:21 --> Config Class Initialized
INFO - 2020-11-12 02:13:21 --> Loader Class Initialized
INFO - 2020-11-12 02:13:21 --> Helper loaded: url_helper
INFO - 2020-11-12 02:13:21 --> Helper loaded: file_helper
INFO - 2020-11-12 02:13:21 --> Helper loaded: form_helper
INFO - 2020-11-12 02:13:21 --> Helper loaded: my_helper
INFO - 2020-11-12 02:13:21 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:13:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:13:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:13:22 --> Controller Class Initialized
DEBUG - 2020-11-12 02:13:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-12 02:13:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:13:22 --> Final output sent to browser
DEBUG - 2020-11-12 02:13:22 --> Total execution time: 0.3958
INFO - 2020-11-12 02:14:00 --> Config Class Initialized
INFO - 2020-11-12 02:14:00 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:00 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:00 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:00 --> URI Class Initialized
INFO - 2020-11-12 02:14:00 --> Router Class Initialized
INFO - 2020-11-12 02:14:00 --> Output Class Initialized
INFO - 2020-11-12 02:14:00 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:00 --> Input Class Initialized
INFO - 2020-11-12 02:14:00 --> Language Class Initialized
INFO - 2020-11-12 02:14:00 --> Language Class Initialized
INFO - 2020-11-12 02:14:00 --> Config Class Initialized
INFO - 2020-11-12 02:14:00 --> Loader Class Initialized
INFO - 2020-11-12 02:14:00 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:00 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:00 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:00 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:00 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:00 --> Controller Class Initialized
INFO - 2020-11-12 02:14:00 --> Helper loaded: cookie_helper
INFO - 2020-11-12 02:14:00 --> Config Class Initialized
INFO - 2020-11-12 02:14:00 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:01 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:01 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:01 --> URI Class Initialized
INFO - 2020-11-12 02:14:01 --> Router Class Initialized
INFO - 2020-11-12 02:14:01 --> Output Class Initialized
INFO - 2020-11-12 02:14:01 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:01 --> Input Class Initialized
INFO - 2020-11-12 02:14:01 --> Language Class Initialized
INFO - 2020-11-12 02:14:01 --> Language Class Initialized
INFO - 2020-11-12 02:14:01 --> Config Class Initialized
INFO - 2020-11-12 02:14:01 --> Loader Class Initialized
INFO - 2020-11-12 02:14:01 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:01 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:01 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:01 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:01 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:01 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-12 02:14:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:01 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:01 --> Total execution time: 0.2568
INFO - 2020-11-12 02:14:07 --> Config Class Initialized
INFO - 2020-11-12 02:14:07 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:07 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:07 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:07 --> URI Class Initialized
INFO - 2020-11-12 02:14:07 --> Router Class Initialized
INFO - 2020-11-12 02:14:07 --> Output Class Initialized
INFO - 2020-11-12 02:14:07 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:07 --> Input Class Initialized
INFO - 2020-11-12 02:14:07 --> Language Class Initialized
INFO - 2020-11-12 02:14:07 --> Language Class Initialized
INFO - 2020-11-12 02:14:07 --> Config Class Initialized
INFO - 2020-11-12 02:14:07 --> Loader Class Initialized
INFO - 2020-11-12 02:14:07 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:07 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:07 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:07 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:07 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:07 --> Controller Class Initialized
INFO - 2020-11-12 02:14:07 --> Helper loaded: cookie_helper
INFO - 2020-11-12 02:14:07 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:07 --> Total execution time: 0.2790
INFO - 2020-11-12 02:14:08 --> Config Class Initialized
INFO - 2020-11-12 02:14:08 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:08 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:08 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:08 --> URI Class Initialized
INFO - 2020-11-12 02:14:08 --> Router Class Initialized
INFO - 2020-11-12 02:14:08 --> Output Class Initialized
INFO - 2020-11-12 02:14:08 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:08 --> Input Class Initialized
INFO - 2020-11-12 02:14:09 --> Language Class Initialized
INFO - 2020-11-12 02:14:09 --> Language Class Initialized
INFO - 2020-11-12 02:14:09 --> Config Class Initialized
INFO - 2020-11-12 02:14:09 --> Loader Class Initialized
INFO - 2020-11-12 02:14:09 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:09 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:09 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:09 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:09 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:09 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-12 02:14:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:09 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:09 --> Total execution time: 0.2999
INFO - 2020-11-12 02:14:12 --> Config Class Initialized
INFO - 2020-11-12 02:14:12 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:12 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:12 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:12 --> URI Class Initialized
INFO - 2020-11-12 02:14:12 --> Router Class Initialized
INFO - 2020-11-12 02:14:12 --> Output Class Initialized
INFO - 2020-11-12 02:14:12 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:12 --> Input Class Initialized
INFO - 2020-11-12 02:14:12 --> Language Class Initialized
INFO - 2020-11-12 02:14:12 --> Language Class Initialized
INFO - 2020-11-12 02:14:12 --> Config Class Initialized
INFO - 2020-11-12 02:14:12 --> Loader Class Initialized
INFO - 2020-11-12 02:14:12 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:12 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:12 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:12 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:12 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:12 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:14:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:12 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:12 --> Total execution time: 0.3014
INFO - 2020-11-12 02:14:13 --> Config Class Initialized
INFO - 2020-11-12 02:14:13 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:13 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:13 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:13 --> URI Class Initialized
INFO - 2020-11-12 02:14:13 --> Router Class Initialized
INFO - 2020-11-12 02:14:13 --> Output Class Initialized
INFO - 2020-11-12 02:14:13 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:13 --> Input Class Initialized
INFO - 2020-11-12 02:14:13 --> Language Class Initialized
INFO - 2020-11-12 02:14:13 --> Language Class Initialized
INFO - 2020-11-12 02:14:13 --> Config Class Initialized
INFO - 2020-11-12 02:14:13 --> Loader Class Initialized
INFO - 2020-11-12 02:14:13 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:13 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:13 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:13 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:13 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:13 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:13 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-12 02:14:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:13 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:13 --> Total execution time: 0.2815
INFO - 2020-11-12 02:14:13 --> Config Class Initialized
INFO - 2020-11-12 02:14:13 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:13 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:13 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:13 --> URI Class Initialized
INFO - 2020-11-12 02:14:13 --> Router Class Initialized
INFO - 2020-11-12 02:14:14 --> Output Class Initialized
INFO - 2020-11-12 02:14:14 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:14 --> Input Class Initialized
INFO - 2020-11-12 02:14:14 --> Language Class Initialized
INFO - 2020-11-12 02:14:14 --> Language Class Initialized
INFO - 2020-11-12 02:14:14 --> Config Class Initialized
INFO - 2020-11-12 02:14:14 --> Loader Class Initialized
INFO - 2020-11-12 02:14:14 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:14 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:14 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:14 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:14 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:14 --> Controller Class Initialized
INFO - 2020-11-12 02:14:15 --> Config Class Initialized
INFO - 2020-11-12 02:14:15 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:15 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:15 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:15 --> URI Class Initialized
INFO - 2020-11-12 02:14:15 --> Router Class Initialized
INFO - 2020-11-12 02:14:15 --> Output Class Initialized
INFO - 2020-11-12 02:14:15 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:15 --> Input Class Initialized
INFO - 2020-11-12 02:14:15 --> Language Class Initialized
INFO - 2020-11-12 02:14:15 --> Language Class Initialized
INFO - 2020-11-12 02:14:15 --> Config Class Initialized
INFO - 2020-11-12 02:14:15 --> Loader Class Initialized
INFO - 2020-11-12 02:14:15 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:15 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:15 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:15 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:15 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:15 --> Controller Class Initialized
INFO - 2020-11-12 02:14:15 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:15 --> Total execution time: 0.2286
INFO - 2020-11-12 02:14:22 --> Config Class Initialized
INFO - 2020-11-12 02:14:22 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:22 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:22 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:22 --> URI Class Initialized
INFO - 2020-11-12 02:14:22 --> Router Class Initialized
INFO - 2020-11-12 02:14:22 --> Output Class Initialized
INFO - 2020-11-12 02:14:22 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:22 --> Input Class Initialized
INFO - 2020-11-12 02:14:22 --> Language Class Initialized
INFO - 2020-11-12 02:14:22 --> Language Class Initialized
INFO - 2020-11-12 02:14:22 --> Config Class Initialized
INFO - 2020-11-12 02:14:22 --> Loader Class Initialized
INFO - 2020-11-12 02:14:22 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:22 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:22 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:22 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:22 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:22 --> Controller Class Initialized
INFO - 2020-11-12 02:14:22 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:22 --> Total execution time: 0.3150
INFO - 2020-11-12 02:14:25 --> Config Class Initialized
INFO - 2020-11-12 02:14:25 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:25 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:25 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:25 --> URI Class Initialized
INFO - 2020-11-12 02:14:25 --> Router Class Initialized
INFO - 2020-11-12 02:14:25 --> Output Class Initialized
INFO - 2020-11-12 02:14:25 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:25 --> Input Class Initialized
INFO - 2020-11-12 02:14:25 --> Language Class Initialized
INFO - 2020-11-12 02:14:25 --> Language Class Initialized
INFO - 2020-11-12 02:14:25 --> Config Class Initialized
INFO - 2020-11-12 02:14:25 --> Loader Class Initialized
INFO - 2020-11-12 02:14:25 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:25 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:25 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:25 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:25 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:25 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-12 02:14:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:25 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:25 --> Total execution time: 0.2343
INFO - 2020-11-12 02:14:25 --> Config Class Initialized
INFO - 2020-11-12 02:14:25 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:25 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:25 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:25 --> URI Class Initialized
INFO - 2020-11-12 02:14:25 --> Router Class Initialized
INFO - 2020-11-12 02:14:25 --> Output Class Initialized
INFO - 2020-11-12 02:14:25 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:25 --> Input Class Initialized
INFO - 2020-11-12 02:14:25 --> Language Class Initialized
INFO - 2020-11-12 02:14:25 --> Language Class Initialized
INFO - 2020-11-12 02:14:25 --> Config Class Initialized
INFO - 2020-11-12 02:14:25 --> Loader Class Initialized
INFO - 2020-11-12 02:14:25 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:25 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:25 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:25 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:25 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:25 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:25 --> Controller Class Initialized
INFO - 2020-11-12 02:14:27 --> Config Class Initialized
INFO - 2020-11-12 02:14:27 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:27 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:27 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:27 --> URI Class Initialized
INFO - 2020-11-12 02:14:27 --> Router Class Initialized
INFO - 2020-11-12 02:14:27 --> Output Class Initialized
INFO - 2020-11-12 02:14:27 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:27 --> Input Class Initialized
INFO - 2020-11-12 02:14:27 --> Language Class Initialized
INFO - 2020-11-12 02:14:27 --> Language Class Initialized
INFO - 2020-11-12 02:14:27 --> Config Class Initialized
INFO - 2020-11-12 02:14:27 --> Loader Class Initialized
INFO - 2020-11-12 02:14:27 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:27 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:27 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:27 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:27 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:27 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:27 --> Controller Class Initialized
INFO - 2020-11-12 02:14:27 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:27 --> Total execution time: 0.2019
INFO - 2020-11-12 02:14:29 --> Config Class Initialized
INFO - 2020-11-12 02:14:29 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:29 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:29 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:29 --> URI Class Initialized
INFO - 2020-11-12 02:14:30 --> Router Class Initialized
INFO - 2020-11-12 02:14:30 --> Output Class Initialized
INFO - 2020-11-12 02:14:30 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:30 --> Input Class Initialized
INFO - 2020-11-12 02:14:30 --> Language Class Initialized
INFO - 2020-11-12 02:14:30 --> Language Class Initialized
INFO - 2020-11-12 02:14:30 --> Config Class Initialized
INFO - 2020-11-12 02:14:30 --> Loader Class Initialized
INFO - 2020-11-12 02:14:30 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:30 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:30 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:30 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:30 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:30 --> Controller Class Initialized
INFO - 2020-11-12 02:14:30 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:30 --> Total execution time: 0.2014
INFO - 2020-11-12 02:14:36 --> Config Class Initialized
INFO - 2020-11-12 02:14:36 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:36 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:36 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:36 --> URI Class Initialized
INFO - 2020-11-12 02:14:36 --> Router Class Initialized
INFO - 2020-11-12 02:14:36 --> Output Class Initialized
INFO - 2020-11-12 02:14:36 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:36 --> Input Class Initialized
INFO - 2020-11-12 02:14:36 --> Language Class Initialized
INFO - 2020-11-12 02:14:36 --> Language Class Initialized
INFO - 2020-11-12 02:14:36 --> Config Class Initialized
INFO - 2020-11-12 02:14:36 --> Loader Class Initialized
INFO - 2020-11-12 02:14:36 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:36 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:36 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:36 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:36 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:36 --> Controller Class Initialized
INFO - 2020-11-12 02:14:36 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:36 --> Total execution time: 0.3021
INFO - 2020-11-12 02:14:38 --> Config Class Initialized
INFO - 2020-11-12 02:14:38 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:38 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:38 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:38 --> URI Class Initialized
INFO - 2020-11-12 02:14:38 --> Router Class Initialized
INFO - 2020-11-12 02:14:38 --> Output Class Initialized
INFO - 2020-11-12 02:14:38 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:38 --> Input Class Initialized
INFO - 2020-11-12 02:14:38 --> Language Class Initialized
INFO - 2020-11-12 02:14:38 --> Language Class Initialized
INFO - 2020-11-12 02:14:38 --> Config Class Initialized
INFO - 2020-11-12 02:14:38 --> Loader Class Initialized
INFO - 2020-11-12 02:14:38 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:38 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:38 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:38 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:38 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:38 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-12 02:14:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:38 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:38 --> Total execution time: 0.3047
INFO - 2020-11-12 02:14:38 --> Config Class Initialized
INFO - 2020-11-12 02:14:38 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:38 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:38 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:38 --> URI Class Initialized
INFO - 2020-11-12 02:14:38 --> Router Class Initialized
INFO - 2020-11-12 02:14:38 --> Output Class Initialized
INFO - 2020-11-12 02:14:38 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:38 --> Input Class Initialized
INFO - 2020-11-12 02:14:38 --> Language Class Initialized
INFO - 2020-11-12 02:14:38 --> Language Class Initialized
INFO - 2020-11-12 02:14:38 --> Config Class Initialized
INFO - 2020-11-12 02:14:38 --> Loader Class Initialized
INFO - 2020-11-12 02:14:38 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:38 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:38 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:38 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:38 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:38 --> Controller Class Initialized
INFO - 2020-11-12 02:14:40 --> Config Class Initialized
INFO - 2020-11-12 02:14:40 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:40 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:40 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:40 --> URI Class Initialized
INFO - 2020-11-12 02:14:40 --> Router Class Initialized
INFO - 2020-11-12 02:14:40 --> Output Class Initialized
INFO - 2020-11-12 02:14:40 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:40 --> Input Class Initialized
INFO - 2020-11-12 02:14:40 --> Language Class Initialized
INFO - 2020-11-12 02:14:40 --> Language Class Initialized
INFO - 2020-11-12 02:14:40 --> Config Class Initialized
INFO - 2020-11-12 02:14:40 --> Loader Class Initialized
INFO - 2020-11-12 02:14:40 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:40 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:40 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:40 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:40 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:40 --> Controller Class Initialized
INFO - 2020-11-12 02:14:40 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:40 --> Total execution time: 0.2241
INFO - 2020-11-12 02:14:42 --> Config Class Initialized
INFO - 2020-11-12 02:14:42 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:42 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:42 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:42 --> URI Class Initialized
INFO - 2020-11-12 02:14:42 --> Router Class Initialized
INFO - 2020-11-12 02:14:42 --> Output Class Initialized
INFO - 2020-11-12 02:14:42 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:42 --> Input Class Initialized
INFO - 2020-11-12 02:14:42 --> Language Class Initialized
INFO - 2020-11-12 02:14:42 --> Language Class Initialized
INFO - 2020-11-12 02:14:42 --> Config Class Initialized
INFO - 2020-11-12 02:14:42 --> Loader Class Initialized
INFO - 2020-11-12 02:14:42 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:42 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:42 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:42 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:42 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:42 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:42 --> Controller Class Initialized
INFO - 2020-11-12 02:14:42 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:42 --> Total execution time: 0.2044
INFO - 2020-11-12 02:14:47 --> Config Class Initialized
INFO - 2020-11-12 02:14:47 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:47 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:47 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:47 --> URI Class Initialized
INFO - 2020-11-12 02:14:47 --> Router Class Initialized
INFO - 2020-11-12 02:14:47 --> Output Class Initialized
INFO - 2020-11-12 02:14:47 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:47 --> Input Class Initialized
INFO - 2020-11-12 02:14:47 --> Language Class Initialized
INFO - 2020-11-12 02:14:47 --> Language Class Initialized
INFO - 2020-11-12 02:14:47 --> Config Class Initialized
INFO - 2020-11-12 02:14:47 --> Loader Class Initialized
INFO - 2020-11-12 02:14:47 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:47 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:47 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:47 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:47 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:47 --> Controller Class Initialized
INFO - 2020-11-12 02:14:48 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:48 --> Total execution time: 0.3568
INFO - 2020-11-12 02:14:51 --> Config Class Initialized
INFO - 2020-11-12 02:14:51 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:51 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:51 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:51 --> URI Class Initialized
INFO - 2020-11-12 02:14:51 --> Router Class Initialized
INFO - 2020-11-12 02:14:51 --> Output Class Initialized
INFO - 2020-11-12 02:14:51 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:51 --> Input Class Initialized
INFO - 2020-11-12 02:14:51 --> Language Class Initialized
INFO - 2020-11-12 02:14:51 --> Language Class Initialized
INFO - 2020-11-12 02:14:51 --> Config Class Initialized
INFO - 2020-11-12 02:14:51 --> Loader Class Initialized
INFO - 2020-11-12 02:14:51 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:51 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:51 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:51 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:51 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:51 --> Controller Class Initialized
INFO - 2020-11-12 02:14:51 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:51 --> Total execution time: 0.2216
INFO - 2020-11-12 02:14:52 --> Config Class Initialized
INFO - 2020-11-12 02:14:52 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:52 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:52 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:52 --> URI Class Initialized
INFO - 2020-11-12 02:14:52 --> Router Class Initialized
INFO - 2020-11-12 02:14:52 --> Output Class Initialized
INFO - 2020-11-12 02:14:52 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:52 --> Input Class Initialized
INFO - 2020-11-12 02:14:52 --> Language Class Initialized
INFO - 2020-11-12 02:14:52 --> Language Class Initialized
INFO - 2020-11-12 02:14:52 --> Config Class Initialized
INFO - 2020-11-12 02:14:52 --> Loader Class Initialized
INFO - 2020-11-12 02:14:52 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:52 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:52 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:52 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:52 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:52 --> Controller Class Initialized
INFO - 2020-11-12 02:14:52 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:52 --> Total execution time: 0.1937
INFO - 2020-11-12 02:14:53 --> Config Class Initialized
INFO - 2020-11-12 02:14:53 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:53 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:53 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:53 --> URI Class Initialized
INFO - 2020-11-12 02:14:53 --> Router Class Initialized
INFO - 2020-11-12 02:14:53 --> Output Class Initialized
INFO - 2020-11-12 02:14:53 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:53 --> Input Class Initialized
INFO - 2020-11-12 02:14:53 --> Language Class Initialized
INFO - 2020-11-12 02:14:53 --> Language Class Initialized
INFO - 2020-11-12 02:14:53 --> Config Class Initialized
INFO - 2020-11-12 02:14:53 --> Loader Class Initialized
INFO - 2020-11-12 02:14:53 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:53 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:53 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:53 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:53 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:53 --> Controller Class Initialized
INFO - 2020-11-12 02:14:53 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:53 --> Total execution time: 0.2289
INFO - 2020-11-12 02:14:55 --> Config Class Initialized
INFO - 2020-11-12 02:14:55 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:55 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:55 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:55 --> URI Class Initialized
INFO - 2020-11-12 02:14:55 --> Router Class Initialized
INFO - 2020-11-12 02:14:55 --> Output Class Initialized
INFO - 2020-11-12 02:14:55 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:55 --> Input Class Initialized
INFO - 2020-11-12 02:14:55 --> Language Class Initialized
INFO - 2020-11-12 02:14:55 --> Language Class Initialized
INFO - 2020-11-12 02:14:55 --> Config Class Initialized
INFO - 2020-11-12 02:14:55 --> Loader Class Initialized
INFO - 2020-11-12 02:14:55 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:55 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:55 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:55 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:55 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:55 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:14:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:55 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:55 --> Total execution time: 0.2730
INFO - 2020-11-12 02:14:57 --> Config Class Initialized
INFO - 2020-11-12 02:14:57 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:57 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:57 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:57 --> URI Class Initialized
INFO - 2020-11-12 02:14:57 --> Router Class Initialized
INFO - 2020-11-12 02:14:57 --> Output Class Initialized
INFO - 2020-11-12 02:14:57 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:57 --> Input Class Initialized
INFO - 2020-11-12 02:14:57 --> Language Class Initialized
INFO - 2020-11-12 02:14:57 --> Language Class Initialized
INFO - 2020-11-12 02:14:57 --> Config Class Initialized
INFO - 2020-11-12 02:14:57 --> Loader Class Initialized
INFO - 2020-11-12 02:14:57 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:57 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:57 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:57 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:57 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:57 --> Controller Class Initialized
DEBUG - 2020-11-12 02:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:14:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:14:57 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:57 --> Total execution time: 0.2776
INFO - 2020-11-12 02:14:59 --> Config Class Initialized
INFO - 2020-11-12 02:14:59 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:14:59 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:14:59 --> Utf8 Class Initialized
INFO - 2020-11-12 02:14:59 --> URI Class Initialized
INFO - 2020-11-12 02:14:59 --> Router Class Initialized
INFO - 2020-11-12 02:14:59 --> Output Class Initialized
INFO - 2020-11-12 02:14:59 --> Security Class Initialized
DEBUG - 2020-11-12 02:14:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:14:59 --> Input Class Initialized
INFO - 2020-11-12 02:14:59 --> Language Class Initialized
INFO - 2020-11-12 02:14:59 --> Language Class Initialized
INFO - 2020-11-12 02:14:59 --> Config Class Initialized
INFO - 2020-11-12 02:14:59 --> Loader Class Initialized
INFO - 2020-11-12 02:14:59 --> Helper loaded: url_helper
INFO - 2020-11-12 02:14:59 --> Helper loaded: file_helper
INFO - 2020-11-12 02:14:59 --> Helper loaded: form_helper
INFO - 2020-11-12 02:14:59 --> Helper loaded: my_helper
INFO - 2020-11-12 02:14:59 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:14:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:14:59 --> Controller Class Initialized
INFO - 2020-11-12 02:14:59 --> Final output sent to browser
DEBUG - 2020-11-12 02:14:59 --> Total execution time: 0.2004
INFO - 2020-11-12 02:31:34 --> Config Class Initialized
INFO - 2020-11-12 02:31:34 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:31:34 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:31:34 --> Utf8 Class Initialized
INFO - 2020-11-12 02:31:34 --> URI Class Initialized
INFO - 2020-11-12 02:31:34 --> Router Class Initialized
INFO - 2020-11-12 02:31:34 --> Output Class Initialized
INFO - 2020-11-12 02:31:34 --> Security Class Initialized
DEBUG - 2020-11-12 02:31:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:31:34 --> Input Class Initialized
INFO - 2020-11-12 02:31:34 --> Language Class Initialized
INFO - 2020-11-12 02:31:34 --> Language Class Initialized
INFO - 2020-11-12 02:31:34 --> Config Class Initialized
INFO - 2020-11-12 02:31:34 --> Loader Class Initialized
INFO - 2020-11-12 02:31:34 --> Helper loaded: url_helper
INFO - 2020-11-12 02:31:34 --> Helper loaded: file_helper
INFO - 2020-11-12 02:31:34 --> Helper loaded: form_helper
INFO - 2020-11-12 02:31:34 --> Helper loaded: my_helper
INFO - 2020-11-12 02:31:34 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:31:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:31:34 --> Controller Class Initialized
DEBUG - 2020-11-12 02:31:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-11-12 02:31:34 --> Final output sent to browser
DEBUG - 2020-11-12 02:31:35 --> Total execution time: 0.6266
INFO - 2020-11-12 02:32:54 --> Config Class Initialized
INFO - 2020-11-12 02:32:54 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:32:54 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:32:54 --> Utf8 Class Initialized
INFO - 2020-11-12 02:32:54 --> URI Class Initialized
INFO - 2020-11-12 02:32:54 --> Router Class Initialized
INFO - 2020-11-12 02:32:54 --> Output Class Initialized
INFO - 2020-11-12 02:32:54 --> Security Class Initialized
DEBUG - 2020-11-12 02:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:32:54 --> Input Class Initialized
INFO - 2020-11-12 02:32:54 --> Language Class Initialized
INFO - 2020-11-12 02:32:54 --> Language Class Initialized
INFO - 2020-11-12 02:32:54 --> Config Class Initialized
INFO - 2020-11-12 02:32:54 --> Loader Class Initialized
INFO - 2020-11-12 02:32:55 --> Helper loaded: url_helper
INFO - 2020-11-12 02:32:55 --> Helper loaded: file_helper
INFO - 2020-11-12 02:32:55 --> Helper loaded: form_helper
INFO - 2020-11-12 02:32:55 --> Helper loaded: my_helper
INFO - 2020-11-12 02:32:55 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:32:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:32:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:32:55 --> Controller Class Initialized
DEBUG - 2020-11-12 02:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:32:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:32:55 --> Final output sent to browser
DEBUG - 2020-11-12 02:32:55 --> Total execution time: 0.8295
INFO - 2020-11-12 02:32:56 --> Config Class Initialized
INFO - 2020-11-12 02:32:56 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:32:57 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:32:57 --> Utf8 Class Initialized
INFO - 2020-11-12 02:32:57 --> URI Class Initialized
INFO - 2020-11-12 02:32:57 --> Router Class Initialized
INFO - 2020-11-12 02:32:57 --> Output Class Initialized
INFO - 2020-11-12 02:32:57 --> Security Class Initialized
DEBUG - 2020-11-12 02:32:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:32:57 --> Input Class Initialized
INFO - 2020-11-12 02:32:57 --> Language Class Initialized
INFO - 2020-11-12 02:32:57 --> Language Class Initialized
INFO - 2020-11-12 02:32:57 --> Config Class Initialized
INFO - 2020-11-12 02:32:57 --> Loader Class Initialized
INFO - 2020-11-12 02:32:57 --> Helper loaded: url_helper
INFO - 2020-11-12 02:32:57 --> Helper loaded: file_helper
INFO - 2020-11-12 02:32:57 --> Helper loaded: form_helper
INFO - 2020-11-12 02:32:57 --> Helper loaded: my_helper
INFO - 2020-11-12 02:32:57 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:32:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:32:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:32:57 --> Controller Class Initialized
INFO - 2020-11-12 02:32:57 --> Final output sent to browser
DEBUG - 2020-11-12 02:32:57 --> Total execution time: 0.6792
INFO - 2020-11-12 02:33:13 --> Config Class Initialized
INFO - 2020-11-12 02:33:13 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:13 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:13 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:13 --> URI Class Initialized
INFO - 2020-11-12 02:33:13 --> Router Class Initialized
INFO - 2020-11-12 02:33:13 --> Output Class Initialized
INFO - 2020-11-12 02:33:13 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:13 --> Input Class Initialized
INFO - 2020-11-12 02:33:13 --> Language Class Initialized
INFO - 2020-11-12 02:33:13 --> Language Class Initialized
INFO - 2020-11-12 02:33:14 --> Config Class Initialized
INFO - 2020-11-12 02:33:14 --> Loader Class Initialized
INFO - 2020-11-12 02:33:14 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:14 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:14 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:14 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:14 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:14 --> Controller Class Initialized
DEBUG - 2020-11-12 02:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:33:14 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:14 --> Total execution time: 0.4495
INFO - 2020-11-12 02:33:15 --> Config Class Initialized
INFO - 2020-11-12 02:33:15 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:15 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:15 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:15 --> URI Class Initialized
INFO - 2020-11-12 02:33:15 --> Router Class Initialized
INFO - 2020-11-12 02:33:15 --> Output Class Initialized
INFO - 2020-11-12 02:33:15 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:15 --> Input Class Initialized
INFO - 2020-11-12 02:33:15 --> Language Class Initialized
INFO - 2020-11-12 02:33:16 --> Language Class Initialized
INFO - 2020-11-12 02:33:16 --> Config Class Initialized
INFO - 2020-11-12 02:33:16 --> Loader Class Initialized
INFO - 2020-11-12 02:33:16 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:16 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:16 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:16 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:16 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:16 --> Controller Class Initialized
INFO - 2020-11-12 02:33:16 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:16 --> Total execution time: 0.4987
INFO - 2020-11-12 02:33:18 --> Config Class Initialized
INFO - 2020-11-12 02:33:18 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:18 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:18 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:18 --> URI Class Initialized
INFO - 2020-11-12 02:33:18 --> Router Class Initialized
INFO - 2020-11-12 02:33:18 --> Output Class Initialized
INFO - 2020-11-12 02:33:18 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:18 --> Input Class Initialized
INFO - 2020-11-12 02:33:18 --> Language Class Initialized
INFO - 2020-11-12 02:33:18 --> Language Class Initialized
INFO - 2020-11-12 02:33:18 --> Config Class Initialized
INFO - 2020-11-12 02:33:18 --> Loader Class Initialized
INFO - 2020-11-12 02:33:18 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:18 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:18 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:18 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:18 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:18 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:18 --> Controller Class Initialized
INFO - 2020-11-12 02:33:18 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:18 --> Total execution time: 0.6920
INFO - 2020-11-12 02:33:19 --> Config Class Initialized
INFO - 2020-11-12 02:33:19 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:19 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:19 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:19 --> URI Class Initialized
INFO - 2020-11-12 02:33:19 --> Router Class Initialized
INFO - 2020-11-12 02:33:19 --> Output Class Initialized
INFO - 2020-11-12 02:33:19 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:19 --> Input Class Initialized
INFO - 2020-11-12 02:33:19 --> Language Class Initialized
INFO - 2020-11-12 02:33:19 --> Language Class Initialized
INFO - 2020-11-12 02:33:19 --> Config Class Initialized
INFO - 2020-11-12 02:33:19 --> Loader Class Initialized
INFO - 2020-11-12 02:33:19 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:19 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:19 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:19 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:19 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:19 --> Controller Class Initialized
DEBUG - 2020-11-12 02:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:33:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:33:20 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:20 --> Total execution time: 1.0139
INFO - 2020-11-12 02:33:21 --> Config Class Initialized
INFO - 2020-11-12 02:33:21 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:21 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:21 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:21 --> URI Class Initialized
INFO - 2020-11-12 02:33:21 --> Router Class Initialized
INFO - 2020-11-12 02:33:21 --> Output Class Initialized
INFO - 2020-11-12 02:33:21 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:21 --> Input Class Initialized
INFO - 2020-11-12 02:33:21 --> Language Class Initialized
INFO - 2020-11-12 02:33:21 --> Language Class Initialized
INFO - 2020-11-12 02:33:21 --> Config Class Initialized
INFO - 2020-11-12 02:33:21 --> Loader Class Initialized
INFO - 2020-11-12 02:33:22 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:22 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:22 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:22 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:22 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:22 --> Controller Class Initialized
INFO - 2020-11-12 02:33:22 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:22 --> Total execution time: 0.7300
INFO - 2020-11-12 02:33:29 --> Config Class Initialized
INFO - 2020-11-12 02:33:29 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:29 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:29 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:29 --> URI Class Initialized
INFO - 2020-11-12 02:33:29 --> Router Class Initialized
INFO - 2020-11-12 02:33:29 --> Output Class Initialized
INFO - 2020-11-12 02:33:29 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:29 --> Input Class Initialized
INFO - 2020-11-12 02:33:29 --> Language Class Initialized
INFO - 2020-11-12 02:33:29 --> Language Class Initialized
INFO - 2020-11-12 02:33:29 --> Config Class Initialized
INFO - 2020-11-12 02:33:29 --> Loader Class Initialized
INFO - 2020-11-12 02:33:29 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:29 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:29 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:29 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:29 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:29 --> Controller Class Initialized
INFO - 2020-11-12 02:33:29 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:29 --> Total execution time: 0.5450
INFO - 2020-11-12 02:33:30 --> Config Class Initialized
INFO - 2020-11-12 02:33:30 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:30 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:30 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:30 --> URI Class Initialized
INFO - 2020-11-12 02:33:30 --> Router Class Initialized
INFO - 2020-11-12 02:33:30 --> Output Class Initialized
INFO - 2020-11-12 02:33:30 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:30 --> Input Class Initialized
INFO - 2020-11-12 02:33:30 --> Language Class Initialized
INFO - 2020-11-12 02:33:30 --> Language Class Initialized
INFO - 2020-11-12 02:33:30 --> Config Class Initialized
INFO - 2020-11-12 02:33:30 --> Loader Class Initialized
INFO - 2020-11-12 02:33:30 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:30 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:30 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:30 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:30 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:31 --> Controller Class Initialized
DEBUG - 2020-11-12 02:33:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:33:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:33:31 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:31 --> Total execution time: 1.0683
INFO - 2020-11-12 02:33:32 --> Config Class Initialized
INFO - 2020-11-12 02:33:32 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:33:32 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:33:32 --> Utf8 Class Initialized
INFO - 2020-11-12 02:33:32 --> URI Class Initialized
INFO - 2020-11-12 02:33:32 --> Router Class Initialized
INFO - 2020-11-12 02:33:32 --> Output Class Initialized
INFO - 2020-11-12 02:33:32 --> Security Class Initialized
DEBUG - 2020-11-12 02:33:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:33:32 --> Input Class Initialized
INFO - 2020-11-12 02:33:32 --> Language Class Initialized
INFO - 2020-11-12 02:33:32 --> Language Class Initialized
INFO - 2020-11-12 02:33:32 --> Config Class Initialized
INFO - 2020-11-12 02:33:32 --> Loader Class Initialized
INFO - 2020-11-12 02:33:32 --> Helper loaded: url_helper
INFO - 2020-11-12 02:33:32 --> Helper loaded: file_helper
INFO - 2020-11-12 02:33:32 --> Helper loaded: form_helper
INFO - 2020-11-12 02:33:32 --> Helper loaded: my_helper
INFO - 2020-11-12 02:33:32 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:33:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:33:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:33:33 --> Controller Class Initialized
INFO - 2020-11-12 02:33:33 --> Final output sent to browser
DEBUG - 2020-11-12 02:33:33 --> Total execution time: 0.6742
INFO - 2020-11-12 02:35:25 --> Config Class Initialized
INFO - 2020-11-12 02:35:25 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:25 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:25 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:25 --> URI Class Initialized
INFO - 2020-11-12 02:35:25 --> Router Class Initialized
INFO - 2020-11-12 02:35:25 --> Output Class Initialized
INFO - 2020-11-12 02:35:25 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:25 --> Input Class Initialized
INFO - 2020-11-12 02:35:25 --> Language Class Initialized
INFO - 2020-11-12 02:35:25 --> Language Class Initialized
INFO - 2020-11-12 02:35:25 --> Config Class Initialized
INFO - 2020-11-12 02:35:25 --> Loader Class Initialized
INFO - 2020-11-12 02:35:26 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:26 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:26 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:26 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:26 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:26 --> Controller Class Initialized
DEBUG - 2020-11-12 02:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:35:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:35:26 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:26 --> Total execution time: 0.8026
INFO - 2020-11-12 02:35:27 --> Config Class Initialized
INFO - 2020-11-12 02:35:27 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:27 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:27 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:27 --> URI Class Initialized
INFO - 2020-11-12 02:35:27 --> Router Class Initialized
INFO - 2020-11-12 02:35:27 --> Output Class Initialized
INFO - 2020-11-12 02:35:28 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:28 --> Input Class Initialized
INFO - 2020-11-12 02:35:28 --> Language Class Initialized
INFO - 2020-11-12 02:35:28 --> Language Class Initialized
INFO - 2020-11-12 02:35:28 --> Config Class Initialized
INFO - 2020-11-12 02:35:28 --> Loader Class Initialized
INFO - 2020-11-12 02:35:28 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:28 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:28 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:28 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:28 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:28 --> Controller Class Initialized
INFO - 2020-11-12 02:35:28 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:28 --> Total execution time: 0.4973
INFO - 2020-11-12 02:35:28 --> Config Class Initialized
INFO - 2020-11-12 02:35:28 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:28 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:28 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:29 --> URI Class Initialized
INFO - 2020-11-12 02:35:29 --> Router Class Initialized
INFO - 2020-11-12 02:35:29 --> Output Class Initialized
INFO - 2020-11-12 02:35:29 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:29 --> Input Class Initialized
INFO - 2020-11-12 02:35:29 --> Language Class Initialized
INFO - 2020-11-12 02:35:29 --> Language Class Initialized
INFO - 2020-11-12 02:35:29 --> Config Class Initialized
INFO - 2020-11-12 02:35:29 --> Loader Class Initialized
INFO - 2020-11-12 02:35:29 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:29 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:29 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:29 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:29 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:29 --> Controller Class Initialized
DEBUG - 2020-11-12 02:35:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:35:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:35:29 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:29 --> Total execution time: 0.7776
INFO - 2020-11-12 02:35:30 --> Config Class Initialized
INFO - 2020-11-12 02:35:30 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:30 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:30 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:30 --> URI Class Initialized
INFO - 2020-11-12 02:35:30 --> Router Class Initialized
INFO - 2020-11-12 02:35:30 --> Output Class Initialized
INFO - 2020-11-12 02:35:30 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:30 --> Input Class Initialized
INFO - 2020-11-12 02:35:30 --> Language Class Initialized
INFO - 2020-11-12 02:35:30 --> Language Class Initialized
INFO - 2020-11-12 02:35:30 --> Config Class Initialized
INFO - 2020-11-12 02:35:30 --> Loader Class Initialized
INFO - 2020-11-12 02:35:31 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:31 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:31 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:31 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:31 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:31 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:31 --> Controller Class Initialized
DEBUG - 2020-11-12 02:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-12 02:35:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:35:31 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:31 --> Total execution time: 0.7535
INFO - 2020-11-12 02:35:31 --> Config Class Initialized
INFO - 2020-11-12 02:35:31 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:31 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:31 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:31 --> URI Class Initialized
INFO - 2020-11-12 02:35:31 --> Router Class Initialized
INFO - 2020-11-12 02:35:31 --> Output Class Initialized
INFO - 2020-11-12 02:35:31 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:31 --> Input Class Initialized
INFO - 2020-11-12 02:35:31 --> Language Class Initialized
INFO - 2020-11-12 02:35:31 --> Language Class Initialized
INFO - 2020-11-12 02:35:31 --> Config Class Initialized
INFO - 2020-11-12 02:35:31 --> Loader Class Initialized
INFO - 2020-11-12 02:35:31 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:31 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:31 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:31 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:31 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:32 --> Controller Class Initialized
INFO - 2020-11-12 02:35:33 --> Config Class Initialized
INFO - 2020-11-12 02:35:33 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:33 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:33 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:33 --> URI Class Initialized
INFO - 2020-11-12 02:35:33 --> Router Class Initialized
INFO - 2020-11-12 02:35:33 --> Output Class Initialized
INFO - 2020-11-12 02:35:33 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:33 --> Input Class Initialized
INFO - 2020-11-12 02:35:33 --> Language Class Initialized
INFO - 2020-11-12 02:35:33 --> Language Class Initialized
INFO - 2020-11-12 02:35:33 --> Config Class Initialized
INFO - 2020-11-12 02:35:33 --> Loader Class Initialized
INFO - 2020-11-12 02:35:33 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:33 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:33 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:33 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:33 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:33 --> Controller Class Initialized
INFO - 2020-11-12 02:35:33 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:33 --> Total execution time: 0.6836
INFO - 2020-11-12 02:35:40 --> Config Class Initialized
INFO - 2020-11-12 02:35:40 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:40 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:40 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:40 --> URI Class Initialized
INFO - 2020-11-12 02:35:40 --> Router Class Initialized
INFO - 2020-11-12 02:35:41 --> Output Class Initialized
INFO - 2020-11-12 02:35:41 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:41 --> Input Class Initialized
INFO - 2020-11-12 02:35:41 --> Language Class Initialized
INFO - 2020-11-12 02:35:41 --> Language Class Initialized
INFO - 2020-11-12 02:35:41 --> Config Class Initialized
INFO - 2020-11-12 02:35:41 --> Loader Class Initialized
INFO - 2020-11-12 02:35:41 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:41 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:41 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:41 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:41 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:41 --> Controller Class Initialized
INFO - 2020-11-12 02:35:41 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:41 --> Total execution time: 0.7573
INFO - 2020-11-12 02:35:46 --> Config Class Initialized
INFO - 2020-11-12 02:35:46 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:46 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:46 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:46 --> URI Class Initialized
INFO - 2020-11-12 02:35:46 --> Router Class Initialized
INFO - 2020-11-12 02:35:46 --> Output Class Initialized
INFO - 2020-11-12 02:35:46 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:46 --> Input Class Initialized
INFO - 2020-11-12 02:35:46 --> Language Class Initialized
INFO - 2020-11-12 02:35:46 --> Language Class Initialized
INFO - 2020-11-12 02:35:46 --> Config Class Initialized
INFO - 2020-11-12 02:35:46 --> Loader Class Initialized
INFO - 2020-11-12 02:35:46 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:46 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:46 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:46 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:46 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:47 --> Controller Class Initialized
INFO - 2020-11-12 02:35:47 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:47 --> Total execution time: 0.6484
INFO - 2020-11-12 02:35:49 --> Config Class Initialized
INFO - 2020-11-12 02:35:49 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:49 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:49 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:49 --> URI Class Initialized
INFO - 2020-11-12 02:35:49 --> Router Class Initialized
INFO - 2020-11-12 02:35:49 --> Output Class Initialized
INFO - 2020-11-12 02:35:49 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:49 --> Input Class Initialized
INFO - 2020-11-12 02:35:49 --> Language Class Initialized
INFO - 2020-11-12 02:35:49 --> Language Class Initialized
INFO - 2020-11-12 02:35:49 --> Config Class Initialized
INFO - 2020-11-12 02:35:49 --> Loader Class Initialized
INFO - 2020-11-12 02:35:49 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:49 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:49 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:49 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:49 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:50 --> Controller Class Initialized
INFO - 2020-11-12 02:35:50 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:50 --> Total execution time: 0.6820
INFO - 2020-11-12 02:35:51 --> Config Class Initialized
INFO - 2020-11-12 02:35:51 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:51 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:51 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:52 --> URI Class Initialized
INFO - 2020-11-12 02:35:52 --> Router Class Initialized
INFO - 2020-11-12 02:35:52 --> Output Class Initialized
INFO - 2020-11-12 02:35:52 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:52 --> Input Class Initialized
INFO - 2020-11-12 02:35:52 --> Language Class Initialized
INFO - 2020-11-12 02:35:52 --> Language Class Initialized
INFO - 2020-11-12 02:35:52 --> Config Class Initialized
INFO - 2020-11-12 02:35:52 --> Loader Class Initialized
INFO - 2020-11-12 02:35:52 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:52 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:52 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:52 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:52 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:52 --> Controller Class Initialized
INFO - 2020-11-12 02:35:52 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:52 --> Total execution time: 0.7579
INFO - 2020-11-12 02:35:57 --> Config Class Initialized
INFO - 2020-11-12 02:35:57 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:35:57 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:35:57 --> Utf8 Class Initialized
INFO - 2020-11-12 02:35:58 --> URI Class Initialized
INFO - 2020-11-12 02:35:58 --> Router Class Initialized
INFO - 2020-11-12 02:35:58 --> Output Class Initialized
INFO - 2020-11-12 02:35:58 --> Security Class Initialized
DEBUG - 2020-11-12 02:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:35:58 --> Input Class Initialized
INFO - 2020-11-12 02:35:58 --> Language Class Initialized
INFO - 2020-11-12 02:35:58 --> Language Class Initialized
INFO - 2020-11-12 02:35:58 --> Config Class Initialized
INFO - 2020-11-12 02:35:58 --> Loader Class Initialized
INFO - 2020-11-12 02:35:58 --> Helper loaded: url_helper
INFO - 2020-11-12 02:35:58 --> Helper loaded: file_helper
INFO - 2020-11-12 02:35:58 --> Helper loaded: form_helper
INFO - 2020-11-12 02:35:58 --> Helper loaded: my_helper
INFO - 2020-11-12 02:35:58 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:35:58 --> Controller Class Initialized
INFO - 2020-11-12 02:35:58 --> Final output sent to browser
DEBUG - 2020-11-12 02:35:58 --> Total execution time: 0.8448
INFO - 2020-11-12 02:36:00 --> Config Class Initialized
INFO - 2020-11-12 02:36:00 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:36:00 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:36:00 --> Utf8 Class Initialized
INFO - 2020-11-12 02:36:00 --> URI Class Initialized
INFO - 2020-11-12 02:36:01 --> Router Class Initialized
INFO - 2020-11-12 02:36:01 --> Output Class Initialized
INFO - 2020-11-12 02:36:01 --> Security Class Initialized
DEBUG - 2020-11-12 02:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:36:01 --> Input Class Initialized
INFO - 2020-11-12 02:36:01 --> Language Class Initialized
INFO - 2020-11-12 02:36:01 --> Language Class Initialized
INFO - 2020-11-12 02:36:01 --> Config Class Initialized
INFO - 2020-11-12 02:36:01 --> Loader Class Initialized
INFO - 2020-11-12 02:36:01 --> Helper loaded: url_helper
INFO - 2020-11-12 02:36:01 --> Helper loaded: file_helper
INFO - 2020-11-12 02:36:01 --> Helper loaded: form_helper
INFO - 2020-11-12 02:36:01 --> Helper loaded: my_helper
INFO - 2020-11-12 02:36:01 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:36:01 --> Controller Class Initialized
INFO - 2020-11-12 02:36:01 --> Final output sent to browser
DEBUG - 2020-11-12 02:36:01 --> Total execution time: 0.7181
INFO - 2020-11-12 02:36:02 --> Config Class Initialized
INFO - 2020-11-12 02:36:02 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:36:02 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:36:02 --> Utf8 Class Initialized
INFO - 2020-11-12 02:36:02 --> URI Class Initialized
INFO - 2020-11-12 02:36:02 --> Router Class Initialized
INFO - 2020-11-12 02:36:02 --> Output Class Initialized
INFO - 2020-11-12 02:36:02 --> Security Class Initialized
DEBUG - 2020-11-12 02:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:36:02 --> Input Class Initialized
INFO - 2020-11-12 02:36:02 --> Language Class Initialized
INFO - 2020-11-12 02:36:02 --> Language Class Initialized
INFO - 2020-11-12 02:36:02 --> Config Class Initialized
INFO - 2020-11-12 02:36:02 --> Loader Class Initialized
INFO - 2020-11-12 02:36:02 --> Helper loaded: url_helper
INFO - 2020-11-12 02:36:02 --> Helper loaded: file_helper
INFO - 2020-11-12 02:36:02 --> Helper loaded: form_helper
INFO - 2020-11-12 02:36:02 --> Helper loaded: my_helper
INFO - 2020-11-12 02:36:02 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:36:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:36:02 --> Controller Class Initialized
INFO - 2020-11-12 02:36:02 --> Final output sent to browser
DEBUG - 2020-11-12 02:36:02 --> Total execution time: 0.7184
INFO - 2020-11-12 02:36:35 --> Config Class Initialized
INFO - 2020-11-12 02:36:35 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:36:35 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:36:35 --> Utf8 Class Initialized
INFO - 2020-11-12 02:36:35 --> URI Class Initialized
INFO - 2020-11-12 02:36:36 --> Router Class Initialized
INFO - 2020-11-12 02:36:36 --> Output Class Initialized
INFO - 2020-11-12 02:36:36 --> Security Class Initialized
DEBUG - 2020-11-12 02:36:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:36:36 --> Input Class Initialized
INFO - 2020-11-12 02:36:36 --> Language Class Initialized
INFO - 2020-11-12 02:36:36 --> Language Class Initialized
INFO - 2020-11-12 02:36:36 --> Config Class Initialized
INFO - 2020-11-12 02:36:36 --> Loader Class Initialized
INFO - 2020-11-12 02:36:36 --> Helper loaded: url_helper
INFO - 2020-11-12 02:36:36 --> Helper loaded: file_helper
INFO - 2020-11-12 02:36:36 --> Helper loaded: form_helper
INFO - 2020-11-12 02:36:36 --> Helper loaded: my_helper
INFO - 2020-11-12 02:36:36 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:36:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:36:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:36:36 --> Controller Class Initialized
DEBUG - 2020-11-12 02:36:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:36:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:36:36 --> Final output sent to browser
DEBUG - 2020-11-12 02:36:36 --> Total execution time: 0.7610
INFO - 2020-11-12 02:36:37 --> Config Class Initialized
INFO - 2020-11-12 02:36:37 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:36:37 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:36:37 --> Utf8 Class Initialized
INFO - 2020-11-12 02:36:37 --> URI Class Initialized
INFO - 2020-11-12 02:36:37 --> Router Class Initialized
INFO - 2020-11-12 02:36:37 --> Output Class Initialized
INFO - 2020-11-12 02:36:37 --> Security Class Initialized
DEBUG - 2020-11-12 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:36:37 --> Input Class Initialized
INFO - 2020-11-12 02:36:37 --> Language Class Initialized
INFO - 2020-11-12 02:36:37 --> Language Class Initialized
INFO - 2020-11-12 02:36:37 --> Config Class Initialized
INFO - 2020-11-12 02:36:37 --> Loader Class Initialized
INFO - 2020-11-12 02:36:37 --> Helper loaded: url_helper
INFO - 2020-11-12 02:36:37 --> Helper loaded: file_helper
INFO - 2020-11-12 02:36:37 --> Helper loaded: form_helper
INFO - 2020-11-12 02:36:37 --> Helper loaded: my_helper
INFO - 2020-11-12 02:36:38 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:36:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:36:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:36:38 --> Controller Class Initialized
DEBUG - 2020-11-12 02:36:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:36:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:36:38 --> Final output sent to browser
DEBUG - 2020-11-12 02:36:38 --> Total execution time: 0.6459
INFO - 2020-11-12 02:36:39 --> Config Class Initialized
INFO - 2020-11-12 02:36:39 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:36:39 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:36:39 --> Utf8 Class Initialized
INFO - 2020-11-12 02:36:39 --> URI Class Initialized
INFO - 2020-11-12 02:36:39 --> Router Class Initialized
INFO - 2020-11-12 02:36:39 --> Output Class Initialized
INFO - 2020-11-12 02:36:39 --> Security Class Initialized
DEBUG - 2020-11-12 02:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:36:39 --> Input Class Initialized
INFO - 2020-11-12 02:36:39 --> Language Class Initialized
INFO - 2020-11-12 02:36:39 --> Language Class Initialized
INFO - 2020-11-12 02:36:39 --> Config Class Initialized
INFO - 2020-11-12 02:36:39 --> Loader Class Initialized
INFO - 2020-11-12 02:36:39 --> Helper loaded: url_helper
INFO - 2020-11-12 02:36:39 --> Helper loaded: file_helper
INFO - 2020-11-12 02:36:39 --> Helper loaded: form_helper
INFO - 2020-11-12 02:36:39 --> Helper loaded: my_helper
INFO - 2020-11-12 02:36:39 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:36:39 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:36:39 --> Controller Class Initialized
INFO - 2020-11-12 02:38:12 --> Config Class Initialized
INFO - 2020-11-12 02:38:12 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:38:12 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:38:12 --> Utf8 Class Initialized
INFO - 2020-11-12 02:38:12 --> URI Class Initialized
INFO - 2020-11-12 02:38:12 --> Router Class Initialized
INFO - 2020-11-12 02:38:12 --> Output Class Initialized
INFO - 2020-11-12 02:38:12 --> Security Class Initialized
DEBUG - 2020-11-12 02:38:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:38:12 --> Input Class Initialized
INFO - 2020-11-12 02:38:12 --> Language Class Initialized
INFO - 2020-11-12 02:38:12 --> Language Class Initialized
INFO - 2020-11-12 02:38:12 --> Config Class Initialized
INFO - 2020-11-12 02:38:12 --> Loader Class Initialized
INFO - 2020-11-12 02:38:12 --> Helper loaded: url_helper
INFO - 2020-11-12 02:38:12 --> Helper loaded: file_helper
INFO - 2020-11-12 02:38:12 --> Helper loaded: form_helper
INFO - 2020-11-12 02:38:12 --> Helper loaded: my_helper
INFO - 2020-11-12 02:38:12 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:38:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:38:12 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:38:12 --> Controller Class Initialized
DEBUG - 2020-11-12 02:38:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:38:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:38:12 --> Final output sent to browser
DEBUG - 2020-11-12 02:38:13 --> Total execution time: 0.6734
INFO - 2020-11-12 02:38:14 --> Config Class Initialized
INFO - 2020-11-12 02:38:14 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:38:14 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:38:14 --> Utf8 Class Initialized
INFO - 2020-11-12 02:38:14 --> URI Class Initialized
INFO - 2020-11-12 02:38:14 --> Router Class Initialized
INFO - 2020-11-12 02:38:14 --> Output Class Initialized
INFO - 2020-11-12 02:38:14 --> Security Class Initialized
DEBUG - 2020-11-12 02:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:38:14 --> Input Class Initialized
INFO - 2020-11-12 02:38:14 --> Language Class Initialized
INFO - 2020-11-12 02:38:14 --> Language Class Initialized
INFO - 2020-11-12 02:38:14 --> Config Class Initialized
INFO - 2020-11-12 02:38:14 --> Loader Class Initialized
INFO - 2020-11-12 02:38:14 --> Helper loaded: url_helper
INFO - 2020-11-12 02:38:14 --> Helper loaded: file_helper
INFO - 2020-11-12 02:38:14 --> Helper loaded: form_helper
INFO - 2020-11-12 02:38:14 --> Helper loaded: my_helper
INFO - 2020-11-12 02:38:14 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:38:14 --> Controller Class Initialized
DEBUG - 2020-11-12 02:38:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-12 02:38:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:38:14 --> Final output sent to browser
DEBUG - 2020-11-12 02:38:15 --> Total execution time: 0.8490
INFO - 2020-11-12 02:38:15 --> Config Class Initialized
INFO - 2020-11-12 02:38:15 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:38:15 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:38:15 --> Utf8 Class Initialized
INFO - 2020-11-12 02:38:15 --> URI Class Initialized
INFO - 2020-11-12 02:38:15 --> Router Class Initialized
INFO - 2020-11-12 02:38:15 --> Output Class Initialized
INFO - 2020-11-12 02:38:15 --> Security Class Initialized
DEBUG - 2020-11-12 02:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:38:15 --> Input Class Initialized
INFO - 2020-11-12 02:38:15 --> Language Class Initialized
INFO - 2020-11-12 02:38:15 --> Language Class Initialized
INFO - 2020-11-12 02:38:15 --> Config Class Initialized
INFO - 2020-11-12 02:38:15 --> Loader Class Initialized
INFO - 2020-11-12 02:38:15 --> Helper loaded: url_helper
INFO - 2020-11-12 02:38:15 --> Helper loaded: file_helper
INFO - 2020-11-12 02:38:15 --> Helper loaded: form_helper
INFO - 2020-11-12 02:38:15 --> Helper loaded: my_helper
INFO - 2020-11-12 02:38:15 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:38:15 --> Controller Class Initialized
INFO - 2020-11-12 02:38:17 --> Config Class Initialized
INFO - 2020-11-12 02:38:17 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:38:17 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:38:17 --> Utf8 Class Initialized
INFO - 2020-11-12 02:38:17 --> URI Class Initialized
INFO - 2020-11-12 02:38:17 --> Router Class Initialized
INFO - 2020-11-12 02:38:17 --> Output Class Initialized
INFO - 2020-11-12 02:38:17 --> Security Class Initialized
DEBUG - 2020-11-12 02:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:38:17 --> Input Class Initialized
INFO - 2020-11-12 02:38:17 --> Language Class Initialized
INFO - 2020-11-12 02:38:17 --> Language Class Initialized
INFO - 2020-11-12 02:38:17 --> Config Class Initialized
INFO - 2020-11-12 02:38:17 --> Loader Class Initialized
INFO - 2020-11-12 02:38:17 --> Helper loaded: url_helper
INFO - 2020-11-12 02:38:17 --> Helper loaded: file_helper
INFO - 2020-11-12 02:38:17 --> Helper loaded: form_helper
INFO - 2020-11-12 02:38:17 --> Helper loaded: my_helper
INFO - 2020-11-12 02:38:17 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:38:17 --> Controller Class Initialized
INFO - 2020-11-12 02:41:48 --> Config Class Initialized
INFO - 2020-11-12 02:41:48 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:41:48 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:41:48 --> Utf8 Class Initialized
INFO - 2020-11-12 02:41:48 --> URI Class Initialized
INFO - 2020-11-12 02:41:48 --> Router Class Initialized
INFO - 2020-11-12 02:41:48 --> Output Class Initialized
INFO - 2020-11-12 02:41:48 --> Security Class Initialized
DEBUG - 2020-11-12 02:41:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:41:48 --> Input Class Initialized
INFO - 2020-11-12 02:41:48 --> Language Class Initialized
INFO - 2020-11-12 02:41:48 --> Language Class Initialized
INFO - 2020-11-12 02:41:48 --> Config Class Initialized
INFO - 2020-11-12 02:41:48 --> Loader Class Initialized
INFO - 2020-11-12 02:41:48 --> Helper loaded: url_helper
INFO - 2020-11-12 02:41:48 --> Helper loaded: file_helper
INFO - 2020-11-12 02:41:48 --> Helper loaded: form_helper
INFO - 2020-11-12 02:41:49 --> Helper loaded: my_helper
INFO - 2020-11-12 02:41:49 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:41:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:41:49 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:41:49 --> Controller Class Initialized
DEBUG - 2020-11-12 02:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:41:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:41:49 --> Final output sent to browser
DEBUG - 2020-11-12 02:41:49 --> Total execution time: 0.7200
INFO - 2020-11-12 02:41:50 --> Config Class Initialized
INFO - 2020-11-12 02:41:50 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:41:50 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:41:50 --> Utf8 Class Initialized
INFO - 2020-11-12 02:41:50 --> URI Class Initialized
INFO - 2020-11-12 02:41:50 --> Router Class Initialized
INFO - 2020-11-12 02:41:50 --> Output Class Initialized
INFO - 2020-11-12 02:41:50 --> Security Class Initialized
DEBUG - 2020-11-12 02:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:41:50 --> Input Class Initialized
INFO - 2020-11-12 02:41:50 --> Language Class Initialized
INFO - 2020-11-12 02:41:50 --> Language Class Initialized
INFO - 2020-11-12 02:41:50 --> Config Class Initialized
INFO - 2020-11-12 02:41:50 --> Loader Class Initialized
INFO - 2020-11-12 02:41:50 --> Helper loaded: url_helper
INFO - 2020-11-12 02:41:50 --> Helper loaded: file_helper
INFO - 2020-11-12 02:41:50 --> Helper loaded: form_helper
INFO - 2020-11-12 02:41:50 --> Helper loaded: my_helper
INFO - 2020-11-12 02:41:50 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:41:50 --> Controller Class Initialized
DEBUG - 2020-11-12 02:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:41:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:41:50 --> Final output sent to browser
DEBUG - 2020-11-12 02:41:50 --> Total execution time: 0.7270
INFO - 2020-11-12 02:41:52 --> Config Class Initialized
INFO - 2020-11-12 02:41:52 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:41:52 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:41:52 --> Utf8 Class Initialized
INFO - 2020-11-12 02:41:52 --> URI Class Initialized
INFO - 2020-11-12 02:41:52 --> Router Class Initialized
INFO - 2020-11-12 02:41:52 --> Output Class Initialized
INFO - 2020-11-12 02:41:52 --> Security Class Initialized
DEBUG - 2020-11-12 02:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:41:52 --> Input Class Initialized
INFO - 2020-11-12 02:41:52 --> Language Class Initialized
INFO - 2020-11-12 02:41:52 --> Language Class Initialized
INFO - 2020-11-12 02:41:52 --> Config Class Initialized
INFO - 2020-11-12 02:41:52 --> Loader Class Initialized
INFO - 2020-11-12 02:41:52 --> Helper loaded: url_helper
INFO - 2020-11-12 02:41:52 --> Helper loaded: file_helper
INFO - 2020-11-12 02:41:52 --> Helper loaded: form_helper
INFO - 2020-11-12 02:41:52 --> Helper loaded: my_helper
INFO - 2020-11-12 02:41:52 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:41:52 --> Controller Class Initialized
DEBUG - 2020-11-12 02:41:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:41:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:41:52 --> Final output sent to browser
DEBUG - 2020-11-12 02:41:53 --> Total execution time: 0.7107
INFO - 2020-11-12 02:41:53 --> Config Class Initialized
INFO - 2020-11-12 02:41:53 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:41:53 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:41:53 --> Utf8 Class Initialized
INFO - 2020-11-12 02:41:53 --> URI Class Initialized
INFO - 2020-11-12 02:41:53 --> Router Class Initialized
INFO - 2020-11-12 02:41:53 --> Output Class Initialized
INFO - 2020-11-12 02:41:53 --> Security Class Initialized
DEBUG - 2020-11-12 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:41:54 --> Input Class Initialized
INFO - 2020-11-12 02:41:54 --> Language Class Initialized
INFO - 2020-11-12 02:41:54 --> Language Class Initialized
INFO - 2020-11-12 02:41:54 --> Config Class Initialized
INFO - 2020-11-12 02:41:54 --> Loader Class Initialized
INFO - 2020-11-12 02:41:54 --> Helper loaded: url_helper
INFO - 2020-11-12 02:41:54 --> Helper loaded: file_helper
INFO - 2020-11-12 02:41:54 --> Helper loaded: form_helper
INFO - 2020-11-12 02:41:54 --> Helper loaded: my_helper
INFO - 2020-11-12 02:41:54 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:41:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:41:54 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:41:54 --> Controller Class Initialized
DEBUG - 2020-11-12 02:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-12 02:41:54 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:41:54 --> Final output sent to browser
DEBUG - 2020-11-12 02:41:54 --> Total execution time: 0.8580
INFO - 2020-11-12 02:41:54 --> Config Class Initialized
INFO - 2020-11-12 02:41:54 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:41:54 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:41:54 --> Utf8 Class Initialized
INFO - 2020-11-12 02:41:54 --> URI Class Initialized
INFO - 2020-11-12 02:41:54 --> Router Class Initialized
INFO - 2020-11-12 02:41:54 --> Output Class Initialized
INFO - 2020-11-12 02:41:54 --> Security Class Initialized
DEBUG - 2020-11-12 02:41:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:41:55 --> Input Class Initialized
INFO - 2020-11-12 02:41:55 --> Language Class Initialized
INFO - 2020-11-12 02:41:55 --> Language Class Initialized
INFO - 2020-11-12 02:41:55 --> Config Class Initialized
INFO - 2020-11-12 02:41:55 --> Loader Class Initialized
INFO - 2020-11-12 02:41:55 --> Helper loaded: url_helper
INFO - 2020-11-12 02:41:55 --> Helper loaded: file_helper
INFO - 2020-11-12 02:41:55 --> Helper loaded: form_helper
INFO - 2020-11-12 02:41:55 --> Helper loaded: my_helper
INFO - 2020-11-12 02:41:55 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:41:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:41:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:41:55 --> Controller Class Initialized
INFO - 2020-11-12 02:43:24 --> Config Class Initialized
INFO - 2020-11-12 02:43:24 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:43:24 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:43:24 --> Utf8 Class Initialized
INFO - 2020-11-12 02:43:24 --> URI Class Initialized
INFO - 2020-11-12 02:43:24 --> Router Class Initialized
INFO - 2020-11-12 02:43:24 --> Output Class Initialized
INFO - 2020-11-12 02:43:24 --> Security Class Initialized
DEBUG - 2020-11-12 02:43:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:43:24 --> Input Class Initialized
INFO - 2020-11-12 02:43:24 --> Language Class Initialized
INFO - 2020-11-12 02:43:24 --> Language Class Initialized
INFO - 2020-11-12 02:43:24 --> Config Class Initialized
INFO - 2020-11-12 02:43:24 --> Loader Class Initialized
INFO - 2020-11-12 02:43:24 --> Helper loaded: url_helper
INFO - 2020-11-12 02:43:24 --> Helper loaded: file_helper
INFO - 2020-11-12 02:43:24 --> Helper loaded: form_helper
INFO - 2020-11-12 02:43:24 --> Helper loaded: my_helper
INFO - 2020-11-12 02:43:24 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:43:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:43:24 --> Controller Class Initialized
INFO - 2020-11-12 02:45:47 --> Config Class Initialized
INFO - 2020-11-12 02:45:47 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:45:47 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:45:47 --> Utf8 Class Initialized
INFO - 2020-11-12 02:45:47 --> URI Class Initialized
INFO - 2020-11-12 02:45:47 --> Router Class Initialized
INFO - 2020-11-12 02:45:47 --> Output Class Initialized
INFO - 2020-11-12 02:45:47 --> Security Class Initialized
DEBUG - 2020-11-12 02:45:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:45:47 --> Input Class Initialized
INFO - 2020-11-12 02:45:47 --> Language Class Initialized
INFO - 2020-11-12 02:45:47 --> Language Class Initialized
INFO - 2020-11-12 02:45:47 --> Config Class Initialized
INFO - 2020-11-12 02:45:47 --> Loader Class Initialized
INFO - 2020-11-12 02:45:47 --> Helper loaded: url_helper
INFO - 2020-11-12 02:45:47 --> Helper loaded: file_helper
INFO - 2020-11-12 02:45:47 --> Helper loaded: form_helper
INFO - 2020-11-12 02:45:47 --> Helper loaded: my_helper
INFO - 2020-11-12 02:45:48 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:45:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:45:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:45:48 --> Controller Class Initialized
DEBUG - 2020-11-12 02:45:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-12 02:45:48 --> Final output sent to browser
DEBUG - 2020-11-12 02:45:48 --> Total execution time: 0.7746
INFO - 2020-11-12 02:46:06 --> Config Class Initialized
INFO - 2020-11-12 02:46:06 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:46:06 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:46:06 --> Utf8 Class Initialized
INFO - 2020-11-12 02:46:06 --> URI Class Initialized
INFO - 2020-11-12 02:46:06 --> Router Class Initialized
INFO - 2020-11-12 02:46:06 --> Output Class Initialized
INFO - 2020-11-12 02:46:06 --> Security Class Initialized
DEBUG - 2020-11-12 02:46:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:46:06 --> Input Class Initialized
INFO - 2020-11-12 02:46:06 --> Language Class Initialized
INFO - 2020-11-12 02:46:06 --> Language Class Initialized
INFO - 2020-11-12 02:46:06 --> Config Class Initialized
INFO - 2020-11-12 02:46:06 --> Loader Class Initialized
INFO - 2020-11-12 02:46:06 --> Helper loaded: url_helper
INFO - 2020-11-12 02:46:07 --> Helper loaded: file_helper
INFO - 2020-11-12 02:46:07 --> Helper loaded: form_helper
INFO - 2020-11-12 02:46:07 --> Helper loaded: my_helper
INFO - 2020-11-12 02:46:07 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:46:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:46:07 --> Controller Class Initialized
DEBUG - 2020-11-12 02:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2020-11-12 02:46:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:46:07 --> Final output sent to browser
DEBUG - 2020-11-12 02:46:07 --> Total execution time: 0.9179
INFO - 2020-11-12 02:46:07 --> Config Class Initialized
INFO - 2020-11-12 02:46:07 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:46:07 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:46:07 --> Utf8 Class Initialized
INFO - 2020-11-12 02:46:07 --> URI Class Initialized
INFO - 2020-11-12 02:46:07 --> Router Class Initialized
INFO - 2020-11-12 02:46:07 --> Output Class Initialized
INFO - 2020-11-12 02:46:08 --> Security Class Initialized
DEBUG - 2020-11-12 02:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:46:08 --> Input Class Initialized
INFO - 2020-11-12 02:46:08 --> Language Class Initialized
INFO - 2020-11-12 02:46:08 --> Language Class Initialized
INFO - 2020-11-12 02:46:08 --> Config Class Initialized
INFO - 2020-11-12 02:46:08 --> Loader Class Initialized
INFO - 2020-11-12 02:46:08 --> Helper loaded: url_helper
INFO - 2020-11-12 02:46:08 --> Helper loaded: file_helper
INFO - 2020-11-12 02:46:08 --> Helper loaded: form_helper
INFO - 2020-11-12 02:46:08 --> Helper loaded: my_helper
INFO - 2020-11-12 02:46:08 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:46:08 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:46:08 --> Controller Class Initialized
INFO - 2020-11-12 02:46:08 --> Config Class Initialized
INFO - 2020-11-12 02:46:08 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:46:08 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:46:08 --> Utf8 Class Initialized
INFO - 2020-11-12 02:46:08 --> URI Class Initialized
INFO - 2020-11-12 02:46:08 --> Router Class Initialized
INFO - 2020-11-12 02:46:08 --> Output Class Initialized
INFO - 2020-11-12 02:46:08 --> Security Class Initialized
DEBUG - 2020-11-12 02:46:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:46:08 --> Input Class Initialized
INFO - 2020-11-12 02:46:08 --> Language Class Initialized
INFO - 2020-11-12 02:46:08 --> Language Class Initialized
INFO - 2020-11-12 02:46:08 --> Config Class Initialized
INFO - 2020-11-12 02:46:08 --> Loader Class Initialized
INFO - 2020-11-12 02:46:08 --> Helper loaded: url_helper
INFO - 2020-11-12 02:46:08 --> Helper loaded: file_helper
INFO - 2020-11-12 02:46:08 --> Helper loaded: form_helper
INFO - 2020-11-12 02:46:09 --> Helper loaded: my_helper
INFO - 2020-11-12 02:46:09 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:46:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:46:09 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:46:09 --> Controller Class Initialized
DEBUG - 2020-11-12 02:46:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-12 02:46:09 --> Final output sent to browser
DEBUG - 2020-11-12 02:46:09 --> Total execution time: 0.7873
INFO - 2020-11-12 02:46:28 --> Config Class Initialized
INFO - 2020-11-12 02:46:28 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:46:28 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:46:28 --> Utf8 Class Initialized
INFO - 2020-11-12 02:46:28 --> URI Class Initialized
INFO - 2020-11-12 02:46:28 --> Router Class Initialized
INFO - 2020-11-12 02:46:28 --> Output Class Initialized
INFO - 2020-11-12 02:46:29 --> Security Class Initialized
DEBUG - 2020-11-12 02:46:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:46:29 --> Input Class Initialized
INFO - 2020-11-12 02:46:29 --> Language Class Initialized
INFO - 2020-11-12 02:46:29 --> Language Class Initialized
INFO - 2020-11-12 02:46:29 --> Config Class Initialized
INFO - 2020-11-12 02:46:29 --> Loader Class Initialized
INFO - 2020-11-12 02:46:29 --> Helper loaded: url_helper
INFO - 2020-11-12 02:46:29 --> Helper loaded: file_helper
INFO - 2020-11-12 02:46:29 --> Helper loaded: form_helper
INFO - 2020-11-12 02:46:29 --> Helper loaded: my_helper
INFO - 2020-11-12 02:46:29 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:46:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:46:29 --> Controller Class Initialized
DEBUG - 2020-11-12 02:46:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-12 02:46:29 --> Final output sent to browser
DEBUG - 2020-11-12 02:46:29 --> Total execution time: 0.5697
INFO - 2020-11-12 02:47:24 --> Config Class Initialized
INFO - 2020-11-12 02:47:24 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:47:24 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:47:24 --> Utf8 Class Initialized
INFO - 2020-11-12 02:47:24 --> URI Class Initialized
INFO - 2020-11-12 02:47:24 --> Router Class Initialized
INFO - 2020-11-12 02:47:24 --> Output Class Initialized
INFO - 2020-11-12 02:47:24 --> Security Class Initialized
DEBUG - 2020-11-12 02:47:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:47:24 --> Input Class Initialized
INFO - 2020-11-12 02:47:24 --> Language Class Initialized
INFO - 2020-11-12 02:47:24 --> Language Class Initialized
INFO - 2020-11-12 02:47:24 --> Config Class Initialized
INFO - 2020-11-12 02:47:24 --> Loader Class Initialized
INFO - 2020-11-12 02:47:24 --> Helper loaded: url_helper
INFO - 2020-11-12 02:47:24 --> Helper loaded: file_helper
INFO - 2020-11-12 02:47:24 --> Helper loaded: form_helper
INFO - 2020-11-12 02:47:24 --> Helper loaded: my_helper
INFO - 2020-11-12 02:47:24 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:47:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:47:24 --> Controller Class Initialized
DEBUG - 2020-11-12 02:47:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2020-11-12 02:47:24 --> Final output sent to browser
DEBUG - 2020-11-12 02:47:25 --> Total execution time: 0.5640
INFO - 2020-11-12 02:47:29 --> Config Class Initialized
INFO - 2020-11-12 02:47:29 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:47:29 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:47:29 --> Utf8 Class Initialized
INFO - 2020-11-12 02:47:29 --> URI Class Initialized
INFO - 2020-11-12 02:47:29 --> Router Class Initialized
INFO - 2020-11-12 02:47:29 --> Output Class Initialized
INFO - 2020-11-12 02:47:29 --> Security Class Initialized
DEBUG - 2020-11-12 02:47:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:47:29 --> Input Class Initialized
INFO - 2020-11-12 02:47:29 --> Language Class Initialized
INFO - 2020-11-12 02:47:29 --> Language Class Initialized
INFO - 2020-11-12 02:47:30 --> Config Class Initialized
INFO - 2020-11-12 02:47:30 --> Loader Class Initialized
INFO - 2020-11-12 02:47:30 --> Helper loaded: url_helper
INFO - 2020-11-12 02:47:30 --> Helper loaded: file_helper
INFO - 2020-11-12 02:47:30 --> Helper loaded: form_helper
INFO - 2020-11-12 02:47:30 --> Helper loaded: my_helper
INFO - 2020-11-12 02:47:30 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:47:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:47:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:47:30 --> Controller Class Initialized
DEBUG - 2020-11-12 02:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2020-11-12 02:47:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:47:30 --> Final output sent to browser
DEBUG - 2020-11-12 02:47:30 --> Total execution time: 0.9184
INFO - 2020-11-12 02:47:31 --> Config Class Initialized
INFO - 2020-11-12 02:47:31 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:47:31 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:47:31 --> Utf8 Class Initialized
INFO - 2020-11-12 02:47:31 --> URI Class Initialized
INFO - 2020-11-12 02:47:31 --> Router Class Initialized
INFO - 2020-11-12 02:47:31 --> Output Class Initialized
INFO - 2020-11-12 02:47:31 --> Security Class Initialized
DEBUG - 2020-11-12 02:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:47:31 --> Input Class Initialized
INFO - 2020-11-12 02:47:31 --> Language Class Initialized
INFO - 2020-11-12 02:47:32 --> Language Class Initialized
INFO - 2020-11-12 02:47:32 --> Config Class Initialized
INFO - 2020-11-12 02:47:32 --> Loader Class Initialized
INFO - 2020-11-12 02:47:32 --> Helper loaded: url_helper
INFO - 2020-11-12 02:47:32 --> Helper loaded: file_helper
INFO - 2020-11-12 02:47:32 --> Helper loaded: form_helper
INFO - 2020-11-12 02:47:32 --> Helper loaded: my_helper
INFO - 2020-11-12 02:47:32 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:47:32 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:47:32 --> Controller Class Initialized
DEBUG - 2020-11-12 02:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2020-11-12 02:47:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 02:47:32 --> Final output sent to browser
DEBUG - 2020-11-12 02:47:32 --> Total execution time: 0.8686
INFO - 2020-11-12 02:47:34 --> Config Class Initialized
INFO - 2020-11-12 02:47:34 --> Hooks Class Initialized
DEBUG - 2020-11-12 02:47:34 --> UTF-8 Support Enabled
INFO - 2020-11-12 02:47:34 --> Utf8 Class Initialized
INFO - 2020-11-12 02:47:34 --> URI Class Initialized
INFO - 2020-11-12 02:47:34 --> Router Class Initialized
INFO - 2020-11-12 02:47:34 --> Output Class Initialized
INFO - 2020-11-12 02:47:34 --> Security Class Initialized
DEBUG - 2020-11-12 02:47:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 02:47:34 --> Input Class Initialized
INFO - 2020-11-12 02:47:34 --> Language Class Initialized
INFO - 2020-11-12 02:47:34 --> Language Class Initialized
INFO - 2020-11-12 02:47:34 --> Config Class Initialized
INFO - 2020-11-12 02:47:34 --> Loader Class Initialized
INFO - 2020-11-12 02:47:34 --> Helper loaded: url_helper
INFO - 2020-11-12 02:47:34 --> Helper loaded: file_helper
INFO - 2020-11-12 02:47:34 --> Helper loaded: form_helper
INFO - 2020-11-12 02:47:34 --> Helper loaded: my_helper
INFO - 2020-11-12 02:47:34 --> Database Driver Class Initialized
DEBUG - 2020-11-12 02:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 02:47:34 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 02:47:34 --> Controller Class Initialized
DEBUG - 2020-11-12 02:47:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2020-11-12 02:47:34 --> Final output sent to browser
DEBUG - 2020-11-12 02:47:34 --> Total execution time: 0.7086
INFO - 2020-11-12 03:23:04 --> Config Class Initialized
INFO - 2020-11-12 03:23:04 --> Hooks Class Initialized
DEBUG - 2020-11-12 03:23:04 --> UTF-8 Support Enabled
INFO - 2020-11-12 03:23:04 --> Utf8 Class Initialized
INFO - 2020-11-12 03:23:04 --> URI Class Initialized
INFO - 2020-11-12 03:23:04 --> Router Class Initialized
INFO - 2020-11-12 03:23:04 --> Output Class Initialized
INFO - 2020-11-12 03:23:05 --> Security Class Initialized
DEBUG - 2020-11-12 03:23:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 03:23:05 --> Input Class Initialized
INFO - 2020-11-12 03:23:05 --> Language Class Initialized
INFO - 2020-11-12 03:23:05 --> Language Class Initialized
INFO - 2020-11-12 03:23:05 --> Config Class Initialized
INFO - 2020-11-12 03:23:05 --> Loader Class Initialized
INFO - 2020-11-12 03:23:05 --> Helper loaded: url_helper
INFO - 2020-11-12 03:23:05 --> Helper loaded: file_helper
INFO - 2020-11-12 03:23:05 --> Helper loaded: form_helper
INFO - 2020-11-12 03:23:05 --> Helper loaded: my_helper
INFO - 2020-11-12 03:23:05 --> Database Driver Class Initialized
DEBUG - 2020-11-12 03:23:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 03:23:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 03:23:05 --> Controller Class Initialized
INFO - 2020-11-12 03:23:05 --> Helper loaded: cookie_helper
INFO - 2020-11-12 03:23:05 --> Config Class Initialized
INFO - 2020-11-12 03:23:05 --> Hooks Class Initialized
DEBUG - 2020-11-12 03:23:05 --> UTF-8 Support Enabled
INFO - 2020-11-12 03:23:05 --> Utf8 Class Initialized
INFO - 2020-11-12 03:23:05 --> URI Class Initialized
INFO - 2020-11-12 03:23:05 --> Router Class Initialized
INFO - 2020-11-12 03:23:06 --> Output Class Initialized
INFO - 2020-11-12 03:23:06 --> Security Class Initialized
DEBUG - 2020-11-12 03:23:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 03:23:06 --> Input Class Initialized
INFO - 2020-11-12 03:23:06 --> Language Class Initialized
INFO - 2020-11-12 03:23:06 --> Language Class Initialized
INFO - 2020-11-12 03:23:06 --> Config Class Initialized
INFO - 2020-11-12 03:23:06 --> Loader Class Initialized
INFO - 2020-11-12 03:23:06 --> Helper loaded: url_helper
INFO - 2020-11-12 03:23:06 --> Helper loaded: file_helper
INFO - 2020-11-12 03:23:06 --> Helper loaded: form_helper
INFO - 2020-11-12 03:23:06 --> Helper loaded: my_helper
INFO - 2020-11-12 03:23:06 --> Database Driver Class Initialized
DEBUG - 2020-11-12 03:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 03:23:06 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 03:23:06 --> Controller Class Initialized
DEBUG - 2020-11-12 03:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-12 03:23:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 03:23:06 --> Final output sent to browser
DEBUG - 2020-11-12 03:23:06 --> Total execution time: 0.9482
INFO - 2020-11-12 03:58:44 --> Config Class Initialized
INFO - 2020-11-12 03:58:44 --> Hooks Class Initialized
DEBUG - 2020-11-12 03:58:44 --> UTF-8 Support Enabled
INFO - 2020-11-12 03:58:44 --> Utf8 Class Initialized
INFO - 2020-11-12 03:58:44 --> URI Class Initialized
INFO - 2020-11-12 03:58:45 --> Router Class Initialized
INFO - 2020-11-12 03:58:45 --> Output Class Initialized
INFO - 2020-11-12 03:58:45 --> Security Class Initialized
DEBUG - 2020-11-12 03:58:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 03:58:45 --> Input Class Initialized
INFO - 2020-11-12 03:58:45 --> Language Class Initialized
INFO - 2020-11-12 03:58:45 --> Language Class Initialized
INFO - 2020-11-12 03:58:45 --> Config Class Initialized
INFO - 2020-11-12 03:58:45 --> Loader Class Initialized
INFO - 2020-11-12 03:58:45 --> Helper loaded: url_helper
INFO - 2020-11-12 03:58:45 --> Helper loaded: file_helper
INFO - 2020-11-12 03:58:45 --> Helper loaded: form_helper
INFO - 2020-11-12 03:58:45 --> Helper loaded: my_helper
INFO - 2020-11-12 03:58:45 --> Database Driver Class Initialized
DEBUG - 2020-11-12 03:58:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 03:58:45 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 03:58:45 --> Controller Class Initialized
DEBUG - 2020-11-12 03:58:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-12 03:58:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 03:58:45 --> Final output sent to browser
DEBUG - 2020-11-12 03:58:45 --> Total execution time: 1.0733
INFO - 2020-11-12 03:58:50 --> Config Class Initialized
INFO - 2020-11-12 03:58:50 --> Hooks Class Initialized
DEBUG - 2020-11-12 03:58:50 --> UTF-8 Support Enabled
INFO - 2020-11-12 03:58:50 --> Utf8 Class Initialized
INFO - 2020-11-12 03:58:50 --> URI Class Initialized
INFO - 2020-11-12 03:58:50 --> Router Class Initialized
INFO - 2020-11-12 03:58:50 --> Output Class Initialized
INFO - 2020-11-12 03:58:50 --> Security Class Initialized
DEBUG - 2020-11-12 03:58:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 03:58:50 --> Input Class Initialized
INFO - 2020-11-12 03:58:50 --> Language Class Initialized
INFO - 2020-11-12 03:58:50 --> Language Class Initialized
INFO - 2020-11-12 03:58:50 --> Config Class Initialized
INFO - 2020-11-12 03:58:50 --> Loader Class Initialized
INFO - 2020-11-12 03:58:50 --> Helper loaded: url_helper
INFO - 2020-11-12 03:58:50 --> Helper loaded: file_helper
INFO - 2020-11-12 03:58:50 --> Helper loaded: form_helper
INFO - 2020-11-12 03:58:51 --> Helper loaded: my_helper
INFO - 2020-11-12 03:58:51 --> Database Driver Class Initialized
DEBUG - 2020-11-12 03:58:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 03:58:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 03:58:51 --> Controller Class Initialized
INFO - 2020-11-12 03:58:51 --> Helper loaded: cookie_helper
INFO - 2020-11-12 03:58:51 --> Final output sent to browser
DEBUG - 2020-11-12 03:58:51 --> Total execution time: 0.6589
INFO - 2020-11-12 03:58:51 --> Config Class Initialized
INFO - 2020-11-12 03:58:51 --> Hooks Class Initialized
DEBUG - 2020-11-12 03:58:52 --> UTF-8 Support Enabled
INFO - 2020-11-12 03:58:52 --> Utf8 Class Initialized
INFO - 2020-11-12 03:58:52 --> URI Class Initialized
INFO - 2020-11-12 03:58:52 --> Router Class Initialized
INFO - 2020-11-12 03:58:52 --> Output Class Initialized
INFO - 2020-11-12 03:58:52 --> Security Class Initialized
DEBUG - 2020-11-12 03:58:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 03:58:52 --> Input Class Initialized
INFO - 2020-11-12 03:58:52 --> Language Class Initialized
INFO - 2020-11-12 03:58:52 --> Language Class Initialized
INFO - 2020-11-12 03:58:52 --> Config Class Initialized
INFO - 2020-11-12 03:58:52 --> Loader Class Initialized
INFO - 2020-11-12 03:58:52 --> Helper loaded: url_helper
INFO - 2020-11-12 03:58:52 --> Helper loaded: file_helper
INFO - 2020-11-12 03:58:52 --> Helper loaded: form_helper
INFO - 2020-11-12 03:58:52 --> Helper loaded: my_helper
INFO - 2020-11-12 03:58:52 --> Database Driver Class Initialized
DEBUG - 2020-11-12 03:58:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 03:58:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 03:58:52 --> Controller Class Initialized
DEBUG - 2020-11-12 03:58:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-11-12 03:58:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 03:58:52 --> Final output sent to browser
DEBUG - 2020-11-12 03:58:52 --> Total execution time: 0.7612
INFO - 2020-11-12 05:38:33 --> Config Class Initialized
INFO - 2020-11-12 05:38:33 --> Hooks Class Initialized
DEBUG - 2020-11-12 05:38:33 --> UTF-8 Support Enabled
INFO - 2020-11-12 05:38:33 --> Utf8 Class Initialized
INFO - 2020-11-12 05:38:33 --> URI Class Initialized
INFO - 2020-11-12 05:38:33 --> Router Class Initialized
INFO - 2020-11-12 05:38:33 --> Output Class Initialized
INFO - 2020-11-12 05:38:33 --> Security Class Initialized
DEBUG - 2020-11-12 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 05:38:33 --> Input Class Initialized
INFO - 2020-11-12 05:38:33 --> Language Class Initialized
INFO - 2020-11-12 05:38:33 --> Language Class Initialized
INFO - 2020-11-12 05:38:33 --> Config Class Initialized
INFO - 2020-11-12 05:38:33 --> Loader Class Initialized
INFO - 2020-11-12 05:38:33 --> Helper loaded: url_helper
INFO - 2020-11-12 05:38:33 --> Helper loaded: file_helper
INFO - 2020-11-12 05:38:33 --> Helper loaded: form_helper
INFO - 2020-11-12 05:38:33 --> Helper loaded: my_helper
INFO - 2020-11-12 05:38:33 --> Database Driver Class Initialized
DEBUG - 2020-11-12 05:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 05:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 05:38:33 --> Controller Class Initialized
INFO - 2020-11-12 05:38:33 --> Helper loaded: cookie_helper
INFO - 2020-11-12 05:38:33 --> Config Class Initialized
INFO - 2020-11-12 05:38:33 --> Hooks Class Initialized
DEBUG - 2020-11-12 05:38:33 --> UTF-8 Support Enabled
INFO - 2020-11-12 05:38:33 --> Utf8 Class Initialized
INFO - 2020-11-12 05:38:33 --> URI Class Initialized
INFO - 2020-11-12 05:38:33 --> Router Class Initialized
INFO - 2020-11-12 05:38:33 --> Output Class Initialized
INFO - 2020-11-12 05:38:33 --> Security Class Initialized
DEBUG - 2020-11-12 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-11-12 05:38:33 --> Input Class Initialized
INFO - 2020-11-12 05:38:33 --> Language Class Initialized
INFO - 2020-11-12 05:38:33 --> Language Class Initialized
INFO - 2020-11-12 05:38:33 --> Config Class Initialized
INFO - 2020-11-12 05:38:33 --> Loader Class Initialized
INFO - 2020-11-12 05:38:33 --> Helper loaded: url_helper
INFO - 2020-11-12 05:38:33 --> Helper loaded: file_helper
INFO - 2020-11-12 05:38:33 --> Helper loaded: form_helper
INFO - 2020-11-12 05:38:33 --> Helper loaded: my_helper
INFO - 2020-11-12 05:38:33 --> Database Driver Class Initialized
DEBUG - 2020-11-12 05:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-11-12 05:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2020-11-12 05:38:33 --> Controller Class Initialized
DEBUG - 2020-11-12 05:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-11-12 05:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-11-12 05:38:33 --> Final output sent to browser
DEBUG - 2020-11-12 05:38:33 --> Total execution time: 0.2995
