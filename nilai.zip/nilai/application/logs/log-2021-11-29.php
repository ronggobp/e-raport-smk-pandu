<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-11-29 04:45:11 --> Config Class Initialized
INFO - 2021-11-29 04:45:11 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:11 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:11 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:11 --> URI Class Initialized
DEBUG - 2021-11-29 04:45:11 --> No URI present. Default controller set.
INFO - 2021-11-29 04:45:11 --> Router Class Initialized
INFO - 2021-11-29 04:45:11 --> Output Class Initialized
INFO - 2021-11-29 04:45:11 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:11 --> Input Class Initialized
INFO - 2021-11-29 04:45:11 --> Language Class Initialized
INFO - 2021-11-29 04:45:12 --> Language Class Initialized
INFO - 2021-11-29 04:45:12 --> Config Class Initialized
INFO - 2021-11-29 04:45:12 --> Loader Class Initialized
INFO - 2021-11-29 04:45:12 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:12 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:12 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:12 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:12 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:12 --> Controller Class Initialized
INFO - 2021-11-29 04:45:12 --> Config Class Initialized
INFO - 2021-11-29 04:45:12 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:12 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:12 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:12 --> URI Class Initialized
INFO - 2021-11-29 04:45:12 --> Router Class Initialized
INFO - 2021-11-29 04:45:12 --> Output Class Initialized
INFO - 2021-11-29 04:45:12 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:12 --> Input Class Initialized
INFO - 2021-11-29 04:45:12 --> Language Class Initialized
INFO - 2021-11-29 04:45:12 --> Language Class Initialized
INFO - 2021-11-29 04:45:12 --> Config Class Initialized
INFO - 2021-11-29 04:45:12 --> Loader Class Initialized
INFO - 2021-11-29 04:45:12 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:12 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:12 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:12 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:12 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:12 --> Controller Class Initialized
DEBUG - 2021-11-29 04:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-29 04:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 04:45:12 --> Final output sent to browser
DEBUG - 2021-11-29 04:45:12 --> Total execution time: 0.1088
INFO - 2021-11-29 04:45:18 --> Config Class Initialized
INFO - 2021-11-29 04:45:18 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:18 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:18 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:18 --> URI Class Initialized
INFO - 2021-11-29 04:45:18 --> Router Class Initialized
INFO - 2021-11-29 04:45:18 --> Output Class Initialized
INFO - 2021-11-29 04:45:18 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:18 --> Input Class Initialized
INFO - 2021-11-29 04:45:18 --> Language Class Initialized
INFO - 2021-11-29 04:45:18 --> Language Class Initialized
INFO - 2021-11-29 04:45:18 --> Config Class Initialized
INFO - 2021-11-29 04:45:18 --> Loader Class Initialized
INFO - 2021-11-29 04:45:18 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:18 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:18 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:18 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:18 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:18 --> Controller Class Initialized
INFO - 2021-11-29 04:45:18 --> Helper loaded: cookie_helper
INFO - 2021-11-29 04:45:18 --> Final output sent to browser
DEBUG - 2021-11-29 04:45:18 --> Total execution time: 0.1281
INFO - 2021-11-29 04:45:18 --> Config Class Initialized
INFO - 2021-11-29 04:45:18 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:18 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:18 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:18 --> URI Class Initialized
INFO - 2021-11-29 04:45:18 --> Router Class Initialized
INFO - 2021-11-29 04:45:18 --> Output Class Initialized
INFO - 2021-11-29 04:45:18 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:18 --> Input Class Initialized
INFO - 2021-11-29 04:45:18 --> Language Class Initialized
INFO - 2021-11-29 04:45:18 --> Language Class Initialized
INFO - 2021-11-29 04:45:18 --> Config Class Initialized
INFO - 2021-11-29 04:45:18 --> Loader Class Initialized
INFO - 2021-11-29 04:45:18 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:18 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:18 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:18 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:18 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:18 --> Controller Class Initialized
DEBUG - 2021-11-29 04:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-29 04:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 04:45:19 --> Final output sent to browser
DEBUG - 2021-11-29 04:45:19 --> Total execution time: 0.3659
INFO - 2021-11-29 04:45:23 --> Config Class Initialized
INFO - 2021-11-29 04:45:23 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:23 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:23 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:23 --> URI Class Initialized
INFO - 2021-11-29 04:45:23 --> Router Class Initialized
INFO - 2021-11-29 04:45:23 --> Output Class Initialized
INFO - 2021-11-29 04:45:23 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:23 --> Input Class Initialized
INFO - 2021-11-29 04:45:23 --> Language Class Initialized
INFO - 2021-11-29 04:45:23 --> Language Class Initialized
INFO - 2021-11-29 04:45:23 --> Config Class Initialized
INFO - 2021-11-29 04:45:23 --> Loader Class Initialized
INFO - 2021-11-29 04:45:23 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:23 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:23 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:23 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:23 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:23 --> Controller Class Initialized
DEBUG - 2021-11-29 04:45:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-11-29 04:45:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 04:45:23 --> Final output sent to browser
DEBUG - 2021-11-29 04:45:23 --> Total execution time: 0.0973
INFO - 2021-11-29 04:45:23 --> Config Class Initialized
INFO - 2021-11-29 04:45:23 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:23 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:23 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:23 --> URI Class Initialized
INFO - 2021-11-29 04:45:23 --> Router Class Initialized
INFO - 2021-11-29 04:45:23 --> Output Class Initialized
INFO - 2021-11-29 04:45:23 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:23 --> Input Class Initialized
INFO - 2021-11-29 04:45:23 --> Language Class Initialized
INFO - 2021-11-29 04:45:23 --> Language Class Initialized
INFO - 2021-11-29 04:45:23 --> Config Class Initialized
INFO - 2021-11-29 04:45:23 --> Loader Class Initialized
INFO - 2021-11-29 04:45:24 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:24 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:24 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:24 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:24 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:24 --> Controller Class Initialized
INFO - 2021-11-29 04:45:25 --> Config Class Initialized
INFO - 2021-11-29 04:45:25 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:25 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:25 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:25 --> URI Class Initialized
INFO - 2021-11-29 04:45:25 --> Router Class Initialized
INFO - 2021-11-29 04:45:25 --> Output Class Initialized
INFO - 2021-11-29 04:45:25 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:25 --> Input Class Initialized
INFO - 2021-11-29 04:45:25 --> Language Class Initialized
INFO - 2021-11-29 04:45:25 --> Language Class Initialized
INFO - 2021-11-29 04:45:25 --> Config Class Initialized
INFO - 2021-11-29 04:45:25 --> Loader Class Initialized
INFO - 2021-11-29 04:45:25 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:25 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:25 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:25 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:25 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:25 --> Controller Class Initialized
INFO - 2021-11-29 04:45:25 --> Final output sent to browser
DEBUG - 2021-11-29 04:45:25 --> Total execution time: 0.0779
INFO - 2021-11-29 04:45:25 --> Config Class Initialized
INFO - 2021-11-29 04:45:25 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:45:25 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:45:25 --> Utf8 Class Initialized
INFO - 2021-11-29 04:45:25 --> URI Class Initialized
INFO - 2021-11-29 04:45:25 --> Router Class Initialized
INFO - 2021-11-29 04:45:25 --> Output Class Initialized
INFO - 2021-11-29 04:45:25 --> Security Class Initialized
DEBUG - 2021-11-29 04:45:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:45:25 --> Input Class Initialized
INFO - 2021-11-29 04:45:25 --> Language Class Initialized
INFO - 2021-11-29 04:45:25 --> Language Class Initialized
INFO - 2021-11-29 04:45:25 --> Config Class Initialized
INFO - 2021-11-29 04:45:25 --> Loader Class Initialized
INFO - 2021-11-29 04:45:25 --> Helper loaded: url_helper
INFO - 2021-11-29 04:45:25 --> Helper loaded: file_helper
INFO - 2021-11-29 04:45:25 --> Helper loaded: form_helper
INFO - 2021-11-29 04:45:25 --> Helper loaded: my_helper
INFO - 2021-11-29 04:45:25 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:45:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:45:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:45:25 --> Controller Class Initialized
INFO - 2021-11-29 04:46:09 --> Config Class Initialized
INFO - 2021-11-29 04:46:09 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:46:09 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:46:09 --> Utf8 Class Initialized
INFO - 2021-11-29 04:46:09 --> URI Class Initialized
INFO - 2021-11-29 04:46:09 --> Router Class Initialized
INFO - 2021-11-29 04:46:09 --> Output Class Initialized
INFO - 2021-11-29 04:46:09 --> Security Class Initialized
DEBUG - 2021-11-29 04:46:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:46:09 --> Input Class Initialized
INFO - 2021-11-29 04:46:09 --> Language Class Initialized
INFO - 2021-11-29 04:46:10 --> Language Class Initialized
INFO - 2021-11-29 04:46:10 --> Config Class Initialized
INFO - 2021-11-29 04:46:10 --> Loader Class Initialized
INFO - 2021-11-29 04:46:10 --> Helper loaded: url_helper
INFO - 2021-11-29 04:46:10 --> Helper loaded: file_helper
INFO - 2021-11-29 04:46:10 --> Helper loaded: form_helper
INFO - 2021-11-29 04:46:10 --> Helper loaded: my_helper
INFO - 2021-11-29 04:46:10 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:46:10 --> Controller Class Initialized
INFO - 2021-11-29 04:46:10 --> Helper loaded: cookie_helper
INFO - 2021-11-29 04:46:10 --> Config Class Initialized
INFO - 2021-11-29 04:46:10 --> Hooks Class Initialized
DEBUG - 2021-11-29 04:46:10 --> UTF-8 Support Enabled
INFO - 2021-11-29 04:46:10 --> Utf8 Class Initialized
INFO - 2021-11-29 04:46:10 --> URI Class Initialized
INFO - 2021-11-29 04:46:10 --> Router Class Initialized
INFO - 2021-11-29 04:46:10 --> Output Class Initialized
INFO - 2021-11-29 04:46:10 --> Security Class Initialized
DEBUG - 2021-11-29 04:46:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 04:46:10 --> Input Class Initialized
INFO - 2021-11-29 04:46:10 --> Language Class Initialized
INFO - 2021-11-29 04:46:10 --> Language Class Initialized
INFO - 2021-11-29 04:46:10 --> Config Class Initialized
INFO - 2021-11-29 04:46:10 --> Loader Class Initialized
INFO - 2021-11-29 04:46:10 --> Helper loaded: url_helper
INFO - 2021-11-29 04:46:10 --> Helper loaded: file_helper
INFO - 2021-11-29 04:46:10 --> Helper loaded: form_helper
INFO - 2021-11-29 04:46:10 --> Helper loaded: my_helper
INFO - 2021-11-29 04:46:10 --> Database Driver Class Initialized
DEBUG - 2021-11-29 04:46:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 04:46:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 04:46:10 --> Controller Class Initialized
DEBUG - 2021-11-29 04:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-29 04:46:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 04:46:10 --> Final output sent to browser
DEBUG - 2021-11-29 04:46:10 --> Total execution time: 0.0510
INFO - 2021-11-29 05:16:26 --> Config Class Initialized
INFO - 2021-11-29 05:16:26 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:16:26 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:16:26 --> Utf8 Class Initialized
INFO - 2021-11-29 05:16:26 --> URI Class Initialized
INFO - 2021-11-29 05:16:26 --> Router Class Initialized
INFO - 2021-11-29 05:16:26 --> Output Class Initialized
INFO - 2021-11-29 05:16:26 --> Security Class Initialized
DEBUG - 2021-11-29 05:16:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:16:26 --> Input Class Initialized
INFO - 2021-11-29 05:16:26 --> Language Class Initialized
INFO - 2021-11-29 05:16:26 --> Language Class Initialized
INFO - 2021-11-29 05:16:26 --> Config Class Initialized
INFO - 2021-11-29 05:16:26 --> Loader Class Initialized
INFO - 2021-11-29 05:16:26 --> Helper loaded: url_helper
INFO - 2021-11-29 05:16:26 --> Helper loaded: file_helper
INFO - 2021-11-29 05:16:26 --> Helper loaded: form_helper
INFO - 2021-11-29 05:16:26 --> Helper loaded: my_helper
INFO - 2021-11-29 05:16:26 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:16:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:16:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:16:26 --> Controller Class Initialized
INFO - 2021-11-29 05:16:26 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:16:26 --> Final output sent to browser
DEBUG - 2021-11-29 05:16:26 --> Total execution time: 0.0864
INFO - 2021-11-29 05:16:27 --> Config Class Initialized
INFO - 2021-11-29 05:16:27 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:16:27 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:16:27 --> Utf8 Class Initialized
INFO - 2021-11-29 05:16:27 --> URI Class Initialized
INFO - 2021-11-29 05:16:27 --> Router Class Initialized
INFO - 2021-11-29 05:16:27 --> Output Class Initialized
INFO - 2021-11-29 05:16:27 --> Security Class Initialized
DEBUG - 2021-11-29 05:16:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:16:27 --> Input Class Initialized
INFO - 2021-11-29 05:16:27 --> Language Class Initialized
INFO - 2021-11-29 05:16:27 --> Language Class Initialized
INFO - 2021-11-29 05:16:27 --> Config Class Initialized
INFO - 2021-11-29 05:16:27 --> Loader Class Initialized
INFO - 2021-11-29 05:16:27 --> Helper loaded: url_helper
INFO - 2021-11-29 05:16:27 --> Helper loaded: file_helper
INFO - 2021-11-29 05:16:27 --> Helper loaded: form_helper
INFO - 2021-11-29 05:16:27 --> Helper loaded: my_helper
INFO - 2021-11-29 05:16:27 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:16:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:16:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:16:27 --> Controller Class Initialized
DEBUG - 2021-11-29 05:16:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-29 05:16:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:16:27 --> Final output sent to browser
DEBUG - 2021-11-29 05:16:27 --> Total execution time: 0.2329
INFO - 2021-11-29 05:16:38 --> Config Class Initialized
INFO - 2021-11-29 05:16:38 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:16:38 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:16:38 --> Utf8 Class Initialized
INFO - 2021-11-29 05:16:38 --> URI Class Initialized
INFO - 2021-11-29 05:16:38 --> Router Class Initialized
INFO - 2021-11-29 05:16:38 --> Output Class Initialized
INFO - 2021-11-29 05:16:38 --> Security Class Initialized
DEBUG - 2021-11-29 05:16:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:16:38 --> Input Class Initialized
INFO - 2021-11-29 05:16:38 --> Language Class Initialized
INFO - 2021-11-29 05:16:38 --> Language Class Initialized
INFO - 2021-11-29 05:16:38 --> Config Class Initialized
INFO - 2021-11-29 05:16:38 --> Loader Class Initialized
INFO - 2021-11-29 05:16:38 --> Helper loaded: url_helper
INFO - 2021-11-29 05:16:38 --> Helper loaded: file_helper
INFO - 2021-11-29 05:16:38 --> Helper loaded: form_helper
INFO - 2021-11-29 05:16:38 --> Helper loaded: my_helper
INFO - 2021-11-29 05:16:38 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:16:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:16:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:16:38 --> Controller Class Initialized
DEBUG - 2021-11-29 05:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-11-29 05:16:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:16:38 --> Final output sent to browser
DEBUG - 2021-11-29 05:16:38 --> Total execution time: 0.1165
INFO - 2021-11-29 05:16:43 --> Config Class Initialized
INFO - 2021-11-29 05:16:43 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:16:43 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:16:43 --> Utf8 Class Initialized
INFO - 2021-11-29 05:16:43 --> URI Class Initialized
INFO - 2021-11-29 05:16:43 --> Router Class Initialized
INFO - 2021-11-29 05:16:43 --> Output Class Initialized
INFO - 2021-11-29 05:16:43 --> Security Class Initialized
DEBUG - 2021-11-29 05:16:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:16:43 --> Input Class Initialized
INFO - 2021-11-29 05:16:43 --> Language Class Initialized
INFO - 2021-11-29 05:16:43 --> Language Class Initialized
INFO - 2021-11-29 05:16:43 --> Config Class Initialized
INFO - 2021-11-29 05:16:43 --> Loader Class Initialized
INFO - 2021-11-29 05:16:43 --> Helper loaded: url_helper
INFO - 2021-11-29 05:16:43 --> Helper loaded: file_helper
INFO - 2021-11-29 05:16:43 --> Helper loaded: form_helper
INFO - 2021-11-29 05:16:43 --> Helper loaded: my_helper
INFO - 2021-11-29 05:16:43 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:16:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:16:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:16:43 --> Controller Class Initialized
DEBUG - 2021-11-29 05:16:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-11-29 05:16:43 --> Final output sent to browser
DEBUG - 2021-11-29 05:16:43 --> Total execution time: 0.2072
INFO - 2021-11-29 05:17:49 --> Config Class Initialized
INFO - 2021-11-29 05:17:49 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:17:49 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:17:49 --> Utf8 Class Initialized
INFO - 2021-11-29 05:17:49 --> URI Class Initialized
INFO - 2021-11-29 05:17:49 --> Router Class Initialized
INFO - 2021-11-29 05:17:49 --> Output Class Initialized
INFO - 2021-11-29 05:17:49 --> Security Class Initialized
DEBUG - 2021-11-29 05:17:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:17:49 --> Input Class Initialized
INFO - 2021-11-29 05:17:49 --> Language Class Initialized
INFO - 2021-11-29 05:17:49 --> Language Class Initialized
INFO - 2021-11-29 05:17:49 --> Config Class Initialized
INFO - 2021-11-29 05:17:49 --> Loader Class Initialized
INFO - 2021-11-29 05:17:49 --> Helper loaded: url_helper
INFO - 2021-11-29 05:17:49 --> Helper loaded: file_helper
INFO - 2021-11-29 05:17:49 --> Helper loaded: form_helper
INFO - 2021-11-29 05:17:49 --> Helper loaded: my_helper
INFO - 2021-11-29 05:17:49 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:17:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:17:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:17:49 --> Controller Class Initialized
DEBUG - 2021-11-29 05:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-29 05:17:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:17:49 --> Final output sent to browser
DEBUG - 2021-11-29 05:17:49 --> Total execution time: 0.1767
INFO - 2021-11-29 05:17:52 --> Config Class Initialized
INFO - 2021-11-29 05:17:52 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:17:52 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:17:52 --> Utf8 Class Initialized
INFO - 2021-11-29 05:17:52 --> URI Class Initialized
INFO - 2021-11-29 05:17:52 --> Router Class Initialized
INFO - 2021-11-29 05:17:52 --> Output Class Initialized
INFO - 2021-11-29 05:17:52 --> Security Class Initialized
DEBUG - 2021-11-29 05:17:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:17:52 --> Input Class Initialized
INFO - 2021-11-29 05:17:52 --> Language Class Initialized
INFO - 2021-11-29 05:17:52 --> Language Class Initialized
INFO - 2021-11-29 05:17:52 --> Config Class Initialized
INFO - 2021-11-29 05:17:52 --> Loader Class Initialized
INFO - 2021-11-29 05:17:52 --> Helper loaded: url_helper
INFO - 2021-11-29 05:17:52 --> Helper loaded: file_helper
INFO - 2021-11-29 05:17:52 --> Helper loaded: form_helper
INFO - 2021-11-29 05:17:52 --> Helper loaded: my_helper
INFO - 2021-11-29 05:17:52 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:17:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:17:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:17:52 --> Controller Class Initialized
DEBUG - 2021-11-29 05:17:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:17:52 --> Final output sent to browser
DEBUG - 2021-11-29 05:17:52 --> Total execution time: 0.2337
INFO - 2021-11-29 05:17:54 --> Config Class Initialized
INFO - 2021-11-29 05:17:54 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:17:54 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:17:54 --> Utf8 Class Initialized
INFO - 2021-11-29 05:17:54 --> URI Class Initialized
INFO - 2021-11-29 05:17:54 --> Router Class Initialized
INFO - 2021-11-29 05:17:54 --> Output Class Initialized
INFO - 2021-11-29 05:17:54 --> Security Class Initialized
DEBUG - 2021-11-29 05:17:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:17:54 --> Input Class Initialized
INFO - 2021-11-29 05:17:54 --> Language Class Initialized
INFO - 2021-11-29 05:17:54 --> Language Class Initialized
INFO - 2021-11-29 05:17:54 --> Config Class Initialized
INFO - 2021-11-29 05:17:54 --> Loader Class Initialized
INFO - 2021-11-29 05:17:54 --> Helper loaded: url_helper
INFO - 2021-11-29 05:17:54 --> Helper loaded: file_helper
INFO - 2021-11-29 05:17:54 --> Helper loaded: form_helper
INFO - 2021-11-29 05:17:54 --> Helper loaded: my_helper
INFO - 2021-11-29 05:17:54 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:17:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:17:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:17:54 --> Controller Class Initialized
DEBUG - 2021-11-29 05:17:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:17:54 --> Final output sent to browser
DEBUG - 2021-11-29 05:17:54 --> Total execution time: 0.1447
INFO - 2021-11-29 05:17:56 --> Config Class Initialized
INFO - 2021-11-29 05:17:56 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:17:56 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:17:56 --> Utf8 Class Initialized
INFO - 2021-11-29 05:17:56 --> URI Class Initialized
INFO - 2021-11-29 05:17:56 --> Router Class Initialized
INFO - 2021-11-29 05:17:56 --> Output Class Initialized
INFO - 2021-11-29 05:17:56 --> Security Class Initialized
DEBUG - 2021-11-29 05:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:17:56 --> Input Class Initialized
INFO - 2021-11-29 05:17:56 --> Language Class Initialized
INFO - 2021-11-29 05:17:56 --> Language Class Initialized
INFO - 2021-11-29 05:17:56 --> Config Class Initialized
INFO - 2021-11-29 05:17:56 --> Loader Class Initialized
INFO - 2021-11-29 05:17:56 --> Helper loaded: url_helper
INFO - 2021-11-29 05:17:56 --> Helper loaded: file_helper
INFO - 2021-11-29 05:17:56 --> Helper loaded: form_helper
INFO - 2021-11-29 05:17:56 --> Helper loaded: my_helper
INFO - 2021-11-29 05:17:56 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:17:56 --> Controller Class Initialized
DEBUG - 2021-11-29 05:17:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:17:56 --> Final output sent to browser
DEBUG - 2021-11-29 05:17:56 --> Total execution time: 0.1719
INFO - 2021-11-29 05:17:58 --> Config Class Initialized
INFO - 2021-11-29 05:17:58 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:17:58 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:17:58 --> Utf8 Class Initialized
INFO - 2021-11-29 05:17:58 --> URI Class Initialized
INFO - 2021-11-29 05:17:58 --> Router Class Initialized
INFO - 2021-11-29 05:17:58 --> Output Class Initialized
INFO - 2021-11-29 05:17:58 --> Security Class Initialized
DEBUG - 2021-11-29 05:17:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:17:58 --> Input Class Initialized
INFO - 2021-11-29 05:17:58 --> Language Class Initialized
INFO - 2021-11-29 05:17:58 --> Language Class Initialized
INFO - 2021-11-29 05:17:58 --> Config Class Initialized
INFO - 2021-11-29 05:17:58 --> Loader Class Initialized
INFO - 2021-11-29 05:17:58 --> Helper loaded: url_helper
INFO - 2021-11-29 05:17:58 --> Helper loaded: file_helper
INFO - 2021-11-29 05:17:58 --> Helper loaded: form_helper
INFO - 2021-11-29 05:17:58 --> Helper loaded: my_helper
INFO - 2021-11-29 05:17:58 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:17:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:17:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:17:58 --> Controller Class Initialized
DEBUG - 2021-11-29 05:17:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:17:58 --> Final output sent to browser
DEBUG - 2021-11-29 05:17:58 --> Total execution time: 0.1426
INFO - 2021-11-29 05:18:00 --> Config Class Initialized
INFO - 2021-11-29 05:18:00 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:00 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:00 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:00 --> URI Class Initialized
INFO - 2021-11-29 05:18:00 --> Router Class Initialized
INFO - 2021-11-29 05:18:00 --> Output Class Initialized
INFO - 2021-11-29 05:18:00 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:00 --> Input Class Initialized
INFO - 2021-11-29 05:18:00 --> Language Class Initialized
INFO - 2021-11-29 05:18:00 --> Language Class Initialized
INFO - 2021-11-29 05:18:00 --> Config Class Initialized
INFO - 2021-11-29 05:18:00 --> Loader Class Initialized
INFO - 2021-11-29 05:18:00 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:00 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:00 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:00 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:00 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:00 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:00 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:00 --> Total execution time: 0.1568
INFO - 2021-11-29 05:18:03 --> Config Class Initialized
INFO - 2021-11-29 05:18:03 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:03 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:03 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:03 --> URI Class Initialized
INFO - 2021-11-29 05:18:03 --> Router Class Initialized
INFO - 2021-11-29 05:18:03 --> Output Class Initialized
INFO - 2021-11-29 05:18:03 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:03 --> Input Class Initialized
INFO - 2021-11-29 05:18:03 --> Language Class Initialized
INFO - 2021-11-29 05:18:03 --> Language Class Initialized
INFO - 2021-11-29 05:18:03 --> Config Class Initialized
INFO - 2021-11-29 05:18:03 --> Loader Class Initialized
INFO - 2021-11-29 05:18:03 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:03 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:03 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:03 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:03 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:03 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:03 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:03 --> Total execution time: 0.1320
INFO - 2021-11-29 05:18:05 --> Config Class Initialized
INFO - 2021-11-29 05:18:05 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:05 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:05 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:05 --> URI Class Initialized
INFO - 2021-11-29 05:18:05 --> Router Class Initialized
INFO - 2021-11-29 05:18:05 --> Output Class Initialized
INFO - 2021-11-29 05:18:05 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:05 --> Input Class Initialized
INFO - 2021-11-29 05:18:05 --> Language Class Initialized
INFO - 2021-11-29 05:18:05 --> Language Class Initialized
INFO - 2021-11-29 05:18:05 --> Config Class Initialized
INFO - 2021-11-29 05:18:05 --> Loader Class Initialized
INFO - 2021-11-29 05:18:05 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:05 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:05 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:05 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:05 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:05 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:05 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:05 --> Total execution time: 0.1260
INFO - 2021-11-29 05:18:07 --> Config Class Initialized
INFO - 2021-11-29 05:18:07 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:07 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:07 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:07 --> URI Class Initialized
INFO - 2021-11-29 05:18:07 --> Router Class Initialized
INFO - 2021-11-29 05:18:07 --> Output Class Initialized
INFO - 2021-11-29 05:18:07 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:07 --> Input Class Initialized
INFO - 2021-11-29 05:18:07 --> Language Class Initialized
INFO - 2021-11-29 05:18:07 --> Language Class Initialized
INFO - 2021-11-29 05:18:07 --> Config Class Initialized
INFO - 2021-11-29 05:18:07 --> Loader Class Initialized
INFO - 2021-11-29 05:18:07 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:07 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:07 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:07 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:07 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:07 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:07 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:07 --> Total execution time: 0.1355
INFO - 2021-11-29 05:18:09 --> Config Class Initialized
INFO - 2021-11-29 05:18:09 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:09 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:09 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:09 --> URI Class Initialized
INFO - 2021-11-29 05:18:09 --> Router Class Initialized
INFO - 2021-11-29 05:18:09 --> Output Class Initialized
INFO - 2021-11-29 05:18:09 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:09 --> Input Class Initialized
INFO - 2021-11-29 05:18:09 --> Language Class Initialized
INFO - 2021-11-29 05:18:09 --> Language Class Initialized
INFO - 2021-11-29 05:18:09 --> Config Class Initialized
INFO - 2021-11-29 05:18:09 --> Loader Class Initialized
INFO - 2021-11-29 05:18:09 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:09 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:09 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:09 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:09 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:09 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:09 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:09 --> Total execution time: 0.1356
INFO - 2021-11-29 05:18:11 --> Config Class Initialized
INFO - 2021-11-29 05:18:11 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:11 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:11 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:11 --> URI Class Initialized
INFO - 2021-11-29 05:18:11 --> Router Class Initialized
INFO - 2021-11-29 05:18:11 --> Output Class Initialized
INFO - 2021-11-29 05:18:11 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:11 --> Input Class Initialized
INFO - 2021-11-29 05:18:11 --> Language Class Initialized
INFO - 2021-11-29 05:18:11 --> Language Class Initialized
INFO - 2021-11-29 05:18:11 --> Config Class Initialized
INFO - 2021-11-29 05:18:11 --> Loader Class Initialized
INFO - 2021-11-29 05:18:11 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:11 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:11 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:11 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:11 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:11 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:11 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:11 --> Total execution time: 0.1397
INFO - 2021-11-29 05:18:13 --> Config Class Initialized
INFO - 2021-11-29 05:18:13 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:13 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:13 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:13 --> URI Class Initialized
INFO - 2021-11-29 05:18:13 --> Router Class Initialized
INFO - 2021-11-29 05:18:13 --> Output Class Initialized
INFO - 2021-11-29 05:18:13 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:13 --> Input Class Initialized
INFO - 2021-11-29 05:18:13 --> Language Class Initialized
INFO - 2021-11-29 05:18:13 --> Language Class Initialized
INFO - 2021-11-29 05:18:13 --> Config Class Initialized
INFO - 2021-11-29 05:18:13 --> Loader Class Initialized
INFO - 2021-11-29 05:18:13 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:13 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:13 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:13 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:13 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:13 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:13 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:13 --> Total execution time: 0.1452
INFO - 2021-11-29 05:18:15 --> Config Class Initialized
INFO - 2021-11-29 05:18:15 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:15 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:15 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:15 --> URI Class Initialized
INFO - 2021-11-29 05:18:15 --> Router Class Initialized
INFO - 2021-11-29 05:18:15 --> Output Class Initialized
INFO - 2021-11-29 05:18:15 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:15 --> Input Class Initialized
INFO - 2021-11-29 05:18:15 --> Language Class Initialized
INFO - 2021-11-29 05:18:15 --> Language Class Initialized
INFO - 2021-11-29 05:18:15 --> Config Class Initialized
INFO - 2021-11-29 05:18:15 --> Loader Class Initialized
INFO - 2021-11-29 05:18:15 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:15 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:15 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:15 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:15 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:15 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:16 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:16 --> Total execution time: 0.1523
INFO - 2021-11-29 05:18:18 --> Config Class Initialized
INFO - 2021-11-29 05:18:18 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:18 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:18 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:18 --> URI Class Initialized
INFO - 2021-11-29 05:18:18 --> Router Class Initialized
INFO - 2021-11-29 05:18:18 --> Output Class Initialized
INFO - 2021-11-29 05:18:18 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:18 --> Input Class Initialized
INFO - 2021-11-29 05:18:18 --> Language Class Initialized
INFO - 2021-11-29 05:18:18 --> Language Class Initialized
INFO - 2021-11-29 05:18:18 --> Config Class Initialized
INFO - 2021-11-29 05:18:18 --> Loader Class Initialized
INFO - 2021-11-29 05:18:18 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:18 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:18 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:18 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:18 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:18 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:18 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:18 --> Total execution time: 0.1488
INFO - 2021-11-29 05:18:19 --> Config Class Initialized
INFO - 2021-11-29 05:18:19 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:19 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:19 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:19 --> URI Class Initialized
INFO - 2021-11-29 05:18:19 --> Router Class Initialized
INFO - 2021-11-29 05:18:19 --> Output Class Initialized
INFO - 2021-11-29 05:18:19 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:19 --> Input Class Initialized
INFO - 2021-11-29 05:18:19 --> Language Class Initialized
INFO - 2021-11-29 05:18:19 --> Language Class Initialized
INFO - 2021-11-29 05:18:19 --> Config Class Initialized
INFO - 2021-11-29 05:18:19 --> Loader Class Initialized
INFO - 2021-11-29 05:18:19 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:19 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:19 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:19 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:20 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:20 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:20 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:20 --> Total execution time: 0.1426
INFO - 2021-11-29 05:18:21 --> Config Class Initialized
INFO - 2021-11-29 05:18:21 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:21 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:21 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:21 --> URI Class Initialized
INFO - 2021-11-29 05:18:21 --> Router Class Initialized
INFO - 2021-11-29 05:18:21 --> Output Class Initialized
INFO - 2021-11-29 05:18:21 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:21 --> Input Class Initialized
INFO - 2021-11-29 05:18:21 --> Language Class Initialized
INFO - 2021-11-29 05:18:21 --> Language Class Initialized
INFO - 2021-11-29 05:18:21 --> Config Class Initialized
INFO - 2021-11-29 05:18:21 --> Loader Class Initialized
INFO - 2021-11-29 05:18:21 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:21 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:21 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:21 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:21 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:21 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:21 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:21 --> Total execution time: 0.1512
INFO - 2021-11-29 05:18:24 --> Config Class Initialized
INFO - 2021-11-29 05:18:24 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:24 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:24 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:24 --> URI Class Initialized
INFO - 2021-11-29 05:18:24 --> Router Class Initialized
INFO - 2021-11-29 05:18:24 --> Output Class Initialized
INFO - 2021-11-29 05:18:24 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:24 --> Input Class Initialized
INFO - 2021-11-29 05:18:24 --> Language Class Initialized
INFO - 2021-11-29 05:18:24 --> Language Class Initialized
INFO - 2021-11-29 05:18:24 --> Config Class Initialized
INFO - 2021-11-29 05:18:24 --> Loader Class Initialized
INFO - 2021-11-29 05:18:24 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:24 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:24 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:24 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:24 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:25 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:25 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:25 --> Total execution time: 0.1801
INFO - 2021-11-29 05:18:26 --> Config Class Initialized
INFO - 2021-11-29 05:18:26 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:26 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:26 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:26 --> URI Class Initialized
INFO - 2021-11-29 05:18:26 --> Router Class Initialized
INFO - 2021-11-29 05:18:26 --> Output Class Initialized
INFO - 2021-11-29 05:18:26 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:26 --> Input Class Initialized
INFO - 2021-11-29 05:18:26 --> Language Class Initialized
INFO - 2021-11-29 05:18:26 --> Language Class Initialized
INFO - 2021-11-29 05:18:26 --> Config Class Initialized
INFO - 2021-11-29 05:18:26 --> Loader Class Initialized
INFO - 2021-11-29 05:18:26 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:26 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:26 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:26 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:26 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:26 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:26 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:26 --> Total execution time: 0.1348
INFO - 2021-11-29 05:18:28 --> Config Class Initialized
INFO - 2021-11-29 05:18:28 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:28 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:28 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:28 --> URI Class Initialized
INFO - 2021-11-29 05:18:28 --> Router Class Initialized
INFO - 2021-11-29 05:18:28 --> Output Class Initialized
INFO - 2021-11-29 05:18:28 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:28 --> Input Class Initialized
INFO - 2021-11-29 05:18:28 --> Language Class Initialized
INFO - 2021-11-29 05:18:28 --> Language Class Initialized
INFO - 2021-11-29 05:18:28 --> Config Class Initialized
INFO - 2021-11-29 05:18:28 --> Loader Class Initialized
INFO - 2021-11-29 05:18:28 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:28 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:28 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:28 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:28 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:28 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:28 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:28 --> Total execution time: 0.1270
INFO - 2021-11-29 05:18:30 --> Config Class Initialized
INFO - 2021-11-29 05:18:30 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:30 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:30 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:30 --> URI Class Initialized
INFO - 2021-11-29 05:18:30 --> Router Class Initialized
INFO - 2021-11-29 05:18:30 --> Output Class Initialized
INFO - 2021-11-29 05:18:30 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:30 --> Input Class Initialized
INFO - 2021-11-29 05:18:30 --> Language Class Initialized
INFO - 2021-11-29 05:18:30 --> Language Class Initialized
INFO - 2021-11-29 05:18:30 --> Config Class Initialized
INFO - 2021-11-29 05:18:30 --> Loader Class Initialized
INFO - 2021-11-29 05:18:30 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:30 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:30 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:30 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:30 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:30 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:30 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:30 --> Total execution time: 0.1519
INFO - 2021-11-29 05:18:32 --> Config Class Initialized
INFO - 2021-11-29 05:18:32 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:32 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:32 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:32 --> URI Class Initialized
INFO - 2021-11-29 05:18:32 --> Router Class Initialized
INFO - 2021-11-29 05:18:32 --> Output Class Initialized
INFO - 2021-11-29 05:18:32 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:32 --> Input Class Initialized
INFO - 2021-11-29 05:18:32 --> Language Class Initialized
INFO - 2021-11-29 05:18:32 --> Language Class Initialized
INFO - 2021-11-29 05:18:32 --> Config Class Initialized
INFO - 2021-11-29 05:18:32 --> Loader Class Initialized
INFO - 2021-11-29 05:18:32 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:32 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:32 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:32 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:32 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:32 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:32 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:32 --> Total execution time: 0.1452
INFO - 2021-11-29 05:18:35 --> Config Class Initialized
INFO - 2021-11-29 05:18:35 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:35 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:35 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:35 --> URI Class Initialized
INFO - 2021-11-29 05:18:35 --> Router Class Initialized
INFO - 2021-11-29 05:18:35 --> Output Class Initialized
INFO - 2021-11-29 05:18:35 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:35 --> Input Class Initialized
INFO - 2021-11-29 05:18:35 --> Language Class Initialized
INFO - 2021-11-29 05:18:35 --> Language Class Initialized
INFO - 2021-11-29 05:18:35 --> Config Class Initialized
INFO - 2021-11-29 05:18:35 --> Loader Class Initialized
INFO - 2021-11-29 05:18:35 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:35 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:35 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:35 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:35 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:35 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:35 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:35 --> Total execution time: 0.1608
INFO - 2021-11-29 05:18:40 --> Config Class Initialized
INFO - 2021-11-29 05:18:40 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:40 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:40 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:40 --> URI Class Initialized
INFO - 2021-11-29 05:18:40 --> Router Class Initialized
INFO - 2021-11-29 05:18:40 --> Output Class Initialized
INFO - 2021-11-29 05:18:40 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:40 --> Input Class Initialized
INFO - 2021-11-29 05:18:40 --> Language Class Initialized
INFO - 2021-11-29 05:18:40 --> Language Class Initialized
INFO - 2021-11-29 05:18:40 --> Config Class Initialized
INFO - 2021-11-29 05:18:40 --> Loader Class Initialized
INFO - 2021-11-29 05:18:40 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:40 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:40 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:40 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:40 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:40 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:40 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:40 --> Total execution time: 0.1424
INFO - 2021-11-29 05:18:43 --> Config Class Initialized
INFO - 2021-11-29 05:18:43 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:43 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:43 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:43 --> URI Class Initialized
INFO - 2021-11-29 05:18:43 --> Router Class Initialized
INFO - 2021-11-29 05:18:43 --> Output Class Initialized
INFO - 2021-11-29 05:18:43 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:43 --> Input Class Initialized
INFO - 2021-11-29 05:18:43 --> Language Class Initialized
INFO - 2021-11-29 05:18:43 --> Language Class Initialized
INFO - 2021-11-29 05:18:43 --> Config Class Initialized
INFO - 2021-11-29 05:18:43 --> Loader Class Initialized
INFO - 2021-11-29 05:18:43 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:43 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:43 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:43 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:43 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:43 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:43 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:43 --> Total execution time: 0.1451
INFO - 2021-11-29 05:18:44 --> Config Class Initialized
INFO - 2021-11-29 05:18:44 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:44 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:44 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:44 --> URI Class Initialized
INFO - 2021-11-29 05:18:44 --> Router Class Initialized
INFO - 2021-11-29 05:18:44 --> Output Class Initialized
INFO - 2021-11-29 05:18:44 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:44 --> Input Class Initialized
INFO - 2021-11-29 05:18:44 --> Language Class Initialized
INFO - 2021-11-29 05:18:44 --> Language Class Initialized
INFO - 2021-11-29 05:18:44 --> Config Class Initialized
INFO - 2021-11-29 05:18:44 --> Loader Class Initialized
INFO - 2021-11-29 05:18:44 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:44 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:45 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:45 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:45 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:45 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:45 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:45 --> Total execution time: 0.1466
INFO - 2021-11-29 05:18:46 --> Config Class Initialized
INFO - 2021-11-29 05:18:46 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:46 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:46 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:46 --> URI Class Initialized
INFO - 2021-11-29 05:18:46 --> Router Class Initialized
INFO - 2021-11-29 05:18:46 --> Output Class Initialized
INFO - 2021-11-29 05:18:46 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:46 --> Input Class Initialized
INFO - 2021-11-29 05:18:46 --> Language Class Initialized
INFO - 2021-11-29 05:18:46 --> Language Class Initialized
INFO - 2021-11-29 05:18:46 --> Config Class Initialized
INFO - 2021-11-29 05:18:46 --> Loader Class Initialized
INFO - 2021-11-29 05:18:46 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:46 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:46 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:46 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:46 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:46 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:46 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:46 --> Total execution time: 0.1354
INFO - 2021-11-29 05:18:48 --> Config Class Initialized
INFO - 2021-11-29 05:18:48 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:48 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:48 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:48 --> URI Class Initialized
INFO - 2021-11-29 05:18:48 --> Router Class Initialized
INFO - 2021-11-29 05:18:48 --> Output Class Initialized
INFO - 2021-11-29 05:18:48 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:48 --> Input Class Initialized
INFO - 2021-11-29 05:18:48 --> Language Class Initialized
INFO - 2021-11-29 05:18:48 --> Language Class Initialized
INFO - 2021-11-29 05:18:48 --> Config Class Initialized
INFO - 2021-11-29 05:18:48 --> Loader Class Initialized
INFO - 2021-11-29 05:18:48 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:48 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:48 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:48 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:48 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:48 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:48 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:48 --> Total execution time: 0.1449
INFO - 2021-11-29 05:18:50 --> Config Class Initialized
INFO - 2021-11-29 05:18:50 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:18:50 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:18:50 --> Utf8 Class Initialized
INFO - 2021-11-29 05:18:50 --> URI Class Initialized
INFO - 2021-11-29 05:18:50 --> Router Class Initialized
INFO - 2021-11-29 05:18:50 --> Output Class Initialized
INFO - 2021-11-29 05:18:50 --> Security Class Initialized
DEBUG - 2021-11-29 05:18:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:18:50 --> Input Class Initialized
INFO - 2021-11-29 05:18:50 --> Language Class Initialized
INFO - 2021-11-29 05:18:50 --> Language Class Initialized
INFO - 2021-11-29 05:18:50 --> Config Class Initialized
INFO - 2021-11-29 05:18:50 --> Loader Class Initialized
INFO - 2021-11-29 05:18:50 --> Helper loaded: url_helper
INFO - 2021-11-29 05:18:50 --> Helper loaded: file_helper
INFO - 2021-11-29 05:18:50 --> Helper loaded: form_helper
INFO - 2021-11-29 05:18:50 --> Helper loaded: my_helper
INFO - 2021-11-29 05:18:50 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:18:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:18:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:18:50 --> Controller Class Initialized
DEBUG - 2021-11-29 05:18:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:18:50 --> Final output sent to browser
DEBUG - 2021-11-29 05:18:50 --> Total execution time: 0.1482
INFO - 2021-11-29 05:24:40 --> Config Class Initialized
INFO - 2021-11-29 05:24:40 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:24:40 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:24:40 --> Utf8 Class Initialized
INFO - 2021-11-29 05:24:40 --> URI Class Initialized
INFO - 2021-11-29 05:24:40 --> Router Class Initialized
INFO - 2021-11-29 05:24:40 --> Output Class Initialized
INFO - 2021-11-29 05:24:40 --> Security Class Initialized
DEBUG - 2021-11-29 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:24:40 --> Input Class Initialized
INFO - 2021-11-29 05:24:40 --> Language Class Initialized
INFO - 2021-11-29 05:24:40 --> Language Class Initialized
INFO - 2021-11-29 05:24:40 --> Config Class Initialized
INFO - 2021-11-29 05:24:40 --> Loader Class Initialized
INFO - 2021-11-29 05:24:40 --> Helper loaded: url_helper
INFO - 2021-11-29 05:24:40 --> Helper loaded: file_helper
INFO - 2021-11-29 05:24:40 --> Helper loaded: form_helper
INFO - 2021-11-29 05:24:40 --> Helper loaded: my_helper
INFO - 2021-11-29 05:24:40 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:24:40 --> Controller Class Initialized
INFO - 2021-11-29 05:24:40 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:24:40 --> Config Class Initialized
INFO - 2021-11-29 05:24:40 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:24:40 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:24:40 --> Utf8 Class Initialized
INFO - 2021-11-29 05:24:40 --> URI Class Initialized
INFO - 2021-11-29 05:24:40 --> Router Class Initialized
INFO - 2021-11-29 05:24:40 --> Output Class Initialized
INFO - 2021-11-29 05:24:40 --> Security Class Initialized
DEBUG - 2021-11-29 05:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:24:40 --> Input Class Initialized
INFO - 2021-11-29 05:24:40 --> Language Class Initialized
INFO - 2021-11-29 05:24:40 --> Language Class Initialized
INFO - 2021-11-29 05:24:40 --> Config Class Initialized
INFO - 2021-11-29 05:24:40 --> Loader Class Initialized
INFO - 2021-11-29 05:24:40 --> Helper loaded: url_helper
INFO - 2021-11-29 05:24:40 --> Helper loaded: file_helper
INFO - 2021-11-29 05:24:40 --> Helper loaded: form_helper
INFO - 2021-11-29 05:24:40 --> Helper loaded: my_helper
INFO - 2021-11-29 05:24:40 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:24:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:24:40 --> Controller Class Initialized
DEBUG - 2021-11-29 05:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-29 05:24:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:24:40 --> Final output sent to browser
DEBUG - 2021-11-29 05:24:40 --> Total execution time: 0.0507
INFO - 2021-11-29 05:24:47 --> Config Class Initialized
INFO - 2021-11-29 05:24:47 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:24:47 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:24:47 --> Utf8 Class Initialized
INFO - 2021-11-29 05:24:47 --> URI Class Initialized
INFO - 2021-11-29 05:24:47 --> Router Class Initialized
INFO - 2021-11-29 05:24:47 --> Output Class Initialized
INFO - 2021-11-29 05:24:47 --> Security Class Initialized
DEBUG - 2021-11-29 05:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:24:47 --> Input Class Initialized
INFO - 2021-11-29 05:24:47 --> Language Class Initialized
INFO - 2021-11-29 05:24:47 --> Language Class Initialized
INFO - 2021-11-29 05:24:47 --> Config Class Initialized
INFO - 2021-11-29 05:24:47 --> Loader Class Initialized
INFO - 2021-11-29 05:24:47 --> Helper loaded: url_helper
INFO - 2021-11-29 05:24:47 --> Helper loaded: file_helper
INFO - 2021-11-29 05:24:47 --> Helper loaded: form_helper
INFO - 2021-11-29 05:24:47 --> Helper loaded: my_helper
INFO - 2021-11-29 05:24:47 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:24:47 --> Controller Class Initialized
INFO - 2021-11-29 05:24:47 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:24:47 --> Final output sent to browser
DEBUG - 2021-11-29 05:24:47 --> Total execution time: 0.0722
INFO - 2021-11-29 05:24:47 --> Config Class Initialized
INFO - 2021-11-29 05:24:47 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:24:47 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:24:47 --> Utf8 Class Initialized
INFO - 2021-11-29 05:24:47 --> URI Class Initialized
INFO - 2021-11-29 05:24:47 --> Router Class Initialized
INFO - 2021-11-29 05:24:47 --> Output Class Initialized
INFO - 2021-11-29 05:24:47 --> Security Class Initialized
DEBUG - 2021-11-29 05:24:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:24:47 --> Input Class Initialized
INFO - 2021-11-29 05:24:47 --> Language Class Initialized
INFO - 2021-11-29 05:24:47 --> Language Class Initialized
INFO - 2021-11-29 05:24:47 --> Config Class Initialized
INFO - 2021-11-29 05:24:47 --> Loader Class Initialized
INFO - 2021-11-29 05:24:47 --> Helper loaded: url_helper
INFO - 2021-11-29 05:24:47 --> Helper loaded: file_helper
INFO - 2021-11-29 05:24:47 --> Helper loaded: form_helper
INFO - 2021-11-29 05:24:47 --> Helper loaded: my_helper
INFO - 2021-11-29 05:24:47 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:24:47 --> Controller Class Initialized
DEBUG - 2021-11-29 05:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-29 05:24:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:24:48 --> Final output sent to browser
DEBUG - 2021-11-29 05:24:48 --> Total execution time: 0.2761
INFO - 2021-11-29 05:24:53 --> Config Class Initialized
INFO - 2021-11-29 05:24:53 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:24:53 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:24:53 --> Utf8 Class Initialized
INFO - 2021-11-29 05:24:53 --> URI Class Initialized
INFO - 2021-11-29 05:24:53 --> Router Class Initialized
INFO - 2021-11-29 05:24:53 --> Output Class Initialized
INFO - 2021-11-29 05:24:53 --> Security Class Initialized
DEBUG - 2021-11-29 05:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:24:53 --> Input Class Initialized
INFO - 2021-11-29 05:24:53 --> Language Class Initialized
INFO - 2021-11-29 05:24:53 --> Language Class Initialized
INFO - 2021-11-29 05:24:53 --> Config Class Initialized
INFO - 2021-11-29 05:24:53 --> Loader Class Initialized
INFO - 2021-11-29 05:24:53 --> Helper loaded: url_helper
INFO - 2021-11-29 05:24:53 --> Helper loaded: file_helper
INFO - 2021-11-29 05:24:53 --> Helper loaded: form_helper
INFO - 2021-11-29 05:24:53 --> Helper loaded: my_helper
INFO - 2021-11-29 05:24:53 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:24:53 --> Controller Class Initialized
DEBUG - 2021-11-29 05:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-11-29 05:24:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:24:53 --> Final output sent to browser
DEBUG - 2021-11-29 05:24:53 --> Total execution time: 0.0980
INFO - 2021-11-29 05:24:55 --> Config Class Initialized
INFO - 2021-11-29 05:24:55 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:24:55 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:24:55 --> Utf8 Class Initialized
INFO - 2021-11-29 05:24:55 --> URI Class Initialized
INFO - 2021-11-29 05:24:55 --> Router Class Initialized
INFO - 2021-11-29 05:24:55 --> Output Class Initialized
INFO - 2021-11-29 05:24:55 --> Security Class Initialized
DEBUG - 2021-11-29 05:24:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:24:55 --> Input Class Initialized
INFO - 2021-11-29 05:24:55 --> Language Class Initialized
INFO - 2021-11-29 05:24:55 --> Language Class Initialized
INFO - 2021-11-29 05:24:55 --> Config Class Initialized
INFO - 2021-11-29 05:24:55 --> Loader Class Initialized
INFO - 2021-11-29 05:24:55 --> Helper loaded: url_helper
INFO - 2021-11-29 05:24:55 --> Helper loaded: file_helper
INFO - 2021-11-29 05:24:55 --> Helper loaded: form_helper
INFO - 2021-11-29 05:24:55 --> Helper loaded: my_helper
INFO - 2021-11-29 05:24:55 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:24:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:24:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:24:55 --> Controller Class Initialized
DEBUG - 2021-11-29 05:24:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_to.php
INFO - 2021-11-29 05:24:55 --> Final output sent to browser
DEBUG - 2021-11-29 05:24:55 --> Total execution time: 0.1671
INFO - 2021-11-29 05:25:51 --> Config Class Initialized
INFO - 2021-11-29 05:25:51 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:25:51 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:25:51 --> Utf8 Class Initialized
INFO - 2021-11-29 05:25:51 --> URI Class Initialized
INFO - 2021-11-29 05:25:51 --> Router Class Initialized
INFO - 2021-11-29 05:25:51 --> Output Class Initialized
INFO - 2021-11-29 05:25:51 --> Security Class Initialized
DEBUG - 2021-11-29 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:25:51 --> Input Class Initialized
INFO - 2021-11-29 05:25:51 --> Language Class Initialized
INFO - 2021-11-29 05:25:51 --> Language Class Initialized
INFO - 2021-11-29 05:25:51 --> Config Class Initialized
INFO - 2021-11-29 05:25:51 --> Loader Class Initialized
INFO - 2021-11-29 05:25:51 --> Helper loaded: url_helper
INFO - 2021-11-29 05:25:51 --> Helper loaded: file_helper
INFO - 2021-11-29 05:25:51 --> Helper loaded: form_helper
INFO - 2021-11-29 05:25:51 --> Helper loaded: my_helper
INFO - 2021-11-29 05:25:51 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:25:51 --> Controller Class Initialized
DEBUG - 2021-11-29 05:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-29 05:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:25:51 --> Final output sent to browser
DEBUG - 2021-11-29 05:25:51 --> Total execution time: 0.0703
INFO - 2021-11-29 05:25:58 --> Config Class Initialized
INFO - 2021-11-29 05:25:58 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:25:58 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:25:58 --> Utf8 Class Initialized
INFO - 2021-11-29 05:25:58 --> URI Class Initialized
INFO - 2021-11-29 05:25:58 --> Router Class Initialized
INFO - 2021-11-29 05:25:58 --> Output Class Initialized
INFO - 2021-11-29 05:25:58 --> Security Class Initialized
DEBUG - 2021-11-29 05:25:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:25:58 --> Input Class Initialized
INFO - 2021-11-29 05:25:58 --> Language Class Initialized
INFO - 2021-11-29 05:25:58 --> Language Class Initialized
INFO - 2021-11-29 05:25:58 --> Config Class Initialized
INFO - 2021-11-29 05:25:58 --> Loader Class Initialized
INFO - 2021-11-29 05:25:58 --> Helper loaded: url_helper
INFO - 2021-11-29 05:25:58 --> Helper loaded: file_helper
INFO - 2021-11-29 05:25:58 --> Helper loaded: form_helper
INFO - 2021-11-29 05:25:58 --> Helper loaded: my_helper
INFO - 2021-11-29 05:25:58 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:25:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:25:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:25:58 --> Controller Class Initialized
DEBUG - 2021-11-29 05:25:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:25:58 --> Final output sent to browser
DEBUG - 2021-11-29 05:25:58 --> Total execution time: 0.1500
INFO - 2021-11-29 05:26:01 --> Config Class Initialized
INFO - 2021-11-29 05:26:01 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:01 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:01 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:01 --> URI Class Initialized
INFO - 2021-11-29 05:26:01 --> Router Class Initialized
INFO - 2021-11-29 05:26:01 --> Output Class Initialized
INFO - 2021-11-29 05:26:01 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:01 --> Input Class Initialized
INFO - 2021-11-29 05:26:01 --> Language Class Initialized
INFO - 2021-11-29 05:26:01 --> Language Class Initialized
INFO - 2021-11-29 05:26:01 --> Config Class Initialized
INFO - 2021-11-29 05:26:01 --> Loader Class Initialized
INFO - 2021-11-29 05:26:01 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:01 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:01 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:01 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:01 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:01 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:01 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:01 --> Total execution time: 0.1257
INFO - 2021-11-29 05:26:05 --> Config Class Initialized
INFO - 2021-11-29 05:26:05 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:05 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:05 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:05 --> URI Class Initialized
INFO - 2021-11-29 05:26:05 --> Router Class Initialized
INFO - 2021-11-29 05:26:05 --> Output Class Initialized
INFO - 2021-11-29 05:26:05 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:05 --> Input Class Initialized
INFO - 2021-11-29 05:26:05 --> Language Class Initialized
INFO - 2021-11-29 05:26:05 --> Language Class Initialized
INFO - 2021-11-29 05:26:05 --> Config Class Initialized
INFO - 2021-11-29 05:26:05 --> Loader Class Initialized
INFO - 2021-11-29 05:26:05 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:05 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:05 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:05 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:05 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:05 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:05 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:05 --> Total execution time: 0.1314
INFO - 2021-11-29 05:26:07 --> Config Class Initialized
INFO - 2021-11-29 05:26:07 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:07 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:07 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:07 --> URI Class Initialized
INFO - 2021-11-29 05:26:07 --> Router Class Initialized
INFO - 2021-11-29 05:26:07 --> Output Class Initialized
INFO - 2021-11-29 05:26:07 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:07 --> Input Class Initialized
INFO - 2021-11-29 05:26:07 --> Language Class Initialized
INFO - 2021-11-29 05:26:07 --> Language Class Initialized
INFO - 2021-11-29 05:26:07 --> Config Class Initialized
INFO - 2021-11-29 05:26:07 --> Loader Class Initialized
INFO - 2021-11-29 05:26:07 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:07 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:07 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:07 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:07 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:07 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:07 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:07 --> Total execution time: 0.1494
INFO - 2021-11-29 05:26:09 --> Config Class Initialized
INFO - 2021-11-29 05:26:09 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:09 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:09 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:09 --> URI Class Initialized
INFO - 2021-11-29 05:26:09 --> Router Class Initialized
INFO - 2021-11-29 05:26:09 --> Output Class Initialized
INFO - 2021-11-29 05:26:09 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:09 --> Input Class Initialized
INFO - 2021-11-29 05:26:09 --> Language Class Initialized
INFO - 2021-11-29 05:26:09 --> Language Class Initialized
INFO - 2021-11-29 05:26:09 --> Config Class Initialized
INFO - 2021-11-29 05:26:09 --> Loader Class Initialized
INFO - 2021-11-29 05:26:09 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:09 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:09 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:09 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:09 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:09 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:10 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:10 --> Total execution time: 0.1232
INFO - 2021-11-29 05:26:12 --> Config Class Initialized
INFO - 2021-11-29 05:26:12 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:12 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:12 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:12 --> URI Class Initialized
INFO - 2021-11-29 05:26:12 --> Router Class Initialized
INFO - 2021-11-29 05:26:12 --> Output Class Initialized
INFO - 2021-11-29 05:26:12 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:12 --> Input Class Initialized
INFO - 2021-11-29 05:26:12 --> Language Class Initialized
INFO - 2021-11-29 05:26:12 --> Language Class Initialized
INFO - 2021-11-29 05:26:12 --> Config Class Initialized
INFO - 2021-11-29 05:26:12 --> Loader Class Initialized
INFO - 2021-11-29 05:26:12 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:12 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:12 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:12 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:12 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:12 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:12 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:12 --> Total execution time: 0.1275
INFO - 2021-11-29 05:26:14 --> Config Class Initialized
INFO - 2021-11-29 05:26:14 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:14 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:14 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:14 --> URI Class Initialized
INFO - 2021-11-29 05:26:14 --> Router Class Initialized
INFO - 2021-11-29 05:26:14 --> Output Class Initialized
INFO - 2021-11-29 05:26:14 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:14 --> Input Class Initialized
INFO - 2021-11-29 05:26:14 --> Language Class Initialized
INFO - 2021-11-29 05:26:14 --> Language Class Initialized
INFO - 2021-11-29 05:26:14 --> Config Class Initialized
INFO - 2021-11-29 05:26:14 --> Loader Class Initialized
INFO - 2021-11-29 05:26:14 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:14 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:14 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:14 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:14 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:14 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:14 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:14 --> Total execution time: 0.1583
INFO - 2021-11-29 05:26:16 --> Config Class Initialized
INFO - 2021-11-29 05:26:16 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:16 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:16 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:16 --> URI Class Initialized
INFO - 2021-11-29 05:26:16 --> Router Class Initialized
INFO - 2021-11-29 05:26:16 --> Output Class Initialized
INFO - 2021-11-29 05:26:16 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:16 --> Input Class Initialized
INFO - 2021-11-29 05:26:16 --> Language Class Initialized
INFO - 2021-11-29 05:26:16 --> Language Class Initialized
INFO - 2021-11-29 05:26:16 --> Config Class Initialized
INFO - 2021-11-29 05:26:16 --> Loader Class Initialized
INFO - 2021-11-29 05:26:16 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:16 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:16 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:16 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:16 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:16 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:16 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:16 --> Total execution time: 0.1322
INFO - 2021-11-29 05:26:18 --> Config Class Initialized
INFO - 2021-11-29 05:26:18 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:18 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:18 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:18 --> URI Class Initialized
INFO - 2021-11-29 05:26:18 --> Router Class Initialized
INFO - 2021-11-29 05:26:18 --> Output Class Initialized
INFO - 2021-11-29 05:26:18 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:18 --> Input Class Initialized
INFO - 2021-11-29 05:26:18 --> Language Class Initialized
INFO - 2021-11-29 05:26:18 --> Language Class Initialized
INFO - 2021-11-29 05:26:18 --> Config Class Initialized
INFO - 2021-11-29 05:26:18 --> Loader Class Initialized
INFO - 2021-11-29 05:26:18 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:18 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:18 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:18 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:18 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:18 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:18 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:18 --> Total execution time: 0.1195
INFO - 2021-11-29 05:26:21 --> Config Class Initialized
INFO - 2021-11-29 05:26:21 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:21 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:21 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:21 --> URI Class Initialized
INFO - 2021-11-29 05:26:21 --> Router Class Initialized
INFO - 2021-11-29 05:26:21 --> Output Class Initialized
INFO - 2021-11-29 05:26:21 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:21 --> Input Class Initialized
INFO - 2021-11-29 05:26:21 --> Language Class Initialized
INFO - 2021-11-29 05:26:21 --> Language Class Initialized
INFO - 2021-11-29 05:26:21 --> Config Class Initialized
INFO - 2021-11-29 05:26:21 --> Loader Class Initialized
INFO - 2021-11-29 05:26:21 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:21 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:21 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:21 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:21 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:21 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:21 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:21 --> Total execution time: 0.1545
INFO - 2021-11-29 05:26:23 --> Config Class Initialized
INFO - 2021-11-29 05:26:23 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:23 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:23 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:23 --> URI Class Initialized
INFO - 2021-11-29 05:26:23 --> Router Class Initialized
INFO - 2021-11-29 05:26:23 --> Output Class Initialized
INFO - 2021-11-29 05:26:23 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:23 --> Input Class Initialized
INFO - 2021-11-29 05:26:23 --> Language Class Initialized
INFO - 2021-11-29 05:26:23 --> Language Class Initialized
INFO - 2021-11-29 05:26:23 --> Config Class Initialized
INFO - 2021-11-29 05:26:23 --> Loader Class Initialized
INFO - 2021-11-29 05:26:23 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:23 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:23 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:23 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:23 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:23 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:23 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:23 --> Total execution time: 0.1331
INFO - 2021-11-29 05:26:26 --> Config Class Initialized
INFO - 2021-11-29 05:26:26 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:26 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:26 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:26 --> URI Class Initialized
INFO - 2021-11-29 05:26:26 --> Router Class Initialized
INFO - 2021-11-29 05:26:26 --> Output Class Initialized
INFO - 2021-11-29 05:26:26 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:26 --> Input Class Initialized
INFO - 2021-11-29 05:26:26 --> Language Class Initialized
INFO - 2021-11-29 05:26:26 --> Language Class Initialized
INFO - 2021-11-29 05:26:26 --> Config Class Initialized
INFO - 2021-11-29 05:26:26 --> Loader Class Initialized
INFO - 2021-11-29 05:26:26 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:26 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:26 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:26 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:26 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:26 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:26 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:26 --> Total execution time: 0.1526
INFO - 2021-11-29 05:26:28 --> Config Class Initialized
INFO - 2021-11-29 05:26:28 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:28 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:28 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:28 --> URI Class Initialized
INFO - 2021-11-29 05:26:28 --> Router Class Initialized
INFO - 2021-11-29 05:26:28 --> Output Class Initialized
INFO - 2021-11-29 05:26:28 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:28 --> Input Class Initialized
INFO - 2021-11-29 05:26:28 --> Language Class Initialized
INFO - 2021-11-29 05:26:28 --> Language Class Initialized
INFO - 2021-11-29 05:26:28 --> Config Class Initialized
INFO - 2021-11-29 05:26:28 --> Loader Class Initialized
INFO - 2021-11-29 05:26:28 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:28 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:28 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:28 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:28 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:28 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:28 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:28 --> Total execution time: 0.1182
INFO - 2021-11-29 05:26:30 --> Config Class Initialized
INFO - 2021-11-29 05:26:30 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:30 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:30 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:30 --> URI Class Initialized
INFO - 2021-11-29 05:26:30 --> Router Class Initialized
INFO - 2021-11-29 05:26:30 --> Output Class Initialized
INFO - 2021-11-29 05:26:30 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:30 --> Input Class Initialized
INFO - 2021-11-29 05:26:30 --> Language Class Initialized
INFO - 2021-11-29 05:26:30 --> Language Class Initialized
INFO - 2021-11-29 05:26:30 --> Config Class Initialized
INFO - 2021-11-29 05:26:30 --> Loader Class Initialized
INFO - 2021-11-29 05:26:30 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:30 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:30 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:30 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:30 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:30 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:30 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:30 --> Total execution time: 0.1288
INFO - 2021-11-29 05:26:32 --> Config Class Initialized
INFO - 2021-11-29 05:26:32 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:32 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:32 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:32 --> URI Class Initialized
INFO - 2021-11-29 05:26:32 --> Router Class Initialized
INFO - 2021-11-29 05:26:32 --> Output Class Initialized
INFO - 2021-11-29 05:26:32 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:32 --> Input Class Initialized
INFO - 2021-11-29 05:26:32 --> Language Class Initialized
INFO - 2021-11-29 05:26:32 --> Language Class Initialized
INFO - 2021-11-29 05:26:32 --> Config Class Initialized
INFO - 2021-11-29 05:26:32 --> Loader Class Initialized
INFO - 2021-11-29 05:26:32 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:32 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:32 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:32 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:32 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:32 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:32 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:32 --> Total execution time: 0.2053
INFO - 2021-11-29 05:26:34 --> Config Class Initialized
INFO - 2021-11-29 05:26:34 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:34 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:34 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:34 --> URI Class Initialized
INFO - 2021-11-29 05:26:34 --> Router Class Initialized
INFO - 2021-11-29 05:26:34 --> Output Class Initialized
INFO - 2021-11-29 05:26:34 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:34 --> Input Class Initialized
INFO - 2021-11-29 05:26:34 --> Language Class Initialized
INFO - 2021-11-29 05:26:34 --> Language Class Initialized
INFO - 2021-11-29 05:26:34 --> Config Class Initialized
INFO - 2021-11-29 05:26:34 --> Loader Class Initialized
INFO - 2021-11-29 05:26:34 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:34 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:34 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:34 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:34 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:34 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:34 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:34 --> Total execution time: 0.1435
INFO - 2021-11-29 05:26:36 --> Config Class Initialized
INFO - 2021-11-29 05:26:36 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:36 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:36 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:36 --> URI Class Initialized
INFO - 2021-11-29 05:26:36 --> Router Class Initialized
INFO - 2021-11-29 05:26:36 --> Output Class Initialized
INFO - 2021-11-29 05:26:36 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:36 --> Input Class Initialized
INFO - 2021-11-29 05:26:36 --> Language Class Initialized
INFO - 2021-11-29 05:26:36 --> Language Class Initialized
INFO - 2021-11-29 05:26:36 --> Config Class Initialized
INFO - 2021-11-29 05:26:36 --> Loader Class Initialized
INFO - 2021-11-29 05:26:36 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:36 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:36 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:36 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:36 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:36 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:36 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:36 --> Total execution time: 0.1272
INFO - 2021-11-29 05:26:38 --> Config Class Initialized
INFO - 2021-11-29 05:26:38 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:38 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:38 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:38 --> URI Class Initialized
INFO - 2021-11-29 05:26:38 --> Router Class Initialized
INFO - 2021-11-29 05:26:38 --> Output Class Initialized
INFO - 2021-11-29 05:26:38 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:38 --> Input Class Initialized
INFO - 2021-11-29 05:26:38 --> Language Class Initialized
INFO - 2021-11-29 05:26:38 --> Language Class Initialized
INFO - 2021-11-29 05:26:38 --> Config Class Initialized
INFO - 2021-11-29 05:26:38 --> Loader Class Initialized
INFO - 2021-11-29 05:26:38 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:38 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:38 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:38 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:38 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:38 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:38 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:38 --> Total execution time: 0.1297
INFO - 2021-11-29 05:26:41 --> Config Class Initialized
INFO - 2021-11-29 05:26:41 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:41 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:41 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:41 --> URI Class Initialized
INFO - 2021-11-29 05:26:41 --> Router Class Initialized
INFO - 2021-11-29 05:26:41 --> Output Class Initialized
INFO - 2021-11-29 05:26:41 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:41 --> Input Class Initialized
INFO - 2021-11-29 05:26:41 --> Language Class Initialized
INFO - 2021-11-29 05:26:41 --> Language Class Initialized
INFO - 2021-11-29 05:26:41 --> Config Class Initialized
INFO - 2021-11-29 05:26:41 --> Loader Class Initialized
INFO - 2021-11-29 05:26:41 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:41 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:41 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:41 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:41 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:41 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:41 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:41 --> Total execution time: 0.1206
INFO - 2021-11-29 05:26:43 --> Config Class Initialized
INFO - 2021-11-29 05:26:43 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:43 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:43 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:43 --> URI Class Initialized
INFO - 2021-11-29 05:26:43 --> Router Class Initialized
INFO - 2021-11-29 05:26:43 --> Output Class Initialized
INFO - 2021-11-29 05:26:43 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:43 --> Input Class Initialized
INFO - 2021-11-29 05:26:43 --> Language Class Initialized
INFO - 2021-11-29 05:26:43 --> Language Class Initialized
INFO - 2021-11-29 05:26:43 --> Config Class Initialized
INFO - 2021-11-29 05:26:43 --> Loader Class Initialized
INFO - 2021-11-29 05:26:43 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:43 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:43 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:43 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:43 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:43 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:43 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:43 --> Total execution time: 0.1599
INFO - 2021-11-29 05:26:48 --> Config Class Initialized
INFO - 2021-11-29 05:26:48 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:48 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:48 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:48 --> URI Class Initialized
INFO - 2021-11-29 05:26:48 --> Router Class Initialized
INFO - 2021-11-29 05:26:48 --> Output Class Initialized
INFO - 2021-11-29 05:26:48 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:48 --> Input Class Initialized
INFO - 2021-11-29 05:26:48 --> Language Class Initialized
INFO - 2021-11-29 05:26:48 --> Language Class Initialized
INFO - 2021-11-29 05:26:48 --> Config Class Initialized
INFO - 2021-11-29 05:26:48 --> Loader Class Initialized
INFO - 2021-11-29 05:26:48 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:48 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:48 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:48 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:48 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:48 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:48 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:48 --> Total execution time: 0.1484
INFO - 2021-11-29 05:26:50 --> Config Class Initialized
INFO - 2021-11-29 05:26:50 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:50 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:50 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:50 --> URI Class Initialized
INFO - 2021-11-29 05:26:50 --> Router Class Initialized
INFO - 2021-11-29 05:26:50 --> Output Class Initialized
INFO - 2021-11-29 05:26:50 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:50 --> Input Class Initialized
INFO - 2021-11-29 05:26:50 --> Language Class Initialized
INFO - 2021-11-29 05:26:50 --> Language Class Initialized
INFO - 2021-11-29 05:26:50 --> Config Class Initialized
INFO - 2021-11-29 05:26:50 --> Loader Class Initialized
INFO - 2021-11-29 05:26:50 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:50 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:50 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:50 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:50 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:50 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:50 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:50 --> Total execution time: 0.1576
INFO - 2021-11-29 05:26:53 --> Config Class Initialized
INFO - 2021-11-29 05:26:53 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:53 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:53 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:53 --> URI Class Initialized
INFO - 2021-11-29 05:26:53 --> Router Class Initialized
INFO - 2021-11-29 05:26:53 --> Output Class Initialized
INFO - 2021-11-29 05:26:53 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:53 --> Input Class Initialized
INFO - 2021-11-29 05:26:53 --> Language Class Initialized
INFO - 2021-11-29 05:26:53 --> Language Class Initialized
INFO - 2021-11-29 05:26:53 --> Config Class Initialized
INFO - 2021-11-29 05:26:53 --> Loader Class Initialized
INFO - 2021-11-29 05:26:53 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:53 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:53 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:53 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:53 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:53 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:53 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:53 --> Total execution time: 0.1529
INFO - 2021-11-29 05:26:55 --> Config Class Initialized
INFO - 2021-11-29 05:26:55 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:55 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:55 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:55 --> URI Class Initialized
INFO - 2021-11-29 05:26:55 --> Router Class Initialized
INFO - 2021-11-29 05:26:55 --> Output Class Initialized
INFO - 2021-11-29 05:26:55 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:55 --> Input Class Initialized
INFO - 2021-11-29 05:26:55 --> Language Class Initialized
INFO - 2021-11-29 05:26:55 --> Language Class Initialized
INFO - 2021-11-29 05:26:55 --> Config Class Initialized
INFO - 2021-11-29 05:26:55 --> Loader Class Initialized
INFO - 2021-11-29 05:26:55 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:55 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:55 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:55 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:55 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:55 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:55 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:55 --> Total execution time: 0.1537
INFO - 2021-11-29 05:26:57 --> Config Class Initialized
INFO - 2021-11-29 05:26:57 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:26:57 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:26:57 --> Utf8 Class Initialized
INFO - 2021-11-29 05:26:57 --> URI Class Initialized
INFO - 2021-11-29 05:26:57 --> Router Class Initialized
INFO - 2021-11-29 05:26:57 --> Output Class Initialized
INFO - 2021-11-29 05:26:57 --> Security Class Initialized
DEBUG - 2021-11-29 05:26:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:26:57 --> Input Class Initialized
INFO - 2021-11-29 05:26:57 --> Language Class Initialized
INFO - 2021-11-29 05:26:57 --> Language Class Initialized
INFO - 2021-11-29 05:26:57 --> Config Class Initialized
INFO - 2021-11-29 05:26:57 --> Loader Class Initialized
INFO - 2021-11-29 05:26:57 --> Helper loaded: url_helper
INFO - 2021-11-29 05:26:57 --> Helper loaded: file_helper
INFO - 2021-11-29 05:26:57 --> Helper loaded: form_helper
INFO - 2021-11-29 05:26:57 --> Helper loaded: my_helper
INFO - 2021-11-29 05:26:57 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:26:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:26:57 --> Controller Class Initialized
DEBUG - 2021-11-29 05:26:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_to.php
INFO - 2021-11-29 05:26:57 --> Final output sent to browser
DEBUG - 2021-11-29 05:26:57 --> Total execution time: 0.1671
INFO - 2021-11-29 05:32:11 --> Config Class Initialized
INFO - 2021-11-29 05:32:11 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:11 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:11 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:11 --> URI Class Initialized
INFO - 2021-11-29 05:32:11 --> Router Class Initialized
INFO - 2021-11-29 05:32:11 --> Output Class Initialized
INFO - 2021-11-29 05:32:11 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:11 --> Input Class Initialized
INFO - 2021-11-29 05:32:11 --> Language Class Initialized
INFO - 2021-11-29 05:32:11 --> Language Class Initialized
INFO - 2021-11-29 05:32:11 --> Config Class Initialized
INFO - 2021-11-29 05:32:11 --> Loader Class Initialized
INFO - 2021-11-29 05:32:11 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:11 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:11 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:11 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:11 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:11 --> Controller Class Initialized
INFO - 2021-11-29 05:32:11 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:32:11 --> Config Class Initialized
INFO - 2021-11-29 05:32:11 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:11 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:11 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:11 --> URI Class Initialized
INFO - 2021-11-29 05:32:11 --> Router Class Initialized
INFO - 2021-11-29 05:32:11 --> Output Class Initialized
INFO - 2021-11-29 05:32:11 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:11 --> Input Class Initialized
INFO - 2021-11-29 05:32:11 --> Language Class Initialized
INFO - 2021-11-29 05:32:11 --> Language Class Initialized
INFO - 2021-11-29 05:32:11 --> Config Class Initialized
INFO - 2021-11-29 05:32:11 --> Loader Class Initialized
INFO - 2021-11-29 05:32:11 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:11 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:11 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:11 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:11 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:11 --> Controller Class Initialized
DEBUG - 2021-11-29 05:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-29 05:32:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:32:11 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:11 --> Total execution time: 0.0911
INFO - 2021-11-29 05:32:27 --> Config Class Initialized
INFO - 2021-11-29 05:32:27 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:27 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:27 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:27 --> URI Class Initialized
INFO - 2021-11-29 05:32:27 --> Router Class Initialized
INFO - 2021-11-29 05:32:27 --> Output Class Initialized
INFO - 2021-11-29 05:32:27 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:27 --> Input Class Initialized
INFO - 2021-11-29 05:32:27 --> Language Class Initialized
INFO - 2021-11-29 05:32:27 --> Language Class Initialized
INFO - 2021-11-29 05:32:27 --> Config Class Initialized
INFO - 2021-11-29 05:32:27 --> Loader Class Initialized
INFO - 2021-11-29 05:32:27 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:27 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:27 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:27 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:27 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:27 --> Controller Class Initialized
INFO - 2021-11-29 05:32:27 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:32:27 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:27 --> Total execution time: 0.0750
INFO - 2021-11-29 05:32:28 --> Config Class Initialized
INFO - 2021-11-29 05:32:28 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:28 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:28 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:28 --> URI Class Initialized
INFO - 2021-11-29 05:32:28 --> Router Class Initialized
INFO - 2021-11-29 05:32:28 --> Output Class Initialized
INFO - 2021-11-29 05:32:28 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:28 --> Input Class Initialized
INFO - 2021-11-29 05:32:28 --> Language Class Initialized
INFO - 2021-11-29 05:32:28 --> Language Class Initialized
INFO - 2021-11-29 05:32:28 --> Config Class Initialized
INFO - 2021-11-29 05:32:28 --> Loader Class Initialized
INFO - 2021-11-29 05:32:28 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:28 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:28 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:28 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:28 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:28 --> Controller Class Initialized
DEBUG - 2021-11-29 05:32:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-29 05:32:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:32:28 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:28 --> Total execution time: 0.2462
INFO - 2021-11-29 05:32:30 --> Config Class Initialized
INFO - 2021-11-29 05:32:30 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:30 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:30 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:30 --> URI Class Initialized
INFO - 2021-11-29 05:32:30 --> Router Class Initialized
INFO - 2021-11-29 05:32:30 --> Output Class Initialized
INFO - 2021-11-29 05:32:30 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:30 --> Input Class Initialized
INFO - 2021-11-29 05:32:30 --> Language Class Initialized
INFO - 2021-11-29 05:32:30 --> Language Class Initialized
INFO - 2021-11-29 05:32:30 --> Config Class Initialized
INFO - 2021-11-29 05:32:30 --> Loader Class Initialized
INFO - 2021-11-29 05:32:30 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:30 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:30 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:30 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:30 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:30 --> Controller Class Initialized
DEBUG - 2021-11-29 05:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2021-11-29 05:32:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:32:30 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:30 --> Total execution time: 0.0807
INFO - 2021-11-29 05:32:30 --> Config Class Initialized
INFO - 2021-11-29 05:32:30 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:30 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:30 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:30 --> URI Class Initialized
INFO - 2021-11-29 05:32:30 --> Router Class Initialized
INFO - 2021-11-29 05:32:30 --> Output Class Initialized
INFO - 2021-11-29 05:32:30 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:30 --> Input Class Initialized
INFO - 2021-11-29 05:32:30 --> Language Class Initialized
INFO - 2021-11-29 05:32:30 --> Language Class Initialized
INFO - 2021-11-29 05:32:30 --> Config Class Initialized
INFO - 2021-11-29 05:32:30 --> Loader Class Initialized
INFO - 2021-11-29 05:32:30 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:30 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:30 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:30 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:30 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:30 --> Controller Class Initialized
INFO - 2021-11-29 05:32:32 --> Config Class Initialized
INFO - 2021-11-29 05:32:32 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:32 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:32 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:32 --> URI Class Initialized
INFO - 2021-11-29 05:32:32 --> Router Class Initialized
INFO - 2021-11-29 05:32:32 --> Output Class Initialized
INFO - 2021-11-29 05:32:32 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:32 --> Input Class Initialized
INFO - 2021-11-29 05:32:32 --> Language Class Initialized
INFO - 2021-11-29 05:32:32 --> Language Class Initialized
INFO - 2021-11-29 05:32:32 --> Config Class Initialized
INFO - 2021-11-29 05:32:32 --> Loader Class Initialized
INFO - 2021-11-29 05:32:32 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:32 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:32 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:32 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:32 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:32 --> Controller Class Initialized
INFO - 2021-11-29 05:32:32 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:32 --> Total execution time: 0.0735
INFO - 2021-11-29 05:32:33 --> Config Class Initialized
INFO - 2021-11-29 05:32:33 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:33 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:33 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:33 --> URI Class Initialized
INFO - 2021-11-29 05:32:33 --> Router Class Initialized
INFO - 2021-11-29 05:32:33 --> Output Class Initialized
INFO - 2021-11-29 05:32:33 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:33 --> Input Class Initialized
INFO - 2021-11-29 05:32:33 --> Language Class Initialized
INFO - 2021-11-29 05:32:33 --> Language Class Initialized
INFO - 2021-11-29 05:32:33 --> Config Class Initialized
INFO - 2021-11-29 05:32:33 --> Loader Class Initialized
INFO - 2021-11-29 05:32:33 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:33 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:33 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:33 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:33 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:33 --> Controller Class Initialized
INFO - 2021-11-29 05:32:35 --> Config Class Initialized
INFO - 2021-11-29 05:32:35 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:35 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:35 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:35 --> URI Class Initialized
INFO - 2021-11-29 05:32:35 --> Router Class Initialized
INFO - 2021-11-29 05:32:35 --> Output Class Initialized
INFO - 2021-11-29 05:32:35 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:35 --> Input Class Initialized
INFO - 2021-11-29 05:32:35 --> Language Class Initialized
INFO - 2021-11-29 05:32:35 --> Language Class Initialized
INFO - 2021-11-29 05:32:35 --> Config Class Initialized
INFO - 2021-11-29 05:32:35 --> Loader Class Initialized
INFO - 2021-11-29 05:32:35 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:35 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:35 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:35 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:35 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:35 --> Controller Class Initialized
INFO - 2021-11-29 05:32:35 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:32:35 --> Config Class Initialized
INFO - 2021-11-29 05:32:35 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:35 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:35 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:35 --> URI Class Initialized
INFO - 2021-11-29 05:32:35 --> Router Class Initialized
INFO - 2021-11-29 05:32:35 --> Output Class Initialized
INFO - 2021-11-29 05:32:35 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:35 --> Input Class Initialized
INFO - 2021-11-29 05:32:35 --> Language Class Initialized
INFO - 2021-11-29 05:32:35 --> Language Class Initialized
INFO - 2021-11-29 05:32:35 --> Config Class Initialized
INFO - 2021-11-29 05:32:35 --> Loader Class Initialized
INFO - 2021-11-29 05:32:35 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:35 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:35 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:35 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:35 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:35 --> Controller Class Initialized
DEBUG - 2021-11-29 05:32:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-29 05:32:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:32:35 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:35 --> Total execution time: 0.0809
INFO - 2021-11-29 05:32:44 --> Config Class Initialized
INFO - 2021-11-29 05:32:44 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:44 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:44 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:44 --> URI Class Initialized
INFO - 2021-11-29 05:32:44 --> Router Class Initialized
INFO - 2021-11-29 05:32:44 --> Output Class Initialized
INFO - 2021-11-29 05:32:44 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:44 --> Input Class Initialized
INFO - 2021-11-29 05:32:44 --> Language Class Initialized
INFO - 2021-11-29 05:32:44 --> Language Class Initialized
INFO - 2021-11-29 05:32:44 --> Config Class Initialized
INFO - 2021-11-29 05:32:44 --> Loader Class Initialized
INFO - 2021-11-29 05:32:44 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:44 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:44 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:44 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:44 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:44 --> Controller Class Initialized
INFO - 2021-11-29 05:32:44 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:32:44 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:44 --> Total execution time: 0.0742
INFO - 2021-11-29 05:32:44 --> Config Class Initialized
INFO - 2021-11-29 05:32:44 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:44 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:44 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:44 --> URI Class Initialized
INFO - 2021-11-29 05:32:44 --> Router Class Initialized
INFO - 2021-11-29 05:32:44 --> Output Class Initialized
INFO - 2021-11-29 05:32:44 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:44 --> Input Class Initialized
INFO - 2021-11-29 05:32:44 --> Language Class Initialized
INFO - 2021-11-29 05:32:44 --> Language Class Initialized
INFO - 2021-11-29 05:32:44 --> Config Class Initialized
INFO - 2021-11-29 05:32:44 --> Loader Class Initialized
INFO - 2021-11-29 05:32:44 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:44 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:44 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:44 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:44 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:44 --> Controller Class Initialized
DEBUG - 2021-11-29 05:32:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-29 05:32:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:32:44 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:44 --> Total execution time: 0.2009
INFO - 2021-11-29 05:32:58 --> Config Class Initialized
INFO - 2021-11-29 05:32:58 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:58 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:58 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:58 --> URI Class Initialized
INFO - 2021-11-29 05:32:58 --> Router Class Initialized
INFO - 2021-11-29 05:32:58 --> Output Class Initialized
INFO - 2021-11-29 05:32:58 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:58 --> Input Class Initialized
INFO - 2021-11-29 05:32:58 --> Language Class Initialized
INFO - 2021-11-29 05:32:58 --> Language Class Initialized
INFO - 2021-11-29 05:32:58 --> Config Class Initialized
INFO - 2021-11-29 05:32:58 --> Loader Class Initialized
INFO - 2021-11-29 05:32:58 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:58 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:58 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:58 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:58 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:58 --> Controller Class Initialized
INFO - 2021-11-29 05:32:58 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:32:58 --> Config Class Initialized
INFO - 2021-11-29 05:32:58 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:32:58 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:32:58 --> Utf8 Class Initialized
INFO - 2021-11-29 05:32:58 --> URI Class Initialized
INFO - 2021-11-29 05:32:58 --> Router Class Initialized
INFO - 2021-11-29 05:32:58 --> Output Class Initialized
INFO - 2021-11-29 05:32:58 --> Security Class Initialized
DEBUG - 2021-11-29 05:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:32:58 --> Input Class Initialized
INFO - 2021-11-29 05:32:58 --> Language Class Initialized
INFO - 2021-11-29 05:32:58 --> Language Class Initialized
INFO - 2021-11-29 05:32:58 --> Config Class Initialized
INFO - 2021-11-29 05:32:58 --> Loader Class Initialized
INFO - 2021-11-29 05:32:58 --> Helper loaded: url_helper
INFO - 2021-11-29 05:32:58 --> Helper loaded: file_helper
INFO - 2021-11-29 05:32:58 --> Helper loaded: form_helper
INFO - 2021-11-29 05:32:58 --> Helper loaded: my_helper
INFO - 2021-11-29 05:32:58 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:32:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:32:58 --> Controller Class Initialized
DEBUG - 2021-11-29 05:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-29 05:32:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:32:58 --> Final output sent to browser
DEBUG - 2021-11-29 05:32:58 --> Total execution time: 0.0512
INFO - 2021-11-29 05:33:06 --> Config Class Initialized
INFO - 2021-11-29 05:33:06 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:33:06 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:33:06 --> Utf8 Class Initialized
INFO - 2021-11-29 05:33:06 --> URI Class Initialized
INFO - 2021-11-29 05:33:06 --> Router Class Initialized
INFO - 2021-11-29 05:33:06 --> Output Class Initialized
INFO - 2021-11-29 05:33:06 --> Security Class Initialized
DEBUG - 2021-11-29 05:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:33:06 --> Input Class Initialized
INFO - 2021-11-29 05:33:06 --> Language Class Initialized
INFO - 2021-11-29 05:33:06 --> Language Class Initialized
INFO - 2021-11-29 05:33:06 --> Config Class Initialized
INFO - 2021-11-29 05:33:06 --> Loader Class Initialized
INFO - 2021-11-29 05:33:06 --> Helper loaded: url_helper
INFO - 2021-11-29 05:33:06 --> Helper loaded: file_helper
INFO - 2021-11-29 05:33:06 --> Helper loaded: form_helper
INFO - 2021-11-29 05:33:06 --> Helper loaded: my_helper
INFO - 2021-11-29 05:33:06 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:33:06 --> Controller Class Initialized
INFO - 2021-11-29 05:33:06 --> Helper loaded: cookie_helper
INFO - 2021-11-29 05:33:06 --> Final output sent to browser
DEBUG - 2021-11-29 05:33:06 --> Total execution time: 0.0940
INFO - 2021-11-29 05:33:07 --> Config Class Initialized
INFO - 2021-11-29 05:33:07 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:33:07 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:33:07 --> Utf8 Class Initialized
INFO - 2021-11-29 05:33:07 --> URI Class Initialized
INFO - 2021-11-29 05:33:07 --> Router Class Initialized
INFO - 2021-11-29 05:33:07 --> Output Class Initialized
INFO - 2021-11-29 05:33:07 --> Security Class Initialized
DEBUG - 2021-11-29 05:33:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:33:07 --> Input Class Initialized
INFO - 2021-11-29 05:33:07 --> Language Class Initialized
INFO - 2021-11-29 05:33:07 --> Language Class Initialized
INFO - 2021-11-29 05:33:07 --> Config Class Initialized
INFO - 2021-11-29 05:33:07 --> Loader Class Initialized
INFO - 2021-11-29 05:33:07 --> Helper loaded: url_helper
INFO - 2021-11-29 05:33:07 --> Helper loaded: file_helper
INFO - 2021-11-29 05:33:07 --> Helper loaded: form_helper
INFO - 2021-11-29 05:33:07 --> Helper loaded: my_helper
INFO - 2021-11-29 05:33:07 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:33:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:33:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:33:07 --> Controller Class Initialized
DEBUG - 2021-11-29 05:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-29 05:33:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:33:07 --> Final output sent to browser
DEBUG - 2021-11-29 05:33:07 --> Total execution time: 0.1874
INFO - 2021-11-29 05:33:14 --> Config Class Initialized
INFO - 2021-11-29 05:33:14 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:33:14 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:33:14 --> Utf8 Class Initialized
INFO - 2021-11-29 05:33:14 --> URI Class Initialized
INFO - 2021-11-29 05:33:14 --> Router Class Initialized
INFO - 2021-11-29 05:33:14 --> Output Class Initialized
INFO - 2021-11-29 05:33:14 --> Security Class Initialized
DEBUG - 2021-11-29 05:33:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:33:14 --> Input Class Initialized
INFO - 2021-11-29 05:33:14 --> Language Class Initialized
INFO - 2021-11-29 05:33:14 --> Language Class Initialized
INFO - 2021-11-29 05:33:14 --> Config Class Initialized
INFO - 2021-11-29 05:33:14 --> Loader Class Initialized
INFO - 2021-11-29 05:33:14 --> Helper loaded: url_helper
INFO - 2021-11-29 05:33:14 --> Helper loaded: file_helper
INFO - 2021-11-29 05:33:14 --> Helper loaded: form_helper
INFO - 2021-11-29 05:33:14 --> Helper loaded: my_helper
INFO - 2021-11-29 05:33:14 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:33:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:33:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:33:14 --> Controller Class Initialized
DEBUG - 2021-11-29 05:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-11-29 05:33:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:33:14 --> Final output sent to browser
DEBUG - 2021-11-29 05:33:14 --> Total execution time: 0.0756
INFO - 2021-11-29 05:33:16 --> Config Class Initialized
INFO - 2021-11-29 05:33:16 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:33:16 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:33:16 --> Utf8 Class Initialized
INFO - 2021-11-29 05:33:16 --> URI Class Initialized
INFO - 2021-11-29 05:33:16 --> Router Class Initialized
INFO - 2021-11-29 05:33:16 --> Output Class Initialized
INFO - 2021-11-29 05:33:16 --> Security Class Initialized
DEBUG - 2021-11-29 05:33:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:33:16 --> Input Class Initialized
INFO - 2021-11-29 05:33:16 --> Language Class Initialized
INFO - 2021-11-29 05:33:16 --> Language Class Initialized
INFO - 2021-11-29 05:33:16 --> Config Class Initialized
INFO - 2021-11-29 05:33:16 --> Loader Class Initialized
INFO - 2021-11-29 05:33:16 --> Helper loaded: url_helper
INFO - 2021-11-29 05:33:16 --> Helper loaded: file_helper
INFO - 2021-11-29 05:33:16 --> Helper loaded: form_helper
INFO - 2021-11-29 05:33:16 --> Helper loaded: my_helper
INFO - 2021-11-29 05:33:16 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:33:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:33:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:33:16 --> Controller Class Initialized
DEBUG - 2021-11-29 05:33:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:33:16 --> Final output sent to browser
DEBUG - 2021-11-29 05:33:16 --> Total execution time: 0.1463
INFO - 2021-11-29 05:34:10 --> Config Class Initialized
INFO - 2021-11-29 05:34:10 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:10 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:10 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:10 --> URI Class Initialized
INFO - 2021-11-29 05:34:10 --> Router Class Initialized
INFO - 2021-11-29 05:34:10 --> Output Class Initialized
INFO - 2021-11-29 05:34:10 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:10 --> Input Class Initialized
INFO - 2021-11-29 05:34:10 --> Language Class Initialized
INFO - 2021-11-29 05:34:10 --> Language Class Initialized
INFO - 2021-11-29 05:34:10 --> Config Class Initialized
INFO - 2021-11-29 05:34:10 --> Loader Class Initialized
INFO - 2021-11-29 05:34:10 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:10 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:10 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:10 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:10 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:10 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-29 05:34:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 05:34:10 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:10 --> Total execution time: 0.0688
INFO - 2021-11-29 05:34:14 --> Config Class Initialized
INFO - 2021-11-29 05:34:14 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:14 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:14 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:14 --> URI Class Initialized
INFO - 2021-11-29 05:34:14 --> Router Class Initialized
INFO - 2021-11-29 05:34:14 --> Output Class Initialized
INFO - 2021-11-29 05:34:14 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:14 --> Input Class Initialized
INFO - 2021-11-29 05:34:14 --> Language Class Initialized
INFO - 2021-11-29 05:34:14 --> Language Class Initialized
INFO - 2021-11-29 05:34:14 --> Config Class Initialized
INFO - 2021-11-29 05:34:14 --> Loader Class Initialized
INFO - 2021-11-29 05:34:14 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:14 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:14 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:14 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:14 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:14 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:14 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:14 --> Total execution time: 0.1577
INFO - 2021-11-29 05:34:39 --> Config Class Initialized
INFO - 2021-11-29 05:34:39 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:39 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:39 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:39 --> URI Class Initialized
INFO - 2021-11-29 05:34:39 --> Router Class Initialized
INFO - 2021-11-29 05:34:39 --> Output Class Initialized
INFO - 2021-11-29 05:34:40 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:40 --> Input Class Initialized
INFO - 2021-11-29 05:34:40 --> Language Class Initialized
INFO - 2021-11-29 05:34:40 --> Language Class Initialized
INFO - 2021-11-29 05:34:40 --> Config Class Initialized
INFO - 2021-11-29 05:34:40 --> Loader Class Initialized
INFO - 2021-11-29 05:34:40 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:40 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:40 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:40 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:40 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:40 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:40 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:40 --> Total execution time: 0.1344
INFO - 2021-11-29 05:34:42 --> Config Class Initialized
INFO - 2021-11-29 05:34:42 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:42 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:42 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:42 --> URI Class Initialized
INFO - 2021-11-29 05:34:42 --> Router Class Initialized
INFO - 2021-11-29 05:34:42 --> Output Class Initialized
INFO - 2021-11-29 05:34:42 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:43 --> Input Class Initialized
INFO - 2021-11-29 05:34:43 --> Language Class Initialized
INFO - 2021-11-29 05:34:43 --> Language Class Initialized
INFO - 2021-11-29 05:34:43 --> Config Class Initialized
INFO - 2021-11-29 05:34:43 --> Loader Class Initialized
INFO - 2021-11-29 05:34:43 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:43 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:43 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:43 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:43 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:43 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:43 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:43 --> Total execution time: 0.1268
INFO - 2021-11-29 05:34:44 --> Config Class Initialized
INFO - 2021-11-29 05:34:44 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:44 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:44 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:44 --> URI Class Initialized
INFO - 2021-11-29 05:34:44 --> Router Class Initialized
INFO - 2021-11-29 05:34:44 --> Output Class Initialized
INFO - 2021-11-29 05:34:44 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:44 --> Input Class Initialized
INFO - 2021-11-29 05:34:44 --> Language Class Initialized
INFO - 2021-11-29 05:34:44 --> Language Class Initialized
INFO - 2021-11-29 05:34:44 --> Config Class Initialized
INFO - 2021-11-29 05:34:44 --> Loader Class Initialized
INFO - 2021-11-29 05:34:44 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:44 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:44 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:44 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:44 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:45 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:45 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:45 --> Total execution time: 0.1271
INFO - 2021-11-29 05:34:47 --> Config Class Initialized
INFO - 2021-11-29 05:34:47 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:47 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:47 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:47 --> URI Class Initialized
INFO - 2021-11-29 05:34:47 --> Router Class Initialized
INFO - 2021-11-29 05:34:47 --> Output Class Initialized
INFO - 2021-11-29 05:34:47 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:47 --> Input Class Initialized
INFO - 2021-11-29 05:34:47 --> Language Class Initialized
INFO - 2021-11-29 05:34:47 --> Language Class Initialized
INFO - 2021-11-29 05:34:47 --> Config Class Initialized
INFO - 2021-11-29 05:34:47 --> Loader Class Initialized
INFO - 2021-11-29 05:34:47 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:47 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:47 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:47 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:47 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:47 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:47 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:47 --> Total execution time: 0.1551
INFO - 2021-11-29 05:34:50 --> Config Class Initialized
INFO - 2021-11-29 05:34:50 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:50 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:50 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:50 --> URI Class Initialized
INFO - 2021-11-29 05:34:50 --> Router Class Initialized
INFO - 2021-11-29 05:34:50 --> Output Class Initialized
INFO - 2021-11-29 05:34:50 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:50 --> Input Class Initialized
INFO - 2021-11-29 05:34:50 --> Language Class Initialized
INFO - 2021-11-29 05:34:50 --> Language Class Initialized
INFO - 2021-11-29 05:34:50 --> Config Class Initialized
INFO - 2021-11-29 05:34:50 --> Loader Class Initialized
INFO - 2021-11-29 05:34:50 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:50 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:50 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:50 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:50 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:50 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:50 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:50 --> Total execution time: 0.1338
INFO - 2021-11-29 05:34:53 --> Config Class Initialized
INFO - 2021-11-29 05:34:53 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:53 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:53 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:53 --> URI Class Initialized
INFO - 2021-11-29 05:34:53 --> Router Class Initialized
INFO - 2021-11-29 05:34:53 --> Output Class Initialized
INFO - 2021-11-29 05:34:53 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:53 --> Input Class Initialized
INFO - 2021-11-29 05:34:53 --> Language Class Initialized
INFO - 2021-11-29 05:34:53 --> Language Class Initialized
INFO - 2021-11-29 05:34:53 --> Config Class Initialized
INFO - 2021-11-29 05:34:53 --> Loader Class Initialized
INFO - 2021-11-29 05:34:53 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:53 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:53 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:53 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:53 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:53 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:53 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:53 --> Total execution time: 0.1252
INFO - 2021-11-29 05:34:54 --> Config Class Initialized
INFO - 2021-11-29 05:34:54 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:54 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:54 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:54 --> URI Class Initialized
INFO - 2021-11-29 05:34:54 --> Router Class Initialized
INFO - 2021-11-29 05:34:54 --> Output Class Initialized
INFO - 2021-11-29 05:34:54 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:54 --> Input Class Initialized
INFO - 2021-11-29 05:34:54 --> Language Class Initialized
INFO - 2021-11-29 05:34:54 --> Language Class Initialized
INFO - 2021-11-29 05:34:54 --> Config Class Initialized
INFO - 2021-11-29 05:34:54 --> Loader Class Initialized
INFO - 2021-11-29 05:34:54 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:54 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:54 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:54 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:54 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:54 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:54 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:54 --> Total execution time: 0.1369
INFO - 2021-11-29 05:34:57 --> Config Class Initialized
INFO - 2021-11-29 05:34:57 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:57 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:57 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:57 --> URI Class Initialized
INFO - 2021-11-29 05:34:57 --> Router Class Initialized
INFO - 2021-11-29 05:34:57 --> Output Class Initialized
INFO - 2021-11-29 05:34:57 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:57 --> Input Class Initialized
INFO - 2021-11-29 05:34:57 --> Language Class Initialized
INFO - 2021-11-29 05:34:57 --> Language Class Initialized
INFO - 2021-11-29 05:34:57 --> Config Class Initialized
INFO - 2021-11-29 05:34:57 --> Loader Class Initialized
INFO - 2021-11-29 05:34:57 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:57 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:57 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:57 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:57 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:57 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:57 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:57 --> Total execution time: 0.1223
INFO - 2021-11-29 05:34:59 --> Config Class Initialized
INFO - 2021-11-29 05:34:59 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:34:59 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:34:59 --> Utf8 Class Initialized
INFO - 2021-11-29 05:34:59 --> URI Class Initialized
INFO - 2021-11-29 05:34:59 --> Router Class Initialized
INFO - 2021-11-29 05:34:59 --> Output Class Initialized
INFO - 2021-11-29 05:34:59 --> Security Class Initialized
DEBUG - 2021-11-29 05:34:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:34:59 --> Input Class Initialized
INFO - 2021-11-29 05:34:59 --> Language Class Initialized
INFO - 2021-11-29 05:34:59 --> Language Class Initialized
INFO - 2021-11-29 05:34:59 --> Config Class Initialized
INFO - 2021-11-29 05:34:59 --> Loader Class Initialized
INFO - 2021-11-29 05:34:59 --> Helper loaded: url_helper
INFO - 2021-11-29 05:34:59 --> Helper loaded: file_helper
INFO - 2021-11-29 05:34:59 --> Helper loaded: form_helper
INFO - 2021-11-29 05:34:59 --> Helper loaded: my_helper
INFO - 2021-11-29 05:34:59 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:34:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:34:59 --> Controller Class Initialized
DEBUG - 2021-11-29 05:34:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:34:59 --> Final output sent to browser
DEBUG - 2021-11-29 05:34:59 --> Total execution time: 0.1186
INFO - 2021-11-29 05:35:01 --> Config Class Initialized
INFO - 2021-11-29 05:35:01 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:01 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:01 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:01 --> URI Class Initialized
INFO - 2021-11-29 05:35:01 --> Router Class Initialized
INFO - 2021-11-29 05:35:01 --> Output Class Initialized
INFO - 2021-11-29 05:35:01 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:01 --> Input Class Initialized
INFO - 2021-11-29 05:35:01 --> Language Class Initialized
INFO - 2021-11-29 05:35:01 --> Language Class Initialized
INFO - 2021-11-29 05:35:01 --> Config Class Initialized
INFO - 2021-11-29 05:35:01 --> Loader Class Initialized
INFO - 2021-11-29 05:35:01 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:01 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:01 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:01 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:01 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:01 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:01 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:01 --> Total execution time: 0.1173
INFO - 2021-11-29 05:35:04 --> Config Class Initialized
INFO - 2021-11-29 05:35:04 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:04 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:04 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:04 --> URI Class Initialized
INFO - 2021-11-29 05:35:04 --> Router Class Initialized
INFO - 2021-11-29 05:35:04 --> Output Class Initialized
INFO - 2021-11-29 05:35:04 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:04 --> Input Class Initialized
INFO - 2021-11-29 05:35:04 --> Language Class Initialized
INFO - 2021-11-29 05:35:04 --> Language Class Initialized
INFO - 2021-11-29 05:35:04 --> Config Class Initialized
INFO - 2021-11-29 05:35:04 --> Loader Class Initialized
INFO - 2021-11-29 05:35:04 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:04 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:04 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:04 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:04 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:04 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:04 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:04 --> Total execution time: 0.1487
INFO - 2021-11-29 05:35:06 --> Config Class Initialized
INFO - 2021-11-29 05:35:06 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:06 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:06 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:06 --> URI Class Initialized
INFO - 2021-11-29 05:35:06 --> Router Class Initialized
INFO - 2021-11-29 05:35:06 --> Output Class Initialized
INFO - 2021-11-29 05:35:06 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:06 --> Input Class Initialized
INFO - 2021-11-29 05:35:06 --> Language Class Initialized
INFO - 2021-11-29 05:35:06 --> Language Class Initialized
INFO - 2021-11-29 05:35:06 --> Config Class Initialized
INFO - 2021-11-29 05:35:06 --> Loader Class Initialized
INFO - 2021-11-29 05:35:06 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:06 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:06 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:06 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:06 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:06 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:06 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:06 --> Total execution time: 0.1450
INFO - 2021-11-29 05:35:09 --> Config Class Initialized
INFO - 2021-11-29 05:35:09 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:09 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:09 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:09 --> URI Class Initialized
INFO - 2021-11-29 05:35:09 --> Router Class Initialized
INFO - 2021-11-29 05:35:09 --> Output Class Initialized
INFO - 2021-11-29 05:35:09 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:09 --> Input Class Initialized
INFO - 2021-11-29 05:35:09 --> Language Class Initialized
INFO - 2021-11-29 05:35:09 --> Language Class Initialized
INFO - 2021-11-29 05:35:09 --> Config Class Initialized
INFO - 2021-11-29 05:35:09 --> Loader Class Initialized
INFO - 2021-11-29 05:35:09 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:09 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:09 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:09 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:09 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:09 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:09 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:09 --> Total execution time: 0.1368
INFO - 2021-11-29 05:35:11 --> Config Class Initialized
INFO - 2021-11-29 05:35:11 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:11 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:11 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:11 --> URI Class Initialized
INFO - 2021-11-29 05:35:11 --> Router Class Initialized
INFO - 2021-11-29 05:35:11 --> Output Class Initialized
INFO - 2021-11-29 05:35:11 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:11 --> Input Class Initialized
INFO - 2021-11-29 05:35:11 --> Language Class Initialized
INFO - 2021-11-29 05:35:11 --> Language Class Initialized
INFO - 2021-11-29 05:35:11 --> Config Class Initialized
INFO - 2021-11-29 05:35:11 --> Loader Class Initialized
INFO - 2021-11-29 05:35:11 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:11 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:11 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:11 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:11 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:11 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:11 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:11 --> Total execution time: 0.1134
INFO - 2021-11-29 05:35:13 --> Config Class Initialized
INFO - 2021-11-29 05:35:13 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:13 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:13 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:13 --> URI Class Initialized
INFO - 2021-11-29 05:35:13 --> Router Class Initialized
INFO - 2021-11-29 05:35:13 --> Output Class Initialized
INFO - 2021-11-29 05:35:13 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:13 --> Input Class Initialized
INFO - 2021-11-29 05:35:13 --> Language Class Initialized
INFO - 2021-11-29 05:35:13 --> Language Class Initialized
INFO - 2021-11-29 05:35:13 --> Config Class Initialized
INFO - 2021-11-29 05:35:13 --> Loader Class Initialized
INFO - 2021-11-29 05:35:13 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:13 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:13 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:13 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:13 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:13 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:13 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:13 --> Total execution time: 0.1529
INFO - 2021-11-29 05:35:16 --> Config Class Initialized
INFO - 2021-11-29 05:35:16 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:16 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:16 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:16 --> URI Class Initialized
INFO - 2021-11-29 05:35:16 --> Router Class Initialized
INFO - 2021-11-29 05:35:16 --> Output Class Initialized
INFO - 2021-11-29 05:35:16 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:16 --> Input Class Initialized
INFO - 2021-11-29 05:35:16 --> Language Class Initialized
INFO - 2021-11-29 05:35:16 --> Language Class Initialized
INFO - 2021-11-29 05:35:16 --> Config Class Initialized
INFO - 2021-11-29 05:35:16 --> Loader Class Initialized
INFO - 2021-11-29 05:35:16 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:16 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:16 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:16 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:16 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:16 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:16 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:16 --> Total execution time: 0.1321
INFO - 2021-11-29 05:35:19 --> Config Class Initialized
INFO - 2021-11-29 05:35:19 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:19 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:19 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:19 --> URI Class Initialized
INFO - 2021-11-29 05:35:19 --> Router Class Initialized
INFO - 2021-11-29 05:35:19 --> Output Class Initialized
INFO - 2021-11-29 05:35:19 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:19 --> Input Class Initialized
INFO - 2021-11-29 05:35:19 --> Language Class Initialized
INFO - 2021-11-29 05:35:19 --> Language Class Initialized
INFO - 2021-11-29 05:35:19 --> Config Class Initialized
INFO - 2021-11-29 05:35:19 --> Loader Class Initialized
INFO - 2021-11-29 05:35:19 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:19 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:19 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:19 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:19 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:19 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:19 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:19 --> Total execution time: 0.1367
INFO - 2021-11-29 05:35:20 --> Config Class Initialized
INFO - 2021-11-29 05:35:20 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:20 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:20 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:20 --> URI Class Initialized
INFO - 2021-11-29 05:35:20 --> Router Class Initialized
INFO - 2021-11-29 05:35:21 --> Output Class Initialized
INFO - 2021-11-29 05:35:21 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:21 --> Input Class Initialized
INFO - 2021-11-29 05:35:21 --> Language Class Initialized
INFO - 2021-11-29 05:35:21 --> Language Class Initialized
INFO - 2021-11-29 05:35:21 --> Config Class Initialized
INFO - 2021-11-29 05:35:21 --> Loader Class Initialized
INFO - 2021-11-29 05:35:21 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:21 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:21 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:21 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:21 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:21 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:21 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:21 --> Total execution time: 0.1477
INFO - 2021-11-29 05:35:23 --> Config Class Initialized
INFO - 2021-11-29 05:35:23 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:23 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:23 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:23 --> URI Class Initialized
INFO - 2021-11-29 05:35:23 --> Router Class Initialized
INFO - 2021-11-29 05:35:23 --> Output Class Initialized
INFO - 2021-11-29 05:35:23 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:23 --> Input Class Initialized
INFO - 2021-11-29 05:35:23 --> Language Class Initialized
INFO - 2021-11-29 05:35:23 --> Language Class Initialized
INFO - 2021-11-29 05:35:23 --> Config Class Initialized
INFO - 2021-11-29 05:35:23 --> Loader Class Initialized
INFO - 2021-11-29 05:35:23 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:23 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:23 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:23 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:23 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:23 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:23 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:23 --> Total execution time: 0.1426
INFO - 2021-11-29 05:35:25 --> Config Class Initialized
INFO - 2021-11-29 05:35:25 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:25 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:25 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:25 --> URI Class Initialized
INFO - 2021-11-29 05:35:25 --> Router Class Initialized
INFO - 2021-11-29 05:35:25 --> Output Class Initialized
INFO - 2021-11-29 05:35:25 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:25 --> Input Class Initialized
INFO - 2021-11-29 05:35:25 --> Language Class Initialized
INFO - 2021-11-29 05:35:25 --> Language Class Initialized
INFO - 2021-11-29 05:35:25 --> Config Class Initialized
INFO - 2021-11-29 05:35:25 --> Loader Class Initialized
INFO - 2021-11-29 05:35:25 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:25 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:25 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:25 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:25 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:25 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:25 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:25 --> Total execution time: 0.1280
INFO - 2021-11-29 05:35:27 --> Config Class Initialized
INFO - 2021-11-29 05:35:27 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:27 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:27 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:27 --> URI Class Initialized
INFO - 2021-11-29 05:35:27 --> Router Class Initialized
INFO - 2021-11-29 05:35:27 --> Output Class Initialized
INFO - 2021-11-29 05:35:27 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:27 --> Input Class Initialized
INFO - 2021-11-29 05:35:27 --> Language Class Initialized
INFO - 2021-11-29 05:35:27 --> Language Class Initialized
INFO - 2021-11-29 05:35:27 --> Config Class Initialized
INFO - 2021-11-29 05:35:27 --> Loader Class Initialized
INFO - 2021-11-29 05:35:27 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:27 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:27 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:27 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:27 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:27 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:28 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:28 --> Total execution time: 0.1627
INFO - 2021-11-29 05:35:30 --> Config Class Initialized
INFO - 2021-11-29 05:35:30 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:30 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:30 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:30 --> URI Class Initialized
INFO - 2021-11-29 05:35:30 --> Router Class Initialized
INFO - 2021-11-29 05:35:30 --> Output Class Initialized
INFO - 2021-11-29 05:35:30 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:30 --> Input Class Initialized
INFO - 2021-11-29 05:35:30 --> Language Class Initialized
INFO - 2021-11-29 05:35:30 --> Language Class Initialized
INFO - 2021-11-29 05:35:30 --> Config Class Initialized
INFO - 2021-11-29 05:35:30 --> Loader Class Initialized
INFO - 2021-11-29 05:35:30 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:30 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:30 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:30 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:30 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:30 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:30 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:30 --> Total execution time: 0.1195
INFO - 2021-11-29 05:35:33 --> Config Class Initialized
INFO - 2021-11-29 05:35:33 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:33 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:33 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:33 --> URI Class Initialized
INFO - 2021-11-29 05:35:33 --> Router Class Initialized
INFO - 2021-11-29 05:35:33 --> Output Class Initialized
INFO - 2021-11-29 05:35:33 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:33 --> Input Class Initialized
INFO - 2021-11-29 05:35:33 --> Language Class Initialized
INFO - 2021-11-29 05:35:33 --> Language Class Initialized
INFO - 2021-11-29 05:35:33 --> Config Class Initialized
INFO - 2021-11-29 05:35:33 --> Loader Class Initialized
INFO - 2021-11-29 05:35:33 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:33 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:33 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:33 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:33 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:33 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:33 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:33 --> Total execution time: 0.1393
INFO - 2021-11-29 05:35:35 --> Config Class Initialized
INFO - 2021-11-29 05:35:35 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:35 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:35 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:35 --> URI Class Initialized
INFO - 2021-11-29 05:35:35 --> Router Class Initialized
INFO - 2021-11-29 05:35:35 --> Output Class Initialized
INFO - 2021-11-29 05:35:35 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:35 --> Input Class Initialized
INFO - 2021-11-29 05:35:35 --> Language Class Initialized
INFO - 2021-11-29 05:35:35 --> Language Class Initialized
INFO - 2021-11-29 05:35:35 --> Config Class Initialized
INFO - 2021-11-29 05:35:35 --> Loader Class Initialized
INFO - 2021-11-29 05:35:35 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:35 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:35 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:35 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:35 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:35 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:35 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:35 --> Total execution time: 0.1141
INFO - 2021-11-29 05:35:37 --> Config Class Initialized
INFO - 2021-11-29 05:35:37 --> Hooks Class Initialized
DEBUG - 2021-11-29 05:35:37 --> UTF-8 Support Enabled
INFO - 2021-11-29 05:35:37 --> Utf8 Class Initialized
INFO - 2021-11-29 05:35:37 --> URI Class Initialized
INFO - 2021-11-29 05:35:37 --> Router Class Initialized
INFO - 2021-11-29 05:35:37 --> Output Class Initialized
INFO - 2021-11-29 05:35:37 --> Security Class Initialized
DEBUG - 2021-11-29 05:35:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 05:35:37 --> Input Class Initialized
INFO - 2021-11-29 05:35:37 --> Language Class Initialized
INFO - 2021-11-29 05:35:37 --> Language Class Initialized
INFO - 2021-11-29 05:35:37 --> Config Class Initialized
INFO - 2021-11-29 05:35:37 --> Loader Class Initialized
INFO - 2021-11-29 05:35:37 --> Helper loaded: url_helper
INFO - 2021-11-29 05:35:37 --> Helper loaded: file_helper
INFO - 2021-11-29 05:35:37 --> Helper loaded: form_helper
INFO - 2021-11-29 05:35:37 --> Helper loaded: my_helper
INFO - 2021-11-29 05:35:37 --> Database Driver Class Initialized
DEBUG - 2021-11-29 05:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 05:35:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 05:35:37 --> Controller Class Initialized
DEBUG - 2021-11-29 05:35:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 05:35:37 --> Final output sent to browser
DEBUG - 2021-11-29 05:35:37 --> Total execution time: 0.1349
INFO - 2021-11-29 07:03:49 --> Config Class Initialized
INFO - 2021-11-29 07:03:49 --> Hooks Class Initialized
DEBUG - 2021-11-29 07:03:49 --> UTF-8 Support Enabled
INFO - 2021-11-29 07:03:49 --> Utf8 Class Initialized
INFO - 2021-11-29 07:03:49 --> URI Class Initialized
INFO - 2021-11-29 07:03:49 --> Router Class Initialized
INFO - 2021-11-29 07:03:49 --> Output Class Initialized
INFO - 2021-11-29 07:03:49 --> Security Class Initialized
DEBUG - 2021-11-29 07:03:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 07:03:49 --> Input Class Initialized
INFO - 2021-11-29 07:03:49 --> Language Class Initialized
INFO - 2021-11-29 07:03:49 --> Language Class Initialized
INFO - 2021-11-29 07:03:49 --> Config Class Initialized
INFO - 2021-11-29 07:03:49 --> Loader Class Initialized
INFO - 2021-11-29 07:03:49 --> Helper loaded: url_helper
INFO - 2021-11-29 07:03:49 --> Helper loaded: file_helper
INFO - 2021-11-29 07:03:49 --> Helper loaded: form_helper
INFO - 2021-11-29 07:03:49 --> Helper loaded: my_helper
INFO - 2021-11-29 07:03:49 --> Database Driver Class Initialized
DEBUG - 2021-11-29 07:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 07:03:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 07:03:49 --> Controller Class Initialized
DEBUG - 2021-11-29 07:03:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 07:03:49 --> Final output sent to browser
DEBUG - 2021-11-29 07:03:49 --> Total execution time: 0.1219
INFO - 2021-11-29 07:03:54 --> Config Class Initialized
INFO - 2021-11-29 07:03:54 --> Hooks Class Initialized
DEBUG - 2021-11-29 07:03:54 --> UTF-8 Support Enabled
INFO - 2021-11-29 07:03:54 --> Utf8 Class Initialized
INFO - 2021-11-29 07:03:54 --> URI Class Initialized
INFO - 2021-11-29 07:03:54 --> Router Class Initialized
INFO - 2021-11-29 07:03:54 --> Output Class Initialized
INFO - 2021-11-29 07:03:54 --> Security Class Initialized
DEBUG - 2021-11-29 07:03:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 07:03:54 --> Input Class Initialized
INFO - 2021-11-29 07:03:54 --> Language Class Initialized
INFO - 2021-11-29 07:03:54 --> Language Class Initialized
INFO - 2021-11-29 07:03:54 --> Config Class Initialized
INFO - 2021-11-29 07:03:54 --> Loader Class Initialized
INFO - 2021-11-29 07:03:54 --> Helper loaded: url_helper
INFO - 2021-11-29 07:03:54 --> Helper loaded: file_helper
INFO - 2021-11-29 07:03:54 --> Helper loaded: form_helper
INFO - 2021-11-29 07:03:54 --> Helper loaded: my_helper
INFO - 2021-11-29 07:03:54 --> Database Driver Class Initialized
DEBUG - 2021-11-29 07:03:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 07:03:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 07:03:54 --> Controller Class Initialized
DEBUG - 2021-11-29 07:03:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 07:03:54 --> Final output sent to browser
DEBUG - 2021-11-29 07:03:54 --> Total execution time: 0.1248
INFO - 2021-11-29 07:04:00 --> Config Class Initialized
INFO - 2021-11-29 07:04:00 --> Hooks Class Initialized
DEBUG - 2021-11-29 07:04:00 --> UTF-8 Support Enabled
INFO - 2021-11-29 07:04:00 --> Utf8 Class Initialized
INFO - 2021-11-29 07:04:00 --> URI Class Initialized
INFO - 2021-11-29 07:04:00 --> Router Class Initialized
INFO - 2021-11-29 07:04:00 --> Output Class Initialized
INFO - 2021-11-29 07:04:00 --> Security Class Initialized
DEBUG - 2021-11-29 07:04:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 07:04:00 --> Input Class Initialized
INFO - 2021-11-29 07:04:00 --> Language Class Initialized
INFO - 2021-11-29 07:04:00 --> Language Class Initialized
INFO - 2021-11-29 07:04:00 --> Config Class Initialized
INFO - 2021-11-29 07:04:00 --> Loader Class Initialized
INFO - 2021-11-29 07:04:00 --> Helper loaded: url_helper
INFO - 2021-11-29 07:04:00 --> Helper loaded: file_helper
INFO - 2021-11-29 07:04:00 --> Helper loaded: form_helper
INFO - 2021-11-29 07:04:00 --> Helper loaded: my_helper
INFO - 2021-11-29 07:04:00 --> Database Driver Class Initialized
DEBUG - 2021-11-29 07:04:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 07:04:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 07:04:00 --> Controller Class Initialized
DEBUG - 2021-11-29 07:04:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tkro_xi.php
INFO - 2021-11-29 07:04:00 --> Final output sent to browser
DEBUG - 2021-11-29 07:04:00 --> Total execution time: 0.1237
INFO - 2021-11-29 09:19:53 --> Config Class Initialized
INFO - 2021-11-29 09:19:53 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:19:53 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:19:53 --> Utf8 Class Initialized
INFO - 2021-11-29 09:19:53 --> URI Class Initialized
INFO - 2021-11-29 09:19:53 --> Router Class Initialized
INFO - 2021-11-29 09:19:53 --> Output Class Initialized
INFO - 2021-11-29 09:19:53 --> Security Class Initialized
DEBUG - 2021-11-29 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:19:53 --> Input Class Initialized
INFO - 2021-11-29 09:19:53 --> Language Class Initialized
INFO - 2021-11-29 09:19:53 --> Language Class Initialized
INFO - 2021-11-29 09:19:53 --> Config Class Initialized
INFO - 2021-11-29 09:19:53 --> Loader Class Initialized
INFO - 2021-11-29 09:19:53 --> Helper loaded: url_helper
INFO - 2021-11-29 09:19:53 --> Helper loaded: file_helper
INFO - 2021-11-29 09:19:53 --> Helper loaded: form_helper
INFO - 2021-11-29 09:19:53 --> Helper loaded: my_helper
INFO - 2021-11-29 09:19:53 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:19:53 --> Controller Class Initialized
INFO - 2021-11-29 09:19:53 --> Helper loaded: cookie_helper
INFO - 2021-11-29 09:19:53 --> Config Class Initialized
INFO - 2021-11-29 09:19:53 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:19:53 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:19:53 --> Utf8 Class Initialized
INFO - 2021-11-29 09:19:53 --> URI Class Initialized
INFO - 2021-11-29 09:19:53 --> Router Class Initialized
INFO - 2021-11-29 09:19:53 --> Output Class Initialized
INFO - 2021-11-29 09:19:53 --> Security Class Initialized
DEBUG - 2021-11-29 09:19:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:19:53 --> Input Class Initialized
INFO - 2021-11-29 09:19:53 --> Language Class Initialized
INFO - 2021-11-29 09:19:53 --> Language Class Initialized
INFO - 2021-11-29 09:19:53 --> Config Class Initialized
INFO - 2021-11-29 09:19:53 --> Loader Class Initialized
INFO - 2021-11-29 09:19:53 --> Helper loaded: url_helper
INFO - 2021-11-29 09:19:53 --> Helper loaded: file_helper
INFO - 2021-11-29 09:19:53 --> Helper loaded: form_helper
INFO - 2021-11-29 09:19:53 --> Helper loaded: my_helper
INFO - 2021-11-29 09:19:53 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:19:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:19:53 --> Controller Class Initialized
DEBUG - 2021-11-29 09:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-11-29 09:19:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 09:19:53 --> Final output sent to browser
DEBUG - 2021-11-29 09:19:53 --> Total execution time: 0.0601
INFO - 2021-11-29 09:20:00 --> Config Class Initialized
INFO - 2021-11-29 09:20:00 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:20:00 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:20:00 --> Utf8 Class Initialized
INFO - 2021-11-29 09:20:00 --> URI Class Initialized
INFO - 2021-11-29 09:20:00 --> Router Class Initialized
INFO - 2021-11-29 09:20:00 --> Output Class Initialized
INFO - 2021-11-29 09:20:00 --> Security Class Initialized
DEBUG - 2021-11-29 09:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:20:00 --> Input Class Initialized
INFO - 2021-11-29 09:20:00 --> Language Class Initialized
INFO - 2021-11-29 09:20:00 --> Language Class Initialized
INFO - 2021-11-29 09:20:00 --> Config Class Initialized
INFO - 2021-11-29 09:20:00 --> Loader Class Initialized
INFO - 2021-11-29 09:20:00 --> Helper loaded: url_helper
INFO - 2021-11-29 09:20:00 --> Helper loaded: file_helper
INFO - 2021-11-29 09:20:00 --> Helper loaded: form_helper
INFO - 2021-11-29 09:20:00 --> Helper loaded: my_helper
INFO - 2021-11-29 09:20:00 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:20:00 --> Controller Class Initialized
INFO - 2021-11-29 09:20:00 --> Helper loaded: cookie_helper
INFO - 2021-11-29 09:20:00 --> Final output sent to browser
DEBUG - 2021-11-29 09:20:00 --> Total execution time: 0.0743
INFO - 2021-11-29 09:20:00 --> Config Class Initialized
INFO - 2021-11-29 09:20:00 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:20:00 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:20:00 --> Utf8 Class Initialized
INFO - 2021-11-29 09:20:00 --> URI Class Initialized
INFO - 2021-11-29 09:20:00 --> Router Class Initialized
INFO - 2021-11-29 09:20:00 --> Output Class Initialized
INFO - 2021-11-29 09:20:00 --> Security Class Initialized
DEBUG - 2021-11-29 09:20:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:20:00 --> Input Class Initialized
INFO - 2021-11-29 09:20:00 --> Language Class Initialized
INFO - 2021-11-29 09:20:00 --> Language Class Initialized
INFO - 2021-11-29 09:20:00 --> Config Class Initialized
INFO - 2021-11-29 09:20:00 --> Loader Class Initialized
INFO - 2021-11-29 09:20:00 --> Helper loaded: url_helper
INFO - 2021-11-29 09:20:00 --> Helper loaded: file_helper
INFO - 2021-11-29 09:20:00 --> Helper loaded: form_helper
INFO - 2021-11-29 09:20:00 --> Helper loaded: my_helper
INFO - 2021-11-29 09:20:00 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:20:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:20:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:20:00 --> Controller Class Initialized
DEBUG - 2021-11-29 09:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-11-29 09:20:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 09:20:00 --> Final output sent to browser
DEBUG - 2021-11-29 09:20:00 --> Total execution time: 0.2248
INFO - 2021-11-29 09:20:13 --> Config Class Initialized
INFO - 2021-11-29 09:20:13 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:20:13 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:20:13 --> Utf8 Class Initialized
INFO - 2021-11-29 09:20:13 --> URI Class Initialized
INFO - 2021-11-29 09:20:13 --> Router Class Initialized
INFO - 2021-11-29 09:20:13 --> Output Class Initialized
INFO - 2021-11-29 09:20:13 --> Security Class Initialized
DEBUG - 2021-11-29 09:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:20:13 --> Input Class Initialized
INFO - 2021-11-29 09:20:13 --> Language Class Initialized
INFO - 2021-11-29 09:20:13 --> Language Class Initialized
INFO - 2021-11-29 09:20:13 --> Config Class Initialized
INFO - 2021-11-29 09:20:13 --> Loader Class Initialized
INFO - 2021-11-29 09:20:13 --> Helper loaded: url_helper
INFO - 2021-11-29 09:20:13 --> Helper loaded: file_helper
INFO - 2021-11-29 09:20:13 --> Helper loaded: form_helper
INFO - 2021-11-29 09:20:13 --> Helper loaded: my_helper
INFO - 2021-11-29 09:20:13 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:20:13 --> Controller Class Initialized
DEBUG - 2021-11-29 09:20:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/landing.php
DEBUG - 2021-11-29 09:20:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 09:20:13 --> Final output sent to browser
DEBUG - 2021-11-29 09:20:13 --> Total execution time: 0.0963
INFO - 2021-11-29 09:20:18 --> Config Class Initialized
INFO - 2021-11-29 09:20:18 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:20:18 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:20:18 --> Utf8 Class Initialized
INFO - 2021-11-29 09:20:18 --> URI Class Initialized
INFO - 2021-11-29 09:20:18 --> Router Class Initialized
INFO - 2021-11-29 09:20:18 --> Output Class Initialized
INFO - 2021-11-29 09:20:18 --> Security Class Initialized
DEBUG - 2021-11-29 09:20:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:20:18 --> Input Class Initialized
INFO - 2021-11-29 09:20:18 --> Language Class Initialized
INFO - 2021-11-29 09:20:18 --> Language Class Initialized
INFO - 2021-11-29 09:20:18 --> Config Class Initialized
INFO - 2021-11-29 09:20:18 --> Loader Class Initialized
INFO - 2021-11-29 09:20:18 --> Helper loaded: url_helper
INFO - 2021-11-29 09:20:18 --> Helper loaded: file_helper
INFO - 2021-11-29 09:20:18 --> Helper loaded: form_helper
INFO - 2021-11-29 09:20:18 --> Helper loaded: my_helper
INFO - 2021-11-29 09:20:18 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:20:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:20:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:20:18 --> Controller Class Initialized
DEBUG - 2021-11-29 09:20:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_leger/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:20:19 --> Final output sent to browser
DEBUG - 2021-11-29 09:20:19 --> Total execution time: 0.1657
INFO - 2021-11-29 09:20:50 --> Config Class Initialized
INFO - 2021-11-29 09:20:50 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:20:50 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:20:50 --> Utf8 Class Initialized
INFO - 2021-11-29 09:20:50 --> URI Class Initialized
INFO - 2021-11-29 09:20:50 --> Router Class Initialized
INFO - 2021-11-29 09:20:50 --> Output Class Initialized
INFO - 2021-11-29 09:20:50 --> Security Class Initialized
DEBUG - 2021-11-29 09:20:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:20:50 --> Input Class Initialized
INFO - 2021-11-29 09:20:50 --> Language Class Initialized
INFO - 2021-11-29 09:20:50 --> Language Class Initialized
INFO - 2021-11-29 09:20:50 --> Config Class Initialized
INFO - 2021-11-29 09:20:50 --> Loader Class Initialized
INFO - 2021-11-29 09:20:50 --> Helper loaded: url_helper
INFO - 2021-11-29 09:20:50 --> Helper loaded: file_helper
INFO - 2021-11-29 09:20:50 --> Helper loaded: form_helper
INFO - 2021-11-29 09:20:50 --> Helper loaded: my_helper
INFO - 2021-11-29 09:20:50 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:20:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:20:50 --> Controller Class Initialized
DEBUG - 2021-11-29 09:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-11-29 09:20:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-11-29 09:20:50 --> Final output sent to browser
DEBUG - 2021-11-29 09:20:50 --> Total execution time: 0.0818
INFO - 2021-11-29 09:20:54 --> Config Class Initialized
INFO - 2021-11-29 09:20:54 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:20:54 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:20:54 --> Utf8 Class Initialized
INFO - 2021-11-29 09:20:54 --> URI Class Initialized
INFO - 2021-11-29 09:20:54 --> Router Class Initialized
INFO - 2021-11-29 09:20:54 --> Output Class Initialized
INFO - 2021-11-29 09:20:54 --> Security Class Initialized
DEBUG - 2021-11-29 09:20:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:20:54 --> Input Class Initialized
INFO - 2021-11-29 09:20:54 --> Language Class Initialized
INFO - 2021-11-29 09:20:54 --> Language Class Initialized
INFO - 2021-11-29 09:20:54 --> Config Class Initialized
INFO - 2021-11-29 09:20:54 --> Loader Class Initialized
INFO - 2021-11-29 09:20:54 --> Helper loaded: url_helper
INFO - 2021-11-29 09:20:54 --> Helper loaded: file_helper
INFO - 2021-11-29 09:20:54 --> Helper loaded: form_helper
INFO - 2021-11-29 09:20:54 --> Helper loaded: my_helper
INFO - 2021-11-29 09:20:54 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:20:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:20:54 --> Controller Class Initialized
DEBUG - 2021-11-29 09:20:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:20:54 --> Final output sent to browser
DEBUG - 2021-11-29 09:20:54 --> Total execution time: 0.1595
INFO - 2021-11-29 09:21:04 --> Config Class Initialized
INFO - 2021-11-29 09:21:04 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:04 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:04 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:04 --> URI Class Initialized
INFO - 2021-11-29 09:21:04 --> Router Class Initialized
INFO - 2021-11-29 09:21:04 --> Output Class Initialized
INFO - 2021-11-29 09:21:04 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:04 --> Input Class Initialized
INFO - 2021-11-29 09:21:04 --> Language Class Initialized
INFO - 2021-11-29 09:21:04 --> Language Class Initialized
INFO - 2021-11-29 09:21:04 --> Config Class Initialized
INFO - 2021-11-29 09:21:04 --> Loader Class Initialized
INFO - 2021-11-29 09:21:04 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:04 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:04 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:04 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:04 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:04 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:04 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:04 --> Total execution time: 0.1449
INFO - 2021-11-29 09:21:07 --> Config Class Initialized
INFO - 2021-11-29 09:21:07 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:07 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:07 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:07 --> URI Class Initialized
INFO - 2021-11-29 09:21:07 --> Router Class Initialized
INFO - 2021-11-29 09:21:07 --> Output Class Initialized
INFO - 2021-11-29 09:21:07 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:07 --> Input Class Initialized
INFO - 2021-11-29 09:21:07 --> Language Class Initialized
INFO - 2021-11-29 09:21:07 --> Language Class Initialized
INFO - 2021-11-29 09:21:07 --> Config Class Initialized
INFO - 2021-11-29 09:21:07 --> Loader Class Initialized
INFO - 2021-11-29 09:21:08 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:08 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:08 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:08 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:08 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:08 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:08 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:08 --> Total execution time: 0.1402
INFO - 2021-11-29 09:21:10 --> Config Class Initialized
INFO - 2021-11-29 09:21:10 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:10 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:10 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:10 --> URI Class Initialized
INFO - 2021-11-29 09:21:10 --> Router Class Initialized
INFO - 2021-11-29 09:21:10 --> Output Class Initialized
INFO - 2021-11-29 09:21:10 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:10 --> Input Class Initialized
INFO - 2021-11-29 09:21:10 --> Language Class Initialized
INFO - 2021-11-29 09:21:10 --> Language Class Initialized
INFO - 2021-11-29 09:21:10 --> Config Class Initialized
INFO - 2021-11-29 09:21:10 --> Loader Class Initialized
INFO - 2021-11-29 09:21:10 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:10 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:10 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:10 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:10 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:10 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:10 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:10 --> Total execution time: 0.1245
INFO - 2021-11-29 09:21:12 --> Config Class Initialized
INFO - 2021-11-29 09:21:12 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:12 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:12 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:12 --> URI Class Initialized
INFO - 2021-11-29 09:21:12 --> Router Class Initialized
INFO - 2021-11-29 09:21:12 --> Output Class Initialized
INFO - 2021-11-29 09:21:12 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:12 --> Input Class Initialized
INFO - 2021-11-29 09:21:12 --> Language Class Initialized
INFO - 2021-11-29 09:21:12 --> Language Class Initialized
INFO - 2021-11-29 09:21:12 --> Config Class Initialized
INFO - 2021-11-29 09:21:12 --> Loader Class Initialized
INFO - 2021-11-29 09:21:12 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:12 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:12 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:12 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:12 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:12 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:12 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:12 --> Total execution time: 0.1893
INFO - 2021-11-29 09:21:14 --> Config Class Initialized
INFO - 2021-11-29 09:21:14 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:14 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:14 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:14 --> URI Class Initialized
INFO - 2021-11-29 09:21:14 --> Router Class Initialized
INFO - 2021-11-29 09:21:14 --> Output Class Initialized
INFO - 2021-11-29 09:21:14 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:14 --> Input Class Initialized
INFO - 2021-11-29 09:21:14 --> Language Class Initialized
INFO - 2021-11-29 09:21:14 --> Language Class Initialized
INFO - 2021-11-29 09:21:14 --> Config Class Initialized
INFO - 2021-11-29 09:21:14 --> Loader Class Initialized
INFO - 2021-11-29 09:21:14 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:14 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:14 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:14 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:14 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:14 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:14 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:14 --> Total execution time: 0.1634
INFO - 2021-11-29 09:21:16 --> Config Class Initialized
INFO - 2021-11-29 09:21:16 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:16 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:16 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:16 --> URI Class Initialized
INFO - 2021-11-29 09:21:16 --> Router Class Initialized
INFO - 2021-11-29 09:21:16 --> Output Class Initialized
INFO - 2021-11-29 09:21:16 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:16 --> Input Class Initialized
INFO - 2021-11-29 09:21:16 --> Language Class Initialized
INFO - 2021-11-29 09:21:16 --> Language Class Initialized
INFO - 2021-11-29 09:21:16 --> Config Class Initialized
INFO - 2021-11-29 09:21:16 --> Loader Class Initialized
INFO - 2021-11-29 09:21:16 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:16 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:16 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:16 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:16 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:16 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:16 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:16 --> Total execution time: 0.1330
INFO - 2021-11-29 09:21:18 --> Config Class Initialized
INFO - 2021-11-29 09:21:18 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:18 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:18 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:18 --> URI Class Initialized
INFO - 2021-11-29 09:21:18 --> Router Class Initialized
INFO - 2021-11-29 09:21:18 --> Output Class Initialized
INFO - 2021-11-29 09:21:18 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:18 --> Input Class Initialized
INFO - 2021-11-29 09:21:18 --> Language Class Initialized
INFO - 2021-11-29 09:21:18 --> Language Class Initialized
INFO - 2021-11-29 09:21:18 --> Config Class Initialized
INFO - 2021-11-29 09:21:18 --> Loader Class Initialized
INFO - 2021-11-29 09:21:18 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:18 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:18 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:18 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:18 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:18 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:19 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:19 --> Total execution time: 0.1238
INFO - 2021-11-29 09:21:21 --> Config Class Initialized
INFO - 2021-11-29 09:21:21 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:21 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:21 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:21 --> URI Class Initialized
INFO - 2021-11-29 09:21:21 --> Router Class Initialized
INFO - 2021-11-29 09:21:21 --> Output Class Initialized
INFO - 2021-11-29 09:21:21 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:21 --> Input Class Initialized
INFO - 2021-11-29 09:21:21 --> Language Class Initialized
INFO - 2021-11-29 09:21:21 --> Language Class Initialized
INFO - 2021-11-29 09:21:21 --> Config Class Initialized
INFO - 2021-11-29 09:21:21 --> Loader Class Initialized
INFO - 2021-11-29 09:21:21 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:21 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:21 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:21 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:21 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:21 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:21 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:21 --> Total execution time: 0.1478
INFO - 2021-11-29 09:21:23 --> Config Class Initialized
INFO - 2021-11-29 09:21:23 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:23 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:23 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:23 --> URI Class Initialized
INFO - 2021-11-29 09:21:23 --> Router Class Initialized
INFO - 2021-11-29 09:21:23 --> Output Class Initialized
INFO - 2021-11-29 09:21:23 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:23 --> Input Class Initialized
INFO - 2021-11-29 09:21:23 --> Language Class Initialized
INFO - 2021-11-29 09:21:23 --> Language Class Initialized
INFO - 2021-11-29 09:21:23 --> Config Class Initialized
INFO - 2021-11-29 09:21:23 --> Loader Class Initialized
INFO - 2021-11-29 09:21:23 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:23 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:23 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:23 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:23 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:23 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:23 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:23 --> Total execution time: 0.1450
INFO - 2021-11-29 09:21:25 --> Config Class Initialized
INFO - 2021-11-29 09:21:25 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:25 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:25 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:25 --> URI Class Initialized
INFO - 2021-11-29 09:21:25 --> Router Class Initialized
INFO - 2021-11-29 09:21:25 --> Output Class Initialized
INFO - 2021-11-29 09:21:25 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:25 --> Input Class Initialized
INFO - 2021-11-29 09:21:25 --> Language Class Initialized
INFO - 2021-11-29 09:21:25 --> Language Class Initialized
INFO - 2021-11-29 09:21:25 --> Config Class Initialized
INFO - 2021-11-29 09:21:25 --> Loader Class Initialized
INFO - 2021-11-29 09:21:25 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:25 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:25 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:25 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:25 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:25 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:25 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:25 --> Total execution time: 0.1437
INFO - 2021-11-29 09:21:27 --> Config Class Initialized
INFO - 2021-11-29 09:21:27 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:27 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:27 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:27 --> URI Class Initialized
INFO - 2021-11-29 09:21:27 --> Router Class Initialized
INFO - 2021-11-29 09:21:27 --> Output Class Initialized
INFO - 2021-11-29 09:21:27 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:27 --> Input Class Initialized
INFO - 2021-11-29 09:21:27 --> Language Class Initialized
INFO - 2021-11-29 09:21:27 --> Language Class Initialized
INFO - 2021-11-29 09:21:27 --> Config Class Initialized
INFO - 2021-11-29 09:21:27 --> Loader Class Initialized
INFO - 2021-11-29 09:21:27 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:27 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:27 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:27 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:27 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:27 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:27 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:27 --> Total execution time: 0.1616
INFO - 2021-11-29 09:21:28 --> Config Class Initialized
INFO - 2021-11-29 09:21:28 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:28 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:28 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:28 --> URI Class Initialized
INFO - 2021-11-29 09:21:28 --> Router Class Initialized
INFO - 2021-11-29 09:21:28 --> Output Class Initialized
INFO - 2021-11-29 09:21:28 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:28 --> Input Class Initialized
INFO - 2021-11-29 09:21:28 --> Language Class Initialized
INFO - 2021-11-29 09:21:28 --> Language Class Initialized
INFO - 2021-11-29 09:21:28 --> Config Class Initialized
INFO - 2021-11-29 09:21:28 --> Loader Class Initialized
INFO - 2021-11-29 09:21:28 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:28 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:28 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:28 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:29 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:29 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:29 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:29 --> Total execution time: 0.1846
INFO - 2021-11-29 09:21:30 --> Config Class Initialized
INFO - 2021-11-29 09:21:30 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:31 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:31 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:31 --> URI Class Initialized
INFO - 2021-11-29 09:21:31 --> Router Class Initialized
INFO - 2021-11-29 09:21:31 --> Output Class Initialized
INFO - 2021-11-29 09:21:31 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:31 --> Input Class Initialized
INFO - 2021-11-29 09:21:31 --> Language Class Initialized
INFO - 2021-11-29 09:21:31 --> Language Class Initialized
INFO - 2021-11-29 09:21:31 --> Config Class Initialized
INFO - 2021-11-29 09:21:31 --> Loader Class Initialized
INFO - 2021-11-29 09:21:31 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:31 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:31 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:31 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:31 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:31 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:31 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:31 --> Total execution time: 0.1622
INFO - 2021-11-29 09:21:33 --> Config Class Initialized
INFO - 2021-11-29 09:21:33 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:33 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:33 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:33 --> URI Class Initialized
INFO - 2021-11-29 09:21:33 --> Router Class Initialized
INFO - 2021-11-29 09:21:33 --> Output Class Initialized
INFO - 2021-11-29 09:21:33 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:33 --> Input Class Initialized
INFO - 2021-11-29 09:21:33 --> Language Class Initialized
INFO - 2021-11-29 09:21:33 --> Language Class Initialized
INFO - 2021-11-29 09:21:33 --> Config Class Initialized
INFO - 2021-11-29 09:21:33 --> Loader Class Initialized
INFO - 2021-11-29 09:21:33 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:33 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:33 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:33 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:33 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:33 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:33 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:33 --> Total execution time: 0.1102
INFO - 2021-11-29 09:21:35 --> Config Class Initialized
INFO - 2021-11-29 09:21:35 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:35 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:35 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:35 --> URI Class Initialized
INFO - 2021-11-29 09:21:35 --> Router Class Initialized
INFO - 2021-11-29 09:21:35 --> Output Class Initialized
INFO - 2021-11-29 09:21:35 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:35 --> Input Class Initialized
INFO - 2021-11-29 09:21:35 --> Language Class Initialized
INFO - 2021-11-29 09:21:35 --> Language Class Initialized
INFO - 2021-11-29 09:21:35 --> Config Class Initialized
INFO - 2021-11-29 09:21:35 --> Loader Class Initialized
INFO - 2021-11-29 09:21:35 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:35 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:35 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:35 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:35 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:35 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:35 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:35 --> Total execution time: 0.1250
INFO - 2021-11-29 09:21:37 --> Config Class Initialized
INFO - 2021-11-29 09:21:37 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:37 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:37 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:37 --> URI Class Initialized
INFO - 2021-11-29 09:21:37 --> Router Class Initialized
INFO - 2021-11-29 09:21:37 --> Output Class Initialized
INFO - 2021-11-29 09:21:37 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:37 --> Input Class Initialized
INFO - 2021-11-29 09:21:37 --> Language Class Initialized
INFO - 2021-11-29 09:21:37 --> Language Class Initialized
INFO - 2021-11-29 09:21:37 --> Config Class Initialized
INFO - 2021-11-29 09:21:37 --> Loader Class Initialized
INFO - 2021-11-29 09:21:37 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:37 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:37 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:37 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:37 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:37 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:37 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:37 --> Total execution time: 0.1219
INFO - 2021-11-29 09:21:39 --> Config Class Initialized
INFO - 2021-11-29 09:21:39 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:39 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:39 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:39 --> URI Class Initialized
INFO - 2021-11-29 09:21:39 --> Router Class Initialized
INFO - 2021-11-29 09:21:39 --> Output Class Initialized
INFO - 2021-11-29 09:21:39 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:39 --> Input Class Initialized
INFO - 2021-11-29 09:21:39 --> Language Class Initialized
INFO - 2021-11-29 09:21:39 --> Language Class Initialized
INFO - 2021-11-29 09:21:39 --> Config Class Initialized
INFO - 2021-11-29 09:21:39 --> Loader Class Initialized
INFO - 2021-11-29 09:21:39 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:39 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:39 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:39 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:39 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:39 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:39 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:39 --> Total execution time: 0.1575
INFO - 2021-11-29 09:21:41 --> Config Class Initialized
INFO - 2021-11-29 09:21:41 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:41 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:41 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:41 --> URI Class Initialized
INFO - 2021-11-29 09:21:41 --> Router Class Initialized
INFO - 2021-11-29 09:21:41 --> Output Class Initialized
INFO - 2021-11-29 09:21:41 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:41 --> Input Class Initialized
INFO - 2021-11-29 09:21:41 --> Language Class Initialized
INFO - 2021-11-29 09:21:41 --> Language Class Initialized
INFO - 2021-11-29 09:21:41 --> Config Class Initialized
INFO - 2021-11-29 09:21:41 --> Loader Class Initialized
INFO - 2021-11-29 09:21:41 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:41 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:41 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:41 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:41 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:41 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:41 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:41 --> Total execution time: 0.1248
INFO - 2021-11-29 09:21:43 --> Config Class Initialized
INFO - 2021-11-29 09:21:43 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:43 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:43 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:43 --> URI Class Initialized
INFO - 2021-11-29 09:21:43 --> Router Class Initialized
INFO - 2021-11-29 09:21:43 --> Output Class Initialized
INFO - 2021-11-29 09:21:43 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:43 --> Input Class Initialized
INFO - 2021-11-29 09:21:43 --> Language Class Initialized
INFO - 2021-11-29 09:21:43 --> Language Class Initialized
INFO - 2021-11-29 09:21:43 --> Config Class Initialized
INFO - 2021-11-29 09:21:43 --> Loader Class Initialized
INFO - 2021-11-29 09:21:43 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:43 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:43 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:43 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:43 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:43 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:43 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:43 --> Total execution time: 0.1417
INFO - 2021-11-29 09:21:46 --> Config Class Initialized
INFO - 2021-11-29 09:21:46 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:46 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:46 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:46 --> URI Class Initialized
INFO - 2021-11-29 09:21:46 --> Router Class Initialized
INFO - 2021-11-29 09:21:46 --> Output Class Initialized
INFO - 2021-11-29 09:21:46 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:46 --> Input Class Initialized
INFO - 2021-11-29 09:21:46 --> Language Class Initialized
INFO - 2021-11-29 09:21:46 --> Language Class Initialized
INFO - 2021-11-29 09:21:46 --> Config Class Initialized
INFO - 2021-11-29 09:21:46 --> Loader Class Initialized
INFO - 2021-11-29 09:21:46 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:46 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:46 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:46 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:46 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:46 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:46 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:46 --> Total execution time: 0.1564
INFO - 2021-11-29 09:21:48 --> Config Class Initialized
INFO - 2021-11-29 09:21:48 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:48 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:48 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:48 --> URI Class Initialized
INFO - 2021-11-29 09:21:48 --> Router Class Initialized
INFO - 2021-11-29 09:21:48 --> Output Class Initialized
INFO - 2021-11-29 09:21:48 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:48 --> Input Class Initialized
INFO - 2021-11-29 09:21:48 --> Language Class Initialized
INFO - 2021-11-29 09:21:48 --> Language Class Initialized
INFO - 2021-11-29 09:21:48 --> Config Class Initialized
INFO - 2021-11-29 09:21:48 --> Loader Class Initialized
INFO - 2021-11-29 09:21:48 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:48 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:48 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:48 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:48 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:48 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:48 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:48 --> Total execution time: 0.1422
INFO - 2021-11-29 09:21:50 --> Config Class Initialized
INFO - 2021-11-29 09:21:50 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:51 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:51 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:51 --> URI Class Initialized
INFO - 2021-11-29 09:21:51 --> Router Class Initialized
INFO - 2021-11-29 09:21:51 --> Output Class Initialized
INFO - 2021-11-29 09:21:51 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:51 --> Input Class Initialized
INFO - 2021-11-29 09:21:51 --> Language Class Initialized
INFO - 2021-11-29 09:21:51 --> Language Class Initialized
INFO - 2021-11-29 09:21:51 --> Config Class Initialized
INFO - 2021-11-29 09:21:51 --> Loader Class Initialized
INFO - 2021-11-29 09:21:51 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:51 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:51 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:51 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:51 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:51 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:51 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:51 --> Total execution time: 0.1447
INFO - 2021-11-29 09:21:52 --> Config Class Initialized
INFO - 2021-11-29 09:21:52 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:52 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:52 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:52 --> URI Class Initialized
INFO - 2021-11-29 09:21:52 --> Router Class Initialized
INFO - 2021-11-29 09:21:52 --> Output Class Initialized
INFO - 2021-11-29 09:21:52 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:52 --> Input Class Initialized
INFO - 2021-11-29 09:21:52 --> Language Class Initialized
INFO - 2021-11-29 09:21:52 --> Language Class Initialized
INFO - 2021-11-29 09:21:52 --> Config Class Initialized
INFO - 2021-11-29 09:21:52 --> Loader Class Initialized
INFO - 2021-11-29 09:21:52 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:52 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:52 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:52 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:52 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:53 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:53 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:53 --> Total execution time: 0.1149
INFO - 2021-11-29 09:21:54 --> Config Class Initialized
INFO - 2021-11-29 09:21:54 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:54 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:54 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:54 --> URI Class Initialized
INFO - 2021-11-29 09:21:54 --> Router Class Initialized
INFO - 2021-11-29 09:21:54 --> Output Class Initialized
INFO - 2021-11-29 09:21:54 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:54 --> Input Class Initialized
INFO - 2021-11-29 09:21:54 --> Language Class Initialized
INFO - 2021-11-29 09:21:54 --> Language Class Initialized
INFO - 2021-11-29 09:21:54 --> Config Class Initialized
INFO - 2021-11-29 09:21:54 --> Loader Class Initialized
INFO - 2021-11-29 09:21:54 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:54 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:54 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:54 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:54 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:54 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:54 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:54 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:54 --> Total execution time: 0.1349
INFO - 2021-11-29 09:21:57 --> Config Class Initialized
INFO - 2021-11-29 09:21:57 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:21:57 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:21:57 --> Utf8 Class Initialized
INFO - 2021-11-29 09:21:57 --> URI Class Initialized
INFO - 2021-11-29 09:21:57 --> Router Class Initialized
INFO - 2021-11-29 09:21:57 --> Output Class Initialized
INFO - 2021-11-29 09:21:57 --> Security Class Initialized
DEBUG - 2021-11-29 09:21:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:21:57 --> Input Class Initialized
INFO - 2021-11-29 09:21:57 --> Language Class Initialized
INFO - 2021-11-29 09:21:57 --> Language Class Initialized
INFO - 2021-11-29 09:21:57 --> Config Class Initialized
INFO - 2021-11-29 09:21:57 --> Loader Class Initialized
INFO - 2021-11-29 09:21:57 --> Helper loaded: url_helper
INFO - 2021-11-29 09:21:57 --> Helper loaded: file_helper
INFO - 2021-11-29 09:21:57 --> Helper loaded: form_helper
INFO - 2021-11-29 09:21:57 --> Helper loaded: my_helper
INFO - 2021-11-29 09:21:57 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:21:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:21:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:21:57 --> Controller Class Initialized
DEBUG - 2021-11-29 09:21:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:21:57 --> Final output sent to browser
DEBUG - 2021-11-29 09:21:57 --> Total execution time: 0.1707
INFO - 2021-11-29 09:21:59 --> Config Class Initialized
INFO - 2021-11-29 09:21:59 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:22:00 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:22:00 --> Utf8 Class Initialized
INFO - 2021-11-29 09:22:00 --> URI Class Initialized
INFO - 2021-11-29 09:22:00 --> Router Class Initialized
INFO - 2021-11-29 09:22:00 --> Output Class Initialized
INFO - 2021-11-29 09:22:00 --> Security Class Initialized
DEBUG - 2021-11-29 09:22:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:22:00 --> Input Class Initialized
INFO - 2021-11-29 09:22:00 --> Language Class Initialized
INFO - 2021-11-29 09:22:00 --> Language Class Initialized
INFO - 2021-11-29 09:22:00 --> Config Class Initialized
INFO - 2021-11-29 09:22:00 --> Loader Class Initialized
INFO - 2021-11-29 09:22:00 --> Helper loaded: url_helper
INFO - 2021-11-29 09:22:00 --> Helper loaded: file_helper
INFO - 2021-11-29 09:22:00 --> Helper loaded: form_helper
INFO - 2021-11-29 09:22:00 --> Helper loaded: my_helper
INFO - 2021-11-29 09:22:00 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:22:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:22:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:22:00 --> Controller Class Initialized
DEBUG - 2021-11-29 09:22:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:22:00 --> Final output sent to browser
DEBUG - 2021-11-29 09:22:00 --> Total execution time: 0.1704
INFO - 2021-11-29 09:32:06 --> Config Class Initialized
INFO - 2021-11-29 09:32:06 --> Hooks Class Initialized
DEBUG - 2021-11-29 09:32:06 --> UTF-8 Support Enabled
INFO - 2021-11-29 09:32:06 --> Utf8 Class Initialized
INFO - 2021-11-29 09:32:06 --> URI Class Initialized
INFO - 2021-11-29 09:32:06 --> Router Class Initialized
INFO - 2021-11-29 09:32:06 --> Output Class Initialized
INFO - 2021-11-29 09:32:06 --> Security Class Initialized
DEBUG - 2021-11-29 09:32:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-11-29 09:32:06 --> Input Class Initialized
INFO - 2021-11-29 09:32:06 --> Language Class Initialized
INFO - 2021-11-29 09:32:06 --> Language Class Initialized
INFO - 2021-11-29 09:32:06 --> Config Class Initialized
INFO - 2021-11-29 09:32:06 --> Loader Class Initialized
INFO - 2021-11-29 09:32:06 --> Helper loaded: url_helper
INFO - 2021-11-29 09:32:06 --> Helper loaded: file_helper
INFO - 2021-11-29 09:32:06 --> Helper loaded: form_helper
INFO - 2021-11-29 09:32:06 --> Helper loaded: my_helper
INFO - 2021-11-29 09:32:06 --> Database Driver Class Initialized
DEBUG - 2021-11-29 09:32:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-11-29 09:32:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-11-29 09:32:06 --> Controller Class Initialized
DEBUG - 2021-11-29 09:32:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_tbsm_xi.php
INFO - 2021-11-29 09:32:06 --> Final output sent to browser
DEBUG - 2021-11-29 09:32:06 --> Total execution time: 0.1220
