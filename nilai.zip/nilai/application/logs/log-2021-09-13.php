<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-09-13 08:54:12 --> Config Class Initialized
INFO - 2021-09-13 08:54:12 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:12 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:12 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:12 --> URI Class Initialized
DEBUG - 2021-09-13 08:54:12 --> No URI present. Default controller set.
INFO - 2021-09-13 08:54:12 --> Router Class Initialized
INFO - 2021-09-13 08:54:12 --> Output Class Initialized
INFO - 2021-09-13 08:54:12 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:12 --> Input Class Initialized
INFO - 2021-09-13 08:54:12 --> Language Class Initialized
INFO - 2021-09-13 08:54:12 --> Language Class Initialized
INFO - 2021-09-13 08:54:12 --> Config Class Initialized
INFO - 2021-09-13 08:54:12 --> Loader Class Initialized
INFO - 2021-09-13 08:54:12 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:12 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:12 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:12 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:12 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:12 --> Controller Class Initialized
INFO - 2021-09-13 08:54:12 --> Config Class Initialized
INFO - 2021-09-13 08:54:12 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:12 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:12 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:12 --> URI Class Initialized
INFO - 2021-09-13 08:54:12 --> Router Class Initialized
INFO - 2021-09-13 08:54:12 --> Output Class Initialized
INFO - 2021-09-13 08:54:12 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:12 --> Input Class Initialized
INFO - 2021-09-13 08:54:12 --> Language Class Initialized
INFO - 2021-09-13 08:54:12 --> Language Class Initialized
INFO - 2021-09-13 08:54:12 --> Config Class Initialized
INFO - 2021-09-13 08:54:12 --> Loader Class Initialized
INFO - 2021-09-13 08:54:12 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:12 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:12 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:12 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:12 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:12 --> Controller Class Initialized
DEBUG - 2021-09-13 08:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-09-13 08:54:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:54:12 --> Final output sent to browser
DEBUG - 2021-09-13 08:54:12 --> Total execution time: 0.0506
INFO - 2021-09-13 08:54:17 --> Config Class Initialized
INFO - 2021-09-13 08:54:17 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:17 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:17 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:17 --> URI Class Initialized
INFO - 2021-09-13 08:54:17 --> Router Class Initialized
INFO - 2021-09-13 08:54:17 --> Output Class Initialized
INFO - 2021-09-13 08:54:17 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:17 --> Input Class Initialized
INFO - 2021-09-13 08:54:17 --> Language Class Initialized
INFO - 2021-09-13 08:54:17 --> Language Class Initialized
INFO - 2021-09-13 08:54:17 --> Config Class Initialized
INFO - 2021-09-13 08:54:17 --> Loader Class Initialized
INFO - 2021-09-13 08:54:17 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:17 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:17 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:17 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:17 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:17 --> Controller Class Initialized
INFO - 2021-09-13 08:54:17 --> Helper loaded: cookie_helper
INFO - 2021-09-13 08:54:17 --> Final output sent to browser
DEBUG - 2021-09-13 08:54:17 --> Total execution time: 0.0726
INFO - 2021-09-13 08:54:17 --> Config Class Initialized
INFO - 2021-09-13 08:54:17 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:17 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:17 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:17 --> URI Class Initialized
INFO - 2021-09-13 08:54:17 --> Router Class Initialized
INFO - 2021-09-13 08:54:17 --> Output Class Initialized
INFO - 2021-09-13 08:54:17 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:17 --> Input Class Initialized
INFO - 2021-09-13 08:54:17 --> Language Class Initialized
INFO - 2021-09-13 08:54:17 --> Language Class Initialized
INFO - 2021-09-13 08:54:17 --> Config Class Initialized
INFO - 2021-09-13 08:54:17 --> Loader Class Initialized
INFO - 2021-09-13 08:54:17 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:17 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:17 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:17 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:17 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:17 --> Controller Class Initialized
DEBUG - 2021-09-13 08:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-09-13 08:54:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:54:17 --> Final output sent to browser
DEBUG - 2021-09-13 08:54:17 --> Total execution time: 0.1170
INFO - 2021-09-13 08:54:35 --> Config Class Initialized
INFO - 2021-09-13 08:54:35 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:35 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:35 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:35 --> URI Class Initialized
INFO - 2021-09-13 08:54:35 --> Router Class Initialized
INFO - 2021-09-13 08:54:35 --> Output Class Initialized
INFO - 2021-09-13 08:54:35 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:35 --> Input Class Initialized
INFO - 2021-09-13 08:54:35 --> Language Class Initialized
INFO - 2021-09-13 08:54:35 --> Language Class Initialized
INFO - 2021-09-13 08:54:35 --> Config Class Initialized
INFO - 2021-09-13 08:54:35 --> Loader Class Initialized
INFO - 2021-09-13 08:54:35 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:35 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:35 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:35 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:35 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:35 --> Controller Class Initialized
DEBUG - 2021-09-13 08:54:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2021-09-13 08:54:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:54:35 --> Final output sent to browser
DEBUG - 2021-09-13 08:54:35 --> Total execution time: 0.0740
INFO - 2021-09-13 08:54:35 --> Config Class Initialized
INFO - 2021-09-13 08:54:35 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:35 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:35 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:35 --> URI Class Initialized
INFO - 2021-09-13 08:54:35 --> Router Class Initialized
INFO - 2021-09-13 08:54:35 --> Output Class Initialized
INFO - 2021-09-13 08:54:35 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:35 --> Input Class Initialized
INFO - 2021-09-13 08:54:35 --> Language Class Initialized
INFO - 2021-09-13 08:54:35 --> Language Class Initialized
INFO - 2021-09-13 08:54:35 --> Config Class Initialized
INFO - 2021-09-13 08:54:35 --> Loader Class Initialized
INFO - 2021-09-13 08:54:35 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:35 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:35 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:35 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:35 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:35 --> Controller Class Initialized
INFO - 2021-09-13 08:54:36 --> Config Class Initialized
INFO - 2021-09-13 08:54:36 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:36 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:36 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:36 --> URI Class Initialized
INFO - 2021-09-13 08:54:36 --> Router Class Initialized
INFO - 2021-09-13 08:54:36 --> Output Class Initialized
INFO - 2021-09-13 08:54:36 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:36 --> Input Class Initialized
INFO - 2021-09-13 08:54:36 --> Language Class Initialized
INFO - 2021-09-13 08:54:36 --> Language Class Initialized
INFO - 2021-09-13 08:54:36 --> Config Class Initialized
INFO - 2021-09-13 08:54:36 --> Loader Class Initialized
INFO - 2021-09-13 08:54:36 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:36 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:36 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:36 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:36 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:37 --> Controller Class Initialized
DEBUG - 2021-09-13 08:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-09-13 08:54:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:54:37 --> Final output sent to browser
DEBUG - 2021-09-13 08:54:37 --> Total execution time: 0.1067
INFO - 2021-09-13 08:54:51 --> Config Class Initialized
INFO - 2021-09-13 08:54:51 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:51 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:51 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:51 --> URI Class Initialized
INFO - 2021-09-13 08:54:51 --> Router Class Initialized
INFO - 2021-09-13 08:54:51 --> Output Class Initialized
INFO - 2021-09-13 08:54:51 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:51 --> Input Class Initialized
INFO - 2021-09-13 08:54:51 --> Language Class Initialized
INFO - 2021-09-13 08:54:51 --> Language Class Initialized
INFO - 2021-09-13 08:54:51 --> Config Class Initialized
INFO - 2021-09-13 08:54:51 --> Loader Class Initialized
INFO - 2021-09-13 08:54:51 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:51 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:51 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:51 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:51 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:51 --> Controller Class Initialized
DEBUG - 2021-09-13 08:54:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-09-13 08:54:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:54:51 --> Final output sent to browser
DEBUG - 2021-09-13 08:54:51 --> Total execution time: 0.0584
INFO - 2021-09-13 08:54:55 --> Config Class Initialized
INFO - 2021-09-13 08:54:55 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:55 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:55 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:55 --> URI Class Initialized
INFO - 2021-09-13 08:54:55 --> Router Class Initialized
INFO - 2021-09-13 08:54:55 --> Output Class Initialized
INFO - 2021-09-13 08:54:55 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:55 --> Input Class Initialized
INFO - 2021-09-13 08:54:55 --> Language Class Initialized
INFO - 2021-09-13 08:54:55 --> Language Class Initialized
INFO - 2021-09-13 08:54:55 --> Config Class Initialized
INFO - 2021-09-13 08:54:55 --> Loader Class Initialized
INFO - 2021-09-13 08:54:55 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:55 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:55 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:55 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:55 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:55 --> Controller Class Initialized
INFO - 2021-09-13 08:54:55 --> Config Class Initialized
INFO - 2021-09-13 08:54:55 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:54:55 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:54:55 --> Utf8 Class Initialized
INFO - 2021-09-13 08:54:55 --> URI Class Initialized
INFO - 2021-09-13 08:54:55 --> Router Class Initialized
INFO - 2021-09-13 08:54:55 --> Output Class Initialized
INFO - 2021-09-13 08:54:55 --> Security Class Initialized
DEBUG - 2021-09-13 08:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:54:55 --> Input Class Initialized
INFO - 2021-09-13 08:54:55 --> Language Class Initialized
INFO - 2021-09-13 08:54:55 --> Language Class Initialized
INFO - 2021-09-13 08:54:55 --> Config Class Initialized
INFO - 2021-09-13 08:54:55 --> Loader Class Initialized
INFO - 2021-09-13 08:54:55 --> Helper loaded: url_helper
INFO - 2021-09-13 08:54:55 --> Helper loaded: file_helper
INFO - 2021-09-13 08:54:55 --> Helper loaded: form_helper
INFO - 2021-09-13 08:54:55 --> Helper loaded: my_helper
INFO - 2021-09-13 08:54:55 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:54:55 --> Controller Class Initialized
DEBUG - 2021-09-13 08:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-09-13 08:54:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:54:55 --> Final output sent to browser
DEBUG - 2021-09-13 08:54:55 --> Total execution time: 0.0612
INFO - 2021-09-13 08:55:03 --> Config Class Initialized
INFO - 2021-09-13 08:55:03 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:55:03 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:55:03 --> Utf8 Class Initialized
INFO - 2021-09-13 08:55:03 --> URI Class Initialized
INFO - 2021-09-13 08:55:03 --> Router Class Initialized
INFO - 2021-09-13 08:55:03 --> Output Class Initialized
INFO - 2021-09-13 08:55:03 --> Security Class Initialized
DEBUG - 2021-09-13 08:55:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:55:03 --> Input Class Initialized
INFO - 2021-09-13 08:55:03 --> Language Class Initialized
INFO - 2021-09-13 08:55:03 --> Language Class Initialized
INFO - 2021-09-13 08:55:03 --> Config Class Initialized
INFO - 2021-09-13 08:55:03 --> Loader Class Initialized
INFO - 2021-09-13 08:55:03 --> Helper loaded: url_helper
INFO - 2021-09-13 08:55:03 --> Helper loaded: file_helper
INFO - 2021-09-13 08:55:03 --> Helper loaded: form_helper
INFO - 2021-09-13 08:55:03 --> Helper loaded: my_helper
INFO - 2021-09-13 08:55:03 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:55:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:55:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:55:03 --> Controller Class Initialized
DEBUG - 2021-09-13 08:55:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2021-09-13 08:55:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:55:03 --> Final output sent to browser
DEBUG - 2021-09-13 08:55:03 --> Total execution time: 0.0422
INFO - 2021-09-13 08:55:24 --> Config Class Initialized
INFO - 2021-09-13 08:55:24 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:55:24 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:55:24 --> Utf8 Class Initialized
INFO - 2021-09-13 08:55:24 --> URI Class Initialized
INFO - 2021-09-13 08:55:24 --> Router Class Initialized
INFO - 2021-09-13 08:55:24 --> Output Class Initialized
INFO - 2021-09-13 08:55:24 --> Security Class Initialized
DEBUG - 2021-09-13 08:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:55:24 --> Input Class Initialized
INFO - 2021-09-13 08:55:24 --> Language Class Initialized
INFO - 2021-09-13 08:55:24 --> Language Class Initialized
INFO - 2021-09-13 08:55:24 --> Config Class Initialized
INFO - 2021-09-13 08:55:24 --> Loader Class Initialized
INFO - 2021-09-13 08:55:24 --> Helper loaded: url_helper
INFO - 2021-09-13 08:55:24 --> Helper loaded: file_helper
INFO - 2021-09-13 08:55:24 --> Helper loaded: form_helper
INFO - 2021-09-13 08:55:24 --> Helper loaded: my_helper
INFO - 2021-09-13 08:55:24 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:55:24 --> Controller Class Initialized
INFO - 2021-09-13 08:55:24 --> Config Class Initialized
INFO - 2021-09-13 08:55:24 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:55:24 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:55:24 --> Utf8 Class Initialized
INFO - 2021-09-13 08:55:24 --> URI Class Initialized
INFO - 2021-09-13 08:55:24 --> Router Class Initialized
INFO - 2021-09-13 08:55:24 --> Output Class Initialized
INFO - 2021-09-13 08:55:24 --> Security Class Initialized
DEBUG - 2021-09-13 08:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:55:24 --> Input Class Initialized
INFO - 2021-09-13 08:55:24 --> Language Class Initialized
INFO - 2021-09-13 08:55:24 --> Language Class Initialized
INFO - 2021-09-13 08:55:24 --> Config Class Initialized
INFO - 2021-09-13 08:55:24 --> Loader Class Initialized
INFO - 2021-09-13 08:55:24 --> Helper loaded: url_helper
INFO - 2021-09-13 08:55:24 --> Helper loaded: file_helper
INFO - 2021-09-13 08:55:24 --> Helper loaded: form_helper
INFO - 2021-09-13 08:55:24 --> Helper loaded: my_helper
INFO - 2021-09-13 08:55:24 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:55:24 --> Controller Class Initialized
DEBUG - 2021-09-13 08:55:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2021-09-13 08:55:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:55:24 --> Final output sent to browser
DEBUG - 2021-09-13 08:55:24 --> Total execution time: 0.0614
INFO - 2021-09-13 08:55:52 --> Config Class Initialized
INFO - 2021-09-13 08:55:52 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:55:52 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:55:52 --> Utf8 Class Initialized
INFO - 2021-09-13 08:55:52 --> URI Class Initialized
INFO - 2021-09-13 08:55:52 --> Router Class Initialized
INFO - 2021-09-13 08:55:52 --> Output Class Initialized
INFO - 2021-09-13 08:55:52 --> Security Class Initialized
DEBUG - 2021-09-13 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:55:52 --> Input Class Initialized
INFO - 2021-09-13 08:55:52 --> Language Class Initialized
INFO - 2021-09-13 08:55:52 --> Language Class Initialized
INFO - 2021-09-13 08:55:52 --> Config Class Initialized
INFO - 2021-09-13 08:55:52 --> Loader Class Initialized
INFO - 2021-09-13 08:55:52 --> Helper loaded: url_helper
INFO - 2021-09-13 08:55:52 --> Helper loaded: file_helper
INFO - 2021-09-13 08:55:52 --> Helper loaded: form_helper
INFO - 2021-09-13 08:55:52 --> Helper loaded: my_helper
INFO - 2021-09-13 08:55:52 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:55:52 --> Controller Class Initialized
INFO - 2021-09-13 08:55:52 --> Helper loaded: cookie_helper
INFO - 2021-09-13 08:55:52 --> Config Class Initialized
INFO - 2021-09-13 08:55:52 --> Hooks Class Initialized
DEBUG - 2021-09-13 08:55:52 --> UTF-8 Support Enabled
INFO - 2021-09-13 08:55:52 --> Utf8 Class Initialized
INFO - 2021-09-13 08:55:52 --> URI Class Initialized
INFO - 2021-09-13 08:55:52 --> Router Class Initialized
INFO - 2021-09-13 08:55:52 --> Output Class Initialized
INFO - 2021-09-13 08:55:52 --> Security Class Initialized
DEBUG - 2021-09-13 08:55:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-09-13 08:55:52 --> Input Class Initialized
INFO - 2021-09-13 08:55:52 --> Language Class Initialized
INFO - 2021-09-13 08:55:52 --> Language Class Initialized
INFO - 2021-09-13 08:55:52 --> Config Class Initialized
INFO - 2021-09-13 08:55:52 --> Loader Class Initialized
INFO - 2021-09-13 08:55:52 --> Helper loaded: url_helper
INFO - 2021-09-13 08:55:52 --> Helper loaded: file_helper
INFO - 2021-09-13 08:55:52 --> Helper loaded: form_helper
INFO - 2021-09-13 08:55:52 --> Helper loaded: my_helper
INFO - 2021-09-13 08:55:52 --> Database Driver Class Initialized
DEBUG - 2021-09-13 08:55:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-09-13 08:55:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-09-13 08:55:52 --> Controller Class Initialized
DEBUG - 2021-09-13 08:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-09-13 08:55:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-09-13 08:55:52 --> Final output sent to browser
DEBUG - 2021-09-13 08:55:52 --> Total execution time: 0.0389
