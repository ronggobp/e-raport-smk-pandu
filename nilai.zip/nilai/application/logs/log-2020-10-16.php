<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-10-16 02:42:08 --> Config Class Initialized
INFO - 2020-10-16 02:42:08 --> Hooks Class Initialized
DEBUG - 2020-10-16 02:42:08 --> UTF-8 Support Enabled
INFO - 2020-10-16 02:42:08 --> Utf8 Class Initialized
INFO - 2020-10-16 02:42:08 --> URI Class Initialized
DEBUG - 2020-10-16 02:42:08 --> No URI present. Default controller set.
INFO - 2020-10-16 02:42:08 --> Router Class Initialized
INFO - 2020-10-16 02:42:08 --> Output Class Initialized
INFO - 2020-10-16 02:42:08 --> Security Class Initialized
DEBUG - 2020-10-16 02:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 02:42:08 --> Input Class Initialized
INFO - 2020-10-16 02:42:09 --> Language Class Initialized
INFO - 2020-10-16 02:42:09 --> Language Class Initialized
INFO - 2020-10-16 02:42:09 --> Config Class Initialized
INFO - 2020-10-16 02:42:09 --> Loader Class Initialized
INFO - 2020-10-16 02:42:09 --> Helper loaded: url_helper
INFO - 2020-10-16 02:42:09 --> Helper loaded: file_helper
INFO - 2020-10-16 02:42:09 --> Helper loaded: form_helper
INFO - 2020-10-16 02:42:09 --> Helper loaded: my_helper
INFO - 2020-10-16 02:42:10 --> Database Driver Class Initialized
DEBUG - 2020-10-16 02:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 02:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 02:42:10 --> Controller Class Initialized
INFO - 2020-10-16 02:42:10 --> Config Class Initialized
INFO - 2020-10-16 02:42:10 --> Hooks Class Initialized
DEBUG - 2020-10-16 02:42:10 --> UTF-8 Support Enabled
INFO - 2020-10-16 02:42:10 --> Utf8 Class Initialized
INFO - 2020-10-16 02:42:10 --> URI Class Initialized
INFO - 2020-10-16 02:42:10 --> Router Class Initialized
INFO - 2020-10-16 02:42:10 --> Output Class Initialized
INFO - 2020-10-16 02:42:10 --> Security Class Initialized
DEBUG - 2020-10-16 02:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 02:42:10 --> Input Class Initialized
INFO - 2020-10-16 02:42:10 --> Language Class Initialized
INFO - 2020-10-16 02:42:10 --> Language Class Initialized
INFO - 2020-10-16 02:42:10 --> Config Class Initialized
INFO - 2020-10-16 02:42:10 --> Loader Class Initialized
INFO - 2020-10-16 02:42:10 --> Helper loaded: url_helper
INFO - 2020-10-16 02:42:10 --> Helper loaded: file_helper
INFO - 2020-10-16 02:42:10 --> Helper loaded: form_helper
INFO - 2020-10-16 02:42:10 --> Helper loaded: my_helper
INFO - 2020-10-16 02:42:10 --> Database Driver Class Initialized
DEBUG - 2020-10-16 02:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 02:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 02:42:11 --> Controller Class Initialized
DEBUG - 2020-10-16 02:42:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-16 02:42:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 02:42:11 --> Final output sent to browser
DEBUG - 2020-10-16 02:42:11 --> Total execution time: 0.6697
INFO - 2020-10-16 02:42:27 --> Config Class Initialized
INFO - 2020-10-16 02:42:27 --> Hooks Class Initialized
DEBUG - 2020-10-16 02:42:27 --> UTF-8 Support Enabled
INFO - 2020-10-16 02:42:27 --> Utf8 Class Initialized
INFO - 2020-10-16 02:42:27 --> URI Class Initialized
INFO - 2020-10-16 02:42:27 --> Router Class Initialized
INFO - 2020-10-16 02:42:27 --> Output Class Initialized
INFO - 2020-10-16 02:42:27 --> Security Class Initialized
DEBUG - 2020-10-16 02:42:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 02:42:27 --> Input Class Initialized
INFO - 2020-10-16 02:42:27 --> Language Class Initialized
ERROR - 2020-10-16 02:42:27 --> 404 Page Not Found: /index
INFO - 2020-10-16 02:43:37 --> Config Class Initialized
INFO - 2020-10-16 02:43:37 --> Hooks Class Initialized
DEBUG - 2020-10-16 02:43:37 --> UTF-8 Support Enabled
INFO - 2020-10-16 02:43:37 --> Utf8 Class Initialized
INFO - 2020-10-16 02:43:37 --> URI Class Initialized
INFO - 2020-10-16 02:43:37 --> Router Class Initialized
INFO - 2020-10-16 02:43:37 --> Output Class Initialized
INFO - 2020-10-16 02:43:37 --> Security Class Initialized
DEBUG - 2020-10-16 02:43:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 02:43:37 --> Input Class Initialized
INFO - 2020-10-16 02:43:37 --> Language Class Initialized
INFO - 2020-10-16 02:43:37 --> Language Class Initialized
INFO - 2020-10-16 02:43:37 --> Config Class Initialized
INFO - 2020-10-16 02:43:37 --> Loader Class Initialized
INFO - 2020-10-16 02:43:37 --> Helper loaded: url_helper
INFO - 2020-10-16 02:43:37 --> Helper loaded: file_helper
INFO - 2020-10-16 02:43:37 --> Helper loaded: form_helper
INFO - 2020-10-16 02:43:37 --> Helper loaded: my_helper
INFO - 2020-10-16 02:43:37 --> Database Driver Class Initialized
DEBUG - 2020-10-16 02:43:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 02:43:37 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 02:43:38 --> Controller Class Initialized
DEBUG - 2020-10-16 02:43:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-16 02:43:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 02:43:38 --> Final output sent to browser
DEBUG - 2020-10-16 02:43:38 --> Total execution time: 0.5784
INFO - 2020-10-16 03:14:26 --> Config Class Initialized
INFO - 2020-10-16 03:14:26 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:26 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:26 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:26 --> URI Class Initialized
INFO - 2020-10-16 03:14:26 --> Router Class Initialized
INFO - 2020-10-16 03:14:26 --> Output Class Initialized
INFO - 2020-10-16 03:14:26 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:26 --> Input Class Initialized
INFO - 2020-10-16 03:14:26 --> Language Class Initialized
INFO - 2020-10-16 03:14:26 --> Language Class Initialized
INFO - 2020-10-16 03:14:26 --> Config Class Initialized
INFO - 2020-10-16 03:14:26 --> Loader Class Initialized
INFO - 2020-10-16 03:14:26 --> Helper loaded: url_helper
INFO - 2020-10-16 03:14:26 --> Helper loaded: file_helper
INFO - 2020-10-16 03:14:26 --> Helper loaded: form_helper
INFO - 2020-10-16 03:14:26 --> Helper loaded: my_helper
INFO - 2020-10-16 03:14:26 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:14:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:14:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:14:26 --> Controller Class Initialized
INFO - 2020-10-16 03:14:26 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:14:26 --> Final output sent to browser
DEBUG - 2020-10-16 03:14:26 --> Total execution time: 0.3331
INFO - 2020-10-16 03:14:28 --> Config Class Initialized
INFO - 2020-10-16 03:14:28 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:28 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:28 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:28 --> URI Class Initialized
INFO - 2020-10-16 03:14:28 --> Router Class Initialized
INFO - 2020-10-16 03:14:28 --> Output Class Initialized
INFO - 2020-10-16 03:14:28 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:28 --> Input Class Initialized
INFO - 2020-10-16 03:14:28 --> Language Class Initialized
INFO - 2020-10-16 03:14:28 --> Language Class Initialized
INFO - 2020-10-16 03:14:28 --> Config Class Initialized
INFO - 2020-10-16 03:14:28 --> Loader Class Initialized
INFO - 2020-10-16 03:14:28 --> Helper loaded: url_helper
INFO - 2020-10-16 03:14:28 --> Helper loaded: file_helper
INFO - 2020-10-16 03:14:28 --> Helper loaded: form_helper
INFO - 2020-10-16 03:14:28 --> Helper loaded: my_helper
INFO - 2020-10-16 03:14:28 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:14:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:14:28 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:14:28 --> Controller Class Initialized
DEBUG - 2020-10-16 03:14:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:14:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:14:28 --> Final output sent to browser
DEBUG - 2020-10-16 03:14:28 --> Total execution time: 0.4081
INFO - 2020-10-16 03:14:30 --> Config Class Initialized
INFO - 2020-10-16 03:14:30 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:30 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:30 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:30 --> URI Class Initialized
INFO - 2020-10-16 03:14:30 --> Router Class Initialized
INFO - 2020-10-16 03:14:30 --> Output Class Initialized
INFO - 2020-10-16 03:14:30 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:30 --> Input Class Initialized
INFO - 2020-10-16 03:14:30 --> Language Class Initialized
INFO - 2020-10-16 03:14:30 --> Language Class Initialized
INFO - 2020-10-16 03:14:30 --> Config Class Initialized
INFO - 2020-10-16 03:14:30 --> Loader Class Initialized
INFO - 2020-10-16 03:14:30 --> Helper loaded: url_helper
INFO - 2020-10-16 03:14:30 --> Helper loaded: file_helper
INFO - 2020-10-16 03:14:30 --> Helper loaded: form_helper
INFO - 2020-10-16 03:14:30 --> Helper loaded: my_helper
INFO - 2020-10-16 03:14:30 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:14:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:14:30 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:14:30 --> Controller Class Initialized
INFO - 2020-10-16 03:14:30 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:14:30 --> Config Class Initialized
INFO - 2020-10-16 03:14:30 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:30 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:30 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:31 --> URI Class Initialized
INFO - 2020-10-16 03:14:31 --> Router Class Initialized
INFO - 2020-10-16 03:14:31 --> Output Class Initialized
INFO - 2020-10-16 03:14:31 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:31 --> Input Class Initialized
INFO - 2020-10-16 03:14:31 --> Language Class Initialized
ERROR - 2020-10-16 03:14:31 --> 404 Page Not Found: /index
INFO - 2020-10-16 03:14:53 --> Config Class Initialized
INFO - 2020-10-16 03:14:53 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:53 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:53 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:53 --> URI Class Initialized
INFO - 2020-10-16 03:14:53 --> Router Class Initialized
INFO - 2020-10-16 03:14:53 --> Output Class Initialized
INFO - 2020-10-16 03:14:53 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:53 --> Input Class Initialized
INFO - 2020-10-16 03:14:53 --> Language Class Initialized
INFO - 2020-10-16 03:14:53 --> Language Class Initialized
INFO - 2020-10-16 03:14:53 --> Config Class Initialized
INFO - 2020-10-16 03:14:53 --> Loader Class Initialized
INFO - 2020-10-16 03:14:53 --> Helper loaded: url_helper
INFO - 2020-10-16 03:14:53 --> Helper loaded: file_helper
INFO - 2020-10-16 03:14:53 --> Helper loaded: form_helper
INFO - 2020-10-16 03:14:53 --> Helper loaded: my_helper
INFO - 2020-10-16 03:14:53 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:14:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:14:53 --> Controller Class Initialized
DEBUG - 2020-10-16 03:14:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:14:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:14:53 --> Final output sent to browser
DEBUG - 2020-10-16 03:14:53 --> Total execution time: 0.2239
INFO - 2020-10-16 03:14:56 --> Config Class Initialized
INFO - 2020-10-16 03:14:56 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:56 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:56 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:56 --> URI Class Initialized
INFO - 2020-10-16 03:14:56 --> Router Class Initialized
INFO - 2020-10-16 03:14:56 --> Output Class Initialized
INFO - 2020-10-16 03:14:56 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:56 --> Input Class Initialized
INFO - 2020-10-16 03:14:56 --> Language Class Initialized
INFO - 2020-10-16 03:14:56 --> Language Class Initialized
INFO - 2020-10-16 03:14:56 --> Config Class Initialized
INFO - 2020-10-16 03:14:56 --> Loader Class Initialized
INFO - 2020-10-16 03:14:56 --> Helper loaded: url_helper
INFO - 2020-10-16 03:14:56 --> Helper loaded: file_helper
INFO - 2020-10-16 03:14:56 --> Helper loaded: form_helper
INFO - 2020-10-16 03:14:56 --> Helper loaded: my_helper
INFO - 2020-10-16 03:14:56 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:14:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:14:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:14:56 --> Controller Class Initialized
DEBUG - 2020-10-16 03:14:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:14:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:14:56 --> Final output sent to browser
DEBUG - 2020-10-16 03:14:56 --> Total execution time: 0.3010
INFO - 2020-10-16 03:14:57 --> Config Class Initialized
INFO - 2020-10-16 03:14:57 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:57 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:57 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:57 --> URI Class Initialized
INFO - 2020-10-16 03:14:57 --> Router Class Initialized
INFO - 2020-10-16 03:14:57 --> Output Class Initialized
INFO - 2020-10-16 03:14:57 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:57 --> Input Class Initialized
INFO - 2020-10-16 03:14:57 --> Language Class Initialized
INFO - 2020-10-16 03:14:57 --> Language Class Initialized
INFO - 2020-10-16 03:14:57 --> Config Class Initialized
INFO - 2020-10-16 03:14:57 --> Loader Class Initialized
INFO - 2020-10-16 03:14:57 --> Helper loaded: url_helper
INFO - 2020-10-16 03:14:57 --> Helper loaded: file_helper
INFO - 2020-10-16 03:14:57 --> Helper loaded: form_helper
INFO - 2020-10-16 03:14:57 --> Helper loaded: my_helper
INFO - 2020-10-16 03:14:57 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:14:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:14:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:14:57 --> Controller Class Initialized
INFO - 2020-10-16 03:14:57 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:14:57 --> Config Class Initialized
INFO - 2020-10-16 03:14:57 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:14:57 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:14:57 --> Utf8 Class Initialized
INFO - 2020-10-16 03:14:57 --> URI Class Initialized
INFO - 2020-10-16 03:14:57 --> Router Class Initialized
INFO - 2020-10-16 03:14:57 --> Output Class Initialized
INFO - 2020-10-16 03:14:57 --> Security Class Initialized
DEBUG - 2020-10-16 03:14:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:14:57 --> Input Class Initialized
INFO - 2020-10-16 03:14:57 --> Language Class Initialized
ERROR - 2020-10-16 03:14:57 --> 404 Page Not Found: /index
INFO - 2020-10-16 03:15:00 --> Config Class Initialized
INFO - 2020-10-16 03:15:00 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:00 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:00 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:00 --> URI Class Initialized
INFO - 2020-10-16 03:15:00 --> Router Class Initialized
INFO - 2020-10-16 03:15:00 --> Output Class Initialized
INFO - 2020-10-16 03:15:00 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:00 --> Input Class Initialized
INFO - 2020-10-16 03:15:00 --> Language Class Initialized
INFO - 2020-10-16 03:15:00 --> Language Class Initialized
INFO - 2020-10-16 03:15:00 --> Config Class Initialized
INFO - 2020-10-16 03:15:00 --> Loader Class Initialized
INFO - 2020-10-16 03:15:00 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:00 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:00 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:00 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:00 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:00 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:00 --> Controller Class Initialized
DEBUG - 2020-10-16 03:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:15:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:15:00 --> Final output sent to browser
DEBUG - 2020-10-16 03:15:00 --> Total execution time: 0.3203
INFO - 2020-10-16 03:15:05 --> Config Class Initialized
INFO - 2020-10-16 03:15:05 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:05 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:05 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:05 --> URI Class Initialized
INFO - 2020-10-16 03:15:05 --> Router Class Initialized
INFO - 2020-10-16 03:15:05 --> Output Class Initialized
INFO - 2020-10-16 03:15:05 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:05 --> Input Class Initialized
INFO - 2020-10-16 03:15:05 --> Language Class Initialized
INFO - 2020-10-16 03:15:05 --> Language Class Initialized
INFO - 2020-10-16 03:15:05 --> Config Class Initialized
INFO - 2020-10-16 03:15:05 --> Loader Class Initialized
INFO - 2020-10-16 03:15:05 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:05 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:05 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:05 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:05 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:05 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:05 --> Controller Class Initialized
DEBUG - 2020-10-16 03:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:15:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:15:06 --> Final output sent to browser
DEBUG - 2020-10-16 03:15:06 --> Total execution time: 0.2629
INFO - 2020-10-16 03:15:07 --> Config Class Initialized
INFO - 2020-10-16 03:15:07 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:07 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:07 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:07 --> URI Class Initialized
INFO - 2020-10-16 03:15:07 --> Router Class Initialized
INFO - 2020-10-16 03:15:07 --> Output Class Initialized
INFO - 2020-10-16 03:15:07 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:07 --> Input Class Initialized
INFO - 2020-10-16 03:15:07 --> Language Class Initialized
INFO - 2020-10-16 03:15:07 --> Language Class Initialized
INFO - 2020-10-16 03:15:07 --> Config Class Initialized
INFO - 2020-10-16 03:15:07 --> Loader Class Initialized
INFO - 2020-10-16 03:15:07 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:07 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:07 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:07 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:07 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:07 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:07 --> Controller Class Initialized
INFO - 2020-10-16 03:15:07 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:15:07 --> Config Class Initialized
INFO - 2020-10-16 03:15:07 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:07 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:07 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:07 --> URI Class Initialized
INFO - 2020-10-16 03:15:07 --> Router Class Initialized
INFO - 2020-10-16 03:15:07 --> Output Class Initialized
INFO - 2020-10-16 03:15:07 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:07 --> Input Class Initialized
INFO - 2020-10-16 03:15:07 --> Language Class Initialized
ERROR - 2020-10-16 03:15:07 --> 404 Page Not Found: /index
INFO - 2020-10-16 03:15:19 --> Config Class Initialized
INFO - 2020-10-16 03:15:19 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:19 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:19 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:19 --> URI Class Initialized
INFO - 2020-10-16 03:15:19 --> Router Class Initialized
INFO - 2020-10-16 03:15:19 --> Output Class Initialized
INFO - 2020-10-16 03:15:19 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:19 --> Input Class Initialized
INFO - 2020-10-16 03:15:19 --> Language Class Initialized
INFO - 2020-10-16 03:15:19 --> Language Class Initialized
INFO - 2020-10-16 03:15:19 --> Config Class Initialized
INFO - 2020-10-16 03:15:19 --> Loader Class Initialized
INFO - 2020-10-16 03:15:19 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:19 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:19 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:19 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:19 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:19 --> Controller Class Initialized
DEBUG - 2020-10-16 03:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:15:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:15:19 --> Final output sent to browser
DEBUG - 2020-10-16 03:15:19 --> Total execution time: 0.2884
INFO - 2020-10-16 03:15:24 --> Config Class Initialized
INFO - 2020-10-16 03:15:24 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:24 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:24 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:24 --> URI Class Initialized
INFO - 2020-10-16 03:15:24 --> Router Class Initialized
INFO - 2020-10-16 03:15:24 --> Output Class Initialized
INFO - 2020-10-16 03:15:24 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:24 --> Input Class Initialized
INFO - 2020-10-16 03:15:24 --> Language Class Initialized
INFO - 2020-10-16 03:15:24 --> Language Class Initialized
INFO - 2020-10-16 03:15:24 --> Config Class Initialized
INFO - 2020-10-16 03:15:24 --> Loader Class Initialized
INFO - 2020-10-16 03:15:24 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:24 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:24 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:24 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:24 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:24 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:24 --> Controller Class Initialized
DEBUG - 2020-10-16 03:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:15:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:15:24 --> Final output sent to browser
DEBUG - 2020-10-16 03:15:24 --> Total execution time: 0.2501
INFO - 2020-10-16 03:15:26 --> Config Class Initialized
INFO - 2020-10-16 03:15:26 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:26 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:26 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:26 --> URI Class Initialized
INFO - 2020-10-16 03:15:26 --> Router Class Initialized
INFO - 2020-10-16 03:15:26 --> Output Class Initialized
INFO - 2020-10-16 03:15:26 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:26 --> Input Class Initialized
INFO - 2020-10-16 03:15:26 --> Language Class Initialized
INFO - 2020-10-16 03:15:26 --> Language Class Initialized
INFO - 2020-10-16 03:15:26 --> Config Class Initialized
INFO - 2020-10-16 03:15:26 --> Loader Class Initialized
INFO - 2020-10-16 03:15:26 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:26 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:26 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:26 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:26 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:26 --> Controller Class Initialized
INFO - 2020-10-16 03:15:26 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:15:26 --> Config Class Initialized
INFO - 2020-10-16 03:15:26 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:26 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:26 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:26 --> URI Class Initialized
DEBUG - 2020-10-16 03:15:26 --> No URI present. Default controller set.
INFO - 2020-10-16 03:15:26 --> Router Class Initialized
INFO - 2020-10-16 03:15:26 --> Output Class Initialized
INFO - 2020-10-16 03:15:26 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:26 --> Input Class Initialized
INFO - 2020-10-16 03:15:26 --> Language Class Initialized
INFO - 2020-10-16 03:15:26 --> Language Class Initialized
INFO - 2020-10-16 03:15:26 --> Config Class Initialized
INFO - 2020-10-16 03:15:26 --> Loader Class Initialized
INFO - 2020-10-16 03:15:26 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:26 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:26 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:26 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:26 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:26 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:26 --> Controller Class Initialized
DEBUG - 2020-10-16 03:15:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:15:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:15:26 --> Final output sent to browser
DEBUG - 2020-10-16 03:15:26 --> Total execution time: 0.2386
INFO - 2020-10-16 03:15:28 --> Config Class Initialized
INFO - 2020-10-16 03:15:28 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:28 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:28 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:28 --> URI Class Initialized
INFO - 2020-10-16 03:15:28 --> Router Class Initialized
INFO - 2020-10-16 03:15:28 --> Output Class Initialized
INFO - 2020-10-16 03:15:28 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:28 --> Input Class Initialized
INFO - 2020-10-16 03:15:28 --> Language Class Initialized
INFO - 2020-10-16 03:15:28 --> Language Class Initialized
INFO - 2020-10-16 03:15:28 --> Config Class Initialized
INFO - 2020-10-16 03:15:28 --> Loader Class Initialized
INFO - 2020-10-16 03:15:28 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:28 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:28 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:28 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:29 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:29 --> Controller Class Initialized
INFO - 2020-10-16 03:15:29 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:15:29 --> Config Class Initialized
INFO - 2020-10-16 03:15:29 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:15:29 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:15:29 --> Utf8 Class Initialized
INFO - 2020-10-16 03:15:29 --> URI Class Initialized
DEBUG - 2020-10-16 03:15:29 --> No URI present. Default controller set.
INFO - 2020-10-16 03:15:29 --> Router Class Initialized
INFO - 2020-10-16 03:15:29 --> Output Class Initialized
INFO - 2020-10-16 03:15:29 --> Security Class Initialized
DEBUG - 2020-10-16 03:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:15:29 --> Input Class Initialized
INFO - 2020-10-16 03:15:29 --> Language Class Initialized
INFO - 2020-10-16 03:15:29 --> Language Class Initialized
INFO - 2020-10-16 03:15:29 --> Config Class Initialized
INFO - 2020-10-16 03:15:29 --> Loader Class Initialized
INFO - 2020-10-16 03:15:29 --> Helper loaded: url_helper
INFO - 2020-10-16 03:15:29 --> Helper loaded: file_helper
INFO - 2020-10-16 03:15:29 --> Helper loaded: form_helper
INFO - 2020-10-16 03:15:29 --> Helper loaded: my_helper
INFO - 2020-10-16 03:15:29 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:15:29 --> Controller Class Initialized
DEBUG - 2020-10-16 03:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:15:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:15:29 --> Final output sent to browser
DEBUG - 2020-10-16 03:15:29 --> Total execution time: 0.2510
INFO - 2020-10-16 03:20:36 --> Config Class Initialized
INFO - 2020-10-16 03:20:36 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:20:36 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:20:36 --> Utf8 Class Initialized
INFO - 2020-10-16 03:20:36 --> URI Class Initialized
DEBUG - 2020-10-16 03:20:36 --> No URI present. Default controller set.
INFO - 2020-10-16 03:20:36 --> Router Class Initialized
INFO - 2020-10-16 03:20:36 --> Output Class Initialized
INFO - 2020-10-16 03:20:36 --> Security Class Initialized
DEBUG - 2020-10-16 03:20:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:20:36 --> Input Class Initialized
INFO - 2020-10-16 03:20:36 --> Language Class Initialized
INFO - 2020-10-16 03:20:36 --> Language Class Initialized
INFO - 2020-10-16 03:20:36 --> Config Class Initialized
INFO - 2020-10-16 03:20:36 --> Loader Class Initialized
INFO - 2020-10-16 03:20:36 --> Helper loaded: url_helper
INFO - 2020-10-16 03:20:36 --> Helper loaded: file_helper
INFO - 2020-10-16 03:20:36 --> Helper loaded: form_helper
INFO - 2020-10-16 03:20:36 --> Helper loaded: my_helper
INFO - 2020-10-16 03:20:36 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:20:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:20:36 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:20:36 --> Controller Class Initialized
DEBUG - 2020-10-16 03:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:20:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:20:36 --> Final output sent to browser
DEBUG - 2020-10-16 03:20:36 --> Total execution time: 0.2862
INFO - 2020-10-16 03:20:38 --> Config Class Initialized
INFO - 2020-10-16 03:20:38 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:20:38 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:20:38 --> Utf8 Class Initialized
INFO - 2020-10-16 03:20:38 --> URI Class Initialized
INFO - 2020-10-16 03:20:38 --> Router Class Initialized
INFO - 2020-10-16 03:20:38 --> Output Class Initialized
INFO - 2020-10-16 03:20:38 --> Security Class Initialized
DEBUG - 2020-10-16 03:20:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:20:38 --> Input Class Initialized
INFO - 2020-10-16 03:20:38 --> Language Class Initialized
INFO - 2020-10-16 03:20:38 --> Language Class Initialized
INFO - 2020-10-16 03:20:38 --> Config Class Initialized
INFO - 2020-10-16 03:20:38 --> Loader Class Initialized
INFO - 2020-10-16 03:20:38 --> Helper loaded: url_helper
INFO - 2020-10-16 03:20:38 --> Helper loaded: file_helper
INFO - 2020-10-16 03:20:38 --> Helper loaded: form_helper
INFO - 2020-10-16 03:20:38 --> Helper loaded: my_helper
INFO - 2020-10-16 03:20:38 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:20:38 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:20:38 --> Controller Class Initialized
INFO - 2020-10-16 03:20:38 --> Helper loaded: cookie_helper
DEBUG - 2020-10-16 03:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-16 03:20:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:20:38 --> Final output sent to browser
DEBUG - 2020-10-16 03:20:38 --> Total execution time: 0.2445
INFO - 2020-10-16 03:30:40 --> Config Class Initialized
INFO - 2020-10-16 03:30:40 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:30:40 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:30:40 --> Utf8 Class Initialized
INFO - 2020-10-16 03:30:40 --> URI Class Initialized
INFO - 2020-10-16 03:30:40 --> Router Class Initialized
INFO - 2020-10-16 03:30:40 --> Output Class Initialized
INFO - 2020-10-16 03:30:40 --> Security Class Initialized
DEBUG - 2020-10-16 03:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:30:40 --> Input Class Initialized
INFO - 2020-10-16 03:30:40 --> Language Class Initialized
INFO - 2020-10-16 03:30:40 --> Language Class Initialized
INFO - 2020-10-16 03:30:40 --> Config Class Initialized
INFO - 2020-10-16 03:30:40 --> Loader Class Initialized
INFO - 2020-10-16 03:30:40 --> Helper loaded: url_helper
INFO - 2020-10-16 03:30:40 --> Helper loaded: file_helper
INFO - 2020-10-16 03:30:40 --> Helper loaded: form_helper
INFO - 2020-10-16 03:30:40 --> Helper loaded: my_helper
INFO - 2020-10-16 03:30:40 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:30:40 --> Controller Class Initialized
INFO - 2020-10-16 03:30:40 --> Helper loaded: cookie_helper
DEBUG - 2020-10-16 03:30:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-16 03:30:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:30:40 --> Final output sent to browser
DEBUG - 2020-10-16 03:30:40 --> Total execution time: 0.2687
INFO - 2020-10-16 03:30:47 --> Config Class Initialized
INFO - 2020-10-16 03:30:47 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:30:47 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:30:47 --> Utf8 Class Initialized
INFO - 2020-10-16 03:30:47 --> URI Class Initialized
DEBUG - 2020-10-16 03:30:47 --> No URI present. Default controller set.
INFO - 2020-10-16 03:30:47 --> Router Class Initialized
INFO - 2020-10-16 03:30:47 --> Output Class Initialized
INFO - 2020-10-16 03:30:47 --> Security Class Initialized
DEBUG - 2020-10-16 03:30:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:30:47 --> Input Class Initialized
INFO - 2020-10-16 03:30:47 --> Language Class Initialized
INFO - 2020-10-16 03:30:47 --> Language Class Initialized
INFO - 2020-10-16 03:30:47 --> Config Class Initialized
INFO - 2020-10-16 03:30:47 --> Loader Class Initialized
INFO - 2020-10-16 03:30:47 --> Helper loaded: url_helper
INFO - 2020-10-16 03:30:47 --> Helper loaded: file_helper
INFO - 2020-10-16 03:30:47 --> Helper loaded: form_helper
INFO - 2020-10-16 03:30:47 --> Helper loaded: my_helper
INFO - 2020-10-16 03:30:48 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:30:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:30:48 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:30:48 --> Controller Class Initialized
DEBUG - 2020-10-16 03:30:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:30:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:30:48 --> Final output sent to browser
DEBUG - 2020-10-16 03:30:48 --> Total execution time: 0.3404
INFO - 2020-10-16 03:33:53 --> Config Class Initialized
INFO - 2020-10-16 03:33:53 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:33:53 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:33:53 --> Utf8 Class Initialized
INFO - 2020-10-16 03:33:53 --> URI Class Initialized
DEBUG - 2020-10-16 03:33:53 --> No URI present. Default controller set.
INFO - 2020-10-16 03:33:53 --> Router Class Initialized
INFO - 2020-10-16 03:33:53 --> Output Class Initialized
INFO - 2020-10-16 03:33:53 --> Security Class Initialized
DEBUG - 2020-10-16 03:33:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:33:53 --> Input Class Initialized
INFO - 2020-10-16 03:33:53 --> Language Class Initialized
INFO - 2020-10-16 03:33:53 --> Language Class Initialized
INFO - 2020-10-16 03:33:53 --> Config Class Initialized
INFO - 2020-10-16 03:33:53 --> Loader Class Initialized
INFO - 2020-10-16 03:33:53 --> Helper loaded: url_helper
INFO - 2020-10-16 03:33:53 --> Helper loaded: file_helper
INFO - 2020-10-16 03:33:53 --> Helper loaded: form_helper
INFO - 2020-10-16 03:33:53 --> Helper loaded: my_helper
INFO - 2020-10-16 03:33:53 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:33:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:33:53 --> Controller Class Initialized
DEBUG - 2020-10-16 03:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:33:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:33:53 --> Final output sent to browser
DEBUG - 2020-10-16 03:33:53 --> Total execution time: 0.3309
INFO - 2020-10-16 03:33:54 --> Config Class Initialized
INFO - 2020-10-16 03:33:54 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:33:54 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:33:54 --> Utf8 Class Initialized
INFO - 2020-10-16 03:33:55 --> URI Class Initialized
INFO - 2020-10-16 03:33:55 --> Router Class Initialized
INFO - 2020-10-16 03:33:55 --> Output Class Initialized
INFO - 2020-10-16 03:33:55 --> Security Class Initialized
DEBUG - 2020-10-16 03:33:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:33:55 --> Input Class Initialized
INFO - 2020-10-16 03:33:55 --> Language Class Initialized
ERROR - 2020-10-16 03:33:55 --> Severity: Parsing Error --> syntax error, unexpected 'public' (T_PUBLIC) C:\xampp\htdocs\nilai\application\modules\login\controllers\Login.php 111
INFO - 2020-10-16 03:36:56 --> Config Class Initialized
INFO - 2020-10-16 03:36:56 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:36:56 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:36:56 --> Utf8 Class Initialized
INFO - 2020-10-16 03:36:56 --> URI Class Initialized
DEBUG - 2020-10-16 03:36:56 --> No URI present. Default controller set.
INFO - 2020-10-16 03:36:56 --> Router Class Initialized
INFO - 2020-10-16 03:36:56 --> Output Class Initialized
INFO - 2020-10-16 03:36:56 --> Security Class Initialized
DEBUG - 2020-10-16 03:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:36:56 --> Input Class Initialized
INFO - 2020-10-16 03:36:56 --> Language Class Initialized
INFO - 2020-10-16 03:36:56 --> Language Class Initialized
INFO - 2020-10-16 03:36:56 --> Config Class Initialized
INFO - 2020-10-16 03:36:56 --> Loader Class Initialized
INFO - 2020-10-16 03:36:56 --> Helper loaded: url_helper
INFO - 2020-10-16 03:36:56 --> Helper loaded: file_helper
INFO - 2020-10-16 03:36:56 --> Helper loaded: form_helper
INFO - 2020-10-16 03:36:56 --> Helper loaded: my_helper
INFO - 2020-10-16 03:36:56 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:36:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:36:56 --> Controller Class Initialized
DEBUG - 2020-10-16 03:36:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:36:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:36:56 --> Final output sent to browser
DEBUG - 2020-10-16 03:36:56 --> Total execution time: 0.2850
INFO - 2020-10-16 03:36:58 --> Config Class Initialized
INFO - 2020-10-16 03:36:58 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:36:58 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:36:58 --> Utf8 Class Initialized
INFO - 2020-10-16 03:36:58 --> URI Class Initialized
DEBUG - 2020-10-16 03:36:58 --> No URI present. Default controller set.
INFO - 2020-10-16 03:36:58 --> Router Class Initialized
INFO - 2020-10-16 03:36:58 --> Output Class Initialized
INFO - 2020-10-16 03:36:58 --> Security Class Initialized
DEBUG - 2020-10-16 03:36:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:36:58 --> Input Class Initialized
INFO - 2020-10-16 03:36:58 --> Language Class Initialized
INFO - 2020-10-16 03:36:58 --> Language Class Initialized
INFO - 2020-10-16 03:36:58 --> Config Class Initialized
INFO - 2020-10-16 03:36:58 --> Loader Class Initialized
INFO - 2020-10-16 03:36:58 --> Helper loaded: url_helper
INFO - 2020-10-16 03:36:58 --> Helper loaded: file_helper
INFO - 2020-10-16 03:36:58 --> Helper loaded: form_helper
INFO - 2020-10-16 03:36:58 --> Helper loaded: my_helper
INFO - 2020-10-16 03:36:58 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:36:58 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:36:58 --> Controller Class Initialized
DEBUG - 2020-10-16 03:36:58 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:36:58 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:36:58 --> Final output sent to browser
DEBUG - 2020-10-16 03:36:58 --> Total execution time: 0.2907
INFO - 2020-10-16 03:36:59 --> Config Class Initialized
INFO - 2020-10-16 03:36:59 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:36:59 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:36:59 --> Utf8 Class Initialized
INFO - 2020-10-16 03:36:59 --> URI Class Initialized
INFO - 2020-10-16 03:36:59 --> Router Class Initialized
INFO - 2020-10-16 03:36:59 --> Output Class Initialized
INFO - 2020-10-16 03:36:59 --> Security Class Initialized
DEBUG - 2020-10-16 03:36:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:36:59 --> Input Class Initialized
INFO - 2020-10-16 03:36:59 --> Language Class Initialized
ERROR - 2020-10-16 03:36:59 --> Severity: Parsing Error --> syntax error, unexpected '->' (T_OBJECT_OPERATOR) C:\xampp\htdocs\nilai\application\modules\login\controllers\Login.php 108
INFO - 2020-10-16 03:37:15 --> Config Class Initialized
INFO - 2020-10-16 03:37:15 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:37:15 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:37:15 --> Utf8 Class Initialized
INFO - 2020-10-16 03:37:15 --> URI Class Initialized
DEBUG - 2020-10-16 03:37:15 --> No URI present. Default controller set.
INFO - 2020-10-16 03:37:15 --> Router Class Initialized
INFO - 2020-10-16 03:37:15 --> Output Class Initialized
INFO - 2020-10-16 03:37:15 --> Security Class Initialized
DEBUG - 2020-10-16 03:37:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:37:15 --> Input Class Initialized
INFO - 2020-10-16 03:37:15 --> Language Class Initialized
INFO - 2020-10-16 03:37:15 --> Language Class Initialized
INFO - 2020-10-16 03:37:15 --> Config Class Initialized
INFO - 2020-10-16 03:37:15 --> Loader Class Initialized
INFO - 2020-10-16 03:37:15 --> Helper loaded: url_helper
INFO - 2020-10-16 03:37:15 --> Helper loaded: file_helper
INFO - 2020-10-16 03:37:15 --> Helper loaded: form_helper
INFO - 2020-10-16 03:37:15 --> Helper loaded: my_helper
INFO - 2020-10-16 03:37:15 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:37:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:37:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:37:16 --> Controller Class Initialized
DEBUG - 2020-10-16 03:37:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:37:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:37:16 --> Final output sent to browser
DEBUG - 2020-10-16 03:37:16 --> Total execution time: 0.2488
INFO - 2020-10-16 03:37:16 --> Config Class Initialized
INFO - 2020-10-16 03:37:16 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:37:16 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:37:16 --> Utf8 Class Initialized
INFO - 2020-10-16 03:37:16 --> URI Class Initialized
DEBUG - 2020-10-16 03:37:16 --> No URI present. Default controller set.
INFO - 2020-10-16 03:37:16 --> Router Class Initialized
INFO - 2020-10-16 03:37:17 --> Output Class Initialized
INFO - 2020-10-16 03:37:17 --> Security Class Initialized
DEBUG - 2020-10-16 03:37:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:37:17 --> Input Class Initialized
INFO - 2020-10-16 03:37:17 --> Language Class Initialized
INFO - 2020-10-16 03:37:17 --> Language Class Initialized
INFO - 2020-10-16 03:37:17 --> Config Class Initialized
INFO - 2020-10-16 03:37:17 --> Loader Class Initialized
INFO - 2020-10-16 03:37:17 --> Helper loaded: url_helper
INFO - 2020-10-16 03:37:17 --> Helper loaded: file_helper
INFO - 2020-10-16 03:37:17 --> Helper loaded: form_helper
INFO - 2020-10-16 03:37:17 --> Helper loaded: my_helper
INFO - 2020-10-16 03:37:17 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:37:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:37:17 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:37:17 --> Controller Class Initialized
DEBUG - 2020-10-16 03:37:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:37:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:37:17 --> Final output sent to browser
DEBUG - 2020-10-16 03:37:17 --> Total execution time: 0.2960
INFO - 2020-10-16 03:37:18 --> Config Class Initialized
INFO - 2020-10-16 03:37:18 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:37:18 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:37:18 --> Utf8 Class Initialized
INFO - 2020-10-16 03:37:18 --> URI Class Initialized
INFO - 2020-10-16 03:37:18 --> Router Class Initialized
INFO - 2020-10-16 03:37:18 --> Output Class Initialized
INFO - 2020-10-16 03:37:18 --> Security Class Initialized
DEBUG - 2020-10-16 03:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:37:18 --> Input Class Initialized
INFO - 2020-10-16 03:37:18 --> Language Class Initialized
INFO - 2020-10-16 03:37:18 --> Language Class Initialized
INFO - 2020-10-16 03:37:18 --> Config Class Initialized
INFO - 2020-10-16 03:37:18 --> Loader Class Initialized
INFO - 2020-10-16 03:37:18 --> Helper loaded: url_helper
INFO - 2020-10-16 03:37:18 --> Helper loaded: file_helper
INFO - 2020-10-16 03:37:18 --> Helper loaded: form_helper
INFO - 2020-10-16 03:37:18 --> Helper loaded: my_helper
INFO - 2020-10-16 03:37:18 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:37:19 --> Controller Class Initialized
INFO - 2020-10-16 03:37:19 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:37:19 --> Config Class Initialized
INFO - 2020-10-16 03:37:19 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:37:19 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:37:19 --> Utf8 Class Initialized
INFO - 2020-10-16 03:37:19 --> URI Class Initialized
INFO - 2020-10-16 03:37:19 --> Router Class Initialized
INFO - 2020-10-16 03:37:19 --> Output Class Initialized
INFO - 2020-10-16 03:37:19 --> Security Class Initialized
DEBUG - 2020-10-16 03:37:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:37:19 --> Input Class Initialized
INFO - 2020-10-16 03:37:19 --> Language Class Initialized
INFO - 2020-10-16 03:37:19 --> Language Class Initialized
INFO - 2020-10-16 03:37:19 --> Config Class Initialized
INFO - 2020-10-16 03:37:19 --> Loader Class Initialized
INFO - 2020-10-16 03:37:19 --> Helper loaded: url_helper
INFO - 2020-10-16 03:37:19 --> Helper loaded: file_helper
INFO - 2020-10-16 03:37:19 --> Helper loaded: form_helper
INFO - 2020-10-16 03:37:19 --> Helper loaded: my_helper
INFO - 2020-10-16 03:37:19 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:37:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:37:19 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:37:19 --> Controller Class Initialized
DEBUG - 2020-10-16 03:37:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-16 03:37:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:37:19 --> Final output sent to browser
DEBUG - 2020-10-16 03:37:19 --> Total execution time: 0.2746
INFO - 2020-10-16 03:54:40 --> Config Class Initialized
INFO - 2020-10-16 03:54:40 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:54:40 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:54:40 --> Utf8 Class Initialized
INFO - 2020-10-16 03:54:40 --> URI Class Initialized
DEBUG - 2020-10-16 03:54:40 --> No URI present. Default controller set.
INFO - 2020-10-16 03:54:40 --> Router Class Initialized
INFO - 2020-10-16 03:54:40 --> Output Class Initialized
INFO - 2020-10-16 03:54:40 --> Security Class Initialized
DEBUG - 2020-10-16 03:54:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:54:40 --> Input Class Initialized
INFO - 2020-10-16 03:54:40 --> Language Class Initialized
INFO - 2020-10-16 03:54:40 --> Language Class Initialized
INFO - 2020-10-16 03:54:40 --> Config Class Initialized
INFO - 2020-10-16 03:54:40 --> Loader Class Initialized
INFO - 2020-10-16 03:54:40 --> Helper loaded: url_helper
INFO - 2020-10-16 03:54:40 --> Helper loaded: file_helper
INFO - 2020-10-16 03:54:40 --> Helper loaded: form_helper
INFO - 2020-10-16 03:54:40 --> Helper loaded: my_helper
INFO - 2020-10-16 03:54:40 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:54:40 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:54:40 --> Controller Class Initialized
INFO - 2020-10-16 03:54:40 --> Config Class Initialized
INFO - 2020-10-16 03:54:40 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:54:40 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:54:40 --> Utf8 Class Initialized
INFO - 2020-10-16 03:54:41 --> URI Class Initialized
INFO - 2020-10-16 03:54:41 --> Router Class Initialized
INFO - 2020-10-16 03:54:41 --> Output Class Initialized
INFO - 2020-10-16 03:54:41 --> Security Class Initialized
DEBUG - 2020-10-16 03:54:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:54:41 --> Input Class Initialized
INFO - 2020-10-16 03:54:41 --> Language Class Initialized
INFO - 2020-10-16 03:54:41 --> Language Class Initialized
INFO - 2020-10-16 03:54:41 --> Config Class Initialized
INFO - 2020-10-16 03:54:41 --> Loader Class Initialized
INFO - 2020-10-16 03:54:41 --> Helper loaded: url_helper
INFO - 2020-10-16 03:54:41 --> Helper loaded: file_helper
INFO - 2020-10-16 03:54:41 --> Helper loaded: form_helper
INFO - 2020-10-16 03:54:41 --> Helper loaded: my_helper
INFO - 2020-10-16 03:54:41 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:54:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:54:41 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:54:41 --> Controller Class Initialized
DEBUG - 2020-10-16 03:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-16 03:54:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:54:41 --> Final output sent to browser
DEBUG - 2020-10-16 03:54:41 --> Total execution time: 0.3253
INFO - 2020-10-16 03:54:51 --> Config Class Initialized
INFO - 2020-10-16 03:54:51 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:54:51 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:54:51 --> Utf8 Class Initialized
INFO - 2020-10-16 03:54:51 --> URI Class Initialized
INFO - 2020-10-16 03:54:51 --> Router Class Initialized
INFO - 2020-10-16 03:54:51 --> Output Class Initialized
INFO - 2020-10-16 03:54:51 --> Security Class Initialized
DEBUG - 2020-10-16 03:54:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:54:51 --> Input Class Initialized
INFO - 2020-10-16 03:54:51 --> Language Class Initialized
INFO - 2020-10-16 03:54:51 --> Language Class Initialized
INFO - 2020-10-16 03:54:51 --> Config Class Initialized
INFO - 2020-10-16 03:54:51 --> Loader Class Initialized
INFO - 2020-10-16 03:54:51 --> Helper loaded: url_helper
INFO - 2020-10-16 03:54:51 --> Helper loaded: file_helper
INFO - 2020-10-16 03:54:51 --> Helper loaded: form_helper
INFO - 2020-10-16 03:54:51 --> Helper loaded: my_helper
INFO - 2020-10-16 03:54:51 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:54:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:54:51 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:54:51 --> Controller Class Initialized
INFO - 2020-10-16 03:54:52 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:54:52 --> Final output sent to browser
DEBUG - 2020-10-16 03:54:52 --> Total execution time: 0.3732
INFO - 2020-10-16 03:54:56 --> Config Class Initialized
INFO - 2020-10-16 03:54:56 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:54:56 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:54:56 --> Utf8 Class Initialized
INFO - 2020-10-16 03:54:56 --> URI Class Initialized
INFO - 2020-10-16 03:54:56 --> Router Class Initialized
INFO - 2020-10-16 03:54:56 --> Output Class Initialized
INFO - 2020-10-16 03:54:56 --> Security Class Initialized
DEBUG - 2020-10-16 03:54:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:54:57 --> Input Class Initialized
INFO - 2020-10-16 03:54:57 --> Language Class Initialized
INFO - 2020-10-16 03:54:57 --> Language Class Initialized
INFO - 2020-10-16 03:54:57 --> Config Class Initialized
INFO - 2020-10-16 03:54:57 --> Loader Class Initialized
INFO - 2020-10-16 03:54:57 --> Helper loaded: url_helper
INFO - 2020-10-16 03:54:57 --> Helper loaded: file_helper
INFO - 2020-10-16 03:54:57 --> Helper loaded: form_helper
INFO - 2020-10-16 03:54:57 --> Helper loaded: my_helper
INFO - 2020-10-16 03:54:57 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:54:57 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:54:57 --> Controller Class Initialized
DEBUG - 2020-10-16 03:54:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-10-16 03:54:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:54:57 --> Final output sent to browser
DEBUG - 2020-10-16 03:54:57 --> Total execution time: 0.4475
INFO - 2020-10-16 03:54:58 --> Config Class Initialized
INFO - 2020-10-16 03:54:58 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:54:58 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:54:58 --> Utf8 Class Initialized
INFO - 2020-10-16 03:54:58 --> URI Class Initialized
INFO - 2020-10-16 03:54:58 --> Router Class Initialized
INFO - 2020-10-16 03:54:58 --> Output Class Initialized
INFO - 2020-10-16 03:54:58 --> Security Class Initialized
DEBUG - 2020-10-16 03:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:54:58 --> Input Class Initialized
INFO - 2020-10-16 03:54:58 --> Language Class Initialized
INFO - 2020-10-16 03:54:59 --> Language Class Initialized
INFO - 2020-10-16 03:54:59 --> Config Class Initialized
INFO - 2020-10-16 03:54:59 --> Loader Class Initialized
INFO - 2020-10-16 03:54:59 --> Helper loaded: url_helper
INFO - 2020-10-16 03:54:59 --> Helper loaded: file_helper
INFO - 2020-10-16 03:54:59 --> Helper loaded: form_helper
INFO - 2020-10-16 03:54:59 --> Helper loaded: my_helper
INFO - 2020-10-16 03:54:59 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:54:59 --> Controller Class Initialized
INFO - 2020-10-16 03:54:59 --> Helper loaded: cookie_helper
INFO - 2020-10-16 03:54:59 --> Config Class Initialized
INFO - 2020-10-16 03:54:59 --> Hooks Class Initialized
DEBUG - 2020-10-16 03:54:59 --> UTF-8 Support Enabled
INFO - 2020-10-16 03:54:59 --> Utf8 Class Initialized
INFO - 2020-10-16 03:54:59 --> URI Class Initialized
INFO - 2020-10-16 03:54:59 --> Router Class Initialized
INFO - 2020-10-16 03:54:59 --> Output Class Initialized
INFO - 2020-10-16 03:54:59 --> Security Class Initialized
DEBUG - 2020-10-16 03:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-10-16 03:54:59 --> Input Class Initialized
INFO - 2020-10-16 03:54:59 --> Language Class Initialized
INFO - 2020-10-16 03:54:59 --> Language Class Initialized
INFO - 2020-10-16 03:54:59 --> Config Class Initialized
INFO - 2020-10-16 03:54:59 --> Loader Class Initialized
INFO - 2020-10-16 03:54:59 --> Helper loaded: url_helper
INFO - 2020-10-16 03:54:59 --> Helper loaded: file_helper
INFO - 2020-10-16 03:54:59 --> Helper loaded: form_helper
INFO - 2020-10-16 03:54:59 --> Helper loaded: my_helper
INFO - 2020-10-16 03:54:59 --> Database Driver Class Initialized
DEBUG - 2020-10-16 03:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-10-16 03:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2020-10-16 03:54:59 --> Controller Class Initialized
DEBUG - 2020-10-16 03:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-10-16 03:54:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-10-16 03:54:59 --> Final output sent to browser
DEBUG - 2020-10-16 03:54:59 --> Total execution time: 0.2503
