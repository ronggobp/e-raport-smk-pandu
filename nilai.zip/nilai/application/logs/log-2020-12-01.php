<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2020-12-01 02:30:15 --> Config Class Initialized
INFO - 2020-12-01 02:30:15 --> Hooks Class Initialized
DEBUG - 2020-12-01 02:30:15 --> UTF-8 Support Enabled
INFO - 2020-12-01 02:30:15 --> Utf8 Class Initialized
INFO - 2020-12-01 02:30:15 --> URI Class Initialized
DEBUG - 2020-12-01 02:30:15 --> No URI present. Default controller set.
INFO - 2020-12-01 02:30:15 --> Router Class Initialized
INFO - 2020-12-01 02:30:15 --> Output Class Initialized
INFO - 2020-12-01 02:30:15 --> Security Class Initialized
DEBUG - 2020-12-01 02:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-01 02:30:15 --> Input Class Initialized
INFO - 2020-12-01 02:30:15 --> Language Class Initialized
INFO - 2020-12-01 02:30:16 --> Language Class Initialized
INFO - 2020-12-01 02:30:16 --> Config Class Initialized
INFO - 2020-12-01 02:30:16 --> Loader Class Initialized
INFO - 2020-12-01 02:30:16 --> Helper loaded: url_helper
INFO - 2020-12-01 02:30:16 --> Helper loaded: file_helper
INFO - 2020-12-01 02:30:16 --> Helper loaded: form_helper
INFO - 2020-12-01 02:30:16 --> Helper loaded: my_helper
INFO - 2020-12-01 02:30:16 --> Database Driver Class Initialized
DEBUG - 2020-12-01 02:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-01 02:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-01 02:30:16 --> Controller Class Initialized
INFO - 2020-12-01 02:30:16 --> Config Class Initialized
INFO - 2020-12-01 02:30:16 --> Hooks Class Initialized
DEBUG - 2020-12-01 02:30:16 --> UTF-8 Support Enabled
INFO - 2020-12-01 02:30:16 --> Utf8 Class Initialized
INFO - 2020-12-01 02:30:16 --> URI Class Initialized
INFO - 2020-12-01 02:30:16 --> Router Class Initialized
INFO - 2020-12-01 02:30:16 --> Output Class Initialized
INFO - 2020-12-01 02:30:16 --> Security Class Initialized
DEBUG - 2020-12-01 02:30:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-01 02:30:16 --> Input Class Initialized
INFO - 2020-12-01 02:30:16 --> Language Class Initialized
INFO - 2020-12-01 02:30:16 --> Language Class Initialized
INFO - 2020-12-01 02:30:16 --> Config Class Initialized
INFO - 2020-12-01 02:30:16 --> Loader Class Initialized
INFO - 2020-12-01 02:30:16 --> Helper loaded: url_helper
INFO - 2020-12-01 02:30:16 --> Helper loaded: file_helper
INFO - 2020-12-01 02:30:16 --> Helper loaded: form_helper
INFO - 2020-12-01 02:30:16 --> Helper loaded: my_helper
INFO - 2020-12-01 02:30:16 --> Database Driver Class Initialized
DEBUG - 2020-12-01 02:30:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-01 02:30:16 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-01 02:30:16 --> Controller Class Initialized
DEBUG - 2020-12-01 02:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2020-12-01 02:30:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-01 02:30:16 --> Final output sent to browser
DEBUG - 2020-12-01 02:30:16 --> Total execution time: 0.3013
INFO - 2020-12-01 02:31:52 --> Config Class Initialized
INFO - 2020-12-01 02:31:52 --> Hooks Class Initialized
DEBUG - 2020-12-01 02:31:52 --> UTF-8 Support Enabled
INFO - 2020-12-01 02:31:52 --> Utf8 Class Initialized
INFO - 2020-12-01 02:31:52 --> URI Class Initialized
INFO - 2020-12-01 02:31:52 --> Router Class Initialized
INFO - 2020-12-01 02:31:52 --> Output Class Initialized
INFO - 2020-12-01 02:31:52 --> Security Class Initialized
DEBUG - 2020-12-01 02:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-01 02:31:52 --> Input Class Initialized
INFO - 2020-12-01 02:31:52 --> Language Class Initialized
INFO - 2020-12-01 02:31:52 --> Language Class Initialized
INFO - 2020-12-01 02:31:52 --> Config Class Initialized
INFO - 2020-12-01 02:31:52 --> Loader Class Initialized
INFO - 2020-12-01 02:31:52 --> Helper loaded: url_helper
INFO - 2020-12-01 02:31:52 --> Helper loaded: file_helper
INFO - 2020-12-01 02:31:52 --> Helper loaded: form_helper
INFO - 2020-12-01 02:31:52 --> Helper loaded: my_helper
INFO - 2020-12-01 02:31:52 --> Database Driver Class Initialized
DEBUG - 2020-12-01 02:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-01 02:31:52 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-01 02:31:52 --> Controller Class Initialized
INFO - 2020-12-01 02:31:53 --> Helper loaded: cookie_helper
INFO - 2020-12-01 02:31:53 --> Final output sent to browser
DEBUG - 2020-12-01 02:31:53 --> Total execution time: 0.3899
INFO - 2020-12-01 02:31:53 --> Config Class Initialized
INFO - 2020-12-01 02:31:53 --> Hooks Class Initialized
DEBUG - 2020-12-01 02:31:53 --> UTF-8 Support Enabled
INFO - 2020-12-01 02:31:53 --> Utf8 Class Initialized
INFO - 2020-12-01 02:31:53 --> URI Class Initialized
INFO - 2020-12-01 02:31:53 --> Router Class Initialized
INFO - 2020-12-01 02:31:53 --> Output Class Initialized
INFO - 2020-12-01 02:31:53 --> Security Class Initialized
DEBUG - 2020-12-01 02:31:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-01 02:31:53 --> Input Class Initialized
INFO - 2020-12-01 02:31:53 --> Language Class Initialized
INFO - 2020-12-01 02:31:53 --> Language Class Initialized
INFO - 2020-12-01 02:31:53 --> Config Class Initialized
INFO - 2020-12-01 02:31:53 --> Loader Class Initialized
INFO - 2020-12-01 02:31:53 --> Helper loaded: url_helper
INFO - 2020-12-01 02:31:53 --> Helper loaded: file_helper
INFO - 2020-12-01 02:31:53 --> Helper loaded: form_helper
INFO - 2020-12-01 02:31:53 --> Helper loaded: my_helper
INFO - 2020-12-01 02:31:53 --> Database Driver Class Initialized
DEBUG - 2020-12-01 02:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-01 02:31:53 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-01 02:31:53 --> Controller Class Initialized
DEBUG - 2020-12-01 02:31:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2020-12-01 02:31:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-01 02:31:53 --> Final output sent to browser
DEBUG - 2020-12-01 02:31:53 --> Total execution time: 0.3830
INFO - 2020-12-01 02:31:54 --> Config Class Initialized
INFO - 2020-12-01 02:31:54 --> Hooks Class Initialized
DEBUG - 2020-12-01 02:31:54 --> UTF-8 Support Enabled
INFO - 2020-12-01 02:31:54 --> Utf8 Class Initialized
INFO - 2020-12-01 02:31:54 --> URI Class Initialized
INFO - 2020-12-01 02:31:54 --> Router Class Initialized
INFO - 2020-12-01 02:31:54 --> Output Class Initialized
INFO - 2020-12-01 02:31:54 --> Security Class Initialized
DEBUG - 2020-12-01 02:31:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2020-12-01 02:31:54 --> Input Class Initialized
INFO - 2020-12-01 02:31:54 --> Language Class Initialized
INFO - 2020-12-01 02:31:54 --> Language Class Initialized
INFO - 2020-12-01 02:31:54 --> Config Class Initialized
INFO - 2020-12-01 02:31:54 --> Loader Class Initialized
INFO - 2020-12-01 02:31:54 --> Helper loaded: url_helper
INFO - 2020-12-01 02:31:54 --> Helper loaded: file_helper
INFO - 2020-12-01 02:31:54 --> Helper loaded: form_helper
INFO - 2020-12-01 02:31:55 --> Helper loaded: my_helper
INFO - 2020-12-01 02:31:55 --> Database Driver Class Initialized
DEBUG - 2020-12-01 02:31:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2020-12-01 02:31:55 --> Session: Class initialized using 'files' driver.
INFO - 2020-12-01 02:31:55 --> Controller Class Initialized
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 50
ERROR - 2020-12-01 02:31:55 --> Severity: Notice --> Undefined variable: catatan C:\xampp\htdocs\nilai\application\modules\n_karakter\views\list.php 92
DEBUG - 2020-12-01 02:31:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_karakter/views/list.php
DEBUG - 2020-12-01 02:31:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2020-12-01 02:31:55 --> Final output sent to browser
DEBUG - 2020-12-01 02:31:55 --> Total execution time: 0.5741
