<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2022-12-16 02:21:50 --> Config Class Initialized
INFO - 2022-12-16 02:21:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 02:21:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 02:21:50 --> Utf8 Class Initialized
INFO - 2022-12-16 02:21:50 --> URI Class Initialized
DEBUG - 2022-12-16 02:21:51 --> No URI present. Default controller set.
INFO - 2022-12-16 02:21:51 --> Router Class Initialized
INFO - 2022-12-16 02:21:51 --> Output Class Initialized
INFO - 2022-12-16 02:21:51 --> Security Class Initialized
DEBUG - 2022-12-16 02:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 02:21:51 --> Input Class Initialized
INFO - 2022-12-16 02:21:51 --> Language Class Initialized
INFO - 2022-12-16 02:21:51 --> Language Class Initialized
INFO - 2022-12-16 02:21:51 --> Config Class Initialized
INFO - 2022-12-16 02:21:51 --> Loader Class Initialized
INFO - 2022-12-16 02:21:51 --> Helper loaded: url_helper
INFO - 2022-12-16 02:21:51 --> Helper loaded: file_helper
INFO - 2022-12-16 02:21:51 --> Helper loaded: form_helper
INFO - 2022-12-16 02:21:51 --> Helper loaded: my_helper
INFO - 2022-12-16 02:21:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 02:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 02:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 02:21:52 --> Controller Class Initialized
INFO - 2022-12-16 02:21:52 --> Config Class Initialized
INFO - 2022-12-16 02:21:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 02:21:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 02:21:52 --> Utf8 Class Initialized
INFO - 2022-12-16 02:21:52 --> URI Class Initialized
INFO - 2022-12-16 02:21:52 --> Router Class Initialized
INFO - 2022-12-16 02:21:52 --> Output Class Initialized
INFO - 2022-12-16 02:21:52 --> Security Class Initialized
DEBUG - 2022-12-16 02:21:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 02:21:52 --> Input Class Initialized
INFO - 2022-12-16 02:21:52 --> Language Class Initialized
INFO - 2022-12-16 02:21:52 --> Language Class Initialized
INFO - 2022-12-16 02:21:52 --> Config Class Initialized
INFO - 2022-12-16 02:21:52 --> Loader Class Initialized
INFO - 2022-12-16 02:21:52 --> Helper loaded: url_helper
INFO - 2022-12-16 02:21:52 --> Helper loaded: file_helper
INFO - 2022-12-16 02:21:52 --> Helper loaded: form_helper
INFO - 2022-12-16 02:21:52 --> Helper loaded: my_helper
INFO - 2022-12-16 02:21:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 02:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 02:21:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 02:21:52 --> Controller Class Initialized
DEBUG - 2022-12-16 02:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-16 02:21:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 02:21:52 --> Final output sent to browser
DEBUG - 2022-12-16 02:21:52 --> Total execution time: 0.3479
INFO - 2022-12-16 03:07:05 --> Config Class Initialized
INFO - 2022-12-16 03:07:05 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:07:05 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:07:05 --> Utf8 Class Initialized
INFO - 2022-12-16 03:07:05 --> URI Class Initialized
INFO - 2022-12-16 03:07:05 --> Router Class Initialized
INFO - 2022-12-16 03:07:05 --> Output Class Initialized
INFO - 2022-12-16 03:07:05 --> Security Class Initialized
DEBUG - 2022-12-16 03:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:07:05 --> Input Class Initialized
INFO - 2022-12-16 03:07:05 --> Language Class Initialized
INFO - 2022-12-16 03:07:05 --> Language Class Initialized
INFO - 2022-12-16 03:07:05 --> Config Class Initialized
INFO - 2022-12-16 03:07:05 --> Loader Class Initialized
INFO - 2022-12-16 03:07:05 --> Helper loaded: url_helper
INFO - 2022-12-16 03:07:05 --> Helper loaded: file_helper
INFO - 2022-12-16 03:07:05 --> Helper loaded: form_helper
INFO - 2022-12-16 03:07:05 --> Helper loaded: my_helper
INFO - 2022-12-16 03:07:05 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:07:05 --> Controller Class Initialized
INFO - 2022-12-16 03:07:05 --> Helper loaded: cookie_helper
INFO - 2022-12-16 03:07:05 --> Final output sent to browser
DEBUG - 2022-12-16 03:07:05 --> Total execution time: 0.1040
INFO - 2022-12-16 03:07:05 --> Config Class Initialized
INFO - 2022-12-16 03:07:05 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:07:05 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:07:05 --> Utf8 Class Initialized
INFO - 2022-12-16 03:07:05 --> URI Class Initialized
INFO - 2022-12-16 03:07:05 --> Router Class Initialized
INFO - 2022-12-16 03:07:05 --> Output Class Initialized
INFO - 2022-12-16 03:07:05 --> Security Class Initialized
DEBUG - 2022-12-16 03:07:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:07:05 --> Input Class Initialized
INFO - 2022-12-16 03:07:05 --> Language Class Initialized
INFO - 2022-12-16 03:07:05 --> Language Class Initialized
INFO - 2022-12-16 03:07:05 --> Config Class Initialized
INFO - 2022-12-16 03:07:05 --> Loader Class Initialized
INFO - 2022-12-16 03:07:05 --> Helper loaded: url_helper
INFO - 2022-12-16 03:07:05 --> Helper loaded: file_helper
INFO - 2022-12-16 03:07:05 --> Helper loaded: form_helper
INFO - 2022-12-16 03:07:05 --> Helper loaded: my_helper
INFO - 2022-12-16 03:07:05 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:07:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:07:05 --> Controller Class Initialized
DEBUG - 2022-12-16 03:07:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-12-16 03:07:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:07:05 --> Final output sent to browser
DEBUG - 2022-12-16 03:07:05 --> Total execution time: 0.1640
INFO - 2022-12-16 03:07:09 --> Config Class Initialized
INFO - 2022-12-16 03:07:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:07:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:07:09 --> Utf8 Class Initialized
INFO - 2022-12-16 03:07:09 --> URI Class Initialized
INFO - 2022-12-16 03:07:09 --> Router Class Initialized
INFO - 2022-12-16 03:07:09 --> Output Class Initialized
INFO - 2022-12-16 03:07:09 --> Security Class Initialized
DEBUG - 2022-12-16 03:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:07:09 --> Input Class Initialized
INFO - 2022-12-16 03:07:09 --> Language Class Initialized
INFO - 2022-12-16 03:07:09 --> Language Class Initialized
INFO - 2022-12-16 03:07:09 --> Config Class Initialized
INFO - 2022-12-16 03:07:09 --> Loader Class Initialized
INFO - 2022-12-16 03:07:09 --> Helper loaded: url_helper
INFO - 2022-12-16 03:07:09 --> Helper loaded: file_helper
INFO - 2022-12-16 03:07:09 --> Helper loaded: form_helper
INFO - 2022-12-16 03:07:09 --> Helper loaded: my_helper
INFO - 2022-12-16 03:07:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:07:09 --> Controller Class Initialized
INFO - 2022-12-16 03:07:09 --> Helper loaded: cookie_helper
INFO - 2022-12-16 03:07:09 --> Config Class Initialized
INFO - 2022-12-16 03:07:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:07:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:07:09 --> Utf8 Class Initialized
INFO - 2022-12-16 03:07:09 --> URI Class Initialized
INFO - 2022-12-16 03:07:09 --> Router Class Initialized
INFO - 2022-12-16 03:07:09 --> Output Class Initialized
INFO - 2022-12-16 03:07:09 --> Security Class Initialized
DEBUG - 2022-12-16 03:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:07:09 --> Input Class Initialized
INFO - 2022-12-16 03:07:09 --> Language Class Initialized
INFO - 2022-12-16 03:07:09 --> Language Class Initialized
INFO - 2022-12-16 03:07:09 --> Config Class Initialized
INFO - 2022-12-16 03:07:09 --> Loader Class Initialized
INFO - 2022-12-16 03:07:09 --> Helper loaded: url_helper
INFO - 2022-12-16 03:07:09 --> Helper loaded: file_helper
INFO - 2022-12-16 03:07:09 --> Helper loaded: form_helper
INFO - 2022-12-16 03:07:09 --> Helper loaded: my_helper
INFO - 2022-12-16 03:07:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:07:09 --> Controller Class Initialized
DEBUG - 2022-12-16 03:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-16 03:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:07:09 --> Final output sent to browser
DEBUG - 2022-12-16 03:07:09 --> Total execution time: 0.0692
INFO - 2022-12-16 03:57:29 --> Config Class Initialized
INFO - 2022-12-16 03:57:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:57:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:57:29 --> Utf8 Class Initialized
INFO - 2022-12-16 03:57:29 --> URI Class Initialized
INFO - 2022-12-16 03:57:29 --> Router Class Initialized
INFO - 2022-12-16 03:57:29 --> Output Class Initialized
INFO - 2022-12-16 03:57:29 --> Security Class Initialized
DEBUG - 2022-12-16 03:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:57:29 --> Input Class Initialized
INFO - 2022-12-16 03:57:29 --> Language Class Initialized
INFO - 2022-12-16 03:57:29 --> Language Class Initialized
INFO - 2022-12-16 03:57:29 --> Config Class Initialized
INFO - 2022-12-16 03:57:29 --> Loader Class Initialized
INFO - 2022-12-16 03:57:29 --> Helper loaded: url_helper
INFO - 2022-12-16 03:57:29 --> Helper loaded: file_helper
INFO - 2022-12-16 03:57:29 --> Helper loaded: form_helper
INFO - 2022-12-16 03:57:29 --> Helper loaded: my_helper
INFO - 2022-12-16 03:57:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:57:29 --> Controller Class Initialized
DEBUG - 2022-12-16 03:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-16 03:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:57:29 --> Final output sent to browser
DEBUG - 2022-12-16 03:57:29 --> Total execution time: 0.0727
INFO - 2022-12-16 03:57:33 --> Config Class Initialized
INFO - 2022-12-16 03:57:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:57:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:57:33 --> Utf8 Class Initialized
INFO - 2022-12-16 03:57:33 --> URI Class Initialized
INFO - 2022-12-16 03:57:33 --> Router Class Initialized
INFO - 2022-12-16 03:57:33 --> Output Class Initialized
INFO - 2022-12-16 03:57:33 --> Security Class Initialized
DEBUG - 2022-12-16 03:57:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:57:33 --> Input Class Initialized
INFO - 2022-12-16 03:57:33 --> Language Class Initialized
INFO - 2022-12-16 03:57:33 --> Language Class Initialized
INFO - 2022-12-16 03:57:33 --> Config Class Initialized
INFO - 2022-12-16 03:57:33 --> Loader Class Initialized
INFO - 2022-12-16 03:57:33 --> Helper loaded: url_helper
INFO - 2022-12-16 03:57:33 --> Helper loaded: file_helper
INFO - 2022-12-16 03:57:33 --> Helper loaded: form_helper
INFO - 2022-12-16 03:57:33 --> Helper loaded: my_helper
INFO - 2022-12-16 03:57:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:57:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:57:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:57:33 --> Controller Class Initialized
INFO - 2022-12-16 03:57:33 --> Helper loaded: cookie_helper
INFO - 2022-12-16 03:57:33 --> Final output sent to browser
DEBUG - 2022-12-16 03:57:33 --> Total execution time: 0.0761
INFO - 2022-12-16 03:57:33 --> Config Class Initialized
INFO - 2022-12-16 03:57:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:57:34 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:57:34 --> Utf8 Class Initialized
INFO - 2022-12-16 03:57:34 --> URI Class Initialized
INFO - 2022-12-16 03:57:34 --> Router Class Initialized
INFO - 2022-12-16 03:57:34 --> Output Class Initialized
INFO - 2022-12-16 03:57:34 --> Security Class Initialized
DEBUG - 2022-12-16 03:57:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:57:34 --> Input Class Initialized
INFO - 2022-12-16 03:57:34 --> Language Class Initialized
INFO - 2022-12-16 03:57:34 --> Language Class Initialized
INFO - 2022-12-16 03:57:34 --> Config Class Initialized
INFO - 2022-12-16 03:57:34 --> Loader Class Initialized
INFO - 2022-12-16 03:57:34 --> Helper loaded: url_helper
INFO - 2022-12-16 03:57:34 --> Helper loaded: file_helper
INFO - 2022-12-16 03:57:34 --> Helper loaded: form_helper
INFO - 2022-12-16 03:57:34 --> Helper loaded: my_helper
INFO - 2022-12-16 03:57:34 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:57:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:57:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:57:34 --> Controller Class Initialized
DEBUG - 2022-12-16 03:57:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-12-16 03:57:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:57:34 --> Final output sent to browser
DEBUG - 2022-12-16 03:57:34 --> Total execution time: 0.0577
INFO - 2022-12-16 03:57:35 --> Config Class Initialized
INFO - 2022-12-16 03:57:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:57:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:57:35 --> Utf8 Class Initialized
INFO - 2022-12-16 03:57:35 --> URI Class Initialized
INFO - 2022-12-16 03:57:35 --> Router Class Initialized
INFO - 2022-12-16 03:57:35 --> Output Class Initialized
INFO - 2022-12-16 03:57:35 --> Security Class Initialized
DEBUG - 2022-12-16 03:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:57:35 --> Input Class Initialized
INFO - 2022-12-16 03:57:35 --> Language Class Initialized
INFO - 2022-12-16 03:57:35 --> Language Class Initialized
INFO - 2022-12-16 03:57:35 --> Config Class Initialized
INFO - 2022-12-16 03:57:35 --> Loader Class Initialized
INFO - 2022-12-16 03:57:35 --> Helper loaded: url_helper
INFO - 2022-12-16 03:57:35 --> Helper loaded: file_helper
INFO - 2022-12-16 03:57:35 --> Helper loaded: form_helper
INFO - 2022-12-16 03:57:35 --> Helper loaded: my_helper
INFO - 2022-12-16 03:57:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:57:35 --> Controller Class Initialized
DEBUG - 2022-12-16 03:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 03:57:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:57:35 --> Final output sent to browser
DEBUG - 2022-12-16 03:57:35 --> Total execution time: 0.0847
INFO - 2022-12-16 03:57:35 --> Config Class Initialized
INFO - 2022-12-16 03:57:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:57:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:57:35 --> Utf8 Class Initialized
INFO - 2022-12-16 03:57:35 --> URI Class Initialized
INFO - 2022-12-16 03:57:35 --> Router Class Initialized
INFO - 2022-12-16 03:57:35 --> Output Class Initialized
INFO - 2022-12-16 03:57:35 --> Security Class Initialized
DEBUG - 2022-12-16 03:57:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:57:35 --> Input Class Initialized
INFO - 2022-12-16 03:57:35 --> Language Class Initialized
INFO - 2022-12-16 03:57:35 --> Language Class Initialized
INFO - 2022-12-16 03:57:35 --> Config Class Initialized
INFO - 2022-12-16 03:57:35 --> Loader Class Initialized
INFO - 2022-12-16 03:57:35 --> Helper loaded: url_helper
INFO - 2022-12-16 03:57:35 --> Helper loaded: file_helper
INFO - 2022-12-16 03:57:35 --> Helper loaded: form_helper
INFO - 2022-12-16 03:57:35 --> Helper loaded: my_helper
INFO - 2022-12-16 03:57:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:57:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:57:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:57:35 --> Controller Class Initialized
INFO - 2022-12-16 03:57:37 --> Config Class Initialized
INFO - 2022-12-16 03:57:37 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:57:37 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:57:37 --> Utf8 Class Initialized
INFO - 2022-12-16 03:57:37 --> URI Class Initialized
INFO - 2022-12-16 03:57:37 --> Router Class Initialized
INFO - 2022-12-16 03:57:37 --> Output Class Initialized
INFO - 2022-12-16 03:57:37 --> Security Class Initialized
DEBUG - 2022-12-16 03:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:57:37 --> Input Class Initialized
INFO - 2022-12-16 03:57:37 --> Language Class Initialized
INFO - 2022-12-16 03:57:37 --> Language Class Initialized
INFO - 2022-12-16 03:57:37 --> Config Class Initialized
INFO - 2022-12-16 03:57:37 --> Loader Class Initialized
INFO - 2022-12-16 03:57:37 --> Helper loaded: url_helper
INFO - 2022-12-16 03:57:37 --> Helper loaded: file_helper
INFO - 2022-12-16 03:57:37 --> Helper loaded: form_helper
INFO - 2022-12-16 03:57:37 --> Helper loaded: my_helper
INFO - 2022-12-16 03:57:37 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:57:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:57:37 --> Controller Class Initialized
DEBUG - 2022-12-16 03:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 03:57:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:57:37 --> Final output sent to browser
DEBUG - 2022-12-16 03:57:37 --> Total execution time: 0.0725
INFO - 2022-12-16 03:58:04 --> Config Class Initialized
INFO - 2022-12-16 03:58:04 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:04 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:04 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:04 --> URI Class Initialized
INFO - 2022-12-16 03:58:04 --> Router Class Initialized
INFO - 2022-12-16 03:58:04 --> Output Class Initialized
INFO - 2022-12-16 03:58:04 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:04 --> Input Class Initialized
INFO - 2022-12-16 03:58:04 --> Language Class Initialized
INFO - 2022-12-16 03:58:04 --> Language Class Initialized
INFO - 2022-12-16 03:58:04 --> Config Class Initialized
INFO - 2022-12-16 03:58:04 --> Loader Class Initialized
INFO - 2022-12-16 03:58:04 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:04 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:04 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:04 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:04 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:04 --> Controller Class Initialized
INFO - 2022-12-16 03:58:07 --> Config Class Initialized
INFO - 2022-12-16 03:58:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:07 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:07 --> URI Class Initialized
INFO - 2022-12-16 03:58:07 --> Router Class Initialized
INFO - 2022-12-16 03:58:07 --> Output Class Initialized
INFO - 2022-12-16 03:58:07 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:07 --> Input Class Initialized
INFO - 2022-12-16 03:58:07 --> Language Class Initialized
INFO - 2022-12-16 03:58:07 --> Language Class Initialized
INFO - 2022-12-16 03:58:07 --> Config Class Initialized
INFO - 2022-12-16 03:58:07 --> Loader Class Initialized
INFO - 2022-12-16 03:58:07 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:07 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:07 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:07 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:07 --> Controller Class Initialized
DEBUG - 2022-12-16 03:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 03:58:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:58:07 --> Final output sent to browser
DEBUG - 2022-12-16 03:58:07 --> Total execution time: 0.0648
INFO - 2022-12-16 03:58:10 --> Config Class Initialized
INFO - 2022-12-16 03:58:10 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:10 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:10 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:10 --> URI Class Initialized
INFO - 2022-12-16 03:58:10 --> Router Class Initialized
INFO - 2022-12-16 03:58:10 --> Output Class Initialized
INFO - 2022-12-16 03:58:10 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:10 --> Input Class Initialized
INFO - 2022-12-16 03:58:10 --> Language Class Initialized
INFO - 2022-12-16 03:58:10 --> Language Class Initialized
INFO - 2022-12-16 03:58:10 --> Config Class Initialized
INFO - 2022-12-16 03:58:10 --> Loader Class Initialized
INFO - 2022-12-16 03:58:10 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:10 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:10 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:10 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:10 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:10 --> Controller Class Initialized
DEBUG - 2022-12-16 03:58:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 03:58:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 03:58:10 --> Final output sent to browser
DEBUG - 2022-12-16 03:58:10 --> Total execution time: 0.0617
INFO - 2022-12-16 03:58:10 --> Config Class Initialized
INFO - 2022-12-16 03:58:10 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:10 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:10 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:10 --> URI Class Initialized
INFO - 2022-12-16 03:58:10 --> Router Class Initialized
INFO - 2022-12-16 03:58:10 --> Output Class Initialized
INFO - 2022-12-16 03:58:10 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:10 --> Input Class Initialized
INFO - 2022-12-16 03:58:10 --> Language Class Initialized
INFO - 2022-12-16 03:58:10 --> Language Class Initialized
INFO - 2022-12-16 03:58:10 --> Config Class Initialized
INFO - 2022-12-16 03:58:10 --> Loader Class Initialized
INFO - 2022-12-16 03:58:10 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:10 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:10 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:10 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:10 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:10 --> Controller Class Initialized
INFO - 2022-12-16 03:58:14 --> Config Class Initialized
INFO - 2022-12-16 03:58:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:14 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:14 --> URI Class Initialized
INFO - 2022-12-16 03:58:14 --> Router Class Initialized
INFO - 2022-12-16 03:58:14 --> Output Class Initialized
INFO - 2022-12-16 03:58:14 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:14 --> Input Class Initialized
INFO - 2022-12-16 03:58:14 --> Language Class Initialized
INFO - 2022-12-16 03:58:14 --> Language Class Initialized
INFO - 2022-12-16 03:58:14 --> Config Class Initialized
INFO - 2022-12-16 03:58:14 --> Loader Class Initialized
INFO - 2022-12-16 03:58:14 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:14 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:14 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:14 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:14 --> Controller Class Initialized
INFO - 2022-12-16 03:58:16 --> Config Class Initialized
INFO - 2022-12-16 03:58:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:16 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:16 --> URI Class Initialized
INFO - 2022-12-16 03:58:16 --> Router Class Initialized
INFO - 2022-12-16 03:58:16 --> Output Class Initialized
INFO - 2022-12-16 03:58:16 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:16 --> Input Class Initialized
INFO - 2022-12-16 03:58:16 --> Language Class Initialized
INFO - 2022-12-16 03:58:16 --> Language Class Initialized
INFO - 2022-12-16 03:58:16 --> Config Class Initialized
INFO - 2022-12-16 03:58:16 --> Loader Class Initialized
INFO - 2022-12-16 03:58:16 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:16 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:16 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:16 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:16 --> Controller Class Initialized
INFO - 2022-12-16 03:58:17 --> Config Class Initialized
INFO - 2022-12-16 03:58:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:17 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:17 --> URI Class Initialized
INFO - 2022-12-16 03:58:17 --> Router Class Initialized
INFO - 2022-12-16 03:58:17 --> Output Class Initialized
INFO - 2022-12-16 03:58:17 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:17 --> Input Class Initialized
INFO - 2022-12-16 03:58:17 --> Language Class Initialized
INFO - 2022-12-16 03:58:17 --> Language Class Initialized
INFO - 2022-12-16 03:58:17 --> Config Class Initialized
INFO - 2022-12-16 03:58:17 --> Loader Class Initialized
INFO - 2022-12-16 03:58:17 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:17 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:17 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:17 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:17 --> Controller Class Initialized
INFO - 2022-12-16 03:58:25 --> Config Class Initialized
INFO - 2022-12-16 03:58:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:25 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:25 --> URI Class Initialized
INFO - 2022-12-16 03:58:25 --> Router Class Initialized
INFO - 2022-12-16 03:58:25 --> Output Class Initialized
INFO - 2022-12-16 03:58:25 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:25 --> Input Class Initialized
INFO - 2022-12-16 03:58:25 --> Language Class Initialized
INFO - 2022-12-16 03:58:25 --> Language Class Initialized
INFO - 2022-12-16 03:58:25 --> Config Class Initialized
INFO - 2022-12-16 03:58:25 --> Loader Class Initialized
INFO - 2022-12-16 03:58:25 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:25 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:25 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:25 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:25 --> Controller Class Initialized
INFO - 2022-12-16 03:58:58 --> Config Class Initialized
INFO - 2022-12-16 03:58:58 --> Hooks Class Initialized
DEBUG - 2022-12-16 03:58:58 --> UTF-8 Support Enabled
INFO - 2022-12-16 03:58:58 --> Utf8 Class Initialized
INFO - 2022-12-16 03:58:58 --> URI Class Initialized
INFO - 2022-12-16 03:58:58 --> Router Class Initialized
INFO - 2022-12-16 03:58:58 --> Output Class Initialized
INFO - 2022-12-16 03:58:58 --> Security Class Initialized
DEBUG - 2022-12-16 03:58:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 03:58:58 --> Input Class Initialized
INFO - 2022-12-16 03:58:58 --> Language Class Initialized
INFO - 2022-12-16 03:58:58 --> Language Class Initialized
INFO - 2022-12-16 03:58:58 --> Config Class Initialized
INFO - 2022-12-16 03:58:58 --> Loader Class Initialized
INFO - 2022-12-16 03:58:58 --> Helper loaded: url_helper
INFO - 2022-12-16 03:58:58 --> Helper loaded: file_helper
INFO - 2022-12-16 03:58:58 --> Helper loaded: form_helper
INFO - 2022-12-16 03:58:58 --> Helper loaded: my_helper
INFO - 2022-12-16 03:58:58 --> Database Driver Class Initialized
DEBUG - 2022-12-16 03:58:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 03:58:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 03:58:58 --> Controller Class Initialized
INFO - 2022-12-16 04:36:25 --> Config Class Initialized
INFO - 2022-12-16 04:36:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:36:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:36:25 --> Utf8 Class Initialized
INFO - 2022-12-16 04:36:25 --> URI Class Initialized
INFO - 2022-12-16 04:36:25 --> Router Class Initialized
INFO - 2022-12-16 04:36:25 --> Output Class Initialized
INFO - 2022-12-16 04:36:25 --> Security Class Initialized
DEBUG - 2022-12-16 04:36:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:36:25 --> Input Class Initialized
INFO - 2022-12-16 04:36:25 --> Language Class Initialized
INFO - 2022-12-16 04:36:25 --> Language Class Initialized
INFO - 2022-12-16 04:36:25 --> Config Class Initialized
INFO - 2022-12-16 04:36:25 --> Loader Class Initialized
INFO - 2022-12-16 04:36:25 --> Helper loaded: url_helper
INFO - 2022-12-16 04:36:25 --> Helper loaded: file_helper
INFO - 2022-12-16 04:36:25 --> Helper loaded: form_helper
INFO - 2022-12-16 04:36:25 --> Helper loaded: my_helper
INFO - 2022-12-16 04:36:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:36:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:36:25 --> Controller Class Initialized
DEBUG - 2022-12-16 04:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:36:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:36:25 --> Final output sent to browser
DEBUG - 2022-12-16 04:36:25 --> Total execution time: 0.1195
INFO - 2022-12-16 04:36:29 --> Config Class Initialized
INFO - 2022-12-16 04:36:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:36:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:36:29 --> Utf8 Class Initialized
INFO - 2022-12-16 04:36:29 --> URI Class Initialized
INFO - 2022-12-16 04:36:29 --> Router Class Initialized
INFO - 2022-12-16 04:36:29 --> Output Class Initialized
INFO - 2022-12-16 04:36:29 --> Security Class Initialized
DEBUG - 2022-12-16 04:36:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:36:29 --> Input Class Initialized
INFO - 2022-12-16 04:36:29 --> Language Class Initialized
INFO - 2022-12-16 04:36:29 --> Language Class Initialized
INFO - 2022-12-16 04:36:29 --> Config Class Initialized
INFO - 2022-12-16 04:36:29 --> Loader Class Initialized
INFO - 2022-12-16 04:36:29 --> Helper loaded: url_helper
INFO - 2022-12-16 04:36:29 --> Helper loaded: file_helper
INFO - 2022-12-16 04:36:29 --> Helper loaded: form_helper
INFO - 2022-12-16 04:36:29 --> Helper loaded: my_helper
INFO - 2022-12-16 04:36:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:36:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:36:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:36:29 --> Controller Class Initialized
DEBUG - 2022-12-16 04:36:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:36:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:36:29 --> Final output sent to browser
DEBUG - 2022-12-16 04:36:29 --> Total execution time: 0.1094
INFO - 2022-12-16 04:38:14 --> Config Class Initialized
INFO - 2022-12-16 04:38:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:38:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:38:14 --> Utf8 Class Initialized
INFO - 2022-12-16 04:38:14 --> URI Class Initialized
INFO - 2022-12-16 04:38:14 --> Router Class Initialized
INFO - 2022-12-16 04:38:14 --> Output Class Initialized
INFO - 2022-12-16 04:38:14 --> Security Class Initialized
DEBUG - 2022-12-16 04:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:38:14 --> Input Class Initialized
INFO - 2022-12-16 04:38:14 --> Language Class Initialized
INFO - 2022-12-16 04:38:14 --> Language Class Initialized
INFO - 2022-12-16 04:38:14 --> Config Class Initialized
INFO - 2022-12-16 04:38:14 --> Loader Class Initialized
INFO - 2022-12-16 04:38:14 --> Helper loaded: url_helper
INFO - 2022-12-16 04:38:14 --> Helper loaded: file_helper
INFO - 2022-12-16 04:38:14 --> Helper loaded: form_helper
INFO - 2022-12-16 04:38:14 --> Helper loaded: my_helper
INFO - 2022-12-16 04:38:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:38:14 --> Controller Class Initialized
INFO - 2022-12-16 04:38:14 --> Config Class Initialized
INFO - 2022-12-16 04:38:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:38:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:38:14 --> Utf8 Class Initialized
INFO - 2022-12-16 04:38:14 --> URI Class Initialized
INFO - 2022-12-16 04:38:14 --> Router Class Initialized
INFO - 2022-12-16 04:38:14 --> Output Class Initialized
INFO - 2022-12-16 04:38:14 --> Security Class Initialized
DEBUG - 2022-12-16 04:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:38:14 --> Input Class Initialized
INFO - 2022-12-16 04:38:14 --> Language Class Initialized
INFO - 2022-12-16 04:38:14 --> Language Class Initialized
INFO - 2022-12-16 04:38:14 --> Config Class Initialized
INFO - 2022-12-16 04:38:14 --> Loader Class Initialized
INFO - 2022-12-16 04:38:14 --> Helper loaded: url_helper
INFO - 2022-12-16 04:38:14 --> Helper loaded: file_helper
INFO - 2022-12-16 04:38:14 --> Helper loaded: form_helper
INFO - 2022-12-16 04:38:14 --> Helper loaded: my_helper
INFO - 2022-12-16 04:38:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:38:14 --> Controller Class Initialized
DEBUG - 2022-12-16 04:38:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:38:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:38:14 --> Final output sent to browser
DEBUG - 2022-12-16 04:38:14 --> Total execution time: 0.0675
INFO - 2022-12-16 04:38:17 --> Config Class Initialized
INFO - 2022-12-16 04:38:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:38:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:38:17 --> Utf8 Class Initialized
INFO - 2022-12-16 04:38:17 --> URI Class Initialized
INFO - 2022-12-16 04:38:17 --> Router Class Initialized
INFO - 2022-12-16 04:38:17 --> Output Class Initialized
INFO - 2022-12-16 04:38:17 --> Security Class Initialized
DEBUG - 2022-12-16 04:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:38:17 --> Input Class Initialized
INFO - 2022-12-16 04:38:17 --> Language Class Initialized
INFO - 2022-12-16 04:38:17 --> Language Class Initialized
INFO - 2022-12-16 04:38:17 --> Config Class Initialized
INFO - 2022-12-16 04:38:17 --> Loader Class Initialized
INFO - 2022-12-16 04:38:17 --> Helper loaded: url_helper
INFO - 2022-12-16 04:38:17 --> Helper loaded: file_helper
INFO - 2022-12-16 04:38:17 --> Helper loaded: form_helper
INFO - 2022-12-16 04:38:17 --> Helper loaded: my_helper
INFO - 2022-12-16 04:38:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:38:17 --> Controller Class Initialized
DEBUG - 2022-12-16 04:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:38:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:38:17 --> Final output sent to browser
DEBUG - 2022-12-16 04:38:17 --> Total execution time: 0.0693
INFO - 2022-12-16 04:38:46 --> Config Class Initialized
INFO - 2022-12-16 04:38:46 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:38:46 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:38:46 --> Utf8 Class Initialized
INFO - 2022-12-16 04:38:46 --> URI Class Initialized
INFO - 2022-12-16 04:38:46 --> Router Class Initialized
INFO - 2022-12-16 04:38:46 --> Output Class Initialized
INFO - 2022-12-16 04:38:46 --> Security Class Initialized
DEBUG - 2022-12-16 04:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:38:46 --> Input Class Initialized
INFO - 2022-12-16 04:38:46 --> Language Class Initialized
INFO - 2022-12-16 04:38:46 --> Language Class Initialized
INFO - 2022-12-16 04:38:46 --> Config Class Initialized
INFO - 2022-12-16 04:38:46 --> Loader Class Initialized
INFO - 2022-12-16 04:38:46 --> Helper loaded: url_helper
INFO - 2022-12-16 04:38:46 --> Helper loaded: file_helper
INFO - 2022-12-16 04:38:46 --> Helper loaded: form_helper
INFO - 2022-12-16 04:38:46 --> Helper loaded: my_helper
INFO - 2022-12-16 04:38:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:38:46 --> Controller Class Initialized
INFO - 2022-12-16 04:38:46 --> Config Class Initialized
INFO - 2022-12-16 04:38:46 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:38:46 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:38:46 --> Utf8 Class Initialized
INFO - 2022-12-16 04:38:46 --> URI Class Initialized
INFO - 2022-12-16 04:38:46 --> Router Class Initialized
INFO - 2022-12-16 04:38:46 --> Output Class Initialized
INFO - 2022-12-16 04:38:46 --> Security Class Initialized
DEBUG - 2022-12-16 04:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:38:46 --> Input Class Initialized
INFO - 2022-12-16 04:38:46 --> Language Class Initialized
INFO - 2022-12-16 04:38:46 --> Language Class Initialized
INFO - 2022-12-16 04:38:46 --> Config Class Initialized
INFO - 2022-12-16 04:38:46 --> Loader Class Initialized
INFO - 2022-12-16 04:38:46 --> Helper loaded: url_helper
INFO - 2022-12-16 04:38:46 --> Helper loaded: file_helper
INFO - 2022-12-16 04:38:46 --> Helper loaded: form_helper
INFO - 2022-12-16 04:38:46 --> Helper loaded: my_helper
INFO - 2022-12-16 04:38:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:38:46 --> Controller Class Initialized
DEBUG - 2022-12-16 04:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:38:46 --> Final output sent to browser
DEBUG - 2022-12-16 04:38:46 --> Total execution time: 0.0755
INFO - 2022-12-16 04:38:52 --> Config Class Initialized
INFO - 2022-12-16 04:38:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:38:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:38:52 --> Utf8 Class Initialized
INFO - 2022-12-16 04:38:52 --> URI Class Initialized
INFO - 2022-12-16 04:38:52 --> Router Class Initialized
INFO - 2022-12-16 04:38:52 --> Output Class Initialized
INFO - 2022-12-16 04:38:52 --> Security Class Initialized
DEBUG - 2022-12-16 04:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:38:52 --> Input Class Initialized
INFO - 2022-12-16 04:38:52 --> Language Class Initialized
INFO - 2022-12-16 04:38:52 --> Language Class Initialized
INFO - 2022-12-16 04:38:52 --> Config Class Initialized
INFO - 2022-12-16 04:38:52 --> Loader Class Initialized
INFO - 2022-12-16 04:38:52 --> Helper loaded: url_helper
INFO - 2022-12-16 04:38:52 --> Helper loaded: file_helper
INFO - 2022-12-16 04:38:52 --> Helper loaded: form_helper
INFO - 2022-12-16 04:38:52 --> Helper loaded: my_helper
INFO - 2022-12-16 04:38:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:38:52 --> Controller Class Initialized
DEBUG - 2022-12-16 04:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:38:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:38:52 --> Final output sent to browser
DEBUG - 2022-12-16 04:38:52 --> Total execution time: 0.0867
INFO - 2022-12-16 04:40:06 --> Config Class Initialized
INFO - 2022-12-16 04:40:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:40:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:40:06 --> Utf8 Class Initialized
INFO - 2022-12-16 04:40:06 --> URI Class Initialized
INFO - 2022-12-16 04:40:06 --> Router Class Initialized
INFO - 2022-12-16 04:40:06 --> Output Class Initialized
INFO - 2022-12-16 04:40:06 --> Security Class Initialized
DEBUG - 2022-12-16 04:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:40:06 --> Input Class Initialized
INFO - 2022-12-16 04:40:06 --> Language Class Initialized
INFO - 2022-12-16 04:40:06 --> Language Class Initialized
INFO - 2022-12-16 04:40:06 --> Config Class Initialized
INFO - 2022-12-16 04:40:06 --> Loader Class Initialized
INFO - 2022-12-16 04:40:06 --> Helper loaded: url_helper
INFO - 2022-12-16 04:40:06 --> Helper loaded: file_helper
INFO - 2022-12-16 04:40:06 --> Helper loaded: form_helper
INFO - 2022-12-16 04:40:06 --> Helper loaded: my_helper
INFO - 2022-12-16 04:40:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:40:06 --> Controller Class Initialized
INFO - 2022-12-16 04:40:06 --> Config Class Initialized
INFO - 2022-12-16 04:40:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:40:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:40:06 --> Utf8 Class Initialized
INFO - 2022-12-16 04:40:06 --> URI Class Initialized
INFO - 2022-12-16 04:40:06 --> Router Class Initialized
INFO - 2022-12-16 04:40:06 --> Output Class Initialized
INFO - 2022-12-16 04:40:06 --> Security Class Initialized
DEBUG - 2022-12-16 04:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:40:06 --> Input Class Initialized
INFO - 2022-12-16 04:40:06 --> Language Class Initialized
INFO - 2022-12-16 04:40:06 --> Language Class Initialized
INFO - 2022-12-16 04:40:06 --> Config Class Initialized
INFO - 2022-12-16 04:40:06 --> Loader Class Initialized
INFO - 2022-12-16 04:40:06 --> Helper loaded: url_helper
INFO - 2022-12-16 04:40:06 --> Helper loaded: file_helper
INFO - 2022-12-16 04:40:06 --> Helper loaded: form_helper
INFO - 2022-12-16 04:40:06 --> Helper loaded: my_helper
INFO - 2022-12-16 04:40:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:40:06 --> Controller Class Initialized
DEBUG - 2022-12-16 04:40:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:40:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:40:06 --> Final output sent to browser
DEBUG - 2022-12-16 04:40:06 --> Total execution time: 0.0817
INFO - 2022-12-16 04:40:08 --> Config Class Initialized
INFO - 2022-12-16 04:40:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:40:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:40:08 --> Utf8 Class Initialized
INFO - 2022-12-16 04:40:08 --> URI Class Initialized
INFO - 2022-12-16 04:40:08 --> Router Class Initialized
INFO - 2022-12-16 04:40:08 --> Output Class Initialized
INFO - 2022-12-16 04:40:08 --> Security Class Initialized
DEBUG - 2022-12-16 04:40:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:40:08 --> Input Class Initialized
INFO - 2022-12-16 04:40:08 --> Language Class Initialized
INFO - 2022-12-16 04:40:08 --> Language Class Initialized
INFO - 2022-12-16 04:40:08 --> Config Class Initialized
INFO - 2022-12-16 04:40:08 --> Loader Class Initialized
INFO - 2022-12-16 04:40:08 --> Helper loaded: url_helper
INFO - 2022-12-16 04:40:08 --> Helper loaded: file_helper
INFO - 2022-12-16 04:40:08 --> Helper loaded: form_helper
INFO - 2022-12-16 04:40:08 --> Helper loaded: my_helper
INFO - 2022-12-16 04:40:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:40:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:40:08 --> Controller Class Initialized
DEBUG - 2022-12-16 04:40:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:40:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:40:08 --> Final output sent to browser
DEBUG - 2022-12-16 04:40:08 --> Total execution time: 0.0848
INFO - 2022-12-16 04:41:11 --> Config Class Initialized
INFO - 2022-12-16 04:41:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:41:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:41:11 --> Utf8 Class Initialized
INFO - 2022-12-16 04:41:11 --> URI Class Initialized
INFO - 2022-12-16 04:41:11 --> Router Class Initialized
INFO - 2022-12-16 04:41:11 --> Output Class Initialized
INFO - 2022-12-16 04:41:11 --> Security Class Initialized
DEBUG - 2022-12-16 04:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:41:11 --> Input Class Initialized
INFO - 2022-12-16 04:41:11 --> Language Class Initialized
INFO - 2022-12-16 04:41:11 --> Language Class Initialized
INFO - 2022-12-16 04:41:11 --> Config Class Initialized
INFO - 2022-12-16 04:41:11 --> Loader Class Initialized
INFO - 2022-12-16 04:41:11 --> Helper loaded: url_helper
INFO - 2022-12-16 04:41:11 --> Helper loaded: file_helper
INFO - 2022-12-16 04:41:11 --> Helper loaded: form_helper
INFO - 2022-12-16 04:41:11 --> Helper loaded: my_helper
INFO - 2022-12-16 04:41:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:41:12 --> Controller Class Initialized
INFO - 2022-12-16 04:41:12 --> Config Class Initialized
INFO - 2022-12-16 04:41:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:41:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:41:12 --> Utf8 Class Initialized
INFO - 2022-12-16 04:41:12 --> URI Class Initialized
INFO - 2022-12-16 04:41:12 --> Router Class Initialized
INFO - 2022-12-16 04:41:12 --> Output Class Initialized
INFO - 2022-12-16 04:41:12 --> Security Class Initialized
DEBUG - 2022-12-16 04:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:41:12 --> Input Class Initialized
INFO - 2022-12-16 04:41:12 --> Language Class Initialized
INFO - 2022-12-16 04:41:12 --> Language Class Initialized
INFO - 2022-12-16 04:41:12 --> Config Class Initialized
INFO - 2022-12-16 04:41:12 --> Loader Class Initialized
INFO - 2022-12-16 04:41:12 --> Helper loaded: url_helper
INFO - 2022-12-16 04:41:12 --> Helper loaded: file_helper
INFO - 2022-12-16 04:41:12 --> Helper loaded: form_helper
INFO - 2022-12-16 04:41:12 --> Helper loaded: my_helper
INFO - 2022-12-16 04:41:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:41:12 --> Controller Class Initialized
DEBUG - 2022-12-16 04:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:41:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:41:12 --> Final output sent to browser
DEBUG - 2022-12-16 04:41:12 --> Total execution time: 0.0872
INFO - 2022-12-16 04:41:13 --> Config Class Initialized
INFO - 2022-12-16 04:41:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:41:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:41:13 --> Utf8 Class Initialized
INFO - 2022-12-16 04:41:13 --> URI Class Initialized
INFO - 2022-12-16 04:41:13 --> Router Class Initialized
INFO - 2022-12-16 04:41:13 --> Output Class Initialized
INFO - 2022-12-16 04:41:13 --> Security Class Initialized
DEBUG - 2022-12-16 04:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:41:13 --> Input Class Initialized
INFO - 2022-12-16 04:41:13 --> Language Class Initialized
INFO - 2022-12-16 04:41:13 --> Language Class Initialized
INFO - 2022-12-16 04:41:13 --> Config Class Initialized
INFO - 2022-12-16 04:41:13 --> Loader Class Initialized
INFO - 2022-12-16 04:41:13 --> Helper loaded: url_helper
INFO - 2022-12-16 04:41:13 --> Helper loaded: file_helper
INFO - 2022-12-16 04:41:13 --> Helper loaded: form_helper
INFO - 2022-12-16 04:41:13 --> Helper loaded: my_helper
INFO - 2022-12-16 04:41:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:41:13 --> Controller Class Initialized
DEBUG - 2022-12-16 04:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:41:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:41:13 --> Final output sent to browser
DEBUG - 2022-12-16 04:41:13 --> Total execution time: 0.0803
INFO - 2022-12-16 04:41:33 --> Config Class Initialized
INFO - 2022-12-16 04:41:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:41:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:41:33 --> Utf8 Class Initialized
INFO - 2022-12-16 04:41:33 --> URI Class Initialized
INFO - 2022-12-16 04:41:33 --> Router Class Initialized
INFO - 2022-12-16 04:41:33 --> Output Class Initialized
INFO - 2022-12-16 04:41:33 --> Security Class Initialized
DEBUG - 2022-12-16 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:41:33 --> Input Class Initialized
INFO - 2022-12-16 04:41:33 --> Language Class Initialized
INFO - 2022-12-16 04:41:33 --> Language Class Initialized
INFO - 2022-12-16 04:41:33 --> Config Class Initialized
INFO - 2022-12-16 04:41:33 --> Loader Class Initialized
INFO - 2022-12-16 04:41:33 --> Helper loaded: url_helper
INFO - 2022-12-16 04:41:33 --> Helper loaded: file_helper
INFO - 2022-12-16 04:41:33 --> Helper loaded: form_helper
INFO - 2022-12-16 04:41:33 --> Helper loaded: my_helper
INFO - 2022-12-16 04:41:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:41:33 --> Controller Class Initialized
INFO - 2022-12-16 04:41:33 --> Config Class Initialized
INFO - 2022-12-16 04:41:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:41:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:41:33 --> Utf8 Class Initialized
INFO - 2022-12-16 04:41:33 --> URI Class Initialized
INFO - 2022-12-16 04:41:33 --> Router Class Initialized
INFO - 2022-12-16 04:41:33 --> Output Class Initialized
INFO - 2022-12-16 04:41:33 --> Security Class Initialized
DEBUG - 2022-12-16 04:41:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:41:33 --> Input Class Initialized
INFO - 2022-12-16 04:41:33 --> Language Class Initialized
INFO - 2022-12-16 04:41:33 --> Language Class Initialized
INFO - 2022-12-16 04:41:33 --> Config Class Initialized
INFO - 2022-12-16 04:41:33 --> Loader Class Initialized
INFO - 2022-12-16 04:41:33 --> Helper loaded: url_helper
INFO - 2022-12-16 04:41:33 --> Helper loaded: file_helper
INFO - 2022-12-16 04:41:33 --> Helper loaded: form_helper
INFO - 2022-12-16 04:41:33 --> Helper loaded: my_helper
INFO - 2022-12-16 04:41:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:41:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:41:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:41:33 --> Controller Class Initialized
DEBUG - 2022-12-16 04:41:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:41:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:41:33 --> Final output sent to browser
DEBUG - 2022-12-16 04:41:33 --> Total execution time: 0.0667
INFO - 2022-12-16 04:41:39 --> Config Class Initialized
INFO - 2022-12-16 04:41:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:41:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:41:39 --> Utf8 Class Initialized
INFO - 2022-12-16 04:41:39 --> URI Class Initialized
INFO - 2022-12-16 04:41:39 --> Router Class Initialized
INFO - 2022-12-16 04:41:39 --> Output Class Initialized
INFO - 2022-12-16 04:41:39 --> Security Class Initialized
DEBUG - 2022-12-16 04:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:41:39 --> Input Class Initialized
INFO - 2022-12-16 04:41:39 --> Language Class Initialized
INFO - 2022-12-16 04:41:39 --> Language Class Initialized
INFO - 2022-12-16 04:41:39 --> Config Class Initialized
INFO - 2022-12-16 04:41:39 --> Loader Class Initialized
INFO - 2022-12-16 04:41:39 --> Helper loaded: url_helper
INFO - 2022-12-16 04:41:39 --> Helper loaded: file_helper
INFO - 2022-12-16 04:41:39 --> Helper loaded: form_helper
INFO - 2022-12-16 04:41:39 --> Helper loaded: my_helper
INFO - 2022-12-16 04:41:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:41:39 --> Controller Class Initialized
DEBUG - 2022-12-16 04:41:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:41:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:41:39 --> Final output sent to browser
DEBUG - 2022-12-16 04:41:39 --> Total execution time: 0.0768
INFO - 2022-12-16 04:42:03 --> Config Class Initialized
INFO - 2022-12-16 04:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:42:03 --> Utf8 Class Initialized
INFO - 2022-12-16 04:42:03 --> URI Class Initialized
INFO - 2022-12-16 04:42:03 --> Router Class Initialized
INFO - 2022-12-16 04:42:03 --> Output Class Initialized
INFO - 2022-12-16 04:42:03 --> Security Class Initialized
DEBUG - 2022-12-16 04:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:42:03 --> Input Class Initialized
INFO - 2022-12-16 04:42:03 --> Language Class Initialized
INFO - 2022-12-16 04:42:03 --> Language Class Initialized
INFO - 2022-12-16 04:42:03 --> Config Class Initialized
INFO - 2022-12-16 04:42:03 --> Loader Class Initialized
INFO - 2022-12-16 04:42:03 --> Helper loaded: url_helper
INFO - 2022-12-16 04:42:03 --> Helper loaded: file_helper
INFO - 2022-12-16 04:42:03 --> Helper loaded: form_helper
INFO - 2022-12-16 04:42:03 --> Helper loaded: my_helper
INFO - 2022-12-16 04:42:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:42:03 --> Controller Class Initialized
INFO - 2022-12-16 04:42:03 --> Config Class Initialized
INFO - 2022-12-16 04:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:42:03 --> Utf8 Class Initialized
INFO - 2022-12-16 04:42:03 --> URI Class Initialized
INFO - 2022-12-16 04:42:03 --> Router Class Initialized
INFO - 2022-12-16 04:42:03 --> Output Class Initialized
INFO - 2022-12-16 04:42:03 --> Security Class Initialized
DEBUG - 2022-12-16 04:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:42:03 --> Input Class Initialized
INFO - 2022-12-16 04:42:03 --> Language Class Initialized
INFO - 2022-12-16 04:42:03 --> Language Class Initialized
INFO - 2022-12-16 04:42:03 --> Config Class Initialized
INFO - 2022-12-16 04:42:03 --> Loader Class Initialized
INFO - 2022-12-16 04:42:03 --> Helper loaded: url_helper
INFO - 2022-12-16 04:42:03 --> Helper loaded: file_helper
INFO - 2022-12-16 04:42:03 --> Helper loaded: form_helper
INFO - 2022-12-16 04:42:03 --> Helper loaded: my_helper
INFO - 2022-12-16 04:42:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:42:03 --> Controller Class Initialized
DEBUG - 2022-12-16 04:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:42:03 --> Final output sent to browser
DEBUG - 2022-12-16 04:42:03 --> Total execution time: 0.0618
INFO - 2022-12-16 04:42:05 --> Config Class Initialized
INFO - 2022-12-16 04:42:05 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:42:05 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:42:05 --> Utf8 Class Initialized
INFO - 2022-12-16 04:42:05 --> URI Class Initialized
INFO - 2022-12-16 04:42:05 --> Router Class Initialized
INFO - 2022-12-16 04:42:05 --> Output Class Initialized
INFO - 2022-12-16 04:42:05 --> Security Class Initialized
DEBUG - 2022-12-16 04:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:42:05 --> Input Class Initialized
INFO - 2022-12-16 04:42:05 --> Language Class Initialized
INFO - 2022-12-16 04:42:05 --> Language Class Initialized
INFO - 2022-12-16 04:42:05 --> Config Class Initialized
INFO - 2022-12-16 04:42:05 --> Loader Class Initialized
INFO - 2022-12-16 04:42:05 --> Helper loaded: url_helper
INFO - 2022-12-16 04:42:05 --> Helper loaded: file_helper
INFO - 2022-12-16 04:42:05 --> Helper loaded: form_helper
INFO - 2022-12-16 04:42:05 --> Helper loaded: my_helper
INFO - 2022-12-16 04:42:05 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:42:05 --> Controller Class Initialized
DEBUG - 2022-12-16 04:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:42:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:42:05 --> Final output sent to browser
DEBUG - 2022-12-16 04:42:05 --> Total execution time: 0.0766
INFO - 2022-12-16 04:42:13 --> Config Class Initialized
INFO - 2022-12-16 04:42:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:42:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:42:13 --> Utf8 Class Initialized
INFO - 2022-12-16 04:42:13 --> URI Class Initialized
INFO - 2022-12-16 04:42:13 --> Router Class Initialized
INFO - 2022-12-16 04:42:13 --> Output Class Initialized
INFO - 2022-12-16 04:42:13 --> Security Class Initialized
DEBUG - 2022-12-16 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:42:13 --> Input Class Initialized
INFO - 2022-12-16 04:42:13 --> Language Class Initialized
INFO - 2022-12-16 04:42:13 --> Language Class Initialized
INFO - 2022-12-16 04:42:13 --> Config Class Initialized
INFO - 2022-12-16 04:42:13 --> Loader Class Initialized
INFO - 2022-12-16 04:42:13 --> Helper loaded: url_helper
INFO - 2022-12-16 04:42:13 --> Helper loaded: file_helper
INFO - 2022-12-16 04:42:13 --> Helper loaded: form_helper
INFO - 2022-12-16 04:42:13 --> Helper loaded: my_helper
INFO - 2022-12-16 04:42:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:42:13 --> Controller Class Initialized
INFO - 2022-12-16 04:42:13 --> Config Class Initialized
INFO - 2022-12-16 04:42:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:42:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:42:13 --> Utf8 Class Initialized
INFO - 2022-12-16 04:42:13 --> URI Class Initialized
INFO - 2022-12-16 04:42:13 --> Router Class Initialized
INFO - 2022-12-16 04:42:13 --> Output Class Initialized
INFO - 2022-12-16 04:42:13 --> Security Class Initialized
DEBUG - 2022-12-16 04:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:42:13 --> Input Class Initialized
INFO - 2022-12-16 04:42:13 --> Language Class Initialized
INFO - 2022-12-16 04:42:13 --> Language Class Initialized
INFO - 2022-12-16 04:42:13 --> Config Class Initialized
INFO - 2022-12-16 04:42:13 --> Loader Class Initialized
INFO - 2022-12-16 04:42:13 --> Helper loaded: url_helper
INFO - 2022-12-16 04:42:13 --> Helper loaded: file_helper
INFO - 2022-12-16 04:42:13 --> Helper loaded: form_helper
INFO - 2022-12-16 04:42:13 --> Helper loaded: my_helper
INFO - 2022-12-16 04:42:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:42:13 --> Controller Class Initialized
DEBUG - 2022-12-16 04:42:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:42:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:42:13 --> Final output sent to browser
DEBUG - 2022-12-16 04:42:13 --> Total execution time: 0.0758
INFO - 2022-12-16 04:43:09 --> Config Class Initialized
INFO - 2022-12-16 04:43:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:09 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:09 --> URI Class Initialized
INFO - 2022-12-16 04:43:09 --> Router Class Initialized
INFO - 2022-12-16 04:43:09 --> Output Class Initialized
INFO - 2022-12-16 04:43:09 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:09 --> Input Class Initialized
INFO - 2022-12-16 04:43:09 --> Language Class Initialized
INFO - 2022-12-16 04:43:09 --> Language Class Initialized
INFO - 2022-12-16 04:43:09 --> Config Class Initialized
INFO - 2022-12-16 04:43:09 --> Loader Class Initialized
INFO - 2022-12-16 04:43:09 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:09 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:09 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:09 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:09 --> Controller Class Initialized
DEBUG - 2022-12-16 04:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 04:43:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:43:09 --> Final output sent to browser
DEBUG - 2022-12-16 04:43:09 --> Total execution time: 0.0943
INFO - 2022-12-16 04:43:10 --> Config Class Initialized
INFO - 2022-12-16 04:43:10 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:10 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:10 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:10 --> URI Class Initialized
INFO - 2022-12-16 04:43:10 --> Router Class Initialized
INFO - 2022-12-16 04:43:10 --> Output Class Initialized
INFO - 2022-12-16 04:43:10 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:10 --> Input Class Initialized
INFO - 2022-12-16 04:43:10 --> Language Class Initialized
INFO - 2022-12-16 04:43:10 --> Language Class Initialized
INFO - 2022-12-16 04:43:10 --> Config Class Initialized
INFO - 2022-12-16 04:43:10 --> Loader Class Initialized
INFO - 2022-12-16 04:43:10 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:10 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:10 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:10 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:10 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:10 --> Controller Class Initialized
INFO - 2022-12-16 04:43:12 --> Config Class Initialized
INFO - 2022-12-16 04:43:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:12 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:12 --> URI Class Initialized
INFO - 2022-12-16 04:43:12 --> Router Class Initialized
INFO - 2022-12-16 04:43:12 --> Output Class Initialized
INFO - 2022-12-16 04:43:12 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:12 --> Input Class Initialized
INFO - 2022-12-16 04:43:12 --> Language Class Initialized
INFO - 2022-12-16 04:43:12 --> Language Class Initialized
INFO - 2022-12-16 04:43:12 --> Config Class Initialized
INFO - 2022-12-16 04:43:12 --> Loader Class Initialized
INFO - 2022-12-16 04:43:12 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:12 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:12 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:13 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:13 --> Controller Class Initialized
INFO - 2022-12-16 04:43:14 --> Config Class Initialized
INFO - 2022-12-16 04:43:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:14 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:14 --> URI Class Initialized
INFO - 2022-12-16 04:43:14 --> Router Class Initialized
INFO - 2022-12-16 04:43:14 --> Output Class Initialized
INFO - 2022-12-16 04:43:14 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:14 --> Input Class Initialized
INFO - 2022-12-16 04:43:14 --> Language Class Initialized
INFO - 2022-12-16 04:43:14 --> Language Class Initialized
INFO - 2022-12-16 04:43:14 --> Config Class Initialized
INFO - 2022-12-16 04:43:14 --> Loader Class Initialized
INFO - 2022-12-16 04:43:14 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:14 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:14 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:14 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:14 --> Controller Class Initialized
INFO - 2022-12-16 04:43:16 --> Config Class Initialized
INFO - 2022-12-16 04:43:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:16 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:16 --> URI Class Initialized
INFO - 2022-12-16 04:43:16 --> Router Class Initialized
INFO - 2022-12-16 04:43:16 --> Output Class Initialized
INFO - 2022-12-16 04:43:16 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:16 --> Input Class Initialized
INFO - 2022-12-16 04:43:16 --> Language Class Initialized
INFO - 2022-12-16 04:43:16 --> Language Class Initialized
INFO - 2022-12-16 04:43:16 --> Config Class Initialized
INFO - 2022-12-16 04:43:16 --> Loader Class Initialized
INFO - 2022-12-16 04:43:16 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:16 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:16 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:16 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:16 --> Controller Class Initialized
INFO - 2022-12-16 04:43:19 --> Config Class Initialized
INFO - 2022-12-16 04:43:19 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:19 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:19 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:19 --> URI Class Initialized
INFO - 2022-12-16 04:43:19 --> Router Class Initialized
INFO - 2022-12-16 04:43:19 --> Output Class Initialized
INFO - 2022-12-16 04:43:19 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:19 --> Input Class Initialized
INFO - 2022-12-16 04:43:19 --> Language Class Initialized
INFO - 2022-12-16 04:43:19 --> Language Class Initialized
INFO - 2022-12-16 04:43:19 --> Config Class Initialized
INFO - 2022-12-16 04:43:19 --> Loader Class Initialized
INFO - 2022-12-16 04:43:19 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:19 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:19 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:19 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:19 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:19 --> Controller Class Initialized
INFO - 2022-12-16 04:43:27 --> Config Class Initialized
INFO - 2022-12-16 04:43:27 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:27 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:27 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:27 --> URI Class Initialized
INFO - 2022-12-16 04:43:27 --> Router Class Initialized
INFO - 2022-12-16 04:43:27 --> Output Class Initialized
INFO - 2022-12-16 04:43:27 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:27 --> Input Class Initialized
INFO - 2022-12-16 04:43:27 --> Language Class Initialized
INFO - 2022-12-16 04:43:27 --> Language Class Initialized
INFO - 2022-12-16 04:43:27 --> Config Class Initialized
INFO - 2022-12-16 04:43:27 --> Loader Class Initialized
INFO - 2022-12-16 04:43:27 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:27 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:27 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:27 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:27 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:27 --> Controller Class Initialized
DEBUG - 2022-12-16 04:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/tahun/views/list.php
DEBUG - 2022-12-16 04:43:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:43:27 --> Final output sent to browser
DEBUG - 2022-12-16 04:43:27 --> Total execution time: 0.0832
INFO - 2022-12-16 04:43:27 --> Config Class Initialized
INFO - 2022-12-16 04:43:27 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:27 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:27 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:27 --> URI Class Initialized
INFO - 2022-12-16 04:43:27 --> Router Class Initialized
INFO - 2022-12-16 04:43:27 --> Output Class Initialized
INFO - 2022-12-16 04:43:27 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:27 --> Input Class Initialized
INFO - 2022-12-16 04:43:27 --> Language Class Initialized
INFO - 2022-12-16 04:43:27 --> Language Class Initialized
INFO - 2022-12-16 04:43:27 --> Config Class Initialized
INFO - 2022-12-16 04:43:27 --> Loader Class Initialized
INFO - 2022-12-16 04:43:27 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:27 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:27 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:27 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:27 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:27 --> Controller Class Initialized
INFO - 2022-12-16 04:43:29 --> Config Class Initialized
INFO - 2022-12-16 04:43:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:29 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:29 --> URI Class Initialized
INFO - 2022-12-16 04:43:29 --> Router Class Initialized
INFO - 2022-12-16 04:43:29 --> Output Class Initialized
INFO - 2022-12-16 04:43:29 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:29 --> Input Class Initialized
INFO - 2022-12-16 04:43:29 --> Language Class Initialized
INFO - 2022-12-16 04:43:29 --> Language Class Initialized
INFO - 2022-12-16 04:43:29 --> Config Class Initialized
INFO - 2022-12-16 04:43:29 --> Loader Class Initialized
INFO - 2022-12-16 04:43:29 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:29 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:29 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:29 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:29 --> Controller Class Initialized
DEBUG - 2022-12-16 04:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 04:43:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:43:29 --> Final output sent to browser
DEBUG - 2022-12-16 04:43:29 --> Total execution time: 0.0678
INFO - 2022-12-16 04:43:29 --> Config Class Initialized
INFO - 2022-12-16 04:43:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:29 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:29 --> URI Class Initialized
INFO - 2022-12-16 04:43:29 --> Router Class Initialized
INFO - 2022-12-16 04:43:29 --> Output Class Initialized
INFO - 2022-12-16 04:43:29 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:29 --> Input Class Initialized
INFO - 2022-12-16 04:43:29 --> Language Class Initialized
INFO - 2022-12-16 04:43:29 --> Language Class Initialized
INFO - 2022-12-16 04:43:29 --> Config Class Initialized
INFO - 2022-12-16 04:43:29 --> Loader Class Initialized
INFO - 2022-12-16 04:43:29 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:29 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:29 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:29 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:29 --> Controller Class Initialized
INFO - 2022-12-16 04:43:32 --> Config Class Initialized
INFO - 2022-12-16 04:43:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:32 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:32 --> URI Class Initialized
INFO - 2022-12-16 04:43:32 --> Router Class Initialized
INFO - 2022-12-16 04:43:32 --> Output Class Initialized
INFO - 2022-12-16 04:43:32 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:32 --> Input Class Initialized
INFO - 2022-12-16 04:43:32 --> Language Class Initialized
INFO - 2022-12-16 04:43:32 --> Language Class Initialized
INFO - 2022-12-16 04:43:32 --> Config Class Initialized
INFO - 2022-12-16 04:43:32 --> Loader Class Initialized
INFO - 2022-12-16 04:43:32 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:32 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:32 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:32 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:32 --> Controller Class Initialized
INFO - 2022-12-16 04:43:32 --> Config Class Initialized
INFO - 2022-12-16 04:43:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:43:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:43:32 --> Utf8 Class Initialized
INFO - 2022-12-16 04:43:32 --> URI Class Initialized
INFO - 2022-12-16 04:43:32 --> Router Class Initialized
INFO - 2022-12-16 04:43:32 --> Output Class Initialized
INFO - 2022-12-16 04:43:32 --> Security Class Initialized
DEBUG - 2022-12-16 04:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:43:32 --> Input Class Initialized
INFO - 2022-12-16 04:43:32 --> Language Class Initialized
INFO - 2022-12-16 04:43:32 --> Language Class Initialized
INFO - 2022-12-16 04:43:32 --> Config Class Initialized
INFO - 2022-12-16 04:43:32 --> Loader Class Initialized
INFO - 2022-12-16 04:43:32 --> Helper loaded: url_helper
INFO - 2022-12-16 04:43:32 --> Helper loaded: file_helper
INFO - 2022-12-16 04:43:32 --> Helper loaded: form_helper
INFO - 2022-12-16 04:43:32 --> Helper loaded: my_helper
INFO - 2022-12-16 04:43:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:43:32 --> Controller Class Initialized
INFO - 2022-12-16 04:57:29 --> Config Class Initialized
INFO - 2022-12-16 04:57:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:57:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:57:29 --> Utf8 Class Initialized
INFO - 2022-12-16 04:57:29 --> URI Class Initialized
INFO - 2022-12-16 04:57:29 --> Router Class Initialized
INFO - 2022-12-16 04:57:29 --> Output Class Initialized
INFO - 2022-12-16 04:57:29 --> Security Class Initialized
DEBUG - 2022-12-16 04:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:57:29 --> Input Class Initialized
INFO - 2022-12-16 04:57:29 --> Language Class Initialized
INFO - 2022-12-16 04:57:29 --> Language Class Initialized
INFO - 2022-12-16 04:57:29 --> Config Class Initialized
INFO - 2022-12-16 04:57:29 --> Loader Class Initialized
INFO - 2022-12-16 04:57:29 --> Helper loaded: url_helper
INFO - 2022-12-16 04:57:29 --> Helper loaded: file_helper
INFO - 2022-12-16 04:57:29 --> Helper loaded: form_helper
INFO - 2022-12-16 04:57:29 --> Helper loaded: my_helper
INFO - 2022-12-16 04:57:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:57:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:57:29 --> Controller Class Initialized
DEBUG - 2022-12-16 04:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:57:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:57:29 --> Final output sent to browser
DEBUG - 2022-12-16 04:57:29 --> Total execution time: 0.0993
INFO - 2022-12-16 04:57:43 --> Config Class Initialized
INFO - 2022-12-16 04:57:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:57:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:57:43 --> Utf8 Class Initialized
INFO - 2022-12-16 04:57:43 --> URI Class Initialized
INFO - 2022-12-16 04:57:43 --> Router Class Initialized
INFO - 2022-12-16 04:57:43 --> Output Class Initialized
INFO - 2022-12-16 04:57:43 --> Security Class Initialized
DEBUG - 2022-12-16 04:57:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:57:43 --> Input Class Initialized
INFO - 2022-12-16 04:57:43 --> Language Class Initialized
INFO - 2022-12-16 04:57:43 --> Language Class Initialized
INFO - 2022-12-16 04:57:43 --> Config Class Initialized
INFO - 2022-12-16 04:57:43 --> Loader Class Initialized
INFO - 2022-12-16 04:57:43 --> Helper loaded: url_helper
INFO - 2022-12-16 04:57:43 --> Helper loaded: file_helper
INFO - 2022-12-16 04:57:43 --> Helper loaded: form_helper
INFO - 2022-12-16 04:57:43 --> Helper loaded: my_helper
INFO - 2022-12-16 04:57:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:57:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:57:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:57:43 --> Controller Class Initialized
INFO - 2022-12-16 04:57:43 --> Final output sent to browser
DEBUG - 2022-12-16 04:57:43 --> Total execution time: 0.1015
INFO - 2022-12-16 04:59:42 --> Config Class Initialized
INFO - 2022-12-16 04:59:42 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:59:42 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:59:42 --> Utf8 Class Initialized
INFO - 2022-12-16 04:59:42 --> URI Class Initialized
INFO - 2022-12-16 04:59:42 --> Router Class Initialized
INFO - 2022-12-16 04:59:42 --> Output Class Initialized
INFO - 2022-12-16 04:59:42 --> Security Class Initialized
DEBUG - 2022-12-16 04:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:59:42 --> Input Class Initialized
INFO - 2022-12-16 04:59:42 --> Language Class Initialized
INFO - 2022-12-16 04:59:42 --> Language Class Initialized
INFO - 2022-12-16 04:59:42 --> Config Class Initialized
INFO - 2022-12-16 04:59:42 --> Loader Class Initialized
INFO - 2022-12-16 04:59:42 --> Helper loaded: url_helper
INFO - 2022-12-16 04:59:42 --> Helper loaded: file_helper
INFO - 2022-12-16 04:59:42 --> Helper loaded: form_helper
INFO - 2022-12-16 04:59:42 --> Helper loaded: my_helper
INFO - 2022-12-16 04:59:42 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:59:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:59:42 --> Controller Class Initialized
DEBUG - 2022-12-16 04:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 04:59:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:59:42 --> Final output sent to browser
DEBUG - 2022-12-16 04:59:42 --> Total execution time: 0.0786
INFO - 2022-12-16 04:59:43 --> Config Class Initialized
INFO - 2022-12-16 04:59:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 04:59:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 04:59:43 --> Utf8 Class Initialized
INFO - 2022-12-16 04:59:43 --> URI Class Initialized
INFO - 2022-12-16 04:59:43 --> Router Class Initialized
INFO - 2022-12-16 04:59:43 --> Output Class Initialized
INFO - 2022-12-16 04:59:43 --> Security Class Initialized
DEBUG - 2022-12-16 04:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 04:59:43 --> Input Class Initialized
INFO - 2022-12-16 04:59:43 --> Language Class Initialized
INFO - 2022-12-16 04:59:43 --> Language Class Initialized
INFO - 2022-12-16 04:59:43 --> Config Class Initialized
INFO - 2022-12-16 04:59:43 --> Loader Class Initialized
INFO - 2022-12-16 04:59:43 --> Helper loaded: url_helper
INFO - 2022-12-16 04:59:43 --> Helper loaded: file_helper
INFO - 2022-12-16 04:59:43 --> Helper loaded: form_helper
INFO - 2022-12-16 04:59:43 --> Helper loaded: my_helper
INFO - 2022-12-16 04:59:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 04:59:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 04:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 04:59:43 --> Controller Class Initialized
DEBUG - 2022-12-16 04:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 04:59:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 04:59:43 --> Final output sent to browser
DEBUG - 2022-12-16 04:59:43 --> Total execution time: 0.0823
INFO - 2022-12-16 05:02:00 --> Config Class Initialized
INFO - 2022-12-16 05:02:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:02:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:02:00 --> Utf8 Class Initialized
INFO - 2022-12-16 05:02:00 --> URI Class Initialized
INFO - 2022-12-16 05:02:00 --> Router Class Initialized
INFO - 2022-12-16 05:02:00 --> Output Class Initialized
INFO - 2022-12-16 05:02:00 --> Security Class Initialized
DEBUG - 2022-12-16 05:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:02:00 --> Input Class Initialized
INFO - 2022-12-16 05:02:00 --> Language Class Initialized
INFO - 2022-12-16 05:02:00 --> Language Class Initialized
INFO - 2022-12-16 05:02:00 --> Config Class Initialized
INFO - 2022-12-16 05:02:00 --> Loader Class Initialized
INFO - 2022-12-16 05:02:00 --> Helper loaded: url_helper
INFO - 2022-12-16 05:02:00 --> Helper loaded: file_helper
INFO - 2022-12-16 05:02:00 --> Helper loaded: form_helper
INFO - 2022-12-16 05:02:00 --> Helper loaded: my_helper
INFO - 2022-12-16 05:02:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:02:00 --> Controller Class Initialized
DEBUG - 2022-12-16 05:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:02:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:02:00 --> Final output sent to browser
DEBUG - 2022-12-16 05:02:00 --> Total execution time: 0.0978
INFO - 2022-12-16 05:05:02 --> Config Class Initialized
INFO - 2022-12-16 05:05:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:02 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:02 --> URI Class Initialized
INFO - 2022-12-16 05:05:02 --> Router Class Initialized
INFO - 2022-12-16 05:05:02 --> Output Class Initialized
INFO - 2022-12-16 05:05:02 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:02 --> Input Class Initialized
INFO - 2022-12-16 05:05:02 --> Language Class Initialized
INFO - 2022-12-16 05:05:02 --> Language Class Initialized
INFO - 2022-12-16 05:05:02 --> Config Class Initialized
INFO - 2022-12-16 05:05:02 --> Loader Class Initialized
INFO - 2022-12-16 05:05:02 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:02 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:02 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:02 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:02 --> Controller Class Initialized
DEBUG - 2022-12-16 05:05:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:05:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:05:02 --> Final output sent to browser
DEBUG - 2022-12-16 05:05:02 --> Total execution time: 0.0724
INFO - 2022-12-16 05:05:03 --> Config Class Initialized
INFO - 2022-12-16 05:05:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:03 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:03 --> URI Class Initialized
INFO - 2022-12-16 05:05:03 --> Router Class Initialized
INFO - 2022-12-16 05:05:03 --> Output Class Initialized
INFO - 2022-12-16 05:05:03 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:03 --> Input Class Initialized
INFO - 2022-12-16 05:05:03 --> Language Class Initialized
INFO - 2022-12-16 05:05:03 --> Language Class Initialized
INFO - 2022-12-16 05:05:03 --> Config Class Initialized
INFO - 2022-12-16 05:05:03 --> Loader Class Initialized
INFO - 2022-12-16 05:05:03 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:03 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:03 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:03 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:04 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:04 --> Controller Class Initialized
DEBUG - 2022-12-16 05:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:05:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:05:04 --> Final output sent to browser
DEBUG - 2022-12-16 05:05:04 --> Total execution time: 0.0845
INFO - 2022-12-16 05:05:04 --> Config Class Initialized
INFO - 2022-12-16 05:05:04 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:04 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:04 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:04 --> URI Class Initialized
INFO - 2022-12-16 05:05:04 --> Router Class Initialized
INFO - 2022-12-16 05:05:04 --> Output Class Initialized
INFO - 2022-12-16 05:05:04 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:04 --> Input Class Initialized
INFO - 2022-12-16 05:05:04 --> Language Class Initialized
INFO - 2022-12-16 05:05:04 --> Language Class Initialized
INFO - 2022-12-16 05:05:04 --> Config Class Initialized
INFO - 2022-12-16 05:05:04 --> Loader Class Initialized
INFO - 2022-12-16 05:05:04 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:04 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:04 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:04 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:04 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:04 --> Controller Class Initialized
INFO - 2022-12-16 05:05:06 --> Config Class Initialized
INFO - 2022-12-16 05:05:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:06 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:06 --> URI Class Initialized
INFO - 2022-12-16 05:05:06 --> Router Class Initialized
INFO - 2022-12-16 05:05:06 --> Output Class Initialized
INFO - 2022-12-16 05:05:06 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:06 --> Input Class Initialized
INFO - 2022-12-16 05:05:06 --> Language Class Initialized
INFO - 2022-12-16 05:05:06 --> Language Class Initialized
INFO - 2022-12-16 05:05:06 --> Config Class Initialized
INFO - 2022-12-16 05:05:06 --> Loader Class Initialized
INFO - 2022-12-16 05:05:06 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:06 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:06 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:06 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:06 --> Controller Class Initialized
DEBUG - 2022-12-16 05:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:05:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:05:06 --> Final output sent to browser
DEBUG - 2022-12-16 05:05:06 --> Total execution time: 0.0850
INFO - 2022-12-16 05:05:13 --> Config Class Initialized
INFO - 2022-12-16 05:05:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:13 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:13 --> URI Class Initialized
INFO - 2022-12-16 05:05:13 --> Router Class Initialized
INFO - 2022-12-16 05:05:13 --> Output Class Initialized
INFO - 2022-12-16 05:05:13 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:13 --> Input Class Initialized
INFO - 2022-12-16 05:05:13 --> Language Class Initialized
INFO - 2022-12-16 05:05:13 --> Language Class Initialized
INFO - 2022-12-16 05:05:13 --> Config Class Initialized
INFO - 2022-12-16 05:05:13 --> Loader Class Initialized
INFO - 2022-12-16 05:05:13 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:13 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:13 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:13 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:13 --> Controller Class Initialized
INFO - 2022-12-16 05:05:15 --> Config Class Initialized
INFO - 2022-12-16 05:05:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:15 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:15 --> URI Class Initialized
INFO - 2022-12-16 05:05:15 --> Router Class Initialized
INFO - 2022-12-16 05:05:15 --> Output Class Initialized
INFO - 2022-12-16 05:05:15 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:15 --> Input Class Initialized
INFO - 2022-12-16 05:05:15 --> Language Class Initialized
INFO - 2022-12-16 05:05:15 --> Language Class Initialized
INFO - 2022-12-16 05:05:15 --> Config Class Initialized
INFO - 2022-12-16 05:05:15 --> Loader Class Initialized
INFO - 2022-12-16 05:05:15 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:15 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:15 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:15 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:15 --> Controller Class Initialized
DEBUG - 2022-12-16 05:05:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:05:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:05:15 --> Final output sent to browser
DEBUG - 2022-12-16 05:05:15 --> Total execution time: 0.0551
INFO - 2022-12-16 05:05:17 --> Config Class Initialized
INFO - 2022-12-16 05:05:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:17 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:17 --> URI Class Initialized
INFO - 2022-12-16 05:05:17 --> Router Class Initialized
INFO - 2022-12-16 05:05:17 --> Output Class Initialized
INFO - 2022-12-16 05:05:17 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:17 --> Input Class Initialized
INFO - 2022-12-16 05:05:17 --> Language Class Initialized
INFO - 2022-12-16 05:05:17 --> Language Class Initialized
INFO - 2022-12-16 05:05:17 --> Config Class Initialized
INFO - 2022-12-16 05:05:17 --> Loader Class Initialized
INFO - 2022-12-16 05:05:17 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:17 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:17 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:17 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:17 --> Controller Class Initialized
DEBUG - 2022-12-16 05:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:05:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:05:17 --> Final output sent to browser
DEBUG - 2022-12-16 05:05:17 --> Total execution time: 0.0715
INFO - 2022-12-16 05:05:17 --> Config Class Initialized
INFO - 2022-12-16 05:05:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:05:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:05:17 --> Utf8 Class Initialized
INFO - 2022-12-16 05:05:17 --> URI Class Initialized
INFO - 2022-12-16 05:05:17 --> Router Class Initialized
INFO - 2022-12-16 05:05:17 --> Output Class Initialized
INFO - 2022-12-16 05:05:17 --> Security Class Initialized
DEBUG - 2022-12-16 05:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:05:17 --> Input Class Initialized
INFO - 2022-12-16 05:05:17 --> Language Class Initialized
INFO - 2022-12-16 05:05:17 --> Language Class Initialized
INFO - 2022-12-16 05:05:17 --> Config Class Initialized
INFO - 2022-12-16 05:05:17 --> Loader Class Initialized
INFO - 2022-12-16 05:05:17 --> Helper loaded: url_helper
INFO - 2022-12-16 05:05:17 --> Helper loaded: file_helper
INFO - 2022-12-16 05:05:17 --> Helper loaded: form_helper
INFO - 2022-12-16 05:05:17 --> Helper loaded: my_helper
INFO - 2022-12-16 05:05:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:05:17 --> Controller Class Initialized
INFO - 2022-12-16 05:06:57 --> Config Class Initialized
INFO - 2022-12-16 05:06:57 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:06:57 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:06:57 --> Utf8 Class Initialized
INFO - 2022-12-16 05:06:57 --> URI Class Initialized
INFO - 2022-12-16 05:06:57 --> Router Class Initialized
INFO - 2022-12-16 05:06:57 --> Output Class Initialized
INFO - 2022-12-16 05:06:57 --> Security Class Initialized
DEBUG - 2022-12-16 05:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:06:57 --> Input Class Initialized
INFO - 2022-12-16 05:06:57 --> Language Class Initialized
INFO - 2022-12-16 05:06:57 --> Language Class Initialized
INFO - 2022-12-16 05:06:57 --> Config Class Initialized
INFO - 2022-12-16 05:06:57 --> Loader Class Initialized
INFO - 2022-12-16 05:06:57 --> Helper loaded: url_helper
INFO - 2022-12-16 05:06:57 --> Helper loaded: file_helper
INFO - 2022-12-16 05:06:57 --> Helper loaded: form_helper
INFO - 2022-12-16 05:06:57 --> Helper loaded: my_helper
INFO - 2022-12-16 05:06:57 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:06:57 --> Controller Class Initialized
DEBUG - 2022-12-16 05:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:06:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:06:57 --> Final output sent to browser
DEBUG - 2022-12-16 05:06:57 --> Total execution time: 0.0629
INFO - 2022-12-16 05:06:57 --> Config Class Initialized
INFO - 2022-12-16 05:06:57 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:06:57 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:06:57 --> Utf8 Class Initialized
INFO - 2022-12-16 05:06:57 --> URI Class Initialized
INFO - 2022-12-16 05:06:57 --> Router Class Initialized
INFO - 2022-12-16 05:06:57 --> Output Class Initialized
INFO - 2022-12-16 05:06:57 --> Security Class Initialized
DEBUG - 2022-12-16 05:06:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:06:57 --> Input Class Initialized
INFO - 2022-12-16 05:06:57 --> Language Class Initialized
INFO - 2022-12-16 05:06:57 --> Language Class Initialized
INFO - 2022-12-16 05:06:57 --> Config Class Initialized
INFO - 2022-12-16 05:06:57 --> Loader Class Initialized
INFO - 2022-12-16 05:06:57 --> Helper loaded: url_helper
INFO - 2022-12-16 05:06:57 --> Helper loaded: file_helper
INFO - 2022-12-16 05:06:57 --> Helper loaded: form_helper
INFO - 2022-12-16 05:06:57 --> Helper loaded: my_helper
INFO - 2022-12-16 05:06:57 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:06:57 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:06:57 --> Controller Class Initialized
INFO - 2022-12-16 05:06:59 --> Config Class Initialized
INFO - 2022-12-16 05:06:59 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:06:59 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:06:59 --> Utf8 Class Initialized
INFO - 2022-12-16 05:06:59 --> URI Class Initialized
INFO - 2022-12-16 05:06:59 --> Router Class Initialized
INFO - 2022-12-16 05:06:59 --> Output Class Initialized
INFO - 2022-12-16 05:06:59 --> Security Class Initialized
DEBUG - 2022-12-16 05:06:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:06:59 --> Input Class Initialized
INFO - 2022-12-16 05:06:59 --> Language Class Initialized
INFO - 2022-12-16 05:06:59 --> Language Class Initialized
INFO - 2022-12-16 05:06:59 --> Config Class Initialized
INFO - 2022-12-16 05:06:59 --> Loader Class Initialized
INFO - 2022-12-16 05:06:59 --> Helper loaded: url_helper
INFO - 2022-12-16 05:06:59 --> Helper loaded: file_helper
INFO - 2022-12-16 05:06:59 --> Helper loaded: form_helper
INFO - 2022-12-16 05:06:59 --> Helper loaded: my_helper
INFO - 2022-12-16 05:06:59 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:06:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:06:59 --> Controller Class Initialized
DEBUG - 2022-12-16 05:06:59 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:06:59 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:06:59 --> Final output sent to browser
DEBUG - 2022-12-16 05:06:59 --> Total execution time: 0.0759
INFO - 2022-12-16 05:07:06 --> Config Class Initialized
INFO - 2022-12-16 05:07:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:07:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:07:06 --> Utf8 Class Initialized
INFO - 2022-12-16 05:07:06 --> URI Class Initialized
INFO - 2022-12-16 05:07:06 --> Router Class Initialized
INFO - 2022-12-16 05:07:06 --> Output Class Initialized
INFO - 2022-12-16 05:07:06 --> Security Class Initialized
DEBUG - 2022-12-16 05:07:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:07:06 --> Input Class Initialized
INFO - 2022-12-16 05:07:06 --> Language Class Initialized
INFO - 2022-12-16 05:07:06 --> Language Class Initialized
INFO - 2022-12-16 05:07:06 --> Config Class Initialized
INFO - 2022-12-16 05:07:06 --> Loader Class Initialized
INFO - 2022-12-16 05:07:06 --> Helper loaded: url_helper
INFO - 2022-12-16 05:07:06 --> Helper loaded: file_helper
INFO - 2022-12-16 05:07:06 --> Helper loaded: form_helper
INFO - 2022-12-16 05:07:06 --> Helper loaded: my_helper
INFO - 2022-12-16 05:07:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:07:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:07:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:07:06 --> Controller Class Initialized
INFO - 2022-12-16 05:07:09 --> Config Class Initialized
INFO - 2022-12-16 05:07:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:07:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:07:09 --> Utf8 Class Initialized
INFO - 2022-12-16 05:07:09 --> URI Class Initialized
INFO - 2022-12-16 05:07:09 --> Router Class Initialized
INFO - 2022-12-16 05:07:09 --> Output Class Initialized
INFO - 2022-12-16 05:07:09 --> Security Class Initialized
DEBUG - 2022-12-16 05:07:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:07:09 --> Input Class Initialized
INFO - 2022-12-16 05:07:09 --> Language Class Initialized
INFO - 2022-12-16 05:07:09 --> Language Class Initialized
INFO - 2022-12-16 05:07:09 --> Config Class Initialized
INFO - 2022-12-16 05:07:09 --> Loader Class Initialized
INFO - 2022-12-16 05:07:09 --> Helper loaded: url_helper
INFO - 2022-12-16 05:07:09 --> Helper loaded: file_helper
INFO - 2022-12-16 05:07:09 --> Helper loaded: form_helper
INFO - 2022-12-16 05:07:09 --> Helper loaded: my_helper
INFO - 2022-12-16 05:07:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:07:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:07:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:07:09 --> Controller Class Initialized
DEBUG - 2022-12-16 05:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:07:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:07:09 --> Final output sent to browser
DEBUG - 2022-12-16 05:07:09 --> Total execution time: 0.0608
INFO - 2022-12-16 05:07:12 --> Config Class Initialized
INFO - 2022-12-16 05:07:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:07:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:07:12 --> Utf8 Class Initialized
INFO - 2022-12-16 05:07:12 --> URI Class Initialized
INFO - 2022-12-16 05:07:12 --> Router Class Initialized
INFO - 2022-12-16 05:07:12 --> Output Class Initialized
INFO - 2022-12-16 05:07:12 --> Security Class Initialized
DEBUG - 2022-12-16 05:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:07:12 --> Input Class Initialized
INFO - 2022-12-16 05:07:12 --> Language Class Initialized
INFO - 2022-12-16 05:07:12 --> Language Class Initialized
INFO - 2022-12-16 05:07:12 --> Config Class Initialized
INFO - 2022-12-16 05:07:12 --> Loader Class Initialized
INFO - 2022-12-16 05:07:12 --> Helper loaded: url_helper
INFO - 2022-12-16 05:07:12 --> Helper loaded: file_helper
INFO - 2022-12-16 05:07:12 --> Helper loaded: form_helper
INFO - 2022-12-16 05:07:12 --> Helper loaded: my_helper
INFO - 2022-12-16 05:07:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:07:12 --> Controller Class Initialized
DEBUG - 2022-12-16 05:07:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:07:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:07:12 --> Final output sent to browser
DEBUG - 2022-12-16 05:07:12 --> Total execution time: 0.0812
INFO - 2022-12-16 05:07:12 --> Config Class Initialized
INFO - 2022-12-16 05:07:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:07:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:07:12 --> Utf8 Class Initialized
INFO - 2022-12-16 05:07:12 --> URI Class Initialized
INFO - 2022-12-16 05:07:12 --> Router Class Initialized
INFO - 2022-12-16 05:07:12 --> Output Class Initialized
INFO - 2022-12-16 05:07:12 --> Security Class Initialized
DEBUG - 2022-12-16 05:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:07:12 --> Input Class Initialized
INFO - 2022-12-16 05:07:12 --> Language Class Initialized
INFO - 2022-12-16 05:07:12 --> Language Class Initialized
INFO - 2022-12-16 05:07:12 --> Config Class Initialized
INFO - 2022-12-16 05:07:12 --> Loader Class Initialized
INFO - 2022-12-16 05:07:12 --> Helper loaded: url_helper
INFO - 2022-12-16 05:07:12 --> Helper loaded: file_helper
INFO - 2022-12-16 05:07:12 --> Helper loaded: form_helper
INFO - 2022-12-16 05:07:12 --> Helper loaded: my_helper
INFO - 2022-12-16 05:07:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:07:12 --> Controller Class Initialized
INFO - 2022-12-16 05:08:48 --> Config Class Initialized
INFO - 2022-12-16 05:08:48 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:08:48 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:08:48 --> Utf8 Class Initialized
INFO - 2022-12-16 05:08:48 --> URI Class Initialized
INFO - 2022-12-16 05:08:48 --> Router Class Initialized
INFO - 2022-12-16 05:08:48 --> Output Class Initialized
INFO - 2022-12-16 05:08:48 --> Security Class Initialized
DEBUG - 2022-12-16 05:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:08:48 --> Input Class Initialized
INFO - 2022-12-16 05:08:48 --> Language Class Initialized
INFO - 2022-12-16 05:08:48 --> Language Class Initialized
INFO - 2022-12-16 05:08:48 --> Config Class Initialized
INFO - 2022-12-16 05:08:48 --> Loader Class Initialized
INFO - 2022-12-16 05:08:48 --> Helper loaded: url_helper
INFO - 2022-12-16 05:08:48 --> Helper loaded: file_helper
INFO - 2022-12-16 05:08:48 --> Helper loaded: form_helper
INFO - 2022-12-16 05:08:48 --> Helper loaded: my_helper
INFO - 2022-12-16 05:08:48 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:08:48 --> Controller Class Initialized
DEBUG - 2022-12-16 05:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:08:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:08:48 --> Final output sent to browser
DEBUG - 2022-12-16 05:08:48 --> Total execution time: 0.0604
INFO - 2022-12-16 05:08:48 --> Config Class Initialized
INFO - 2022-12-16 05:08:48 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:08:48 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:08:48 --> Utf8 Class Initialized
INFO - 2022-12-16 05:08:48 --> URI Class Initialized
INFO - 2022-12-16 05:08:48 --> Router Class Initialized
INFO - 2022-12-16 05:08:48 --> Output Class Initialized
INFO - 2022-12-16 05:08:48 --> Security Class Initialized
DEBUG - 2022-12-16 05:08:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:08:48 --> Input Class Initialized
INFO - 2022-12-16 05:08:48 --> Language Class Initialized
INFO - 2022-12-16 05:08:48 --> Language Class Initialized
INFO - 2022-12-16 05:08:48 --> Config Class Initialized
INFO - 2022-12-16 05:08:48 --> Loader Class Initialized
INFO - 2022-12-16 05:08:48 --> Helper loaded: url_helper
INFO - 2022-12-16 05:08:48 --> Helper loaded: file_helper
INFO - 2022-12-16 05:08:48 --> Helper loaded: form_helper
INFO - 2022-12-16 05:08:48 --> Helper loaded: my_helper
INFO - 2022-12-16 05:08:48 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:08:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:08:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:08:48 --> Controller Class Initialized
INFO - 2022-12-16 05:08:53 --> Config Class Initialized
INFO - 2022-12-16 05:08:53 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:08:53 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:08:53 --> Utf8 Class Initialized
INFO - 2022-12-16 05:08:53 --> URI Class Initialized
INFO - 2022-12-16 05:08:53 --> Router Class Initialized
INFO - 2022-12-16 05:08:53 --> Output Class Initialized
INFO - 2022-12-16 05:08:53 --> Security Class Initialized
DEBUG - 2022-12-16 05:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:08:53 --> Input Class Initialized
INFO - 2022-12-16 05:08:53 --> Language Class Initialized
INFO - 2022-12-16 05:08:53 --> Language Class Initialized
INFO - 2022-12-16 05:08:53 --> Config Class Initialized
INFO - 2022-12-16 05:08:53 --> Loader Class Initialized
INFO - 2022-12-16 05:08:53 --> Helper loaded: url_helper
INFO - 2022-12-16 05:08:53 --> Helper loaded: file_helper
INFO - 2022-12-16 05:08:53 --> Helper loaded: form_helper
INFO - 2022-12-16 05:08:53 --> Helper loaded: my_helper
INFO - 2022-12-16 05:08:53 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:08:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:08:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:08:53 --> Controller Class Initialized
DEBUG - 2022-12-16 05:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:08:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:08:53 --> Final output sent to browser
DEBUG - 2022-12-16 05:08:53 --> Total execution time: 0.0632
INFO - 2022-12-16 05:09:18 --> Config Class Initialized
INFO - 2022-12-16 05:09:18 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:09:18 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:09:18 --> Utf8 Class Initialized
INFO - 2022-12-16 05:09:18 --> URI Class Initialized
INFO - 2022-12-16 05:09:18 --> Router Class Initialized
INFO - 2022-12-16 05:09:18 --> Output Class Initialized
INFO - 2022-12-16 05:09:18 --> Security Class Initialized
DEBUG - 2022-12-16 05:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:09:18 --> Input Class Initialized
INFO - 2022-12-16 05:09:18 --> Language Class Initialized
INFO - 2022-12-16 05:09:18 --> Language Class Initialized
INFO - 2022-12-16 05:09:18 --> Config Class Initialized
INFO - 2022-12-16 05:09:18 --> Loader Class Initialized
INFO - 2022-12-16 05:09:18 --> Helper loaded: url_helper
INFO - 2022-12-16 05:09:18 --> Helper loaded: file_helper
INFO - 2022-12-16 05:09:18 --> Helper loaded: form_helper
INFO - 2022-12-16 05:09:18 --> Helper loaded: my_helper
INFO - 2022-12-16 05:09:18 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:09:18 --> Controller Class Initialized
DEBUG - 2022-12-16 05:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:09:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:09:18 --> Final output sent to browser
DEBUG - 2022-12-16 05:09:18 --> Total execution time: 0.0606
INFO - 2022-12-16 05:09:18 --> Config Class Initialized
INFO - 2022-12-16 05:09:18 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:09:18 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:09:18 --> Utf8 Class Initialized
INFO - 2022-12-16 05:09:18 --> URI Class Initialized
INFO - 2022-12-16 05:09:18 --> Router Class Initialized
INFO - 2022-12-16 05:09:18 --> Output Class Initialized
INFO - 2022-12-16 05:09:18 --> Security Class Initialized
DEBUG - 2022-12-16 05:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:09:18 --> Input Class Initialized
INFO - 2022-12-16 05:09:18 --> Language Class Initialized
INFO - 2022-12-16 05:09:18 --> Language Class Initialized
INFO - 2022-12-16 05:09:18 --> Config Class Initialized
INFO - 2022-12-16 05:09:18 --> Loader Class Initialized
INFO - 2022-12-16 05:09:18 --> Helper loaded: url_helper
INFO - 2022-12-16 05:09:18 --> Helper loaded: file_helper
INFO - 2022-12-16 05:09:18 --> Helper loaded: form_helper
INFO - 2022-12-16 05:09:18 --> Helper loaded: my_helper
INFO - 2022-12-16 05:09:18 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:09:18 --> Controller Class Initialized
INFO - 2022-12-16 05:09:21 --> Config Class Initialized
INFO - 2022-12-16 05:09:21 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:09:21 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:09:21 --> Utf8 Class Initialized
INFO - 2022-12-16 05:09:21 --> URI Class Initialized
INFO - 2022-12-16 05:09:21 --> Router Class Initialized
INFO - 2022-12-16 05:09:21 --> Output Class Initialized
INFO - 2022-12-16 05:09:21 --> Security Class Initialized
DEBUG - 2022-12-16 05:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:09:21 --> Input Class Initialized
INFO - 2022-12-16 05:09:21 --> Language Class Initialized
INFO - 2022-12-16 05:09:21 --> Language Class Initialized
INFO - 2022-12-16 05:09:21 --> Config Class Initialized
INFO - 2022-12-16 05:09:21 --> Loader Class Initialized
INFO - 2022-12-16 05:09:21 --> Helper loaded: url_helper
INFO - 2022-12-16 05:09:21 --> Helper loaded: file_helper
INFO - 2022-12-16 05:09:21 --> Helper loaded: form_helper
INFO - 2022-12-16 05:09:21 --> Helper loaded: my_helper
INFO - 2022-12-16 05:09:21 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:09:21 --> Controller Class Initialized
ERROR - 2022-12-16 05:09:21 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-12-16 05:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-12-16 05:09:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:09:21 --> Final output sent to browser
DEBUG - 2022-12-16 05:09:21 --> Total execution time: 0.1496
INFO - 2022-12-16 05:11:48 --> Config Class Initialized
INFO - 2022-12-16 05:11:48 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:11:48 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:11:48 --> Utf8 Class Initialized
INFO - 2022-12-16 05:11:48 --> URI Class Initialized
INFO - 2022-12-16 05:11:48 --> Router Class Initialized
INFO - 2022-12-16 05:11:48 --> Output Class Initialized
INFO - 2022-12-16 05:11:48 --> Security Class Initialized
DEBUG - 2022-12-16 05:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:11:48 --> Input Class Initialized
INFO - 2022-12-16 05:11:48 --> Language Class Initialized
INFO - 2022-12-16 05:11:48 --> Language Class Initialized
INFO - 2022-12-16 05:11:48 --> Config Class Initialized
INFO - 2022-12-16 05:11:48 --> Loader Class Initialized
INFO - 2022-12-16 05:11:48 --> Helper loaded: url_helper
INFO - 2022-12-16 05:11:48 --> Helper loaded: file_helper
INFO - 2022-12-16 05:11:48 --> Helper loaded: form_helper
INFO - 2022-12-16 05:11:48 --> Helper loaded: my_helper
INFO - 2022-12-16 05:11:48 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:11:48 --> Controller Class Initialized
DEBUG - 2022-12-16 05:11:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:11:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:11:48 --> Final output sent to browser
DEBUG - 2022-12-16 05:11:48 --> Total execution time: 0.0845
INFO - 2022-12-16 05:11:48 --> Config Class Initialized
INFO - 2022-12-16 05:11:48 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:11:48 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:11:48 --> Utf8 Class Initialized
INFO - 2022-12-16 05:11:48 --> URI Class Initialized
INFO - 2022-12-16 05:11:48 --> Router Class Initialized
INFO - 2022-12-16 05:11:48 --> Output Class Initialized
INFO - 2022-12-16 05:11:48 --> Security Class Initialized
DEBUG - 2022-12-16 05:11:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:11:48 --> Input Class Initialized
INFO - 2022-12-16 05:11:48 --> Language Class Initialized
INFO - 2022-12-16 05:11:48 --> Language Class Initialized
INFO - 2022-12-16 05:11:48 --> Config Class Initialized
INFO - 2022-12-16 05:11:48 --> Loader Class Initialized
INFO - 2022-12-16 05:11:48 --> Helper loaded: url_helper
INFO - 2022-12-16 05:11:48 --> Helper loaded: file_helper
INFO - 2022-12-16 05:11:48 --> Helper loaded: form_helper
INFO - 2022-12-16 05:11:48 --> Helper loaded: my_helper
INFO - 2022-12-16 05:11:48 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:11:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:11:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:11:48 --> Controller Class Initialized
INFO - 2022-12-16 05:11:49 --> Config Class Initialized
INFO - 2022-12-16 05:11:49 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:11:49 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:11:49 --> Utf8 Class Initialized
INFO - 2022-12-16 05:11:49 --> URI Class Initialized
INFO - 2022-12-16 05:11:49 --> Router Class Initialized
INFO - 2022-12-16 05:11:49 --> Output Class Initialized
INFO - 2022-12-16 05:11:50 --> Security Class Initialized
DEBUG - 2022-12-16 05:11:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:11:50 --> Input Class Initialized
INFO - 2022-12-16 05:11:50 --> Language Class Initialized
INFO - 2022-12-16 05:11:50 --> Language Class Initialized
INFO - 2022-12-16 05:11:50 --> Config Class Initialized
INFO - 2022-12-16 05:11:50 --> Loader Class Initialized
INFO - 2022-12-16 05:11:50 --> Helper loaded: url_helper
INFO - 2022-12-16 05:11:50 --> Helper loaded: file_helper
INFO - 2022-12-16 05:11:50 --> Helper loaded: form_helper
INFO - 2022-12-16 05:11:50 --> Helper loaded: my_helper
INFO - 2022-12-16 05:11:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:11:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:11:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:11:50 --> Controller Class Initialized
DEBUG - 2022-12-16 05:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:11:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:11:50 --> Final output sent to browser
DEBUG - 2022-12-16 05:11:50 --> Total execution time: 0.0965
INFO - 2022-12-16 05:11:58 --> Config Class Initialized
INFO - 2022-12-16 05:11:58 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:11:58 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:11:58 --> Utf8 Class Initialized
INFO - 2022-12-16 05:11:58 --> URI Class Initialized
INFO - 2022-12-16 05:11:58 --> Router Class Initialized
INFO - 2022-12-16 05:11:58 --> Output Class Initialized
INFO - 2022-12-16 05:11:58 --> Security Class Initialized
DEBUG - 2022-12-16 05:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:11:58 --> Input Class Initialized
INFO - 2022-12-16 05:11:58 --> Language Class Initialized
INFO - 2022-12-16 05:11:58 --> Language Class Initialized
INFO - 2022-12-16 05:11:58 --> Config Class Initialized
INFO - 2022-12-16 05:11:58 --> Loader Class Initialized
INFO - 2022-12-16 05:11:58 --> Helper loaded: url_helper
INFO - 2022-12-16 05:11:58 --> Helper loaded: file_helper
INFO - 2022-12-16 05:11:58 --> Helper loaded: form_helper
INFO - 2022-12-16 05:11:58 --> Helper loaded: my_helper
INFO - 2022-12-16 05:11:58 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:11:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:11:58 --> Controller Class Initialized
INFO - 2022-12-16 05:12:00 --> Config Class Initialized
INFO - 2022-12-16 05:12:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:12:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:12:00 --> Utf8 Class Initialized
INFO - 2022-12-16 05:12:00 --> URI Class Initialized
INFO - 2022-12-16 05:12:00 --> Router Class Initialized
INFO - 2022-12-16 05:12:00 --> Output Class Initialized
INFO - 2022-12-16 05:12:00 --> Security Class Initialized
DEBUG - 2022-12-16 05:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:12:00 --> Input Class Initialized
INFO - 2022-12-16 05:12:00 --> Language Class Initialized
INFO - 2022-12-16 05:12:00 --> Language Class Initialized
INFO - 2022-12-16 05:12:00 --> Config Class Initialized
INFO - 2022-12-16 05:12:00 --> Loader Class Initialized
INFO - 2022-12-16 05:12:00 --> Helper loaded: url_helper
INFO - 2022-12-16 05:12:00 --> Helper loaded: file_helper
INFO - 2022-12-16 05:12:00 --> Helper loaded: form_helper
INFO - 2022-12-16 05:12:00 --> Helper loaded: my_helper
INFO - 2022-12-16 05:12:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:12:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:12:00 --> Controller Class Initialized
DEBUG - 2022-12-16 05:12:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:12:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:12:00 --> Final output sent to browser
DEBUG - 2022-12-16 05:12:00 --> Total execution time: 0.0432
INFO - 2022-12-16 05:12:02 --> Config Class Initialized
INFO - 2022-12-16 05:12:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:12:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:12:02 --> Utf8 Class Initialized
INFO - 2022-12-16 05:12:02 --> URI Class Initialized
INFO - 2022-12-16 05:12:02 --> Router Class Initialized
INFO - 2022-12-16 05:12:02 --> Output Class Initialized
INFO - 2022-12-16 05:12:02 --> Security Class Initialized
DEBUG - 2022-12-16 05:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:12:02 --> Input Class Initialized
INFO - 2022-12-16 05:12:02 --> Language Class Initialized
INFO - 2022-12-16 05:12:02 --> Language Class Initialized
INFO - 2022-12-16 05:12:02 --> Config Class Initialized
INFO - 2022-12-16 05:12:02 --> Loader Class Initialized
INFO - 2022-12-16 05:12:02 --> Helper loaded: url_helper
INFO - 2022-12-16 05:12:02 --> Helper loaded: file_helper
INFO - 2022-12-16 05:12:02 --> Helper loaded: form_helper
INFO - 2022-12-16 05:12:02 --> Helper loaded: my_helper
INFO - 2022-12-16 05:12:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:12:02 --> Controller Class Initialized
DEBUG - 2022-12-16 05:12:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:12:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:12:02 --> Final output sent to browser
DEBUG - 2022-12-16 05:12:02 --> Total execution time: 0.0872
INFO - 2022-12-16 05:12:02 --> Config Class Initialized
INFO - 2022-12-16 05:12:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:12:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:12:02 --> Utf8 Class Initialized
INFO - 2022-12-16 05:12:02 --> URI Class Initialized
INFO - 2022-12-16 05:12:02 --> Router Class Initialized
INFO - 2022-12-16 05:12:02 --> Output Class Initialized
INFO - 2022-12-16 05:12:02 --> Security Class Initialized
DEBUG - 2022-12-16 05:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:12:02 --> Input Class Initialized
INFO - 2022-12-16 05:12:02 --> Language Class Initialized
INFO - 2022-12-16 05:12:02 --> Language Class Initialized
INFO - 2022-12-16 05:12:02 --> Config Class Initialized
INFO - 2022-12-16 05:12:02 --> Loader Class Initialized
INFO - 2022-12-16 05:12:02 --> Helper loaded: url_helper
INFO - 2022-12-16 05:12:02 --> Helper loaded: file_helper
INFO - 2022-12-16 05:12:02 --> Helper loaded: form_helper
INFO - 2022-12-16 05:12:02 --> Helper loaded: my_helper
INFO - 2022-12-16 05:12:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:12:02 --> Controller Class Initialized
INFO - 2022-12-16 05:19:08 --> Config Class Initialized
INFO - 2022-12-16 05:19:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:19:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:19:08 --> Utf8 Class Initialized
INFO - 2022-12-16 05:19:08 --> URI Class Initialized
INFO - 2022-12-16 05:19:08 --> Router Class Initialized
INFO - 2022-12-16 05:19:08 --> Output Class Initialized
INFO - 2022-12-16 05:19:08 --> Security Class Initialized
DEBUG - 2022-12-16 05:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:19:08 --> Input Class Initialized
INFO - 2022-12-16 05:19:08 --> Language Class Initialized
INFO - 2022-12-16 05:19:08 --> Language Class Initialized
INFO - 2022-12-16 05:19:08 --> Config Class Initialized
INFO - 2022-12-16 05:19:08 --> Loader Class Initialized
INFO - 2022-12-16 05:19:08 --> Helper loaded: url_helper
INFO - 2022-12-16 05:19:08 --> Helper loaded: file_helper
INFO - 2022-12-16 05:19:08 --> Helper loaded: form_helper
INFO - 2022-12-16 05:19:08 --> Helper loaded: my_helper
INFO - 2022-12-16 05:19:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:19:08 --> Controller Class Initialized
DEBUG - 2022-12-16 05:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:19:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:19:08 --> Final output sent to browser
DEBUG - 2022-12-16 05:19:08 --> Total execution time: 0.0652
INFO - 2022-12-16 05:19:08 --> Config Class Initialized
INFO - 2022-12-16 05:19:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:19:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:19:08 --> Utf8 Class Initialized
INFO - 2022-12-16 05:19:08 --> URI Class Initialized
INFO - 2022-12-16 05:19:08 --> Router Class Initialized
INFO - 2022-12-16 05:19:08 --> Output Class Initialized
INFO - 2022-12-16 05:19:08 --> Security Class Initialized
DEBUG - 2022-12-16 05:19:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:19:08 --> Input Class Initialized
INFO - 2022-12-16 05:19:08 --> Language Class Initialized
INFO - 2022-12-16 05:19:08 --> Language Class Initialized
INFO - 2022-12-16 05:19:08 --> Config Class Initialized
INFO - 2022-12-16 05:19:08 --> Loader Class Initialized
INFO - 2022-12-16 05:19:08 --> Helper loaded: url_helper
INFO - 2022-12-16 05:19:08 --> Helper loaded: file_helper
INFO - 2022-12-16 05:19:08 --> Helper loaded: form_helper
INFO - 2022-12-16 05:19:08 --> Helper loaded: my_helper
INFO - 2022-12-16 05:19:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:19:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:19:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:19:08 --> Controller Class Initialized
INFO - 2022-12-16 05:19:09 --> Config Class Initialized
INFO - 2022-12-16 05:19:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:19:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:19:09 --> Utf8 Class Initialized
INFO - 2022-12-16 05:19:09 --> URI Class Initialized
INFO - 2022-12-16 05:19:09 --> Router Class Initialized
INFO - 2022-12-16 05:19:09 --> Output Class Initialized
INFO - 2022-12-16 05:19:09 --> Security Class Initialized
DEBUG - 2022-12-16 05:19:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:19:09 --> Input Class Initialized
INFO - 2022-12-16 05:19:09 --> Language Class Initialized
INFO - 2022-12-16 05:19:09 --> Language Class Initialized
INFO - 2022-12-16 05:19:09 --> Config Class Initialized
INFO - 2022-12-16 05:19:09 --> Loader Class Initialized
INFO - 2022-12-16 05:19:09 --> Helper loaded: url_helper
INFO - 2022-12-16 05:19:09 --> Helper loaded: file_helper
INFO - 2022-12-16 05:19:09 --> Helper loaded: form_helper
INFO - 2022-12-16 05:19:09 --> Helper loaded: my_helper
INFO - 2022-12-16 05:19:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:19:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:19:09 --> Controller Class Initialized
DEBUG - 2022-12-16 05:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:19:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:19:09 --> Final output sent to browser
DEBUG - 2022-12-16 05:19:09 --> Total execution time: 0.0769
INFO - 2022-12-16 05:22:39 --> Config Class Initialized
INFO - 2022-12-16 05:22:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:22:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:22:39 --> Utf8 Class Initialized
INFO - 2022-12-16 05:22:39 --> URI Class Initialized
INFO - 2022-12-16 05:22:39 --> Router Class Initialized
INFO - 2022-12-16 05:22:39 --> Output Class Initialized
INFO - 2022-12-16 05:22:39 --> Security Class Initialized
DEBUG - 2022-12-16 05:22:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:22:39 --> Input Class Initialized
INFO - 2022-12-16 05:22:39 --> Language Class Initialized
INFO - 2022-12-16 05:22:39 --> Language Class Initialized
INFO - 2022-12-16 05:22:39 --> Config Class Initialized
INFO - 2022-12-16 05:22:39 --> Loader Class Initialized
INFO - 2022-12-16 05:22:39 --> Helper loaded: url_helper
INFO - 2022-12-16 05:22:39 --> Helper loaded: file_helper
INFO - 2022-12-16 05:22:39 --> Helper loaded: form_helper
INFO - 2022-12-16 05:22:39 --> Helper loaded: my_helper
INFO - 2022-12-16 05:22:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:22:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:22:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:22:39 --> Controller Class Initialized
INFO - 2022-12-16 05:22:41 --> Config Class Initialized
INFO - 2022-12-16 05:22:41 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:22:41 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:22:41 --> Utf8 Class Initialized
INFO - 2022-12-16 05:22:41 --> URI Class Initialized
INFO - 2022-12-16 05:22:41 --> Router Class Initialized
INFO - 2022-12-16 05:22:41 --> Output Class Initialized
INFO - 2022-12-16 05:22:41 --> Security Class Initialized
DEBUG - 2022-12-16 05:22:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:22:41 --> Input Class Initialized
INFO - 2022-12-16 05:22:41 --> Language Class Initialized
INFO - 2022-12-16 05:22:41 --> Language Class Initialized
INFO - 2022-12-16 05:22:41 --> Config Class Initialized
INFO - 2022-12-16 05:22:41 --> Loader Class Initialized
INFO - 2022-12-16 05:22:41 --> Helper loaded: url_helper
INFO - 2022-12-16 05:22:41 --> Helper loaded: file_helper
INFO - 2022-12-16 05:22:41 --> Helper loaded: form_helper
INFO - 2022-12-16 05:22:41 --> Helper loaded: my_helper
INFO - 2022-12-16 05:22:41 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:22:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:22:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:22:41 --> Controller Class Initialized
DEBUG - 2022-12-16 05:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form_import.php
DEBUG - 2022-12-16 05:22:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:22:41 --> Final output sent to browser
DEBUG - 2022-12-16 05:22:41 --> Total execution time: 0.0645
INFO - 2022-12-16 05:22:43 --> Config Class Initialized
INFO - 2022-12-16 05:22:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:22:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:22:43 --> Utf8 Class Initialized
INFO - 2022-12-16 05:22:43 --> URI Class Initialized
INFO - 2022-12-16 05:22:43 --> Router Class Initialized
INFO - 2022-12-16 05:22:43 --> Output Class Initialized
INFO - 2022-12-16 05:22:43 --> Security Class Initialized
DEBUG - 2022-12-16 05:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:22:43 --> Input Class Initialized
INFO - 2022-12-16 05:22:43 --> Language Class Initialized
INFO - 2022-12-16 05:22:43 --> Language Class Initialized
INFO - 2022-12-16 05:22:43 --> Config Class Initialized
INFO - 2022-12-16 05:22:43 --> Loader Class Initialized
INFO - 2022-12-16 05:22:43 --> Helper loaded: url_helper
INFO - 2022-12-16 05:22:43 --> Helper loaded: file_helper
INFO - 2022-12-16 05:22:43 --> Helper loaded: form_helper
INFO - 2022-12-16 05:22:43 --> Helper loaded: my_helper
INFO - 2022-12-16 05:22:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:22:43 --> Controller Class Initialized
DEBUG - 2022-12-16 05:22:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:22:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:22:43 --> Final output sent to browser
DEBUG - 2022-12-16 05:22:43 --> Total execution time: 0.0618
INFO - 2022-12-16 05:22:43 --> Config Class Initialized
INFO - 2022-12-16 05:22:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:22:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:22:43 --> Utf8 Class Initialized
INFO - 2022-12-16 05:22:43 --> URI Class Initialized
INFO - 2022-12-16 05:22:43 --> Router Class Initialized
INFO - 2022-12-16 05:22:43 --> Output Class Initialized
INFO - 2022-12-16 05:22:43 --> Security Class Initialized
DEBUG - 2022-12-16 05:22:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:22:43 --> Input Class Initialized
INFO - 2022-12-16 05:22:43 --> Language Class Initialized
INFO - 2022-12-16 05:22:43 --> Language Class Initialized
INFO - 2022-12-16 05:22:43 --> Config Class Initialized
INFO - 2022-12-16 05:22:43 --> Loader Class Initialized
INFO - 2022-12-16 05:22:43 --> Helper loaded: url_helper
INFO - 2022-12-16 05:22:43 --> Helper loaded: file_helper
INFO - 2022-12-16 05:22:43 --> Helper loaded: form_helper
INFO - 2022-12-16 05:22:43 --> Helper loaded: my_helper
INFO - 2022-12-16 05:22:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:22:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:22:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:22:43 --> Controller Class Initialized
INFO - 2022-12-16 05:23:25 --> Config Class Initialized
INFO - 2022-12-16 05:23:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:23:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:23:25 --> Utf8 Class Initialized
INFO - 2022-12-16 05:23:25 --> URI Class Initialized
INFO - 2022-12-16 05:23:25 --> Router Class Initialized
INFO - 2022-12-16 05:23:25 --> Output Class Initialized
INFO - 2022-12-16 05:23:25 --> Security Class Initialized
DEBUG - 2022-12-16 05:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:23:25 --> Input Class Initialized
INFO - 2022-12-16 05:23:25 --> Language Class Initialized
INFO - 2022-12-16 05:23:25 --> Language Class Initialized
INFO - 2022-12-16 05:23:25 --> Config Class Initialized
INFO - 2022-12-16 05:23:25 --> Loader Class Initialized
INFO - 2022-12-16 05:23:25 --> Helper loaded: url_helper
INFO - 2022-12-16 05:23:25 --> Helper loaded: file_helper
INFO - 2022-12-16 05:23:25 --> Helper loaded: form_helper
INFO - 2022-12-16 05:23:25 --> Helper loaded: my_helper
INFO - 2022-12-16 05:23:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:23:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:23:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:23:25 --> Controller Class Initialized
DEBUG - 2022-12-16 05:23:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:23:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:23:25 --> Final output sent to browser
DEBUG - 2022-12-16 05:23:25 --> Total execution time: 0.0781
INFO - 2022-12-16 05:23:27 --> Config Class Initialized
INFO - 2022-12-16 05:23:27 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:23:27 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:23:27 --> Utf8 Class Initialized
INFO - 2022-12-16 05:23:27 --> URI Class Initialized
INFO - 2022-12-16 05:23:27 --> Router Class Initialized
INFO - 2022-12-16 05:23:27 --> Output Class Initialized
INFO - 2022-12-16 05:23:27 --> Security Class Initialized
DEBUG - 2022-12-16 05:23:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:23:27 --> Input Class Initialized
INFO - 2022-12-16 05:23:27 --> Language Class Initialized
INFO - 2022-12-16 05:23:27 --> Language Class Initialized
INFO - 2022-12-16 05:23:27 --> Config Class Initialized
INFO - 2022-12-16 05:23:27 --> Loader Class Initialized
INFO - 2022-12-16 05:23:27 --> Helper loaded: url_helper
INFO - 2022-12-16 05:23:27 --> Helper loaded: file_helper
INFO - 2022-12-16 05:23:27 --> Helper loaded: form_helper
INFO - 2022-12-16 05:23:27 --> Helper loaded: my_helper
INFO - 2022-12-16 05:23:27 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:23:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:23:27 --> Controller Class Initialized
DEBUG - 2022-12-16 05:23:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:23:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:23:27 --> Final output sent to browser
DEBUG - 2022-12-16 05:23:27 --> Total execution time: 0.0852
INFO - 2022-12-16 05:23:46 --> Config Class Initialized
INFO - 2022-12-16 05:23:46 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:23:46 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:23:46 --> Utf8 Class Initialized
INFO - 2022-12-16 05:23:46 --> URI Class Initialized
INFO - 2022-12-16 05:23:46 --> Router Class Initialized
INFO - 2022-12-16 05:23:46 --> Output Class Initialized
INFO - 2022-12-16 05:23:46 --> Security Class Initialized
DEBUG - 2022-12-16 05:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:23:46 --> Input Class Initialized
INFO - 2022-12-16 05:23:46 --> Language Class Initialized
INFO - 2022-12-16 05:23:46 --> Language Class Initialized
INFO - 2022-12-16 05:23:46 --> Config Class Initialized
INFO - 2022-12-16 05:23:46 --> Loader Class Initialized
INFO - 2022-12-16 05:23:46 --> Helper loaded: url_helper
INFO - 2022-12-16 05:23:46 --> Helper loaded: file_helper
INFO - 2022-12-16 05:23:46 --> Helper loaded: form_helper
INFO - 2022-12-16 05:23:46 --> Helper loaded: my_helper
INFO - 2022-12-16 05:23:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:23:46 --> Controller Class Initialized
DEBUG - 2022-12-16 05:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:23:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:23:46 --> Final output sent to browser
DEBUG - 2022-12-16 05:23:46 --> Total execution time: 0.0855
INFO - 2022-12-16 05:23:46 --> Config Class Initialized
INFO - 2022-12-16 05:23:46 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:23:46 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:23:46 --> Utf8 Class Initialized
INFO - 2022-12-16 05:23:46 --> URI Class Initialized
INFO - 2022-12-16 05:23:46 --> Router Class Initialized
INFO - 2022-12-16 05:23:46 --> Output Class Initialized
INFO - 2022-12-16 05:23:46 --> Security Class Initialized
DEBUG - 2022-12-16 05:23:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:23:46 --> Input Class Initialized
INFO - 2022-12-16 05:23:46 --> Language Class Initialized
INFO - 2022-12-16 05:23:46 --> Language Class Initialized
INFO - 2022-12-16 05:23:46 --> Config Class Initialized
INFO - 2022-12-16 05:23:46 --> Loader Class Initialized
INFO - 2022-12-16 05:23:46 --> Helper loaded: url_helper
INFO - 2022-12-16 05:23:46 --> Helper loaded: file_helper
INFO - 2022-12-16 05:23:46 --> Helper loaded: form_helper
INFO - 2022-12-16 05:23:46 --> Helper loaded: my_helper
INFO - 2022-12-16 05:23:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:23:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:23:46 --> Controller Class Initialized
INFO - 2022-12-16 05:24:24 --> Config Class Initialized
INFO - 2022-12-16 05:24:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:24:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:24:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:24:24 --> URI Class Initialized
INFO - 2022-12-16 05:24:24 --> Router Class Initialized
INFO - 2022-12-16 05:24:24 --> Output Class Initialized
INFO - 2022-12-16 05:24:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:24:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:24:24 --> Input Class Initialized
INFO - 2022-12-16 05:24:24 --> Language Class Initialized
INFO - 2022-12-16 05:24:24 --> Language Class Initialized
INFO - 2022-12-16 05:24:24 --> Config Class Initialized
INFO - 2022-12-16 05:24:24 --> Loader Class Initialized
INFO - 2022-12-16 05:24:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:24:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:24:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:24:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:24:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:24:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:24:24 --> Controller Class Initialized
DEBUG - 2022-12-16 05:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:24:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:24:24 --> Final output sent to browser
DEBUG - 2022-12-16 05:24:24 --> Total execution time: 0.0715
INFO - 2022-12-16 05:24:25 --> Config Class Initialized
INFO - 2022-12-16 05:24:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:24:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:24:25 --> Utf8 Class Initialized
INFO - 2022-12-16 05:24:25 --> URI Class Initialized
INFO - 2022-12-16 05:24:25 --> Router Class Initialized
INFO - 2022-12-16 05:24:25 --> Output Class Initialized
INFO - 2022-12-16 05:24:25 --> Security Class Initialized
DEBUG - 2022-12-16 05:24:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:24:25 --> Input Class Initialized
INFO - 2022-12-16 05:24:25 --> Language Class Initialized
INFO - 2022-12-16 05:24:25 --> Language Class Initialized
INFO - 2022-12-16 05:24:25 --> Config Class Initialized
INFO - 2022-12-16 05:24:25 --> Loader Class Initialized
INFO - 2022-12-16 05:24:25 --> Helper loaded: url_helper
INFO - 2022-12-16 05:24:25 --> Helper loaded: file_helper
INFO - 2022-12-16 05:24:25 --> Helper loaded: form_helper
INFO - 2022-12-16 05:24:25 --> Helper loaded: my_helper
INFO - 2022-12-16 05:24:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:24:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:24:25 --> Controller Class Initialized
DEBUG - 2022-12-16 05:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:24:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:24:25 --> Final output sent to browser
DEBUG - 2022-12-16 05:24:25 --> Total execution time: 0.0689
INFO - 2022-12-16 05:24:50 --> Config Class Initialized
INFO - 2022-12-16 05:24:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:24:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:24:50 --> Utf8 Class Initialized
INFO - 2022-12-16 05:24:50 --> URI Class Initialized
INFO - 2022-12-16 05:24:50 --> Router Class Initialized
INFO - 2022-12-16 05:24:50 --> Output Class Initialized
INFO - 2022-12-16 05:24:50 --> Security Class Initialized
DEBUG - 2022-12-16 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:24:50 --> Input Class Initialized
INFO - 2022-12-16 05:24:50 --> Language Class Initialized
INFO - 2022-12-16 05:24:50 --> Language Class Initialized
INFO - 2022-12-16 05:24:50 --> Config Class Initialized
INFO - 2022-12-16 05:24:50 --> Loader Class Initialized
INFO - 2022-12-16 05:24:50 --> Helper loaded: url_helper
INFO - 2022-12-16 05:24:50 --> Helper loaded: file_helper
INFO - 2022-12-16 05:24:50 --> Helper loaded: form_helper
INFO - 2022-12-16 05:24:50 --> Helper loaded: my_helper
INFO - 2022-12-16 05:24:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:24:50 --> Controller Class Initialized
INFO - 2022-12-16 05:24:50 --> Config Class Initialized
INFO - 2022-12-16 05:24:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:24:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:24:50 --> Utf8 Class Initialized
INFO - 2022-12-16 05:24:50 --> URI Class Initialized
INFO - 2022-12-16 05:24:50 --> Router Class Initialized
INFO - 2022-12-16 05:24:50 --> Output Class Initialized
INFO - 2022-12-16 05:24:50 --> Security Class Initialized
DEBUG - 2022-12-16 05:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:24:50 --> Input Class Initialized
INFO - 2022-12-16 05:24:50 --> Language Class Initialized
INFO - 2022-12-16 05:24:50 --> Language Class Initialized
INFO - 2022-12-16 05:24:50 --> Config Class Initialized
INFO - 2022-12-16 05:24:50 --> Loader Class Initialized
INFO - 2022-12-16 05:24:50 --> Helper loaded: url_helper
INFO - 2022-12-16 05:24:50 --> Helper loaded: file_helper
INFO - 2022-12-16 05:24:50 --> Helper loaded: form_helper
INFO - 2022-12-16 05:24:50 --> Helper loaded: my_helper
INFO - 2022-12-16 05:24:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:24:50 --> Controller Class Initialized
DEBUG - 2022-12-16 05:24:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:24:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:24:50 --> Final output sent to browser
DEBUG - 2022-12-16 05:24:50 --> Total execution time: 0.0731
INFO - 2022-12-16 05:25:01 --> Config Class Initialized
INFO - 2022-12-16 05:25:01 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:01 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:01 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:01 --> URI Class Initialized
INFO - 2022-12-16 05:25:01 --> Router Class Initialized
INFO - 2022-12-16 05:25:01 --> Output Class Initialized
INFO - 2022-12-16 05:25:01 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:01 --> Input Class Initialized
INFO - 2022-12-16 05:25:01 --> Language Class Initialized
INFO - 2022-12-16 05:25:01 --> Language Class Initialized
INFO - 2022-12-16 05:25:01 --> Config Class Initialized
INFO - 2022-12-16 05:25:01 --> Loader Class Initialized
INFO - 2022-12-16 05:25:01 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:01 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:01 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:01 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:01 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:01 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:25:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:01 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:01 --> Total execution time: 0.0797
INFO - 2022-12-16 05:25:15 --> Config Class Initialized
INFO - 2022-12-16 05:25:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:15 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:15 --> URI Class Initialized
INFO - 2022-12-16 05:25:15 --> Router Class Initialized
INFO - 2022-12-16 05:25:15 --> Output Class Initialized
INFO - 2022-12-16 05:25:15 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:15 --> Input Class Initialized
INFO - 2022-12-16 05:25:15 --> Language Class Initialized
INFO - 2022-12-16 05:25:15 --> Language Class Initialized
INFO - 2022-12-16 05:25:15 --> Config Class Initialized
INFO - 2022-12-16 05:25:15 --> Loader Class Initialized
INFO - 2022-12-16 05:25:15 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:15 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:15 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:15 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:15 --> Controller Class Initialized
INFO - 2022-12-16 05:25:15 --> Config Class Initialized
INFO - 2022-12-16 05:25:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:15 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:15 --> URI Class Initialized
INFO - 2022-12-16 05:25:15 --> Router Class Initialized
INFO - 2022-12-16 05:25:15 --> Output Class Initialized
INFO - 2022-12-16 05:25:15 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:15 --> Input Class Initialized
INFO - 2022-12-16 05:25:15 --> Language Class Initialized
INFO - 2022-12-16 05:25:15 --> Language Class Initialized
INFO - 2022-12-16 05:25:15 --> Config Class Initialized
INFO - 2022-12-16 05:25:15 --> Loader Class Initialized
INFO - 2022-12-16 05:25:15 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:15 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:15 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:15 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:15 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:25:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:15 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:15 --> Total execution time: 0.0645
INFO - 2022-12-16 05:25:16 --> Config Class Initialized
INFO - 2022-12-16 05:25:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:16 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:16 --> URI Class Initialized
INFO - 2022-12-16 05:25:16 --> Router Class Initialized
INFO - 2022-12-16 05:25:16 --> Output Class Initialized
INFO - 2022-12-16 05:25:16 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:16 --> Input Class Initialized
INFO - 2022-12-16 05:25:16 --> Language Class Initialized
INFO - 2022-12-16 05:25:16 --> Language Class Initialized
INFO - 2022-12-16 05:25:16 --> Config Class Initialized
INFO - 2022-12-16 05:25:16 --> Loader Class Initialized
INFO - 2022-12-16 05:25:16 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:16 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:16 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:16 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:16 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:25:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:16 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:16 --> Total execution time: 0.0654
INFO - 2022-12-16 05:25:24 --> Config Class Initialized
INFO - 2022-12-16 05:25:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:24 --> URI Class Initialized
INFO - 2022-12-16 05:25:24 --> Router Class Initialized
INFO - 2022-12-16 05:25:24 --> Output Class Initialized
INFO - 2022-12-16 05:25:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:24 --> Input Class Initialized
INFO - 2022-12-16 05:25:24 --> Language Class Initialized
INFO - 2022-12-16 05:25:24 --> Language Class Initialized
INFO - 2022-12-16 05:25:24 --> Config Class Initialized
INFO - 2022-12-16 05:25:24 --> Loader Class Initialized
INFO - 2022-12-16 05:25:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:25 --> Controller Class Initialized
INFO - 2022-12-16 05:25:25 --> Config Class Initialized
INFO - 2022-12-16 05:25:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:25 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:25 --> URI Class Initialized
INFO - 2022-12-16 05:25:25 --> Router Class Initialized
INFO - 2022-12-16 05:25:25 --> Output Class Initialized
INFO - 2022-12-16 05:25:25 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:25 --> Input Class Initialized
INFO - 2022-12-16 05:25:25 --> Language Class Initialized
INFO - 2022-12-16 05:25:25 --> Language Class Initialized
INFO - 2022-12-16 05:25:25 --> Config Class Initialized
INFO - 2022-12-16 05:25:25 --> Loader Class Initialized
INFO - 2022-12-16 05:25:25 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:25 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:25 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:25 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:25 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:25:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:25 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:25 --> Total execution time: 0.0789
INFO - 2022-12-16 05:25:26 --> Config Class Initialized
INFO - 2022-12-16 05:25:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:26 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:26 --> URI Class Initialized
INFO - 2022-12-16 05:25:26 --> Router Class Initialized
INFO - 2022-12-16 05:25:26 --> Output Class Initialized
INFO - 2022-12-16 05:25:26 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:26 --> Input Class Initialized
INFO - 2022-12-16 05:25:26 --> Language Class Initialized
INFO - 2022-12-16 05:25:26 --> Language Class Initialized
INFO - 2022-12-16 05:25:26 --> Config Class Initialized
INFO - 2022-12-16 05:25:26 --> Loader Class Initialized
INFO - 2022-12-16 05:25:26 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:26 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:26 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:26 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:26 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:26 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:26 --> Total execution time: 0.0858
INFO - 2022-12-16 05:25:40 --> Config Class Initialized
INFO - 2022-12-16 05:25:40 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:40 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:40 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:40 --> URI Class Initialized
INFO - 2022-12-16 05:25:40 --> Router Class Initialized
INFO - 2022-12-16 05:25:40 --> Output Class Initialized
INFO - 2022-12-16 05:25:40 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:40 --> Input Class Initialized
INFO - 2022-12-16 05:25:40 --> Language Class Initialized
INFO - 2022-12-16 05:25:40 --> Language Class Initialized
INFO - 2022-12-16 05:25:40 --> Config Class Initialized
INFO - 2022-12-16 05:25:40 --> Loader Class Initialized
INFO - 2022-12-16 05:25:40 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:40 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:40 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:40 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:40 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:40 --> Controller Class Initialized
INFO - 2022-12-16 05:25:40 --> Config Class Initialized
INFO - 2022-12-16 05:25:40 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:40 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:40 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:40 --> URI Class Initialized
INFO - 2022-12-16 05:25:40 --> Router Class Initialized
INFO - 2022-12-16 05:25:40 --> Output Class Initialized
INFO - 2022-12-16 05:25:40 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:40 --> Input Class Initialized
INFO - 2022-12-16 05:25:40 --> Language Class Initialized
INFO - 2022-12-16 05:25:40 --> Language Class Initialized
INFO - 2022-12-16 05:25:40 --> Config Class Initialized
INFO - 2022-12-16 05:25:40 --> Loader Class Initialized
INFO - 2022-12-16 05:25:40 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:40 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:40 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:40 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:40 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:40 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:25:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:40 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:40 --> Total execution time: 0.0671
INFO - 2022-12-16 05:25:41 --> Config Class Initialized
INFO - 2022-12-16 05:25:41 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:41 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:41 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:41 --> URI Class Initialized
INFO - 2022-12-16 05:25:41 --> Router Class Initialized
INFO - 2022-12-16 05:25:41 --> Output Class Initialized
INFO - 2022-12-16 05:25:41 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:41 --> Input Class Initialized
INFO - 2022-12-16 05:25:41 --> Language Class Initialized
INFO - 2022-12-16 05:25:41 --> Language Class Initialized
INFO - 2022-12-16 05:25:41 --> Config Class Initialized
INFO - 2022-12-16 05:25:41 --> Loader Class Initialized
INFO - 2022-12-16 05:25:41 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:41 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:41 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:41 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:41 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:41 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:25:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:41 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:41 --> Total execution time: 0.0854
INFO - 2022-12-16 05:25:51 --> Config Class Initialized
INFO - 2022-12-16 05:25:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:51 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:51 --> URI Class Initialized
INFO - 2022-12-16 05:25:51 --> Router Class Initialized
INFO - 2022-12-16 05:25:51 --> Output Class Initialized
INFO - 2022-12-16 05:25:51 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:51 --> Input Class Initialized
INFO - 2022-12-16 05:25:51 --> Language Class Initialized
INFO - 2022-12-16 05:25:51 --> Language Class Initialized
INFO - 2022-12-16 05:25:51 --> Config Class Initialized
INFO - 2022-12-16 05:25:51 --> Loader Class Initialized
INFO - 2022-12-16 05:25:51 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:51 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:51 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:51 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:51 --> Controller Class Initialized
INFO - 2022-12-16 05:25:51 --> Config Class Initialized
INFO - 2022-12-16 05:25:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:51 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:51 --> URI Class Initialized
INFO - 2022-12-16 05:25:51 --> Router Class Initialized
INFO - 2022-12-16 05:25:51 --> Output Class Initialized
INFO - 2022-12-16 05:25:51 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:51 --> Input Class Initialized
INFO - 2022-12-16 05:25:51 --> Language Class Initialized
INFO - 2022-12-16 05:25:51 --> Language Class Initialized
INFO - 2022-12-16 05:25:51 --> Config Class Initialized
INFO - 2022-12-16 05:25:51 --> Loader Class Initialized
INFO - 2022-12-16 05:25:51 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:51 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:51 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:51 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:51 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:25:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:51 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:51 --> Total execution time: 0.0847
INFO - 2022-12-16 05:25:53 --> Config Class Initialized
INFO - 2022-12-16 05:25:53 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:25:53 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:25:53 --> Utf8 Class Initialized
INFO - 2022-12-16 05:25:53 --> URI Class Initialized
INFO - 2022-12-16 05:25:53 --> Router Class Initialized
INFO - 2022-12-16 05:25:53 --> Output Class Initialized
INFO - 2022-12-16 05:25:53 --> Security Class Initialized
DEBUG - 2022-12-16 05:25:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:25:53 --> Input Class Initialized
INFO - 2022-12-16 05:25:53 --> Language Class Initialized
INFO - 2022-12-16 05:25:53 --> Language Class Initialized
INFO - 2022-12-16 05:25:53 --> Config Class Initialized
INFO - 2022-12-16 05:25:53 --> Loader Class Initialized
INFO - 2022-12-16 05:25:53 --> Helper loaded: url_helper
INFO - 2022-12-16 05:25:53 --> Helper loaded: file_helper
INFO - 2022-12-16 05:25:53 --> Helper loaded: form_helper
INFO - 2022-12-16 05:25:53 --> Helper loaded: my_helper
INFO - 2022-12-16 05:25:53 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:25:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:25:53 --> Controller Class Initialized
DEBUG - 2022-12-16 05:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:25:53 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:25:53 --> Final output sent to browser
DEBUG - 2022-12-16 05:25:53 --> Total execution time: 0.0821
INFO - 2022-12-16 05:26:23 --> Config Class Initialized
INFO - 2022-12-16 05:26:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:26:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:26:23 --> Utf8 Class Initialized
INFO - 2022-12-16 05:26:23 --> URI Class Initialized
INFO - 2022-12-16 05:26:23 --> Router Class Initialized
INFO - 2022-12-16 05:26:23 --> Output Class Initialized
INFO - 2022-12-16 05:26:23 --> Security Class Initialized
DEBUG - 2022-12-16 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:26:23 --> Input Class Initialized
INFO - 2022-12-16 05:26:23 --> Language Class Initialized
INFO - 2022-12-16 05:26:23 --> Language Class Initialized
INFO - 2022-12-16 05:26:23 --> Config Class Initialized
INFO - 2022-12-16 05:26:23 --> Loader Class Initialized
INFO - 2022-12-16 05:26:23 --> Helper loaded: url_helper
INFO - 2022-12-16 05:26:23 --> Helper loaded: file_helper
INFO - 2022-12-16 05:26:23 --> Helper loaded: form_helper
INFO - 2022-12-16 05:26:23 --> Helper loaded: my_helper
INFO - 2022-12-16 05:26:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:26:23 --> Controller Class Initialized
INFO - 2022-12-16 05:26:23 --> Config Class Initialized
INFO - 2022-12-16 05:26:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:26:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:26:23 --> Utf8 Class Initialized
INFO - 2022-12-16 05:26:23 --> URI Class Initialized
INFO - 2022-12-16 05:26:23 --> Router Class Initialized
INFO - 2022-12-16 05:26:23 --> Output Class Initialized
INFO - 2022-12-16 05:26:23 --> Security Class Initialized
DEBUG - 2022-12-16 05:26:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:26:23 --> Input Class Initialized
INFO - 2022-12-16 05:26:23 --> Language Class Initialized
INFO - 2022-12-16 05:26:23 --> Language Class Initialized
INFO - 2022-12-16 05:26:23 --> Config Class Initialized
INFO - 2022-12-16 05:26:23 --> Loader Class Initialized
INFO - 2022-12-16 05:26:23 --> Helper loaded: url_helper
INFO - 2022-12-16 05:26:23 --> Helper loaded: file_helper
INFO - 2022-12-16 05:26:23 --> Helper loaded: form_helper
INFO - 2022-12-16 05:26:23 --> Helper loaded: my_helper
INFO - 2022-12-16 05:26:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:26:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:26:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:26:23 --> Controller Class Initialized
DEBUG - 2022-12-16 05:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:26:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:26:23 --> Final output sent to browser
DEBUG - 2022-12-16 05:26:23 --> Total execution time: 0.0839
INFO - 2022-12-16 05:26:24 --> Config Class Initialized
INFO - 2022-12-16 05:26:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:26:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:26:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:26:24 --> URI Class Initialized
INFO - 2022-12-16 05:26:24 --> Router Class Initialized
INFO - 2022-12-16 05:26:24 --> Output Class Initialized
INFO - 2022-12-16 05:26:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:26:24 --> Input Class Initialized
INFO - 2022-12-16 05:26:24 --> Language Class Initialized
INFO - 2022-12-16 05:26:24 --> Language Class Initialized
INFO - 2022-12-16 05:26:24 --> Config Class Initialized
INFO - 2022-12-16 05:26:24 --> Loader Class Initialized
INFO - 2022-12-16 05:26:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:26:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:26:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:26:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:26:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:26:24 --> Controller Class Initialized
DEBUG - 2022-12-16 05:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:26:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:26:24 --> Final output sent to browser
DEBUG - 2022-12-16 05:26:24 --> Total execution time: 0.0784
INFO - 2022-12-16 05:26:51 --> Config Class Initialized
INFO - 2022-12-16 05:26:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:26:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:26:51 --> Utf8 Class Initialized
INFO - 2022-12-16 05:26:51 --> URI Class Initialized
INFO - 2022-12-16 05:26:51 --> Router Class Initialized
INFO - 2022-12-16 05:26:51 --> Output Class Initialized
INFO - 2022-12-16 05:26:51 --> Security Class Initialized
DEBUG - 2022-12-16 05:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:26:51 --> Input Class Initialized
INFO - 2022-12-16 05:26:51 --> Language Class Initialized
INFO - 2022-12-16 05:26:51 --> Language Class Initialized
INFO - 2022-12-16 05:26:51 --> Config Class Initialized
INFO - 2022-12-16 05:26:51 --> Loader Class Initialized
INFO - 2022-12-16 05:26:51 --> Helper loaded: url_helper
INFO - 2022-12-16 05:26:51 --> Helper loaded: file_helper
INFO - 2022-12-16 05:26:51 --> Helper loaded: form_helper
INFO - 2022-12-16 05:26:51 --> Helper loaded: my_helper
INFO - 2022-12-16 05:26:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:26:51 --> Controller Class Initialized
INFO - 2022-12-16 05:26:51 --> Config Class Initialized
INFO - 2022-12-16 05:26:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:26:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:26:51 --> Utf8 Class Initialized
INFO - 2022-12-16 05:26:51 --> URI Class Initialized
INFO - 2022-12-16 05:26:51 --> Router Class Initialized
INFO - 2022-12-16 05:26:51 --> Output Class Initialized
INFO - 2022-12-16 05:26:51 --> Security Class Initialized
DEBUG - 2022-12-16 05:26:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:26:51 --> Input Class Initialized
INFO - 2022-12-16 05:26:51 --> Language Class Initialized
INFO - 2022-12-16 05:26:51 --> Language Class Initialized
INFO - 2022-12-16 05:26:51 --> Config Class Initialized
INFO - 2022-12-16 05:26:51 --> Loader Class Initialized
INFO - 2022-12-16 05:26:51 --> Helper loaded: url_helper
INFO - 2022-12-16 05:26:51 --> Helper loaded: file_helper
INFO - 2022-12-16 05:26:51 --> Helper loaded: form_helper
INFO - 2022-12-16 05:26:51 --> Helper loaded: my_helper
INFO - 2022-12-16 05:26:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:26:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:26:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:26:51 --> Controller Class Initialized
DEBUG - 2022-12-16 05:26:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:26:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:26:51 --> Final output sent to browser
DEBUG - 2022-12-16 05:26:51 --> Total execution time: 0.0683
INFO - 2022-12-16 05:27:08 --> Config Class Initialized
INFO - 2022-12-16 05:27:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:08 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:08 --> URI Class Initialized
INFO - 2022-12-16 05:27:08 --> Router Class Initialized
INFO - 2022-12-16 05:27:08 --> Output Class Initialized
INFO - 2022-12-16 05:27:08 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:08 --> Input Class Initialized
INFO - 2022-12-16 05:27:08 --> Language Class Initialized
INFO - 2022-12-16 05:27:08 --> Language Class Initialized
INFO - 2022-12-16 05:27:08 --> Config Class Initialized
INFO - 2022-12-16 05:27:08 --> Loader Class Initialized
INFO - 2022-12-16 05:27:08 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:08 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:08 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:08 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:09 --> Controller Class Initialized
DEBUG - 2022-12-16 05:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:27:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:27:09 --> Final output sent to browser
DEBUG - 2022-12-16 05:27:09 --> Total execution time: 0.0737
INFO - 2022-12-16 05:27:09 --> Config Class Initialized
INFO - 2022-12-16 05:27:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:09 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:09 --> URI Class Initialized
INFO - 2022-12-16 05:27:09 --> Router Class Initialized
INFO - 2022-12-16 05:27:09 --> Output Class Initialized
INFO - 2022-12-16 05:27:09 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:09 --> Input Class Initialized
INFO - 2022-12-16 05:27:09 --> Language Class Initialized
INFO - 2022-12-16 05:27:09 --> Language Class Initialized
INFO - 2022-12-16 05:27:09 --> Config Class Initialized
INFO - 2022-12-16 05:27:09 --> Loader Class Initialized
INFO - 2022-12-16 05:27:09 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:09 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:09 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:09 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:10 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:10 --> Controller Class Initialized
DEBUG - 2022-12-16 05:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:27:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:27:10 --> Final output sent to browser
DEBUG - 2022-12-16 05:27:10 --> Total execution time: 0.0829
INFO - 2022-12-16 05:27:23 --> Config Class Initialized
INFO - 2022-12-16 05:27:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:23 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:23 --> URI Class Initialized
INFO - 2022-12-16 05:27:23 --> Router Class Initialized
INFO - 2022-12-16 05:27:23 --> Output Class Initialized
INFO - 2022-12-16 05:27:23 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:23 --> Input Class Initialized
INFO - 2022-12-16 05:27:23 --> Language Class Initialized
INFO - 2022-12-16 05:27:23 --> Language Class Initialized
INFO - 2022-12-16 05:27:23 --> Config Class Initialized
INFO - 2022-12-16 05:27:23 --> Loader Class Initialized
INFO - 2022-12-16 05:27:23 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:23 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:23 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:23 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:23 --> Controller Class Initialized
INFO - 2022-12-16 05:27:23 --> Config Class Initialized
INFO - 2022-12-16 05:27:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:23 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:23 --> URI Class Initialized
INFO - 2022-12-16 05:27:23 --> Router Class Initialized
INFO - 2022-12-16 05:27:23 --> Output Class Initialized
INFO - 2022-12-16 05:27:23 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:23 --> Input Class Initialized
INFO - 2022-12-16 05:27:23 --> Language Class Initialized
INFO - 2022-12-16 05:27:23 --> Language Class Initialized
INFO - 2022-12-16 05:27:23 --> Config Class Initialized
INFO - 2022-12-16 05:27:23 --> Loader Class Initialized
INFO - 2022-12-16 05:27:23 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:23 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:23 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:23 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:23 --> Controller Class Initialized
DEBUG - 2022-12-16 05:27:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:27:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:27:23 --> Final output sent to browser
DEBUG - 2022-12-16 05:27:23 --> Total execution time: 0.0940
INFO - 2022-12-16 05:27:24 --> Config Class Initialized
INFO - 2022-12-16 05:27:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:24 --> URI Class Initialized
INFO - 2022-12-16 05:27:24 --> Router Class Initialized
INFO - 2022-12-16 05:27:24 --> Output Class Initialized
INFO - 2022-12-16 05:27:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:24 --> Input Class Initialized
INFO - 2022-12-16 05:27:25 --> Language Class Initialized
INFO - 2022-12-16 05:27:25 --> Language Class Initialized
INFO - 2022-12-16 05:27:25 --> Config Class Initialized
INFO - 2022-12-16 05:27:25 --> Loader Class Initialized
INFO - 2022-12-16 05:27:25 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:25 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:25 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:25 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:25 --> Controller Class Initialized
DEBUG - 2022-12-16 05:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:27:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:27:25 --> Final output sent to browser
DEBUG - 2022-12-16 05:27:25 --> Total execution time: 0.0837
INFO - 2022-12-16 05:27:32 --> Config Class Initialized
INFO - 2022-12-16 05:27:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:32 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:32 --> URI Class Initialized
INFO - 2022-12-16 05:27:32 --> Router Class Initialized
INFO - 2022-12-16 05:27:32 --> Output Class Initialized
INFO - 2022-12-16 05:27:32 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:32 --> Input Class Initialized
INFO - 2022-12-16 05:27:32 --> Language Class Initialized
INFO - 2022-12-16 05:27:32 --> Language Class Initialized
INFO - 2022-12-16 05:27:32 --> Config Class Initialized
INFO - 2022-12-16 05:27:32 --> Loader Class Initialized
INFO - 2022-12-16 05:27:32 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:32 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:32 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:32 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:32 --> Controller Class Initialized
INFO - 2022-12-16 05:27:32 --> Config Class Initialized
INFO - 2022-12-16 05:27:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:32 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:32 --> URI Class Initialized
INFO - 2022-12-16 05:27:32 --> Router Class Initialized
INFO - 2022-12-16 05:27:32 --> Output Class Initialized
INFO - 2022-12-16 05:27:32 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:32 --> Input Class Initialized
INFO - 2022-12-16 05:27:32 --> Language Class Initialized
INFO - 2022-12-16 05:27:32 --> Language Class Initialized
INFO - 2022-12-16 05:27:32 --> Config Class Initialized
INFO - 2022-12-16 05:27:32 --> Loader Class Initialized
INFO - 2022-12-16 05:27:32 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:32 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:32 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:32 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:32 --> Controller Class Initialized
DEBUG - 2022-12-16 05:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:27:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:27:32 --> Final output sent to browser
DEBUG - 2022-12-16 05:27:32 --> Total execution time: 0.0699
INFO - 2022-12-16 05:27:33 --> Config Class Initialized
INFO - 2022-12-16 05:27:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:33 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:33 --> URI Class Initialized
INFO - 2022-12-16 05:27:33 --> Router Class Initialized
INFO - 2022-12-16 05:27:33 --> Output Class Initialized
INFO - 2022-12-16 05:27:33 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:33 --> Input Class Initialized
INFO - 2022-12-16 05:27:33 --> Language Class Initialized
INFO - 2022-12-16 05:27:33 --> Language Class Initialized
INFO - 2022-12-16 05:27:33 --> Config Class Initialized
INFO - 2022-12-16 05:27:33 --> Loader Class Initialized
INFO - 2022-12-16 05:27:33 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:33 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:33 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:33 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:33 --> Controller Class Initialized
DEBUG - 2022-12-16 05:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:27:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:27:33 --> Final output sent to browser
DEBUG - 2022-12-16 05:27:33 --> Total execution time: 0.0821
INFO - 2022-12-16 05:27:36 --> Config Class Initialized
INFO - 2022-12-16 05:27:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:27:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:27:36 --> Utf8 Class Initialized
INFO - 2022-12-16 05:27:36 --> URI Class Initialized
INFO - 2022-12-16 05:27:36 --> Router Class Initialized
INFO - 2022-12-16 05:27:36 --> Output Class Initialized
INFO - 2022-12-16 05:27:36 --> Security Class Initialized
DEBUG - 2022-12-16 05:27:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:27:36 --> Input Class Initialized
INFO - 2022-12-16 05:27:36 --> Language Class Initialized
INFO - 2022-12-16 05:27:36 --> Language Class Initialized
INFO - 2022-12-16 05:27:36 --> Config Class Initialized
INFO - 2022-12-16 05:27:36 --> Loader Class Initialized
INFO - 2022-12-16 05:27:36 --> Helper loaded: url_helper
INFO - 2022-12-16 05:27:36 --> Helper loaded: file_helper
INFO - 2022-12-16 05:27:36 --> Helper loaded: form_helper
INFO - 2022-12-16 05:27:36 --> Helper loaded: my_helper
INFO - 2022-12-16 05:27:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:27:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:27:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:27:36 --> Controller Class Initialized
DEBUG - 2022-12-16 05:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:27:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:27:36 --> Final output sent to browser
DEBUG - 2022-12-16 05:27:36 --> Total execution time: 0.1046
INFO - 2022-12-16 05:28:05 --> Config Class Initialized
INFO - 2022-12-16 05:28:05 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:28:05 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:28:05 --> Utf8 Class Initialized
INFO - 2022-12-16 05:28:05 --> URI Class Initialized
INFO - 2022-12-16 05:28:05 --> Router Class Initialized
INFO - 2022-12-16 05:28:05 --> Output Class Initialized
INFO - 2022-12-16 05:28:05 --> Security Class Initialized
DEBUG - 2022-12-16 05:28:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:28:05 --> Input Class Initialized
INFO - 2022-12-16 05:28:05 --> Language Class Initialized
INFO - 2022-12-16 05:28:05 --> Language Class Initialized
INFO - 2022-12-16 05:28:05 --> Config Class Initialized
INFO - 2022-12-16 05:28:05 --> Loader Class Initialized
INFO - 2022-12-16 05:28:05 --> Helper loaded: url_helper
INFO - 2022-12-16 05:28:05 --> Helper loaded: file_helper
INFO - 2022-12-16 05:28:05 --> Helper loaded: form_helper
INFO - 2022-12-16 05:28:05 --> Helper loaded: my_helper
INFO - 2022-12-16 05:28:05 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:28:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:28:05 --> Controller Class Initialized
DEBUG - 2022-12-16 05:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:28:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:28:05 --> Final output sent to browser
DEBUG - 2022-12-16 05:28:05 --> Total execution time: 0.0799
INFO - 2022-12-16 05:28:36 --> Config Class Initialized
INFO - 2022-12-16 05:28:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:28:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:28:36 --> Utf8 Class Initialized
INFO - 2022-12-16 05:28:36 --> URI Class Initialized
INFO - 2022-12-16 05:28:36 --> Router Class Initialized
INFO - 2022-12-16 05:28:36 --> Output Class Initialized
INFO - 2022-12-16 05:28:36 --> Security Class Initialized
DEBUG - 2022-12-16 05:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:28:36 --> Input Class Initialized
INFO - 2022-12-16 05:28:36 --> Language Class Initialized
INFO - 2022-12-16 05:28:36 --> Language Class Initialized
INFO - 2022-12-16 05:28:36 --> Config Class Initialized
INFO - 2022-12-16 05:28:36 --> Loader Class Initialized
INFO - 2022-12-16 05:28:36 --> Helper loaded: url_helper
INFO - 2022-12-16 05:28:36 --> Helper loaded: file_helper
INFO - 2022-12-16 05:28:36 --> Helper loaded: form_helper
INFO - 2022-12-16 05:28:36 --> Helper loaded: my_helper
INFO - 2022-12-16 05:28:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:28:36 --> Controller Class Initialized
INFO - 2022-12-16 05:28:36 --> Config Class Initialized
INFO - 2022-12-16 05:28:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:28:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:28:36 --> Utf8 Class Initialized
INFO - 2022-12-16 05:28:36 --> URI Class Initialized
INFO - 2022-12-16 05:28:36 --> Router Class Initialized
INFO - 2022-12-16 05:28:36 --> Output Class Initialized
INFO - 2022-12-16 05:28:36 --> Security Class Initialized
DEBUG - 2022-12-16 05:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:28:36 --> Input Class Initialized
INFO - 2022-12-16 05:28:36 --> Language Class Initialized
INFO - 2022-12-16 05:28:36 --> Language Class Initialized
INFO - 2022-12-16 05:28:36 --> Config Class Initialized
INFO - 2022-12-16 05:28:36 --> Loader Class Initialized
INFO - 2022-12-16 05:28:36 --> Helper loaded: url_helper
INFO - 2022-12-16 05:28:36 --> Helper loaded: file_helper
INFO - 2022-12-16 05:28:36 --> Helper loaded: form_helper
INFO - 2022-12-16 05:28:36 --> Helper loaded: my_helper
INFO - 2022-12-16 05:28:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:28:37 --> Controller Class Initialized
DEBUG - 2022-12-16 05:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:28:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:28:37 --> Final output sent to browser
DEBUG - 2022-12-16 05:28:37 --> Total execution time: 0.0716
INFO - 2022-12-16 05:28:47 --> Config Class Initialized
INFO - 2022-12-16 05:28:47 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:28:47 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:28:47 --> Utf8 Class Initialized
INFO - 2022-12-16 05:28:47 --> URI Class Initialized
INFO - 2022-12-16 05:28:47 --> Router Class Initialized
INFO - 2022-12-16 05:28:47 --> Output Class Initialized
INFO - 2022-12-16 05:28:47 --> Security Class Initialized
DEBUG - 2022-12-16 05:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:28:47 --> Input Class Initialized
INFO - 2022-12-16 05:28:47 --> Language Class Initialized
INFO - 2022-12-16 05:28:47 --> Language Class Initialized
INFO - 2022-12-16 05:28:47 --> Config Class Initialized
INFO - 2022-12-16 05:28:47 --> Loader Class Initialized
INFO - 2022-12-16 05:28:47 --> Helper loaded: url_helper
INFO - 2022-12-16 05:28:47 --> Helper loaded: file_helper
INFO - 2022-12-16 05:28:47 --> Helper loaded: form_helper
INFO - 2022-12-16 05:28:47 --> Helper loaded: my_helper
INFO - 2022-12-16 05:28:47 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:28:47 --> Controller Class Initialized
DEBUG - 2022-12-16 05:28:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:28:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:28:47 --> Final output sent to browser
DEBUG - 2022-12-16 05:28:47 --> Total execution time: 0.0776
INFO - 2022-12-16 05:29:00 --> Config Class Initialized
INFO - 2022-12-16 05:29:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:00 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:00 --> URI Class Initialized
INFO - 2022-12-16 05:29:00 --> Router Class Initialized
INFO - 2022-12-16 05:29:00 --> Output Class Initialized
INFO - 2022-12-16 05:29:00 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:00 --> Input Class Initialized
INFO - 2022-12-16 05:29:00 --> Language Class Initialized
INFO - 2022-12-16 05:29:00 --> Language Class Initialized
INFO - 2022-12-16 05:29:00 --> Config Class Initialized
INFO - 2022-12-16 05:29:00 --> Loader Class Initialized
INFO - 2022-12-16 05:29:00 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:00 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:00 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:00 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:00 --> Controller Class Initialized
INFO - 2022-12-16 05:29:00 --> Config Class Initialized
INFO - 2022-12-16 05:29:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:00 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:00 --> URI Class Initialized
INFO - 2022-12-16 05:29:00 --> Router Class Initialized
INFO - 2022-12-16 05:29:00 --> Output Class Initialized
INFO - 2022-12-16 05:29:00 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:00 --> Input Class Initialized
INFO - 2022-12-16 05:29:00 --> Language Class Initialized
INFO - 2022-12-16 05:29:00 --> Language Class Initialized
INFO - 2022-12-16 05:29:00 --> Config Class Initialized
INFO - 2022-12-16 05:29:00 --> Loader Class Initialized
INFO - 2022-12-16 05:29:00 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:00 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:00 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:00 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:00 --> Controller Class Initialized
DEBUG - 2022-12-16 05:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:29:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:29:00 --> Final output sent to browser
DEBUG - 2022-12-16 05:29:00 --> Total execution time: 0.0780
INFO - 2022-12-16 05:29:01 --> Config Class Initialized
INFO - 2022-12-16 05:29:01 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:01 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:01 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:01 --> URI Class Initialized
INFO - 2022-12-16 05:29:01 --> Router Class Initialized
INFO - 2022-12-16 05:29:01 --> Output Class Initialized
INFO - 2022-12-16 05:29:01 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:01 --> Input Class Initialized
INFO - 2022-12-16 05:29:01 --> Language Class Initialized
INFO - 2022-12-16 05:29:01 --> Language Class Initialized
INFO - 2022-12-16 05:29:01 --> Config Class Initialized
INFO - 2022-12-16 05:29:01 --> Loader Class Initialized
INFO - 2022-12-16 05:29:01 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:01 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:01 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:01 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:01 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:01 --> Controller Class Initialized
DEBUG - 2022-12-16 05:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:29:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:29:01 --> Final output sent to browser
DEBUG - 2022-12-16 05:29:01 --> Total execution time: 0.0694
INFO - 2022-12-16 05:29:11 --> Config Class Initialized
INFO - 2022-12-16 05:29:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:11 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:11 --> URI Class Initialized
INFO - 2022-12-16 05:29:11 --> Router Class Initialized
INFO - 2022-12-16 05:29:11 --> Output Class Initialized
INFO - 2022-12-16 05:29:11 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:11 --> Input Class Initialized
INFO - 2022-12-16 05:29:11 --> Language Class Initialized
INFO - 2022-12-16 05:29:11 --> Language Class Initialized
INFO - 2022-12-16 05:29:11 --> Config Class Initialized
INFO - 2022-12-16 05:29:11 --> Loader Class Initialized
INFO - 2022-12-16 05:29:11 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:11 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:11 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:11 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:11 --> Controller Class Initialized
INFO - 2022-12-16 05:29:11 --> Config Class Initialized
INFO - 2022-12-16 05:29:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:11 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:11 --> URI Class Initialized
INFO - 2022-12-16 05:29:11 --> Router Class Initialized
INFO - 2022-12-16 05:29:11 --> Output Class Initialized
INFO - 2022-12-16 05:29:11 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:11 --> Input Class Initialized
INFO - 2022-12-16 05:29:11 --> Language Class Initialized
INFO - 2022-12-16 05:29:11 --> Language Class Initialized
INFO - 2022-12-16 05:29:11 --> Config Class Initialized
INFO - 2022-12-16 05:29:11 --> Loader Class Initialized
INFO - 2022-12-16 05:29:11 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:11 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:11 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:11 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:11 --> Controller Class Initialized
DEBUG - 2022-12-16 05:29:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:29:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:29:11 --> Final output sent to browser
DEBUG - 2022-12-16 05:29:11 --> Total execution time: 0.0787
INFO - 2022-12-16 05:29:12 --> Config Class Initialized
INFO - 2022-12-16 05:29:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:12 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:12 --> URI Class Initialized
INFO - 2022-12-16 05:29:12 --> Router Class Initialized
INFO - 2022-12-16 05:29:12 --> Output Class Initialized
INFO - 2022-12-16 05:29:12 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:12 --> Input Class Initialized
INFO - 2022-12-16 05:29:12 --> Language Class Initialized
INFO - 2022-12-16 05:29:12 --> Language Class Initialized
INFO - 2022-12-16 05:29:12 --> Config Class Initialized
INFO - 2022-12-16 05:29:12 --> Loader Class Initialized
INFO - 2022-12-16 05:29:12 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:12 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:12 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:12 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:12 --> Controller Class Initialized
DEBUG - 2022-12-16 05:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:29:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:29:12 --> Final output sent to browser
DEBUG - 2022-12-16 05:29:12 --> Total execution time: 0.0763
INFO - 2022-12-16 05:29:24 --> Config Class Initialized
INFO - 2022-12-16 05:29:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:24 --> URI Class Initialized
INFO - 2022-12-16 05:29:24 --> Router Class Initialized
INFO - 2022-12-16 05:29:24 --> Output Class Initialized
INFO - 2022-12-16 05:29:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:24 --> Input Class Initialized
INFO - 2022-12-16 05:29:24 --> Language Class Initialized
INFO - 2022-12-16 05:29:24 --> Language Class Initialized
INFO - 2022-12-16 05:29:24 --> Config Class Initialized
INFO - 2022-12-16 05:29:24 --> Loader Class Initialized
INFO - 2022-12-16 05:29:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:24 --> Controller Class Initialized
INFO - 2022-12-16 05:29:24 --> Config Class Initialized
INFO - 2022-12-16 05:29:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:24 --> URI Class Initialized
INFO - 2022-12-16 05:29:24 --> Router Class Initialized
INFO - 2022-12-16 05:29:24 --> Output Class Initialized
INFO - 2022-12-16 05:29:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:24 --> Input Class Initialized
INFO - 2022-12-16 05:29:24 --> Language Class Initialized
INFO - 2022-12-16 05:29:24 --> Language Class Initialized
INFO - 2022-12-16 05:29:24 --> Config Class Initialized
INFO - 2022-12-16 05:29:24 --> Loader Class Initialized
INFO - 2022-12-16 05:29:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:24 --> Controller Class Initialized
DEBUG - 2022-12-16 05:29:24 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:29:24 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:29:24 --> Final output sent to browser
DEBUG - 2022-12-16 05:29:24 --> Total execution time: 0.1003
INFO - 2022-12-16 05:29:25 --> Config Class Initialized
INFO - 2022-12-16 05:29:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:25 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:25 --> URI Class Initialized
INFO - 2022-12-16 05:29:25 --> Router Class Initialized
INFO - 2022-12-16 05:29:25 --> Output Class Initialized
INFO - 2022-12-16 05:29:25 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:25 --> Input Class Initialized
INFO - 2022-12-16 05:29:25 --> Language Class Initialized
INFO - 2022-12-16 05:29:25 --> Language Class Initialized
INFO - 2022-12-16 05:29:25 --> Config Class Initialized
INFO - 2022-12-16 05:29:25 --> Loader Class Initialized
INFO - 2022-12-16 05:29:25 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:25 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:25 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:25 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:25 --> Controller Class Initialized
DEBUG - 2022-12-16 05:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/form.php
DEBUG - 2022-12-16 05:29:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:29:25 --> Final output sent to browser
DEBUG - 2022-12-16 05:29:25 --> Total execution time: 0.0932
INFO - 2022-12-16 05:29:43 --> Config Class Initialized
INFO - 2022-12-16 05:29:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:43 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:43 --> URI Class Initialized
INFO - 2022-12-16 05:29:43 --> Router Class Initialized
INFO - 2022-12-16 05:29:43 --> Output Class Initialized
INFO - 2022-12-16 05:29:43 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:43 --> Input Class Initialized
INFO - 2022-12-16 05:29:43 --> Language Class Initialized
INFO - 2022-12-16 05:29:43 --> Language Class Initialized
INFO - 2022-12-16 05:29:43 --> Config Class Initialized
INFO - 2022-12-16 05:29:43 --> Loader Class Initialized
INFO - 2022-12-16 05:29:43 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:43 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:43 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:43 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:43 --> Controller Class Initialized
INFO - 2022-12-16 05:29:43 --> Config Class Initialized
INFO - 2022-12-16 05:29:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:29:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:29:43 --> Utf8 Class Initialized
INFO - 2022-12-16 05:29:43 --> URI Class Initialized
INFO - 2022-12-16 05:29:43 --> Router Class Initialized
INFO - 2022-12-16 05:29:43 --> Output Class Initialized
INFO - 2022-12-16 05:29:43 --> Security Class Initialized
DEBUG - 2022-12-16 05:29:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:29:43 --> Input Class Initialized
INFO - 2022-12-16 05:29:43 --> Language Class Initialized
INFO - 2022-12-16 05:29:43 --> Language Class Initialized
INFO - 2022-12-16 05:29:43 --> Config Class Initialized
INFO - 2022-12-16 05:29:43 --> Loader Class Initialized
INFO - 2022-12-16 05:29:43 --> Helper loaded: url_helper
INFO - 2022-12-16 05:29:43 --> Helper loaded: file_helper
INFO - 2022-12-16 05:29:43 --> Helper loaded: form_helper
INFO - 2022-12-16 05:29:43 --> Helper loaded: my_helper
INFO - 2022-12-16 05:29:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:29:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:29:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:29:43 --> Controller Class Initialized
DEBUG - 2022-12-16 05:29:43 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:29:43 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:29:43 --> Final output sent to browser
DEBUG - 2022-12-16 05:29:43 --> Total execution time: 0.0811
INFO - 2022-12-16 05:31:00 --> Config Class Initialized
INFO - 2022-12-16 05:31:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:00 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:00 --> URI Class Initialized
INFO - 2022-12-16 05:31:00 --> Router Class Initialized
INFO - 2022-12-16 05:31:00 --> Output Class Initialized
INFO - 2022-12-16 05:31:00 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:00 --> Input Class Initialized
INFO - 2022-12-16 05:31:00 --> Language Class Initialized
INFO - 2022-12-16 05:31:00 --> Language Class Initialized
INFO - 2022-12-16 05:31:00 --> Config Class Initialized
INFO - 2022-12-16 05:31:00 --> Loader Class Initialized
INFO - 2022-12-16 05:31:00 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:00 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:00 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:00 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:01 --> Controller Class Initialized
DEBUG - 2022-12-16 05:31:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:31:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:31:01 --> Final output sent to browser
DEBUG - 2022-12-16 05:31:01 --> Total execution time: 0.0839
INFO - 2022-12-16 05:31:01 --> Config Class Initialized
INFO - 2022-12-16 05:31:01 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:01 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:01 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:01 --> URI Class Initialized
INFO - 2022-12-16 05:31:01 --> Router Class Initialized
INFO - 2022-12-16 05:31:01 --> Output Class Initialized
INFO - 2022-12-16 05:31:01 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:01 --> Input Class Initialized
INFO - 2022-12-16 05:31:01 --> Language Class Initialized
INFO - 2022-12-16 05:31:01 --> Language Class Initialized
INFO - 2022-12-16 05:31:01 --> Config Class Initialized
INFO - 2022-12-16 05:31:01 --> Loader Class Initialized
INFO - 2022-12-16 05:31:01 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:01 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:01 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:01 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:01 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:01 --> Controller Class Initialized
INFO - 2022-12-16 05:31:02 --> Config Class Initialized
INFO - 2022-12-16 05:31:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:02 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:02 --> URI Class Initialized
INFO - 2022-12-16 05:31:02 --> Router Class Initialized
INFO - 2022-12-16 05:31:02 --> Output Class Initialized
INFO - 2022-12-16 05:31:02 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:02 --> Input Class Initialized
INFO - 2022-12-16 05:31:02 --> Language Class Initialized
INFO - 2022-12-16 05:31:02 --> Language Class Initialized
INFO - 2022-12-16 05:31:02 --> Config Class Initialized
INFO - 2022-12-16 05:31:02 --> Loader Class Initialized
INFO - 2022-12-16 05:31:02 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:02 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:02 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:02 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:02 --> Controller Class Initialized
INFO - 2022-12-16 05:31:04 --> Config Class Initialized
INFO - 2022-12-16 05:31:04 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:04 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:04 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:04 --> URI Class Initialized
INFO - 2022-12-16 05:31:04 --> Router Class Initialized
INFO - 2022-12-16 05:31:04 --> Output Class Initialized
INFO - 2022-12-16 05:31:04 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:04 --> Input Class Initialized
INFO - 2022-12-16 05:31:04 --> Language Class Initialized
INFO - 2022-12-16 05:31:04 --> Language Class Initialized
INFO - 2022-12-16 05:31:04 --> Config Class Initialized
INFO - 2022-12-16 05:31:04 --> Loader Class Initialized
INFO - 2022-12-16 05:31:04 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:04 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:04 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:04 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:04 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:04 --> Controller Class Initialized
ERROR - 2022-12-16 05:31:04 --> Severity: Notice --> Undefined variable: status_form C:\xampp\htdocs\nilai\application\modules\data_siswa\views\form.php 259
DEBUG - 2022-12-16 05:31:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/form.php
DEBUG - 2022-12-16 05:31:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:31:04 --> Final output sent to browser
DEBUG - 2022-12-16 05:31:04 --> Total execution time: 0.0808
INFO - 2022-12-16 05:31:11 --> Config Class Initialized
INFO - 2022-12-16 05:31:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:11 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:11 --> URI Class Initialized
INFO - 2022-12-16 05:31:11 --> Router Class Initialized
INFO - 2022-12-16 05:31:11 --> Output Class Initialized
INFO - 2022-12-16 05:31:11 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:11 --> Input Class Initialized
INFO - 2022-12-16 05:31:11 --> Language Class Initialized
INFO - 2022-12-16 05:31:11 --> Language Class Initialized
INFO - 2022-12-16 05:31:11 --> Config Class Initialized
INFO - 2022-12-16 05:31:11 --> Loader Class Initialized
INFO - 2022-12-16 05:31:11 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:11 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:11 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:11 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:11 --> Controller Class Initialized
INFO - 2022-12-16 05:31:12 --> Upload Class Initialized
INFO - 2022-12-16 05:31:12 --> Language file loaded: language/english/upload_lang.php
ERROR - 2022-12-16 05:31:12 --> The upload path does not appear to be valid.
INFO - 2022-12-16 05:31:12 --> Config Class Initialized
INFO - 2022-12-16 05:31:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:12 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:12 --> URI Class Initialized
INFO - 2022-12-16 05:31:12 --> Router Class Initialized
INFO - 2022-12-16 05:31:12 --> Output Class Initialized
INFO - 2022-12-16 05:31:12 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:12 --> Input Class Initialized
INFO - 2022-12-16 05:31:12 --> Language Class Initialized
INFO - 2022-12-16 05:31:12 --> Language Class Initialized
INFO - 2022-12-16 05:31:12 --> Config Class Initialized
INFO - 2022-12-16 05:31:12 --> Loader Class Initialized
INFO - 2022-12-16 05:31:12 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:12 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:12 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:12 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:12 --> Controller Class Initialized
DEBUG - 2022-12-16 05:31:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:31:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:31:12 --> Final output sent to browser
DEBUG - 2022-12-16 05:31:12 --> Total execution time: 0.0685
INFO - 2022-12-16 05:31:12 --> Config Class Initialized
INFO - 2022-12-16 05:31:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:12 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:12 --> URI Class Initialized
INFO - 2022-12-16 05:31:12 --> Router Class Initialized
INFO - 2022-12-16 05:31:12 --> Output Class Initialized
INFO - 2022-12-16 05:31:12 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:12 --> Input Class Initialized
INFO - 2022-12-16 05:31:12 --> Language Class Initialized
INFO - 2022-12-16 05:31:12 --> Language Class Initialized
INFO - 2022-12-16 05:31:12 --> Config Class Initialized
INFO - 2022-12-16 05:31:12 --> Loader Class Initialized
INFO - 2022-12-16 05:31:12 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:12 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:12 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:12 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:12 --> Controller Class Initialized
INFO - 2022-12-16 05:31:16 --> Config Class Initialized
INFO - 2022-12-16 05:31:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:31:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:31:16 --> Utf8 Class Initialized
INFO - 2022-12-16 05:31:16 --> URI Class Initialized
INFO - 2022-12-16 05:31:16 --> Router Class Initialized
INFO - 2022-12-16 05:31:16 --> Output Class Initialized
INFO - 2022-12-16 05:31:16 --> Security Class Initialized
DEBUG - 2022-12-16 05:31:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:31:16 --> Input Class Initialized
INFO - 2022-12-16 05:31:16 --> Language Class Initialized
INFO - 2022-12-16 05:31:16 --> Language Class Initialized
INFO - 2022-12-16 05:31:16 --> Config Class Initialized
INFO - 2022-12-16 05:31:16 --> Loader Class Initialized
INFO - 2022-12-16 05:31:16 --> Helper loaded: url_helper
INFO - 2022-12-16 05:31:16 --> Helper loaded: file_helper
INFO - 2022-12-16 05:31:16 --> Helper loaded: form_helper
INFO - 2022-12-16 05:31:16 --> Helper loaded: my_helper
INFO - 2022-12-16 05:31:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:31:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:31:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:31:16 --> Controller Class Initialized
INFO - 2022-12-16 05:32:19 --> Config Class Initialized
INFO - 2022-12-16 05:32:19 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:32:19 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:32:19 --> Utf8 Class Initialized
INFO - 2022-12-16 05:32:19 --> URI Class Initialized
INFO - 2022-12-16 05:32:19 --> Router Class Initialized
INFO - 2022-12-16 05:32:19 --> Output Class Initialized
INFO - 2022-12-16 05:32:19 --> Security Class Initialized
DEBUG - 2022-12-16 05:32:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:32:19 --> Input Class Initialized
INFO - 2022-12-16 05:32:19 --> Language Class Initialized
INFO - 2022-12-16 05:32:19 --> Language Class Initialized
INFO - 2022-12-16 05:32:19 --> Config Class Initialized
INFO - 2022-12-16 05:32:19 --> Loader Class Initialized
INFO - 2022-12-16 05:32:19 --> Helper loaded: url_helper
INFO - 2022-12-16 05:32:19 --> Helper loaded: file_helper
INFO - 2022-12-16 05:32:19 --> Helper loaded: form_helper
INFO - 2022-12-16 05:32:19 --> Helper loaded: my_helper
INFO - 2022-12-16 05:32:19 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:32:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:32:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:32:19 --> Controller Class Initialized
DEBUG - 2022-12-16 05:32:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_siswa/views/list.php
DEBUG - 2022-12-16 05:32:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:32:20 --> Final output sent to browser
DEBUG - 2022-12-16 05:32:20 --> Total execution time: 0.0655
INFO - 2022-12-16 05:32:20 --> Config Class Initialized
INFO - 2022-12-16 05:32:20 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:32:20 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:32:20 --> Utf8 Class Initialized
INFO - 2022-12-16 05:32:20 --> URI Class Initialized
INFO - 2022-12-16 05:32:20 --> Router Class Initialized
INFO - 2022-12-16 05:32:20 --> Output Class Initialized
INFO - 2022-12-16 05:32:20 --> Security Class Initialized
DEBUG - 2022-12-16 05:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:32:20 --> Input Class Initialized
INFO - 2022-12-16 05:32:20 --> Language Class Initialized
INFO - 2022-12-16 05:32:20 --> Language Class Initialized
INFO - 2022-12-16 05:32:20 --> Config Class Initialized
INFO - 2022-12-16 05:32:20 --> Loader Class Initialized
INFO - 2022-12-16 05:32:20 --> Helper loaded: url_helper
INFO - 2022-12-16 05:32:20 --> Helper loaded: file_helper
INFO - 2022-12-16 05:32:20 --> Helper loaded: form_helper
INFO - 2022-12-16 05:32:20 --> Helper loaded: my_helper
INFO - 2022-12-16 05:32:20 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:32:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:32:20 --> Controller Class Initialized
INFO - 2022-12-16 05:32:22 --> Config Class Initialized
INFO - 2022-12-16 05:32:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:32:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:32:22 --> Utf8 Class Initialized
INFO - 2022-12-16 05:32:22 --> URI Class Initialized
INFO - 2022-12-16 05:32:22 --> Router Class Initialized
INFO - 2022-12-16 05:32:22 --> Output Class Initialized
INFO - 2022-12-16 05:32:22 --> Security Class Initialized
DEBUG - 2022-12-16 05:32:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:32:22 --> Input Class Initialized
INFO - 2022-12-16 05:32:22 --> Language Class Initialized
INFO - 2022-12-16 05:32:22 --> Language Class Initialized
INFO - 2022-12-16 05:32:22 --> Config Class Initialized
INFO - 2022-12-16 05:32:22 --> Loader Class Initialized
INFO - 2022-12-16 05:32:22 --> Helper loaded: url_helper
INFO - 2022-12-16 05:32:22 --> Helper loaded: file_helper
INFO - 2022-12-16 05:32:22 --> Helper loaded: form_helper
INFO - 2022-12-16 05:32:22 --> Helper loaded: my_helper
INFO - 2022-12-16 05:32:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:32:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:32:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:32:22 --> Controller Class Initialized
INFO - 2022-12-16 05:32:52 --> Config Class Initialized
INFO - 2022-12-16 05:32:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:32:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:32:52 --> Utf8 Class Initialized
INFO - 2022-12-16 05:32:52 --> URI Class Initialized
INFO - 2022-12-16 05:32:52 --> Router Class Initialized
INFO - 2022-12-16 05:32:52 --> Output Class Initialized
INFO - 2022-12-16 05:32:52 --> Security Class Initialized
DEBUG - 2022-12-16 05:32:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:32:52 --> Input Class Initialized
INFO - 2022-12-16 05:32:52 --> Language Class Initialized
INFO - 2022-12-16 05:32:52 --> Language Class Initialized
INFO - 2022-12-16 05:32:52 --> Config Class Initialized
INFO - 2022-12-16 05:32:52 --> Loader Class Initialized
INFO - 2022-12-16 05:32:52 --> Helper loaded: url_helper
INFO - 2022-12-16 05:32:52 --> Helper loaded: file_helper
INFO - 2022-12-16 05:32:52 --> Helper loaded: form_helper
INFO - 2022-12-16 05:32:52 --> Helper loaded: my_helper
INFO - 2022-12-16 05:32:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:32:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:32:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:32:52 --> Controller Class Initialized
DEBUG - 2022-12-16 05:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:32:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:32:52 --> Final output sent to browser
DEBUG - 2022-12-16 05:32:52 --> Total execution time: 0.0862
INFO - 2022-12-16 05:33:06 --> Config Class Initialized
INFO - 2022-12-16 05:33:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:33:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:33:06 --> Utf8 Class Initialized
INFO - 2022-12-16 05:33:06 --> URI Class Initialized
INFO - 2022-12-16 05:33:06 --> Router Class Initialized
INFO - 2022-12-16 05:33:06 --> Output Class Initialized
INFO - 2022-12-16 05:33:06 --> Security Class Initialized
DEBUG - 2022-12-16 05:33:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:33:06 --> Input Class Initialized
INFO - 2022-12-16 05:33:06 --> Language Class Initialized
INFO - 2022-12-16 05:33:06 --> Language Class Initialized
INFO - 2022-12-16 05:33:06 --> Config Class Initialized
INFO - 2022-12-16 05:33:06 --> Loader Class Initialized
INFO - 2022-12-16 05:33:06 --> Helper loaded: url_helper
INFO - 2022-12-16 05:33:06 --> Helper loaded: file_helper
INFO - 2022-12-16 05:33:06 --> Helper loaded: form_helper
INFO - 2022-12-16 05:33:06 --> Helper loaded: my_helper
INFO - 2022-12-16 05:33:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:33:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:33:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:33:06 --> Controller Class Initialized
INFO - 2022-12-16 05:33:06 --> Final output sent to browser
DEBUG - 2022-12-16 05:33:06 --> Total execution time: 0.1077
INFO - 2022-12-16 05:33:08 --> Config Class Initialized
INFO - 2022-12-16 05:33:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:33:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:33:08 --> Utf8 Class Initialized
INFO - 2022-12-16 05:33:08 --> URI Class Initialized
INFO - 2022-12-16 05:33:08 --> Router Class Initialized
INFO - 2022-12-16 05:33:08 --> Output Class Initialized
INFO - 2022-12-16 05:33:08 --> Security Class Initialized
DEBUG - 2022-12-16 05:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:33:08 --> Input Class Initialized
INFO - 2022-12-16 05:33:08 --> Language Class Initialized
INFO - 2022-12-16 05:33:08 --> Language Class Initialized
INFO - 2022-12-16 05:33:08 --> Config Class Initialized
INFO - 2022-12-16 05:33:08 --> Loader Class Initialized
INFO - 2022-12-16 05:33:08 --> Helper loaded: url_helper
INFO - 2022-12-16 05:33:08 --> Helper loaded: file_helper
INFO - 2022-12-16 05:33:08 --> Helper loaded: form_helper
INFO - 2022-12-16 05:33:08 --> Helper loaded: my_helper
INFO - 2022-12-16 05:33:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:33:08 --> Controller Class Initialized
DEBUG - 2022-12-16 05:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:33:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:33:08 --> Final output sent to browser
DEBUG - 2022-12-16 05:33:08 --> Total execution time: 0.0699
INFO - 2022-12-16 05:33:38 --> Config Class Initialized
INFO - 2022-12-16 05:33:38 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:33:38 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:33:38 --> Utf8 Class Initialized
INFO - 2022-12-16 05:33:38 --> URI Class Initialized
INFO - 2022-12-16 05:33:38 --> Router Class Initialized
INFO - 2022-12-16 05:33:38 --> Output Class Initialized
INFO - 2022-12-16 05:33:38 --> Security Class Initialized
DEBUG - 2022-12-16 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:33:38 --> Input Class Initialized
INFO - 2022-12-16 05:33:38 --> Language Class Initialized
INFO - 2022-12-16 05:33:38 --> Language Class Initialized
INFO - 2022-12-16 05:33:38 --> Config Class Initialized
INFO - 2022-12-16 05:33:38 --> Loader Class Initialized
INFO - 2022-12-16 05:33:38 --> Helper loaded: url_helper
INFO - 2022-12-16 05:33:38 --> Helper loaded: file_helper
INFO - 2022-12-16 05:33:38 --> Helper loaded: form_helper
INFO - 2022-12-16 05:33:38 --> Helper loaded: my_helper
INFO - 2022-12-16 05:33:38 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:33:38 --> Controller Class Initialized
DEBUG - 2022-12-16 05:33:38 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-12-16 05:33:38 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:33:38 --> Final output sent to browser
DEBUG - 2022-12-16 05:33:38 --> Total execution time: 0.1047
INFO - 2022-12-16 05:33:38 --> Config Class Initialized
INFO - 2022-12-16 05:33:38 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:33:38 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:33:38 --> Utf8 Class Initialized
INFO - 2022-12-16 05:33:38 --> URI Class Initialized
INFO - 2022-12-16 05:33:38 --> Router Class Initialized
INFO - 2022-12-16 05:33:38 --> Output Class Initialized
INFO - 2022-12-16 05:33:38 --> Security Class Initialized
DEBUG - 2022-12-16 05:33:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:33:38 --> Input Class Initialized
INFO - 2022-12-16 05:33:38 --> Language Class Initialized
INFO - 2022-12-16 05:33:38 --> Language Class Initialized
INFO - 2022-12-16 05:33:38 --> Config Class Initialized
INFO - 2022-12-16 05:33:38 --> Loader Class Initialized
INFO - 2022-12-16 05:33:38 --> Helper loaded: url_helper
INFO - 2022-12-16 05:33:38 --> Helper loaded: file_helper
INFO - 2022-12-16 05:33:38 --> Helper loaded: form_helper
INFO - 2022-12-16 05:33:38 --> Helper loaded: my_helper
INFO - 2022-12-16 05:33:38 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:33:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:33:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:33:38 --> Controller Class Initialized
INFO - 2022-12-16 05:33:40 --> Config Class Initialized
INFO - 2022-12-16 05:33:40 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:33:40 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:33:40 --> Utf8 Class Initialized
INFO - 2022-12-16 05:33:40 --> URI Class Initialized
INFO - 2022-12-16 05:33:40 --> Router Class Initialized
INFO - 2022-12-16 05:33:40 --> Output Class Initialized
INFO - 2022-12-16 05:33:40 --> Security Class Initialized
DEBUG - 2022-12-16 05:33:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:33:40 --> Input Class Initialized
INFO - 2022-12-16 05:33:40 --> Language Class Initialized
INFO - 2022-12-16 05:33:40 --> Language Class Initialized
INFO - 2022-12-16 05:33:40 --> Config Class Initialized
INFO - 2022-12-16 05:33:40 --> Loader Class Initialized
INFO - 2022-12-16 05:33:40 --> Helper loaded: url_helper
INFO - 2022-12-16 05:33:40 --> Helper loaded: file_helper
INFO - 2022-12-16 05:33:40 --> Helper loaded: form_helper
INFO - 2022-12-16 05:33:40 --> Helper loaded: my_helper
INFO - 2022-12-16 05:33:40 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:33:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:33:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:33:40 --> Controller Class Initialized
INFO - 2022-12-16 05:33:40 --> Final output sent to browser
DEBUG - 2022-12-16 05:33:40 --> Total execution time: 0.0786
INFO - 2022-12-16 05:38:07 --> Config Class Initialized
INFO - 2022-12-16 05:38:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:07 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:07 --> URI Class Initialized
INFO - 2022-12-16 05:38:07 --> Router Class Initialized
INFO - 2022-12-16 05:38:07 --> Output Class Initialized
INFO - 2022-12-16 05:38:07 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:07 --> Input Class Initialized
INFO - 2022-12-16 05:38:07 --> Language Class Initialized
INFO - 2022-12-16 05:38:07 --> Language Class Initialized
INFO - 2022-12-16 05:38:07 --> Config Class Initialized
INFO - 2022-12-16 05:38:07 --> Loader Class Initialized
INFO - 2022-12-16 05:38:07 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:07 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:07 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:07 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:07 --> Controller Class Initialized
DEBUG - 2022-12-16 05:38:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_kelas/views/list.php
DEBUG - 2022-12-16 05:38:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:38:07 --> Final output sent to browser
DEBUG - 2022-12-16 05:38:07 --> Total execution time: 0.0985
INFO - 2022-12-16 05:38:16 --> Config Class Initialized
INFO - 2022-12-16 05:38:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:16 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:16 --> URI Class Initialized
INFO - 2022-12-16 05:38:16 --> Router Class Initialized
INFO - 2022-12-16 05:38:16 --> Output Class Initialized
INFO - 2022-12-16 05:38:16 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:16 --> Input Class Initialized
INFO - 2022-12-16 05:38:16 --> Language Class Initialized
INFO - 2022-12-16 05:38:16 --> Language Class Initialized
INFO - 2022-12-16 05:38:16 --> Config Class Initialized
INFO - 2022-12-16 05:38:16 --> Loader Class Initialized
INFO - 2022-12-16 05:38:16 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:16 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:16 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:16 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:16 --> Controller Class Initialized
DEBUG - 2022-12-16 05:38:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_walikelas/views/list.php
DEBUG - 2022-12-16 05:38:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 05:38:16 --> Final output sent to browser
DEBUG - 2022-12-16 05:38:16 --> Total execution time: 0.0669
INFO - 2022-12-16 05:38:17 --> Config Class Initialized
INFO - 2022-12-16 05:38:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:17 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:17 --> URI Class Initialized
INFO - 2022-12-16 05:38:17 --> Router Class Initialized
INFO - 2022-12-16 05:38:17 --> Output Class Initialized
INFO - 2022-12-16 05:38:17 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:17 --> Input Class Initialized
INFO - 2022-12-16 05:38:17 --> Language Class Initialized
INFO - 2022-12-16 05:38:17 --> Language Class Initialized
INFO - 2022-12-16 05:38:17 --> Config Class Initialized
INFO - 2022-12-16 05:38:17 --> Loader Class Initialized
INFO - 2022-12-16 05:38:17 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:17 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:17 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:17 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:17 --> Controller Class Initialized
INFO - 2022-12-16 05:38:18 --> Config Class Initialized
INFO - 2022-12-16 05:38:18 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:18 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:18 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:18 --> URI Class Initialized
INFO - 2022-12-16 05:38:18 --> Router Class Initialized
INFO - 2022-12-16 05:38:18 --> Output Class Initialized
INFO - 2022-12-16 05:38:18 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:18 --> Input Class Initialized
INFO - 2022-12-16 05:38:18 --> Language Class Initialized
INFO - 2022-12-16 05:38:18 --> Language Class Initialized
INFO - 2022-12-16 05:38:18 --> Config Class Initialized
INFO - 2022-12-16 05:38:18 --> Loader Class Initialized
INFO - 2022-12-16 05:38:18 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:18 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:18 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:18 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:18 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:18 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:18 --> Controller Class Initialized
INFO - 2022-12-16 05:38:18 --> Final output sent to browser
DEBUG - 2022-12-16 05:38:18 --> Total execution time: 0.0637
INFO - 2022-12-16 05:38:32 --> Config Class Initialized
INFO - 2022-12-16 05:38:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:32 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:32 --> URI Class Initialized
INFO - 2022-12-16 05:38:32 --> Router Class Initialized
INFO - 2022-12-16 05:38:32 --> Output Class Initialized
INFO - 2022-12-16 05:38:32 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:32 --> Input Class Initialized
INFO - 2022-12-16 05:38:32 --> Language Class Initialized
INFO - 2022-12-16 05:38:32 --> Language Class Initialized
INFO - 2022-12-16 05:38:32 --> Config Class Initialized
INFO - 2022-12-16 05:38:32 --> Loader Class Initialized
INFO - 2022-12-16 05:38:32 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:32 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:32 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:32 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:33 --> Controller Class Initialized
INFO - 2022-12-16 05:38:33 --> Final output sent to browser
DEBUG - 2022-12-16 05:38:33 --> Total execution time: 0.0860
INFO - 2022-12-16 05:38:33 --> Config Class Initialized
INFO - 2022-12-16 05:38:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:33 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:33 --> URI Class Initialized
INFO - 2022-12-16 05:38:33 --> Router Class Initialized
INFO - 2022-12-16 05:38:33 --> Output Class Initialized
INFO - 2022-12-16 05:38:33 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:33 --> Input Class Initialized
INFO - 2022-12-16 05:38:33 --> Language Class Initialized
INFO - 2022-12-16 05:38:33 --> Language Class Initialized
INFO - 2022-12-16 05:38:33 --> Config Class Initialized
INFO - 2022-12-16 05:38:33 --> Loader Class Initialized
INFO - 2022-12-16 05:38:33 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:33 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:33 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:33 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:33 --> Controller Class Initialized
INFO - 2022-12-16 05:38:34 --> Config Class Initialized
INFO - 2022-12-16 05:38:34 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:34 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:34 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:34 --> URI Class Initialized
INFO - 2022-12-16 05:38:34 --> Router Class Initialized
INFO - 2022-12-16 05:38:34 --> Output Class Initialized
INFO - 2022-12-16 05:38:34 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:34 --> Input Class Initialized
INFO - 2022-12-16 05:38:34 --> Language Class Initialized
INFO - 2022-12-16 05:38:34 --> Language Class Initialized
INFO - 2022-12-16 05:38:34 --> Config Class Initialized
INFO - 2022-12-16 05:38:34 --> Loader Class Initialized
INFO - 2022-12-16 05:38:34 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:34 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:34 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:34 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:34 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:34 --> Controller Class Initialized
INFO - 2022-12-16 05:38:34 --> Final output sent to browser
DEBUG - 2022-12-16 05:38:34 --> Total execution time: 0.0726
INFO - 2022-12-16 05:38:51 --> Config Class Initialized
INFO - 2022-12-16 05:38:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:51 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:51 --> URI Class Initialized
INFO - 2022-12-16 05:38:51 --> Router Class Initialized
INFO - 2022-12-16 05:38:51 --> Output Class Initialized
INFO - 2022-12-16 05:38:51 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:51 --> Input Class Initialized
INFO - 2022-12-16 05:38:51 --> Language Class Initialized
INFO - 2022-12-16 05:38:51 --> Language Class Initialized
INFO - 2022-12-16 05:38:51 --> Config Class Initialized
INFO - 2022-12-16 05:38:51 --> Loader Class Initialized
INFO - 2022-12-16 05:38:51 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:51 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:51 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:51 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:51 --> Controller Class Initialized
INFO - 2022-12-16 05:38:51 --> Final output sent to browser
DEBUG - 2022-12-16 05:38:51 --> Total execution time: 0.0714
INFO - 2022-12-16 05:38:51 --> Config Class Initialized
INFO - 2022-12-16 05:38:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:51 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:51 --> URI Class Initialized
INFO - 2022-12-16 05:38:51 --> Router Class Initialized
INFO - 2022-12-16 05:38:51 --> Output Class Initialized
INFO - 2022-12-16 05:38:51 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:51 --> Input Class Initialized
INFO - 2022-12-16 05:38:51 --> Language Class Initialized
INFO - 2022-12-16 05:38:51 --> Language Class Initialized
INFO - 2022-12-16 05:38:51 --> Config Class Initialized
INFO - 2022-12-16 05:38:51 --> Loader Class Initialized
INFO - 2022-12-16 05:38:51 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:51 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:51 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:51 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:51 --> Controller Class Initialized
INFO - 2022-12-16 05:38:52 --> Config Class Initialized
INFO - 2022-12-16 05:38:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:38:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:38:52 --> Utf8 Class Initialized
INFO - 2022-12-16 05:38:52 --> URI Class Initialized
INFO - 2022-12-16 05:38:52 --> Router Class Initialized
INFO - 2022-12-16 05:38:52 --> Output Class Initialized
INFO - 2022-12-16 05:38:52 --> Security Class Initialized
DEBUG - 2022-12-16 05:38:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:38:52 --> Input Class Initialized
INFO - 2022-12-16 05:38:52 --> Language Class Initialized
INFO - 2022-12-16 05:38:52 --> Language Class Initialized
INFO - 2022-12-16 05:38:52 --> Config Class Initialized
INFO - 2022-12-16 05:38:52 --> Loader Class Initialized
INFO - 2022-12-16 05:38:52 --> Helper loaded: url_helper
INFO - 2022-12-16 05:38:52 --> Helper loaded: file_helper
INFO - 2022-12-16 05:38:52 --> Helper loaded: form_helper
INFO - 2022-12-16 05:38:52 --> Helper loaded: my_helper
INFO - 2022-12-16 05:38:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:38:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:38:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:38:52 --> Controller Class Initialized
INFO - 2022-12-16 05:38:52 --> Final output sent to browser
DEBUG - 2022-12-16 05:38:52 --> Total execution time: 0.0761
INFO - 2022-12-16 05:39:39 --> Config Class Initialized
INFO - 2022-12-16 05:39:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:39:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:39:39 --> Utf8 Class Initialized
INFO - 2022-12-16 05:39:39 --> URI Class Initialized
INFO - 2022-12-16 05:39:39 --> Router Class Initialized
INFO - 2022-12-16 05:39:39 --> Output Class Initialized
INFO - 2022-12-16 05:39:39 --> Security Class Initialized
DEBUG - 2022-12-16 05:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:39:39 --> Input Class Initialized
INFO - 2022-12-16 05:39:39 --> Language Class Initialized
INFO - 2022-12-16 05:39:39 --> Language Class Initialized
INFO - 2022-12-16 05:39:39 --> Config Class Initialized
INFO - 2022-12-16 05:39:39 --> Loader Class Initialized
INFO - 2022-12-16 05:39:39 --> Helper loaded: url_helper
INFO - 2022-12-16 05:39:39 --> Helper loaded: file_helper
INFO - 2022-12-16 05:39:39 --> Helper loaded: form_helper
INFO - 2022-12-16 05:39:39 --> Helper loaded: my_helper
INFO - 2022-12-16 05:39:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:39:39 --> Controller Class Initialized
INFO - 2022-12-16 05:39:39 --> Final output sent to browser
DEBUG - 2022-12-16 05:39:39 --> Total execution time: 0.0740
INFO - 2022-12-16 05:39:39 --> Config Class Initialized
INFO - 2022-12-16 05:39:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:39:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:39:39 --> Utf8 Class Initialized
INFO - 2022-12-16 05:39:39 --> URI Class Initialized
INFO - 2022-12-16 05:39:39 --> Router Class Initialized
INFO - 2022-12-16 05:39:39 --> Output Class Initialized
INFO - 2022-12-16 05:39:39 --> Security Class Initialized
DEBUG - 2022-12-16 05:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:39:39 --> Input Class Initialized
INFO - 2022-12-16 05:39:39 --> Language Class Initialized
INFO - 2022-12-16 05:39:39 --> Language Class Initialized
INFO - 2022-12-16 05:39:39 --> Config Class Initialized
INFO - 2022-12-16 05:39:39 --> Loader Class Initialized
INFO - 2022-12-16 05:39:39 --> Helper loaded: url_helper
INFO - 2022-12-16 05:39:39 --> Helper loaded: file_helper
INFO - 2022-12-16 05:39:39 --> Helper loaded: form_helper
INFO - 2022-12-16 05:39:39 --> Helper loaded: my_helper
INFO - 2022-12-16 05:39:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:39:39 --> Controller Class Initialized
INFO - 2022-12-16 05:39:40 --> Config Class Initialized
INFO - 2022-12-16 05:39:40 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:39:40 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:39:40 --> Utf8 Class Initialized
INFO - 2022-12-16 05:39:40 --> URI Class Initialized
INFO - 2022-12-16 05:39:40 --> Router Class Initialized
INFO - 2022-12-16 05:39:40 --> Output Class Initialized
INFO - 2022-12-16 05:39:40 --> Security Class Initialized
DEBUG - 2022-12-16 05:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:39:40 --> Input Class Initialized
INFO - 2022-12-16 05:39:40 --> Language Class Initialized
INFO - 2022-12-16 05:39:40 --> Language Class Initialized
INFO - 2022-12-16 05:39:40 --> Config Class Initialized
INFO - 2022-12-16 05:39:40 --> Loader Class Initialized
INFO - 2022-12-16 05:39:40 --> Helper loaded: url_helper
INFO - 2022-12-16 05:39:40 --> Helper loaded: file_helper
INFO - 2022-12-16 05:39:40 --> Helper loaded: form_helper
INFO - 2022-12-16 05:39:40 --> Helper loaded: my_helper
INFO - 2022-12-16 05:39:40 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:39:40 --> Controller Class Initialized
INFO - 2022-12-16 05:39:40 --> Final output sent to browser
DEBUG - 2022-12-16 05:39:40 --> Total execution time: 0.0574
INFO - 2022-12-16 05:39:50 --> Config Class Initialized
INFO - 2022-12-16 05:39:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:39:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:39:50 --> Utf8 Class Initialized
INFO - 2022-12-16 05:39:50 --> URI Class Initialized
INFO - 2022-12-16 05:39:50 --> Router Class Initialized
INFO - 2022-12-16 05:39:50 --> Output Class Initialized
INFO - 2022-12-16 05:39:50 --> Security Class Initialized
DEBUG - 2022-12-16 05:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:39:50 --> Input Class Initialized
INFO - 2022-12-16 05:39:50 --> Language Class Initialized
INFO - 2022-12-16 05:39:50 --> Language Class Initialized
INFO - 2022-12-16 05:39:50 --> Config Class Initialized
INFO - 2022-12-16 05:39:50 --> Loader Class Initialized
INFO - 2022-12-16 05:39:50 --> Helper loaded: url_helper
INFO - 2022-12-16 05:39:50 --> Helper loaded: file_helper
INFO - 2022-12-16 05:39:50 --> Helper loaded: form_helper
INFO - 2022-12-16 05:39:50 --> Helper loaded: my_helper
INFO - 2022-12-16 05:39:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:39:50 --> Controller Class Initialized
INFO - 2022-12-16 05:39:50 --> Final output sent to browser
DEBUG - 2022-12-16 05:39:50 --> Total execution time: 0.0730
INFO - 2022-12-16 05:39:50 --> Config Class Initialized
INFO - 2022-12-16 05:39:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:39:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:39:50 --> Utf8 Class Initialized
INFO - 2022-12-16 05:39:50 --> URI Class Initialized
INFO - 2022-12-16 05:39:50 --> Router Class Initialized
INFO - 2022-12-16 05:39:50 --> Output Class Initialized
INFO - 2022-12-16 05:39:50 --> Security Class Initialized
DEBUG - 2022-12-16 05:39:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:39:50 --> Input Class Initialized
INFO - 2022-12-16 05:39:50 --> Language Class Initialized
INFO - 2022-12-16 05:39:50 --> Language Class Initialized
INFO - 2022-12-16 05:39:50 --> Config Class Initialized
INFO - 2022-12-16 05:39:50 --> Loader Class Initialized
INFO - 2022-12-16 05:39:50 --> Helper loaded: url_helper
INFO - 2022-12-16 05:39:50 --> Helper loaded: file_helper
INFO - 2022-12-16 05:39:50 --> Helper loaded: form_helper
INFO - 2022-12-16 05:39:50 --> Helper loaded: my_helper
INFO - 2022-12-16 05:39:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:39:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:39:50 --> Controller Class Initialized
INFO - 2022-12-16 05:39:51 --> Config Class Initialized
INFO - 2022-12-16 05:39:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:39:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:39:51 --> Utf8 Class Initialized
INFO - 2022-12-16 05:39:51 --> URI Class Initialized
INFO - 2022-12-16 05:39:51 --> Router Class Initialized
INFO - 2022-12-16 05:39:51 --> Output Class Initialized
INFO - 2022-12-16 05:39:51 --> Security Class Initialized
DEBUG - 2022-12-16 05:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:39:51 --> Input Class Initialized
INFO - 2022-12-16 05:39:51 --> Language Class Initialized
INFO - 2022-12-16 05:39:51 --> Language Class Initialized
INFO - 2022-12-16 05:39:51 --> Config Class Initialized
INFO - 2022-12-16 05:39:51 --> Loader Class Initialized
INFO - 2022-12-16 05:39:51 --> Helper loaded: url_helper
INFO - 2022-12-16 05:39:51 --> Helper loaded: file_helper
INFO - 2022-12-16 05:39:51 --> Helper loaded: form_helper
INFO - 2022-12-16 05:39:51 --> Helper loaded: my_helper
INFO - 2022-12-16 05:39:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:39:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:39:51 --> Controller Class Initialized
INFO - 2022-12-16 05:39:51 --> Final output sent to browser
DEBUG - 2022-12-16 05:39:51 --> Total execution time: 0.0693
INFO - 2022-12-16 05:40:06 --> Config Class Initialized
INFO - 2022-12-16 05:40:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:06 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:06 --> URI Class Initialized
INFO - 2022-12-16 05:40:06 --> Router Class Initialized
INFO - 2022-12-16 05:40:06 --> Output Class Initialized
INFO - 2022-12-16 05:40:06 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:06 --> Input Class Initialized
INFO - 2022-12-16 05:40:06 --> Language Class Initialized
INFO - 2022-12-16 05:40:06 --> Language Class Initialized
INFO - 2022-12-16 05:40:06 --> Config Class Initialized
INFO - 2022-12-16 05:40:06 --> Loader Class Initialized
INFO - 2022-12-16 05:40:06 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:06 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:06 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:06 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:06 --> Controller Class Initialized
INFO - 2022-12-16 05:40:06 --> Final output sent to browser
DEBUG - 2022-12-16 05:40:06 --> Total execution time: 0.0622
INFO - 2022-12-16 05:40:06 --> Config Class Initialized
INFO - 2022-12-16 05:40:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:06 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:06 --> URI Class Initialized
INFO - 2022-12-16 05:40:06 --> Router Class Initialized
INFO - 2022-12-16 05:40:06 --> Output Class Initialized
INFO - 2022-12-16 05:40:06 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:06 --> Input Class Initialized
INFO - 2022-12-16 05:40:06 --> Language Class Initialized
INFO - 2022-12-16 05:40:06 --> Language Class Initialized
INFO - 2022-12-16 05:40:06 --> Config Class Initialized
INFO - 2022-12-16 05:40:06 --> Loader Class Initialized
INFO - 2022-12-16 05:40:06 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:06 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:06 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:06 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:06 --> Controller Class Initialized
INFO - 2022-12-16 05:40:10 --> Config Class Initialized
INFO - 2022-12-16 05:40:10 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:10 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:10 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:10 --> URI Class Initialized
INFO - 2022-12-16 05:40:10 --> Router Class Initialized
INFO - 2022-12-16 05:40:10 --> Output Class Initialized
INFO - 2022-12-16 05:40:10 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:10 --> Input Class Initialized
INFO - 2022-12-16 05:40:10 --> Language Class Initialized
INFO - 2022-12-16 05:40:10 --> Language Class Initialized
INFO - 2022-12-16 05:40:10 --> Config Class Initialized
INFO - 2022-12-16 05:40:10 --> Loader Class Initialized
INFO - 2022-12-16 05:40:10 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:10 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:10 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:10 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:10 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:10 --> Controller Class Initialized
INFO - 2022-12-16 05:40:10 --> Final output sent to browser
DEBUG - 2022-12-16 05:40:10 --> Total execution time: 0.0795
INFO - 2022-12-16 05:40:24 --> Config Class Initialized
INFO - 2022-12-16 05:40:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:24 --> URI Class Initialized
INFO - 2022-12-16 05:40:24 --> Router Class Initialized
INFO - 2022-12-16 05:40:24 --> Output Class Initialized
INFO - 2022-12-16 05:40:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:24 --> Input Class Initialized
INFO - 2022-12-16 05:40:24 --> Language Class Initialized
INFO - 2022-12-16 05:40:24 --> Language Class Initialized
INFO - 2022-12-16 05:40:24 --> Config Class Initialized
INFO - 2022-12-16 05:40:24 --> Loader Class Initialized
INFO - 2022-12-16 05:40:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:24 --> Controller Class Initialized
INFO - 2022-12-16 05:40:24 --> Final output sent to browser
DEBUG - 2022-12-16 05:40:24 --> Total execution time: 0.0696
INFO - 2022-12-16 05:40:24 --> Config Class Initialized
INFO - 2022-12-16 05:40:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:24 --> URI Class Initialized
INFO - 2022-12-16 05:40:24 --> Router Class Initialized
INFO - 2022-12-16 05:40:24 --> Output Class Initialized
INFO - 2022-12-16 05:40:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:24 --> Input Class Initialized
INFO - 2022-12-16 05:40:24 --> Language Class Initialized
INFO - 2022-12-16 05:40:24 --> Language Class Initialized
INFO - 2022-12-16 05:40:24 --> Config Class Initialized
INFO - 2022-12-16 05:40:24 --> Loader Class Initialized
INFO - 2022-12-16 05:40:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:24 --> Controller Class Initialized
INFO - 2022-12-16 05:40:26 --> Config Class Initialized
INFO - 2022-12-16 05:40:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:26 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:26 --> URI Class Initialized
INFO - 2022-12-16 05:40:26 --> Router Class Initialized
INFO - 2022-12-16 05:40:26 --> Output Class Initialized
INFO - 2022-12-16 05:40:26 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:26 --> Input Class Initialized
INFO - 2022-12-16 05:40:26 --> Language Class Initialized
INFO - 2022-12-16 05:40:26 --> Language Class Initialized
INFO - 2022-12-16 05:40:26 --> Config Class Initialized
INFO - 2022-12-16 05:40:26 --> Loader Class Initialized
INFO - 2022-12-16 05:40:26 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:26 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:26 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:26 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:26 --> Controller Class Initialized
INFO - 2022-12-16 05:40:26 --> Final output sent to browser
DEBUG - 2022-12-16 05:40:26 --> Total execution time: 0.0731
INFO - 2022-12-16 05:40:38 --> Config Class Initialized
INFO - 2022-12-16 05:40:38 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:38 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:38 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:38 --> URI Class Initialized
INFO - 2022-12-16 05:40:38 --> Router Class Initialized
INFO - 2022-12-16 05:40:38 --> Output Class Initialized
INFO - 2022-12-16 05:40:38 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:38 --> Input Class Initialized
INFO - 2022-12-16 05:40:38 --> Language Class Initialized
INFO - 2022-12-16 05:40:38 --> Language Class Initialized
INFO - 2022-12-16 05:40:38 --> Config Class Initialized
INFO - 2022-12-16 05:40:38 --> Loader Class Initialized
INFO - 2022-12-16 05:40:38 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:38 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:38 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:38 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:38 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:38 --> Controller Class Initialized
INFO - 2022-12-16 05:40:38 --> Final output sent to browser
DEBUG - 2022-12-16 05:40:38 --> Total execution time: 0.0724
INFO - 2022-12-16 05:40:38 --> Config Class Initialized
INFO - 2022-12-16 05:40:38 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:38 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:38 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:38 --> URI Class Initialized
INFO - 2022-12-16 05:40:38 --> Router Class Initialized
INFO - 2022-12-16 05:40:38 --> Output Class Initialized
INFO - 2022-12-16 05:40:38 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:39 --> Input Class Initialized
INFO - 2022-12-16 05:40:39 --> Language Class Initialized
INFO - 2022-12-16 05:40:39 --> Language Class Initialized
INFO - 2022-12-16 05:40:39 --> Config Class Initialized
INFO - 2022-12-16 05:40:39 --> Loader Class Initialized
INFO - 2022-12-16 05:40:39 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:39 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:39 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:39 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:39 --> Controller Class Initialized
INFO - 2022-12-16 05:40:54 --> Config Class Initialized
INFO - 2022-12-16 05:40:54 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:40:54 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:40:54 --> Utf8 Class Initialized
INFO - 2022-12-16 05:40:54 --> URI Class Initialized
INFO - 2022-12-16 05:40:54 --> Router Class Initialized
INFO - 2022-12-16 05:40:54 --> Output Class Initialized
INFO - 2022-12-16 05:40:54 --> Security Class Initialized
DEBUG - 2022-12-16 05:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:40:54 --> Input Class Initialized
INFO - 2022-12-16 05:40:54 --> Language Class Initialized
INFO - 2022-12-16 05:40:54 --> Language Class Initialized
INFO - 2022-12-16 05:40:54 --> Config Class Initialized
INFO - 2022-12-16 05:40:54 --> Loader Class Initialized
INFO - 2022-12-16 05:40:54 --> Helper loaded: url_helper
INFO - 2022-12-16 05:40:54 --> Helper loaded: file_helper
INFO - 2022-12-16 05:40:54 --> Helper loaded: form_helper
INFO - 2022-12-16 05:40:54 --> Helper loaded: my_helper
INFO - 2022-12-16 05:40:54 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:40:54 --> Controller Class Initialized
INFO - 2022-12-16 05:40:54 --> Final output sent to browser
DEBUG - 2022-12-16 05:40:54 --> Total execution time: 0.0676
INFO - 2022-12-16 05:41:02 --> Config Class Initialized
INFO - 2022-12-16 05:41:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:02 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:02 --> URI Class Initialized
INFO - 2022-12-16 05:41:02 --> Router Class Initialized
INFO - 2022-12-16 05:41:02 --> Output Class Initialized
INFO - 2022-12-16 05:41:02 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:02 --> Input Class Initialized
INFO - 2022-12-16 05:41:02 --> Language Class Initialized
INFO - 2022-12-16 05:41:02 --> Language Class Initialized
INFO - 2022-12-16 05:41:02 --> Config Class Initialized
INFO - 2022-12-16 05:41:02 --> Loader Class Initialized
INFO - 2022-12-16 05:41:02 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:02 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:02 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:02 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:02 --> Controller Class Initialized
INFO - 2022-12-16 05:41:02 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:02 --> Total execution time: 0.0695
INFO - 2022-12-16 05:41:02 --> Config Class Initialized
INFO - 2022-12-16 05:41:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:02 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:02 --> URI Class Initialized
INFO - 2022-12-16 05:41:02 --> Router Class Initialized
INFO - 2022-12-16 05:41:02 --> Output Class Initialized
INFO - 2022-12-16 05:41:02 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:02 --> Input Class Initialized
INFO - 2022-12-16 05:41:02 --> Language Class Initialized
INFO - 2022-12-16 05:41:02 --> Language Class Initialized
INFO - 2022-12-16 05:41:02 --> Config Class Initialized
INFO - 2022-12-16 05:41:02 --> Loader Class Initialized
INFO - 2022-12-16 05:41:02 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:02 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:02 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:02 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:02 --> Controller Class Initialized
INFO - 2022-12-16 05:41:03 --> Config Class Initialized
INFO - 2022-12-16 05:41:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:03 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:03 --> URI Class Initialized
INFO - 2022-12-16 05:41:03 --> Router Class Initialized
INFO - 2022-12-16 05:41:03 --> Output Class Initialized
INFO - 2022-12-16 05:41:03 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:03 --> Input Class Initialized
INFO - 2022-12-16 05:41:03 --> Language Class Initialized
INFO - 2022-12-16 05:41:03 --> Language Class Initialized
INFO - 2022-12-16 05:41:03 --> Config Class Initialized
INFO - 2022-12-16 05:41:03 --> Loader Class Initialized
INFO - 2022-12-16 05:41:03 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:03 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:03 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:03 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:03 --> Controller Class Initialized
INFO - 2022-12-16 05:41:03 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:03 --> Total execution time: 0.0743
INFO - 2022-12-16 05:41:11 --> Config Class Initialized
INFO - 2022-12-16 05:41:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:11 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:11 --> URI Class Initialized
INFO - 2022-12-16 05:41:11 --> Router Class Initialized
INFO - 2022-12-16 05:41:11 --> Output Class Initialized
INFO - 2022-12-16 05:41:11 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:11 --> Input Class Initialized
INFO - 2022-12-16 05:41:11 --> Language Class Initialized
INFO - 2022-12-16 05:41:11 --> Language Class Initialized
INFO - 2022-12-16 05:41:11 --> Config Class Initialized
INFO - 2022-12-16 05:41:11 --> Loader Class Initialized
INFO - 2022-12-16 05:41:11 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:11 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:11 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:11 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:12 --> Controller Class Initialized
INFO - 2022-12-16 05:41:12 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:12 --> Total execution time: 0.0755
INFO - 2022-12-16 05:41:12 --> Config Class Initialized
INFO - 2022-12-16 05:41:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:12 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:12 --> URI Class Initialized
INFO - 2022-12-16 05:41:12 --> Router Class Initialized
INFO - 2022-12-16 05:41:12 --> Output Class Initialized
INFO - 2022-12-16 05:41:12 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:12 --> Input Class Initialized
INFO - 2022-12-16 05:41:12 --> Language Class Initialized
INFO - 2022-12-16 05:41:12 --> Language Class Initialized
INFO - 2022-12-16 05:41:12 --> Config Class Initialized
INFO - 2022-12-16 05:41:12 --> Loader Class Initialized
INFO - 2022-12-16 05:41:12 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:12 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:12 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:12 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:12 --> Controller Class Initialized
INFO - 2022-12-16 05:41:13 --> Config Class Initialized
INFO - 2022-12-16 05:41:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:13 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:13 --> URI Class Initialized
INFO - 2022-12-16 05:41:13 --> Router Class Initialized
INFO - 2022-12-16 05:41:13 --> Output Class Initialized
INFO - 2022-12-16 05:41:13 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:13 --> Input Class Initialized
INFO - 2022-12-16 05:41:13 --> Language Class Initialized
INFO - 2022-12-16 05:41:13 --> Language Class Initialized
INFO - 2022-12-16 05:41:13 --> Config Class Initialized
INFO - 2022-12-16 05:41:13 --> Loader Class Initialized
INFO - 2022-12-16 05:41:13 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:13 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:13 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:13 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:13 --> Controller Class Initialized
INFO - 2022-12-16 05:41:13 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:13 --> Total execution time: 0.0761
INFO - 2022-12-16 05:41:24 --> Config Class Initialized
INFO - 2022-12-16 05:41:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:24 --> URI Class Initialized
INFO - 2022-12-16 05:41:24 --> Router Class Initialized
INFO - 2022-12-16 05:41:24 --> Output Class Initialized
INFO - 2022-12-16 05:41:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:24 --> Input Class Initialized
INFO - 2022-12-16 05:41:24 --> Language Class Initialized
INFO - 2022-12-16 05:41:24 --> Language Class Initialized
INFO - 2022-12-16 05:41:24 --> Config Class Initialized
INFO - 2022-12-16 05:41:24 --> Loader Class Initialized
INFO - 2022-12-16 05:41:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:24 --> Controller Class Initialized
INFO - 2022-12-16 05:41:24 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:24 --> Total execution time: 0.0801
INFO - 2022-12-16 05:41:24 --> Config Class Initialized
INFO - 2022-12-16 05:41:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:24 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:24 --> URI Class Initialized
INFO - 2022-12-16 05:41:24 --> Router Class Initialized
INFO - 2022-12-16 05:41:24 --> Output Class Initialized
INFO - 2022-12-16 05:41:24 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:24 --> Input Class Initialized
INFO - 2022-12-16 05:41:24 --> Language Class Initialized
INFO - 2022-12-16 05:41:24 --> Language Class Initialized
INFO - 2022-12-16 05:41:24 --> Config Class Initialized
INFO - 2022-12-16 05:41:24 --> Loader Class Initialized
INFO - 2022-12-16 05:41:24 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:24 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:24 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:24 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:24 --> Controller Class Initialized
INFO - 2022-12-16 05:41:26 --> Config Class Initialized
INFO - 2022-12-16 05:41:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:26 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:26 --> URI Class Initialized
INFO - 2022-12-16 05:41:26 --> Router Class Initialized
INFO - 2022-12-16 05:41:26 --> Output Class Initialized
INFO - 2022-12-16 05:41:26 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:26 --> Input Class Initialized
INFO - 2022-12-16 05:41:26 --> Language Class Initialized
INFO - 2022-12-16 05:41:26 --> Language Class Initialized
INFO - 2022-12-16 05:41:26 --> Config Class Initialized
INFO - 2022-12-16 05:41:26 --> Loader Class Initialized
INFO - 2022-12-16 05:41:26 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:26 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:26 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:26 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:26 --> Controller Class Initialized
INFO - 2022-12-16 05:41:26 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:26 --> Total execution time: 0.0691
INFO - 2022-12-16 05:41:35 --> Config Class Initialized
INFO - 2022-12-16 05:41:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:35 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:35 --> URI Class Initialized
INFO - 2022-12-16 05:41:35 --> Router Class Initialized
INFO - 2022-12-16 05:41:35 --> Output Class Initialized
INFO - 2022-12-16 05:41:35 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:35 --> Input Class Initialized
INFO - 2022-12-16 05:41:35 --> Language Class Initialized
INFO - 2022-12-16 05:41:35 --> Language Class Initialized
INFO - 2022-12-16 05:41:35 --> Config Class Initialized
INFO - 2022-12-16 05:41:35 --> Loader Class Initialized
INFO - 2022-12-16 05:41:35 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:35 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:35 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:35 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:35 --> Controller Class Initialized
INFO - 2022-12-16 05:41:35 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:35 --> Total execution time: 0.0788
INFO - 2022-12-16 05:41:35 --> Config Class Initialized
INFO - 2022-12-16 05:41:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:35 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:35 --> URI Class Initialized
INFO - 2022-12-16 05:41:35 --> Router Class Initialized
INFO - 2022-12-16 05:41:35 --> Output Class Initialized
INFO - 2022-12-16 05:41:35 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:35 --> Input Class Initialized
INFO - 2022-12-16 05:41:35 --> Language Class Initialized
INFO - 2022-12-16 05:41:35 --> Language Class Initialized
INFO - 2022-12-16 05:41:35 --> Config Class Initialized
INFO - 2022-12-16 05:41:35 --> Loader Class Initialized
INFO - 2022-12-16 05:41:35 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:35 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:35 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:35 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:35 --> Controller Class Initialized
INFO - 2022-12-16 05:41:36 --> Config Class Initialized
INFO - 2022-12-16 05:41:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:36 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:36 --> URI Class Initialized
INFO - 2022-12-16 05:41:36 --> Router Class Initialized
INFO - 2022-12-16 05:41:36 --> Output Class Initialized
INFO - 2022-12-16 05:41:36 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:36 --> Input Class Initialized
INFO - 2022-12-16 05:41:36 --> Language Class Initialized
INFO - 2022-12-16 05:41:36 --> Language Class Initialized
INFO - 2022-12-16 05:41:36 --> Config Class Initialized
INFO - 2022-12-16 05:41:36 --> Loader Class Initialized
INFO - 2022-12-16 05:41:36 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:36 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:36 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:36 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:36 --> Controller Class Initialized
INFO - 2022-12-16 05:41:36 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:36 --> Total execution time: 0.0756
INFO - 2022-12-16 05:41:47 --> Config Class Initialized
INFO - 2022-12-16 05:41:47 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:47 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:47 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:47 --> URI Class Initialized
INFO - 2022-12-16 05:41:47 --> Router Class Initialized
INFO - 2022-12-16 05:41:47 --> Output Class Initialized
INFO - 2022-12-16 05:41:47 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:47 --> Input Class Initialized
INFO - 2022-12-16 05:41:47 --> Language Class Initialized
INFO - 2022-12-16 05:41:47 --> Language Class Initialized
INFO - 2022-12-16 05:41:47 --> Config Class Initialized
INFO - 2022-12-16 05:41:47 --> Loader Class Initialized
INFO - 2022-12-16 05:41:47 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:47 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:47 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:47 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:47 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:47 --> Controller Class Initialized
INFO - 2022-12-16 05:41:47 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:47 --> Total execution time: 0.0682
INFO - 2022-12-16 05:41:47 --> Config Class Initialized
INFO - 2022-12-16 05:41:47 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:47 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:47 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:47 --> URI Class Initialized
INFO - 2022-12-16 05:41:47 --> Router Class Initialized
INFO - 2022-12-16 05:41:47 --> Output Class Initialized
INFO - 2022-12-16 05:41:47 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:47 --> Input Class Initialized
INFO - 2022-12-16 05:41:47 --> Language Class Initialized
INFO - 2022-12-16 05:41:47 --> Language Class Initialized
INFO - 2022-12-16 05:41:47 --> Config Class Initialized
INFO - 2022-12-16 05:41:47 --> Loader Class Initialized
INFO - 2022-12-16 05:41:47 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:47 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:47 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:47 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:47 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:47 --> Controller Class Initialized
INFO - 2022-12-16 05:41:50 --> Config Class Initialized
INFO - 2022-12-16 05:41:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:50 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:50 --> URI Class Initialized
INFO - 2022-12-16 05:41:50 --> Router Class Initialized
INFO - 2022-12-16 05:41:50 --> Output Class Initialized
INFO - 2022-12-16 05:41:50 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:50 --> Input Class Initialized
INFO - 2022-12-16 05:41:50 --> Language Class Initialized
INFO - 2022-12-16 05:41:50 --> Language Class Initialized
INFO - 2022-12-16 05:41:50 --> Config Class Initialized
INFO - 2022-12-16 05:41:50 --> Loader Class Initialized
INFO - 2022-12-16 05:41:50 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:50 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:50 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:50 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:50 --> Controller Class Initialized
INFO - 2022-12-16 05:41:52 --> Config Class Initialized
INFO - 2022-12-16 05:41:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:41:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:41:52 --> Utf8 Class Initialized
INFO - 2022-12-16 05:41:52 --> URI Class Initialized
INFO - 2022-12-16 05:41:52 --> Router Class Initialized
INFO - 2022-12-16 05:41:52 --> Output Class Initialized
INFO - 2022-12-16 05:41:52 --> Security Class Initialized
DEBUG - 2022-12-16 05:41:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:41:52 --> Input Class Initialized
INFO - 2022-12-16 05:41:52 --> Language Class Initialized
INFO - 2022-12-16 05:41:52 --> Language Class Initialized
INFO - 2022-12-16 05:41:52 --> Config Class Initialized
INFO - 2022-12-16 05:41:52 --> Loader Class Initialized
INFO - 2022-12-16 05:41:52 --> Helper loaded: url_helper
INFO - 2022-12-16 05:41:52 --> Helper loaded: file_helper
INFO - 2022-12-16 05:41:52 --> Helper loaded: form_helper
INFO - 2022-12-16 05:41:52 --> Helper loaded: my_helper
INFO - 2022-12-16 05:41:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:41:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:41:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:41:52 --> Controller Class Initialized
INFO - 2022-12-16 05:41:52 --> Final output sent to browser
DEBUG - 2022-12-16 05:41:52 --> Total execution time: 0.0532
INFO - 2022-12-16 05:42:03 --> Config Class Initialized
INFO - 2022-12-16 05:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:42:03 --> Utf8 Class Initialized
INFO - 2022-12-16 05:42:03 --> URI Class Initialized
INFO - 2022-12-16 05:42:03 --> Router Class Initialized
INFO - 2022-12-16 05:42:03 --> Output Class Initialized
INFO - 2022-12-16 05:42:03 --> Security Class Initialized
DEBUG - 2022-12-16 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:42:03 --> Input Class Initialized
INFO - 2022-12-16 05:42:03 --> Language Class Initialized
INFO - 2022-12-16 05:42:03 --> Language Class Initialized
INFO - 2022-12-16 05:42:03 --> Config Class Initialized
INFO - 2022-12-16 05:42:03 --> Loader Class Initialized
INFO - 2022-12-16 05:42:03 --> Helper loaded: url_helper
INFO - 2022-12-16 05:42:03 --> Helper loaded: file_helper
INFO - 2022-12-16 05:42:03 --> Helper loaded: form_helper
INFO - 2022-12-16 05:42:03 --> Helper loaded: my_helper
INFO - 2022-12-16 05:42:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:42:03 --> Controller Class Initialized
INFO - 2022-12-16 05:42:03 --> Final output sent to browser
DEBUG - 2022-12-16 05:42:03 --> Total execution time: 0.0812
INFO - 2022-12-16 05:42:03 --> Config Class Initialized
INFO - 2022-12-16 05:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:42:03 --> Utf8 Class Initialized
INFO - 2022-12-16 05:42:03 --> URI Class Initialized
INFO - 2022-12-16 05:42:03 --> Router Class Initialized
INFO - 2022-12-16 05:42:03 --> Output Class Initialized
INFO - 2022-12-16 05:42:03 --> Security Class Initialized
DEBUG - 2022-12-16 05:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:42:03 --> Input Class Initialized
INFO - 2022-12-16 05:42:03 --> Language Class Initialized
INFO - 2022-12-16 05:42:03 --> Language Class Initialized
INFO - 2022-12-16 05:42:03 --> Config Class Initialized
INFO - 2022-12-16 05:42:03 --> Loader Class Initialized
INFO - 2022-12-16 05:42:03 --> Helper loaded: url_helper
INFO - 2022-12-16 05:42:03 --> Helper loaded: file_helper
INFO - 2022-12-16 05:42:03 --> Helper loaded: form_helper
INFO - 2022-12-16 05:42:03 --> Helper loaded: my_helper
INFO - 2022-12-16 05:42:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:42:03 --> Controller Class Initialized
INFO - 2022-12-16 05:42:04 --> Config Class Initialized
INFO - 2022-12-16 05:42:04 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:42:04 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:42:04 --> Utf8 Class Initialized
INFO - 2022-12-16 05:42:04 --> URI Class Initialized
INFO - 2022-12-16 05:42:04 --> Router Class Initialized
INFO - 2022-12-16 05:42:04 --> Output Class Initialized
INFO - 2022-12-16 05:42:04 --> Security Class Initialized
DEBUG - 2022-12-16 05:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:42:04 --> Input Class Initialized
INFO - 2022-12-16 05:42:05 --> Language Class Initialized
INFO - 2022-12-16 05:42:05 --> Language Class Initialized
INFO - 2022-12-16 05:42:05 --> Config Class Initialized
INFO - 2022-12-16 05:42:05 --> Loader Class Initialized
INFO - 2022-12-16 05:42:05 --> Helper loaded: url_helper
INFO - 2022-12-16 05:42:05 --> Helper loaded: file_helper
INFO - 2022-12-16 05:42:05 --> Helper loaded: form_helper
INFO - 2022-12-16 05:42:05 --> Helper loaded: my_helper
INFO - 2022-12-16 05:42:05 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:42:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:42:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:42:05 --> Controller Class Initialized
INFO - 2022-12-16 05:42:05 --> Final output sent to browser
DEBUG - 2022-12-16 05:42:05 --> Total execution time: 0.0599
INFO - 2022-12-16 05:42:13 --> Config Class Initialized
INFO - 2022-12-16 05:42:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:42:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:42:13 --> Utf8 Class Initialized
INFO - 2022-12-16 05:42:13 --> URI Class Initialized
INFO - 2022-12-16 05:42:13 --> Router Class Initialized
INFO - 2022-12-16 05:42:13 --> Output Class Initialized
INFO - 2022-12-16 05:42:13 --> Security Class Initialized
DEBUG - 2022-12-16 05:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:42:13 --> Input Class Initialized
INFO - 2022-12-16 05:42:13 --> Language Class Initialized
INFO - 2022-12-16 05:42:13 --> Language Class Initialized
INFO - 2022-12-16 05:42:13 --> Config Class Initialized
INFO - 2022-12-16 05:42:13 --> Loader Class Initialized
INFO - 2022-12-16 05:42:13 --> Helper loaded: url_helper
INFO - 2022-12-16 05:42:13 --> Helper loaded: file_helper
INFO - 2022-12-16 05:42:13 --> Helper loaded: form_helper
INFO - 2022-12-16 05:42:13 --> Helper loaded: my_helper
INFO - 2022-12-16 05:42:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:42:13 --> Controller Class Initialized
INFO - 2022-12-16 05:42:13 --> Final output sent to browser
DEBUG - 2022-12-16 05:42:13 --> Total execution time: 0.0661
INFO - 2022-12-16 05:42:13 --> Config Class Initialized
INFO - 2022-12-16 05:42:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:42:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:42:13 --> Utf8 Class Initialized
INFO - 2022-12-16 05:42:13 --> URI Class Initialized
INFO - 2022-12-16 05:42:13 --> Router Class Initialized
INFO - 2022-12-16 05:42:13 --> Output Class Initialized
INFO - 2022-12-16 05:42:13 --> Security Class Initialized
DEBUG - 2022-12-16 05:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:42:13 --> Input Class Initialized
INFO - 2022-12-16 05:42:13 --> Language Class Initialized
INFO - 2022-12-16 05:42:13 --> Language Class Initialized
INFO - 2022-12-16 05:42:13 --> Config Class Initialized
INFO - 2022-12-16 05:42:13 --> Loader Class Initialized
INFO - 2022-12-16 05:42:13 --> Helper loaded: url_helper
INFO - 2022-12-16 05:42:13 --> Helper loaded: file_helper
INFO - 2022-12-16 05:42:13 --> Helper loaded: form_helper
INFO - 2022-12-16 05:42:13 --> Helper loaded: my_helper
INFO - 2022-12-16 05:42:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:42:13 --> Controller Class Initialized
INFO - 2022-12-16 05:42:16 --> Config Class Initialized
INFO - 2022-12-16 05:42:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 05:42:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 05:42:16 --> Utf8 Class Initialized
INFO - 2022-12-16 05:42:16 --> URI Class Initialized
INFO - 2022-12-16 05:42:16 --> Router Class Initialized
INFO - 2022-12-16 05:42:16 --> Output Class Initialized
INFO - 2022-12-16 05:42:16 --> Security Class Initialized
DEBUG - 2022-12-16 05:42:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 05:42:16 --> Input Class Initialized
INFO - 2022-12-16 05:42:16 --> Language Class Initialized
INFO - 2022-12-16 05:42:16 --> Language Class Initialized
INFO - 2022-12-16 05:42:16 --> Config Class Initialized
INFO - 2022-12-16 05:42:16 --> Loader Class Initialized
INFO - 2022-12-16 05:42:16 --> Helper loaded: url_helper
INFO - 2022-12-16 05:42:16 --> Helper loaded: file_helper
INFO - 2022-12-16 05:42:16 --> Helper loaded: form_helper
INFO - 2022-12-16 05:42:16 --> Helper loaded: my_helper
INFO - 2022-12-16 05:42:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 05:42:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 05:42:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 05:42:16 --> Controller Class Initialized
INFO - 2022-12-16 07:14:14 --> Config Class Initialized
INFO - 2022-12-16 07:14:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:14:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:14:14 --> Utf8 Class Initialized
INFO - 2022-12-16 07:14:14 --> URI Class Initialized
DEBUG - 2022-12-16 07:14:14 --> No URI present. Default controller set.
INFO - 2022-12-16 07:14:14 --> Router Class Initialized
INFO - 2022-12-16 07:14:14 --> Output Class Initialized
INFO - 2022-12-16 07:14:14 --> Security Class Initialized
DEBUG - 2022-12-16 07:14:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:14:14 --> Input Class Initialized
INFO - 2022-12-16 07:14:14 --> Language Class Initialized
INFO - 2022-12-16 07:14:14 --> Language Class Initialized
INFO - 2022-12-16 07:14:14 --> Config Class Initialized
INFO - 2022-12-16 07:14:14 --> Loader Class Initialized
INFO - 2022-12-16 07:14:14 --> Helper loaded: url_helper
INFO - 2022-12-16 07:14:14 --> Helper loaded: file_helper
INFO - 2022-12-16 07:14:14 --> Helper loaded: form_helper
INFO - 2022-12-16 07:14:14 --> Helper loaded: my_helper
INFO - 2022-12-16 07:14:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:14:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:14:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:14:14 --> Controller Class Initialized
INFO - 2022-12-16 07:14:15 --> Config Class Initialized
INFO - 2022-12-16 07:14:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:14:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:14:15 --> Utf8 Class Initialized
INFO - 2022-12-16 07:14:15 --> URI Class Initialized
INFO - 2022-12-16 07:14:15 --> Router Class Initialized
INFO - 2022-12-16 07:14:15 --> Output Class Initialized
INFO - 2022-12-16 07:14:15 --> Security Class Initialized
DEBUG - 2022-12-16 07:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:14:15 --> Input Class Initialized
INFO - 2022-12-16 07:14:15 --> Language Class Initialized
INFO - 2022-12-16 07:14:15 --> Language Class Initialized
INFO - 2022-12-16 07:14:15 --> Config Class Initialized
INFO - 2022-12-16 07:14:15 --> Loader Class Initialized
INFO - 2022-12-16 07:14:15 --> Helper loaded: url_helper
INFO - 2022-12-16 07:14:15 --> Helper loaded: file_helper
INFO - 2022-12-16 07:14:15 --> Helper loaded: form_helper
INFO - 2022-12-16 07:14:15 --> Helper loaded: my_helper
INFO - 2022-12-16 07:14:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:14:15 --> Controller Class Initialized
DEBUG - 2022-12-16 07:14:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2022-12-16 07:14:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:14:15 --> Final output sent to browser
DEBUG - 2022-12-16 07:14:15 --> Total execution time: 0.0676
INFO - 2022-12-16 07:15:20 --> Config Class Initialized
INFO - 2022-12-16 07:15:20 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:15:20 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:15:20 --> Utf8 Class Initialized
INFO - 2022-12-16 07:15:20 --> URI Class Initialized
INFO - 2022-12-16 07:15:20 --> Router Class Initialized
INFO - 2022-12-16 07:15:20 --> Output Class Initialized
INFO - 2022-12-16 07:15:20 --> Security Class Initialized
DEBUG - 2022-12-16 07:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:15:20 --> Input Class Initialized
INFO - 2022-12-16 07:15:20 --> Language Class Initialized
INFO - 2022-12-16 07:15:20 --> Language Class Initialized
INFO - 2022-12-16 07:15:20 --> Config Class Initialized
INFO - 2022-12-16 07:15:20 --> Loader Class Initialized
INFO - 2022-12-16 07:15:20 --> Helper loaded: url_helper
INFO - 2022-12-16 07:15:20 --> Helper loaded: file_helper
INFO - 2022-12-16 07:15:20 --> Helper loaded: form_helper
INFO - 2022-12-16 07:15:20 --> Helper loaded: my_helper
INFO - 2022-12-16 07:15:20 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:15:20 --> Controller Class Initialized
INFO - 2022-12-16 07:15:20 --> Helper loaded: cookie_helper
INFO - 2022-12-16 07:15:20 --> Final output sent to browser
DEBUG - 2022-12-16 07:15:20 --> Total execution time: 0.0852
INFO - 2022-12-16 07:15:21 --> Config Class Initialized
INFO - 2022-12-16 07:15:21 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:15:21 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:15:21 --> Utf8 Class Initialized
INFO - 2022-12-16 07:15:21 --> URI Class Initialized
INFO - 2022-12-16 07:15:21 --> Router Class Initialized
INFO - 2022-12-16 07:15:21 --> Output Class Initialized
INFO - 2022-12-16 07:15:21 --> Security Class Initialized
DEBUG - 2022-12-16 07:15:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:15:21 --> Input Class Initialized
INFO - 2022-12-16 07:15:21 --> Language Class Initialized
INFO - 2022-12-16 07:15:21 --> Language Class Initialized
INFO - 2022-12-16 07:15:21 --> Config Class Initialized
INFO - 2022-12-16 07:15:21 --> Loader Class Initialized
INFO - 2022-12-16 07:15:21 --> Helper loaded: url_helper
INFO - 2022-12-16 07:15:21 --> Helper loaded: file_helper
INFO - 2022-12-16 07:15:21 --> Helper loaded: form_helper
INFO - 2022-12-16 07:15:21 --> Helper loaded: my_helper
INFO - 2022-12-16 07:15:21 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:15:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:15:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:15:21 --> Controller Class Initialized
DEBUG - 2022-12-16 07:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2022-12-16 07:15:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:15:21 --> Final output sent to browser
DEBUG - 2022-12-16 07:15:21 --> Total execution time: 0.1010
INFO - 2022-12-16 07:16:29 --> Config Class Initialized
INFO - 2022-12-16 07:16:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:16:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:16:29 --> Utf8 Class Initialized
INFO - 2022-12-16 07:16:29 --> URI Class Initialized
INFO - 2022-12-16 07:16:29 --> Router Class Initialized
INFO - 2022-12-16 07:16:29 --> Output Class Initialized
INFO - 2022-12-16 07:16:29 --> Security Class Initialized
DEBUG - 2022-12-16 07:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:16:29 --> Input Class Initialized
INFO - 2022-12-16 07:16:29 --> Language Class Initialized
INFO - 2022-12-16 07:16:29 --> Language Class Initialized
INFO - 2022-12-16 07:16:29 --> Config Class Initialized
INFO - 2022-12-16 07:16:29 --> Loader Class Initialized
INFO - 2022-12-16 07:16:29 --> Helper loaded: url_helper
INFO - 2022-12-16 07:16:29 --> Helper loaded: file_helper
INFO - 2022-12-16 07:16:29 --> Helper loaded: form_helper
INFO - 2022-12-16 07:16:29 --> Helper loaded: my_helper
INFO - 2022-12-16 07:16:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:16:29 --> Controller Class Initialized
DEBUG - 2022-12-16 07:16:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:16:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:16:29 --> Final output sent to browser
DEBUG - 2022-12-16 07:16:29 --> Total execution time: 0.0959
INFO - 2022-12-16 07:16:30 --> Config Class Initialized
INFO - 2022-12-16 07:16:30 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:16:30 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:16:30 --> Utf8 Class Initialized
INFO - 2022-12-16 07:16:30 --> URI Class Initialized
INFO - 2022-12-16 07:16:30 --> Router Class Initialized
INFO - 2022-12-16 07:16:30 --> Output Class Initialized
INFO - 2022-12-16 07:16:30 --> Security Class Initialized
DEBUG - 2022-12-16 07:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:16:30 --> Input Class Initialized
INFO - 2022-12-16 07:16:30 --> Language Class Initialized
INFO - 2022-12-16 07:16:30 --> Language Class Initialized
INFO - 2022-12-16 07:16:30 --> Config Class Initialized
INFO - 2022-12-16 07:16:30 --> Loader Class Initialized
INFO - 2022-12-16 07:16:30 --> Helper loaded: url_helper
INFO - 2022-12-16 07:16:30 --> Helper loaded: file_helper
INFO - 2022-12-16 07:16:30 --> Helper loaded: form_helper
INFO - 2022-12-16 07:16:30 --> Helper loaded: my_helper
INFO - 2022-12-16 07:16:30 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:16:30 --> Controller Class Initialized
INFO - 2022-12-16 07:16:55 --> Config Class Initialized
INFO - 2022-12-16 07:16:55 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:16:55 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:16:55 --> Utf8 Class Initialized
INFO - 2022-12-16 07:16:55 --> URI Class Initialized
INFO - 2022-12-16 07:16:55 --> Router Class Initialized
INFO - 2022-12-16 07:16:55 --> Output Class Initialized
INFO - 2022-12-16 07:16:55 --> Security Class Initialized
DEBUG - 2022-12-16 07:16:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:16:55 --> Input Class Initialized
INFO - 2022-12-16 07:16:55 --> Language Class Initialized
INFO - 2022-12-16 07:16:55 --> Language Class Initialized
INFO - 2022-12-16 07:16:55 --> Config Class Initialized
INFO - 2022-12-16 07:16:55 --> Loader Class Initialized
INFO - 2022-12-16 07:16:55 --> Helper loaded: url_helper
INFO - 2022-12-16 07:16:55 --> Helper loaded: file_helper
INFO - 2022-12-16 07:16:55 --> Helper loaded: form_helper
INFO - 2022-12-16 07:16:55 --> Helper loaded: my_helper
INFO - 2022-12-16 07:16:55 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:16:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:16:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:16:55 --> Controller Class Initialized
DEBUG - 2022-12-16 07:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:16:55 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:16:55 --> Final output sent to browser
DEBUG - 2022-12-16 07:16:55 --> Total execution time: 0.0995
INFO - 2022-12-16 07:18:32 --> Config Class Initialized
INFO - 2022-12-16 07:18:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:18:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:18:32 --> Utf8 Class Initialized
INFO - 2022-12-16 07:18:32 --> URI Class Initialized
INFO - 2022-12-16 07:18:32 --> Router Class Initialized
INFO - 2022-12-16 07:18:32 --> Output Class Initialized
INFO - 2022-12-16 07:18:32 --> Security Class Initialized
DEBUG - 2022-12-16 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:18:32 --> Input Class Initialized
INFO - 2022-12-16 07:18:32 --> Language Class Initialized
INFO - 2022-12-16 07:18:32 --> Language Class Initialized
INFO - 2022-12-16 07:18:32 --> Config Class Initialized
INFO - 2022-12-16 07:18:32 --> Loader Class Initialized
INFO - 2022-12-16 07:18:32 --> Helper loaded: url_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: file_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: form_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: my_helper
INFO - 2022-12-16 07:18:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:18:32 --> Controller Class Initialized
INFO - 2022-12-16 07:18:32 --> Config Class Initialized
INFO - 2022-12-16 07:18:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:18:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:18:32 --> Utf8 Class Initialized
INFO - 2022-12-16 07:18:32 --> URI Class Initialized
INFO - 2022-12-16 07:18:32 --> Router Class Initialized
INFO - 2022-12-16 07:18:32 --> Output Class Initialized
INFO - 2022-12-16 07:18:32 --> Security Class Initialized
DEBUG - 2022-12-16 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:18:32 --> Input Class Initialized
INFO - 2022-12-16 07:18:32 --> Language Class Initialized
INFO - 2022-12-16 07:18:32 --> Language Class Initialized
INFO - 2022-12-16 07:18:32 --> Config Class Initialized
INFO - 2022-12-16 07:18:32 --> Loader Class Initialized
INFO - 2022-12-16 07:18:32 --> Helper loaded: url_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: file_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: form_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: my_helper
INFO - 2022-12-16 07:18:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:18:32 --> Controller Class Initialized
DEBUG - 2022-12-16 07:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:18:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:18:32 --> Final output sent to browser
DEBUG - 2022-12-16 07:18:32 --> Total execution time: 0.0457
INFO - 2022-12-16 07:18:32 --> Config Class Initialized
INFO - 2022-12-16 07:18:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:18:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:18:32 --> Utf8 Class Initialized
INFO - 2022-12-16 07:18:32 --> URI Class Initialized
INFO - 2022-12-16 07:18:32 --> Router Class Initialized
INFO - 2022-12-16 07:18:32 --> Output Class Initialized
INFO - 2022-12-16 07:18:32 --> Security Class Initialized
DEBUG - 2022-12-16 07:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:18:32 --> Input Class Initialized
INFO - 2022-12-16 07:18:32 --> Language Class Initialized
INFO - 2022-12-16 07:18:32 --> Language Class Initialized
INFO - 2022-12-16 07:18:32 --> Config Class Initialized
INFO - 2022-12-16 07:18:32 --> Loader Class Initialized
INFO - 2022-12-16 07:18:32 --> Helper loaded: url_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: file_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: form_helper
INFO - 2022-12-16 07:18:32 --> Helper loaded: my_helper
INFO - 2022-12-16 07:18:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:18:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:18:32 --> Controller Class Initialized
INFO - 2022-12-16 07:19:07 --> Config Class Initialized
INFO - 2022-12-16 07:19:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:19:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:19:07 --> Utf8 Class Initialized
INFO - 2022-12-16 07:19:07 --> URI Class Initialized
INFO - 2022-12-16 07:19:07 --> Router Class Initialized
INFO - 2022-12-16 07:19:07 --> Output Class Initialized
INFO - 2022-12-16 07:19:07 --> Security Class Initialized
DEBUG - 2022-12-16 07:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:19:07 --> Input Class Initialized
INFO - 2022-12-16 07:19:07 --> Language Class Initialized
INFO - 2022-12-16 07:19:07 --> Language Class Initialized
INFO - 2022-12-16 07:19:07 --> Config Class Initialized
INFO - 2022-12-16 07:19:07 --> Loader Class Initialized
INFO - 2022-12-16 07:19:07 --> Helper loaded: url_helper
INFO - 2022-12-16 07:19:07 --> Helper loaded: file_helper
INFO - 2022-12-16 07:19:07 --> Helper loaded: form_helper
INFO - 2022-12-16 07:19:07 --> Helper loaded: my_helper
INFO - 2022-12-16 07:19:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:19:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:19:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:19:07 --> Controller Class Initialized
DEBUG - 2022-12-16 07:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:19:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:19:07 --> Final output sent to browser
DEBUG - 2022-12-16 07:19:07 --> Total execution time: 0.0735
INFO - 2022-12-16 07:19:29 --> Config Class Initialized
INFO - 2022-12-16 07:19:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:19:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:19:29 --> Utf8 Class Initialized
INFO - 2022-12-16 07:19:29 --> URI Class Initialized
INFO - 2022-12-16 07:19:29 --> Router Class Initialized
INFO - 2022-12-16 07:19:29 --> Output Class Initialized
INFO - 2022-12-16 07:19:29 --> Security Class Initialized
DEBUG - 2022-12-16 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:19:29 --> Input Class Initialized
INFO - 2022-12-16 07:19:29 --> Language Class Initialized
INFO - 2022-12-16 07:19:29 --> Language Class Initialized
INFO - 2022-12-16 07:19:29 --> Config Class Initialized
INFO - 2022-12-16 07:19:29 --> Loader Class Initialized
INFO - 2022-12-16 07:19:29 --> Helper loaded: url_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: file_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: form_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: my_helper
INFO - 2022-12-16 07:19:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:19:29 --> Controller Class Initialized
INFO - 2022-12-16 07:19:29 --> Config Class Initialized
INFO - 2022-12-16 07:19:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:19:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:19:29 --> Utf8 Class Initialized
INFO - 2022-12-16 07:19:29 --> URI Class Initialized
INFO - 2022-12-16 07:19:29 --> Router Class Initialized
INFO - 2022-12-16 07:19:29 --> Output Class Initialized
INFO - 2022-12-16 07:19:29 --> Security Class Initialized
DEBUG - 2022-12-16 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:19:29 --> Input Class Initialized
INFO - 2022-12-16 07:19:29 --> Language Class Initialized
INFO - 2022-12-16 07:19:29 --> Language Class Initialized
INFO - 2022-12-16 07:19:29 --> Config Class Initialized
INFO - 2022-12-16 07:19:29 --> Loader Class Initialized
INFO - 2022-12-16 07:19:29 --> Helper loaded: url_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: file_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: form_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: my_helper
INFO - 2022-12-16 07:19:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:19:29 --> Controller Class Initialized
DEBUG - 2022-12-16 07:19:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:19:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:19:29 --> Final output sent to browser
DEBUG - 2022-12-16 07:19:29 --> Total execution time: 0.0472
INFO - 2022-12-16 07:19:29 --> Config Class Initialized
INFO - 2022-12-16 07:19:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:19:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:19:29 --> Utf8 Class Initialized
INFO - 2022-12-16 07:19:29 --> URI Class Initialized
INFO - 2022-12-16 07:19:29 --> Router Class Initialized
INFO - 2022-12-16 07:19:29 --> Output Class Initialized
INFO - 2022-12-16 07:19:29 --> Security Class Initialized
DEBUG - 2022-12-16 07:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:19:29 --> Input Class Initialized
INFO - 2022-12-16 07:19:29 --> Language Class Initialized
INFO - 2022-12-16 07:19:29 --> Language Class Initialized
INFO - 2022-12-16 07:19:29 --> Config Class Initialized
INFO - 2022-12-16 07:19:29 --> Loader Class Initialized
INFO - 2022-12-16 07:19:29 --> Helper loaded: url_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: file_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: form_helper
INFO - 2022-12-16 07:19:29 --> Helper loaded: my_helper
INFO - 2022-12-16 07:19:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:19:29 --> Controller Class Initialized
INFO - 2022-12-16 07:19:32 --> Config Class Initialized
INFO - 2022-12-16 07:19:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:19:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:19:32 --> Utf8 Class Initialized
INFO - 2022-12-16 07:19:32 --> URI Class Initialized
INFO - 2022-12-16 07:19:32 --> Router Class Initialized
INFO - 2022-12-16 07:19:32 --> Output Class Initialized
INFO - 2022-12-16 07:19:32 --> Security Class Initialized
DEBUG - 2022-12-16 07:19:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:19:32 --> Input Class Initialized
INFO - 2022-12-16 07:19:32 --> Language Class Initialized
INFO - 2022-12-16 07:19:32 --> Language Class Initialized
INFO - 2022-12-16 07:19:32 --> Config Class Initialized
INFO - 2022-12-16 07:19:32 --> Loader Class Initialized
INFO - 2022-12-16 07:19:32 --> Helper loaded: url_helper
INFO - 2022-12-16 07:19:32 --> Helper loaded: file_helper
INFO - 2022-12-16 07:19:32 --> Helper loaded: form_helper
INFO - 2022-12-16 07:19:32 --> Helper loaded: my_helper
INFO - 2022-12-16 07:19:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:19:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:19:32 --> Controller Class Initialized
DEBUG - 2022-12-16 07:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:19:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:19:32 --> Final output sent to browser
DEBUG - 2022-12-16 07:19:32 --> Total execution time: 0.0863
INFO - 2022-12-16 07:21:13 --> Config Class Initialized
INFO - 2022-12-16 07:21:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:21:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:21:13 --> Utf8 Class Initialized
INFO - 2022-12-16 07:21:13 --> URI Class Initialized
INFO - 2022-12-16 07:21:13 --> Router Class Initialized
INFO - 2022-12-16 07:21:13 --> Output Class Initialized
INFO - 2022-12-16 07:21:13 --> Security Class Initialized
DEBUG - 2022-12-16 07:21:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:21:13 --> Input Class Initialized
INFO - 2022-12-16 07:21:13 --> Language Class Initialized
INFO - 2022-12-16 07:21:13 --> Language Class Initialized
INFO - 2022-12-16 07:21:13 --> Config Class Initialized
INFO - 2022-12-16 07:21:13 --> Loader Class Initialized
INFO - 2022-12-16 07:21:13 --> Helper loaded: url_helper
INFO - 2022-12-16 07:21:13 --> Helper loaded: file_helper
INFO - 2022-12-16 07:21:13 --> Helper loaded: form_helper
INFO - 2022-12-16 07:21:13 --> Helper loaded: my_helper
INFO - 2022-12-16 07:21:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:21:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:21:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:21:13 --> Controller Class Initialized
INFO - 2022-12-16 07:21:14 --> Config Class Initialized
INFO - 2022-12-16 07:21:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:21:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:21:14 --> Utf8 Class Initialized
INFO - 2022-12-16 07:21:14 --> URI Class Initialized
INFO - 2022-12-16 07:21:14 --> Router Class Initialized
INFO - 2022-12-16 07:21:14 --> Output Class Initialized
INFO - 2022-12-16 07:21:14 --> Security Class Initialized
DEBUG - 2022-12-16 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:21:14 --> Input Class Initialized
INFO - 2022-12-16 07:21:14 --> Language Class Initialized
INFO - 2022-12-16 07:21:14 --> Language Class Initialized
INFO - 2022-12-16 07:21:14 --> Config Class Initialized
INFO - 2022-12-16 07:21:14 --> Loader Class Initialized
INFO - 2022-12-16 07:21:14 --> Helper loaded: url_helper
INFO - 2022-12-16 07:21:14 --> Helper loaded: file_helper
INFO - 2022-12-16 07:21:14 --> Helper loaded: form_helper
INFO - 2022-12-16 07:21:14 --> Helper loaded: my_helper
INFO - 2022-12-16 07:21:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:21:14 --> Controller Class Initialized
DEBUG - 2022-12-16 07:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:21:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:21:14 --> Final output sent to browser
DEBUG - 2022-12-16 07:21:14 --> Total execution time: 0.0586
INFO - 2022-12-16 07:21:14 --> Config Class Initialized
INFO - 2022-12-16 07:21:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:21:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:21:14 --> Utf8 Class Initialized
INFO - 2022-12-16 07:21:14 --> URI Class Initialized
INFO - 2022-12-16 07:21:14 --> Router Class Initialized
INFO - 2022-12-16 07:21:14 --> Output Class Initialized
INFO - 2022-12-16 07:21:14 --> Security Class Initialized
DEBUG - 2022-12-16 07:21:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:21:14 --> Input Class Initialized
INFO - 2022-12-16 07:21:14 --> Language Class Initialized
INFO - 2022-12-16 07:21:14 --> Language Class Initialized
INFO - 2022-12-16 07:21:14 --> Config Class Initialized
INFO - 2022-12-16 07:21:14 --> Loader Class Initialized
INFO - 2022-12-16 07:21:14 --> Helper loaded: url_helper
INFO - 2022-12-16 07:21:14 --> Helper loaded: file_helper
INFO - 2022-12-16 07:21:14 --> Helper loaded: form_helper
INFO - 2022-12-16 07:21:14 --> Helper loaded: my_helper
INFO - 2022-12-16 07:21:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:21:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:21:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:21:14 --> Controller Class Initialized
INFO - 2022-12-16 07:21:20 --> Config Class Initialized
INFO - 2022-12-16 07:21:20 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:21:20 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:21:20 --> Utf8 Class Initialized
INFO - 2022-12-16 07:21:20 --> URI Class Initialized
INFO - 2022-12-16 07:21:20 --> Router Class Initialized
INFO - 2022-12-16 07:21:20 --> Output Class Initialized
INFO - 2022-12-16 07:21:20 --> Security Class Initialized
DEBUG - 2022-12-16 07:21:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:21:20 --> Input Class Initialized
INFO - 2022-12-16 07:21:20 --> Language Class Initialized
INFO - 2022-12-16 07:21:20 --> Language Class Initialized
INFO - 2022-12-16 07:21:20 --> Config Class Initialized
INFO - 2022-12-16 07:21:20 --> Loader Class Initialized
INFO - 2022-12-16 07:21:20 --> Helper loaded: url_helper
INFO - 2022-12-16 07:21:20 --> Helper loaded: file_helper
INFO - 2022-12-16 07:21:20 --> Helper loaded: form_helper
INFO - 2022-12-16 07:21:20 --> Helper loaded: my_helper
INFO - 2022-12-16 07:21:20 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:21:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:21:20 --> Controller Class Initialized
DEBUG - 2022-12-16 07:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:21:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:21:20 --> Final output sent to browser
DEBUG - 2022-12-16 07:21:20 --> Total execution time: 0.0740
INFO - 2022-12-16 07:22:08 --> Config Class Initialized
INFO - 2022-12-16 07:22:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:22:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:22:08 --> Utf8 Class Initialized
INFO - 2022-12-16 07:22:08 --> URI Class Initialized
INFO - 2022-12-16 07:22:08 --> Router Class Initialized
INFO - 2022-12-16 07:22:08 --> Output Class Initialized
INFO - 2022-12-16 07:22:08 --> Security Class Initialized
DEBUG - 2022-12-16 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:22:08 --> Input Class Initialized
INFO - 2022-12-16 07:22:08 --> Language Class Initialized
INFO - 2022-12-16 07:22:08 --> Language Class Initialized
INFO - 2022-12-16 07:22:08 --> Config Class Initialized
INFO - 2022-12-16 07:22:08 --> Loader Class Initialized
INFO - 2022-12-16 07:22:08 --> Helper loaded: url_helper
INFO - 2022-12-16 07:22:08 --> Helper loaded: file_helper
INFO - 2022-12-16 07:22:08 --> Helper loaded: form_helper
INFO - 2022-12-16 07:22:08 --> Helper loaded: my_helper
INFO - 2022-12-16 07:22:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:22:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:22:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:22:08 --> Controller Class Initialized
INFO - 2022-12-16 07:22:08 --> Config Class Initialized
INFO - 2022-12-16 07:22:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:22:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:22:08 --> Utf8 Class Initialized
INFO - 2022-12-16 07:22:08 --> URI Class Initialized
INFO - 2022-12-16 07:22:08 --> Router Class Initialized
INFO - 2022-12-16 07:22:08 --> Output Class Initialized
INFO - 2022-12-16 07:22:08 --> Security Class Initialized
DEBUG - 2022-12-16 07:22:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:22:08 --> Input Class Initialized
INFO - 2022-12-16 07:22:08 --> Language Class Initialized
INFO - 2022-12-16 07:22:09 --> Language Class Initialized
INFO - 2022-12-16 07:22:09 --> Config Class Initialized
INFO - 2022-12-16 07:22:09 --> Loader Class Initialized
INFO - 2022-12-16 07:22:09 --> Helper loaded: url_helper
INFO - 2022-12-16 07:22:09 --> Helper loaded: file_helper
INFO - 2022-12-16 07:22:09 --> Helper loaded: form_helper
INFO - 2022-12-16 07:22:09 --> Helper loaded: my_helper
INFO - 2022-12-16 07:22:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:22:09 --> Controller Class Initialized
DEBUG - 2022-12-16 07:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:22:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:22:09 --> Final output sent to browser
DEBUG - 2022-12-16 07:22:09 --> Total execution time: 0.0555
INFO - 2022-12-16 07:22:09 --> Config Class Initialized
INFO - 2022-12-16 07:22:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:22:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:22:09 --> Utf8 Class Initialized
INFO - 2022-12-16 07:22:09 --> URI Class Initialized
INFO - 2022-12-16 07:22:09 --> Router Class Initialized
INFO - 2022-12-16 07:22:09 --> Output Class Initialized
INFO - 2022-12-16 07:22:09 --> Security Class Initialized
DEBUG - 2022-12-16 07:22:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:22:09 --> Input Class Initialized
INFO - 2022-12-16 07:22:09 --> Language Class Initialized
INFO - 2022-12-16 07:22:09 --> Language Class Initialized
INFO - 2022-12-16 07:22:09 --> Config Class Initialized
INFO - 2022-12-16 07:22:09 --> Loader Class Initialized
INFO - 2022-12-16 07:22:09 --> Helper loaded: url_helper
INFO - 2022-12-16 07:22:09 --> Helper loaded: file_helper
INFO - 2022-12-16 07:22:09 --> Helper loaded: form_helper
INFO - 2022-12-16 07:22:09 --> Helper loaded: my_helper
INFO - 2022-12-16 07:22:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:22:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:22:09 --> Controller Class Initialized
INFO - 2022-12-16 07:22:11 --> Config Class Initialized
INFO - 2022-12-16 07:22:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:22:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:22:11 --> Utf8 Class Initialized
INFO - 2022-12-16 07:22:11 --> URI Class Initialized
INFO - 2022-12-16 07:22:11 --> Router Class Initialized
INFO - 2022-12-16 07:22:11 --> Output Class Initialized
INFO - 2022-12-16 07:22:11 --> Security Class Initialized
DEBUG - 2022-12-16 07:22:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:22:11 --> Input Class Initialized
INFO - 2022-12-16 07:22:11 --> Language Class Initialized
INFO - 2022-12-16 07:22:11 --> Language Class Initialized
INFO - 2022-12-16 07:22:11 --> Config Class Initialized
INFO - 2022-12-16 07:22:11 --> Loader Class Initialized
INFO - 2022-12-16 07:22:11 --> Helper loaded: url_helper
INFO - 2022-12-16 07:22:11 --> Helper loaded: file_helper
INFO - 2022-12-16 07:22:11 --> Helper loaded: form_helper
INFO - 2022-12-16 07:22:11 --> Helper loaded: my_helper
INFO - 2022-12-16 07:22:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:22:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:22:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:22:11 --> Controller Class Initialized
DEBUG - 2022-12-16 07:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:22:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:22:11 --> Final output sent to browser
DEBUG - 2022-12-16 07:22:11 --> Total execution time: 0.0777
INFO - 2022-12-16 07:26:02 --> Config Class Initialized
INFO - 2022-12-16 07:26:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:02 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:02 --> URI Class Initialized
INFO - 2022-12-16 07:26:02 --> Router Class Initialized
INFO - 2022-12-16 07:26:02 --> Output Class Initialized
INFO - 2022-12-16 07:26:02 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:02 --> Input Class Initialized
INFO - 2022-12-16 07:26:02 --> Language Class Initialized
INFO - 2022-12-16 07:26:02 --> Language Class Initialized
INFO - 2022-12-16 07:26:02 --> Config Class Initialized
INFO - 2022-12-16 07:26:02 --> Loader Class Initialized
INFO - 2022-12-16 07:26:02 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:02 --> Controller Class Initialized
INFO - 2022-12-16 07:26:02 --> Config Class Initialized
INFO - 2022-12-16 07:26:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:02 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:02 --> URI Class Initialized
INFO - 2022-12-16 07:26:02 --> Router Class Initialized
INFO - 2022-12-16 07:26:02 --> Output Class Initialized
INFO - 2022-12-16 07:26:02 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:02 --> Input Class Initialized
INFO - 2022-12-16 07:26:02 --> Language Class Initialized
INFO - 2022-12-16 07:26:02 --> Language Class Initialized
INFO - 2022-12-16 07:26:02 --> Config Class Initialized
INFO - 2022-12-16 07:26:02 --> Loader Class Initialized
INFO - 2022-12-16 07:26:02 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:02 --> Controller Class Initialized
DEBUG - 2022-12-16 07:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:26:02 --> Final output sent to browser
DEBUG - 2022-12-16 07:26:02 --> Total execution time: 0.0660
INFO - 2022-12-16 07:26:02 --> Config Class Initialized
INFO - 2022-12-16 07:26:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:02 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:02 --> URI Class Initialized
INFO - 2022-12-16 07:26:02 --> Router Class Initialized
INFO - 2022-12-16 07:26:02 --> Output Class Initialized
INFO - 2022-12-16 07:26:02 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:02 --> Input Class Initialized
INFO - 2022-12-16 07:26:02 --> Language Class Initialized
INFO - 2022-12-16 07:26:02 --> Language Class Initialized
INFO - 2022-12-16 07:26:02 --> Config Class Initialized
INFO - 2022-12-16 07:26:02 --> Loader Class Initialized
INFO - 2022-12-16 07:26:02 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:02 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:02 --> Controller Class Initialized
INFO - 2022-12-16 07:26:08 --> Config Class Initialized
INFO - 2022-12-16 07:26:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:08 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:08 --> URI Class Initialized
INFO - 2022-12-16 07:26:08 --> Router Class Initialized
INFO - 2022-12-16 07:26:08 --> Output Class Initialized
INFO - 2022-12-16 07:26:08 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:08 --> Input Class Initialized
INFO - 2022-12-16 07:26:08 --> Language Class Initialized
INFO - 2022-12-16 07:26:08 --> Language Class Initialized
INFO - 2022-12-16 07:26:08 --> Config Class Initialized
INFO - 2022-12-16 07:26:08 --> Loader Class Initialized
INFO - 2022-12-16 07:26:08 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:08 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:08 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:08 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:08 --> Controller Class Initialized
DEBUG - 2022-12-16 07:26:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:26:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:26:08 --> Final output sent to browser
DEBUG - 2022-12-16 07:26:08 --> Total execution time: 0.0799
INFO - 2022-12-16 07:26:40 --> Config Class Initialized
INFO - 2022-12-16 07:26:40 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:40 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:40 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:40 --> URI Class Initialized
INFO - 2022-12-16 07:26:40 --> Router Class Initialized
INFO - 2022-12-16 07:26:40 --> Output Class Initialized
INFO - 2022-12-16 07:26:40 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:40 --> Input Class Initialized
INFO - 2022-12-16 07:26:40 --> Language Class Initialized
INFO - 2022-12-16 07:26:40 --> Language Class Initialized
INFO - 2022-12-16 07:26:40 --> Config Class Initialized
INFO - 2022-12-16 07:26:40 --> Loader Class Initialized
INFO - 2022-12-16 07:26:40 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:40 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:40 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:40 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:40 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:40 --> Controller Class Initialized
INFO - 2022-12-16 07:26:41 --> Config Class Initialized
INFO - 2022-12-16 07:26:41 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:41 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:41 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:41 --> URI Class Initialized
INFO - 2022-12-16 07:26:41 --> Router Class Initialized
INFO - 2022-12-16 07:26:41 --> Output Class Initialized
INFO - 2022-12-16 07:26:41 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:41 --> Input Class Initialized
INFO - 2022-12-16 07:26:41 --> Language Class Initialized
INFO - 2022-12-16 07:26:41 --> Language Class Initialized
INFO - 2022-12-16 07:26:41 --> Config Class Initialized
INFO - 2022-12-16 07:26:41 --> Loader Class Initialized
INFO - 2022-12-16 07:26:41 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:41 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:41 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:41 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:41 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:41 --> Controller Class Initialized
DEBUG - 2022-12-16 07:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:26:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:26:41 --> Final output sent to browser
DEBUG - 2022-12-16 07:26:41 --> Total execution time: 0.0647
INFO - 2022-12-16 07:26:41 --> Config Class Initialized
INFO - 2022-12-16 07:26:41 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:41 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:41 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:41 --> URI Class Initialized
INFO - 2022-12-16 07:26:41 --> Router Class Initialized
INFO - 2022-12-16 07:26:41 --> Output Class Initialized
INFO - 2022-12-16 07:26:41 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:41 --> Input Class Initialized
INFO - 2022-12-16 07:26:41 --> Language Class Initialized
INFO - 2022-12-16 07:26:41 --> Language Class Initialized
INFO - 2022-12-16 07:26:41 --> Config Class Initialized
INFO - 2022-12-16 07:26:41 --> Loader Class Initialized
INFO - 2022-12-16 07:26:41 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:41 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:41 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:41 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:41 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:41 --> Controller Class Initialized
INFO - 2022-12-16 07:26:42 --> Config Class Initialized
INFO - 2022-12-16 07:26:42 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:26:42 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:26:42 --> Utf8 Class Initialized
INFO - 2022-12-16 07:26:42 --> URI Class Initialized
INFO - 2022-12-16 07:26:42 --> Router Class Initialized
INFO - 2022-12-16 07:26:42 --> Output Class Initialized
INFO - 2022-12-16 07:26:42 --> Security Class Initialized
DEBUG - 2022-12-16 07:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:26:42 --> Input Class Initialized
INFO - 2022-12-16 07:26:42 --> Language Class Initialized
INFO - 2022-12-16 07:26:42 --> Language Class Initialized
INFO - 2022-12-16 07:26:42 --> Config Class Initialized
INFO - 2022-12-16 07:26:42 --> Loader Class Initialized
INFO - 2022-12-16 07:26:42 --> Helper loaded: url_helper
INFO - 2022-12-16 07:26:42 --> Helper loaded: file_helper
INFO - 2022-12-16 07:26:42 --> Helper loaded: form_helper
INFO - 2022-12-16 07:26:42 --> Helper loaded: my_helper
INFO - 2022-12-16 07:26:42 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:26:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:26:42 --> Controller Class Initialized
DEBUG - 2022-12-16 07:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:26:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:26:42 --> Final output sent to browser
DEBUG - 2022-12-16 07:26:42 --> Total execution time: 0.0896
INFO - 2022-12-16 07:27:28 --> Config Class Initialized
INFO - 2022-12-16 07:27:28 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:27:28 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:27:28 --> Utf8 Class Initialized
INFO - 2022-12-16 07:27:28 --> URI Class Initialized
INFO - 2022-12-16 07:27:28 --> Router Class Initialized
INFO - 2022-12-16 07:27:28 --> Output Class Initialized
INFO - 2022-12-16 07:27:28 --> Security Class Initialized
DEBUG - 2022-12-16 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:27:28 --> Input Class Initialized
INFO - 2022-12-16 07:27:28 --> Language Class Initialized
INFO - 2022-12-16 07:27:28 --> Language Class Initialized
INFO - 2022-12-16 07:27:28 --> Config Class Initialized
INFO - 2022-12-16 07:27:28 --> Loader Class Initialized
INFO - 2022-12-16 07:27:28 --> Helper loaded: url_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: file_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: form_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: my_helper
INFO - 2022-12-16 07:27:28 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:27:28 --> Controller Class Initialized
INFO - 2022-12-16 07:27:28 --> Config Class Initialized
INFO - 2022-12-16 07:27:28 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:27:28 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:27:28 --> Utf8 Class Initialized
INFO - 2022-12-16 07:27:28 --> URI Class Initialized
INFO - 2022-12-16 07:27:28 --> Router Class Initialized
INFO - 2022-12-16 07:27:28 --> Output Class Initialized
INFO - 2022-12-16 07:27:28 --> Security Class Initialized
DEBUG - 2022-12-16 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:27:28 --> Input Class Initialized
INFO - 2022-12-16 07:27:28 --> Language Class Initialized
INFO - 2022-12-16 07:27:28 --> Language Class Initialized
INFO - 2022-12-16 07:27:28 --> Config Class Initialized
INFO - 2022-12-16 07:27:28 --> Loader Class Initialized
INFO - 2022-12-16 07:27:28 --> Helper loaded: url_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: file_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: form_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: my_helper
INFO - 2022-12-16 07:27:28 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:27:28 --> Controller Class Initialized
DEBUG - 2022-12-16 07:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:27:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:27:28 --> Final output sent to browser
DEBUG - 2022-12-16 07:27:28 --> Total execution time: 0.0680
INFO - 2022-12-16 07:27:28 --> Config Class Initialized
INFO - 2022-12-16 07:27:28 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:27:28 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:27:28 --> Utf8 Class Initialized
INFO - 2022-12-16 07:27:28 --> URI Class Initialized
INFO - 2022-12-16 07:27:28 --> Router Class Initialized
INFO - 2022-12-16 07:27:28 --> Output Class Initialized
INFO - 2022-12-16 07:27:28 --> Security Class Initialized
DEBUG - 2022-12-16 07:27:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:27:28 --> Input Class Initialized
INFO - 2022-12-16 07:27:28 --> Language Class Initialized
INFO - 2022-12-16 07:27:28 --> Language Class Initialized
INFO - 2022-12-16 07:27:28 --> Config Class Initialized
INFO - 2022-12-16 07:27:28 --> Loader Class Initialized
INFO - 2022-12-16 07:27:28 --> Helper loaded: url_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: file_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: form_helper
INFO - 2022-12-16 07:27:28 --> Helper loaded: my_helper
INFO - 2022-12-16 07:27:28 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:27:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:27:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:27:28 --> Controller Class Initialized
INFO - 2022-12-16 07:27:29 --> Config Class Initialized
INFO - 2022-12-16 07:27:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:27:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:27:29 --> Utf8 Class Initialized
INFO - 2022-12-16 07:27:29 --> URI Class Initialized
INFO - 2022-12-16 07:27:29 --> Router Class Initialized
INFO - 2022-12-16 07:27:29 --> Output Class Initialized
INFO - 2022-12-16 07:27:29 --> Security Class Initialized
DEBUG - 2022-12-16 07:27:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:27:29 --> Input Class Initialized
INFO - 2022-12-16 07:27:29 --> Language Class Initialized
INFO - 2022-12-16 07:27:29 --> Language Class Initialized
INFO - 2022-12-16 07:27:29 --> Config Class Initialized
INFO - 2022-12-16 07:27:29 --> Loader Class Initialized
INFO - 2022-12-16 07:27:29 --> Helper loaded: url_helper
INFO - 2022-12-16 07:27:29 --> Helper loaded: file_helper
INFO - 2022-12-16 07:27:29 --> Helper loaded: form_helper
INFO - 2022-12-16 07:27:29 --> Helper loaded: my_helper
INFO - 2022-12-16 07:27:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:27:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:27:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:27:29 --> Controller Class Initialized
DEBUG - 2022-12-16 07:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:27:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:27:29 --> Final output sent to browser
DEBUG - 2022-12-16 07:27:29 --> Total execution time: 0.0877
INFO - 2022-12-16 07:28:39 --> Config Class Initialized
INFO - 2022-12-16 07:28:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:39 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:39 --> URI Class Initialized
INFO - 2022-12-16 07:28:39 --> Router Class Initialized
INFO - 2022-12-16 07:28:39 --> Output Class Initialized
INFO - 2022-12-16 07:28:39 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:39 --> Input Class Initialized
INFO - 2022-12-16 07:28:39 --> Language Class Initialized
INFO - 2022-12-16 07:28:39 --> Language Class Initialized
INFO - 2022-12-16 07:28:39 --> Config Class Initialized
INFO - 2022-12-16 07:28:39 --> Loader Class Initialized
INFO - 2022-12-16 07:28:39 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:39 --> Controller Class Initialized
INFO - 2022-12-16 07:28:39 --> Config Class Initialized
INFO - 2022-12-16 07:28:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:39 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:39 --> URI Class Initialized
INFO - 2022-12-16 07:28:39 --> Router Class Initialized
INFO - 2022-12-16 07:28:39 --> Output Class Initialized
INFO - 2022-12-16 07:28:39 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:39 --> Input Class Initialized
INFO - 2022-12-16 07:28:39 --> Language Class Initialized
INFO - 2022-12-16 07:28:39 --> Language Class Initialized
INFO - 2022-12-16 07:28:39 --> Config Class Initialized
INFO - 2022-12-16 07:28:39 --> Loader Class Initialized
INFO - 2022-12-16 07:28:39 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:39 --> Controller Class Initialized
DEBUG - 2022-12-16 07:28:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:28:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:28:39 --> Final output sent to browser
DEBUG - 2022-12-16 07:28:39 --> Total execution time: 0.0642
INFO - 2022-12-16 07:28:39 --> Config Class Initialized
INFO - 2022-12-16 07:28:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:39 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:39 --> URI Class Initialized
INFO - 2022-12-16 07:28:39 --> Router Class Initialized
INFO - 2022-12-16 07:28:39 --> Output Class Initialized
INFO - 2022-12-16 07:28:39 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:39 --> Input Class Initialized
INFO - 2022-12-16 07:28:39 --> Language Class Initialized
INFO - 2022-12-16 07:28:39 --> Language Class Initialized
INFO - 2022-12-16 07:28:39 --> Config Class Initialized
INFO - 2022-12-16 07:28:39 --> Loader Class Initialized
INFO - 2022-12-16 07:28:39 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:39 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:39 --> Controller Class Initialized
INFO - 2022-12-16 07:28:43 --> Config Class Initialized
INFO - 2022-12-16 07:28:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:43 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:43 --> URI Class Initialized
INFO - 2022-12-16 07:28:43 --> Router Class Initialized
INFO - 2022-12-16 07:28:43 --> Output Class Initialized
INFO - 2022-12-16 07:28:43 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:43 --> Input Class Initialized
INFO - 2022-12-16 07:28:43 --> Language Class Initialized
INFO - 2022-12-16 07:28:43 --> Language Class Initialized
INFO - 2022-12-16 07:28:43 --> Config Class Initialized
INFO - 2022-12-16 07:28:43 --> Loader Class Initialized
INFO - 2022-12-16 07:28:43 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:43 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:43 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:43 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:43 --> Controller Class Initialized
INFO - 2022-12-16 07:28:43 --> Config Class Initialized
INFO - 2022-12-16 07:28:43 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:43 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:43 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:43 --> URI Class Initialized
INFO - 2022-12-16 07:28:43 --> Router Class Initialized
INFO - 2022-12-16 07:28:43 --> Output Class Initialized
INFO - 2022-12-16 07:28:43 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:43 --> Input Class Initialized
INFO - 2022-12-16 07:28:43 --> Language Class Initialized
INFO - 2022-12-16 07:28:43 --> Language Class Initialized
INFO - 2022-12-16 07:28:43 --> Config Class Initialized
INFO - 2022-12-16 07:28:43 --> Loader Class Initialized
INFO - 2022-12-16 07:28:43 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:43 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:43 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:43 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:43 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:43 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:43 --> Controller Class Initialized
INFO - 2022-12-16 07:28:44 --> Config Class Initialized
INFO - 2022-12-16 07:28:44 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:44 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:44 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:44 --> URI Class Initialized
INFO - 2022-12-16 07:28:44 --> Router Class Initialized
INFO - 2022-12-16 07:28:44 --> Output Class Initialized
INFO - 2022-12-16 07:28:44 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:44 --> Input Class Initialized
INFO - 2022-12-16 07:28:44 --> Language Class Initialized
INFO - 2022-12-16 07:28:44 --> Language Class Initialized
INFO - 2022-12-16 07:28:44 --> Config Class Initialized
INFO - 2022-12-16 07:28:44 --> Loader Class Initialized
INFO - 2022-12-16 07:28:44 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:44 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:44 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:44 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:44 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:44 --> Controller Class Initialized
INFO - 2022-12-16 07:28:45 --> Config Class Initialized
INFO - 2022-12-16 07:28:45 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:45 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:45 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:45 --> URI Class Initialized
INFO - 2022-12-16 07:28:45 --> Router Class Initialized
INFO - 2022-12-16 07:28:45 --> Output Class Initialized
INFO - 2022-12-16 07:28:45 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:45 --> Input Class Initialized
INFO - 2022-12-16 07:28:45 --> Language Class Initialized
INFO - 2022-12-16 07:28:45 --> Language Class Initialized
INFO - 2022-12-16 07:28:45 --> Config Class Initialized
INFO - 2022-12-16 07:28:45 --> Loader Class Initialized
INFO - 2022-12-16 07:28:45 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:45 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:45 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:45 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:45 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:45 --> Controller Class Initialized
INFO - 2022-12-16 07:28:46 --> Config Class Initialized
INFO - 2022-12-16 07:28:46 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:28:46 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:28:46 --> Utf8 Class Initialized
INFO - 2022-12-16 07:28:46 --> URI Class Initialized
INFO - 2022-12-16 07:28:46 --> Router Class Initialized
INFO - 2022-12-16 07:28:46 --> Output Class Initialized
INFO - 2022-12-16 07:28:46 --> Security Class Initialized
DEBUG - 2022-12-16 07:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:28:46 --> Input Class Initialized
INFO - 2022-12-16 07:28:46 --> Language Class Initialized
INFO - 2022-12-16 07:28:46 --> Language Class Initialized
INFO - 2022-12-16 07:28:46 --> Config Class Initialized
INFO - 2022-12-16 07:28:46 --> Loader Class Initialized
INFO - 2022-12-16 07:28:46 --> Helper loaded: url_helper
INFO - 2022-12-16 07:28:46 --> Helper loaded: file_helper
INFO - 2022-12-16 07:28:46 --> Helper loaded: form_helper
INFO - 2022-12-16 07:28:46 --> Helper loaded: my_helper
INFO - 2022-12-16 07:28:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:28:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:28:46 --> Controller Class Initialized
DEBUG - 2022-12-16 07:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:28:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:28:46 --> Final output sent to browser
DEBUG - 2022-12-16 07:28:46 --> Total execution time: 0.0629
INFO - 2022-12-16 07:29:05 --> Config Class Initialized
INFO - 2022-12-16 07:29:05 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:29:05 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:29:05 --> Utf8 Class Initialized
INFO - 2022-12-16 07:29:05 --> URI Class Initialized
INFO - 2022-12-16 07:29:05 --> Router Class Initialized
INFO - 2022-12-16 07:29:05 --> Output Class Initialized
INFO - 2022-12-16 07:29:05 --> Security Class Initialized
DEBUG - 2022-12-16 07:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:29:05 --> Input Class Initialized
INFO - 2022-12-16 07:29:05 --> Language Class Initialized
INFO - 2022-12-16 07:29:05 --> Language Class Initialized
INFO - 2022-12-16 07:29:05 --> Config Class Initialized
INFO - 2022-12-16 07:29:05 --> Loader Class Initialized
INFO - 2022-12-16 07:29:05 --> Helper loaded: url_helper
INFO - 2022-12-16 07:29:05 --> Helper loaded: file_helper
INFO - 2022-12-16 07:29:05 --> Helper loaded: form_helper
INFO - 2022-12-16 07:29:05 --> Helper loaded: my_helper
INFO - 2022-12-16 07:29:05 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:29:05 --> Controller Class Initialized
INFO - 2022-12-16 07:29:05 --> Config Class Initialized
INFO - 2022-12-16 07:29:05 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:29:05 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:29:05 --> Utf8 Class Initialized
INFO - 2022-12-16 07:29:05 --> URI Class Initialized
INFO - 2022-12-16 07:29:05 --> Router Class Initialized
INFO - 2022-12-16 07:29:05 --> Output Class Initialized
INFO - 2022-12-16 07:29:05 --> Security Class Initialized
DEBUG - 2022-12-16 07:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:29:05 --> Input Class Initialized
INFO - 2022-12-16 07:29:05 --> Language Class Initialized
INFO - 2022-12-16 07:29:05 --> Language Class Initialized
INFO - 2022-12-16 07:29:05 --> Config Class Initialized
INFO - 2022-12-16 07:29:05 --> Loader Class Initialized
INFO - 2022-12-16 07:29:05 --> Helper loaded: url_helper
INFO - 2022-12-16 07:29:05 --> Helper loaded: file_helper
INFO - 2022-12-16 07:29:05 --> Helper loaded: form_helper
INFO - 2022-12-16 07:29:05 --> Helper loaded: my_helper
INFO - 2022-12-16 07:29:05 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:29:05 --> Controller Class Initialized
DEBUG - 2022-12-16 07:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:29:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:29:05 --> Final output sent to browser
DEBUG - 2022-12-16 07:29:05 --> Total execution time: 0.0619
INFO - 2022-12-16 07:29:06 --> Config Class Initialized
INFO - 2022-12-16 07:29:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:29:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:29:06 --> Utf8 Class Initialized
INFO - 2022-12-16 07:29:06 --> URI Class Initialized
INFO - 2022-12-16 07:29:06 --> Router Class Initialized
INFO - 2022-12-16 07:29:06 --> Output Class Initialized
INFO - 2022-12-16 07:29:06 --> Security Class Initialized
DEBUG - 2022-12-16 07:29:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:29:06 --> Input Class Initialized
INFO - 2022-12-16 07:29:06 --> Language Class Initialized
INFO - 2022-12-16 07:29:06 --> Language Class Initialized
INFO - 2022-12-16 07:29:06 --> Config Class Initialized
INFO - 2022-12-16 07:29:06 --> Loader Class Initialized
INFO - 2022-12-16 07:29:06 --> Helper loaded: url_helper
INFO - 2022-12-16 07:29:06 --> Helper loaded: file_helper
INFO - 2022-12-16 07:29:06 --> Helper loaded: form_helper
INFO - 2022-12-16 07:29:06 --> Helper loaded: my_helper
INFO - 2022-12-16 07:29:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:29:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:29:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:29:06 --> Controller Class Initialized
INFO - 2022-12-16 07:29:08 --> Config Class Initialized
INFO - 2022-12-16 07:29:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:29:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:29:08 --> Utf8 Class Initialized
INFO - 2022-12-16 07:29:08 --> URI Class Initialized
INFO - 2022-12-16 07:29:08 --> Router Class Initialized
INFO - 2022-12-16 07:29:08 --> Output Class Initialized
INFO - 2022-12-16 07:29:08 --> Security Class Initialized
DEBUG - 2022-12-16 07:29:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:29:08 --> Input Class Initialized
INFO - 2022-12-16 07:29:08 --> Language Class Initialized
INFO - 2022-12-16 07:29:08 --> Language Class Initialized
INFO - 2022-12-16 07:29:08 --> Config Class Initialized
INFO - 2022-12-16 07:29:08 --> Loader Class Initialized
INFO - 2022-12-16 07:29:08 --> Helper loaded: url_helper
INFO - 2022-12-16 07:29:08 --> Helper loaded: file_helper
INFO - 2022-12-16 07:29:08 --> Helper loaded: form_helper
INFO - 2022-12-16 07:29:08 --> Helper loaded: my_helper
INFO - 2022-12-16 07:29:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:29:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:29:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:29:08 --> Controller Class Initialized
DEBUG - 2022-12-16 07:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:29:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:29:08 --> Final output sent to browser
DEBUG - 2022-12-16 07:29:08 --> Total execution time: 0.0721
INFO - 2022-12-16 07:37:03 --> Config Class Initialized
INFO - 2022-12-16 07:37:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:37:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:37:03 --> Utf8 Class Initialized
INFO - 2022-12-16 07:37:03 --> URI Class Initialized
INFO - 2022-12-16 07:37:03 --> Router Class Initialized
INFO - 2022-12-16 07:37:03 --> Output Class Initialized
INFO - 2022-12-16 07:37:03 --> Security Class Initialized
DEBUG - 2022-12-16 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:37:03 --> Input Class Initialized
INFO - 2022-12-16 07:37:03 --> Language Class Initialized
INFO - 2022-12-16 07:37:03 --> Language Class Initialized
INFO - 2022-12-16 07:37:03 --> Config Class Initialized
INFO - 2022-12-16 07:37:03 --> Loader Class Initialized
INFO - 2022-12-16 07:37:03 --> Helper loaded: url_helper
INFO - 2022-12-16 07:37:03 --> Helper loaded: file_helper
INFO - 2022-12-16 07:37:03 --> Helper loaded: form_helper
INFO - 2022-12-16 07:37:03 --> Helper loaded: my_helper
INFO - 2022-12-16 07:37:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:37:03 --> Controller Class Initialized
DEBUG - 2022-12-16 07:37:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:37:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:37:03 --> Final output sent to browser
DEBUG - 2022-12-16 07:37:03 --> Total execution time: 0.0779
INFO - 2022-12-16 07:37:03 --> Config Class Initialized
INFO - 2022-12-16 07:37:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:37:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:37:03 --> Utf8 Class Initialized
INFO - 2022-12-16 07:37:03 --> URI Class Initialized
INFO - 2022-12-16 07:37:03 --> Router Class Initialized
INFO - 2022-12-16 07:37:03 --> Output Class Initialized
INFO - 2022-12-16 07:37:03 --> Security Class Initialized
DEBUG - 2022-12-16 07:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:37:03 --> Input Class Initialized
INFO - 2022-12-16 07:37:03 --> Language Class Initialized
INFO - 2022-12-16 07:37:03 --> Language Class Initialized
INFO - 2022-12-16 07:37:03 --> Config Class Initialized
INFO - 2022-12-16 07:37:03 --> Loader Class Initialized
INFO - 2022-12-16 07:37:03 --> Helper loaded: url_helper
INFO - 2022-12-16 07:37:03 --> Helper loaded: file_helper
INFO - 2022-12-16 07:37:03 --> Helper loaded: form_helper
INFO - 2022-12-16 07:37:03 --> Helper loaded: my_helper
INFO - 2022-12-16 07:37:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:37:03 --> Controller Class Initialized
INFO - 2022-12-16 07:38:44 --> Config Class Initialized
INFO - 2022-12-16 07:38:44 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:38:44 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:38:44 --> Utf8 Class Initialized
INFO - 2022-12-16 07:38:44 --> URI Class Initialized
INFO - 2022-12-16 07:38:44 --> Router Class Initialized
INFO - 2022-12-16 07:38:44 --> Output Class Initialized
INFO - 2022-12-16 07:38:44 --> Security Class Initialized
DEBUG - 2022-12-16 07:38:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:38:44 --> Input Class Initialized
INFO - 2022-12-16 07:38:44 --> Language Class Initialized
INFO - 2022-12-16 07:38:44 --> Language Class Initialized
INFO - 2022-12-16 07:38:44 --> Config Class Initialized
INFO - 2022-12-16 07:38:44 --> Loader Class Initialized
INFO - 2022-12-16 07:38:44 --> Helper loaded: url_helper
INFO - 2022-12-16 07:38:44 --> Helper loaded: file_helper
INFO - 2022-12-16 07:38:44 --> Helper loaded: form_helper
INFO - 2022-12-16 07:38:44 --> Helper loaded: my_helper
INFO - 2022-12-16 07:38:44 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:38:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:38:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:38:44 --> Controller Class Initialized
DEBUG - 2022-12-16 07:38:44 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:38:44 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:38:44 --> Final output sent to browser
DEBUG - 2022-12-16 07:38:44 --> Total execution time: 0.0772
INFO - 2022-12-16 07:39:36 --> Config Class Initialized
INFO - 2022-12-16 07:39:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:39:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:39:36 --> Utf8 Class Initialized
INFO - 2022-12-16 07:39:36 --> URI Class Initialized
INFO - 2022-12-16 07:39:36 --> Router Class Initialized
INFO - 2022-12-16 07:39:36 --> Output Class Initialized
INFO - 2022-12-16 07:39:36 --> Security Class Initialized
DEBUG - 2022-12-16 07:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:39:36 --> Input Class Initialized
INFO - 2022-12-16 07:39:36 --> Language Class Initialized
INFO - 2022-12-16 07:39:36 --> Language Class Initialized
INFO - 2022-12-16 07:39:36 --> Config Class Initialized
INFO - 2022-12-16 07:39:36 --> Loader Class Initialized
INFO - 2022-12-16 07:39:36 --> Helper loaded: url_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: file_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: form_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: my_helper
INFO - 2022-12-16 07:39:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:39:36 --> Controller Class Initialized
INFO - 2022-12-16 07:39:36 --> Config Class Initialized
INFO - 2022-12-16 07:39:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:39:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:39:36 --> Utf8 Class Initialized
INFO - 2022-12-16 07:39:36 --> URI Class Initialized
INFO - 2022-12-16 07:39:36 --> Router Class Initialized
INFO - 2022-12-16 07:39:36 --> Output Class Initialized
INFO - 2022-12-16 07:39:36 --> Security Class Initialized
DEBUG - 2022-12-16 07:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:39:36 --> Input Class Initialized
INFO - 2022-12-16 07:39:36 --> Language Class Initialized
INFO - 2022-12-16 07:39:36 --> Language Class Initialized
INFO - 2022-12-16 07:39:36 --> Config Class Initialized
INFO - 2022-12-16 07:39:36 --> Loader Class Initialized
INFO - 2022-12-16 07:39:36 --> Helper loaded: url_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: file_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: form_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: my_helper
INFO - 2022-12-16 07:39:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:39:36 --> Controller Class Initialized
DEBUG - 2022-12-16 07:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:39:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:39:36 --> Final output sent to browser
DEBUG - 2022-12-16 07:39:36 --> Total execution time: 0.0776
INFO - 2022-12-16 07:39:36 --> Config Class Initialized
INFO - 2022-12-16 07:39:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:39:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:39:36 --> Utf8 Class Initialized
INFO - 2022-12-16 07:39:36 --> URI Class Initialized
INFO - 2022-12-16 07:39:36 --> Router Class Initialized
INFO - 2022-12-16 07:39:36 --> Output Class Initialized
INFO - 2022-12-16 07:39:36 --> Security Class Initialized
DEBUG - 2022-12-16 07:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:39:36 --> Input Class Initialized
INFO - 2022-12-16 07:39:36 --> Language Class Initialized
INFO - 2022-12-16 07:39:36 --> Language Class Initialized
INFO - 2022-12-16 07:39:36 --> Config Class Initialized
INFO - 2022-12-16 07:39:36 --> Loader Class Initialized
INFO - 2022-12-16 07:39:36 --> Helper loaded: url_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: file_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: form_helper
INFO - 2022-12-16 07:39:36 --> Helper loaded: my_helper
INFO - 2022-12-16 07:39:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:39:36 --> Controller Class Initialized
INFO - 2022-12-16 07:39:47 --> Config Class Initialized
INFO - 2022-12-16 07:39:47 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:39:47 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:39:47 --> Utf8 Class Initialized
INFO - 2022-12-16 07:39:47 --> URI Class Initialized
INFO - 2022-12-16 07:39:47 --> Router Class Initialized
INFO - 2022-12-16 07:39:47 --> Output Class Initialized
INFO - 2022-12-16 07:39:47 --> Security Class Initialized
DEBUG - 2022-12-16 07:39:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:39:47 --> Input Class Initialized
INFO - 2022-12-16 07:39:47 --> Language Class Initialized
INFO - 2022-12-16 07:39:47 --> Language Class Initialized
INFO - 2022-12-16 07:39:47 --> Config Class Initialized
INFO - 2022-12-16 07:39:47 --> Loader Class Initialized
INFO - 2022-12-16 07:39:47 --> Helper loaded: url_helper
INFO - 2022-12-16 07:39:47 --> Helper loaded: file_helper
INFO - 2022-12-16 07:39:47 --> Helper loaded: form_helper
INFO - 2022-12-16 07:39:47 --> Helper loaded: my_helper
INFO - 2022-12-16 07:39:47 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:39:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:39:47 --> Controller Class Initialized
DEBUG - 2022-12-16 07:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:39:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:39:47 --> Final output sent to browser
DEBUG - 2022-12-16 07:39:47 --> Total execution time: 0.0963
INFO - 2022-12-16 07:40:13 --> Config Class Initialized
INFO - 2022-12-16 07:40:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:40:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:40:13 --> Utf8 Class Initialized
INFO - 2022-12-16 07:40:13 --> URI Class Initialized
INFO - 2022-12-16 07:40:13 --> Router Class Initialized
INFO - 2022-12-16 07:40:13 --> Output Class Initialized
INFO - 2022-12-16 07:40:13 --> Security Class Initialized
DEBUG - 2022-12-16 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:40:13 --> Input Class Initialized
INFO - 2022-12-16 07:40:13 --> Language Class Initialized
INFO - 2022-12-16 07:40:13 --> Language Class Initialized
INFO - 2022-12-16 07:40:13 --> Config Class Initialized
INFO - 2022-12-16 07:40:13 --> Loader Class Initialized
INFO - 2022-12-16 07:40:13 --> Helper loaded: url_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: file_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: form_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: my_helper
INFO - 2022-12-16 07:40:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:40:13 --> Controller Class Initialized
INFO - 2022-12-16 07:40:13 --> Config Class Initialized
INFO - 2022-12-16 07:40:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:40:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:40:13 --> Utf8 Class Initialized
INFO - 2022-12-16 07:40:13 --> URI Class Initialized
INFO - 2022-12-16 07:40:13 --> Router Class Initialized
INFO - 2022-12-16 07:40:13 --> Output Class Initialized
INFO - 2022-12-16 07:40:13 --> Security Class Initialized
DEBUG - 2022-12-16 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:40:13 --> Input Class Initialized
INFO - 2022-12-16 07:40:13 --> Language Class Initialized
INFO - 2022-12-16 07:40:13 --> Language Class Initialized
INFO - 2022-12-16 07:40:13 --> Config Class Initialized
INFO - 2022-12-16 07:40:13 --> Loader Class Initialized
INFO - 2022-12-16 07:40:13 --> Helper loaded: url_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: file_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: form_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: my_helper
INFO - 2022-12-16 07:40:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:40:13 --> Controller Class Initialized
DEBUG - 2022-12-16 07:40:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:40:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:40:13 --> Final output sent to browser
DEBUG - 2022-12-16 07:40:13 --> Total execution time: 0.0825
INFO - 2022-12-16 07:40:13 --> Config Class Initialized
INFO - 2022-12-16 07:40:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:40:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:40:13 --> Utf8 Class Initialized
INFO - 2022-12-16 07:40:13 --> URI Class Initialized
INFO - 2022-12-16 07:40:13 --> Router Class Initialized
INFO - 2022-12-16 07:40:13 --> Output Class Initialized
INFO - 2022-12-16 07:40:13 --> Security Class Initialized
DEBUG - 2022-12-16 07:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:40:13 --> Input Class Initialized
INFO - 2022-12-16 07:40:13 --> Language Class Initialized
INFO - 2022-12-16 07:40:13 --> Language Class Initialized
INFO - 2022-12-16 07:40:13 --> Config Class Initialized
INFO - 2022-12-16 07:40:13 --> Loader Class Initialized
INFO - 2022-12-16 07:40:13 --> Helper loaded: url_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: file_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: form_helper
INFO - 2022-12-16 07:40:13 --> Helper loaded: my_helper
INFO - 2022-12-16 07:40:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:40:13 --> Controller Class Initialized
INFO - 2022-12-16 07:40:22 --> Config Class Initialized
INFO - 2022-12-16 07:40:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:40:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:40:22 --> Utf8 Class Initialized
INFO - 2022-12-16 07:40:22 --> URI Class Initialized
INFO - 2022-12-16 07:40:22 --> Router Class Initialized
INFO - 2022-12-16 07:40:22 --> Output Class Initialized
INFO - 2022-12-16 07:40:22 --> Security Class Initialized
DEBUG - 2022-12-16 07:40:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:40:22 --> Input Class Initialized
INFO - 2022-12-16 07:40:22 --> Language Class Initialized
INFO - 2022-12-16 07:40:22 --> Language Class Initialized
INFO - 2022-12-16 07:40:22 --> Config Class Initialized
INFO - 2022-12-16 07:40:22 --> Loader Class Initialized
INFO - 2022-12-16 07:40:22 --> Helper loaded: url_helper
INFO - 2022-12-16 07:40:22 --> Helper loaded: file_helper
INFO - 2022-12-16 07:40:22 --> Helper loaded: form_helper
INFO - 2022-12-16 07:40:22 --> Helper loaded: my_helper
INFO - 2022-12-16 07:40:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:40:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:40:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:40:22 --> Controller Class Initialized
DEBUG - 2022-12-16 07:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:40:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:40:22 --> Final output sent to browser
DEBUG - 2022-12-16 07:40:22 --> Total execution time: 0.0742
INFO - 2022-12-16 07:40:42 --> Config Class Initialized
INFO - 2022-12-16 07:40:42 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:40:42 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:40:42 --> Utf8 Class Initialized
INFO - 2022-12-16 07:40:42 --> URI Class Initialized
INFO - 2022-12-16 07:40:42 --> Router Class Initialized
INFO - 2022-12-16 07:40:42 --> Output Class Initialized
INFO - 2022-12-16 07:40:42 --> Security Class Initialized
DEBUG - 2022-12-16 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:40:42 --> Input Class Initialized
INFO - 2022-12-16 07:40:42 --> Language Class Initialized
INFO - 2022-12-16 07:40:42 --> Language Class Initialized
INFO - 2022-12-16 07:40:42 --> Config Class Initialized
INFO - 2022-12-16 07:40:42 --> Loader Class Initialized
INFO - 2022-12-16 07:40:42 --> Helper loaded: url_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: file_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: form_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: my_helper
INFO - 2022-12-16 07:40:42 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:40:42 --> Controller Class Initialized
INFO - 2022-12-16 07:40:42 --> Config Class Initialized
INFO - 2022-12-16 07:40:42 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:40:42 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:40:42 --> Utf8 Class Initialized
INFO - 2022-12-16 07:40:42 --> URI Class Initialized
INFO - 2022-12-16 07:40:42 --> Router Class Initialized
INFO - 2022-12-16 07:40:42 --> Output Class Initialized
INFO - 2022-12-16 07:40:42 --> Security Class Initialized
DEBUG - 2022-12-16 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:40:42 --> Input Class Initialized
INFO - 2022-12-16 07:40:42 --> Language Class Initialized
INFO - 2022-12-16 07:40:42 --> Language Class Initialized
INFO - 2022-12-16 07:40:42 --> Config Class Initialized
INFO - 2022-12-16 07:40:42 --> Loader Class Initialized
INFO - 2022-12-16 07:40:42 --> Helper loaded: url_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: file_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: form_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: my_helper
INFO - 2022-12-16 07:40:42 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:40:42 --> Controller Class Initialized
DEBUG - 2022-12-16 07:40:42 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:40:42 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:40:42 --> Final output sent to browser
DEBUG - 2022-12-16 07:40:42 --> Total execution time: 0.0787
INFO - 2022-12-16 07:40:42 --> Config Class Initialized
INFO - 2022-12-16 07:40:42 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:40:42 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:40:42 --> Utf8 Class Initialized
INFO - 2022-12-16 07:40:42 --> URI Class Initialized
INFO - 2022-12-16 07:40:42 --> Router Class Initialized
INFO - 2022-12-16 07:40:42 --> Output Class Initialized
INFO - 2022-12-16 07:40:42 --> Security Class Initialized
DEBUG - 2022-12-16 07:40:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:40:42 --> Input Class Initialized
INFO - 2022-12-16 07:40:42 --> Language Class Initialized
INFO - 2022-12-16 07:40:42 --> Language Class Initialized
INFO - 2022-12-16 07:40:42 --> Config Class Initialized
INFO - 2022-12-16 07:40:42 --> Loader Class Initialized
INFO - 2022-12-16 07:40:42 --> Helper loaded: url_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: file_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: form_helper
INFO - 2022-12-16 07:40:42 --> Helper loaded: my_helper
INFO - 2022-12-16 07:40:42 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:40:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:40:42 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:40:42 --> Controller Class Initialized
INFO - 2022-12-16 07:41:00 --> Config Class Initialized
INFO - 2022-12-16 07:41:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:41:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:41:00 --> Utf8 Class Initialized
INFO - 2022-12-16 07:41:00 --> URI Class Initialized
INFO - 2022-12-16 07:41:00 --> Router Class Initialized
INFO - 2022-12-16 07:41:00 --> Output Class Initialized
INFO - 2022-12-16 07:41:00 --> Security Class Initialized
DEBUG - 2022-12-16 07:41:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:41:00 --> Input Class Initialized
INFO - 2022-12-16 07:41:00 --> Language Class Initialized
INFO - 2022-12-16 07:41:00 --> Language Class Initialized
INFO - 2022-12-16 07:41:00 --> Config Class Initialized
INFO - 2022-12-16 07:41:00 --> Loader Class Initialized
INFO - 2022-12-16 07:41:00 --> Helper loaded: url_helper
INFO - 2022-12-16 07:41:00 --> Helper loaded: file_helper
INFO - 2022-12-16 07:41:00 --> Helper loaded: form_helper
INFO - 2022-12-16 07:41:00 --> Helper loaded: my_helper
INFO - 2022-12-16 07:41:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:41:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:41:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:41:00 --> Controller Class Initialized
DEBUG - 2022-12-16 07:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:41:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:41:00 --> Final output sent to browser
DEBUG - 2022-12-16 07:41:00 --> Total execution time: 0.0744
INFO - 2022-12-16 07:42:03 --> Config Class Initialized
INFO - 2022-12-16 07:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:42:03 --> Utf8 Class Initialized
INFO - 2022-12-16 07:42:03 --> URI Class Initialized
INFO - 2022-12-16 07:42:03 --> Router Class Initialized
INFO - 2022-12-16 07:42:03 --> Output Class Initialized
INFO - 2022-12-16 07:42:03 --> Security Class Initialized
DEBUG - 2022-12-16 07:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:42:03 --> Input Class Initialized
INFO - 2022-12-16 07:42:03 --> Language Class Initialized
INFO - 2022-12-16 07:42:03 --> Language Class Initialized
INFO - 2022-12-16 07:42:03 --> Config Class Initialized
INFO - 2022-12-16 07:42:03 --> Loader Class Initialized
INFO - 2022-12-16 07:42:03 --> Helper loaded: url_helper
INFO - 2022-12-16 07:42:03 --> Helper loaded: file_helper
INFO - 2022-12-16 07:42:03 --> Helper loaded: form_helper
INFO - 2022-12-16 07:42:03 --> Helper loaded: my_helper
INFO - 2022-12-16 07:42:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:42:03 --> Controller Class Initialized
DEBUG - 2022-12-16 07:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:42:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:42:03 --> Final output sent to browser
DEBUG - 2022-12-16 07:42:03 --> Total execution time: 0.1038
INFO - 2022-12-16 07:42:03 --> Config Class Initialized
INFO - 2022-12-16 07:42:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:42:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:42:03 --> Utf8 Class Initialized
INFO - 2022-12-16 07:42:03 --> URI Class Initialized
INFO - 2022-12-16 07:42:03 --> Router Class Initialized
INFO - 2022-12-16 07:42:03 --> Output Class Initialized
INFO - 2022-12-16 07:42:03 --> Security Class Initialized
DEBUG - 2022-12-16 07:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:42:03 --> Input Class Initialized
INFO - 2022-12-16 07:42:03 --> Language Class Initialized
INFO - 2022-12-16 07:42:03 --> Language Class Initialized
INFO - 2022-12-16 07:42:03 --> Config Class Initialized
INFO - 2022-12-16 07:42:03 --> Loader Class Initialized
INFO - 2022-12-16 07:42:03 --> Helper loaded: url_helper
INFO - 2022-12-16 07:42:03 --> Helper loaded: file_helper
INFO - 2022-12-16 07:42:03 --> Helper loaded: form_helper
INFO - 2022-12-16 07:42:03 --> Helper loaded: my_helper
INFO - 2022-12-16 07:42:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:42:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:42:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:42:03 --> Controller Class Initialized
INFO - 2022-12-16 07:43:22 --> Config Class Initialized
INFO - 2022-12-16 07:43:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:22 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:22 --> URI Class Initialized
INFO - 2022-12-16 07:43:22 --> Router Class Initialized
INFO - 2022-12-16 07:43:22 --> Output Class Initialized
INFO - 2022-12-16 07:43:22 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:22 --> Input Class Initialized
INFO - 2022-12-16 07:43:22 --> Language Class Initialized
INFO - 2022-12-16 07:43:22 --> Language Class Initialized
INFO - 2022-12-16 07:43:22 --> Config Class Initialized
INFO - 2022-12-16 07:43:22 --> Loader Class Initialized
INFO - 2022-12-16 07:43:22 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:22 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:22 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:22 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:22 --> Controller Class Initialized
INFO - 2022-12-16 07:43:22 --> Config Class Initialized
INFO - 2022-12-16 07:43:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:22 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:22 --> URI Class Initialized
INFO - 2022-12-16 07:43:22 --> Router Class Initialized
INFO - 2022-12-16 07:43:22 --> Output Class Initialized
INFO - 2022-12-16 07:43:22 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:22 --> Input Class Initialized
INFO - 2022-12-16 07:43:22 --> Language Class Initialized
INFO - 2022-12-16 07:43:22 --> Language Class Initialized
INFO - 2022-12-16 07:43:22 --> Config Class Initialized
INFO - 2022-12-16 07:43:22 --> Loader Class Initialized
INFO - 2022-12-16 07:43:22 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:22 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:22 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:22 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:22 --> Controller Class Initialized
INFO - 2022-12-16 07:43:23 --> Config Class Initialized
INFO - 2022-12-16 07:43:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:23 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:23 --> URI Class Initialized
INFO - 2022-12-16 07:43:23 --> Router Class Initialized
INFO - 2022-12-16 07:43:23 --> Output Class Initialized
INFO - 2022-12-16 07:43:23 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:23 --> Input Class Initialized
INFO - 2022-12-16 07:43:23 --> Language Class Initialized
INFO - 2022-12-16 07:43:23 --> Language Class Initialized
INFO - 2022-12-16 07:43:23 --> Config Class Initialized
INFO - 2022-12-16 07:43:23 --> Loader Class Initialized
INFO - 2022-12-16 07:43:23 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:23 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:23 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:23 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:23 --> Controller Class Initialized
INFO - 2022-12-16 07:43:25 --> Config Class Initialized
INFO - 2022-12-16 07:43:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:25 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:25 --> URI Class Initialized
INFO - 2022-12-16 07:43:25 --> Router Class Initialized
INFO - 2022-12-16 07:43:25 --> Output Class Initialized
INFO - 2022-12-16 07:43:25 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:25 --> Input Class Initialized
INFO - 2022-12-16 07:43:25 --> Language Class Initialized
INFO - 2022-12-16 07:43:25 --> Language Class Initialized
INFO - 2022-12-16 07:43:25 --> Config Class Initialized
INFO - 2022-12-16 07:43:25 --> Loader Class Initialized
INFO - 2022-12-16 07:43:25 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:25 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:25 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:25 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:25 --> Controller Class Initialized
INFO - 2022-12-16 07:43:26 --> Config Class Initialized
INFO - 2022-12-16 07:43:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:26 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:26 --> URI Class Initialized
INFO - 2022-12-16 07:43:26 --> Router Class Initialized
INFO - 2022-12-16 07:43:26 --> Output Class Initialized
INFO - 2022-12-16 07:43:26 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:26 --> Input Class Initialized
INFO - 2022-12-16 07:43:26 --> Language Class Initialized
INFO - 2022-12-16 07:43:26 --> Language Class Initialized
INFO - 2022-12-16 07:43:26 --> Config Class Initialized
INFO - 2022-12-16 07:43:26 --> Loader Class Initialized
INFO - 2022-12-16 07:43:26 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:26 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:26 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:26 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:26 --> Controller Class Initialized
INFO - 2022-12-16 07:43:26 --> Config Class Initialized
INFO - 2022-12-16 07:43:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:26 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:26 --> URI Class Initialized
INFO - 2022-12-16 07:43:26 --> Router Class Initialized
INFO - 2022-12-16 07:43:26 --> Output Class Initialized
INFO - 2022-12-16 07:43:26 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:26 --> Input Class Initialized
INFO - 2022-12-16 07:43:26 --> Language Class Initialized
INFO - 2022-12-16 07:43:26 --> Language Class Initialized
INFO - 2022-12-16 07:43:26 --> Config Class Initialized
INFO - 2022-12-16 07:43:26 --> Loader Class Initialized
INFO - 2022-12-16 07:43:26 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:26 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:26 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:26 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:26 --> Controller Class Initialized
INFO - 2022-12-16 07:43:27 --> Config Class Initialized
INFO - 2022-12-16 07:43:27 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:27 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:27 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:27 --> URI Class Initialized
INFO - 2022-12-16 07:43:27 --> Router Class Initialized
INFO - 2022-12-16 07:43:27 --> Output Class Initialized
INFO - 2022-12-16 07:43:27 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:27 --> Input Class Initialized
INFO - 2022-12-16 07:43:27 --> Language Class Initialized
INFO - 2022-12-16 07:43:27 --> Language Class Initialized
INFO - 2022-12-16 07:43:27 --> Config Class Initialized
INFO - 2022-12-16 07:43:27 --> Loader Class Initialized
INFO - 2022-12-16 07:43:27 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:27 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:27 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:27 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:27 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:27 --> Controller Class Initialized
INFO - 2022-12-16 07:43:31 --> Config Class Initialized
INFO - 2022-12-16 07:43:31 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:31 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:31 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:31 --> URI Class Initialized
INFO - 2022-12-16 07:43:31 --> Router Class Initialized
INFO - 2022-12-16 07:43:31 --> Output Class Initialized
INFO - 2022-12-16 07:43:31 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:31 --> Input Class Initialized
INFO - 2022-12-16 07:43:31 --> Language Class Initialized
INFO - 2022-12-16 07:43:31 --> Language Class Initialized
INFO - 2022-12-16 07:43:31 --> Config Class Initialized
INFO - 2022-12-16 07:43:31 --> Loader Class Initialized
INFO - 2022-12-16 07:43:31 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:31 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:31 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:31 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:31 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:31 --> Controller Class Initialized
INFO - 2022-12-16 07:43:32 --> Config Class Initialized
INFO - 2022-12-16 07:43:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:43:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:43:32 --> Utf8 Class Initialized
INFO - 2022-12-16 07:43:32 --> URI Class Initialized
INFO - 2022-12-16 07:43:32 --> Router Class Initialized
INFO - 2022-12-16 07:43:32 --> Output Class Initialized
INFO - 2022-12-16 07:43:32 --> Security Class Initialized
DEBUG - 2022-12-16 07:43:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:43:32 --> Input Class Initialized
INFO - 2022-12-16 07:43:32 --> Language Class Initialized
INFO - 2022-12-16 07:43:32 --> Language Class Initialized
INFO - 2022-12-16 07:43:32 --> Config Class Initialized
INFO - 2022-12-16 07:43:32 --> Loader Class Initialized
INFO - 2022-12-16 07:43:32 --> Helper loaded: url_helper
INFO - 2022-12-16 07:43:32 --> Helper loaded: file_helper
INFO - 2022-12-16 07:43:32 --> Helper loaded: form_helper
INFO - 2022-12-16 07:43:32 --> Helper loaded: my_helper
INFO - 2022-12-16 07:43:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:43:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:43:32 --> Controller Class Initialized
DEBUG - 2022-12-16 07:43:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:43:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:43:32 --> Final output sent to browser
DEBUG - 2022-12-16 07:43:32 --> Total execution time: 0.0996
INFO - 2022-12-16 07:45:32 --> Config Class Initialized
INFO - 2022-12-16 07:45:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:32 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:32 --> URI Class Initialized
INFO - 2022-12-16 07:45:32 --> Router Class Initialized
INFO - 2022-12-16 07:45:32 --> Output Class Initialized
INFO - 2022-12-16 07:45:32 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:32 --> Input Class Initialized
INFO - 2022-12-16 07:45:32 --> Language Class Initialized
INFO - 2022-12-16 07:45:32 --> Language Class Initialized
INFO - 2022-12-16 07:45:32 --> Config Class Initialized
INFO - 2022-12-16 07:45:32 --> Loader Class Initialized
INFO - 2022-12-16 07:45:32 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:32 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:32 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:32 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:32 --> Controller Class Initialized
DEBUG - 2022-12-16 07:45:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:45:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:45:32 --> Final output sent to browser
DEBUG - 2022-12-16 07:45:32 --> Total execution time: 0.0749
INFO - 2022-12-16 07:45:33 --> Config Class Initialized
INFO - 2022-12-16 07:45:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:33 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:33 --> URI Class Initialized
INFO - 2022-12-16 07:45:33 --> Router Class Initialized
INFO - 2022-12-16 07:45:33 --> Output Class Initialized
INFO - 2022-12-16 07:45:33 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:33 --> Input Class Initialized
INFO - 2022-12-16 07:45:33 --> Language Class Initialized
INFO - 2022-12-16 07:45:33 --> Language Class Initialized
INFO - 2022-12-16 07:45:33 --> Config Class Initialized
INFO - 2022-12-16 07:45:33 --> Loader Class Initialized
INFO - 2022-12-16 07:45:33 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:33 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:33 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:33 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:33 --> Controller Class Initialized
INFO - 2022-12-16 07:45:35 --> Config Class Initialized
INFO - 2022-12-16 07:45:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:35 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:35 --> URI Class Initialized
INFO - 2022-12-16 07:45:35 --> Router Class Initialized
INFO - 2022-12-16 07:45:35 --> Output Class Initialized
INFO - 2022-12-16 07:45:35 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:35 --> Input Class Initialized
INFO - 2022-12-16 07:45:35 --> Language Class Initialized
INFO - 2022-12-16 07:45:35 --> Language Class Initialized
INFO - 2022-12-16 07:45:35 --> Config Class Initialized
INFO - 2022-12-16 07:45:35 --> Loader Class Initialized
INFO - 2022-12-16 07:45:35 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:35 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:35 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:35 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:35 --> Controller Class Initialized
INFO - 2022-12-16 07:45:37 --> Config Class Initialized
INFO - 2022-12-16 07:45:37 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:37 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:37 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:37 --> URI Class Initialized
INFO - 2022-12-16 07:45:37 --> Router Class Initialized
INFO - 2022-12-16 07:45:37 --> Output Class Initialized
INFO - 2022-12-16 07:45:37 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:37 --> Input Class Initialized
INFO - 2022-12-16 07:45:37 --> Language Class Initialized
INFO - 2022-12-16 07:45:37 --> Language Class Initialized
INFO - 2022-12-16 07:45:37 --> Config Class Initialized
INFO - 2022-12-16 07:45:37 --> Loader Class Initialized
INFO - 2022-12-16 07:45:37 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:37 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:37 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:37 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:37 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:37 --> Controller Class Initialized
INFO - 2022-12-16 07:45:38 --> Config Class Initialized
INFO - 2022-12-16 07:45:38 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:38 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:38 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:38 --> URI Class Initialized
INFO - 2022-12-16 07:45:38 --> Router Class Initialized
INFO - 2022-12-16 07:45:38 --> Output Class Initialized
INFO - 2022-12-16 07:45:38 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:38 --> Input Class Initialized
INFO - 2022-12-16 07:45:38 --> Language Class Initialized
INFO - 2022-12-16 07:45:38 --> Language Class Initialized
INFO - 2022-12-16 07:45:38 --> Config Class Initialized
INFO - 2022-12-16 07:45:38 --> Loader Class Initialized
INFO - 2022-12-16 07:45:38 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:38 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:38 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:38 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:38 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:38 --> Controller Class Initialized
INFO - 2022-12-16 07:45:38 --> Config Class Initialized
INFO - 2022-12-16 07:45:38 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:38 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:38 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:38 --> URI Class Initialized
INFO - 2022-12-16 07:45:38 --> Router Class Initialized
INFO - 2022-12-16 07:45:38 --> Output Class Initialized
INFO - 2022-12-16 07:45:38 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:38 --> Input Class Initialized
INFO - 2022-12-16 07:45:38 --> Language Class Initialized
INFO - 2022-12-16 07:45:38 --> Language Class Initialized
INFO - 2022-12-16 07:45:38 --> Config Class Initialized
INFO - 2022-12-16 07:45:38 --> Loader Class Initialized
INFO - 2022-12-16 07:45:38 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:38 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:38 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:38 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:38 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:38 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:38 --> Controller Class Initialized
INFO - 2022-12-16 07:45:39 --> Config Class Initialized
INFO - 2022-12-16 07:45:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:39 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:39 --> URI Class Initialized
INFO - 2022-12-16 07:45:39 --> Router Class Initialized
INFO - 2022-12-16 07:45:39 --> Output Class Initialized
INFO - 2022-12-16 07:45:39 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:39 --> Input Class Initialized
INFO - 2022-12-16 07:45:39 --> Language Class Initialized
INFO - 2022-12-16 07:45:39 --> Language Class Initialized
INFO - 2022-12-16 07:45:39 --> Config Class Initialized
INFO - 2022-12-16 07:45:39 --> Loader Class Initialized
INFO - 2022-12-16 07:45:39 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:39 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:39 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:39 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:39 --> Controller Class Initialized
INFO - 2022-12-16 07:45:39 --> Config Class Initialized
INFO - 2022-12-16 07:45:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:39 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:39 --> URI Class Initialized
INFO - 2022-12-16 07:45:39 --> Router Class Initialized
INFO - 2022-12-16 07:45:39 --> Output Class Initialized
INFO - 2022-12-16 07:45:39 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:39 --> Input Class Initialized
INFO - 2022-12-16 07:45:39 --> Language Class Initialized
INFO - 2022-12-16 07:45:39 --> Language Class Initialized
INFO - 2022-12-16 07:45:39 --> Config Class Initialized
INFO - 2022-12-16 07:45:39 --> Loader Class Initialized
INFO - 2022-12-16 07:45:39 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:39 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:39 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:39 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:39 --> Controller Class Initialized
INFO - 2022-12-16 07:45:50 --> Config Class Initialized
INFO - 2022-12-16 07:45:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:50 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:50 --> URI Class Initialized
INFO - 2022-12-16 07:45:50 --> Router Class Initialized
INFO - 2022-12-16 07:45:50 --> Output Class Initialized
INFO - 2022-12-16 07:45:50 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:50 --> Input Class Initialized
INFO - 2022-12-16 07:45:50 --> Language Class Initialized
INFO - 2022-12-16 07:45:50 --> Language Class Initialized
INFO - 2022-12-16 07:45:50 --> Config Class Initialized
INFO - 2022-12-16 07:45:50 --> Loader Class Initialized
INFO - 2022-12-16 07:45:50 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:50 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:50 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:50 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:50 --> Controller Class Initialized
DEBUG - 2022-12-16 07:45:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:45:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:45:50 --> Final output sent to browser
DEBUG - 2022-12-16 07:45:50 --> Total execution time: 0.1049
INFO - 2022-12-16 07:45:52 --> Config Class Initialized
INFO - 2022-12-16 07:45:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:52 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:52 --> URI Class Initialized
INFO - 2022-12-16 07:45:52 --> Router Class Initialized
INFO - 2022-12-16 07:45:52 --> Output Class Initialized
INFO - 2022-12-16 07:45:52 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:52 --> Input Class Initialized
INFO - 2022-12-16 07:45:52 --> Language Class Initialized
INFO - 2022-12-16 07:45:52 --> Language Class Initialized
INFO - 2022-12-16 07:45:52 --> Config Class Initialized
INFO - 2022-12-16 07:45:52 --> Loader Class Initialized
INFO - 2022-12-16 07:45:52 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:52 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:52 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:52 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:52 --> Controller Class Initialized
DEBUG - 2022-12-16 07:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:45:52 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:45:52 --> Final output sent to browser
DEBUG - 2022-12-16 07:45:52 --> Total execution time: 0.0827
INFO - 2022-12-16 07:45:52 --> Config Class Initialized
INFO - 2022-12-16 07:45:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:52 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:52 --> URI Class Initialized
INFO - 2022-12-16 07:45:52 --> Router Class Initialized
INFO - 2022-12-16 07:45:52 --> Output Class Initialized
INFO - 2022-12-16 07:45:52 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:52 --> Input Class Initialized
INFO - 2022-12-16 07:45:52 --> Language Class Initialized
INFO - 2022-12-16 07:45:52 --> Language Class Initialized
INFO - 2022-12-16 07:45:52 --> Config Class Initialized
INFO - 2022-12-16 07:45:52 --> Loader Class Initialized
INFO - 2022-12-16 07:45:52 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:52 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:52 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:52 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:52 --> Controller Class Initialized
INFO - 2022-12-16 07:45:54 --> Config Class Initialized
INFO - 2022-12-16 07:45:54 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:54 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:54 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:54 --> URI Class Initialized
INFO - 2022-12-16 07:45:54 --> Router Class Initialized
INFO - 2022-12-16 07:45:54 --> Output Class Initialized
INFO - 2022-12-16 07:45:54 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:54 --> Input Class Initialized
INFO - 2022-12-16 07:45:54 --> Language Class Initialized
INFO - 2022-12-16 07:45:54 --> Language Class Initialized
INFO - 2022-12-16 07:45:54 --> Config Class Initialized
INFO - 2022-12-16 07:45:54 --> Loader Class Initialized
INFO - 2022-12-16 07:45:54 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:54 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:54 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:54 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:54 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:54 --> Controller Class Initialized
INFO - 2022-12-16 07:45:55 --> Config Class Initialized
INFO - 2022-12-16 07:45:55 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:55 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:55 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:55 --> URI Class Initialized
INFO - 2022-12-16 07:45:55 --> Router Class Initialized
INFO - 2022-12-16 07:45:55 --> Output Class Initialized
INFO - 2022-12-16 07:45:55 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:55 --> Input Class Initialized
INFO - 2022-12-16 07:45:55 --> Language Class Initialized
INFO - 2022-12-16 07:45:55 --> Language Class Initialized
INFO - 2022-12-16 07:45:55 --> Config Class Initialized
INFO - 2022-12-16 07:45:55 --> Loader Class Initialized
INFO - 2022-12-16 07:45:55 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:55 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:55 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:55 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:55 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:55 --> Controller Class Initialized
INFO - 2022-12-16 07:45:56 --> Config Class Initialized
INFO - 2022-12-16 07:45:56 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:45:56 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:45:56 --> Utf8 Class Initialized
INFO - 2022-12-16 07:45:56 --> URI Class Initialized
INFO - 2022-12-16 07:45:56 --> Router Class Initialized
INFO - 2022-12-16 07:45:56 --> Output Class Initialized
INFO - 2022-12-16 07:45:56 --> Security Class Initialized
DEBUG - 2022-12-16 07:45:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:45:56 --> Input Class Initialized
INFO - 2022-12-16 07:45:56 --> Language Class Initialized
INFO - 2022-12-16 07:45:56 --> Language Class Initialized
INFO - 2022-12-16 07:45:56 --> Config Class Initialized
INFO - 2022-12-16 07:45:56 --> Loader Class Initialized
INFO - 2022-12-16 07:45:56 --> Helper loaded: url_helper
INFO - 2022-12-16 07:45:56 --> Helper loaded: file_helper
INFO - 2022-12-16 07:45:56 --> Helper loaded: form_helper
INFO - 2022-12-16 07:45:56 --> Helper loaded: my_helper
INFO - 2022-12-16 07:45:56 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:45:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:45:56 --> Controller Class Initialized
DEBUG - 2022-12-16 07:45:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:45:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:45:56 --> Final output sent to browser
DEBUG - 2022-12-16 07:45:56 --> Total execution time: 0.0886
INFO - 2022-12-16 07:46:35 --> Config Class Initialized
INFO - 2022-12-16 07:46:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:46:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:46:35 --> Utf8 Class Initialized
INFO - 2022-12-16 07:46:35 --> URI Class Initialized
INFO - 2022-12-16 07:46:35 --> Router Class Initialized
INFO - 2022-12-16 07:46:35 --> Output Class Initialized
INFO - 2022-12-16 07:46:35 --> Security Class Initialized
DEBUG - 2022-12-16 07:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:46:35 --> Input Class Initialized
INFO - 2022-12-16 07:46:35 --> Language Class Initialized
INFO - 2022-12-16 07:46:35 --> Language Class Initialized
INFO - 2022-12-16 07:46:35 --> Config Class Initialized
INFO - 2022-12-16 07:46:35 --> Loader Class Initialized
INFO - 2022-12-16 07:46:35 --> Helper loaded: url_helper
INFO - 2022-12-16 07:46:35 --> Helper loaded: file_helper
INFO - 2022-12-16 07:46:35 --> Helper loaded: form_helper
INFO - 2022-12-16 07:46:35 --> Helper loaded: my_helper
INFO - 2022-12-16 07:46:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:46:35 --> Controller Class Initialized
INFO - 2022-12-16 07:46:35 --> Config Class Initialized
INFO - 2022-12-16 07:46:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:46:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:46:35 --> Utf8 Class Initialized
INFO - 2022-12-16 07:46:35 --> URI Class Initialized
INFO - 2022-12-16 07:46:35 --> Router Class Initialized
INFO - 2022-12-16 07:46:35 --> Output Class Initialized
INFO - 2022-12-16 07:46:35 --> Security Class Initialized
DEBUG - 2022-12-16 07:46:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:46:35 --> Input Class Initialized
INFO - 2022-12-16 07:46:35 --> Language Class Initialized
INFO - 2022-12-16 07:46:35 --> Language Class Initialized
INFO - 2022-12-16 07:46:35 --> Config Class Initialized
INFO - 2022-12-16 07:46:35 --> Loader Class Initialized
INFO - 2022-12-16 07:46:35 --> Helper loaded: url_helper
INFO - 2022-12-16 07:46:35 --> Helper loaded: file_helper
INFO - 2022-12-16 07:46:35 --> Helper loaded: form_helper
INFO - 2022-12-16 07:46:35 --> Helper loaded: my_helper
INFO - 2022-12-16 07:46:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:46:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:46:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:46:35 --> Controller Class Initialized
DEBUG - 2022-12-16 07:46:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:46:35 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:46:35 --> Final output sent to browser
DEBUG - 2022-12-16 07:46:35 --> Total execution time: 0.0585
INFO - 2022-12-16 07:46:35 --> Config Class Initialized
INFO - 2022-12-16 07:46:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:46:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:46:35 --> Utf8 Class Initialized
INFO - 2022-12-16 07:46:35 --> URI Class Initialized
INFO - 2022-12-16 07:46:35 --> Router Class Initialized
INFO - 2022-12-16 07:46:36 --> Output Class Initialized
INFO - 2022-12-16 07:46:36 --> Security Class Initialized
DEBUG - 2022-12-16 07:46:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:46:36 --> Input Class Initialized
INFO - 2022-12-16 07:46:36 --> Language Class Initialized
INFO - 2022-12-16 07:46:36 --> Language Class Initialized
INFO - 2022-12-16 07:46:36 --> Config Class Initialized
INFO - 2022-12-16 07:46:36 --> Loader Class Initialized
INFO - 2022-12-16 07:46:36 --> Helper loaded: url_helper
INFO - 2022-12-16 07:46:36 --> Helper loaded: file_helper
INFO - 2022-12-16 07:46:36 --> Helper loaded: form_helper
INFO - 2022-12-16 07:46:36 --> Helper loaded: my_helper
INFO - 2022-12-16 07:46:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:46:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:46:36 --> Controller Class Initialized
INFO - 2022-12-16 07:46:37 --> Config Class Initialized
INFO - 2022-12-16 07:46:37 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:46:37 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:46:37 --> Utf8 Class Initialized
INFO - 2022-12-16 07:46:37 --> URI Class Initialized
INFO - 2022-12-16 07:46:37 --> Router Class Initialized
INFO - 2022-12-16 07:46:37 --> Output Class Initialized
INFO - 2022-12-16 07:46:37 --> Security Class Initialized
DEBUG - 2022-12-16 07:46:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:46:37 --> Input Class Initialized
INFO - 2022-12-16 07:46:37 --> Language Class Initialized
INFO - 2022-12-16 07:46:37 --> Language Class Initialized
INFO - 2022-12-16 07:46:37 --> Config Class Initialized
INFO - 2022-12-16 07:46:37 --> Loader Class Initialized
INFO - 2022-12-16 07:46:37 --> Helper loaded: url_helper
INFO - 2022-12-16 07:46:37 --> Helper loaded: file_helper
INFO - 2022-12-16 07:46:37 --> Helper loaded: form_helper
INFO - 2022-12-16 07:46:37 --> Helper loaded: my_helper
INFO - 2022-12-16 07:46:37 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:46:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:46:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:46:37 --> Controller Class Initialized
DEBUG - 2022-12-16 07:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 07:46:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:46:37 --> Final output sent to browser
DEBUG - 2022-12-16 07:46:37 --> Total execution time: 0.0773
INFO - 2022-12-16 07:48:02 --> Config Class Initialized
INFO - 2022-12-16 07:48:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:02 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:02 --> URI Class Initialized
INFO - 2022-12-16 07:48:02 --> Router Class Initialized
INFO - 2022-12-16 07:48:02 --> Output Class Initialized
INFO - 2022-12-16 07:48:02 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:02 --> Input Class Initialized
INFO - 2022-12-16 07:48:02 --> Language Class Initialized
INFO - 2022-12-16 07:48:02 --> Language Class Initialized
INFO - 2022-12-16 07:48:02 --> Config Class Initialized
INFO - 2022-12-16 07:48:02 --> Loader Class Initialized
INFO - 2022-12-16 07:48:02 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:02 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:02 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:02 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:02 --> Controller Class Initialized
INFO - 2022-12-16 07:48:02 --> Config Class Initialized
INFO - 2022-12-16 07:48:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:02 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:02 --> URI Class Initialized
INFO - 2022-12-16 07:48:02 --> Router Class Initialized
INFO - 2022-12-16 07:48:02 --> Output Class Initialized
INFO - 2022-12-16 07:48:02 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:02 --> Input Class Initialized
INFO - 2022-12-16 07:48:02 --> Language Class Initialized
INFO - 2022-12-16 07:48:02 --> Language Class Initialized
INFO - 2022-12-16 07:48:02 --> Config Class Initialized
INFO - 2022-12-16 07:48:02 --> Loader Class Initialized
INFO - 2022-12-16 07:48:02 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:02 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:02 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:03 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:03 --> Controller Class Initialized
DEBUG - 2022-12-16 07:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 07:48:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 07:48:03 --> Final output sent to browser
DEBUG - 2022-12-16 07:48:03 --> Total execution time: 0.0779
INFO - 2022-12-16 07:48:03 --> Config Class Initialized
INFO - 2022-12-16 07:48:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:03 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:03 --> URI Class Initialized
INFO - 2022-12-16 07:48:03 --> Router Class Initialized
INFO - 2022-12-16 07:48:03 --> Output Class Initialized
INFO - 2022-12-16 07:48:03 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:03 --> Input Class Initialized
INFO - 2022-12-16 07:48:03 --> Language Class Initialized
INFO - 2022-12-16 07:48:03 --> Language Class Initialized
INFO - 2022-12-16 07:48:03 --> Config Class Initialized
INFO - 2022-12-16 07:48:03 --> Loader Class Initialized
INFO - 2022-12-16 07:48:03 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:03 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:03 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:03 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:03 --> Controller Class Initialized
INFO - 2022-12-16 07:48:07 --> Config Class Initialized
INFO - 2022-12-16 07:48:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:07 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:07 --> URI Class Initialized
INFO - 2022-12-16 07:48:07 --> Router Class Initialized
INFO - 2022-12-16 07:48:07 --> Output Class Initialized
INFO - 2022-12-16 07:48:07 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:07 --> Input Class Initialized
INFO - 2022-12-16 07:48:07 --> Language Class Initialized
INFO - 2022-12-16 07:48:07 --> Language Class Initialized
INFO - 2022-12-16 07:48:07 --> Config Class Initialized
INFO - 2022-12-16 07:48:07 --> Loader Class Initialized
INFO - 2022-12-16 07:48:07 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:07 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:07 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:07 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:07 --> Controller Class Initialized
INFO - 2022-12-16 07:48:07 --> Config Class Initialized
INFO - 2022-12-16 07:48:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:07 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:07 --> URI Class Initialized
INFO - 2022-12-16 07:48:07 --> Router Class Initialized
INFO - 2022-12-16 07:48:07 --> Output Class Initialized
INFO - 2022-12-16 07:48:07 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:07 --> Input Class Initialized
INFO - 2022-12-16 07:48:07 --> Language Class Initialized
INFO - 2022-12-16 07:48:07 --> Language Class Initialized
INFO - 2022-12-16 07:48:07 --> Config Class Initialized
INFO - 2022-12-16 07:48:07 --> Loader Class Initialized
INFO - 2022-12-16 07:48:07 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:07 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:07 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:07 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:07 --> Controller Class Initialized
INFO - 2022-12-16 07:48:08 --> Config Class Initialized
INFO - 2022-12-16 07:48:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:08 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:08 --> URI Class Initialized
INFO - 2022-12-16 07:48:08 --> Router Class Initialized
INFO - 2022-12-16 07:48:08 --> Output Class Initialized
INFO - 2022-12-16 07:48:08 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:08 --> Input Class Initialized
INFO - 2022-12-16 07:48:08 --> Language Class Initialized
INFO - 2022-12-16 07:48:08 --> Language Class Initialized
INFO - 2022-12-16 07:48:08 --> Config Class Initialized
INFO - 2022-12-16 07:48:08 --> Loader Class Initialized
INFO - 2022-12-16 07:48:08 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:08 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:08 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:08 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:08 --> Controller Class Initialized
INFO - 2022-12-16 07:48:08 --> Config Class Initialized
INFO - 2022-12-16 07:48:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:08 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:08 --> URI Class Initialized
INFO - 2022-12-16 07:48:08 --> Router Class Initialized
INFO - 2022-12-16 07:48:08 --> Output Class Initialized
INFO - 2022-12-16 07:48:08 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:09 --> Input Class Initialized
INFO - 2022-12-16 07:48:09 --> Language Class Initialized
INFO - 2022-12-16 07:48:09 --> Language Class Initialized
INFO - 2022-12-16 07:48:09 --> Config Class Initialized
INFO - 2022-12-16 07:48:09 --> Loader Class Initialized
INFO - 2022-12-16 07:48:09 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:09 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:09 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:09 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:09 --> Controller Class Initialized
INFO - 2022-12-16 07:48:09 --> Config Class Initialized
INFO - 2022-12-16 07:48:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:09 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:09 --> URI Class Initialized
INFO - 2022-12-16 07:48:09 --> Router Class Initialized
INFO - 2022-12-16 07:48:09 --> Output Class Initialized
INFO - 2022-12-16 07:48:09 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:09 --> Input Class Initialized
INFO - 2022-12-16 07:48:09 --> Language Class Initialized
INFO - 2022-12-16 07:48:09 --> Language Class Initialized
INFO - 2022-12-16 07:48:09 --> Config Class Initialized
INFO - 2022-12-16 07:48:09 --> Loader Class Initialized
INFO - 2022-12-16 07:48:09 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:09 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:09 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:09 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:09 --> Controller Class Initialized
INFO - 2022-12-16 07:48:19 --> Config Class Initialized
INFO - 2022-12-16 07:48:19 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:19 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:19 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:19 --> URI Class Initialized
INFO - 2022-12-16 07:48:19 --> Router Class Initialized
INFO - 2022-12-16 07:48:19 --> Output Class Initialized
INFO - 2022-12-16 07:48:19 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:19 --> Input Class Initialized
INFO - 2022-12-16 07:48:19 --> Language Class Initialized
INFO - 2022-12-16 07:48:19 --> Language Class Initialized
INFO - 2022-12-16 07:48:19 --> Config Class Initialized
INFO - 2022-12-16 07:48:19 --> Loader Class Initialized
INFO - 2022-12-16 07:48:19 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:19 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:19 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:19 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:19 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:19 --> Controller Class Initialized
INFO - 2022-12-16 07:48:19 --> Config Class Initialized
INFO - 2022-12-16 07:48:19 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:19 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:19 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:19 --> URI Class Initialized
INFO - 2022-12-16 07:48:19 --> Router Class Initialized
INFO - 2022-12-16 07:48:19 --> Output Class Initialized
INFO - 2022-12-16 07:48:19 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:19 --> Input Class Initialized
INFO - 2022-12-16 07:48:19 --> Language Class Initialized
INFO - 2022-12-16 07:48:19 --> Language Class Initialized
INFO - 2022-12-16 07:48:19 --> Config Class Initialized
INFO - 2022-12-16 07:48:19 --> Loader Class Initialized
INFO - 2022-12-16 07:48:19 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:19 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:19 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:19 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:19 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:19 --> Controller Class Initialized
INFO - 2022-12-16 07:48:20 --> Config Class Initialized
INFO - 2022-12-16 07:48:20 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:20 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:20 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:20 --> URI Class Initialized
INFO - 2022-12-16 07:48:20 --> Router Class Initialized
INFO - 2022-12-16 07:48:20 --> Output Class Initialized
INFO - 2022-12-16 07:48:20 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:20 --> Input Class Initialized
INFO - 2022-12-16 07:48:20 --> Language Class Initialized
INFO - 2022-12-16 07:48:20 --> Language Class Initialized
INFO - 2022-12-16 07:48:20 --> Config Class Initialized
INFO - 2022-12-16 07:48:20 --> Loader Class Initialized
INFO - 2022-12-16 07:48:20 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:20 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:20 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:20 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:20 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:20 --> Controller Class Initialized
INFO - 2022-12-16 07:48:22 --> Config Class Initialized
INFO - 2022-12-16 07:48:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:22 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:22 --> URI Class Initialized
INFO - 2022-12-16 07:48:22 --> Router Class Initialized
INFO - 2022-12-16 07:48:22 --> Output Class Initialized
INFO - 2022-12-16 07:48:22 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:22 --> Input Class Initialized
INFO - 2022-12-16 07:48:22 --> Language Class Initialized
INFO - 2022-12-16 07:48:22 --> Language Class Initialized
INFO - 2022-12-16 07:48:22 --> Config Class Initialized
INFO - 2022-12-16 07:48:22 --> Loader Class Initialized
INFO - 2022-12-16 07:48:22 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:22 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:22 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:22 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:22 --> Controller Class Initialized
INFO - 2022-12-16 07:48:23 --> Config Class Initialized
INFO - 2022-12-16 07:48:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:23 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:23 --> URI Class Initialized
INFO - 2022-12-16 07:48:23 --> Router Class Initialized
INFO - 2022-12-16 07:48:23 --> Output Class Initialized
INFO - 2022-12-16 07:48:23 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:23 --> Input Class Initialized
INFO - 2022-12-16 07:48:23 --> Language Class Initialized
INFO - 2022-12-16 07:48:23 --> Language Class Initialized
INFO - 2022-12-16 07:48:23 --> Config Class Initialized
INFO - 2022-12-16 07:48:23 --> Loader Class Initialized
INFO - 2022-12-16 07:48:23 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:23 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:23 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:23 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:23 --> Controller Class Initialized
INFO - 2022-12-16 07:48:25 --> Config Class Initialized
INFO - 2022-12-16 07:48:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:25 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:25 --> URI Class Initialized
INFO - 2022-12-16 07:48:25 --> Router Class Initialized
INFO - 2022-12-16 07:48:25 --> Output Class Initialized
INFO - 2022-12-16 07:48:25 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:25 --> Input Class Initialized
INFO - 2022-12-16 07:48:25 --> Language Class Initialized
INFO - 2022-12-16 07:48:25 --> Language Class Initialized
INFO - 2022-12-16 07:48:25 --> Config Class Initialized
INFO - 2022-12-16 07:48:25 --> Loader Class Initialized
INFO - 2022-12-16 07:48:25 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:25 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:25 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:25 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:25 --> Controller Class Initialized
INFO - 2022-12-16 07:48:28 --> Config Class Initialized
INFO - 2022-12-16 07:48:28 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:28 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:28 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:28 --> URI Class Initialized
INFO - 2022-12-16 07:48:28 --> Router Class Initialized
INFO - 2022-12-16 07:48:28 --> Output Class Initialized
INFO - 2022-12-16 07:48:28 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:28 --> Input Class Initialized
INFO - 2022-12-16 07:48:28 --> Language Class Initialized
INFO - 2022-12-16 07:48:28 --> Language Class Initialized
INFO - 2022-12-16 07:48:28 --> Config Class Initialized
INFO - 2022-12-16 07:48:28 --> Loader Class Initialized
INFO - 2022-12-16 07:48:28 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:28 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:28 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:28 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:28 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:28 --> Controller Class Initialized
INFO - 2022-12-16 07:48:36 --> Config Class Initialized
INFO - 2022-12-16 07:48:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:36 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:36 --> URI Class Initialized
INFO - 2022-12-16 07:48:36 --> Router Class Initialized
INFO - 2022-12-16 07:48:36 --> Output Class Initialized
INFO - 2022-12-16 07:48:36 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:36 --> Input Class Initialized
INFO - 2022-12-16 07:48:36 --> Language Class Initialized
INFO - 2022-12-16 07:48:36 --> Language Class Initialized
INFO - 2022-12-16 07:48:36 --> Config Class Initialized
INFO - 2022-12-16 07:48:36 --> Loader Class Initialized
INFO - 2022-12-16 07:48:36 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:36 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:36 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:36 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:36 --> Controller Class Initialized
INFO - 2022-12-16 07:48:36 --> Final output sent to browser
DEBUG - 2022-12-16 07:48:36 --> Total execution time: 0.0893
INFO - 2022-12-16 07:48:36 --> Config Class Initialized
INFO - 2022-12-16 07:48:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 07:48:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 07:48:36 --> Utf8 Class Initialized
INFO - 2022-12-16 07:48:36 --> URI Class Initialized
INFO - 2022-12-16 07:48:36 --> Router Class Initialized
INFO - 2022-12-16 07:48:36 --> Output Class Initialized
INFO - 2022-12-16 07:48:36 --> Security Class Initialized
DEBUG - 2022-12-16 07:48:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 07:48:36 --> Input Class Initialized
INFO - 2022-12-16 07:48:36 --> Language Class Initialized
INFO - 2022-12-16 07:48:36 --> Language Class Initialized
INFO - 2022-12-16 07:48:36 --> Config Class Initialized
INFO - 2022-12-16 07:48:36 --> Loader Class Initialized
INFO - 2022-12-16 07:48:36 --> Helper loaded: url_helper
INFO - 2022-12-16 07:48:36 --> Helper loaded: file_helper
INFO - 2022-12-16 07:48:36 --> Helper loaded: form_helper
INFO - 2022-12-16 07:48:36 --> Helper loaded: my_helper
INFO - 2022-12-16 07:48:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 07:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 07:48:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 07:48:36 --> Controller Class Initialized
INFO - 2022-12-16 09:01:07 --> Config Class Initialized
INFO - 2022-12-16 09:01:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:07 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:07 --> URI Class Initialized
INFO - 2022-12-16 09:01:07 --> Router Class Initialized
INFO - 2022-12-16 09:01:07 --> Output Class Initialized
INFO - 2022-12-16 09:01:07 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:07 --> Input Class Initialized
INFO - 2022-12-16 09:01:07 --> Language Class Initialized
INFO - 2022-12-16 09:01:07 --> Language Class Initialized
INFO - 2022-12-16 09:01:07 --> Config Class Initialized
INFO - 2022-12-16 09:01:07 --> Loader Class Initialized
INFO - 2022-12-16 09:01:07 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:07 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:07 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:07 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:07 --> Controller Class Initialized
INFO - 2022-12-16 09:01:07 --> Config Class Initialized
INFO - 2022-12-16 09:01:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:07 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:07 --> URI Class Initialized
INFO - 2022-12-16 09:01:07 --> Router Class Initialized
INFO - 2022-12-16 09:01:07 --> Output Class Initialized
INFO - 2022-12-16 09:01:07 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:07 --> Input Class Initialized
INFO - 2022-12-16 09:01:07 --> Language Class Initialized
INFO - 2022-12-16 09:01:07 --> Language Class Initialized
INFO - 2022-12-16 09:01:07 --> Config Class Initialized
INFO - 2022-12-16 09:01:07 --> Loader Class Initialized
INFO - 2022-12-16 09:01:07 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:07 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:07 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:07 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:07 --> Controller Class Initialized
INFO - 2022-12-16 09:01:08 --> Config Class Initialized
INFO - 2022-12-16 09:01:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:08 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:08 --> URI Class Initialized
INFO - 2022-12-16 09:01:08 --> Router Class Initialized
INFO - 2022-12-16 09:01:08 --> Output Class Initialized
INFO - 2022-12-16 09:01:08 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:08 --> Input Class Initialized
INFO - 2022-12-16 09:01:08 --> Language Class Initialized
INFO - 2022-12-16 09:01:08 --> Language Class Initialized
INFO - 2022-12-16 09:01:08 --> Config Class Initialized
INFO - 2022-12-16 09:01:08 --> Loader Class Initialized
INFO - 2022-12-16 09:01:08 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:08 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:08 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:08 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:08 --> Controller Class Initialized
INFO - 2022-12-16 09:01:15 --> Config Class Initialized
INFO - 2022-12-16 09:01:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:15 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:15 --> URI Class Initialized
INFO - 2022-12-16 09:01:15 --> Router Class Initialized
INFO - 2022-12-16 09:01:15 --> Output Class Initialized
INFO - 2022-12-16 09:01:15 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:15 --> Input Class Initialized
INFO - 2022-12-16 09:01:15 --> Language Class Initialized
INFO - 2022-12-16 09:01:15 --> Language Class Initialized
INFO - 2022-12-16 09:01:15 --> Config Class Initialized
INFO - 2022-12-16 09:01:15 --> Loader Class Initialized
INFO - 2022-12-16 09:01:15 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:15 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:15 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:15 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:15 --> Controller Class Initialized
INFO - 2022-12-16 09:01:16 --> Config Class Initialized
INFO - 2022-12-16 09:01:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:16 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:16 --> URI Class Initialized
INFO - 2022-12-16 09:01:16 --> Router Class Initialized
INFO - 2022-12-16 09:01:16 --> Output Class Initialized
INFO - 2022-12-16 09:01:16 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:16 --> Input Class Initialized
INFO - 2022-12-16 09:01:16 --> Language Class Initialized
INFO - 2022-12-16 09:01:16 --> Language Class Initialized
INFO - 2022-12-16 09:01:16 --> Config Class Initialized
INFO - 2022-12-16 09:01:16 --> Loader Class Initialized
INFO - 2022-12-16 09:01:16 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:16 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:16 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:16 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:16 --> Controller Class Initialized
INFO - 2022-12-16 09:01:24 --> Config Class Initialized
INFO - 2022-12-16 09:01:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:24 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:24 --> URI Class Initialized
INFO - 2022-12-16 09:01:24 --> Router Class Initialized
INFO - 2022-12-16 09:01:24 --> Output Class Initialized
INFO - 2022-12-16 09:01:24 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:24 --> Input Class Initialized
INFO - 2022-12-16 09:01:24 --> Language Class Initialized
INFO - 2022-12-16 09:01:24 --> Language Class Initialized
INFO - 2022-12-16 09:01:24 --> Config Class Initialized
INFO - 2022-12-16 09:01:24 --> Loader Class Initialized
INFO - 2022-12-16 09:01:24 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:24 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:24 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:24 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:24 --> Controller Class Initialized
INFO - 2022-12-16 09:01:25 --> Config Class Initialized
INFO - 2022-12-16 09:01:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:25 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:25 --> URI Class Initialized
INFO - 2022-12-16 09:01:25 --> Router Class Initialized
INFO - 2022-12-16 09:01:25 --> Output Class Initialized
INFO - 2022-12-16 09:01:25 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:25 --> Input Class Initialized
INFO - 2022-12-16 09:01:25 --> Language Class Initialized
INFO - 2022-12-16 09:01:25 --> Language Class Initialized
INFO - 2022-12-16 09:01:25 --> Config Class Initialized
INFO - 2022-12-16 09:01:25 --> Loader Class Initialized
INFO - 2022-12-16 09:01:25 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:25 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:25 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:25 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:25 --> Controller Class Initialized
INFO - 2022-12-16 09:01:26 --> Config Class Initialized
INFO - 2022-12-16 09:01:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:26 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:26 --> URI Class Initialized
INFO - 2022-12-16 09:01:26 --> Router Class Initialized
INFO - 2022-12-16 09:01:26 --> Output Class Initialized
INFO - 2022-12-16 09:01:26 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:26 --> Input Class Initialized
INFO - 2022-12-16 09:01:26 --> Language Class Initialized
INFO - 2022-12-16 09:01:26 --> Language Class Initialized
INFO - 2022-12-16 09:01:26 --> Config Class Initialized
INFO - 2022-12-16 09:01:26 --> Loader Class Initialized
INFO - 2022-12-16 09:01:26 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:26 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:26 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:26 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:26 --> Controller Class Initialized
INFO - 2022-12-16 09:01:28 --> Config Class Initialized
INFO - 2022-12-16 09:01:28 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:28 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:28 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:28 --> URI Class Initialized
INFO - 2022-12-16 09:01:28 --> Router Class Initialized
INFO - 2022-12-16 09:01:28 --> Output Class Initialized
INFO - 2022-12-16 09:01:28 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:28 --> Input Class Initialized
INFO - 2022-12-16 09:01:28 --> Language Class Initialized
INFO - 2022-12-16 09:01:28 --> Language Class Initialized
INFO - 2022-12-16 09:01:28 --> Config Class Initialized
INFO - 2022-12-16 09:01:28 --> Loader Class Initialized
INFO - 2022-12-16 09:01:28 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:28 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:28 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:28 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:28 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:28 --> Controller Class Initialized
DEBUG - 2022-12-16 09:01:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:01:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:01:28 --> Final output sent to browser
DEBUG - 2022-12-16 09:01:28 --> Total execution time: 0.1089
INFO - 2022-12-16 09:01:56 --> Config Class Initialized
INFO - 2022-12-16 09:01:56 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:56 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:56 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:56 --> URI Class Initialized
INFO - 2022-12-16 09:01:56 --> Router Class Initialized
INFO - 2022-12-16 09:01:56 --> Output Class Initialized
INFO - 2022-12-16 09:01:56 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:56 --> Input Class Initialized
INFO - 2022-12-16 09:01:56 --> Language Class Initialized
INFO - 2022-12-16 09:01:56 --> Language Class Initialized
INFO - 2022-12-16 09:01:56 --> Config Class Initialized
INFO - 2022-12-16 09:01:56 --> Loader Class Initialized
INFO - 2022-12-16 09:01:56 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:56 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:56 --> Controller Class Initialized
INFO - 2022-12-16 09:01:56 --> Config Class Initialized
INFO - 2022-12-16 09:01:56 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:56 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:56 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:56 --> URI Class Initialized
INFO - 2022-12-16 09:01:56 --> Router Class Initialized
INFO - 2022-12-16 09:01:56 --> Output Class Initialized
INFO - 2022-12-16 09:01:56 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:56 --> Input Class Initialized
INFO - 2022-12-16 09:01:56 --> Language Class Initialized
INFO - 2022-12-16 09:01:56 --> Language Class Initialized
INFO - 2022-12-16 09:01:56 --> Config Class Initialized
INFO - 2022-12-16 09:01:56 --> Loader Class Initialized
INFO - 2022-12-16 09:01:56 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:56 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:56 --> Controller Class Initialized
DEBUG - 2022-12-16 09:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:01:56 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:01:56 --> Final output sent to browser
DEBUG - 2022-12-16 09:01:56 --> Total execution time: 0.0756
INFO - 2022-12-16 09:01:56 --> Config Class Initialized
INFO - 2022-12-16 09:01:56 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:56 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:56 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:56 --> URI Class Initialized
INFO - 2022-12-16 09:01:56 --> Router Class Initialized
INFO - 2022-12-16 09:01:56 --> Output Class Initialized
INFO - 2022-12-16 09:01:56 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:56 --> Input Class Initialized
INFO - 2022-12-16 09:01:56 --> Language Class Initialized
INFO - 2022-12-16 09:01:56 --> Language Class Initialized
INFO - 2022-12-16 09:01:56 --> Config Class Initialized
INFO - 2022-12-16 09:01:56 --> Loader Class Initialized
INFO - 2022-12-16 09:01:56 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:56 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:56 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:56 --> Controller Class Initialized
INFO - 2022-12-16 09:01:58 --> Config Class Initialized
INFO - 2022-12-16 09:01:58 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:58 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:58 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:58 --> URI Class Initialized
INFO - 2022-12-16 09:01:58 --> Router Class Initialized
INFO - 2022-12-16 09:01:58 --> Output Class Initialized
INFO - 2022-12-16 09:01:58 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:58 --> Input Class Initialized
INFO - 2022-12-16 09:01:58 --> Language Class Initialized
INFO - 2022-12-16 09:01:58 --> Language Class Initialized
INFO - 2022-12-16 09:01:58 --> Config Class Initialized
INFO - 2022-12-16 09:01:58 --> Loader Class Initialized
INFO - 2022-12-16 09:01:58 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:58 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:58 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:58 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:58 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:58 --> Controller Class Initialized
INFO - 2022-12-16 09:01:59 --> Config Class Initialized
INFO - 2022-12-16 09:01:59 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:59 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:59 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:59 --> URI Class Initialized
INFO - 2022-12-16 09:01:59 --> Router Class Initialized
INFO - 2022-12-16 09:01:59 --> Output Class Initialized
INFO - 2022-12-16 09:01:59 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:59 --> Input Class Initialized
INFO - 2022-12-16 09:01:59 --> Language Class Initialized
INFO - 2022-12-16 09:01:59 --> Language Class Initialized
INFO - 2022-12-16 09:01:59 --> Config Class Initialized
INFO - 2022-12-16 09:01:59 --> Loader Class Initialized
INFO - 2022-12-16 09:01:59 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:59 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:59 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:59 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:59 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:59 --> Controller Class Initialized
INFO - 2022-12-16 09:01:59 --> Config Class Initialized
INFO - 2022-12-16 09:01:59 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:01:59 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:01:59 --> Utf8 Class Initialized
INFO - 2022-12-16 09:01:59 --> URI Class Initialized
INFO - 2022-12-16 09:01:59 --> Router Class Initialized
INFO - 2022-12-16 09:01:59 --> Output Class Initialized
INFO - 2022-12-16 09:01:59 --> Security Class Initialized
DEBUG - 2022-12-16 09:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:01:59 --> Input Class Initialized
INFO - 2022-12-16 09:01:59 --> Language Class Initialized
INFO - 2022-12-16 09:01:59 --> Language Class Initialized
INFO - 2022-12-16 09:01:59 --> Config Class Initialized
INFO - 2022-12-16 09:01:59 --> Loader Class Initialized
INFO - 2022-12-16 09:01:59 --> Helper loaded: url_helper
INFO - 2022-12-16 09:01:59 --> Helper loaded: file_helper
INFO - 2022-12-16 09:01:59 --> Helper loaded: form_helper
INFO - 2022-12-16 09:01:59 --> Helper loaded: my_helper
INFO - 2022-12-16 09:01:59 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:01:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:01:59 --> Controller Class Initialized
INFO - 2022-12-16 09:02:10 --> Config Class Initialized
INFO - 2022-12-16 09:02:10 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:02:10 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:02:10 --> Utf8 Class Initialized
INFO - 2022-12-16 09:02:10 --> URI Class Initialized
INFO - 2022-12-16 09:02:10 --> Router Class Initialized
INFO - 2022-12-16 09:02:10 --> Output Class Initialized
INFO - 2022-12-16 09:02:10 --> Security Class Initialized
DEBUG - 2022-12-16 09:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:02:10 --> Input Class Initialized
INFO - 2022-12-16 09:02:10 --> Language Class Initialized
INFO - 2022-12-16 09:02:10 --> Language Class Initialized
INFO - 2022-12-16 09:02:10 --> Config Class Initialized
INFO - 2022-12-16 09:02:10 --> Loader Class Initialized
INFO - 2022-12-16 09:02:10 --> Helper loaded: url_helper
INFO - 2022-12-16 09:02:10 --> Helper loaded: file_helper
INFO - 2022-12-16 09:02:10 --> Helper loaded: form_helper
INFO - 2022-12-16 09:02:10 --> Helper loaded: my_helper
INFO - 2022-12-16 09:02:10 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:02:10 --> Controller Class Initialized
DEBUG - 2022-12-16 09:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:02:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:02:10 --> Final output sent to browser
DEBUG - 2022-12-16 09:02:10 --> Total execution time: 0.0783
INFO - 2022-12-16 09:02:32 --> Config Class Initialized
INFO - 2022-12-16 09:02:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:02:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:02:32 --> Utf8 Class Initialized
INFO - 2022-12-16 09:02:32 --> URI Class Initialized
INFO - 2022-12-16 09:02:32 --> Router Class Initialized
INFO - 2022-12-16 09:02:32 --> Output Class Initialized
INFO - 2022-12-16 09:02:32 --> Security Class Initialized
DEBUG - 2022-12-16 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:02:32 --> Input Class Initialized
INFO - 2022-12-16 09:02:32 --> Language Class Initialized
INFO - 2022-12-16 09:02:32 --> Language Class Initialized
INFO - 2022-12-16 09:02:32 --> Config Class Initialized
INFO - 2022-12-16 09:02:32 --> Loader Class Initialized
INFO - 2022-12-16 09:02:32 --> Helper loaded: url_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: file_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: form_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: my_helper
INFO - 2022-12-16 09:02:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:02:32 --> Controller Class Initialized
INFO - 2022-12-16 09:02:32 --> Config Class Initialized
INFO - 2022-12-16 09:02:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:02:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:02:32 --> Utf8 Class Initialized
INFO - 2022-12-16 09:02:32 --> URI Class Initialized
INFO - 2022-12-16 09:02:32 --> Router Class Initialized
INFO - 2022-12-16 09:02:32 --> Output Class Initialized
INFO - 2022-12-16 09:02:32 --> Security Class Initialized
DEBUG - 2022-12-16 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:02:32 --> Input Class Initialized
INFO - 2022-12-16 09:02:32 --> Language Class Initialized
INFO - 2022-12-16 09:02:32 --> Language Class Initialized
INFO - 2022-12-16 09:02:32 --> Config Class Initialized
INFO - 2022-12-16 09:02:32 --> Loader Class Initialized
INFO - 2022-12-16 09:02:32 --> Helper loaded: url_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: file_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: form_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: my_helper
INFO - 2022-12-16 09:02:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:02:32 --> Controller Class Initialized
DEBUG - 2022-12-16 09:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:02:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:02:32 --> Final output sent to browser
DEBUG - 2022-12-16 09:02:32 --> Total execution time: 0.0650
INFO - 2022-12-16 09:02:32 --> Config Class Initialized
INFO - 2022-12-16 09:02:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:02:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:02:32 --> Utf8 Class Initialized
INFO - 2022-12-16 09:02:32 --> URI Class Initialized
INFO - 2022-12-16 09:02:32 --> Router Class Initialized
INFO - 2022-12-16 09:02:32 --> Output Class Initialized
INFO - 2022-12-16 09:02:32 --> Security Class Initialized
DEBUG - 2022-12-16 09:02:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:02:32 --> Input Class Initialized
INFO - 2022-12-16 09:02:32 --> Language Class Initialized
INFO - 2022-12-16 09:02:32 --> Language Class Initialized
INFO - 2022-12-16 09:02:32 --> Config Class Initialized
INFO - 2022-12-16 09:02:32 --> Loader Class Initialized
INFO - 2022-12-16 09:02:32 --> Helper loaded: url_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: file_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: form_helper
INFO - 2022-12-16 09:02:32 --> Helper loaded: my_helper
INFO - 2022-12-16 09:02:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:02:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:02:32 --> Controller Class Initialized
INFO - 2022-12-16 09:02:35 --> Config Class Initialized
INFO - 2022-12-16 09:02:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:02:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:02:35 --> Utf8 Class Initialized
INFO - 2022-12-16 09:02:35 --> URI Class Initialized
INFO - 2022-12-16 09:02:35 --> Router Class Initialized
INFO - 2022-12-16 09:02:35 --> Output Class Initialized
INFO - 2022-12-16 09:02:35 --> Security Class Initialized
DEBUG - 2022-12-16 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:02:35 --> Input Class Initialized
INFO - 2022-12-16 09:02:35 --> Language Class Initialized
INFO - 2022-12-16 09:02:35 --> Language Class Initialized
INFO - 2022-12-16 09:02:35 --> Config Class Initialized
INFO - 2022-12-16 09:02:35 --> Loader Class Initialized
INFO - 2022-12-16 09:02:35 --> Helper loaded: url_helper
INFO - 2022-12-16 09:02:35 --> Helper loaded: file_helper
INFO - 2022-12-16 09:02:35 --> Helper loaded: form_helper
INFO - 2022-12-16 09:02:35 --> Helper loaded: my_helper
INFO - 2022-12-16 09:02:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:02:35 --> Controller Class Initialized
INFO - 2022-12-16 09:02:35 --> Config Class Initialized
INFO - 2022-12-16 09:02:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:02:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:02:35 --> Utf8 Class Initialized
INFO - 2022-12-16 09:02:35 --> URI Class Initialized
INFO - 2022-12-16 09:02:35 --> Router Class Initialized
INFO - 2022-12-16 09:02:35 --> Output Class Initialized
INFO - 2022-12-16 09:02:35 --> Security Class Initialized
DEBUG - 2022-12-16 09:02:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:02:35 --> Input Class Initialized
INFO - 2022-12-16 09:02:35 --> Language Class Initialized
INFO - 2022-12-16 09:02:35 --> Language Class Initialized
INFO - 2022-12-16 09:02:35 --> Config Class Initialized
INFO - 2022-12-16 09:02:35 --> Loader Class Initialized
INFO - 2022-12-16 09:02:35 --> Helper loaded: url_helper
INFO - 2022-12-16 09:02:35 --> Helper loaded: file_helper
INFO - 2022-12-16 09:02:35 --> Helper loaded: form_helper
INFO - 2022-12-16 09:02:35 --> Helper loaded: my_helper
INFO - 2022-12-16 09:02:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:02:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:02:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:02:35 --> Controller Class Initialized
INFO - 2022-12-16 09:02:36 --> Config Class Initialized
INFO - 2022-12-16 09:02:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:02:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:02:36 --> Utf8 Class Initialized
INFO - 2022-12-16 09:02:36 --> URI Class Initialized
INFO - 2022-12-16 09:02:36 --> Router Class Initialized
INFO - 2022-12-16 09:02:36 --> Output Class Initialized
INFO - 2022-12-16 09:02:36 --> Security Class Initialized
DEBUG - 2022-12-16 09:02:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:02:36 --> Input Class Initialized
INFO - 2022-12-16 09:02:36 --> Language Class Initialized
INFO - 2022-12-16 09:02:36 --> Language Class Initialized
INFO - 2022-12-16 09:02:36 --> Config Class Initialized
INFO - 2022-12-16 09:02:36 --> Loader Class Initialized
INFO - 2022-12-16 09:02:36 --> Helper loaded: url_helper
INFO - 2022-12-16 09:02:36 --> Helper loaded: file_helper
INFO - 2022-12-16 09:02:36 --> Helper loaded: form_helper
INFO - 2022-12-16 09:02:36 --> Helper loaded: my_helper
INFO - 2022-12-16 09:02:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:02:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:02:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:02:36 --> Controller Class Initialized
INFO - 2022-12-16 09:08:37 --> Config Class Initialized
INFO - 2022-12-16 09:08:37 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:08:37 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:08:37 --> Utf8 Class Initialized
INFO - 2022-12-16 09:08:37 --> URI Class Initialized
INFO - 2022-12-16 09:08:37 --> Router Class Initialized
INFO - 2022-12-16 09:08:37 --> Output Class Initialized
INFO - 2022-12-16 09:08:37 --> Security Class Initialized
DEBUG - 2022-12-16 09:08:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:08:37 --> Input Class Initialized
INFO - 2022-12-16 09:08:37 --> Language Class Initialized
INFO - 2022-12-16 09:08:37 --> Language Class Initialized
INFO - 2022-12-16 09:08:37 --> Config Class Initialized
INFO - 2022-12-16 09:08:37 --> Loader Class Initialized
INFO - 2022-12-16 09:08:37 --> Helper loaded: url_helper
INFO - 2022-12-16 09:08:37 --> Helper loaded: file_helper
INFO - 2022-12-16 09:08:37 --> Helper loaded: form_helper
INFO - 2022-12-16 09:08:37 --> Helper loaded: my_helper
INFO - 2022-12-16 09:08:37 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:08:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:08:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:08:37 --> Controller Class Initialized
DEBUG - 2022-12-16 09:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:08:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:08:37 --> Final output sent to browser
DEBUG - 2022-12-16 09:08:37 --> Total execution time: 0.0649
INFO - 2022-12-16 09:10:00 --> Config Class Initialized
INFO - 2022-12-16 09:10:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:10:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:10:00 --> Utf8 Class Initialized
INFO - 2022-12-16 09:10:00 --> URI Class Initialized
INFO - 2022-12-16 09:10:00 --> Router Class Initialized
INFO - 2022-12-16 09:10:00 --> Output Class Initialized
INFO - 2022-12-16 09:10:00 --> Security Class Initialized
DEBUG - 2022-12-16 09:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:10:00 --> Input Class Initialized
INFO - 2022-12-16 09:10:00 --> Language Class Initialized
INFO - 2022-12-16 09:10:00 --> Language Class Initialized
INFO - 2022-12-16 09:10:00 --> Config Class Initialized
INFO - 2022-12-16 09:10:00 --> Loader Class Initialized
INFO - 2022-12-16 09:10:00 --> Helper loaded: url_helper
INFO - 2022-12-16 09:10:00 --> Helper loaded: file_helper
INFO - 2022-12-16 09:10:00 --> Helper loaded: form_helper
INFO - 2022-12-16 09:10:00 --> Helper loaded: my_helper
INFO - 2022-12-16 09:10:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:10:00 --> Controller Class Initialized
INFO - 2022-12-16 09:10:00 --> Config Class Initialized
INFO - 2022-12-16 09:10:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:10:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:10:00 --> Utf8 Class Initialized
INFO - 2022-12-16 09:10:00 --> URI Class Initialized
INFO - 2022-12-16 09:10:00 --> Router Class Initialized
INFO - 2022-12-16 09:10:00 --> Output Class Initialized
INFO - 2022-12-16 09:10:00 --> Security Class Initialized
DEBUG - 2022-12-16 09:10:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:10:00 --> Input Class Initialized
INFO - 2022-12-16 09:10:00 --> Language Class Initialized
INFO - 2022-12-16 09:10:00 --> Language Class Initialized
INFO - 2022-12-16 09:10:00 --> Config Class Initialized
INFO - 2022-12-16 09:10:00 --> Loader Class Initialized
INFO - 2022-12-16 09:10:00 --> Helper loaded: url_helper
INFO - 2022-12-16 09:10:00 --> Helper loaded: file_helper
INFO - 2022-12-16 09:10:00 --> Helper loaded: form_helper
INFO - 2022-12-16 09:10:00 --> Helper loaded: my_helper
INFO - 2022-12-16 09:10:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:10:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:10:00 --> Controller Class Initialized
DEBUG - 2022-12-16 09:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:10:00 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:10:00 --> Final output sent to browser
DEBUG - 2022-12-16 09:10:00 --> Total execution time: 0.0770
INFO - 2022-12-16 09:10:01 --> Config Class Initialized
INFO - 2022-12-16 09:10:01 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:10:01 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:10:01 --> Utf8 Class Initialized
INFO - 2022-12-16 09:10:01 --> URI Class Initialized
INFO - 2022-12-16 09:10:01 --> Router Class Initialized
INFO - 2022-12-16 09:10:01 --> Output Class Initialized
INFO - 2022-12-16 09:10:01 --> Security Class Initialized
DEBUG - 2022-12-16 09:10:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:10:01 --> Input Class Initialized
INFO - 2022-12-16 09:10:01 --> Language Class Initialized
INFO - 2022-12-16 09:10:01 --> Language Class Initialized
INFO - 2022-12-16 09:10:01 --> Config Class Initialized
INFO - 2022-12-16 09:10:01 --> Loader Class Initialized
INFO - 2022-12-16 09:10:01 --> Helper loaded: url_helper
INFO - 2022-12-16 09:10:01 --> Helper loaded: file_helper
INFO - 2022-12-16 09:10:01 --> Helper loaded: form_helper
INFO - 2022-12-16 09:10:01 --> Helper loaded: my_helper
INFO - 2022-12-16 09:10:01 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:10:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:10:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:10:01 --> Controller Class Initialized
INFO - 2022-12-16 09:10:02 --> Config Class Initialized
INFO - 2022-12-16 09:10:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:10:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:10:02 --> Utf8 Class Initialized
INFO - 2022-12-16 09:10:02 --> URI Class Initialized
INFO - 2022-12-16 09:10:02 --> Router Class Initialized
INFO - 2022-12-16 09:10:02 --> Output Class Initialized
INFO - 2022-12-16 09:10:02 --> Security Class Initialized
DEBUG - 2022-12-16 09:10:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:10:02 --> Input Class Initialized
INFO - 2022-12-16 09:10:02 --> Language Class Initialized
INFO - 2022-12-16 09:10:02 --> Language Class Initialized
INFO - 2022-12-16 09:10:02 --> Config Class Initialized
INFO - 2022-12-16 09:10:02 --> Loader Class Initialized
INFO - 2022-12-16 09:10:02 --> Helper loaded: url_helper
INFO - 2022-12-16 09:10:02 --> Helper loaded: file_helper
INFO - 2022-12-16 09:10:02 --> Helper loaded: form_helper
INFO - 2022-12-16 09:10:02 --> Helper loaded: my_helper
INFO - 2022-12-16 09:10:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:10:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:10:02 --> Controller Class Initialized
INFO - 2022-12-16 09:10:03 --> Config Class Initialized
INFO - 2022-12-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:10:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:10:03 --> Utf8 Class Initialized
INFO - 2022-12-16 09:10:03 --> URI Class Initialized
INFO - 2022-12-16 09:10:03 --> Router Class Initialized
INFO - 2022-12-16 09:10:03 --> Output Class Initialized
INFO - 2022-12-16 09:10:03 --> Security Class Initialized
DEBUG - 2022-12-16 09:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:10:03 --> Input Class Initialized
INFO - 2022-12-16 09:10:03 --> Language Class Initialized
INFO - 2022-12-16 09:10:03 --> Language Class Initialized
INFO - 2022-12-16 09:10:03 --> Config Class Initialized
INFO - 2022-12-16 09:10:03 --> Loader Class Initialized
INFO - 2022-12-16 09:10:03 --> Helper loaded: url_helper
INFO - 2022-12-16 09:10:03 --> Helper loaded: file_helper
INFO - 2022-12-16 09:10:03 --> Helper loaded: form_helper
INFO - 2022-12-16 09:10:03 --> Helper loaded: my_helper
INFO - 2022-12-16 09:10:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:10:03 --> Controller Class Initialized
INFO - 2022-12-16 09:10:03 --> Config Class Initialized
INFO - 2022-12-16 09:10:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:10:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:10:03 --> Utf8 Class Initialized
INFO - 2022-12-16 09:10:03 --> URI Class Initialized
INFO - 2022-12-16 09:10:03 --> Router Class Initialized
INFO - 2022-12-16 09:10:03 --> Output Class Initialized
INFO - 2022-12-16 09:10:03 --> Security Class Initialized
DEBUG - 2022-12-16 09:10:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:10:03 --> Input Class Initialized
INFO - 2022-12-16 09:10:03 --> Language Class Initialized
INFO - 2022-12-16 09:10:03 --> Language Class Initialized
INFO - 2022-12-16 09:10:03 --> Config Class Initialized
INFO - 2022-12-16 09:10:03 --> Loader Class Initialized
INFO - 2022-12-16 09:10:03 --> Helper loaded: url_helper
INFO - 2022-12-16 09:10:03 --> Helper loaded: file_helper
INFO - 2022-12-16 09:10:03 --> Helper loaded: form_helper
INFO - 2022-12-16 09:10:03 --> Helper loaded: my_helper
INFO - 2022-12-16 09:10:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:10:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:10:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:10:03 --> Controller Class Initialized
INFO - 2022-12-16 09:10:45 --> Config Class Initialized
INFO - 2022-12-16 09:10:45 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:10:45 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:10:45 --> Utf8 Class Initialized
INFO - 2022-12-16 09:10:45 --> URI Class Initialized
INFO - 2022-12-16 09:10:45 --> Router Class Initialized
INFO - 2022-12-16 09:10:45 --> Output Class Initialized
INFO - 2022-12-16 09:10:45 --> Security Class Initialized
DEBUG - 2022-12-16 09:10:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:10:45 --> Input Class Initialized
INFO - 2022-12-16 09:10:45 --> Language Class Initialized
INFO - 2022-12-16 09:10:45 --> Language Class Initialized
INFO - 2022-12-16 09:10:45 --> Config Class Initialized
INFO - 2022-12-16 09:10:45 --> Loader Class Initialized
INFO - 2022-12-16 09:10:45 --> Helper loaded: url_helper
INFO - 2022-12-16 09:10:45 --> Helper loaded: file_helper
INFO - 2022-12-16 09:10:45 --> Helper loaded: form_helper
INFO - 2022-12-16 09:10:45 --> Helper loaded: my_helper
INFO - 2022-12-16 09:10:45 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:10:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:10:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:10:45 --> Controller Class Initialized
DEBUG - 2022-12-16 09:10:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:10:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:10:45 --> Final output sent to browser
DEBUG - 2022-12-16 09:10:45 --> Total execution time: 0.0668
INFO - 2022-12-16 09:11:08 --> Config Class Initialized
INFO - 2022-12-16 09:11:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:08 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:08 --> URI Class Initialized
INFO - 2022-12-16 09:11:08 --> Router Class Initialized
INFO - 2022-12-16 09:11:08 --> Output Class Initialized
INFO - 2022-12-16 09:11:08 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:08 --> Input Class Initialized
INFO - 2022-12-16 09:11:08 --> Language Class Initialized
INFO - 2022-12-16 09:11:08 --> Language Class Initialized
INFO - 2022-12-16 09:11:08 --> Config Class Initialized
INFO - 2022-12-16 09:11:08 --> Loader Class Initialized
INFO - 2022-12-16 09:11:08 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:08 --> Controller Class Initialized
INFO - 2022-12-16 09:11:08 --> Config Class Initialized
INFO - 2022-12-16 09:11:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:08 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:08 --> URI Class Initialized
INFO - 2022-12-16 09:11:08 --> Router Class Initialized
INFO - 2022-12-16 09:11:08 --> Output Class Initialized
INFO - 2022-12-16 09:11:08 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:08 --> Input Class Initialized
INFO - 2022-12-16 09:11:08 --> Language Class Initialized
INFO - 2022-12-16 09:11:08 --> Language Class Initialized
INFO - 2022-12-16 09:11:08 --> Config Class Initialized
INFO - 2022-12-16 09:11:08 --> Loader Class Initialized
INFO - 2022-12-16 09:11:08 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:08 --> Controller Class Initialized
DEBUG - 2022-12-16 09:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:11:08 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:11:08 --> Final output sent to browser
DEBUG - 2022-12-16 09:11:08 --> Total execution time: 0.0507
INFO - 2022-12-16 09:11:08 --> Config Class Initialized
INFO - 2022-12-16 09:11:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:08 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:08 --> URI Class Initialized
INFO - 2022-12-16 09:11:08 --> Router Class Initialized
INFO - 2022-12-16 09:11:08 --> Output Class Initialized
INFO - 2022-12-16 09:11:08 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:08 --> Input Class Initialized
INFO - 2022-12-16 09:11:08 --> Language Class Initialized
INFO - 2022-12-16 09:11:08 --> Language Class Initialized
INFO - 2022-12-16 09:11:08 --> Config Class Initialized
INFO - 2022-12-16 09:11:08 --> Loader Class Initialized
INFO - 2022-12-16 09:11:08 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:08 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:08 --> Controller Class Initialized
INFO - 2022-12-16 09:11:09 --> Config Class Initialized
INFO - 2022-12-16 09:11:09 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:09 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:09 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:09 --> URI Class Initialized
INFO - 2022-12-16 09:11:09 --> Router Class Initialized
INFO - 2022-12-16 09:11:09 --> Output Class Initialized
INFO - 2022-12-16 09:11:09 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:09 --> Input Class Initialized
INFO - 2022-12-16 09:11:09 --> Language Class Initialized
INFO - 2022-12-16 09:11:09 --> Language Class Initialized
INFO - 2022-12-16 09:11:09 --> Config Class Initialized
INFO - 2022-12-16 09:11:09 --> Loader Class Initialized
INFO - 2022-12-16 09:11:09 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:09 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:09 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:09 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:09 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:09 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:09 --> Controller Class Initialized
DEBUG - 2022-12-16 09:11:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:11:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:11:09 --> Final output sent to browser
DEBUG - 2022-12-16 09:11:09 --> Total execution time: 0.0965
INFO - 2022-12-16 09:11:22 --> Config Class Initialized
INFO - 2022-12-16 09:11:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:22 --> URI Class Initialized
INFO - 2022-12-16 09:11:22 --> Router Class Initialized
INFO - 2022-12-16 09:11:22 --> Output Class Initialized
INFO - 2022-12-16 09:11:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:22 --> Input Class Initialized
INFO - 2022-12-16 09:11:22 --> Language Class Initialized
INFO - 2022-12-16 09:11:22 --> Language Class Initialized
INFO - 2022-12-16 09:11:22 --> Config Class Initialized
INFO - 2022-12-16 09:11:22 --> Loader Class Initialized
INFO - 2022-12-16 09:11:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:22 --> Controller Class Initialized
INFO - 2022-12-16 09:11:22 --> Config Class Initialized
INFO - 2022-12-16 09:11:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:22 --> URI Class Initialized
INFO - 2022-12-16 09:11:22 --> Router Class Initialized
INFO - 2022-12-16 09:11:22 --> Output Class Initialized
INFO - 2022-12-16 09:11:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:22 --> Input Class Initialized
INFO - 2022-12-16 09:11:22 --> Language Class Initialized
INFO - 2022-12-16 09:11:22 --> Language Class Initialized
INFO - 2022-12-16 09:11:22 --> Config Class Initialized
INFO - 2022-12-16 09:11:22 --> Loader Class Initialized
INFO - 2022-12-16 09:11:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:22 --> Controller Class Initialized
DEBUG - 2022-12-16 09:11:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:11:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:11:22 --> Final output sent to browser
DEBUG - 2022-12-16 09:11:22 --> Total execution time: 0.0495
INFO - 2022-12-16 09:11:22 --> Config Class Initialized
INFO - 2022-12-16 09:11:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:22 --> URI Class Initialized
INFO - 2022-12-16 09:11:22 --> Router Class Initialized
INFO - 2022-12-16 09:11:22 --> Output Class Initialized
INFO - 2022-12-16 09:11:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:22 --> Input Class Initialized
INFO - 2022-12-16 09:11:22 --> Language Class Initialized
INFO - 2022-12-16 09:11:22 --> Language Class Initialized
INFO - 2022-12-16 09:11:22 --> Config Class Initialized
INFO - 2022-12-16 09:11:22 --> Loader Class Initialized
INFO - 2022-12-16 09:11:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:22 --> Controller Class Initialized
INFO - 2022-12-16 09:11:25 --> Config Class Initialized
INFO - 2022-12-16 09:11:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:25 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:25 --> URI Class Initialized
INFO - 2022-12-16 09:11:25 --> Router Class Initialized
INFO - 2022-12-16 09:11:25 --> Output Class Initialized
INFO - 2022-12-16 09:11:25 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:25 --> Input Class Initialized
INFO - 2022-12-16 09:11:25 --> Language Class Initialized
INFO - 2022-12-16 09:11:25 --> Language Class Initialized
INFO - 2022-12-16 09:11:25 --> Config Class Initialized
INFO - 2022-12-16 09:11:25 --> Loader Class Initialized
INFO - 2022-12-16 09:11:25 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:25 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:25 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:25 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:25 --> Controller Class Initialized
INFO - 2022-12-16 09:11:25 --> Config Class Initialized
INFO - 2022-12-16 09:11:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:25 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:25 --> URI Class Initialized
INFO - 2022-12-16 09:11:25 --> Router Class Initialized
INFO - 2022-12-16 09:11:25 --> Output Class Initialized
INFO - 2022-12-16 09:11:25 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:25 --> Input Class Initialized
INFO - 2022-12-16 09:11:25 --> Language Class Initialized
INFO - 2022-12-16 09:11:25 --> Language Class Initialized
INFO - 2022-12-16 09:11:25 --> Config Class Initialized
INFO - 2022-12-16 09:11:25 --> Loader Class Initialized
INFO - 2022-12-16 09:11:25 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:25 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:25 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:25 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:25 --> Controller Class Initialized
INFO - 2022-12-16 09:11:33 --> Config Class Initialized
INFO - 2022-12-16 09:11:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:11:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:11:33 --> Utf8 Class Initialized
INFO - 2022-12-16 09:11:33 --> URI Class Initialized
INFO - 2022-12-16 09:11:33 --> Router Class Initialized
INFO - 2022-12-16 09:11:33 --> Output Class Initialized
INFO - 2022-12-16 09:11:33 --> Security Class Initialized
DEBUG - 2022-12-16 09:11:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:11:33 --> Input Class Initialized
INFO - 2022-12-16 09:11:33 --> Language Class Initialized
INFO - 2022-12-16 09:11:33 --> Language Class Initialized
INFO - 2022-12-16 09:11:33 --> Config Class Initialized
INFO - 2022-12-16 09:11:33 --> Loader Class Initialized
INFO - 2022-12-16 09:11:33 --> Helper loaded: url_helper
INFO - 2022-12-16 09:11:33 --> Helper loaded: file_helper
INFO - 2022-12-16 09:11:33 --> Helper loaded: form_helper
INFO - 2022-12-16 09:11:33 --> Helper loaded: my_helper
INFO - 2022-12-16 09:11:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:11:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:11:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:11:33 --> Controller Class Initialized
DEBUG - 2022-12-16 09:11:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:11:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:11:33 --> Final output sent to browser
DEBUG - 2022-12-16 09:11:33 --> Total execution time: 0.0749
INFO - 2022-12-16 09:12:03 --> Config Class Initialized
INFO - 2022-12-16 09:12:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:12:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:12:03 --> Utf8 Class Initialized
INFO - 2022-12-16 09:12:03 --> URI Class Initialized
INFO - 2022-12-16 09:12:03 --> Router Class Initialized
INFO - 2022-12-16 09:12:03 --> Output Class Initialized
INFO - 2022-12-16 09:12:03 --> Security Class Initialized
DEBUG - 2022-12-16 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:12:03 --> Input Class Initialized
INFO - 2022-12-16 09:12:03 --> Language Class Initialized
INFO - 2022-12-16 09:12:03 --> Language Class Initialized
INFO - 2022-12-16 09:12:03 --> Config Class Initialized
INFO - 2022-12-16 09:12:03 --> Loader Class Initialized
INFO - 2022-12-16 09:12:03 --> Helper loaded: url_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: file_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: form_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: my_helper
INFO - 2022-12-16 09:12:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:12:03 --> Controller Class Initialized
INFO - 2022-12-16 09:12:03 --> Config Class Initialized
INFO - 2022-12-16 09:12:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:12:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:12:03 --> Utf8 Class Initialized
INFO - 2022-12-16 09:12:03 --> URI Class Initialized
INFO - 2022-12-16 09:12:03 --> Router Class Initialized
INFO - 2022-12-16 09:12:03 --> Output Class Initialized
INFO - 2022-12-16 09:12:03 --> Security Class Initialized
DEBUG - 2022-12-16 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:12:03 --> Input Class Initialized
INFO - 2022-12-16 09:12:03 --> Language Class Initialized
INFO - 2022-12-16 09:12:03 --> Language Class Initialized
INFO - 2022-12-16 09:12:03 --> Config Class Initialized
INFO - 2022-12-16 09:12:03 --> Loader Class Initialized
INFO - 2022-12-16 09:12:03 --> Helper loaded: url_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: file_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: form_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: my_helper
INFO - 2022-12-16 09:12:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:12:03 --> Controller Class Initialized
DEBUG - 2022-12-16 09:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:12:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:12:03 --> Final output sent to browser
DEBUG - 2022-12-16 09:12:03 --> Total execution time: 0.0599
INFO - 2022-12-16 09:12:03 --> Config Class Initialized
INFO - 2022-12-16 09:12:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:12:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:12:03 --> Utf8 Class Initialized
INFO - 2022-12-16 09:12:03 --> URI Class Initialized
INFO - 2022-12-16 09:12:03 --> Router Class Initialized
INFO - 2022-12-16 09:12:03 --> Output Class Initialized
INFO - 2022-12-16 09:12:03 --> Security Class Initialized
DEBUG - 2022-12-16 09:12:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:12:03 --> Input Class Initialized
INFO - 2022-12-16 09:12:03 --> Language Class Initialized
INFO - 2022-12-16 09:12:03 --> Language Class Initialized
INFO - 2022-12-16 09:12:03 --> Config Class Initialized
INFO - 2022-12-16 09:12:03 --> Loader Class Initialized
INFO - 2022-12-16 09:12:03 --> Helper loaded: url_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: file_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: form_helper
INFO - 2022-12-16 09:12:03 --> Helper loaded: my_helper
INFO - 2022-12-16 09:12:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:12:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:12:03 --> Controller Class Initialized
INFO - 2022-12-16 09:12:11 --> Config Class Initialized
INFO - 2022-12-16 09:12:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:12:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:12:11 --> Utf8 Class Initialized
INFO - 2022-12-16 09:12:11 --> URI Class Initialized
INFO - 2022-12-16 09:12:11 --> Router Class Initialized
INFO - 2022-12-16 09:12:11 --> Output Class Initialized
INFO - 2022-12-16 09:12:11 --> Security Class Initialized
DEBUG - 2022-12-16 09:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:12:11 --> Input Class Initialized
INFO - 2022-12-16 09:12:11 --> Language Class Initialized
INFO - 2022-12-16 09:12:11 --> Language Class Initialized
INFO - 2022-12-16 09:12:11 --> Config Class Initialized
INFO - 2022-12-16 09:12:11 --> Loader Class Initialized
INFO - 2022-12-16 09:12:11 --> Helper loaded: url_helper
INFO - 2022-12-16 09:12:11 --> Helper loaded: file_helper
INFO - 2022-12-16 09:12:11 --> Helper loaded: form_helper
INFO - 2022-12-16 09:12:11 --> Helper loaded: my_helper
INFO - 2022-12-16 09:12:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:12:11 --> Controller Class Initialized
INFO - 2022-12-16 09:12:11 --> Config Class Initialized
INFO - 2022-12-16 09:12:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:12:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:12:11 --> Utf8 Class Initialized
INFO - 2022-12-16 09:12:11 --> URI Class Initialized
INFO - 2022-12-16 09:12:11 --> Router Class Initialized
INFO - 2022-12-16 09:12:11 --> Output Class Initialized
INFO - 2022-12-16 09:12:11 --> Security Class Initialized
DEBUG - 2022-12-16 09:12:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:12:11 --> Input Class Initialized
INFO - 2022-12-16 09:12:11 --> Language Class Initialized
INFO - 2022-12-16 09:12:11 --> Language Class Initialized
INFO - 2022-12-16 09:12:11 --> Config Class Initialized
INFO - 2022-12-16 09:12:11 --> Loader Class Initialized
INFO - 2022-12-16 09:12:11 --> Helper loaded: url_helper
INFO - 2022-12-16 09:12:11 --> Helper loaded: file_helper
INFO - 2022-12-16 09:12:11 --> Helper loaded: form_helper
INFO - 2022-12-16 09:12:11 --> Helper loaded: my_helper
INFO - 2022-12-16 09:12:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:12:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:12:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:12:11 --> Controller Class Initialized
INFO - 2022-12-16 09:12:12 --> Config Class Initialized
INFO - 2022-12-16 09:12:12 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:12:12 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:12:12 --> Utf8 Class Initialized
INFO - 2022-12-16 09:12:12 --> URI Class Initialized
INFO - 2022-12-16 09:12:12 --> Router Class Initialized
INFO - 2022-12-16 09:12:12 --> Output Class Initialized
INFO - 2022-12-16 09:12:12 --> Security Class Initialized
DEBUG - 2022-12-16 09:12:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:12:12 --> Input Class Initialized
INFO - 2022-12-16 09:12:12 --> Language Class Initialized
INFO - 2022-12-16 09:12:12 --> Language Class Initialized
INFO - 2022-12-16 09:12:12 --> Config Class Initialized
INFO - 2022-12-16 09:12:12 --> Loader Class Initialized
INFO - 2022-12-16 09:12:12 --> Helper loaded: url_helper
INFO - 2022-12-16 09:12:12 --> Helper loaded: file_helper
INFO - 2022-12-16 09:12:12 --> Helper loaded: form_helper
INFO - 2022-12-16 09:12:12 --> Helper loaded: my_helper
INFO - 2022-12-16 09:12:12 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:12:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:12:12 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:12:12 --> Controller Class Initialized
INFO - 2022-12-16 09:12:34 --> Config Class Initialized
INFO - 2022-12-16 09:12:34 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:12:34 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:12:34 --> Utf8 Class Initialized
INFO - 2022-12-16 09:12:34 --> URI Class Initialized
INFO - 2022-12-16 09:12:34 --> Router Class Initialized
INFO - 2022-12-16 09:12:34 --> Output Class Initialized
INFO - 2022-12-16 09:12:34 --> Security Class Initialized
DEBUG - 2022-12-16 09:12:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:12:34 --> Input Class Initialized
INFO - 2022-12-16 09:12:34 --> Language Class Initialized
INFO - 2022-12-16 09:12:34 --> Language Class Initialized
INFO - 2022-12-16 09:12:34 --> Config Class Initialized
INFO - 2022-12-16 09:12:34 --> Loader Class Initialized
INFO - 2022-12-16 09:12:34 --> Helper loaded: url_helper
INFO - 2022-12-16 09:12:34 --> Helper loaded: file_helper
INFO - 2022-12-16 09:12:34 --> Helper loaded: form_helper
INFO - 2022-12-16 09:12:34 --> Helper loaded: my_helper
INFO - 2022-12-16 09:12:34 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:12:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:12:34 --> Controller Class Initialized
DEBUG - 2022-12-16 09:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:12:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:12:34 --> Final output sent to browser
DEBUG - 2022-12-16 09:12:34 --> Total execution time: 0.0810
INFO - 2022-12-16 09:13:13 --> Config Class Initialized
INFO - 2022-12-16 09:13:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:13 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:13 --> URI Class Initialized
INFO - 2022-12-16 09:13:13 --> Router Class Initialized
INFO - 2022-12-16 09:13:13 --> Output Class Initialized
INFO - 2022-12-16 09:13:13 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:13 --> Input Class Initialized
INFO - 2022-12-16 09:13:13 --> Language Class Initialized
INFO - 2022-12-16 09:13:13 --> Language Class Initialized
INFO - 2022-12-16 09:13:13 --> Config Class Initialized
INFO - 2022-12-16 09:13:13 --> Loader Class Initialized
INFO - 2022-12-16 09:13:13 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:13 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:13 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:13 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:13 --> Controller Class Initialized
INFO - 2022-12-16 09:13:13 --> Config Class Initialized
INFO - 2022-12-16 09:13:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:13 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:13 --> URI Class Initialized
INFO - 2022-12-16 09:13:13 --> Router Class Initialized
INFO - 2022-12-16 09:13:13 --> Output Class Initialized
INFO - 2022-12-16 09:13:13 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:13 --> Input Class Initialized
INFO - 2022-12-16 09:13:13 --> Language Class Initialized
INFO - 2022-12-16 09:13:13 --> Language Class Initialized
INFO - 2022-12-16 09:13:13 --> Config Class Initialized
INFO - 2022-12-16 09:13:13 --> Loader Class Initialized
INFO - 2022-12-16 09:13:13 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:13 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:13 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:13 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:13 --> Controller Class Initialized
DEBUG - 2022-12-16 09:13:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:13:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:13:13 --> Final output sent to browser
DEBUG - 2022-12-16 09:13:13 --> Total execution time: 0.0573
INFO - 2022-12-16 09:13:14 --> Config Class Initialized
INFO - 2022-12-16 09:13:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:14 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:14 --> URI Class Initialized
INFO - 2022-12-16 09:13:14 --> Router Class Initialized
INFO - 2022-12-16 09:13:14 --> Output Class Initialized
INFO - 2022-12-16 09:13:14 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:14 --> Input Class Initialized
INFO - 2022-12-16 09:13:14 --> Language Class Initialized
INFO - 2022-12-16 09:13:14 --> Language Class Initialized
INFO - 2022-12-16 09:13:14 --> Config Class Initialized
INFO - 2022-12-16 09:13:14 --> Loader Class Initialized
INFO - 2022-12-16 09:13:14 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:14 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:14 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:14 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:14 --> Controller Class Initialized
INFO - 2022-12-16 09:13:15 --> Config Class Initialized
INFO - 2022-12-16 09:13:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:15 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:15 --> URI Class Initialized
INFO - 2022-12-16 09:13:15 --> Router Class Initialized
INFO - 2022-12-16 09:13:15 --> Output Class Initialized
INFO - 2022-12-16 09:13:15 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:15 --> Input Class Initialized
INFO - 2022-12-16 09:13:15 --> Language Class Initialized
INFO - 2022-12-16 09:13:15 --> Language Class Initialized
INFO - 2022-12-16 09:13:15 --> Config Class Initialized
INFO - 2022-12-16 09:13:15 --> Loader Class Initialized
INFO - 2022-12-16 09:13:15 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:15 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:15 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:15 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:15 --> Controller Class Initialized
INFO - 2022-12-16 09:13:16 --> Config Class Initialized
INFO - 2022-12-16 09:13:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:16 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:16 --> URI Class Initialized
INFO - 2022-12-16 09:13:16 --> Router Class Initialized
INFO - 2022-12-16 09:13:16 --> Output Class Initialized
INFO - 2022-12-16 09:13:16 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:16 --> Input Class Initialized
INFO - 2022-12-16 09:13:16 --> Language Class Initialized
INFO - 2022-12-16 09:13:16 --> Language Class Initialized
INFO - 2022-12-16 09:13:16 --> Config Class Initialized
INFO - 2022-12-16 09:13:16 --> Loader Class Initialized
INFO - 2022-12-16 09:13:16 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:16 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:16 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:16 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:16 --> Controller Class Initialized
INFO - 2022-12-16 09:13:31 --> Config Class Initialized
INFO - 2022-12-16 09:13:31 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:31 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:31 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:31 --> URI Class Initialized
INFO - 2022-12-16 09:13:31 --> Router Class Initialized
INFO - 2022-12-16 09:13:31 --> Output Class Initialized
INFO - 2022-12-16 09:13:31 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:31 --> Input Class Initialized
INFO - 2022-12-16 09:13:31 --> Language Class Initialized
INFO - 2022-12-16 09:13:31 --> Language Class Initialized
INFO - 2022-12-16 09:13:31 --> Config Class Initialized
INFO - 2022-12-16 09:13:31 --> Loader Class Initialized
INFO - 2022-12-16 09:13:31 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:31 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:31 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:31 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:31 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:31 --> Controller Class Initialized
INFO - 2022-12-16 09:13:31 --> Config Class Initialized
INFO - 2022-12-16 09:13:31 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:31 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:31 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:31 --> URI Class Initialized
INFO - 2022-12-16 09:13:31 --> Router Class Initialized
INFO - 2022-12-16 09:13:31 --> Output Class Initialized
INFO - 2022-12-16 09:13:32 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:32 --> Input Class Initialized
INFO - 2022-12-16 09:13:32 --> Language Class Initialized
INFO - 2022-12-16 09:13:32 --> Language Class Initialized
INFO - 2022-12-16 09:13:32 --> Config Class Initialized
INFO - 2022-12-16 09:13:32 --> Loader Class Initialized
INFO - 2022-12-16 09:13:32 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:32 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:32 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:32 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:32 --> Controller Class Initialized
INFO - 2022-12-16 09:13:32 --> Config Class Initialized
INFO - 2022-12-16 09:13:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:32 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:32 --> URI Class Initialized
INFO - 2022-12-16 09:13:32 --> Router Class Initialized
INFO - 2022-12-16 09:13:32 --> Output Class Initialized
INFO - 2022-12-16 09:13:32 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:32 --> Input Class Initialized
INFO - 2022-12-16 09:13:32 --> Language Class Initialized
INFO - 2022-12-16 09:13:32 --> Language Class Initialized
INFO - 2022-12-16 09:13:32 --> Config Class Initialized
INFO - 2022-12-16 09:13:32 --> Loader Class Initialized
INFO - 2022-12-16 09:13:32 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:32 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:32 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:32 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:32 --> Controller Class Initialized
INFO - 2022-12-16 09:13:41 --> Config Class Initialized
INFO - 2022-12-16 09:13:41 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:13:41 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:13:41 --> Utf8 Class Initialized
INFO - 2022-12-16 09:13:41 --> URI Class Initialized
INFO - 2022-12-16 09:13:41 --> Router Class Initialized
INFO - 2022-12-16 09:13:41 --> Output Class Initialized
INFO - 2022-12-16 09:13:41 --> Security Class Initialized
DEBUG - 2022-12-16 09:13:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:13:41 --> Input Class Initialized
INFO - 2022-12-16 09:13:41 --> Language Class Initialized
INFO - 2022-12-16 09:13:41 --> Language Class Initialized
INFO - 2022-12-16 09:13:41 --> Config Class Initialized
INFO - 2022-12-16 09:13:41 --> Loader Class Initialized
INFO - 2022-12-16 09:13:41 --> Helper loaded: url_helper
INFO - 2022-12-16 09:13:41 --> Helper loaded: file_helper
INFO - 2022-12-16 09:13:41 --> Helper loaded: form_helper
INFO - 2022-12-16 09:13:41 --> Helper loaded: my_helper
INFO - 2022-12-16 09:13:41 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:13:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:13:41 --> Controller Class Initialized
DEBUG - 2022-12-16 09:13:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:13:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:13:41 --> Final output sent to browser
DEBUG - 2022-12-16 09:13:41 --> Total execution time: 0.0708
INFO - 2022-12-16 09:14:06 --> Config Class Initialized
INFO - 2022-12-16 09:14:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:14:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:14:06 --> Utf8 Class Initialized
INFO - 2022-12-16 09:14:06 --> URI Class Initialized
INFO - 2022-12-16 09:14:06 --> Router Class Initialized
INFO - 2022-12-16 09:14:06 --> Output Class Initialized
INFO - 2022-12-16 09:14:06 --> Security Class Initialized
DEBUG - 2022-12-16 09:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:14:06 --> Input Class Initialized
INFO - 2022-12-16 09:14:06 --> Language Class Initialized
INFO - 2022-12-16 09:14:06 --> Language Class Initialized
INFO - 2022-12-16 09:14:06 --> Config Class Initialized
INFO - 2022-12-16 09:14:06 --> Loader Class Initialized
INFO - 2022-12-16 09:14:06 --> Helper loaded: url_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: file_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: form_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: my_helper
INFO - 2022-12-16 09:14:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:14:06 --> Controller Class Initialized
INFO - 2022-12-16 09:14:06 --> Config Class Initialized
INFO - 2022-12-16 09:14:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:14:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:14:06 --> Utf8 Class Initialized
INFO - 2022-12-16 09:14:06 --> URI Class Initialized
INFO - 2022-12-16 09:14:06 --> Router Class Initialized
INFO - 2022-12-16 09:14:06 --> Output Class Initialized
INFO - 2022-12-16 09:14:06 --> Security Class Initialized
DEBUG - 2022-12-16 09:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:14:06 --> Input Class Initialized
INFO - 2022-12-16 09:14:06 --> Language Class Initialized
INFO - 2022-12-16 09:14:06 --> Language Class Initialized
INFO - 2022-12-16 09:14:06 --> Config Class Initialized
INFO - 2022-12-16 09:14:06 --> Loader Class Initialized
INFO - 2022-12-16 09:14:06 --> Helper loaded: url_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: file_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: form_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: my_helper
INFO - 2022-12-16 09:14:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:14:06 --> Controller Class Initialized
DEBUG - 2022-12-16 09:14:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:14:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:14:06 --> Final output sent to browser
DEBUG - 2022-12-16 09:14:06 --> Total execution time: 0.0847
INFO - 2022-12-16 09:14:06 --> Config Class Initialized
INFO - 2022-12-16 09:14:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:14:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:14:06 --> Utf8 Class Initialized
INFO - 2022-12-16 09:14:06 --> URI Class Initialized
INFO - 2022-12-16 09:14:06 --> Router Class Initialized
INFO - 2022-12-16 09:14:06 --> Output Class Initialized
INFO - 2022-12-16 09:14:06 --> Security Class Initialized
DEBUG - 2022-12-16 09:14:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:14:06 --> Input Class Initialized
INFO - 2022-12-16 09:14:06 --> Language Class Initialized
INFO - 2022-12-16 09:14:06 --> Language Class Initialized
INFO - 2022-12-16 09:14:06 --> Config Class Initialized
INFO - 2022-12-16 09:14:06 --> Loader Class Initialized
INFO - 2022-12-16 09:14:06 --> Helper loaded: url_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: file_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: form_helper
INFO - 2022-12-16 09:14:06 --> Helper loaded: my_helper
INFO - 2022-12-16 09:14:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:14:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:14:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:14:06 --> Controller Class Initialized
INFO - 2022-12-16 09:14:19 --> Config Class Initialized
INFO - 2022-12-16 09:14:19 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:14:19 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:14:19 --> Utf8 Class Initialized
INFO - 2022-12-16 09:14:19 --> URI Class Initialized
INFO - 2022-12-16 09:14:19 --> Router Class Initialized
INFO - 2022-12-16 09:14:19 --> Output Class Initialized
INFO - 2022-12-16 09:14:19 --> Security Class Initialized
DEBUG - 2022-12-16 09:14:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:14:19 --> Input Class Initialized
INFO - 2022-12-16 09:14:19 --> Language Class Initialized
INFO - 2022-12-16 09:14:19 --> Language Class Initialized
INFO - 2022-12-16 09:14:19 --> Config Class Initialized
INFO - 2022-12-16 09:14:19 --> Loader Class Initialized
INFO - 2022-12-16 09:14:19 --> Helper loaded: url_helper
INFO - 2022-12-16 09:14:19 --> Helper loaded: file_helper
INFO - 2022-12-16 09:14:19 --> Helper loaded: form_helper
INFO - 2022-12-16 09:14:19 --> Helper loaded: my_helper
INFO - 2022-12-16 09:14:19 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:14:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:14:19 --> Controller Class Initialized
DEBUG - 2022-12-16 09:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:14:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:14:19 --> Final output sent to browser
DEBUG - 2022-12-16 09:14:19 --> Total execution time: 0.0681
INFO - 2022-12-16 09:15:17 --> Config Class Initialized
INFO - 2022-12-16 09:15:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:17 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:17 --> URI Class Initialized
INFO - 2022-12-16 09:15:17 --> Router Class Initialized
INFO - 2022-12-16 09:15:17 --> Output Class Initialized
INFO - 2022-12-16 09:15:17 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:17 --> Input Class Initialized
INFO - 2022-12-16 09:15:17 --> Language Class Initialized
INFO - 2022-12-16 09:15:17 --> Language Class Initialized
INFO - 2022-12-16 09:15:17 --> Config Class Initialized
INFO - 2022-12-16 09:15:17 --> Loader Class Initialized
INFO - 2022-12-16 09:15:17 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:17 --> Controller Class Initialized
INFO - 2022-12-16 09:15:17 --> Config Class Initialized
INFO - 2022-12-16 09:15:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:17 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:17 --> URI Class Initialized
INFO - 2022-12-16 09:15:17 --> Router Class Initialized
INFO - 2022-12-16 09:15:17 --> Output Class Initialized
INFO - 2022-12-16 09:15:17 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:17 --> Input Class Initialized
INFO - 2022-12-16 09:15:17 --> Language Class Initialized
INFO - 2022-12-16 09:15:17 --> Language Class Initialized
INFO - 2022-12-16 09:15:17 --> Config Class Initialized
INFO - 2022-12-16 09:15:17 --> Loader Class Initialized
INFO - 2022-12-16 09:15:17 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:17 --> Controller Class Initialized
DEBUG - 2022-12-16 09:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:15:17 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:15:17 --> Final output sent to browser
DEBUG - 2022-12-16 09:15:17 --> Total execution time: 0.0807
INFO - 2022-12-16 09:15:17 --> Config Class Initialized
INFO - 2022-12-16 09:15:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:17 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:17 --> URI Class Initialized
INFO - 2022-12-16 09:15:17 --> Router Class Initialized
INFO - 2022-12-16 09:15:17 --> Output Class Initialized
INFO - 2022-12-16 09:15:17 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:17 --> Input Class Initialized
INFO - 2022-12-16 09:15:17 --> Language Class Initialized
INFO - 2022-12-16 09:15:17 --> Language Class Initialized
INFO - 2022-12-16 09:15:17 --> Config Class Initialized
INFO - 2022-12-16 09:15:17 --> Loader Class Initialized
INFO - 2022-12-16 09:15:17 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:17 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:17 --> Controller Class Initialized
INFO - 2022-12-16 09:15:19 --> Config Class Initialized
INFO - 2022-12-16 09:15:19 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:19 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:19 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:19 --> URI Class Initialized
INFO - 2022-12-16 09:15:19 --> Router Class Initialized
INFO - 2022-12-16 09:15:19 --> Output Class Initialized
INFO - 2022-12-16 09:15:19 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:19 --> Input Class Initialized
INFO - 2022-12-16 09:15:19 --> Language Class Initialized
INFO - 2022-12-16 09:15:19 --> Language Class Initialized
INFO - 2022-12-16 09:15:19 --> Config Class Initialized
INFO - 2022-12-16 09:15:19 --> Loader Class Initialized
INFO - 2022-12-16 09:15:19 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:19 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:19 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:19 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:19 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:19 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:19 --> Controller Class Initialized
INFO - 2022-12-16 09:15:20 --> Config Class Initialized
INFO - 2022-12-16 09:15:20 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:20 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:20 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:20 --> URI Class Initialized
INFO - 2022-12-16 09:15:20 --> Router Class Initialized
INFO - 2022-12-16 09:15:20 --> Output Class Initialized
INFO - 2022-12-16 09:15:20 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:20 --> Input Class Initialized
INFO - 2022-12-16 09:15:20 --> Language Class Initialized
INFO - 2022-12-16 09:15:20 --> Language Class Initialized
INFO - 2022-12-16 09:15:20 --> Config Class Initialized
INFO - 2022-12-16 09:15:20 --> Loader Class Initialized
INFO - 2022-12-16 09:15:20 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:20 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:20 --> Controller Class Initialized
INFO - 2022-12-16 09:15:20 --> Config Class Initialized
INFO - 2022-12-16 09:15:20 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:20 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:20 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:20 --> URI Class Initialized
INFO - 2022-12-16 09:15:20 --> Router Class Initialized
INFO - 2022-12-16 09:15:20 --> Output Class Initialized
INFO - 2022-12-16 09:15:20 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:20 --> Input Class Initialized
INFO - 2022-12-16 09:15:20 --> Language Class Initialized
INFO - 2022-12-16 09:15:20 --> Language Class Initialized
INFO - 2022-12-16 09:15:20 --> Config Class Initialized
INFO - 2022-12-16 09:15:20 --> Loader Class Initialized
INFO - 2022-12-16 09:15:20 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:20 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:20 --> Controller Class Initialized
INFO - 2022-12-16 09:15:20 --> Config Class Initialized
INFO - 2022-12-16 09:15:20 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:20 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:20 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:20 --> URI Class Initialized
INFO - 2022-12-16 09:15:20 --> Router Class Initialized
INFO - 2022-12-16 09:15:20 --> Output Class Initialized
INFO - 2022-12-16 09:15:20 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:20 --> Input Class Initialized
INFO - 2022-12-16 09:15:20 --> Language Class Initialized
INFO - 2022-12-16 09:15:20 --> Language Class Initialized
INFO - 2022-12-16 09:15:20 --> Config Class Initialized
INFO - 2022-12-16 09:15:20 --> Loader Class Initialized
INFO - 2022-12-16 09:15:20 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:20 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:20 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:20 --> Controller Class Initialized
INFO - 2022-12-16 09:15:22 --> Config Class Initialized
INFO - 2022-12-16 09:15:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:22 --> URI Class Initialized
INFO - 2022-12-16 09:15:22 --> Router Class Initialized
INFO - 2022-12-16 09:15:22 --> Output Class Initialized
INFO - 2022-12-16 09:15:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:22 --> Input Class Initialized
INFO - 2022-12-16 09:15:22 --> Language Class Initialized
INFO - 2022-12-16 09:15:22 --> Language Class Initialized
INFO - 2022-12-16 09:15:22 --> Config Class Initialized
INFO - 2022-12-16 09:15:22 --> Loader Class Initialized
INFO - 2022-12-16 09:15:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:22 --> Controller Class Initialized
INFO - 2022-12-16 09:15:41 --> Config Class Initialized
INFO - 2022-12-16 09:15:41 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:15:41 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:15:41 --> Utf8 Class Initialized
INFO - 2022-12-16 09:15:41 --> URI Class Initialized
INFO - 2022-12-16 09:15:41 --> Router Class Initialized
INFO - 2022-12-16 09:15:41 --> Output Class Initialized
INFO - 2022-12-16 09:15:41 --> Security Class Initialized
DEBUG - 2022-12-16 09:15:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:15:41 --> Input Class Initialized
INFO - 2022-12-16 09:15:41 --> Language Class Initialized
INFO - 2022-12-16 09:15:41 --> Language Class Initialized
INFO - 2022-12-16 09:15:41 --> Config Class Initialized
INFO - 2022-12-16 09:15:41 --> Loader Class Initialized
INFO - 2022-12-16 09:15:41 --> Helper loaded: url_helper
INFO - 2022-12-16 09:15:41 --> Helper loaded: file_helper
INFO - 2022-12-16 09:15:41 --> Helper loaded: form_helper
INFO - 2022-12-16 09:15:41 --> Helper loaded: my_helper
INFO - 2022-12-16 09:15:41 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:15:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:15:41 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:15:41 --> Controller Class Initialized
DEBUG - 2022-12-16 09:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:15:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:15:41 --> Final output sent to browser
DEBUG - 2022-12-16 09:15:41 --> Total execution time: 0.0717
INFO - 2022-12-16 09:16:06 --> Config Class Initialized
INFO - 2022-12-16 09:16:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:06 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:06 --> URI Class Initialized
INFO - 2022-12-16 09:16:06 --> Router Class Initialized
INFO - 2022-12-16 09:16:06 --> Output Class Initialized
INFO - 2022-12-16 09:16:06 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:06 --> Input Class Initialized
INFO - 2022-12-16 09:16:06 --> Language Class Initialized
INFO - 2022-12-16 09:16:06 --> Language Class Initialized
INFO - 2022-12-16 09:16:06 --> Config Class Initialized
INFO - 2022-12-16 09:16:06 --> Loader Class Initialized
INFO - 2022-12-16 09:16:06 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:06 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:06 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:06 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:06 --> Controller Class Initialized
INFO - 2022-12-16 09:16:06 --> Config Class Initialized
INFO - 2022-12-16 09:16:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:06 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:06 --> URI Class Initialized
INFO - 2022-12-16 09:16:06 --> Router Class Initialized
INFO - 2022-12-16 09:16:06 --> Output Class Initialized
INFO - 2022-12-16 09:16:06 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:06 --> Input Class Initialized
INFO - 2022-12-16 09:16:06 --> Language Class Initialized
INFO - 2022-12-16 09:16:06 --> Language Class Initialized
INFO - 2022-12-16 09:16:06 --> Config Class Initialized
INFO - 2022-12-16 09:16:06 --> Loader Class Initialized
INFO - 2022-12-16 09:16:06 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:06 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:06 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:06 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:06 --> Controller Class Initialized
DEBUG - 2022-12-16 09:16:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:16:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:16:06 --> Final output sent to browser
DEBUG - 2022-12-16 09:16:06 --> Total execution time: 0.0740
INFO - 2022-12-16 09:16:07 --> Config Class Initialized
INFO - 2022-12-16 09:16:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:07 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:07 --> URI Class Initialized
INFO - 2022-12-16 09:16:07 --> Router Class Initialized
INFO - 2022-12-16 09:16:07 --> Output Class Initialized
INFO - 2022-12-16 09:16:07 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:07 --> Input Class Initialized
INFO - 2022-12-16 09:16:07 --> Language Class Initialized
INFO - 2022-12-16 09:16:07 --> Language Class Initialized
INFO - 2022-12-16 09:16:07 --> Config Class Initialized
INFO - 2022-12-16 09:16:07 --> Loader Class Initialized
INFO - 2022-12-16 09:16:07 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:07 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:07 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:07 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:07 --> Controller Class Initialized
INFO - 2022-12-16 09:16:07 --> Config Class Initialized
INFO - 2022-12-16 09:16:07 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:07 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:07 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:07 --> URI Class Initialized
INFO - 2022-12-16 09:16:07 --> Router Class Initialized
INFO - 2022-12-16 09:16:07 --> Output Class Initialized
INFO - 2022-12-16 09:16:07 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:07 --> Input Class Initialized
INFO - 2022-12-16 09:16:07 --> Language Class Initialized
INFO - 2022-12-16 09:16:07 --> Language Class Initialized
INFO - 2022-12-16 09:16:07 --> Config Class Initialized
INFO - 2022-12-16 09:16:07 --> Loader Class Initialized
INFO - 2022-12-16 09:16:07 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:07 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:07 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:07 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:07 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:07 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:07 --> Controller Class Initialized
DEBUG - 2022-12-16 09:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:16:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:16:07 --> Final output sent to browser
DEBUG - 2022-12-16 09:16:07 --> Total execution time: 0.0914
INFO - 2022-12-16 09:16:29 --> Config Class Initialized
INFO - 2022-12-16 09:16:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:29 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:29 --> URI Class Initialized
INFO - 2022-12-16 09:16:29 --> Router Class Initialized
INFO - 2022-12-16 09:16:29 --> Output Class Initialized
INFO - 2022-12-16 09:16:29 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:29 --> Input Class Initialized
INFO - 2022-12-16 09:16:29 --> Language Class Initialized
INFO - 2022-12-16 09:16:29 --> Language Class Initialized
INFO - 2022-12-16 09:16:29 --> Config Class Initialized
INFO - 2022-12-16 09:16:29 --> Loader Class Initialized
INFO - 2022-12-16 09:16:29 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:29 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:29 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:29 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:29 --> Controller Class Initialized
INFO - 2022-12-16 09:16:29 --> Config Class Initialized
INFO - 2022-12-16 09:16:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:29 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:29 --> URI Class Initialized
INFO - 2022-12-16 09:16:29 --> Router Class Initialized
INFO - 2022-12-16 09:16:29 --> Output Class Initialized
INFO - 2022-12-16 09:16:29 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:29 --> Input Class Initialized
INFO - 2022-12-16 09:16:29 --> Language Class Initialized
INFO - 2022-12-16 09:16:29 --> Language Class Initialized
INFO - 2022-12-16 09:16:29 --> Config Class Initialized
INFO - 2022-12-16 09:16:29 --> Loader Class Initialized
INFO - 2022-12-16 09:16:29 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:29 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:29 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:29 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:29 --> Controller Class Initialized
DEBUG - 2022-12-16 09:16:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:16:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:16:29 --> Final output sent to browser
DEBUG - 2022-12-16 09:16:29 --> Total execution time: 0.0586
INFO - 2022-12-16 09:16:30 --> Config Class Initialized
INFO - 2022-12-16 09:16:30 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:30 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:30 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:30 --> URI Class Initialized
INFO - 2022-12-16 09:16:30 --> Router Class Initialized
INFO - 2022-12-16 09:16:30 --> Output Class Initialized
INFO - 2022-12-16 09:16:30 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:30 --> Input Class Initialized
INFO - 2022-12-16 09:16:30 --> Language Class Initialized
INFO - 2022-12-16 09:16:30 --> Language Class Initialized
INFO - 2022-12-16 09:16:30 --> Config Class Initialized
INFO - 2022-12-16 09:16:30 --> Loader Class Initialized
INFO - 2022-12-16 09:16:30 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:30 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:30 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:30 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:30 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:30 --> Controller Class Initialized
INFO - 2022-12-16 09:16:48 --> Config Class Initialized
INFO - 2022-12-16 09:16:48 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:48 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:48 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:48 --> URI Class Initialized
INFO - 2022-12-16 09:16:48 --> Router Class Initialized
INFO - 2022-12-16 09:16:48 --> Output Class Initialized
INFO - 2022-12-16 09:16:48 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:48 --> Input Class Initialized
INFO - 2022-12-16 09:16:48 --> Language Class Initialized
INFO - 2022-12-16 09:16:48 --> Language Class Initialized
INFO - 2022-12-16 09:16:48 --> Config Class Initialized
INFO - 2022-12-16 09:16:48 --> Loader Class Initialized
INFO - 2022-12-16 09:16:48 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:48 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:48 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:48 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:48 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:48 --> Controller Class Initialized
INFO - 2022-12-16 09:16:48 --> Config Class Initialized
INFO - 2022-12-16 09:16:48 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:48 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:48 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:48 --> URI Class Initialized
INFO - 2022-12-16 09:16:48 --> Router Class Initialized
INFO - 2022-12-16 09:16:48 --> Output Class Initialized
INFO - 2022-12-16 09:16:48 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:48 --> Input Class Initialized
INFO - 2022-12-16 09:16:48 --> Language Class Initialized
INFO - 2022-12-16 09:16:48 --> Language Class Initialized
INFO - 2022-12-16 09:16:48 --> Config Class Initialized
INFO - 2022-12-16 09:16:48 --> Loader Class Initialized
INFO - 2022-12-16 09:16:48 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:48 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:48 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:48 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:48 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:48 --> Controller Class Initialized
INFO - 2022-12-16 09:16:49 --> Config Class Initialized
INFO - 2022-12-16 09:16:49 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:49 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:49 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:49 --> URI Class Initialized
INFO - 2022-12-16 09:16:49 --> Router Class Initialized
INFO - 2022-12-16 09:16:49 --> Output Class Initialized
INFO - 2022-12-16 09:16:49 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:49 --> Input Class Initialized
INFO - 2022-12-16 09:16:49 --> Language Class Initialized
INFO - 2022-12-16 09:16:49 --> Language Class Initialized
INFO - 2022-12-16 09:16:49 --> Config Class Initialized
INFO - 2022-12-16 09:16:49 --> Loader Class Initialized
INFO - 2022-12-16 09:16:49 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:49 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:49 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:49 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:49 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:49 --> Controller Class Initialized
INFO - 2022-12-16 09:16:49 --> Config Class Initialized
INFO - 2022-12-16 09:16:49 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:49 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:49 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:49 --> URI Class Initialized
INFO - 2022-12-16 09:16:49 --> Router Class Initialized
INFO - 2022-12-16 09:16:49 --> Output Class Initialized
INFO - 2022-12-16 09:16:49 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:49 --> Input Class Initialized
INFO - 2022-12-16 09:16:49 --> Language Class Initialized
INFO - 2022-12-16 09:16:49 --> Language Class Initialized
INFO - 2022-12-16 09:16:49 --> Config Class Initialized
INFO - 2022-12-16 09:16:49 --> Loader Class Initialized
INFO - 2022-12-16 09:16:49 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:49 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:49 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:49 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:49 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:49 --> Controller Class Initialized
INFO - 2022-12-16 09:16:50 --> Config Class Initialized
INFO - 2022-12-16 09:16:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:50 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:50 --> URI Class Initialized
INFO - 2022-12-16 09:16:50 --> Router Class Initialized
INFO - 2022-12-16 09:16:50 --> Output Class Initialized
INFO - 2022-12-16 09:16:50 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:50 --> Input Class Initialized
INFO - 2022-12-16 09:16:50 --> Language Class Initialized
INFO - 2022-12-16 09:16:50 --> Language Class Initialized
INFO - 2022-12-16 09:16:50 --> Config Class Initialized
INFO - 2022-12-16 09:16:50 --> Loader Class Initialized
INFO - 2022-12-16 09:16:50 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:50 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:50 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:50 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:50 --> Controller Class Initialized
INFO - 2022-12-16 09:16:51 --> Config Class Initialized
INFO - 2022-12-16 09:16:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:51 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:51 --> URI Class Initialized
INFO - 2022-12-16 09:16:51 --> Router Class Initialized
INFO - 2022-12-16 09:16:51 --> Output Class Initialized
INFO - 2022-12-16 09:16:51 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:51 --> Input Class Initialized
INFO - 2022-12-16 09:16:51 --> Language Class Initialized
INFO - 2022-12-16 09:16:51 --> Language Class Initialized
INFO - 2022-12-16 09:16:51 --> Config Class Initialized
INFO - 2022-12-16 09:16:51 --> Loader Class Initialized
INFO - 2022-12-16 09:16:51 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:51 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:51 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:51 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:51 --> Controller Class Initialized
INFO - 2022-12-16 09:16:51 --> Config Class Initialized
INFO - 2022-12-16 09:16:51 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:51 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:51 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:51 --> URI Class Initialized
INFO - 2022-12-16 09:16:51 --> Router Class Initialized
INFO - 2022-12-16 09:16:51 --> Output Class Initialized
INFO - 2022-12-16 09:16:51 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:51 --> Input Class Initialized
INFO - 2022-12-16 09:16:51 --> Language Class Initialized
INFO - 2022-12-16 09:16:51 --> Language Class Initialized
INFO - 2022-12-16 09:16:51 --> Config Class Initialized
INFO - 2022-12-16 09:16:51 --> Loader Class Initialized
INFO - 2022-12-16 09:16:51 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:51 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:51 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:51 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:51 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:51 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:51 --> Controller Class Initialized
INFO - 2022-12-16 09:16:52 --> Config Class Initialized
INFO - 2022-12-16 09:16:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:52 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:52 --> URI Class Initialized
INFO - 2022-12-16 09:16:52 --> Router Class Initialized
INFO - 2022-12-16 09:16:52 --> Output Class Initialized
INFO - 2022-12-16 09:16:52 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:52 --> Input Class Initialized
INFO - 2022-12-16 09:16:52 --> Language Class Initialized
INFO - 2022-12-16 09:16:52 --> Language Class Initialized
INFO - 2022-12-16 09:16:52 --> Config Class Initialized
INFO - 2022-12-16 09:16:52 --> Loader Class Initialized
INFO - 2022-12-16 09:16:52 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:52 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:52 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:52 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:52 --> Controller Class Initialized
INFO - 2022-12-16 09:16:53 --> Config Class Initialized
INFO - 2022-12-16 09:16:53 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:53 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:53 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:53 --> URI Class Initialized
INFO - 2022-12-16 09:16:53 --> Router Class Initialized
INFO - 2022-12-16 09:16:53 --> Output Class Initialized
INFO - 2022-12-16 09:16:53 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:53 --> Input Class Initialized
INFO - 2022-12-16 09:16:53 --> Language Class Initialized
INFO - 2022-12-16 09:16:53 --> Language Class Initialized
INFO - 2022-12-16 09:16:53 --> Config Class Initialized
INFO - 2022-12-16 09:16:53 --> Loader Class Initialized
INFO - 2022-12-16 09:16:53 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:53 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:53 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:53 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:53 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:53 --> Controller Class Initialized
INFO - 2022-12-16 09:16:53 --> Config Class Initialized
INFO - 2022-12-16 09:16:53 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:16:53 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:16:53 --> Utf8 Class Initialized
INFO - 2022-12-16 09:16:53 --> URI Class Initialized
INFO - 2022-12-16 09:16:53 --> Router Class Initialized
INFO - 2022-12-16 09:16:53 --> Output Class Initialized
INFO - 2022-12-16 09:16:53 --> Security Class Initialized
DEBUG - 2022-12-16 09:16:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:16:53 --> Input Class Initialized
INFO - 2022-12-16 09:16:53 --> Language Class Initialized
INFO - 2022-12-16 09:16:53 --> Language Class Initialized
INFO - 2022-12-16 09:16:53 --> Config Class Initialized
INFO - 2022-12-16 09:16:53 --> Loader Class Initialized
INFO - 2022-12-16 09:16:53 --> Helper loaded: url_helper
INFO - 2022-12-16 09:16:53 --> Helper loaded: file_helper
INFO - 2022-12-16 09:16:53 --> Helper loaded: form_helper
INFO - 2022-12-16 09:16:53 --> Helper loaded: my_helper
INFO - 2022-12-16 09:16:53 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:16:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:16:53 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:16:53 --> Controller Class Initialized
INFO - 2022-12-16 09:17:16 --> Config Class Initialized
INFO - 2022-12-16 09:17:16 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:16 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:16 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:16 --> URI Class Initialized
INFO - 2022-12-16 09:17:16 --> Router Class Initialized
INFO - 2022-12-16 09:17:16 --> Output Class Initialized
INFO - 2022-12-16 09:17:16 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:16 --> Input Class Initialized
INFO - 2022-12-16 09:17:16 --> Language Class Initialized
INFO - 2022-12-16 09:17:16 --> Language Class Initialized
INFO - 2022-12-16 09:17:16 --> Config Class Initialized
INFO - 2022-12-16 09:17:16 --> Loader Class Initialized
INFO - 2022-12-16 09:17:16 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:16 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:16 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:16 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:16 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:16 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:16 --> Controller Class Initialized
DEBUG - 2022-12-16 09:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:17:16 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:17:16 --> Final output sent to browser
DEBUG - 2022-12-16 09:17:16 --> Total execution time: 0.0827
INFO - 2022-12-16 09:17:31 --> Config Class Initialized
INFO - 2022-12-16 09:17:31 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:31 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:31 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:31 --> URI Class Initialized
INFO - 2022-12-16 09:17:31 --> Router Class Initialized
INFO - 2022-12-16 09:17:31 --> Output Class Initialized
INFO - 2022-12-16 09:17:31 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:31 --> Input Class Initialized
INFO - 2022-12-16 09:17:31 --> Language Class Initialized
INFO - 2022-12-16 09:17:31 --> Language Class Initialized
INFO - 2022-12-16 09:17:31 --> Config Class Initialized
INFO - 2022-12-16 09:17:31 --> Loader Class Initialized
INFO - 2022-12-16 09:17:31 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:31 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:31 --> Controller Class Initialized
INFO - 2022-12-16 09:17:31 --> Config Class Initialized
INFO - 2022-12-16 09:17:31 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:31 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:31 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:31 --> URI Class Initialized
INFO - 2022-12-16 09:17:31 --> Router Class Initialized
INFO - 2022-12-16 09:17:31 --> Output Class Initialized
INFO - 2022-12-16 09:17:31 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:31 --> Input Class Initialized
INFO - 2022-12-16 09:17:31 --> Language Class Initialized
INFO - 2022-12-16 09:17:31 --> Language Class Initialized
INFO - 2022-12-16 09:17:31 --> Config Class Initialized
INFO - 2022-12-16 09:17:31 --> Loader Class Initialized
INFO - 2022-12-16 09:17:31 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:31 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:31 --> Controller Class Initialized
DEBUG - 2022-12-16 09:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:17:31 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:17:31 --> Final output sent to browser
DEBUG - 2022-12-16 09:17:31 --> Total execution time: 0.0625
INFO - 2022-12-16 09:17:31 --> Config Class Initialized
INFO - 2022-12-16 09:17:31 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:31 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:31 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:31 --> URI Class Initialized
INFO - 2022-12-16 09:17:31 --> Router Class Initialized
INFO - 2022-12-16 09:17:31 --> Output Class Initialized
INFO - 2022-12-16 09:17:31 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:31 --> Input Class Initialized
INFO - 2022-12-16 09:17:31 --> Language Class Initialized
INFO - 2022-12-16 09:17:31 --> Language Class Initialized
INFO - 2022-12-16 09:17:31 --> Config Class Initialized
INFO - 2022-12-16 09:17:31 --> Loader Class Initialized
INFO - 2022-12-16 09:17:31 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:31 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:31 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:31 --> Controller Class Initialized
INFO - 2022-12-16 09:17:33 --> Config Class Initialized
INFO - 2022-12-16 09:17:33 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:33 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:33 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:33 --> URI Class Initialized
INFO - 2022-12-16 09:17:33 --> Router Class Initialized
INFO - 2022-12-16 09:17:33 --> Output Class Initialized
INFO - 2022-12-16 09:17:33 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:33 --> Input Class Initialized
INFO - 2022-12-16 09:17:33 --> Language Class Initialized
INFO - 2022-12-16 09:17:33 --> Language Class Initialized
INFO - 2022-12-16 09:17:33 --> Config Class Initialized
INFO - 2022-12-16 09:17:33 --> Loader Class Initialized
INFO - 2022-12-16 09:17:33 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:33 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:33 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:33 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:33 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:33 --> Controller Class Initialized
INFO - 2022-12-16 09:17:34 --> Config Class Initialized
INFO - 2022-12-16 09:17:34 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:34 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:34 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:34 --> URI Class Initialized
INFO - 2022-12-16 09:17:34 --> Router Class Initialized
INFO - 2022-12-16 09:17:34 --> Output Class Initialized
INFO - 2022-12-16 09:17:34 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:34 --> Input Class Initialized
INFO - 2022-12-16 09:17:34 --> Language Class Initialized
INFO - 2022-12-16 09:17:34 --> Language Class Initialized
INFO - 2022-12-16 09:17:34 --> Config Class Initialized
INFO - 2022-12-16 09:17:34 --> Loader Class Initialized
INFO - 2022-12-16 09:17:34 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:34 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:34 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:34 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:34 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:34 --> Controller Class Initialized
INFO - 2022-12-16 09:17:34 --> Config Class Initialized
INFO - 2022-12-16 09:17:34 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:34 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:34 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:34 --> URI Class Initialized
INFO - 2022-12-16 09:17:34 --> Router Class Initialized
INFO - 2022-12-16 09:17:34 --> Output Class Initialized
INFO - 2022-12-16 09:17:34 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:34 --> Input Class Initialized
INFO - 2022-12-16 09:17:34 --> Language Class Initialized
INFO - 2022-12-16 09:17:34 --> Language Class Initialized
INFO - 2022-12-16 09:17:34 --> Config Class Initialized
INFO - 2022-12-16 09:17:34 --> Loader Class Initialized
INFO - 2022-12-16 09:17:34 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:34 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:34 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:34 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:34 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:34 --> Controller Class Initialized
INFO - 2022-12-16 09:17:35 --> Config Class Initialized
INFO - 2022-12-16 09:17:35 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:17:35 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:17:35 --> Utf8 Class Initialized
INFO - 2022-12-16 09:17:35 --> URI Class Initialized
INFO - 2022-12-16 09:17:35 --> Router Class Initialized
INFO - 2022-12-16 09:17:35 --> Output Class Initialized
INFO - 2022-12-16 09:17:35 --> Security Class Initialized
DEBUG - 2022-12-16 09:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:17:35 --> Input Class Initialized
INFO - 2022-12-16 09:17:35 --> Language Class Initialized
INFO - 2022-12-16 09:17:35 --> Language Class Initialized
INFO - 2022-12-16 09:17:35 --> Config Class Initialized
INFO - 2022-12-16 09:17:35 --> Loader Class Initialized
INFO - 2022-12-16 09:17:35 --> Helper loaded: url_helper
INFO - 2022-12-16 09:17:35 --> Helper loaded: file_helper
INFO - 2022-12-16 09:17:35 --> Helper loaded: form_helper
INFO - 2022-12-16 09:17:35 --> Helper loaded: my_helper
INFO - 2022-12-16 09:17:35 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:17:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:17:35 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:17:35 --> Controller Class Initialized
INFO - 2022-12-16 09:18:13 --> Config Class Initialized
INFO - 2022-12-16 09:18:13 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:18:13 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:18:13 --> Utf8 Class Initialized
INFO - 2022-12-16 09:18:13 --> URI Class Initialized
INFO - 2022-12-16 09:18:13 --> Router Class Initialized
INFO - 2022-12-16 09:18:13 --> Output Class Initialized
INFO - 2022-12-16 09:18:13 --> Security Class Initialized
DEBUG - 2022-12-16 09:18:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:18:13 --> Input Class Initialized
INFO - 2022-12-16 09:18:13 --> Language Class Initialized
INFO - 2022-12-16 09:18:13 --> Language Class Initialized
INFO - 2022-12-16 09:18:13 --> Config Class Initialized
INFO - 2022-12-16 09:18:13 --> Loader Class Initialized
INFO - 2022-12-16 09:18:13 --> Helper loaded: url_helper
INFO - 2022-12-16 09:18:13 --> Helper loaded: file_helper
INFO - 2022-12-16 09:18:13 --> Helper loaded: form_helper
INFO - 2022-12-16 09:18:13 --> Helper loaded: my_helper
INFO - 2022-12-16 09:18:13 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:18:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:18:13 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:18:13 --> Controller Class Initialized
DEBUG - 2022-12-16 09:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:18:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:18:13 --> Final output sent to browser
DEBUG - 2022-12-16 09:18:13 --> Total execution time: 0.0700
INFO - 2022-12-16 09:19:26 --> Config Class Initialized
INFO - 2022-12-16 09:19:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:26 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:26 --> URI Class Initialized
INFO - 2022-12-16 09:19:26 --> Router Class Initialized
INFO - 2022-12-16 09:19:26 --> Output Class Initialized
INFO - 2022-12-16 09:19:26 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:26 --> Input Class Initialized
INFO - 2022-12-16 09:19:26 --> Language Class Initialized
INFO - 2022-12-16 09:19:26 --> Language Class Initialized
INFO - 2022-12-16 09:19:26 --> Config Class Initialized
INFO - 2022-12-16 09:19:26 --> Loader Class Initialized
INFO - 2022-12-16 09:19:26 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:26 --> Controller Class Initialized
INFO - 2022-12-16 09:19:26 --> Config Class Initialized
INFO - 2022-12-16 09:19:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:26 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:26 --> URI Class Initialized
INFO - 2022-12-16 09:19:26 --> Router Class Initialized
INFO - 2022-12-16 09:19:26 --> Output Class Initialized
INFO - 2022-12-16 09:19:26 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:26 --> Input Class Initialized
INFO - 2022-12-16 09:19:26 --> Language Class Initialized
INFO - 2022-12-16 09:19:26 --> Language Class Initialized
INFO - 2022-12-16 09:19:26 --> Config Class Initialized
INFO - 2022-12-16 09:19:26 --> Loader Class Initialized
INFO - 2022-12-16 09:19:26 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:26 --> Controller Class Initialized
DEBUG - 2022-12-16 09:19:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:19:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:19:26 --> Final output sent to browser
DEBUG - 2022-12-16 09:19:26 --> Total execution time: 0.0542
INFO - 2022-12-16 09:19:26 --> Config Class Initialized
INFO - 2022-12-16 09:19:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:26 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:26 --> URI Class Initialized
INFO - 2022-12-16 09:19:26 --> Router Class Initialized
INFO - 2022-12-16 09:19:26 --> Output Class Initialized
INFO - 2022-12-16 09:19:26 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:26 --> Input Class Initialized
INFO - 2022-12-16 09:19:26 --> Language Class Initialized
INFO - 2022-12-16 09:19:26 --> Language Class Initialized
INFO - 2022-12-16 09:19:26 --> Config Class Initialized
INFO - 2022-12-16 09:19:26 --> Loader Class Initialized
INFO - 2022-12-16 09:19:26 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:26 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:26 --> Controller Class Initialized
INFO - 2022-12-16 09:19:27 --> Config Class Initialized
INFO - 2022-12-16 09:19:27 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:27 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:27 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:27 --> URI Class Initialized
INFO - 2022-12-16 09:19:27 --> Router Class Initialized
INFO - 2022-12-16 09:19:27 --> Output Class Initialized
INFO - 2022-12-16 09:19:27 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:27 --> Input Class Initialized
INFO - 2022-12-16 09:19:27 --> Language Class Initialized
INFO - 2022-12-16 09:19:27 --> Language Class Initialized
INFO - 2022-12-16 09:19:27 --> Config Class Initialized
INFO - 2022-12-16 09:19:27 --> Loader Class Initialized
INFO - 2022-12-16 09:19:27 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:27 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:27 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:27 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:27 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:27 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:27 --> Controller Class Initialized
INFO - 2022-12-16 09:19:28 --> Config Class Initialized
INFO - 2022-12-16 09:19:28 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:28 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:28 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:28 --> URI Class Initialized
INFO - 2022-12-16 09:19:28 --> Router Class Initialized
INFO - 2022-12-16 09:19:28 --> Output Class Initialized
INFO - 2022-12-16 09:19:28 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:28 --> Input Class Initialized
INFO - 2022-12-16 09:19:28 --> Language Class Initialized
INFO - 2022-12-16 09:19:28 --> Language Class Initialized
INFO - 2022-12-16 09:19:28 --> Config Class Initialized
INFO - 2022-12-16 09:19:28 --> Loader Class Initialized
INFO - 2022-12-16 09:19:28 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:28 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:28 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:28 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:28 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:28 --> Controller Class Initialized
INFO - 2022-12-16 09:19:28 --> Config Class Initialized
INFO - 2022-12-16 09:19:28 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:28 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:28 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:28 --> URI Class Initialized
INFO - 2022-12-16 09:19:28 --> Router Class Initialized
INFO - 2022-12-16 09:19:28 --> Output Class Initialized
INFO - 2022-12-16 09:19:28 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:28 --> Input Class Initialized
INFO - 2022-12-16 09:19:28 --> Language Class Initialized
INFO - 2022-12-16 09:19:28 --> Language Class Initialized
INFO - 2022-12-16 09:19:28 --> Config Class Initialized
INFO - 2022-12-16 09:19:28 --> Loader Class Initialized
INFO - 2022-12-16 09:19:28 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:28 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:28 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:28 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:28 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:28 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:28 --> Controller Class Initialized
INFO - 2022-12-16 09:19:29 --> Config Class Initialized
INFO - 2022-12-16 09:19:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:29 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:29 --> URI Class Initialized
INFO - 2022-12-16 09:19:29 --> Router Class Initialized
INFO - 2022-12-16 09:19:29 --> Output Class Initialized
INFO - 2022-12-16 09:19:29 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:29 --> Input Class Initialized
INFO - 2022-12-16 09:19:29 --> Language Class Initialized
INFO - 2022-12-16 09:19:29 --> Language Class Initialized
INFO - 2022-12-16 09:19:29 --> Config Class Initialized
INFO - 2022-12-16 09:19:29 --> Loader Class Initialized
INFO - 2022-12-16 09:19:29 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:29 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:29 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:29 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:29 --> Controller Class Initialized
INFO - 2022-12-16 09:19:29 --> Config Class Initialized
INFO - 2022-12-16 09:19:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:29 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:29 --> URI Class Initialized
INFO - 2022-12-16 09:19:29 --> Router Class Initialized
INFO - 2022-12-16 09:19:29 --> Output Class Initialized
INFO - 2022-12-16 09:19:29 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:29 --> Input Class Initialized
INFO - 2022-12-16 09:19:29 --> Language Class Initialized
INFO - 2022-12-16 09:19:29 --> Language Class Initialized
INFO - 2022-12-16 09:19:29 --> Config Class Initialized
INFO - 2022-12-16 09:19:29 --> Loader Class Initialized
INFO - 2022-12-16 09:19:29 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:29 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:29 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:29 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:29 --> Controller Class Initialized
INFO - 2022-12-16 09:19:34 --> Config Class Initialized
INFO - 2022-12-16 09:19:34 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:19:34 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:19:34 --> Utf8 Class Initialized
INFO - 2022-12-16 09:19:34 --> URI Class Initialized
INFO - 2022-12-16 09:19:34 --> Router Class Initialized
INFO - 2022-12-16 09:19:34 --> Output Class Initialized
INFO - 2022-12-16 09:19:34 --> Security Class Initialized
DEBUG - 2022-12-16 09:19:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:19:34 --> Input Class Initialized
INFO - 2022-12-16 09:19:34 --> Language Class Initialized
INFO - 2022-12-16 09:19:34 --> Language Class Initialized
INFO - 2022-12-16 09:19:34 --> Config Class Initialized
INFO - 2022-12-16 09:19:34 --> Loader Class Initialized
INFO - 2022-12-16 09:19:34 --> Helper loaded: url_helper
INFO - 2022-12-16 09:19:34 --> Helper loaded: file_helper
INFO - 2022-12-16 09:19:34 --> Helper loaded: form_helper
INFO - 2022-12-16 09:19:34 --> Helper loaded: my_helper
INFO - 2022-12-16 09:19:34 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:19:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:19:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:19:34 --> Controller Class Initialized
DEBUG - 2022-12-16 09:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:19:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:19:34 --> Final output sent to browser
DEBUG - 2022-12-16 09:19:34 --> Total execution time: 0.0962
INFO - 2022-12-16 09:20:23 --> Config Class Initialized
INFO - 2022-12-16 09:20:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:20:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:20:23 --> Utf8 Class Initialized
INFO - 2022-12-16 09:20:23 --> URI Class Initialized
INFO - 2022-12-16 09:20:23 --> Router Class Initialized
INFO - 2022-12-16 09:20:23 --> Output Class Initialized
INFO - 2022-12-16 09:20:23 --> Security Class Initialized
DEBUG - 2022-12-16 09:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:20:23 --> Input Class Initialized
INFO - 2022-12-16 09:20:23 --> Language Class Initialized
INFO - 2022-12-16 09:20:23 --> Language Class Initialized
INFO - 2022-12-16 09:20:23 --> Config Class Initialized
INFO - 2022-12-16 09:20:23 --> Loader Class Initialized
INFO - 2022-12-16 09:20:23 --> Helper loaded: url_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: file_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: form_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: my_helper
INFO - 2022-12-16 09:20:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:20:23 --> Controller Class Initialized
INFO - 2022-12-16 09:20:23 --> Config Class Initialized
INFO - 2022-12-16 09:20:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:20:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:20:23 --> Utf8 Class Initialized
INFO - 2022-12-16 09:20:23 --> URI Class Initialized
INFO - 2022-12-16 09:20:23 --> Router Class Initialized
INFO - 2022-12-16 09:20:23 --> Output Class Initialized
INFO - 2022-12-16 09:20:23 --> Security Class Initialized
DEBUG - 2022-12-16 09:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:20:23 --> Input Class Initialized
INFO - 2022-12-16 09:20:23 --> Language Class Initialized
INFO - 2022-12-16 09:20:23 --> Language Class Initialized
INFO - 2022-12-16 09:20:23 --> Config Class Initialized
INFO - 2022-12-16 09:20:23 --> Loader Class Initialized
INFO - 2022-12-16 09:20:23 --> Helper loaded: url_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: file_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: form_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: my_helper
INFO - 2022-12-16 09:20:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:20:23 --> Controller Class Initialized
DEBUG - 2022-12-16 09:20:23 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:20:23 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:20:23 --> Final output sent to browser
DEBUG - 2022-12-16 09:20:23 --> Total execution time: 0.0639
INFO - 2022-12-16 09:20:23 --> Config Class Initialized
INFO - 2022-12-16 09:20:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:20:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:20:23 --> Utf8 Class Initialized
INFO - 2022-12-16 09:20:23 --> URI Class Initialized
INFO - 2022-12-16 09:20:23 --> Router Class Initialized
INFO - 2022-12-16 09:20:23 --> Output Class Initialized
INFO - 2022-12-16 09:20:23 --> Security Class Initialized
DEBUG - 2022-12-16 09:20:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:20:23 --> Input Class Initialized
INFO - 2022-12-16 09:20:23 --> Language Class Initialized
INFO - 2022-12-16 09:20:23 --> Language Class Initialized
INFO - 2022-12-16 09:20:23 --> Config Class Initialized
INFO - 2022-12-16 09:20:23 --> Loader Class Initialized
INFO - 2022-12-16 09:20:23 --> Helper loaded: url_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: file_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: form_helper
INFO - 2022-12-16 09:20:23 --> Helper loaded: my_helper
INFO - 2022-12-16 09:20:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:20:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:20:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:20:23 --> Controller Class Initialized
INFO - 2022-12-16 09:21:06 --> Config Class Initialized
INFO - 2022-12-16 09:21:06 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:21:06 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:21:06 --> Utf8 Class Initialized
INFO - 2022-12-16 09:21:06 --> URI Class Initialized
INFO - 2022-12-16 09:21:06 --> Router Class Initialized
INFO - 2022-12-16 09:21:06 --> Output Class Initialized
INFO - 2022-12-16 09:21:06 --> Security Class Initialized
DEBUG - 2022-12-16 09:21:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:21:06 --> Input Class Initialized
INFO - 2022-12-16 09:21:06 --> Language Class Initialized
INFO - 2022-12-16 09:21:06 --> Language Class Initialized
INFO - 2022-12-16 09:21:06 --> Config Class Initialized
INFO - 2022-12-16 09:21:06 --> Loader Class Initialized
INFO - 2022-12-16 09:21:06 --> Helper loaded: url_helper
INFO - 2022-12-16 09:21:06 --> Helper loaded: file_helper
INFO - 2022-12-16 09:21:06 --> Helper loaded: form_helper
INFO - 2022-12-16 09:21:06 --> Helper loaded: my_helper
INFO - 2022-12-16 09:21:06 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:21:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:21:06 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:21:06 --> Controller Class Initialized
DEBUG - 2022-12-16 09:21:06 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:21:06 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:21:06 --> Final output sent to browser
DEBUG - 2022-12-16 09:21:06 --> Total execution time: 0.0721
INFO - 2022-12-16 09:21:50 --> Config Class Initialized
INFO - 2022-12-16 09:21:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:21:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:21:50 --> Utf8 Class Initialized
INFO - 2022-12-16 09:21:50 --> URI Class Initialized
INFO - 2022-12-16 09:21:50 --> Router Class Initialized
INFO - 2022-12-16 09:21:50 --> Output Class Initialized
INFO - 2022-12-16 09:21:50 --> Security Class Initialized
DEBUG - 2022-12-16 09:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:21:50 --> Input Class Initialized
INFO - 2022-12-16 09:21:50 --> Language Class Initialized
INFO - 2022-12-16 09:21:50 --> Language Class Initialized
INFO - 2022-12-16 09:21:50 --> Config Class Initialized
INFO - 2022-12-16 09:21:50 --> Loader Class Initialized
INFO - 2022-12-16 09:21:50 --> Helper loaded: url_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: file_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: form_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: my_helper
INFO - 2022-12-16 09:21:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:21:50 --> Controller Class Initialized
INFO - 2022-12-16 09:21:50 --> Config Class Initialized
INFO - 2022-12-16 09:21:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:21:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:21:50 --> Utf8 Class Initialized
INFO - 2022-12-16 09:21:50 --> URI Class Initialized
INFO - 2022-12-16 09:21:50 --> Router Class Initialized
INFO - 2022-12-16 09:21:50 --> Output Class Initialized
INFO - 2022-12-16 09:21:50 --> Security Class Initialized
DEBUG - 2022-12-16 09:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:21:50 --> Input Class Initialized
INFO - 2022-12-16 09:21:50 --> Language Class Initialized
INFO - 2022-12-16 09:21:50 --> Language Class Initialized
INFO - 2022-12-16 09:21:50 --> Config Class Initialized
INFO - 2022-12-16 09:21:50 --> Loader Class Initialized
INFO - 2022-12-16 09:21:50 --> Helper loaded: url_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: file_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: form_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: my_helper
INFO - 2022-12-16 09:21:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:21:50 --> Controller Class Initialized
DEBUG - 2022-12-16 09:21:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:21:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:21:50 --> Final output sent to browser
DEBUG - 2022-12-16 09:21:50 --> Total execution time: 0.0575
INFO - 2022-12-16 09:21:50 --> Config Class Initialized
INFO - 2022-12-16 09:21:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:21:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:21:50 --> Utf8 Class Initialized
INFO - 2022-12-16 09:21:50 --> URI Class Initialized
INFO - 2022-12-16 09:21:50 --> Router Class Initialized
INFO - 2022-12-16 09:21:50 --> Output Class Initialized
INFO - 2022-12-16 09:21:50 --> Security Class Initialized
DEBUG - 2022-12-16 09:21:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:21:50 --> Input Class Initialized
INFO - 2022-12-16 09:21:50 --> Language Class Initialized
INFO - 2022-12-16 09:21:50 --> Language Class Initialized
INFO - 2022-12-16 09:21:50 --> Config Class Initialized
INFO - 2022-12-16 09:21:50 --> Loader Class Initialized
INFO - 2022-12-16 09:21:50 --> Helper loaded: url_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: file_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: form_helper
INFO - 2022-12-16 09:21:50 --> Helper loaded: my_helper
INFO - 2022-12-16 09:21:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:21:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:21:50 --> Controller Class Initialized
INFO - 2022-12-16 09:22:15 --> Config Class Initialized
INFO - 2022-12-16 09:22:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:15 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:15 --> URI Class Initialized
INFO - 2022-12-16 09:22:15 --> Router Class Initialized
INFO - 2022-12-16 09:22:15 --> Output Class Initialized
INFO - 2022-12-16 09:22:15 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:15 --> Input Class Initialized
INFO - 2022-12-16 09:22:15 --> Language Class Initialized
INFO - 2022-12-16 09:22:15 --> Language Class Initialized
INFO - 2022-12-16 09:22:15 --> Config Class Initialized
INFO - 2022-12-16 09:22:15 --> Loader Class Initialized
INFO - 2022-12-16 09:22:15 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:15 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:15 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:15 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:15 --> Controller Class Initialized
DEBUG - 2022-12-16 09:22:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:22:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:22:15 --> Final output sent to browser
DEBUG - 2022-12-16 09:22:15 --> Total execution time: 0.0732
INFO - 2022-12-16 09:22:29 --> Config Class Initialized
INFO - 2022-12-16 09:22:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:29 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:29 --> URI Class Initialized
INFO - 2022-12-16 09:22:29 --> Router Class Initialized
INFO - 2022-12-16 09:22:29 --> Output Class Initialized
INFO - 2022-12-16 09:22:29 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:29 --> Input Class Initialized
INFO - 2022-12-16 09:22:29 --> Language Class Initialized
INFO - 2022-12-16 09:22:29 --> Language Class Initialized
INFO - 2022-12-16 09:22:29 --> Config Class Initialized
INFO - 2022-12-16 09:22:29 --> Loader Class Initialized
INFO - 2022-12-16 09:22:29 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:29 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:29 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:29 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:29 --> Controller Class Initialized
INFO - 2022-12-16 09:22:29 --> Config Class Initialized
INFO - 2022-12-16 09:22:29 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:29 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:29 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:29 --> URI Class Initialized
INFO - 2022-12-16 09:22:29 --> Router Class Initialized
INFO - 2022-12-16 09:22:29 --> Output Class Initialized
INFO - 2022-12-16 09:22:29 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:29 --> Input Class Initialized
INFO - 2022-12-16 09:22:29 --> Language Class Initialized
INFO - 2022-12-16 09:22:29 --> Language Class Initialized
INFO - 2022-12-16 09:22:29 --> Config Class Initialized
INFO - 2022-12-16 09:22:29 --> Loader Class Initialized
INFO - 2022-12-16 09:22:29 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:29 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:29 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:29 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:29 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:29 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:29 --> Controller Class Initialized
DEBUG - 2022-12-16 09:22:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:22:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:22:29 --> Final output sent to browser
DEBUG - 2022-12-16 09:22:29 --> Total execution time: 0.0500
INFO - 2022-12-16 09:22:30 --> Config Class Initialized
INFO - 2022-12-16 09:22:30 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:30 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:30 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:30 --> URI Class Initialized
INFO - 2022-12-16 09:22:30 --> Router Class Initialized
INFO - 2022-12-16 09:22:30 --> Output Class Initialized
INFO - 2022-12-16 09:22:30 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:30 --> Input Class Initialized
INFO - 2022-12-16 09:22:30 --> Language Class Initialized
INFO - 2022-12-16 09:22:30 --> Language Class Initialized
INFO - 2022-12-16 09:22:30 --> Config Class Initialized
INFO - 2022-12-16 09:22:30 --> Loader Class Initialized
INFO - 2022-12-16 09:22:30 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:30 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:30 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:30 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:30 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:30 --> Controller Class Initialized
INFO - 2022-12-16 09:22:31 --> Config Class Initialized
INFO - 2022-12-16 09:22:31 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:31 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:31 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:31 --> URI Class Initialized
INFO - 2022-12-16 09:22:31 --> Router Class Initialized
INFO - 2022-12-16 09:22:31 --> Output Class Initialized
INFO - 2022-12-16 09:22:31 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:31 --> Input Class Initialized
INFO - 2022-12-16 09:22:31 --> Language Class Initialized
INFO - 2022-12-16 09:22:31 --> Language Class Initialized
INFO - 2022-12-16 09:22:31 --> Config Class Initialized
INFO - 2022-12-16 09:22:31 --> Loader Class Initialized
INFO - 2022-12-16 09:22:31 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:31 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:31 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:31 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:31 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:31 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:31 --> Controller Class Initialized
INFO - 2022-12-16 09:22:32 --> Config Class Initialized
INFO - 2022-12-16 09:22:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:32 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:32 --> URI Class Initialized
INFO - 2022-12-16 09:22:32 --> Router Class Initialized
INFO - 2022-12-16 09:22:32 --> Output Class Initialized
INFO - 2022-12-16 09:22:32 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:32 --> Input Class Initialized
INFO - 2022-12-16 09:22:32 --> Language Class Initialized
INFO - 2022-12-16 09:22:32 --> Language Class Initialized
INFO - 2022-12-16 09:22:32 --> Config Class Initialized
INFO - 2022-12-16 09:22:32 --> Loader Class Initialized
INFO - 2022-12-16 09:22:32 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:32 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:32 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:32 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:32 --> Controller Class Initialized
INFO - 2022-12-16 09:22:32 --> Config Class Initialized
INFO - 2022-12-16 09:22:32 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:32 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:32 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:32 --> URI Class Initialized
INFO - 2022-12-16 09:22:32 --> Router Class Initialized
INFO - 2022-12-16 09:22:32 --> Output Class Initialized
INFO - 2022-12-16 09:22:32 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:32 --> Input Class Initialized
INFO - 2022-12-16 09:22:32 --> Language Class Initialized
INFO - 2022-12-16 09:22:32 --> Language Class Initialized
INFO - 2022-12-16 09:22:32 --> Config Class Initialized
INFO - 2022-12-16 09:22:32 --> Loader Class Initialized
INFO - 2022-12-16 09:22:32 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:32 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:32 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:32 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:32 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:32 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:32 --> Controller Class Initialized
INFO - 2022-12-16 09:22:34 --> Config Class Initialized
INFO - 2022-12-16 09:22:34 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:34 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:34 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:34 --> URI Class Initialized
INFO - 2022-12-16 09:22:34 --> Router Class Initialized
INFO - 2022-12-16 09:22:34 --> Output Class Initialized
INFO - 2022-12-16 09:22:34 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:34 --> Input Class Initialized
INFO - 2022-12-16 09:22:34 --> Language Class Initialized
INFO - 2022-12-16 09:22:34 --> Language Class Initialized
INFO - 2022-12-16 09:22:34 --> Config Class Initialized
INFO - 2022-12-16 09:22:34 --> Loader Class Initialized
INFO - 2022-12-16 09:22:34 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:34 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:34 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:34 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:34 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:34 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:34 --> Controller Class Initialized
INFO - 2022-12-16 09:22:36 --> Config Class Initialized
INFO - 2022-12-16 09:22:36 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:36 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:36 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:36 --> URI Class Initialized
INFO - 2022-12-16 09:22:36 --> Router Class Initialized
INFO - 2022-12-16 09:22:36 --> Output Class Initialized
INFO - 2022-12-16 09:22:36 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:36 --> Input Class Initialized
INFO - 2022-12-16 09:22:36 --> Language Class Initialized
INFO - 2022-12-16 09:22:36 --> Language Class Initialized
INFO - 2022-12-16 09:22:36 --> Config Class Initialized
INFO - 2022-12-16 09:22:36 --> Loader Class Initialized
INFO - 2022-12-16 09:22:36 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:36 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:36 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:36 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:36 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:36 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:36 --> Controller Class Initialized
DEBUG - 2022-12-16 09:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:22:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:22:36 --> Final output sent to browser
DEBUG - 2022-12-16 09:22:36 --> Total execution time: 0.0820
INFO - 2022-12-16 09:22:45 --> Config Class Initialized
INFO - 2022-12-16 09:22:45 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:45 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:45 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:45 --> URI Class Initialized
INFO - 2022-12-16 09:22:45 --> Router Class Initialized
INFO - 2022-12-16 09:22:45 --> Output Class Initialized
INFO - 2022-12-16 09:22:46 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:46 --> Input Class Initialized
INFO - 2022-12-16 09:22:46 --> Language Class Initialized
INFO - 2022-12-16 09:22:46 --> Language Class Initialized
INFO - 2022-12-16 09:22:46 --> Config Class Initialized
INFO - 2022-12-16 09:22:46 --> Loader Class Initialized
INFO - 2022-12-16 09:22:46 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:46 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:46 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:46 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:46 --> Controller Class Initialized
DEBUG - 2022-12-16 09:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/data_guru/views/list.php
DEBUG - 2022-12-16 09:22:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:22:46 --> Final output sent to browser
DEBUG - 2022-12-16 09:22:46 --> Total execution time: 0.0969
INFO - 2022-12-16 09:22:46 --> Config Class Initialized
INFO - 2022-12-16 09:22:46 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:46 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:46 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:46 --> URI Class Initialized
INFO - 2022-12-16 09:22:46 --> Router Class Initialized
INFO - 2022-12-16 09:22:46 --> Output Class Initialized
INFO - 2022-12-16 09:22:46 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:46 --> Input Class Initialized
INFO - 2022-12-16 09:22:46 --> Language Class Initialized
INFO - 2022-12-16 09:22:46 --> Language Class Initialized
INFO - 2022-12-16 09:22:46 --> Config Class Initialized
INFO - 2022-12-16 09:22:46 --> Loader Class Initialized
INFO - 2022-12-16 09:22:46 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:46 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:46 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:46 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:46 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:46 --> Controller Class Initialized
INFO - 2022-12-16 09:22:49 --> Config Class Initialized
INFO - 2022-12-16 09:22:49 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:49 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:49 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:49 --> URI Class Initialized
INFO - 2022-12-16 09:22:49 --> Router Class Initialized
INFO - 2022-12-16 09:22:49 --> Output Class Initialized
INFO - 2022-12-16 09:22:49 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:49 --> Input Class Initialized
INFO - 2022-12-16 09:22:49 --> Language Class Initialized
INFO - 2022-12-16 09:22:49 --> Language Class Initialized
INFO - 2022-12-16 09:22:49 --> Config Class Initialized
INFO - 2022-12-16 09:22:49 --> Loader Class Initialized
INFO - 2022-12-16 09:22:49 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:49 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:49 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:49 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:49 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:49 --> Controller Class Initialized
INFO - 2022-12-16 09:22:52 --> Config Class Initialized
INFO - 2022-12-16 09:22:52 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:52 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:52 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:52 --> URI Class Initialized
INFO - 2022-12-16 09:22:52 --> Router Class Initialized
INFO - 2022-12-16 09:22:52 --> Output Class Initialized
INFO - 2022-12-16 09:22:52 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:52 --> Input Class Initialized
INFO - 2022-12-16 09:22:52 --> Language Class Initialized
INFO - 2022-12-16 09:22:52 --> Language Class Initialized
INFO - 2022-12-16 09:22:52 --> Config Class Initialized
INFO - 2022-12-16 09:22:52 --> Loader Class Initialized
INFO - 2022-12-16 09:22:52 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:52 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:52 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:52 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:52 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:52 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:52 --> Controller Class Initialized
INFO - 2022-12-16 09:22:56 --> Config Class Initialized
INFO - 2022-12-16 09:22:56 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:56 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:56 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:56 --> URI Class Initialized
INFO - 2022-12-16 09:22:56 --> Router Class Initialized
INFO - 2022-12-16 09:22:56 --> Output Class Initialized
INFO - 2022-12-16 09:22:56 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:56 --> Input Class Initialized
INFO - 2022-12-16 09:22:56 --> Language Class Initialized
INFO - 2022-12-16 09:22:56 --> Language Class Initialized
INFO - 2022-12-16 09:22:56 --> Config Class Initialized
INFO - 2022-12-16 09:22:56 --> Loader Class Initialized
INFO - 2022-12-16 09:22:56 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:56 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:56 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:56 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:56 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:56 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:56 --> Controller Class Initialized
INFO - 2022-12-16 09:22:58 --> Config Class Initialized
INFO - 2022-12-16 09:22:58 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:58 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:58 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:58 --> URI Class Initialized
INFO - 2022-12-16 09:22:58 --> Router Class Initialized
INFO - 2022-12-16 09:22:58 --> Output Class Initialized
INFO - 2022-12-16 09:22:58 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:58 --> Input Class Initialized
INFO - 2022-12-16 09:22:58 --> Language Class Initialized
INFO - 2022-12-16 09:22:58 --> Language Class Initialized
INFO - 2022-12-16 09:22:58 --> Config Class Initialized
INFO - 2022-12-16 09:22:58 --> Loader Class Initialized
INFO - 2022-12-16 09:22:58 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:58 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:58 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:58 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:58 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:58 --> Controller Class Initialized
INFO - 2022-12-16 09:22:58 --> Config Class Initialized
INFO - 2022-12-16 09:22:58 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:58 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:58 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:58 --> URI Class Initialized
INFO - 2022-12-16 09:22:58 --> Router Class Initialized
INFO - 2022-12-16 09:22:58 --> Output Class Initialized
INFO - 2022-12-16 09:22:58 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:58 --> Input Class Initialized
INFO - 2022-12-16 09:22:58 --> Language Class Initialized
INFO - 2022-12-16 09:22:58 --> Language Class Initialized
INFO - 2022-12-16 09:22:58 --> Config Class Initialized
INFO - 2022-12-16 09:22:58 --> Loader Class Initialized
INFO - 2022-12-16 09:22:58 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:58 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:58 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:58 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:58 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:58 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:58 --> Controller Class Initialized
INFO - 2022-12-16 09:22:59 --> Config Class Initialized
INFO - 2022-12-16 09:22:59 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:59 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:59 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:59 --> URI Class Initialized
INFO - 2022-12-16 09:22:59 --> Router Class Initialized
INFO - 2022-12-16 09:22:59 --> Output Class Initialized
INFO - 2022-12-16 09:22:59 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:59 --> Input Class Initialized
INFO - 2022-12-16 09:22:59 --> Language Class Initialized
INFO - 2022-12-16 09:22:59 --> Language Class Initialized
INFO - 2022-12-16 09:22:59 --> Config Class Initialized
INFO - 2022-12-16 09:22:59 --> Loader Class Initialized
INFO - 2022-12-16 09:22:59 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:59 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:59 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:59 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:59 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:59 --> Controller Class Initialized
INFO - 2022-12-16 09:22:59 --> Config Class Initialized
INFO - 2022-12-16 09:22:59 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:22:59 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:22:59 --> Utf8 Class Initialized
INFO - 2022-12-16 09:22:59 --> URI Class Initialized
INFO - 2022-12-16 09:22:59 --> Router Class Initialized
INFO - 2022-12-16 09:22:59 --> Output Class Initialized
INFO - 2022-12-16 09:22:59 --> Security Class Initialized
DEBUG - 2022-12-16 09:22:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:22:59 --> Input Class Initialized
INFO - 2022-12-16 09:22:59 --> Language Class Initialized
INFO - 2022-12-16 09:22:59 --> Language Class Initialized
INFO - 2022-12-16 09:22:59 --> Config Class Initialized
INFO - 2022-12-16 09:22:59 --> Loader Class Initialized
INFO - 2022-12-16 09:22:59 --> Helper loaded: url_helper
INFO - 2022-12-16 09:22:59 --> Helper loaded: file_helper
INFO - 2022-12-16 09:22:59 --> Helper loaded: form_helper
INFO - 2022-12-16 09:22:59 --> Helper loaded: my_helper
INFO - 2022-12-16 09:22:59 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:22:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:22:59 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:22:59 --> Controller Class Initialized
INFO - 2022-12-16 09:23:00 --> Config Class Initialized
INFO - 2022-12-16 09:23:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:00 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:00 --> URI Class Initialized
INFO - 2022-12-16 09:23:00 --> Router Class Initialized
INFO - 2022-12-16 09:23:00 --> Output Class Initialized
INFO - 2022-12-16 09:23:00 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:00 --> Input Class Initialized
INFO - 2022-12-16 09:23:00 --> Language Class Initialized
INFO - 2022-12-16 09:23:00 --> Language Class Initialized
INFO - 2022-12-16 09:23:00 --> Config Class Initialized
INFO - 2022-12-16 09:23:00 --> Loader Class Initialized
INFO - 2022-12-16 09:23:00 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:00 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:00 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:00 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:00 --> Controller Class Initialized
INFO - 2022-12-16 09:23:00 --> Config Class Initialized
INFO - 2022-12-16 09:23:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:00 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:00 --> URI Class Initialized
INFO - 2022-12-16 09:23:00 --> Router Class Initialized
INFO - 2022-12-16 09:23:00 --> Output Class Initialized
INFO - 2022-12-16 09:23:00 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:00 --> Input Class Initialized
INFO - 2022-12-16 09:23:00 --> Language Class Initialized
INFO - 2022-12-16 09:23:00 --> Language Class Initialized
INFO - 2022-12-16 09:23:00 --> Config Class Initialized
INFO - 2022-12-16 09:23:00 --> Loader Class Initialized
INFO - 2022-12-16 09:23:00 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:00 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:00 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:00 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:00 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:00 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:00 --> Controller Class Initialized
INFO - 2022-12-16 09:23:00 --> Config Class Initialized
INFO - 2022-12-16 09:23:00 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:00 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:00 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:00 --> URI Class Initialized
INFO - 2022-12-16 09:23:00 --> Router Class Initialized
INFO - 2022-12-16 09:23:00 --> Output Class Initialized
INFO - 2022-12-16 09:23:00 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:00 --> Input Class Initialized
INFO - 2022-12-16 09:23:00 --> Language Class Initialized
INFO - 2022-12-16 09:23:00 --> Language Class Initialized
INFO - 2022-12-16 09:23:00 --> Config Class Initialized
INFO - 2022-12-16 09:23:00 --> Loader Class Initialized
INFO - 2022-12-16 09:23:01 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:01 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:01 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:01 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:01 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:01 --> Controller Class Initialized
INFO - 2022-12-16 09:23:04 --> Config Class Initialized
INFO - 2022-12-16 09:23:04 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:04 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:04 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:04 --> URI Class Initialized
INFO - 2022-12-16 09:23:04 --> Router Class Initialized
INFO - 2022-12-16 09:23:04 --> Output Class Initialized
INFO - 2022-12-16 09:23:04 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:04 --> Input Class Initialized
INFO - 2022-12-16 09:23:04 --> Language Class Initialized
INFO - 2022-12-16 09:23:04 --> Language Class Initialized
INFO - 2022-12-16 09:23:04 --> Config Class Initialized
INFO - 2022-12-16 09:23:04 --> Loader Class Initialized
INFO - 2022-12-16 09:23:04 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:04 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:04 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:04 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:04 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:04 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:04 --> Controller Class Initialized
INFO - 2022-12-16 09:23:08 --> Config Class Initialized
INFO - 2022-12-16 09:23:08 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:08 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:08 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:08 --> URI Class Initialized
INFO - 2022-12-16 09:23:08 --> Router Class Initialized
INFO - 2022-12-16 09:23:08 --> Output Class Initialized
INFO - 2022-12-16 09:23:08 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:08 --> Input Class Initialized
INFO - 2022-12-16 09:23:08 --> Language Class Initialized
INFO - 2022-12-16 09:23:08 --> Language Class Initialized
INFO - 2022-12-16 09:23:08 --> Config Class Initialized
INFO - 2022-12-16 09:23:08 --> Loader Class Initialized
INFO - 2022-12-16 09:23:08 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:08 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:08 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:08 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:08 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:08 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:08 --> Controller Class Initialized
INFO - 2022-12-16 09:23:14 --> Config Class Initialized
INFO - 2022-12-16 09:23:14 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:14 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:14 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:14 --> URI Class Initialized
INFO - 2022-12-16 09:23:14 --> Router Class Initialized
INFO - 2022-12-16 09:23:14 --> Output Class Initialized
INFO - 2022-12-16 09:23:14 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:14 --> Input Class Initialized
INFO - 2022-12-16 09:23:14 --> Language Class Initialized
INFO - 2022-12-16 09:23:14 --> Language Class Initialized
INFO - 2022-12-16 09:23:14 --> Config Class Initialized
INFO - 2022-12-16 09:23:14 --> Loader Class Initialized
INFO - 2022-12-16 09:23:14 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:14 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:14 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:14 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:14 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:14 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:14 --> Controller Class Initialized
INFO - 2022-12-16 09:23:24 --> Config Class Initialized
INFO - 2022-12-16 09:23:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:24 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:24 --> URI Class Initialized
INFO - 2022-12-16 09:23:24 --> Router Class Initialized
INFO - 2022-12-16 09:23:24 --> Output Class Initialized
INFO - 2022-12-16 09:23:24 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:24 --> Input Class Initialized
INFO - 2022-12-16 09:23:24 --> Language Class Initialized
INFO - 2022-12-16 09:23:24 --> Language Class Initialized
INFO - 2022-12-16 09:23:24 --> Config Class Initialized
INFO - 2022-12-16 09:23:24 --> Loader Class Initialized
INFO - 2022-12-16 09:23:24 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:24 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:24 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:24 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:24 --> Controller Class Initialized
INFO - 2022-12-16 09:23:25 --> Config Class Initialized
INFO - 2022-12-16 09:23:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:25 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:25 --> URI Class Initialized
INFO - 2022-12-16 09:23:25 --> Router Class Initialized
INFO - 2022-12-16 09:23:25 --> Output Class Initialized
INFO - 2022-12-16 09:23:25 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:25 --> Input Class Initialized
INFO - 2022-12-16 09:23:25 --> Language Class Initialized
INFO - 2022-12-16 09:23:25 --> Language Class Initialized
INFO - 2022-12-16 09:23:25 --> Config Class Initialized
INFO - 2022-12-16 09:23:25 --> Loader Class Initialized
INFO - 2022-12-16 09:23:25 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:25 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:25 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:25 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:26 --> Controller Class Initialized
INFO - 2022-12-16 09:23:26 --> Final output sent to browser
DEBUG - 2022-12-16 09:23:26 --> Total execution time: 0.0532
INFO - 2022-12-16 09:23:49 --> Config Class Initialized
INFO - 2022-12-16 09:23:49 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:49 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:49 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:49 --> URI Class Initialized
INFO - 2022-12-16 09:23:49 --> Router Class Initialized
INFO - 2022-12-16 09:23:49 --> Output Class Initialized
INFO - 2022-12-16 09:23:49 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:49 --> Input Class Initialized
INFO - 2022-12-16 09:23:49 --> Language Class Initialized
INFO - 2022-12-16 09:23:49 --> Language Class Initialized
INFO - 2022-12-16 09:23:49 --> Config Class Initialized
INFO - 2022-12-16 09:23:49 --> Loader Class Initialized
INFO - 2022-12-16 09:23:49 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:49 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:49 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:49 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:49 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:49 --> Controller Class Initialized
INFO - 2022-12-16 09:23:49 --> Final output sent to browser
DEBUG - 2022-12-16 09:23:49 --> Total execution time: 0.0544
INFO - 2022-12-16 09:23:49 --> Config Class Initialized
INFO - 2022-12-16 09:23:49 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:49 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:49 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:49 --> URI Class Initialized
INFO - 2022-12-16 09:23:49 --> Router Class Initialized
INFO - 2022-12-16 09:23:49 --> Output Class Initialized
INFO - 2022-12-16 09:23:49 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:49 --> Input Class Initialized
INFO - 2022-12-16 09:23:49 --> Language Class Initialized
INFO - 2022-12-16 09:23:49 --> Language Class Initialized
INFO - 2022-12-16 09:23:49 --> Config Class Initialized
INFO - 2022-12-16 09:23:49 --> Loader Class Initialized
INFO - 2022-12-16 09:23:49 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:49 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:49 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:49 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:49 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:49 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:49 --> Controller Class Initialized
INFO - 2022-12-16 09:23:50 --> Config Class Initialized
INFO - 2022-12-16 09:23:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:23:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:23:50 --> Utf8 Class Initialized
INFO - 2022-12-16 09:23:50 --> URI Class Initialized
INFO - 2022-12-16 09:23:50 --> Router Class Initialized
INFO - 2022-12-16 09:23:50 --> Output Class Initialized
INFO - 2022-12-16 09:23:50 --> Security Class Initialized
DEBUG - 2022-12-16 09:23:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:23:50 --> Input Class Initialized
INFO - 2022-12-16 09:23:50 --> Language Class Initialized
INFO - 2022-12-16 09:23:50 --> Language Class Initialized
INFO - 2022-12-16 09:23:50 --> Config Class Initialized
INFO - 2022-12-16 09:23:50 --> Loader Class Initialized
INFO - 2022-12-16 09:23:50 --> Helper loaded: url_helper
INFO - 2022-12-16 09:23:50 --> Helper loaded: file_helper
INFO - 2022-12-16 09:23:50 --> Helper loaded: form_helper
INFO - 2022-12-16 09:23:50 --> Helper loaded: my_helper
INFO - 2022-12-16 09:23:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:23:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:23:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:23:50 --> Controller Class Initialized
INFO - 2022-12-16 09:23:50 --> Final output sent to browser
DEBUG - 2022-12-16 09:23:50 --> Total execution time: 0.0638
INFO - 2022-12-16 09:24:02 --> Config Class Initialized
INFO - 2022-12-16 09:24:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:02 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:02 --> URI Class Initialized
INFO - 2022-12-16 09:24:02 --> Router Class Initialized
INFO - 2022-12-16 09:24:02 --> Output Class Initialized
INFO - 2022-12-16 09:24:02 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:02 --> Input Class Initialized
INFO - 2022-12-16 09:24:02 --> Language Class Initialized
INFO - 2022-12-16 09:24:02 --> Language Class Initialized
INFO - 2022-12-16 09:24:02 --> Config Class Initialized
INFO - 2022-12-16 09:24:02 --> Loader Class Initialized
INFO - 2022-12-16 09:24:02 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:02 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:02 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:02 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:02 --> Controller Class Initialized
INFO - 2022-12-16 09:24:02 --> Final output sent to browser
DEBUG - 2022-12-16 09:24:02 --> Total execution time: 0.0638
INFO - 2022-12-16 09:24:02 --> Config Class Initialized
INFO - 2022-12-16 09:24:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:02 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:02 --> URI Class Initialized
INFO - 2022-12-16 09:24:02 --> Router Class Initialized
INFO - 2022-12-16 09:24:02 --> Output Class Initialized
INFO - 2022-12-16 09:24:02 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:02 --> Input Class Initialized
INFO - 2022-12-16 09:24:02 --> Language Class Initialized
INFO - 2022-12-16 09:24:02 --> Language Class Initialized
INFO - 2022-12-16 09:24:02 --> Config Class Initialized
INFO - 2022-12-16 09:24:02 --> Loader Class Initialized
INFO - 2022-12-16 09:24:02 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:02 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:02 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:02 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:02 --> Controller Class Initialized
INFO - 2022-12-16 09:24:10 --> Config Class Initialized
INFO - 2022-12-16 09:24:10 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:10 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:10 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:10 --> URI Class Initialized
INFO - 2022-12-16 09:24:10 --> Router Class Initialized
INFO - 2022-12-16 09:24:10 --> Output Class Initialized
INFO - 2022-12-16 09:24:10 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:10 --> Input Class Initialized
INFO - 2022-12-16 09:24:10 --> Language Class Initialized
INFO - 2022-12-16 09:24:10 --> Language Class Initialized
INFO - 2022-12-16 09:24:10 --> Config Class Initialized
INFO - 2022-12-16 09:24:10 --> Loader Class Initialized
INFO - 2022-12-16 09:24:10 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:10 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:10 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:10 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:10 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:10 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:10 --> Controller Class Initialized
INFO - 2022-12-16 09:24:10 --> Final output sent to browser
DEBUG - 2022-12-16 09:24:10 --> Total execution time: 0.0805
INFO - 2022-12-16 09:24:17 --> Config Class Initialized
INFO - 2022-12-16 09:24:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:17 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:17 --> URI Class Initialized
INFO - 2022-12-16 09:24:17 --> Router Class Initialized
INFO - 2022-12-16 09:24:17 --> Output Class Initialized
INFO - 2022-12-16 09:24:17 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:17 --> Input Class Initialized
INFO - 2022-12-16 09:24:17 --> Language Class Initialized
INFO - 2022-12-16 09:24:17 --> Language Class Initialized
INFO - 2022-12-16 09:24:17 --> Config Class Initialized
INFO - 2022-12-16 09:24:17 --> Loader Class Initialized
INFO - 2022-12-16 09:24:17 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:17 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:17 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:17 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:17 --> Controller Class Initialized
INFO - 2022-12-16 09:24:17 --> Final output sent to browser
DEBUG - 2022-12-16 09:24:17 --> Total execution time: 0.0747
INFO - 2022-12-16 09:24:17 --> Config Class Initialized
INFO - 2022-12-16 09:24:17 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:17 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:17 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:17 --> URI Class Initialized
INFO - 2022-12-16 09:24:17 --> Router Class Initialized
INFO - 2022-12-16 09:24:17 --> Output Class Initialized
INFO - 2022-12-16 09:24:17 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:17 --> Input Class Initialized
INFO - 2022-12-16 09:24:17 --> Language Class Initialized
INFO - 2022-12-16 09:24:17 --> Language Class Initialized
INFO - 2022-12-16 09:24:17 --> Config Class Initialized
INFO - 2022-12-16 09:24:17 --> Loader Class Initialized
INFO - 2022-12-16 09:24:17 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:17 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:17 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:17 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:17 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:17 --> Controller Class Initialized
INFO - 2022-12-16 09:24:21 --> Config Class Initialized
INFO - 2022-12-16 09:24:21 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:21 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:21 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:21 --> URI Class Initialized
INFO - 2022-12-16 09:24:21 --> Router Class Initialized
INFO - 2022-12-16 09:24:21 --> Output Class Initialized
INFO - 2022-12-16 09:24:21 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:21 --> Input Class Initialized
INFO - 2022-12-16 09:24:21 --> Language Class Initialized
INFO - 2022-12-16 09:24:21 --> Language Class Initialized
INFO - 2022-12-16 09:24:21 --> Config Class Initialized
INFO - 2022-12-16 09:24:21 --> Loader Class Initialized
INFO - 2022-12-16 09:24:21 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:21 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:21 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:21 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:21 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:21 --> Controller Class Initialized
DEBUG - 2022-12-16 09:24:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:24:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:24:21 --> Final output sent to browser
DEBUG - 2022-12-16 09:24:21 --> Total execution time: 0.0672
INFO - 2022-12-16 09:24:21 --> Config Class Initialized
INFO - 2022-12-16 09:24:21 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:21 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:21 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:21 --> URI Class Initialized
INFO - 2022-12-16 09:24:21 --> Router Class Initialized
INFO - 2022-12-16 09:24:21 --> Output Class Initialized
INFO - 2022-12-16 09:24:21 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:21 --> Input Class Initialized
INFO - 2022-12-16 09:24:21 --> Language Class Initialized
INFO - 2022-12-16 09:24:21 --> Language Class Initialized
INFO - 2022-12-16 09:24:21 --> Config Class Initialized
INFO - 2022-12-16 09:24:21 --> Loader Class Initialized
INFO - 2022-12-16 09:24:21 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:21 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:21 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:21 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:21 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:21 --> Controller Class Initialized
INFO - 2022-12-16 09:24:44 --> Config Class Initialized
INFO - 2022-12-16 09:24:44 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:44 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:44 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:44 --> URI Class Initialized
INFO - 2022-12-16 09:24:44 --> Router Class Initialized
INFO - 2022-12-16 09:24:44 --> Output Class Initialized
INFO - 2022-12-16 09:24:44 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:44 --> Input Class Initialized
INFO - 2022-12-16 09:24:44 --> Language Class Initialized
INFO - 2022-12-16 09:24:44 --> Language Class Initialized
INFO - 2022-12-16 09:24:44 --> Config Class Initialized
INFO - 2022-12-16 09:24:44 --> Loader Class Initialized
INFO - 2022-12-16 09:24:44 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:44 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:44 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:44 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:44 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:44 --> Controller Class Initialized
INFO - 2022-12-16 09:24:44 --> Config Class Initialized
INFO - 2022-12-16 09:24:44 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:44 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:44 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:44 --> URI Class Initialized
INFO - 2022-12-16 09:24:44 --> Router Class Initialized
INFO - 2022-12-16 09:24:44 --> Output Class Initialized
INFO - 2022-12-16 09:24:44 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:44 --> Input Class Initialized
INFO - 2022-12-16 09:24:44 --> Language Class Initialized
INFO - 2022-12-16 09:24:44 --> Language Class Initialized
INFO - 2022-12-16 09:24:44 --> Config Class Initialized
INFO - 2022-12-16 09:24:44 --> Loader Class Initialized
INFO - 2022-12-16 09:24:44 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:44 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:44 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:44 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:44 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:44 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:44 --> Controller Class Initialized
INFO - 2022-12-16 09:24:45 --> Config Class Initialized
INFO - 2022-12-16 09:24:45 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:45 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:45 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:45 --> URI Class Initialized
INFO - 2022-12-16 09:24:45 --> Router Class Initialized
INFO - 2022-12-16 09:24:45 --> Output Class Initialized
INFO - 2022-12-16 09:24:45 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:45 --> Input Class Initialized
INFO - 2022-12-16 09:24:45 --> Language Class Initialized
INFO - 2022-12-16 09:24:45 --> Language Class Initialized
INFO - 2022-12-16 09:24:45 --> Config Class Initialized
INFO - 2022-12-16 09:24:45 --> Loader Class Initialized
INFO - 2022-12-16 09:24:45 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:45 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:45 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:45 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:45 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:45 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:45 --> Controller Class Initialized
INFO - 2022-12-16 09:24:46 --> Config Class Initialized
INFO - 2022-12-16 09:24:46 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:46 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:46 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:46 --> URI Class Initialized
INFO - 2022-12-16 09:24:46 --> Router Class Initialized
INFO - 2022-12-16 09:24:46 --> Output Class Initialized
INFO - 2022-12-16 09:24:46 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:46 --> Input Class Initialized
INFO - 2022-12-16 09:24:46 --> Language Class Initialized
INFO - 2022-12-16 09:24:46 --> Language Class Initialized
INFO - 2022-12-16 09:24:46 --> Config Class Initialized
INFO - 2022-12-16 09:24:46 --> Loader Class Initialized
INFO - 2022-12-16 09:24:46 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:46 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:46 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:46 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:46 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:47 --> Controller Class Initialized
INFO - 2022-12-16 09:24:50 --> Config Class Initialized
INFO - 2022-12-16 09:24:50 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:24:50 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:24:50 --> Utf8 Class Initialized
INFO - 2022-12-16 09:24:50 --> URI Class Initialized
INFO - 2022-12-16 09:24:50 --> Router Class Initialized
INFO - 2022-12-16 09:24:50 --> Output Class Initialized
INFO - 2022-12-16 09:24:50 --> Security Class Initialized
DEBUG - 2022-12-16 09:24:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:24:50 --> Input Class Initialized
INFO - 2022-12-16 09:24:50 --> Language Class Initialized
INFO - 2022-12-16 09:24:50 --> Language Class Initialized
INFO - 2022-12-16 09:24:50 --> Config Class Initialized
INFO - 2022-12-16 09:24:50 --> Loader Class Initialized
INFO - 2022-12-16 09:24:50 --> Helper loaded: url_helper
INFO - 2022-12-16 09:24:50 --> Helper loaded: file_helper
INFO - 2022-12-16 09:24:50 --> Helper loaded: form_helper
INFO - 2022-12-16 09:24:50 --> Helper loaded: my_helper
INFO - 2022-12-16 09:24:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:24:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:24:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:24:50 --> Controller Class Initialized
DEBUG - 2022-12-16 09:24:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:24:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:24:50 --> Final output sent to browser
DEBUG - 2022-12-16 09:24:50 --> Total execution time: 0.0799
INFO - 2022-12-16 09:25:21 --> Config Class Initialized
INFO - 2022-12-16 09:25:21 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:21 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:21 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:21 --> URI Class Initialized
INFO - 2022-12-16 09:25:21 --> Router Class Initialized
INFO - 2022-12-16 09:25:21 --> Output Class Initialized
INFO - 2022-12-16 09:25:21 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:21 --> Input Class Initialized
INFO - 2022-12-16 09:25:21 --> Language Class Initialized
INFO - 2022-12-16 09:25:21 --> Language Class Initialized
INFO - 2022-12-16 09:25:21 --> Config Class Initialized
INFO - 2022-12-16 09:25:21 --> Loader Class Initialized
INFO - 2022-12-16 09:25:21 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:21 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:21 --> Controller Class Initialized
INFO - 2022-12-16 09:25:21 --> Config Class Initialized
INFO - 2022-12-16 09:25:21 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:21 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:21 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:21 --> URI Class Initialized
INFO - 2022-12-16 09:25:21 --> Router Class Initialized
INFO - 2022-12-16 09:25:21 --> Output Class Initialized
INFO - 2022-12-16 09:25:21 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:21 --> Input Class Initialized
INFO - 2022-12-16 09:25:21 --> Language Class Initialized
INFO - 2022-12-16 09:25:21 --> Language Class Initialized
INFO - 2022-12-16 09:25:21 --> Config Class Initialized
INFO - 2022-12-16 09:25:21 --> Loader Class Initialized
INFO - 2022-12-16 09:25:21 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:21 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:21 --> Controller Class Initialized
DEBUG - 2022-12-16 09:25:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:25:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:25:21 --> Final output sent to browser
DEBUG - 2022-12-16 09:25:21 --> Total execution time: 0.0442
INFO - 2022-12-16 09:25:21 --> Config Class Initialized
INFO - 2022-12-16 09:25:21 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:21 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:21 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:21 --> URI Class Initialized
INFO - 2022-12-16 09:25:21 --> Router Class Initialized
INFO - 2022-12-16 09:25:21 --> Output Class Initialized
INFO - 2022-12-16 09:25:21 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:21 --> Input Class Initialized
INFO - 2022-12-16 09:25:21 --> Language Class Initialized
INFO - 2022-12-16 09:25:21 --> Language Class Initialized
INFO - 2022-12-16 09:25:21 --> Config Class Initialized
INFO - 2022-12-16 09:25:21 --> Loader Class Initialized
INFO - 2022-12-16 09:25:21 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:21 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:21 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:21 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:21 --> Controller Class Initialized
INFO - 2022-12-16 09:25:23 --> Config Class Initialized
INFO - 2022-12-16 09:25:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:23 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:23 --> URI Class Initialized
INFO - 2022-12-16 09:25:23 --> Router Class Initialized
INFO - 2022-12-16 09:25:23 --> Output Class Initialized
INFO - 2022-12-16 09:25:23 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:23 --> Input Class Initialized
INFO - 2022-12-16 09:25:23 --> Language Class Initialized
INFO - 2022-12-16 09:25:23 --> Language Class Initialized
INFO - 2022-12-16 09:25:23 --> Config Class Initialized
INFO - 2022-12-16 09:25:23 --> Loader Class Initialized
INFO - 2022-12-16 09:25:23 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:23 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:23 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:23 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:23 --> Controller Class Initialized
INFO - 2022-12-16 09:25:23 --> Config Class Initialized
INFO - 2022-12-16 09:25:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:23 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:23 --> URI Class Initialized
INFO - 2022-12-16 09:25:23 --> Router Class Initialized
INFO - 2022-12-16 09:25:23 --> Output Class Initialized
INFO - 2022-12-16 09:25:23 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:23 --> Input Class Initialized
INFO - 2022-12-16 09:25:23 --> Language Class Initialized
INFO - 2022-12-16 09:25:23 --> Language Class Initialized
INFO - 2022-12-16 09:25:23 --> Config Class Initialized
INFO - 2022-12-16 09:25:23 --> Loader Class Initialized
INFO - 2022-12-16 09:25:23 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:23 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:23 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:23 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:23 --> Controller Class Initialized
INFO - 2022-12-16 09:25:24 --> Config Class Initialized
INFO - 2022-12-16 09:25:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:24 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:24 --> URI Class Initialized
INFO - 2022-12-16 09:25:24 --> Router Class Initialized
INFO - 2022-12-16 09:25:24 --> Output Class Initialized
INFO - 2022-12-16 09:25:24 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:24 --> Input Class Initialized
INFO - 2022-12-16 09:25:24 --> Language Class Initialized
INFO - 2022-12-16 09:25:24 --> Language Class Initialized
INFO - 2022-12-16 09:25:24 --> Config Class Initialized
INFO - 2022-12-16 09:25:24 --> Loader Class Initialized
INFO - 2022-12-16 09:25:24 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:24 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:24 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:24 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:24 --> Controller Class Initialized
INFO - 2022-12-16 09:25:26 --> Config Class Initialized
INFO - 2022-12-16 09:25:26 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:26 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:26 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:26 --> URI Class Initialized
INFO - 2022-12-16 09:25:26 --> Router Class Initialized
INFO - 2022-12-16 09:25:26 --> Output Class Initialized
INFO - 2022-12-16 09:25:26 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:26 --> Input Class Initialized
INFO - 2022-12-16 09:25:26 --> Language Class Initialized
INFO - 2022-12-16 09:25:26 --> Language Class Initialized
INFO - 2022-12-16 09:25:26 --> Config Class Initialized
INFO - 2022-12-16 09:25:26 --> Loader Class Initialized
INFO - 2022-12-16 09:25:26 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:26 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:26 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:26 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:26 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:26 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:26 --> Controller Class Initialized
DEBUG - 2022-12-16 09:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:25:26 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:25:26 --> Final output sent to browser
DEBUG - 2022-12-16 09:25:26 --> Total execution time: 0.0847
INFO - 2022-12-16 09:25:39 --> Config Class Initialized
INFO - 2022-12-16 09:25:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:39 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:39 --> URI Class Initialized
INFO - 2022-12-16 09:25:39 --> Router Class Initialized
INFO - 2022-12-16 09:25:39 --> Output Class Initialized
INFO - 2022-12-16 09:25:39 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:39 --> Input Class Initialized
INFO - 2022-12-16 09:25:39 --> Language Class Initialized
INFO - 2022-12-16 09:25:39 --> Language Class Initialized
INFO - 2022-12-16 09:25:39 --> Config Class Initialized
INFO - 2022-12-16 09:25:39 --> Loader Class Initialized
INFO - 2022-12-16 09:25:39 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:39 --> Controller Class Initialized
INFO - 2022-12-16 09:25:39 --> Config Class Initialized
INFO - 2022-12-16 09:25:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:39 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:39 --> URI Class Initialized
INFO - 2022-12-16 09:25:39 --> Router Class Initialized
INFO - 2022-12-16 09:25:39 --> Output Class Initialized
INFO - 2022-12-16 09:25:39 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:39 --> Input Class Initialized
INFO - 2022-12-16 09:25:39 --> Language Class Initialized
INFO - 2022-12-16 09:25:39 --> Language Class Initialized
INFO - 2022-12-16 09:25:39 --> Config Class Initialized
INFO - 2022-12-16 09:25:39 --> Loader Class Initialized
INFO - 2022-12-16 09:25:39 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:39 --> Controller Class Initialized
DEBUG - 2022-12-16 09:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:25:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:25:39 --> Final output sent to browser
DEBUG - 2022-12-16 09:25:39 --> Total execution time: 0.0658
INFO - 2022-12-16 09:25:39 --> Config Class Initialized
INFO - 2022-12-16 09:25:39 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:39 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:39 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:39 --> URI Class Initialized
INFO - 2022-12-16 09:25:39 --> Router Class Initialized
INFO - 2022-12-16 09:25:39 --> Output Class Initialized
INFO - 2022-12-16 09:25:39 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:39 --> Input Class Initialized
INFO - 2022-12-16 09:25:39 --> Language Class Initialized
INFO - 2022-12-16 09:25:39 --> Language Class Initialized
INFO - 2022-12-16 09:25:39 --> Config Class Initialized
INFO - 2022-12-16 09:25:39 --> Loader Class Initialized
INFO - 2022-12-16 09:25:39 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:39 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:39 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:39 --> Controller Class Initialized
INFO - 2022-12-16 09:25:49 --> Config Class Initialized
INFO - 2022-12-16 09:25:49 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:25:49 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:25:49 --> Utf8 Class Initialized
INFO - 2022-12-16 09:25:49 --> URI Class Initialized
INFO - 2022-12-16 09:25:49 --> Router Class Initialized
INFO - 2022-12-16 09:25:49 --> Output Class Initialized
INFO - 2022-12-16 09:25:49 --> Security Class Initialized
DEBUG - 2022-12-16 09:25:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:25:49 --> Input Class Initialized
INFO - 2022-12-16 09:25:49 --> Language Class Initialized
INFO - 2022-12-16 09:25:49 --> Language Class Initialized
INFO - 2022-12-16 09:25:50 --> Config Class Initialized
INFO - 2022-12-16 09:25:50 --> Loader Class Initialized
INFO - 2022-12-16 09:25:50 --> Helper loaded: url_helper
INFO - 2022-12-16 09:25:50 --> Helper loaded: file_helper
INFO - 2022-12-16 09:25:50 --> Helper loaded: form_helper
INFO - 2022-12-16 09:25:50 --> Helper loaded: my_helper
INFO - 2022-12-16 09:25:50 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:25:50 --> Controller Class Initialized
DEBUG - 2022-12-16 09:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:25:50 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:25:50 --> Final output sent to browser
DEBUG - 2022-12-16 09:25:50 --> Total execution time: 0.0931
INFO - 2022-12-16 09:26:01 --> Config Class Initialized
INFO - 2022-12-16 09:26:01 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:01 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:01 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:01 --> URI Class Initialized
INFO - 2022-12-16 09:26:01 --> Router Class Initialized
INFO - 2022-12-16 09:26:01 --> Output Class Initialized
INFO - 2022-12-16 09:26:01 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:01 --> Input Class Initialized
INFO - 2022-12-16 09:26:01 --> Language Class Initialized
INFO - 2022-12-16 09:26:01 --> Language Class Initialized
INFO - 2022-12-16 09:26:01 --> Config Class Initialized
INFO - 2022-12-16 09:26:01 --> Loader Class Initialized
INFO - 2022-12-16 09:26:01 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:01 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:01 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:01 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:01 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:01 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:01 --> Controller Class Initialized
INFO - 2022-12-16 09:26:01 --> Config Class Initialized
INFO - 2022-12-16 09:26:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:02 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:02 --> URI Class Initialized
INFO - 2022-12-16 09:26:02 --> Router Class Initialized
INFO - 2022-12-16 09:26:02 --> Output Class Initialized
INFO - 2022-12-16 09:26:02 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:02 --> Input Class Initialized
INFO - 2022-12-16 09:26:02 --> Language Class Initialized
INFO - 2022-12-16 09:26:02 --> Language Class Initialized
INFO - 2022-12-16 09:26:02 --> Config Class Initialized
INFO - 2022-12-16 09:26:02 --> Loader Class Initialized
INFO - 2022-12-16 09:26:02 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:02 --> Controller Class Initialized
DEBUG - 2022-12-16 09:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:26:02 --> Final output sent to browser
DEBUG - 2022-12-16 09:26:02 --> Total execution time: 0.0484
INFO - 2022-12-16 09:26:02 --> Config Class Initialized
INFO - 2022-12-16 09:26:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:02 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:02 --> URI Class Initialized
INFO - 2022-12-16 09:26:02 --> Router Class Initialized
INFO - 2022-12-16 09:26:02 --> Output Class Initialized
INFO - 2022-12-16 09:26:02 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:02 --> Input Class Initialized
INFO - 2022-12-16 09:26:02 --> Language Class Initialized
INFO - 2022-12-16 09:26:02 --> Language Class Initialized
INFO - 2022-12-16 09:26:02 --> Config Class Initialized
INFO - 2022-12-16 09:26:02 --> Loader Class Initialized
INFO - 2022-12-16 09:26:02 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:02 --> Controller Class Initialized
INFO - 2022-12-16 09:26:02 --> Config Class Initialized
INFO - 2022-12-16 09:26:02 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:02 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:02 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:02 --> URI Class Initialized
INFO - 2022-12-16 09:26:02 --> Router Class Initialized
INFO - 2022-12-16 09:26:02 --> Output Class Initialized
INFO - 2022-12-16 09:26:02 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:02 --> Input Class Initialized
INFO - 2022-12-16 09:26:02 --> Language Class Initialized
INFO - 2022-12-16 09:26:02 --> Language Class Initialized
INFO - 2022-12-16 09:26:02 --> Config Class Initialized
INFO - 2022-12-16 09:26:02 --> Loader Class Initialized
INFO - 2022-12-16 09:26:02 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:02 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:02 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:02 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:02 --> Controller Class Initialized
DEBUG - 2022-12-16 09:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/form.php
DEBUG - 2022-12-16 09:26:02 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:26:02 --> Final output sent to browser
DEBUG - 2022-12-16 09:26:02 --> Total execution time: 0.0781
INFO - 2022-12-16 09:26:22 --> Config Class Initialized
INFO - 2022-12-16 09:26:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:22 --> URI Class Initialized
INFO - 2022-12-16 09:26:22 --> Router Class Initialized
INFO - 2022-12-16 09:26:22 --> Output Class Initialized
INFO - 2022-12-16 09:26:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:22 --> Input Class Initialized
INFO - 2022-12-16 09:26:22 --> Language Class Initialized
INFO - 2022-12-16 09:26:22 --> Language Class Initialized
INFO - 2022-12-16 09:26:22 --> Config Class Initialized
INFO - 2022-12-16 09:26:22 --> Loader Class Initialized
INFO - 2022-12-16 09:26:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:22 --> Controller Class Initialized
INFO - 2022-12-16 09:26:22 --> Config Class Initialized
INFO - 2022-12-16 09:26:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:22 --> URI Class Initialized
INFO - 2022-12-16 09:26:22 --> Router Class Initialized
INFO - 2022-12-16 09:26:22 --> Output Class Initialized
INFO - 2022-12-16 09:26:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:22 --> Input Class Initialized
INFO - 2022-12-16 09:26:22 --> Language Class Initialized
INFO - 2022-12-16 09:26:22 --> Language Class Initialized
INFO - 2022-12-16 09:26:22 --> Config Class Initialized
INFO - 2022-12-16 09:26:22 --> Loader Class Initialized
INFO - 2022-12-16 09:26:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:22 --> Controller Class Initialized
DEBUG - 2022-12-16 09:26:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/set_mapel/views/list.php
DEBUG - 2022-12-16 09:26:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2022-12-16 09:26:22 --> Final output sent to browser
DEBUG - 2022-12-16 09:26:22 --> Total execution time: 0.0740
INFO - 2022-12-16 09:26:22 --> Config Class Initialized
INFO - 2022-12-16 09:26:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:22 --> URI Class Initialized
INFO - 2022-12-16 09:26:22 --> Router Class Initialized
INFO - 2022-12-16 09:26:22 --> Output Class Initialized
INFO - 2022-12-16 09:26:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:22 --> Input Class Initialized
INFO - 2022-12-16 09:26:22 --> Language Class Initialized
INFO - 2022-12-16 09:26:22 --> Language Class Initialized
INFO - 2022-12-16 09:26:22 --> Config Class Initialized
INFO - 2022-12-16 09:26:22 --> Loader Class Initialized
INFO - 2022-12-16 09:26:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:22 --> Controller Class Initialized
INFO - 2022-12-16 09:26:24 --> Config Class Initialized
INFO - 2022-12-16 09:26:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:24 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:24 --> URI Class Initialized
INFO - 2022-12-16 09:26:24 --> Router Class Initialized
INFO - 2022-12-16 09:26:24 --> Output Class Initialized
INFO - 2022-12-16 09:26:24 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:24 --> Input Class Initialized
INFO - 2022-12-16 09:26:24 --> Language Class Initialized
INFO - 2022-12-16 09:26:24 --> Language Class Initialized
INFO - 2022-12-16 09:26:24 --> Config Class Initialized
INFO - 2022-12-16 09:26:24 --> Loader Class Initialized
INFO - 2022-12-16 09:26:24 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:24 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:24 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:24 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:24 --> Controller Class Initialized
INFO - 2022-12-16 09:26:24 --> Config Class Initialized
INFO - 2022-12-16 09:26:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:24 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:24 --> URI Class Initialized
INFO - 2022-12-16 09:26:24 --> Router Class Initialized
INFO - 2022-12-16 09:26:24 --> Output Class Initialized
INFO - 2022-12-16 09:26:24 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:24 --> Input Class Initialized
INFO - 2022-12-16 09:26:24 --> Language Class Initialized
INFO - 2022-12-16 09:26:24 --> Language Class Initialized
INFO - 2022-12-16 09:26:24 --> Config Class Initialized
INFO - 2022-12-16 09:26:24 --> Loader Class Initialized
INFO - 2022-12-16 09:26:24 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:24 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:24 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:24 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:24 --> Controller Class Initialized
INFO - 2022-12-16 09:26:25 --> Config Class Initialized
INFO - 2022-12-16 09:26:25 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:25 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:25 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:25 --> URI Class Initialized
INFO - 2022-12-16 09:26:25 --> Router Class Initialized
INFO - 2022-12-16 09:26:25 --> Output Class Initialized
INFO - 2022-12-16 09:26:25 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:25 --> Input Class Initialized
INFO - 2022-12-16 09:26:25 --> Language Class Initialized
INFO - 2022-12-16 09:26:25 --> Language Class Initialized
INFO - 2022-12-16 09:26:25 --> Config Class Initialized
INFO - 2022-12-16 09:26:25 --> Loader Class Initialized
INFO - 2022-12-16 09:26:25 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:25 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:25 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:25 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:25 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:25 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:25 --> Controller Class Initialized
INFO - 2022-12-16 09:26:30 --> Config Class Initialized
INFO - 2022-12-16 09:26:30 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:26:30 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:26:30 --> Utf8 Class Initialized
INFO - 2022-12-16 09:26:30 --> URI Class Initialized
INFO - 2022-12-16 09:26:30 --> Router Class Initialized
INFO - 2022-12-16 09:26:30 --> Output Class Initialized
INFO - 2022-12-16 09:26:30 --> Security Class Initialized
DEBUG - 2022-12-16 09:26:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:26:30 --> Input Class Initialized
INFO - 2022-12-16 09:26:30 --> Language Class Initialized
INFO - 2022-12-16 09:26:30 --> Language Class Initialized
INFO - 2022-12-16 09:26:30 --> Config Class Initialized
INFO - 2022-12-16 09:26:30 --> Loader Class Initialized
INFO - 2022-12-16 09:26:30 --> Helper loaded: url_helper
INFO - 2022-12-16 09:26:30 --> Helper loaded: file_helper
INFO - 2022-12-16 09:26:30 --> Helper loaded: form_helper
INFO - 2022-12-16 09:26:30 --> Helper loaded: my_helper
INFO - 2022-12-16 09:26:30 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:26:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:26:30 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:26:30 --> Controller Class Initialized
INFO - 2022-12-16 09:28:23 --> Config Class Initialized
INFO - 2022-12-16 09:28:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:28:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:28:23 --> Utf8 Class Initialized
INFO - 2022-12-16 09:28:23 --> URI Class Initialized
INFO - 2022-12-16 09:28:23 --> Router Class Initialized
INFO - 2022-12-16 09:28:23 --> Output Class Initialized
INFO - 2022-12-16 09:28:23 --> Security Class Initialized
DEBUG - 2022-12-16 09:28:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:28:23 --> Input Class Initialized
INFO - 2022-12-16 09:28:23 --> Language Class Initialized
INFO - 2022-12-16 09:28:23 --> Language Class Initialized
INFO - 2022-12-16 09:28:23 --> Config Class Initialized
INFO - 2022-12-16 09:28:23 --> Loader Class Initialized
INFO - 2022-12-16 09:28:23 --> Helper loaded: url_helper
INFO - 2022-12-16 09:28:23 --> Helper loaded: file_helper
INFO - 2022-12-16 09:28:23 --> Helper loaded: form_helper
INFO - 2022-12-16 09:28:23 --> Helper loaded: my_helper
INFO - 2022-12-16 09:28:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:28:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:28:23 --> Controller Class Initialized
INFO - 2022-12-16 09:30:03 --> Config Class Initialized
INFO - 2022-12-16 09:30:03 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:30:03 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:30:03 --> Utf8 Class Initialized
INFO - 2022-12-16 09:30:03 --> URI Class Initialized
INFO - 2022-12-16 09:30:03 --> Router Class Initialized
INFO - 2022-12-16 09:30:03 --> Output Class Initialized
INFO - 2022-12-16 09:30:03 --> Security Class Initialized
DEBUG - 2022-12-16 09:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:30:03 --> Input Class Initialized
INFO - 2022-12-16 09:30:03 --> Language Class Initialized
INFO - 2022-12-16 09:30:03 --> Language Class Initialized
INFO - 2022-12-16 09:30:03 --> Config Class Initialized
INFO - 2022-12-16 09:30:03 --> Loader Class Initialized
INFO - 2022-12-16 09:30:03 --> Helper loaded: url_helper
INFO - 2022-12-16 09:30:03 --> Helper loaded: file_helper
INFO - 2022-12-16 09:30:03 --> Helper loaded: form_helper
INFO - 2022-12-16 09:30:03 --> Helper loaded: my_helper
INFO - 2022-12-16 09:30:03 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:30:03 --> Controller Class Initialized
INFO - 2022-12-16 09:30:37 --> Config Class Initialized
INFO - 2022-12-16 09:30:37 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:30:37 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:30:37 --> Utf8 Class Initialized
INFO - 2022-12-16 09:30:37 --> URI Class Initialized
INFO - 2022-12-16 09:30:37 --> Router Class Initialized
INFO - 2022-12-16 09:30:37 --> Output Class Initialized
INFO - 2022-12-16 09:30:37 --> Security Class Initialized
DEBUG - 2022-12-16 09:30:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:30:37 --> Input Class Initialized
INFO - 2022-12-16 09:30:37 --> Language Class Initialized
INFO - 2022-12-16 09:30:37 --> Language Class Initialized
INFO - 2022-12-16 09:30:37 --> Config Class Initialized
INFO - 2022-12-16 09:30:37 --> Loader Class Initialized
INFO - 2022-12-16 09:30:37 --> Helper loaded: url_helper
INFO - 2022-12-16 09:30:37 --> Helper loaded: file_helper
INFO - 2022-12-16 09:30:37 --> Helper loaded: form_helper
INFO - 2022-12-16 09:30:37 --> Helper loaded: my_helper
INFO - 2022-12-16 09:30:37 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:30:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:30:37 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:30:37 --> Controller Class Initialized
INFO - 2022-12-16 09:31:11 --> Config Class Initialized
INFO - 2022-12-16 09:31:11 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:31:11 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:31:11 --> Utf8 Class Initialized
INFO - 2022-12-16 09:31:11 --> URI Class Initialized
INFO - 2022-12-16 09:31:11 --> Router Class Initialized
INFO - 2022-12-16 09:31:11 --> Output Class Initialized
INFO - 2022-12-16 09:31:11 --> Security Class Initialized
DEBUG - 2022-12-16 09:31:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:31:11 --> Input Class Initialized
INFO - 2022-12-16 09:31:11 --> Language Class Initialized
INFO - 2022-12-16 09:31:11 --> Language Class Initialized
INFO - 2022-12-16 09:31:11 --> Config Class Initialized
INFO - 2022-12-16 09:31:11 --> Loader Class Initialized
INFO - 2022-12-16 09:31:11 --> Helper loaded: url_helper
INFO - 2022-12-16 09:31:11 --> Helper loaded: file_helper
INFO - 2022-12-16 09:31:11 --> Helper loaded: form_helper
INFO - 2022-12-16 09:31:11 --> Helper loaded: my_helper
INFO - 2022-12-16 09:31:11 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:31:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:31:11 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:31:11 --> Controller Class Initialized
INFO - 2022-12-16 09:31:47 --> Config Class Initialized
INFO - 2022-12-16 09:31:47 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:31:47 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:31:47 --> Utf8 Class Initialized
INFO - 2022-12-16 09:31:47 --> URI Class Initialized
INFO - 2022-12-16 09:31:47 --> Router Class Initialized
INFO - 2022-12-16 09:31:47 --> Output Class Initialized
INFO - 2022-12-16 09:31:47 --> Security Class Initialized
DEBUG - 2022-12-16 09:31:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:31:47 --> Input Class Initialized
INFO - 2022-12-16 09:31:47 --> Language Class Initialized
INFO - 2022-12-16 09:31:47 --> Language Class Initialized
INFO - 2022-12-16 09:31:47 --> Config Class Initialized
INFO - 2022-12-16 09:31:47 --> Loader Class Initialized
INFO - 2022-12-16 09:31:47 --> Helper loaded: url_helper
INFO - 2022-12-16 09:31:47 --> Helper loaded: file_helper
INFO - 2022-12-16 09:31:47 --> Helper loaded: form_helper
INFO - 2022-12-16 09:31:47 --> Helper loaded: my_helper
INFO - 2022-12-16 09:31:47 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:31:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:31:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:31:47 --> Controller Class Initialized
INFO - 2022-12-16 09:35:22 --> Config Class Initialized
INFO - 2022-12-16 09:35:22 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:35:22 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:35:22 --> Utf8 Class Initialized
INFO - 2022-12-16 09:35:22 --> URI Class Initialized
INFO - 2022-12-16 09:35:22 --> Router Class Initialized
INFO - 2022-12-16 09:35:22 --> Output Class Initialized
INFO - 2022-12-16 09:35:22 --> Security Class Initialized
DEBUG - 2022-12-16 09:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:35:22 --> Input Class Initialized
INFO - 2022-12-16 09:35:22 --> Language Class Initialized
INFO - 2022-12-16 09:35:22 --> Language Class Initialized
INFO - 2022-12-16 09:35:22 --> Config Class Initialized
INFO - 2022-12-16 09:35:22 --> Loader Class Initialized
INFO - 2022-12-16 09:35:22 --> Helper loaded: url_helper
INFO - 2022-12-16 09:35:22 --> Helper loaded: file_helper
INFO - 2022-12-16 09:35:22 --> Helper loaded: form_helper
INFO - 2022-12-16 09:35:22 --> Helper loaded: my_helper
INFO - 2022-12-16 09:35:22 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:35:22 --> Controller Class Initialized
INFO - 2022-12-16 09:35:48 --> Config Class Initialized
INFO - 2022-12-16 09:35:48 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:35:48 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:35:48 --> Utf8 Class Initialized
INFO - 2022-12-16 09:35:48 --> URI Class Initialized
INFO - 2022-12-16 09:35:48 --> Router Class Initialized
INFO - 2022-12-16 09:35:48 --> Output Class Initialized
INFO - 2022-12-16 09:35:48 --> Security Class Initialized
DEBUG - 2022-12-16 09:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:35:48 --> Input Class Initialized
INFO - 2022-12-16 09:35:48 --> Language Class Initialized
INFO - 2022-12-16 09:35:48 --> Language Class Initialized
INFO - 2022-12-16 09:35:48 --> Config Class Initialized
INFO - 2022-12-16 09:35:48 --> Loader Class Initialized
INFO - 2022-12-16 09:35:48 --> Helper loaded: url_helper
INFO - 2022-12-16 09:35:48 --> Helper loaded: file_helper
INFO - 2022-12-16 09:35:48 --> Helper loaded: form_helper
INFO - 2022-12-16 09:35:48 --> Helper loaded: my_helper
INFO - 2022-12-16 09:35:48 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:35:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:35:48 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:35:48 --> Controller Class Initialized
INFO - 2022-12-16 09:36:24 --> Config Class Initialized
INFO - 2022-12-16 09:36:24 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:36:24 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:36:24 --> Utf8 Class Initialized
INFO - 2022-12-16 09:36:24 --> URI Class Initialized
INFO - 2022-12-16 09:36:24 --> Router Class Initialized
INFO - 2022-12-16 09:36:24 --> Output Class Initialized
INFO - 2022-12-16 09:36:24 --> Security Class Initialized
DEBUG - 2022-12-16 09:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:36:24 --> Input Class Initialized
INFO - 2022-12-16 09:36:24 --> Language Class Initialized
INFO - 2022-12-16 09:36:24 --> Language Class Initialized
INFO - 2022-12-16 09:36:24 --> Config Class Initialized
INFO - 2022-12-16 09:36:24 --> Loader Class Initialized
INFO - 2022-12-16 09:36:24 --> Helper loaded: url_helper
INFO - 2022-12-16 09:36:24 --> Helper loaded: file_helper
INFO - 2022-12-16 09:36:24 --> Helper loaded: form_helper
INFO - 2022-12-16 09:36:24 --> Helper loaded: my_helper
INFO - 2022-12-16 09:36:24 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:36:24 --> Controller Class Initialized
INFO - 2022-12-16 09:36:54 --> Config Class Initialized
INFO - 2022-12-16 09:36:54 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:36:54 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:36:54 --> Utf8 Class Initialized
INFO - 2022-12-16 09:36:54 --> URI Class Initialized
INFO - 2022-12-16 09:36:54 --> Router Class Initialized
INFO - 2022-12-16 09:36:54 --> Output Class Initialized
INFO - 2022-12-16 09:36:54 --> Security Class Initialized
DEBUG - 2022-12-16 09:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:36:54 --> Input Class Initialized
INFO - 2022-12-16 09:36:54 --> Language Class Initialized
INFO - 2022-12-16 09:36:54 --> Language Class Initialized
INFO - 2022-12-16 09:36:54 --> Config Class Initialized
INFO - 2022-12-16 09:36:54 --> Loader Class Initialized
INFO - 2022-12-16 09:36:55 --> Helper loaded: url_helper
INFO - 2022-12-16 09:36:55 --> Helper loaded: file_helper
INFO - 2022-12-16 09:36:55 --> Helper loaded: form_helper
INFO - 2022-12-16 09:36:55 --> Helper loaded: my_helper
INFO - 2022-12-16 09:36:55 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:36:55 --> Controller Class Initialized
INFO - 2022-12-16 09:37:23 --> Config Class Initialized
INFO - 2022-12-16 09:37:23 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:37:23 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:37:23 --> Utf8 Class Initialized
INFO - 2022-12-16 09:37:23 --> URI Class Initialized
INFO - 2022-12-16 09:37:23 --> Router Class Initialized
INFO - 2022-12-16 09:37:23 --> Output Class Initialized
INFO - 2022-12-16 09:37:23 --> Security Class Initialized
DEBUG - 2022-12-16 09:37:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:37:23 --> Input Class Initialized
INFO - 2022-12-16 09:37:23 --> Language Class Initialized
INFO - 2022-12-16 09:37:23 --> Language Class Initialized
INFO - 2022-12-16 09:37:23 --> Config Class Initialized
INFO - 2022-12-16 09:37:23 --> Loader Class Initialized
INFO - 2022-12-16 09:37:23 --> Helper loaded: url_helper
INFO - 2022-12-16 09:37:23 --> Helper loaded: file_helper
INFO - 2022-12-16 09:37:23 --> Helper loaded: form_helper
INFO - 2022-12-16 09:37:23 --> Helper loaded: my_helper
INFO - 2022-12-16 09:37:23 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:37:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:37:23 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:37:23 --> Controller Class Initialized
INFO - 2022-12-16 09:38:15 --> Config Class Initialized
INFO - 2022-12-16 09:38:15 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:38:15 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:38:15 --> Utf8 Class Initialized
INFO - 2022-12-16 09:38:15 --> URI Class Initialized
INFO - 2022-12-16 09:38:15 --> Router Class Initialized
INFO - 2022-12-16 09:38:15 --> Output Class Initialized
INFO - 2022-12-16 09:38:15 --> Security Class Initialized
DEBUG - 2022-12-16 09:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:38:15 --> Input Class Initialized
INFO - 2022-12-16 09:38:15 --> Language Class Initialized
INFO - 2022-12-16 09:38:15 --> Language Class Initialized
INFO - 2022-12-16 09:38:15 --> Config Class Initialized
INFO - 2022-12-16 09:38:15 --> Loader Class Initialized
INFO - 2022-12-16 09:38:15 --> Helper loaded: url_helper
INFO - 2022-12-16 09:38:15 --> Helper loaded: file_helper
INFO - 2022-12-16 09:38:15 --> Helper loaded: form_helper
INFO - 2022-12-16 09:38:15 --> Helper loaded: my_helper
INFO - 2022-12-16 09:38:15 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:38:15 --> Controller Class Initialized
INFO - 2022-12-16 09:38:47 --> Config Class Initialized
INFO - 2022-12-16 09:38:47 --> Hooks Class Initialized
DEBUG - 2022-12-16 09:38:47 --> UTF-8 Support Enabled
INFO - 2022-12-16 09:38:47 --> Utf8 Class Initialized
INFO - 2022-12-16 09:38:47 --> URI Class Initialized
INFO - 2022-12-16 09:38:47 --> Router Class Initialized
INFO - 2022-12-16 09:38:47 --> Output Class Initialized
INFO - 2022-12-16 09:38:47 --> Security Class Initialized
DEBUG - 2022-12-16 09:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2022-12-16 09:38:47 --> Input Class Initialized
INFO - 2022-12-16 09:38:47 --> Language Class Initialized
INFO - 2022-12-16 09:38:47 --> Language Class Initialized
INFO - 2022-12-16 09:38:47 --> Config Class Initialized
INFO - 2022-12-16 09:38:47 --> Loader Class Initialized
INFO - 2022-12-16 09:38:47 --> Helper loaded: url_helper
INFO - 2022-12-16 09:38:47 --> Helper loaded: file_helper
INFO - 2022-12-16 09:38:47 --> Helper loaded: form_helper
INFO - 2022-12-16 09:38:47 --> Helper loaded: my_helper
INFO - 2022-12-16 09:38:47 --> Database Driver Class Initialized
DEBUG - 2022-12-16 09:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2022-12-16 09:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2022-12-16 09:38:47 --> Controller Class Initialized
