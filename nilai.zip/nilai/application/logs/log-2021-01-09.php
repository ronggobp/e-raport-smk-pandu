<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-01-09 01:58:40 --> Config Class Initialized
INFO - 2021-01-09 01:58:40 --> Hooks Class Initialized
DEBUG - 2021-01-09 01:58:40 --> UTF-8 Support Enabled
INFO - 2021-01-09 01:58:40 --> Utf8 Class Initialized
INFO - 2021-01-09 01:58:40 --> URI Class Initialized
DEBUG - 2021-01-09 01:58:40 --> No URI present. Default controller set.
INFO - 2021-01-09 01:58:40 --> Router Class Initialized
INFO - 2021-01-09 01:58:40 --> Output Class Initialized
INFO - 2021-01-09 01:58:40 --> Security Class Initialized
DEBUG - 2021-01-09 01:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 01:58:40 --> Input Class Initialized
INFO - 2021-01-09 01:58:40 --> Language Class Initialized
INFO - 2021-01-09 01:58:40 --> Language Class Initialized
INFO - 2021-01-09 01:58:40 --> Config Class Initialized
INFO - 2021-01-09 01:58:40 --> Loader Class Initialized
INFO - 2021-01-09 01:58:40 --> Helper loaded: url_helper
INFO - 2021-01-09 01:58:40 --> Helper loaded: file_helper
INFO - 2021-01-09 01:58:40 --> Helper loaded: form_helper
INFO - 2021-01-09 01:58:40 --> Helper loaded: my_helper
INFO - 2021-01-09 01:58:40 --> Database Driver Class Initialized
DEBUG - 2021-01-09 01:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 01:58:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 01:58:40 --> Controller Class Initialized
INFO - 2021-01-09 01:58:40 --> Config Class Initialized
INFO - 2021-01-09 01:58:40 --> Hooks Class Initialized
DEBUG - 2021-01-09 01:58:40 --> UTF-8 Support Enabled
INFO - 2021-01-09 01:58:40 --> Utf8 Class Initialized
INFO - 2021-01-09 01:58:40 --> URI Class Initialized
INFO - 2021-01-09 01:58:40 --> Router Class Initialized
INFO - 2021-01-09 01:58:40 --> Output Class Initialized
INFO - 2021-01-09 01:58:40 --> Security Class Initialized
DEBUG - 2021-01-09 01:58:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 01:58:40 --> Input Class Initialized
INFO - 2021-01-09 01:58:40 --> Language Class Initialized
INFO - 2021-01-09 01:58:40 --> Language Class Initialized
INFO - 2021-01-09 01:58:41 --> Config Class Initialized
INFO - 2021-01-09 01:58:41 --> Loader Class Initialized
INFO - 2021-01-09 01:58:41 --> Helper loaded: url_helper
INFO - 2021-01-09 01:58:41 --> Helper loaded: file_helper
INFO - 2021-01-09 01:58:41 --> Helper loaded: form_helper
INFO - 2021-01-09 01:58:41 --> Helper loaded: my_helper
INFO - 2021-01-09 01:58:41 --> Database Driver Class Initialized
DEBUG - 2021-01-09 01:58:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 01:58:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 01:58:41 --> Controller Class Initialized
DEBUG - 2021-01-09 01:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-09 01:58:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 01:58:41 --> Final output sent to browser
DEBUG - 2021-01-09 01:58:41 --> Total execution time: 0.8060
INFO - 2021-01-09 01:59:12 --> Config Class Initialized
INFO - 2021-01-09 01:59:12 --> Hooks Class Initialized
DEBUG - 2021-01-09 01:59:12 --> UTF-8 Support Enabled
INFO - 2021-01-09 01:59:12 --> Utf8 Class Initialized
INFO - 2021-01-09 01:59:12 --> URI Class Initialized
INFO - 2021-01-09 01:59:12 --> Router Class Initialized
INFO - 2021-01-09 01:59:12 --> Output Class Initialized
INFO - 2021-01-09 01:59:12 --> Security Class Initialized
DEBUG - 2021-01-09 01:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 01:59:12 --> Input Class Initialized
INFO - 2021-01-09 01:59:12 --> Language Class Initialized
INFO - 2021-01-09 01:59:12 --> Language Class Initialized
INFO - 2021-01-09 01:59:12 --> Config Class Initialized
INFO - 2021-01-09 01:59:12 --> Loader Class Initialized
INFO - 2021-01-09 01:59:12 --> Helper loaded: url_helper
INFO - 2021-01-09 01:59:12 --> Helper loaded: file_helper
INFO - 2021-01-09 01:59:12 --> Helper loaded: form_helper
INFO - 2021-01-09 01:59:12 --> Helper loaded: my_helper
INFO - 2021-01-09 01:59:12 --> Database Driver Class Initialized
DEBUG - 2021-01-09 01:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 01:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 01:59:12 --> Controller Class Initialized
INFO - 2021-01-09 01:59:12 --> Helper loaded: cookie_helper
INFO - 2021-01-09 01:59:12 --> Final output sent to browser
DEBUG - 2021-01-09 01:59:12 --> Total execution time: 0.7019
INFO - 2021-01-09 01:59:13 --> Config Class Initialized
INFO - 2021-01-09 01:59:13 --> Hooks Class Initialized
DEBUG - 2021-01-09 01:59:13 --> UTF-8 Support Enabled
INFO - 2021-01-09 01:59:13 --> Utf8 Class Initialized
INFO - 2021-01-09 01:59:13 --> URI Class Initialized
INFO - 2021-01-09 01:59:13 --> Router Class Initialized
INFO - 2021-01-09 01:59:13 --> Output Class Initialized
INFO - 2021-01-09 01:59:13 --> Security Class Initialized
DEBUG - 2021-01-09 01:59:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 01:59:13 --> Input Class Initialized
INFO - 2021-01-09 01:59:14 --> Language Class Initialized
INFO - 2021-01-09 01:59:14 --> Language Class Initialized
INFO - 2021-01-09 01:59:14 --> Config Class Initialized
INFO - 2021-01-09 01:59:14 --> Loader Class Initialized
INFO - 2021-01-09 01:59:14 --> Helper loaded: url_helper
INFO - 2021-01-09 01:59:14 --> Helper loaded: file_helper
INFO - 2021-01-09 01:59:14 --> Helper loaded: form_helper
INFO - 2021-01-09 01:59:14 --> Helper loaded: my_helper
INFO - 2021-01-09 01:59:14 --> Database Driver Class Initialized
DEBUG - 2021-01-09 01:59:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 01:59:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 01:59:14 --> Controller Class Initialized
DEBUG - 2021-01-09 01:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-09 01:59:14 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 01:59:14 --> Final output sent to browser
DEBUG - 2021-01-09 01:59:14 --> Total execution time: 0.8822
INFO - 2021-01-09 02:26:32 --> Config Class Initialized
INFO - 2021-01-09 02:26:32 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:26:32 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:26:32 --> Utf8 Class Initialized
INFO - 2021-01-09 02:26:32 --> URI Class Initialized
INFO - 2021-01-09 02:26:32 --> Router Class Initialized
INFO - 2021-01-09 02:26:32 --> Output Class Initialized
INFO - 2021-01-09 02:26:33 --> Security Class Initialized
DEBUG - 2021-01-09 02:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:26:33 --> Input Class Initialized
INFO - 2021-01-09 02:26:33 --> Language Class Initialized
INFO - 2021-01-09 02:26:33 --> Language Class Initialized
INFO - 2021-01-09 02:26:33 --> Config Class Initialized
INFO - 2021-01-09 02:26:33 --> Loader Class Initialized
INFO - 2021-01-09 02:26:33 --> Helper loaded: url_helper
INFO - 2021-01-09 02:26:33 --> Helper loaded: file_helper
INFO - 2021-01-09 02:26:33 --> Helper loaded: form_helper
INFO - 2021-01-09 02:26:33 --> Helper loaded: my_helper
INFO - 2021-01-09 02:26:33 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:26:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:26:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:26:33 --> Controller Class Initialized
DEBUG - 2021-01-09 02:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:26:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:26:33 --> Final output sent to browser
DEBUG - 2021-01-09 02:26:33 --> Total execution time: 0.2359
INFO - 2021-01-09 02:27:45 --> Config Class Initialized
INFO - 2021-01-09 02:27:45 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:27:45 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:27:45 --> Utf8 Class Initialized
INFO - 2021-01-09 02:27:45 --> URI Class Initialized
INFO - 2021-01-09 02:27:45 --> Router Class Initialized
INFO - 2021-01-09 02:27:45 --> Output Class Initialized
INFO - 2021-01-09 02:27:45 --> Security Class Initialized
DEBUG - 2021-01-09 02:27:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:27:45 --> Input Class Initialized
INFO - 2021-01-09 02:27:45 --> Language Class Initialized
INFO - 2021-01-09 02:27:45 --> Language Class Initialized
INFO - 2021-01-09 02:27:45 --> Config Class Initialized
INFO - 2021-01-09 02:27:45 --> Loader Class Initialized
INFO - 2021-01-09 02:27:45 --> Helper loaded: url_helper
INFO - 2021-01-09 02:27:45 --> Helper loaded: file_helper
INFO - 2021-01-09 02:27:45 --> Helper loaded: form_helper
INFO - 2021-01-09 02:27:45 --> Helper loaded: my_helper
INFO - 2021-01-09 02:27:45 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:27:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:27:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:27:45 --> Controller Class Initialized
DEBUG - 2021-01-09 02:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-09 02:27:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:27:46 --> Final output sent to browser
DEBUG - 2021-01-09 02:27:46 --> Total execution time: 0.2237
INFO - 2021-01-09 02:27:47 --> Config Class Initialized
INFO - 2021-01-09 02:27:47 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:27:47 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:27:47 --> Utf8 Class Initialized
INFO - 2021-01-09 02:27:47 --> URI Class Initialized
INFO - 2021-01-09 02:27:47 --> Router Class Initialized
INFO - 2021-01-09 02:27:47 --> Output Class Initialized
INFO - 2021-01-09 02:27:47 --> Security Class Initialized
DEBUG - 2021-01-09 02:27:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:27:47 --> Input Class Initialized
INFO - 2021-01-09 02:27:47 --> Language Class Initialized
INFO - 2021-01-09 02:27:48 --> Language Class Initialized
INFO - 2021-01-09 02:27:48 --> Config Class Initialized
INFO - 2021-01-09 02:27:48 --> Loader Class Initialized
INFO - 2021-01-09 02:27:48 --> Helper loaded: url_helper
INFO - 2021-01-09 02:27:48 --> Helper loaded: file_helper
INFO - 2021-01-09 02:27:48 --> Helper loaded: form_helper
INFO - 2021-01-09 02:27:48 --> Helper loaded: my_helper
INFO - 2021-01-09 02:27:48 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:27:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:27:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:27:48 --> Controller Class Initialized
DEBUG - 2021-01-09 02:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:27:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:27:48 --> Final output sent to browser
DEBUG - 2021-01-09 02:27:48 --> Total execution time: 0.2237
INFO - 2021-01-09 02:28:27 --> Config Class Initialized
INFO - 2021-01-09 02:28:27 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:28:27 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:28:27 --> Utf8 Class Initialized
INFO - 2021-01-09 02:28:27 --> URI Class Initialized
INFO - 2021-01-09 02:28:27 --> Router Class Initialized
INFO - 2021-01-09 02:28:27 --> Output Class Initialized
INFO - 2021-01-09 02:28:27 --> Security Class Initialized
DEBUG - 2021-01-09 02:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:28:27 --> Input Class Initialized
INFO - 2021-01-09 02:28:27 --> Language Class Initialized
INFO - 2021-01-09 02:28:27 --> Language Class Initialized
INFO - 2021-01-09 02:28:27 --> Config Class Initialized
INFO - 2021-01-09 02:28:27 --> Loader Class Initialized
INFO - 2021-01-09 02:28:27 --> Helper loaded: url_helper
INFO - 2021-01-09 02:28:27 --> Helper loaded: file_helper
INFO - 2021-01-09 02:28:27 --> Helper loaded: form_helper
INFO - 2021-01-09 02:28:27 --> Helper loaded: my_helper
INFO - 2021-01-09 02:28:27 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:28:27 --> Controller Class Initialized
DEBUG - 2021-01-09 02:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:28:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:28:27 --> Final output sent to browser
DEBUG - 2021-01-09 02:28:27 --> Total execution time: 0.2784
INFO - 2021-01-09 02:28:27 --> Config Class Initialized
INFO - 2021-01-09 02:28:27 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:28:27 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:28:27 --> Utf8 Class Initialized
INFO - 2021-01-09 02:28:27 --> URI Class Initialized
INFO - 2021-01-09 02:28:27 --> Router Class Initialized
INFO - 2021-01-09 02:28:27 --> Output Class Initialized
INFO - 2021-01-09 02:28:27 --> Security Class Initialized
DEBUG - 2021-01-09 02:28:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:28:27 --> Input Class Initialized
INFO - 2021-01-09 02:28:27 --> Language Class Initialized
INFO - 2021-01-09 02:28:27 --> Language Class Initialized
INFO - 2021-01-09 02:28:27 --> Config Class Initialized
INFO - 2021-01-09 02:28:27 --> Loader Class Initialized
INFO - 2021-01-09 02:28:27 --> Helper loaded: url_helper
INFO - 2021-01-09 02:28:27 --> Helper loaded: file_helper
INFO - 2021-01-09 02:28:27 --> Helper loaded: form_helper
INFO - 2021-01-09 02:28:27 --> Helper loaded: my_helper
INFO - 2021-01-09 02:28:27 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:28:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:28:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:28:27 --> Controller Class Initialized
INFO - 2021-01-09 02:28:45 --> Config Class Initialized
INFO - 2021-01-09 02:28:45 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:28:45 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:28:45 --> Utf8 Class Initialized
INFO - 2021-01-09 02:28:45 --> URI Class Initialized
INFO - 2021-01-09 02:28:45 --> Router Class Initialized
INFO - 2021-01-09 02:28:45 --> Output Class Initialized
INFO - 2021-01-09 02:28:45 --> Security Class Initialized
DEBUG - 2021-01-09 02:28:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:28:45 --> Input Class Initialized
INFO - 2021-01-09 02:28:45 --> Language Class Initialized
INFO - 2021-01-09 02:28:45 --> Language Class Initialized
INFO - 2021-01-09 02:28:45 --> Config Class Initialized
INFO - 2021-01-09 02:28:45 --> Loader Class Initialized
INFO - 2021-01-09 02:28:45 --> Helper loaded: url_helper
INFO - 2021-01-09 02:28:45 --> Helper loaded: file_helper
INFO - 2021-01-09 02:28:45 --> Helper loaded: form_helper
INFO - 2021-01-09 02:28:45 --> Helper loaded: my_helper
INFO - 2021-01-09 02:28:45 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:28:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:28:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:28:45 --> Controller Class Initialized
INFO - 2021-01-09 02:28:47 --> Config Class Initialized
INFO - 2021-01-09 02:28:47 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:28:47 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:28:47 --> Utf8 Class Initialized
INFO - 2021-01-09 02:28:47 --> URI Class Initialized
INFO - 2021-01-09 02:28:47 --> Router Class Initialized
INFO - 2021-01-09 02:28:47 --> Output Class Initialized
INFO - 2021-01-09 02:28:47 --> Security Class Initialized
DEBUG - 2021-01-09 02:28:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:28:47 --> Input Class Initialized
INFO - 2021-01-09 02:28:47 --> Language Class Initialized
INFO - 2021-01-09 02:28:47 --> Language Class Initialized
INFO - 2021-01-09 02:28:47 --> Config Class Initialized
INFO - 2021-01-09 02:28:47 --> Loader Class Initialized
INFO - 2021-01-09 02:28:47 --> Helper loaded: url_helper
INFO - 2021-01-09 02:28:47 --> Helper loaded: file_helper
INFO - 2021-01-09 02:28:47 --> Helper loaded: form_helper
INFO - 2021-01-09 02:28:47 --> Helper loaded: my_helper
INFO - 2021-01-09 02:28:47 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:28:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:28:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:28:47 --> Controller Class Initialized
DEBUG - 2021-01-09 02:28:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:28:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:28:47 --> Final output sent to browser
DEBUG - 2021-01-09 02:28:47 --> Total execution time: 0.3833
INFO - 2021-01-09 02:28:48 --> Config Class Initialized
INFO - 2021-01-09 02:28:48 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:28:48 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:28:48 --> Utf8 Class Initialized
INFO - 2021-01-09 02:28:48 --> URI Class Initialized
INFO - 2021-01-09 02:28:48 --> Router Class Initialized
INFO - 2021-01-09 02:28:48 --> Output Class Initialized
INFO - 2021-01-09 02:28:48 --> Security Class Initialized
DEBUG - 2021-01-09 02:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:28:48 --> Input Class Initialized
INFO - 2021-01-09 02:28:48 --> Language Class Initialized
INFO - 2021-01-09 02:28:48 --> Language Class Initialized
INFO - 2021-01-09 02:28:48 --> Config Class Initialized
INFO - 2021-01-09 02:28:48 --> Loader Class Initialized
INFO - 2021-01-09 02:28:48 --> Helper loaded: url_helper
INFO - 2021-01-09 02:28:48 --> Helper loaded: file_helper
INFO - 2021-01-09 02:28:48 --> Helper loaded: form_helper
INFO - 2021-01-09 02:28:48 --> Helper loaded: my_helper
INFO - 2021-01-09 02:28:48 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:28:48 --> Controller Class Initialized
DEBUG - 2021-01-09 02:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:28:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:28:48 --> Final output sent to browser
DEBUG - 2021-01-09 02:28:48 --> Total execution time: 0.3423
INFO - 2021-01-09 02:28:56 --> Config Class Initialized
INFO - 2021-01-09 02:28:56 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:28:56 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:28:56 --> Utf8 Class Initialized
INFO - 2021-01-09 02:28:56 --> URI Class Initialized
INFO - 2021-01-09 02:28:56 --> Router Class Initialized
INFO - 2021-01-09 02:28:56 --> Output Class Initialized
INFO - 2021-01-09 02:28:56 --> Security Class Initialized
DEBUG - 2021-01-09 02:28:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:28:56 --> Input Class Initialized
INFO - 2021-01-09 02:28:56 --> Language Class Initialized
INFO - 2021-01-09 02:28:56 --> Language Class Initialized
INFO - 2021-01-09 02:28:56 --> Config Class Initialized
INFO - 2021-01-09 02:28:56 --> Loader Class Initialized
INFO - 2021-01-09 02:28:56 --> Helper loaded: url_helper
INFO - 2021-01-09 02:28:56 --> Helper loaded: file_helper
INFO - 2021-01-09 02:28:56 --> Helper loaded: form_helper
INFO - 2021-01-09 02:28:56 --> Helper loaded: my_helper
INFO - 2021-01-09 02:28:56 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:28:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:28:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:28:56 --> Controller Class Initialized
INFO - 2021-01-09 02:28:56 --> Helper loaded: cookie_helper
INFO - 2021-01-09 02:28:56 --> Config Class Initialized
INFO - 2021-01-09 02:28:56 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:28:56 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:28:56 --> Utf8 Class Initialized
INFO - 2021-01-09 02:28:56 --> URI Class Initialized
INFO - 2021-01-09 02:28:56 --> Router Class Initialized
INFO - 2021-01-09 02:28:56 --> Output Class Initialized
INFO - 2021-01-09 02:28:57 --> Security Class Initialized
DEBUG - 2021-01-09 02:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:28:57 --> Input Class Initialized
INFO - 2021-01-09 02:28:57 --> Language Class Initialized
INFO - 2021-01-09 02:28:57 --> Language Class Initialized
INFO - 2021-01-09 02:28:57 --> Config Class Initialized
INFO - 2021-01-09 02:28:57 --> Loader Class Initialized
INFO - 2021-01-09 02:28:57 --> Helper loaded: url_helper
INFO - 2021-01-09 02:28:57 --> Helper loaded: file_helper
INFO - 2021-01-09 02:28:57 --> Helper loaded: form_helper
INFO - 2021-01-09 02:28:57 --> Helper loaded: my_helper
INFO - 2021-01-09 02:28:57 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:28:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:28:57 --> Controller Class Initialized
DEBUG - 2021-01-09 02:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-09 02:28:57 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:28:57 --> Final output sent to browser
DEBUG - 2021-01-09 02:28:57 --> Total execution time: 0.2444
INFO - 2021-01-09 02:29:03 --> Config Class Initialized
INFO - 2021-01-09 02:29:03 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:29:03 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:29:03 --> Utf8 Class Initialized
INFO - 2021-01-09 02:29:03 --> URI Class Initialized
INFO - 2021-01-09 02:29:03 --> Router Class Initialized
INFO - 2021-01-09 02:29:03 --> Output Class Initialized
INFO - 2021-01-09 02:29:03 --> Security Class Initialized
DEBUG - 2021-01-09 02:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:29:03 --> Input Class Initialized
INFO - 2021-01-09 02:29:03 --> Language Class Initialized
INFO - 2021-01-09 02:29:03 --> Language Class Initialized
INFO - 2021-01-09 02:29:03 --> Config Class Initialized
INFO - 2021-01-09 02:29:03 --> Loader Class Initialized
INFO - 2021-01-09 02:29:03 --> Helper loaded: url_helper
INFO - 2021-01-09 02:29:03 --> Helper loaded: file_helper
INFO - 2021-01-09 02:29:03 --> Helper loaded: form_helper
INFO - 2021-01-09 02:29:03 --> Helper loaded: my_helper
INFO - 2021-01-09 02:29:03 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:29:03 --> Controller Class Initialized
INFO - 2021-01-09 02:29:03 --> Helper loaded: cookie_helper
INFO - 2021-01-09 02:29:03 --> Final output sent to browser
DEBUG - 2021-01-09 02:29:03 --> Total execution time: 0.2988
INFO - 2021-01-09 02:29:03 --> Config Class Initialized
INFO - 2021-01-09 02:29:03 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:29:03 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:29:03 --> Utf8 Class Initialized
INFO - 2021-01-09 02:29:03 --> URI Class Initialized
INFO - 2021-01-09 02:29:04 --> Router Class Initialized
INFO - 2021-01-09 02:29:04 --> Output Class Initialized
INFO - 2021-01-09 02:29:04 --> Security Class Initialized
DEBUG - 2021-01-09 02:29:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:29:04 --> Input Class Initialized
INFO - 2021-01-09 02:29:04 --> Language Class Initialized
INFO - 2021-01-09 02:29:04 --> Language Class Initialized
INFO - 2021-01-09 02:29:04 --> Config Class Initialized
INFO - 2021-01-09 02:29:04 --> Loader Class Initialized
INFO - 2021-01-09 02:29:04 --> Helper loaded: url_helper
INFO - 2021-01-09 02:29:04 --> Helper loaded: file_helper
INFO - 2021-01-09 02:29:04 --> Helper loaded: form_helper
INFO - 2021-01-09 02:29:04 --> Helper loaded: my_helper
INFO - 2021-01-09 02:29:04 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:29:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:29:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:29:04 --> Controller Class Initialized
DEBUG - 2021-01-09 02:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-09 02:29:04 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:29:04 --> Final output sent to browser
DEBUG - 2021-01-09 02:29:04 --> Total execution time: 0.3824
INFO - 2021-01-09 02:34:07 --> Config Class Initialized
INFO - 2021-01-09 02:34:07 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:07 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:07 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:07 --> URI Class Initialized
INFO - 2021-01-09 02:34:07 --> Router Class Initialized
INFO - 2021-01-09 02:34:07 --> Output Class Initialized
INFO - 2021-01-09 02:34:07 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:07 --> Input Class Initialized
INFO - 2021-01-09 02:34:07 --> Language Class Initialized
INFO - 2021-01-09 02:34:07 --> Language Class Initialized
INFO - 2021-01-09 02:34:07 --> Config Class Initialized
INFO - 2021-01-09 02:34:07 --> Loader Class Initialized
INFO - 2021-01-09 02:34:07 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:07 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:07 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:07 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:07 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:07 --> Controller Class Initialized
DEBUG - 2021-01-09 02:34:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:34:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:34:07 --> Final output sent to browser
DEBUG - 2021-01-09 02:34:07 --> Total execution time: 0.2452
INFO - 2021-01-09 02:34:11 --> Config Class Initialized
INFO - 2021-01-09 02:34:11 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:11 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:11 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:11 --> URI Class Initialized
INFO - 2021-01-09 02:34:11 --> Router Class Initialized
INFO - 2021-01-09 02:34:11 --> Output Class Initialized
INFO - 2021-01-09 02:34:11 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:11 --> Input Class Initialized
INFO - 2021-01-09 02:34:11 --> Language Class Initialized
INFO - 2021-01-09 02:34:11 --> Language Class Initialized
INFO - 2021-01-09 02:34:11 --> Config Class Initialized
INFO - 2021-01-09 02:34:11 --> Loader Class Initialized
INFO - 2021-01-09 02:34:11 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:11 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:11 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:11 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:11 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:11 --> Controller Class Initialized
DEBUG - 2021-01-09 02:34:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:34:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:34:11 --> Final output sent to browser
DEBUG - 2021-01-09 02:34:11 --> Total execution time: 0.2570
INFO - 2021-01-09 02:34:11 --> Config Class Initialized
INFO - 2021-01-09 02:34:11 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:11 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:11 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:11 --> URI Class Initialized
INFO - 2021-01-09 02:34:11 --> Router Class Initialized
INFO - 2021-01-09 02:34:11 --> Output Class Initialized
INFO - 2021-01-09 02:34:11 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:11 --> Input Class Initialized
INFO - 2021-01-09 02:34:11 --> Language Class Initialized
INFO - 2021-01-09 02:34:12 --> Language Class Initialized
INFO - 2021-01-09 02:34:12 --> Config Class Initialized
INFO - 2021-01-09 02:34:12 --> Loader Class Initialized
INFO - 2021-01-09 02:34:12 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:12 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:12 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:12 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:12 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:12 --> Controller Class Initialized
INFO - 2021-01-09 02:34:15 --> Config Class Initialized
INFO - 2021-01-09 02:34:15 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:15 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:15 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:15 --> URI Class Initialized
INFO - 2021-01-09 02:34:15 --> Router Class Initialized
INFO - 2021-01-09 02:34:15 --> Output Class Initialized
INFO - 2021-01-09 02:34:15 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:15 --> Input Class Initialized
INFO - 2021-01-09 02:34:15 --> Language Class Initialized
INFO - 2021-01-09 02:34:15 --> Language Class Initialized
INFO - 2021-01-09 02:34:15 --> Config Class Initialized
INFO - 2021-01-09 02:34:15 --> Loader Class Initialized
INFO - 2021-01-09 02:34:15 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:15 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:15 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:15 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:15 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:15 --> Controller Class Initialized
INFO - 2021-01-09 02:34:18 --> Config Class Initialized
INFO - 2021-01-09 02:34:18 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:18 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:18 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:18 --> URI Class Initialized
INFO - 2021-01-09 02:34:18 --> Router Class Initialized
INFO - 2021-01-09 02:34:18 --> Output Class Initialized
INFO - 2021-01-09 02:34:18 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:18 --> Input Class Initialized
INFO - 2021-01-09 02:34:18 --> Language Class Initialized
INFO - 2021-01-09 02:34:18 --> Language Class Initialized
INFO - 2021-01-09 02:34:18 --> Config Class Initialized
INFO - 2021-01-09 02:34:18 --> Loader Class Initialized
INFO - 2021-01-09 02:34:18 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:18 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:18 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:18 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:18 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:18 --> Controller Class Initialized
DEBUG - 2021-01-09 02:34:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:34:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:34:18 --> Final output sent to browser
DEBUG - 2021-01-09 02:34:18 --> Total execution time: 0.3240
INFO - 2021-01-09 02:34:19 --> Config Class Initialized
INFO - 2021-01-09 02:34:19 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:19 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:19 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:19 --> URI Class Initialized
INFO - 2021-01-09 02:34:19 --> Router Class Initialized
INFO - 2021-01-09 02:34:19 --> Output Class Initialized
INFO - 2021-01-09 02:34:19 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:19 --> Input Class Initialized
INFO - 2021-01-09 02:34:19 --> Language Class Initialized
INFO - 2021-01-09 02:34:19 --> Language Class Initialized
INFO - 2021-01-09 02:34:19 --> Config Class Initialized
INFO - 2021-01-09 02:34:19 --> Loader Class Initialized
INFO - 2021-01-09 02:34:19 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:19 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:19 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:19 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:20 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:20 --> Controller Class Initialized
DEBUG - 2021-01-09 02:34:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:34:20 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:34:20 --> Final output sent to browser
DEBUG - 2021-01-09 02:34:20 --> Total execution time: 0.2310
INFO - 2021-01-09 02:34:21 --> Config Class Initialized
INFO - 2021-01-09 02:34:21 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:21 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:21 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:21 --> URI Class Initialized
INFO - 2021-01-09 02:34:21 --> Router Class Initialized
INFO - 2021-01-09 02:34:21 --> Output Class Initialized
INFO - 2021-01-09 02:34:21 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:21 --> Input Class Initialized
INFO - 2021-01-09 02:34:21 --> Language Class Initialized
INFO - 2021-01-09 02:34:21 --> Language Class Initialized
INFO - 2021-01-09 02:34:21 --> Config Class Initialized
INFO - 2021-01-09 02:34:21 --> Loader Class Initialized
INFO - 2021-01-09 02:34:21 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:21 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:21 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:21 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:21 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:21 --> Controller Class Initialized
INFO - 2021-01-09 02:34:58 --> Config Class Initialized
INFO - 2021-01-09 02:34:58 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:34:58 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:34:58 --> Utf8 Class Initialized
INFO - 2021-01-09 02:34:58 --> URI Class Initialized
INFO - 2021-01-09 02:34:58 --> Router Class Initialized
INFO - 2021-01-09 02:34:58 --> Output Class Initialized
INFO - 2021-01-09 02:34:58 --> Security Class Initialized
DEBUG - 2021-01-09 02:34:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:34:58 --> Input Class Initialized
INFO - 2021-01-09 02:34:58 --> Language Class Initialized
INFO - 2021-01-09 02:34:58 --> Language Class Initialized
INFO - 2021-01-09 02:34:58 --> Config Class Initialized
INFO - 2021-01-09 02:34:58 --> Loader Class Initialized
INFO - 2021-01-09 02:34:58 --> Helper loaded: url_helper
INFO - 2021-01-09 02:34:58 --> Helper loaded: file_helper
INFO - 2021-01-09 02:34:58 --> Helper loaded: form_helper
INFO - 2021-01-09 02:34:58 --> Helper loaded: my_helper
INFO - 2021-01-09 02:34:58 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:34:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:34:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:34:58 --> Controller Class Initialized
INFO - 2021-01-09 02:35:43 --> Config Class Initialized
INFO - 2021-01-09 02:35:43 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:35:43 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:35:43 --> Utf8 Class Initialized
INFO - 2021-01-09 02:35:43 --> URI Class Initialized
INFO - 2021-01-09 02:35:43 --> Router Class Initialized
INFO - 2021-01-09 02:35:43 --> Output Class Initialized
INFO - 2021-01-09 02:35:43 --> Security Class Initialized
DEBUG - 2021-01-09 02:35:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:35:43 --> Input Class Initialized
INFO - 2021-01-09 02:35:43 --> Language Class Initialized
INFO - 2021-01-09 02:35:43 --> Language Class Initialized
INFO - 2021-01-09 02:35:43 --> Config Class Initialized
INFO - 2021-01-09 02:35:43 --> Loader Class Initialized
INFO - 2021-01-09 02:35:43 --> Helper loaded: url_helper
INFO - 2021-01-09 02:35:43 --> Helper loaded: file_helper
INFO - 2021-01-09 02:35:43 --> Helper loaded: form_helper
INFO - 2021-01-09 02:35:43 --> Helper loaded: my_helper
INFO - 2021-01-09 02:35:43 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:35:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:35:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:35:43 --> Controller Class Initialized
INFO - 2021-01-09 02:35:43 --> Final output sent to browser
DEBUG - 2021-01-09 02:35:43 --> Total execution time: 0.2332
INFO - 2021-01-09 02:35:51 --> Config Class Initialized
INFO - 2021-01-09 02:35:51 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:35:51 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:35:51 --> Utf8 Class Initialized
INFO - 2021-01-09 02:35:51 --> URI Class Initialized
INFO - 2021-01-09 02:35:51 --> Router Class Initialized
INFO - 2021-01-09 02:35:51 --> Output Class Initialized
INFO - 2021-01-09 02:35:51 --> Security Class Initialized
DEBUG - 2021-01-09 02:35:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:35:51 --> Input Class Initialized
INFO - 2021-01-09 02:35:51 --> Language Class Initialized
INFO - 2021-01-09 02:35:51 --> Language Class Initialized
INFO - 2021-01-09 02:35:51 --> Config Class Initialized
INFO - 2021-01-09 02:35:51 --> Loader Class Initialized
INFO - 2021-01-09 02:35:51 --> Helper loaded: url_helper
INFO - 2021-01-09 02:35:51 --> Helper loaded: file_helper
INFO - 2021-01-09 02:35:51 --> Helper loaded: form_helper
INFO - 2021-01-09 02:35:51 --> Helper loaded: my_helper
INFO - 2021-01-09 02:35:51 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:35:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:35:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:35:51 --> Controller Class Initialized
INFO - 2021-01-09 02:35:51 --> Final output sent to browser
DEBUG - 2021-01-09 02:35:51 --> Total execution time: 0.3056
INFO - 2021-01-09 02:35:54 --> Config Class Initialized
INFO - 2021-01-09 02:35:54 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:35:54 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:35:54 --> Utf8 Class Initialized
INFO - 2021-01-09 02:35:54 --> URI Class Initialized
INFO - 2021-01-09 02:35:54 --> Router Class Initialized
INFO - 2021-01-09 02:35:54 --> Output Class Initialized
INFO - 2021-01-09 02:35:54 --> Security Class Initialized
DEBUG - 2021-01-09 02:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:35:54 --> Input Class Initialized
INFO - 2021-01-09 02:35:54 --> Language Class Initialized
INFO - 2021-01-09 02:35:54 --> Language Class Initialized
INFO - 2021-01-09 02:35:54 --> Config Class Initialized
INFO - 2021-01-09 02:35:54 --> Loader Class Initialized
INFO - 2021-01-09 02:35:54 --> Helper loaded: url_helper
INFO - 2021-01-09 02:35:54 --> Helper loaded: file_helper
INFO - 2021-01-09 02:35:54 --> Helper loaded: form_helper
INFO - 2021-01-09 02:35:54 --> Helper loaded: my_helper
INFO - 2021-01-09 02:35:54 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:35:54 --> Controller Class Initialized
INFO - 2021-01-09 02:35:54 --> Final output sent to browser
DEBUG - 2021-01-09 02:35:54 --> Total execution time: 0.2056
INFO - 2021-01-09 02:35:58 --> Config Class Initialized
INFO - 2021-01-09 02:35:58 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:35:58 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:35:58 --> Utf8 Class Initialized
INFO - 2021-01-09 02:35:58 --> URI Class Initialized
INFO - 2021-01-09 02:35:58 --> Router Class Initialized
INFO - 2021-01-09 02:35:58 --> Output Class Initialized
INFO - 2021-01-09 02:35:58 --> Security Class Initialized
DEBUG - 2021-01-09 02:35:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:35:58 --> Input Class Initialized
INFO - 2021-01-09 02:35:58 --> Language Class Initialized
INFO - 2021-01-09 02:35:58 --> Language Class Initialized
INFO - 2021-01-09 02:35:58 --> Config Class Initialized
INFO - 2021-01-09 02:35:58 --> Loader Class Initialized
INFO - 2021-01-09 02:35:58 --> Helper loaded: url_helper
INFO - 2021-01-09 02:35:58 --> Helper loaded: file_helper
INFO - 2021-01-09 02:35:58 --> Helper loaded: form_helper
INFO - 2021-01-09 02:35:58 --> Helper loaded: my_helper
INFO - 2021-01-09 02:35:58 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:35:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:35:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:35:58 --> Controller Class Initialized
INFO - 2021-01-09 02:35:58 --> Final output sent to browser
DEBUG - 2021-01-09 02:35:58 --> Total execution time: 0.4275
INFO - 2021-01-09 02:36:01 --> Config Class Initialized
INFO - 2021-01-09 02:36:01 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:01 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:01 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:01 --> URI Class Initialized
INFO - 2021-01-09 02:36:01 --> Router Class Initialized
INFO - 2021-01-09 02:36:01 --> Output Class Initialized
INFO - 2021-01-09 02:36:01 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:01 --> Input Class Initialized
INFO - 2021-01-09 02:36:01 --> Language Class Initialized
INFO - 2021-01-09 02:36:01 --> Language Class Initialized
INFO - 2021-01-09 02:36:01 --> Config Class Initialized
INFO - 2021-01-09 02:36:01 --> Loader Class Initialized
INFO - 2021-01-09 02:36:01 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:01 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:01 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:01 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:01 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:01 --> Controller Class Initialized
DEBUG - 2021-01-09 02:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:36:01 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:36:01 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:01 --> Total execution time: 0.2852
INFO - 2021-01-09 02:36:03 --> Config Class Initialized
INFO - 2021-01-09 02:36:03 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:03 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:03 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:03 --> URI Class Initialized
INFO - 2021-01-09 02:36:03 --> Router Class Initialized
INFO - 2021-01-09 02:36:03 --> Output Class Initialized
INFO - 2021-01-09 02:36:03 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:03 --> Input Class Initialized
INFO - 2021-01-09 02:36:03 --> Language Class Initialized
INFO - 2021-01-09 02:36:03 --> Language Class Initialized
INFO - 2021-01-09 02:36:03 --> Config Class Initialized
INFO - 2021-01-09 02:36:03 --> Loader Class Initialized
INFO - 2021-01-09 02:36:03 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:03 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:03 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:03 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:03 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:03 --> Controller Class Initialized
DEBUG - 2021-01-09 02:36:03 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:36:03 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:36:03 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:03 --> Total execution time: 0.2614
INFO - 2021-01-09 02:36:03 --> Config Class Initialized
INFO - 2021-01-09 02:36:03 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:03 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:03 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:03 --> URI Class Initialized
INFO - 2021-01-09 02:36:03 --> Router Class Initialized
INFO - 2021-01-09 02:36:03 --> Output Class Initialized
INFO - 2021-01-09 02:36:03 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:03 --> Input Class Initialized
INFO - 2021-01-09 02:36:03 --> Language Class Initialized
INFO - 2021-01-09 02:36:03 --> Language Class Initialized
INFO - 2021-01-09 02:36:03 --> Config Class Initialized
INFO - 2021-01-09 02:36:03 --> Loader Class Initialized
INFO - 2021-01-09 02:36:03 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:03 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:03 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:03 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:03 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:03 --> Controller Class Initialized
INFO - 2021-01-09 02:36:04 --> Config Class Initialized
INFO - 2021-01-09 02:36:04 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:04 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:04 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:04 --> URI Class Initialized
INFO - 2021-01-09 02:36:04 --> Router Class Initialized
INFO - 2021-01-09 02:36:04 --> Output Class Initialized
INFO - 2021-01-09 02:36:04 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:04 --> Input Class Initialized
INFO - 2021-01-09 02:36:05 --> Language Class Initialized
INFO - 2021-01-09 02:36:05 --> Language Class Initialized
INFO - 2021-01-09 02:36:05 --> Config Class Initialized
INFO - 2021-01-09 02:36:05 --> Loader Class Initialized
INFO - 2021-01-09 02:36:05 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:05 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:05 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:05 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:05 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:05 --> Controller Class Initialized
INFO - 2021-01-09 02:36:05 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:05 --> Total execution time: 0.2531
INFO - 2021-01-09 02:36:08 --> Config Class Initialized
INFO - 2021-01-09 02:36:08 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:08 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:08 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:08 --> URI Class Initialized
INFO - 2021-01-09 02:36:08 --> Router Class Initialized
INFO - 2021-01-09 02:36:08 --> Output Class Initialized
INFO - 2021-01-09 02:36:08 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:08 --> Input Class Initialized
INFO - 2021-01-09 02:36:08 --> Language Class Initialized
INFO - 2021-01-09 02:36:08 --> Language Class Initialized
INFO - 2021-01-09 02:36:08 --> Config Class Initialized
INFO - 2021-01-09 02:36:08 --> Loader Class Initialized
INFO - 2021-01-09 02:36:08 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:08 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:08 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:08 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:08 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:08 --> Controller Class Initialized
INFO - 2021-01-09 02:36:08 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:08 --> Total execution time: 0.3556
INFO - 2021-01-09 02:36:11 --> Config Class Initialized
INFO - 2021-01-09 02:36:11 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:11 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:11 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:11 --> URI Class Initialized
INFO - 2021-01-09 02:36:11 --> Router Class Initialized
INFO - 2021-01-09 02:36:11 --> Output Class Initialized
INFO - 2021-01-09 02:36:11 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:11 --> Input Class Initialized
INFO - 2021-01-09 02:36:11 --> Language Class Initialized
INFO - 2021-01-09 02:36:11 --> Language Class Initialized
INFO - 2021-01-09 02:36:11 --> Config Class Initialized
INFO - 2021-01-09 02:36:11 --> Loader Class Initialized
INFO - 2021-01-09 02:36:11 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:11 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:11 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:11 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:11 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:11 --> Controller Class Initialized
INFO - 2021-01-09 02:36:11 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:11 --> Total execution time: 0.2070
INFO - 2021-01-09 02:36:14 --> Config Class Initialized
INFO - 2021-01-09 02:36:14 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:14 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:14 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:14 --> URI Class Initialized
INFO - 2021-01-09 02:36:14 --> Router Class Initialized
INFO - 2021-01-09 02:36:14 --> Output Class Initialized
INFO - 2021-01-09 02:36:14 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:14 --> Input Class Initialized
INFO - 2021-01-09 02:36:14 --> Language Class Initialized
INFO - 2021-01-09 02:36:14 --> Language Class Initialized
INFO - 2021-01-09 02:36:14 --> Config Class Initialized
INFO - 2021-01-09 02:36:14 --> Loader Class Initialized
INFO - 2021-01-09 02:36:14 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:14 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:14 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:14 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:14 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:14 --> Controller Class Initialized
INFO - 2021-01-09 02:36:14 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:14 --> Total execution time: 0.3933
INFO - 2021-01-09 02:36:16 --> Config Class Initialized
INFO - 2021-01-09 02:36:16 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:16 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:16 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:16 --> URI Class Initialized
INFO - 2021-01-09 02:36:16 --> Router Class Initialized
INFO - 2021-01-09 02:36:16 --> Output Class Initialized
INFO - 2021-01-09 02:36:16 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:16 --> Input Class Initialized
INFO - 2021-01-09 02:36:16 --> Language Class Initialized
INFO - 2021-01-09 02:36:17 --> Language Class Initialized
INFO - 2021-01-09 02:36:17 --> Config Class Initialized
INFO - 2021-01-09 02:36:17 --> Loader Class Initialized
INFO - 2021-01-09 02:36:17 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:17 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:17 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:17 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:17 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:17 --> Controller Class Initialized
INFO - 2021-01-09 02:36:17 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:17 --> Total execution time: 0.2416
INFO - 2021-01-09 02:36:19 --> Config Class Initialized
INFO - 2021-01-09 02:36:19 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:19 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:19 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:19 --> URI Class Initialized
INFO - 2021-01-09 02:36:19 --> Router Class Initialized
INFO - 2021-01-09 02:36:19 --> Output Class Initialized
INFO - 2021-01-09 02:36:19 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:19 --> Input Class Initialized
INFO - 2021-01-09 02:36:19 --> Language Class Initialized
INFO - 2021-01-09 02:36:19 --> Language Class Initialized
INFO - 2021-01-09 02:36:19 --> Config Class Initialized
INFO - 2021-01-09 02:36:19 --> Loader Class Initialized
INFO - 2021-01-09 02:36:19 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:19 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:19 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:19 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:19 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:20 --> Controller Class Initialized
INFO - 2021-01-09 02:36:20 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:20 --> Total execution time: 0.3791
INFO - 2021-01-09 02:36:21 --> Config Class Initialized
INFO - 2021-01-09 02:36:21 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:21 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:21 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:21 --> URI Class Initialized
INFO - 2021-01-09 02:36:21 --> Router Class Initialized
INFO - 2021-01-09 02:36:21 --> Output Class Initialized
INFO - 2021-01-09 02:36:21 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:21 --> Input Class Initialized
INFO - 2021-01-09 02:36:21 --> Language Class Initialized
INFO - 2021-01-09 02:36:21 --> Language Class Initialized
INFO - 2021-01-09 02:36:21 --> Config Class Initialized
INFO - 2021-01-09 02:36:21 --> Loader Class Initialized
INFO - 2021-01-09 02:36:22 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:22 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:22 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:22 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:22 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:22 --> Controller Class Initialized
INFO - 2021-01-09 02:36:22 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:22 --> Total execution time: 0.2337
INFO - 2021-01-09 02:36:24 --> Config Class Initialized
INFO - 2021-01-09 02:36:24 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:24 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:24 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:24 --> URI Class Initialized
INFO - 2021-01-09 02:36:24 --> Router Class Initialized
INFO - 2021-01-09 02:36:24 --> Output Class Initialized
INFO - 2021-01-09 02:36:24 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:24 --> Input Class Initialized
INFO - 2021-01-09 02:36:24 --> Language Class Initialized
INFO - 2021-01-09 02:36:24 --> Language Class Initialized
INFO - 2021-01-09 02:36:24 --> Config Class Initialized
INFO - 2021-01-09 02:36:24 --> Loader Class Initialized
INFO - 2021-01-09 02:36:24 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:24 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:24 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:24 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:24 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:24 --> Controller Class Initialized
INFO - 2021-01-09 02:36:24 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:24 --> Total execution time: 0.3282
INFO - 2021-01-09 02:36:33 --> Config Class Initialized
INFO - 2021-01-09 02:36:33 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:33 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:33 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:33 --> URI Class Initialized
INFO - 2021-01-09 02:36:33 --> Router Class Initialized
INFO - 2021-01-09 02:36:33 --> Output Class Initialized
INFO - 2021-01-09 02:36:33 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:33 --> Input Class Initialized
INFO - 2021-01-09 02:36:33 --> Language Class Initialized
INFO - 2021-01-09 02:36:33 --> Language Class Initialized
INFO - 2021-01-09 02:36:33 --> Config Class Initialized
INFO - 2021-01-09 02:36:33 --> Loader Class Initialized
INFO - 2021-01-09 02:36:33 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:33 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:33 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:33 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:33 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:33 --> Controller Class Initialized
DEBUG - 2021-01-09 02:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:36:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:36:33 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:33 --> Total execution time: 0.2685
INFO - 2021-01-09 02:36:33 --> Config Class Initialized
INFO - 2021-01-09 02:36:33 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:34 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:34 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:34 --> URI Class Initialized
INFO - 2021-01-09 02:36:34 --> Router Class Initialized
INFO - 2021-01-09 02:36:34 --> Output Class Initialized
INFO - 2021-01-09 02:36:34 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:34 --> Input Class Initialized
INFO - 2021-01-09 02:36:34 --> Language Class Initialized
INFO - 2021-01-09 02:36:34 --> Language Class Initialized
INFO - 2021-01-09 02:36:34 --> Config Class Initialized
INFO - 2021-01-09 02:36:34 --> Loader Class Initialized
INFO - 2021-01-09 02:36:34 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:34 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:34 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:34 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:34 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:34 --> Controller Class Initialized
INFO - 2021-01-09 02:36:37 --> Config Class Initialized
INFO - 2021-01-09 02:36:37 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:37 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:37 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:37 --> URI Class Initialized
INFO - 2021-01-09 02:36:37 --> Router Class Initialized
INFO - 2021-01-09 02:36:37 --> Output Class Initialized
INFO - 2021-01-09 02:36:37 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:37 --> Input Class Initialized
INFO - 2021-01-09 02:36:37 --> Language Class Initialized
INFO - 2021-01-09 02:36:37 --> Language Class Initialized
INFO - 2021-01-09 02:36:37 --> Config Class Initialized
INFO - 2021-01-09 02:36:37 --> Loader Class Initialized
INFO - 2021-01-09 02:36:37 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:37 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:37 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:37 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:37 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:37 --> Controller Class Initialized
DEBUG - 2021-01-09 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-09 02:36:37 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:36:37 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:37 --> Total execution time: 0.3149
INFO - 2021-01-09 02:36:50 --> Config Class Initialized
INFO - 2021-01-09 02:36:50 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:50 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:50 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:50 --> URI Class Initialized
INFO - 2021-01-09 02:36:50 --> Router Class Initialized
INFO - 2021-01-09 02:36:50 --> Output Class Initialized
INFO - 2021-01-09 02:36:50 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:50 --> Input Class Initialized
INFO - 2021-01-09 02:36:50 --> Language Class Initialized
INFO - 2021-01-09 02:36:50 --> Language Class Initialized
INFO - 2021-01-09 02:36:50 --> Config Class Initialized
INFO - 2021-01-09 02:36:50 --> Loader Class Initialized
INFO - 2021-01-09 02:36:50 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:50 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:50 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:50 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:50 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:51 --> Controller Class Initialized
INFO - 2021-01-09 02:36:51 --> Config Class Initialized
INFO - 2021-01-09 02:36:51 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:51 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:51 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:51 --> URI Class Initialized
INFO - 2021-01-09 02:36:51 --> Router Class Initialized
INFO - 2021-01-09 02:36:51 --> Output Class Initialized
INFO - 2021-01-09 02:36:51 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:51 --> Input Class Initialized
INFO - 2021-01-09 02:36:51 --> Language Class Initialized
INFO - 2021-01-09 02:36:51 --> Language Class Initialized
INFO - 2021-01-09 02:36:51 --> Config Class Initialized
INFO - 2021-01-09 02:36:51 --> Loader Class Initialized
INFO - 2021-01-09 02:36:51 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:51 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:51 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:51 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:51 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:51 --> Controller Class Initialized
DEBUG - 2021-01-09 02:36:51 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:36:51 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:36:51 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:51 --> Total execution time: 0.3334
INFO - 2021-01-09 02:36:51 --> Config Class Initialized
INFO - 2021-01-09 02:36:51 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:51 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:51 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:51 --> URI Class Initialized
INFO - 2021-01-09 02:36:51 --> Router Class Initialized
INFO - 2021-01-09 02:36:51 --> Output Class Initialized
INFO - 2021-01-09 02:36:51 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:51 --> Input Class Initialized
INFO - 2021-01-09 02:36:51 --> Language Class Initialized
INFO - 2021-01-09 02:36:51 --> Language Class Initialized
INFO - 2021-01-09 02:36:51 --> Config Class Initialized
INFO - 2021-01-09 02:36:51 --> Loader Class Initialized
INFO - 2021-01-09 02:36:51 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:51 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:51 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:51 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:51 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:51 --> Controller Class Initialized
INFO - 2021-01-09 02:36:53 --> Config Class Initialized
INFO - 2021-01-09 02:36:53 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:53 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:53 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:53 --> URI Class Initialized
INFO - 2021-01-09 02:36:53 --> Router Class Initialized
INFO - 2021-01-09 02:36:53 --> Output Class Initialized
INFO - 2021-01-09 02:36:53 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:53 --> Input Class Initialized
INFO - 2021-01-09 02:36:53 --> Language Class Initialized
INFO - 2021-01-09 02:36:53 --> Language Class Initialized
INFO - 2021-01-09 02:36:53 --> Config Class Initialized
INFO - 2021-01-09 02:36:53 --> Loader Class Initialized
INFO - 2021-01-09 02:36:53 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:53 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:53 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:53 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:53 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:53 --> Controller Class Initialized
INFO - 2021-01-09 02:36:53 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:53 --> Total execution time: 0.2341
INFO - 2021-01-09 02:36:54 --> Config Class Initialized
INFO - 2021-01-09 02:36:54 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:36:54 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:36:54 --> Utf8 Class Initialized
INFO - 2021-01-09 02:36:54 --> URI Class Initialized
INFO - 2021-01-09 02:36:54 --> Router Class Initialized
INFO - 2021-01-09 02:36:54 --> Output Class Initialized
INFO - 2021-01-09 02:36:54 --> Security Class Initialized
DEBUG - 2021-01-09 02:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:36:55 --> Input Class Initialized
INFO - 2021-01-09 02:36:55 --> Language Class Initialized
INFO - 2021-01-09 02:36:55 --> Language Class Initialized
INFO - 2021-01-09 02:36:55 --> Config Class Initialized
INFO - 2021-01-09 02:36:55 --> Loader Class Initialized
INFO - 2021-01-09 02:36:55 --> Helper loaded: url_helper
INFO - 2021-01-09 02:36:55 --> Helper loaded: file_helper
INFO - 2021-01-09 02:36:55 --> Helper loaded: form_helper
INFO - 2021-01-09 02:36:55 --> Helper loaded: my_helper
INFO - 2021-01-09 02:36:55 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:36:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:36:55 --> Controller Class Initialized
INFO - 2021-01-09 02:36:55 --> Final output sent to browser
DEBUG - 2021-01-09 02:36:55 --> Total execution time: 0.2287
INFO - 2021-01-09 02:37:10 --> Config Class Initialized
INFO - 2021-01-09 02:37:10 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:10 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:10 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:10 --> URI Class Initialized
INFO - 2021-01-09 02:37:10 --> Router Class Initialized
INFO - 2021-01-09 02:37:10 --> Output Class Initialized
INFO - 2021-01-09 02:37:10 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:10 --> Input Class Initialized
INFO - 2021-01-09 02:37:10 --> Language Class Initialized
INFO - 2021-01-09 02:37:10 --> Language Class Initialized
INFO - 2021-01-09 02:37:10 --> Config Class Initialized
INFO - 2021-01-09 02:37:10 --> Loader Class Initialized
INFO - 2021-01-09 02:37:10 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:10 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:10 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:10 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:10 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:10 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:37:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:10 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:10 --> Total execution time: 0.3435
INFO - 2021-01-09 02:37:11 --> Config Class Initialized
INFO - 2021-01-09 02:37:11 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:11 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:11 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:11 --> URI Class Initialized
INFO - 2021-01-09 02:37:11 --> Router Class Initialized
INFO - 2021-01-09 02:37:11 --> Output Class Initialized
INFO - 2021-01-09 02:37:11 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:11 --> Input Class Initialized
INFO - 2021-01-09 02:37:11 --> Language Class Initialized
INFO - 2021-01-09 02:37:12 --> Language Class Initialized
INFO - 2021-01-09 02:37:12 --> Config Class Initialized
INFO - 2021-01-09 02:37:12 --> Loader Class Initialized
INFO - 2021-01-09 02:37:12 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:12 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:12 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:12 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:12 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:12 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:37:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:12 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:12 --> Total execution time: 0.3080
INFO - 2021-01-09 02:37:13 --> Config Class Initialized
INFO - 2021-01-09 02:37:13 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:13 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:13 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:13 --> URI Class Initialized
INFO - 2021-01-09 02:37:13 --> Router Class Initialized
INFO - 2021-01-09 02:37:13 --> Output Class Initialized
INFO - 2021-01-09 02:37:13 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:13 --> Input Class Initialized
INFO - 2021-01-09 02:37:13 --> Language Class Initialized
INFO - 2021-01-09 02:37:13 --> Language Class Initialized
INFO - 2021-01-09 02:37:13 --> Config Class Initialized
INFO - 2021-01-09 02:37:13 --> Loader Class Initialized
INFO - 2021-01-09 02:37:13 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:13 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:13 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:13 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:13 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:13 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-01-09 02:37:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:13 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:13 --> Total execution time: 0.3046
INFO - 2021-01-09 02:37:25 --> Config Class Initialized
INFO - 2021-01-09 02:37:25 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:25 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:25 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:25 --> URI Class Initialized
INFO - 2021-01-09 02:37:25 --> Router Class Initialized
INFO - 2021-01-09 02:37:25 --> Output Class Initialized
INFO - 2021-01-09 02:37:25 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:25 --> Input Class Initialized
INFO - 2021-01-09 02:37:25 --> Language Class Initialized
INFO - 2021-01-09 02:37:25 --> Language Class Initialized
INFO - 2021-01-09 02:37:25 --> Config Class Initialized
INFO - 2021-01-09 02:37:25 --> Loader Class Initialized
INFO - 2021-01-09 02:37:25 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:25 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:25 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:25 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:25 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:25 --> Controller Class Initialized
INFO - 2021-01-09 02:37:25 --> Config Class Initialized
INFO - 2021-01-09 02:37:25 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:25 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:25 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:25 --> URI Class Initialized
INFO - 2021-01-09 02:37:25 --> Router Class Initialized
INFO - 2021-01-09 02:37:25 --> Output Class Initialized
INFO - 2021-01-09 02:37:25 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:25 --> Input Class Initialized
INFO - 2021-01-09 02:37:25 --> Language Class Initialized
INFO - 2021-01-09 02:37:25 --> Language Class Initialized
INFO - 2021-01-09 02:37:25 --> Config Class Initialized
INFO - 2021-01-09 02:37:25 --> Loader Class Initialized
INFO - 2021-01-09 02:37:25 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:25 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:25 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:25 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:25 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:25 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:37:25 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:25 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:25 --> Total execution time: 0.2528
INFO - 2021-01-09 02:37:28 --> Config Class Initialized
INFO - 2021-01-09 02:37:28 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:28 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:28 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:28 --> URI Class Initialized
INFO - 2021-01-09 02:37:28 --> Router Class Initialized
INFO - 2021-01-09 02:37:28 --> Output Class Initialized
INFO - 2021-01-09 02:37:28 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:28 --> Input Class Initialized
INFO - 2021-01-09 02:37:28 --> Language Class Initialized
INFO - 2021-01-09 02:37:28 --> Language Class Initialized
INFO - 2021-01-09 02:37:28 --> Config Class Initialized
INFO - 2021-01-09 02:37:28 --> Loader Class Initialized
INFO - 2021-01-09 02:37:28 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:28 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:28 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:28 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:28 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:28 --> Controller Class Initialized
INFO - 2021-01-09 02:37:28 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:28 --> Total execution time: 0.2372
INFO - 2021-01-09 02:37:29 --> Config Class Initialized
INFO - 2021-01-09 02:37:29 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:29 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:29 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:29 --> URI Class Initialized
INFO - 2021-01-09 02:37:29 --> Router Class Initialized
INFO - 2021-01-09 02:37:29 --> Output Class Initialized
INFO - 2021-01-09 02:37:29 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:29 --> Input Class Initialized
INFO - 2021-01-09 02:37:29 --> Language Class Initialized
INFO - 2021-01-09 02:37:29 --> Language Class Initialized
INFO - 2021-01-09 02:37:29 --> Config Class Initialized
INFO - 2021-01-09 02:37:29 --> Loader Class Initialized
INFO - 2021-01-09 02:37:29 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:29 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:29 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:29 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:29 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:29 --> Controller Class Initialized
INFO - 2021-01-09 02:37:29 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:29 --> Total execution time: 0.2215
INFO - 2021-01-09 02:37:38 --> Config Class Initialized
INFO - 2021-01-09 02:37:38 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:38 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:38 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:38 --> URI Class Initialized
INFO - 2021-01-09 02:37:38 --> Router Class Initialized
INFO - 2021-01-09 02:37:38 --> Output Class Initialized
INFO - 2021-01-09 02:37:38 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:38 --> Input Class Initialized
INFO - 2021-01-09 02:37:38 --> Language Class Initialized
INFO - 2021-01-09 02:37:38 --> Language Class Initialized
INFO - 2021-01-09 02:37:38 --> Config Class Initialized
INFO - 2021-01-09 02:37:38 --> Loader Class Initialized
INFO - 2021-01-09 02:37:39 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:39 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:39 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:39 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:39 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:39 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:39 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:37:39 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:39 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:39 --> Total execution time: 0.2795
INFO - 2021-01-09 02:37:39 --> Config Class Initialized
INFO - 2021-01-09 02:37:39 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:39 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:39 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:39 --> URI Class Initialized
INFO - 2021-01-09 02:37:40 --> Router Class Initialized
INFO - 2021-01-09 02:37:40 --> Output Class Initialized
INFO - 2021-01-09 02:37:40 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:40 --> Input Class Initialized
INFO - 2021-01-09 02:37:40 --> Language Class Initialized
INFO - 2021-01-09 02:37:40 --> Language Class Initialized
INFO - 2021-01-09 02:37:40 --> Config Class Initialized
INFO - 2021-01-09 02:37:40 --> Loader Class Initialized
INFO - 2021-01-09 02:37:40 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:40 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:40 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:40 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:40 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:40 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:40 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:37:40 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:40 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:40 --> Total execution time: 0.2586
INFO - 2021-01-09 02:37:40 --> Config Class Initialized
INFO - 2021-01-09 02:37:40 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:40 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:40 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:40 --> URI Class Initialized
INFO - 2021-01-09 02:37:40 --> Router Class Initialized
INFO - 2021-01-09 02:37:40 --> Output Class Initialized
INFO - 2021-01-09 02:37:40 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:40 --> Input Class Initialized
INFO - 2021-01-09 02:37:40 --> Language Class Initialized
INFO - 2021-01-09 02:37:40 --> Language Class Initialized
INFO - 2021-01-09 02:37:40 --> Config Class Initialized
INFO - 2021-01-09 02:37:40 --> Loader Class Initialized
INFO - 2021-01-09 02:37:40 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:40 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:40 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:40 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:40 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:40 --> Controller Class Initialized
INFO - 2021-01-09 02:37:41 --> Config Class Initialized
INFO - 2021-01-09 02:37:41 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:41 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:41 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:41 --> URI Class Initialized
INFO - 2021-01-09 02:37:41 --> Router Class Initialized
INFO - 2021-01-09 02:37:41 --> Output Class Initialized
INFO - 2021-01-09 02:37:41 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:41 --> Input Class Initialized
INFO - 2021-01-09 02:37:41 --> Language Class Initialized
INFO - 2021-01-09 02:37:41 --> Language Class Initialized
INFO - 2021-01-09 02:37:41 --> Config Class Initialized
INFO - 2021-01-09 02:37:41 --> Loader Class Initialized
INFO - 2021-01-09 02:37:41 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:41 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:41 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:41 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:41 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:41 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-09 02:37:41 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:41 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:41 --> Total execution time: 0.2911
INFO - 2021-01-09 02:37:44 --> Config Class Initialized
INFO - 2021-01-09 02:37:44 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:45 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:45 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:45 --> URI Class Initialized
INFO - 2021-01-09 02:37:45 --> Router Class Initialized
INFO - 2021-01-09 02:37:45 --> Output Class Initialized
INFO - 2021-01-09 02:37:45 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:45 --> Input Class Initialized
INFO - 2021-01-09 02:37:45 --> Language Class Initialized
INFO - 2021-01-09 02:37:45 --> Language Class Initialized
INFO - 2021-01-09 02:37:45 --> Config Class Initialized
INFO - 2021-01-09 02:37:45 --> Loader Class Initialized
INFO - 2021-01-09 02:37:45 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:45 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:45 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:45 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:45 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:45 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:37:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:45 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:45 --> Total execution time: 0.2860
INFO - 2021-01-09 02:37:45 --> Config Class Initialized
INFO - 2021-01-09 02:37:45 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:45 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:45 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:45 --> URI Class Initialized
INFO - 2021-01-09 02:37:45 --> Router Class Initialized
INFO - 2021-01-09 02:37:45 --> Output Class Initialized
INFO - 2021-01-09 02:37:45 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:45 --> Input Class Initialized
INFO - 2021-01-09 02:37:45 --> Language Class Initialized
INFO - 2021-01-09 02:37:45 --> Language Class Initialized
INFO - 2021-01-09 02:37:45 --> Config Class Initialized
INFO - 2021-01-09 02:37:45 --> Loader Class Initialized
INFO - 2021-01-09 02:37:45 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:45 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:45 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:45 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:45 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:45 --> Controller Class Initialized
INFO - 2021-01-09 02:37:48 --> Config Class Initialized
INFO - 2021-01-09 02:37:48 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:37:48 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:37:48 --> Utf8 Class Initialized
INFO - 2021-01-09 02:37:48 --> URI Class Initialized
INFO - 2021-01-09 02:37:48 --> Router Class Initialized
INFO - 2021-01-09 02:37:48 --> Output Class Initialized
INFO - 2021-01-09 02:37:48 --> Security Class Initialized
DEBUG - 2021-01-09 02:37:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:37:48 --> Input Class Initialized
INFO - 2021-01-09 02:37:48 --> Language Class Initialized
INFO - 2021-01-09 02:37:48 --> Language Class Initialized
INFO - 2021-01-09 02:37:48 --> Config Class Initialized
INFO - 2021-01-09 02:37:48 --> Loader Class Initialized
INFO - 2021-01-09 02:37:48 --> Helper loaded: url_helper
INFO - 2021-01-09 02:37:48 --> Helper loaded: file_helper
INFO - 2021-01-09 02:37:48 --> Helper loaded: form_helper
INFO - 2021-01-09 02:37:48 --> Helper loaded: my_helper
INFO - 2021-01-09 02:37:48 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:37:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:37:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:37:48 --> Controller Class Initialized
DEBUG - 2021-01-09 02:37:48 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-09 02:37:48 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:37:48 --> Final output sent to browser
DEBUG - 2021-01-09 02:37:48 --> Total execution time: 0.3709
INFO - 2021-01-09 02:38:21 --> Config Class Initialized
INFO - 2021-01-09 02:38:21 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:21 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:21 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:21 --> URI Class Initialized
INFO - 2021-01-09 02:38:21 --> Router Class Initialized
INFO - 2021-01-09 02:38:21 --> Output Class Initialized
INFO - 2021-01-09 02:38:21 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:21 --> Input Class Initialized
INFO - 2021-01-09 02:38:21 --> Language Class Initialized
INFO - 2021-01-09 02:38:22 --> Language Class Initialized
INFO - 2021-01-09 02:38:22 --> Config Class Initialized
INFO - 2021-01-09 02:38:22 --> Loader Class Initialized
INFO - 2021-01-09 02:38:22 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:22 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:22 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:22 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:22 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:22 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:22 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:38:22 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:22 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:22 --> Total execution time: 0.2620
INFO - 2021-01-09 02:38:22 --> Config Class Initialized
INFO - 2021-01-09 02:38:22 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:22 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:22 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:22 --> URI Class Initialized
INFO - 2021-01-09 02:38:22 --> Router Class Initialized
INFO - 2021-01-09 02:38:22 --> Output Class Initialized
INFO - 2021-01-09 02:38:22 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:22 --> Input Class Initialized
INFO - 2021-01-09 02:38:22 --> Language Class Initialized
INFO - 2021-01-09 02:38:22 --> Language Class Initialized
INFO - 2021-01-09 02:38:22 --> Config Class Initialized
INFO - 2021-01-09 02:38:22 --> Loader Class Initialized
INFO - 2021-01-09 02:38:22 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:22 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:22 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:22 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:22 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:22 --> Controller Class Initialized
INFO - 2021-01-09 02:38:27 --> Config Class Initialized
INFO - 2021-01-09 02:38:27 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:27 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:27 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:27 --> URI Class Initialized
INFO - 2021-01-09 02:38:27 --> Router Class Initialized
INFO - 2021-01-09 02:38:27 --> Output Class Initialized
INFO - 2021-01-09 02:38:27 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:27 --> Input Class Initialized
INFO - 2021-01-09 02:38:27 --> Language Class Initialized
INFO - 2021-01-09 02:38:27 --> Language Class Initialized
INFO - 2021-01-09 02:38:28 --> Config Class Initialized
INFO - 2021-01-09 02:38:28 --> Loader Class Initialized
INFO - 2021-01-09 02:38:28 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:28 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:28 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:28 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:28 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:28 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-09 02:38:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:28 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:28 --> Total execution time: 0.3430
INFO - 2021-01-09 02:38:30 --> Config Class Initialized
INFO - 2021-01-09 02:38:30 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:30 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:30 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:30 --> URI Class Initialized
INFO - 2021-01-09 02:38:30 --> Router Class Initialized
INFO - 2021-01-09 02:38:30 --> Output Class Initialized
INFO - 2021-01-09 02:38:30 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:30 --> Input Class Initialized
INFO - 2021-01-09 02:38:30 --> Language Class Initialized
INFO - 2021-01-09 02:38:30 --> Language Class Initialized
INFO - 2021-01-09 02:38:30 --> Config Class Initialized
INFO - 2021-01-09 02:38:30 --> Loader Class Initialized
INFO - 2021-01-09 02:38:30 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:30 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:30 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:30 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:30 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:30 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:38:30 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:30 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:30 --> Total execution time: 0.2582
INFO - 2021-01-09 02:38:31 --> Config Class Initialized
INFO - 2021-01-09 02:38:31 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:31 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:31 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:31 --> URI Class Initialized
INFO - 2021-01-09 02:38:31 --> Router Class Initialized
INFO - 2021-01-09 02:38:31 --> Output Class Initialized
INFO - 2021-01-09 02:38:31 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:31 --> Input Class Initialized
INFO - 2021-01-09 02:38:31 --> Language Class Initialized
INFO - 2021-01-09 02:38:31 --> Language Class Initialized
INFO - 2021-01-09 02:38:31 --> Config Class Initialized
INFO - 2021-01-09 02:38:31 --> Loader Class Initialized
INFO - 2021-01-09 02:38:31 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:31 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:31 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:31 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:31 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:31 --> Controller Class Initialized
INFO - 2021-01-09 02:38:32 --> Config Class Initialized
INFO - 2021-01-09 02:38:32 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:32 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:32 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:32 --> URI Class Initialized
INFO - 2021-01-09 02:38:32 --> Router Class Initialized
INFO - 2021-01-09 02:38:32 --> Output Class Initialized
INFO - 2021-01-09 02:38:32 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:32 --> Input Class Initialized
INFO - 2021-01-09 02:38:32 --> Language Class Initialized
INFO - 2021-01-09 02:38:32 --> Language Class Initialized
INFO - 2021-01-09 02:38:32 --> Config Class Initialized
INFO - 2021-01-09 02:38:32 --> Loader Class Initialized
INFO - 2021-01-09 02:38:32 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:32 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:32 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:32 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:32 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:32 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:38:32 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:32 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:32 --> Total execution time: 0.3175
INFO - 2021-01-09 02:38:33 --> Config Class Initialized
INFO - 2021-01-09 02:38:33 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:33 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:33 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:33 --> URI Class Initialized
INFO - 2021-01-09 02:38:33 --> Router Class Initialized
INFO - 2021-01-09 02:38:33 --> Output Class Initialized
INFO - 2021-01-09 02:38:33 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:33 --> Input Class Initialized
INFO - 2021-01-09 02:38:33 --> Language Class Initialized
INFO - 2021-01-09 02:38:33 --> Language Class Initialized
INFO - 2021-01-09 02:38:33 --> Config Class Initialized
INFO - 2021-01-09 02:38:33 --> Loader Class Initialized
INFO - 2021-01-09 02:38:33 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:33 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:33 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:33 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:33 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:33 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:38:33 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:33 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:33 --> Total execution time: 0.2587
INFO - 2021-01-09 02:38:35 --> Config Class Initialized
INFO - 2021-01-09 02:38:35 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:35 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:35 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:35 --> URI Class Initialized
INFO - 2021-01-09 02:38:35 --> Router Class Initialized
INFO - 2021-01-09 02:38:36 --> Output Class Initialized
INFO - 2021-01-09 02:38:36 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:36 --> Input Class Initialized
INFO - 2021-01-09 02:38:36 --> Language Class Initialized
INFO - 2021-01-09 02:38:36 --> Language Class Initialized
INFO - 2021-01-09 02:38:36 --> Config Class Initialized
INFO - 2021-01-09 02:38:36 --> Loader Class Initialized
INFO - 2021-01-09 02:38:36 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:36 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:36 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:36 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:36 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:36 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:36 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-01-09 02:38:36 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:36 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:36 --> Total execution time: 0.3250
INFO - 2021-01-09 02:38:45 --> Config Class Initialized
INFO - 2021-01-09 02:38:45 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:45 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:45 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:45 --> URI Class Initialized
INFO - 2021-01-09 02:38:45 --> Router Class Initialized
INFO - 2021-01-09 02:38:45 --> Output Class Initialized
INFO - 2021-01-09 02:38:45 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:45 --> Input Class Initialized
INFO - 2021-01-09 02:38:45 --> Language Class Initialized
INFO - 2021-01-09 02:38:45 --> Language Class Initialized
INFO - 2021-01-09 02:38:45 --> Config Class Initialized
INFO - 2021-01-09 02:38:45 --> Loader Class Initialized
INFO - 2021-01-09 02:38:45 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:45 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:45 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:45 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:45 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:45 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:45 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:38:45 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:45 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:45 --> Total execution time: 0.2584
INFO - 2021-01-09 02:38:46 --> Config Class Initialized
INFO - 2021-01-09 02:38:46 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:46 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:46 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:46 --> URI Class Initialized
INFO - 2021-01-09 02:38:46 --> Router Class Initialized
INFO - 2021-01-09 02:38:46 --> Output Class Initialized
INFO - 2021-01-09 02:38:46 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:46 --> Input Class Initialized
INFO - 2021-01-09 02:38:46 --> Language Class Initialized
INFO - 2021-01-09 02:38:46 --> Language Class Initialized
INFO - 2021-01-09 02:38:46 --> Config Class Initialized
INFO - 2021-01-09 02:38:46 --> Loader Class Initialized
INFO - 2021-01-09 02:38:46 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:46 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:46 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:46 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:46 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:46 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:38:46 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:46 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:46 --> Total execution time: 0.3311
INFO - 2021-01-09 02:38:47 --> Config Class Initialized
INFO - 2021-01-09 02:38:47 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:47 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:47 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:47 --> URI Class Initialized
INFO - 2021-01-09 02:38:47 --> Router Class Initialized
INFO - 2021-01-09 02:38:47 --> Output Class Initialized
INFO - 2021-01-09 02:38:47 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:47 --> Input Class Initialized
INFO - 2021-01-09 02:38:47 --> Language Class Initialized
INFO - 2021-01-09 02:38:47 --> Language Class Initialized
INFO - 2021-01-09 02:38:47 --> Config Class Initialized
INFO - 2021-01-09 02:38:47 --> Loader Class Initialized
INFO - 2021-01-09 02:38:47 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:47 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:47 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:47 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:47 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:47 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:38:47 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:47 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:47 --> Total execution time: 0.2675
INFO - 2021-01-09 02:38:47 --> Config Class Initialized
INFO - 2021-01-09 02:38:47 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:47 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:47 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:48 --> URI Class Initialized
INFO - 2021-01-09 02:38:48 --> Router Class Initialized
INFO - 2021-01-09 02:38:48 --> Output Class Initialized
INFO - 2021-01-09 02:38:48 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:48 --> Input Class Initialized
INFO - 2021-01-09 02:38:48 --> Language Class Initialized
INFO - 2021-01-09 02:38:48 --> Language Class Initialized
INFO - 2021-01-09 02:38:48 --> Config Class Initialized
INFO - 2021-01-09 02:38:48 --> Loader Class Initialized
INFO - 2021-01-09 02:38:48 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:48 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:48 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:48 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:48 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:48 --> Controller Class Initialized
INFO - 2021-01-09 02:38:49 --> Config Class Initialized
INFO - 2021-01-09 02:38:49 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:38:49 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:38:49 --> Utf8 Class Initialized
INFO - 2021-01-09 02:38:49 --> URI Class Initialized
INFO - 2021-01-09 02:38:49 --> Router Class Initialized
INFO - 2021-01-09 02:38:49 --> Output Class Initialized
INFO - 2021-01-09 02:38:49 --> Security Class Initialized
DEBUG - 2021-01-09 02:38:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:38:49 --> Input Class Initialized
INFO - 2021-01-09 02:38:49 --> Language Class Initialized
INFO - 2021-01-09 02:38:49 --> Language Class Initialized
INFO - 2021-01-09 02:38:49 --> Config Class Initialized
INFO - 2021-01-09 02:38:49 --> Loader Class Initialized
INFO - 2021-01-09 02:38:49 --> Helper loaded: url_helper
INFO - 2021-01-09 02:38:49 --> Helper loaded: file_helper
INFO - 2021-01-09 02:38:49 --> Helper loaded: form_helper
INFO - 2021-01-09 02:38:49 --> Helper loaded: my_helper
INFO - 2021-01-09 02:38:49 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:38:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:38:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:38:49 --> Controller Class Initialized
DEBUG - 2021-01-09 02:38:49 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-09 02:38:49 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:38:49 --> Final output sent to browser
DEBUG - 2021-01-09 02:38:49 --> Total execution time: 0.2946
INFO - 2021-01-09 02:39:07 --> Config Class Initialized
INFO - 2021-01-09 02:39:07 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:07 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:07 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:07 --> URI Class Initialized
INFO - 2021-01-09 02:39:07 --> Router Class Initialized
INFO - 2021-01-09 02:39:07 --> Output Class Initialized
INFO - 2021-01-09 02:39:07 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:07 --> Input Class Initialized
INFO - 2021-01-09 02:39:07 --> Language Class Initialized
INFO - 2021-01-09 02:39:07 --> Language Class Initialized
INFO - 2021-01-09 02:39:07 --> Config Class Initialized
INFO - 2021-01-09 02:39:07 --> Loader Class Initialized
INFO - 2021-01-09 02:39:07 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:07 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:07 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:07 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:07 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:07 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/form.php
DEBUG - 2021-01-09 02:39:07 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:07 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:07 --> Total execution time: 0.2756
INFO - 2021-01-09 02:39:09 --> Config Class Initialized
INFO - 2021-01-09 02:39:09 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:09 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:09 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:09 --> URI Class Initialized
INFO - 2021-01-09 02:39:09 --> Router Class Initialized
INFO - 2021-01-09 02:39:09 --> Output Class Initialized
INFO - 2021-01-09 02:39:09 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:09 --> Input Class Initialized
INFO - 2021-01-09 02:39:09 --> Language Class Initialized
INFO - 2021-01-09 02:39:09 --> Language Class Initialized
INFO - 2021-01-09 02:39:09 --> Config Class Initialized
INFO - 2021-01-09 02:39:09 --> Loader Class Initialized
INFO - 2021-01-09 02:39:09 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:09 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:09 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:09 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:09 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:09 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:39:09 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:09 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:09 --> Total execution time: 0.2968
INFO - 2021-01-09 02:39:09 --> Config Class Initialized
INFO - 2021-01-09 02:39:09 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:09 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:09 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:09 --> URI Class Initialized
INFO - 2021-01-09 02:39:10 --> Router Class Initialized
INFO - 2021-01-09 02:39:10 --> Output Class Initialized
INFO - 2021-01-09 02:39:10 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:10 --> Input Class Initialized
INFO - 2021-01-09 02:39:10 --> Language Class Initialized
INFO - 2021-01-09 02:39:10 --> Language Class Initialized
INFO - 2021-01-09 02:39:10 --> Config Class Initialized
INFO - 2021-01-09 02:39:10 --> Loader Class Initialized
INFO - 2021-01-09 02:39:10 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:10 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:10 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:10 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:10 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:10 --> Controller Class Initialized
INFO - 2021-01-09 02:39:10 --> Config Class Initialized
INFO - 2021-01-09 02:39:10 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:10 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:10 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:10 --> URI Class Initialized
INFO - 2021-01-09 02:39:10 --> Router Class Initialized
INFO - 2021-01-09 02:39:10 --> Output Class Initialized
INFO - 2021-01-09 02:39:10 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:10 --> Input Class Initialized
INFO - 2021-01-09 02:39:10 --> Language Class Initialized
INFO - 2021-01-09 02:39:10 --> Language Class Initialized
INFO - 2021-01-09 02:39:10 --> Config Class Initialized
INFO - 2021-01-09 02:39:10 --> Loader Class Initialized
INFO - 2021-01-09 02:39:10 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:10 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:10 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:10 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:10 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:10 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:10 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:39:10 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:10 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:10 --> Total execution time: 0.3036
INFO - 2021-01-09 02:39:11 --> Config Class Initialized
INFO - 2021-01-09 02:39:11 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:11 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:11 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:11 --> URI Class Initialized
INFO - 2021-01-09 02:39:11 --> Router Class Initialized
INFO - 2021-01-09 02:39:11 --> Output Class Initialized
INFO - 2021-01-09 02:39:11 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:11 --> Input Class Initialized
INFO - 2021-01-09 02:39:11 --> Language Class Initialized
INFO - 2021-01-09 02:39:11 --> Language Class Initialized
INFO - 2021-01-09 02:39:11 --> Config Class Initialized
INFO - 2021-01-09 02:39:11 --> Loader Class Initialized
INFO - 2021-01-09 02:39:11 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:11 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:11 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:11 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:11 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:11 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:39:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:11 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:11 --> Total execution time: 0.2605
INFO - 2021-01-09 02:39:13 --> Config Class Initialized
INFO - 2021-01-09 02:39:13 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:13 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:13 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:13 --> URI Class Initialized
INFO - 2021-01-09 02:39:13 --> Router Class Initialized
INFO - 2021-01-09 02:39:13 --> Output Class Initialized
INFO - 2021-01-09 02:39:13 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:13 --> Input Class Initialized
INFO - 2021-01-09 02:39:13 --> Language Class Initialized
INFO - 2021-01-09 02:39:13 --> Language Class Initialized
INFO - 2021-01-09 02:39:13 --> Config Class Initialized
INFO - 2021-01-09 02:39:13 --> Loader Class Initialized
INFO - 2021-01-09 02:39:13 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:13 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:13 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:13 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:13 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:13 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:13 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/form.php
DEBUG - 2021-01-09 02:39:13 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:13 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:13 --> Total execution time: 0.3030
INFO - 2021-01-09 02:39:18 --> Config Class Initialized
INFO - 2021-01-09 02:39:18 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:18 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:18 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:18 --> URI Class Initialized
INFO - 2021-01-09 02:39:18 --> Router Class Initialized
INFO - 2021-01-09 02:39:18 --> Output Class Initialized
INFO - 2021-01-09 02:39:18 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:18 --> Input Class Initialized
INFO - 2021-01-09 02:39:18 --> Language Class Initialized
INFO - 2021-01-09 02:39:18 --> Language Class Initialized
INFO - 2021-01-09 02:39:18 --> Config Class Initialized
INFO - 2021-01-09 02:39:18 --> Loader Class Initialized
INFO - 2021-01-09 02:39:18 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:18 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:18 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:18 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:18 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:18 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 02:39:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:18 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:18 --> Total execution time: 0.3152
INFO - 2021-01-09 02:39:19 --> Config Class Initialized
INFO - 2021-01-09 02:39:19 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:19 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:19 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:19 --> URI Class Initialized
INFO - 2021-01-09 02:39:19 --> Router Class Initialized
INFO - 2021-01-09 02:39:19 --> Output Class Initialized
INFO - 2021-01-09 02:39:19 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:20 --> Input Class Initialized
INFO - 2021-01-09 02:39:20 --> Language Class Initialized
INFO - 2021-01-09 02:39:20 --> Language Class Initialized
INFO - 2021-01-09 02:39:20 --> Config Class Initialized
INFO - 2021-01-09 02:39:20 --> Loader Class Initialized
INFO - 2021-01-09 02:39:20 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:20 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:20 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:20 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:20 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:20 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:20 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-09 02:39:20 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:20 --> Total execution time: 0.3138
INFO - 2021-01-09 02:39:27 --> Config Class Initialized
INFO - 2021-01-09 02:39:27 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:27 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:27 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:27 --> URI Class Initialized
INFO - 2021-01-09 02:39:27 --> Router Class Initialized
INFO - 2021-01-09 02:39:27 --> Output Class Initialized
INFO - 2021-01-09 02:39:27 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:27 --> Input Class Initialized
INFO - 2021-01-09 02:39:27 --> Language Class Initialized
INFO - 2021-01-09 02:39:27 --> Language Class Initialized
INFO - 2021-01-09 02:39:27 --> Config Class Initialized
INFO - 2021-01-09 02:39:27 --> Loader Class Initialized
INFO - 2021-01-09 02:39:27 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:27 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:27 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:27 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:27 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:27 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 02:39:28 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:28 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:28 --> Total execution time: 0.2973
INFO - 2021-01-09 02:39:28 --> Config Class Initialized
INFO - 2021-01-09 02:39:29 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:29 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:29 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:29 --> URI Class Initialized
INFO - 2021-01-09 02:39:29 --> Router Class Initialized
INFO - 2021-01-09 02:39:29 --> Output Class Initialized
INFO - 2021-01-09 02:39:29 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:29 --> Input Class Initialized
INFO - 2021-01-09 02:39:29 --> Language Class Initialized
INFO - 2021-01-09 02:39:29 --> Language Class Initialized
INFO - 2021-01-09 02:39:29 --> Config Class Initialized
INFO - 2021-01-09 02:39:29 --> Loader Class Initialized
INFO - 2021-01-09 02:39:29 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:29 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:29 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:29 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:29 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:29 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 02:39:29 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:39:29 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:29 --> Total execution time: 0.2754
INFO - 2021-01-09 02:39:29 --> Config Class Initialized
INFO - 2021-01-09 02:39:29 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:29 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:29 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:29 --> URI Class Initialized
INFO - 2021-01-09 02:39:29 --> Router Class Initialized
INFO - 2021-01-09 02:39:29 --> Output Class Initialized
INFO - 2021-01-09 02:39:29 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:29 --> Input Class Initialized
INFO - 2021-01-09 02:39:29 --> Language Class Initialized
INFO - 2021-01-09 02:39:29 --> Language Class Initialized
INFO - 2021-01-09 02:39:29 --> Config Class Initialized
INFO - 2021-01-09 02:39:29 --> Loader Class Initialized
INFO - 2021-01-09 02:39:29 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:29 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:29 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:29 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:29 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:29 --> Controller Class Initialized
INFO - 2021-01-09 02:39:30 --> Config Class Initialized
INFO - 2021-01-09 02:39:30 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:39:30 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:39:30 --> Utf8 Class Initialized
INFO - 2021-01-09 02:39:30 --> URI Class Initialized
INFO - 2021-01-09 02:39:30 --> Router Class Initialized
INFO - 2021-01-09 02:39:30 --> Output Class Initialized
INFO - 2021-01-09 02:39:30 --> Security Class Initialized
DEBUG - 2021-01-09 02:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:39:30 --> Input Class Initialized
INFO - 2021-01-09 02:39:30 --> Language Class Initialized
INFO - 2021-01-09 02:39:30 --> Language Class Initialized
INFO - 2021-01-09 02:39:30 --> Config Class Initialized
INFO - 2021-01-09 02:39:30 --> Loader Class Initialized
INFO - 2021-01-09 02:39:30 --> Helper loaded: url_helper
INFO - 2021-01-09 02:39:30 --> Helper loaded: file_helper
INFO - 2021-01-09 02:39:30 --> Helper loaded: form_helper
INFO - 2021-01-09 02:39:30 --> Helper loaded: my_helper
INFO - 2021-01-09 02:39:30 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:39:30 --> Controller Class Initialized
DEBUG - 2021-01-09 02:39:30 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-09 02:39:30 --> Final output sent to browser
DEBUG - 2021-01-09 02:39:31 --> Total execution time: 0.3019
INFO - 2021-01-09 02:53:21 --> Config Class Initialized
INFO - 2021-01-09 02:53:21 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:53:21 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:53:21 --> Utf8 Class Initialized
INFO - 2021-01-09 02:53:21 --> URI Class Initialized
INFO - 2021-01-09 02:53:21 --> Router Class Initialized
INFO - 2021-01-09 02:53:21 --> Output Class Initialized
INFO - 2021-01-09 02:53:21 --> Security Class Initialized
DEBUG - 2021-01-09 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:53:21 --> Input Class Initialized
INFO - 2021-01-09 02:53:21 --> Language Class Initialized
INFO - 2021-01-09 02:53:21 --> Language Class Initialized
INFO - 2021-01-09 02:53:21 --> Config Class Initialized
INFO - 2021-01-09 02:53:21 --> Loader Class Initialized
INFO - 2021-01-09 02:53:21 --> Helper loaded: url_helper
INFO - 2021-01-09 02:53:21 --> Helper loaded: file_helper
INFO - 2021-01-09 02:53:21 --> Helper loaded: form_helper
INFO - 2021-01-09 02:53:21 --> Helper loaded: my_helper
INFO - 2021-01-09 02:53:21 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:53:21 --> Controller Class Initialized
INFO - 2021-01-09 02:53:21 --> Helper loaded: cookie_helper
INFO - 2021-01-09 02:53:21 --> Config Class Initialized
INFO - 2021-01-09 02:53:21 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:53:21 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:53:21 --> Utf8 Class Initialized
INFO - 2021-01-09 02:53:21 --> URI Class Initialized
INFO - 2021-01-09 02:53:21 --> Router Class Initialized
INFO - 2021-01-09 02:53:21 --> Output Class Initialized
INFO - 2021-01-09 02:53:21 --> Security Class Initialized
DEBUG - 2021-01-09 02:53:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:53:21 --> Input Class Initialized
INFO - 2021-01-09 02:53:21 --> Language Class Initialized
INFO - 2021-01-09 02:53:21 --> Language Class Initialized
INFO - 2021-01-09 02:53:21 --> Config Class Initialized
INFO - 2021-01-09 02:53:21 --> Loader Class Initialized
INFO - 2021-01-09 02:53:21 --> Helper loaded: url_helper
INFO - 2021-01-09 02:53:21 --> Helper loaded: file_helper
INFO - 2021-01-09 02:53:21 --> Helper loaded: form_helper
INFO - 2021-01-09 02:53:21 --> Helper loaded: my_helper
INFO - 2021-01-09 02:53:21 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:53:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:53:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:53:21 --> Controller Class Initialized
DEBUG - 2021-01-09 02:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-09 02:53:21 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:53:21 --> Final output sent to browser
DEBUG - 2021-01-09 02:53:21 --> Total execution time: 0.3039
INFO - 2021-01-09 02:53:26 --> Config Class Initialized
INFO - 2021-01-09 02:53:26 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:53:26 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:53:26 --> Utf8 Class Initialized
INFO - 2021-01-09 02:53:26 --> URI Class Initialized
INFO - 2021-01-09 02:53:26 --> Router Class Initialized
INFO - 2021-01-09 02:53:26 --> Output Class Initialized
INFO - 2021-01-09 02:53:26 --> Security Class Initialized
DEBUG - 2021-01-09 02:53:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:53:26 --> Input Class Initialized
INFO - 2021-01-09 02:53:26 --> Language Class Initialized
INFO - 2021-01-09 02:53:26 --> Language Class Initialized
INFO - 2021-01-09 02:53:26 --> Config Class Initialized
INFO - 2021-01-09 02:53:26 --> Loader Class Initialized
INFO - 2021-01-09 02:53:26 --> Helper loaded: url_helper
INFO - 2021-01-09 02:53:26 --> Helper loaded: file_helper
INFO - 2021-01-09 02:53:26 --> Helper loaded: form_helper
INFO - 2021-01-09 02:53:26 --> Helper loaded: my_helper
INFO - 2021-01-09 02:53:26 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:53:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:53:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:53:26 --> Controller Class Initialized
INFO - 2021-01-09 02:53:26 --> Helper loaded: cookie_helper
INFO - 2021-01-09 02:53:26 --> Final output sent to browser
DEBUG - 2021-01-09 02:53:26 --> Total execution time: 0.3620
INFO - 2021-01-09 02:53:27 --> Config Class Initialized
INFO - 2021-01-09 02:53:27 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:53:27 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:53:27 --> Utf8 Class Initialized
INFO - 2021-01-09 02:53:27 --> URI Class Initialized
INFO - 2021-01-09 02:53:27 --> Router Class Initialized
INFO - 2021-01-09 02:53:27 --> Output Class Initialized
INFO - 2021-01-09 02:53:27 --> Security Class Initialized
DEBUG - 2021-01-09 02:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:53:27 --> Input Class Initialized
INFO - 2021-01-09 02:53:27 --> Language Class Initialized
INFO - 2021-01-09 02:53:27 --> Language Class Initialized
INFO - 2021-01-09 02:53:27 --> Config Class Initialized
INFO - 2021-01-09 02:53:27 --> Loader Class Initialized
INFO - 2021-01-09 02:53:27 --> Helper loaded: url_helper
INFO - 2021-01-09 02:53:27 --> Helper loaded: file_helper
INFO - 2021-01-09 02:53:27 --> Helper loaded: form_helper
INFO - 2021-01-09 02:53:27 --> Helper loaded: my_helper
INFO - 2021-01-09 02:53:27 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:53:27 --> Controller Class Initialized
DEBUG - 2021-01-09 02:53:27 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-09 02:53:27 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:53:27 --> Final output sent to browser
DEBUG - 2021-01-09 02:53:27 --> Total execution time: 0.4471
INFO - 2021-01-09 02:53:34 --> Config Class Initialized
INFO - 2021-01-09 02:53:34 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:53:34 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:53:34 --> Utf8 Class Initialized
INFO - 2021-01-09 02:53:34 --> URI Class Initialized
INFO - 2021-01-09 02:53:34 --> Router Class Initialized
INFO - 2021-01-09 02:53:34 --> Output Class Initialized
INFO - 2021-01-09 02:53:34 --> Security Class Initialized
DEBUG - 2021-01-09 02:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:53:34 --> Input Class Initialized
INFO - 2021-01-09 02:53:34 --> Language Class Initialized
INFO - 2021-01-09 02:53:34 --> Language Class Initialized
INFO - 2021-01-09 02:53:34 --> Config Class Initialized
INFO - 2021-01-09 02:53:34 --> Loader Class Initialized
INFO - 2021-01-09 02:53:34 --> Helper loaded: url_helper
INFO - 2021-01-09 02:53:34 --> Helper loaded: file_helper
INFO - 2021-01-09 02:53:34 --> Helper loaded: form_helper
INFO - 2021-01-09 02:53:34 --> Helper loaded: my_helper
INFO - 2021-01-09 02:53:34 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:53:34 --> Controller Class Initialized
DEBUG - 2021-01-09 02:53:34 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/list.php
DEBUG - 2021-01-09 02:53:34 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 02:53:34 --> Final output sent to browser
DEBUG - 2021-01-09 02:53:34 --> Total execution time: 0.2966
INFO - 2021-01-09 02:53:37 --> Config Class Initialized
INFO - 2021-01-09 02:53:37 --> Hooks Class Initialized
DEBUG - 2021-01-09 02:53:37 --> UTF-8 Support Enabled
INFO - 2021-01-09 02:53:37 --> Utf8 Class Initialized
INFO - 2021-01-09 02:53:37 --> URI Class Initialized
INFO - 2021-01-09 02:53:37 --> Router Class Initialized
INFO - 2021-01-09 02:53:37 --> Output Class Initialized
INFO - 2021-01-09 02:53:37 --> Security Class Initialized
DEBUG - 2021-01-09 02:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 02:53:37 --> Input Class Initialized
INFO - 2021-01-09 02:53:37 --> Language Class Initialized
INFO - 2021-01-09 02:53:37 --> Language Class Initialized
INFO - 2021-01-09 02:53:37 --> Config Class Initialized
INFO - 2021-01-09 02:53:37 --> Loader Class Initialized
INFO - 2021-01-09 02:53:37 --> Helper loaded: url_helper
INFO - 2021-01-09 02:53:37 --> Helper loaded: file_helper
INFO - 2021-01-09 02:53:37 --> Helper loaded: form_helper
INFO - 2021-01-09 02:53:37 --> Helper loaded: my_helper
INFO - 2021-01-09 02:53:37 --> Database Driver Class Initialized
DEBUG - 2021-01-09 02:53:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 02:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 02:53:37 --> Controller Class Initialized
DEBUG - 2021-01-09 02:53:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-09 02:53:37 --> Final output sent to browser
DEBUG - 2021-01-09 02:53:37 --> Total execution time: 0.3264
INFO - 2021-01-09 03:05:02 --> Config Class Initialized
INFO - 2021-01-09 03:05:02 --> Hooks Class Initialized
DEBUG - 2021-01-09 03:05:02 --> UTF-8 Support Enabled
INFO - 2021-01-09 03:05:02 --> Utf8 Class Initialized
INFO - 2021-01-09 03:05:02 --> URI Class Initialized
INFO - 2021-01-09 03:05:02 --> Router Class Initialized
INFO - 2021-01-09 03:05:02 --> Output Class Initialized
INFO - 2021-01-09 03:05:02 --> Security Class Initialized
DEBUG - 2021-01-09 03:05:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 03:05:02 --> Input Class Initialized
INFO - 2021-01-09 03:05:02 --> Language Class Initialized
ERROR - 2021-01-09 03:05:02 --> Severity: Parsing Error --> syntax error, unexpected '$nilai_akhir' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 399
INFO - 2021-01-09 03:08:55 --> Config Class Initialized
INFO - 2021-01-09 03:08:55 --> Hooks Class Initialized
DEBUG - 2021-01-09 03:08:55 --> UTF-8 Support Enabled
INFO - 2021-01-09 03:08:55 --> Utf8 Class Initialized
INFO - 2021-01-09 03:08:55 --> URI Class Initialized
INFO - 2021-01-09 03:08:56 --> Router Class Initialized
INFO - 2021-01-09 03:08:56 --> Output Class Initialized
INFO - 2021-01-09 03:08:56 --> Security Class Initialized
DEBUG - 2021-01-09 03:08:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 03:08:56 --> Input Class Initialized
INFO - 2021-01-09 03:08:56 --> Language Class Initialized
ERROR - 2021-01-09 03:08:56 --> Severity: Parsing Error --> syntax error, unexpected '$nilai_akhir' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 401
INFO - 2021-01-09 03:17:42 --> Config Class Initialized
INFO - 2021-01-09 03:17:42 --> Hooks Class Initialized
DEBUG - 2021-01-09 03:17:42 --> UTF-8 Support Enabled
INFO - 2021-01-09 03:17:42 --> Utf8 Class Initialized
INFO - 2021-01-09 03:17:42 --> URI Class Initialized
INFO - 2021-01-09 03:17:42 --> Router Class Initialized
INFO - 2021-01-09 03:17:42 --> Output Class Initialized
INFO - 2021-01-09 03:17:42 --> Security Class Initialized
DEBUG - 2021-01-09 03:17:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 03:17:42 --> Input Class Initialized
INFO - 2021-01-09 03:17:42 --> Language Class Initialized
ERROR - 2021-01-09 03:17:42 --> Severity: Parsing Error --> syntax error, unexpected '$nilai_akhir' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 281
INFO - 2021-01-09 03:56:45 --> Config Class Initialized
INFO - 2021-01-09 03:56:45 --> Hooks Class Initialized
DEBUG - 2021-01-09 03:56:45 --> UTF-8 Support Enabled
INFO - 2021-01-09 03:56:45 --> Utf8 Class Initialized
INFO - 2021-01-09 03:56:45 --> URI Class Initialized
INFO - 2021-01-09 03:56:45 --> Router Class Initialized
INFO - 2021-01-09 03:56:45 --> Output Class Initialized
INFO - 2021-01-09 03:56:45 --> Security Class Initialized
DEBUG - 2021-01-09 03:56:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 03:56:45 --> Input Class Initialized
INFO - 2021-01-09 03:56:45 --> Language Class Initialized
ERROR - 2021-01-09 03:56:45 --> Severity: Parsing Error --> syntax error, unexpected '$nilai_akhir' (T_VARIABLE) C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 263
INFO - 2021-01-09 03:59:15 --> Config Class Initialized
INFO - 2021-01-09 03:59:15 --> Hooks Class Initialized
DEBUG - 2021-01-09 03:59:15 --> UTF-8 Support Enabled
INFO - 2021-01-09 03:59:15 --> Utf8 Class Initialized
INFO - 2021-01-09 03:59:15 --> URI Class Initialized
INFO - 2021-01-09 03:59:15 --> Router Class Initialized
INFO - 2021-01-09 03:59:15 --> Output Class Initialized
INFO - 2021-01-09 03:59:15 --> Security Class Initialized
DEBUG - 2021-01-09 03:59:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 03:59:15 --> Input Class Initialized
INFO - 2021-01-09 03:59:15 --> Language Class Initialized
INFO - 2021-01-09 03:59:15 --> Language Class Initialized
INFO - 2021-01-09 03:59:15 --> Config Class Initialized
INFO - 2021-01-09 03:59:15 --> Loader Class Initialized
INFO - 2021-01-09 03:59:15 --> Helper loaded: url_helper
INFO - 2021-01-09 03:59:15 --> Helper loaded: file_helper
INFO - 2021-01-09 03:59:15 --> Helper loaded: form_helper
INFO - 2021-01-09 03:59:15 --> Helper loaded: my_helper
INFO - 2021-01-09 03:59:15 --> Database Driver Class Initialized
DEBUG - 2021-01-09 03:59:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 03:59:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 03:59:15 --> Controller Class Initialized
ERROR - 2021-01-09 03:59:15 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 03:59:15 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
ERROR - 2021-01-09 03:59:15 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 03:59:15 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
ERROR - 2021-01-09 03:59:16 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 03:59:16 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
ERROR - 2021-01-09 03:59:16 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 03:59:16 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
DEBUG - 2021-01-09 03:59:16 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-09 03:59:16 --> Final output sent to browser
DEBUG - 2021-01-09 03:59:16 --> Total execution time: 0.3992
INFO - 2021-01-09 04:07:32 --> Config Class Initialized
INFO - 2021-01-09 04:07:32 --> Hooks Class Initialized
DEBUG - 2021-01-09 04:07:32 --> UTF-8 Support Enabled
INFO - 2021-01-09 04:07:32 --> Utf8 Class Initialized
INFO - 2021-01-09 04:07:32 --> URI Class Initialized
INFO - 2021-01-09 04:07:32 --> Router Class Initialized
INFO - 2021-01-09 04:07:32 --> Output Class Initialized
INFO - 2021-01-09 04:07:32 --> Security Class Initialized
DEBUG - 2021-01-09 04:07:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 04:07:32 --> Input Class Initialized
INFO - 2021-01-09 04:07:32 --> Language Class Initialized
INFO - 2021-01-09 04:07:32 --> Language Class Initialized
INFO - 2021-01-09 04:07:32 --> Config Class Initialized
INFO - 2021-01-09 04:07:32 --> Loader Class Initialized
INFO - 2021-01-09 04:07:32 --> Helper loaded: url_helper
INFO - 2021-01-09 04:07:32 --> Helper loaded: file_helper
INFO - 2021-01-09 04:07:32 --> Helper loaded: form_helper
INFO - 2021-01-09 04:07:32 --> Helper loaded: my_helper
INFO - 2021-01-09 04:07:32 --> Database Driver Class Initialized
DEBUG - 2021-01-09 04:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 04:07:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 04:07:32 --> Controller Class Initialized
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfa C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 375
ERROR - 2021-01-09 04:07:32 --> Severity: Notice --> Undefined variable: nfp C:\xampp\htdocs\nilai\application\modules\cetak_raport\controllers\Cetak_raport.php 376
DEBUG - 2021-01-09 04:07:32 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-09 04:07:32 --> Final output sent to browser
DEBUG - 2021-01-09 04:07:32 --> Total execution time: 0.4268
INFO - 2021-01-09 04:08:03 --> Config Class Initialized
INFO - 2021-01-09 04:08:03 --> Hooks Class Initialized
DEBUG - 2021-01-09 04:08:03 --> UTF-8 Support Enabled
INFO - 2021-01-09 04:08:03 --> Utf8 Class Initialized
INFO - 2021-01-09 04:08:03 --> URI Class Initialized
INFO - 2021-01-09 04:08:03 --> Router Class Initialized
INFO - 2021-01-09 04:08:03 --> Output Class Initialized
INFO - 2021-01-09 04:08:03 --> Security Class Initialized
DEBUG - 2021-01-09 04:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 04:08:03 --> Input Class Initialized
INFO - 2021-01-09 04:08:03 --> Language Class Initialized
INFO - 2021-01-09 04:08:03 --> Language Class Initialized
INFO - 2021-01-09 04:08:03 --> Config Class Initialized
INFO - 2021-01-09 04:08:03 --> Loader Class Initialized
INFO - 2021-01-09 04:08:03 --> Helper loaded: url_helper
INFO - 2021-01-09 04:08:03 --> Helper loaded: file_helper
INFO - 2021-01-09 04:08:03 --> Helper loaded: form_helper
INFO - 2021-01-09 04:08:03 --> Helper loaded: my_helper
INFO - 2021-01-09 04:08:04 --> Database Driver Class Initialized
DEBUG - 2021-01-09 04:08:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 04:08:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 04:08:04 --> Controller Class Initialized
DEBUG - 2021-01-09 04:08:04 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-09 04:08:04 --> Final output sent to browser
DEBUG - 2021-01-09 04:08:04 --> Total execution time: 0.3282
INFO - 2021-01-09 05:45:04 --> Config Class Initialized
INFO - 2021-01-09 05:45:04 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:04 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:04 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:04 --> URI Class Initialized
INFO - 2021-01-09 05:45:04 --> Router Class Initialized
INFO - 2021-01-09 05:45:04 --> Output Class Initialized
INFO - 2021-01-09 05:45:04 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:04 --> Input Class Initialized
INFO - 2021-01-09 05:45:04 --> Language Class Initialized
INFO - 2021-01-09 05:45:04 --> Language Class Initialized
INFO - 2021-01-09 05:45:04 --> Config Class Initialized
INFO - 2021-01-09 05:45:04 --> Loader Class Initialized
INFO - 2021-01-09 05:45:04 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:04 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:04 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:04 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:04 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:05 --> Controller Class Initialized
INFO - 2021-01-09 05:45:05 --> Helper loaded: cookie_helper
INFO - 2021-01-09 05:45:05 --> Config Class Initialized
INFO - 2021-01-09 05:45:05 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:05 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:05 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:05 --> URI Class Initialized
INFO - 2021-01-09 05:45:05 --> Router Class Initialized
INFO - 2021-01-09 05:45:05 --> Output Class Initialized
INFO - 2021-01-09 05:45:05 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:05 --> Input Class Initialized
INFO - 2021-01-09 05:45:05 --> Language Class Initialized
INFO - 2021-01-09 05:45:05 --> Language Class Initialized
INFO - 2021-01-09 05:45:05 --> Config Class Initialized
INFO - 2021-01-09 05:45:05 --> Loader Class Initialized
INFO - 2021-01-09 05:45:05 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:05 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:05 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:05 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:05 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:05 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\modules/login/views/login.php
DEBUG - 2021-01-09 05:45:05 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 05:45:05 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:05 --> Total execution time: 0.2936
INFO - 2021-01-09 05:45:09 --> Config Class Initialized
INFO - 2021-01-09 05:45:09 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:09 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:09 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:09 --> URI Class Initialized
INFO - 2021-01-09 05:45:09 --> Router Class Initialized
INFO - 2021-01-09 05:45:09 --> Output Class Initialized
INFO - 2021-01-09 05:45:09 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:10 --> Input Class Initialized
INFO - 2021-01-09 05:45:10 --> Language Class Initialized
INFO - 2021-01-09 05:45:10 --> Language Class Initialized
INFO - 2021-01-09 05:45:10 --> Config Class Initialized
INFO - 2021-01-09 05:45:10 --> Loader Class Initialized
INFO - 2021-01-09 05:45:10 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:10 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:10 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:10 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:10 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:10 --> Controller Class Initialized
INFO - 2021-01-09 05:45:10 --> Helper loaded: cookie_helper
INFO - 2021-01-09 05:45:10 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:10 --> Total execution time: 0.3737
INFO - 2021-01-09 05:45:10 --> Config Class Initialized
INFO - 2021-01-09 05:45:10 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:10 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:10 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:10 --> URI Class Initialized
INFO - 2021-01-09 05:45:10 --> Router Class Initialized
INFO - 2021-01-09 05:45:10 --> Output Class Initialized
INFO - 2021-01-09 05:45:10 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:10 --> Input Class Initialized
INFO - 2021-01-09 05:45:10 --> Language Class Initialized
INFO - 2021-01-09 05:45:10 --> Language Class Initialized
INFO - 2021-01-09 05:45:10 --> Config Class Initialized
INFO - 2021-01-09 05:45:10 --> Loader Class Initialized
INFO - 2021-01-09 05:45:10 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:10 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:10 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:10 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:10 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:11 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\modules/home/views/v_home.php
DEBUG - 2021-01-09 05:45:11 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 05:45:11 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:11 --> Total execution time: 0.4116
INFO - 2021-01-09 05:45:12 --> Config Class Initialized
INFO - 2021-01-09 05:45:12 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:12 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:12 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:12 --> URI Class Initialized
INFO - 2021-01-09 05:45:12 --> Router Class Initialized
INFO - 2021-01-09 05:45:12 --> Output Class Initialized
INFO - 2021-01-09 05:45:12 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:12 --> Input Class Initialized
INFO - 2021-01-09 05:45:12 --> Language Class Initialized
INFO - 2021-01-09 05:45:12 --> Language Class Initialized
INFO - 2021-01-09 05:45:12 --> Config Class Initialized
INFO - 2021-01-09 05:45:12 --> Loader Class Initialized
INFO - 2021-01-09 05:45:12 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:12 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:12 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:12 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:12 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:12 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 05:45:12 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 05:45:12 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:12 --> Total execution time: 0.3465
INFO - 2021-01-09 05:45:14 --> Config Class Initialized
INFO - 2021-01-09 05:45:14 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:14 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:14 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:14 --> URI Class Initialized
INFO - 2021-01-09 05:45:14 --> Router Class Initialized
INFO - 2021-01-09 05:45:14 --> Output Class Initialized
INFO - 2021-01-09 05:45:14 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:14 --> Input Class Initialized
INFO - 2021-01-09 05:45:14 --> Language Class Initialized
INFO - 2021-01-09 05:45:14 --> Language Class Initialized
INFO - 2021-01-09 05:45:14 --> Config Class Initialized
INFO - 2021-01-09 05:45:14 --> Loader Class Initialized
INFO - 2021-01-09 05:45:14 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:15 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:15 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:15 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:15 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:15 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/list.php
DEBUG - 2021-01-09 05:45:15 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 05:45:15 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:15 --> Total execution time: 0.3114
INFO - 2021-01-09 05:45:15 --> Config Class Initialized
INFO - 2021-01-09 05:45:15 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:15 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:15 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:15 --> URI Class Initialized
INFO - 2021-01-09 05:45:15 --> Router Class Initialized
INFO - 2021-01-09 05:45:15 --> Output Class Initialized
INFO - 2021-01-09 05:45:15 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:15 --> Input Class Initialized
INFO - 2021-01-09 05:45:15 --> Language Class Initialized
INFO - 2021-01-09 05:45:15 --> Language Class Initialized
INFO - 2021-01-09 05:45:15 --> Config Class Initialized
INFO - 2021-01-09 05:45:15 --> Loader Class Initialized
INFO - 2021-01-09 05:45:15 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:15 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:15 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:15 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:15 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:15 --> Controller Class Initialized
INFO - 2021-01-09 05:45:16 --> Config Class Initialized
INFO - 2021-01-09 05:45:16 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:16 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:16 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:16 --> URI Class Initialized
INFO - 2021-01-09 05:45:16 --> Router Class Initialized
INFO - 2021-01-09 05:45:16 --> Output Class Initialized
INFO - 2021-01-09 05:45:16 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:16 --> Input Class Initialized
INFO - 2021-01-09 05:45:16 --> Language Class Initialized
INFO - 2021-01-09 05:45:16 --> Language Class Initialized
INFO - 2021-01-09 05:45:16 --> Config Class Initialized
INFO - 2021-01-09 05:45:16 --> Loader Class Initialized
INFO - 2021-01-09 05:45:16 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:17 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:17 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:17 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:17 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:17 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:17 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_pengetahuan/views/cetak.php
INFO - 2021-01-09 05:45:17 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:17 --> Total execution time: 0.3268
INFO - 2021-01-09 05:45:18 --> Config Class Initialized
INFO - 2021-01-09 05:45:18 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:18 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:18 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:18 --> URI Class Initialized
INFO - 2021-01-09 05:45:18 --> Router Class Initialized
INFO - 2021-01-09 05:45:18 --> Output Class Initialized
INFO - 2021-01-09 05:45:18 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:18 --> Input Class Initialized
INFO - 2021-01-09 05:45:18 --> Language Class Initialized
INFO - 2021-01-09 05:45:18 --> Language Class Initialized
INFO - 2021-01-09 05:45:18 --> Config Class Initialized
INFO - 2021-01-09 05:45:18 --> Loader Class Initialized
INFO - 2021-01-09 05:45:18 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:18 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:18 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:18 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:18 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:18 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/view_mapel/views/v_view_mapel.php
DEBUG - 2021-01-09 05:45:18 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 05:45:18 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:18 --> Total execution time: 0.3160
INFO - 2021-01-09 05:45:19 --> Config Class Initialized
INFO - 2021-01-09 05:45:19 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:19 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:19 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:19 --> URI Class Initialized
INFO - 2021-01-09 05:45:19 --> Router Class Initialized
INFO - 2021-01-09 05:45:19 --> Output Class Initialized
INFO - 2021-01-09 05:45:19 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:19 --> Input Class Initialized
INFO - 2021-01-09 05:45:19 --> Language Class Initialized
INFO - 2021-01-09 05:45:19 --> Language Class Initialized
INFO - 2021-01-09 05:45:19 --> Config Class Initialized
INFO - 2021-01-09 05:45:19 --> Loader Class Initialized
INFO - 2021-01-09 05:45:19 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:19 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:19 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:19 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:19 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:19 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/list.php
DEBUG - 2021-01-09 05:45:19 --> File loaded: C:\xampp\htdocs\nilai\application\views\template_utama.php
INFO - 2021-01-09 05:45:19 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:19 --> Total execution time: 0.2905
INFO - 2021-01-09 05:45:21 --> Config Class Initialized
INFO - 2021-01-09 05:45:21 --> Hooks Class Initialized
DEBUG - 2021-01-09 05:45:21 --> UTF-8 Support Enabled
INFO - 2021-01-09 05:45:21 --> Utf8 Class Initialized
INFO - 2021-01-09 05:45:21 --> URI Class Initialized
INFO - 2021-01-09 05:45:21 --> Router Class Initialized
INFO - 2021-01-09 05:45:21 --> Output Class Initialized
INFO - 2021-01-09 05:45:21 --> Security Class Initialized
DEBUG - 2021-01-09 05:45:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 05:45:21 --> Input Class Initialized
INFO - 2021-01-09 05:45:21 --> Language Class Initialized
INFO - 2021-01-09 05:45:21 --> Language Class Initialized
INFO - 2021-01-09 05:45:21 --> Config Class Initialized
INFO - 2021-01-09 05:45:21 --> Loader Class Initialized
INFO - 2021-01-09 05:45:21 --> Helper loaded: url_helper
INFO - 2021-01-09 05:45:21 --> Helper loaded: file_helper
INFO - 2021-01-09 05:45:21 --> Helper loaded: form_helper
INFO - 2021-01-09 05:45:21 --> Helper loaded: my_helper
INFO - 2021-01-09 05:45:21 --> Database Driver Class Initialized
DEBUG - 2021-01-09 05:45:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 05:45:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 05:45:21 --> Controller Class Initialized
DEBUG - 2021-01-09 05:45:21 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-09 05:45:21 --> Final output sent to browser
DEBUG - 2021-01-09 05:45:21 --> Total execution time: 0.3213
INFO - 2021-01-09 09:10:35 --> Config Class Initialized
INFO - 2021-01-09 09:10:35 --> Hooks Class Initialized
DEBUG - 2021-01-09 09:10:35 --> UTF-8 Support Enabled
INFO - 2021-01-09 09:10:35 --> Utf8 Class Initialized
INFO - 2021-01-09 09:10:35 --> URI Class Initialized
INFO - 2021-01-09 09:10:35 --> Router Class Initialized
INFO - 2021-01-09 09:10:35 --> Output Class Initialized
INFO - 2021-01-09 09:10:35 --> Security Class Initialized
DEBUG - 2021-01-09 09:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 09:10:35 --> Input Class Initialized
INFO - 2021-01-09 09:10:35 --> Language Class Initialized
INFO - 2021-01-09 09:10:35 --> Language Class Initialized
INFO - 2021-01-09 09:10:35 --> Config Class Initialized
INFO - 2021-01-09 09:10:35 --> Loader Class Initialized
INFO - 2021-01-09 09:10:35 --> Helper loaded: url_helper
INFO - 2021-01-09 09:10:35 --> Helper loaded: file_helper
INFO - 2021-01-09 09:10:35 --> Helper loaded: form_helper
INFO - 2021-01-09 09:10:35 --> Helper loaded: my_helper
INFO - 2021-01-09 09:10:35 --> Database Driver Class Initialized
DEBUG - 2021-01-09 09:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 09:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 09:10:35 --> Controller Class Initialized
DEBUG - 2021-01-09 09:10:35 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-09 09:10:35 --> Final output sent to browser
DEBUG - 2021-01-09 09:10:35 --> Total execution time: 0.2494
INFO - 2021-01-09 09:11:36 --> Config Class Initialized
INFO - 2021-01-09 09:11:36 --> Hooks Class Initialized
DEBUG - 2021-01-09 09:11:36 --> UTF-8 Support Enabled
INFO - 2021-01-09 09:11:36 --> Utf8 Class Initialized
INFO - 2021-01-09 09:11:36 --> URI Class Initialized
INFO - 2021-01-09 09:11:36 --> Router Class Initialized
INFO - 2021-01-09 09:11:36 --> Output Class Initialized
INFO - 2021-01-09 09:11:36 --> Security Class Initialized
DEBUG - 2021-01-09 09:11:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 09:11:36 --> Input Class Initialized
INFO - 2021-01-09 09:11:36 --> Language Class Initialized
INFO - 2021-01-09 09:11:36 --> Language Class Initialized
INFO - 2021-01-09 09:11:36 --> Config Class Initialized
INFO - 2021-01-09 09:11:36 --> Loader Class Initialized
INFO - 2021-01-09 09:11:36 --> Helper loaded: url_helper
INFO - 2021-01-09 09:11:36 --> Helper loaded: file_helper
INFO - 2021-01-09 09:11:36 --> Helper loaded: form_helper
INFO - 2021-01-09 09:11:36 --> Helper loaded: my_helper
INFO - 2021-01-09 09:11:36 --> Database Driver Class Initialized
DEBUG - 2021-01-09 09:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 09:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 09:11:37 --> Controller Class Initialized
DEBUG - 2021-01-09 09:11:37 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-09 09:11:37 --> Final output sent to browser
DEBUG - 2021-01-09 09:11:37 --> Total execution time: 0.2545
INFO - 2021-01-09 09:29:18 --> Config Class Initialized
INFO - 2021-01-09 09:29:18 --> Hooks Class Initialized
DEBUG - 2021-01-09 09:29:18 --> UTF-8 Support Enabled
INFO - 2021-01-09 09:29:18 --> Utf8 Class Initialized
INFO - 2021-01-09 09:29:18 --> URI Class Initialized
INFO - 2021-01-09 09:29:18 --> Router Class Initialized
INFO - 2021-01-09 09:29:18 --> Output Class Initialized
INFO - 2021-01-09 09:29:18 --> Security Class Initialized
DEBUG - 2021-01-09 09:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 09:29:18 --> Input Class Initialized
INFO - 2021-01-09 09:29:18 --> Language Class Initialized
INFO - 2021-01-09 09:29:18 --> Language Class Initialized
INFO - 2021-01-09 09:29:18 --> Config Class Initialized
INFO - 2021-01-09 09:29:18 --> Loader Class Initialized
INFO - 2021-01-09 09:29:18 --> Helper loaded: url_helper
INFO - 2021-01-09 09:29:18 --> Helper loaded: file_helper
INFO - 2021-01-09 09:29:18 --> Helper loaded: form_helper
INFO - 2021-01-09 09:29:18 --> Helper loaded: my_helper
INFO - 2021-01-09 09:29:18 --> Database Driver Class Initialized
DEBUG - 2021-01-09 09:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 09:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 09:29:18 --> Controller Class Initialized
DEBUG - 2021-01-09 09:29:18 --> File loaded: C:\xampp\htdocs\nilai\application\modules/n_keterampilan/views/cetak.php
INFO - 2021-01-09 09:29:18 --> Final output sent to browser
DEBUG - 2021-01-09 09:29:18 --> Total execution time: 0.2947
INFO - 2021-01-09 09:29:29 --> Config Class Initialized
INFO - 2021-01-09 09:29:29 --> Hooks Class Initialized
DEBUG - 2021-01-09 09:29:29 --> UTF-8 Support Enabled
INFO - 2021-01-09 09:29:29 --> Utf8 Class Initialized
INFO - 2021-01-09 09:29:29 --> URI Class Initialized
INFO - 2021-01-09 09:29:29 --> Router Class Initialized
INFO - 2021-01-09 09:29:29 --> Output Class Initialized
INFO - 2021-01-09 09:29:29 --> Security Class Initialized
DEBUG - 2021-01-09 09:29:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-01-09 09:29:29 --> Input Class Initialized
INFO - 2021-01-09 09:29:29 --> Language Class Initialized
INFO - 2021-01-09 09:29:29 --> Language Class Initialized
INFO - 2021-01-09 09:29:29 --> Config Class Initialized
INFO - 2021-01-09 09:29:29 --> Loader Class Initialized
INFO - 2021-01-09 09:29:29 --> Helper loaded: url_helper
INFO - 2021-01-09 09:29:29 --> Helper loaded: file_helper
INFO - 2021-01-09 09:29:29 --> Helper loaded: form_helper
INFO - 2021-01-09 09:29:29 --> Helper loaded: my_helper
INFO - 2021-01-09 09:29:29 --> Database Driver Class Initialized
DEBUG - 2021-01-09 09:29:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-01-09 09:29:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-01-09 09:29:29 --> Controller Class Initialized
DEBUG - 2021-01-09 09:29:29 --> File loaded: C:\xampp\htdocs\nilai\application\modules/cetak_raport/views/cetak_rapot.php
INFO - 2021-01-09 09:29:29 --> Final output sent to browser
DEBUG - 2021-01-09 09:29:29 --> Total execution time: 0.2908
